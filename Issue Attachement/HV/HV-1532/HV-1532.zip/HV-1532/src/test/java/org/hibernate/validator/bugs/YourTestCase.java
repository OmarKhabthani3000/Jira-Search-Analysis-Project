package org.hibernate.validator.bugs;

import org.hibernate.validator.internal.engine.ConfigurationImpl;
import org.hibernate.validator.testutil.TestForIssue;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.Set;

import static org.junit.Assert.assertEquals;

public class YourTestCase {

    private static Validator validator;

    @BeforeClass
    public static void setUp() {
        ValidatorFactory factory = configure().buildValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    @TestForIssue(jiraKey = "HV-1532") // Please fill in the JIRA key of your issue
    public void testYourBug() {

        GenericBean2<Integer> genericBean = new GenericBean2<>();
        genericBean.setF1(new GenericBean<>(1));

        YourAnnotatedBean yourEntity1 = new YourAnnotatedBean();
        yourEntity1.setF1(genericBean);

        Set<ConstraintViolation<YourAnnotatedBean>> constraintViolations = validator.validate( yourEntity1 );
        assertEquals( 1, constraintViolations.size() );
        assertEquals(
                "must not be null",
                constraintViolations.iterator().next().getMessage() );
    }

    private static ConfigurationImpl configure() {

        ConfigurationImpl config = (ConfigurationImpl) Validation.byDefaultProvider().configure();

        config.ignoreXmlConfiguration();
        config.addValueExtractor(new GenericBeanValueExtractor());
        config.addValueExtractor(new GenericBean2ValueExtractor());

        return config;
    }
}