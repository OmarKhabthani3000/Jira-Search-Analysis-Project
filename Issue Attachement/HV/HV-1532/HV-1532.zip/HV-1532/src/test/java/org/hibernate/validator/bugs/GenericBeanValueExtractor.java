package org.hibernate.validator.bugs;

import javax.validation.valueextraction.ExtractedValue;
import javax.validation.valueextraction.ValueExtractor;

public class GenericBeanValueExtractor implements ValueExtractor<GenericBean<@ExtractedValue ?>> {

    @Override
    public void extractValues(GenericBean<?> originalValue, ValueExtractor.ValueReceiver receiver) {
        receiver.value( "f1", originalValue.getF1() );
    }
}