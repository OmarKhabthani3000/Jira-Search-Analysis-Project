package org.hibernate.validator.bugs;

public class GenericBean<T extends Number> {
    private T f1;

    public GenericBean(T f1) {
        this.f1 = f1;
    }

    public T getF1() {
        return f1;
    }

    public void setF1(T f1) {
        this.f1 = f1;
    }
}