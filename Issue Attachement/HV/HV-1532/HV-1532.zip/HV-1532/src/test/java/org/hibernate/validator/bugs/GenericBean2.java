package org.hibernate.validator.bugs;

import javax.validation.Valid;

public class GenericBean2<T extends Number> {
    @Valid
    private GenericBean<T> f1;

    @Valid
    private GenericBean<T> f2;


    public GenericBean<T> getF1() {
        return f1;
    }

    public void setF1(GenericBean<T> f1) {
        this.f1 = f1;
    }

    public GenericBean<T> getF2() {
        return f2;
    }

    public void setF2(GenericBean<T> f2) {
        this.f2 = f2;
    }
}