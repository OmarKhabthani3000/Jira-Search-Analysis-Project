package org.hibernate.validator.bugs;

import javax.validation.valueextraction.ExtractedValue;
import javax.validation.valueextraction.ValueExtractor;

public class GenericBean2ValueExtractor implements ValueExtractor<GenericBean2<@ExtractedValue ?>> {

    @Override
    public void extractValues(GenericBean2<?> originalValue, ValueReceiver receiver) {
        receiver.value( "f1", originalValue.getF1() );
        receiver.value( "f2", originalValue.getF2() );
    }
}