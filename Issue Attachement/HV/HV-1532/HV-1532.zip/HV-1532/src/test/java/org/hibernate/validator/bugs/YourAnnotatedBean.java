package org.hibernate.validator.bugs;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class YourAnnotatedBean {

    @Valid
    private GenericBean2<@NotNull Integer> f1;


    public GenericBean2<Integer> getF1() {
        return f1;
    }

    public void setF1(GenericBean2<Integer> f1) {
        this.f1 = f1;
    }
}