package com.ttsltd.test;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * Part of a test setup to prove a flaw in hibernate validator
 */
public class TestValidator implements ConstraintValidator<IsValid, DummyTestClass>{

	@Override
	public void initialize(IsValid isValid) {}

	@Override
	public boolean isValid(DummyTestClass dummyTestClass, ConstraintValidatorContext constraintValidatorContext) {
		constraintValidatorContext.disableDefaultConstraintViolation();
		constraintValidatorContext.buildConstraintViolationWithTemplate("Changed error message").addConstraintViolation();
		return false;
	}
}