package com.ttsltd.test;

import static org.junit.Assert.*;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.junit.Test;

/**
 * TestClass represents an instance of
 */
public class TestClass {


	/**
	 * test
	 * @throws Exception
	 */
	@Test
	public void test() throws Exception {

	    ValidatorFactory  factory           = Validation.buildDefaultValidatorFactory();
		Validator         validator         = factory.getValidator();
		DummyTestClass dummyTestClass = new DummyTestClass();

		Set<ConstraintViolation<DummyTestClass>> constraintViolations = validator.validate(dummyTestClass, TestChecks.class);

		for (ConstraintViolation<DummyTestClass> instance : constraintViolations)
			assertEquals("Changed error message", instance.getMessage());
	}
}