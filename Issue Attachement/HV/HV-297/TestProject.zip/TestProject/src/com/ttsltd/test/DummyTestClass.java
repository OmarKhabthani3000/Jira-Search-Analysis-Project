package com.ttsltd.test;

/**
 * Part of a test setup to prove a flaw in hibernate validator
 */
@IsValid(groups=TestChecks.class)
public class DummyTestClass {}