package com.ttsltd.test;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;

/**
 * Part of a test setup to prove a flaw in hibernate validator
 */
@Target(TYPE)
@Retention(RUNTIME)
@Constraint(validatedBy = TestValidator.class)
@Documented
@ReportAsSingleViolation
public @interface IsValid {
	/**
	 * groups
	 * @return
	 */
	Class<?>[] groups() default {};

	/**
	 * message
	 * @return
	 */
	String message() default "Default error message";

	/**
	 * payload
	 * @return
	 */
	Class<? extends Payload>[] payload() default {};
}