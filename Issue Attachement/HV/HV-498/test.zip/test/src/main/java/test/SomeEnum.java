package test;

public enum SomeEnum
{
    VALUE1,
    VALUE2
}
