package testvalidation;

public class Dumn {

	/**
	 * @param args
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws ClassNotFoundException {
		Class<?> clazz = Class.forName("org.jboss.resteasy.plugins.validation.hibernate.HibernateValidatorContextResolver");
	}

}
