package testvalidation.services;

import javax.ejb.Stateless;

import testvalidation.TestBean;
import testvalidation.services.interfaces.TestService;


@Stateless
public class TestServiceBean implements TestService {

	@Override
	public String test(TestBean test) {
		return "tralala";
	}

}
