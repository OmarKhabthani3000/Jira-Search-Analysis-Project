package testvalidation.services;

import javax.ws.rs.core.MediaType;

import org.jboss.resteasy.client.ClientRequest;
import org.junit.Test;

import testvalidation.TestBean;


public class TestServiceBeanTest {

	@Test
	public void testValidation() throws Exception {
		ClientRequest req = new ClientRequest("http://localhost:8080/testvalidation/validationTest");
		req.body(MediaType.APPLICATION_JSON_TYPE, new TestBean());
		req.post();
	}
}
