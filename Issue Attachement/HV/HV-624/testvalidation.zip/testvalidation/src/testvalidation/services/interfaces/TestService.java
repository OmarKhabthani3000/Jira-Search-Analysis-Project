package testvalidation.services.interfaces;

import javax.ejb.Local;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

import org.jboss.resteasy.spi.validation.ValidateRequest;

import testvalidation.TestBean;


@Path("validationTest")
@Local
public interface TestService {
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@ValidateRequest
	public String test(@Valid TestBean test);
}
