package bval.rest;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import bval.ejb.Test;

@Local
@Stateless
@Path("/")
public class RestService {
	
	@EJB
	private Test ejb;
	
	@GET
	@Path("/test")
	@Produces(MediaType.APPLICATION_JSON)
	public String validateParam(@QueryParam("value") String value) {
		return ejb.validate(value);
	}

}
