package bval.interceptor;

import java.util.Set;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
//import javax.validation.ValidatorFactory;
import javax.validation.executable.ExecutableValidator;
/* For Weblogic workaround
import weblogic.ejb.container.interfaces.WLEnterpriseBean;
import weblogic.ejb.container.internal.SessionEJBContextImpl;
*/
public class ValidateParameters {
	//For by pass metadata cache, do not reuse validator factory:
	//private static final ValidatorFactory VALIDATOR_FACTORY = Validation.buildDefaultValidatorFactory();
	
	@AroundInvoke
	public Object checkArguments(InvocationContext context) throws Exception {
		
		validateParameters(context);
		
		return context.proceed();
	}

	private void validateParameters(InvocationContext context) throws Exception {
		
		Object target = context.getTarget();
		
		/* For Weblogic workaround
		if (context.getTarget() instanceof WLEnterpriseBean) {
			WLEnterpriseBean wLEnterpriseBean = (WLEnterpriseBean)context.getTarget();
			SessionEJBContextImpl sessionEJBContextImpl = (SessionEJBContextImpl)wLEnterpriseBean.__WL_getEJBContext();
			String packageName = context.getTarget().getClass().getPackage().getName();
			try {
				target = Class.forName(packageName + '.' + sessionEJBContextImpl.getEJBName()).newInstance();
			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
				throw new RuntimeException(e);
			}

		}
		*/
		
//		ExecutableValidator executableValidator = VALIDATOR_FACTORY.getValidator().forExecutables();
		//For by pass metadata cache, do not reuse validator factory:
		ExecutableValidator executableValidator = Validation.buildDefaultValidatorFactory().getValidator().forExecutables();
		
		Set<ConstraintViolation<Object>> errors = executableValidator.validateParameters(
				target,
				context.getMethod(),
				context.getParameters());
		
		if (!errors.isEmpty()) {
			String errorDetail = getValidationErrorMessages(errors);
			throw new IllegalArgumentException(errorDetail);
		}
	}
	
	private String getValidationErrorMessages(Set<ConstraintViolation<Object>> errors) {
		StringBuilder stringBuilder = new StringBuilder();
		for (ConstraintViolation<Object> error : errors) {
			stringBuilder.append(String.format(
					"%n%s(%s)-> %s",
					error.getPropertyPath(),
					error.getInvalidValue(),
					error.getMessage()));
		}
		return stringBuilder.toString();
	}
}
