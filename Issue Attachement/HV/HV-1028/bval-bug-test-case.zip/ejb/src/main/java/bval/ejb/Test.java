package bval.ejb;

import javax.ejb.Local;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

@Local
public interface Test {
	
	String validate(@NotBlank @Size(max = 2) String param);

}
