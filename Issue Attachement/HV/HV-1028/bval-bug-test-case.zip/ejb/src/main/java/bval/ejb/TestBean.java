package bval.ejb;

import javax.ejb.Stateless;
import javax.interceptor.Interceptors;

import bval.interceptor.ValidateParameters;

@Stateless
public class TestBean implements Test {

	@Override
	@Interceptors(ValidateParameters.class)
	public String validate(String param) {
		return "OK";
	}

}
