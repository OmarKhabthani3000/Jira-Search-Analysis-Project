package bval.test;

import java.lang.reflect.Method;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.executable.ExecutableValidator;

import org.junit.Assert;
import org.junit.Test;

public class ValidationTest {

	@Test
	public void test() throws NoSuchMethodException, SecurityException {
		int totalErrors = 0;
//		int totalNoErrors = 0;
				
		TestImplFake testImplFake = new TestImplFake();
		
		Method method = TestImplFake.class.getMethod( "validate", String.class );
		Object[] parameterValues = { "123" };
		
		for (int i = 0; i < 10; i++) {	
			ExecutableValidator executableValidator = Validation.buildDefaultValidatorFactory().getValidator().forExecutables();
			
			Set<ConstraintViolation<TestImplFake>> errors = executableValidator.validateParameters(
					testImplFake,
					method,
					parameterValues);
			
			if (!errors.isEmpty()) {
				totalErrors++;
			} else {
				//totalNoErrors++;
				System.out.println("Fail, should has errors!");
			}
		}
		
//		Assert.assertEquals(0, totalNoErrors);
		Assert.assertEquals(10, totalErrors);
	}

}
