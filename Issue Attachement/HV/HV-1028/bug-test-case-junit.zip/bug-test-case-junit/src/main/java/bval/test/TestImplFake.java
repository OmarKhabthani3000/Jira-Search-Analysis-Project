package bval.test;

public class TestImplFake extends TestImpl implements TestFake {

	public void doNothing() {
		
	}
}
