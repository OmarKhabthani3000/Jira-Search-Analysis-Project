package bval.test;

import javax.validation.constraints.Size;

public interface Test {
	
	String validate(@Size(min = 1, max = 2) String param);

}
