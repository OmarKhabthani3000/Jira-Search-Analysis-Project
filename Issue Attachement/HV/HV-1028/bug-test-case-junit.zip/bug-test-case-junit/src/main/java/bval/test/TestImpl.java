package bval.test;

public class TestImpl implements Test {

	@Override
	public String validate(String param) {
		return "OK";
	}

}
