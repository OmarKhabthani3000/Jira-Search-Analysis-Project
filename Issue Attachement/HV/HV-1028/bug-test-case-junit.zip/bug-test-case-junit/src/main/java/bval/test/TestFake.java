package bval.test;


public interface TestFake {
	
	String validate(String param);

}
