package org.hibernate.validator.benchmark.hv1040;

import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class StringValidator implements ConstraintValidator<FieldLevelConstraint, String> {

	@Override
	public void initialize(FieldLevelConstraint constraintAnnotation) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {

		List<String> errors = StringValidationService.getInstance().validate( value );
		return errors.size() == 0;
	}

}
