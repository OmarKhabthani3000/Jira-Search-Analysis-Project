package org.hibernate.validator.benchmark.hv1040;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Manages the validation of String values.
 *
 * @author andre.hernandez
 */
public class StringValidationService {

	private static final String VALIDATION_REGEX = "^[A-Za-z0-9]+$";
	private Pattern pattern;
	private static final String INVALID_MESSAGE = "String failed validation";

	private final static StringValidationService INSTANCE = new StringValidationService();

	private StringValidationService() {
		pattern = Pattern.compile( VALIDATION_REGEX );
	}

	public static StringValidationService getInstance() {
		return INSTANCE;
	}

	public List<String> validate(String value) {

		List<String> errors = new ArrayList<String>();

		if ( value == null ) {
			return errors;
		}

		boolean valid = pattern.matcher( value ).matches();

		if ( !valid ) {
			errors.add( INVALID_MESSAGE );
		}

		return errors;
	}

}
