package org.hibernate.validator.benchmark.hv1040.test;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.junit.Before;
import org.junit.Test;

public class ValidationSpeedTest {

	private TestBean testBeanBuiltIn;
	private TestBean2 testBeanCustomFieldLevel;
	private TestBean3 testBeanCustomClassLevel;
	private ValidatorFactory factory = Validation
			.buildDefaultValidatorFactory();

	private Validator validator = factory.getValidator();

	private static final int MAX_ITERATIONS = 1_000_000;

	@Before
	public void setUp() throws Exception {
		testBeanBuiltIn = new TestBean();
		testBeanBuiltIn.setField1("A");
		testBeanBuiltIn.setField2("B");
		testBeanBuiltIn.setField3("C");
		testBeanBuiltIn.setField4("D");
		testBeanBuiltIn.setField5("E");
		testBeanBuiltIn.setField6("F");
		testBeanBuiltIn.setField7("G");
		testBeanBuiltIn.setField8("H");

		testBeanCustomFieldLevel = new TestBean2();
		testBeanCustomFieldLevel.setField1("A");
		testBeanCustomFieldLevel.setField2("B");
		testBeanCustomFieldLevel.setField3("C");
		testBeanCustomFieldLevel.setField4("D");
		testBeanCustomFieldLevel.setField5("E");
		testBeanCustomFieldLevel.setField6("F");
		testBeanCustomFieldLevel.setField7("G");
		testBeanCustomFieldLevel.setField8("H");

		testBeanCustomClassLevel = new TestBean3();
		testBeanCustomClassLevel.setField1("A");
		testBeanCustomClassLevel.setField2("B");
		testBeanCustomClassLevel.setField3("C");
		testBeanCustomClassLevel.setField4("D");
		testBeanCustomClassLevel.setField5("E");
		testBeanCustomClassLevel.setField6("F");
		testBeanCustomClassLevel.setField7("G");
		testBeanCustomClassLevel.setField8("H");

	}

	@Test
	public void testBuiltInValidator() {

		long start = System.currentTimeMillis();

		for (int i = 0; i < MAX_ITERATIONS; i++) {
			validateBean(testBeanBuiltIn);
		}

		long end = System.currentTimeMillis();

		System.out.println("Time to Validate (Built-in): " + (end - start));

	}

	@Test
	public void testCustomConstraintFieldLevel() {

		long start = System.currentTimeMillis();

		for (int i = 0; i < MAX_ITERATIONS; i++) {
			validateBean(testBeanCustomFieldLevel);
		}

		long end = System.currentTimeMillis();

		System.out.println("Time to Validate (Field-level): " + (end - start));

	}

	@Test
	public void testCustomConstraintClassLevel() {

		long start = System.currentTimeMillis();

		for (int i = 0; i < MAX_ITERATIONS; i++) {
			validateBean(testBeanCustomClassLevel);
		}

		long end = System.currentTimeMillis();

		System.out.println("Time to Validate (Class-level): " + (end - start));

	}

	@Test
	public void testNoValidation() {

		long start = System.currentTimeMillis();

		for (int i = 0; i < MAX_ITERATIONS; i++) {
			testBeanBuiltIn.getField1();
			testBeanBuiltIn.getField2();
			testBeanBuiltIn.getField3();
			testBeanBuiltIn.getField4();
			testBeanBuiltIn.getField5();
			testBeanBuiltIn.getField6();
			testBeanBuiltIn.getField7();
			testBeanBuiltIn.getField8();
		}

		long end = System.currentTimeMillis();

		System.out.println("Time (no validation): " + (end - start));

	}

	private <T> Set<ConstraintViolation<T>> validateBean(T bean) {

		Set<ConstraintViolation<T>> constraintViolations = null;

		constraintViolations = validator.validate(bean);

		return constraintViolations;
	}

}
