package main;

import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class Validator implements ConstraintValidator<ClassLevelConstraint, Object> {
	
	@Override
	public void initialize(ClassLevelConstraint constraintAnnotation) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isValid(Object bean, ConstraintValidatorContext context) {
		
		List<String> errors = ValidationService.getInstance().validate(bean);
		return errors.size() == 0;
	}

}
