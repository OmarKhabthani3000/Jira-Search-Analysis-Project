package main;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * Manages the validation of bean at a class-level and the required reflection
 * to perform field-level validation. The field-level annotations will determine
 * which validation service will be called.
 * 
 * @author andre.hernandez
 *
 */
public class ValidationService {

	private final static ValidationService INSTANCE = new ValidationService();

	private ValidationService() {

	}

	public static ValidationService getInstance() {
		return INSTANCE;
	}

	/**
	 * Validates bean
	 * 
	 * @param bean
	 * @return
	 */
	public List<String> validate(Object bean) {
		List<String> errors = new ArrayList<String>();

		if (bean == null) {
			return errors;
		}

		try {
			
			// Get all field-level annotations
			Field[] fields = bean.getClass().getDeclaredFields();
			fieldsLoop: for (Field field : fields) {

				boolean valid = false;
				Annotation[] annotations = field.getAnnotations();
				for (Annotation annotation : annotations) {
					valid = isValid(bean, errors, field, annotation);

					if (!valid) {
						break fieldsLoop;
					}
				}

			}
		} catch (IllegalArgumentException | IllegalAccessException e) {
			errors.add(e.getMessage());
		}

		return errors;
	}

	/**
	 * 
	 * Manage bean validation
	 * 
	 * @param bean
	 * @param errors
	 * @param field
	 * @param annotation
	 * @return
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private boolean isValid(Object bean, List<String> errors, Field field,
			Annotation annotation) throws IllegalArgumentException,
			IllegalAccessException {
		Object object;
		boolean valid = false;
		// Call appropriate validation service per annotation
		if (annotation.annotationType().equals(FieldLevelAnnotation.class)) {
			object = field.getType();
			if (object.equals(String.class)) {
				field.setAccessible(true);
				object = field.get(bean);
				String stringValue = null;
				if (object != null) {
					stringValue = (String) object;
				}
				errors.addAll(StringValidationService.getInstance().validate(
						stringValue));
			} else {
				throw new IllegalArgumentException(
						"@FieldLevelAnnotation may only be used on a String");
			}
		}
		return valid;
	}

}
