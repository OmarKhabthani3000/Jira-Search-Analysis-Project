package org.example;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.Set;

@JsonIdentityInfo(
  generator = ObjectIdGenerators.PropertyGenerator.class,
  property = "id",
  scope = Parent.class)
public class Parent
{
  @NotNull
  private Long id;

  @Valid
  private Set<Child> children = new HashSet<>();

  public Long getId()
  {
    return id;
  }

  public void setId(Long id)
  {
    this.id = id;
  }

  public Set<Child> getChildren()
  {
    return children;
  }

  public void setChildren(Set<Child> children)
  {
    this.children = children;
  }
}