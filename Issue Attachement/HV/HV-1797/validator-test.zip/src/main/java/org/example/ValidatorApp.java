package org.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidatorApp
{
  public static void main(final String[] argv)
  {
    SpringApplication.run(ValidatorApp.class, argv);
  }
}
