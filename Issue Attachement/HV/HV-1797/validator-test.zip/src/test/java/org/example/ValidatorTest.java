package org.example;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
public class ValidatorTest
{
  @Autowired
  private MockMvc mvc;

  @Test
  public void test() throws Exception
  {
    final MvcResult result = mvc.perform(get("/").accept(MediaType.APPLICATION_JSON))
      .andExpect(status().is2xxSuccessful()).andReturn();

    final String json = result.getResponse().getContentAsString();
    System.out.println(json);

    mvc.perform(post("/").contentType(MediaType.APPLICATION_JSON).content(json))
      .andExpect(status().is2xxSuccessful());
  }
}
