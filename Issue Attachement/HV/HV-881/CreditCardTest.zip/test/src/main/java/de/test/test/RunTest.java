package de.test.test;

import javax.validation.Validation;

public class RunTest {
	
    public static void main(String args[]) {
    	Validation.buildDefaultValidatorFactory().getValidator().validate(new TestVO());
    }
}
