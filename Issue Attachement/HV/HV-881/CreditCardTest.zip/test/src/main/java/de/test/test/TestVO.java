package de.test.test;

import org.hibernate.validator.constraints.CreditCardNumber;

public class TestVO {
	@CreditCardNumber(message = "141")
	public String getCreditCardNumber() {
		return "4411111111111";
	}
}
