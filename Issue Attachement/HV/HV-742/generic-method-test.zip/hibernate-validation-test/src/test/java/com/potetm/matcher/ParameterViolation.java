package com.potetm.matcher;

import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

import org.hibernate.validator.method.MethodConstraintViolation;
import org.hibernate.validator.method.MethodConstraintViolationException;

import java.text.MessageFormat;

/**
 *
 * @author tpote
 */
@SuppressWarnings("deprecation")
public class ParameterViolation extends TypeSafeMatcher<MethodConstraintViolationException> {
  private int              index;
  private ViolationMessage violationMessage;

  public ParameterViolation(int index, ViolationMessage violationMessage) {
    this.index            = index;
    this.violationMessage = violationMessage;
  }

  public enum ViolationMessage {
    NOT_NULL("may not be null"), MIN("must be greater than or equal to"), PATTERN_REGEX("must match");

    private String message;

    private ViolationMessage(String message) {
      this.message = message;
    }

    public String getMessage() {
      return message;
    }
  }

  @Override
  @SuppressWarnings( {
    "rawtypes", "deprecation"
  })
  public boolean matchesSafely(MethodConstraintViolationException mcve) {
    for (MethodConstraintViolation c : mcve.getConstraintViolations()) {
      if ((c.getKind() == MethodConstraintViolation.Kind.PARAMETER) && (c.getParameterIndex() == index)) {
        return c.getMessage().contains(violationMessage.getMessage());
      }
    }

    return false;
  }

  @Override
  public void describeTo(Description description) {
    description.appendText(MessageFormat.format("has no contraint violation for parameter {0} with message containing '{1}'", index, violationMessage.getMessage()));
  }
}

