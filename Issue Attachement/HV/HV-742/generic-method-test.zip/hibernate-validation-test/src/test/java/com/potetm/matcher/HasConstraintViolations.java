package com.potetm.matcher;

import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

import org.hibernate.validator.method.MethodConstraintViolationException;

import java.text.MessageFormat;

/**
 *
 * @author tpote
 */
@SuppressWarnings("deprecation")
public class HasConstraintViolations extends TypeSafeMatcher<MethodConstraintViolationException> {
  private Integer constraintViolationCount;

  public HasConstraintViolations(Integer constraintViolationCount) {
    this.constraintViolationCount = constraintViolationCount;
  }

  @Override
  protected boolean matchesSafely(MethodConstraintViolationException mcve) {
    return mcve.getConstraintViolations().size() == constraintViolationCount;
  }

  @Override
  public void describeTo(Description description) {
    description.appendText(MessageFormat.format("has {0} contraint violations", constraintViolationCount));
  }
}

