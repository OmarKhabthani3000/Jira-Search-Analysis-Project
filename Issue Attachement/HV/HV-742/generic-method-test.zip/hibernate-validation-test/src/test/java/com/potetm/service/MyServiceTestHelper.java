package com.potetm.service;

import com.potetm.matcher.HasConstraintViolations;
import com.potetm.matcher.ParameterViolation;
import com.potetm.matcher.ParameterViolation.ViolationMessage;
import com.potetm.service.api.MyService;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/applicationContext.xml")
public class MyServiceTestHelper {
  @Rule
  public ExpectedException error = ExpectedException.none();
  @Inject
  private MyService        myService;

  @Test
  @DirtiesContext
  public void test_standardMethod() {
    error.expect(hasConstraintViolations(1));
    error.expect(hasNullViolationOnParameter(0));
    myService.standardMethod(null);
  }

  @Test
  @DirtiesContext
  public void test_genericMethod() {
    error.expect(hasConstraintViolations(1));
    error.expect(hasNullViolationOnParameter(0));
    myService.genericMethod(null);
  }

  private HasConstraintViolations hasConstraintViolations(int count) {
    return new HasConstraintViolations(count);
  }

  private ParameterViolation hasNullViolationOnParameter(int index) {
    return new ParameterViolation(index, ViolationMessage.NOT_NULL);
  }
}

