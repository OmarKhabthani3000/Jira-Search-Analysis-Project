package com.potetm.service.api;

import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;

/**
 *
 * @author tpote
 */
@Validated
public interface MyService {
  public void standardMethod(@NotNull String string);

  public <T> void genericMethod(@NotNull T t);
}

