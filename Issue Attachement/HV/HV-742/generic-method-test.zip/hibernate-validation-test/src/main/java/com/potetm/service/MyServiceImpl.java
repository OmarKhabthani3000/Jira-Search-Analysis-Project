package com.potetm.service;

import com.potetm.service.api.MyService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

@Service
public class MyServiceImpl implements MyService {
  private static final Logger LOGGER = LoggerFactory.getLogger(MyServiceImpl.class);

  public <T> void genericMethod(T t) {
    LOGGER.debug("genericMethod called");
  }

  public void standardMethod(String string) {
    LOGGER.debug("standardMethod called");
  }
}

