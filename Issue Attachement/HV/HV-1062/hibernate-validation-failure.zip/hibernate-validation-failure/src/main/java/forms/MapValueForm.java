package forms;

import annotations.NotBlankTypeUse;

import javax.validation.Valid;
import java.util.Map;

public class MapValueForm {
    @Valid
    public Map<String, @NotBlankTypeUse String> data;

    public MapValueForm(Map<String, String> data) {
        this.data = data;
    }
}
