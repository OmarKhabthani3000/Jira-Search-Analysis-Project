package forms;

import annotations.NotBlankTypeUse;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Map;

public class NotNullMapValueForm {
    @NotNull
    @Valid
    public Map<String, @NotBlankTypeUse String> data;

    public NotNullMapValueForm(Map<String, String> data) {
        this.data = data;
    }
}
