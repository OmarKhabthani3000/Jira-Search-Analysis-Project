package forms;

import annotations.NotBlankTypeUse;

import javax.validation.Valid;
import java.util.List;

public class ListForm {
    @Valid
    public List<@NotBlankTypeUse String> data;

    public ListForm(List<String> data) {
        this.data = data;
    }
}
