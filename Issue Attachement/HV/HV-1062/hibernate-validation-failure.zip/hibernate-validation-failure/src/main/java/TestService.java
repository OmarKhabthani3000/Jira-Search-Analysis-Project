import forms.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class TestService {

    public String methodForMapValue(@Valid MapValueForm form) {
        return "OK";
    }

    public String methodForNotNullMapValue(@NotNull @Valid NotNullMapValueForm form) {
        return "OK";
    }

    public String methodForMapKey(@Valid MapKeyForm form) {
        return "OK";
    }

    public String methodForNotNullMapKey(@Valid NotNullMapKeyForm form) {
        return "OK";
    }

    public String methodForList(@Valid ListForm form) {
        return "OK";
    }

    public String methodForNotNullList(@NotNull @Valid NotNullListForm form) {
        return "OK";
    }

}
