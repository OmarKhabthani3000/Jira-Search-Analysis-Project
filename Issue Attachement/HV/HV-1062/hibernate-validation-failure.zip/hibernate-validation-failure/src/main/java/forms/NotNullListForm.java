package forms;

import annotations.NotBlankTypeUse;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

public class NotNullListForm {
    @NotNull
    @Valid
    public List<@NotBlankTypeUse String> data;

    public NotNullListForm(List<String> data) {
        this.data = data;
    }
}
