package forms;

import annotations.NotBlankTypeUse;

import javax.validation.Valid;
import java.util.Map;

public class MapKeyForm {
    @Valid
    public Map<@NotBlankTypeUse String, String> data;

    public MapKeyForm(Map<String, String> data) {
        this.data = data;
    }
}
