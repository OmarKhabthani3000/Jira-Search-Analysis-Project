package poc.validation;

import javax.faces.bean.ManagedBean;
import javax.inject.Inject;

@ManagedBean(name = "helloWorld", eager = true)
public class HelloWorld {
	@Inject
	private MyInterface bean;
	
   public HelloWorld() {
      System.out.println("HelloWorld started!");
   }
   public String getMessage() {
	  return bean.lookup(null);
   }
}