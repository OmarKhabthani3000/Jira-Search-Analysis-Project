package poc.validation;

import javax.ejb.Stateless;
import javax.validation.constraints.NotNull;

@Stateless
public class MyBean extends MyInterface{
	 	@Override
        public String lookup(String text){
             return "found3";
        }
}