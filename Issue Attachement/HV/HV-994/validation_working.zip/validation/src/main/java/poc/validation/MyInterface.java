package poc.validation;

import javax.validation.constraints.NotNull;

public abstract class MyInterface {
	public abstract String lookup(@NotNull String text);
}
