package poc.validation;

import javax.ejb.Stateless;
import javax.validation.constraints.NotNull;

@Stateless
public class MyBean implements MyInterface{
	 	@Override
        public String lookup(String text){
             return "found3";
        }
}