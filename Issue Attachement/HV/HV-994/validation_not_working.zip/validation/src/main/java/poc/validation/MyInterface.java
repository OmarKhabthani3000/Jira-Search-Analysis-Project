package poc.validation;

import javax.validation.constraints.NotNull;

public interface MyInterface {
	public abstract String lookup(@NotNull String text);
}
