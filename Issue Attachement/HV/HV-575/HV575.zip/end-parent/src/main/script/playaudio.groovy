import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
try {
    File fileToPlay = new File("$project.properties.fileToPlay");
    // Was a specific WAV file specified to play?
    if (fileToPlay.isDirectory()) {
       // No
    
       
       // We try to play particular audio files on special days of the year
       Calendar today = Calendar.getInstance();
       int date = today.get(Calendar.DAY_OF_MONTH);
       int month = today.get(Calendar.MONTH);
         
        String todaysFile = null;
        
        // HAL's Birthday January 12, 1992?
        if (date == 12 && month == Calendar.JANUARY) {
            println "HAL's Birthday, January 12, 1992";
            // We have three files, we should pick one at random for the day
            //String [] hal = new String[]{};
            //todaysFile = hal[(int) (hal.length * Math.random())];
            //todaysFile = "hmnerror.wav";
            //todaysFile = "dave.wav";
            //todaysFile = "halfunc.wav";
            todaysFile = "humanerr.wav";
        }
        // Ground Hog Day?
        else if (date == 2 && month == Calendar.FEBRUARY) {
            println "Ground Hog Day";
            todaysFile = "ghd-groundhog.wav";
        } 
        // World Sleep Day?
        else if (date == 16 && month == Calendar.MARCH) {
            println "World Sleep Day";
            todaysFile = "stoodinbed.wav";
        } 
        // Poultry Day?
        else if (date == 19 && month == Calendar.MARCH) {
            println "Poultry Day";
            todaysFile = "rooster.wav";
        } 
        // Doctor's Day?
        else if (date == 30 && month == Calendar.MARCH) {
            println "Doctor's Day";
            //todaysFile = "engineer.wav";
            todaysFile = "whatsupdoc.wav";
        } 
        // Launch of Apollo 13 Day? (April 11, 1970)
        else if (date == 11 && month == Calendar.APRIL) {
            println "Launch of Apollo 13";
            //todaysFile = "a13-go1.wav";
            todaysFile = "a13-launch.wav";
        } 
        // Twilight Zone Day
        else if (date == 11 && month == Calendar.MAY) {
            println "Twilight Zone Day";
            todaysFile = "twilightzone.wav";
        } 
        // National Doughnut Day
        // First Friday of June
        else if (date == 1 && month == Calendar.JUNE) {
            // June 1, 2012, June 7, 2013, June 6, 2014, June 5, 2015, June 3, 2016
            println "National Doughnut Day";
            todaysFile = "donuts.wav";
        } 
        // Flag Day?
        else if (date == 14 && month == Calendar.JUNE) {
            println "Flag Day";
            todaysFile = "grandoldflag.wav";
        } 
        // Father's Day?
        else if (date == 17 && month == Calendar.JUNE) {
            // June 17, 2012, June 16, 2013, June 15, 2014, June 21, 2015, June 19, 2016
            println "Father's Day";
            todaysFile = "father.wav";
        } 
        // Watergate Day?
        else if (date == 17 && month == Calendar.JUNE) {
            println "Watergate Day";
            todaysFile = "nixon1.wav";
        } 
        // International Panic Day
         else if (date == 18 && month == Calendar.JUNE) {
            println "International Panic Day";
            todaysFile = "daffy.wav";
        } 
        //  Canada Day
        else if (date == 1 && month == Calendar.JULY) {
            println "Canada Day";
            todaysFile = "canadiananthem.wav";
        } 
        // Independence Day
        else if (date == 4 && month == Calendar.JULY) {
            println "Independence Day";
            todaysFile = "usanthem.wav";
        } 
        // Work-a-holics Day? (look it up)
        else if (date == 5 && month == Calendar.JULY) {
            println "Work-a-holics Day";
            todaysFile = "workwork.wav";
        } 
        // Cow Appreciation Day? (look it up)
        else if (date == 15 && month == Calendar.JULY) {
            println "Cow Appreciation Day";            
            todaysFile = "moo.wav";
        } 
        // Apollo 11 Moon landing?
        else if (date == 20 && month == Calendar.JULY) {
            println "Apollo 11 Moon Landing";
            todaysFile = "tranq1.wav";
        } 
        // National Honey Bee Day?
        else if (date == 18 && month == Calendar.AUGUST) {
            println "National Honey Bee Day";
            todaysFile = "flightbumblebee.wav";
        } 
        // National Coffee Day?
        else if (date == 29 && month == Calendar.SEPTEMBER) {
            println "National Coffee Day";
            todaysFile = "morecoffee.wav";
        } 
        // Techies Day?
        else if (date == 3 && month == Calendar.OCTOBER) {
            println "Techies Day";
            // todaysFile = "physics.wav";
            // todaysFile = "verbal.wav";
            todaysFile = "withinhour.wav";
        } 
        // Mental Health Day?
        else if (date == 10 && month == Calendar.OCTOBER) {
            println "Mental Health Day";
            todaysFile = "insanity.wav";
        } 
        // National Skeptics Day?
        else if (date == 13 && month == Calendar.OCTOBER) {
            println "National Skeptics Day";
            todaysFile = "hotline.wav";
        } 
        // National Nut Day?
        else if (date == 22 && month == Calendar.OCTOBER) {
            println "National Nut Day";
            todaysFile = "likeanut.wav";
        } 
        // Winter Solstice?
        else if (date == 21 && month == Calendar.DECEMBER) {
            println "Winter Solstice";
            todaysFile = "winterwonderland.wav";
        } 
        
        // Get the list of files in the directory
        File[] audioFiles = fileToPlay.listFiles();
        fileToPlay = null;
        if (todaysFile != null ) {
          for( int i = 0; i < audioFiles.length; i++) {
               File file = audioFiles[i];
               if (file.getName().equals(todaysFile) ) {
                  fileToPlay = file;
                  break;
               }
            } // for i
            // Did we find the file we were looking for?
            if (fileToPlay == null ) {
               // No
               // Pick one of the audio files in the directory at random
               println "Couldn't find today's featured clip: \"" + todaysFile + "\"";
               final int i = (int) (audioFiles.length * Math.random());
               fileToPlay = audioFiles[i];
            }
        }
        else {
           // Pick one of the audio files in the directory at random
           final int i = (int) (audioFiles.length * Math.random());
           fileToPlay = audioFiles[i];
       } // else random
    } // if no specific file specified
    
    println "Playing \"" + fileToPlay.getName() + "\"";

    AudioInputStream sound = AudioSystem.getAudioInputStream(fileToPlay);
    DataLine.Info info = new DataLine.Info(Clip.class,sound.getFormat());
    Clip clip = (Clip) AudioSystem.getLine(info);
    clip.open(sound);
    clip.start();
    sleep(7000);
    
} catch(Exception e ) {
  println "Caught an exception trying to play audio, you can ignore this, but here's the message anyway: " + e.getMessage();
}