// package-info.java
/*******************************************************************************
 * Copyright (c) 2011 Daniel Ford.
 * All rights reserved.
 *******************************************************************************/
/**
 *
 * The classes in this package define testing utility classes.
 *
 */
package com.forddaniel.end.testing;

