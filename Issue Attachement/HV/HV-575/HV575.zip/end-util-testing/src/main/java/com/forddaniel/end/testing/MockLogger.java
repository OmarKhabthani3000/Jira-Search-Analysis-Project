// MockLogger.java
/*******************************************************************************
 * Copyright (c) 2012 Daniel Ford.
 * All rights reserved.
 *******************************************************************************/
package com.forddaniel.end.testing;

import org.apache.log4j.Logger;
import org.apache.log4j.Priority;

/**
 * This class represents a Logger that serves to absorb all logging. It is used
 * for testing to increase code coverage reports by both causing all logging to
 * occur, but also to absorb all logging messages so there is no output.
 */
@SuppressWarnings("unused")
public final class MockLogger extends Logger {

    private static MockLogger INSTANCE = null;

    @SuppressWarnings({ "javadoc", "nls" })
    public static Logger getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new MockLogger("Mocklogger");
        }
        return INSTANCE;
    }

    private MockLogger(final String name) {
        super(name);
    }


    @Override
    public void trace(final Object message) {
        // Nothing
    }

    @Override
    public void trace(final Object message, final Throwable t) {
        // Nothing
    }

    @Override
    public boolean isTraceEnabled() {
        return true;
    }

    @Override
    public void debug(final Object message) {
        // Nothing
    }

    @Override
    public void debug(final Object message, final Throwable t) {
        // Nothing
    }

    @Override
    public void error(final Object message) {
        // Nothing
    }

    @Override
    public void error(final Object message, final Throwable t) {
        // Nothing
    }

    @Override
    public void fatal(final Object message) {
        // Nothing
    }

    @Override
    public void fatal(final Object message, final Throwable t) {
        // Nothing
    }

    @Override
    public void info(final Object message) {
        // Nothing
    }

    @Override
    public void info(final Object message, final Throwable t) {
        // Nothing
    }

    @Override
    public boolean isDebugEnabled() {
        return true;
    }

    @Override
    public boolean isInfoEnabled() {
        return true;
    }

    @Override
    public void log(final Priority priority, final Object message,
            final Throwable t) {
        // Nothing
    }

    @Override
    public void log(final Priority priority, final Object message) {
        // Nothing
    }

    @Override
    public void log(final String callerFQCN, final Priority level,
            final Object message, final Throwable t) {
        // Nothing
    }

    @Override
    public void warn(final Object message) {
        // Nothing
    }

    @Override
    public void warn(final Object message, final Throwable t) {
        // Nothing
    }

} // MockLogger
