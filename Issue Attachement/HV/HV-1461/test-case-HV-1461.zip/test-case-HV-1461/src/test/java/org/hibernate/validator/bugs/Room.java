package org.hibernate.validator.bugs;

public class Room extends Entity {

}
