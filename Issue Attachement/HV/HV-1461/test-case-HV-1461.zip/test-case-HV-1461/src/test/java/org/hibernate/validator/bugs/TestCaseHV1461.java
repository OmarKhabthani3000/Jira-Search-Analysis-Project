package org.hibernate.validator.bugs;

import org.hibernate.validator.internal.util.ExecutableHelper;
import org.hibernate.validator.internal.util.TypeResolutionHelper;
import org.hibernate.validator.testutil.TestForIssue;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;


public class TestCaseHV1461 {

	private static ExecutableHelper executableHelper;

	@BeforeClass
	public static void setUp() {
		executableHelper = new ExecutableHelper(new TypeResolutionHelper());
	}

	@Test
	public void testGenericParam() throws NoSuchMethodException {
		Assert.assertTrue(executableHelper.overrides(
			IRoomUpdateService.class.getMethod("update", Room.class),
			IUpdateService.class.getMethod("update", Entity.class)));
	}

	@Test
	public void testNonGenericParam() throws NoSuchMethodException {
		Assert.assertTrue(executableHelper.overrides(
			IRoomUpdateService.class.getMethod("update", Long.class),
			IUpdateService.class.getMethod("update", Long.class)));
	}

	@Test
	@TestForIssue(jiraKey = "HV-1461")
	public void testNonGenericAndGenericParams() throws NoSuchMethodException {
		Assert.assertTrue(executableHelper.overrides(
			IRoomUpdateService.class.getMethod("update", Long.class, Room.class),
			IUpdateService.class.getMethod("update", Long.class, Entity.class)));
	}
}
