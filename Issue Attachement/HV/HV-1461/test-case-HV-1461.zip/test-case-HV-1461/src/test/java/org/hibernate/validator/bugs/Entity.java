package org.hibernate.validator.bugs;

public class Entity {

}
