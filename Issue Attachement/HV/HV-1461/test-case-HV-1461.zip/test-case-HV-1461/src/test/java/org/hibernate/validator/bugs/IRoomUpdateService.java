package org.hibernate.validator.bugs;

public interface IRoomUpdateService extends IUpdateService<Room> {

	void update(Room entiry);

	void update(Long id);

	void update(Long id, Room entity);
}
