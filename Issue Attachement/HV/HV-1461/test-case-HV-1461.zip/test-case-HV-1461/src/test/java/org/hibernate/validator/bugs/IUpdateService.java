package org.hibernate.validator.bugs;

public interface IUpdateService<T extends Entity> {

	void update(T entiry);

	void update(Long id);

	void update(Long id, T entity);
}
