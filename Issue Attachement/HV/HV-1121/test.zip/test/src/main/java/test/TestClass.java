package test;

import static java.lang.annotation.ElementType.TYPE_USE;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import javax.validation.Valid;
import javax.validation.constraints.Min;

public class TestClass {

	@Retention(RetentionPolicy.RUNTIME)
	@Target({TYPE_USE})
	@Constraint(validatedBy = {LimitedSizeStringValidator.class})
	public @interface LimitedSize {

		String message() default "{javax.validation.constraints.Size.message}";

		Class<?>[] groups() default {};

		Class<? extends Payload>[] payload() default {};

		int min() default 0;

		int max() default Integer.MAX_VALUE;
	}

	@Valid
	public Collection<@LimitedSize(max = 3) String> strings = new ArrayList<>();

	@Valid
	public Collection<InnerBean> beans = new ArrayList<>();

	public static class InnerBean {
		@Min(3)
		public final int value;

		public InnerBean(int value) {
			this.value = value;
		}
	}

	public static class LimitedSizeStringValidator implements ConstraintValidator<LimitedSize, String> {

		private LimitedSize constraint;

		@Override
		public void initialize(LimitedSize constraintAnnotation) {
			this.constraint = constraintAnnotation;
		}

		@Override
		public boolean isValid(String value, ConstraintValidatorContext context) {
			String s = null == value ? "" : value;
			return s.length() >= constraint.min() &&
				s.length() <= constraint.max();
		}
	}
}
