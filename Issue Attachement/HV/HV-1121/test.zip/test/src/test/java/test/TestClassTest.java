package test;

import static org.hamcrest.CoreMatchers.is;

import java.util.Set;
import java.util.stream.StreamSupport;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import org.junit.Assert;
import org.junit.Test;

import test.TestClass;

public class TestClassTest {

	private final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

	@Test
	public void testBeanInvalid() {

		TestClass testBean = new TestClass();

		Assert.assertThat(validator.validate(testBean).size(), is(0));

		testBean.strings.add("ok");
		testBean.strings.add("ok2");
		testBean.beans.add(new TestClass.InnerBean(4));
		Assert.assertThat(validator.validate(testBean).size(), is(0));

		testBean.strings.add("not_ok");
		testBean.beans.add(new TestClass.InnerBean(2));

		Set<ConstraintViolation<TestClass>> violations = validator.validate(testBean);
		Assert.assertThat(validator.validate(testBean).size(), is(2));

		StreamSupport.stream(violations.spliterator(), false)
			.forEach(v -> {
				System.out.println(v.getPropertyPath());
				System.out.println(v.getMessage());
				v.getPropertyPath().forEach(p -> System.out.print("'" + p.getName() + (p.getIndex() != null ? "[" + p.getIndex() + "]" : "") + "' -> "));
				System.out.println();
			});
	}
}