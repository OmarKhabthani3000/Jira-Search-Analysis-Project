package org.example;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public interface GreetingService {
    String greet(@NotEmpty @Size(max = 10) String who);
}

