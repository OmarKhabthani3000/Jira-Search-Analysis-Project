package org.example;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/")
public class GreetResource {
    @Inject
    private GreetingService service;

    @GET
    @Path("greet/{who}")
    public String getGreeting(@PathParam("who") String param) {
        return this.service.greet(param);
    }

}
