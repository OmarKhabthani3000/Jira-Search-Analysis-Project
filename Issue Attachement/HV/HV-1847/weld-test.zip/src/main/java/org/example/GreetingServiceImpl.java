package org.example;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@ApplicationScoped
public class GreetingServiceImpl implements GreetingService {
    @Override
    public String greet(String who) {
        return String.format("Hello %s!", who);
    }

    /*public void foo(@NotNull String bar){

    }*/
}

