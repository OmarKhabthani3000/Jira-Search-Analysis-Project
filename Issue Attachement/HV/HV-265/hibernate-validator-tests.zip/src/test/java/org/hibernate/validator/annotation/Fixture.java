package org.hibernate.validator.annotation;

import org.hibernate.validator.IFixture;

public class Fixture extends Game implements IFixture {

	public Fixture() {
		super();
	}

	public Fixture(Competition competition) {
		super(competition);
	}

}
