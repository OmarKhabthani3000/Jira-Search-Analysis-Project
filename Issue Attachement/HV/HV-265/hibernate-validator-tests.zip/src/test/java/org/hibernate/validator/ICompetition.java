package org.hibernate.validator;

public interface ICompetition {}
