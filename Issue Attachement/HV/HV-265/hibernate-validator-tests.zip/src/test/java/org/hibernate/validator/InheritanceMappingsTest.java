package org.hibernate.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.Set;

import javax.validation.Configuration;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.ICompetition;
import org.hibernate.validator.IFixture;
import org.junit.Test;

public class InheritanceMappingsTest {

	@Test
	public void defaultConfigurationNoExplicitAnnotationDefinition1() {
		validateAnnotatedFixture(
				new org.hibernate.validator.annotation.PersonCompetition(),
				configure());
	}

	@Test
	public void defaultConfigurationNoExplicitAnnotationDefinition2() {
		validateAnnotatedFixture(
				new org.hibernate.validator.annotation.TeamCompetition(),
				configure());
	}

	@Test
	public void customConfigurationNoExplicitAnnotationDefinition1() {
		validateAnnotatedFixture(
				new org.hibernate.validator.annotation.PersonCompetition(),
				configure("/annotation-mappings.xml"));
 	}

	@Test
	public void customConfigurationNoExplicitAnnotationDefinition2() {
		validateAnnotatedFixture(
				new org.hibernate.validator.annotation.TeamCompetition(),
				configure("/annotation-mappings.xml"));
 	}

	@Test
	public void customConfigurationExplicitXmlDefinition() {
		validateXmlDefinedFixture(
				new org.hibernate.validator.xml.PersonCompetition(),
				configure("/xml-mappings.xml"));
	}

	@Test
	public void customConfigurationNoExplicitXmlDefinition() {
		validateXmlDefinedFixture(
				new org.hibernate.validator.xml.TeamCompetition(),
				configure("/xml-mappings.xml"));
 	}

	private Validator configure() {
		return Validation.buildDefaultValidatorFactory().getValidator();
	}

	private Validator configure(String mappingsUrl) {
		Configuration<?> configuration = Validation.byDefaultProvider().configure();
 	 	configuration.addMapping(InheritanceMappingsTest.class.getResourceAsStream(mappingsUrl));

 	 	ValidatorFactory validatorFactory = configuration.buildValidatorFactory();
 	 	return validatorFactory.getValidator();
	}

	private void validateFixture(IFixture fixture, Validator validator) {
		Set<ConstraintViolation<IFixture>> violations = validator.validate(fixture);

		for (ConstraintViolation<IFixture> violation : violations) {
			if (violation.getLeafBean() instanceof ICompetition
					&& "detail.competition.name".equals(violation.getPropertyPath().toString())) {
				assertEquals(fixture.getCompetition(), violation.getLeafBean());
				assertEquals(NotNull.class, violation.getConstraintDescriptor().getAnnotation().annotationType());
				return;
			}
		}
		fail("@NotNull constraint violation for 'detail.competition.name' not detected");
	}

	private void validateAnnotatedFixture(org.hibernate.validator.annotation.Competition competition,
			Validator validator) {
		org.hibernate.validator.annotation.Fixture fixture = new org.hibernate.validator.annotation.Fixture();
		fixture.setCompetition(competition);

		validateFixture(fixture, validator);
	}

	private void validateXmlDefinedFixture(org.hibernate.validator.xml.Competition competition,
			Validator validator) {
		org.hibernate.validator.xml.Fixture fixture = new org.hibernate.validator.xml.Fixture();
		fixture.setCompetition(competition);

		validateFixture(fixture, validator);
	}

}
