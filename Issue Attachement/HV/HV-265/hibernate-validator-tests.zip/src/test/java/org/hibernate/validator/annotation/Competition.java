package org.hibernate.validator.annotation;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.ICompetition;


public abstract class Competition implements ICompetition {

	@NotNull @Size(min = 1)
	private String name;

	public Competition() {
		super();
	}

	public Competition(String name) {
		setName(name);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
