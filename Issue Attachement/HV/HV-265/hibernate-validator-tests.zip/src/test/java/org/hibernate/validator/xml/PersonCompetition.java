package org.hibernate.validator.xml;

public class PersonCompetition extends Competition {

	public PersonCompetition() {
		super();
	}

	public PersonCompetition(String name) {
		super(name);
	}

}
