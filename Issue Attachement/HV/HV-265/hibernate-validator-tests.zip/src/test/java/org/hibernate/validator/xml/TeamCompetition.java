package org.hibernate.validator.xml;

public class TeamCompetition extends Competition {

	public TeamCompetition() {
		super();
	}

	public TeamCompetition(String name) {
		super(name);
	}

}
