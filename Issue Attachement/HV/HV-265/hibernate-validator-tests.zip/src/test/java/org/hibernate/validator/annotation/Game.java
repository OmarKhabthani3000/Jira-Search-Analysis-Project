package org.hibernate.validator.annotation;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public abstract class Game {

	@NotNull @Valid
	private GameDetail detail;

	private Game(GameDetail detail) {
		this.detail = detail;
	}

	public Game() {
		this(new GameDetail());
	}

	public Game(Competition competition) {
		this(new GameDetail(competition));
	}

	public Competition getCompetition() {
		return detail.getCompetition();
	}

	public void setCompetition(Competition competition) {
		detail.setCompetition(competition);
	}

}
