package org.hibernate.validator.annotation;

public class PersonCompetition extends Competition {

	public PersonCompetition() {
		super();
	}

	public PersonCompetition(String name) {
		super(name);
	}

}
