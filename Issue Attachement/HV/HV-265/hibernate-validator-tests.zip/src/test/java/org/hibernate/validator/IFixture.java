package org.hibernate.validator;

public interface IFixture {

	ICompetition getCompetition();

}
