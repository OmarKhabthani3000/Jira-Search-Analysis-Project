package org.hibernate.validator.annotation;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class GameDetail {

	@NotNull @Valid
	private Competition competition;

	public GameDetail() {
		super();
	}

	public GameDetail(Competition competition) {
		setCompetition(competition);
	}

	public Competition getCompetition() {
		return competition;
	}

	public void setCompetition(Competition competition) {
		this.competition = competition;
	}


}
