package org.hibernate.validator.xml;

import org.hibernate.validator.ICompetition;

public abstract class Competition implements ICompetition {

	private String name;

	public Competition() {
		super();
	}

	public Competition(String name) {
		setName(name);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
