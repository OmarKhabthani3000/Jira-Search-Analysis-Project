package org.hibernate.validator.annotation;

public class TeamCompetition extends Competition {

	public TeamCompetition() {
		super();
	}

	public TeamCompetition(String name) {
		super(name);
	}

}
