package org.hibernate.validator.bugs;

import static org.junit.Assert.assertEquals;

import java.util.Collections;
import java.util.Optional;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.hibernate.validator.testutil.TestForIssue;
import org.junit.BeforeClass;
import org.junit.Test;

public class StringWrapperTestCase {

    private static Validator validator;

    @BeforeClass
    public static void setUp() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    @TestForIssue(jiraKey = "HV-1603")
    public void noValidatorFound() {
        StringWrapper entity = new StringWrapper(Optional.empty());

        Set<ConstraintViolation<StringWrapper>> constraintViolations = validator.validate(entity);
        assertEquals(Collections.emptySet(), constraintViolations);
    }
}
