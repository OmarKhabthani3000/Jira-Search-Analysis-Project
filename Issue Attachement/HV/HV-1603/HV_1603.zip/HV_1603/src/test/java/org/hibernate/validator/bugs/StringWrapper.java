package org.hibernate.validator.bugs;

import java.util.Optional;

import javax.validation.constraints.NotBlank;

public final class StringWrapper {
    private final Optional<@NotBlank String> num;

    public StringWrapper(Optional<String> num) {
        this.num = num;
    }

    public Optional<String> getNum() {
        return num;
    }
}
