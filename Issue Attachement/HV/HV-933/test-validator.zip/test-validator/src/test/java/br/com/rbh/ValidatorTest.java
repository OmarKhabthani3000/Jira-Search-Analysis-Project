package br.com.rbh;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.junit.Test;

public class ValidatorTest {
	
	public void validate(Person p) {
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		
		Set<ConstraintViolation<Person>> constraintViolations = validator.validate(p);
		
		for (ConstraintViolation<Person> constraintViolation : constraintViolations) {
			throw new IllegalArgumentException(constraintViolation.getMessage());
		}
	}

	@Test
	public void verifyCPF() {
		Person p = new Person();
		p.setCpf("11647407842");
		
		validate(p);
	}
	
	@Test
	public void verifyCNPJ() {
		Person p = new Person();
		p.setCnpj("48357375000130");
		
		validate(p);
	}
}
