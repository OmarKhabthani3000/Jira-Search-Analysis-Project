package br.com.rbh;

import org.hibernate.validator.constraints.br.CNPJ;
import org.hibernate.validator.constraints.br.CPF;

public class Person {
	
	@CPF
	private String cpf;
	
	@CNPJ
	private String cnpj;

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
}
