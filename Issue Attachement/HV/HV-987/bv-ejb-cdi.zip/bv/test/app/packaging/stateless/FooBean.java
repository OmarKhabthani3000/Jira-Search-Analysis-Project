package bv.test.app.packaging.stateless;

import java.util.Set;

import javax.annotation.Resource;
import javax.ejb.Remote;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

@Stateless
public class FooBean implements Foo { 

  @Resource
  private SessionContext ctx;

  /**
   * an illegal value of testValue must be greater than or equal to 100;
   */
  public int verifyValidatorOnPojo(int testValue) {
    PojoBean pojo = new PojoBean(testValue);

    Validator v = (Validator) ctx.lookup("java:comp/Validator");
    Set<ConstraintViolation<PojoBean>> violations = v.validate(pojo);
    return violations.size();
  }
}

