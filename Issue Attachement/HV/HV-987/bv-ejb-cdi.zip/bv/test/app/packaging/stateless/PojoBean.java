package bv.test.app.packaging.stateless;

public class PojoBean {
  private int value;

  public PojoBean(int initValue) {
    this.value = initValue;
  }

}
