package bv.test.app.packaging.stateless;

import javax.ejb.Remote;
import weblogic.javaee.JNDIName;

@Remote
@JNDIName("FooBean")
public interface Foo {
  /**
   * verify if the validator is indeed using the correct validation configuration.
   * @param testValue an integer to test
   * @return an integer that indicates the total number of the violations.
   */
  int verifyValidatorOnPojo(int testValue);
}
