package bv.test.app.packaging;

import bv.test.app.packaging.stateless.*;
import bv.test.app.packaging.test.Echo;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.testng.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.EnterpriseArchive;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.testng.annotations.Test;

import javax.inject.Inject;
import javax.naming.Context;
import javax.naming.InitialContext;

import static org.testng.AssertJUnit.*;

public class AppWithMultipleEJBJarsTest extends Arquillian {

    @Deployment
    public static EnterpriseArchive createDeployment() throws Exception {

        JavaArchive ejbJar1 = ShrinkWrap.create(JavaArchive.class)
                .addClass(Foo.class).addClass(FooBean.class).addClass(PojoBean.class);

        ejbJar1.add(new ValidationXmlBuilder().constraintMapping("META-INF/constraint-mappings.xml").build(), "META-INF/validation.xml");

        ejbJar1.add(ConstraintMappingXmlFactory.build("<bean class=\"" + PojoBean.class.getName() + "\" ignore-annotations=\"false\">\n" +
                "    <field name=\"value\">\n" +
                "      <constraint annotation=\"javax.validation.constraints.Min\">\n" +
                "        <element name=\"value\">100</element>\n" +
                "      </constraint>\n" +
                "    </field>\n" +
                "  </bean>\n"), "META-INF/constraint-mappings.xml");

        JavaArchive ejbJar2 = ShrinkWrap.create(JavaArchive.class)
                .addClass(Bar.class).addClass(BarBean.class).addClass(PojoBean.class);


        ejbJar2.add(new ValidationXmlBuilder().constraintMapping("META-INF/constraint-mappings.xml").build(), "META-INF/validation.xml");

        ejbJar2.add(ConstraintMappingXmlFactory.build("<bean class=\"" + PojoBean.class.getName() + "\" ignore-annotations=\"false\">\n" +
                "    <field name=\"value\">\n" +
                "      <constraint annotation=\"javax.validation.constraints.Max\">\n" +
                "        <element name=\"value\">10</element>\n" +
                "      </constraint>\n" +
                "    </field>\n" +
                "  </bean>"), "META-INF/constraint-mappings.xml");

        JavaArchive testClassesJar = ShrinkWrap.create(JavaArchive.class)
                .addClass(AppWithMultipleEJBJarsTest.class);

        EnterpriseArchive ear = ShrinkWrap.create(EnterpriseArchive.class)
                .addAsModule(ejbJar1).addAsModule(ejbJar2)
                .addAsLibrary(testClassesJar);

        return ear;
    }

    @Test
    public void testFooBarWithJndi() throws Exception {
        int violations;

        Context ctx = new InitialContext();

        // min is 100.
        Foo foo = (Foo) ctx.lookup("FooBean");
        violations = foo.verifyValidatorOnPojo(150);
        assertTrue("Valid values are [100, Integer.MAX_VALUE). Setting 150 for Foo is correct, so violations should be 0, but actually : " + violations, violations == 0);
        violations = foo.verifyValidatorOnPojo(50);
        assertTrue("Valid values are [100, Integer.MAX_VALUE). Setting 50 for Foo is not correct, so violations should be 1, but actually : " + violations, violations == 1);

        // max is 10.
        Bar bar = (Bar) ctx.lookup("BarBean");
        violations = bar.verifyValidatorOnPojo(5);
        assertTrue("Valid values are (Integer.MIN_VALUE, 10]. Setting 5 for Bar is correct, so violations should be 0, but actually : " + violations, violations == 0);
        violations = bar.verifyValidatorOnPojo(15);
        assertTrue("Valid values are (Integer.MIN_VALUE, 10]. Setting 15 for Bar is not correct, so violations should be 1, but actually : " + violations, violations == 1);


    }

}
