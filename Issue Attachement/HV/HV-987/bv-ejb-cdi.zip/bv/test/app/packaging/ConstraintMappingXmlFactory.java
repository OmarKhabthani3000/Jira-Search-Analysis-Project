package bv.test.app.packaging;

import org.jboss.shrinkwrap.api.asset.ByteArrayAsset;


public class ConstraintMappingXmlFactory {

    public static ByteArrayAsset build(String snippet) {
        StringBuilder sb = new StringBuilder();

        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "\n" +
                "<constraint-mappings xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
                "xsi:schemaLocation=\"http://jboss.org/xml/ns/javax/validation/mapping http://jboss.org/xml/ns/javax/validation/mapping/validation-mapping-1.1.xsd\"\n" +
                "xmlns=\"http://jboss.org/xml/ns/javax/validation/mapping\"\n" +
                "                     version=\"1.1\">\n");

        sb.append(snippet);


        sb.append("\n</constraint-mappings>");

        ByteArrayAsset asset = null;
        try {
            String xml = sb.toString();
            System.out.println("configuration-mapping asset:\n" + xml);
            asset = new ByteArrayAsset(xml.getBytes("UTF-8"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return asset;
    }
}
