package hv6;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintViolationException;
import javax.validation.Payload;
import javax.validation.constraintvalidation.SupportedValidationTarget;
import javax.validation.constraintvalidation.ValidationTarget;

import org.jboss.weld.environment.se.Weld;
import org.junit.Test;

public class ValidatorTest {
	
	@Test(expected = ConstraintViolationException.class)
	public void test() {
		new Weld().addBeanClass(getClass()).initialize().select(getClass()).get().validate("first", "second");
	}
	
	@MyConstraint
	public void validate(final String arg1, final String arg2) {
		
	}

	@Target({ METHOD })
	@Retention(RUNTIME)
	@Constraint(validatedBy = MyValidator.class)
	public @interface MyConstraint {
		String message() default "{myConstraint.message}";

		Class<?>[] groups() default {};

		Class<? extends Payload>[] payload() default {};

	}

	@SupportedValidationTarget(ValidationTarget.PARAMETERS)
	public static class MyValidator implements ConstraintValidator<MyConstraint, Object[]> {
		
		public boolean isValid(Object[] value, ConstraintValidatorContext context) {
			return false;
		}

	}
}