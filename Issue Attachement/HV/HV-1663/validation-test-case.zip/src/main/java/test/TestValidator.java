package test;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class TestValidator implements ConstraintValidator<TestConstraint, ModelType> {
  @Override
  public boolean isValid(final ModelType value, final ConstraintValidatorContext context) {
    return true;
  }
}
