package test;

import javax.validation.Validation;
import javax.validation.Validator;

public class Main {
  public static void main(String[] args) {
    Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
    validator.validate(new ModelType());
  }
}
