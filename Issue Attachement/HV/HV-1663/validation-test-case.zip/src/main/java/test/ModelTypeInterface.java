package test;

@TestConstraint
public interface ModelTypeInterface {
}
