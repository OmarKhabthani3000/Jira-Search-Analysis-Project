package test;

public class ModelType implements ModelTypeInterface {
}
