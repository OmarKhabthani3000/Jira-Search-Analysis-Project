package org.test;

import org.junit.Before;
import org.junit.Test;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.lang.reflect.Method;
import java.util.Set;

import static org.junit.Assert.assertEquals;

public class TestTest {
    private Validator validator;

    @Before
    public void setUp() throws Exception {
        ValidatorFactory factory = Validation.byDefaultProvider()
                .configure()
                .parameterNameProvider(new MyrParameterNameProvider(new NameAnnotationParanamer()))
                .buildValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    public void test() throws Exception {
        Service service = new ServiceImpl();
        Method sayHello = Service.class.getMethod("sayHello", String.class);
        Set<ConstraintViolation<Service>> violations = validator.forExecutables().validateParameters(service, sayHello, new Object[]{null});
        assertEquals(violations.size(), 1);
        assertEquals(violations.iterator().next().getPropertyPath().toString(), "sayHello.xxx0");
    }
}
