package org.test;

import javax.validation.constraints.NotNull;

interface Service {
    void sayHello(@NotNull @Name("foo") String world);
}
