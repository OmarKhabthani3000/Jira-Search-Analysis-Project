package org.test;

import com.thoughtworks.paranamer.Paranamer;

import javax.validation.ParameterNameProvider;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class MyrParameterNameProvider implements ParameterNameProvider {
    private final Paranamer paranamer;

    public MyrParameterNameProvider(Paranamer paranamer) {
        this.paranamer = paranamer;
    }

    @Override
    public List<String> getParameterNames(Constructor<?> constructor) {
        return getParameterNames(constructor.getParameterTypes().length);
    }

    @Override
    public List<String> getParameterNames(Method method) {
        String[] names = paranamer.lookupParameterNames(method, false);
        if (names != null && names.length == method.getParameterTypes().length)
            return Arrays.asList(names);
        return getParameterNames(method.getParameterTypes().length);
    }

    private List<String> getParameterNames(int parameterCount) {
        List<String> parameterNames = new ArrayList<>();
        for (int i = 0; i < parameterCount; i++)
            parameterNames.add("xxx" + i);
        return parameterNames;
    }
}
