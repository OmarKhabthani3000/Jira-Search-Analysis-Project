package org.test;

import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;

class ServiceImpl implements Service {
    @Override
    @ValidateOnExecution(type = ExecutableType.NONE)
    public void sayHello(String world) {}
}
