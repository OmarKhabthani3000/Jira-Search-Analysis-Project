package org.test;

import com.thoughtworks.paranamer.AnnotationParanamer;

import java.lang.annotation.Annotation;

class NameAnnotationParanamer extends AnnotationParanamer {
    @Override
    protected boolean isNamed(Annotation ann) {
        return ann instanceof Name;
    }

    @Override
    protected String getNamedValue(Annotation ann) {
        if (ann instanceof Name)
            return ((Name) ann).value();
        return null;
    }
}
