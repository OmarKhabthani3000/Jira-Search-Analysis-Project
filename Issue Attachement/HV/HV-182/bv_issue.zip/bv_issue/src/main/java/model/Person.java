/**
 * Copyright 2009 by Gerhard Petracek, IRIAN Solutions GmbH
 */
package model;

import constraint.NickName;
import javax.validation.constraints.NotNull;

public class Person
{
    @NickName
    private String nickName;
    @NotNull
    private String name;

    public Person(String nickName, String name)
    {
        this.nickName = nickName;
        this.name = name;
    }

    public String getNickName()
    {
        return nickName;
    }

    public void setNickName(String nickName)
    {
        this.nickName = nickName;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }
}
