/**
 * Copyright 2009 by Gerhard Petracek, IRIAN Solutions GmbH
 */
package constraint;

import javax.validation.Constraint;
import javax.validation.ConstraintPayload;
import javax.validation.ReportAsSingleViolation;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@NotNull
@Size(min = 2, max = 10)
@ReportAsSingleViolation

@Target({METHOD, FIELD})
@Retention(RUNTIME)
@Constraint(validatedBy = {})
public @interface NickName
{
    String message() default "invalid nick-name - min: {min} max: {max}";

    Class<?>[] groups() default {};

    Class<? extends ConstraintPayload>[] payload() default {};
}