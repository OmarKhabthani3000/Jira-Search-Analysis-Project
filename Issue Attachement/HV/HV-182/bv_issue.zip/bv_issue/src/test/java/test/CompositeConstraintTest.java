/**
 * Copyright 2009 by Gerhard Petracek, IRIAN Solutions GmbH
 */
package test;

import model.Person;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.Validation;
import javax.validation.constraints.Size;
import java.util.Set;

public class CompositeConstraintTest
{
    @Test
    public void invalidNickName()
    {
        Validator currentValidator = Validation.buildDefaultValidatorFactory().getValidator();

        Set<ConstraintViolation<Person>> constraintViolations = currentValidator.validate(new Person("g", "Gerhard"));

        assertEquals(constraintViolations.size(), 1);
        assertEquals(constraintViolations.iterator().next().getConstraintDescriptor().getAnnotation().annotationType(), Size.class);
    }
}
