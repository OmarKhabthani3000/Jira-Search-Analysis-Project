package sinuhepop.hv524;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class UselessValidator implements ConstraintValidator<Useless, Object> {

    public void initialize(Useless constraintAnnotation) {

    }


    public boolean isValid(Object value, ConstraintValidatorContext context) {
        return true;
    }

}
