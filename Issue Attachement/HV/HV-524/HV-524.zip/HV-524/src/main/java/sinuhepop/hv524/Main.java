package sinuhepop.hv524;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.groups.Default;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

    public static void main(String[] args) {
        
        MyEntity entity = new MyEntity();
        
        // Works ok in the simplest case
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        validator.validate(entity, Default.class);
        System.out.println("First!");
        
        // Fails depending on HV's version
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        Repo repository = context.getBean(Repo.class);
        repository.save(entity);
        System.out.println("Last!");
    }

}
