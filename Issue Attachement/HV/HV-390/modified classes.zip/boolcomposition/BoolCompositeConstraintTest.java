package org.hibernate.validator.test.constraints.boolcomposition;

import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import static org.testng.Assert.assertEquals;
import org.testng.annotations.Test;

import org.hibernate.validator.test.util.TestUtil;

import static org.hibernate.validator.test.util.TestUtil.assertCorrectConstraintTypes;
import static org.hibernate.validator.test.util.TestUtil.assertCorrectConstraintViolationMessages;
import static org.hibernate.validator.test.util.TestUtil.assertNumberOfViolations;

/**
 * @author Federico Mancini
 * @author Dag Hovland
 */

public class BoolCompositeConstraintTest {

	/**
	 * HV-390
	 */
	@Test
	public void testCorrectAnnotationTypeWithBoolAndOr() {

		Validator currentValidator = TestUtil.getValidator();
		

		
			Set<ConstraintViolation<PersonBool>> constraintViolations = currentValidator.validate(
					new PersonBool("K", "G"));

			assertNumberOfViolations( constraintViolations, 2 );
			//assertCorrectConstraintTypes( constraintViolations, OrValidName.class, AndValidName.class );
			//assertCorrectConstraintViolationMessages( constraintViolations, "invalid name" );

			constraintViolations = currentValidator.validate(
					new PersonBool(
							"G", "Gerhard"
					)
			);
			assertNumberOfViolations( constraintViolations, 1 );
			//assertCorrectConstraintTypes( constraintViolations, OrValidName.class);
	}

	/**
	 * HV-390
	 */
	@Test
	public void testCorrectAnnotationTypeWithBoolAndOr2() {

		Validator currentValidator = TestUtil.getValidator();

		
			Set<ConstraintViolation<PersonBool>> constraintViolations = currentValidator.validate(
					new PersonBool(
							"G", "K"
					)
			);

			assertNumberOfViolations( constraintViolations, 2 );
			//assertCorrectConstraintTypes( constraintViolations, OrValidName.class, AndValidName.class );
			//assertCorrectConstraintViolationMessages( constraintViolations, "invalid name" );

			constraintViolations = currentValidator.validate(
					new PersonBool(
							"L", "G"
					)
			);
			assertNumberOfViolations( constraintViolations, 3 );
			//assertCorrectConstraintTypes( constraintViolations, AndValidName.class, OrValidName.class, OrValidName.class );
			//assertCorrectConstraintViolationMessages( constraintViolations, "invalid name" );
		
	}
}

