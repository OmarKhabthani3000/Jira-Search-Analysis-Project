package org.hibernate.validator.test.constraints.boolcomposition;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import java.lang.annotation.Target;


import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.validation.constraints.Size.List;
import org.hibernate.validator.constraints.Bool;
import org.hibernate.validator.constraints.Bool.BoolType;
import static org.hibernate.validator.constraints.Bool.BoolType.ALLFALSE;
import static org.hibernate.validator.constraints.Bool.BoolType.AND;
import static org.hibernate.validator.constraints.Bool.BoolType.OR;

/**
 * Test constraint for HV-390.
 *
 * @author Gerhard Petracek
 * @author Hardy Ferentschik
 * @author Federico Mancini
 * @author Dag Hovland
 */

@Bool(OR)
@Pattern(regexp="K")
@Size(min = 2, max = 10)
@ReportAsSingleViolation
@Target({ METHOD, FIELD })
@Retention(RUNTIME)
@Constraint(validatedBy = { })
public @interface OrValidName {
	public abstract String message() default "OR";

	public abstract Class<?>[] groups() default { };

	public abstract Class<? extends Payload>[] payload() default { };
}
