package org.hibernate.validator.constraints;

import java.lang.annotation.Documented;
import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import java.lang.annotation.Target;
import java.lang.annotation.Annotation;


/**
 * Boolean operator that is applied to all constraints defined in the annotation.
 * <p/>
 * A composed constraint annotation can define a boolean combination of the constraints composing it,
 * by using <code>@Bool<\code>.
 *
 * @author Dag Hovland
 * @author Federico Mancini
 */
@Documented
@Target({ ANNOTATION_TYPE })
@Retention(RUNTIME)
public @interface Bool {
	/**
	 * The value of this element specifies the boolean operator,
	 * namely disjunction (OR), negation of the conjunction (ALLFALSE),
	 * or, the default, simple conjunction (AND).
	 *
	 */
	BoolType value() default BoolType.AND;

	/**
	 * The Enum <code>BoolType<\code> which is used as argument to the annotation <code>@BoolTest<\code>.
	 */
	public enum BoolType {
		/** Used to indicate the disjunction of all annotations it is applied to. */
		OR,
		/** Used to indicate the conjunction of all the annotation it is applied to. */
		AND,
		/** ALLFALSE is a generalisation of the usual NOT operator, which is applied to 
		 *  a list of conditions rather than just one element.
		 *  When the annotation it is used on is composed of a single constraint annotation, then it is equivalent to NOT.*/
		ALLFALSE
		}
}
