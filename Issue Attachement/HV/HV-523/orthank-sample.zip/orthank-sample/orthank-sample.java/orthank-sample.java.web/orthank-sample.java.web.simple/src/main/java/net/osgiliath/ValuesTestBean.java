/**
 * 
 */
package net.osgiliath;

import javax.annotation.Resource;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import net.osgiliath.dao.ValuesTestDao;
import net.osgiliath.entities.ValuesTest;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import javax.inject.Inject;
import javax.inject.Named;
/**
 * @author CMORDANT
 *
 */
@Component
@Scope("request")
public class ValuesTestBean {
	@Inject
	ValuesTestDao dao;
	ValuesTest val = new ValuesTest();
	public String toto;
	public String getToto() {
		return toto;
	}
	public void setToto(String toto) {
		this.toto = toto;
	}
	public ValuesTest getVal() {
		
		return val;
	}
	public void setVal(ValuesTest val) {
		
		this.val = val;
	}
	public String go() {
		dao.save(val);
		//normalement, la transaction est finie, vue que la methode go n'est pas annot�e @Transactionnal
		val = dao.getAll().get(0);
		return "go";
	}

}
