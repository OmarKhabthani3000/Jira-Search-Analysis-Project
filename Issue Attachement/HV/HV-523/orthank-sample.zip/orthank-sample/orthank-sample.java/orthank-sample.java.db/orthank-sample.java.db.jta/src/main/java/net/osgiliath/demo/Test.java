package net.osgiliath.demo;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.transaction.PlatformTransactionManager;

public class Test {
	
	Log maLog = LogFactory.getLog(Test.class);
	PlatformTransactionManager tm;

	DataSource dataSource;
	public void setTm(PlatformTransactionManager tm) {
	
		
		this.tm = tm;
		
		
	}
	 
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	public void start(){
		
		maLog.fatal("----------------+---+--- "+tm.toString());
		maLog.fatal("----------------+---+--- "+dataSource);
	}
}
