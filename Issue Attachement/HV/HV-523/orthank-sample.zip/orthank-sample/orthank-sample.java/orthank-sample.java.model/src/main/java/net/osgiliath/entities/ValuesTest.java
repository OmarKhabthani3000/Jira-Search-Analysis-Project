/**
 * @generated
 */

// Start of user code for ValuesTest imports
// End of user code
package net.osgiliath.entities;
import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.persistence.Transient;
import java.util.Date;
import javax.validation.constraints.Size;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.TemporalType;
import javax.persistence.Temporal;
import net.osgiliath.entities.BaseEntity;

@Entity
@NamedQueries(
		value={@NamedQuery(name="getAllValuesTest", query="from ValuesTest")}
		)
public class ValuesTest extends BaseEntity  {
/**
	 * 
	 */
	private static final long serialVersionUID = -2201005980406542741L;
/**.
 * the dateVal
// Start of user code for dateVal imports
// End of user code
 */
private Date dateVal;
/**.
 * the stringVal
// Start of user code for stringVal imports
// End of user code
 */
private String stringVal;
/**
Start of user code for propertystringVal min length comment
End of user code
 * Minimum stringVal length
 */	
@Transient
private static final int STRINGVAL_MIN 
 //Start of user code for property stringVal min length number
 = 0
 //End of user code
 ;
 /**
//Start of user code for property stringVal max lengthEnd of user code
 * Maximum stringVal length
 */	
@Transient
private static final int STRINGVAL_MAX 
 //Start of user code for property stringVal max length number
 = 20//1
 //End of user code
 ;
/**.
 * the booleanVal
// Start of user code for booleanVal imports
// End of user code
 */
private boolean booleanVal;
/**.
 * the dateVal setter
// Start of user code for dateVal imports
// End of user code
 * @param aDateVal the dateVal to set
 */
public void setDateVal(Date aDateVal) {
this.dateVal = aDateVal;
}
//Start of user code protected for dateVal annotations
//End of user code
/**.
 * the dateVal getter
// Start of user code for dateVal imports
// End of user code
 * @return the dateVal to get
 */
@Temporal(TemporalType.TIMESTAMP)
public Date getDateVal() {
return this.dateVal;
}
/**.
 * the stringVal setter
// Start of user code for stringVal imports
// End of user code
 * @param aStringVal the stringVal to set
 */
public void setStringVal(String aStringVal) {
this.stringVal = aStringVal;
}
//Start of user code protected for stringVal annotations
@NotNull(message = "stringVal must not be null")
@Size(
min = STRINGVAL_MIN,
max = STRINGVAL_MAX,
message = "length of stringVal must be between" + STRINGVAL_MIN + " and " + STRINGVAL_MAX
)
@Pattern(
regexp = "[A-Za-z0-9]+",
message = "stringVal must contain characters")
//End of user code
/**.
 * the stringVal getter
// Start of user code for stringVal imports
// End of user code
 * @return the stringVal to get
 */
public String getStringVal() {
return this.stringVal;
}
/**.
 * the booleanVal setter
// Start of user code for booleanVal imports
// End of user code
 * @param aBooleanVal the booleanVal to set
 */
public void setBooleanVal(boolean aBooleanVal) {
this.booleanVal = aBooleanVal;
}
//Start of user code protected for booleanVal annotations
//End of user code
/**.
 * the booleanVal getter
// Start of user code for booleanVal imports
// End of user code
 * @return the booleanVal to get
 */
public boolean isBooleanVal() {
return this.booleanVal;
}
}
