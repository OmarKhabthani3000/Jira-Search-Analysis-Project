package net.osgiliath.dao;
import java.util.List;

//import javax.validation.Valid;
import org.springframework.transaction.annotation.Transactional;
import net.osgiliath.entities.ValuesTest;
/**
 * Example Spring Bean
 */

public interface ValuesTestDao
{
	@Transactional
    ValuesTest save(/*@Valid*/ ValuesTest valuesTest);
	@Transactional
    void remove(Long id);
	@Transactional(readOnly=true)
    List<ValuesTest> getAll();
	@Transactional(readOnly=true)
    ValuesTest findOne(Long one);
    
}
