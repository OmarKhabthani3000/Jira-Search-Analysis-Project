package net.osgiliath.dao.internal;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import net.osgiliath.dao.ValuesTestDao;
import net.osgiliath.entities.ValuesTest;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * Internal implementation of our example Spring Bean
 */
@Repository("valuesTestDao")
@Transactional
public class ValuesTestDaoImpl implements ValuesTestDao {
	
	EntityManager entityManager;
	
	@Required
    @PersistenceContext
    public void setEntityManager(final EntityManager entityManager) {
            this.entityManager = entityManager;
    }
	@Transactional(readOnly=false)
	public ValuesTest save(/*@Valid*/ ValuesTest valuesTest) {
		
		if (valuesTest.getId() == null) {
			entityManager.persist(valuesTest);
			return valuesTest;
		} else {
			return entityManager.merge(valuesTest);
		}
	}
	@Transactional(readOnly=false)
	public void remove(Long id) {
		entityManager.remove(findOne(id));

	}

	public List<ValuesTest> getAll() {
		return entityManager.createNamedQuery("getAllValuesTest").getResultList();
	}

	public ValuesTest findOne(Long one) {	
		return entityManager.find(ValuesTest.class, one);
	}

}
