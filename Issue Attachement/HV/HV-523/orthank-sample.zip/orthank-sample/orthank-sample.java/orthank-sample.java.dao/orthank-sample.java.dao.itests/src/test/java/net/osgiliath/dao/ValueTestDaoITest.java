/**
 * 
 */
package net.osgiliath.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.ops4j.pax.exam.CoreOptions.cleanCaches;
import static org.ops4j.pax.exam.CoreOptions.compendiumProfile;
import static org.ops4j.pax.exam.CoreOptions.debugClassLoading;
import static org.ops4j.pax.exam.CoreOptions.mavenBundle;
import static org.ops4j.pax.exam.CoreOptions.options;
import static org.ops4j.pax.exam.CoreOptions.provision;
import static org.ops4j.pax.exam.CoreOptions.workingDirectory;

import java.io.File;
import java.util.Date;

import javax.naming.Context;
import javax.sql.DataSource;
import javax.transaction.TransactionManager;

import net.osgiliath.entities.ValuesTest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.ops4j.pax.exam.Customizer;
import org.ops4j.pax.exam.Option;
import org.ops4j.pax.exam.junit.Configuration;
import org.ops4j.pax.exam.junit.JUnit4TestRunner;
import org.osgi.framework.BundleContext;
import org.osgi.util.tracker.ServiceTracker;

//import static org.ops4j.pax.exam.container.def.PaxRunnerOptions.vmOption;

/**
 * @author CMORDANT
 * 
 */
@RunWith(JUnit4TestRunner.class)
public class ValueTestDaoITest {

	// @Before
	// public void setup() throws Exception {
	// valuesTestDao = retrieveValuesTestDao();
	// }

	@Configuration
	public static Option[] configuration() {
		String vmOpt = "";

		// This runs in the VM that runs the build, but the tests run in another
		// one.
		// Make all system properties available to OSGi framework VM
		for (Object o : System.getProperties().keySet()) {
			final String key = (String) o;
			if (key.startsWith("launchpad.")) {
				vmOpt += " -D" + key + "=" + System.getProperty(key);
			}
		}
		// optional debugging
		final String paxDebugPort = System.getProperty("pax.exam.debug.port");
		if (paxDebugPort != null && paxDebugPort.length() > 0) {
			vmOpt += " -Xrunjdwp:transport=dt_socket,server=y,suspend=y,address="
					+ paxDebugPort;
		}
		return options(
				// frameworkStartLevel(5),
				debugClassLoading(),
				// equinox(),
				// equinox().version( "3.5.1" ),
				// felix(),
				cleanCaches(),
				compendiumProfile(),
				// equinox().version("3.5.1"),
				// systemProperty("osgi.console").value("6666"),
				// rawPaxRunnerOption("--definitionURL",
				// "file:platform-equinox-3.7.xml"),
				// vmOption(vmOpt),

				provision(mavenBundle().groupId("org.osgi")
						.artifactId("org.osgi.core").version("4.2.0")),
				// Logging
				provision(mavenBundle().groupId("org.slf4j")
						.artifactId("slf4j-api").version("1.6.1")),
				provision(mavenBundle().groupId("org.slf4j")
						.artifactId("slf4j-log4j12").version("1.6.1").noStart()),
				provision(mavenBundle().groupId("org.apache.log4j")
						.artifactId("com.springsource.org.apache.log4j")
						.version("1.2.15")),
				provision(mavenBundle()
						.groupId("org.apache.commons")
						.artifactId(
								"com.springsource.org.apache.commons.logging")
						.version("1.1.1")),
				provision(mavenBundle()
						.groupId("net.osgiliath.orthank-sample.java.logging")
						.artifactId("orthank-sample.java.logging.config")
						.version("1.0-SNAPSHOT").noStart()),
				provision(mavenBundle().groupId("org.apache.xbean")
						.artifactId("com.springsource.org.apache.xbean.spring")
						.version("3.6.0")),

				// ***************** Common dependencies ********************
				provision(mavenBundle().groupId("org.aopalliance")
						.artifactId("com.springsource.org.aopalliance")
						.version("1.0.0")),
				provision(mavenBundle().groupId("org.springframework")
						.artifactId("org.springframework.aop")
						.version("3.0.6.RELEASE")),
				provision(mavenBundle().groupId("org.springframework")
						.artifactId("org.springframework.beans")
						.version("3.0.6.RELEASE")),
				provision(mavenBundle().groupId("org.springframework")
						.artifactId("org.springframework.context")
						.version("3.0.6.RELEASE")),

				provision(mavenBundle().groupId("org.springframework")
						.artifactId("org.springframework.core")
						.version("3.0.6.RELEASE")),

				// provision(mavenBundle().groupId("javax.el")
				// .artifactId("com.springsource.javax.el")
				// .version("1.0.0")),
				// provision(mavenBundle().groupId("javax.inject")
				// .artifactId("com.springsource.javax.inject")
				// .version("1.0.0")),
				provision(mavenBundle().groupId("org.springframework")
						.artifactId("org.springframework.orm")
						.version("3.0.6.RELEASE")),
				provision(mavenBundle().groupId("org.springframework")
						.artifactId("org.springframework.jdbc")
						.version("3.0.6.RELEASE")),
				//
				//
				provision(mavenBundle().groupId("org.springframework")
						.artifactId("org.springframework.asm")
						.version("3.0.6.RELEASE")),
				provision(mavenBundle().groupId("org.springframework")
						.artifactId("org.springframework.expression")
						.version("3.0.6.RELEASE")),
				// provision(mavenBundle().groupId("javax.inject")
				// .artifactId("com.springsource.org.atinject.tck")
				// .version("1.0.0")),
				provision(mavenBundle().groupId("org.junit")
						.artifactId("com.springsource.org.junit")
						.version("4.8.2")),

				// ***************** First module dep: Atomikos *************
				// spring dm libraries
				//

				provision(mavenBundle().groupId("org.springframework.osgi")
						.artifactId("org.springframework.osgi.core")
						.version("1.2.1")),

				provision(mavenBundle().groupId("org.springframework.osgi")
						.artifactId("org.springframework.osgi.io")
						.version("1.2.1")),

				provision(mavenBundle().groupId("org.springframework.osgi")
						.artifactId("org.springframework.osgi.extender")
						.version("1.2.1")),
				// persistence api
				provision(mavenBundle().groupId("javax.persistence")
						.artifactId("com.springsource.javax.persistence")
						.version("1.0.0")),
				// // hibernate & deps
				mavenBundle()
						.groupId("net.osgiliath.orthank-sample.third-parties")
						.artifactId(
								"orthank-sample.third-parties.atomikos-hibernate3-adapter")
						.version("1.0-SNAPSHOT").noStart(),

				provision(mavenBundle().groupId("org.hibernate")
						.artifactId("com.springsource.org.hibernate")
						.version("3.3.2.GA")),

				provision(mavenBundle()
						.groupId("org.hibernate")
						.artifactId(
								"com.springsource.org.hibernate.annotations")
						.version("3.4.0.GA").noStart()),
				provision(mavenBundle()
						.groupId("org.hibernate")
						.artifactId(
								"com.springsource.org.hibernate.annotations.common")
						.version("3.3.0.ga")),
				provision(mavenBundle().groupId("org.hibernate")
						.artifactId("com.springsource.org.hibernate.ejb")
						.version("3.4.0.GA").noStart()),
				provision(mavenBundle().groupId("net.sourceforge.cglib")
						.artifactId("com.springsource.net.sf.cglib")
						.version("2.2.0")),
				provision(mavenBundle().groupId("org.antlr")
						.artifactId("com.springsource.antlr").version("2.7.6")),
				provision(mavenBundle()
						.groupId("org.apache.commons")
						.artifactId(
								"com.springsource.org.apache.commons.collections")
						.version("3.2.0")),
				provision(mavenBundle().groupId("org.dom4j")
						.artifactId("com.springsource.org.dom4j")
						.version("1.6.1")),
				provision(mavenBundle().groupId("org.jboss.javassist")
						.artifactId("com.springsource.javassist")
						.version("3.10.0.GA")),
				provision(mavenBundle().groupId("org.objectweb.asm")
						.artifactId("com.springsource.org.objectweb.asm")
						.version("1.5.3")),
				provision(mavenBundle().groupId("org.objectweb.asm")
						.artifactId("com.springsource.org.objectweb.asm.attrs")
						.version("1.5.3")),

				// provision(mavenBundle().groupId("org.jboss.util")
				// .artifactId("com.springsource.org.jboss.util")
				// .version("2.0.4.GA")),
				provision(mavenBundle().groupId("javax.xml.bind")
						.artifactId("com.springsource.javax.xml.bind")
						.version("2.0.0")),
				provision(mavenBundle().groupId("javax.xml.stream")
						.artifactId("com.springsource.javax.xml.stream")
						.version("1.0.1")),

				provision(mavenBundle().groupId("javax.activation")
						.artifactId("com.springsource.javax.activation")
						.version("1.1.0")),
				// ****************** Orthank JTA dependencies ***********
				// JTA api
				provision(mavenBundle().groupId("javax.transaction")
						.artifactId("com.springsource.javax.transaction")
						.version("1.1.0")),
				// spring tx
				provision(mavenBundle().groupId("org.springframework")
						.artifactId("org.springframework.transaction")
						.version("3.0.6.RELEASE")),
				// atomikos deps
				provision(mavenBundle().groupId("com.atomikos")
						.artifactId("transactions-osgi").version("3.7.0")),

				// derby db

				// // Orthank-atomikos itself
				// provision(mavenBundle()
				// .groupId("net.osgiliath.orthank-sample.java.db")
				// .artifactId("orthank-sample.java.db.atomikos")
				// .version("1.0-SNAPSHOT")),

				// validation api
				provision(mavenBundle().groupId("javax.validation")
						.artifactId("com.springsource.javax.validation")
						.version("1.0.0.GA")),

				// Orthank-jta itself
				provision(mavenBundle()
						.groupId("net.osgiliath.orthank-sample.java.db")
						.artifactId("orthank-sample.java.db.jta")
						.version("1.0-SNAPSHOT").noStart()),

				provision(mavenBundle().groupId("org.apache.derby")
						.artifactId("com.springsource.org.apache.derby")
						.version("10.5.1000001.764942")),

				// Orthank model deps

				//
				// // ******************* Orthank Dao api deps *************
				provision(mavenBundle()
						.groupId("net.osgiliath.orthank-sample.java.dao")
						.artifactId("orthank-sample.java.dao.api")
						.version("1.0-SNAPSHOT")),
				// // // ******************* Orthank Dao api deps *************
				provision(mavenBundle()
						.groupId("net.osgiliath.orthank-sample.java.dao")
						.artifactId("orthank-sample.java.dao.impl")
						.version("1.0-SNAPSHOT")),
				//
				provision(mavenBundle()
						.groupId("net.osgiliath.orthank-sample.java")
						.artifactId("orthank-sample.java.model")
						.version("1.0-SNAPSHOT")),
				// ******************** Orthank - Model deps *******
				// validation impl
				provision(mavenBundle().groupId("org.hibernate")
						.artifactId("com.springsource.org.hibernate.validator")
						.version("4.1.0.GA")),

				workingDirectory("/tmp/demo2"), new Customizer() {

					@Override
					public void customizeEnvironment(File workingFolder) {

						System.err.println("AAAAAAAAAAAAAAAAAAAAAAAAAA: "
								+ workingFolder.getAbsolutePath());
					}
				});

	}

	private ValuesTestDao retrieveValuesTestDao(BundleContext ctx)
			throws InterruptedException {
		ServiceTracker tracker = new ServiceTracker(ctx,
				ValuesTestDao.class.getName(), null);
		tracker.open();
		ValuesTestDao service = (ValuesTestDao) tracker.waitForService(5000);
		tracker.close();
		assertNotNull(service);
		return service;
	}

	@Test
	public void validateDataSource(BundleContext ctx) throws Exception {

		Object service = null;
		ServiceTracker st = new ServiceTracker(ctx, DataSource.class.getName(),
				null);
		st.open();
		try {
			service = st.waitForService(10000L);
		} finally {
			st.close();
		}
		System.err.println("DataSource " + service);
		assertNotNull(service);

	}

	@Test
	public void validateTransactionManager(BundleContext ctx) throws Exception {

		Object service = null;
		ServiceTracker st = new ServiceTracker(ctx,
				TransactionManager.class.getName(), null);
		st.open();
		try {
			service = st.waitForService(10000L);
		} finally {
			st.close();
		}
		System.err.println("TransactionManager  " + service);
		assertNotNull(service);
	}

	@Test
	public void validateNamingContext(BundleContext ctx) throws Exception {

		Object service = null;
		ServiceTracker st = new ServiceTracker(ctx, Context.class.getName(),
				null);
		st.open();
		try {
			service = st.waitForService(10000L);
		} finally {
			st.close();
		}
		System.err.println("Naming Context  " + service);
		assertNotNull(service);
	}

	@Test
	public void persistAndRetriveDataMustBeTheSame(BundleContext ctx)
			throws Exception {
		Date d = new Date();
		ValuesTest original = new ValuesTest();
		original.setBooleanVal(true);
		original.setDateVal(d);
		original.setStringVal("test");
		ValuesTestDao valuesTestDao = retrieveValuesTestDao(ctx);
		assertNotNull(valuesTestDao);
		System.out.println("valuesTestDao ++++++++++++++++++++++++++++ "
				+ valuesTestDao);
		System.out.println("original ++++++++++++++++++++++++++++ " + original);
		valuesTestDao.save(original);
		System.out.println("original ++++++++++++++++++++++++++++ " + original);
		System.out.println("original ++++++++++++++++++++++++++++ "
				+ original.getId());
		assertNotNull(original.getId());
		ValuesTest retrieved = valuesTestDao.findOne(original.getId());
		assertEquals(original.isBooleanVal(), retrieved.isBooleanVal());
		assertEquals(original.getDateVal(), retrieved.getDateVal());
		assertEquals(original.getStringVal(), retrieved.getStringVal());
		// assertEquals(1, retrieved.getVersion());

	}
}
