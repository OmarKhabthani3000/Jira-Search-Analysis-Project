package validator;

public interface CheckInitialData {

}
