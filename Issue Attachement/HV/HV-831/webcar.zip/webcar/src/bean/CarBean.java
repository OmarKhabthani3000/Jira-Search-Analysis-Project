package bean;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Set;

import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import validator.CheckInitialData;
import model.Car;
import model.Driver;

@Named
@SessionScoped
public class CarBean implements Serializable {

	private static final long serialVersionUID = -5370967217813547733L;
	
	private Car car = new Car();
	
	public String simulateGroupValidation() {
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Car>> carViolations = validator.validate( car, CheckInitialData.class );
		
		// OK. Group validation works
		if (carViolations != null && carViolations.size() > 0) {
			FacesMessage fm = new FacesMessage();
			fm.setSummary(carViolations.iterator().next().getMessage());
			fm.setSeverity(FacesMessage.SEVERITY_ERROR);
			FacesContext.getCurrentInstance().addMessage("form", fm);
		}
		
		Set<ConstraintViolation<Driver>> driverViolations = validator.validate( car.getDriver(), CheckInitialData.class );
		
		// Error. Group validation fails for name attribute. 
		if (driverViolations != null && driverViolations.size() > 0) {
			Iterator<ConstraintViolation<Driver>> iterator = driverViolations.iterator();
			while (iterator.hasNext()) {
				FacesMessage fm = new FacesMessage();
				fm.setSummary(iterator.next().getMessage());
				fm.setSeverity(FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().addMessage("form", fm);
			}
		}
		
		return null;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}
	
}
