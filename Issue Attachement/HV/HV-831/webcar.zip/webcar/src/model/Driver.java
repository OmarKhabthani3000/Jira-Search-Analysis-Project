package model;

import java.io.Serializable;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import validator.CheckInitialData;

public class Driver implements Serializable {

	private static final long serialVersionUID = -7550803178037273756L;
	
	@NotNull(message="The name of the driver cannot be blank", groups=CheckInitialData.class)
	private String name;
	
	@NotNull(message="Years of experience of the driver cannot be blank", groups=CheckInitialData.class)
	@Min(value=5, message="The driver must have at least {value} years of experience", groups=CheckInitialData.class)
	private Integer yearsOfExperience;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Integer getYearsOfExperience() {
		return yearsOfExperience;
	}
	public void setYearsOfExperience(Integer yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}
	
}
