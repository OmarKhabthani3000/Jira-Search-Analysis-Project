package model;

import java.io.Serializable;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import validator.CheckInitialData;

public class Car implements Serializable {

	private static final long serialVersionUID = -7655818311732307866L;

	@NotNull(message = "Model of the car cannot be blank")
	@Size(min = 2, max = 40, message = "The model of the car must have between {min} and {max} characters")
	private String model;
	
	@AssertTrue(message="The field taxi must be checked", groups=CheckInitialData.class)
	private Boolean taxi;
	
	private Driver driver = new Driver();

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Boolean getTaxi() {
		return taxi;
	}

	public void setTaxi(Boolean taxi) {
		this.taxi = taxi;
	}

	public Driver getDriver() {
		return driver;
	}

	public void setDriver(Driver driver) {
		this.driver = driver;
	}
	
}
