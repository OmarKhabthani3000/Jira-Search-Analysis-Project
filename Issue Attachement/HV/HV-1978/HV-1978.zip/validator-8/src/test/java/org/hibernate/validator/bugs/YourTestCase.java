package org.hibernate.validator.bugs;

import jakarta.validation.*;
import org.hibernate.validator.constraintvalidation.HibernateConstraintValidatorContext;
import org.hibernate.validator.messageinterpolation.ExpressionLanguageFeatureLevel;
import org.hibernate.validator.testutil.TestForIssue;
import org.junit.BeforeClass;
import org.junit.Test;

import java.lang.annotation.*;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.assertEquals;

public class YourTestCase {

    private static Validator validator;

    @BeforeClass
    public static void setUp() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    @TestForIssue(jiraKey = "HV-1978")
    public void testYourBug() {
        YourAnnotatedBean yourEntity1 = new YourAnnotatedBean(1L, "example");
        yourEntity1.add("foo", "bar");

        Set<ConstraintViolation<YourAnnotatedBean>> constraintViolations = validator.validate(yourEntity1);
        assertEquals(1, constraintViolations.size());

        final ConstraintViolation<YourAnnotatedBean> violation = constraintViolations.iterator().next();
        assertEquals("'bar' is not a valid value for foo", violation.getMessage());
        assertEquals("map[foo]", violation.getPropertyPath().toString());
    }

    public static class MapValidator implements ConstraintValidator<MapValidator.ValidMap, Map<String, String>> {

        @Override
        public boolean isValid(Map<String, String> map, ConstraintValidatorContext context) {

            if (map.containsKey("foo") && map.get("foo").equals("bar")) {
                final HibernateConstraintValidatorContext unwrap = context.unwrap(HibernateConstraintValidatorContext.class);
                unwrap.disableDefaultConstraintViolation();
                final ConstraintValidatorContext.ConstraintViolationBuilder.LeafNodeBuilderDefinedContext leafNodeBuilderDefinedContext = unwrap.buildConstraintViolationWithTemplate("'${validatedValue.foo}' is not a valid value for foo")
                        .enableExpressionLanguage(ExpressionLanguageFeatureLevel.BEAN_PROPERTIES)
                        .addBeanNode().inIterable().atKey("foo");

                // uncomment to pass test
                /*final Field expressionLanguageFeatureLevelField;
                try {
                    final Class<? extends ConstraintValidatorContext.ConstraintViolationBuilder.LeafNodeBuilderDefinedContext> aClass = leafNodeBuilderDefinedContext.getClass();
                    final Class<?> superclass = aClass.getSuperclass();

                    expressionLanguageFeatureLevelField = superclass.getDeclaredField("expressionLanguageFeatureLevel");
                    expressionLanguageFeatureLevelField.setAccessible(true);
                    expressionLanguageFeatureLevelField.set(leafNodeBuilderDefinedContext, ExpressionLanguageFeatureLevel.BEAN_PROPERTIES);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    throw new RuntimeException(e);
                }*/

                leafNodeBuilderDefinedContext
                        .addConstraintViolation();
                return false;
            }

            return true;
        }

        @Documented
        @Retention(RetentionPolicy.RUNTIME)
        @Target({ElementType.FIELD})
        @Constraint(validatedBy = MapValidator.class)
        @interface ValidMap {
            String message() default "The map is not valid";

            Class<?>[] groups() default {};

            Class<?>[] payload() default {};
        }
    }
}
