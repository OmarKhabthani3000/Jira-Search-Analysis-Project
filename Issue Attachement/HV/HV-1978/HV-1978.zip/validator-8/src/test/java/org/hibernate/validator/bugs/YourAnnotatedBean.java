package org.hibernate.validator.bugs;

import java.util.HashMap;
import java.util.Map;

public class YourAnnotatedBean {

    private Long id;

    private String name;

    @YourTestCase.MapValidator.ValidMap
    private Map<String, String> map = new HashMap<>();

    protected YourAnnotatedBean() {
    }

    public YourAnnotatedBean(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void add(String key, String value) {
        map.put(key, value);
    }

    public Map<String, String> getMap() {
        return map;
    }

    public void setMap(Map<String, String> map) {
        this.map = map;
    }
}
