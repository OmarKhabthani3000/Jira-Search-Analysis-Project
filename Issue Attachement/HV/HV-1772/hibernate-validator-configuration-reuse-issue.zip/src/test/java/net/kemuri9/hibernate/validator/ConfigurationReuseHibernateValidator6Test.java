package net.kemuri9.hibernate.validator;

import java.util.Locale;
import java.util.ServiceLoader;

import javax.validation.Configuration;
import javax.validation.MessageInterpolator;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;

public class ConfigurationReuseHibernateValidator6Test {

	public static class MessageInterpolatorImpl implements MessageInterpolator {

		private final String prefix;
		
		public MessageInterpolatorImpl(String prefix) {
			this.prefix = prefix;
		}
		
		@Override
		public String interpolate(String messageTemplate, Context context) {
			return prefix + ": " + messageTemplate;
		}

		@Override
		public String interpolate(String messageTemplate, Context context, Locale locale) {
			return prefix + ": " + messageTemplate + locale.toLanguageTag();
		}
		
		public String toString() {
			return getClass().getSimpleName() + prefix;
		}
	}
	
	@Test
	public void testMessageInterpolatorChange() {
		Assumptions.assumeTrue(ServiceLoader.load(javax.validation.spi.ValidationProvider.class).iterator().hasNext());
		Configuration<?> config = Validation.byDefaultProvider().configure();
		MessageInterpolator interpolator1 = new MessageInterpolatorImpl("One");
		MessageInterpolator interpolator2 = new MessageInterpolatorImpl("Two");
		ValidatorFactory factory1 = config.messageInterpolator(interpolator1).buildValidatorFactory();
		ValidatorFactory factory2 = config.messageInterpolator(interpolator2).buildValidatorFactory();
		Assertions.assertEquals(interpolator1, factory1.getMessageInterpolator());
		Assertions.assertEquals(interpolator2, factory2.getMessageInterpolator());
	}
}
