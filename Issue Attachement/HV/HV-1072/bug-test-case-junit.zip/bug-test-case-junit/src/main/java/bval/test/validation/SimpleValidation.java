package bval.test.validation;

public interface SimpleValidation {
}
