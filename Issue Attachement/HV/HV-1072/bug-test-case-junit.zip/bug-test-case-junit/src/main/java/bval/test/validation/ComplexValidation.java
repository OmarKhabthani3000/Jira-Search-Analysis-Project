package bval.test.validation;

public interface ComplexValidation {
}
