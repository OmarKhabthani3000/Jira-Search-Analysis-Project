package bval.test;

import javax.validation.Valid;

public interface Test {

	void validate(@Valid Entity entity);

	void validate(@Valid CompoundEntity compoundEntity);

}
