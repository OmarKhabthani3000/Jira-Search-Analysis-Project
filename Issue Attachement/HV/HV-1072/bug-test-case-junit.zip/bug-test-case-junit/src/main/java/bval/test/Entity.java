package bval.test;

import javax.validation.constraints.NotNull;

import bval.test.validation.ComplexValidation;
import bval.test.validation.SimpleValidation;

public class Entity {
	@NotNull(groups = SimpleValidation.class)
	String value1;

	@NotNull(groups = ComplexValidation.class)
	String value2;

	public Entity() {}

	public Entity(String value1) {
		this.value1 = value1;
	}
}
