package bval.test.validation;

import javax.validation.GroupSequence;

@GroupSequence({SimpleValidation.class, ComplexValidation.class})
public interface CompleteValidation {
}
