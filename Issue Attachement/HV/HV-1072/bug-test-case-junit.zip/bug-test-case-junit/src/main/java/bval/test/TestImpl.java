package bval.test;

import javax.validation.Valid;

public class TestImpl implements Test {

	public void validate(@Valid Entity entity) {

	}

	public void validate(@Valid CompoundEntity compoundEntity) {

	}
}
