package bval.test;

import javax.validation.Valid;

public class CompoundEntity {
	@Valid
	Entity entity;

	public CompoundEntity(Entity entity) {
		this.entity = entity;
	}
}
