package bval.test;

import java.lang.reflect.Method;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.executable.ExecutableValidator;

import org.junit.Assert;
import org.junit.Test;

import bval.test.validation.CompleteValidation;
import bval.test.validation.ComplexValidation;
import bval.test.validation.SimpleValidation;

public class ValidationTest {
	Validator validator;

	@Test
	public void testEntity() {
		Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
		Assert.assertEquals("Expect one error for simple validation.", 1,
				validator.validate(new Entity(), SimpleValidation.class).size());
		Assert.assertEquals("Expect one error for complex validation.", 1,
				validator.validate(new Entity(), ComplexValidation.class).size());
		Assert.assertEquals("Expect one error for complete validation with failure in first group.", 1,
				validator.validate(new Entity(), CompleteValidation.class).size());
		Assert.assertEquals("Expect two errors for complete validation with failure in second group.", 1,
				validator.validate(new Entity("test"), CompleteValidation.class).size());
	}

	@Test
	public void testCompoundEntity() {
		Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
		Assert.assertEquals("Expect one error for simple validation.", 1,
				validator.validate(new CompoundEntity(new Entity()), SimpleValidation.class).size());
		Assert.assertEquals("Expect one error for complex validation.", 1,
				validator.validate(new CompoundEntity(new Entity()), ComplexValidation.class).size());
		Assert.assertEquals("Expect one error for complete validation with failure in first group.", 1,
				validator.validate(new CompoundEntity(new Entity()), CompleteValidation.class).size());
		Assert.assertEquals("Expect two errors for complete validation with failure in second group.", 1,
				validator.validate(new CompoundEntity(new Entity("test")), CompleteValidation.class).size());
		Assert.assertEquals("Expect two errors for complete validation with failure in second group.", 1,
				validator.validate(new CompoundEntity(new Entity("test")), SimpleValidation.class, ComplexValidation.class).size());
	}

	@Test
	public void testMethodWithCascadedValidation() throws NoSuchMethodException {
		Method method = TestImpl.class.getMethod("validate", Entity.class);
		TestImpl impl = new TestImpl();
		ExecutableValidator validator = Validation.buildDefaultValidatorFactory().getValidator().forExecutables();
		Assert.assertEquals("Expect one error for simple cascaded method validation.", 1,
				validator.validateParameters(impl, method, new Object[] { new Entity() }, SimpleValidation.class).size());
		Assert.assertEquals("Expect one error for complex cascaded method validation.", 1,
				validator.validateParameters(impl, method, new Object[] { new Entity() }, ComplexValidation.class).size());
		Assert.assertEquals("Expect one error for complete cascaded method validation with failure in first group.", 1,
				validator.validateParameters(impl, method, new Object[] { new Entity() }, CompleteValidation.class).size());
		Assert.assertEquals("Expect two errors for complete cascaded method validation with failure in second group.", 1,
				validator.validateParameters(impl, method, new Object[] { new Entity("test") }, CompleteValidation.class).size());
		Assert.assertEquals("Expect two errors for complete cascaded method validation with failure in second group.", 1,
				validator.validateParameters(impl, method, new Object[] { new Entity("test") }, SimpleValidation.class, ComplexValidation.class).size());
	}

	@Test
	public void testMethodWithCascadedCompoundValidation() throws NoSuchMethodException {
		Method method = TestImpl.class.getMethod("validate", CompoundEntity.class);
		TestImpl impl = new TestImpl();
		ExecutableValidator validator = Validation.buildDefaultValidatorFactory().getValidator().forExecutables();
		Assert.assertEquals("Expect one error for simple cascaded method validation.", 1, validator
				.validateParameters(impl, method, new Object[] { new CompoundEntity(new Entity()) }, SimpleValidation.class)
				.size());
		Assert.assertEquals("Expect one error for complex cascaded method validation.", 1, validator
				.validateParameters(impl, method, new Object[] { new CompoundEntity(new Entity()) }, ComplexValidation.class)
				.size());
		Assert.assertEquals("Expect one error for complete cascaded method validation with failure in first group of sequence.", 1, validator
				.validateParameters(impl, method, new Object[] { new CompoundEntity(new Entity()) }, CompleteValidation.class)
				.size());
		Assert.assertEquals("Expect two errors for complete cascaded method validation with failure in second group of group sequence.", 1, validator
				.validateParameters(impl, method, new Object[] { new CompoundEntity(new Entity("test")) }, CompleteValidation.class)
				.size());
		Assert.assertEquals("Expect one error for cascaded method validation with failure in first group.", 1, validator
				.validateParameters(impl, method, new Object[] { new CompoundEntity(new Entity()) }, SimpleValidation.class, ComplexValidation.class)
				.size());
		Assert.assertEquals("Expect two errors for cascaded method validation with failure in second group.", 2, validator
				.validateParameters(impl, method, new Object[] { new CompoundEntity(new Entity("test")) }, SimpleValidation.class, ComplexValidation.class)
				.size());
	}
}
