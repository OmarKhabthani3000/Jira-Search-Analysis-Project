package com.rreps.core;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.BeforeClass;

public abstract class AbstractTestCase {

	protected final Log log = LogFactory.getLog(getClass());
	
    protected static Validator validator;

	@BeforeClass
	public static void setUp() throws Exception {
		//Locale.setDefault(Locale.FRENCH);
    	ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
		System.setErr(System.out);
	}
	
}
