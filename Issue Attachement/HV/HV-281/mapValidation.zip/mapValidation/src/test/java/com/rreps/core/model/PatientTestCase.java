package com.rreps.core.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Set;

import javax.validation.ConstraintViolation;

import org.junit.Test;

import com.rreps.core.AbstractTestCase;

public class PatientTestCase extends AbstractTestCase {

	@Test
	public void testAnnotationMap() {
		Patient p = new Patient("P-00000001");

		PatientAttribute pat;
		PatientAnnotation pan;
		pat = new PatientFreeAttribute("initiales");
		pan = new PatientAnnotation();
		pan.setAttribute(pat);
		p.addAnnotation(pan);

		PatientAnnotation retrieved = p.getAnnotation("initiales");

		assertNotNull("Annotation 'initiales' non trouv�e", retrieved);

		pat = new PatientConstrainedAttribute("sexe");
		pan = new PatientAnnotation();
		pan.setAttribute(pat);
		p.addAnnotation(pan);

		retrieved = p.getAnnotation("sexe");

		assertNotNull("Annotation 'sexe' non trouv�e", retrieved);

		retrieved = p.getAnnotation("initiales");

		assertNotNull("Annotation 'initiales' non trouv�e", retrieved);
	}

	@Test
	public void validatePatient() {
		Patient p = new Patient("P-00000001");

		PatientAttribute pat;
		PatientAnnotation pan;
		AnnotationValue<PatientAttribute> av = new AnnotationValue<PatientAttribute>();
		av.setFreeValue("yaks");

		pat = new PatientFreeAttribute("initiales");
		pan = new PatientAnnotation();
		pan.setAttribute(pat);
		pan.setValue(av);
		p.addAnnotation(pan);
		pat = new PatientFreeAttribute("sexe");
		pan = new PatientAnnotation();
		pan.setAttribute(pat);
		pan.setValue(av);
		p.addAnnotation(pan);
		pat = new PatientFreeAttribute("dateNaissance");
		pan = new PatientAnnotation();
		pan.setAttribute(pat);
		pan.setValue(av);
		p.addAnnotation(pan);

		// valid case
		Set<ConstraintViolation<Patient>> constraintViolations = validator.validate(p);
		for (ConstraintViolation<Patient> constraintViolation : constraintViolations) {
			System.out.println(constraintViolation.getPropertyPath() + " : " + constraintViolation.getMessage());
		}
		assertEquals(0, constraintViolations.size());

		// invalid case
		p.removeAnnotation("initiales");
		constraintViolations = validator.validate(p);
		assertEquals(1, constraintViolations.size());

		
		for (ConstraintViolation<Patient> constraintViolation : constraintViolations) {
			System.out.println(constraintViolation.getPropertyPath() + " : " + constraintViolation.getMessage());
		}

	}

}