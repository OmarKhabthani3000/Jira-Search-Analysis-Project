package com.rreps.core.dao;

import org.hibernate.SessionFactory;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.rreps.core.AbstractTestCase;
import com.rreps.core.model.AnnotationValue;
import com.rreps.core.model.Patient;
import com.rreps.core.model.PatientAnnotation;
import com.rreps.core.model.PatientAnnotationConstrainedValue;
import com.rreps.core.model.PatientAttribute;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext-core.xml" })
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public abstract class AbstractDaoTestCase extends AbstractTestCase {

	@Autowired
	@Qualifier("sessionFactory")
	protected SessionFactory sessionFactory;

	protected void flush(SessionFactory sf) {
		HibernateTemplate hibernateTemplate = new HibernateTemplate(sf);
		hibernateTemplate.flush();
		hibernateTemplate.clear();
	}

	protected void addPatientAnnotation(AttributeDao atDao, ConstrainedValueDao cvDao, Patient p, String attr,
	        String value) {
		PatientAttribute attribute;
		PatientAnnotation annotation;
		AnnotationValue<PatientAttribute> av;
		PatientAnnotationConstrainedValue pacv;

		if (value == null) {
			return;
		}
		attribute = atDao.getPatientAttribute(attr);
		annotation = new PatientAnnotation();
		annotation.setAttribute(attribute);
		if (attribute.isConstrained()) {
			pacv = new PatientAnnotationConstrainedValue();
			pacv.addValue(cvDao.getPatientConstrainedValue(attr, value));
			annotation.setValue(pacv);
			pacv.setAnnotation(annotation);
		}
		else {
			av = new AnnotationValue<PatientAttribute>();
			av.setFreeValue(value);
			annotation.setValue(av);
			av.setAnnotation(annotation);
		}
		p.addAnnotation(annotation);
	}

}
