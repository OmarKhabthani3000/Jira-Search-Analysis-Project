package com.rreps.core.dao;

import static org.junit.Assert.fail;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.rreps.core.model.Patient;

public class PatientDaoTestCase extends AbstractDaoTestCase {

	@Autowired
	private PatientDao dao;

	@Autowired
	private ConstrainedValueDao cvDao;

	@Autowired
	private AttributeDao atDao;

	@Test
	public void testCreatePatient() {
		Patient p = new Patient("P-12345678");
		addPatientAnnotation(atDao, cvDao, p, "initiales", "XX");
		addPatientAnnotation(atDao, cvDao, p, "sexe", "M");
		addPatientAnnotation(atDao, cvDao, p, "dateNaissance", "11/11/1911");
		addPatientAnnotation(atDao, cvDao, p, "antecedents", "Aucun");

		// valid case
		try {
			p = dao.save(p);
		}
		catch (ConstraintViolationException e) {
			for (ConstraintViolation<?> constraintViolation : e.getConstraintViolations()) {
				System.out.println(constraintViolation.getPropertyPath() + " : " + constraintViolation.getMessage());
			}
			fail("should have passed validation!");
		}
		
		// invalid case
		p.removeAnnotation("initiales");
		try {
			p = dao.save(p);
			fail("should have failed because of validation!");
		}
		catch (ConstraintViolationException e) {
			for (ConstraintViolation<?> constraintViolation : e.getConstraintViolations()) {
				System.out.println(constraintViolation.getPropertyPath() + " : " + constraintViolation.getMessage());
			}
		}
	}

}
