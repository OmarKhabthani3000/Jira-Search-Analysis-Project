package com.rreps.core.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Transient;

@Entity
@DiscriminatorValue("PatientConstrainedAttribute")
public class PatientConstrainedAttribute extends PatientAttribute implements
        ConstrainedAttribute<PatientConstrainedValue>, Serializable {

	private static final long serialVersionUID = 4121484604103205296L;

	private List<PatientConstrainedValue> allowed = new ArrayList<PatientConstrainedValue>();

	public PatientConstrainedAttribute() {
		super();
	}

	public PatientConstrainedAttribute(final String name) {
		super(name);
	}

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "attribute_constrainedvalue", joinColumns = @JoinColumn(name = "attribute_id"), 
			inverseJoinColumns = @JoinColumn(name = "constrainedvalue_id"))
	public List<PatientConstrainedValue> getAllowed() {
		return allowed;
	}

	public void setAllowed(List<PatientConstrainedValue> allowed) {
		this.allowed = allowed;
	}

	@Transient
	public List<PatientConstrainedValue> getFirstLevelAllowed() {
		List<PatientConstrainedValue> l = new ArrayList<PatientConstrainedValue>();
		for (PatientConstrainedValue c : getAllowed()) {
			if (c.getParent() == null) {
				l.add(c);
			}
		}
		return l;
	}

	public void addAllowed(PatientConstrainedValue item) {
		allowed.add(item);
	}

	public void removeAllowed(PatientConstrainedValue item) {
		allowed.remove(item);
	}

}
