package com.rreps.core.model;

import java.util.List;


public interface ConstrainedAttribute<CONSTRAINED extends ConstrainedValue<?>> {
	
	public List<? extends CONSTRAINED> getAllowed();

	public List<? extends CONSTRAINED> getFirstLevelAllowed();
	
    public void addAllowed(CONSTRAINED item);
    
    public void removeAllowed(CONSTRAINED item);
}
