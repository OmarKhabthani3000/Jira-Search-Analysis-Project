package com.rreps.core.model;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public abstract class PatientAttribute extends Attribute<Annotable<?, ?>> implements Serializable {

    private static final long serialVersionUID = -3909998273067668924L;
    
	public PatientAttribute() {
	}

	public PatientAttribute(final String name) {
		this.name = name;
	}
	
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (!(o instanceof PatientAttribute)) {
			return false;
		}
		final PatientAttribute a = (PatientAttribute) o;
		return !(getName() != null ? !getName().equals(a.getName()) : a.getName() != null);
	}
}
