package com.rreps.core.model;

import java.util.Map;

import org.apache.commons.lang.builder.HashCodeBuilder;

public abstract class AnnotableObject<ANNOTATION extends Annotation<?, ATTRIBUTE>, ATTRIBUTE extends Attribute<?>>
        extends BaseObject implements Annotable<ANNOTATION, ATTRIBUTE> {

	private static final long serialVersionUID = -4864779429692107227L;
	protected String reference = null;
	
	public abstract String getReference();

	public void setReference(String reference) {
		this.reference = reference;
	}

	public abstract Map<ATTRIBUTE, ANNOTATION> getAnnotations();

	public abstract void setAnnotations(Map<ATTRIBUTE, ANNOTATION> m);

	public abstract void addAnnotation(ANNOTATION annotation);

	public abstract ANNOTATION getAnnotation(String name);

	public abstract void removeAnnotation(String name);

	@Override
	public int hashCode() {
		return new HashCodeBuilder(-1525997167, -811076155).append(getReference()).append(getId()).toHashCode();
	}
}
