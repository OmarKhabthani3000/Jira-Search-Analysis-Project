package com.rreps.core.model;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.rreps.core.model.validation.PatientMandatoryAnnotations;

@Entity
@Table(name = "patient")
public class Patient extends AnnotableObject<PatientAnnotation, PatientAttribute> {

	private static final long serialVersionUID = 3825148115001055028L;

	private Integer version = null;
	protected Map<PatientAttribute, PatientAnnotation> annotations = new HashMap<PatientAttribute, PatientAnnotation>();

	public Patient() {
	}

	public Patient(final String ref) {
		this.reference = ref;
	}

	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	@Override
	@NotNull
	@Pattern(regexp = "\\QP-\\E\\d{8}")
	@Column(name = "reference", nullable = false, length = 10, unique = true)
	public String getReference() {
		return reference;
	}

	@Version
	public Integer getVersion() {
		return version;
	}

	@Override
	@PatientMandatoryAnnotations
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "entity", cascade = CascadeType.ALL)
	@MapKey(name = "attribute")
	public Map<PatientAttribute, PatientAnnotation> getAnnotations() {
		return annotations;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	@Override
	public void setAnnotations(Map<PatientAttribute, PatientAnnotation> annotations) {
		this.annotations = annotations;
	}

	@Override
	public void addAnnotation(PatientAnnotation annotation) {
		annotation.setEntity(this);
		annotations.put(annotation.getAttribute(), annotation);
	}

	@Override
	public void removeAnnotation(String name) {
		PatientAnnotation a = annotations.remove(new PatientFreeAttribute(name));
		if (a != null)
			a.setEntity(null);
	}

	@Override
	@Transient
	public PatientAnnotation getAnnotation(String name) {
		return annotations.get(new PatientFreeAttribute(name));
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (!(o instanceof Patient)) {
			return false;
		}
		final Patient m = (Patient) o;
		return !(getId() != null ? !getId().equals(m.getId()) : m.getId() != null);

	}

	@Override
	public String toString() {
		return getId() + ":" + getReference();
	}

}
