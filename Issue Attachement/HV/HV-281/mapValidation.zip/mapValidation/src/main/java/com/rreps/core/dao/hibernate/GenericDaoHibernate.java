package com.rreps.core.dao.hibernate;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.impl.CriteriaImpl;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.orm.ObjectRetrievalFailureException;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.rreps.core.dao.GenericDao;
import com.rreps.core.dao.Pagination;

public abstract class GenericDaoHibernate<T, PK extends Serializable> implements GenericDao<T, PK> {

	protected final Log log = LogFactory.getLog(getClass());
	private Class<T> persistentClass;
	private HibernateTemplate hibernateTemplate;

	private SessionFactory sessionFactory;

	public GenericDaoHibernate(final Class<T> persistentClass) {
		this.persistentClass = persistentClass;
	}

	public GenericDaoHibernate(final Class<T> persistentClass, SessionFactory sessionFactory) {
		this.persistentClass = persistentClass;
		this.sessionFactory = sessionFactory;
		this.hibernateTemplate = new HibernateTemplate(sessionFactory);
	}

	public HibernateTemplate getHibernateTemplate() {
		return this.hibernateTemplate;
	}

	public SessionFactory getSessionFactory() {
		return this.sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		this.hibernateTemplate = new HibernateTemplate(sessionFactory);
	}

	public List<T> getAll() {
		return hibernateTemplate.loadAll(this.persistentClass);
	}

	@SuppressWarnings("unchecked")
	public List<T> getAllDistinct() {
		Collection result = new LinkedHashSet(getAll());
		return new ArrayList(result);
	}

	public T get(PK id) {
		T entity = (T) hibernateTemplate.get(this.persistentClass, id);

		if (entity == null) {
			log.warn("Uh oh, '" + this.persistentClass + "' object with id '" + id + "' not found...");
			throw new ObjectRetrievalFailureException(this.persistentClass, id);
		}

		return entity;
	}

	public boolean exists(PK id) {
		T entity = (T) hibernateTemplate.get(this.persistentClass, id);
		return entity != null;
	}

	public T save(T object) {
		return (T) hibernateTemplate.merge(object);
	}

	public void remove(PK id) {
		hibernateTemplate.delete(this.get(id));
	}

	@SuppressWarnings("unchecked")
	public List<T> findByNamedQuery(String queryName, Map<String, Object> queryParams) {
		String[] params = new String[queryParams.size()];
		Object[] values = new Object[queryParams.size()];

		int index = 0;
		for (String s : queryParams.keySet()) {
			params[index] = s;
			values[index++] = queryParams.get(s);
		}

		return hibernateTemplate.findByNamedQueryAndNamedParam(queryName, params, values);
	}

	@SuppressWarnings("unchecked")
	public Pagination<T> paginate(String field, boolean ascending, int startIndex, int nbResults) {
		CriteriaImpl c = (CriteriaImpl) sessionFactory.getCurrentSession().createCriteria(persistentClass);

		// total number of records
		int total = ((Long) c.setProjection(Projections.rowCount()).uniqueResult()).intValue();

		// the property to sort upon (or id if null)
		String actualField = (field == null || field.length() == 0 ? "id" : field);

		// create a projection list with all the properties in the persistent class
		ProjectionList pl = Projections.projectionList();
		for (String property : sessionFactory.getClassMetadata(persistentClass).getPropertyNames()) {
			pl.add(Projections.property(property), property);
		}

		// the AliasToBeanResultTransformer trick
		c.setProjection(Projections.distinct(pl)).setResultTransformer(
		        new AliasToBeanResultTransformer(persistentClass));

		// get the results
		List<T> results = c.addOrder(ascending ? Order.asc(actualField) : Order.desc(actualField)).setFirstResult(
		        startIndex).setMaxResults(nbResults >= total ? total : nbResults).list();

		// create the Pagination object using total and list
		Pagination<T> p = new Pagination<T>(results, total, (ascending ? Pagination.Order.ASC : Pagination.Order.DESC),
		        field, startIndex, nbResults >= total ? total : nbResults);

		return p;
	}

}
