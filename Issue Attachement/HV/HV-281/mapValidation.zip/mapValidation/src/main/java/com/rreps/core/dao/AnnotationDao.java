package com.rreps.core.dao;

import com.rreps.core.model.Annotation;

@SuppressWarnings("unchecked")
public interface AnnotationDao extends GenericDao<Annotation, Long> {

    Annotation getAnnotation(Long id);

    void removeAnnotation(Long id);

}
