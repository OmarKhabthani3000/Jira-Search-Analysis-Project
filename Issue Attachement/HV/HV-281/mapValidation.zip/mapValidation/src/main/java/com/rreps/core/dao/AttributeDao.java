package com.rreps.core.dao;

import java.util.List;

import com.rreps.core.model.Attribute;
import com.rreps.core.model.PatientAttribute;

@SuppressWarnings("unchecked")
public interface AttributeDao extends GenericDao<Attribute, Long> {

	PatientAttribute getPatientAttribute(String name);

	List<Attribute> getAttributes();

	List<PatientAttribute> getPatientAttributes();

	Attribute<?> getAttribute(Long id);

	Attribute<?> saveAttribute(Attribute<?> a);

	void removeAttribute(Long id);
}
