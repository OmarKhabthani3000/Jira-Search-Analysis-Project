package com.rreps.core.model.validation;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.*;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Target( { METHOD, FIELD, ANNOTATION_TYPE })
@Retention(RUNTIME)
@Constraint(validatedBy = PatientMandatoryAnnotationsValidator.class)
@Documented
public @interface PatientMandatoryAnnotations {

	Class<? extends Payload>[] payload() default {};
	
	Class<?>[] groups() default {};

    String message() default "Il manque des donn�es pour ce patient";

    String[] mandatoryNames() default {"initiales", "sexe", "dateNaissance" };
}