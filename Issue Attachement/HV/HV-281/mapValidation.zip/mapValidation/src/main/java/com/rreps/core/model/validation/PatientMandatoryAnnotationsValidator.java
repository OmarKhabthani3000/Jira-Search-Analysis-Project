package com.rreps.core.model.validation;

import java.util.Map;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.rreps.core.model.PatientAnnotation;
import com.rreps.core.model.PatientAttribute;
import com.rreps.core.model.PatientFreeAttribute;

public class PatientMandatoryAnnotationsValidator implements ConstraintValidator<PatientMandatoryAnnotations, Map<PatientAttribute, PatientAnnotation>> {

	private String[] mandatoryNames;
	
    public void initialize(PatientMandatoryAnnotations constraintAnnotation) {
    	mandatoryNames = constraintAnnotation.mandatoryNames();
    }

    public boolean isValid(Map<PatientAttribute, PatientAnnotation> annotationMap, ConstraintValidatorContext constraintContext) {
    	for (String name: mandatoryNames) {
	        if (!annotationMap.containsKey(new PatientFreeAttribute(name))){
	        	return false;
	        }
        }
    	return true;    	
    }

}