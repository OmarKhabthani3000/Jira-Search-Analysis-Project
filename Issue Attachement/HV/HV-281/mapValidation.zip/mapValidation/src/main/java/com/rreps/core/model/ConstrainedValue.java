package com.rreps.core.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Min;

@Entity
@Table(name = "constrainedvalue", uniqueConstraints = { @UniqueConstraint(columnNames = { "category", "allowed" }) })
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING)
public abstract class ConstrainedValue<ATTRIBUTE extends Attribute<?>> extends BaseObject implements Serializable,
		Comparable<ConstrainedValue<ATTRIBUTE>> {

	private static final long serialVersionUID = -664307990393655657L;
	protected List<ConstrainedValue<ATTRIBUTE>> children = new ArrayList<ConstrainedValue<ATTRIBUTE>>();
	protected String value;
	protected String category;
	protected ConstrainedValue<ATTRIBUTE> parent;
	private int ordering;
	private String code;

	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	@Column(name = "allowed", nullable = false, length = 100)
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Column(name = "code", nullable = false, updatable = false, unique = true, length = 6)
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Column(name = "category", nullable = false, updatable = false, length = 100)
	public void setCategory(String category) {
		this.category = category;
	}

	public String getCategory() {
		return category;
	}

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, targetEntity = ConstrainedValue.class)
	@JoinColumn(name = "parent_id", updatable = false, insertable = false)
	@OrderBy(value = "ordering")
	public List<ConstrainedValue<ATTRIBUTE>> getChildren() {
		return children;
	}

	public void setChildren(List<ConstrainedValue<ATTRIBUTE>> children) {
		this.children = children;
	}

	public void addChild(ConstrainedValue<ATTRIBUTE> c) {
		c.setParent(this);
		this.getChildren().add(c);
	}

	public void removeChild(ConstrainedValue<ATTRIBUTE> c) {
		c.setParent(null);
		this.getChildren().remove(c);
	}

	@ManyToOne(fetch = FetchType.EAGER, targetEntity = ConstrainedValue.class)
	@JoinColumn(name = "parent_id", insertable = true, updatable = true)
	public ConstrainedValue<ATTRIBUTE> getParent() {
		return parent;
	}

	public void setParent(ConstrainedValue<ATTRIBUTE> parent) {
		this.parent = parent;
	}

	@Min(value = 1)
	@Column(name = "ordering", nullable = false, columnDefinition = "int(11) default 1")
	public int getOrdering() {
		return ordering;
	}

	public void setOrdering(int ordering) {
		this.ordering = ordering;
	}

	public int hashCode() {
		final int prime = 31;
		int result = 0;
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@SuppressWarnings("unchecked")
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (getClass() != obj.getClass())
			return false;
		ConstrainedValue other = (ConstrainedValue) obj;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

	public String toString() {
		return value;
	}

}
