package com.rreps.core.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "eav_patient", uniqueConstraints = { @UniqueConstraint(columnNames = { "attribute_id", "value_id", "entity_id" })})
public class PatientAnnotation extends Annotation<Patient, PatientAttribute> implements Serializable {

	private static final long serialVersionUID = -5180580885061582423L;

	@Override
	@NotNull
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(nullable = false, updatable = false)
	public Patient getEntity() {
		return super.getEntity();
	}
	
    @Override
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(nullable = false, updatable = false)
    public PatientAttribute getAttribute() {
	    return super.getAttribute();
    }
    
    @Override
	@NotNull
	@Valid
	@OneToOne(cascade = CascadeType.ALL, optional = false)
	@JoinColumn(nullable = false, updatable = true)
	public AnnotationValue<? extends PatientAttribute> getValue() {
		return value;
	}
    
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof PatientAnnotation))
			return false;
		final PatientAnnotation other = (PatientAnnotation) obj;
		return (id != null && id.equals(other.id));
	}
}
