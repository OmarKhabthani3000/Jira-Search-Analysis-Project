package com.rreps.core.dao;

import java.util.List;

import com.rreps.core.model.Patient;
import com.rreps.core.model.PatientConstrainedValue;

public interface PatientDao extends GenericDao<Patient, Long> {

	Patient getPatient(String reference);
	
	Patient getPatient(Long id);

    List<Patient> getAllPatients();
    
    List<Patient> getPotentialDuplicates(String initiales, PatientConstrainedValue sex, String birthDate);
    
    //Patient savePatient(Patient p);

    //void removePatient(Long id);
}
