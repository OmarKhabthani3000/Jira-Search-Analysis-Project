package com.rreps.core.dao.hibernate;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.rreps.core.dao.PatientDao;
import com.rreps.core.model.Patient;
import com.rreps.core.model.PatientConstrainedValue;

@Repository
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class PatientDaoHibernate extends GenericDaoHibernate<Patient, Long> implements PatientDao {

	public PatientDaoHibernate() {
		super(Patient.class);
	}

	@Override
	@Autowired
	public void setSessionFactory(@Qualifier("sessionFactory") SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	public Patient getPatient(String reference) {
		List<?> l = getHibernateTemplate().find("from Patient where reference=?", reference);
		if (l.size() == 1) {
			return (Patient) l.get(0);
		}
		throw new DataRetrievalFailureException("Patient not found: reference='" + reference + "'");
	}

	public Patient getPatient(Long id) {
		return get(id);
	}

	public List<Patient> getAllPatients() {
		return getAll();
	}

	@SuppressWarnings("unchecked")
	public List<Patient> getPotentialDuplicates(String initiales, PatientConstrainedValue sex, String birthDate) {

		Object[] params = { initiales, sex, birthDate };
		String[] names = { "initiales", "sexe", "dateNaissance" };
		List<Patient> l = getHibernateTemplate()
		        .findByNamedParam(
		                "from Patient p where p in ("
		                        + "select a.entity from PatientAnnotation a where a.attribute.name = 'initiales' and a.value.freeValue = :initiales"
		                        + ") and p in ("
		                        + "select a.entity from PatientAnnotation a where a.attribute.name = 'sexe' and :sexe in elements(a.value.constrainedValues)"
		                        + ") and p in ("
		                        + "select a.entity from PatientAnnotation a where a.attribute.name = 'dateNaissance' and a.value.freeValue = :dateNaissance"
		                        + ")", names, params);
		return l;
	}

	// @Transactional(readOnly = false)
	// public void removePatient(Long id) {
	// remove(id);
	// }
	//	
	// @Transactional(readOnly = false)
	// public Patient savePatient(Patient p) {
	// return save(p);
	// }

}
