package com.rreps.core.dao.hibernate;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.rreps.core.dao.AnnotationDao;
import com.rreps.core.model.Annotation;

@SuppressWarnings("unchecked")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
@Repository
public class AnnotationDaoHibernate extends GenericDaoHibernate<Annotation, Long> implements AnnotationDao {

    public AnnotationDaoHibernate() {
        super(Annotation.class);
    }

    @Override
    @Autowired
    public void setSessionFactory(@Qualifier("sessionFactory")SessionFactory sessionFactory) {
	    super.setSessionFactory(sessionFactory);
    }
    
	public Annotation<?, ?> getAnnotation(Long id) {
        return get(id);
    }

	@Transactional(readOnly = false)
	public void removeAnnotation(Long id) {
        remove(id);
    }

}
