package com.rreps.core.model;

import java.util.List;


public interface ConstrainedAnnotationValue {
	
	public List<? extends ConstrainedValue<?>> getConstrainedValues();
	
}
