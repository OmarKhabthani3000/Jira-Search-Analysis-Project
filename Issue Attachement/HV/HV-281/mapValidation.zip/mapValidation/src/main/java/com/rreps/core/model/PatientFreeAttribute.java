package com.rreps.core.model;

import java.io.Serializable;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("PatientFreeAttribute")
public class PatientFreeAttribute extends PatientAttribute implements Serializable {

	private static final long serialVersionUID = 4464021942714613205L;

	public PatientFreeAttribute() {
		super();
	}

	public PatientFreeAttribute(final String name) {
		this.name = name;
	}
}
