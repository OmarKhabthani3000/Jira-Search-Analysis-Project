package com.rreps.core.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

@Entity
@Table(name = "value")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("Free")
public class AnnotationValue<ATTRIBUTE extends Attribute<?>> extends BaseObject implements Serializable {

	protected static final long serialVersionUID = 8091152309303389818L;
	protected String freeValue = null;
	private Annotation<?, ?> annotation;
	
	@Transient
	public String getStringValue(){
		return freeValue;
	}

	public void setStringValue(String value){
		this.freeValue = value;
	}
		
	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	@Size(min = 1, max = 256)
	@Column(length = 256)
	public String getFreeValue() {
		return freeValue;
	}

	public void setFreeValue(String value) {
		this.freeValue = value;
	}

	public int hashCode() {
	    final int prime = 31;
	    int result = 0;
	    result = prime * result + ((annotation == null) ? 0 : annotation.hashCode());
	    result = prime * result + ((freeValue == null) ? 0 : freeValue.hashCode());
	    return result;
    }

	@SuppressWarnings("unchecked")
    public boolean equals(Object obj) {
	    if (this == obj)
		    return true;
	    if (getClass() != obj.getClass())
		    return false;
	    AnnotationValue other = (AnnotationValue) obj;
	    if (annotation == null) {
		    if (other.annotation != null)
			    return false;
	    }
	    else if (!annotation.equals(other.annotation))
		    return false;
	    if (freeValue == null) {
		    if (other.freeValue != null)
			    return false;
	    }
	    else if (!freeValue.equals(other.freeValue))
		    return false;
	    return true;
    }

	@Override
	public String toString() {
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE).append("name", getStringValue()).toString();
	}

	public void setAnnotation(Annotation<?, ?> annotation) {
	    this.annotation = annotation;
    }

	@Transient
	public Annotation<?, ?> getAnnotation() {
	    return annotation;
    }
}
