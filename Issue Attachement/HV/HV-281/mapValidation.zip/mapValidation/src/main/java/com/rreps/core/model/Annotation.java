package com.rreps.core.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.builder.HashCodeBuilder;

@Entity
@Table(name = "eav")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Annotation<ENTITY extends Annotable<?, ATTRIBUTE>, ATTRIBUTE extends Attribute<?>> extends
        BaseObject {

	private static final long serialVersionUID = -1343306758260706302L;
	protected ENTITY entity = null;
	protected ATTRIBUTE attribute = null;
	protected AnnotationValue<? extends ATTRIBUTE> value = null;

	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	@Transient
	public AnnotationValue<? extends ATTRIBUTE> getValue() {
		return value;
	}

	public void setValue(AnnotationValue<? extends ATTRIBUTE> value) {
		this.value = value;
		// ATTENTION!!! needed for history but might mess everything up!
		if (value != null) {
			value.setAnnotation(this);
		}
	}

	@Transient
	public ATTRIBUTE getAttribute() {
		return attribute;
	}

	public void setAttribute(ATTRIBUTE attribute) {
		this.attribute = attribute;
	}

	@Transient
	public ENTITY getEntity() {
		return entity;
	}

	public void setEntity(ENTITY entity) {
		this.entity = entity;
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(-939998163, 1509120713).append(getClass().getSimpleName()).append(getId())
		        .toHashCode();
	}

	@Override
	public String toString() {
		return "entity:" + entity.getReference() + "/attribute:" + attribute.getName() + "/value:"
		        + getValue().toString();
	}

}
