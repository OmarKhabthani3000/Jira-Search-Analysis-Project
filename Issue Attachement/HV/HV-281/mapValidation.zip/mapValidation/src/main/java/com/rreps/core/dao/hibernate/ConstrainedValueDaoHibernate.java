package com.rreps.core.dao.hibernate;

import java.util.Collections;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.rreps.core.dao.ConstrainedValueDao;
import com.rreps.core.model.ConstrainedValue;
import com.rreps.core.model.PatientConstrainedValue;

@Repository
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
@SuppressWarnings("unchecked")
public class ConstrainedValueDaoHibernate extends GenericDaoHibernate<ConstrainedValue, Long> implements
		ConstrainedValueDao {

	public ConstrainedValueDaoHibernate() {
		super(ConstrainedValue.class);
	}

	@Override
	@Autowired
	public void setSessionFactory(@Qualifier("sessionFactory") SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	public ConstrainedValue getConstrainedValue(Long id) {
		return get(id);
	}

	public List<? extends ConstrainedValue<?>> getConstrainedValues(String attribute) {
		String query = "select attribute.allowed from Attribute as attribute where attribute.name = ?";
		List<? extends ConstrainedValue<?>> l = getHibernateTemplate().find(query, attribute);
		if (l == null || l.size() == 0) {
			throw new DataRetrievalFailureException("not values found! attribute='" + attribute + "'");
		}
		Collections.sort(l);
		return l;
	}

	public List<PatientConstrainedValue> getPatientConstrainedValues(String attribute) {
		String query = "select attribute.allowed from PatientAttribute as attribute where attribute.name = ?";
		List<PatientConstrainedValue> l = getHibernateTemplate().find(query, attribute);
		if (l == null || l.size() == 0) {
			throw new DataRetrievalFailureException("not values found! attribute='" + attribute + "'");
		}
		Collections.sort(l);
		return l;
	}

	public ConstrainedValue getConstrainedValue(String attribute, String value) {
		Object[] params = new Object[] { attribute, value };
		String query = "select allowed from Attribute as attribute join attribute.allowed as allowed where attribute.name = ? and allowed.value = ?";
		List<?> l = getHibernateTemplate().find(query, params);
		if (l.size() == 1) {
			return (ConstrainedValue) l.get(0);
		}
		throw new DataRetrievalFailureException(l.size() == 0 ? "value not found!" : "multiple values found!"
				+ " attribute='" + attribute + "', value='" + value + "'");
	}

	public ConstrainedValue getConstrainedValueByCode(String attribute, String code) {
		Object[] params = new Object[] { attribute, code };
		String query = "select allowed from Attribute as attribute join attribute.allowed as allowed where attribute.name = ? and allowed.code = ?";
		List<?> l = getHibernateTemplate().find(query, params);
		if (l.size() == 1) {
			return (ConstrainedValue) l.get(0);
		}
		throw new DataRetrievalFailureException(l.size() == 0 ? "value not found!" : "multiple values found!"
				+ " attribute='" + attribute + "', code='" + code + "'");
	}

	public PatientConstrainedValue getPatientConstrainedValue(String attribute, String value) {
		Object[] params = new Object[] { attribute, value };
		String query = "select allowed from PatientAttribute as attribute join attribute.allowed as allowed where attribute.name = ? and allowed.value = ?";
		List<?> l = getHibernateTemplate().find(query, params);
		if (l.size() == 1) {
			return (PatientConstrainedValue) l.get(0);
		}
		throw new DataRetrievalFailureException(l.size() == 0 ? "value not found!" : "multiple values found!"
				+ " attribute='" + attribute + "', value='" + value + "'");
	}

	@Transactional(readOnly = false)
	public void removeConstrainedValue(Long id) {
		remove(id);
	}

	@Transactional(readOnly = false)
	public ConstrainedValue saveConstrainedValue(ConstrainedValue cv) {
		return save(cv);
	}
}
