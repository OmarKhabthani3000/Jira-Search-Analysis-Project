package com.rreps.core.dao;

import java.util.List;

import com.rreps.core.model.ConstrainedValue;
import com.rreps.core.model.PatientConstrainedValue;

@SuppressWarnings("unchecked")
public interface ConstrainedValueDao extends GenericDao<ConstrainedValue, Long> {

	ConstrainedValue getConstrainedValue(String attribute, String value);

	ConstrainedValue getConstrainedValueByCode(String attribute, String code);

	PatientConstrainedValue getPatientConstrainedValue(String attribute, String value);

	List<? extends ConstrainedValue<?>> getConstrainedValues(String attribute);

	List<PatientConstrainedValue> getPatientConstrainedValues(String attribute);

	ConstrainedValue getConstrainedValue(Long id);

	ConstrainedValue saveConstrainedValue(ConstrainedValue a);

	void removeConstrainedValue(Long id);
}
