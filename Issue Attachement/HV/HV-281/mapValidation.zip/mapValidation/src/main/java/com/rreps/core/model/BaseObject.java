package com.rreps.core.model;

import java.io.Serializable;

/**
 * Base class for Model objects. Child objects should implement toString(), equals() and hashCode().
 */
public abstract class BaseObject implements Serializable {

    private static final long serialVersionUID = -943630336299469742L;

    protected Long id = null;
    
    public abstract Long getId();

    public void setId(Long id) {
        this.id = id;
    }
    
    @Override
    public abstract String toString();

    @Override
    public abstract boolean equals(Object o);

    @Override
    public abstract int hashCode();
}
