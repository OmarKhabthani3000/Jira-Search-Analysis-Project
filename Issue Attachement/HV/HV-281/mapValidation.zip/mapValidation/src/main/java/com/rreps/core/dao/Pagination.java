package com.rreps.core.dao;

import java.util.ArrayList;
import java.util.List;


public class Pagination<ELEMENT> {

	private final static Order DEFAULT_ORDER = Order.ASC;
	private final static String DEFAULT_FIELD = "id";
	private final static int DEFAULT_NB_RESULTS = 1;
	
	public enum Order { 
		ASC("asc"), DESC("desc"); 
		
		String value;
		
		Order(String value){
			this.value = value;
		}
		
		public String toString(){
			return value;
		}
	};
	
	private int totalRecords = 0;
	private List<ELEMENT> elements = new ArrayList<ELEMENT>();
	private Order order = DEFAULT_ORDER;
	private String field = DEFAULT_FIELD;
	private int startIndex = 0;
	private int nbResults= DEFAULT_NB_RESULTS;

	public Pagination() {
	}

	public Pagination(List<ELEMENT> elements, int totalRecords, Order order, String field, int startIndex, int nbResults){
		this.elements = elements;
		this.totalRecords = totalRecords;
		this.order = order;
		this.field = field;
		this.startIndex = startIndex;
		this.nbResults = nbResults;
	}

	
    public int getTotalRecords() {
    	return totalRecords;
    }

	
    public void setTotalRecords(int totalRecords) {
    	this.totalRecords = totalRecords;
    }

	
    public List<ELEMENT> getElements() {
    	return elements;
    }

	
    public void setElements(List<ELEMENT> elements) {
    	this.elements = elements;
    }

	
    public Order getOrder() {
    	return order;
    }

	
    public void setOrder(Order order) {
    	if (order == null){
    		this.order = DEFAULT_ORDER;
    	}
    	else{
    		this.order = order;	
    	}
    }

	
    public String getField() {
    	return field;
    }

	
    public void setField(String field) {
    	if (field == null || field.length() == 0){
    		this.field = DEFAULT_FIELD;
    	}
    	else{
    		this.field = field;	
    	}
    }

	
    public int getStartIndex() {
    	return startIndex;
    }

	
    public void setStartIndex(int startIndex) {
    	if (startIndex < 0){
    		this.startIndex = 0;
    	}
    	else{
    		this.startIndex = startIndex;	
    	}
    }

	
    public int getNbResults() {
    	return nbResults;
    }

	
    public void setNbResults(int nbResults) {
    	if (nbResults <= 0){
    		this.nbResults = DEFAULT_NB_RESULTS;
    	}
    	else{
    		this.nbResults = nbResults;	
    	}
    }
}
