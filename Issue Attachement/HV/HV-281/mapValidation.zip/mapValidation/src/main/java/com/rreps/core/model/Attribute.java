package com.rreps.core.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Min;

import org.apache.commons.lang.builder.HashCodeBuilder;

@Entity
@Table(name = "attribute", uniqueConstraints = @UniqueConstraint(columnNames = {"type", "name"}))
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING)
public abstract class Attribute<ENTITY extends Annotable<?, ?>>
        extends BaseObject implements Serializable {

    private static final long serialVersionUID = -328834888742499071L;
    protected String name;
    private String displayName;
    private String description;
    private String dataType;
    private int ordering = 1;
    private boolean mandatory;
    private boolean multiple;
    private boolean annotation;

    @Column(nullable = false, columnDefinition = "BOOLEAN")
    public boolean isConstrained(){
    	return this instanceof ConstrainedAttribute<?>;
    }

    public void setConstrained(boolean constrained) {
    	// computed
    }

    @Override
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    @Column(length = 100, nullable = false, unique = true)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(length = 200, nullable = false)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "data_type", length = 30, nullable = false)
    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    @Column(length = 80, name = "display_name", nullable = false)
    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

	@Min(value = 1)
    @Column(name = "ordering", nullable = false, columnDefinition = "int(11) default 1")
    public int getOrdering() {
        return ordering;
    }

    public void setOrdering(int ordering) {
        this.ordering = ordering;
    }

    @Column(nullable = false, columnDefinition = "BOOLEAN")
    public boolean getMandatory() {
        return mandatory;
    }

    public void setMandatory(boolean mandatory) {
        this.mandatory = mandatory;
    }

    @Column(nullable = false, columnDefinition = "BOOLEAN")
    public boolean isAnnotation() {
        return annotation;
    }

    public void setAnnotation(boolean annotation) {
        this.annotation = annotation;
    }

    @Column(nullable = false, columnDefinition = "BOOLEAN")
    public boolean getMultiple() {
        return multiple;
    }

    public void setMultiple(boolean multiple) {
        this.multiple = multiple;
    }

    @Override
    public String toString() {
        return this.name;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(-939998163, 1509120713).append(this.name).toHashCode();
    }

}
