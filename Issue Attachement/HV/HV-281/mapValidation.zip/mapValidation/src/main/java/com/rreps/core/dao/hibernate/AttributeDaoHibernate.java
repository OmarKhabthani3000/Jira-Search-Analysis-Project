package com.rreps.core.dao.hibernate;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.rreps.core.dao.AttributeDao;
import com.rreps.core.model.Attribute;
import com.rreps.core.model.PatientAttribute;

@Repository
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
@SuppressWarnings("unchecked")
public class AttributeDaoHibernate extends
        GenericDaoHibernate<Attribute, Long> implements AttributeDao {

	public AttributeDaoHibernate() {
		super(Attribute.class);
	}

    @Override
    @Autowired
    public void setSessionFactory(@Qualifier("sessionFactory")SessionFactory sessionFactory) {
	    super.setSessionFactory(sessionFactory);
    }
    
	public List<Attribute> getAttributes() {
		return getAll();
	}

    public List<PatientAttribute> getPatientAttributes() {
		return (List<PatientAttribute>) getHibernateTemplate().find("from PatientAttribute");
    }
	
    public PatientAttribute getPatientAttribute(String name) {
		List<PatientAttribute> l = getHibernateTemplate().find("from PatientAttribute where name=?", name);
		if (l == null || l.isEmpty()) {
			throw new DataRetrievalFailureException("patient attribute with name:" + name + " not found...");
		}
		else {
			return l.get(0);
		}
    }

	public Attribute getAttribute(Long id) {
		return get(id);
	}

	@Transactional(readOnly = false)
	public void removeAttribute(Long id) {
		remove(id);
	}

	@Transactional(readOnly = false)
	public Attribute saveAttribute(Attribute a) {
		return save(a);
	}

	@Override
    public List<Attribute> getAll() {
	    return super.getAll();
    }	

}
