package com.rreps.core.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Transient;

@Entity
@DiscriminatorValue("PatientConstrained")
public class PatientAnnotationConstrainedValue extends AnnotationConstrainedValue<PatientConstrainedAttribute>
        implements Serializable {

	private static final long serialVersionUID = -4014083040684538741L;

	protected List<PatientConstrainedValue> constrainedValues = new ArrayList<PatientConstrainedValue>();

	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH })
	@JoinTable(name = "value_constrainedvalue", joinColumns = @JoinColumn(name = "value_id"), inverseJoinColumns = @JoinColumn(name = "constrainedvalue_id"))
	public List<PatientConstrainedValue> getConstrainedValues() {
		return constrainedValues;
	}

	@SuppressWarnings("unchecked")
    public void setConstrainedValues(List<? extends ConstrainedValue<PatientConstrainedAttribute>> l) {
		this.constrainedValues = (List<PatientConstrainedValue>) l;
	}

	@Override
	@Transient
	public String getStringValue() {
		return getConstrainedValues().toString().replaceAll("\\[", "").replaceAll("\\]", "");
	}

	public void addValue(PatientConstrainedValue v){
		constrainedValues.add(v);
	}
}
