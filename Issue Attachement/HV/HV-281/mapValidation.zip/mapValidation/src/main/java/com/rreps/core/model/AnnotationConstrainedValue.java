package com.rreps.core.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Transient;

@Entity
public abstract class AnnotationConstrainedValue<ATTRIBUTE extends Attribute<?>> extends AnnotationValue<ATTRIBUTE>
        implements ConstrainedAnnotationValue, Serializable {

	private static final long serialVersionUID = -998599545011142066L;

	@Transient
	public abstract void setConstrainedValues(List<? extends ConstrainedValue<ATTRIBUTE>> l);

	@Override
	public void setStringValue(String value) {
		// do nothing
	}

	@Override
	public void setFreeValue(String value) {
		// do nothing
	}

}
