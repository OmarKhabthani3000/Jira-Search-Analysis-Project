package com.rreps.core.model;

import java.io.Serializable;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("PatientConstrainedValue")
public class PatientConstrainedValue extends ConstrainedValue<PatientConstrainedAttribute> implements
        Serializable {

	private static final long serialVersionUID = -6716435150770334234L;

    public PatientConstrainedValue() {
    }

    public PatientConstrainedValue(final String value) {
        this.value = value;
    }

	public int compareTo(ConstrainedValue<PatientConstrainedAttribute> o) {
		if (this == o){
			return 0;
		}
		return getOrdering() - o.getOrdering();
	}
}
