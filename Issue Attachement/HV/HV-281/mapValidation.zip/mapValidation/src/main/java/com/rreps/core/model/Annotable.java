package com.rreps.core.model;

import java.util.Map;

public interface Annotable<ANNOTATION extends Annotation<?, ATTRIBUTE>, ATTRIBUTE extends Attribute<?>> {

	public String getReference();

	public void setReference(String reference);

	public Map<ATTRIBUTE, ANNOTATION> getAnnotations();

	public void setAnnotations(Map<ATTRIBUTE, ANNOTATION> m);

	public void addAnnotation(ANNOTATION annotation);

	public ANNOTATION getAnnotation(String name);

	public void removeAnnotation(String name);

}