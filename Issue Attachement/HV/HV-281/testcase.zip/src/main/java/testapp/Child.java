package testapp;

import javax.persistence.*;

/**
 * @author vladimirkl
 * @since <pre>$today</pre>
 */
@Entity
public class Child {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Parent parent;

    public Child() {
    }


    public void setParent(Parent parent) {
        this.parent = parent;
    }

    public Parent getParent() {
        return parent;
    }
}
