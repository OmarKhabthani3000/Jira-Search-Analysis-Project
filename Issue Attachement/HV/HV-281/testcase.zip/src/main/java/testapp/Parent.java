package testapp;

import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author vladimirkl
 * @since <pre>$today</pre>
 */
@Entity
public class Parent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "parent", cascade= CascadeType.ALL)
    @NotEmpty
    private List<Child> children;

    public Parent() {
    }

    public Parent(Child child) {
        child.setParent(this);
        this.children = new ArrayList<Child>(Arrays.asList(child));
    }

    public List<Child> getChildren() {
        return children;
    }
}
