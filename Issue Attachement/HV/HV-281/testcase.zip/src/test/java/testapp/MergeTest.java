package testapp;

import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author vladimirkl
 * @since <pre>$today</pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
@ContextConfiguration(locations = {"/app-context.xml"})
public class MergeTest {


    @Autowired
    private SessionFactory sessionFactory;

    @Test
    public void testMerge() {
        getSession().merge(new Parent(new Child()));
        getSession().flush();
    }

    @Test
    public void testSave() {
        getSession().save(new Parent(new Child()));
        getSession().flush();
    }

    private Session getSession() {
        return sessionFactory.getCurrentSession();
    }
}
