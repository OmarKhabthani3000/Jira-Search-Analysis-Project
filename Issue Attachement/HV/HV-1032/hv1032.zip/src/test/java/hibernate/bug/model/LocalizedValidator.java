
package hibernate.bug.model;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class LocalizedValidator implements ConstraintValidator<Localized, Localizable<?>> {
    
    @Override
    public void initialize(Localized constraintAnnotation) {

    }

    @Override
    public boolean isValid(Localizable<?> target, ConstraintValidatorContext context) {
        boolean isValid = target.getDefaultLanguage() != null && target.getLocalized().containsKey(target.getDefaultLanguage());

        if (!isValid) {
            String message = context.getDefaultConstraintMessageTemplate();

            if (message.isEmpty()) {
                message = new StringBuilder("No localization found for the set default language for the entity: ").append(target).toString();
            }

            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
        }

        return isValid;
    }
}
