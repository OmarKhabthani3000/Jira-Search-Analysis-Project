
package hibernate.bug.model;

import java.io.Serializable;
import java.util.Locale;
import java.util.Map;

public interface Localizable<V extends LocalizedEntity> extends Serializable {

    public Map<Locale, V> getLocalized();

    public Locale getDefaultLanguage();

    public void setDefaultLanguage(Locale defaultLanguage);
}