
package hibernate.bug.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.validation.constraints.NotNull;

@Localized
public class AbstractLocalizable<T extends Serializable, L extends LocalizedEntity> extends BaseEntity<T> implements Localizable<L> {

    private static final long serialVersionUID = 1L;

    private Locale defaultLanguage;
    private Map<Locale, L> localized = new HashMap<Locale, L>();

    public AbstractLocalizable() {
        super();
    }

    @NotNull
    public Locale getDefaultLanguage() {
        return defaultLanguage;
    }

    public void setDefaultLanguage(Locale defaultLanguage) {
        this.defaultLanguage = defaultLanguage;
    }

    public Map<Locale, L> getLocalized() {
        return localized;
    }

    public void setLocalized(Map<Locale, L> localized) {
        this.localized = localized;
    }
}