
package hibernate.bug;

import hibernate.bug.model.LocalizableEntity;
import hibernate.bug.model.LocalizedEntity;
import java.util.Locale;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import org.junit.Assert;
import org.junit.Test;

public class InfiniteLoopTest {
    
    @Test
    public void test() throws Exception {
        LocalizableEntity entity = new LocalizableEntity();
        entity.setDefaultLanguage(Locale.ENGLISH);
        entity.getLocalized().put(Locale.ENGLISH, new LocalizedEntity("name", "description"));
        Set<ConstraintViolation<LocalizableEntity>> set = Validation.buildDefaultValidatorFactory().getValidator().validate(entity);
        Assert.assertEquals(0, set.size());
    }
}
