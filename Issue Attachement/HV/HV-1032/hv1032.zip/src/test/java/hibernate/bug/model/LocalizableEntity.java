package hibernate.bug.model;

@Localized
public class LocalizableEntity extends AbstractLocalizable<Integer, LocalizedEntity> {

    public LocalizableEntity() {
    }

}
