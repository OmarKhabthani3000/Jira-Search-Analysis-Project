
package hibernate.bug.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class LocalizedEntity implements Serializable, Cloneable {

    private static final long serialVersionUID = -8539302606114365372L;

    private String name;
    private String description;

    public LocalizedEntity() {
        super();
    }

    public LocalizedEntity(String name, String description) {
        this.name = name;
        this.description = description;
    }

    @NotNull
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NotNull
    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
