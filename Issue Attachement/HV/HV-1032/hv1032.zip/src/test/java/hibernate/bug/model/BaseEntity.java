
package hibernate.bug.model;

import java.io.Serializable;

public abstract class BaseEntity<T extends Serializable> implements Serializable {

    private static final long serialVersionUID = 1L;

    protected T id;

    public BaseEntity() {
        super();
    }

    public BaseEntity(T id) {
        super();
        this.id = id;
    }

    public T getId() {
        return id;
    }

    public void setId(T id) {
        this.id = id;
    }
}
