package com.example;

import org.hibernate.validator.internal.util.TypeHelper;
import org.junit.Assert;
import org.junit.Test;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.lang.reflect.ParameterizedType;
import java.util.Set;

public class HibernateBugApplicationTests
{

   /**
    * Never completes using the Validator. AbstractMaturity has a custom class-level validator. The infinite loop does not occur if I use
    * field-level validators like @NotNull
    */
   @Test
   public void testHV870Validation()
   {
      ConcreteMaturity maturity = new ConcreteMaturity("good");

      ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
      Validator validator = factory.getValidator();

      Set<ConstraintViolation<Maturity>> violations = validator.validate(maturity);

      Assert.assertEquals(0, violations.size());
   }

   /**
    * Illustrates the issue in TypeHelper directly. Seems to be some issue with how the map of type parameters to type
    * arguments is constructed. ParameterizedType.getActualTypeArguments() is returning the exact same object as
    * Class.getTypeParameters(). Would have to do more digging to determine if this is a bug in java? Seems odd that
    * the type argument is coming back the same as type parameter. (See TypeHelper.getActualTypeArgumentsByParameterInternal())
    */
   @Test
   public void testHV870TypeHelper()
   {
      ConcreteMaturity maturity = new ConcreteMaturity("good");
      ParameterizedType superType = ((ParameterizedType)((Class) ((ParameterizedType) maturity.getClass().getGenericSuperclass()).getRawType()).getGenericInterfaces()[0]);
      ParameterizedType testType = TypeHelper.parameterizedType(GenericMaturity.class, GenericMaturity.class.getTypeParameters());
      boolean result = TypeHelper.isAssignable(superType, testType);

      Assert.assertTrue(result);
   }
}
