package com.example;

public class ConcreteMaturity extends GenericMaturity<GenericProduct>
{
   public ConcreteMaturity(String thing1)
   {
      super(thing1);
   }
}
