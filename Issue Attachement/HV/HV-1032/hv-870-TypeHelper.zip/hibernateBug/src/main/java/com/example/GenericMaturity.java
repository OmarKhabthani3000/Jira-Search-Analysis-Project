package com.example;

@CustomValidation
public class GenericMaturity<P extends Product> implements Maturity<P>
{
   private String thing1;

   public GenericMaturity(String thing1)
   {
      this.thing1 = thing1;
   }

   public String getThing1()
   {
      return thing1;
   }
}
