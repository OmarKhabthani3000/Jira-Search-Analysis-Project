package com.example;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CustomValidator implements ConstraintValidator<CustomValidation, Maturity<GenericProduct>>
{

   @Override
   public void initialize(CustomValidation validation)
   {
   }

   @Override
   public boolean isValid(Maturity<GenericProduct> value, ConstraintValidatorContext context)
   {
      if (value.getThing1().equals("good"))
      {
         return true;
      } else
      {
         return false;
      }
   }
}


