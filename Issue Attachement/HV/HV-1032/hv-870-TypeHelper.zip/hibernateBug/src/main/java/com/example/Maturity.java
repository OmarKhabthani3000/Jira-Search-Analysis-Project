package com.example;

public interface Maturity<P extends Product>
{
   String getThing1();
}
