package com.example;

public class GenericProduct implements Product
{
}
