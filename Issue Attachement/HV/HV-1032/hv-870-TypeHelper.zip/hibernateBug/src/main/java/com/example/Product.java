package com.example;

public interface Product
{
}
