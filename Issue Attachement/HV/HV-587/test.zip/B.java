import javax.persistence.ManyToOne;
import javax.validation.Valid;

public class B {

  @ManyToOne
  @Valid
  private A a;

  public A getA() {
    return a;
  }

  public void setA(A a) {
    this.a = a;
  }

}
