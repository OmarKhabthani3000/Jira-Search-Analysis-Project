import java.util.Set;

import javax.persistence.OneToMany;
import javax.validation.Valid;

public class A {

  @OneToMany
  @Valid
  private Set<B> b;

  public Set<B> getB() {
    return b;
  }

  public void setB(Set<B> b) {
    this.b = b;
  }

}
