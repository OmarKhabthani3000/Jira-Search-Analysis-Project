import java.util.HashSet;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

public class Setup {

  public static void main(String args[]) throws Exception {
    A a = new A();
    B b = new B();
    Set<B> bs = new HashSet<B>();
    bs.add(b);
    a.setB(bs);
    b.setA(a);

    ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
    Validator validator = factory.getValidator();

    Set<ConstraintViolation<A>> violations = validator.validate(a);

  }
}
