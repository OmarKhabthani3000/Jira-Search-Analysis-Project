/****************************************************************************\
 File: ValidationModule.java
 Date: 01.10.12
 Author: Alexey Krylov

 Copyright (c) 2012 i-free
 ****************************************************************************/

package validation;

import com.google.inject.AbstractModule;

/**
 * ValidationModule -
 *
 * @author lexx
 */
public class ValidationModule extends AbstractModule {

    /*===========================================[ CLASS METHODS ]==============*/

    @Override
    protected void configure() {
        bind(SimpleService.class).to(SimpleServiceImpl.class);
    }
}
