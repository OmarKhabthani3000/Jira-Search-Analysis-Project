/****************************************************************************\
 File: Checked.java
 Date: 01.10.12
 Author: Alexey Krylov

 Copyright (c) 2012 i-free
 ****************************************************************************/

package validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Checked -
 *
 * @author lexx
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Checked {
}
