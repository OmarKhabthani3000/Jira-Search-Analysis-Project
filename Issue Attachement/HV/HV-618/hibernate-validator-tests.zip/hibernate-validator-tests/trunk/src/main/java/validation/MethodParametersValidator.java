/****************************************************************************\
 File: MethodParametersValidator.java
 Date: 01.10.12
 Author: Alexey Krylov

 Copyright (c) 2012 i-free
 ****************************************************************************/

package validation;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.lang.reflect.Method;
import java.util.Set;

/**
 * MethodParametersValidator -
 *
 * @author lexx
 */
public class MethodParametersValidator implements MethodInterceptor {

    /*===========================================[ INSTANCE VARIABLES ]=========*/

    private Validator validator;

    public MethodParametersValidator() {
        validator = Validation.buildDefaultValidatorFactory().getValidator();
    }

    /*===========================================[ CLASS METHODS ]==============*/

    public Object invoke(MethodInvocation invocation) throws Throwable {
        Object object = invocation.getThis();

        checkWithValidator5(invocation, object);
        //checkWithValidator4(invocation, object);

        return invocation.proceed();
    }

  private void checkWithValidator5(MethodInvocation invocation, Object object) {
        Method method = invocation.getMethod();
        Set<ConstraintViolation<Object>> violations = validator.validateParameters(object, method, invocation.getArguments());
        if (!violations.isEmpty()) {
            System.out.println(String.format("%s: Found %d violation(s)", method.getName(), violations.size()));
            StringBuilder sb = new StringBuilder();
            //validator.validateAllParameters(object, invocation.getMethod(), invocation.getArguments());
            for (ConstraintViolation<Object> violation : violations) {
                sb.append(System.getProperty("line.separator"));
                sb.append("[").append(violation.getPropertyPath().toString()).append("] ").append(violation.getMessage());
            }

            throw new IllegalArgumentException(sb.toString());
        } else {
            System.out.println(String.format("%s: No violations found", method.getName()));
        }
    }

/*
    private void checkWithValidator4(MethodInvocation invocation, Object object) {
        Method method = invocation.getMethod();
        Set<MethodConstraintViolation<Object>> violations = validator.unwrap(MethodValidator.class).validateAllParameters(object, method, invocation.getArguments());
        if (!violations.isEmpty()) {
            System.out.println(String.format("%s: Found %d violation(s)", method.getName(), violations.size()));
            StringBuilder sb = new StringBuilder();
            //validator.validateAllParameters(object, invocation.getMethod(), invocation.getArguments());
            for (ConstraintViolation<Object> violation : violations) {
                sb.append(System.getProperty("line.separator"));
                sb.append("[").append(violation.getPropertyPath().toString()).append("] ").append(violation.getMessage());
            }

            throw new IllegalArgumentException(sb.toString());
        } else {
            System.out.println(String.format("%s: No violations found", method.getName()));
        }
    }
*/
}
