/****************************************************************************\
 __FILE..........: ValidateSample.java
 __AUTHOR........: Alexey Krylov
 __COPYRIGHT.....: Copyright (c) 2012 i-free
 _________________All rights reserved.
 __DESCRIPTION...:
 _____________________________________________________________________________
 ________________:27.09.12 Alexey Krylov AKA LexX: created.
 ****************************************************************************/


package validation;

import com.google.inject.Guice;
import com.google.inject.Injector;
import junit.framework.Assert;
import org.junit.Test;


public class ValidationTest {

    /*===========================================[ CLASS METHODS ]==============*/

    @Test
    public void testValidation() throws Exception {
        Injector injector = Guice.createInjector(new ValidationModule(), new AOPModule());
        SimpleService instance = injector.getInstance(SimpleService.class);
        try {
            instance.configure(null);
        } catch (IllegalArgumentException e) {
            // all ok - this is an exception from MethodParametersValidator
            System.out.println("Exception from MethodParametersValidator successfully received: " + e.getMessage());
        } catch (IllegalStateException e) {
            Assert.fail("Exception from SimpleServiceImpl received instead of exception from MethodParametersValidator");
        }
    }
}
