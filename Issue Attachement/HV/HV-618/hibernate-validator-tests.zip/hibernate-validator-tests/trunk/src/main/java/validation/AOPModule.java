/****************************************************************************\
 File: AOPModule.java
 Date: 01.10.12
 Author: Alexey Krylov

 Copyright (c) 2012 i-free
 ****************************************************************************/

package validation;

import com.google.inject.AbstractModule;
import com.google.inject.matcher.Matchers;

/**
 * AOPModule -
 *
 * @author lexx
 */
public class AOPModule extends AbstractModule {

    /*===========================================[ CLASS METHODS ]==============*/

    @Override
    protected void configure() {
        bindInterceptor(Matchers.any(), Matchers.annotatedWith(Checked.class), new MethodParametersValidator());
    }
}