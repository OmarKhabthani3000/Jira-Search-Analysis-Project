/****************************************************************************\
 File: SimpleIntImpl.java
 Date: 01.10.12
 Author: Alexey Krylov

 ****************************************************************************/

package validation;

/**
 * SimpleIntImpl -
 *
 * @author lexx
 */
public abstract class AbstractSimpleService<C> implements SimpleService<C> {

    /*===========================================[ CLASS METHODS ]==============*/

    public void configure(C config) {
        if (config == null) {
            throw new IllegalStateException("Config cannot be null!");
        }

        System.out.println("Abstract config: " + config);
    }
}

