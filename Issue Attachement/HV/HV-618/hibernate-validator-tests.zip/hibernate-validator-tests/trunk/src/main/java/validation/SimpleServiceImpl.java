/****************************************************************************\
 File: SimpleIntImpl.java
 Date: 01.10.12
 Author: Alexey Krylov

 Copyright (c) 2012 i-free
 ****************************************************************************/

package validation;

/**
 * SimpleIntImpl -
 *
 * @author lexx
 */
public class SimpleServiceImpl extends AbstractSimpleService<String> {

    /*===========================================[ CLASS METHODS ]==============*/

    @Override
    @Checked
    public void configure(String config) {
        super.configure(config);
        System.out.println("SimpleServiceImpl config: " + config);
    }
}
