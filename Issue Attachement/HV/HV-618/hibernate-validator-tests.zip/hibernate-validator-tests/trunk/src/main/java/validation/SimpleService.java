/****************************************************************************\
 File: SimpleInt.java
 Date: 01.10.12
 Author: Alexey Krylov

 Copyright (c) 2012 i-free
 ****************************************************************************/

package validation;

import javax.validation.constraints.NotNull;

/**
 * SimpleInt -
 *
 * @author lexx
 */
public interface SimpleService<C> {

    /*===========================================[ INTERFACE METHODS ]==============*/

    void configure(@NotNull C config);
}
