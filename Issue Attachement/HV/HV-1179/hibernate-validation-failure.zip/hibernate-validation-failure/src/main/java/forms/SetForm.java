package forms;

import annotations.NotBlankTypeUse;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Set;

public class SetForm {
    @NotNull
    @Valid
    public Set<@NotBlankTypeUse String> data;

    public SetForm(Set<String> data) {
        this.data = data;
    }
}
