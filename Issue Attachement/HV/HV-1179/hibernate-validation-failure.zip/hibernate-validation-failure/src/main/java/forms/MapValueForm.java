package forms;

import annotations.NotBlankTypeUse;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Map;

public class MapValueForm {
    @NotNull
    @Valid
    public Map<String, @NotBlankTypeUse String> data;

    public MapValueForm(Map<String, String> data) {
        this.data = data;
    }
}
