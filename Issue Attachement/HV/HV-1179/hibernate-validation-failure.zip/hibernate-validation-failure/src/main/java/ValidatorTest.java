import forms.*;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;
import javax.validation.executable.ExecutableValidator;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ValidatorTest {

    public static void main(String[] args) {
        new ValidatorTest().run();
    }

    private void run() {
        final Map<String, String> validMap = Collections.singletonMap("valid", "valid");
        final Map<String, String> invalidMap = Collections.singletonMap("", "");
        final List<String> validList = Collections.singletonList("valid");
        final List<String> invalidList = Collections.singletonList("");
        final Set<String> validSet = Collections.singleton("valid");
        final Set<String> invalidSet = Collections.singleton("");

        validate(TestService.class, "methodForMapValue", new MapValueForm(validMap));
        validate(TestService.class, "methodForMapKey", new MapKeyForm(validMap));
        validate(TestService.class, "methodForList", new ListForm(validList));
        validate(TestService.class, "methodForSet", new SetForm(validSet));

        validate(TestService.class, "methodForMapValue", new MapValueForm(invalidMap));
        validate(TestService.class, "methodForMapKey", new MapKeyForm(invalidMap));
        validate(TestService.class, "methodForList", new ListForm(invalidList));
        validate(TestService.class, "methodForSet", new SetForm(invalidSet));

        validate(TestService.class, "methodForNotNullMapValue", new NotNullMapValueForm(validMap));
        validate(TestService.class, "methodForNotNullMapKey", new NotNullMapKeyForm(validMap));
        validate(TestService.class, "methodForNotNullList", new NotNullListForm(validList));

        validate(TestService.class, "methodForNotNullMapValue", new NotNullMapValueForm(invalidMap));
        validate(TestService.class, "methodForNotNullMapKey", new NotNullMapKeyForm(invalidMap));
        validate(TestService.class, "methodForNotNullList", new NotNullListForm(invalidList));
    }

    private void validate(Class<?> serviceClass, String name, Object... params) {
        try {
            System.out.println("Method: " + name);
            validateUnsafe(serviceClass, name, params);
            System.out.println("   Validated successful!");
        } catch (IllegalArgumentException ignore) {
            System.out.println("-- Params violate validation constraints!");
        } catch (Exception e) {
            System.out.println("!! Validation fails with internal exception: " + e.getMessage());
        }
    }

    private void validateUnsafe(Class<?> serviceClass, String name, Object... params) throws Exception {
        Object service = serviceClass.newInstance();
        ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
        ExecutableValidator validator = validatorFactory.getValidator().forExecutables();

        Class<?>[] paramTypes = new Class[params.length];
        for (int i = 0; i < params.length; i++) {
            assert params[i] != null;
            paramTypes[i] = params[i].getClass();
        }
        Method method = serviceClass.getMethod(name, paramTypes);
        Set<ConstraintViolation<Object>> violations = validator.validateParameters(service, method, params);
        if (!violations.isEmpty()) {
            throw new IllegalArgumentException(violations.toString());
        }
    }

}
