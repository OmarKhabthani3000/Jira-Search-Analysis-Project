package forms;

import annotations.NotBlankTypeUse;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

public class ListForm {
    @NotNull
    @Valid
    public List<@NotBlankTypeUse String> data;

    public ListForm(List<String> data) {
        this.data = data;
    }
}
