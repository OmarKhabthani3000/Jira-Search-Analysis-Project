package forms;

import annotations.NotBlankTypeUse;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Map;

public class NotNullMapKeyForm {
    @NotNull
    @Valid
    public Map<@NotBlankTypeUse String, String> data;

    public NotNullMapKeyForm(Map<String, String> data) {
        this.data = data;
    }
}
