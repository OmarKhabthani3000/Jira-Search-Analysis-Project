package org.hibernate.validation.bugscenario;


public class OrderLine {
	
}
