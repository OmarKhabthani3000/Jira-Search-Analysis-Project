package org.hibernate.validation.bugscenario;

import java.util.Date;
import java.util.List;

public class Order {

	private Date orderDate;
	
	private List<OrderLine> orderLines;

}