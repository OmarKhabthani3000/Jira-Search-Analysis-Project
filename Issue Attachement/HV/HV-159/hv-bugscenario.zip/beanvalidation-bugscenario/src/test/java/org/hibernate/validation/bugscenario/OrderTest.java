package org.hibernate.validation.bugscenario;

import javax.validation.Validation;

import org.junit.Test;

public class OrderTest {
    
    @Test
    public void validOrder() {

   		Validation.buildDefaultValidatorFactory();
    }

}