package com.base.store.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.base.store.Activity;
import com.base.store.repository.ActivityRepository;
import com.base.store.service.ActivityService;

@Service("activityService")
@Repository
@Transactional
public class ActivityServiceImpl implements ActivityService {

	@Autowired
	ActivityRepository repo;
	
	@Override
	public Activity findById(Long id) {
		return repo.findById(id);
	}

	@Override
	public Activity save(Activity save) {
		return repo.save(save);
	}

	@Override
	public void delete(Activity del) {
		//Activity merge = repo.save(del);
		repo.delete(del);
	}

}
