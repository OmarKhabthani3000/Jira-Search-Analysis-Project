package com.base.store;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;


@Entity
@Table(name="activity")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name="type", discriminatorType=DiscriminatorType.INTEGER)
public abstract class Activity implements Serializable{

	private static final long serialVersionUID = 2029045183726484673L;


	@Id 
	@GeneratedValue(strategy=IDENTITY)
	@Column(name="id")
	protected Long id;
	

	@ManyToOne
	@JoinColumn(name="account_id")
	protected Account account;
	
	
	
	@Column(name="type")
	protected String type;
	
	@Version
	@Column(name="version")
	protected long version;	
	
	//Accessors
	
	public Long getId() {
		return id;
	}



	public void setId(Long activityId) {
		this.id = activityId;
	}



	public Account getAccount() {
		return account;
	}



	public void setAccount(Account account) {
		this.account = account;
	}

	public long getVersion() {
		return version;
	}



	public void setVersion(long version) {
		this.version = version;
	}

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

}

