package com.base.store;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="account")
public class Account implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	
	
	@Id @GeneratedValue(strategy=IDENTITY)
	@Column(name="id")
	private Long id;

	@Column(name="name")
	private String name;
	@Column(name="email_address")
	private String emailAddress;
	@Version
	@Column(name="version")
	private int version;		
	
	@OneToMany(targetEntity=Activity.class, 
			mappedBy="account",
			fetch=FetchType.EAGER,
			cascade={CascadeType.ALL},
			orphanRemoval=true)
	
	 private  List<Activity> accountActicity = new ArrayList<Activity>();
	
	//holds reference to other account(s) 'visited'
	@OneToMany(targetEntity=ActivityAccount.class, 
				mappedBy="activity",
				fetch=FetchType.LAZY, 
				cascade={CascadeType.REMOVE,CascadeType.REFRESH},
			orphanRemoval=true)
	@NotEmpty
	private List<ActivityAccount> activity = new ArrayList<ActivityAccount>();
	
	public void addActivty(ActivityAccount activity){
		activity.setAccount(this);
		getActivity().add(activity);
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	
	
	public List<Activity> getAccountActicity() {
		return accountActicity;
	}

	public void setAccountActicity(List<Activity> accountActicity) {
		this.accountActicity = accountActicity;
	}

	public List<ActivityAccount> getActivity() {
		return activity;
	}

	public void setActivity(List<ActivityAccount> activity) {
		this.activity = activity;
	}

	@Override
	public String toString(){
		return "Id: "+id+", Email Address:"+emailAddress+", Name: "+name;
	}
	
}
