package com.base.store.repository;

import org.springframework.data.repository.CrudRepository;

import com.base.store.Account;

public interface AccountRepository extends CrudRepository<Account, Long>{
	public Account findByEmailAddress(String emailAddress);
	public Account findById(Long accountId);

}
