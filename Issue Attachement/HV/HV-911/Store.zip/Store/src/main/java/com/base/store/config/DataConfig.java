package com.base.store.config;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.springframework.context.annotation.AdviceMode;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@ComponentScan(basePackages = {"com.base.store.service"})
@EnableJpaRepositories(value={"com.base.store.repository"}, entityManagerFactoryRef="entityManagerFactory", transactionManagerRef="transactionManager")
public class DataConfig {
	
	@Bean
	public EmbeddedDatabase dataSource() {
		EmbeddedDatabaseBuilder builder = new EmbeddedDatabaseBuilder();
		builder.addDefaultScripts()
		.addScript("classpath:schema.sql")
		.addScript("classpath:data.sql");
		return builder.setType(EmbeddedDatabaseType.H2).build(); 
		}	
	
	@Bean
	public PlatformTransactionManager transactionManager() { 
		JpaTransactionManager txManager = new JpaTransactionManager(); 
		txManager.setEntityManagerFactory(entityManagerFactory().getObject());
		return txManager; 
	}
	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {		
		LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
		factory.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
		factory.setPackagesToScan("com.base.store");
		factory.setJpaPropertyMap(jpaProperties());
		factory.setDataSource(dataSource());
		return factory; 
	}
	public static Map<String, String> jpaProperties(){
		Map<String, String> jpaProperties = new HashMap<String,String>();
		jpaProperties.put("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
		jpaProperties.put("hibernate.max_fetch_depth", "3");
		jpaProperties.put("hibernate.jdbc.fetch_size", "50");
		jpaProperties.put("hibernate.jdbc.batch_size", "10");
		jpaProperties.put("hibernate.show_sql", "true");
		jpaProperties.put("jadira.usertype.databaseZone","UTC");
		jpaProperties.put("jadira.usertype.javaZone", "UTC");
		jpaProperties.put("jadira.usertype.autoRegisterUserTypes", "true");
		return jpaProperties;
	}	
	
}