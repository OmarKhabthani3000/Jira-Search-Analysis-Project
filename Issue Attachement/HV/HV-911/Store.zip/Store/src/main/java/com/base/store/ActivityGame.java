package com.base.store;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="activity_game")
@DiscriminatorValue("2")
public final class ActivityGame extends Activity{
	private static final long serialVersionUID = -8238326960173310575L;

	@ManyToOne
	@JoinColumn(name="game_id")
	private Game game;
	
	private ActivityGame(){

	}
	
	private ActivityGame(Account account, Game game){
		setAccount(account);
		setGame(game);
		this.type = "game";
	}
	
	public static ActivityGame newActivityGameInstance(Account account, Game game){
		return new ActivityGame(account,game);
	}

	public Game getGame() {
		return game;
	}

	public void setGame(Game game) {
		this.game = game;
	}
	
	


}
