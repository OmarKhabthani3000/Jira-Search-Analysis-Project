package com.base.store;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="game")
public class Game {
	@Id
	@GeneratedValue(strategy=IDENTITY)
	@Column(name="id")
	private Long id;
	@Column(name="name",unique=true)
	private String name;	

	@Column(name="version")
	private int version;
	@OneToMany(targetEntity=ActivityGame.class, 
			mappedBy="game",
			fetch=FetchType.EAGER, 
			cascade={CascadeType.ALL},
			orphanRemoval=true)
	private Set<ActivityGame> activities;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public Set<ActivityGame> getActivities() {
		return activities;
	}
	public void setActivities(Set<ActivityGame> activities) {
		this.activities = activities;
	}
	
	
	
}
