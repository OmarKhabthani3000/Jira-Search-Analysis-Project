package com.base.store.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.base.store.Account;
import com.base.store.repository.AccountRepository;
import com.base.store.service.AccountService;
@Service("accountService")
@Repository
@Transactional
public class AccountServiceImpl implements AccountService{

	
	@Autowired 
	private AccountRepository repo;

	

	@Override
	@Transactional(readOnly=true)
	public Account findByAccountId(Long accountId) {
		Account account = repo.findById(accountId);
		return account;
	}

	@Override
	@Transactional(readOnly=true)
	public Account findByEmailAddress(String emailAddress)  {
		Account account = repo.findByEmailAddress(emailAddress);
		return account;
	}

	@Override
	@Transactional(readOnly=false)
	public Account save(Account account) {	
		Account saved = repo.save(account);
		return saved;
	}

	@Override
	public void deleteAll() {
		repo.deleteAll();		
	}

	@Override
	public void delete(Account account) {
		repo.delete(account);
		
	}



}