package com.base.store.service;

import com.base.store.Account;
public interface AccountService {	
	public Account findByEmailAddress(String emailAddress);
	public Account findByAccountId(Long accountId);
	public Account save(Account account);	
	public void deleteAll();
	public void delete(Account account);

	
	

}
