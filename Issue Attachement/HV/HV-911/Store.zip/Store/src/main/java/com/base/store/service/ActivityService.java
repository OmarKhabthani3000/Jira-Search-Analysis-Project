package com.base.store.service;

import com.base.store.Activity;

public interface ActivityService {
	public Activity findById(Long id);
	public Activity save(Activity save);
	public void delete(Activity del);

}
