package com.base.store;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.joda.time.DateTime;

@Entity
@Table(name="activity_account")
@DiscriminatorValue("1")
public final class ActivityAccount extends Activity{
	private static final long serialVersionUID = 1200376142843376595L;	
	@ManyToOne
	@JoinColumn(name="activity_id")
	private Account activity;
	
		
	public ActivityAccount(){}
	
	public ActivityAccount(Account activity){
		this.activity = activity;
	}
	public Account getActivity() {
		return activity;
	}

	
	
	public void setActivity(Account activity) {
		this.activity = activity;
	}

	@Override
	public String toString(){
		 StringBuilder sb = new StringBuilder();
	        sb.append("Id: ").append(getId()).append(", ");
	        sb.append("Version: ").append(getVersion()).append(", ");
	        sb.append("Account: ").append(getAccount()).append(", ");
	        return sb.toString();
	}

}
