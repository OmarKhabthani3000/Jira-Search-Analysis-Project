package com.base.store.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ComponentScan(basePackages = {"com.base.store"})
@Import(value={DataConfig.class})
public class AppConfig{
	 
	 
}
