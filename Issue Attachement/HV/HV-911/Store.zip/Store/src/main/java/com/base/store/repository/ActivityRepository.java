package com.base.store.repository;

import org.springframework.data.repository.CrudRepository;

import com.base.store.Activity;

public interface ActivityRepository extends CrudRepository<Activity, Long>{
	public Activity findById(Long id);


}
