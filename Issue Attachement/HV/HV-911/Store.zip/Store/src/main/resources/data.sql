INSERT INTO account(id,name, email_address, version) 
VALUES (DEFAULT,'Foo Boo', 'foo.boo@outlook.com','0');

INSERT INTO account(id,name, email_address, version)
VALUES (DEFAULT,'Boo Hoo', 'boo.hoo@outlook.com','0');

INSERT INTO account(id,name, email_address, version)
VALUES (DEFAULT,'Zoo', 'zoo@outlook.com','0');

INSERT INTO activity(id, account_id, type, version)
VALUES (DEFAULT, '1', 'account', '0');
INSERT INTO activity_account(id, activity_id)
VALUES (DEFAULT, '3');

