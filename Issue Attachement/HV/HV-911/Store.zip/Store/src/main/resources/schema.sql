
DROP TABLE account if exists;
DROP TABLE game if exists;
DROP TABLE activity if exists;
DROP TABLE activity_game if exists;
DROP TABLE activity_account if exists;
CREATE TABLE account(
	id int(10) UNSIGNED NOT NULL auto_increment,
	name varchar(70) NOT NULL,
	email_address varchar(254) NOT NULL,
	version int(10) UNSIGNED NULL,
	CONSTRAINT pkey_account_id PRIMARY KEY(id),
	UNIQUE unique_account_email (email_address),
);

CREATE TABLE game(
	id int(10) UNSIGNED NOT NULL auto_increment,
	name varchar(50) NOT NULL,
	version int(10) UNSIGNED NULL,
	CONSTRAINT pkey_game_id PRIMARY KEY (id)
	);
	
CREATE TABLE activity(
	id int(10) UNSIGNED NOT NULL auto_increment,
	account_id int(10) UNSIGNED NOT NULL,
	type varchar(50) NOT NULL,
	version int(10) UNSIGNED NULL,
	CONSTRAINT pkey_activty_id PRIMARY KEY (id),
	CONSTRAINT fkey_account_activity FOREIGN KEY(account_id) REFERENCES account(id)	
);

CREATE TABLE activity_game(
	id int(10) UNSIGNED NOT NULL auto_increment,
	game_id int(10) UNSIGNED NOT NULL,
	CONSTRAINT fkey_activity_type_game FOREIGN KEY(id) REFERENCES activity(id),
	CONSTRAINT fkey_activity_game FOREIGN KEY(game_id) REFERENCES game(id)
);

CREATE TABLE activity_account(
	id int(10) UNSIGNED NOT NULL auto_increment,
	activity_id int(10) UNSIGNED NOT NULL,
	CONSTRAINT fkey_activity_type_account FOREIGN KEY(id) REFERENCES activity(id),
	CONSTRAINT fkey_activity_account FOREIGN KEY(activity_id) REFERENCES account(id)
);