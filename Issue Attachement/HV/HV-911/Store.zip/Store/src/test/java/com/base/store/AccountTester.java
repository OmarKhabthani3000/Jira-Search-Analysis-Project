package com.base.store;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.base.store.config.DataConfig;
import com.base.store.service.AccountService;
import com.base.store.service.ActivityService;
/**
 * 
 * pre-populated fields via script data.sql (see /src/main/resource folder
 *
 */
public class AccountTester {
	private static Logger logger = Logger.getLogger(AccountTester.class);
	public static void main(String[] args) {
	AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(DataConfig.class);
	AccountService service = ctx.getBean(AccountService.class);
	ActivityService actService = ctx.getBean(ActivityService.class); 

	//logger.info(saved);

	
	Account foo = service.findByEmailAddress("foo.boo@outlook.com");
	assertEquals("Foo Boo", foo.getName());
	
	Account boo = service.findByEmailAddress("boo.hoo@outlook.com");
	assertEquals("Boo Hoo", boo.getName());
	 
	service.delete(boo);//<-- Account Delete Works, following assert passes
	assertNull(service.findByEmailAddress("boo.hoo@outlook.com"));
	
	Account zoo = service.findByEmailAddress("zoo@outlook.com");
	assertEquals("Zoo", zoo.getName());
	
	Account save = new Account();
	save.setName("Batman");
	save.setEmailAddress("batman@gmail.com");
	
	save.addActivty(new ActivityAccount(foo));
	
	service.save(save);
	
	
	}
}
