package com.acme;


public interface Person {

    String getFirstName();

    String getMiddleName();

    String getLastName();
}