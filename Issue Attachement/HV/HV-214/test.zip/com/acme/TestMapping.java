package com.acme;

import static org.junit.Assert.assertEquals;

import java.util.Set;

import javax.validation.Configuration;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.groups.Default;

import org.junit.Test;

public class TestMapping {

    @Test
    public void testMe() {

	final Configuration<?> configuration = Validation.byDefaultProvider()
		.configure();
	configuration.addMapping(TestMapping.class
		.getResourceAsStream("mapping.xml"));
	final ValidatorFactory validatorFactory = configuration
		.buildValidatorFactory();
	final Validator validator = validatorFactory.getValidator();

	final Set<ConstraintViolation<Customer>> violations = validator
		.validate(new Customer(), Default.class);

	for (final ConstraintViolation<Customer> violation : violations) {
	    System.err.println(violation.getPropertyPath() + " "
		    + violation.getMessage());
	}

	assertEquals(2, violations.size());

    }
}
