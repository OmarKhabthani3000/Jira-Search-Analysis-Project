package test.validation.email;


import org.hibernate.validator.internal.constraintvalidators.EmailValidator;
import org.junit.Assert;
import org.junit.Test;

public class SMTPLimitsTest {

    private static final String local_valid = "1234567890123456789012345678901234567890123456789012345678901234";
    private static final String local_invalid = local_valid + "5";

    private static final String domain_valid = "example.com";

    public EmailValidator getValidator() {
        return new EmailValidator();
    }

    public CharSequence createAddress(String localPart, String domainPart) {
        return localPart + "@" + domainPart;
    }

    @Test
    public void testValidLocalPartAddress() {
        Assert.assertTrue(getValidator().isValid(createAddress(local_valid, domain_valid), null));
    }

    @Test
    public void testInvalidLocalPartAddress() {
        Assert.assertFalse(getValidator().isValid(createAddress(local_invalid, domain_valid), null));
    }
}
