package org.hibernate.validator.bugs;

import java.lang.reflect.Method;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.hibernate.validator.testutil.TestForIssue;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestCase
{
    private static ConcreteEntityWebService ws;
    private static Method method;
    private static Object[] params;

    @BeforeClass
    public static void setUp()
    throws NoSuchMethodException
    {
        ws = new ConcreteEntityWebService();
        method = ConcreteEntityWebService.class.getMethod(
            "getEntityVersion", Long.class);
        params = new Object[] {null};
    }

    @Test
    @TestForIssue(jiraKey = "HV-1450")
    public void testHV1450()
    {
        int passed = 0;
        int failed = 0;

        for (int i = 0; i < 100; i++)
        {
            ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
            Validator validator = factory.getValidator();

            Set<ConstraintViolation<ConcreteEntityWebService>> cvs =
                validator.forExecutables().validateParameters(
                    ws, method, params);

            if (cvs.isEmpty())
            {
                passed++;
            }
            else
            {
                failed++;
            }
        }

        Assert.assertTrue("Passed: " + passed + ", failed: " + failed,
            failed == 0);
    }
}
