package org.hibernate.validator.bugs;

public interface IConcreteEntityWebService
extends IEntityVersionWebService
{
    @Override
    // @javax.annotation.security.RolesAllowed(...)
    int getEntityVersion(
        Long id);
}
