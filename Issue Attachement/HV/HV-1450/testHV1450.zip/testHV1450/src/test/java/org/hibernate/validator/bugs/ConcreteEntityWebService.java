package org.hibernate.validator.bugs;

public class ConcreteEntityWebService
extends  EntityWebService
implements IConcreteEntityWebService
{
    public ConcreteEntityWebService()
    {
    }
}
