package org.hibernate.validator.bugs;

import javax.validation.constraints.NotNull;

public interface IEntityVersionWebService
{
    int getEntityVersion(
        @NotNull Long id);
}
