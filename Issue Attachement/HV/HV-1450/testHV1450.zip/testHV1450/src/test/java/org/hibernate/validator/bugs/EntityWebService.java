package org.hibernate.validator.bugs;

public abstract class EntityWebService
implements IEntityVersionWebService
{
    public EntityWebService()
    {
    }

    @Override
    public int getEntityVersion(
        Long id)
    {
        return id.intValue();
    }
}
