import static junit.framework.Assert.assertTrue;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import org.junit.Test;

public class ValidationTest {
	private static Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

	@Test
	public void testWithBooks() {
		Author author = new Author();
		author.books.add(new Book());

		// This causes an exception. The root cause is:
		//
		// javax.persistence.PersistenceException: Unable to find field or method: class Book#books
		// at org.hibernate.ejb.util.PersistenceUtilHelper.get(PersistenceUtilHelper.java:95)
		// at org.hibernate.ejb.util.PersistenceUtilHelper.isLoadedWithReference(PersistenceUtilHelper.java:76)
		// at org.hibernate.ejb.HibernatePersistence$1.isLoadedWithReference(HibernatePersistence.java:92)
		// at javax.persistence.Persistence$1.isLoaded(Persistence.java:83)
		// at org.hibernate.validator.engine.resolver.JPATraversableResolver.isReachable(JPATraversableResolver.java:33)
		// at org.hibernate.validator.engine.resolver.DefaultTraversableResolver.isReachable(DefaultTraversableResolver.java:112)
		// at org.hibernate.validator.engine.resolver.SingleThreadCachedTraversableResolver.isReachable(SingleThreadCachedTraversableResolver.java:47)
		// at org.hibernate.validator.engine.ValidatorImpl.isValidationRequired(ValidatorImpl.java:764)
		// ... 29 more

		Set<ConstraintViolation<Author>> results = validator.validate(author);
		assertTrue(results.isEmpty());
	}

	@Test
	public void testWithoutBooks() {
		Author author = new Author();

		// If the "books" collection is empty, everything works as expected.

		Set<ConstraintViolation<Author>> results = validator.validate(author);
		assertTrue(results.isEmpty());
	}
}
