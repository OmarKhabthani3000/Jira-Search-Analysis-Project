import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.Valid;

@AuthorBusinessRules
@Entity
public class Author {
	@Id
	public Long id;

	@Valid
	@OneToMany(mappedBy = "author")
	public List<Book> books = new ArrayList<Book>();
}
