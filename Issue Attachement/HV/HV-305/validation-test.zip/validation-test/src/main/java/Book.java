import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@BookBusinessRules
@Entity
public class Book {
	@Id
	public Long id;

	@ManyToOne
	public Author author;
}
