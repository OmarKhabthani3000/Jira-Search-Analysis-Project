package fr.test.hibernate;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import fr.test.hibernate.bo.A;
import fr.test.hibernate.bo.B;
import fr.test.hibernate.bo.BusinessObject;

public class MainAB {

	public static void main(String[] args) {
		ExportSchema.main(null);

		System.err.println("<!-- Save Begin -->");
		for (int i = 0; i < 10; i++) {
			A a = new A("a" + i);
			B b = new B("b" + i);
			B bprime = new B("b" + (i + 100));
			a.getB().add(b);
			a.getB().add(bprime);
			b.setA(a);
			bprime.setA(a);

			save(a);
		}
		System.err.println("<!-- Save End -->");

		deleteFromB();
	}

	public static void save(BusinessObject boToSave) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			if (boToSave != null) {
				session.saveOrUpdate(boToSave);
			}
			session.flush();
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			throw e;
		} finally {
			session.close();
		}
	}

	@SuppressWarnings({ "finally", "unchecked" })
	public static void deleteFromA() {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Criteria crit = session.createCriteria(A.class);
			List<A> objectsA = crit.list();

			Set<B> objectsB = new HashSet<B>();
			Set<B> objectsBToDelete = new HashSet<B>();

			for (A a : objectsA) {
				for (B b : a.getB()) {
					objectsB.add(b);
				}
			}

			for (B b : objectsB) {
				// we do not detach and delete each "b" to be able to validate the @Required mapping on a.getB()
				if (b.getA().getB().size() > 1) {
					b.detach();
					objectsBToDelete.add(b);
				}
			}
			session.flush();

			// delete B 
			for (B b : objectsBToDelete) {
				session.delete(b);
			}
			session.flush();

			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			throw e;
		} finally {
			session.close();
		}
	}

	@SuppressWarnings({ "finally", "unchecked" })
	public static void deleteFromB() {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Criteria crit = session.createCriteria(B.class);
			List<B> objectsB = crit.list();

			Set<B> objectsBToDelete = new HashSet<B>();

			for (B b : objectsB) {
				// we do not detach and delete each "b" to be able to validate the @Required mapping on a.getB()
				if (b.getA().getB().size() > 1) {
					b.detach();
					objectsBToDelete.add(b);
				}
			}
			session.flush();

			// delete B 
			for (B b : objectsBToDelete) {
				session.delete(b);
			}
			session.flush();

			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			throw e;
		} finally {
			session.close();
		}
	}
}
