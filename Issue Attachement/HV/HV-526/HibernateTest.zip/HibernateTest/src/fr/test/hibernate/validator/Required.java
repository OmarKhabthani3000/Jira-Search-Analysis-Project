package fr.test.hibernate.validator;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

/**
 * Designates a property that is required to have a value. It cannot be null or
 * empty.
 */
@Documented
@Constraint(validatedBy = RequiredValidator.class)
@Target({ METHOD, FIELD })
@Retention(RUNTIME)
public @interface Required {
    String i18nName();

    String message() default "Required => {i18nName}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
