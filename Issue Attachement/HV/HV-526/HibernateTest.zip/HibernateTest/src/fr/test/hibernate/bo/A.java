package fr.test.hibernate.bo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import fr.test.hibernate.validator.Required;

@Entity
@Table(name = "A")
public class A extends BusinessObject {

	private static final long serialVersionUID = 87345767169183337L;
	private Set<B> b;
	private String name;

	public A() {
		super();
		b = new HashSet<B>();
	}
	
	public A(String name) {
		this();
		this.name = name;
	}

	@OneToMany(fetch = FetchType.LAZY, cascade = { CascadeType.REFRESH, CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE }, targetEntity = B.class, mappedBy = "a")
	@Cascade({ org.hibernate.annotations.CascadeType.ALL })
	@Required(i18nName = "B")
	@LazyCollection(LazyCollectionOption.EXTRA)
	public Set<B> getB() {
		return b;
	}

	public void setB(Set<B> b) {
		this.b = b;
	}

	@Basic
	@Column(name = "name", nullable = false)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
