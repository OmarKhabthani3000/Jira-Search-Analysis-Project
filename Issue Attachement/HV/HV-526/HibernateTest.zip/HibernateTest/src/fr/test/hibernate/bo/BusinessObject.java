package fr.test.hibernate.bo;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

@MappedSuperclass
public abstract class BusinessObject implements Serializable {

	private static final long serialVersionUID = 4179574695380922867L;

	/**
	 * Technical primary key
	 */
	protected Long id = null;

	protected Calendar timeStamp = null;

	public BusinessObject() {
	}

	@Id
	@Column(name = "ID", nullable = false)
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setId(long id) {
		this.id = new Long(id);
	}

	@Version
	@Column(name = "OBJ_OPT_LOCK", nullable = false)
	public Calendar getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Calendar ts) {
		timeStamp = ts;
	}
}
