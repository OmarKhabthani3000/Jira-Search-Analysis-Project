package fr.test.hibernate.validator;

import java.io.Serializable;
import java.util.Collection;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class RequiredValidator implements ConstraintValidator<Required, Object>, Serializable {
    @Override
    public void initialize(Required parameters) {
    }

    /** @return true if the value is not null or an empty String */
    @Override
    public boolean isValid(Object value, ConstraintValidatorContext constraintContext) {
        if (value == null) {
            return false;
        }
        if (value instanceof String) {
            String stringValue = (String) value;
            if (stringValue.trim().length() == 0) {
                return false;
            }
        }
        if (value instanceof Collection) {
            return ((Collection<?>) value).size() > 0;
        }
        return true;
    }

}
