package fr.test.hibernate.bo;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.NaturalId;

import fr.test.hibernate.validator.Required;

@Entity
@Table(name = "B")
public class B extends BusinessObject {

	private static final long serialVersionUID = -5733931756299476473L;

	private A a;
	private String name;

	public B() {
		super();
	}
	
	
	public B(String name) {
		this();
		this.name = name;
	}

	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.REFRESH, CascadeType.PERSIST, CascadeType.MERGE }, targetEntity = A.class)
	@JoinColumn(name = "ID_A", nullable = false)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE })
	public A getA() {
		return a;
	}

	public void setA(A a) {
		this.a = a;
	}

	@Basic
	@Column(name = "name", nullable = false)
	@NaturalId(mutable = true)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Transient
	public void detach() {
		if (getA() != null) {
			getA().getB().remove(this);
		}
	}
}
