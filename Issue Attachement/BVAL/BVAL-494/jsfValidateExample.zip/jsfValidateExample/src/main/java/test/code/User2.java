package test.code;

import test.code.constraints.groups.EmailGroup;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * Created by James Moliere (james.moliere@one.verizon.com) on 7/16/2015.
 */
public class User2 extends User
{
	@Size(min = 2, message = "Name should at least be 2 characters long")
	public String getName()
	{
		return super.getName();
	}

	@Pattern(regexp = "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$", message = "This is not a valid email", groups = EmailGroup.class)
	public String getEmail()
	{
		return super.getEmail();
	}
}
