package test.code.constraints.groups;

/**
 * Created by James Moliere (james.moliere@one.verizon.com) on 7/17/2015.
 */
public interface LengthGroup
{
}
