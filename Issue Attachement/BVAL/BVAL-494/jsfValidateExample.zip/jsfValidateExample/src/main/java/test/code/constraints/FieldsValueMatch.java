package test.code.constraints;

/**
 * Created by James Moliere (james.moliere@one.verizon.com) on 7/16/2015.
 */

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Created by v659267 on 5/4/2015.
 */
/**
 * Validation annotation to validate 2 fields that have the same value.
 * An array of fields and their matching confirmation fields can be supplied.
 *
 * Example, compare email fields in an HTML form:
 * @ValueMatch(first = "password", second = "confirmPassword", message = "The password fields must match")
 *
 * Example, compare more than 1 pair of fields:
 * @ValueMatch.List({
 *   @ValueMatch(first = "password", second = "confirmPassword", message = "The password fields must match"),
 *   @ValueMatch(first = "email", second = "confirmEmail", message = "The email fields must match")})
 */
@Target({TYPE, ANNOTATION_TYPE})
@Retention(RUNTIME)
@Constraint(validatedBy = FieldsValueMatchValidator.class)
@Documented
public @interface FieldsValueMatch
{
	String message() default "Fields don't match";


	Class<?>[] groups() default {};
	boolean ignoreCase() default false;

	Class<? extends Payload>[] payload() default {};

	/**
	 * @return The first field
	 */
	String first();

	/**
	 * @return The second field
	 */
	String second();

	/**
	 * Defines several <code>@FieldMatch</code> annotations on the same element
	 *
	 * @see FieldsValueMatch
	 */
	@Target({TYPE, ANNOTATION_TYPE})
	@Retention(RUNTIME)
	@Documented
	@interface List
	{
		FieldsValueMatch[] value();
	}
}
