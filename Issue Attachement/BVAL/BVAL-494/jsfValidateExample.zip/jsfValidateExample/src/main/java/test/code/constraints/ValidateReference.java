package test.code.constraints;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.TYPE;
import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import java.lang.annotation.Target;



/**
 * Created by James Moliere (james.moliere@one.verizon.com) on 7/15/2015.
 */
@Target({TYPE, METHOD, ANNOTATION_TYPE})
@Retention(RUNTIME)
@Constraint(validatedBy = ValidateReferenceValidator.class)
@Documented
public @interface ValidateReference
{
	String message() default "message from ValidateReference";
	Class<?> refClass() ;
	String property() ;
	Class<?>[] groups() default {};
	Class<? extends Payload>[] payload() default {};
}
