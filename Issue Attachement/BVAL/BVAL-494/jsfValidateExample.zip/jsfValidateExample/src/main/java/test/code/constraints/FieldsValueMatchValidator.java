package test.code.constraints;

import org.apache.commons.beanutils.BeanUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * Created by James Moliere (james.moliere@one.verizon.com) on 7/16/2015.
 */


/**
 * Created by v659267 on 5/4/2015.
 */
public class FieldsValueMatchValidator implements ConstraintValidator<FieldsValueMatch, Object>
{
	private String firstFieldName;
	private String secondFieldName;
	private boolean ignoreCase;

	@Override
	public void initialize(final FieldsValueMatch constraintAnnotation)
	{
		firstFieldName = constraintAnnotation.first();
		secondFieldName = constraintAnnotation.second();
		ignoreCase = constraintAnnotation.ignoreCase();
	}

	@Override
	public boolean isValid(final Object value, final ConstraintValidatorContext context)
	{
		try
		{
			final String firstObj = BeanUtils.getProperty(value, firstFieldName);
			final String secondObj = BeanUtils.getProperty(value, secondFieldName);

			if (firstObj == null)
			{
				return secondObj == null;
			}

			return (ignoreCase)?firstObj.equalsIgnoreCase(secondObj):firstObj.equals(secondObj);
		}
		catch (final Exception exception)
		{
			throw new IllegalArgumentException("Could not compare field("+firstFieldName+") with other field ("+secondFieldName+") because one (or more) of the field name(s) is invalid.", exception);
		}
	}
}

