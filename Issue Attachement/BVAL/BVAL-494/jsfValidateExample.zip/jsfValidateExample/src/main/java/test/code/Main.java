package test.code;

import test.code.constraints.FieldsValueMatch;
import test.code.constraints.groups.EmailGroup;
import test.code.constraints.groups.LengthGroup;
import test.code.constraints.groups.NotBlankGroup;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.util.Set;

/**
 * Created by James Moliere (james.moliere@one.verizon.com) on 7/16/2015.
 */
public class Main
{
	public static void main(String ... args)
	{
		checkBadNameAndBadEmailUser();
		printlines();
		checkBadEmailUser2();
		printlines();
		checkBadEmailUserBean();
		printlines();
		checkBadNameAndBadEmailUser3();
		printlines();
		checkBadNameAndBadEmailUser1();
		printlines();

	}

	private static void checkBadEmailUserBean()
	{
		UserBean userBean = new UserBean();
		userBean.setName("a");
		userBean.setEmail("j@");
		userBean.setConfirmEmail("j@j");
		validate(userBean);

	}

	private static void checkBadEmailUser2()
	{
		User2 user = new User2();
		user.setName("a");
		user.setEmail("j@");
		validate(user);
	}

	private static void checkBadNameAndBadEmailUser()
	{
		User user = new User();
		user.setName("");
		user.setEmail("");
		validate(user);
	}

	static void checkBadNameAndBadEmailUser3()
	{
		User3 user = new User3();
		user.setName("  ");
		user.setEmail("j@");
		validate(user, NotBlankGroup.class, EmailGroup.class, LengthGroup.class);
	}

	static void checkBadNameAndBadEmailUser1()
	{
		User user = new User();
		user.setName("  ");
		user.setEmail("j@");
		validate(user, NotBlankGroup.class, EmailGroup.class, LengthGroup.class);
	}

	private static <T> void validate(T t, Class<?> ... c)
	{
		System.out.println("validating: "+t.getClass().getName());
		Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
		Set<ConstraintViolation<T>> response = validator.validate(t, c);
		for (ConstraintViolation<T> cv : response)
		{
			System.out.println("got error message: "+cv.getMessage());
			System.out.println("root:"+cv.getRootBean());
			System.out.println("path: "+cv.getPropertyPath());
			String propPath = cv.getPropertyPath().toString();
			Class<?> theClass = cv.getConstraintDescriptor().getAnnotation().annotationType();

			if ("user.email".equals(propPath) ||
					("".equals(propPath) &&
							theClass.equals(FieldsValueMatch.class)))
			{
				System.out.println("Error with message: "+cv.getMessage());
			}
		}
	}

	private static void printlines()
	{
		System.out.println("==============================");
	}
}
