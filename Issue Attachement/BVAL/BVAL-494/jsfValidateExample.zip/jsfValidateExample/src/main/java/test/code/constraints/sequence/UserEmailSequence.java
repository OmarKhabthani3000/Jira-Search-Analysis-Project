package test.code.constraints.sequence;

import test.code.constraints.groups.EmailGroup;
import test.code.constraints.groups.EmailsMatchGroup;
import test.code.constraints.groups.LengthGroup;
import test.code.constraints.groups.NotBlankGroup;

import javax.validation.GroupSequence;

/**
 * Created by James Moliere (james.moliere@one.verizon.com) on 7/17/2015.
 */
@GroupSequence({NotBlankGroup.class, EmailGroup.class, EmailsMatchGroup.class, LengthGroup.class})
public interface UserEmailSequence {}
