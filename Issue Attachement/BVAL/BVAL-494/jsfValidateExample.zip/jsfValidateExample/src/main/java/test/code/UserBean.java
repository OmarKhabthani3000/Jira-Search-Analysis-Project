package test.code;

import test.code.constraints.FieldsValueMatch;
import test.code.constraints.groups.EmailGroup;
import test.code.constraints.groups.EmailsMatchGroup;
import test.code.constraints.groups.LengthGroup;
import test.code.constraints.groups.NotBlankGroup;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.validation.GroupSequence;
import javax.validation.Valid;
import javax.validation.constraints.*;

@ManagedBean
@RequestScoped




@FieldsValueMatch.List({
        @FieldsValueMatch(first = "email", second = "confirmEmail", message ="emails don't match", groups=EmailsMatchGroup.class, ignoreCase=true)
})
@GroupSequence({UserBean.class, NotBlankGroup.class, EmailsMatchGroup.class, LengthGroup.class})
public class UserBean {

    private User user = new User();
    private String confirmEmail;
    private String phone;


    public String getName() {
        return user.getName();
    }

    public void setName(String name) {
        this.user.setName( name);
    }

    @NotBlank(groups=NotBlankGroup.class)
    @Pattern(regexp = "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$", message = "This is not a valid email", groups = {EmailGroup.class})
    @Length(max=254, groups=LengthGroup.class)
    public String getEmail() {
        return user.getEmail();
    }
    public void setEmail(String email) {
        this.user.setEmail(email);
    }

    public String getConfirmEmail()
    {
        return confirmEmail;
    }
    public void setConfirmEmail(String email)
    {
        this.confirmEmail = email;
    }


    @NotBlank(message="Phone can't be blank", groups=NotBlankGroup.class)
    public String getPhone(){
        return phone;
    }
    public void setPhone(String phone)
    {
        this.phone = phone;
    }

    @NotNull(groups=NotBlankGroup.class)
    @Valid
    public User getUser() { return user; }

    public String toString()
    {
        return "UserBean:[user:"+user+", phone:"+phone+"]";
    }
}
