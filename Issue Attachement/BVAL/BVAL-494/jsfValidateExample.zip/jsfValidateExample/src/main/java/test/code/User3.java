package test.code;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;
import test.code.constraints.groups.EmailGroup;
import test.code.constraints.groups.LengthGroup;
import test.code.constraints.groups.NotBlankGroup;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * Created by James Moliere (james.moliere@one.verizon.com) on 8/11/2015.
 */
public class User3
{
	private String name;
	private String email;

	@NotBlank(groups=NotBlankGroup.class)
	@Size(min = 3, message = "Name should at least be 3 characters long", groups=LengthGroup.class)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	@NotBlank(groups=NotBlankGroup.class)
	@Pattern(regexp = "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$", message = "This is not a valid email", groups = {EmailGroup.class})
	@Length(max=254, groups=LengthGroup.class)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String toString()
	{
		return "User:[name:"+name+", email:"+email+"]";
	}

}
