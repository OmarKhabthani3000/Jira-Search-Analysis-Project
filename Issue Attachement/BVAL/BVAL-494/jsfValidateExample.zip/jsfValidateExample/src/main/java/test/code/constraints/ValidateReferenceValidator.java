package test.code.constraints;

import org.hibernate.validator.constraintvalidation.HibernateConstraintValidatorContext;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.util.Set;

/**
 * Created by James Moliere (james.moliere@one.verizon.com) on 7/15/2015.
 */
public class ValidateReferenceValidator implements ConstraintValidator<ValidateReference, Object>
{
	Class<?> theClass;
	String property;
	Class<?>[] groups;

	public void initialize(ValidateReference validateReference)
	{
		theClass = validateReference.refClass();
		property = validateReference.property();
		groups = validateReference.groups();
	}

	public boolean isValid(Object o, ConstraintValidatorContext constraintValidatorContext)
	{
		HibernateConstraintValidatorContext hibernateContext =
				constraintValidatorContext.unwrap( HibernateConstraintValidatorContext.class );



		Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
		Set<? extends ConstraintViolation<?>> results = validator.validateValue(theClass, property, o, groups);
		if (!results.isEmpty())
		{

			return false;
		}
		return true;
	}
}
