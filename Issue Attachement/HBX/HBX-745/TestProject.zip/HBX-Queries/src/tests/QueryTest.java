package tests;

import java.util.Iterator;
import java.util.Set;

import junit.framework.TestCase;

import org.hibernate.cfg.Configuration;
import org.hibernate.engine.NamedQueryDefinition;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.tool.hbm2x.Cfg2JavaTool;

public class QueryTest extends TestCase {
	private Configuration cfg;

	public void ListQueries(){
		Set qnames = cfg.getNamedQueries().keySet();
		for (Object c: qnames) {
			System.out.println(c);			
		}
	}
	public void testQueries() {
		
		cfg = new Configuration().configure();
		Cfg2JavaTool c2j = new Cfg2JavaTool();
		//ListQueries();
		
		PersistentClass element = cfg.getClassMapping("my.Model.Motd");
		assertNotNull(element);
		NamedQueryDefinition query = (NamedQueryDefinition) cfg
				.getNamedQueries().get(
						"my.Model.Motd.findMatching");
		assertNotNull(query);
		String arglist = c2j.asFinderArgumentList(query.getParameterTypes(),
				element);
		assertEquals("String pattern", arglist);
	}
}