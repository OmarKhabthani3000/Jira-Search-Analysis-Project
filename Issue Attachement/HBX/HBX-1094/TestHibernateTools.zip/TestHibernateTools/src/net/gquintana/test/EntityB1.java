package net.gquintana.test;

import javax.persistence.*;

@Entity
public class EntityB1 extends AbstractEntityB {
	private String comment;

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getComment() {
		return comment;
	}
}