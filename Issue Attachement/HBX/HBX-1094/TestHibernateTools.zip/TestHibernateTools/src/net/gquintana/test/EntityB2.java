package net.gquintana.test;

import javax.persistence.*;

@Entity
public class EntityB2 extends AbstractEntityB {
	private String something;

	public void setSomething(String something) {
		this.something = something;
	}

	public String getSomething() {
		return something;
	}
}