package net.gquintana.test;

import javax.persistence.*;

@Entity
public class EntityA {
	@Id
	private int id;
	@ManyToOne
	private AbstractEntityB b;

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setB(AbstractEntityB b) {
		this.b = b;
	}

	public AbstractEntityB getB() {
		return b;
	}
}