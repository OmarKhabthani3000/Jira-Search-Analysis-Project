package net.sf.hibernate.console;

import java.awt.Image;
import java.awt.Toolkit;
import java.util.ResourceBundle;

import javax.swing.Icon;
import javax.swing.ImageIcon;

public class Resources {

	private static ResourceBundle resource;
	
	public static String getString(String key){
		if(resource==null){
			resource = ResourceBundle.getBundle("net.sf.hibernate.console.message");
		}
		return resource.getString(key);
	}
	
	public static Image getImage(String name){
		return Toolkit.getDefaultToolkit().getImage(Start.class.getResource("images/"+name));
	}
	
	public static Icon getIcon(String name){
		return new ImageIcon(getImage(name));
	}
	
}
