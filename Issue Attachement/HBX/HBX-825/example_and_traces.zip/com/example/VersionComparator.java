package com.example;

import java.util.Comparator;

public class VersionComparator implements Comparator {

	private final int min20ThYear = 97;
	private final int max20ThYear = 99;
	public VersionComparator() {
	}
	
	public int compare(Object obj1, Object obj2) {
		ServiceVersion service1 = (Version) obj1;
		ServiceVersion service2 = (Version) obj2;
		
		if (in20ThCenturyRange(service1.getVersion()) != in20ThCenturyRange(service2.getVersion())) {
			// not in the same century, easy ...
			if (service1.getVersion() > service2.getVersion()) {
				// service1 is in 20th century : 9x > 0x so service2 is newer
				return +1;
			} else { // service1 is newer
				return -1;
			}
		}
		// they both are in the same century
		// first compare version (major)
		if (service1.getVersion() < service2.getVersion()) {
			return +1; // service1 < service2
		} else if (service1.getVersion() > service2.getVersion()) {
			return -1; // service1 > service2
		} else { // versions are equal then compare release (minor)
			if (service1.getRelease() < service2.getRelease()) {
				return +1; // service1 < service2
			} else if (service1.getRelease() > service2.getRelease()) {
				return -1; // service1 > service2
			} else { // they're equal
				return 0;
			}
		}
	}
	
	private boolean in20ThCenturyRange(int version) {
		return (version >= min20ThYear && version <= max20ThYear); 
	}
}
