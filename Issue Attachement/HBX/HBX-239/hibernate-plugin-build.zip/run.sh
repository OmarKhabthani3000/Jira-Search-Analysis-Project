#
#-------
#
# path to the directory hibernate and hibernate ext source.
HIBERNATE=/share/home/john/projects/hibernate



#--------------------
# The parameters in this section affect the jvm that drives the build
#
# 
JAVA_HOME=${JAVA_HOME:=/opt/j2sdk1.4.2_06}

# the eclipse that 'hosts' the build. In other words,
# this is where the pde build runtime classes are.
ECLIPSE31_HOME=${ECLIPSE31_HOME:=/opt/eclipse}
CP=$ECLIPSE31_HOME/startup.jar

# use xerces instead of crimson
XERCES_HOME=${XERCES_HOME:=/opt/xerces-2_6_2}
ENDORSED="-Djava.endorsed.dirs=$XERCES_HOME"

# tell antRunner to be noisy
#VERBOSE=-verbose

#
# when a failure occurs, $WORKSPACE/.metadata/.log might help diagnose
WORKSPACE="-data workspace"

#
# set USEPDESCRIPTS to avoid having to copy-in scripts from pde.build_x.x.x
PDESCRIPTSDIR=$ECLIPSE31_HOME/plugins/org.eclipse.pde.build_3.1.0/scripts
USEPDESCRIPTS="-f $PDESCRIPTSDIR/build.xml \
   -DgenericTargets=$PDESCRIPTSDIR/genericTargets.xml \
   -Dbasedir=$PWD"



#
#------------------
# The parameters in this section override parameters in the main
# build.properties.  They are provided here in this shell script so that the
# build is more easily parameterized (i.e via command line parameters)
# If you prefer to use build.properties, remove or comment
# out the parameter from this shell script.
# 

# location of hibernate core distribution (not source tree!)
# precondition: Hibernate core is successfully built!
HIBERNATE_CORE_HOME=-Dhibernate-core.home=$HIBERNATE/hibernate-3.0

# location of HibernateExt source directory (not distribution tree!)
# precondition: HibernateExt (console, tools) is successfully built!
HIBERNATE_EXT_SRC=-Dhibernate-ext-src.home=$HIBERNATE/HibernateExt

#
# buildId and buildType affect the location and 
#  name of the zip file of the build
BUILDID=-DbuildId=20050421
BUILDTYPE=-DbuildType=S


#
# the directory with hibernate.map, customTargets.xml
BUILDER=-Dbuilder=$PWD

#
# the directory where all files are checkout into, the build is run from
# and where the final product is located.
#
# From pde build article: "On Windows systems, this directory should
# be close to the drive root to avoid path length limitations
# particularly at compile time."
#
# Also, due to eclipse pde build issue 92174, disregard pde build article:
# this MUST be absolute path.
BUILDDIRECTORY=-DbuildDirectory=/usr/tmp/hibernate3

#
# the directory where an eclipse with all dependent plugins are
# installed.  MUST NOT CONTAIN HIBERNATE PLUGINS! but otherwise
# could be set to ECLIPSE31_HOME.
BASELOCATION=-DbaseLocation=/opt/eclipse


# the cvs tag common to all plugins and feature, default is in map file
# if not set, build checksout using tag in hibernate.map file. 
#
#FETCHARG="-DfetchTag=HEAD"


# workaround to eclipse issue in org.eclipse.pde.build (as of 3.1M6):
# 90398: workaround:  -DarchivesFormat="*, *, * - zip"
# use zip format until issue 92380 is resolved
ARCHIVEFORMAT="-DarchivesFormat=*, *, * - zip"

# must build for java1.4 due to assert statement in mapper code
JAVATARGET="-DjavaSource=1.4 -DjavacTarget=1.4"

# zipargs must be set to something!, otherwise no archive is created
# eclipse issue: 92290
ZIPARGS=-Dzipargs=-q

#---------------

set -x
$JAVA_HOME/bin/java  $ENDORSED -cp $CP \
   org.eclipse.core.launcher.Main \
   -application org.eclipse.ant.core.antRunner \
   $USEPDESCRIPTS \
   $JAVATARGET \
   $VERBOSE \
   $WORKSPACE \
   $FETCHARG  \
   $BUILDID $BUILDTYPE \
   $BUILDER \
   $BUILDDIRECTORY \
   $BASELOCATION \
   $HIBERNATE_CORE_HOME \
   $HIBERNATE_EXT_SRC \
   $ZIPARGS \
   "$ARCHIVEFORMAT" \
   $*

