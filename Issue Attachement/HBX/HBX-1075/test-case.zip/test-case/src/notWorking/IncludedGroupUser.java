package notWorking;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("I")
public class IncludedGroupUser extends GroupUser{	
}
