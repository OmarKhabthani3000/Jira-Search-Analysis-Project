package notWorking;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Group {
	
	@Id 
    @SequenceGenerator(name = "group", sequenceName = "group_id") 
    @GeneratedValue(generator = "group")  
    private int id; 
	
	private String name;
	
	@ManyToOne(fetch = FetchType.EAGER)
	private Group underlying;

	/** list of user belong to underlying group, but not belongs to this group */
    @OneToMany(mappedBy = "group")
    private List<ExcludedGroupUser> excludedUsers;

    /** list of user belong to this group **/
    @OneToMany(mappedBy = "group")
    private List<IncludedGroupUser> includedUsers;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Group getUnderlying() {
		return underlying;
	}

	public void setUnderlying(Group underlying) {
		this.underlying = underlying;
	}

	public List<ExcludedGroupUser> getExcludedUsers() {
		return excludedUsers;
	}

	public void setExcludedUsers(List<ExcludedGroupUser> excludedUsers) {
		this.excludedUsers = excludedUsers;
	}

	public List<IncludedGroupUser> getIncludedUsers() {
		return includedUsers;
	}

	public void setIncludedUsers(List<IncludedGroupUser> includedUsers) {
		this.includedUsers = includedUsers;
	}

}
