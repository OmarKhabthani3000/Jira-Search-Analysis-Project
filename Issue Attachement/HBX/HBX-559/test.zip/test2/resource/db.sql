/*==============================================================*/
/* DBMS name:      PostgreSQL 8                                 */
/* Created on:     25.01.2006 19:08:00                          */
/*==============================================================*/


drop table CONTAINER;

drop table ITEM;

drop table SPECIAL;

/*==============================================================*/
/* Table: CONTAINER                                             */
/*==============================================================*/
create table CONTAINER (
   SPECIALID            INT4                 not null,
   CONTAINERID          INT4                 not null,
   ITEMID               VARCHAR(20)          not null,
   constraint PK_CONTAINER primary key (SPECIALID, CONTAINERID)
);

/*==============================================================*/
/* Table: ITEM                                                  */
/*==============================================================*/
create table ITEM (
   ITEMID               VARCHAR(20)          not null,
   SPECIALID            INT4                 not null,
   constraint PK_ITEM primary key (ITEMID, SPECIALID)
);

/*==============================================================*/
/* Table: SPECIAL                                               */
/*==============================================================*/
create table SPECIAL (
   SPECIALID            INT4                 not null,
   constraint PK_SPECIAL primary key (SPECIALID)
);

alter table CONTAINER
   add constraint FK_CONTAINE_REFERENCE_ITEM foreign key (ITEMID, SPECIALID)
      references ITEM (ITEMID, SPECIALID)
      on delete restrict on update restrict;

alter table ITEM
   add constraint FK_ITEM_REFERENCE_SPECIAL foreign key (SPECIALID)
      references SPECIAL (SPECIALID)
      on delete restrict on update restrict;




