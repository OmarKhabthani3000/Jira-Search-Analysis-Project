
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Main {
	public static void main(String[] args) {
		Session session = new AnnotationConfiguration().configure().buildSessionFactory().getCurrentSession();
		Transaction tx = null;
		try {		
			tx = session.beginTransaction();
			Special spec = new Special();
			spec.setSpecialid(3);
			ItemId iid = new ItemId();
			iid.setItemid("item1");
			iid.setSpecialid(3);
	        Item item = new Item();
			item.setId(iid);
			Set<Item> items = new HashSet<Item>();
			items.add(item);
			spec.setItems(items);
			Container cont = new Container();
			ContainerId contId = new ContainerId();
			contId.setContainerid(9);
			contId.setSpecialid(3);
			cont.setId(contId);
			cont.setItem(item);
			Set<Container> containers = new HashSet<Container>();
			item.setContainers(containers);
			containers.add(cont);
			session.save(spec);
			session.save(item);
			tx.commit();
		} catch (Exception e){
		    e.printStackTrace();
		    if (tx != null) tx.rollback();
		    throw new RuntimeException(e);
		}
		finally {
			if( session.isOpen() ){
				session.close();
			}
		}
	}
}
