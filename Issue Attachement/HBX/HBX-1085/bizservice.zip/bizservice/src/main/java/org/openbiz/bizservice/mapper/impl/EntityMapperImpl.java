/*
 * Copyright  2003-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */

package org.openbiz.bizservice.mapper.impl;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.openbiz.bizservice.domain.Entity;
import org.openbiz.bizservice.mapper.EntityMapper;

/**
 * Entity mapper implementation.
 *
 * @param <T> entity type
 * @param <ID> entity ID type
 */
public class EntityMapperImpl<T extends Entity,
    ID extends Serializable> implements EntityMapper<T, ID> {

    private Class<T> persistentClass;

    /**
     * SessionFactory for this mapper.
     */
    private SessionFactory sessionFactory;

    /**
     * Default constructor for initializing EntityMapperImpl.
     */
    @SuppressWarnings("unchecked")
    public EntityMapperImpl() {
        this.persistentClass = (Class<T>) ((ParameterizedType) getClass()
                .getGenericSuperclass()).getActualTypeArguments()[0];
    }

    protected Class<T> getPersistentClass() {
        return persistentClass;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    protected SessionFactory getSessionFactory() {
        return this.sessionFactory;
    }

    /**
     * Returns the persistent instance of the given entity class
     * with the given identifier.
     *
     * @param id ID
     * @return entity
     */
    @SuppressWarnings("unchecked")
    public T get(ID id) {
        Session session = getSessionFactory().getCurrentSession();
        T result = (T) session.get(persistentClass, id);
        return result;
    }

    /**
     * Makes a transient instance persistent.
     *
     * @param entity entity
     */
    public void persist(T entity) {
        Session session = getSessionFactory().getCurrentSession();
        session.persist(entity);
    }

    /**
     * Copies the state of the given object onto the persistent object with
     * the same identifier.
     *
     * @param entity a detached instance with state to be copied
     * @return an updated persistent instance
     */
    @SuppressWarnings("unchecked")
    public T merge(T entity) {
        Session session = getSessionFactory().getCurrentSession();
        return (T) session.merge(entity);
    }

    /**
     * Removes a persistent instance from the datastore.
     *
     * @param entity the instance to be removed
     */
    public void delete(T entity) {
        Session session = getSessionFactory().getCurrentSession();
        session.delete(entity);
    }

    /**
     * Returns the persistent instances of the given entity class
     * with the given attribute value.
     *
     * @param attributeName attribute name
     * @param attributeValue attribute value
     * @return a list of matched persistent entities
     */
    @SuppressWarnings("unchecked")
    public List<T> find(String attributeName, Object attributeValue) {
        List<T> result;
        Session session = getSessionFactory().getCurrentSession();
        Criteria criteria = session.createCriteria(getPersistentClass());
        criteria.add(Restrictions.eq(attributeName, attributeValue));
        result = criteria.list();
        return result;
    }

}
