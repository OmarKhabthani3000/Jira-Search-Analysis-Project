/*
 * Copyright  2003-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */

package org.openbiz.bizservice.advice;

import java.lang.reflect.Method;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Advice class to log method calls.
 */
public class MethodLoggingAdvice implements MethodInterceptor {

    private static final Log LOGGER =
        LogFactory.getLog(MethodLoggingAdvice.class);

    /**
     * Intercepts method invocations to log input parameters and output values.
     *
     * @param invocation invocation
     * @return invocation result
     * @throws Throwable Throwable
     */
    @SuppressWarnings("unchecked")
    public Object invoke(MethodInvocation invocation) throws Throwable {
        Object result;
        Method method = invocation.getMethod();
        Class clazz = invocation.getThis().getClass();
        if (LOGGER.isDebugEnabled()) {
            String methodName = clazz.getSimpleName() + "::" + method.getName();
            try {
                LOGGER.debug("BEGIN: " + methodName
                        + convertToString(invocation.getArguments()));
                result = invocation.proceed();
                if (method.getReturnType() == Void.TYPE) {
                    LOGGER.debug("END: " + methodName + "(..)");
                } else {
                    LOGGER.debug("END: " + methodName + "(..)=" + result);
                }
            } catch (Exception e) {
                LOGGER.warn("END WITH EXCEPTION: " + methodName, e);
                throw e;
            }
        } else {
            try {
                result = invocation.proceed();
            } catch (Exception e) {
                String methodName = clazz.getSimpleName()
                    + "::" + method.getName();
                LOGGER.warn("END WITH EXCEPTION: " + methodName, e);
                throw e;
            }
        }
        return result;
    }

    private static StringBuffer convertToString(Object[] arguments) {
        StringBuffer result;
        if (arguments.length == 0) {
            result = new StringBuffer(4);
            result.append("(void)");
        } else {
            result = null;
            for (Object object : arguments) {
                if (result == null) {
                    result = new StringBuffer(100);
                    result.append('(').append(object);
                } else {
                    result.append(',').append(object);
                }
            }
            result.append(')');
        }
        return result;
    }

}
