package org.openbiz.bizservice;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.openbiz.bizservice.domain.User;

public class DatabaseInitializer {

    private SessionFactory sessionFactory;

    public DatabaseInitializer(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void setup() {

        Session session = sessionFactory.getCurrentSession();

        User user = new User();
        user.setUsername("username1");
        user.setPassword("password1");
        session.save(user);
    }

}
