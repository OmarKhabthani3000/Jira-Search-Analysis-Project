package org.openbiz.bizservice;

import org.hibernate.SessionFactory;
import org.springframework.test.AbstractTransactionalSpringContextTests;

public abstract class AbstractTransactionalTest extends
        AbstractTransactionalSpringContextTests {

    protected SessionFactory sessionFactory;

    @Override
    protected String[] getConfigLocations() {
        return new String[] {
                "classpath:applicationContext.xml"};
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    protected void onSetUpInTransaction() throws Exception {

        // Call super's method first
        super.onSetUpInTransaction();

        DatabaseInitializer initializer = new DatabaseInitializer(sessionFactory);
        initializer.setup();

    }
}
