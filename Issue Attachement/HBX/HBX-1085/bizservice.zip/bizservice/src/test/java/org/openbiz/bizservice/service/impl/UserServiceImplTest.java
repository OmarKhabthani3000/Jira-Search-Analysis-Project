package org.openbiz.bizservice.service.impl;

import org.openbiz.bizservice.AbstractTransactionalTest;
import org.openbiz.bizservice.service.UserService;

public class UserServiceImplTest extends AbstractTransactionalTest {

    private UserService userService;

    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    public void testLogin() {
        assertNotNull(userService.login("username1", "password1"));
        assertNull(userService.login("username", "password1"));
        assertNull(userService.login("username1", "password"));
    }
}
