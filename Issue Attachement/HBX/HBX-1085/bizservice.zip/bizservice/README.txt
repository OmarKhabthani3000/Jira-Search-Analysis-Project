
To set up the project in Eclipse

1. Install JDK5/ JDK6

2. Install Maven 2.0.x (remember to set <MAVEN HOME>/bin to your PATH environment variable)

3. Download all Java libraries with maven command
> cd bizservice
> mvn compile

4. Import project:
Launch Eclipse and go to File > Import > Existing Projects into Workspace (under the General category). Select the root directory of your project, followed by the modules to import. Click Finish to complete the process. 

5. Create M2_REPO classpath variable:
From the Eclipse menu bar, select Window > Preferences. Select the Java > Build Path > Classpath Variables page and set M2_REPO to equal <your home dir>/.m2/repository (On windows, it will be C:/Documents and Settings/<your account>/.m2/repository).


