package auction.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import another.model.Pai;

@Entity
@Table(name = "Filho")
public class Filho extends Pai{

	@Id
	int id;
	
	int test;
	
}
