package another.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Pojo")
public class Pojo {

	@Id
	int id;
	
}
