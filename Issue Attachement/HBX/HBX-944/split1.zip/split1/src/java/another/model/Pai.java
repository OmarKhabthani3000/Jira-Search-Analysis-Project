package another.model;


import javax.persistence.MappedSuperclass;
import javax.persistence.OneToOne;

@MappedSuperclass
public class Pai {
	
	@OneToOne
	Pojo pojo;

}
