package org.hibernate.test.metadata.onetoone;


import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.metadata.TestCase;


public class InheritIdTest extends TestCase {

    public InheritIdTest(String x) {
        super( x );
    }

    public void testInheritId() throws Exception {

        Session s;
        Transaction tx;
        s = openSession();
        tx = s.beginTransaction();
        Notebook n = new Notebook();
        Brand b = new Brand();
        b.setName("noname");
        n.setBrand(b);
        s.persist(n);
        tx.commit();
        s.close();

        s = openSession();
        tx = s.beginTransaction();
        n = (Notebook)s.get( Notebook.class, n.getId() );
        assertNotNull(n);
        assertNotNull(n.getBrand());
        tx.commit();
        s.close();
    }

    /**
     * @see org.hibernate.test.metadata.TestCase#getMappings()
     */
    protected Class[] getMappings() {
        return new Class[] { Brand.class, Notebook.class };
    }

}
