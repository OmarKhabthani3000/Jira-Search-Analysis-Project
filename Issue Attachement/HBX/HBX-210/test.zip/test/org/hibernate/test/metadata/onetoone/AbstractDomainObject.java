package org.hibernate.test.metadata.onetoone;

import javax.ejb.GeneratorType;
import javax.ejb.Id;


public abstract class AbstractDomainObject {

    private Integer id;

    @Id(generate = GeneratorType.AUTO)
    public Integer getId() {

        return id;
    }

    public void setId( Integer id ) {

        this.id = id;
    }
}
