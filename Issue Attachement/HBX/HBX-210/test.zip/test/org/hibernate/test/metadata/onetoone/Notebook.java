package org.hibernate.test.metadata.onetoone;


import javax.ejb.CascadeType;
import javax.ejb.Entity;
import javax.ejb.JoinColumn;
import javax.ejb.OneToOne;


@Entity
public class Notebook extends AbstractDomainObject {

    private Brand brand;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "BRAND_ID")
    public Brand getBrand() {
        return brand;
    }

    public void setBrand( Brand brand ) {
        this.brand = brand;
    }

}
