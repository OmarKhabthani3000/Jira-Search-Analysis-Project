package com.sample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.entity.Specialism;

public interface SpecialismRepository extends JpaRepository<Specialism, Long> {

}