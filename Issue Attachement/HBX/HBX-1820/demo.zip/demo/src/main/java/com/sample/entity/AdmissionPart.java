package com.sample.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;

//import com.thoughtworks.xstream.annotations.XStreamAlias;
//import org.optaplanner.examples.common.domain.AbstractPersistable;


//@XStreamAlias("AdmissionPart")
//public class AdmissionPart extends AbstractPersistable {
@Entity
@Table(name="admissionpart")
@Data
public class AdmissionPart {

    @GeneratedValue(strategy = GenerationType.AUTO)
    @Id
    private Long Id;

	@NotNull
	@ManyToOne(cascade=CascadeType.ALL) //同じ人の別日程登録 ⇒patient,AdmissionPartの順で作成する。
	@JoinColumn(name = "patient_id")
    private Patient patient;

	private Long firstnight_id;

	//@NotNull
	//@ManyToOne(cascade=CascadeType.ALL)
	//@Embedded
	//@JoinColumn(name = "night_id", referencedColumnName = "firstnight")
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumns({
	@JoinColumn(name = "id", referencedColumnName = "firstnight_id")
	})
	private Night firstNight;

	private Long lastnight_id;

	//@NotNull
	//@ManyToOne(cascade=CascadeType.ALL)
	//@Embedded
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumns({
	@JoinColumn(name = "id", referencedColumnName = "lastnight_id")
	})
	private Night lastNight;

	@NotNull
    @ManyToOne(cascade=CascadeType.REFRESH)
    @JoinColumn(name="specialism_id")
	private Specialism specialism;

    public int getNightCount() {
      return (int) (lastNight.getId() - firstNight.getId() + 1);
    }

    //public int calculateSameNightCount(AdmissionPart other) {
    //    int firstNightIndex = (int) Math.max(getFirstNight().getId(), other.getFirstNight().getId());
    //   int lastNightIndex = (int) Math.min(getLastNight().getId(), other.getLastNight().getId());
    //    return Math.max(0, lastNightIndex - firstNightIndex + 1);
    //}

    @Override
    public String toString() {
        return patient + "(" + firstNight + "-" + lastNight + ")";
    }

}


