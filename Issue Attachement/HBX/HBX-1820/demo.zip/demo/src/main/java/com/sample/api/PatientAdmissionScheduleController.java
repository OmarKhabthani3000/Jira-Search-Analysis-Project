package com.sample.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sample.entity.PatientAdmissionSchedule;
import com.sample.service.PatientAdmissionScheduleService;

@RestController
@RequestMapping("api/patientadmissionschedule")
public class PatientAdmissionScheduleController {
  @Autowired
  PatientAdmissionScheduleService PatientAdmissionScheduleService;

  @RequestMapping(method = RequestMethod.GET)
    List<PatientAdmissionSchedule> getPatientAdmissionSchedule() {
        return PatientAdmissionScheduleService.findAll();
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    PatientAdmissionSchedule insertPatientAdmissionSchedule(@Validated @RequestBody PatientAdmissionSchedule PatientAdmissionSchedule) {
        return PatientAdmissionScheduleService.save(PatientAdmissionSchedule);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.OK)
    PatientAdmissionSchedule updatePatientAdmissionSchedule(@PathVariable("id") Long id, @Validated @RequestBody PatientAdmissionSchedule PatientAdmissionSchedule) {
      PatientAdmissionSchedule.setId(id);
      return PatientAdmissionScheduleService.save(PatientAdmissionSchedule);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    void deletePatientAdmissionSchedule(@PathVariable("id") Long id) {
      PatientAdmissionScheduleService.delete(id);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.GET)
    PatientAdmissionSchedule getPatientAdmissionSchedule(@PathVariable("id") Long id) {
        return PatientAdmissionScheduleService.find(id);
    }
}