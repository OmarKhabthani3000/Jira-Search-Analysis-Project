package com.sample.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.sample.entity.DepartmentSpecialismImpl;

public interface DepartmentSpecialismRepository extends JpaRepository< DepartmentSpecialismImpl, Long>, JpaSpecificationExecutor<DepartmentSpecialismImpl> {
    //List<DepartmentSpecialism> search();
	//@Query(name = "search")
	//@Query("select d  as department , DepartmentSpecialismPriority.priority as priority from Department d left join d.id DepartmentSpecialismPriority order by d.id")
	//@Query("select d as department, 0 as priority from Department d order by d.id")
	//@Query("select d as department , d.DepartmentSpecialismPriority.priority from Department d order by d.id")
	@Query("select d as department, ar.priority as priority from Department d LEFT OUTER JOIN d.DepartmentSpecialismPriority as ar")
	public List<DepartmentSpecialism> findByMaster1Value_Join();

}
