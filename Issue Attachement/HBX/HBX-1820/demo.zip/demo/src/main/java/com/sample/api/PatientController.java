package com.sample.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sample.entity.Patient;
import com.sample.service.PatientService;

@RestController
@RequestMapping("api/patient")
public class PatientController {
  @Autowired
  PatientService PatientService;

  @RequestMapping(method = RequestMethod.GET)
    List<Patient> getPatient() {
        return PatientService.findAll();
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    Patient insertpatient(@Validated @RequestBody Patient patient) {
        return PatientService.save(patient);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.OK)
    Patient updatepatient(@PathVariable("id") Long id, @Validated @RequestBody Patient patient) {
      patient.setId(id);
      return PatientService.save(patient);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    void deletepatient(@PathVariable("id") Long id) {
      PatientService.delete(id);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.GET)
    Patient getpatient(@PathVariable("id") Long id) {
        return PatientService.find(id);
    }
}