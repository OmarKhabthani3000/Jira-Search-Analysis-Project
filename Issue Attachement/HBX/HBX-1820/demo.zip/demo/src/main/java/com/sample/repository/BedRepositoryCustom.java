package com.sample.repository;

import com.sample.entity.Bed;

public interface BedRepositoryCustom {
	  public void delete(Long room, Long index);
	  public Bed find(Long room, Long index);
}
