package com.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.entity.Patient;
import com.sample.repository.PatientRepository;

@Service
@Transactional
public class PatientService {
  @Autowired
  PatientRepository PatientRepository;

  public List<Patient> findAll() {
    return PatientRepository.findAll(new Sort(Sort.Direction.ASC, "id"));
  }

  public Patient save(Patient Patient) {
    return PatientRepository.save(Patient);
  }

  public void delete(Long id) {
    PatientRepository.deleteById(id);
  }

  public Patient find(Long id) {
        return PatientRepository.getOne(id);
    }
}