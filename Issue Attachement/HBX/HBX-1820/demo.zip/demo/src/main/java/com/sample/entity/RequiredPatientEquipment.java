package com.sample.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;

//@XStreamAlias("RequiredPatientEquipment")
//public class RequiredPatientEquipment extends AbstractPersistable {
//@Entity
@Data
@Embeddable
public class RequiredPatientEquipment implements Serializable  {

	//@Id
	//@ManyToOne
	//@JoinColumn(name="id")
    //private Patient patient;

	//@Id
	//@ManyToOne(targetEntity=Equipment.class, fetch=FetchType.EAGER)
	//@PrimaryKeyJoinColumn

    @ManyToOne(cascade=CascadeType.REFRESH)
    @JoinColumn(name="equipment_id")
	private Equipment equipment;

    @Override
    public String toString() {
        return "" + equipment;
        //return patient + "-" + equipment;
    }

}