package com.sample.entity;

import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;

//@XStreamAlias("Patient")
//public class Patient extends AbstractPersistable {
@Entity
@Data
//@Embeddable
@Table(name="patient")
public class Patient {
    @Id
    private Long id;

	@NotNull
	private String name;

	@NotNull
	private Gender gender;

	@NotNull
	private int age;

	@NotNull
	private Integer preferredMaximumRoomCapacity;

	//@OneToMany(targetEntity=RequiredPatientEquipment.class, mappedBy="patient", fetch=FetchType.EAGER)
    @Embedded
    @ElementCollection(fetch=FetchType.EAGER)
    //@CollectionTable(
    //    name="list_table",joinColumns=@JoinColumn(name="table_alpha_id")
    //)
	private Set <RequiredPatientEquipment> requiredPatientEquipment;


	//@OneToMany(targetEntity=PreferredPatientEquipment.class, mappedBy="patient", fetch=FetchType.EAGER)
    @Embedded
    @ElementCollection(fetch=FetchType.EAGER)
    //@CollectionTable(
    //    name="list_table", joinColumns=@JoinColumn(name="table_beta_id")
    //    )
    private Set <PreferredPatientEquipment> preferredPatientEquipment;

    @Override
    public String toString() {
        return name;
    }


}




