package com.sample.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sample.entity.Room;
import com.sample.service.RoomService;

@RestController
@RequestMapping("api/room")
public class RoomController {
  @Autowired
  RoomService RoomService;

  @RequestMapping(method = RequestMethod.GET)
    List<Room> getRoom() {
        return RoomService.findAll();
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    Room insertRoom(@Validated @RequestBody Room Room) {
        return RoomService.save(Room);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.OK)
    Room updateRoom(@PathVariable("id") String id, @Validated @RequestBody Room Room) {
      Room.setName(id);
      return RoomService.save(Room);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    void deleteRoom(@PathVariable("id") String id) {
      RoomService.delete(id);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.GET)
    Room getRoom(@PathVariable("id") String id) {
        return RoomService.find(id);
    }
}