package com.sample.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sample.entity.AdmissionPart;
import com.sample.service.AdmissionPartService;

@RestController
@RequestMapping("api/admissionpart")
public class AdmissionPartController {
  @Autowired
  AdmissionPartService AdmissionPartService;

  @RequestMapping(method = RequestMethod.GET)
    List<AdmissionPart> getAdmissionPart() {
        return AdmissionPartService.findAll();
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    AdmissionPart insertAdmissionPart(@Validated @RequestBody AdmissionPart AdmissionPart) {
        return AdmissionPartService.save(AdmissionPart);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.OK)
    AdmissionPart updateAdmissionPart(@PathVariable("id") Long id, @Validated @RequestBody AdmissionPart AdmissionPart) {
      AdmissionPart.setId(id);
      return AdmissionPartService.save(AdmissionPart);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    void deleteAdmissionPart(@PathVariable("id") Long id) {
      AdmissionPartService.delete(id);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.GET)
    AdmissionPart getAdmissionPart(@PathVariable("id") Long id) {
        return AdmissionPartService.find(id);
    }
}