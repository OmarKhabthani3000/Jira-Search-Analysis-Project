package com.sample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.entity.Bed;
import com.sample.entity.BedPK;

public interface BedRepository extends JpaRepository<Bed, BedPK>,BedRepositoryCustom {

}