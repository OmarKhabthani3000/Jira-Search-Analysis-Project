package com.sample.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sample.entity.Department;
import com.sample.service.DepartmentService;

@RestController
@RequestMapping("api/department")
public class DepartmentController {
  @Autowired
  DepartmentService DepartmentService;

  @RequestMapping(method = RequestMethod.GET)
    List<Department> getDepartment() {
        return DepartmentService.findAll();
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    Department insertDepartment(@Validated @RequestBody Department Department) {
        return DepartmentService.save(Department);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.OK)
    Department updateDepartment(@PathVariable("id") Long id, @Validated @RequestBody Department Department) {
      Department.setId(id);
      return DepartmentService.save(Department);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    void deleteDepartment(@PathVariable("id") Long id) {
      DepartmentService.delete(id);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.GET)
    Department getDepartment(@PathVariable("id") Long id) {
        return DepartmentService.find(id);
    }
}