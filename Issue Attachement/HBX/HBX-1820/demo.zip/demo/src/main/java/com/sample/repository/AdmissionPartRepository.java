package com.sample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.entity.AdmissionPart;

public interface AdmissionPartRepository extends JpaRepository<AdmissionPart, Long> {

}