package com.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.entity.Specialism;
import com.sample.repository.SpecialismRepository;

@Service
@Transactional
public class SpecialismService {
  @Autowired
  SpecialismRepository SpecialismRepository;

  public List<Specialism> findAll() {
    return SpecialismRepository.findAll(new Sort(Sort.Direction.ASC, "id"));
  }

  public Specialism save(Specialism Specialism) {
    return SpecialismRepository.save(Specialism);
  }

  public void delete(Long id) {
    SpecialismRepository.deleteById(id);
  }

  public Specialism find(Long id) {
        return SpecialismRepository.getOne(id);
    }
}