package com.sample.repository;

import com.sample.entity.Department;
import com.sample.entity.Specialism;

//import com.thoughtworks.xstream.annotations.XStreamAlias;
//import org.optaplanner.examples.common.domain.AbstractPersistable;

//@XStreamAlias("DepartmentSpecialism")
//public class DepartmentSpecialism extends AbstractPersistable {
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//@Entity
//@SqlResultSetMappings({
//	@SqlResultSetMapping(name="DepartmentSpecialismResult",
//			classes=@ConstructorResult(targetClass=DepartmentSpecialism.class,
//			columns= {@ColumnResult(name="department", type=Department.class),
//					//@ColumnResult(name="specialism", type=Specialism.class),
//					@ColumnResult(name="priority", type=int.class),
//					}))
//})
//@NamedNativeQuery(name="search",query="select d.* ,p.priority from department d left join department_department_specialism_priority p on p.department_id = d.id order by d.id", resultSetMapping="DepartmentSpecialismResult")
//public class DepartmentSpecialism implements Serializable {
public interface DepartmentSpecialism {
	//@Id
    //private Long id;

    //private Department department;
	//@Transient
	//private Department department;
	Department getDepartment();

	//@Transient
	//private Specialism specialism;
    Specialism getSpecialism();

	//@Transient
    //private int priority; // AKA choice
    int getpriority(); // AKA choice

    //@Override
    //public String toString() {
    //    return department + "-" + specialism;
    //}

}
