package com.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.entity.AdmissionPart;
import com.sample.repository.AdmissionPartRepository;

@Service
@Transactional
public class AdmissionPartService {
  @Autowired
  AdmissionPartRepository AdmissionPartRepository;

  public List<AdmissionPart> findAll() {
    return AdmissionPartRepository.findAll(new Sort(Sort.Direction.ASC, "id"));
  }

  public AdmissionPart save(AdmissionPart AdmissionPart) {
    return AdmissionPartRepository.save(AdmissionPart);
  }

  public void delete(Long id) {
    AdmissionPartRepository.deleteById(id);
  }

  public AdmissionPart find(Long id) {
        return AdmissionPartRepository.getOne(id);
    }
}