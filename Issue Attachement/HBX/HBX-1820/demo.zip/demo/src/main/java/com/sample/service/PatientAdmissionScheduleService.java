package com.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.entity.PatientAdmissionSchedule;
import com.sample.repository.PatientAdmissionScheduleRepository;

@Service
@Transactional
public class PatientAdmissionScheduleService {
  @Autowired
  PatientAdmissionScheduleRepository PatientAdmissionScheduleRepository;

  public List<PatientAdmissionSchedule> findAll() {
    return PatientAdmissionScheduleRepository.findAll(new Sort(Sort.Direction.ASC, "id"));
  }

  public PatientAdmissionSchedule save(PatientAdmissionSchedule PatientAdmissionSchedule) {
    return PatientAdmissionScheduleRepository.save(PatientAdmissionSchedule);
  }

  public void delete(Long id) {
	  PatientAdmissionScheduleRepository.deleteById(id);
  }

  public PatientAdmissionSchedule find(Long id) {
        return PatientAdmissionScheduleRepository.getOne(id);
    }
}