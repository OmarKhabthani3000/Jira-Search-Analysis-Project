package com.sample.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sample.entity.Equipment;
import com.sample.service.EquipmentService;

@RestController
@RequestMapping("api/equipment")
public class EquipmentController {
  @Autowired
  EquipmentService EquipmentService;

  @RequestMapping(method = RequestMethod.GET)
    List<Equipment> getEquipment() {
        return EquipmentService.findAll();
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    Equipment insertEquipment(@Validated @RequestBody Equipment Equipment) {
        return EquipmentService.save(Equipment);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.OK)
    Equipment updateEquipment(@PathVariable("id") Long id, @Validated @RequestBody Equipment Equipment) {
      Equipment.setId(id);
      return EquipmentService.save(Equipment);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    void deleteEquipment(@PathVariable("id") Long id) {
      EquipmentService.delete(id);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.GET)
    Equipment getEquipment(@PathVariable("id") Long id) {
        return EquipmentService.find(id);
    }
}