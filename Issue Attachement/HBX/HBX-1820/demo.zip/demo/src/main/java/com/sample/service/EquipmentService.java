package com.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.entity.Equipment;
import com.sample.repository.EquipmentRepository;

@Service
@Transactional
public class EquipmentService {
  @Autowired
  EquipmentRepository EquipmentRepository;

  public List<Equipment> findAll() {
    return EquipmentRepository.findAll(new Sort(Sort.Direction.ASC, "id"));
  }

  public Equipment save(Equipment Equipment) {
    return EquipmentRepository.save(Equipment);
  }

  public void delete(Long id) {
    EquipmentRepository.deleteById(id);
  }

  public Equipment find(Long id) {
        return EquipmentRepository.getOne(id);
    }
}