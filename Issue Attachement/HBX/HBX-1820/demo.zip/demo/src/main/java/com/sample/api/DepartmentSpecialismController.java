package com.sample.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sample.repository.DepartmentSpecialism;
import com.sample.repository.DepartmentSpecialismRepository;

@RestController
@RequestMapping("api/departmentspecialism")
public class DepartmentSpecialismController {
  @Autowired
  DepartmentSpecialismRepository DepartmentSpecialismService;

  @RequestMapping(method = RequestMethod.GET)
    List<DepartmentSpecialism> getDepartmentSpecialism() {
      return DepartmentSpecialismService.findByMaster1Value_Join();
      //return DepartmentSpecialismService.search();
    }
}