package com.sample.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sample.entity.Specialism;
import com.sample.service.SpecialismService;

@RestController
@RequestMapping("api/specialism")
public class SpecialismController {
  @Autowired
  SpecialismService SpecialismService;

  @RequestMapping(method = RequestMethod.GET)
    List<Specialism> getSpecialism() {
        return SpecialismService.findAll();
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    Specialism insertSpecialism(@Validated @RequestBody Specialism Specialism) {
        return SpecialismService.save(Specialism);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.OK)
    Specialism updateSpecialism(@PathVariable("id") Long id, @Validated @RequestBody Specialism Specialism) {
      Specialism.setId(id);
      return SpecialismService.save(Specialism);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    void deleteSpecialism(@PathVariable("id") Long id) {
      SpecialismService.delete(id);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.GET)
    Specialism getSpecialism(@PathVariable("id") Long id) {
        return SpecialismService.find(id);
    }
}