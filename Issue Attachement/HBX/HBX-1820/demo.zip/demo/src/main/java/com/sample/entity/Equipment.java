package com.sample.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

//import com.thoughtworks.xstream.annotations.XStreamAlias;

import lombok.Data;

/**
 * AKA RoomProperty.
 */
//@XStreamAlias("Equipment")
//public class Equipment extends AbstractPersistable {
@Entity
@Table(name="equipment")
@Data
public class Equipment {

	@Id
    private Long id;

	@NotNull
    private String name;

    @Override
    public String toString() {
        return name;
    }

}