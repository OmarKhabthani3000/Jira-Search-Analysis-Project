package com.sample.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sample.entity.Bed;
import com.sample.service.BedService;

@RestController
@RequestMapping("api/bed")
public class BedController {
  @Autowired
  BedService BedService;

  @RequestMapping(method = RequestMethod.GET)
    List<Bed> getBed() {
        return BedService.findAll();
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    Bed insertBed(@Validated @RequestBody Bed Bed) {
        return BedService.save(Bed);
    }

    @RequestMapping(value = "{room},{index}", method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.OK)

    Bed updateBed(@PathVariable("room") Long room, @PathVariable("index") int index,@Validated @RequestBody Bed Bed) {
    	//Bed.setRoom(room);
    	Bed.setIndexInRoom(index);
    	//Bed.setId(pk);
      return BedService.save(Bed);
    }

    @RequestMapping(value = "{room},{index}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
//    void deleteBed(@PathVariable("id") Long id) {
  void deleteBed(@PathVariable("room") Long room, @PathVariable("index") int index) {
        BedService.delete(room, index);
      //BedService.delete(id);
    }

    @RequestMapping(value = "{room},{index}", method = RequestMethod.GET)
    Bed getBed(@PathVariable("room") Long room, @PathVariable("index") int index) {
        return BedService.find(room, index);
    	//    return BedService.find(id);
    }
}