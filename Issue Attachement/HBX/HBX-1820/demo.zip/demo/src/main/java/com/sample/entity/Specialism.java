package com.sample.entity;

//import com.thoughtworks.xstream.annotations.XStreamAlias;
//import org.optaplanner.examples.common.domain.AbstractPersistable;

//import org.optaplanner.examples.common.swingui.components.Labeled;

//import org.optaplanner.core.api.domain.entity.PlanningEntity;
//import org.optaplanner.core.api.domain.variable.PlanningVariable;
//import org.optaplanner.examples.pas.domain.solver.BedDesignationDifficultyWeightFactory;
//import org.optaplanner.examples.pas.domain.solver.BedStrengthComparator;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;

//@XStreamAlias("Specialism")
//public class Specialism extends AbstractPersistable {

@Entity
@Table(name="specialism")
@Data
public class Specialism {
  //@GeneratedValue
  @Id
  private Long id;

  @NotNull
  private String name;

  @Override
  public String toString() {
      return name;
  }

}