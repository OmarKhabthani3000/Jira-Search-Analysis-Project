package com.sample.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;

@Data
@Embeddable
public class BedPK {


	@Column
    private Room room;
    //private Long room;
	@Column
    private int indexInRoom;

}
