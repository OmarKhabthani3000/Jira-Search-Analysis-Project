package com.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.repository.DepartmentSpecialism;
import com.sample.repository.DepartmentSpecialismRepository;

@Service
@Transactional
public class DepartmentSpecialismService {
  @Autowired
  DepartmentSpecialismRepository DepartmentSpecialismRepository;

  public List<DepartmentSpecialism> findAll() {
    return DepartmentSpecialismRepository.findByMaster1Value_Join();
  }

}