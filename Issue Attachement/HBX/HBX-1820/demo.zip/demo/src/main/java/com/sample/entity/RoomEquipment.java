package com.sample.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;

//import com.thoughtworks.xstream.annotations.XStreamAlias;
//import org.optaplanner.examples.common.domain.AbstractPersistable;

//@XStreamAlias("RoomEquipment")
//public class RoomEquipment extends AbstractPersistable {
@Data
@Embeddable
public class RoomEquipment implements Serializable {

    //private Room room;

    @ManyToOne(cascade=CascadeType.REFRESH)
    @JoinColumn(name="equipment_id")
    private Equipment equipment;

    @Override
    public String toString() {
        return "" + equipment;
    }

}
