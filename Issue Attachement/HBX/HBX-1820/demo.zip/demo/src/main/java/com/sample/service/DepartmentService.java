package com.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.entity.Department;
import com.sample.repository.DepartmentRepository;

@Service
@Transactional
public class DepartmentService {
  @Autowired
  DepartmentRepository DepartmentRepository;

  public List<Department> findAll() {
    return DepartmentRepository.findAll(new Sort(Sort.Direction.ASC, "id"));
  }

  public Department save(Department Department) {
    return DepartmentRepository.save(Department);
  }

  public void delete(Long id) {
    DepartmentRepository.deleteById(id);
  }

  public Department find(Long id) {
        return DepartmentRepository.getOne(id);
    }
}