package com.sample.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;

//import com.thoughtworks.xstream.annotations.XStreamAlias;
//import org.optaplanner.examples.common.domain.AbstractPersistable;

//@XStreamAlias("DepartmentSpecialism")
//public class DepartmentSpecialism extends AbstractPersistable {
@Data
@Embeddable
public class DepartmentSpecialismPriority implements Serializable {
    //private Department department;

    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="specialism_id")
    private Specialism specialism;

    private int priority; // AKA choice

    @Override
    public String toString() {
        return "" + specialism;
    }

}
