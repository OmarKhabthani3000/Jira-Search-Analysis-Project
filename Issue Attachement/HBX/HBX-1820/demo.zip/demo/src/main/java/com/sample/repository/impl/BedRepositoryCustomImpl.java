package com.sample.repository.impl;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sample.entity.Bed;
import com.sample.repository.BedRepositoryCustom;

@Component
public class BedRepositoryCustomImpl  implements BedRepositoryCustom {

  @Autowired
  EntityManager manager;

  @Override
  public void delete(Long room, Long index) {
		// TODO 自動生成されたメソッド・スタブ
  }

  @Override
  public Bed find(Long room, Long index) {
	// TODO 自動生成されたメソッド・スタブ
	return null;
  }

}