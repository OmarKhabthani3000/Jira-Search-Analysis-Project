package com.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.entity.Room;
import com.sample.repository.RoomRepository;

@Service
@Transactional
public class RoomService {
  @Autowired
  RoomRepository RoomRepository;

  public List<Room> findAll() {
    return RoomRepository.findAll(new Sort(Sort.Direction.ASC, "id"));
  }

  public Room save(Room Room) {
    return RoomRepository.save(Room);
  }

  public void delete(String id) {
    RoomRepository.deleteById(id);
  }

  public Room find(String id) {
        return RoomRepository.getOne(id);
    }
}