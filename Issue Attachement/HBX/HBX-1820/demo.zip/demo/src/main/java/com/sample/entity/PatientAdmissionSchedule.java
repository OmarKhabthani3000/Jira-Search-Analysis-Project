package com.sample.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.optaplanner.core.api.domain.solution.PlanningScore;
import org.optaplanner.core.api.domain.solution.PlanningSolution;
import org.optaplanner.core.api.score.buildin.hardmediumsoft.HardMediumSoftScore;
//import org.optaplanner.examples.common.domain.AbstractPersistable;
//import org.optaplanner.persistence.xstream.api.score.buildin.hardmediumsoft.HardMediumSoftScoreXStreamConverter;

import lombok.Data;

@PlanningSolution
//@XStreamAlias("PatientAdmissionSchedule")
//public class PatientAdmissionSchedule extends AbstractPersistable {

@Entity
@Data
public class PatientAdmissionSchedule  {
    //private List<Specialism> specialismList;
    //private List<Equipment> equipmentList;
    //private List<Department> departmentList;
    //private List<DepartmentSpecialism> departmentSpecialismList;
    //private List<Room> roomList;
    //private List<RoomSpecialism> roomSpecialismList;
    //private List<RoomEquipment> roomEquipmentList;
    //private List<Bed> bedList;
    //private List<Night> nightList;
    //private List<Patient> patientList;
    //private List<AdmissionPart> admissionPartList;
    //private List<RequiredPatientEquipment> requiredPatientEquipmentList;
    //private List<PreferredPatientEquipment> preferredPatientEquipmentList;

    //private List<BedDesignation> bedDesignationList;

//    @XStreamConverter(HardMediumSoftScoreXStreamConverter.class)
    private HardMediumSoftScore score;

    @GeneratedValue
    @Id
    private Long id;

    //@ProblemFactCollectionProperty
    //public List<Specialism> getSpecialismList() {
    //    return specialismList;
    //}

    //public void setSpecialismList(List<Specialism> specialismList) {
    //    this.specialismList = specialismList;
    //}

    //@ProblemFactCollectionProperty
    //public List<Equipment> getEquipmentList() {
    //    return equipmentList;
    //}

    //public void setEquipmentList(List<Equipment> equipmentList) {
    //    this.equipmentList = equipmentList;
    //}

    //@ProblemFactCollectionProperty
    //public List<Department> getDepartmentList() {
    //    return departmentList;
    //}

    //public void setDepartmentList(List<Department> departmentList) {
    //    this.departmentList = departmentList;
    //}

    //@ProblemFactCollectionProperty
    //public List<DepartmentSpecialism> getDepartmentSpecialismList() {
    //    return departmentSpecialismList;
    //}

    //public void setDepartmentSpecialismList(List<DepartmentSpecialism> departmentSpecialismList) {
    //    this.departmentSpecialismList = departmentSpecialismList;
    //}

    //@ProblemFactCollectionProperty
    //public List<Room> getRoomList() {
    //    return roomList;
    //}

    //public void setRoomList(List<Room> roomList) {
    //    this.roomList = roomList;
    //}

    //@ProblemFactCollectionProperty
    //public List<RoomSpecialism> getRoomSpecialismList() {
    //    return roomSpecialismList;
    //}

    //public void setRoomSpecialismList(List<RoomSpecialism> roomSpecialismList) {
    //    this.roomSpecialismList = roomSpecialismList;
    //}

    //@ProblemFactCollectionProperty
    //public List<RoomEquipment> getRoomEquipmentList() {
    //    return roomEquipmentList;
    //}

    //public void setRoomEquipmentList(List<RoomEquipment> roomEquipmentList) {
    //    this.roomEquipmentList = roomEquipmentList;
    //}

    //@ValueRangeProvider(id = "bedRange")
    //@ProblemFactCollectionProperty
    //public List<Bed> getBedList() {
    //    return bedList;
    //}

    //public void setBedList(List<Bed> bedList) {
    //    this.bedList = bedList;
    //}

    //@ProblemFactCollectionProperty
    //public List<Night> getNightList() {
    //    return nightList;
    //}

    //public void setNightList(List<Night> nightList) {
    //    this.nightList = nightList;
    //}

    //@ProblemFactCollectionProperty
    //public List<Patient> getPatientList() {
    //    return patientList;
    //}

    //public void setPatientList(List<Patient> patientList) {
    //    this.patientList = patientList;
    //}

    //@ProblemFactCollectionProperty
    //public List<AdmissionPart> getAdmissionPartList() {
    //    return admissionPartList;
    //}

    //public void setAdmissionPartList(List<AdmissionPart> admissionPartList) {
    //    this.admissionPartList = admissionPartList;
    //}

    //@ProblemFactCollectionProperty
    //public List<RequiredPatientEquipment> getRequiredPatientEquipmentList() {
    //    return requiredPatientEquipmentList;
    //}

    //public void setRequiredPatientEquipmentList(List<RequiredPatientEquipment> requiredPatientEquipmentList) {
    //    this.requiredPatientEquipmentList = requiredPatientEquipmentList;
    //}

    //@ProblemFactCollectionProperty
    //public List<PreferredPatientEquipment> getPreferredPatientEquipmentList() {
    //    return preferredPatientEquipmentList;
    //}

    //public void setPreferredPatientEquipmentList(List<PreferredPatientEquipment> preferredPatientEquipmentList) {
    //   this.preferredPatientEquipmentList = preferredPatientEquipmentList;
    //}

    //@PlanningEntityCollectionProperty
    //public List<BedDesignation> getBedDesignationList() {
    //    return bedDesignationList;
    //}

    //public void setBedDesignationList(List<BedDesignation> bedDesignationList) {
    //    this.bedDesignationList = bedDesignationList;
    //}

    @PlanningScore
    public HardMediumSoftScore getScore() {
        return score;
    }

    //public void setScore(HardMediumSoftScore score) {
    //    this.score = score;
    //}

    // ************************************************************************
    // Complex methods
    // ************************************************************************

}
