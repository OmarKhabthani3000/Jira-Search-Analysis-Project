package com.sample.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

//import com.thoughtworks.xstream.annotations.XStreamAlias;
//import org.optaplanner.examples.common.domain.AbstractPersistable;
//import org.optaplanner.examples.common.swingui.components.Labeled;

//@XStreamAlias("Bed")
//public class Bed extends AbstractPersistable implements Labeled {
@Entity
//@IdClass(BedPK.class)
@Table(name="bed")
@Data
public class Bed  {

	//@EmbeddedId
	//@Id
	@ManyToOne(cascade=CascadeType.REFRESH)
	@JoinColumn(name = "room_name")
    private Room room;

	//private long room;
	//@EmbeddedId
	@Id
    private int indexInRoom;

    public String getLabelInRoom() {
        if (indexInRoom > 'Z') {
            return Integer.toString(indexInRoom);
        }
        return Character.toString((char) ('A' + indexInRoom));
    }

    //@Override
    //public String getLabel() {
    //    return room.getDepartment().getName() + " " + room.getName() + " " + getLabelInRoom();
    //}

    @Override
    public String toString() {
        return room + "(" + indexInRoom + ")";
    }

}
