package com.sample.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.Data;


//@PlanningEntity(difficultyWeightFactoryClass = BedDesignationDifficultyWeightFactory.class)
//@XStreamAlias("BedDesignation")
//public class BedDesignation extends AbstractPersistable {
@Entity
@Data
public class BedDesignation {

	@Id
    private long id;

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "admissionpart_id")
	private AdmissionPart admissionPart;

//    @PlanningVariable(nullable = true, valueRangeProviderRefs = {"bedRange"},
//            strengthComparatorClass = BedStrengthComparator.class)

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "bed_indexInRoom")
	private Bed bed;

    // ************************************************************************
    // Complex methods
    // ************************************************************************

    public Patient getPatient() {
        return admissionPart.getPatient();
    }

    public Gender getPatientGender() {
        return admissionPart.getPatient().getGender();
    }

    public int getPatientAge() {
        return admissionPart.getPatient().getAge();
    }

    public Integer getPatientPreferredMaximumRoomCapacity() {
        return admissionPart.getPatient().getPreferredMaximumRoomCapacity();
    }

    public Specialism getAdmissionPartSpecialism() {
        return admissionPart.getSpecialism();
    }

    public Long getFirstNightIndex() {
        return admissionPart.getFirstNight().getId();
    }

    public Long getLastNightIndex() {
        return admissionPart.getLastNight().getId();
    }

    //public int getAdmissionPartNightCount() {
    //    return admissionPart.getNightCount();
    //}

    public Room getRoom() {
        if (bed == null) {
            return null;
        }
        return bed.getRoom();
    }

    public int getRoomCapacity() {
        if (bed == null) {
            return Integer.MIN_VALUE;
        }
        return bed.getRoom().getCapacity();
    }

    //public DepartmentSpecialism getDepartment() {
    //    if (bed == null) {
    //        return null;
    //    }
    //    return bed.getRoom().getDepartment();
    //}

    public GenderLimitation getRoomGenderLimitation() {
        if (bed == null) {
            return null;
        }
        return bed.getRoom().getGenderLimitation();
    }

    @Override
    public String toString() {
        return admissionPart.toString();
    }

}
