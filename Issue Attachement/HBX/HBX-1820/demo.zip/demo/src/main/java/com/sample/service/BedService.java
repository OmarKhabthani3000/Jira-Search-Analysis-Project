package com.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.entity.Bed;
import com.sample.repository.BedRepository;

@Service
@Transactional
public class BedService {
  @Autowired
  BedRepository BedRepository;
  //@Autowired
  //BedRepositoryCustom BedRepositoryCustom;

  public List<Bed> findAll() {
    return BedRepository.findAll(new Sort(Sort.Direction.ASC, "room").and( new Sort(Sort.Direction.ASC, "indexInRoom")));
  }

  public Bed save(Bed Bed) {
    return BedRepository.save(Bed);
  }

  public void delete(Long room, int index) {
    //BedRepository.deleteById(room, index);
  }

  public Bed find(Long room,int index) {
        //return BedRepository.getOne(id);
	  return null;
  }
}