package com.sample.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

//import com.thoughtworks.xstream.annotations.XStreamAlias;
//import org.optaplanner.examples.common.domain.AbstractPersistable;

//@XStreamAlias("Department")
//public class Department extends AbstractPersistable {
@Entity
@Table(name="department")
@Data
public class Department {

    @Id
    private Long id;

    private String name;
    private Integer minimumAge = null;
    private Integer maximumAge = null;

	@OneToMany(cascade=CascadeType.ALL)
	private List<Room> roomList;
	//private Room room;

    @Embedded
    @ElementCollection(fetch=FetchType.EAGER)
	private List <DepartmentSpecialismPriority> DepartmentSpecialismPriority;

    public int countHardDisallowedAdmissionPart(AdmissionPart admissionPart) {
        return countDisallowedPatientAge(admissionPart.getPatient());
    }

    public int countDisallowedPatientAge(Patient patient) {
        int count = 0;
        if (minimumAge != null && patient.getAge() < minimumAge) {
            count += 100;
        }
        if (maximumAge != null && patient.getAge() > maximumAge) {
            count += 100;
        }
        return count;
    }

    public String getLabel() {
        String label = name;
        if (minimumAge != null) {
            label += "(≥" + minimumAge + ")";
        }
        if (maximumAge != null) {
            label += "(≤" + maximumAge + ")";
        }
        return label;
    }

    @Override
    public String toString() {
        return name;
    }

}
