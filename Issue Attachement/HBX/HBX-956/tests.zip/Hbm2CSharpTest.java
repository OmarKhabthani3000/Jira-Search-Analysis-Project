/*
 * Created on 2004-12-01
 *
 */
package org.hibernate.tool.hbm2x;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.mapping.Component;
import org.hibernate.mapping.MetaAttribute;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;
import org.hibernate.mapping.RootClass;
import org.hibernate.mapping.SingleTableSubclass;
import org.hibernate.tool.NonReflectiveTestCase;
import org.hibernate.tool.hbm2x.pojo.BasicPOJOClass;
import org.hibernate.tool.hbm2x.pojo.ImportContext;
import org.hibernate.tool.hbm2x.pojo.ImportContextImpl;
import org.hibernate.tool.hbm2x.pojo.NoopImportContext;
import org.hibernate.tool.hbm2x.pojo.POJOClass;
import org.hibernate.tool.hbm2x.support.CSharp2ExportContext;
import org.hibernate.tool.test.TestHelper;

/**
 * @author max
 * 
 */
public class Hbm2CSharpTest extends NonReflectiveTestCase {

    private static final String basePackage = "org.hibernate.tool.hbm2x";
    private static final String basePojo = "org.hibernate.tool.hbm2x.Order";
    
    private Cfg2JavaTool c2j = new Cfg2JavaTool(new CSharp2ExportContext());
    
	private ArtifactCollector artifactCollector;
	
	public Hbm2CSharpTest(String name) {
		super( name, "hbm2csoutput" );
	}

	protected void setUp() throws Exception {
		super.setUp();

		Exporter exporter = new POJOExporter(getCfg(), new Cfg2JavaTool(
                new CSharp2ExportContext()), "csharp2/CsObject.ftl",
                "{package-name}/{class-name}.cs",
                getOutputDir());
		
        artifactCollector = new ArtifactCollector();
		exporter.setArtifactCollector(artifactCollector);
		exporter.start();
	}

	public void testFileExistence() {

		assertFileAndExists( new File( getOutputDir(),
				"org/hibernate/tool/hbm2x/Customer.cs" ) );
		assertFileAndExists( new File( getOutputDir(),
				"org/hibernate/tool/hbm2x/LineItem.cs" ) );
		assertFileAndExists( new File( getOutputDir(),
				"org/hibernate/tool/hbm2x/Order.cs" ) );
		assertFileAndExists( new File( getOutputDir(),
				"org/hibernate/tool/hbm2x/Train.cs" ) );
		assertFileAndExists( new File( getOutputDir(),
				"org/hibernate/tool/hbm2x/Passenger.cs" ) );
		assertFileAndExists( new File( getOutputDir(),
				"org/hibernate/tool/hbm2x/Product.cs" ) );
		assertFileAndExists( new File( getOutputDir(),
				"generated/BaseHelloWorld.cs" ) );
		assertFileAndExists( new File( getOutputDir(), "HelloUniverse.cs" ) );
		
		assertFileAndExists( new File( getOutputDir(), "org/hibernate/tool/hbm2x/FatherComponent.cs" ) );
		assertFileAndExists( new File( getOutputDir(), "org/hibernate/tool/hbm2x/ChildComponent.cs" ) );

		assertEquals(15, artifactCollector.getFileCount("cs"));
	}
	
    //TODO: Implement this
    /*
	public void testCompilable() {

		File file = new File( "compilable" );
		file.mkdir();

		ArrayList list = new ArrayList();
		list.add( new File( "src/testoutputdependent/HelloWorld.cs" )
				.getAbsolutePath() );
		TestHelper.compile( getOutputDir(), file, TestHelper.visitAllFiles(
				getOutputDir(), list ) );

		TestHelper.deleteDir( file );
	}
    */

	/** HBX-606 */
	public void testParentComponentFailureExpected() {
		
		File file = new File( getOutputDir(), "org/hibernate/tool/hbm2x/FatherComponent.cs" );
		
		assertEquals("test", findFirstString("testParent", file));
	}
	
	public void testNoVelocityLeftOvers() {

		assertEquals( null, findFirstString( "$", new File( getOutputDir(),
				"org/hibernate/tool/hbm2x/Customer.cs" ) ) );
		assertEquals( null, findFirstString( "$", new File( getOutputDir(),
				"org/hibernate/tool/hbm2x/LineItem.cs" ) ) );
		assertEquals( null, findFirstString( "$", new File( getOutputDir(),
				"org/hibernate/tool/hbm2x/Order.cs" ) ) );
		assertEquals( null, findFirstString( "$", new File( getOutputDir(),
				"org/hibernate/tool/hbm2x/Product.cs" ) ) );
		assertEquals( null, findFirstString( "$", new File( getOutputDir(),
				"org/hibernate/tool/hbm2x/Address.cs" ) ) );

	}

	protected String getBaseForMappings() {
		return "org/hibernate/tool/hbm2x/";
	}

	protected String[] getMappings() {
		return new String[] { "Customer.hbm.xml", "Order.hbm.xml",
				"LineItem.hbm.xml", "Product.hbm.xml", "HelloWorld.hbm.xml", "Train.hbm.xml", "Passenger.hbm.xml" };
	}

	public void testPackageName() {
        
		PersistentClass classMapping = getCfg()
				.getClassMapping( basePojo );
		POJOClass pc = c2j.getPOJOClass(classMapping);
		
		assertEquals( "org.hibernate.tool.hbm2x", pc.getPackageName() );
		assertEquals( "namespace " + basePackage + " {", pc.getPackageDeclaration().trim() );
		assertEquals( "did not honor generated-class", "namespace generated {", 
                c2j.getPOJOClass( getCfg().getClassMapping("HelloWorld" )).
                    getPackageDeclaration().trim());
	}
	
	public void testFieldNotThere() {
		assertEquals(null,findFirstString("notgenerated", new File( getOutputDir(),
		"HelloUniverse.cs" )));
	}

	public void testJavaDoc() {

		assertEquals( "/// test", c2j.toJavaDoc( "test", 0 ) );
		assertEquals( "  /// test", c2j.toJavaDoc( "test", 2 ) );
		assertEquals( "  /// test\n  /// me", c2j.toJavaDoc( "test\nme", 2 ) );

		PersistentClass local = getCfg()
				.getClassMapping( "HelloWorld" );
		POJOClass pc = c2j.getPOJOClass(local);
		
		assertEquals( "/// Hey there", pc.getClassJavaDoc( "fallback", 0 ) );

		assertEquals( "/// Test Field Description", pc.getFieldJavaDoc(
				local.getIdentifierProperty(), 0 ) );
	}

	
	public void testTypeName() {
	    PersistentClass pc = getCfg().getClassMapping(
                basePojo );
		Property property = pc.getProperty( "lineItems" );
		assertEquals( "System.Collections.ICollection", c2j.getJavaTypeName( property, false ) );		
	}
    

	public void testUseRawTypeNullability() {
		PersistentClass pc = getCfg().getClassMapping(
				basePackage + ".Product" );
		Property property = pc.getProperty( "numberAvailable" );
		assertFalse( property.getValue().isNullable() );
		assertEquals( "typename should be used when rawtypemode", "int", c2j
				.getJavaTypeName( property, false ) );

		property = pc.getProperty( "minStock" );
		assertTrue( property.getValue().isNullable() );
		assertEquals( "typename should be used when rawtypemode", "long", c2j
				.getJavaTypeName( property, false ) );

		property = pc.getProperty( "otherStock" );
		assertFalse( property.getValue().isNullable() );
		assertEquals( "type should still be overriden by meta attribute",
				"int?", c2j.getJavaTypeName( property, false ) );

		property = pc.getIdentifierProperty();
		assertFalse( property.getValue().isNullable() );
		assertEquals( "wrappers should be used by default", "long", c2j
				.getJavaTypeName( property, false ) );

		pc = getCfg().getClassMapping( basePackage + ".Customer" );
		Component identifier = (Component) pc.getIdentifier();

		assertFalse( ((Property) identifier.getPropertyIterator().next() )
				.getValue().isNullable() );
		assertEquals( "long", c2j.getJavaTypeName( property, false ) );

	}
   
    public void testExtendsImplements() {
        Cfg2JavaTool c2j = new Cfg2JavaTool();

        PersistentClass pc = getCfg().getClassMapping(
                "org.hibernate.tool.hbm2x.Order" );
        assertEquals( null, c2j.getPOJOClass(pc).getExtends() );

        POJOClass entityPOJOClass = c2j.getPOJOClass(getCfg().getClassMapping(
        "HelloWorld" ));
        assertEquals( "Comparable", entityPOJOClass.getExtends() );
        assertEquals( "should be interface which cannot have implements", null,
                entityPOJOClass.getImplements() );
        assertEquals( "should be interface which cannot have implements", "",
                entityPOJOClass.getImplementsDeclaration() );

        PersistentClass base = new RootClass();
        base.setClassName( "Base" );

        PersistentClass sub = new SingleTableSubclass( base );
        sub.setClassName( "Sub" );

        assertEquals( null, c2j.getPOJOClass(base).getExtends() );
        assertEquals( "Base", c2j.getPOJOClass(sub).getExtends() );

        Map m = new HashMap();
        MetaAttribute attribute = new MetaAttribute( "extends" );
        attribute.addValue( "x" );
        attribute.addValue( "y" );
        m.put( attribute.getName(), attribute );
        attribute = new MetaAttribute( "interface" );
        attribute.addValue( "true" );
        m.put( attribute.getName(), attribute );

        sub.setMetaAttributes( m );
        assertEquals( "Base,x,y", c2j.getPOJOClass(sub).getExtends() );

        m = new HashMap();
        attribute = new MetaAttribute( "implements" );
        attribute.addValue( "intf" );
        m.put( attribute.getName(), attribute );
        base.setMetaAttributes( m );
        assertEquals( "intf,java.io.Serializable", c2j.getPOJOClass(base).getImplements() );
    }
    
   public void testAsArguments() {
	    PersistentClass pc = getCfg().getClassMapping(
				"org.hibernate.tool.hbm2x.Order" );

		assertEquals(
				"DateTime? orderDate, decimal? total, org.hibernate.tool.hbm2x.Customer customer, System.Collections.ICollection lineItems",
				c2j.asParameterList( pc.getPropertyIterator(), false, new NoopImportContext() ));
		assertEquals( "orderDate, total, customer, lineItems", c2j
				.asArgumentList( pc.getPropertyIterator() ) );
	}

	public void testImportOfSameName() {
		ImportContext ic = new ImportContextImpl("foobar");
		
		assertEquals("CascadeType", ic.importType("javax.persistence.CascadeType"));
		assertEquals("org.hibernate.annotations.CascadeType", ic.importType("org.hibernate.annotations.CascadeType"));
		
		assertTrue("The hibernate annotation should not be imported to avoid name clashes", ic.generateImports().indexOf("hibernate")<0);
		
	}
	
		/*public void testDynamicComponent() {
		
		PersistentClass classMapping = getCfg().getClassMapping("org.hibernate.tool.hbm2x.Customer");
		
		assertEquals("java.util.Map", new Cfg2JavaTool().getJavaTypeName(classMapping.getProperty("dynaMap")));
	}
	*/
	
	public void testUserTypes() {
		PersistentClass classMapping = getCfg().getClassMapping("org.hibernate.tool.hbm2x.Customer");
		
		Property property = classMapping.getProperty("customDate");
		assertEquals("DateTime?", c2j.getJavaTypeName(property, false));
		
	}
	
	
}
