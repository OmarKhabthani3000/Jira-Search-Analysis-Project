/*
 * Copyright Neurosoft 2006
 *
 */
package org.hibernate.tool.hbm2x;

import org.hibernate.tool.JDBCMetaDataBinderTestCase;
import org.hibernate.tool.hbm2x.support.CSharp2ExportContext;

public class Hbm2CSharpJdbcTest extends JDBCMetaDataBinderTestCase {
    public Hbm2CSharpJdbcTest() {
        super("hbm2csoutput");
    }
    
    
    protected String[] getCreateSQL() {
        return new String[] {
                    "CREATE TABLE ITEM (ITEM_ID NUMBER, QTY NUMBER, DESCRIPTION VARCHAR2(255), PRIMARY KEY (ITEM_ID) ENABLE)",
                    "CREATE TABLE CUST_ORDER (ORDER_ID NUMBER, QTY NUMBER, DESCRIPTION VARCHAR2(255), PRIMARY KEY (ORDER_ID) ENABLE)",
                    "CREATE TABLE ORDER_ITEM (ORDER_ITEM_ID NUMBER, ITEM_ID NUMBER, " +
                                              "ORDER_ID NUMBER, QTY NUMBER, " +
                                              "NOTES VARCHAR2(255), " +
                                              "PRIMARY KEY (ORDER_ITEM_ID) ENABLE," +
                                              "FOREIGN KEY (ITEM_ID) REFERENCES ITEM(ITEM_ID) ENABLE," +
                                              "FOREIGN KEY (ORDER_ID) REFERENCES CUST_ORDER(ORDER_ID) ENABLE)"};
    }


    protected String[] getDropSQL() {
        return new String[] {
                "DROP TABLE ORDER_ITEM",
                "DROP TABLE CUST_ORDER",
                "DROP TABLE ITEM"
        };
    }


    public void testGenerateCSharpCode() {
        Exporter exporter = new POJOExporter(cfg, new Cfg2JavaTool(
                new CSharp2ExportContext()), "csharp2/CsObject.ftl",
                "{package-name}/{class-name}.cs",
                getOutputDir());
        
        exporter.start();
    }
}
