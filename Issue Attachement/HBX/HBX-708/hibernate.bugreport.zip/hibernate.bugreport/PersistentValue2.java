
import java.util.Date;
import javax.persistence.*;


@MappedSuperclass
public abstract class PersistentValue2 {

  @Id
  @GeneratedValue(strategy=GenerationType.SEQUENCE)
  public Long getIdentifier() {    return id_; }

  protected void setIdentifier(Long id) {  id_ = id;  }

  @Version
  @Column(name="Version")
  public int getVersion() {   return version_;  }

  public void setVersion(int version) { version_ = version;}

  @Temporal(TemporalType.TIMESTAMP)
  public Date getCreated() {    return created_;  }

  public void setCreated(Date created) {    created_ = created;  }

  private Long id_;
  private int version_;
  private Date created_;

}
