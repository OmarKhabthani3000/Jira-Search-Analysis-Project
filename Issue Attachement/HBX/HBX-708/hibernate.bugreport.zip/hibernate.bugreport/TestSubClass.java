
import javax.persistence.*;

@Entity
@Table(name="TestSubClass")
public class TestSubClass extends PersistentValue2 {

  private String profileId_;
  
  @Basic
  protected String getProfileId() {  return profileId_;  }

  protected void setProfileId(String profileId)  {    profileId_ = profileId;  }


}
