CREATE TABLE works(
   id INT NOT NULL,
   text CHAR(20),
   CONSTRAINT PK_ID_Table PRIMARY KEY (id)
);

CREATE TABLE doesntwork(
   id BIGINT NOT NULL,
   text CHAR(20),
   CONSTRAINT PK_ID_Table PRIMARY KEY (id)
);

CREATE TABLE doesntwork2(
   id SMALLINT NOT NULL,
   text CHAR(20),
   CONSTRAINT PK_ID_Table PRIMARY KEY (id)
);
