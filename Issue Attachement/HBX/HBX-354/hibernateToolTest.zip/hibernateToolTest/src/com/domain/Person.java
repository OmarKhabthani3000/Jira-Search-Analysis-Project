package com.domain;

/**
 * @author Les Hazlewood
 */
public class Person extends Party {

    private String salutation;
    private String givenName;
    private String middleNames;
    private String surname;
    private String nameSuffix;
    private String gender;

    public Person() {}

    public String getGender() {
        return this.gender;
    }

    public void setGender( java.lang.String gender ) {
        this.gender = gender;
    }

    public String getSalutation() {
        return salutation;
    }

    public void setSalutation( String salutation ) {
        this.salutation = salutation;
    }

    public String getGivenName() {
        return givenName;
    }

    public void setGivenName( String givenName ) {
        this.givenName = givenName;
    }

    public String getMiddleNames() {
        return middleNames;
    }

    public void setMiddleNames( String middleNames ) {
        this.middleNames = middleNames;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname( String surname ) {
        this.surname = surname;
    }

    public String getNameSuffix() {
        return nameSuffix;
    }

    public void setNameSuffix( String nameSuffix ) {
        this.nameSuffix = nameSuffix;
    }

    public boolean equals( Object o ) {
        if ( this == o ) return true;
        if ( o == null || getClass() != o.getClass() ) return false;

        final Person person = (Person) o;

        if ( gender != null ? !gender.equals( person.gender ) : person.gender != null ) return false;
        if ( salutation != null ? !salutation.equals( person.salutation ) : person.salutation != null ) return false;
        if ( givenName != null ? !givenName.equals( person.givenName ) : person.givenName != null ) return false;
        if ( middleNames != null ? !middleNames.equals( person.middleNames ) : person.middleNames != null ) return false;
        if ( surname != null ? !surname.equals( person.surname ) : person.surname != null ) return false;
        if ( nameSuffix != null ? !nameSuffix.equals( person.nameSuffix ) : person.nameSuffix != null ) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = ( salutation != null ? salutation.hashCode() : 0 );
        result = 29 * result + ( givenName != null ? givenName.hashCode() : 0 );
        result = 29 * result + ( middleNames != null ? middleNames.hashCode() : 0 );
        result = 29 * result + ( surname != null ? surname.hashCode() : 0 );
        result = 29 * result + ( nameSuffix != null ? nameSuffix.hashCode() : 0 );
        result = 29 * result + ( gender != null ? gender.hashCode() : 0 );
        return result;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        if ( salutation != null ) sb.append( salutation ).append( " " );
        if ( givenName != null ) sb.append( givenName ).append( " " );
        if ( middleNames != null ) sb.append( middleNames ).append( " " );
        if ( surname != null ) sb.append( surname );
        if ( nameSuffix != null ) sb.append( " " ).append( nameSuffix );
        return sb.toString();
    }
}

