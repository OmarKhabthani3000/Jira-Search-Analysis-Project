package com.domain;

import java.io.Serializable;
import java.util.UUID;

/**
 * Base model object convenience class for all persistable objects.
 *
 * @author Les Hazlewood
 */
public abstract class Entity implements Serializable {

    private UUID id;

    public Entity(){}

    public UUID getId() {
        return id;
    }

    public void setId( UUID id ) {
        this.id = id;
    }

    public abstract String toString();

    public abstract boolean equals( Object o );

    public abstract int hashCode();
}
