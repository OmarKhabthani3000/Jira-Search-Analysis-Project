package com.domain;

/**
 * A party is any "contactable" entity.  That is, a party can be a person,
 * a group of people (such as a business/company), or any other
 * such entity.
 *
 * @author Les Hazlewood
 */
public abstract class Party extends Entity {

    /* todo - change these attributes to Sets of respective objects */
    private String emailAddress;
    private String phoneNumber;
    private String postalAddress;

    public Party() {}

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress( String emailAddress ) {
        this.emailAddress = emailAddress;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber( String phoneNumber ) {
        this.phoneNumber = phoneNumber;
    }

    public String getPostalAddress() {
        return postalAddress;
    }

    public void setPostalAddress( String postalAddress ) {
        this.postalAddress = postalAddress;
    }
}
