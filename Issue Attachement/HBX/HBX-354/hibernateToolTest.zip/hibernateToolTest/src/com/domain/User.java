package com.domain;

/**
 * A com.domain.User is a {@link com.domain.Person com.domain.Person} that can log-in to the application.
 *
 * @author Les Hazlewood
 */
public class User extends Person {

    private String username;
    private String password;

    public User(){}

    public String getUsername() {
        return username;
    }

    public void setUsername( String username ) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword( String password ) {
        this.password = password;
    }

    public boolean equals( Object o ) {
        if ( o == this ) return true;
        if ( o != null && ( o instanceof User ) ) {
            User u = (User)o;
            return username.equals( u.getUsername() );
        }
        return false;
    }

    public int hashCode() {
        return username.hashCode();
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("name=").append(super.toString()).append( ",username=").append(username);
        return sb.toString();
    }
}
