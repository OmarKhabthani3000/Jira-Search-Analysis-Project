package com.domain;

import org.hibernate.id.IdentifierGenerator;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.HibernateException;

import java.io.Serializable;
import java.util.UUID;

/**
 * Created on: Jul 26, 2005 7:54:47 AM
 *
 * @author Les Hazlewood
 */
public class UUIDGenerator implements IdentifierGenerator {

    public Serializable generate( SessionImplementor sessionImplementor, Object object )
    throws HibernateException {
        return UUID.randomUUID();
    }

}
