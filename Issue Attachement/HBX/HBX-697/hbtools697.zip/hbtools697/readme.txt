the table creation sql may need some minor tweaks to work in any given database,
but i did run it through mysql 5.0 and sql server 2000 (was generated and from sql server
then made ansi-ish).

to witness the behavior described, in the HQL editor do a "from hbtools697_main" and
take a look at the result pane.  i customized the toString() method so you can see
what is set and what isnt.  clicking on either of the first 2 results will generate
an exception in the Error Log view and the properties window wont respond to the click.
click the 3rd result however and the properties view inspects the instance without
issue.
