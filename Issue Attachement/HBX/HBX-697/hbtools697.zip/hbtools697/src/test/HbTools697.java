package test;

import java.io.Serializable;

public class HbTools697 implements Serializable {
    private static final long serialVersionUID = 0xDEADBEEF;

    private Integer id;
    private String mainValue;
    private String optionalValue;

    public Integer getId() {
        return id;
    }
    public void setId( Integer id ) {
        this.id = id;
    }
    public String getMainValue() {
        return mainValue;
    }
    public void setMainValue( String mainValue ) {
        this.mainValue = mainValue;
    }
    public String getOptionalValue() {
        return optionalValue;
    }
    public void setOptionalValue( String optionalValue ) {
        this.optionalValue = optionalValue;
    }
    
    @Override
    public String toString() {
        StringBuffer buf = new StringBuffer( HbTools697.class.getSimpleName() );
        buf.append( '[' );
        buf.append("id=").append(id);
        buf.append(", mainValue=").append(mainValue);
        buf.append(", optionalValue=").append(optionalValue);
        buf.append( ']' );
        return buf.toString();
    }

}
