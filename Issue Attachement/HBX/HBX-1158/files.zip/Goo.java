

public class Goo {
    
    private long id;
    private Foo foo;
    
    public Goo() {}

    public ConstFoo getFoo() {
        return new ConstFoo(foo);
    }
}