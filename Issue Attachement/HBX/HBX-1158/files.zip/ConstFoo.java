

public class ConstFoo {

    private Foo foo;
    
    public ConstFoo(Foo foo) {
        this.foo = foo;
    }
}