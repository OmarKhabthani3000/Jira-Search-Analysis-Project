

public final class Foo {

    private long id;
    
    public Foo() {}
}