

import org.hibernate.cfg.*;
import org.hibernate.tool.hbm2ddl.*;

public class Main {
    
    public static void main(String[] args) {
        try {
            Configuration cfg = new Configuration().configure("bug.cfg.xml");
            new SchemaExport(cfg).create(true, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}