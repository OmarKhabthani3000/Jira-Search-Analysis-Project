
public class PropertiesUsage {

	public void personName(){
		Person person = new Person();
		person.setName( "name" );
	}
}
