package my.hibernate.generators;

import java.io.File;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2x.ExporterSettings;
import org.hibernate.tool.hbm2x.GenericExporter;
import org.hibernate.tool.hbm2x.pojo.ImportContext;
import org.hibernate.tool.hbm2x.pojo.ImportContextImpl;

public class MyVerboseExporter extends GenericExporter {
	private static final Log log = LogFactory.getLog(MyVerboseExporter.class);
	public MyVerboseExporter() {
		super();
		log.info(String.format(
				"MyVerboseExporter instance created default constructor, template is", this
						.getTemplateName()));
	}
	public MyVerboseExporter(Configuration cfg, File outputdir) {
		super(cfg, outputdir);
		log.info(String.format(
				"MyVerboseExporter instance created with template=%s", this
						.getTemplateName()));
		// TODO: supply GenericExporter.getFilePattern()
	}
	public String getName() {
		return "MyVerboseExporter (generic)";
	}

	/**
	 * Sets missing attributes after GenericExporter.start(), before launching
	 */
	@Override
	public void start() {
		log.info("start() called");
		// Retrieve properties
		Properties p = getProperties();
		String template = p.getProperty(ExporterSettings.PREFIX_KEY
						+ "template_name");
		String pattern = p.getProperty(ExporterSettings.PREFIX_KEY
				+ "file_pattern");
		// Check critical values:
		if (getTemplateName()==null){
			log.warn("no template active");
		} else {
			log.info("active template: " + getTemplateName());
		}
		// Check if consistant with properties data
		if ((template!=null) && !template.equals(getTemplateName())){
			log.warn("template mismatch with properties data: " + template);
			//setTemplateName(template);
		}
		
		log.info("File pattern is (maybe !) " + pattern);
		//setFilePattern(pattern);
		// setTemplatePrefix(???));
		log.debug("calling super.start()");
		super.start();
	}

	// Add some info logging
	@Override
	public void setFilePattern(String filePattern) {
		super.setFilePattern(filePattern);
		log.info(String.format("FilePattern set to %s", filePattern));
	}

	@Override
	public void setTemplateName(String templateName) {
		super.setTemplateName(templateName);
		log.info(String.format("TemplateName set to %s", templateName));
	}

	@Override
	public void setTemplatePath(String[] templatePaths) {
		super.setTemplatePath(templatePaths);
		log.info(String.format("TemplatePath set to [%s]", 
				my.tools.Text.join(templatePaths,";")
				));
	}

	@Override
	public void setTemplatePrefix(String t) {
		super.setTemplatePrefix(t);
		log.info(String.format("TemplatePrefix set to %s", t));
	}

	@Override
	public void setOutputDirectory(File outputdir) {
		super.setOutputDirectory(outputdir);
		log.info(String.format("OutputDirectory set to %s", outputdir));
	}
}
