package my.hibernate.generators;

import org.hibernate.tool.hbm2x.GenericExporter;

public class MyExporter extends GenericExporter {
	public MyExporter() {
		super();
	}
}
