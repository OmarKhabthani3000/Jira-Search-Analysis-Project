package my.tools;


public final class Text {
	/**
	 * Reverses a String.split() operation
	 * @param args an array of string elements
	 * @param delim the separator to use between elements
	 * @return
	 * @see String.split
	 */
	public static String join(String[] args, String delim) {
		StringBuffer result = new StringBuffer();
		for (int idx = 0, n = args.length; idx < n; idx++) {
			result.append(args[idx]);
			if (idx < n - 1) {
				result.append(delim);
			}
		}

		return result.toString();

	}
}
