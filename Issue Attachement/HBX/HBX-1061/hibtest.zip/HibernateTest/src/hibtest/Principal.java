package hibtest;

import java.io.Serializable;

public class Principal implements Serializable { 
	private Long id;
    private String propA;
    private Integer propB;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}		
	public String getPropA() {
		return propA;
	}
	public void setPropA(String propA) {
		this.propA = propA;
	}
	public Integer getPropB() {
		return propB;
	}
	public void setPropB(Integer propB) {
		this.propB = propB;
	}
}
