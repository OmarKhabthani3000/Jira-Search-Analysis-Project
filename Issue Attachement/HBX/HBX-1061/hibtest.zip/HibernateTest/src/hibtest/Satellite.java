package hibtest;

import java.io.Serializable;

public class Satellite implements Serializable {
    private Long id;
	private Principal principal;
	private Integer propC;
	public Long getId() {
	    return id;
	}
	public void setId(Long i) {
	    id = i;
	}
	public Integer getPropC() {
		return propC;
	}
	public void setPropC(Integer propC) {
		this.propC = propC;
	}
	public Principal getPrincipal() {
		return principal;
	}
	public void setPrincipal(Principal principal) {
		this.principal = principal;
	}
}
