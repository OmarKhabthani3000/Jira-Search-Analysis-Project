public interface TestPOJO {
  Long getId();
  String getName();
  String getDescription();
}
