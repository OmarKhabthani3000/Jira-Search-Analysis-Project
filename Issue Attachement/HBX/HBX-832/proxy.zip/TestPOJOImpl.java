import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.ssn.acx.api.common.ACXToStringBuilder;
import com.ssn.acx.api.logistics.mfs.logisticobject.ACXMFSLocation;


public class TestPOJOImpl implements TestPOJO {
  Long id = null;
  private int version = -1;
  String name = null;
  String description = null;
  
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public Long getId() {
    return id;
  }
  public void setId(Long id) {
    this.id = id;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  
  public int getVersion() {
    return version;
  }
  public void setVersion(int version) {
    this.version = version;
  }

  
  @Override
  public boolean equals(Object other) {
    if (!(other instanceof ACXMFSLocation)) {
      return false;
    }
    ACXMFSLocation castOther = (ACXMFSLocation) other;
    return new EqualsBuilder().append(this.getName(), castOther.getName()).isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(getName()).toHashCode();
  }

  @Override
  public String toString() {
    return new ACXToStringBuilder(this).append("id", getId()).append("name", getName()).append("description", getDescription()).toString();
  }


}
