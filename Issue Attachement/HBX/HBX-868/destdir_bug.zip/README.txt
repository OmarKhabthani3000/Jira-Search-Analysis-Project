To reproduce the issue:

1. unzip.  Should have two subdirectories: inner, outer.
2. cd inner
3. ant.   Build should succeed.
4. cd ../outer
5. ant.   Build should fail.  data directory created off of outer/ not inner/ as specified by destdir attribute.
