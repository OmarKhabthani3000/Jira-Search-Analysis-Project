/*
 * Created on Mar 5, 2005
 *
 */
package org.hibernate.eclipce.instrument;

import java.util.ArrayList;
import java.util.Arrays;

import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;


/**
 * @author Juozas
 */
public class EnableEnhancerOperation implements IWorkspaceRunnable{

	private IProject project;
	
	public EnableEnhancerOperation(IProject project){
		
		this.project = project;
		
	}
	
	public void run(IProgressMonitor monitor) throws CoreException {
		
		
		   IProjectDescription desc = project.getDescription();
		   ICommand[] commands = desc.getBuildSpec();
		   boolean found = false;

		   for (int i = 0; i < commands.length; ++i) {
		      if (commands[i].getBuilderName().equals(Enhancer.BUILDER_ID)) {
		         found = true;
		         break;
		      }
		   }
		   if (!found) { 
		      //add builder to project
		      ICommand command = desc.newCommand();
		      command.setBuilderName(Enhancer.BUILDER_ID);
		      ArrayList list = new ArrayList();
		      list.addAll(Arrays.asList(commands));
		      list.add(command);
		      desc.setBuildSpec((ICommand[])list.toArray(new ICommand[]{}));
		      project.setDescription(desc, monitor);
		   }

	}

}
