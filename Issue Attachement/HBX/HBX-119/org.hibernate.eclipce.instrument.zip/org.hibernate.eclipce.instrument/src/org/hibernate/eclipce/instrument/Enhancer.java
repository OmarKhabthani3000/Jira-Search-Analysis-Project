/**
 * $Id$
 *
 * Public Domain code
 */
package org.hibernate.eclipce.instrument;

import java.io.File;
import java.util.*;
import java.util.Collection;
import java.util.Map;

import org.apache.tools.ant.types.Resource;
import org.eclipse.core.resources.*;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.hibernate.tool.instrument.InstrumentTask;

/**
 * @author juozas
 *
 */
public class Enhancer extends IncrementalProjectBuilder {

	public static final String BUILDER_ID = InstrumentPlugin.PLUGIN_ID + ".Enhancer";
	
    protected IProject[] build(int kind, Map args, final IProgressMonitor monitor)
            throws CoreException {
        
        
        IJavaProject jproject = JavaCore.create(getProject());
        IPath location = jproject.getOutputLocation();
        IResource res = ResourcesPlugin.getWorkspace().getRoot().findMember(location);
        if(res != null){
            res.accept( new IResourceVisitor(){
                
                public boolean visit(IResource resource) throws CoreException {
                    
                    if( resource instanceof IFile ){
                        IFile file = (IFile)resource;
                        process(file.getLocation().toFile());
                        file.refreshLocal(IFile.DEPTH_ZERO, monitor);
                    }
                    return true;
                }
                
                
            });
        }
        
        return null;
    }

   private void process(final File file){

        InstrumentTask task = new InstrumentTask(){
            
             protected Collection getFiles() {
               return Collections.singleton(file);       
            
             }  
           }; 
         
           task.execute();
    }
    
}

/**
* $Log$
*/
