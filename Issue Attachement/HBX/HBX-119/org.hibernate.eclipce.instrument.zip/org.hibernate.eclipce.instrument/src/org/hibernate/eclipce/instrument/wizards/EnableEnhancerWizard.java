package org.hibernate.eclipce.instrument.wizards;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.core.internal.resources.Workspace;
import org.eclipse.core.runtime.*;
import org.eclipse.jface.operation.*;
import java.lang.reflect.InvocationTargetException;

import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.core.resources.*;
import org.eclipse.core.runtime.CoreException;
import java.io.*;
import org.eclipse.ui.*;
import org.hibernate.eclipce.instrument.EnableEnhancerOperation;
import org.hibernate.eclipce.instrument.InstrumentPlugin;




public class EnableEnhancerWizard extends Wizard implements INewWizard {
	private EnableEnhancerWizardPage page;
	private ISelection selection;

	/**
	 * Constructor for EnableEnhancerWizard.
	 */
	public EnableEnhancerWizard() {
		super();
		setNeedsProgressMonitor(true);
	}
	
	/**
	 * Adding the page to the wizard.
	 */

	public void addPages() {
		page = new EnableEnhancerWizardPage(selection);
		addPage(page);
	}

	/**
	 * This method is called when 'Finish' button is pressed in
	 * the wizard. We will create an operation and run it
	 * using wizard as execution context.
	 */
	public boolean performFinish() {
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		final IProject project = root.getProject(page.getContainerName());
		try {
			getContainer().run(false,false,
			
					new IRunnableWithProgress(){

						public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
							
							try {
								ResourcesPlugin.getWorkspace().run(new EnableEnhancerOperation(project),monitor);
							} catch (CoreException e) {
								
								throw new InvocationTargetException(e);
							}
						}
				
				    
			}
					
			);
		} catch (InvocationTargetException e) {
			
			InstrumentPlugin.log(e.getTargetException());
			ErrorDialog.openError(getShell(),"Error",e.getMessage(),InstrumentPlugin.getStatus(e));
			
		} catch (InterruptedException e) {
			return false;
		}
		
		
		return true;
	}
	
	
	
	
	
	/**
	 * We will accept the selection in the workbench to see if
	 * we can initialize from it.
	 * @see IWorkbenchWizard#init(IWorkbench, IStructuredSelection)
	 */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
	}
}