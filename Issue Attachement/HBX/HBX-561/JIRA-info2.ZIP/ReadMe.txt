I'd like to re-open this JIRA, as the problem still occurs with newer levels of HIbernate core, annotations, and entity manager:

Environment:

Java 1.5.0_02-b09
WinXP SP2
Eclipse 3.1.1
JBoss 4.0.2 plus EJB3 RC3
JBossIDE 1.5 - "Final" release
Hibernate 3.1.1
Hibernate Annotations 3.1 Beta 8
Hibernate EntityManager 3.1 Beta 6