package com.demos.hibernatemovies;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.OneToMany;
import javax.persistence.FetchType;
import javax.persistence.CascadeType;
import javax.persistence.NamedQuery;

/*
@NamedQuery(
   name="findAllStudiosWithName",
   queryString="SELECT s.studioName FROM Studio s WHERE s.studioName = :studioName"
)
*/

import java.util.Set;
import java.util.HashSet;

import com.demos.hibernatemovies.Movie;

@Entity
@Table(name="STUDIO")
public class Studio implements java.io.Serializable {
	private String studioName ;
	private Set<Movie> movies  = new HashSet<Movie>();
	
    /** default constructor */
    public Studio() {
    }

    /** minimal constructor */
    public Studio(String studioName) {
        this.studioName = studioName;
    }
	
    /** full constructor */
    public Studio(String studioName, Set<Movie>movies) {
        this.studioName = studioName;
		this.movies = movies;
    }

    @Id
    @Column(name="STUDIO_NAME", nullable=false, length=64)
    public String getStudioName() {
        return this.studioName;
    }
    public void setStudioName(String studioName) {
        this.studioName = studioName;
    }
	
    public void addMovie(Movie movie)
	{
	      if (movies == null) movies = new HashSet<Movie>();
	      movies.add(movie);
		  System.out.println("Exit: addMovie()");
	}	
	

	/* Studio is the inverse side of the OneToMany relationship to Movie
	 * 5.1.19 OneToMany Annotation
	 * mappedBy (Optional) The field that owns the relationship.
	 * cascade (Optional) By default, no operations are cascaded.
	 * fetch (Optional) Default is FetchType.LAZY
	 *  @JoinColumn(name="MOVIE_TITLE", referencedColumnName="STUDIO_NAME")	
	 */
	@OneToMany(targetEntity=com.demos.hibernatemovies.Movie.class,
			   mappedBy="studio", 
			   cascade = CascadeType.ALL, 
			   fetch = FetchType.EAGER )	   
	public Set<Movie> getMovies()
	{
		// 2.1.7
		// In a onetomany relationship the many side must be the owner
		// the mappedBy property here designates the property or field
		// in the entity that is the owner of the relationship.
		// Here the owner is Movie and the Movie field is studioName
	      return movies;
    }
	
	public void setMovies(Set<Movie> movies)
	{
	      this.movies = movies;
	}
	

}
