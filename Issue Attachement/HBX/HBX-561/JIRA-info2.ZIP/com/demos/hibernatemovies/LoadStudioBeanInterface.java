
package com.demos.hibernatemovies;




public interface LoadStudioBeanInterface {

 // 0106 Studio loadStudio(String line);
 public boolean loadStudio(String line);

 public Studio queryStudio(String studioName);

 public void closeManager();

 public void flush();

 public void merge(Studio studio);

}
 