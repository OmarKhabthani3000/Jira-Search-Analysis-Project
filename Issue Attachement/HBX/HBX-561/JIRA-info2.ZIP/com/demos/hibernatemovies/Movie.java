package com.demos.hibernatemovies;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;

import java.sql.Date;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;
import java.util.Calendar;


import com.demos.hibernatemovies.Actor;
import com.demos.hibernatemovies.Category;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.CascadeType;
import javax.persistence.FetchType;


@Entity
@Table(name="MOVIE")
public class Movie implements java.io.Serializable {

	private String     movieTitle;
	private Date       releaseDate;
	// private String     studioName;
	private Studio     studio = new Studio();
	private BigDecimal budget;
	private Set<Actor>        actors = new HashSet<Actor>();
	private Set<Category>     categories = new HashSet<Category>();
	
    /** default constructor */
    public Movie() {
    }

    /** full constructor */
    public Movie(String movieTitle, Date releaseDate, Studio studio, BigDecimal budget, Set<Actor> actors, Set<Category> categories) {
        this.movieTitle = movieTitle;
        this.releaseDate = releaseDate;
        // this.studioName = studioName;
		this.studio = studio;
        this.budget = budget;
		this.actors = actors;
		this.categories = categories;
    }

    /** minimal constructor */
    public Movie(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    @Id
    @Column(name="MOVIE_TITLE", nullable=false, length=64)
    public String getMovieTitle() {
        return this.movieTitle;
    }
    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    @Column(name="REL_DATE", nullable=true)
    public Date getReleaseDate() {
        return this.releaseDate;
    }
    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

	@ManyToOne(optional=true, 
			targetEntity=com.demos.hibernatemovies.Studio.class,
			fetch=FetchType.EAGER)
	public Studio getStudio() {
		return this.studio;
	}
	public void setStudio(Studio studio) {
		this.studio = studio;
	}
	
	/*
	 * 5.1.6  JoinColumn Annotation
	 * 5.1.17 ManyToOne Annotation
	 * optional (Optional) Whether the association is optional
	 * If set to false, then a non-null relationship
	 * must always exist.  Default is true.
	 * cascade (Optional) By default, no operations are cascaded.
	 * fetch (Optional) The default is FetchType.EAGER.
	 *-
	-ManyToOne(optional=true, 
			targetEntity="com.demos.hibernatemovies.Studio",
			fetch=FetchType.EAGER)
	-JoinColumn(name="STUDIO_NAME", nullable=false)
    public String getStudioName() {
		-* 4.4.3.1. Bidirectional
		 * 2.1.7 Entity Bean relationahips
		 * For many-to-one bidirectional relationships, the many
		 * side must be the owning side. Hence the mappedby
		 * member is not specified here, because Movie
		 * is the owner.
		 * 2.1.8.2 Bidirectional ManyToOne/OneToMany Relationships
		 * Studio references a Set of Movie(s)
		 *-
        return this.studioName;
    }
    public void setStudioName(String studioName) {
        this.studioName = studioName;
    }
	*/

    @Column(name="BUDGET", nullable=true, length=2)
    public BigDecimal getBudget() {
        return this.budget;
    }
    public void setBudget(BigDecimal budget) {
        this.budget = budget;
    }
	
	/* 5.1.20 JoinTable Annotation
	 * If the JoinTable annotation is missing, the default
	 * values of the annotation members apply.
	 * 
	 * 5.1.21 ManyToMany Annotations
	 * The JoinTable may be specified on either of the 
	 * two sides, but would normally be fully specified on the 
	 * owning side.
	 */
    @ManyToMany(
	        targetEntity=com.demos.hibernatemovies.Actor.class,
	        cascade={CascadeType.PERSIST, CascadeType.MERGE}
	    )
	    @JoinTable(
	        name="MOVIE_ACTORS",
	        joinColumns={@JoinColumn(name="MOVIE_TITLE")},
	        inverseJoinColumns={@JoinColumn(name="FIRST_NAME"), @JoinColumn(name="LAST_NAME")}
	    )
	    
	public Set<Actor> getActors() {
		return actors;
	}
	
	public void setActors(Set<Actor> actors)
	{
		this.actors = actors;
	}

    public void addActor(Actor actor)
	{
	      if (actors == null) actors = new HashSet<Actor>();
		  actors.add(actor);
	}	
	
	/* 5.1.20 JoinTable Annotation
	 * If the JoinTable annotation is missing, the default
	 * values of the annotation members apply.
	 * 
	 * 5.1.21 ManyToMany Annotations
	 * The JoinTable may be specified on either of the 
	 * two sides, but would normally be fully specified on the 
	 * owning side.
	 */
    @ManyToMany(
	        targetEntity=com.demos.hibernatemovies.Category.class,
	        cascade={CascadeType.PERSIST, CascadeType.MERGE}
	    )
	    @JoinTable(
	        name="MOVIE_CATEGORIES",
	        joinColumns={@JoinColumn(name="MOVIE_TITLE")},
	        inverseJoinColumns={@JoinColumn(name="CATEGORY")}
	    )
	public Set<Category> getCategories() {
		return categories;
	}
	
	public void setCategories(Set<Category> categories)
	{
		this.categories = categories;
	}
	
	public void addCategory(Category category) {
		if (categories == null) categories = new HashSet<Category>();
		categories.add(category);
	}
	


    public static Date parseReleaseDate(String year, String month, String day) {
        // See page 590, section 18.1.1 Creating a Date Object
    	// in JDBC API Tutorial and Reference, Third Edition
		// ISBN 0-321-17384-8
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, Integer.parseInt(year));
		cal.set(Calendar.MONTH, Integer.parseInt(month));
		cal.set(Calendar.DATE, Integer.parseInt(day));
		cal.set(Calendar.HOUR, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		
		long millis = cal.getTime().getTime();
		java.sql.Date date = new Date(millis);
		System.out.println("yyyymmdd=" + year + month + day
				+ " "
				+ "date="
				+ date);
    	return date;
    }

   public int hashCode()
   {
      int result;
      result = getMovieTitle().hashCode();
      result = 29 * result;
      return result;
   }

   public boolean equals(Object obj)
   {
      if (obj == this) return true;
      if (!(obj instanceof Movie)) return false;
      if (obj == null) return false;
      Movie pk = (Movie) obj;
      return pk.movieTitle.equals(movieTitle);
   }
	
}
