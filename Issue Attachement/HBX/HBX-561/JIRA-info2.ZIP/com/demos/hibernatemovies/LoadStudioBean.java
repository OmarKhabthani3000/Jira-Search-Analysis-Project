package com.demos.hibernatemovies;

import java.util.StringTokenizer;

// out import javax.ejb.Remote;
// out import javax.ejb.Stateless;
import javax.persistence.EntityManager;


import javax.persistence.EntityTransaction;


import com.demos.hibernatemovies.Studio;
import com.demos.hibernatemovies.BasicQueries;
import com.demos.hibernatemovies.LoadStudioBeanInterface;

import util.HibernateUtil;

// out @Stateless
// out @Remote(LoadStudioBeanInterface.class)
public class LoadStudioBean implements LoadStudioBeanInterface{
     
// old	@PersistenceContext(unitName="em1")
// old          private EntityManager manager;  

	private EntityManager manager;
	public LoadStudioBean() 
      {
		// fix manager = HibernateUtil.getEntityManagerFactory().getEntityManager();
      }

	
	// 0106 public Studio loadStudio(String line) {
        public boolean loadStudio(String line) {
		System.out.println("StudioBean: loadStudio()");
		EntityTransaction tx = null;
		boolean bResult = false;
            // manager = emf.createEntityManager();
            // 0106 Studio studio = parseStudioData(line); 
		    try {
    		  tx = manager.getTransaction();
    		  tx.begin();
              String studioName = parseStudioData(line);
              if (studioName != null) {
            	Studio studio2 = new Studio(studioName);
            	bResult = true;
              }  
              tx.commit();
		    } catch (IllegalStateException e) {
		    	if (tx != null) tx.rollback();
		    	System.out.println("IllegalStateException " + e.getMessage());
		    } catch (RuntimeException e) {
		    	if (tx != null) tx.rollback();
		    	System.out.println("Exception: " + e.getMessage());
		    }
            System.out.println("StudioBean: loadStudio() done.");
            // closeManager();
            // 0106 return studio;
            return bResult;

	}
		
	public String parseStudioData(String line)
	{
	    StringTokenizer tokenizer = new StringTokenizer(line, ";");
	    String studioName  = tokenizer.nextToken();
	    studioName = studioName.trim();
	    System.out.println(
				"Studio: " + studioName );


	    String sName= BasicQueries.findStudioById(manager, studioName);
	    if (sName != null) {
		   System.out.println("Duplicate studio: " + sName);
           sName = null;
// old	   return false;
          } else {
        	  sName = studioName;
          }

// old          Studio studio2 = new Studio(studioName);
			
// old          manager.persist(studio2);
          // 0106 return studio2;
          
// old          return true;
	    return sName;
	}
 
      public Studio queryStudio(String studioName)
      {
         Studio studio = null;
/* begin 0106
         Studio studio = BasicQueries.findStudioById(manager, studioName);
         if (studio != null) 
         {
            System.out.println("queryStudio() found: " + studioName);
         }
end 0106 */
         return studio;
      }

      public void closeManager()
      {
         manager.close();
         System.out.println("Manager closed.");
         return;
      }

      public void flush()
      {
         manager.flush();
         System.out.println("manager.flush(): Done");
      }


      public void merge(Studio studio)
      {
         manager.merge(studio);
         System.out.println("manager.merge(studio): Done");
      }


}
