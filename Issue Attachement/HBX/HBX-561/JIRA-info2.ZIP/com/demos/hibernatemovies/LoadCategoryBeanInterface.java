
package com.demos.hibernatemovies;






public interface LoadCategoryBeanInterface {

 // boolean contains(Category category);

 Category loadCategory(String line);

 public Category queryCategory(String categoryName);

 public void flush();

 public void merge(Category category);

 // void deleteCategory(Category category);

 // void deleteCategoryList(List l);

 // @Remove void persist(Category category);

}
 