package com.demos.hibernatemovies;


import javax.persistence.Embeddable; 


@Embeddable
public class ActorPK implements java.io.Serializable {
	   private String firstName;
	   private String lastName;


	   public ActorPK()
	   {
	   }

	   public ActorPK(String firstName, String lastName)
	   {
	      this.firstName = firstName;
	      this.lastName = lastName;
	   }

	   public String getFirstName()
	   {
	      return firstName;
	   }

	   public void setFirstName(String firstName)
	   {
	      this.firstName = firstName;
	   }

	   public String getLastName()
	   {
	      return lastName;
	   }

	   public void setLastName(String lastName)
	   {
	      this.lastName = lastName;
	   }

	   /*
	    * Section 5.1.5 of the Hibernate 3.0 reference manual says:
	    * Your persistent class must override equals() and hashCode() 
	    * to implement composite identifier equality. It must also 
	    * implement Serializable.
	    */
	   public int hashCode()
	   {
		  String fullName = firstName + lastName;
	      return (int) 29*fullName.hashCode();
	   }

	   public boolean equals(Object obj)
	   {
	      if (obj == this) return true;
	      if (!(obj instanceof ActorPK)) return false;
	      if (obj == null) return false;
	      ActorPK pk = (ActorPK) obj;
	      return pk.firstName.equals(firstName) && pk.lastName.equals(lastName);
	   }

}
