package com.demos.hibernatemovies;

import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.AttributeOverrides;
import javax.persistence.AttributeOverride;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.CascadeType;
import javax.persistence.ManyToMany;

import com.demos.hibernatemovies.ActorPK;
import com.demos.hibernatemovies.Actor;
import com.demos.hibernatemovies.Movie;


import java.util.Set;
import java.util.HashSet;

@Entity
@Table(name="ACTOR")
public class Actor implements java.io.Serializable {

	/*
	 * You must allocate an ActorPK class 
	 * and instantiate it with a first name 
	 * and last name when you create the Actor.
	 */

	private ActorPK pk = new ActorPK();
	private Set<Movie> movies = new HashSet<Movie>();
	
    /** default constructor */	
	public Actor()
	{
	}


    /** full constructor */
    public Actor(String firstName, String lastName, Set<Movie> movies) {
        this.pk.setFirstName(firstName);
        this.pk.setLastName(lastName);
		this.movies = movies;
    }

    /** minimal constructor */
    public Actor(String firstName, String lastName) {
        this.pk.setFirstName(firstName);
        this.pk.setLastName(lastName);	
    }

	
	@EmbeddedId
      @AttributeOverrides({
	@AttributeOverride(name = "firstName", column = @Column(name="FIRST_NAME", length=32) ),
	@AttributeOverride(name = "lastName",  column = @Column(name="LAST_NAME", length=32))
	})
	public ActorPK getPk()
	{
		return pk;
	}
	public void setPk(ActorPK pk)
	{
		this.pk = pk;
	}
	
	@Transient
	public String getFirstName()
	{
	   return pk.getFirstName();
	}
	@Transient
	public String getLastName()
	{
	   return pk.getLastName();
	}
	
    @ManyToMany(
	        cascade={CascadeType.PERSIST, CascadeType.MERGE},
	        mappedBy="actors")
    public Set<Movie> getMovies(){
		return this.movies;
    }
	public void setMovies(Set<Movie> movies){
		if (movies == null) movies = new HashSet<Movie>();
		this.movies = movies;
	}
	
	public void addMovie(Movie movie) {
		if (movies == null) movies = new HashSet<Movie>();
		movies.add(movie);
	}
	
}
