package com.demos.hibernatemovies;




import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.Transient;

import java.util.Set;
import java.util.HashSet;

import com.demos.hibernatemovies.Movie;


@Entity
@Table(name="CATEGORY")
public class Category implements java.io.Serializable {

	private String category;
	private String description;
	private Set<Movie> movies = new HashSet<Movie>();
	
	
	
    /** default constructor */
    public Category() {
    }

    /** full constructor */
    public Category(String category, String description, Set<Movie> movies) {
        this.category = category;
        this.description = description;
		this.movies = movies;
    }

    /** minimal constructor */
    public Category(String category) {
        this.category = category;
    }

    @Id
    @Column(name="CATEGORY", nullable=false, length=64)
    public String getCategory() {
        return this.category;
    }
    public void setCategory(String category) {
        this.category = category;
    }	
	
    @Column(name="DESC", nullable=true, length=255)
    public String getDescription() {
        return this.description;
    }
    public void setDescription(String description) {
        this.description = description;
    }	
	
    @ManyToMany(
	        cascade={CascadeType.PERSIST, CascadeType.MERGE},
	        mappedBy="categories")
	public Set<Movie> getMovies() {
		// 2.1.7 Entity Bean Relationships
		// mappedBy designates the property or field that
		// is the owner of the relationship
		return this.movies;
	}
	
	public void setMovies(Set<Movie> movies) {
		this.movies = movies;
	}
    public void addMovie(Movie movie)
	{
	      if (movies == null) movies = new HashSet<Movie>();
	      movies.add(movie);
	}
	/*
    public void addMovie(String title, Date releaseDate, String studioName, BigDecimal budget)
	{
	      if (movies == null) movies = new HashSet<Movie>();
	      Movie movie = new Movie();
		  movie.setStudioName(studioName);
		  movie.setReleaseDate(releaseDate);
		  movie.setBudget(budget);
	      movies.add(movie);
	}
	*/
}
