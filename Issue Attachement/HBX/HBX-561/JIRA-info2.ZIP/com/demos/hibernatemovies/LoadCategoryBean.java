package com.demos.hibernatemovies;

import java.util.StringTokenizer;

// import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TransactionRequiredException;

import util.HibernateUtil;


import com.demos.hibernatemovies.Category;
import com.demos.hibernatemovies.BasicQueries;
import com.demos.hibernatemovies.LoadCategoryBeanInterface;


public class LoadCategoryBean implements LoadCategoryBeanInterface {

	// private EntityManagerFactory emf;
    // private EntityManager manager;

  	public LoadCategoryBean() 
    {
		//System.out.println("Enter LoadCategoryBean() constructor");
		//emf = HibernateUtil.getEntityManagerFactory();

		System.out.println("Exit  LoadCategoryBean() constructor");
    }

	public Category loadCategory(String line) {
		System.out.println("CategoryBean: loadCategory()");
            Category category = parseCategoryData(line);
            System.out.println("CategoryBean: loadCategory() done.");
            return category;
	}

	public Category parseCategoryData(String line)
	{
		/*
		 * Format:
		 * categoryName;categoryDescription;
		 * both values are required
		 */
		Category category = null;
		Category category2 = null;
		EntityTransaction tx = null;
	    StringTokenizer tokenizer = new StringTokenizer(line, ";");
		String categoryName  = tokenizer.nextToken();
		categoryName = categoryName.trim();
		String categoryDescription  = tokenizer.nextToken();
		categoryDescription = categoryDescription.trim();
		System.out.println(
				"Category: >" + categoryName
				+ "<  Description: >" + categoryDescription + "<");
	    try {
	     /* 	
		    tx = manager.getTransaction();
	  	    tx.begin();  // new persistence context starts here
	  		          // new persistence context created with each call
	    	
		  if (tx != null) {
			  System.out.println("Before find: tx != null");
		  }
		  */
		  category = BasicQueries.findCategoryById(HibernateUtil.getEntityManager(), categoryName);
		  /*
		  if (tx != null) {
			  System.out.println("After  find: tx != null");
			  if (tx.isActive() == true) {
				  System.out.println("tx.isActive() is true");
			  } else {
				  System.out.println("tx.isActive() is false");
			  }
		  }
		  */
	    	
		  if (category != null) {
			System.out.println("Duplicate category: " + categoryName);
            category = null;
			return category;
		  } else { 	
			System.out.println("Not a duplicate category: " + categoryName);
			HibernateUtil.getEntityManager().getTransaction().begin();
			// tx.begin();
			if (HibernateUtil.getEntityManager().getTransaction().isActive() == true) {
				  System.out.println("begin - tx.isActive() is true");
			} else {
				  System.out.println("begin - tx.isActive() is false");
			}
		    category2 = new Category();
		    category2.setCategory(categoryName);
		    category2.setDescription(categoryDescription);
		    System.out.println("After setCategory and setDescription >"
		    		+ category2.getCategory() + "< >" + category2.getDescription() + "<");
		    HibernateUtil.getEntityManager().persist(category2);
		    System.out.println("After manager.persist(category2)");
		    HibernateUtil.getEntityManager().getTransaction().commit();
			System.out.println("After tx.commit()");
		  } // else
	    } catch (IllegalStateException e) {
	    	if (HibernateUtil.getEntityManager().getTransaction() != null) HibernateUtil.getEntityManager().getTransaction().rollback(); else System.out.println("e:Commit - tx is null");
	    	category2 = null;
	    	System.out.println("Commit - IllegalStateException " + e.getMessage());
	    } catch (TransactionRequiredException tre) {
	    	if (HibernateUtil.getEntityManager().getTransaction() != null) HibernateUtil.getEntityManager().getTransaction().rollback(); else System.out.println("tre:Commit - tx is null");
	    	category2 = null;
	    	System.out.println("Commit - TransactionRequiredException: >" + tre.getMessage()  + "<");
	    } catch (PersistenceException pe) {
	    	if (HibernateUtil.getEntityManager().getTransaction() != null) HibernateUtil.getEntityManager().getTransaction().rollback(); else System.out.println("PE:Commit - tx is null");
	    	category2 = null;
	    	System.out.println("Commit - PersistenceException: >" + pe.getMessage()  + "<");
	    } catch (RuntimeException e) {
	    	if (HibernateUtil.getEntityManager().getTransaction() != null) HibernateUtil.getEntityManager().getTransaction().rollback(); else System.out.println("RE:Commit - tx is null");
	    	category2 = null;
	    	System.out.println("Commit - RunTimeException: >" + e.getMessage()  + "<");
	    }  finally {
			// HibernateUtil.getEntityManagerFactory().getEntityManager().close();
			System.out.println("finally");
	    }
		
        return category2;
	}


      public Category queryCategory(String categoryName)
      {
      	 EntityManager manager = HibernateUtil.getEntityManager();
         Category category = BasicQueries.findCategoryById(manager, categoryName);
         if (category != null) 
         {
            System.out.println("queryCategory() found: " + categoryName);
         }
         return category;
      }

      public void close()
      {
		 EntityManager manager = HibernateUtil.getEntityManager();
         manager.close();
         System.out.println("manager.close(): Done");
      }
      
      public void flush()
      {
		 EntityManager manager = HibernateUtil.getEntityManager();
         manager.flush();
         System.out.println("manager.flush(): Done");
      }


      public void merge(Category category)
      {
		 EntityManager manager = HibernateUtil.getEntityManager();
         manager.merge(category);
         System.out.println("manager.merge(category): Done");
      }
      

}
