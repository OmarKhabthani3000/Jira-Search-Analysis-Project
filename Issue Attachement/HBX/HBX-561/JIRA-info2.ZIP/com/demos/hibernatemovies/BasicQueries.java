package com.demos.hibernatemovies;

import javax.persistence.EntityManager;

import java.util.Iterator;
import java.util.List;

// import org.hibernate.HibernateException;
// import org.hibernate.Session;
// import org.hibernate.Query;
// import org.hibernate.QueryException;

import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;

import com.demos.hibernatemovies.Category;
import com.demos.hibernatemovies.Actor;
import com.demos.hibernatemovies.ActorPK;
import com.demos.hibernatemovies.Movie;

public class BasicQueries {

	   public static Actor findActorById(EntityManager manager, ActorPK actorPK)
	   {
	      /*
	       * Note: the find() Session method has been deprecated.  The API
	       * documentation tells you to replace it with createQuery()
	       */
	      System.out.println("findActoryById(): Enter, id = " 
				+ actorPK.getFirstName()
				+ " " 
				+ actorPK.getLastName());
	      Actor actor = null;

	      Query query = manager.createQuery(
				        "from Actor a where a.pk.firstName = :firstName and a.pk.lastName = :lastName") 
			                .setParameter("firstName", actorPK.getFirstName())
					.setParameter("lastName",  actorPK.getLastName());

               List listActor = query.getResultList();
               Iterator iter = listActor.iterator();
			 
	       if (iter.hasNext()) actor = (Actor)iter.next();
			
	       return actor;

	    }	
	
	   public static Category findCategoryById(EntityManager manager, String categoryName)
	   {
		/*
		 * Note: the find() Session method has been deprecated.  The API
		 * documentation tells you to replace it with createQuery()
		 */
		 System.out.println("findCategoryById(): Enter, id = >" + categoryName + "<");
		 Category category = null;
			  // In EJB-QL, the select clause is not optional
	    Query query = manager.createQuery(
	    		       "select c from Category as c where c.category = :categoryName") 
			           .setParameter("categoryName", categoryName);
                 
		 List listCategory = query.getResultList();
		 Iterator iter = listCategory.iterator();
		 if (iter.hasNext()) {
              category = (Category)iter.next();
			  System.out.println("findCategoryById() -- found Category");
         }

	     return category;

	    }
	   
	   public static Movie findMovieById(EntityManager manager, String movieTitle)
	   {
		/*
		 * Note: the find() Session method has been deprecated.  The API
		 * documentation tells you to replace it with createQuery()
		 */
		 System.out.println("findMovieById(): Enter, id = " + movieTitle);
		 Movie movie = null;
			  
	         Query query = manager.createQuery("from Movie as movie where movie.movieTitle = :movieTitle") 
			                      .setParameter("movieTitle", movieTitle);
                  
		 List listMovie = query.getResultList();
                 Iterator iter = listMovie.iterator();
		 if (iter.hasNext()) {
			  movie = (Movie)iter.next();
			  System.out.println("findMovieById() -- found movie");
		  }

		   	  
	       return movie;
	    }	
	   
	   public static String findStudioById(EntityManager manager, String studioName)
	   {
		   /*
		    * Note: the find() Session method has been deprecated.  The API
		    * documentation tells you to replace it with createQuery()
		    */
              

		    System.out.println("findStudioById(): Enter, id=>" + studioName + "<");
		    String sName=null;


			  
	         Query query = manager.createQuery(
                    "SELECT s.studioName FROM Studio s"); 
                List listStudio = query.setMaxResults(10).getResultList();
		    Iterator iter = listStudio.iterator(); 
                int i = 0;
		    while (iter.hasNext()) {
                       i++;
                       String theName = (String)iter.next();
			     System.out.println(
                         "findStudioById() -- found #" + i + " >" + theName + "<");
                    }

/*
            try
            {
            Studio studio2 = (Studio)manager.createNamedQuery("findAllStudiosWithName")
			  .setParameter("studioName", "\'" + studioName.trim() + "\'" )
                    .getSingleResult();
             } catch (EntityNotFoundException e) {
		    System.out.println("findStudioById(): NamedQuery EntityNotFoundException!");
             }
*/
            String theName = studioName.trim();
            System.out.println(">\'" + theName + "\'<");
            try
            {    
                sName = (String)manager.createQuery(
                    "SELECT s.studioName FROM Studio s WHERE s.studioName = :param") 
			        .setParameter("param", theName ) 
                    .getSingleResult();
             } catch (EntityNotFoundException e) {
                if (sName == null) {
                  System.out.println("sName = null");
                } else {
                  System.out.println("sName = >" + sName + "<");
                }
		        System.out.println("findStudioById(): EntityNotFoundException!");
             }
             
	       return sName;

	    }	   
}
