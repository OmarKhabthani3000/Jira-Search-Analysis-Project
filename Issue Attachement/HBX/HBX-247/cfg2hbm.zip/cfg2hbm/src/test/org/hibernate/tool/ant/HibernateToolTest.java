/*
 * Created on 13-Feb-2005
 *
 */
package org.hibernate.tool.ant;

import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * @author max
 *
 */
public class HibernateToolTest extends BuildFileTestCase {

	public HibernateToolTest(String name) {
		super(name);
	}
	
	protected void setUp() throws Exception {
		configureProject("src/testsupport/anttest-build.xml");
	}
	
	public void testConfiguration() {
		executeTarget("testantcfg");
	}

	public void testJDBCConfiguration() {
		executeTarget("testantjdbccfg");
	}
	
	public void testAnnotationConfiguration() {
		executeTarget("testantannotationcfg");
	}
	
	public void testHbm2JavaEJB3Configuration() {
		executeTarget("testantejb3hbm2java");
	}
	
    public void testCfg2HbmNoError() {
        executeTarget("testantcfg2hbm1");
    }
    
    public void testCfg2HbmWithCustomReverseNamingStrategy() {
        executeTarget("testantcfg2hbm2");
    }
    
    public void testCfg2HbmWithInvalidReverseNamingStrategy() {
        expectSpecificBuildException("testantcfg2hbm3", 
                "namingStrategy attribute should not be loaded", 
                "Cannot load reverseNamingStrategy invalid.classname");
    }
    
    public void testCfg2HbmWithPackageName() {
        executeTarget("testantcfg2hbm4");
    }
    
    public void testCfg2HbmWithPackageNameAndReverseNamingStrategy() {
        executeTarget("testantcfg2hbm5");
    }
    
    public void testCfg2HbmWithPackageNameAndWrongReverseNamingStrategy() {
        expectSpecificBuildException("testantcfg2hbm6",
                "",
                "reverseNamingStrategy "
                + NonProtectedDefaultReverseNamingStrategy.class.getName() + 
                " does not support setting packageName");
    }
    
	public static Test suite() {
		return new TestSuite(HibernateToolTest.class);
	}
	
}
