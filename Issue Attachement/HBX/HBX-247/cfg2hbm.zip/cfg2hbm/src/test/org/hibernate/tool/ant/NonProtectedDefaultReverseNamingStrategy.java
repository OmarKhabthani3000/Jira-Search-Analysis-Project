package org.hibernate.tool.ant;

import org.hibernate.cfg.reveng.DefaultReverseNamingStrategy;


public class NonProtectedDefaultReverseNamingStrategy extends DefaultReverseNamingStrategy {
    public NonProtectedDefaultReverseNamingStrategy() {
    }
}
