/*
 * Created on 2004-11-24
 *
 */
package org.hibernate.tool;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;

import junit.framework.ComparisonFailure;
import junit.framework.TestCase;

import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.JDBCBinder;
import org.hibernate.cfg.JDBCMetaDataConfiguration;
import org.hibernate.cfg.Settings;
import org.hibernate.cfg.reveng.JDBCFilter;
import org.hibernate.cfg.reveng.TableIdentifier;
import org.hibernate.mapping.ForeignKey;
import org.hibernate.mapping.Table;

/**
 * @author max
 *
 */
public abstract class JDBCMetaDataBinderTestCase extends TestCase {

	/*static*/ protected JDBCMetaDataConfiguration cfg;

    static private boolean storesLowerCaseIdentifiers;

    static private boolean storesUpperCaseIdentifiers;
	
	/** should this maybe be on dialect ? **/
	protected String identifier(String actual) {
		if(storesLowerCaseIdentifiers) {
			return actual.toLowerCase();
		} else if (storesUpperCaseIdentifiers) {
			return actual.toUpperCase();
		} else {
			return actual;
		}			
	}
	
	/**
	 * Tries to adjust for different behaviors on databases regarding cases on identifiers.
	 * Used if you don't care about cases in comparisons.
	 * 
	 * @param expected
	 * @param actual
	 */
	protected void assertEqualIdentifiers(String expected, String actual) {
		assertEquals(identifier(expected), identifier(actual));
	}
	
	/**
	 * @param sqls
	 * @throws SQLException
	 */
	protected void executeDDL(String[] sqls) throws SQLException {
		Configuration configuration = new Configuration();
		Settings testSettings = configuration.buildSettings();
		
        
		Connection con = testSettings.getConnectionProvider().getConnection();
		
		DatabaseMetaData metaData = con.getMetaData();
		storesLowerCaseIdentifiers = metaData.storesLowerCaseIdentifiers();
        storesUpperCaseIdentifiers = metaData.storesUpperCaseIdentifiers();
        
		Statement statement = con.createStatement();
		
		
		
		for (int i = 0; i < sqls.length; i++) {
			String string = sqls[i];
			System.out.println("Execute: " + string);
			
            try {
			statement.execute(string);
            } catch (SQLException se) {
                se.printStackTrace();
                throw se;
            }
		}
		if (statement!=null) statement.close();
		con.commit();
		testSettings.getConnectionProvider().closeConnection(con);
	}

	protected abstract String[] getCreateSQL();
	protected abstract String[] getDropSQL();

	protected void setUp() throws Exception {
		if(cfg==null) { // only do if we haven't done it before - to save time!

            try {
                executeDDL(getDropSQL());
            } catch (SQLException se) {
                System.err.println("Error while dropping - normally ok.");
            }
        
		String[] sqls = getCreateSQL();
		
        executeDDL(sqls);
				
		cfg = new JDBCMetaDataConfiguration();
		configure(cfg);
		cfg.readFromJDBC();			
		}
	}

    /* (non-Javadoc)
     * @see junit.framework.TestCase#tearDown()
     */
    protected void tearDown() throws Exception {
        executeDDL(getDropSQL());
    }
	/**
	 * @param cfg2
	 */
	protected void configure(JDBCMetaDataConfiguration cfg) {
		
		
	}
	
	protected void assertHasNext(int expected, Iterator foreignKeyIterator) {
		assertHasNext(null, expected, foreignKeyIterator);
	}
	/**
	 * @param i
	 * @param foreignKeyIterator
	 */
	protected void assertHasNext(String reason, int expected, Iterator foreignKeyIterator) {
		int actual = 0;
		while(foreignKeyIterator.hasNext() && actual <= expected) {
			foreignKeyIterator.next();
			actual ++;
		}
		
		if(actual < expected) {
			throw new ComparisonFailure(reason==null?"Expected were less":reason, ""+expected, ""+actual);
		}
		
		if(actual > expected) {
			throw new ComparisonFailure(reason==null?"Expected were higher":reason, ""+expected, ""+actual);
		}		
	}

	/**
	 * @param column
	 * @return
	 */
	protected String toPropertyName(String column) {
		return cfg.getReverseNamingStrategy().columnToPropertyName(null,column);
	}

	/**
	 * @param table
	 * @return
	 */
	protected String toClassName(String table) {
		return cfg.getReverseNamingStrategy().tableToClassName(new TableIdentifier(null,null,table));
	}

    /**
     * Return the first foreignkey with the matching name ... there actually might be multiple foreignkeys with same name, but then they point to different entitities.
     * @param table
     * @param fkName
     * @return
     */
    protected ForeignKey getForeignKey(Table table, String fkName) {
        Iterator iter = table.getForeignKeyIterator();
        while(iter.hasNext()) {
            ForeignKey fk = (ForeignKey) iter.next();
            if(fk.getName().equals(fkName)) {
                return fk;
            }
        }
        return null;
    }
    
    /**
     * Find the first table matching the name (without looking at schema/catalog)
     * @param tabName
     * @return
     */
    protected Table getTable(String tabName) {
        Iterator iter = cfg.getTableMappings();
        while(iter.hasNext()) {
            Table table = (Table) iter.next();
            if(table.getName().equals(tabName)) {
                return table;
            }
        }
        return null;
    }
    
}
