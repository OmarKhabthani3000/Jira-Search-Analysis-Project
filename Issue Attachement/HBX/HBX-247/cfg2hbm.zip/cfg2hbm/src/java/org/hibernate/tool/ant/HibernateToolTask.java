/*
 * Created on 13-Feb-2005
 *
 */
package org.hibernate.tool.ant;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.tools.ant.AntClassLoader;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.Path;
import org.hibernate.cfg.Configuration;

/**
 * @author max
 *
 */
public class HibernateToolTask extends Task {

	ConfigurationTask configurationTask;
	private File destDir;
	private List generators = new ArrayList();
	private Path classPath;
	private Path templatePath;
	
	private void checkConfiguration() {
		if(configurationTask!=null) {
			throw new BuildException("Only a single configuration is allowed.");
		}
	}

	public ConfigurationTask createConfiguration() {
		checkConfiguration();
		configurationTask = new ConfigurationTask();
		return configurationTask;			
	}
	

	public JDBCConfigurationTask createJDBCConfiguration() {
		checkConfiguration();
		configurationTask = new JDBCConfigurationTask();
		return (JDBCConfigurationTask) configurationTask;			
	}
	
	public AnnotationConfigurationTask createAnnotationConfiguration() {
		checkConfiguration();
		configurationTask = new AnnotationConfigurationTask();
		return (AnnotationConfigurationTask) configurationTask;			
	}
	
	public GeneratorTask createHbm2DDL() {
		GeneratorTask generator = new Hbm2DDLGeneratorTask(this);
		generators.add(generator);
		
		return generator;
	}
	
	public GeneratorTask createHbm2Java() {
		GeneratorTask generator = new Hbm2JavaGeneratorTask(this);
		generators.add(generator);
		return generator;
	}
	
    public GeneratorTask createCfg2Hbm() {
        GeneratorTask generator= new Cfg2HbmGeneratorTask(this);
        generators.add(generator);
        return generator;
    }
    
	/**
     * Set the classpath to be used when running the Java class
     *
     * @param s an Ant Path object containing the classpath.
     */
    public void setClasspath(Path s) {
		classPath = s;
    }

    /**
     * Adds a path to the classpath.
     *
     * @return created classpath
     */
    public Path createClasspath() {
		classPath = new Path(getProject());
		return classPath;
    }

	
	public void execute() {
		validateParameters();
        Iterator iterator = generators.iterator();
        
		AntClassLoader loader = project.createClassLoader(classPath);
		try {
        loader.setParent(project.getCoreLoader());
        loader.setThreadContextLoader();
        
		int count = 1;
        while (iterator.hasNext()) {
			GeneratorTask generatorTask = (GeneratorTask) iterator.next();
			log(count++ + ". task: " + generatorTask.getName());
			generatorTask.execute();			
		}
		} finally {
			if (loader != null) {
                loader.resetThreadContextLoader();
                loader.cleanup();
            }            
		}
	}

	private void validateParameters() {
		Iterator iterator = generators.iterator();
        
        while (iterator.hasNext()) {
			GeneratorTask generatorTask = (GeneratorTask) iterator.next();
			generatorTask.validateParameters();			
		}
		
	}

	/**
	 * @return
	 */
	public File getDestDir() {
		return destDir;
	}
	
	public void setDestDir(File file) {
		destDir = file;
	}

	/**
	 * @return
	 */
	public Configuration getConfiguration() {
		return configurationTask.getConfiguration();
	}

	public Path getTemplatePath() {
		if(templatePath==null) {
			templatePath = new Path(getProject());
		}
		return templatePath;
	}
}
