/*
 * Created on 15-Feb-2005
 *
 */
package org.hibernate.tool.ant;

import org.apache.tools.ant.BuildException;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.JDBCMetaDataConfiguration;
import org.hibernate.cfg.reveng.ConfigurableReverseNamingStrategy;
import org.hibernate.cfg.reveng.ReverseNamingStrategy;

/**
 * @author max
 * @author <a href='mailto:the_mindstorm@evolva.ro'>Alexandru Popescu</a>
 */
public class JDBCConfigurationTask extends ConfigurationTask {
    private boolean preferRawCompositeIds = false;
    private boolean generateDynamicClasses = false;
    private String reverseNamingStrategyClass;
    private String packageName;
    private ReverseNamingStrategy reverseNamingStrategy;
    
	protected Configuration createConfiguration() {
		return new JDBCMetaDataConfiguration();
	}
	
	/* (non-Javadoc)
	 * @see org.hibernate.tool.hbm2x.ant.ConfigurationTask#doConfiguration(org.hibernate.cfg.Configuration)
	 */
	protected void doConfiguration(Configuration configuration) {
		JDBCMetaDataConfiguration jmdc = (JDBCMetaDataConfiguration) configuration;
		super.doConfiguration(jmdc);
		
        jmdc.setPreferRawCompositeIds(preferRawCompositeIds);
        jmdc.setGeneratingDynamicClasses(generateDynamicClasses);
        
        if(null != packageName) {
            ((ConfigurableReverseNamingStrategy) reverseNamingStrategy).setPackageName(packageName);
        }
        jmdc.setReverseNamingStrategy(reverseNamingStrategy);
        
		jmdc.readFromJDBC(); // TODO: need to allow configuraiton of oracle stuff!
	}

    /**
     * Custom validation:
     * - check if reverseNamingStrategyClass is an implementation of ReverseNamingStrategy
     * - check if reverseNamingStrategyClass has a no-args constructor
     * - check if packageName specified and reverseNamingStrategy supports setting a package name
     * 
     * @see org.hibernate.tool.ant.ConfigurationTask#validateParameters()
     */
    protected void validateParameters() throws BuildException {
        super.validateParameters();
        
        if (null == reverseNamingStrategyClass) {
            reverseNamingStrategy = new ConfigurableReverseNamingStrategy(); 
        } else {
            reverseNamingStrategy = loadReverseNamingStrategy(reverseNamingStrategyClass);
        }
        if (null != packageName 
                && !(reverseNamingStrategy instanceof ConfigurableReverseNamingStrategy)) {
            throw new BuildException("reverseNamingStrategy " 
                    + reverseNamingStrategy.getClass().getName()
                    + " does not support setting packageName");
        }
    }
    
    public void setPackageName(String pkgName) {
        packageName = pkgName;
    }
    
    public void setNamingStrategy(String fqn) {
        reverseNamingStrategyClass = fqn;
    }
    
    private ReverseNamingStrategy loadReverseNamingStrategy(final String className) 
    throws BuildException {
        try {
            Class clazz = Class.forName(className);
            return (ReverseNamingStrategy) clazz.newInstance();
        } catch(ClassNotFoundException cnfe) {
            throw new BuildException("Cannot load reverseNamingStrategy " + className, cnfe);
        } catch(InstantiationException ie) {
            ie.printStackTrace();
            throw new BuildException("reverseNamingStrategy " + className + " has not a no-args constructor");
        } catch(IllegalAccessException iae) {
            iae.printStackTrace();
            throw new BuildException("reverseNamingStrategy " + className + " has not a public no-args constructor");
        }
    }
}
