package test;

import java.util.Date;

public class User {
  private String createdBy;
  private Date createDate;
  private String updatedBy;
  private Date updateDate;
 
  public User() {
  }
  public User(String cb, Date cd, String ub, Date ud) {
    createdBy = cb;
    createDate = cd;
    updatedBy = ub;
    updateDate = ud;
  }
  public String getCreatedBy() {
    return createdBy;
  }
  public void setCreatedBy(String cb) {
    createdBy = cb;
  }
  public Date getCreateDate() {
    return createDate;
  }
  public void setCreateDate(Date cd) {
    createDate = cd;
  }
  public String getUpdatedBy() {
    return updatedBy;
  }
  public void setUpdatedBy(String ub) {
    updatedBy = ub;
  }
  public Date getUpdateDate() {
    return updateDate;
  }
  public void setUpdateDate(Date ud) {
    updateDate = ud;
  }

  public String toString() {
    StringBuffer buffer = new StringBuffer();
    buffer.append(getClass().getName()).append("@").append(Integer.toHexString(hashCode())).append(" [");
    buffer.append("createdBy").append("='").append(getCreatedBy()).append("' ");
    buffer.append("createDate").append("='").append(getCreateDate()).append("' ");
    buffer.append("updatedBy").append("='").append(getUpdatedBy()).append("' ");
    buffer.append("updateDate").append("='").append(getUpdateDate()).append("' ");
    buffer.append("]");
    return buffer.toString();
  }
}

