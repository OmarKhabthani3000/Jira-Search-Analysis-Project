package test;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Struct;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Connection;
import java.util.Date;
import java.io.Serializable;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;
import org.hibernate.HibernateException;
import org.hibernate.usertype.UserType;
import test.User;

public class UserUserType implements UserType, Serializable {
  private User user;
  private static final String DB_OBJECT_TYPE = "USER_TY";
  private static final int SQL_TYPE = Types.STRUCT;

  public UserUserType() {
  }

  public UserUserType(User u) {
    user = u;
  }

  public int [] sqlTypes() {
    return new int [] { SQL_TYPE };
  }

  public Class returnedClass() {
    return User.class;
  }

  public User getUser() {
    return user;
  }

  public boolean equals(Object o1, Object o2) throws HibernateException {
    if (o1 == o2){
      return true;
    }
    if (o1 == null || o2 == null) {
      return false;
    }
    final User user1 = (User) o1;
    final User user2 = (User) o2;
    return equals(user1.getCreatedBy(), user2.getCreatedBy())
      && equals(user1.getUpdatedBy(), user2.getUpdatedBy())
      && equals(user1.getUpdateDate(), user2.getUpdateDate())
      && equals(user1.getUpdateDate(), user2.getUpdateDate());
  }

  private boolean equals(final String s1, final String s2) {
    if (null == s1 && null == s2) {
      return true;
    }
    return null == s1 ? false : 0 == s1.compareTo(s2);
  }

  private boolean equals(final Date date1, final Date date2) {
    if (date1 == date2) {
      return true;
    }
    if (date1 != null && date2 != null) {
      return date1.equals(date2);
    }
    return false;
  }

  public Object nullSafeGet(ResultSet resultSet, String[] names, Object owner) 
    throws HibernateException, SQLException {
    assert 1 == names.length;
    final Struct struct = (Struct) resultSet.getObject(names[0]);
    if (resultSet.wasNull()) {
      return null;
    }
    final User user = new User();
    user.setCreatedBy((String) struct.getAttributes()[0]);
    user.setCreateDate((Date)  struct.getAttributes()[1]);
    user.setUpdatedBy((String) struct.getAttributes()[2]);
    user.setUpdateDate((Date)  struct.getAttributes()[3]);
    return user;
  }

  public void nullSafeSet(PreparedStatement statement, Object value, int index)
    throws HibernateException, SQLException {
    if (null == value) {
      statement.setNull(index, SQL_TYPE, DB_OBJECT_TYPE);
    } 
    else {
      final User user = (User) value;
      final Object[] values = new Object[] {
      user.getCreatedBy(), convertDate(user.getCreateDate()),
      user.getUpdatedBy(), convertDate(user.getUpdateDate())};
      final Connection connection = statement.getConnection();
      final STRUCT struct = new STRUCT(
        StructDescriptor.createDescriptor(DB_OBJECT_TYPE, connection),
        connection, 
        values
      );
      statement.setObject(index, struct, SQL_TYPE);
    }
  }

  public java.sql.Date convertDate(Date date) {
    return date == null ? null : new java.sql.Date(date.getTime());
  }

  public Object deepCopy(Object value) throws HibernateException {
    if (null == value) {
      return null;
    }
    final User user = (User) value;
    final User clone = new User();
    clone.setCreateDate(user.getCreateDate());
    clone.setCreatedBy(user.getCreatedBy());
    clone.setUpdateDate(user.getUpdateDate());
    clone.setUpdatedBy(user.getUpdatedBy());
    return clone;
  }

  public boolean isMutable() {
    return true;
  }

  public Serializable disassemble(Object o) throws HibernateException {
    return (Serializable) deepCopy(o);
  }

  public Object assemble(Serializable s, Object o) throws HibernateException {
    return deepCopy(s);
  }

  public Object replace(Object o, Object o1, Object o2) throws HibernateException {
    return (UserUserType)o;
  }

  public int hashCode(Object o) throws HibernateException {
    return ((UserUserType)o).hashCode();
  }
}

