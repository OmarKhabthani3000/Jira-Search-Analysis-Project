package test;

import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Date;

import org.hibernate.cfg.Configuration;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.MappingException;
import org.hibernate.HibernateException;

import persistence.*;
import test.*;

public class TestPerson {
  public static void testCreatePerson(String name, User user)
    throws MappingException, HibernateException {
    Session session = HibernateUtil.getSessionFactory().openSession();
    Transaction tx = null;
    try {
      Person person = new Person(name, 33, user);
      tx = session.beginTransaction();
      session.save(person);
      System.out.println("Created person: " + person);
      tx.commit();
    }
    catch (HibernateException he) {
      System.out.println("***he.getMessage(): " + he.getMessage());
      he.printStackTrace();
      if (null != tx) {
        tx.rollback();
        throw he;
      }
    }
    finally {
      session.close();
    }
  } 

  public static void testLookupPerson(String name) {
    System.out.println(">>>testLookupPerson(" + name + ")");
    Session session = HibernateUtil.getSessionFactory().openSession();
    Transaction tx = null;
    try {
      tx = session.beginTransaction();
      List list = session.getNamedQuery("getPersonByName")
        .setString("name", name)
        .list();
      tx.commit();
      for (Iterator i = list.iterator(); i.hasNext(); ) {
        Person p = (Person) i.next();
        System.out.println("Found person: " + p);
      }
    }
    catch (HibernateException he) {
      System.out.println("***he.getMessage(): " + he.getMessage());
      he.printStackTrace();
      if (null != tx) {
        tx.rollback();
        throw he;
      }
    }
    finally {
      session.close();
    }
  }

  public static void main ( String[] args ) { 
    try {
      User u = new User("a", new Date(), "aaa", new Date());
      testCreatePerson("larry", u);
      u = new User("b", new Date(), "bbb", new Date());
      testCreatePerson("harry", u);
      u = new User("c", new Date(), "ccc", new Date());
      testCreatePerson("shane", u);
      testLookupPerson("arr");
      HibernateUtil.shutdown();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}

