To see the problem, execute "ant codegen" from within this directory.

This will create, among other things, the file:
src/com/oreilly/hh/data/Track.java

In that file, the sourceMedia property should have the type
com.oreilly.hh.SourceMedia, but instead gets the type
com.oreilly.hh.SourceMediaType (the UserType that handles its mapping).

Similarly, the volume property should have the type
com.oreilly.hh.StereoVolume, but instead gets the type
com.oreilly.hh.StereoVolumeType.

If it is any help, this problem did *not* occur when we were trying to use
the Hibernate tools having directly downloaded them and expanded them into
the lib directory. The problem occurs, however, when trying to use the
Maven Ant Tasks to automatically obtain them as dependencies.
