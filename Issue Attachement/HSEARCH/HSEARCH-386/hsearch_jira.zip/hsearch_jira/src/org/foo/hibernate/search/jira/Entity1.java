/*
 * Projet  : hsearch_xxxx
 * 
 * Cree le : 24 févr. 2009
 * Package : org.foo.hibernate.search.jira
 * 
 */
package org.foo.hibernate.search.jira;

import java.io.Serializable;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Version;


/**
 * Entite 1
 *
 * @author grolland
 * 
 */
@javax.persistence.Entity
@org.hibernate.annotations.Proxy(lazy = false)
@org.hibernate.annotations.Cache(usage = org.hibernate.annotations.CacheConcurrencyStrategy.READ_WRITE)
@javax.persistence.Table(name = "entity1")
public class Entity1 implements Serializable
{

    /**
     * Commentaire pour <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = -3191273589083411349L;

    /**
     * Identifiant unique
     */
    @Id
    @GeneratedValue(generator = "ids_generator", strategy = GenerationType.SEQUENCE)
    private long              uid;

    /**
     * Controle de version optimiste
     */
    @Version
    private int               optlock;

    @javax.persistence.OneToMany(mappedBy = "entity1", cascade={})
    @org.hibernate.search.annotations.ContainedIn
    @org.hibernate.annotations.Cache(usage = org.hibernate.annotations.CacheConcurrencyStrategy.READ_WRITE)
    private java.util.List<Entity2> entities2 = new java.util.ArrayList<Entity2>();
    
    /**
     * Getter de l'attribut uid
     * @return long : Renvoie uid.
     */
    public long getUid()
    {
        return uid;
    }

    /**
     * Setter de l'attribut uid
     * @param uid uid a definir.
     */
    public void setUid(long uid)
    {
        this.uid = uid;
    }

    /**
     * Getter de l'attribut optlock
     * @return int : Renvoie optlock.
     */
    public int getOptlock()
    {
        return optlock;
    }

    /**
     * Setter de l'attribut optlock
     * @param optlock optlock a definir.
     */
    public void setOptlock(int optlock)
    {
        this.optlock = optlock;
    }

    /**
     * Setter de l'attribut entities2
     * @param entities2 entities2 a definir.
     */
    public void setEntities2(java.util.List<Entity2> entities2)
    {
        this.entities2 = entities2;
    }

    /**
     * Getter de l'attribut entities2
     * @return java.util.List<Entity2> : Renvoie entities2.
     */
    public java.util.List<Entity2> getEntities2()
    {
        return entities2;
    }
    
}
