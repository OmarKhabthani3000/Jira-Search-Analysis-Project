/*
 * Projet  : hsearch_xxxx
 * 
 * Cree le : 24 févr. 2009
 * Package : org.foo.hibernate.search.jira
 * 
 */
package org.foo.hibernate.search.jira;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Version;

/**
 * 
 * Entite 2
 *
 * @author grolland
 *
 */
@javax.persistence.Entity
@org.hibernate.annotations.Proxy(lazy = false)
@org.hibernate.annotations.Cache(usage = org.hibernate.annotations.CacheConcurrencyStrategy.READ_WRITE)
@javax.persistence.Table(name = "entity2")
@org.hibernate.search.annotations.Indexed
public class Entity2
{
    /**
     * Commentaire pour <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = -3191273589083411349L;

    /**
     * Identifiant unique
     */
    @Id
    @GeneratedValue(generator = "ids_generator", strategy = GenerationType.SEQUENCE)
    private long              uid;

    /**
     * Controle de version optimiste
     */
    @Version
    private int               optlock;

    @javax.persistence.ManyToOne(cascade={} , fetch = javax.persistence.FetchType.LAZY)
    @org.hibernate.search.annotations.IndexedEmbedded()
    @org.hibernate.annotations.Cache(usage = org.hibernate.annotations.CacheConcurrencyStrategy.READ_WRITE)
    private Entity1 entity1;
    
    /**
     * Getter de l'attribut uid
     * @return long : Renvoie uid.
     */
    public long getUid()
    {
        return uid;
    }

    /**
     * Setter de l'attribut uid
     * @param uid uid a definir.
     */
    public void setUid(long uid)
    {
        this.uid = uid;
    }

    /**
     * Getter de l'attribut optlock
     * @return int : Renvoie optlock.
     */
    public int getOptlock()
    {
        return optlock;
    }

    /**
     * Setter de l'attribut optlock
     * @param optlock optlock a definir.
     */
    public void setOptlock(int optlock)
    {
        this.optlock = optlock;
    }

    /**
     * Setter de l'attribut entity1
     * @param entity1 entity1 a definir.
     */
    public void setEntity1(Entity1 entity1)
    {
        this.entity1 = entity1;
    }

    /**
     * Getter de l'attribut entity1
     * @return Entity1 : Renvoie entity1.
     */
    public Entity1 getEntity1()
    {
        return entity1;
    }
}
