/*
 * Projet  : hsearch_xxxx
 * 
 * Cree le : 24 févr. 2009
 * Package : org.foo.hibernate.search.jira
 * 
 */
package org.foo.hibernate.search.jira;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Launch Test
 *
 * @author grolland
 * 
 */
public class Boot
{

    /**
     * @param args
     */
    public static void main(String[] args)
    {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("local");
        
        EntityManager em = emf.createEntityManager();
        
        Entity1 ent1_0 = new Entity1();
        Entity1 ent1_1 = new Entity1();
        
        Entity2 ent2_0   = new Entity2();
        Entity2 ent2_1   = new Entity2();
        
        ent2_0.setEntity1(ent1_0);
        ent1_0.getEntities2().add(ent2_0);
        
        ent2_1.setEntity1(ent1_1);
        ent1_1.getEntities2().add(ent2_1);
        
        em.persist(ent1_0);
        em.persist(ent1_1);
        em.persist(ent2_0);
        em.persist(ent2_1);
        
        em.getTransaction().begin();
        em.getTransaction().commit();
        em.clear();
        em.close();
        em = null;
        
        em = emf.createEntityManager();
        
        Entity1 other = new Entity1();
        em.persist(other);

        long id = other.getUid();
        
        em.getTransaction().begin();
        em.getTransaction().commit();
        em.clear();
        em.close();
        em = null;
        
        em = emf.createEntityManager();
        
        Entity1 toDelete = em.find(Entity1.class, id);
        
        em.remove(toDelete);
        
        em.getTransaction().begin();
        em.getTransaction().commit();
        em.clear();
        em.close();
        em = null;
        
        emf.close();
    }

}
