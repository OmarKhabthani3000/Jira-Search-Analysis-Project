package org.mycompany.hibernate.search;

public class MySubClass extends MyClass {

  private static final long serialVersionUID = -5448802364821646971L;
  protected long dbid;
  
  private int field3;

  protected MySubClass() {}

  public MySubClass(String field1, String field2, int field3) {
    super(field1, field2);
    this.field3 = field3;
  }

  public int getField3() {
    return field3;
  }

  public void setField3(int field3) {
    this.field3 = field3;
  }

  // Uncomment these lines
//  public String getField1() {
//    return super.getField1();
//  }
//
//  public String getField2() {
//    return super.getField2();
//  }

}
