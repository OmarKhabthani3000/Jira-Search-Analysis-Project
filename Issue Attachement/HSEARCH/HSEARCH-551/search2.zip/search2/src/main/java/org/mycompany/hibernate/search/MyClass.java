package org.mycompany.hibernate.search;

import java.io.Serializable;

public class MyClass implements Serializable {

  private static final long serialVersionUID = 3659134332754833157L;
  protected long dbid;

  private String field1;
  private String field2;

  protected MyClass() {}

  public MyClass(String field1, String field2) {
    super();
    this.field1 = field1;
    this.field2 = field2;
  }

  public long getDbid() {
    return dbid;
  }

  public void setDbid(long dbid) {
    this.dbid = dbid;
  }

  public String getField1() {
    return field1;
  }

  public void setField1(String field1) {
    this.field1 = field1;
  }

  public String getField2() {
    return field2;
  }

  public void setField2(String field2) {
    this.field2 = field2;
  }

}
