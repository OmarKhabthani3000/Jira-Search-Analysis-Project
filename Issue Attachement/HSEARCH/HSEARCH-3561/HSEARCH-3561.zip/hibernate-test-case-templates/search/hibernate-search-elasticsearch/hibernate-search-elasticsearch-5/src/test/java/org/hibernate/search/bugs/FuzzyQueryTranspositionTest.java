package org.hibernate.search.bugs;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.elasticsearch.ElasticsearchQueries;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.query.engine.spi.QueryDescriptor;
import org.hibernate.search.testsupport.TestForIssue;
import org.junit.After;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;

public class FuzzyQueryTranspositionTest extends SearchTestBase {

    @Override
    public Class<?>[] getAnnotatedClasses() {
        return new Class<?>[]{YourAnnotatedEntity.class};
    }

    @Test
    @TestForIssue(jiraKey = "HSEARCH-3561")
    @SuppressWarnings("unchecked")
    public void testBuildESQueryWithTranspositionsAllowed() {
        try (Session s = getSessionFactory().openSession()) {
            YourAnnotatedEntity yourEntity1 = new YourAnnotatedEntity(1L, "example");

            Transaction tx = s.beginTransaction();
            s.persist(yourEntity1);
            tx.commit();

            FullTextSession session = Search.getFullTextSession(s);
            QueryBuilder qb = session.getSearchFactory().buildQueryBuilder().forEntity(YourAnnotatedEntity.class).get();

            int editDistance = 1;  // allow 1 'fuzziness'
            int prefixLength = 1;  // no fuzziness on 1st char

            // "exampel" matches "example" when transpositions are allowed (set to true)
            String field = "name";
            String term = "exampel";

            // In a Fuzzy Query, the transposition parameter doesn't get used when building the Elasticsarch query
            Query query = new FuzzyQuery(new Term(field, term), editDistance, prefixLength, FuzzyQuery.defaultMaxExpansions, true);

            List<YourAnnotatedEntity> result = (List<YourAnnotatedEntity>) session.createFullTextQuery(query).list();
            assertEquals(1, result.size());
            assertEquals(1l, (long) result.get(0).getId());
        }
    }

    @After
    public void deleteTestData() {
        try (Session s = getSessionFactory().openSession()) {
            FullTextSession session = Search.getFullTextSession(s);
            Transaction tx = s.beginTransaction();

            QueryDescriptor query = ElasticsearchQueries.fromJson("{ 'query': { 'match_all' : {} } }");
            List<?> result = session.createFullTextQuery(query, YourAnnotatedEntity.class).list();

            for (Object entity : result) {
                session.delete(entity);
            }

            tx.commit();
        }
    }

}
