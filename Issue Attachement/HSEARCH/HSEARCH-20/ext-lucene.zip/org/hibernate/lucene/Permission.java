/**
 * User: alesj
 * Date: 7.11.2005
 * Time: 12:17:58
 * 
 * (C) Genera Lynx d.o.o.
 */

package org.hibernate.lucene;

import java.lang.annotation.*;

/**
 * Useful for some sort of Security Lucene filtering.
 * @see org.apache.lucene.search.Filter
 *
 *     public BitSet bits(IndexReader reader) throws IOException {
 *         BitSet bits = new BitSet(reader.maxDoc());
 *         String fieldName = ExtendedDocumentBuilder.PERMISSION_FIELD_NAME;
 *         TermDocs td = reader.termDocs(new Term(fieldName, permission));
 *         while(td.next()) {
 *             bits.set(td.doc());
 *         }
 *         return bits;
 *     }
 *
 * @author <a href="mailto:ales.justin@genera-lynx.com">Ales Justin</a>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Documented
public @interface Permission {

    String permission();

}
