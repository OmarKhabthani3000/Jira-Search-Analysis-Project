/**
 * User: alesj
 * Date: 9.11.2005
 * Time: 12:17:57
 * 
 * (C) Genera Lynx d.o.o.
 */

package org.hibernate.lucene;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.Term;
import org.hibernate.AssertionFailure;
import org.hibernate.HibernateException;
import org.hibernate.util.StringHelper;

import javax.persistence.Id;
import java.io.File;
import java.io.Serializable;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Extended basic DocumentBuilder with some useful Lucene capabilities.
 * Looking for boosting on a class (eq. to document boosting)
 * and method (eq. to field boosting) level.
 * Setting Analyzer class for each entity.
 * Adding permission keywords (@see Permission) for filter usage.
 * Additional DateField annotation for better date field handling.
 * Using additional entity data (@see EntityField), as well as mapping entities
 * by their entity name instead of class name. 
 *
 * @author <a href="mailto:ales.justin@genera-lynx.com">Ales Justin</a>
 */
public class ExtendedDocumentBuilder<T> {

    private static final Log logger = LogFactory.getLog(ExtendedDocumentBuilder.class);

    public static final String IDENTITY_FIELD_NAME = "identity";
    public static final String ID_FIELD_NAME = "id_value";
    public static final String ENTITY_FIELD_NAME = "entity_name";
    public static final String PERMISSION_FIELD_NAME = "permission";

    private final List<Member> keywordGetters = new ArrayList<Member>();
    private final List<String> keywordNames = new ArrayList<String>();
    private final List<Member> unstoredGetters = new ArrayList<Member>();
    private final List<String> unstoredNames = new ArrayList<String>();
    private final List<Member> textGetters = new ArrayList<Member>();
    private final List<String> textNames = new ArrayList<String>();

    private boolean useEntityField;
    private String entityName;
    private String idKeywordName;
    private float boost = 1.0f;
    private Set<String> permissions = new HashSet<String>();

    private final File file;
    private Analyzer analyzer;

    public ExtendedDocumentBuilder(String entityName, Class<T> clazz) {
        this.entityName = entityName;
        String fileName = getTypeName(clazz, clazz.getAnnotation(Indexed.class).index());
        file = new File(fileName);
        EntityField entityField = clazz.getAnnotation(EntityField.class);
        if (entityField != null) {
            useEntityField = entityField.useEntityField();
        }

        for (Class<T> currClass = clazz; currClass != null; currClass = (Class<T>)currClass.getSuperclass()) {

            org.hibernate.lucene.Analyzer analyzerAnn = currClass.getAnnotation(org.hibernate.lucene.Analyzer.class);
            if (analyzerAnn != null && analyzer == null) {
                try {
                    analyzer = analyzerAnn.analyzerClass().newInstance();
                } catch (Exception e) {
                    throw new HibernateException(e);
                }
            }

            Permission p = currClass.getAnnotation(Permission.class);
            if (p != null) {
                permissions.add(p.permission());
            }

            Permissions ps = currClass.getAnnotation(Permissions.class);
            if (ps != null) {
                permissions.addAll(Arrays.asList(ps.permission()));
            }

            Boost boostAnn = currClass.getAnnotation(Boost.class);
            if (boostAnn != null) {
                boost *= boostAnn.boost();
            }

            Method[] methods = currClass.getDeclaredMethods();
            for (Method method : methods) {
                Id idAnn = method.getAnnotation(Id.class);
                if (idAnn != null && useEntityField) {
                    warnIdKeyname(method);
                    idKeywordName = ID_FIELD_NAME;
                }
                Keyword keywordAnn = method.getAnnotation(Keyword.class);
                if (keywordAnn != null) {
                    String name = getAttributeName(method, keywordAnn.name());
                    if (keywordAnn.id()) {
                        warnIdKeyname(method);
                        idKeywordName = name;
                    } else {
                        keywordGetters.add(method);
                        keywordNames.add(name);
                    }
                }
                Unstored unstoredAnn = method.getAnnotation(Unstored.class);
                if (unstoredAnn != null) {
                    unstoredGetters.add(method);
                    unstoredNames.add(getAttributeName(method, unstoredAnn.name()));
                }
                Text textAnn = method.getAnnotation(Text.class);
                if (textAnn != null) {
                    textGetters.add(method);
                    textNames.add(getAttributeName(method, textAnn.name()));
                }
            }
        }

        if (idKeywordName == null) {
            throw new HibernateException("No id Keyword for: " + clazz.getName());
        }
    }

    private void warnIdKeyname(Member m) {
        if (idKeywordName != null) {
            logger.warn("Overridding idKeyname in " + m);
        }
    }

    private Object getValue(Member member, T bean) {
        try {
            if (member instanceof java.lang.reflect.Field) {
                return ((java.lang.reflect.Field)member).get(bean);
            } else if (member instanceof Method) {
                return ((Method)member).invoke(bean);
            } else {
                throw new AssertionFailure("Unexpected member: " + member.getClass().getName());
            }
        }
        catch (Exception e) {
            throw new IllegalStateException("Could not get property value", e);
        }
    }

    public Document getDocument(T instance, Serializable id) {
        Document doc = new Document();
        doc.add(Field.Keyword(idKeywordName, id.toString()));
        if (useEntityField) {
            doc.add(Field.Keyword(ENTITY_FIELD_NAME, entityName));
            doc.add(Field.Keyword(IDENTITY_FIELD_NAME, createIdentityString(id)));
        }
        doc.setBoost(boost);
        if (!permissions.isEmpty()) {
            doc.add(Field.UnStored(
                    PERMISSION_FIELD_NAME,
                    StringHelper.join(",", permissions.iterator()))
            );
        }

        for (int i = 0; i < keywordNames.size(); i++) {
            Member member = keywordGetters.get(i);
            Object value = getValue(member, instance);
            if (value != null) {
                Field field = null;
                if (value instanceof Date) {
                    Date date = (Date)value;
                    AnnotatedElement ae = (AnnotatedElement)member;
                    DateField df = ae.getAnnotation(DateField.class);
                    if (df != null) {
                        if (df.convert()) {
                            DateFormat format = new SimpleDateFormat(df.format());
                            field = Field.Keyword(keywordNames.get(i), format.format(date));
                        } else {
                            field = Field.Keyword(keywordNames.get(i), date);
                        }
                    }
                } else {
                    field = Field.Keyword(keywordNames.get(i), toString(value));
                }
                addField(member, field, doc);
            }
        }

        for (int i = 0; i < textNames.size(); i++) {
            Member member = textGetters.get(i);
            Object value = getValue(member, instance);
            if (value != null) {
                Field field = Field.Text(textNames.get(i), toString(value));
                addField(member, field, doc);
            }
        }

        for (int i = 0; i < unstoredNames.size(); i++) {
            Member member = unstoredGetters.get(i);
            Object value = getValue(member, instance);
            if (value != null) {
                Field field = Field.UnStored(unstoredNames.get(i), toString(value));
                addField(member, field, doc);
            }
        }

        return doc;
    }

    private void addField(Member member, Field field, Document doc) {
        Float bf = getBoost(member);
        if (bf != null) {
            field.setBoost(bf);
        }
        doc.add(field);
    }

    private static Float getBoost(Member member) {
        AnnotatedElement ae = (AnnotatedElement)member;
        Boost boostAnn = ae.getAnnotation(Boost.class);
        return boostAnn != null ? boostAnn.boost() : null;
    }

    private static String toString(Object value) {
        return value.toString();
    }

    private String createIdentityString(Serializable id) {
        return (entityName + "#" + id);
    }

    public Term getTerm(Serializable id) {
        if (useEntityField) {
            return new Term(IDENTITY_FIELD_NAME, createIdentityString(id));
        } else {
            return new Term(idKeywordName, id.toString());
        }
    }

    private static String getAttributeName(Method method, String name) {
        if (name != null && !"".equals(name)) {
            return name;
        } else {
            String subName = method.getName().substring(3);
            char[] chars = subName.toCharArray();
            chars[0] = Character.toLowerCase(chars[0]);
            return new String(chars);
        }
    }

    private static String getTypeName(Class clazz, String name) {
        return "".equals(name) ? clazz.getName() : name;
    }

    public File getFile() {
        return file;
    }

    public Analyzer getAnalyzer() {
        if (analyzer == null) {
            analyzer = new StandardAnalyzer();
        }
        return analyzer;
    }

}
