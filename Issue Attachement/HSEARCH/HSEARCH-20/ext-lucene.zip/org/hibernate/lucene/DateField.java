/**
 * User: alesj
 * Date: 7.11.2005
 * Time: 12:17:58
 * 
 * (C) Genera Lynx d.o.o.
 */

package org.hibernate.lucene;

import java.lang.annotation.*;

/**
 * Used with keyword field for date range queries.
 * Only used on getters returning java.util.Date instance.
 * @see org.apache.lucene.document.Field#Keyword
 *
 * @author <a href="mailto:ales.justin@genera-lynx.com">Ales Justin</a>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Documented
public @interface DateField {

    /**
     * Convert to String.
     */
    boolean convert() default false;

    /**
     * Format used when converting to String.
     */
    String format() default "yyyyMMdd";

}
