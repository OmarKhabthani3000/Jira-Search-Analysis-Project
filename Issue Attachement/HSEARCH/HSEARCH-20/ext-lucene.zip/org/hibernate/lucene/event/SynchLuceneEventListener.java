/**
 * User: alesj
 * Date: 9.11.2005
 * Time: 12:19:59
 * 
 * (C) Genera Lynx d.o.o.
 */

package org.hibernate.lucene.event;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.hibernate.HibernateException;
import org.hibernate.cfg.Configuration;
import org.hibernate.event.*;
import org.hibernate.lucene.ExtendedDocumentBuilder;
import org.hibernate.lucene.Indexed;
import org.hibernate.mapping.PersistentClass;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * Synchronizing on Index writting and deleting.
 * Using <code>ExtendedDocumentBuilder</code> for handling entities.
 * @see ExtendedDocumentBuilder 
 *
 * @author <a href="mailto:ales.justin@genera-lynx.com">Ales Justin</a>
 */
public class SynchLuceneEventListener implements PostDeleteEventListener, PostInsertEventListener,
        PostUpdateEventListener, Initializable {

    private Map<String, ExtendedDocumentBuilder> documentBuilders = new HashMap<String, ExtendedDocumentBuilder>();
    private Map<File, IndexWriter> tmpWriterMap = new TreeMap<File, IndexWriter>();
    private final Object LOCK = new Object();

    private boolean initialized;

    private static final Log log = LogFactory.getLog(SynchLuceneEventListener.class);

    /**
     * No need to synchronize, since this is the only intialized once.
     * When used in multiple .par files, they are initialized sequentially.
     */
    public void initialize(Configuration cfg) {
        if (initialized) return;

        try {
            Iterator iter = cfg.getClassMappings();
            while (iter.hasNext()) {
                PersistentClass pc = (PersistentClass)iter.next();
                Class mappedClass = pc.getMappedClass();
                if (mappedClass != null) {
                    if (mappedClass.getAnnotation(Indexed.class) != null) {
                        String entityName = pc.getEntityName();
                        final ExtendedDocumentBuilder documentBuilder =
                                new ExtendedDocumentBuilder(entityName, mappedClass);
                        documentBuilders.put(entityName, documentBuilder);
                        File file = documentBuilder.getFile();
                        try {
                            IndexWriter iw = tmpWriterMap.get(file);
                            if (iw == null) {
                                iw = new IndexWriter(file, documentBuilder.getAnalyzer(), false);
                                tmpWriterMap.put(file, iw);
                            }
                        } catch (IOException ioe) {
                            throw new HibernateException(ioe);
                        }
                        log.info("index: " + documentBuilder.getFile().getAbsolutePath());
                    }
                }
            }
            initialized = true;
        } finally {
            for(IndexWriter iw : tmpWriterMap.values()) {
                try {
                    iw.close();
                } catch (IOException e) {
                    //ignored
                }
            }
            tmpWriterMap.clear();
            tmpWriterMap = null;
        }
    }

    public void onPostDelete(PostDeleteEvent event) {
        ExtendedDocumentBuilder builder = documentBuilders.get(event.getPersister().getEntityName());
        if (builder != null) {
            remove(builder, event.getId());
        }
    }

    public void onPostInsert(PostInsertEvent event) {
        final Object entity = event.getEntity();
        ExtendedDocumentBuilder builder = documentBuilders.get(event.getPersister().getEntityName());
        if (builder != null) {
            add(entity, builder, event.getId());
        }
    }

    public void onPostUpdate(PostUpdateEvent event) {
        final Object entity = event.getEntity();
        ExtendedDocumentBuilder builder = documentBuilders.get(event.getPersister().getEntityName());
        if (builder != null) {
            final Serializable id = event.getId();
            remove(builder, id);
            add(entity, builder, id);
        }
    }

    private void remove(ExtendedDocumentBuilder builder, Serializable id) {
        Term idTerm = builder.getTerm(id);
        log.debug("removing: " + idTerm);
        try {
            synchronized(LOCK) {
                IndexReader reader = null;
                try {
                    reader = IndexReader.open(builder.getFile());
                    reader.delete(idTerm);
                } finally {
                    if (reader != null) {
                        reader.close();
                    }
                }
            }
        } catch (IOException ioe) {
            throw new HibernateException(ioe);
        }
    }

    private void add(final Object entity, final ExtendedDocumentBuilder builder, final Serializable id) {
        Document doc = builder.getDocument(entity, id);
        log.debug("adding: " + doc);
        try {
            IndexWriter writer = null;
            synchronized(LOCK) {
                try {
                    writer = new IndexWriter(builder.getFile(), builder.getAnalyzer(), false);
                    writer.addDocument(doc);
                } finally {
                    if (writer != null) {
                        writer.close();
                    }
                }
            }
        } catch (IOException ioe) {
            throw new HibernateException(ioe);
        }
    }

}
