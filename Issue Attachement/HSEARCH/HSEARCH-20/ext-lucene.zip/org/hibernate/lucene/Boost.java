/**
 * User: alesj
 * Date: 7.11.2005
 * Time: 12:17:58
 * 
 * (C) Genera Lynx d.o.o.
 */

package org.hibernate.lucene;

import java.lang.annotation.*;

/**
 * Boosting documents and fields.
 * @see org.apache.lucene.document.Document#setBoost
 * @see org.apache.lucene.document.Field#setBoost
 *
 * @author <a href="mailto:ales.justin@genera-lynx.com">Ales Justin</a>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
@Documented
public @interface Boost {

    float boost() default 1.0f;

}
