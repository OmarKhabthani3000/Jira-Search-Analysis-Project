/**
 * User: alesj
 * Date: 21.11.2005
 * Time: 10:34:18
 * 
 * (C) Genera Lynx d.o.o.
 */

package org.hibernate.lucene;

import java.lang.annotation.*;

/**
 * Used when different entity classes are all in the same index file.
 * Useful to have entityName and id stored under constant keyword.
 *
 * doc.add(Field.Keyword(ENTITY_FIELD_NAME, entityName));
 * doc.add(Field.Keyword(IDENTITY_FIELD_NAME, createIdentityString(id)));
 *
 * @author <a href="mailto:ales.justin@genera-lynx.com">Ales Justin</a>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Documented
@Inherited
public @interface EntityField {

    boolean useEntityField() default true;

}
