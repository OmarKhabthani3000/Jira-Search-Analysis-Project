package org.hibernate.search.bugs.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * @author hummich
 * @since 07/05/2018
 */
@Entity
@DiscriminatorValue(Contact.SAMPLE_UNIT_CONTACT)
public class SampleUnitContact extends Contact {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SAMPLE_UNIT_ID")
    private SampleUnit sampleUnit;

    public SampleUnit getSampleUnit() {
        return this.sampleUnit;
    }

    public void setSampleUnit(final SampleUnit sampleUnit) {
        this.sampleUnit = sampleUnit;
    }

}
