package org.hibernate.search.bugs.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.List;

/**
 * @author hummich
 * @since 07/05/2018
 */
@Entity
public class SampleUnit {

    @Id
    private Long id;

    @OneToMany(cascade = CascadeType.PERSIST, mappedBy = "sampleUnit")
    private List<SampleUnitContact> sampleUnitContacts;

    public Long getId() {
        return this.id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public List<SampleUnitContact> getSampleUnitContacts() {
        return this.sampleUnitContacts;
    }

    public void setSampleUnitContacts(final List<SampleUnitContact> sampleUnitContacts) {
        this.sampleUnitContacts = sampleUnitContacts;
    }

}
