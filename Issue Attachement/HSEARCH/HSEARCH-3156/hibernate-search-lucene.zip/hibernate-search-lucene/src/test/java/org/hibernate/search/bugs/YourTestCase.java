package org.hibernate.search.bugs;

import org.apache.lucene.search.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.bugs.model.CaseContact;
import org.hibernate.search.bugs.model.Contact;
import org.hibernate.search.bugs.model.ContactInformation;
import org.hibernate.search.bugs.model.RegistryBasedCase;
import org.hibernate.search.bugs.model.SampleUnit;
import org.hibernate.search.bugs.model.SampleUnitContact;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.testsupport.TestForIssue;
import org.junit.Test;

import java.util.Collections;
import java.util.List;

import static junit.framework.TestCase.assertEquals;

public class YourTestCase extends SearchTestBase {

	@Override
	public Class<?>[] getAnnotatedClasses() {
		return new Class<?>[]{
			Contact.class,
            CaseContact.class,
            SampleUnitContact.class,
            RegistryBasedCase.class,
            SampleUnit.class,
            ContactInformation.class
		};
	}

	@Test
	@TestForIssue(jiraKey = "HSEARCH-3156")
	@SuppressWarnings("unchecked")
	public void testHSEARCH3156() {
	    // First example, shows a successful save with the model.
        this.happyPath();
        // Second example demonstrates the bug.
        this.errorPath();
	}

	void happyPath() {
        try (final Session s = this.getSessionFactory().openSession() ) {

            // Save a case and 1 associated contact information, via this path:
            // RegistryBasedCase --> List<CaseContact> --> List<ContactInformation>
            final RegistryBasedCase registryBasedCase = new RegistryBasedCase();
            registryBasedCase.setId(1L);
            final CaseContact caseContact = new CaseContact();
            caseContact.setId(1L);
            caseContact.setRegistryBasedCase(registryBasedCase);
            final ContactInformation contactInformation = new ContactInformation();
            contactInformation.setId(1L);
            contactInformation.setPhoneNumber("1234567890");

            contactInformation.setContact(caseContact);
            caseContact.setContactInformation(Collections.singletonList(contactInformation));
            registryBasedCase.setCaseContacts(Collections.singletonList(caseContact));


            final Transaction tx = s.beginTransaction();
            s.persist( registryBasedCase );
            tx.commit();

            final FullTextSession session = Search.getFullTextSession(s );
            final QueryBuilder qb = session.getSearchFactory().buildQueryBuilder().forEntity(RegistryBasedCase.class ).get();
            final Query query = qb.keyword().onField("caseContacts.contactInformation.phoneNumber" ).matching("1234567890" ).createQuery();

            final List<RegistryBasedCase> result = (List<RegistryBasedCase>) session.createFullTextQuery(query ).list();
            assertEquals( 1, result.size() );
            assertEquals( 1, (long) result.get( 0 ).getId() );
        }
    }

    void errorPath() {
        try (final Session s = this.getSessionFactory().openSession()) {

            // Save a Sample Unit that is not indexed and 1 associated contact information, via this path:
            // SampleUnit --> List<SampleUnitContact> --> List<ContactInformation>
            final SampleUnit sampleUnit = new SampleUnit();
            sampleUnit.setId(2L);
            final SampleUnitContact caseContact = new SampleUnitContact();
            caseContact.setId(2L);
            caseContact.setSampleUnit(sampleUnit);
            final ContactInformation contactInformation = new ContactInformation();
            contactInformation.setId(2L);
            contactInformation.setPhoneNumber("9876543210");

            contactInformation.setContact(caseContact);
            caseContact.setContactInformation(Collections.singletonList(contactInformation));
            sampleUnit.setSampleUnitContacts(Collections.singletonList(caseContact));

            final Transaction tx = s.beginTransaction();
            s.persist(sampleUnit);
            tx.commit();
        }
    }

}
