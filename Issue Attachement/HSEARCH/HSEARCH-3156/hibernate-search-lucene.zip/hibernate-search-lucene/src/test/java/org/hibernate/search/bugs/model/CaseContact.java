package org.hibernate.search.bugs.model;

import org.hibernate.search.annotations.ContainedIn;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * @author hummich
 * @since 07/05/2018
 */
@Entity
@DiscriminatorValue(Contact.CASE_CONTACT)
public class CaseContact extends Contact {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CASE_ID")
    @ContainedIn
    private RegistryBasedCase registryBasedCase;

    public RegistryBasedCase getRegistryBasedCase() {
        return this.registryBasedCase;
    }

    public void setRegistryBasedCase(final RegistryBasedCase registryBasedCase) {
        this.registryBasedCase = registryBasedCase;
    }

}
