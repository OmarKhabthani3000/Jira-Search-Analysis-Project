package org.hibernate.search.bugs.model;

import org.hibernate.search.annotations.IndexedEmbedded;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToMany;
import java.util.List;

/**
 * @author hummich
 * @since 07/05/2018
 */
@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "CONTACT_TYPE", discriminatorType = DiscriminatorType.INTEGER)
public abstract class Contact {

    public static final String CASE_CONTACT = "1";

    public static final String SAMPLE_UNIT_CONTACT = "2";

    @Id
    private Long id;

    @Column(name = "CONTACT_TYPE", updatable = false, nullable = false, insertable = false)
    private int contactType;

    @OneToMany(mappedBy = "contact", cascade = CascadeType.PERSIST)
    @IndexedEmbedded
    private List<ContactInformation> contactInformation;

    public Long getId() {
        return this.id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public List<ContactInformation> getContactInformation() {
        return this.contactInformation;
    }

    public void setContactInformation(final List<ContactInformation> contactInformation) {
        this.contactInformation = contactInformation;
    }

}
