package org.hibernate.search.bugs.model;

import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.List;

/**
 * @author hummich
 * @since 07/05/2018
 */
@Entity
@Indexed
public class RegistryBasedCase {

    @Id
    @DocumentId
    private Long id;

    @OneToMany(cascade = CascadeType.PERSIST, mappedBy = "registryBasedCase")
    @IndexedEmbedded
    private List<CaseContact> caseContacts;

    public Long getId() {
        return this.id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public List<CaseContact> getCaseContacts() {
        return this.caseContacts;
    }

    public void setCaseContacts(final List<CaseContact> caseContacts) {
        this.caseContacts = caseContacts;
    }

}
