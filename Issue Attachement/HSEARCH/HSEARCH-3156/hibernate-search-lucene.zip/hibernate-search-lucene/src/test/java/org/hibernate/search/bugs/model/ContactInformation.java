package org.hibernate.search.bugs.model;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * @author hummich
 * @since 07/05/2018
 */
@Entity
public class ContactInformation {

    @Id
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CONTACT_ID", nullable = false)
    @ContainedIn
    private Contact contact;

    @Column(name = "PHONE_NUMBER")
    @Field
    private String phoneNumber;

    public Long getId() {
        return this.id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public Contact getContact() {
        return this.contact;
    }

    public void setContact(final Contact contact) {
        this.contact = contact;
    }

    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    public void setPhoneNumber(final String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
