/*
 * Copied from org.hibernate.search.test.embedded.Author
 * Changed annotation of name field
 */

package org.hibernate.search.test.query.facet;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;

import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Fields;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.DocumentId;

@Entity
public class Author {
	@Id
	@GeneratedValue
	@DocumentId
	private Integer id;
	@Fields({@Field(index= Index.TOKENIZED), @Field(index= Index.UN_TOKENIZED, name="name_untokenized")})
	private String name;


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
