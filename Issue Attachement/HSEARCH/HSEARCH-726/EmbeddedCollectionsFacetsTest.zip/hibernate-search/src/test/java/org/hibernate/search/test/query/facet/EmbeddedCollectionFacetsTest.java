package org.hibernate.search.test.query.facet;

import java.util.List;

import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.query.facet.Facet;
import org.hibernate.search.query.facet.FacetSortOrder;
import org.hibernate.search.query.facet.FacetingRequest;
import org.hibernate.search.test.SearchTestCase;
import org.hibernate.search.test.query.facet.Author;
import org.hibernate.search.test.query.facet.Product;


/**
 * @author Elmer van Chastelet
 */

public class EmbeddedCollectionFacetsTest extends SearchTestCase {

	public void testFacetEmbeddedAndCollections() throws Exception {
		Author a = new Author();
		a.setName( "Voltaire" );
		Author a2 = new Author();
		a2.setName( "Victor Hugo" );
		Author a3 = new Author();
		a3.setName( "Moliere" );
		Author a4 = new Author();
		a4.setName( "Proust" );

		Product p1 = new Product();
		p1.setName( "Candide" );
		p1.getAuthors().add( a );
		p1.getAuthors().add( a2 ); // be creative

		Product p2 = new Product();
		p2.setName( "Candide" );
		p2.getAuthors().add( a2 );
		p2.getAuthors().add( a3 );
		
		Product p3 = new Product();
		p3.setName( "Candide" );
		p3.getAuthors().add( a2 );
		p3.getAuthors().add( a3 );

		Session s = openSession();
		Transaction tx = s.beginTransaction();
		s.persist( a );
		s.persist( a2 );
		s.persist( a3 );
		s.persist( a4 );
		s.persist( p1 );
		s.persist( p2 );
		s.persist( p3 );
		tx.commit();

		s.clear();

		FullTextSession session = Search.getFullTextSession( s );
		tx = session.beginTransaction();

		QueryParser parser = new MultiFieldQueryParser( getTargetLuceneVersion(), new String[] { "name" }, SearchTestCase.standardAnalyzer );
		Query query;
		FullTextQuery ftq;
		QueryBuilder builder;
		List<Facet> facets;

		query = parser.parse( "Candide" );
		ftq = session.createFullTextQuery( query, Product.class );
		FacetingRequest facetReq;
		

		builder = session.getSearchFactory().buildQueryBuilder().forEntity( Product.class ).get();
		facetReq = builder.facet().name("someFacet").onField("authors.name_untokenized")
		.discrete().orderedBy(FacetSortOrder.COUNT_DESC)
		.includeZeroCounts(false).maxFacetCount(10)
		.createFacetingRequest();
		facets = ftq.getFacetManager().enableFaceting(facetReq).getFacets("someFacet");
		
		assertEquals( "error in collecting facets on embedded collections, wrong number of facets", 3, facets.size() );
		for(Facet f : facets){
			if(f.getValue().equals(a.getName()))
				assertEquals( "error in collecting facets on embedded collections (Author a)", 1, f.getCount() );
			if(f.getValue().equals(a2.getName()))
				assertEquals( "error in collecting facets on embedded collections (Author a2)", 3, f.getCount() );
			if(f.getValue().equals(a3.getName()))
				assertEquals( "error in collecting facets on embedded collections (Author a3)", 2, f.getCount() );
		}


		tx.commit();

		s.clear();
		s.close();
	}

	protected void configure( org.hibernate.cfg.Configuration cfg ) {
		super.configure( cfg );
	}

	protected Class<?>[] getAnnotatedClasses() {
		return new Class[] { Author.class, Product.class
		};
	}
	
}