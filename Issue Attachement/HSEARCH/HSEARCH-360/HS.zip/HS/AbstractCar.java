package hibernatetest.search;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;

import material.AbstractThing;
import material.persistence.PersistableRoot;

@Entity
@Table(name = "Car")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "DISC", discriminatorType = DiscriminatorType.STRING, length = 5)
@Indexed
public abstract class AbstractCar extends AbstractThing implements PersistableRoot
{

    @Field
    private String _kurztext;

    private boolean _hasColor;

    protected AbstractCar()
    {
        // nur f�r hibernate
    }

    public String getKurztext()
    {
        return _kurztext;
    }

    public void setKurztext(final String kurztext)
    {
        _kurztext = kurztext;
    }

}
