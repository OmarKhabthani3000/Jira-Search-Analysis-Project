package hibernatetest.search;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.util.List;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.search.Query;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import hibernatetest.Papa;
import support.IOCContainer;
import support.IOCContainerFactory;

/**
 * TODO - Klasse kommentieren
 * 
 * @author chenzd 16.04.2009 create
 */
public class HSMixedCriteriaTest
{

    private static IOCContainer _picoContainer;
    private static SessionFactory _sessionFactory;

    @BeforeClass
    public static void setUpClass()
    {
        _picoContainer = IOCContainerFactory.createAndInitIOCContainer("de/pds/common/mappingsForTest.cfg.xml");
        _sessionFactory = (SessionFactory) _picoContainer.getComponentInstanceOfType(SessionFactory.class);
    }

    @AfterClass
    public static void tearDownClass()
    {
        IOCContainerFactory.shutdownIOCContainer(_picoContainer);
        IOCContainerFactory.shutdownServer();
    }

    @After
    public void tearDown()
    {
        Session session = _sessionFactory.openSession();
        session.beginTransaction();
        List<?> result = session.createQuery("from AbstractCar").list();
        for (Object object : result)
        {
            session.delete(object);
        }

        session.flush();
        session.getTransaction().commit();
        session.close();
    }

    @Test
    public void defaultTest() throws Exception
    {
        Session session = _sessionFactory.openSession();
        CombiCar combi = new CombiCar();
        combi.setKurztext("combiCar");

        Transaction tx = session.beginTransaction();
        session.persist(combi);
        tx.commit();
        session.close();

        // Get
        session = _sessionFactory.openSession();
        tx = session.beginTransaction();
        CombiCar loadedObjectOne = (CombiCar) session.get(CombiCar.class, combi.getDBId());
        assertThat(loadedObjectOne.getKurztext(), is(combi.getKurztext()));

        // search
        session = _sessionFactory.openSession();
        tx = session.beginTransaction();
        tx.begin();

        FullTextSession fullTextSession = Search.getFullTextSession(session);

        MultiFieldQueryParser parser = new MultiFieldQueryParser(new String[] { "_kurztext"}, new StandardAnalyzer());
        Query query = parser.parse("c*");

        Criteria criteria = session.createCriteria(Papa.class);
        criteria.add(Restrictions.eq("_hasColor", Boolean.FALSE));

        org.hibernate.Query hibQuery = fullTextSession.createFullTextQuery(query, AbstractCar.class).setCriteriaQuery(criteria);
        List result = hibQuery.list();
        assertThat(result.size(), is(1));
        tx.commit();
        session.close();

    }
}
