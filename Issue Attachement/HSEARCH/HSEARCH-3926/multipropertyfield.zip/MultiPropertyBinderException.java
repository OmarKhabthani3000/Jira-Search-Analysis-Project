package de.tl.hibernate.search.binder;

/**
 *	@author TL
 */
public class MultiPropertyBinderException extends RuntimeException
{
	public MultiPropertyBinderException()
	{
	}

	public MultiPropertyBinderException(String message)
	{
		super(message);
	}

	public MultiPropertyBinderException(String message, Throwable cause)
	{
		super(message, cause);
	}

	public MultiPropertyBinderException(Throwable cause)
	{
		super(cause);
	}
}
