package de.tl.hibernate.search.binder;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.search.engine.backend.analysis.AnalyzerNames;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.FullTextField;

/**
 *	@author TL
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.METHOD})
@Repeatable(MultiPropertyFullTextField.List.class)
public @interface MultiPropertyFullTextField
{
	/**
	 *	same as {@link FullTextField#name}
	 */
	String name() default "";

	/**
	 *	same as {@link FullTextField#analyzer}
	 */
	String analyzer() default AnalyzerNames.DEFAULT;

	@Retention(RetentionPolicy.RUNTIME)
	@Target({ElementType.FIELD, ElementType.METHOD})
	@interface List
	{
		MultiPropertyFullTextField[] value();
	}
}
