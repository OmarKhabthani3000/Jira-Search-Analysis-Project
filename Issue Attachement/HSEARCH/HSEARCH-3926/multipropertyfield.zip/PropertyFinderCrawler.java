package de.tl.hibernate.search.binder;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.List;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.IndexedEmbedded;

/**
 *	@author TL
 */
class PropertyFinderCrawler
{
	private final Class<?> clazz;

	public PropertyFinderCrawler(Class<?> clazz)
	{
		this.clazz=clazz;
	}

	public List<PropertyDescriptor> makeAllProperties()
	{
		List<PropertyDescriptor> toReturn=new LinkedList();
		collectAllProperties(clazz, toReturn);
		return toReturn;
	}

	private void collectAllProperties(Class<?> clazz, List<PropertyDescriptor> target)
	{
		for (Field curDeclaredField: clazz.getDeclaredFields())
		{
			if (PropertyDescriptor.isPropertyCandidate(curDeclaredField))
			{
				PropertyDescriptor fieldProperty=PropertyDescriptor.forField(curDeclaredField);
				target.add(fieldProperty);
				collectPotentialNestedProperties(fieldProperty, target);
			}
		}

		for (Method curDeclaredMethod: clazz.getDeclaredMethods())
		{
			if (PropertyDescriptor.isPropertyCandidate(curDeclaredMethod))
			{
				PropertyDescriptor methodProperty=PropertyDescriptor.forMethod(curDeclaredMethod);
				target.add(methodProperty);
				collectPotentialNestedProperties(methodProperty, target);
			}
		}

		Class<?> superclass=clazz.getSuperclass();
		if (superclass!=null)
		{
			collectAllProperties(superclass, target);
		}

		for (Class<?> curInterface: clazz.getInterfaces())
		{
			collectAllProperties(curInterface, target);
		}
	}

	private void collectPotentialNestedProperties(PropertyDescriptor property, List<PropertyDescriptor> target)
	{
		IndexedEmbedded indexedEmbeddedAnnotation=property.getAnnotation(IndexedEmbedded.class);
		if (indexedEmbeddedAnnotation!=null)
		{
			List<PropertyDescriptor> targetTmp=new LinkedList();
			collectAllProperties(property.getPropertyType(), targetTmp);
			for (PropertyDescriptor curNestedPropertyDescriptor: targetTmp)
			{
				target.add(PropertyDescriptor.forNestedProperty(property, curNestedPropertyDescriptor));
			}
		}
	}
}
