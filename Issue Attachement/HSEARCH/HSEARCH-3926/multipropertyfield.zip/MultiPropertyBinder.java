package de.tl.hibernate.search.binder;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.hibernate.search.engine.backend.document.IndexFieldReference;
import org.hibernate.search.engine.backend.document.model.dsl.IndexSchemaElement;
import org.hibernate.search.engine.backend.types.Projectable;
import org.hibernate.search.mapper.pojo.bridge.binding.TypeBindingContext;
import org.hibernate.search.mapper.pojo.bridge.mapping.programmatic.TypeBinder;
import org.hibernate.search.mapper.pojo.model.dependency.PojoTypeIndexingDependencyConfigurationContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *	this class is trying to work around a hibernate 6 'gap' where they removed an important feature that was present
 *	in hibernate 5. specifically: in hibernate 5 it was possible and totally normal to assign several properties to
 *	the same field, like this:
 *	class ABC
 *	{
 *		@Field(name = "everything", analyzer = @Analyzer(definition = "defaultanalyzer"))
 *		private String property1;
 *
 *		@Field(name = "everything", analyzer = @Analyzer(definition = "defaultanalyzer"))
 *		private String property2;
 *	}
 *
 *	that way you could search in all properties with just one handy field definition "everything".
 *
 *	in hibernate 6 they removed support for this. it throws an exception:
 *	org.hibernate.search.util.common.SearchException: HSEARCH600034: Duplicate index field definition: 'everything'. Index field names must be unique. Look for two property mappings with the same field name, or two indexed-embeddeds with prefixes that lead to conflicting index field names, or two custom bridges declaring index fields with the same name.
 *
 *	there is an article here that suggests a workaround:
 *	https://discourse.hibernate.org/t/index-multiple-properties-in-the-same-field/5542
 *
 *	however, this workaround is not as simple as things used to be, and in particular contains redundant information,
 *	that is the properties that are involved need to be inside the method and above in the annotation. furthermore,
 *	you clutter your class with such a transient method.
 *
 *	to avoid these shortcomings, i implemented this class that allows you to use pretty much the old syntax and the rest
 *	happens automatically.
 *
 *	@author TL
 */
public class MultiPropertyBinder<T> implements TypeBinder
{
	private static final Logger log=LoggerFactory.getLogger(MultiPropertyBinder.class);

	private final Class<T> classT;

	public MultiPropertyBinder(Class<T> classT)
	{
		this.classT=classT;
	}

	@Override
	public void bind(TypeBindingContext context)
	{
		// collect all data first to have validation running before we change anything

		List<String> dependenciesToAdd=new LinkedList();
		for (List<PropertyDescriptorWithSpecificMultiAnnotation> curDependencies: getMultiAnnotatedPropertiesByFieldName().values())
		{
			for (PropertyDescriptorWithSpecificMultiAnnotation curDependency: curDependencies)
			{
				dependenciesToAdd.add(curDependency.getPropertyDescriptor().getPropertyName());
			}
		}

		Map<String, String> fieldNamesWithAnalyzerNamesToBind=new LinkedHashMap();
		Map<String, List<PropertyDescriptor>> fieldNamesWithProperties=new LinkedHashMap();
		for (Map.Entry<String, List<PropertyDescriptorWithSpecificMultiAnnotation>> curMultiFieldEntry: getMultiAnnotatedPropertiesByFieldName().entrySet())
		{
			String curFieldName=curMultiFieldEntry.getKey();

			String curFieldNameAnalyzerName=null;
			for (PropertyDescriptorWithSpecificMultiAnnotation curPropertyDescriptorWithSpecificMultiAnnotation: curMultiFieldEntry.getValue())
			{
				String curAnnotationAnalyzerName=curPropertyDescriptorWithSpecificMultiAnnotation.getAnnotation().analyzer();

				if (curFieldNameAnalyzerName==null)
				{
					curFieldNameAnalyzerName=curAnnotationAnalyzerName;
				}
				else if (!curFieldNameAnalyzerName.equals(curAnnotationAnalyzerName))
				{
					throw new MultiPropertyBinderException("Contradicting analyzers for field name '"+curFieldName+"': "+curFieldNameAnalyzerName+"!="+curAnnotationAnalyzerName);
				}

			}

			if (curFieldNameAnalyzerName==null)
			{
				throw new MultiPropertyBinderException("No analyzer defined for field name '"+curFieldName+"'!");
			}

			fieldNamesWithAnalyzerNamesToBind.put(curFieldName, curFieldNameAnalyzerName);


			// iterate over all properties to make sure they're all strings
			// and collect their properties
			List<PropertyDescriptor> curFieldProperties=new LinkedList();
			for (PropertyDescriptorWithSpecificMultiAnnotation curMultiPropertyDescriptorWithSpecificMultiAnnotation: curMultiFieldEntry.getValue())
			{
				if (!curMultiPropertyDescriptorWithSpecificMultiAnnotation.getPropertyDescriptor().getPropertyType().equals(String.class))
				{
					throw new MultiPropertyBinderException("Multi properties only support strings at the moment. Not a string: Field '"+curFieldName+"' from '"+curMultiPropertyDescriptorWithSpecificMultiAnnotation.getPropertyDescriptor().getPropertyName()+"' -> "+curMultiPropertyDescriptorWithSpecificMultiAnnotation.getPropertyDescriptor().getPropertyType()+"!");
				}
				curFieldProperties.add(curMultiPropertyDescriptorWithSpecificMultiAnnotation.getPropertyDescriptor());
			}
			fieldNamesWithProperties.put(curFieldName, curFieldProperties);
		}

		// what comes from here has been implemented following https://docs.jboss.org/hibernate/stable/search/reference/en-US/html_single/#binding-typebridge

		PojoTypeIndexingDependencyConfigurationContext dependencies=context.dependencies();
		for (String curDependencyToAdd: dependenciesToAdd)
		{
			dependencies.use(curDependencyToAdd);
		}

		IndexSchemaElement indexSchemaElement=context.indexSchemaElement();
		for (Map.Entry<String, String> curFieldNameWithAnalyzerEntry: fieldNamesWithAnalyzerNamesToBind.entrySet())
		{
			String curFieldName=curFieldNameWithAnalyzerEntry.getKey();
			IndexFieldReference<String> curField=indexSchemaElement.field(curFieldName,
				f -> f.asString().projectable(Projectable.YES).analyzer(curFieldNameWithAnalyzerEntry.getValue())).multiValued().toReference();

			context.bridge(classT, new Bridge<>(curField, fieldNamesWithProperties.get(curFieldName)));
		}
	}

	private Map<String, List<PropertyDescriptorWithSpecificMultiAnnotation>> multiAnnotatedPropertiesByFieldName=null;
	Map<String, List<PropertyDescriptorWithSpecificMultiAnnotation>> getMultiAnnotatedPropertiesByFieldName()
	{
		if (multiAnnotatedPropertiesByFieldName==null)
		{
			Map<String, List<PropertyDescriptorWithSpecificMultiAnnotation>> multiAnnotatedPropertiesByFieldNameTmp=new LinkedHashMap();

			for (PropertyDescriptor curMultiAnnotatedProperty: getMultiAnnotatedProperties())
			{
				for (MultiPropertyFullTextField curMultiPropertyAnnotation: curMultiAnnotatedProperty.getMultiPropertyAnnotations())
				{
					PropertyDescriptorWithSpecificMultiAnnotation curPropertyDescriptorWithSpecificMultiAnnotation=new PropertyDescriptorWithSpecificMultiAnnotation(curMultiAnnotatedProperty, curMultiPropertyAnnotation);
					String curFieldName=curMultiPropertyAnnotation.name();

					List<PropertyDescriptorWithSpecificMultiAnnotation> curList=multiAnnotatedPropertiesByFieldNameTmp.get(curFieldName);
					if (curList==null)
					{
						curList=new LinkedList();
						multiAnnotatedPropertiesByFieldNameTmp.put(curFieldName, curList);
					}
					curList.add(curPropertyDescriptorWithSpecificMultiAnnotation);
				}
			}

			multiAnnotatedPropertiesByFieldName=multiAnnotatedPropertiesByFieldNameTmp;
		}
		return multiAnnotatedPropertiesByFieldName;
	}

	private List<PropertyDescriptor> multiAnnotatedProperties=null;
	List<PropertyDescriptor> getMultiAnnotatedProperties()
	{
		if (multiAnnotatedProperties==null)
		{
			List<PropertyDescriptor> multiAnnotatedPropertiesTmp=new LinkedList();
			List<PropertyDescriptor> allProperties=new PropertyFinderCrawler(classT).makeAllProperties();
			for (PropertyDescriptor curProperty: allProperties)
			{
				List<MultiPropertyFullTextField> multiPropertyAnnotations=curProperty.getMultiPropertyAnnotations();
				if (multiPropertyAnnotations!=null)
				{
					multiAnnotatedPropertiesTmp.add(curProperty);
				}
			}
			multiAnnotatedProperties=multiAnnotatedPropertiesTmp;
		}
		return multiAnnotatedProperties;
	}

	class PropertyDescriptorWithSpecificMultiAnnotation
	{
		private final PropertyDescriptor propertyDescriptor;
		private final MultiPropertyFullTextField annotation;

		public PropertyDescriptorWithSpecificMultiAnnotation(PropertyDescriptor propertyDescriptor, MultiPropertyFullTextField annotation)
		{
			this.propertyDescriptor=propertyDescriptor;
			this.annotation=annotation;
		}

		public PropertyDescriptor getPropertyDescriptor()
		{
			return propertyDescriptor;
		}

		public MultiPropertyFullTextField getAnnotation()
		{
			return annotation;
		}
	}
}
