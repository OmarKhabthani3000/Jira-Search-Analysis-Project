package de.tl.hibernate.search.binder;

import java.util.LinkedList;
import java.util.List;
import org.hibernate.search.engine.backend.document.DocumentElement;
import org.hibernate.search.engine.backend.document.IndexFieldReference;
import org.hibernate.search.mapper.pojo.bridge.TypeBridge;
import org.hibernate.search.mapper.pojo.bridge.runtime.TypeBridgeWriteContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *	@author https://docs.jboss.org/hibernate/stable/search/reference/en-US/html_single/#binding-typebridge-basics
 *	@author TL
 */
class Bridge<T> implements TypeBridge<T>
{
	private static final Logger log=LoggerFactory.getLogger(Bridge.class);

	private final IndexFieldReference<String> indexedField;
	private final List<PropertyDescriptor> propertiesToInclude;

	public Bridge(IndexFieldReference<String> indexedField, List<PropertyDescriptor> propertiesToInclude)
	{
		this.indexedField=indexedField;
		this.propertiesToInclude=propertiesToInclude;
	}

	@Override
	public void write(DocumentElement target, T bridgedElement, TypeBridgeWriteContext context)
	{
		for (PropertyDescriptor curPropertyDescriptor: propertiesToInclude)
		{
			Object curValue=curPropertyDescriptor.getValue(bridgedElement);
			if (curValue!=null)
			{
				if (!(curValue instanceof String))
				{
					log.warn("Unexpected non-string found: '"+curValue+"' of type "+curValue.getClass()+"!");
				}
				target.addValue(indexedField, curValue.toString());
			}
		}
	}

}
