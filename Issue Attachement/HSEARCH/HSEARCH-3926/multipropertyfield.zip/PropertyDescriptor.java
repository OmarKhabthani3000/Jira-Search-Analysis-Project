package de.tl.hibernate.search.binder;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Member;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.IndexedEmbedded;

/**
 *	@author TL
 */
abstract class PropertyDescriptor
{
	public PropertyDescriptor()
	{
	}

	public static boolean isPropertyCandidate(AnnotatedElement annotatedElement)
	{
		return
			annotatedElement.getAnnotation(MultiPropertyFullTextField.class)!=null ||
			annotatedElement.getAnnotation(MultiPropertyFullTextField.List.class)!=null ||
			annotatedElement.getAnnotation(IndexedEmbedded.class)!=null;
	}

	public static PropertyDescriptor forField(java.lang.reflect.Field field)
	{
		assertIsPropertyCandidate(field);
		return new ByField(field);
	}

	public static PropertyDescriptor forMethod(java.lang.reflect.Method method)
	{
		assertIsPropertyCandidate(method);
		return new ByMethod(method);
	}

	public static PropertyDescriptor forNestedProperty(PropertyDescriptor ownerProperty, PropertyDescriptor property)
	{
		return new ByNestedProperty(ownerProperty, property);
	}

	protected static void assertIsPropertyCandidate(AnnotatedElement annotatedElement)
	{
		if (!isPropertyCandidate(annotatedElement))
		{
			throw new MultiPropertyBinderException(""+annotatedElement+" doesn't have any of the qualifying annotations.");
		}
	}

	public abstract String getPropertyName();
	public abstract Class<?> getPropertyType();

	public <T extends Annotation> T getAnnotation(Class<T> annotationClass)
	{
		return getAnnotatedElement().getAnnotation(annotationClass);
	}

	private List<MultiPropertyFullTextField> multiPropertyAnnotations=null;
	public List<MultiPropertyFullTextField> getMultiPropertyAnnotations()
	{
		if (multiPropertyAnnotations==null)
		{
			List<MultiPropertyFullTextField> multiPropertyAnnotationsTmp=new LinkedList();
			MultiPropertyFullTextField annotationDirect=getAnnotation(MultiPropertyFullTextField.class);
			if (annotationDirect!=null)
			{
				multiPropertyAnnotationsTmp.add(annotationDirect);
			}

			MultiPropertyFullTextField.List annotationList=getAnnotation(MultiPropertyFullTextField.List.class);
			if (annotationList!=null)
			{
				multiPropertyAnnotationsTmp.addAll(Arrays.asList(annotationList.value()));
			}
			multiPropertyAnnotations=multiPropertyAnnotationsTmp;
		}
		return multiPropertyAnnotations;
	}

	public abstract Object getValue(Object object);

	protected abstract AnnotatedElement getAnnotatedElement();


	@Override
	public String toString()
	{
		return "PropertyDescriptor('"+getPropertyName()+"')";
	}

	static abstract class MemberProperty extends PropertyDescriptor
	{
		@Override
		public Object getValue(Object object)
		{
			try
			{
				return getDirectGetterMethod().invoke(object);
			}
			catch (Exception ex)
			{
				throw new MultiPropertyBinderException(ex);
			}
		}

		private java.lang.reflect.Method directGetterMethod=null;
		protected java.lang.reflect.Method getDirectGetterMethod()
		{
			if (directGetterMethod==null)
			{
				Class<?> declaringClass=getMember().getDeclaringClass();

				StringBuilder methodNameMainPart=new StringBuilder(getPropertyName());
				methodNameMainPart.setCharAt(0, Character.toUpperCase(methodNameMainPart.charAt(0)));
				try
				{
					directGetterMethod=declaringClass.getMethod("get"+methodNameMainPart);
				}
				catch (NoSuchMethodException ex)
				{
					for (int i=1; i<methodNameMainPart.length(); i++)
					{
						char curChar=methodNameMainPart.charAt(i);
						if (Character.isLowerCase(curChar))
						{
							methodNameMainPart.setCharAt(i, Character.toUpperCase(curChar));
						}
						else
						{
							break;
						}
					}

					try
					{
						directGetterMethod=declaringClass.getMethod("get"+methodNameMainPart);
					}
					catch (NoSuchMethodException ex2)
					{
						throw new MultiPropertyBinderException(ex2);
					}
				}
			}
			return directGetterMethod;
		}

		protected abstract java.lang.reflect.Member getMember();
	}

	static class ByField extends MemberProperty
	{
		private final java.lang.reflect.Field field;

		protected ByField(java.lang.reflect.Field field)
		{
			this.field=field;
		}

		@Override
		public String getPropertyName()
		{
			return field.getName();
		}

		@Override
		public Class<?> getPropertyType()
		{
			return field.getType();
		}

		@Override
		protected AnnotatedElement getAnnotatedElement()
		{
			return field;
		}

		@Override
		protected Member getMember()
		{
			return field;
		}
	}

	static class ByMethod extends MemberProperty
	{
		private final java.lang.reflect.Method method;

		protected ByMethod(java.lang.reflect.Method method)
		{
			this.method=method;
			String methodName=method.getName();
			if (!methodName.startsWith("get") && !methodName.startsWith("set"))
			{
				throw new IllegalArgumentException("Method name '"+methodName+"' doesn't start with 'get' or 'set'.");
			}
		}

		private String propertyName=null;
		@Override
		public String getPropertyName()
		{
			if (propertyName==null)
			{
				String methodName=method.getName();
				assert methodName.length()>3;

				// remove leading three characters ("get" or "set") and replace uppercase with lowercase until a lowercase
				// character is found.
				StringBuilder rawPropertyName=new StringBuilder(methodName.substring(3));
				for (int i=0; i<rawPropertyName.length(); i++)
				{
					char curChar=rawPropertyName.charAt(i);
					if (Character.isUpperCase(curChar))
					{
						rawPropertyName.setCharAt(i, Character.toLowerCase(curChar));
					}
					else
					{
						break;
					}
				}

				propertyName=rawPropertyName.toString();
			}
			return propertyName;
		}

		@Override
		public Class<?> getPropertyType()
		{
			return method.getReturnType();
		}

		@Override
		public Object getValue(Object object)
		{
			try
			{
				return getDirectGetterMethod().invoke(object);
			}
			catch (Exception ex)
			{
				throw new MultiPropertyBinderException(ex);
			}
		}

		@Override
		protected AnnotatedElement getAnnotatedElement()
		{
			return method;
		}

		@Override
		protected Member getMember()
		{
			return method;
		}
	}

	static class ByNestedProperty extends PropertyDescriptor
	{
		private final PropertyDescriptor ownerProperty;
		private final PropertyDescriptor property;

		public ByNestedProperty(PropertyDescriptor ownerProperty, PropertyDescriptor property)
		{
			this.ownerProperty=ownerProperty;
			this.property=property;
		}

		@Override
		public String getPropertyName()
		{
			return ownerProperty.getPropertyName()+"."+property.getPropertyName();
		}

		@Override
		public Class<?> getPropertyType()
		{
			return property.getPropertyType();
		}

		@Override
		public Object getValue(Object object)
		{
			Object owner=ownerProperty.getValue(object);
			if (owner==null)
			{
				return null;
			}
			else
			{
				return property.getValue(owner);
			}
		}

		@Override
		protected AnnotatedElement getAnnotatedElement()
		{
			return property.getAnnotatedElement();
		}
	}
}
