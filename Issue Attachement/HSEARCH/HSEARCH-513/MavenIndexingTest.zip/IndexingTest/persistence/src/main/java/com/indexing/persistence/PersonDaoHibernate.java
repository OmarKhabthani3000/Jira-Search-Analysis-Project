package com.indexing.persistence;

import com.indexing.people.Person;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class PersonDaoHibernate {

    @Autowired
    protected SessionFactory sessionFactory;

    public void addPeople(Collection<Person> people) {
        for (Person person : people) {
            addPerson(person);
        }
    }

    private long addPerson(Person person) {
        return (Long) sessionFactory.getCurrentSession().save(person);
    }
}