package com.indexing.persistence;

import com.indexing.people.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.util.Collection;

@Service
public class PersonManager implements Serializable {

    @Autowired
    private PersonDaoHibernate personDao;

    public void savePeople(Collection<Person> people) {
        personDao.addPeople(people);
    }
}

