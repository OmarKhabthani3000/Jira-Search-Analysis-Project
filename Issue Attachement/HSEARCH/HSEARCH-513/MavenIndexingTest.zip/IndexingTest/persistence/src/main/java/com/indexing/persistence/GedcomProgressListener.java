package com.indexing.persistence;

import org.familysearch.gedcomparser.ProgressListener;

public class GedcomProgressListener implements ProgressListener {
    @Override
    public void setFileSize(long l) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void updateRemaining(long l) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void importingPerson() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void importingFamily() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void importingHeader() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void importingSubmission() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void importingMedia() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void importingNote() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void importingRepository() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void importingSource() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void importingSubmitter() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void importingTPinDate() {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}

