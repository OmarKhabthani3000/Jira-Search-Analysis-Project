package com.indexing.persistence;

import com.indexing.people.Person;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:application-context.xml"})
public class TestGedcomManager {

    @Autowired
    private PersonManager personManager;

    @Test
    public void testSavePeople() throws Exception {
        File file = new File("testGedcom.ged");
        GedcomSmall gedcom = new GedcomSmall(new FileInputStream(file), file.length());
        Collection<Person> people = gedcom.getPeople();
        savePeople(people);
    }

    private void savePeople(Collection<Person> people) {
        List<Person> peopleBatch = new ArrayList<Person>();
        int i = 0;
        for (Person person : people) {
            peopleBatch.add(person);
            if (peopleBatch.size() == 20) {
                System.out.println("Saving batch number " + i);
                long time = System.currentTimeMillis();
                personManager.savePeople(peopleBatch);
                System.out.println("Finished saving batch number " + i + "in " + (System.currentTimeMillis() - time) + "millis");
                peopleBatch = new ArrayList<Person>();
                i++;
            }
        }
    }
}

