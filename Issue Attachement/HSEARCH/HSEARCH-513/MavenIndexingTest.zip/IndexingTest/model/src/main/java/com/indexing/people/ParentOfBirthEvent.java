package com.indexing.people;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.IndexedEmbedded;

import java.io.Serializable;

public class ParentOfBirthEvent implements Serializable {
    private Long id;
    @IndexedEmbedded
    private Person parent;
    @ContainedIn
    private Event event;

    public ParentOfBirthEvent() {
    }

    public ParentOfBirthEvent(Person parent, Event event) {
        this();
        this.parent = parent;
        this.event = event;
        event.getParentsOf().add(this);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Person getParent() {
        return parent;
    }

    public void setParent(Person parent) {
        this.parent = parent;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

     @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Person)) return false;
        ParentOfBirthEvent parentOfBirthEventToCompareWith = (ParentOfBirthEvent) o;
        if (id != null && id.equals(parentOfBirthEventToCompareWith.getId()))
            return true;
        return false;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : super.hashCode();
    }
}
