package people;

import org.familysearch.gedcomparser.GedcomParser;
import org.familysearch.gedcomparser.handler.RecordHandler;
import org.familysearch.gedcomparser.record.*;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.zip.DataFormatException;

/**
 * Takes a GEDCOM file and converts it to a list of people with references to their children.
 */
public class GedcomSmall implements RecordHandler {
    private HashMap<String, Person> people;

    @Override
    public void initialize() {}

    @Override
    public boolean handleHeaderRecord(HeaderRecord headerRecord) {
        return true;
    }

    @Override
    public boolean handleSubmissionRecord(SubmissionRecord submissionRecord) {
        return true;
    }

    @Override
    public boolean handleFamilyRecord(FamilyRecord familyRecord) {
        parseFamily(familyRecord);
        return true;
    }

    @Override
    public boolean handleIndividualRecord(IndividualRecord individualRecord) {
        parsePerson(individualRecord);
        return true;
    }

    @Override
    public boolean handleMultiMediaRecord(MultiMediaRecord multiMediaRecord) {
        return true;
    }

    @Override
    public boolean handleNoteRecord(NoteRecord noteRecord) {
        return true;
    }

    @Override
    public boolean handleRepositoryRecord(RepositoryRecord repositoryRecord) {
        return true;
    }

    @Override
    public boolean handleSourceRecord(SourceRecord sourceRecord) {
        return true;
    }

    @Override
    public boolean handleSubmitterRecord(SubmitterRecord submitterRecord) {
        return true;
    }

    @Override
    public boolean handleTPinDateRecord(TPinDateRecord tPinDateRecord, String s, String s1) {
        return true;
    }

    @Override
    public void close() {
    }

    public GedcomSmall(InputStream inputStream, long fileLength) throws IOException, DataFormatException  {
        people = new LinkedHashMap<String, Person>();
        parseGedcom(inputStream, fileLength);
    }

    private boolean parseGedcom(InputStream inputStream, long fileLength) throws IOException, DataFormatException {
        GedcomParser gedcomParser = new GedcomParser();
        return gedcomParser.importGedcomFile(inputStream, fileLength, new GedcomProgressListener(), this);
    }

    private void parsePerson(IndividualRecord individualRecord) {
        people.put(individualRecord.getId(), new Person());
    }

    private void parseFamily(FamilyRecord familyRecord) {
        Person father = familyRecord.getHusbandId() != null ? people.get(familyRecord.getHusbandId()) : null;
        Person mother = familyRecord.getWifeId() != null ? people.get(familyRecord.getWifeId()) : null;
        if (father == mother)
            mother = null;
        if (familyRecord.getChildrenInfos() != null) {
            for (ChildRecord child : familyRecord.getChildrenInfos()) {
                trySettingParent(people.get(child.getChildGedcomId()), father);
                trySettingParent(people.get(child.getChildGedcomId()), mother);
            }
        }
    }

    private void trySettingParent(Person child, Person parent) {
        if (child.getBirthEvent().getParentsOf().size() < 2 && parent != null)
            setParent(child, parent);
    }

    private void setParent(Person child, Person parent) {
        ParentOfBirthEvent parentOfBirthEvent = new ParentOfBirthEvent(parent, child.getBirthEvent());
        parent.getParentOfBirthEvents().add(parentOfBirthEvent);
    }

    public Collection<Person> getPeople() {
        return people.values();
    }
}