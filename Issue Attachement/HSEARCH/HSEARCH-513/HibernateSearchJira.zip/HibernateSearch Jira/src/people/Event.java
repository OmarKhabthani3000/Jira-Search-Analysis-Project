package people;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.IndexedEmbedded;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Event implements Serializable {
    //@DocumentId
    protected Long id;
    @IndexedEmbedded
    protected Set<ParentOfBirthEvent> parentsOf;
    @ContainedIn
    protected Set<Person> children;

    /**
     * Instantiates empty sets.
     */
    public Event() {
        parentsOf = new HashSet<ParentOfBirthEvent>();
        children = new HashSet<Person>();
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public Set<ParentOfBirthEvent> getParentsOf() {
        return parentsOf;
    }

    public void setParentsOf(Set<ParentOfBirthEvent> parentsOf) {
        this.parentsOf = parentsOf;
    }

    public Set<Person> getChildren() {
        return children;
    }

    public void setChildren(Set<Person> children) {
        this.children = children;
    }

    public boolean isTransient() {
        return getId() == null;
    }
}