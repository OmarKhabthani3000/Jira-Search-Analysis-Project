package people;

import org.hibernate.SessionFactory;

import java.util.Collection;

public class PersonDaoHibernate {
    protected SessionFactory sessionFactory;

    public void addPeople(Collection<Person> people) {
        for (Person person : people) {
            addPerson(person);
        }
    }

    private long addPerson(Person person) {
        return (Long) sessionFactory.getCurrentSession().save(person);
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}