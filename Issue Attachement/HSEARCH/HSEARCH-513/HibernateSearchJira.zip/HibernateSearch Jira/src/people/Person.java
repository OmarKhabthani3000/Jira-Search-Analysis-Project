package people;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.Set;

@Indexed
public class Person implements Serializable {
    @DocumentId
    private Long id;
    @ContainedIn
    private Set<ParentOfBirthEvent> parentOfBirthEvents;
    @IndexedEmbedded(depth = 4)
    private Event birthEvent;

    public Person() {
        birthEvent = new Event();
        birthEvent.getChildren().add(this);
        parentOfBirthEvents = new LinkedHashSet<ParentOfBirthEvent>();
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public Set<ParentOfBirthEvent> getParentOfBirthEvents() {
        return parentOfBirthEvents;
    }

    public void setParentOfBirthEvents(Set<ParentOfBirthEvent> parentOfBirthEvents) {
        this.parentOfBirthEvents = parentOfBirthEvents;
    }

    public Event getBirthEvent() {
        return birthEvent;
    }

    public void setBirthEvent(Event birthEvent) {
        this.birthEvent = birthEvent;
    }
}