package people;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.IndexedEmbedded;

import java.io.Serializable;

public class ParentOfBirthEvent implements Serializable {
    private Long id;
    @IndexedEmbedded
    private Person parent;
    @ContainedIn
    private Event event;

    public ParentOfBirthEvent() {
    }

    public ParentOfBirthEvent(Person parent, Event event) {
        this();
        this.parent = parent;
        this.event = event;
        event.getParentsOf().add(this);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Person getParent() {
        return parent;
    }

    public void setParent(Person parent) {
        this.parent = parent;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }
}
