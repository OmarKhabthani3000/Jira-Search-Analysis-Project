package manager;

import people.Person;
import people.PersonDaoHibernate;

import java.io.Serializable;
import java.util.Collection;

public class PersonManager implements Serializable {

    private PersonDaoHibernate personDao;

    public void savePeople(Collection<Person> people) {
        personDao.addPeople(people);
    }

    public void setPersonDao(PersonDaoHibernate personDao) {
        this.personDao = personDao;
    }
}

