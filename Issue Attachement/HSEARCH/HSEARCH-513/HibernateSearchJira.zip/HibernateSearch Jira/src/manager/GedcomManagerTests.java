package manager;

import org.springframework.test.AbstractDependencyInjectionSpringContextTests;
import people.GedcomSmall;
import people.Person;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author Florin
 */
public class GedcomManagerTests extends AbstractDependencyInjectionSpringContextTests {

    private PersonManager personManager;

    @Override
    protected String[] getConfigLocations() {
        return new String[]{"classpath:config/application-context.xml"};
    }

    public void testSavePeople() throws Exception {
        // TODO: either place the test file in the root dir or replace the path with the actual path of the file
        File file = new File(File.separatorChar + "testGedcom.ged");
        GedcomSmall gedcom = new GedcomSmall(new FileInputStream(file), file.length());
        Collection<Person> people = gedcom.getPeople();
        savePeople(people);
    }

    private void savePeople(Collection<Person> people) {
        List<Person> peopleBatch = new ArrayList<Person>();
        int i = 0;
        for (Person person : people) {
            peopleBatch.add(person);
            if (peopleBatch.size() == 20) {
                System.out.println("Saving batch number " + i);
                long time = System.currentTimeMillis();
                personManager.savePeople(peopleBatch);
                System.out.println("Finished saving batch number " + i + "in " + (System.currentTimeMillis() - time) + "millis");
                peopleBatch = new ArrayList<Person>();
                i++;
            }
        }
    }

    public void setPersonManager(PersonManager personManager) {
        this.personManager = personManager;
    }
}

