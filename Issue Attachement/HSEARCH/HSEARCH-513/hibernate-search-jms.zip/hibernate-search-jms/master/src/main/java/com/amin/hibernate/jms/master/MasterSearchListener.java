package com.amin.hibernate.jms.master;


import java.util.concurrent.atomic.AtomicInteger;
import javax.jms.Message;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.search.backend.impl.jms.AbstractJMSHibernateSearchController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * MasterSearchListener
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 20, 2010
 */
public class MasterSearchListener extends AbstractJMSHibernateSearchController {

    private static final Logger LOGGER = LoggerFactory.getLogger(MasterSearchListener.class);

    private SessionFactory sessionFactory;

    private final AtomicInteger integer = new AtomicInteger();


    @Override
    protected Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    @Override
    protected void cleanSessionIfNeeded(Session session) {
    }

    @Override
    public void onMessage(Message message) {
        LOGGER.info("Receieved message");
        super.onMessage(message);
        LOGGER.info("Completed message");
        LOGGER.info("Total processed " + integer.incrementAndGet());

    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory= sessionFactory;
    }
}
