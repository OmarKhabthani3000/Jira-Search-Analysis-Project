package com.amin.hibernate.jms.master;

import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * MasterHibernateSearchBootstrap
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 20, 2010
 */
public class MasterHibernateSearchBootstrap {

    
    private static final Logger LOGGER = LoggerFactory.getLogger(MasterHibernateSearchBootstrap.class);

    public static void main (String[] args) {
        LOGGER.info("Initialising Hibernate Search Master Node ");
        ClassPathXmlApplicationContext ctx =
                new ClassPathXmlApplicationContext(new String[]{"classpath:master-search-context-hibernate.xml"});

        LOGGER.info("Initialising complete on " + new Date());

    }
}
