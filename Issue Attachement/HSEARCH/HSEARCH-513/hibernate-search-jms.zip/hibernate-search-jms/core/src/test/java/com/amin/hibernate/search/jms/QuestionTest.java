package com.amin.hibernate.search.jms;

import java.util.List;

import com.amin.hibernate.search.jms.domain.Question;
import com.amin.hibernate.search.jms.repository.QuestionRepository;
import static junit.framework.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

/**
 * QuestionTest
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 28, 2010
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/repository-context.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class QuestionTest {

    @Autowired
    private QuestionRepository questionRepository;

    @Autowired
    private HibernateTemplate hibernateTemplate;

    private void hibernateSessionFlushAndClear() {
        hibernateTemplate.flush();
        hibernateTemplate.clear();
    }

    @Test
    public void findAQuestion() {

        Question q  = new Question();
        q.setQuestionText("What is a book");
        questionRepository.create(q);
        
        hibernateSessionFlushAndClear();

        final List<Question> questions = questionRepository.search("book");
        assertEquals(1, questions.size());
    }
}
