package com.amin.hibernate.search.jms;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.amin.hibernate.search.jms.domain.Author;
import com.amin.hibernate.search.jms.domain.Book;
import com.amin.hibernate.search.jms.domain.Isbn;
import com.amin.hibernate.search.jms.repository.BookRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

/**
 * JMSSlaveTest
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 20, 2010
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/repository-context.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class JMSSlaveTest {

    @Autowired
    private BookRepository bookRepository;


    @Test
    public void createBook() {
        for (int i = 0; i < 1000; i ++) {
            Book b = new Book();
            final Isbn isbn = new Isbn();
            isbn.setNumber("ISBN123143433"+i);
            b.setIsbn(isbn);
            Author author = new Author();
            author.setFirstName("Sarah"+i);
            author.setLastName("Mohammed-Coleman"+i);
            author.setDateOfBirth(new Date());
            b.writtenBy(author);
            bookRepository.create(b);
        }

        try {
            TimeUnit.MINUTES.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        final List<Book> books = bookRepository.search("sarah*");
        System.out.println(books.size());

    }

}
