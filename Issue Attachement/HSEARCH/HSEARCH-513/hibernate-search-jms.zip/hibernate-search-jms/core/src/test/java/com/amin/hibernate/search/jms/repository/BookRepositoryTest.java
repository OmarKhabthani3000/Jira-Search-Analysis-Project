package com.amin.hibernate.search.jms.repository;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.amin.hibernate.search.jms.domain.Author;
import com.amin.hibernate.search.jms.domain.Book;
import com.amin.hibernate.search.jms.domain.Isbn;
import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

/**
 * BookRepositoryTest
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 20, 2010
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/repository-context.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class BookRepositoryTest {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private HibernateTemplate hibernateTemplate;


    @Test
    @Transactional
    public void createBook() {
        Book b = new Book();
        final Isbn isbn = new Isbn();
        isbn.setNumber(UUID.randomUUID().toString());
        b.setIsbn(isbn);
        Author author = new Author();
        author.setFirstName("Amin");
        author.setLastName("Mohammed-Coleman");
        author.setDateOfBirth(new Date());
        author.setType(Author.AuthorType.BRILLIANT);
        b.writtenBy(author);
        bookRepository.create(b);

        hibernateSessionFlushAndClear();

        final Book book = hibernateTemplate.get(Book.class, b.getId());

        assertEquals(1, book.getAuthors().size());
        assertEquals(1, book.getAuthors().get(0).booksWritten().size());
    }

    @Test
    @Transactional
    public void updateBook() {
        Book b = new Book();
        final Isbn isbn = new Isbn();
        isbn.setNumber(UUID.randomUUID().toString());
        b.setIsbn(isbn);
        Author author = new Author();
        author.setFirstName("Amin");
        author.setLastName("Mohammed-Coleman");
        author.setDateOfBirth(new Date());
        b.writtenBy(author);
        bookRepository.create(b);

        hibernateSessionFlushAndClear();

        b.remove(author);

        bookRepository.update(b);

        hibernateSessionFlushAndClear();

        final Book book = hibernateTemplate.get(Book.class, b.getId());

        assertEquals(0, book.getAuthors().size());

    }

    private void hibernateSessionFlushAndClear() {
        hibernateTemplate.flush();
        hibernateTemplate.clear();
    }

    @Test
    public void findABookById() {
        Book b = new Book();
        final Isbn isbn = new Isbn();
        isbn.setNumber(UUID.randomUUID().toString());
        b.setIsbn(isbn);
        Author author = new Author();
        author.setFirstName("Amin");
        author.setLastName("Mohammed-Coleman");
        author.setDateOfBirth(new Date());
        b.writtenBy(author);
        bookRepository.create(b);

        hibernateSessionFlushAndClear();

        final Book book = bookRepository.findBy(b.getId());
        assertNotNull(book);

    }


    @Test
    public void findABookUsingFreeText() {
        Book b = new Book();
        final Isbn isbn = new Isbn();
        isbn.setNumber("ISBN123143433");
        b.setIsbn(isbn);
        Author author = new Author();
        author.setFirstName("Sarah");
        author.setLastName("Mohammed-Coleman");
        author.setDateOfBirth(new Date());
         author.setType(Author.AuthorType.AVERAGE);
        b.writtenBy(author);
        bookRepository.create(b);

        hibernateSessionFlushAndClear();

        final List<Book> books = bookRepository.search("average");
        assertEquals(1, books.size());
    }
}
