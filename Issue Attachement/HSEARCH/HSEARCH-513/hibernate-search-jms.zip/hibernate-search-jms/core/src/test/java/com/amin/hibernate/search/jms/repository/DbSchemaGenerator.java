package com.amin.hibernate.search.jms.repository;

import com.amin.hibernate.search.jms.domain.Author;
import com.amin.hibernate.search.jms.domain.Book;
import com.amin.hibernate.search.jms.domain.Isbn;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

/**
 * DbSchemaGenerator
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 20, 2010
 */
public class DbSchemaGenerator {
    public static void main(String[] args) {
        AnnotationConfiguration configuration = new AnnotationConfiguration();


        configuration.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");

        configuration.addAnnotatedClass(Author.class);
        configuration.addAnnotatedClass(Book.class);
        configuration.addAnnotatedClass(Isbn.class);
        configuration.buildMappings();

        // Dump formated SQL to console and file
        SchemaExport schemaExport = new SchemaExport(configuration);
        schemaExport.setOutputFile("mysql-schema.sql");
        schemaExport.setFormat(true);
        schemaExport.setDelimiter(";");
        schemaExport.execute(true, // write schema to output
                false, // do not export to DB
                false, // no drop statements
                true // only create statements
        );
    }

}
