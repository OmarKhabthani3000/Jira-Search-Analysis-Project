package com.amin.hibernate.search.jms.people;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.amin.hibernate.search.jms.Person;
import com.amin.hibernate.search.jms.domain.GedcomSmall;
import com.amin.hibernate.search.jms.service.PersonService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * GedcomManagerTest
 *
 * @author: Amin Mohammed-Coleman
 * @since: May 5, 2010
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/repository-context-hibernate.xml"})
public class GedcomManagerTest {

    @Autowired
    private PersonService personService;

    @Test
    public void savePeople() throws Exception {
        // TODO: either place the test file in the root dir or replace the path with the actual path of the file
        final URL resource = this.getClass().getClassLoader().getResource("testGedcom.ged");
        File file = new File(resource.toURI());
        GedcomSmall gedcom = new GedcomSmall(new FileInputStream(file), file.length());
        Collection<Person> people = gedcom.getPeople();
        savePeople(people);
    }

    private void savePeople(Collection<Person> people) {
        List<Person> peopleBatch = new ArrayList<Person>();
        List<Long> executionTimes = new ArrayList<Long>();
        int i = 0;
        for (Person person : people) {
            peopleBatch.add(person);
            if (peopleBatch.size() == 20) {
                System.out.println("Saving batch number " + i);
                long time = System.currentTimeMillis();
                personService.save(peopleBatch.toArray(new Person[]{}));

                final long timeTaken = System.currentTimeMillis() - time;
                executionTimes.add(timeTaken);
                System.out.println("Finished saving batch number " + i + "in " + timeTaken + "millis");
                peopleBatch = new ArrayList<Person>();
                i++;
            }
        }
        int numberOfExecution = i;
        Long totalTime = new Long(0);
        for(Long l : executionTimes) {
            totalTime = totalTime + l;
        }

        System.out.println("Average " + totalTime / numberOfExecution + "ms per batch");

    }

}
