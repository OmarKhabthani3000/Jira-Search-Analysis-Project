package com.amin.hibernate.search.jms.people;

import java.util.List;

import com.amin.hibernate.search.jms.ParentOfBirthEvent;
import com.amin.hibernate.search.jms.Event;
import com.amin.hibernate.search.jms.Person;
import com.amin.hibernate.search.jms.service.PersonService;
import static junit.framework.Assert.assertTrue;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * people
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 22, 2010
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/repository-context-hibernate.xml"})
public class PersonServiceTest {

    @Autowired
    private PersonService personService;

    @Autowired
    private TransactionTemplate transactionTemplate;


    @Autowired private HibernateTemplate hibernateTemplate;


    @Test
    public void savePeople() {

        //transactionTemplate.execute(new TransactionCallbackWithoutResult() {
          //  @Override
         //   protected void doInTransactionWithoutResult(TransactionStatus transactionStatus) {
                for (int i = 0; i < 1000; i++) {
                    personService.save(createParentAndChild());
                }
            //}
        //});

        final List people = hibernateTemplate.find("from com.amin.hibernate.search.jms.Person");


        assertTrue(people.size() == 2000);

//        assertTrue(peopleSaved.size() > 0);
    }

    private Person[] createParentAndChild() {
        Person[] people = new Person[2];
        Person parent = new Person();
        Person child = new Person();
        connectChildToParent(child, parent);
        people[0] = parent;
        people[1] = child;
        return people;
    }

    private void connectChildToParent(Person child, Person parent) {
        Event birthEvent = child.getBirthEvent();
        child.setBirthEvent(birthEvent);
        ParentOfBirthEvent parentOfBirthEvent = new ParentOfBirthEvent(parent, child.getBirthEvent());
        parent.getParentOfBirthEvents().add(parentOfBirthEvent);
    }

}


