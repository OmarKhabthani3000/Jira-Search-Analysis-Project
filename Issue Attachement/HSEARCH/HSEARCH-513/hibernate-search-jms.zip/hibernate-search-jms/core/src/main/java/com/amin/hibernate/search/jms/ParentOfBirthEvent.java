package com.amin.hibernate.search.jms;

import java.io.Serializable;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.IndexedEmbedded;

/**
 * ParentOfBirthEvent
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 22, 2010
 */
public class ParentOfBirthEvent implements Serializable {

    private Long id;

    @IndexedEmbedded
    private Person parent;

    @ContainedIn
    private Event event;

    public ParentOfBirthEvent(Person parent, Event event) {
        this.parent = parent;
        this.event = event;
        event.getParentsOf().add(this);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Person getParent() {
        return parent;
    }

    public void setParent(Person parent) {
        this.parent = parent;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ParentOfBirthEvent that = (ParentOfBirthEvent) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
