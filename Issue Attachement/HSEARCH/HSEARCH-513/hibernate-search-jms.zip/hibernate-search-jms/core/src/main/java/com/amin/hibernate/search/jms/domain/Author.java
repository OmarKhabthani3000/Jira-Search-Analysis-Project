package com.amin.hibernate.search.jms.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.DateBridge;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Resolution;
import org.hibernate.search.annotations.Store;

/**
 * Author
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 20, 2010
 */
@Entity
@Table(name = "AUTHOR")
public class Author {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "AUTHOR_ID")
    @DocumentId
    private Long id;

    @Column(name = "FIRST_NAME")
    @Field(name = "first.name", store = Store.YES, index = Index.TOKENIZED)
    private String firstName;

    @Column(name = "MIDDLE_NAME")
    @Field(name = "middle.name", store = Store.YES, index = Index.TOKENIZED)
    private String middleName;

    @Column(name = "LAST_NAME")
    @Field(name = "last.name", store = Store.YES, index = Index.TOKENIZED)
    private String lastName;

    @Column(name = "DATE_OF_BIRTH")
    @Field(name = "date.of.birth", store = Store.YES)
    @DateBridge(resolution = Resolution.DAY)
    private Date dateOfBirth;

    @ManyToMany(
            cascade = {CascadeType.PERSIST, CascadeType.MERGE},
            mappedBy = "authors"
    )
    @Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE,
            org.hibernate.annotations.CascadeType.PERSIST})
    @ContainedIn
    private List<Book> books = new ArrayList<Book>();

    @Field(name = "type")
    @Enumerated
    @Column(name = "type")
    private AuthorType type;



    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Author author = (Author) o;

        if (dateOfBirth != null ? !dateOfBirth.equals(author.dateOfBirth) : author.dateOfBirth != null) return false;
        if (firstName != null ? !firstName.equals(author.firstName) : author.firstName != null) return false;
        if (id != null ? !id.equals(author.id) : author.id != null) return false;
        if (lastName != null ? !lastName.equals(author.lastName) : author.lastName != null) return false;
        if (middleName != null ? !middleName.equals(author.middleName) : author.middleName != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (firstName != null ? firstName.hashCode() : 0);
        result = 31 * result + (middleName != null ? middleName.hashCode() : 0);
        result = 31 * result + (lastName != null ? lastName.hashCode() : 0);
        result = 31 * result + (dateOfBirth != null ? dateOfBirth.hashCode() : 0);
        return result;
    }

    public void wrote(Book book) {
        this.books.add(book);
    }

    public List<Book> booksWritten() {
        return Collections.unmodifiableList(books);
    }

    public void setType(AuthorType type) {
        this.type = type;


    }

    public AuthorType getType() {
        return type;
    }

    public enum AuthorType {
        BRILLIANT, AVERAGE;
    }
}
