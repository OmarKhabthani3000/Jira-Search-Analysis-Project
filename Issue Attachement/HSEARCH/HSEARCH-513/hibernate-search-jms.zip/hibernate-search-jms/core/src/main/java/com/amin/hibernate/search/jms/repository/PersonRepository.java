package com.amin.hibernate.search.jms.repository;

import com.amin.hibernate.search.jms.Person;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;

/**
 * PersonRepository
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 22, 2010
 */
public class PersonRepository {
    private HibernateTemplate hibernateTemplate;

    private static final Logger LOGGER = LoggerFactory.getLogger(PersonRepository.class);

    public Person save(Person person) {
        hibernateTemplate.save(person);
        return person;
    }

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }
}
