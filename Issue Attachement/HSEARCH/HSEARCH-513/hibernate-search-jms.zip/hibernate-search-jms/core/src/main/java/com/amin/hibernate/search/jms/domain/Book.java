package com.amin.hibernate.search.jms.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.hibernate.annotations.Cascade;
import org.hibernate.search.annotations.Analyzer;
import org.hibernate.search.annotations.DateBridge;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Resolution;
import org.hibernate.search.annotations.Store;

/**
 * Book
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 20, 2010
 */
@Entity
@Table(name = "BOOK")
@Indexed
@Analyzer(impl = StandardAnalyzer.class)
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "BOOK_ID")
    @DocumentId
    private Long id;

    @IndexedEmbedded
    @ManyToMany(
            targetEntity = Author.class,
            cascade = {CascadeType.PERSIST, CascadeType.MERGE}
    )
    @JoinTable(
            name = "AUTHOR_BOOK",
            joinColumns = {@JoinColumn(name = "AUTHOR_ID")},
            inverseJoinColumns = {@JoinColumn(name = "BOOK_ID")}
    )
    @Cascade(org.hibernate.annotations.CascadeType.SAVE_UPDATE)
    private List<Author> authors = new ArrayList<Author>();


    @Column(name = "DATE_OF_PUBLICATION")
    @Field(store = Store.YES)
    @DateBridge(resolution = Resolution.DAY)
    private Date dateOfPublication;

    @Embedded
    @IndexedEmbedded
    private Isbn isbn;

    public List<Author> getAuthors() {
        return Collections.unmodifiableList(authors);
    }

    public void writtenBy(Author author) {
        if (!authors.contains(author)) {
            author.wrote(this);
            authors.add(author);
        }
    }

    public void remove(Author author) {
        authors.remove(author);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getDateOfPublication() {
        return dateOfPublication;
    }

    public void setDateOfPublication(Date dateOfPublication) {
        this.dateOfPublication = dateOfPublication;
    }

    public Isbn getIsbn() {
        return isbn;
    }

    public void setIsbn(Isbn isbn) {
        this.isbn = isbn;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Book book = (Book) o;

        if (id != null ? !id.equals(book.id) : book.id != null) return false;
        if (isbn != null ? !isbn.equals(book.isbn) : book.isbn != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (isbn != null ? isbn.hashCode() : 0);
        return result;
    }
}
