package com.amin.hibernate.search.jms.domain;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.zip.DataFormatException;

import com.amin.hibernate.search.jms.ParentOfBirthEvent;
import com.amin.hibernate.search.jms.Person;
import org.familysearch.gedcomparser.GedcomParser;
import org.familysearch.gedcomparser.handler.RecordHandler;
import org.familysearch.gedcomparser.record.ChildRecord;
import org.familysearch.gedcomparser.record.FamilyRecord;
import org.familysearch.gedcomparser.record.HeaderRecord;
import org.familysearch.gedcomparser.record.IndividualRecord;
import org.familysearch.gedcomparser.record.MultiMediaRecord;
import org.familysearch.gedcomparser.record.NoteRecord;
import org.familysearch.gedcomparser.record.RepositoryRecord;
import org.familysearch.gedcomparser.record.SourceRecord;
import org.familysearch.gedcomparser.record.SubmissionRecord;
import org.familysearch.gedcomparser.record.SubmitterRecord;
import org.familysearch.gedcomparser.record.TPinDateRecord;

/**
 * GedcomSmall
 *
 * @author: Amin Mohammed-Coleman
 * @since: May 5, 2010
 */
public class GedcomSmall implements RecordHandler {
    private HashMap<String, Person> people;

    public void initialize() {}

    public boolean handleHeaderRecord(HeaderRecord headerRecord) {
        return true;
    }

    public boolean handleSubmissionRecord(SubmissionRecord submissionRecord) {
        return true;
    }

    public boolean handleFamilyRecord(FamilyRecord familyRecord) {
        parseFamily(familyRecord);
        return true;
    }

    public boolean handleIndividualRecord(IndividualRecord individualRecord) {
        parsePerson(individualRecord);
        return true;
    }

    public boolean handleMultiMediaRecord(MultiMediaRecord multiMediaRecord) {
        return true;
    }

    public boolean handleNoteRecord(NoteRecord noteRecord) {
        return true;
    }

    public boolean handleRepositoryRecord(RepositoryRecord repositoryRecord) {
        return true;
    }

    public boolean handleSourceRecord(SourceRecord sourceRecord) {
        return true;
    }

    public boolean handleSubmitterRecord(SubmitterRecord submitterRecord) {
        return true;
    }

    public boolean handleTPinDateRecord(TPinDateRecord tPinDateRecord, String s, String s1) {
        return true;
    }

    public void close() {
    }

    public GedcomSmall(InputStream inputStream, long fileLength) throws IOException, DataFormatException  {
        people = new LinkedHashMap<String, Person>();
        parseGedcom(inputStream, fileLength);
    }

    private boolean parseGedcom(InputStream inputStream, long fileLength) throws IOException, DataFormatException {
        GedcomParser gedcomParser = new GedcomParser();
        return gedcomParser.importGedcomFile(inputStream, fileLength, new GedcomProgressListener(), this);
    }

    private void parsePerson(IndividualRecord individualRecord) {
        people.put(individualRecord.getId(), new Person());
    }

    private void parseFamily(FamilyRecord familyRecord) {
        Person father = familyRecord.getHusbandId() != null ? people.get(familyRecord.getHusbandId()) : null;
        Person mother = familyRecord.getWifeId() != null ? people.get(familyRecord.getWifeId()) : null;
        if (father == mother)
            mother = null;
        if (familyRecord.getChildrenInfos() != null) {
            for (ChildRecord child : familyRecord.getChildrenInfos()) {
                trySettingParent(people.get(child.getChildGedcomId()), father);
                trySettingParent(people.get(child.getChildGedcomId()), mother);
            }
        }
    }

    private void trySettingParent(Person child, Person parent) {
        if (child.getBirthEvent().getParentsOf().size() < 2 && parent != null)
            setParent(child, parent);
    }

    private void setParent(Person child, Person parent) {
        ParentOfBirthEvent parentOfBirthEvent = new ParentOfBirthEvent(parent, child.getBirthEvent());
        parent.getParentOfBirthEvents().add(parentOfBirthEvent);
    }

    public Collection<Person> getPeople() {
        return people.values();
    }
}
