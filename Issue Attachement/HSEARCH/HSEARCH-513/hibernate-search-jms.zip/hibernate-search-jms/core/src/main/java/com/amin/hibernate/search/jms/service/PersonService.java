package com.amin.hibernate.search.jms.service;

import java.util.ArrayList;
import java.util.List;

import com.amin.hibernate.search.jms.Person;
import com.amin.hibernate.search.jms.repository.PersonRepository;

/**
 * PersonService
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 22, 2010
 */
public class PersonService {

    private PersonRepository personRepository;


    public List<Person> save(Person[] people) {
        List<Person> peopleSaved = new ArrayList<Person>();
        for (Person person: people) {
            personRepository.save(person);
            peopleSaved.add(person);
        }

        return peopleSaved;
    }

    public void setPersonRepository(PersonRepository personRepository) {
        this.personRepository =personRepository;
    }
}
