package com.amin.hibernate.search.jms;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.Set;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

/**
 * Person
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 22, 2010
 */
@Indexed
public class Person implements Serializable {

    @DocumentId
    private Long id;

    @ContainedIn
    private Set<ParentOfBirthEvent> parentOfBirthEvents;

    @IndexedEmbedded(depth = 4)
    private Event birthEvent;

    public Person() {
        birthEvent = new Event();
        birthEvent.getChildren().add(this);
        parentOfBirthEvents = new LinkedHashSet<ParentOfBirthEvent>();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Set<ParentOfBirthEvent> getParentOfBirthEvents() {
        return parentOfBirthEvents;
    }

    public void setParentOfBirthEvents(Set<ParentOfBirthEvent> parentOfBirthEvents) {
        this.parentOfBirthEvents = parentOfBirthEvents;
    }

    public Event getBirthEvent() {
        return birthEvent;
    }

    public void setBirthEvent(Event birthEvent) {
        this.birthEvent = birthEvent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Person person = (Person) o;

        if (id != null ? !id.equals(person.id) : person.id != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
