package com.amin.hibernate.search.jms.repository;

import java.sql.SQLException;
import java.util.List;

import com.amin.hibernate.search.jms.domain.Book;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.util.Version;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.SearchFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

/**
 * BookRepository
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 20, 2010
 */
@Repository
public class BookRepository {

    @Autowired
    private HibernateTemplate hibernateTemplate;

    private static final Logger LOGGER = LoggerFactory.getLogger(BookRepository.class);


    private final String[] FIELD_NAMES = new String[]{"dateOfPublication",
            "authors.first.name",
            "authors.middle.name",
            "authors.last.name",
            "authors.date.of.birth",
            "isbn.number", "authors.type"};

    public Book create(Book book) {
        LOGGER.info("Creating a new book");
        hibernateTemplate.save(book);
        return book;
    }

    public Book findBy(Long id) {
        LOGGER.info("Finding a book using id");
        return hibernateTemplate.get(Book.class, id);
    }


    public Book update(Book book) {
        LOGGER.info("Updating an existing book");

        hibernateTemplate.update(book);
        return book;
    }

    public List<Book> search(final String term) {
        LOGGER.info("Performing a free text search");

        return hibernateTemplate.execute(new HibernateCallback<List<Book>>() {
            public List<Book> doInHibernate(Session session) throws HibernateException, SQLException {
                FullTextSession fullTextSession = org.hibernate.search.Search.getFullTextSession(session);
                SearchFactory searchFactory = fullTextSession.getSearchFactory();
                Analyzer entityScopedAnalyzer = searchFactory.getAnalyzer(Book.class);


                if (entityScopedAnalyzer == null) {
                    entityScopedAnalyzer = new StandardAnalyzer(Version.LUCENE_29);
                }

                QueryParser parser = new MultiFieldQueryParser(Version.LUCENE_29, FIELD_NAMES, entityScopedAnalyzer);
                org.apache.lucene.search.Query query = null;
                try {
                    query = parser.parse(term);
                } catch (Exception e) {
                    throw new IllegalStateException(e);
                }

                FullTextQuery fullTextQuery = fullTextSession.createFullTextQuery(query, Book.class);
                org.hibernate.Query hibQuery = fullTextQuery;

                return hibQuery.list();

            }
        });
    }
}
