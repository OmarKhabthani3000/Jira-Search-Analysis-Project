package com.amin.hibernate.search.jms.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Store;

/**
 * Isbn
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 20, 2010
 */
@Embeddable
public class Isbn {

    @Column(name = "ISBN_NUMBER")
    @Field(name = "number", store = Store.YES, index = Index.UN_TOKENIZED)
    private String number;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }


}
