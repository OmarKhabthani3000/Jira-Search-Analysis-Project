package com.amin.hibernate.search.jms;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.IndexedEmbedded;

/**
 * Event
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 22, 2010
 */
public class Event implements Serializable {

    protected Long id;

    @IndexedEmbedded
    protected Set<ParentOfBirthEvent> parentsOf;


    @ContainedIn
    protected Set<Person> children;

    public Event() {
        parentsOf = new HashSet<ParentOfBirthEvent>();
        children = new HashSet<Person>();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Set<ParentOfBirthEvent> getParentsOf() {
        return parentsOf;
    }

    public void setParentsOf(Set<ParentOfBirthEvent> parentsOf) {
        this.parentsOf = parentsOf;
    }

    public Set<Person> getChildren() {
        return children;
    }

    public void setChildren(Set<Person> children) {
        this.children = children;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Event event = (Event) o;

        if (id != null ? !id.equals(event.id) : event.id != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
