package com.amin.hibernate.search.jms.domain;


import org.familysearch.gedcomparser.ProgressListener;

/**
 * GedcomProgressListener
 *
 * @author: Amin Mohammed-Coleman
 * @since: May 5, 2010
 */
public class GedcomProgressListener implements ProgressListener {

    public void setFileSize(long l) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void updateRemaining(long l) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void importingPerson() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void importingFamily() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void importingHeader() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void importingSubmission() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void importingMedia() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void importingNote() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void importingRepository() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void importingSource() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void importingSubmitter() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void importingTPinDate() {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}

