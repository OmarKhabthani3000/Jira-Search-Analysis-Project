
    create table AUTHOR (
        AUTHOR_ID INTEGER not null auto_increment,
        DATE_OF_BIRTH timestamp ,
        FIRST_NAME varchar(255),
        LAST_NAME varchar(255),
        MIDDLE_NAME varchar(255),
        primary key (AUTHOR_ID)
    ) ENGINE=InnoDB;

    create table AUTHOR_BOOK (
        AUTHOR_ID INTEGER not null,
        BOOK_ID INTEGER not null
    ) ENGINE=InnoDB;

    create table BOOK (
        BOOK_ID INTEGER not null auto_increment,
        DATE_OF_PUBLICATION datetime,
        ISBN_NUMBER varchar(255),
        primary key (BOOK_ID)
    ) ENGINE=InnoDB;

    alter table AUTHOR_BOOK 
        add constraint BOOK_FK
        foreign key (BOOK_ID) 
        references AUTHOR (AUTHOR_ID);

    alter table AUTHOR_BOOK 
        add constraint AUTHOR_FK 
        foreign key (AUTHOR_ID) 
        references BOOK (BOOK_ID);
