import org.apache.wicket.Page;
import org.apache.wicket.PageParameters;
import org.apache.wicket.markup.html.WebPage;


public class MyPage extends WebPage {
    public MyPage() {
        super()
                ;
    }

    public MyPage(PageParameters parameters) {
        super(parameters);
    }
}
