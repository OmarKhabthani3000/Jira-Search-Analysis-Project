package org.hradil.search.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;

/**
 * Entita reprezentuje firmu.
 * Firmu lze ve fulltextu vyhledat podle id, name a regNo.
 * 
 * @author jirka@hradil.org
 */
@Entity
@Table(name = "company")
@Indexed //tridu budeme chtit indexovat ve fulltextu
public class Company implements Serializable {

    private static final long serialVersionUID = 1216348069826762176L;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
   
    @DocumentId //primarni klic objektu ve fulltextu, zaroven podle nej muzeme vyhledavat
    private int id;

    @Column
    @Field //ve fulltextu chceme hledat firmu podle nazvu
    private String name;

    @Column
    @Field //ve fulltextu chceme hledat firmu podle IC
    private String regNo;

    /**
     * Vytvori novou firmu.
     */
    public Company() {
    }

    /**
     * Vytvori novou firmu a predvyplni atributy.
     * @param name nazev firmy
     * @param regNo IC
     */
    public Company(final String name, final String regNo) {
        this.name = name;
        this.regNo = regNo;
    }

    /**
     * Vrati id firmy
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     * Nastavi id firmy
     * @param id id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Vrati nazev firmy.
     * @return nazev
     */
    public String getName() {
        return name;
    }

    /**
     * Nastavi nazev firmy.
     * @param name nazev
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Vrati IC firmy.
     * @return IC
     */
    public String getRegNo() {
        return regNo;
    }

    /**
     * Nastavi IC firmy.
     * @param regNo IC
     */
    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }
}
