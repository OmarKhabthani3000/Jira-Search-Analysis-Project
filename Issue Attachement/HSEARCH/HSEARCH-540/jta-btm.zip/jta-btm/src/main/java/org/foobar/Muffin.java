package org.foobar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.search.annotations.Analyzer;
import org.hibernate.search.annotations.Indexed;

// Hibernate
@Entity
@Table(name = "muffin")
@Cache(usage=CacheConcurrencyStrategy.TRANSACTIONAL, region="muffin")
// Hibernate Search
//@Indexed(index="Muffin")
//@Analyzer(impl = StandardAnalyzer.class)
public class Muffin {
	@Id()
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long muffinId;
	
	@ManyToOne
	private Box box;
	
	@Column(length = 255,nullable=false)
	private String kind;
	
	public Muffin() {
	}

	/**
	 * @return the muffinId
	 */
	public Long getMuffinId() {
		return muffinId;
	}

	/**
	 * @param muffinId the muffinId to set
	 */
	public void setMuffinId(Long muffinId) {
		this.muffinId = muffinId;
	}

	/**
	 * @return the box
	 */
	public Box getBox() {
		return box;
	}

	/**
	 * @param box the box to set
	 */
	public void setBox(Box box) {
		this.box = box;
	}

	/**
	 * @return the kind
	 */
	public String getKind() {
		return kind;
	}

	/**
	 * @param kind the kind to set
	 */
	public void setKind(String kind) {
		this.kind = kind;
	}
	
	
}
