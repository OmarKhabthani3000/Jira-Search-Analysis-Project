package org.foobar;

import javax.inject.Inject;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class MuffinDAO {
	@Inject
	private SessionFactory sessionFactory;

	@Transactional
	public void persist(Muffin muffin) {
		sessionFactory.getCurrentSession().save(muffin);
	}

	@Transactional
	public void merge(Muffin muffin) {
		sessionFactory.getCurrentSession().merge(muffin);
	}

	@Transactional
	public void remove(Muffin muffin) {
		sessionFactory.getCurrentSession().delete(muffin);
	}
}
