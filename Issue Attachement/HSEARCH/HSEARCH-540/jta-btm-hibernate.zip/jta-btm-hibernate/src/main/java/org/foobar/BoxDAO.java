package org.foobar;

import javax.inject.Inject;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class BoxDAO {
	
	@Inject
	private SessionFactory sessionFactory;

	@Transactional
	public void persist(Box box) {
		sessionFactory.getCurrentSession().save(box);
	}

	@Transactional
	public Box merge(Box box) {
		Box result = (Box) sessionFactory.getCurrentSession().merge(box);
		
		return result;
	}

	@Transactional
	public void remove(Box box) {
		sessionFactory.getCurrentSession().delete(box);
	}
}
