package embedded.test;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Store;

@Entity
@Indexed
public class B
{
	@Id
	@GeneratedValue
	@DocumentId
	private Long id;
	
	@Field(index=Index.TOKENIZED, store=Store.YES)
	private String name;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@IndexedEmbedded
	private C c;

	public C getC()
	{
		return c;
	}

	public void setC(C c)
	{
		this.c = c;
	}

	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}
}
