package embedded.test;

import java.util.List;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;

// A contains a B which contains a C
// Each object has a property called 'name'
// We should be able to access:
//    name
//    b.name
//    b.c.name (this doesn't seem to work)

public class EmbeddedTest extends SearchTestCase
{
	public void testEmbeddedEmbedded() throws Exception
	{
		Session s = openSession();
		Transaction tx = s.beginTransaction();

		A a = new A();
		a.setName("AName");

		B b = new B();
		b.setName("BName");

		C c = new C();
		c.setName("CName");

		b.setC(c);
		a.setB(b);

		s.persist(a);
		tx.commit();

		FullTextSession session = Search.createFullTextSession(s);
		QueryParser parser = new QueryParser("id", new StandardAnalyzer());
		Query query;
		List result;

		// Finding the property on the base object works as expected
		query = parser.parse("name:AName");
		result = session.createFullTextQuery(query).list();
		assertEquals("unable to find property", 1, result.size());

		s.clear();

		// As does one level down
		query = parser.parse("b.name:BName");
		result = session.createFullTextQuery(query).list();
		assertEquals("unable to find property in embedded", 1, result.size());

		s.clear();

		// Finding a child property of a child does not seem to work
		query = parser.parse("b.c.name:CName");
		result = session.createFullTextQuery(query).list();
		assertEquals("unable to find property in embedded-embedded", 1, result
				.size());

		s.close();
	}

	@Override
	protected Class[] getMappings()
	{
		return new Class[]
		{ A.class, B.class, C.class, };
	}

}
