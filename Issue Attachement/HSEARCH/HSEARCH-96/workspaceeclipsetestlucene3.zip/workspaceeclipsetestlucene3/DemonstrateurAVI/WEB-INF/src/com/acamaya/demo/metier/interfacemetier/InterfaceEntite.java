package com.acamaya.demo.metier.interfacemetier;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.acamaya.demo.dao.modele.Entite;
import com.acamaya.demo.dao.utilitaires.GestionEntite;
import com.acamaya.demo.dao.utilitaires.HibernateUtil;

public class InterfaceEntite
{
	public static Entite ajouterEntite(String titre, String resume)
	{
		// mise a jour donnees persistantes
		GestionEntite gestionEntite = new GestionEntite();
		Session session = HibernateUtil.getSessionActuelle();
		Transaction tx = session.beginTransaction();

		// ajout de l'entite en base
		Entite entite = gestionEntite.getListeEntites().ajouterEntite(new Entite(titre,resume));

		// met a jour la base, mais ne commit pas les donnees
		session.flush();

		// fin de la transaction, on commit les donnees en base
		tx.commit();

		return entite;
	}
}
