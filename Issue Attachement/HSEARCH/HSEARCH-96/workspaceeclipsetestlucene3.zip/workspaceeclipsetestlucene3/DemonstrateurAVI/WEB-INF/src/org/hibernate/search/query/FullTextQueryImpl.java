//$Id: FullTextQueryImpl.java 11631 2007-06-05 15:48:42Z epbernard $
package org.hibernate.search.query;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.TermQuery;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.annotations.common.util.ReflectHelper;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.engine.query.ParameterMetadata;
import org.hibernate.impl.AbstractQueryImpl;
import org.hibernate.impl.CriteriaImpl;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.SearchException;
import org.hibernate.search.impl.SearchFactoryImpl;
import org.hibernate.search.engine.DocumentBuilder;
import org.hibernate.search.engine.DocumentExtractor;
import org.hibernate.search.engine.EntityInfo;
import org.hibernate.search.engine.Loader;
import org.hibernate.search.engine.ObjectLoader;
import org.hibernate.search.engine.ProjectionLoader;
import org.hibernate.search.engine.QueryLoader;
import org.hibernate.search.engine.SearchFactoryImplementor;
import org.hibernate.search.store.DirectoryProvider;
import org.hibernate.search.util.ContextHelper;

/**
 * Implementation of {@link org.hibernate.search.FullTextQuery}
 *
 * @author Emmanuel Bernard
 * @author Hardy Ferentschik
 */
//TODO implements setParameter()
public class FullTextQueryImpl extends AbstractQueryImpl implements FullTextQuery {
	private static final Log log = LogFactory.getLog( FullTextQueryImpl.class );
	private org.apache.lucene.search.Query luceneQuery;
	private Class[] classes;
	private Set<Class> classesAndSubclasses;
	private Integer firstResult;
	private Integer maxResults;
	private Integer resultSize;
	private Sort sort;
	private Criteria criteria;
	private String[] indexProjection;

	/**
	 * classes must be immutable
	 */
	public FullTextQueryImpl(org.apache.lucene.search.Query query, Class[] classes, SessionImplementor session,
							 ParameterMetadata parameterMetadata) {
		//TODO handle flushMode
		super( query.toString(), null, session, parameterMetadata );
		this.luceneQuery = query;
		this.classes = classes;
	}


	public FullTextQuery setSort(Sort sort) {
		this.sort = sort;
		return this;
	}

	/**
	 * Return an interator on the results.
	 * Retrieve the object one by one (initialize it during the next() operation)
	 */
	public Iterator iterate() throws HibernateException {
		//implement an interator which keep the id/class for each hit and get the object on demand
		//cause I can't keep the searcher and hence the hit opened. I dont have any hook to know when the
		//user stop using it
		//scrollable is better in this area

		SearchFactoryImplementor searchFactoryImplementor = ContextHelper.getSearchFactoryBySFI( session );
		//find the directories
		IndexSearcher searcher = buildSearcher( searchFactoryImplementor );
		if ( searcher == null ) {
		   	return new IteratorImpl( new ArrayList<EntityInfo>(0), noLoader );
		}
		try {
			Hits hits = getHits( searcher );
			int first = first();
			int max = max( first, hits );
			Session sess = (Session) this.session;

			List<EntityInfo> entityInfos = new ArrayList<EntityInfo>( max - first + 1 );
			DocumentExtractor extractor = new DocumentExtractor( searchFactoryImplementor, indexProjection );
			for ( int index = first; index <= max; index++ ) {
				//TODO use indexSearcher.getIndexReader().document( hits.id(index), FieldSelector(indexProjection) );
				Document document = hits.doc( index );
				entityInfos.add( extractor.extract( document ) );
			}
			Loader loader = getLoader(sess, searchFactoryImplementor);
			return new IteratorImpl( entityInfos, loader );
		}
		catch (IOException e) {
			throw new HibernateException( "Unable to query Lucene index", e );
		}
		finally {
			try {
				searchFactoryImplementor.getReaderProvider().closeReader( searcher.getIndexReader() );
			}
			catch( SearchException e ) {
				log.warn( "Unable to properly close searcher during lucene query: " + getQueryString(), e );
			}
		}
	}

	private Loader getLoader(Session session, SearchFactoryImplementor searchFactoryImplementor) {
		if ( indexProjection != null) {
			ProjectionLoader loader = new ProjectionLoader();
			loader.init( session, searchFactoryImplementor );
			return loader;
		}
		if (criteria != null) {
			if (classes.length > 1) throw new SearchException("Cannot mix criteria and multiple entity types");
			if ( criteria instanceof CriteriaImpl ) {
				String targetEntity = ( (CriteriaImpl) criteria).getEntityOrClassName();
				if ( classes.length == 1 && !classes[0].getName().equals( targetEntity ) ) {
					throw new SearchException("Criteria query entity should match query entity");
				}
				else {
					try {
						Class entityType = ReflectHelper.classForName( targetEntity );
						classes = new Class[] { entityType };
					}
					catch (ClassNotFoundException e) {
						throw new SearchException("Unable to load entity class from criteria: " + targetEntity, e);
					}
				}
			}
			QueryLoader loader = new QueryLoader();
			loader.init( session, searchFactoryImplementor );
			loader.setEntityType( classes[0] );
			loader.setCriteria(criteria);
			return loader;
		}
		else if (classes.length == 1) {
			QueryLoader loader = new QueryLoader();
			loader.init( session, searchFactoryImplementor );
			loader.setEntityType( classes[0] );
			return loader;
		}
		else {
			final ObjectLoader objectLoader = new ObjectLoader();
			objectLoader.init( session, searchFactoryImplementor );
			return objectLoader;
		}
	}

	public ScrollableResults scroll() throws HibernateException {
		//keep the searcher open until the resultset is closed
		SearchFactoryImplementor searchFactory = ContextHelper.getSearchFactoryBySFI( session );

		//find the directories
		IndexSearcher searcher = buildSearcher( searchFactory );
		//FIXME: handle null searcher
		Hits hits;
		try {
			hits = getHits( searcher );
			int first = first();
			int max = max( first, hits );
			DocumentExtractor extractor = new DocumentExtractor( searchFactory, indexProjection );
			Loader loader = getLoader( (Session) this.session, searchFactory );
			return new ScrollableResultsImpl( searcher, hits, first, max, extractor, loader, searchFactory);
		}
		catch (IOException e) {
			//close only in case of exception
			try {
				searchFactory.getReaderProvider().closeReader( searcher.getIndexReader() );
			}
			catch( SearchException ee ) {
				//we have the initial issue already
			}
			throw new HibernateException( "Unable to query Lucene index", e );
		}
	}

	public ScrollableResults scroll(ScrollMode scrollMode) throws HibernateException {
		//TODO think about this scrollmode
		return scroll();
	}

	public List list() throws HibernateException {
		SearchFactoryImplementor searchFactoryImplementor = ContextHelper.getSearchFactoryBySFI( session );
		//find the directories
		IndexSearcher searcher = buildSearcher( searchFactoryImplementor );
		if (searcher == null) return new ArrayList(0);
		Hits hits;
		try {
			hits = getHits( searcher );
			int first = first();
			int max = max( first, hits );
			Session sess = (Session) this.session;
			List<EntityInfo> infos = new ArrayList<EntityInfo>( max - first + 1 );
			DocumentExtractor extractor = new DocumentExtractor( searchFactoryImplementor, indexProjection );
			for ( int index = first; index <= max; index++ ) {
				Document document = hits.doc( index );
				infos.add( extractor.extract( document ) );
			}
			Loader loader = getLoader( sess, searchFactoryImplementor );
			return loader.load( infos.toArray( new EntityInfo[infos.size()]) );
		}
		catch (IOException e) {
			throw new HibernateException( "Unable to query Lucene index", e );
		}
		finally {
			try {
				searchFactoryImplementor.getReaderProvider().closeReader( searcher.getIndexReader() );
			}
			catch (SearchException e) {
				log.warn( "Unable to properly close searcher during lucene query: " + getQueryString(), e );
			}
		}
	}

	/**
	 * Execute the lucene search and return the machting hits.
	 *
	 * @param searcher The index searcher.
	 * @return The lucene hits.
	 * @throws IOException in case there is an error executing the lucene search.
	 */
	private Hits getHits(Searcher searcher) throws IOException {
		Hits hits;
		org.apache.lucene.search.Query query = filterQueryByClasses( luceneQuery );
		if(sort == null){
			hits = searcher.search( query );
		}
		else {
			hits = searcher.search( query, sort );
		}
		setResultSize( hits );
		return hits;
	}

	private org.apache.lucene.search.Query filterQueryByClasses(org.apache.lucene.search.Query luceneQuery) {
		//A query filter is more practical than a manual class filtering post query (esp on scrollable resultsets)
		//it also probably minimise the memory footprint
		if ( classesAndSubclasses == null ) {
			return luceneQuery;
		}
		else {
			BooleanQuery classFilter = new BooleanQuery();
			//annihilate the scoring impact of DocumentBuilder.CLASS_FIELDNAME
			classFilter.setBoost( 0 );
			for ( Class clazz : classesAndSubclasses ) {
				Term t = new Term( DocumentBuilder.CLASS_FIELDNAME, clazz.getName() );
				TermQuery termQuery = new TermQuery( t );
				classFilter.add( termQuery, BooleanClause.Occur.SHOULD );
			}
			BooleanQuery filteredQuery = new BooleanQuery();
			filteredQuery.add( luceneQuery, BooleanClause.Occur.MUST );
			filteredQuery.add( classFilter, BooleanClause.Occur.MUST );
			return filteredQuery;
		}
	}

	private int max(int first, Hits hits) {
		return maxResults == null ?
				hits.length() - 1 :
				maxResults + first < hits.length() ?
						first + maxResults - 1 :
						hits.length() - 1;
	}

	private int first() {
		return firstResult != null ?
				firstResult :
				0;
	}


	/**
	 * can return null
	 * TODO change classesAndSubclasses by side effect, which is a mismatch with the Searcher return, fix that.
	 */
	private IndexSearcher buildSearcher(SearchFactoryImplementor searchFactoryImplementor) {
		Map<Class, DocumentBuilder<Object>> builders = searchFactoryImplementor.getDocumentBuilders();
		List<DirectoryProvider> directories = new ArrayList<DirectoryProvider>();
		if ( classes == null || classes.length == 0 ) {
			//no class means all classes
			for ( DocumentBuilder builder : builders.values() ) {
				final DirectoryProvider directoryProvider = builder.getDirectoryProvider();
				if ( ! directories.contains( directoryProvider ) ) {
					directories.add( directoryProvider );
				}
			}
			classesAndSubclasses = null;
		}
		else {
			Set<Class> involvedClasses = new HashSet<Class>( classes.length );
			Collections.addAll( involvedClasses, classes );
			for ( Class clazz : classes ) {
				DocumentBuilder builder = builders.get( clazz );
				if ( builder != null ) involvedClasses.addAll( builder.getMappedSubclasses() );
			}
			for ( Class clazz : involvedClasses ) {
				DocumentBuilder builder = builders.get( clazz );
				//TODO should we rather choose a polymorphic path and allow non mapped entities
				if ( builder == null ) throw new HibernateException( "Not a mapped entity: " + clazz );
				final DirectoryProvider directoryProvider = builder.getDirectoryProvider();
				if ( ! directories.contains( directoryProvider ) ) {
					directories.add( directoryProvider );
				}
			}
			classesAndSubclasses = involvedClasses;
		}

		//set up the searcher
		final DirectoryProvider[] directoryProviders = directories.toArray( new DirectoryProvider[directories.size()] );
		return new IndexSearcher( searchFactoryImplementor.getReaderProvider().openReader( directoryProviders ) );
	}

	private void setResultSize(Hits hits) {
		resultSize = hits.length();
	}


	public int getResultSize() {
		if (resultSize == null) {
			//get result size without object initialization
			SearchFactoryImplementor searchFactoryImplementor = ContextHelper.getSearchFactoryBySFI( session );
			IndexSearcher searcher = buildSearcher( searchFactoryImplementor );
			if (searcher == null) {
				resultSize = 0;
			}
			else {
				Hits hits;
				try {
					hits = getHits( searcher );
					resultSize = hits.length();
				}
				catch (IOException e) {
					throw new HibernateException( "Unable to query Lucene index", e );
				}
				finally {
					//searcher cannot be null
					try {
						searchFactoryImplementor.getReaderProvider().closeReader( searcher.getIndexReader() );
					}
					catch( SearchException e ) {
						log.warn( "Unable to properly close searcher during lucene query: " + getQueryString(), e );
					}
				}
			}
		}
		return this.resultSize;
	}

	public FullTextQuery setCriteriaQuery(Criteria criteria) {
		this.criteria = criteria;
		return this;
	}

	public FullTextQuery setIndexProjection(String... fields) {
		if ( fields == null || fields.length == 0) {
			this.indexProjection = null;
		}
		else {
			this.indexProjection = fields;
		}
		return this;
	}

	public FullTextQuery setFirstResult(int firstResult) {
		this.firstResult = firstResult;
		return this;
	}

	public FullTextQuery setMaxResults(int maxResults) {
		this.maxResults = maxResults;
		return this;
	}

	public int executeUpdate() throws HibernateException {
		throw new HibernateException( "Not supported operation" );
	}

	public Query setLockMode(String alias, LockMode lockMode) {
		return null;
	}

	protected Map getLockModes() {
		return null;
	}

	private static Loader noLoader = new Loader() {
		public void init(Session session, SearchFactoryImplementor searchFactoryImplementor) {
		}

		public Object load(EntityInfo entityInfo) {
			throw new UnsupportedOperationException( "noLoader should not be used" );
		}

		public List load(EntityInfo... entityInfos) {
			throw new UnsupportedOperationException( "noLoader should not be used" );
		}
	};
}
