//$Id: WorkType.java 11625 2007-06-04 16:21:54Z epbernard $
package org.hibernate.search.backend;

/**
 * @author Emmanuel Bernard
 */
public enum WorkType {
	ADD,
	UPDATE,
	DELETE
	//add INDEX at some point to behave differently during the queue process?
}
