package com.acamaya.demo.dao.utilitaires;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.acamaya.demo.dao.modele.ListeEntites;

public class GestionEntite
{
	private ListeEntites listeEntites;

	public GestionEntite()
	{
		// recuperation des donnees presistantes
		Session session = HibernateUtil.getSessionActuelle();


		listeEntites = (ListeEntites) session.get(ListeEntites.class,new Integer(1));
		
		// si rien n'est present dans la base, on le cree
		if(listeEntites == null)
		{
			// demarre une transaction
			Transaction tx = session.beginTransaction();
			
			listeEntites = new ListeEntites();
			session.persist(listeEntites); // listeEntites devient persistant

			tx.commit();
		}
		
	}

	public ListeEntites getListeEntites() {
		return listeEntites;
	}

	public void setListeEntites(ListeEntites listeEntites) {
		this.listeEntites = listeEntites;
	}
}
