//$Id: LuceneBackendQueueProcessor.java 11700 2007-06-22 19:39:47Z epbernard $
package org.hibernate.search.backend.impl.lucene;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.hibernate.search.backend.AddLuceneWork;
import org.hibernate.search.backend.LuceneWork;
import org.hibernate.search.backend.Workspace;
import org.hibernate.search.backend.OptimizeLuceneWork;
import org.hibernate.search.engine.SearchFactoryImplementor;
import org.hibernate.search.store.DirectoryProvider;

/**
 * Apply the operations to Lucene directories
 * avoiding deadlocks
 *
 * @author Emmanuel Bernard
 */
public class LuceneBackendQueueProcessor implements Runnable {
	private List<LuceneWork> queue;
	private SearchFactoryImplementor searchFactoryImplementor;

	public LuceneBackendQueueProcessor(List<LuceneWork> queue, SearchFactoryImplementor searchFactoryImplementor) {
		this.queue = queue;
		this.searchFactoryImplementor = searchFactoryImplementor;
	}

	public void run() {
		Workspace workspace;
		LuceneWorker worker;
		workspace = new Workspace( searchFactoryImplementor );
		worker = new LuceneWorker( workspace );
		try {
			deadlockFreeQueue(queue, workspace, searchFactoryImplementor);
			for ( LuceneWork luceneWork : queue ) {
				worker.performWork( luceneWork );
			}
		}
		finally {
			workspace.clean();
			queue.clear();
		}
	}

	/**
	 * one must lock the directory providers in the exact same order to avoid
	 * dead lock between concurrent threads or processes
	 * To achieve that, the work will be done per directory provider
	 */
	private void deadlockFreeQueue(List<LuceneWork> queue, final Workspace workspace, final SearchFactoryImplementor searchFactoryImplementor) {
		Collections.sort( queue, new Comparator<LuceneWork>() {
			public int compare(LuceneWork o1, LuceneWork o2) {
				long h1 = getWorkHashCode( o1, searchFactoryImplementor );
				long h2 = getWorkHashCode( o2, searchFactoryImplementor );
				return h1 < h2 ?
						-1 :
						h1 == h2 ?
							0 :
							1;
			}
		} );
	}

	private long getWorkHashCode(LuceneWork luceneWork, SearchFactoryImplementor searchFactoryImplementor) {
		Class entity = luceneWork.getEntityClass();
		DirectoryProvider provider = searchFactoryImplementor.getDirectoryProvider( entity );
		int h = provider.getClass().hashCode();
		h = 31 * h + provider.hashCode();
		long extendedHash = h; //to be sure extendedHash + 1 < extendedHash + 2 is always true
		if ( luceneWork instanceof AddLuceneWork ) extendedHash+=1; //addwork after deleteWork
		if ( luceneWork instanceof OptimizeLuceneWork ) extendedHash+=2; //optimize after everything
		return extendedHash;
	}
}
