//$Id: ScrollableResultsImpl.java 11625 2007-06-04 16:21:54Z epbernard $
package org.hibernate.search.query;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Blob;
import java.sql.Clob;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.document.Document;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.hibernate.HibernateException;
import org.hibernate.ScrollableResults;
import org.hibernate.search.SearchException;
import org.hibernate.search.SearchFactory;
import org.hibernate.search.engine.DocumentExtractor;
import org.hibernate.search.engine.EntityInfo;
import org.hibernate.search.engine.Loader;
import org.hibernate.type.Type;

/**
 * Implements scollable and paginated resultsets.
 * Contrary to query#iterate() or query#list(), this implementation is
 * exposed to returned null objects (if the index is out of date).
 *
 * @author Emmanuel Bernard
 */
public class ScrollableResultsImpl implements ScrollableResults {
	private static Log log = LogFactory.getLog( ScrollableResultsImpl.class );
	private final IndexSearcher searcher;
	private final SearchFactory searchFactory;
	private final Hits hits;
	private final int first;
	private final int max;
	private int current;
	private EntityInfo[] entityInfos;
	private Loader loader;
	private DocumentExtractor documentExtractor;
	private Map<EntityInfo, Object[]> resultContext;

	public ScrollableResultsImpl(
			IndexSearcher searcher, Hits hits, int first, int max, DocumentExtractor extractor,
			Loader loader, SearchFactory searchFactory
	) {
		this.searcher = searcher;
		this.searchFactory = searchFactory;
		this.hits = hits;
		this.first = first;
		this.max = max;
		this.current = first;
		this.loader = loader;
		this.documentExtractor = extractor;
		this.entityInfos = new EntityInfo[max - first + 1];
		this.resultContext = new HashMap<EntityInfo, Object[]>( max - first + 1 );
	}

	public boolean next() throws HibernateException {
		return ++current <= max;
	}

	public boolean previous() throws HibernateException {
		return --current >= first;
	}

	public boolean scroll(int i) throws HibernateException {
		current = current + i;
		return current >= first && current <= max;
	}

	public boolean last() throws HibernateException {
		current = max;
		return max >= first;
	}

	public boolean first() throws HibernateException {
		current = first;
		return max >= first;
	}

	public void beforeFirst() throws HibernateException {
		current = first - 1;
	}

	public void afterLast() throws HibernateException {
		current = max + 1;
	}

	public boolean isFirst() throws HibernateException {
		return current == first;
	}

	public boolean isLast() throws HibernateException {
		return current == max;
	}

	public void close() throws HibernateException {
		try {
			searchFactory.getReaderProvider().closeReader( searcher.getIndexReader() );
		}
		catch (SearchException e) {
			log.warn( "Unable to properly close searcher in ScrollableResults", e );
		}
	}

	public Object[] get() throws HibernateException {
		if ( current < first || current > max ) return null; //or exception?
		EntityInfo info = entityInfos[current - first];
		if ( info == null ) {
			Document document = null;
			try {
				document = hits.doc( current );
			}
			catch (IOException e) {
				throw new HibernateException( "Unable to read Lucene hits[" + current + "]", e );
			}
			//FIXME should check that clazz match classes but this complexify a lot the firstResult/maxResult
			info = documentExtractor.extract( document );
			entityInfos[current - first] = info;
		}
		if ( !resultContext.containsKey( info ) ) {
			Object loaded = loader.load( info );
			if ( !loaded.getClass().isArray() ) loaded = new Object[] { loaded };
			resultContext.put( info, (Object[]) loaded );
		}
		return resultContext.get( info );
	}

	public Object get(int i) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Type getType(int i) {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Integer getInteger(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Long getLong(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Float getFloat(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Boolean getBoolean(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Double getDouble(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Short getShort(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Byte getByte(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Character getCharacter(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public byte[] getBinary(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public String getText(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Blob getBlob(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Clob getClob(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public String getString(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public BigDecimal getBigDecimal(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public BigInteger getBigInteger(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Date getDate(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Locale getLocale(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public Calendar getCalendar(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public TimeZone getTimeZone(int col) throws HibernateException {
		throw new UnsupportedOperationException( "Lucene does not work on columns" );
	}

	public int getRowNumber() throws HibernateException {
		if ( max < first ) return -1;
		return current - first;
	}

	public boolean setRowNumber(int rowNumber) throws HibernateException {
		if ( rowNumber >= 0 ) {
			current = first + rowNumber;
		}
		else {
			current = max + rowNumber + 1; //max row start at -1
		}
		return current >= first && current <= max;
	}
}
