/**
 * 
 */
package com.acamaya.demo.dao.modele;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.search.annotations.*;

@Indexed
public class Entite
{
	@DocumentId
	private Integer id;

	@Field(index=Index.TOKENIZED, store=Store.YES)
	@Boost(value=0.5f)
	private String titre;

	@Field(index=Index.TOKENIZED, store=Store.YES)
	private String resume;

	@IndexedEmbedded
	private List<Document> documents;

	public Entite() { }
	
	public Entite(String titre, String resume)
	{
		documents = new ArrayList<Document>();
		
		this.titre = titre;
		this.resume = resume;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}
	
	public String getResume() {
		return resume;
	}

	public void setResume(String resume) {
		this.resume = resume;
	}

	public List<Document> getDocuments() {
		return documents;
	}

	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}
}
