//$Id: DeleteLuceneWork.java 11625 2007-06-04 16:21:54Z epbernard $
package org.hibernate.search.backend;

import java.io.Serializable;

/**
 * @author Emmanuel Bernard
 */
public class DeleteLuceneWork extends LuceneWork {
	public DeleteLuceneWork(Serializable id, Class entity) {
		super( id, entity );
	}
}
