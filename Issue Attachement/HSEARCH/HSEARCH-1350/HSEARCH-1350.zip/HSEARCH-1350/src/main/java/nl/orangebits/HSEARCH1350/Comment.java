package nl.orangebits.HSEARCH1350;

import java.io.Serializable;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

@Entity(name="Comment")
@DiscriminatorValue(value = "WPT")
@Indexed
public class Comment extends BaseComment implements Serializable{
	
	private Post post;
	
	@ManyToOne(optional=true,fetch=FetchType.LAZY)
	@JoinColumn(name="FK_PostId", nullable=true, insertable=true,updatable=false)
	@IndexedEmbedded(includePaths={"id"},indexNullAs=Field.DEFAULT_NULL_TOKEN)
	public Post getPost() {
		return post;
	}

	public void setPost(Post family) {
		this.post = family;
	}


}
