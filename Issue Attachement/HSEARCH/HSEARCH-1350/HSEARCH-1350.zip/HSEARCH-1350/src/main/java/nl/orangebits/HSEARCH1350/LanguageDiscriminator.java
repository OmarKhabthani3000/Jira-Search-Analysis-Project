package nl.orangebits.HSEARCH1350;

import org.hibernate.search.analyzer.Discriminator;

public class LanguageDiscriminator implements Discriminator {

	@Override
	public String getAnalyzerDefinitionName(Object value, Object entity,
			String field) {
		
		Country c = (Country) value;
		
		if(c == null)
			return "nl";			
		
		return c.getLanguage().getLanguage();
	}

}
