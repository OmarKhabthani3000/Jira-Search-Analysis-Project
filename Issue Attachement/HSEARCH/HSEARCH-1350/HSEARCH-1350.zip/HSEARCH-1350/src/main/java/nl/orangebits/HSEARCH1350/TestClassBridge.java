package nl.orangebits.HSEARCH1350;

import java.util.List;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Field.Index;
import org.apache.lucene.document.Field.Store;
import org.hibernate.search.bridge.FieldBridge;
import org.hibernate.search.bridge.LuceneOptions;

public class TestClassBridge implements FieldBridge{

	@Override
	public void set(String name, Object value, Document document,
			LuceneOptions luceneOptions) {
		
		Post post = (Post) value;
		Field field = null;

		List<Comment> comments = post.getComments();
		
		if(comments == null || comments.isEmpty())
			return;
		
		int size = comments.size();
		int x = size - 1;
		
		Comment comment = null;
		
		if(size == 0)
			return;
	
		comment = comments.get(x);
				
		field = new Field( "commentCount", String.valueOf(size), Store.YES, Index.NOT_ANALYZED);
		document.add(field);
		
		field = new Field( "comment.txt", comment.getName(), Store.YES, Index.NOT_ANALYZED);
		document.add(field);
	
	}

}
