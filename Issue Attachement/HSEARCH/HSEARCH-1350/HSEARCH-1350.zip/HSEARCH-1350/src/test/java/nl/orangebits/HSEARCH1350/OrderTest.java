package nl.orangebits.HSEARCH1350;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.Assert.*;

public class OrderTest {

	private static final Logger log = LoggerFactory.getLogger(OrderTest.class);
	
	EntityManagerFactory entityManagerFactory;
	EntityManager entityManager;
	
	@Before
	public void setup(){
		entityManagerFactory = Persistence
				.createEntityManagerFactory("OrderColumnTestJPA");
		entityManager = entityManagerFactory
				.createEntityManager();

	}
	
	@After
	public void teardown(){
		entityManager.close();
		entityManagerFactory.close();	
	}
	
	@Test
	public void detachedEntityTest(){
		EntityTransaction tx = entityManager.getTransaction();
		
		try{
			
			tx.begin();
			
			Language language = new Language();
			language.setLanguage("nl");
			
			Country country = new Country();
			country.setCountryCode("NL");
			country.setLanguage(language);
			
			country = entityManager.merge(country);
			
			//detach country
			entityManager.flush();
			entityManager.clear();
			entityManagerFactory.getCache().evictAll();
			
			Forum forum = new Forum();
			forum.setName("forum1");
			forum = entityManager.merge(forum);
			
			entityManager.flush();
			entityManager.clear();
			entityManagerFactory.getCache().evictAll();
			
			tx.commit();
			
			tx.begin();
			
			forum = (Forum) entityManager.find(Forum.class, forum.getId());
			
			//Create a post
			Post post = new Post();
			post.setName("post1");
			post.setForum(forum);
			post.setCountry(country);
			forum.getPosts().add(post);
			
			post = entityManager.merge(post);
			country = post.getCountry();
			
			entityManager.flush();
			entityManager.clear();
			entityManagerFactory.getCache().evictAll();
			
			tx.commit();
			
			tx.begin();
			
			post = entityManager.find(Post.class, post.getId());
			
			Comment comment = new Comment();
			comment.setName("text");
			comment.setPost(post);
			comment.setCountry(country);
			post.getComments().add(comment);
			
			post = entityManager.merge(post);
			
			entityManager.flush();
			entityManager.clear();
			entityManagerFactory.getCache().evictAll();
			
			tx.commit();
			
			tx.begin();
			
			post = entityManager.find(Post.class, post.getId());
			comment = new Comment();
			comment.setName("text 2");
			comment.setPost(post);
			comment.setCountry(country);
			post.getComments().add(comment);
			
			post = entityManager.merge(post);
			
			entityManager.flush();
			
			assertTrue(false);
			
		}catch(Exception e){
			log.error("problem",e);
			assertTrue(false);
		}finally{
			if(tx.isActive())
				tx.commit();
		}
	}
	

}
