package com.foo;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.util.Version;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Example testcase for Hibernate Search
 */
public class IndexAndSearchTest {

    private EntityManagerFactory emf;

    private EntityManager em;

    private static Logger log = LoggerFactory.getLogger(IndexAndSearchTest.class);

    @Before
    public void setUp() {
        emf = Persistence.createEntityManagerFactory("hibernate-search-example");
        em = emf.createEntityManager();
    }

    @After
    public void tearDown() {
        FullTextEntityManager ftEm = org.hibernate.search.jpa.Search.getFullTextEntityManager(em);
        ftEm.purgeAll(Book.class);
        ftEm.flushToIndexes();
        ftEm.close();
        emf.close();
    }

    /**
     * Test ElementCollection directly on Entity Book
     */
    @Test
    public void testElementCollection() throws Exception {
        // create Book and set "Foo" into ElementCollection
        em.getTransaction().begin();
        Book book = new Book();
        book.setId(1234L);
        book.getCategories().put(12L, "Foo");
        em.persist(book);
        em.getTransaction().commit();

        // Test
        assertEquals(1, search("categories:Foo").size()); // should find
        assertEquals(0, search("categories:Bar").size()); // should not find

        // add "Bar" into ElementCollection
        em.getTransaction().begin();
        book = em.find(Book.class, 1234L);
        book.getCategories().put(13L, "Bar");
        em.persist(book);
        em.getTransaction().commit();

        // Test
        assertEquals(1, search("categories:Foo").size()); // should find
        assertEquals(1, search("categories:Bar").size()); // should find
    }

    /**
     * Test ElementCollection on Embedded property Book.getEmb()
     */
    @Test
    public void testEmbeddedElementCollection() throws Exception {
        // create Book and set "Foo" into Embedded ElementCollection
        em.getTransaction().begin();
        Book book = new Book();
        book.setId(1234L);
        book.getEmb().getCategories().put(12L, "Foo");
        em.persist(book);
        em.getTransaction().commit();

        // Test
        assertEquals(1, search("emb.categories:Foo").size()); // should find
        assertEquals(0, search("emb.categories:Bar").size()); // should not find

        // add "Bar" into Embedded ElementCollection
        em.getTransaction().begin();
        book = em.find(Book.class, 1234L);
        book.getEmb().getCategories().put(13L, "Bar");
        em.persist(book);
        em.getTransaction().commit();

        // Test
        assertEquals(1, search("emb.categories:Foo").size()); // should find
        assertEquals(1, search("emb.categories:Bar").size()); // should find
    }

    private List<Book> search(String searchQuery) throws ParseException {
        QueryParser parser = new MultiFieldQueryParser(Version.LUCENE_36, new String[] {}, new StandardAnalyzer(Version.LUCENE_36));
        FullTextQuery query = Search.getFullTextEntityManager(em).createFullTextQuery(parser.parse(searchQuery), Book.class);
        return query.getResultList();
    }
}
