package com.foo;

import org.hibernate.search.annotations.*;

import javax.persistence.*;
import java.util.HashMap;
import java.util.Map;

@Entity
@Indexed
public class Book {

	private Long id;

    @Id
   	@DocumentId
   	public Long getId() {
   		return id;
   	}

   	public void setId(Long id) {
   		this.id = id;
   	}

	private String title;

	@Field(store = Store.YES)
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

    private Map<Long, String> categories;

    @ElementCollection
    @IndexedEmbedded
    @MapKeyColumn
    @Field(bridge = @FieldBridge(impl = CategoriesBridge.class))
    public Map<Long, String> getCategories() {
        if (categories == null) {
            categories = new HashMap<Long, String>();
        }
        return categories;
    }

    public void setCategories(Map<Long, String> categories) {
        this.categories = categories;
    }

    private BookEmbeddable emb;

    @Embedded
    @IndexedEmbedded
    public BookEmbeddable getEmb() {
        if (emb == null) {
            emb = new BookEmbeddable();
        }
        return emb;
    }

    public void setEmb(BookEmbeddable emb) {
        this.emb = emb;
    }
}
