package com.foo;

import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.annotations.IndexedEmbedded;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.MapKeyColumn;
import java.util.HashMap;
import java.util.Map;

@Embeddable
public class BookEmbeddable {

    private Map<Long, String> categories;

    @ElementCollection
    @IndexedEmbedded
    @MapKeyColumn
    @Field(bridge = @FieldBridge(impl = CategoriesBridge.class))
    public Map<Long, String> getCategories() {
        if (categories == null) {
            categories = new HashMap<Long, String>();
        }
        return categories;
    }

    public void setCategories(Map<Long, String> categories) {
        this.categories = categories;
    }
}
