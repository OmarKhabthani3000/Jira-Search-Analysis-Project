package com.foo;

import org.apache.lucene.document.Document;
import org.hibernate.search.bridge.FieldBridge;
import org.hibernate.search.bridge.LuceneOptions;

import java.util.Map;

public class CategoriesBridge implements FieldBridge {
    @Override
    public void set(String name, Object value, Document document, LuceneOptions luceneOptions) {
        Map<Long, String> categoriesValue = (Map<Long, String>) value;
        for (String s : categoriesValue.values()) {
            luceneOptions.addFieldToDocument(name, s, document);
        }
    }
}
