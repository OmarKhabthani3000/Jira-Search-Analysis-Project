package fr.dsirc.testcase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.hibernate.search.util.impl.WeakIdentityHashMap;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestMap {

	static Logger logger = LoggerFactory.getLogger(TestMap.class);

	protected final WeakIdentityHashMap<String, String> weakIdentityHashMap = new WeakIdentityHashMap<String, String>();

	@Test
	public void executeTest() throws Exception {
		ExecutorService executorService = Executors.newFixedThreadPool(20);
		TestWeakIdentityHashMap test = new TestWeakIdentityHashMap();
		for (int i = 0; i < 20; i++) {
			executorService.execute(test);
		}
		executorService.shutdown();
		executorService.awaitTermination(10, TimeUnit.MINUTES);
	}

	public class TestWeakIdentityHashMap implements Runnable {

		public void run() {
			String name = Thread.currentThread().getName();
			while (true) {
				weakIdentityHashMap.put(name, name);
				Assert.assertEquals(name, weakIdentityHashMap.get(name));
				weakIdentityHashMap.removeValue(name);
			}
		}
	}
}
