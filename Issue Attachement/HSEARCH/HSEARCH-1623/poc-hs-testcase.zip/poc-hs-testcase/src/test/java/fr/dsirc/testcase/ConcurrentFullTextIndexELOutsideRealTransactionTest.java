package fr.dsirc.testcase;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextSession;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.dsirc.testcase.model.Individu;

public class ConcurrentFullTextIndexELOutsideRealTransactionTest {

	static Logger logger = LoggerFactory.getLogger(ConcurrentFullTextIndexELOutsideRealTransactionTest.class);

	@Before
	public void setUp() throws InterruptedException, IOException {
		File idxFile = new File("./target/idx");
		if (idxFile.exists())
			FileUtils.cleanDirectory(idxFile);
	}

	private void checkNumberOfIndexedEntities(SessionFactory sessionFactory,
			int expected) {
		Session session = sessionFactory.openSession();
		try {

			FullTextSession fte = org.hibernate.search.Search
					.getFullTextSession(session);

			int numDocs = fte
					.getSearchFactory()
					.getStatistics()
					.getNumberOfIndexedEntities(
							Individu.class.getCanonicalName());
			Assert.assertEquals("indexed documents", expected, numDocs);

		} finally {
			session.close();
			sessionFactory.close();
		}
	}

	public class InsertEntityJob implements Runnable {
		private SessionFactory sessionFactory;
		private int jobNumber;

		public InsertEntityJob(SessionFactory sessionFactory, int jobNumber) {
			super();
			this.sessionFactory = sessionFactory;
			this.jobNumber = jobNumber;
		}

		public void run() {
			Session session = sessionFactory.openSession();
//			Transaction transaction = null;
			try {
//				transaction = session.beginTransaction();
				session.save(new Individu("peter_" + jobNumber));
				session.flush();
//				transaction.commit();

			} catch (HibernateException e) {
				e.printStackTrace();
//				transaction.rollback();
			} finally {
				session.close();
			}
		}
	}

	@Test
	public void testMultiThread() {
		SessionFactory sessionFactory = new org.hibernate.cfg.Configuration()
				.configure("hibernate-cfg.xml").buildSessionFactory();

		ExecutorService executorService = Executors.newFixedThreadPool(10);

		for (int i = 0; i < 1000; i++) {
			executorService.execute(new InsertEntityJob(sessionFactory, i));
		}
		try {
			executorService.shutdown();
			executorService.awaitTermination(10, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			Assert.fail("unexpected error " + e.getMessage());
		}

		checkNumberOfIndexedEntities(sessionFactory, 1000);
	}
}
