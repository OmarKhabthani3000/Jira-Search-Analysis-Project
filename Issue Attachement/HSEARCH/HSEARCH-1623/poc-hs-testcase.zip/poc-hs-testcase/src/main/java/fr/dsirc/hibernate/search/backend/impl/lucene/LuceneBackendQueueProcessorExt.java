package fr.dsirc.hibernate.search.backend.impl.lucene;

import java.util.List;

import org.hibernate.search.backend.IndexingMonitor;
import org.hibernate.search.backend.LuceneWork;
import org.hibernate.search.backend.impl.lucene.LuceneBackendQueueProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LuceneBackendQueueProcessorExt extends LuceneBackendQueueProcessor {
	static Logger logger = LoggerFactory
			.getLogger(LuceneBackendQueueProcessorExt.class);

	@Override
	public void applyWork(List<LuceneWork> workList, IndexingMonitor monitor) {
		logger.debug("LuceneBackendQueueProcessorExt begin applyWork...");
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		super.applyWork(workList, monitor);
		logger.debug("...LuceneBackendQueueProcessorExt end applyWork");
	}

}
