package fr.dsirc.testcase.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;

@Entity()
@Table(name = "RI_INDIVIDU")
@Indexed
public class Individu {

	
	public Individu(String nom) {
		super();
		this.nom = nom;
	}

	@Id
	@Column(name = "ID", nullable = true)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	@SequenceGenerator(name = "seq", initialValue = 1000)
	private Integer id;

	@Column(name = "NOM", length = 40, nullable = true)
	@Field(name = "nom", store = Store.NO)
	private String nom;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

}
