//$Id: ProjectionLoader.java 11631 2007-06-05 15:48:42Z epbernard $
package org.hibernate.search.engine;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.search.engine.EntityInfo;

/**
 * @author Emmanuel Bernard
 */
public class ProjectionLoader implements Loader {
	public void init(Session session, SearchFactoryImplementor searchFactoryImplementor) {
	}

	public Object load(EntityInfo entityInfo) {
		return entityInfo.projection;
	}

	public List load(EntityInfo... entityInfos) {
		List results = new ArrayList(entityInfos.length);
		for (EntityInfo entityInfo : entityInfos) {
			results.add( entityInfo.projection );
		}
		return results;
	}
}
