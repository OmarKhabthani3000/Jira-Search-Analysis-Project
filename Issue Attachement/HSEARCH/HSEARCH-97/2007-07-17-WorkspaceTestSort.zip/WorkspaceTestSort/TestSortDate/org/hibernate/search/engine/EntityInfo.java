//$Id: EntityInfo.java 11625 2007-06-04 16:21:54Z epbernard $
package org.hibernate.search.engine;

import java.io.Serializable;

/**
 *
 * @author Emmanuel Bernard
 */
//Move to egine?
public class EntityInfo {
	public Class clazz;
	public Serializable id;
	public Object[] projection;
}
