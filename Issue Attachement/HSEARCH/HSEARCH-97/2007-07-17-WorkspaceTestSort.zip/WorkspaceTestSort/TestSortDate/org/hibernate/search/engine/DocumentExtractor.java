//$Id: DocumentExtractor.java 11631 2007-06-05 15:48:42Z epbernard $
package org.hibernate.search.engine;

import org.apache.lucene.document.Document;
import org.hibernate.search.engine.EntityInfo;

/**
 * @author Emmanuel Bernard
 */
public class DocumentExtractor {
	private SearchFactoryImplementor searchFactoryImplementor;
	private String[] projection;

	public DocumentExtractor(SearchFactoryImplementor searchFactoryImplementor, String... projection) {
		this.searchFactoryImplementor = searchFactoryImplementor;
		this.projection = projection;
	}

	public EntityInfo extract(Document document) {
		EntityInfo entityInfo = new EntityInfo();
		entityInfo.clazz = DocumentBuilder.getDocumentClass( document );
		entityInfo.id = DocumentBuilder.getDocumentId( searchFactoryImplementor, entityInfo.clazz, document );
		if (projection != null && projection.length > 0) {
			entityInfo.projection = DocumentBuilder.getDocumentFields( searchFactoryImplementor, entityInfo.clazz, document, projection );
		}
		//TODO read fields
		return entityInfo;
	}
}
