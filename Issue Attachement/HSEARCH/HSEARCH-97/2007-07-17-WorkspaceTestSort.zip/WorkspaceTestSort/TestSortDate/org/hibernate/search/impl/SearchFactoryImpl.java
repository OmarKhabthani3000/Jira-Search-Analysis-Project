//$Id: SearchFactoryImpl.java 11695 2007-06-19 22:07:51Z epbernard $
package org.hibernate.search.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.hibernate.annotations.common.reflection.ReflectionManager;
import org.hibernate.annotations.common.reflection.XClass;
import org.hibernate.annotations.common.reflection.java.JavaReflectionManager;
import org.hibernate.cfg.Configuration;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.search.Environment;
import org.hibernate.search.SearchException;
import org.hibernate.search.Version;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.backend.BackendQueueProcessorFactory;
import org.hibernate.search.backend.Worker;
import org.hibernate.search.backend.WorkerFactory;
import org.hibernate.search.backend.LuceneWork;
import org.hibernate.search.backend.OptimizeLuceneWork;
import org.hibernate.search.engine.DocumentBuilder;
import org.hibernate.search.engine.SearchFactoryImplementor;
import org.hibernate.search.reader.ReaderProvider;
import org.hibernate.search.reader.ReaderProviderFactory;
import org.hibernate.search.store.DirectoryProvider;
import org.hibernate.search.store.DirectoryProviderFactory;
import org.hibernate.search.store.optimization.OptimizerStrategy;
import org.hibernate.util.ReflectHelper;

/**
 * @author Emmanuel Bernard
 */
public class SearchFactoryImpl implements SearchFactoryImplementor {
	private static ThreadLocal<WeakHashMap<Configuration, SearchFactoryImpl>> contexts =
			new ThreadLocal<WeakHashMap<Configuration, SearchFactoryImpl>>();

	static {
		Version.touch();
	}

	private Map<Class, DocumentBuilder<Object>> documentBuilders = new HashMap<Class, DocumentBuilder<Object>>();
	//keep track of the index modifiers per DirectoryProvider since multiple entity can use the same directory provider
	private Map<DirectoryProvider, ReentrantLock> lockableDirectoryProviders =
			new HashMap<DirectoryProvider, ReentrantLock>();
	private Map<DirectoryProvider, OptimizerStrategy> dirProviderOptimizerStrategies =
			new HashMap<DirectoryProvider, OptimizerStrategy>();
	private Worker worker;
	private ReaderProvider readerProvider;
	private BackendQueueProcessorFactory backendQueueProcessorFactory;

	public BackendQueueProcessorFactory getBackendQueueProcessorFactory() {
		return backendQueueProcessorFactory;
	}

	public void setBackendQueueProcessorFactory(BackendQueueProcessorFactory backendQueueProcessorFactory) {
		this.backendQueueProcessorFactory = backendQueueProcessorFactory;
	}

	public SearchFactoryImpl(Configuration cfg) {
		//yuk
		ReflectionManager reflectionManager = getReflectionManager( cfg );

		Class analyzerClass;
		String analyzerClassName = cfg.getProperty( Environment.ANALYZER_CLASS );
		if ( analyzerClassName != null ) {
			try {
				analyzerClass = ReflectHelper.classForName( analyzerClassName );
			}
			catch (Exception e) {
				throw new SearchException(
						"Lucene analyzer class '" + analyzerClassName + "' defined in property '" + Environment.ANALYZER_CLASS + "' could not be found.",
						e
				);
			}
		}
		else {
			analyzerClass = StandardAnalyzer.class;
		}
		// Initialize analyzer
		Analyzer analyzer;
		try {
			analyzer = (Analyzer) analyzerClass.newInstance();
		}
		catch (ClassCastException e) {
			throw new SearchException(
					"Lucene analyzer does not implement " + Analyzer.class.getName() + ": " + analyzerClassName
			);
		}
		catch (Exception e) {
			throw new SearchException( "Failed to instantiate lucene analyzer with type " + analyzerClassName );
		}

		Iterator iter = cfg.getClassMappings();
		DirectoryProviderFactory factory = new DirectoryProviderFactory();
		while ( iter.hasNext() ) {
			PersistentClass clazz = (PersistentClass) iter.next();
			Class<?> mappedClass = clazz.getMappedClass();
			if ( mappedClass != null ) {
				XClass mappedXClass = reflectionManager.toXClass( mappedClass );
				if ( mappedXClass != null && mappedXClass.isAnnotationPresent( Indexed.class ) ) {
					DirectoryProvider provider = factory.createDirectoryProvider( mappedXClass, cfg, this );
					//TODO move that into DirectoryProviderFactory
					if ( !lockableDirectoryProviders.containsKey( provider ) ) {
						lockableDirectoryProviders.put( provider, new ReentrantLock() );
					}
					final DocumentBuilder<Object> documentBuilder = new DocumentBuilder<Object>(
							mappedXClass, analyzer, provider, reflectionManager
					);

					documentBuilders.put( mappedClass, documentBuilder );
				}
			}
		}
		Set<Class> indexedClasses = documentBuilders.keySet();
		for (DocumentBuilder builder : documentBuilders.values()) {
			builder.postInitialize( indexedClasses );
		}
		worker = WorkerFactory.createWorker( cfg, this );
		readerProvider = ReaderProviderFactory.createReaderProvider( cfg, this );
	}

	//code doesn't have to be multithreaded because SF creation is not.
	//this is not a public API, should really only be used during the SessionFActory building
	//FIXME this is ugly, impl.staticmethod, fix that
	public static SearchFactoryImpl getSearchFactory(Configuration cfg) {
		WeakHashMap<Configuration, SearchFactoryImpl> contextMap = contexts.get();
		if ( contextMap == null ) {
			contextMap = new WeakHashMap<Configuration, SearchFactoryImpl>( 2 );
			contexts.set( contextMap );
		}
		SearchFactoryImpl searchFactory = contextMap.get( cfg );
		if ( searchFactory == null ) {
			searchFactory = new SearchFactoryImpl( cfg );

			contextMap.put( cfg, searchFactory );
		}
		return searchFactory;
	}


	public Map<Class, DocumentBuilder<Object>> getDocumentBuilders() {
		return documentBuilders;
	}

	public Map<DirectoryProvider, ReentrantLock> getLockableDirectoryProviders() {
		return lockableDirectoryProviders;
	}

	public Worker getWorker() {
		return worker;
	}

	public void addOptimizerStrategy(DirectoryProvider<?> provider, OptimizerStrategy optimizerStrategy) {
		dirProviderOptimizerStrategies.put( provider, optimizerStrategy );
	}

	public OptimizerStrategy getOptimizerStrategy(DirectoryProvider<?> provider) {
		return dirProviderOptimizerStrategies.get( provider );
	}

	public ReaderProvider getReaderProvider() {
		return readerProvider;
	}

	//not happy about having it as a helper class but I don't want cfg to be associated with the SearchFactory
	public static ReflectionManager getReflectionManager(Configuration cfg) {
		ReflectionManager reflectionManager;
		try {
			//TODO introduce a ReflectionManagerHolder interface to avoid reflection
			//I want to avoid hard link between HAN and Validator for usch a simple need
			//reuse the existing reflectionManager one when possible
			reflectionManager =
					(ReflectionManager) cfg.getClass().getMethod( "getReflectionManager" ).invoke( cfg );

		}
		catch (Exception e) {
			reflectionManager = new JavaReflectionManager();
		}
		return reflectionManager;
	}

	public DirectoryProvider getDirectoryProvider(Class entity) {
		DocumentBuilder<Object> documentBuilder = getDocumentBuilders().get( entity );
		return documentBuilder == null ? null : documentBuilder.getDirectoryProvider();
	}

	public void optimize() {
		Set<Class> clazzs = getDocumentBuilders().keySet();
		for (Class clazz : clazzs) {
			optimize( clazz );
		}
	}

	public void optimize(Class entityType) {
		if ( ! getDocumentBuilders().containsKey( entityType ) ) {
			throw new SearchException("Entity not indexed: " + entityType);
		}
		List<LuceneWork> queue = new ArrayList<LuceneWork>(1);
		queue.add( new OptimizeLuceneWork( entityType ) );
		getBackendQueueProcessorFactory().getProcessor( queue ).run();
	}
}
