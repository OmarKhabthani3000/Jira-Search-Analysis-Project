//$Id: $
package org.hibernate.search.engine;

import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

import org.hibernate.search.SearchFactory;
import org.hibernate.search.store.DirectoryProvider;
import org.hibernate.search.store.optimization.OptimizerStrategy;
import org.hibernate.search.backend.BackendQueueProcessorFactory;
import org.hibernate.search.backend.Worker;

/**
 * @author Emmanuel Bernard
 */
public interface SearchFactoryImplementor extends SearchFactory {
	BackendQueueProcessorFactory getBackendQueueProcessorFactory();

	void setBackendQueueProcessorFactory(BackendQueueProcessorFactory backendQueueProcessorFactory);

	Map<Class, DocumentBuilder<Object>> getDocumentBuilders();

	Map<DirectoryProvider, ReentrantLock> getLockableDirectoryProviders();

	Worker getWorker();

	void addOptimizerStrategy(DirectoryProvider<?> provider, OptimizerStrategy optimizerStrategy);

	public OptimizerStrategy getOptimizerStrategy(DirectoryProvider<?> provider);
}
