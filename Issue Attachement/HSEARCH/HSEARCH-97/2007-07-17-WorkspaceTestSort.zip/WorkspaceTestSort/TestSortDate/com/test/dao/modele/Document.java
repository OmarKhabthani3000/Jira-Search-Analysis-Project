/**
 * 
 */
package com.test.dao.modele;

import org.hibernate.search.annotations.*;

@Indexed
public class Document {

	@DocumentId
	private Integer id;

	@Field(index=Index.TOKENIZED, store=Store.YES)
	private String titre;
	
	@Field(index=Index.TOKENIZED, store=Store.YES)
	private String resume;
	
	public Document() {}
	
	public Document(String titre, String resume)
	{
		this.titre = titre;
		this.resume = resume;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getResume() {
		return resume;
	}

	public void setResume(String resume) {
		this.resume = resume;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}
}