package com.test.dao.modele;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.test.dao.utilitaires.HibernateUtil;

public class ListeEntites {
	
	private Integer id;
	
	private List<Entite> entites;
	
	public ListeEntites()
	{
		entites = new ArrayList<Entite>();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public List<Entite> getEntites() {
		return entites;
	}

	public void setEntites(List<Entite> entites) {
		this.entites = entites;
	}

	public String toString()
	{
		String tmp = "Liste des entites :\n";

		for(int i=0; i < entites.size(); i++)
		{
			tmp += entites.get(i).toString()+"\n";
		}

		return tmp;
	}
	
	/**
	 * Ajout d'une entite
	 * @param entite
	 */
	public Entite ajouterEntite(Entite entite)
	{
		entites.add(entite);
		
		return entite;
	}
	
	/**
	 * Recupere une entite identifie par son identifiant dans la liste
	 * @param id
	 * @return Entite, null si non trouve
	 */
	public Entite getEntite(Integer id)
	{
		Session session = HibernateUtil.getSessionActuelle();
		Entite e = (Entite) session.get(Entite.class,new Integer(id));
		return e;
	}
	
	/**
	 * Cherche une entite qui contient le titre donne
	 * @param titre
	 * @return liste d'entites
	 */
/*
	public ArrayList<Entite> chercherEntite(String titre)
	{
		Session session = HibernateUtil.getSessionActuelle();
		Query requete = session.createQuery("SELECT e FROM Entite e WHERE e.titre LIKE '%"+titre+"%'");

		ArrayList<Entite> entitesRes = new ArrayList<Entite>();
		
		Iterator i = requete.iterate();
		while(i.hasNext())
		{
			entitesRes.add((Entite) i.next());
		}
		
		return entitesRes;
	}
*/

	/**
	 * Donne un ensemble d'entites parmis toutes, avec une limitation definie par un debut et une taille
	 * @return liste d'entites
	 * @param debut
	 * @param taille
	 * @param orderBy parmis
	 * titre, date
	 * @param desc a mettre a vrai si on veut le sens decroissant
	 * @return ArrayList<Entite>
	 */
	public ArrayList<Entite> getEntites(int debut, int taille, String orderBy, boolean desc)
	{
		Session session = HibernateUtil.getSessionActuelle();
		String orderByStr;
		String sensStr = "";
		
		if(orderBy.equals("titre"))
			orderByStr = "titre";
		else orderByStr = "date";
		
		if(desc)
			sensStr = "DESC";
			
		Query requete = session.createQuery("SELECT e FROM Entite e ORDER BY e."+orderByStr+" "+sensStr);

		requete.setFirstResult(debut).setMaxResults(taille);
		
		ArrayList<Entite> entitesRes = new ArrayList<Entite>();
		Iterator i = requete.iterate();
		while(i.hasNext())
		{
			entitesRes.add((Entite) i.next());
		}
		
		return entitesRes;
	}	

	/**
	 * Supprime une entite
	 * @param categorie
	 */
	public void supprimerEntite(Entite entite)
	{
		Session session = HibernateUtil.getSessionActuelle();
		
		entites.remove(entite);
		
		session.delete(entite);
	}
}
