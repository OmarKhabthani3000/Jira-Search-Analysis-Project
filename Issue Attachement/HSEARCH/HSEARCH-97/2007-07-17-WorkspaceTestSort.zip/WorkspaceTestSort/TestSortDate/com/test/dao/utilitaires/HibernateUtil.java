package com.test.dao.utilitaires;

import java.util.Date;
import java.util.List;

import org.apache.lucene.analysis.StopAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Sort;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.tool.hbm2ddl.SchemaExport;

import com.test.dao.modele.Entite;
import com.test.metier.interfacemetier.InterfaceDocument;
import com.test.metier.interfacemetier.InterfaceEntite;

public class HibernateUtil
{
	private static final Configuration configuration;
	private static final SessionFactory sessionFactory;

	static
	{
		try
		{
			configuration = new Configuration();
			configuration.configure("com/test/dao/config/hibernate.cfg.xml"); // lecture du hibernate.cfg.xml au lieu du hibernate.properties
			
			// sert a creer des instances de sessions hibernate
			sessionFactory = configuration.buildSessionFactory();

		} catch (HibernateException e) {
			throw new RuntimeException("Probleme de configuration Hibernate : "+ e.getMessage(), e);
		}
	}

	public static final ThreadLocal<Session> session = new ThreadLocal<Session>();

	/**
	 * Recupere une session (ou en cree une)
	 * et lance une transaction
	 * @return
	 */
	public static Session getSessionActuelle()
	{
		Session s = (Session) session.get();
		
		// ouvre une nouvelle Session, si ce Thread n'en a aucune
		if (s == null)
		{
			s = sessionFactory.openSession();
			session.set(s);		
		}
		return s;
	}

	/**
	 * Ferme la session si elle existe
	 */
	public static void fermerSession()
	{
		Session s = (Session) session.get();
		session.set(null);
		if (s != null)
			s.close();
	}
	
	/**
	 * Creation des tables necessaires
	 * Si deja presentes, elles sont ecrasees !
	 */
	public static void reinitialiserDonnees()
	{
		SchemaExport se = new SchemaExport(configuration);
		se.create(true,true);

		// cree la session, rempli les tables avec les infos comme les categories, les types ..
		new GestionEntite();
	}
	
	public static void main(String[] args) throws InterruptedException, ParseException
	{
		// vide la base
		reinitialiserDonnees();

		InterfaceEntite.ajouterEntite("titre", "resume", new Date());
		InterfaceDocument.ajouterDocument(1, "titre", "resume");
		
		// pause
		for(int i = 0; i < 200000; i++) System.out.println("---");
		//Thread.currentThread().wait(3000);
		
		InterfaceEntite.ajouterEntite("titre2", "resume2", new Date());
		
		
		
		Session s = HibernateUtil.getSessionActuelle();
		
		FullTextSession fullTextSession = Search.createFullTextSession(s);
		QueryParser parser = new QueryParser("title", new StandardAnalyzer());
		
		
		org.apache.lucene.search.Query luceneQuery = parser.parse("titre:t*");
		FullTextQuery fullTextQuery = fullTextSession.createFullTextQuery(luceneQuery,Entite.class);
		
		fullTextQuery.setSort(new Sort("date",false));
		//fullTextQuery.setSort(new Sort("date",true));
		
		for(Object e : fullTextQuery.list())
		{
			System.out.println("Date : "+((Entite) e).getDate());
		}
	}
}
