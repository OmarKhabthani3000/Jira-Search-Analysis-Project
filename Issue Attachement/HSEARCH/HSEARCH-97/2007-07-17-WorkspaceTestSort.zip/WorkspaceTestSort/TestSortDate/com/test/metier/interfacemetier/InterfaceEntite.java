package com.test.metier.interfacemetier;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.test.dao.modele.Entite;
import com.test.dao.utilitaires.GestionEntite;
import com.test.dao.utilitaires.HibernateUtil;

public class InterfaceEntite
{
	public static Entite ajouterEntite(String titre, String resume, Date date)
	{
		// mise a jour donnees persistantes
		GestionEntite gestionEntite = new GestionEntite();
		Session session = HibernateUtil.getSessionActuelle();
		Transaction tx = session.beginTransaction();

		// ajout de l'entite en base
		Entite entite = gestionEntite.getListeEntites().ajouterEntite(new Entite(titre,resume, date));

		// met a jour la base, mais ne commit pas les donnees
		session.flush();

		// fin de la transaction, on commit les donnees en base
		tx.commit();

		return entite;
	}
}
