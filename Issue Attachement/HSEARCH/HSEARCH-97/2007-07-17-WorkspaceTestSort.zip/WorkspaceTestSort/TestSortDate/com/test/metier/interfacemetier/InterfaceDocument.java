package com.test.metier.interfacemetier;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;

import com.test.dao.modele.Document;
import com.test.dao.utilitaires.HibernateUtil;
import com.test.dao.utilitaires.GestionEntite;

public class InterfaceDocument
{
	public static Document ajouterDocument(Integer idEntite, String titre, String resume)
	{
		Document document = null;
		
		// mise a jour donnees persistantes
		GestionEntite gestionEntite = new GestionEntite();
		Session session = HibernateUtil.getSessionActuelle();
		Transaction tx = session.beginTransaction();

		// ajout du document en base 
        gestionEntite.getListeEntites().getEntite(idEntite).getDocuments().add(
        new Document(titre, resume)
        );

		// reindexation de l'entite, sinon entite.documents n'est pas
		// indexe car c'est une liste (bug Hibernate Search)
		FullTextSession fullTextSession = Search.createFullTextSession(HibernateUtil.getSessionActuelle());
		fullTextSession.index(gestionEntite.getListeEntites().getEntite(idEntite));

		// met a jour la base, mais ne commit pas les donnees
		session.flush();
		
		// fin de la transaction, on commit les donnees en base
		tx.commit();

		return document;
	}
}
