--
-- PostgreSQL database dump
--

-- Started on 2010-03-29 12:46:39

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 1474 (class 1259 OID 224354)
-- Dependencies: 3
-- Name: myentity; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "myentity" (
    key1 character varying,
    key2 character varying,
    attr1 character varying,
    attr2 character varying
);


ALTER TABLE public."myentity" OWNER TO postgres;

--
-- TOC entry 1741 (class 0 OID 224354)
-- Dependencies: 1474
-- Data for Name: myentity; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "myentity" (key1, key2, attr1, attr2) VALUES ('k11', 'k12', 'a11', 'a12');
INSERT INTO "myentity" (key1, key2, attr1, attr2) VALUES ('k21', 'k22', 'a21', 'a22');
INSERT INTO "myentity" (key1, key2, attr1, attr2) VALUES ('k31', 'k32', 'a31', 'a32');
INSERT INTO "myentity" (key1, key2, attr1, attr2) VALUES ('k41', 'k42', 'a41', 'a42');
INSERT INTO "myentity" (key1, key2, attr1, attr2) VALUES ('k51', 'k52', 'a51', 'a52');


-- Completed on 2010-03-29 12:46:40

--
-- PostgreSQL database dump complete
--

