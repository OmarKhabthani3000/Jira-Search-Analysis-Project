package test.persistant;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Store;

@Embeddable
public class EntityPK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Field(index=Index.TOKENIZED, store=Store.NO)
	private String key1;
	
	@Field(index=Index.TOKENIZED, store=Store.NO)
	private String key2;
	
	public EntityPK(){
		
	}
	
	public EntityPK(String key1, String key2){
		this.key1 = key1;
		this.key2 = key2;
	}

	@Column(name="key1", nullable=false)
	public String getKey1() {
		return key1;
	}

	public void setKey1(String key1) {
		this.key1 = key1;
	}

	@Column(name="key2", nullable=false)
	public String getKey2() {
		return key2;
	}

	public void setKey2(String key2) {
		this.key2 = key2;
	}
}
