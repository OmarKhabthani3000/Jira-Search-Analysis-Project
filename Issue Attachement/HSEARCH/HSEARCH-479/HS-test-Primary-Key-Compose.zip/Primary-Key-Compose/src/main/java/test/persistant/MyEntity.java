package test.persistant;

import javax.persistence.Entity;

import org.hibernate.search.annotations.Indexed;

@Entity
@Indexed
public class MyEntity extends SuperEntity {
	
}
