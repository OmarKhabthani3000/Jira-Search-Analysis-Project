package test.indexation;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.Search;

import test.persistant.MyEntity;

public class IndexAll {

	public static void main(String[] arg){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("test");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		FullTextEntityManager fullTextEntityManager = 
			Search.getFullTextEntityManager(em);
		
		List<MyEntity> myEntities = em.createQuery("Select a from MyEntity a").getResultList();
		
		for(MyEntity myEntity : myEntities)
			fullTextEntityManager.index(myEntity);
		
		em.getTransaction().commit();
		em.close();
	}
}
