package test.persistant.HSearch;

import org.hibernate.search.bridge.TwoWayStringBridge;

import test.persistant.EntityPK;

public class SuperEntity_DocumentId_Bridge implements TwoWayStringBridge{

	public Object stringToObject(String arg0) {
		String[] tab = arg0.split("þ");
		return new EntityPK(tab[0],tab[1]);
	}

	public String objectToString(Object arg0) {
		EntityPK e = (EntityPK)arg0;
		return e.getKey1()+"þ"+e.getKey2();
	}

}
