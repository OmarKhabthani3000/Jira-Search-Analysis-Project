package test.persistant;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.MappedSuperclass;

import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Store;

import test.persistant.HSearch.SuperEntity_DocumentId_Bridge;

@MappedSuperclass
public class SuperEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@FieldBridge(impl=SuperEntity_DocumentId_Bridge.class)
	@IndexedEmbedded
	@DocumentId
	private EntityPK entityPK;
	
	@Field(index=Index.TOKENIZED, store=Store.NO)
	private String attr1;
	
	@Field(index=Index.TOKENIZED, store=Store.NO)
	private String attr2;
	
	@EmbeddedId
	public EntityPK getEntityPK() {
		return entityPK;
	}

	public void setEntityPK(EntityPK entityPK) {
		this.entityPK = entityPK;
	}

	@Column(name="attr1", nullable=false)
	public String getAttr1() {
		return attr1;
	}

	public void setAttr1(String attr1) {
		this.attr1 = attr1;
	}

	@Column(name="attr2", nullable=false)
	public String getAttr2() {
		return attr2;
	}

	public void setAttr2(String attr2) {
		this.attr2 = attr2;
	}	
}
