package test.searchTest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;

import test.persistant.MyEntity;

public class searchTest {

	public static void main(String[] arg){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("test");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		FullTextEntityManager fullTextEntityManager = 
			Search.getFullTextEntityManager(em);
		
		String rqt = "entityPK.key1:k11 entityPK.key1:k21";
		
		QueryParser parser = new QueryParser(rqt,new StandardAnalyzer());
		Query query;
				
		try {
			query = parser.parse(rqt);
			
			FullTextQuery persistenceQuery = fullTextEntityManager.createFullTextQuery(query, MyEntity.class);
			
			System.out.print("getResultSize : "+persistenceQuery.getResultSize()+"\n");
			System.out.print("getResultList size : "+persistenceQuery.getResultList().size()+"\n");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		em.close();
	}
}
