alter table Name drop foreign key FK24EEABE2157C27;
drop table if exists Name;
drop table if exists Person;
create table Name (Id bigint not null auto_increment, First tinyblob, Last tinyblob, Full_Lowercase blob, Person_Id bigint, primary key (Id)) type=InnoDB;
create table Person (Id bigint not null auto_increment, primary key (Id)) type=InnoDB;
alter table Name add index FK24EEABE2157C27 (Person_Id), add constraint FK24EEABE2157C27 foreign key (Person_Id) references Person (Id);
