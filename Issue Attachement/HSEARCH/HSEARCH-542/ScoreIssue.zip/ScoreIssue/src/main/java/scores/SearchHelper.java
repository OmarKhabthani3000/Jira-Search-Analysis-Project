package scores;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.Query;
import org.apache.lucene.util.Version;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;

public class SearchHelper {
    public static Query buildSearchQuery(String searchQuery, FullTextSession session, Class<?> searchedEntity) {
        return parseQuery(searchQuery, getAnalyzer(searchedEntity, session));
    }

    private static Query parseQuery(String query, Analyzer analyzer) {
        try {
            return MultiFieldQueryParser.parse(Version.LUCENE_29, query, new String[] {"names.full"}, new BooleanClause.Occur[] {BooleanClause.Occur.SHOULD}, analyzer);
        } catch (ParseException e) {
            throw new IllegalArgumentException("Unable to parse search query", e);
        }
    }

    private static Analyzer getAnalyzer(Class<?> searchedEntity, FullTextSession session) {
        if (searchedEntity == null)
            return new StandardAnalyzer();
        else
            return session.getSearchFactory().getAnalyzer(searchedEntity);
    }

    public static FullTextQuery buildFullTextQuery(String searchQuery, FullTextSession session, Class<?> searchedEntity) {
        Query query = buildSearchQuery(searchQuery, session, searchedEntity);
        return session.createFullTextQuery(query, searchedEntity);
    }
}
