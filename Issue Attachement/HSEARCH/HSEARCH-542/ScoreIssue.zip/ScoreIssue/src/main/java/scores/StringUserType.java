package scores;

import org.hibernate.HibernateException;
import org.hibernate.usertype.UserType;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

public class StringUserType implements UserType {

    private static final int[] SQL_TYPES = {Types.VARBINARY};

    @Override
    public int[] sqlTypes() {
        return SQL_TYPES;
    }

    @Override
    public Class returnedClass() {
        return String.class;
    }

    @Override
    public boolean equals(Object o, Object o1) throws HibernateException {
        return o == o1;
    }

    @Override
    public int hashCode(Object o) throws HibernateException {
        return String.valueOf(o).hashCode();
    }

    @Override
    public Object nullSafeGet(ResultSet resultSet, String[] strings, Object owner) throws HibernateException, SQLException {
        byte[] value = resultSet.getBytes(strings[0]);
        try {
            return resultSet.wasNull() ? null : new String(value, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new HibernateException("Could not read a UTF-8 character from the provided byte[]");
        }
    }

    @Override
    public void nullSafeSet(PreparedStatement preparedStatement, Object value, int index) throws HibernateException, SQLException {
        if (value == null) {
            preparedStatement.setNull(index, Types.VARBINARY);
        } else {
            try {
                preparedStatement.setBytes(index, ((String) value).getBytes("UTF-8"));
            } catch (UnsupportedEncodingException e) {
                throw new HibernateException("Could not write the specified String to a varbinary column using UTF-8 charset");
            }
        }
    }

    @Override
    public Object deepCopy(Object value) throws HibernateException {
        return value;
    }

    @Override
    public boolean isMutable() {
        return false;
    }

    @Override
    public Serializable disassemble(Object value) throws HibernateException {
        return (String) value;
    }

    @Override
    public Object assemble(Serializable serializable, Object owner) throws HibernateException {
        return serializable;
    }

    @Override
    public Object replace(Object original, Object target, Object owner) throws HibernateException {
        return original;
    }
}

