package scores;

import org.hibernate.search.annotations.*;
import org.hibernate.search.bridge.builtin.BooleanBridge;

import java.io.Serializable;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

@Indexed
public class Person implements Serializable {
    @DocumentId
    private Long id;
    @IndexedEmbedded
    private Set<Name> names;

    public Person() {
        names = new HashSet<Name>();
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public Set<Name> getNames() {
        return names;
    }

    public void setNames(Set<Name> names) {
        this.names = names;
    }
}