package scores;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;

import java.util.Collection;
import java.util.List;

public class PersonDaoHibernate {
    protected SessionFactory sessionFactory;

    public void addPeople(Collection<Person> people) {
        for (Person person : people) {
            addPerson(person);
        }
    }

    private long addPerson(Person person) {
        return (Long) sessionFactory.getCurrentSession().save(person);
    }

    @SuppressWarnings("unchecked")
    public List<Person> getPeopleBySearch(String searchQuery) {
        FullTextSession session = getFullTextSession();
        FullTextQuery query = SearchHelper.buildFullTextQuery(searchQuery, session, Person.class);
        return query.list();
    }

    private FullTextSession getFullTextSession() {
        return Search.getFullTextSession(sessionFactory.getCurrentSession());
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}