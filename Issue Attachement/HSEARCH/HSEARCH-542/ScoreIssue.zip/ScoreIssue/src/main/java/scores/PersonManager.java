package scores;

import scores.Person;
import scores.PersonDaoHibernate;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

public class PersonManager implements Serializable {

    private PersonDaoHibernate personDao;

    public void savePeople(Collection<Person> people) {
        personDao.addPeople(people);
    }

    public void setPersonDao(PersonDaoHibernate personDao) {
        this.personDao = personDao;
    }

    public List<Person> searchPeople(String query) {
        return personDao.getPeopleBySearch(query);
    }
}

