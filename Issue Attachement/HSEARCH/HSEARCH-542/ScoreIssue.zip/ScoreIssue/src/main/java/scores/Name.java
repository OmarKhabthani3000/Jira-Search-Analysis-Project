package scores;

import org.apache.solr.analysis.StandardFilterFactory;
import org.apache.solr.analysis.StandardTokenizerFactory;
import org.hibernate.search.annotations.*;

import java.io.Serializable;

@AnalyzerDef(name="phonetic",
    tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class),
    filters = {
        @TokenFilterDef(factory = StandardFilterFactory.class)
    })
/**
 * Name of a person.  Full name and count can never change except count can go from <code>null</code> to a value when becoming a primary name.
 */
public class Name implements Serializable {
    //@DocumentId
    private Long id;
    @Fields({@Field(boost = @Boost(2.0f))})
    private String first;
    @Fields({@Field(boost = @Boost(2.2f))})
    private String last;
    @Fields({@Field(name = "full", boost = @Boost(2.0f))})
    private String fullLowercase;
    private Person person;

    public Name() {
    }

    public Name(Person person) {
        this();
        this.person = person;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirst() {
        return first;
    }

    public void setFirst(String first) {
        this.first = first;
    }

    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last;
    }

    /**
     * @return full name including first, middle, last and suffix
     */
    @Fields({@Field(boost = @Boost(2.0f))})
    public String getFull() {
        return constructFullName(" ");
    }

    public String getFullLowercase() {
        return fullLowercase;
    }

    public void setFullLowercase(String fullLowercase) {
        this.fullLowercase = fullLowercase;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    /**
     * Sets all parts of this name and then updates concatenations of these parts.
     *
     * @param first first part of a name
     * @param last last part of a name
     */
    public void setPartsAndUpdate(String first, String last) {
        this.first = first;
        this.last = last;
        prepareForPersisting();
    }

    public void prepareForPersisting() {
        String full = constructFullName(" ");
        lowerNameParts(full);
    }

    private void lowerNameParts(String full) {
        fullLowercase = lowerOrNull(full);
    }


    /**
     * Puts together first, middle and last names to create full name with a specified delimiter in between.
     * Care is taken for empty strings and nulls to handle all situations.
     *
     * @param delimiter string to insert between name parts
     * @return full name from first, middle and last names
     */
    public String constructFullName(String delimiter) {
        return constructFullName(first, last, delimiter);
    }

    /**
     * Puts together first and last names to create full name with a specified delimiter in between.
     * Care is taken for empty strings and nulls to handle all situations.
     *
     * @param first first name part of the full name, can be null or empty
     * @param last last name part of the full name, can be null or empty
     * @param delimiter string to insert between name parts
     * @return full name from first and last names
     */
    public static String constructFullName(String first, String last, String delimiter) {
        StringBuffer fullName = new StringBuffer();
        if (first != null && first.length() > 0)
            fullName.append(first);
        if (last != null && last.length() > 0)
            fullName.append(fullName.length() > 0 ? delimiter : "").append(last);
        return (fullName.length() == 0 ? null : fullName.toString());
    }

    private String lowerOrNull(String string) {
        return (string == null || string.length() == 0) ? null : string.toLowerCase();
    }
}
