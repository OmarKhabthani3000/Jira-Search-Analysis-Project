package scores;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:application-context.xml"})
@Transactional
public class PersonManagerTests {

    @Autowired
    private PersonManager personManager;

    @Test
    @Rollback(false)
    public void testSavePeople() {
        List<Person> people = new ArrayList<Person>();
        Person person1 = createPerson(createName("Sly", "Stallone"));
        Person person2 = createPerson(createName("Bruce", "Willis"), createName("John", "Doe"));
        Person person3 = createPerson(createName("Scott", "Sly"), createName("Sam", "Jim"), createName("Frank", "Dup"), createName("Michael", "Ralph"), createName("Jack", "Moore"));
        Person person4 = createPerson(createName("John", "Davis"), createName("Sam", "Stallone"), createName("Frank", "Mueller"), createName("Michael", "Mueller"), createName("Jack", "Mueller"));
        Person person5 = createPerson(createName("Mark", "Strong"), createName("Stallone", "Yang"), createName("Franz", "Scott"), createName("Franz", "Johnson"), createName("Franz", "Will"));
        people.add(person1);
        people.add(person2);
        people.add(person3);
        people.add(person4);
        people.add(person5);
        personManager.savePeople(people);
    }
    
    @Test
    @Rollback(false)
    public void testSearchPeople() {
        List<Person> foundPeople = personManager.searchPeople("sly stallone");
        Person firstResult = foundPeople.get(0);
        assertEquals(1, firstResult.getNames().size());
        assertEquals("Sly", firstResult.getNames().iterator().next().getFirst());
        assertEquals("Stallone", firstResult.getNames().iterator().next().getLast());
    }

    private Person createPerson(Name... names) {
        Person person = new Person();
        person.getNames().addAll(Arrays.asList(names));
        return person;
    }

    private Name createName(String first, String last) {
        Name name = new Name();
        name.setPartsAndUpdate(first, last);
        return name;
    }


    public void setPersonManager(PersonManager personManager) {
        this.personManager = personManager;
    }
}