package org.hibernate.search.test.query.facet;

import java.util.Iterator;
import java.util.List;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.SearchException;
import org.hibernate.search.query.engine.spi.FacetManager;
import org.hibernate.search.query.facet.Facet;
import org.hibernate.search.query.facet.FacetSortOrder;
import org.hibernate.search.query.facet.FacetingRequest;
import org.hibernate.search.test.query.facet.manytoone.Company;
import org.hibernate.search.test.query.facet.manytoone.Companyfacility;

/**
 * @author Pragnesh
 */
public class ManyToOneFacetingTest extends AbstractFacetTest {
	private final String indexFieldName = "companyfacilities.country";
	private final String facetName = "countryfacility";
	public void testSimpleFaceting() throws Exception {
		FacetingRequest request = queryBuilder( Company.class ).facet()
				.name( facetName )
				.onField( indexFieldName )
				.discrete()
				.createFacetingRequest();
		FullTextQuery query = queryCompanyWithFacet( request );

		List<Facet> facetList = query.getFacetManager().getFacets( facetName );
		assertEquals( "Wrong number of facets", 2, facetList.size() );
		
		//check count in facet
		Iterator<Facet> itr = facetList.iterator();
		while(itr.hasNext()){
		      Facet item= itr.next();
		      assertEquals( "Wrong count of facet", 1, item.getCount() );
		}
		
	}
	private FullTextQuery queryCompanyWithFacet(FacetingRequest request) {
		Query luceneQuery = queryBuilder( Company.class ).keyword().onField( "companyName" ).matching( "ABC" ).createQuery();
		FullTextQuery query = fullTextSession.createFullTextQuery( luceneQuery, Company.class );
		query.getFacetManager().enableFaceting( request );
		assertEquals( "Wrong number of query matches", 1, query.getResultSize() );
		return query;
	}

	public void loadTestData(Session session) {
		Transaction tx = session.beginTransaction();

		Company a = new Company( "ABC");
		session.save( a );
		
		Companyfacility us = new Companyfacility(a,"US");
		session.save(us);
		
		Companyfacility india = new Companyfacility(a,"INDIA");
		session.save(india);

		tx.commit();
		session.clear();
	}

	protected Class<?>[] getAnnotatedClasses() {
		return new Class[] {
				Company.class,Companyfacility.class
		};
	}
}
