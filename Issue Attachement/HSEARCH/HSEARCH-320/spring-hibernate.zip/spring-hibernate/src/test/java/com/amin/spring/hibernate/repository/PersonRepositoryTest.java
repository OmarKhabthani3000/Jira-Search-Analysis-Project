package com.amin.spring.hibernate.repository;

import java.util.Date;
import java.util.List;

import com.amin.spring.hibernate.entity.Name;
import com.amin.spring.hibernate.entity.Person;
import static junit.framework.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

/**
 * PersonRepositoryTest
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 7, 2010
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:hibernate-app-context.xml"})
@TransactionConfiguration(transactionManager = "transactionManager",defaultRollback = false)

public class PersonRepositoryTest {

    @Autowired
    private PersonRepository repository;

    @Test
    public void createPerson() {
        Name name = new Name();
        name.setFirstName("Amin");
        name.setLastName("Mohammed-Coleman");
        Person amin = new Person();
        amin.setName(name);
        amin.setDateOfBirth(new Date());
        amin.setDescription("Nice person");

        repository.create(amin);

        Person aminLoadedFromRepository = repository.find(amin.getId());
        assertEquals(amin.getName(), aminLoadedFromRepository.getName());
    }

    @Test
    public void search() {
        Name name = new Name();

        name.setFirstName("Amin");
        name.setLastName("Mohammed-Coleman");
        Person amin = new Person();
        amin.setName(name);
        amin.setDateOfBirth(new Date());
        amin.setDescription("Nice person");

        repository.create(amin);

        final List<Person> people = repository.search("Mohammed-Coleman");
        assertEquals(1, people.size());

    }
}
