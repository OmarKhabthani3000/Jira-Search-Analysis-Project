package com.amin.spring.hibernate.repository;

import java.util.List;

import com.amin.spring.hibernate.entity.Person;

/**
 * PersonRepository
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 7, 2010
 */
public interface PersonRepository {

    Person create(Person person);

    Person update(Person person);

    List<Person> search (String query);

    Person find(Long id);
}
