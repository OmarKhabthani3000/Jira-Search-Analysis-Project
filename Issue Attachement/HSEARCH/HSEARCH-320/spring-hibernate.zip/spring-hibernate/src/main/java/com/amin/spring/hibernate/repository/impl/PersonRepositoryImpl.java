package com.amin.spring.hibernate.repository.impl;

import java.sql.SQLException;
import java.util.List;

import com.amin.spring.hibernate.entity.Person;
import com.amin.spring.hibernate.repository.PersonRepository;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.queryParser.QueryParser;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.SearchFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

/**
 * PersonRepositoryImpl
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 7, 2010
 */
@Repository
public class PersonRepositoryImpl implements PersonRepository {

    @Autowired
    private HibernateTemplate hibernateTemplate;

    public Person create(Person person) {
        hibernateTemplate.save(person);
        return person;
    }

    public Person update(Person person) {
        hibernateTemplate.update(person);
        return person;
    }

    public Person find(Long id) {
        return hibernateTemplate.get(Person.class, id);
    }

    public List<Person> search(final String term) {
        return hibernateTemplate.execute(new HibernateCallback<List<Person>>() {
            public List<Person> doInHibernate(Session session) throws HibernateException, SQLException {
                FullTextSession fullTextSession = org.hibernate.search.Search.getFullTextSession(session);
                SearchFactory searchFactory = fullTextSession.getSearchFactory();
                Analyzer entityScopedAnalyzer = searchFactory.getAnalyzer(Person.class);


                if (entityScopedAnalyzer == null) {
                    entityScopedAnalyzer = new StandardAnalyzer();
                }

                QueryParser parser = new MultiFieldQueryParser(new String[]{"name.firstName", "name.middleName", "name.lastName", "description"}, entityScopedAnalyzer);
                org.apache.lucene.search.Query query = null;
                try {
                    query = parser.parse(term);
                } catch (Exception e) {
                    throw new IllegalStateException(e);
                }

                FullTextQuery fullTextQuery = fullTextSession.createFullTextQuery(query, Person.class);
                org.hibernate.Query hibQuery = fullTextQuery;

                return hibQuery.list();

            }
        });
    }
}
