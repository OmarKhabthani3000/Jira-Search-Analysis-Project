package com.amin.spring.hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Store;

/**
 * Name
 *
 * @author: Amin Mohammed-Coleman
 * @since: Apr 7, 2010
 */
@Embeddable
public class Name {

    @Column(name = "FIRST_NAME")
    @Field(name = "firstName", store = Store.YES, index = Index.TOKENIZED)
    private String firstName;

    @Column(name = "MIDDLE_NAME", nullable = true)
    @Field(name = "middleName", store = Store.YES, index = Index.TOKENIZED)
    private String middleName;

    @Column(name = "LAST_NAME")
    @Field(name = "lastName", store = Store.YES, index = Index.TOKENIZED)
    private String lastName;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Name name = (Name) o;

        if (firstName != null ? !firstName.equals(name.firstName) : name.firstName != null) return false;
        if (lastName != null ? !lastName.equals(name.lastName) : name.lastName != null) return false;
        if (middleName != null ? !middleName.equals(name.middleName) : name.middleName != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = firstName != null ? firstName.hashCode() : 0;
        result = 31 * result + (middleName != null ? middleName.hashCode() : 0);
        result = 31 * result + (lastName != null ? lastName.hashCode() : 0);
        return result;
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(firstName).append(" ");
        if (middleName != null || "".equals(middleName)) {
            builder.append(middleName).append(" ");
        }
        builder.append(lastName);
        return builder.toString();
    }
}

