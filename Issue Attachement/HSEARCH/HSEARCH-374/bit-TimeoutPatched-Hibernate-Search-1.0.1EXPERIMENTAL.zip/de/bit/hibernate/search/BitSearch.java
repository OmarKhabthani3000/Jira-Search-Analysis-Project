// $Id: Search.java 14845 2008-07-03 12:41:06Z hardy.ferentschik $
package de.bit.hibernate.search;

import org.hibernate.Session;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.impl.FullTextSessionImpl;

import de.bit.hibernate.search.impl.BitFullTextSessionImpl;

/**
 * Helper class to get a FullTextSession out of a regular session.
 * 
 * @author Emmanuel Bernard
 * @author Hardy Ferentschik
 * @author Benjamin Gniza - bridgingIT (copied and modified FullTextSessionImpl to BitFullTextSessionImpl)
 */
public final class BitSearch {

    private BitSearch() {
    }

    public static FullTextSession getFullTextSession(Session session) {
        if (session instanceof FullTextSessionImpl) {
            return (FullTextSession) session;
        } else {
            return new BitFullTextSessionImpl(session);
        }
    }

    /**
     * @deprecated As of release 3.1.0, replaced by {@link #getFullTextSession(Session)}
     */
    @Deprecated
    public static FullTextSession createFullTextSession(Session session) {
        return getFullTextSession(session);
    }
}