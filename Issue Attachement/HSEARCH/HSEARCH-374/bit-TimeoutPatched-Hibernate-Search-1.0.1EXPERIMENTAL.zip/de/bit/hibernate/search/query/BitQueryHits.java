// $Id: QueryHits.java 15603 2008-11-20 16:42:49Z hardy.ferentschik $
/*
 * JBoss, Home of Professional Open Source Copyright 2008, Red Hat Middleware LLC, and individual contributors by the @authors tag. See the
 * copyright.txt in the distribution for a full listing of individual contributors.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may
 * obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under the License.
 */
package de.bit.hibernate.search.query;

import java.io.IOException;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.FieldSelector;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Explanation;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.HitCollector;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.PrefixQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TimeLimitedCollector;
import org.apache.lucene.search.TopDocCollector;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.TopFieldDocCollector;
import org.apache.lucene.search.WildcardQuery;
import org.hibernate.search.SearchException;
import org.hibernate.search.query.QueryHits;

/**
 * A helper class which gives access to the current query and its hits. This class will dynamically reload the underlying
 * <code>TopDocs</code> if required.
 * 
 * @author Hardy Ferentschik
 * @author Benjamin Gniza - Bridging IT (extended for timeout support and !experimental! support for finding a offenting search term which
 *         causes a TooManyClauses exception)
 */
public class BitQueryHits extends QueryHits {

    /**
     * Exception thrown if a term resolves to too many clauses
     * 
     * @author BGniza
     * 
     */
    public class TooManyClauses extends RuntimeException {
        /**
         * 
         */
        private static final long serialVersionUID = -6594078532444090963L;
        private String            clause;

        public TooManyClauses(String clause) {
            this.clause = clause;
        }

        /**
         * Returns the clause causing the TooManyClauses Exception<br />
         * <strong>This does not return the CAUSE but the CLAUSE</strong>
         * 
         * @return
         */
        public String getClause() {
            return clause;
        }

    }

    private static final int                    DEFAULT_TOP_DOC_RETRIEVAL_SIZE = 1000;
    private static final long                   DEFAULT_TIMEOUT                = 0;
    public final org.apache.lucene.search.Query preparedQuery;
    public final Searcher                       searcher;
    public final Filter                         filter;
    public final Sort                           sort;
    public final int                            totalHits;
    public TopDocs                              topDocs;
    private boolean                             timeLimitExceeded              = false;
    private final static Query                  dummyQuery                     = new TermQuery(new Term("dummy", "dummy"));
    private final IndexReader                   indexReader;
    private final long                          timeout;

    public BitQueryHits(IndexSearcher searcher, org.apache.lucene.search.Query preparedQuery, Filter filter, Sort sort, long timeout)
            throws IOException {
        this(searcher, preparedQuery, filter, sort, DEFAULT_TOP_DOC_RETRIEVAL_SIZE, timeout);
    }

    public BitQueryHits(IndexSearcher searcher, org.apache.lucene.search.Query preparedQuery, Filter filter, Sort sort, Integer n)
            throws IOException {
        this(searcher, preparedQuery, filter, sort, n, DEFAULT_TIMEOUT);
    }

    public BitQueryHits(IndexSearcher searcher, org.apache.lucene.search.Query preparedQuery, Filter filter, Sort sort, Integer n,
            long timeout) throws IOException {
        super(searcher, dummyQuery, filter, sort, 1);
        this.indexReader = searcher.getIndexReader();
        this.timeout = timeout;

        this.preparedQuery = preparedQuery;

        this.searcher = searcher;
        this.filter = filter;
        this.sort = sort;
        updateTopDocs(n);

        // Need to do that here, because the Java compiler will prohibit assignment of this field outside the constructor
        if (this.timeLimitExceeded) {
            // If the time limit was exceeded, don't return the total Hits but only the found hits until the timeout occurred
            this.totalHits = topDocs.scoreDocs.length;
        } else {
            this.totalHits = topDocs.totalHits;
        }

    }

    public Document doc(int index) throws IOException {
        return searcher.doc(docId(index));
    }

    public Document doc(int index, FieldSelector selector) throws IOException {
        return searcher.doc(docId(index), selector);
    }

    public ScoreDoc scoreDoc(int index) throws IOException {
        if (index >= totalHits) {
            throw new SearchException("Not a valid ScoreDoc index: " + index);
        }

        if (timeLimitExceeded && index >= topDocs.scoreDocs.length) {
            // TODO - Search for a better text
            throw new RuntimeException(
                    "The time limit for this query was reached! You can only get documents that where found until the timeout.");
        }
        // TODO - Is there a better way to get more TopDocs? Get more or less?
        if (index >= topDocs.scoreDocs.length) {
            updateTopDocs(2 * index);
        }

        return topDocs.scoreDocs[index];
    }

    public int docId(int index) throws IOException {
        return scoreDoc(index).doc;
    }

    public float score(int index) throws IOException {
        return scoreDoc(index).score;
    }

    public Explanation explain(int index) throws IOException {
        return searcher.explain(preparedQuery, docId(index));
    }

    private void updateTopDocs(int n) throws IOException {
        // Get the collector to gather the documents
        TopDocCollector topDocCollector = getTopDocCollector(n);
        // Get the collector to search with
        HitCollector searchCollector = getHitCollectorForSearch(topDocCollector);

        try {
            searcher.search(preparedQuery, filter, searchCollector);
        } catch (TimeLimitedCollector.TimeExceededException ex) {
            // The search reached the time limit (but may have found hits)
            this.timeLimitExceeded = true;

            /** EXPERIMANTAL. Will only work in very special cases such as ours ; **/
        } catch (BooleanQuery.TooManyClauses tmc) {
            // Try to find the offending Clause and throw a exception containing it
            throwExceptionForOffendingClause(preparedQuery);
        }
        // Use the topDocs collector to get the docs since the searchCollector isn't necessarily a top TopDocCollector
        topDocs = topDocCollector.topDocs();

    }

    /**
     * Construct a collector to search with.<br />
     * Either returns the given collector or returnes as {@link TimeLimitedCollector} if a timeout has been specified ({@link #timeout})
     * 
     * @param topDocCollector
     * @return
     */
    private HitCollector getHitCollectorForSearch(TopDocCollector topDocCollector) {
        // Wrap the topdocs collector in a time limited collector if a timeout has been specified
        if (this.timeout > DEFAULT_TIMEOUT) {
            return new TimeLimitedCollector(topDocCollector, timeout);
        }
        return topDocCollector;
    }

    /**
     * @param number
     * @return a {@link TopDocCollector} for the given number of documents
     * @throws IOException
     */
    private TopDocCollector getTopDocCollector(int number) throws IOException {
        if (this.sort != null) {
            return new TopFieldDocCollector(this.indexReader, this.sort, number);
        }
        return new TopDocCollector(number);

    }

    /**
     * ALWAYS throws a specific exception providing the variable part of the query, which resolved to too many clauses.
     * 
     * @param preparedQuery
     *            the query to examine
     * 
     */
    private void throwExceptionForOffendingClause(Query preparedQuery) {

        int maxClauseCount = 0;
        BooleanClause maxClause = null;
        BooleanClause clause = null;

        BooleanQuery bq = (BooleanQuery) preparedQuery;
        BooleanClause[] clauses = bq.getClauses();

        if (clauses.length == 1) {
            // There is only one clause, so it must be this clause!
            clause = clauses[0];
        } else {
            // Cycle thru the clauses
            for (BooleanClause boolClause : clauses) {
                try {
                    Query q = boolClause.getQuery().rewrite(indexReader);
                    BooleanQuery bq1 = (BooleanQuery) q;
                    int tmpLength = bq1.getClauses().length;
                    if (tmpLength > maxClauseCount) {
                        // If no exception (BooleanQuery.TooManyClauses) occurred, remember the BooleanClause with the most sub-clauses
                        maxClauseCount = tmpLength;
                        maxClause = boolClause;
                    }

                } catch (IOException ex) {
                    // Something went wrong
                    throw new RuntimeException(ex);
                } catch (BooleanQuery.TooManyClauses tmc) {
                    // This clause is (one of) the offending clauses
                    clause = boolClause;
                    break;
                }
            }
            // No clause caused the TooManyClauses-Exception, so take the one with the most sub-clauses
            if (clause == null) {
                clause = maxClause;
            }
        }
        // Translate the lucenes clause to the search term(s) provided
        String userClause = findUserClause(clause);
        throw new TooManyClauses(userClause);
    }

    /**
     * Returns the user/variable part of the given clause.<br />
     * Returns "undefined" if the variable part of the clause could not be found.
     * 
     * @param query
     * @return
     */
    private String findUserClause(BooleanClause clause) {
        Query q = findOffendingQuery(clause);
        return findUserTerm(q);
    }

    /**
     * Returns the user/variable part of the given query.<br />
     * Returns "undefined" if the variable part of the query could not be found.
     * 
     * @param query
     * @return
     */
    private String findUserTerm(Query query) {
        if (query instanceof WildcardQuery) {
            return ((WildcardQuery) query).getTerm().text();
        }
        if (query instanceof PrefixQuery) {
            return ((PrefixQuery) query).getPrefix().text();
        }
        return "undefined";
    }

    /**
     * Finds the offending query for the given cause.<br />
     * It is assumed, that {@link PrefixQuery}s or {@link WildcardQuery}s are usually offenders.<br />
     * If no offender could be found <strong>null</strong> is returned
     * 
     * @param clause
     * @return an instance of {@link PrefixQuery} or am instance of {@link WildcardQuery} or null
     */
    private Query findOffendingQuery(BooleanClause clause) {
        if (clause.getQuery() instanceof WildcardQuery) {
            return clause.getQuery();
        }
        if (clause.getQuery() instanceof PrefixQuery) {
            return clause.getQuery();
        }
        if (clause.getQuery() instanceof BooleanQuery) {
            BooleanQuery bq = (BooleanQuery) clause.getQuery();
            BooleanClause[] clauses = bq.getClauses();
            for (BooleanClause loopclause : clauses) {
                Query query = findOffendingQuery(loopclause);
                if (query != null) {
                    return query;
                }
            }
        }
        return null;
    }

    /**
     * 
     * @return true if the time limit for this search has been reached/exceeded. All results until the timeout are available via
     */
    public boolean isTimeLimitExceeded() {
        return timeLimitExceeded;
    }

}
