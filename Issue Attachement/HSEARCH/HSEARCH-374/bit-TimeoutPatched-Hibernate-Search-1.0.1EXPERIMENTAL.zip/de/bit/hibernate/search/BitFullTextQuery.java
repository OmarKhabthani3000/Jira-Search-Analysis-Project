package de.bit.hibernate.search;

import org.hibernate.search.FullTextQuery;

/**
 * Extension of the {@link FullTextQuery} interface of hibernate to provide timeouts during search.
 * 
 * @author Benjamin Gniza - bridgingIT
 * 
 */
public interface BitFullTextQuery extends FullTextQuery {
    /**
     * 
     * @return true if the search timeout has been reached/exceeded.<br />
     *         The search may still have hits, so the {@link FullTextQuery#list()} method will always succeed.
     */
    boolean isSearchTimoutExceeded();

    /**
     * Set the timeout to the given amount of milliseconds.<br/>
     * The search {@link FullTextQuery#list()} will <strong>NOT</strong> throw an exception, but may return no or not all matching results.
     * 
     * @param timeoutInMillis
     *            the timeout in millis. To disable the timeout provide values <=0.
     * @see #isSearchTimoutExceeded()
     */
    void setTimeout(long timeoutInMillis);

    /**
     * 
     * @return the current search timeout. <br />
     *         Values <=0 indicate no timeout.
     * 
     */
    long getTimeout();
}
