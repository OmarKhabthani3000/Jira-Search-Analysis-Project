package org.infinispan;

import org.hibernate.search.mapper.pojo.mapping.definition.annotation.FullTextField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;
import org.infinispan.configuration.cache.ConfigurationBuilder;
import org.infinispan.configuration.global.GlobalConfigurationBuilder;
import org.infinispan.manager.DefaultCacheManager;
import org.infinispan.protostream.annotations.ProtoField;
import org.infinispan.query.Search;
import org.infinispan.query.dsl.Query;
import org.infinispan.query.dsl.QueryFactory;

import java.awt.print.Book;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.infinispan.configuration.cache.IndexStorage.FILESYSTEM;

public class QueryTest {

    @Indexed
    public static class MyBook {

        @FullTextField
        @ProtoField(number = 1)
        String title;

        @FullTextField
        @ProtoField(number = 2)
        String description;

        @ProtoField(number = 3)
        int publicationYear;
    }

    @Indexed
    public static class MyAuthor {

        @ProtoField(number = 1)
        @FullTextField
        String name;

        @ProtoField(number = 2)
        @FullTextField
        String surname;
    }

    public static void main(String[] args) {
        DefaultCacheManager cacheManager = null;
        try {

            GlobalConfigurationBuilder globalBuilder = GlobalConfigurationBuilder.defaultClusteredBuilder();

            cacheManager = new DefaultCacheManager(globalBuilder.build());
            cacheManager.createCache("myCache", new ConfigurationBuilder()
                    .indexing().enable().storage(FILESYSTEM).path("target/index")
                    .addIndexedEntity(MyBook.class)
                    .addIndexedEntities(MyAuthor.class).build());
            final Cache<Integer, MyBook> cache = cacheManager.getCache("myCache");
            final QueryFactory queryFactory = Search.getQueryFactory(cache);
            AtomicBoolean run = new AtomicBoolean(true);
            Thread t1 = new Thread(() -> {
                while (true) {
                    if (!run.get()) {
                        break;
                    }
                    cache.put(1, randomBook());
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });

            Thread t2 = new Thread(() -> {
                while (true) {
                    if (!run.get()) {
                        break;
                    }
                    Query<Book> query = queryFactory.create("SELECT title FROM " + MyBook.class.getName());
                    System.out.println(query.execute().hitCount().getAsLong());
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });

            Thread t3 = new Thread(() -> {
                while (true) {
                    if (!run.get()) {
                        break;
                    }
                    Query<Book> query = queryFactory.create("Delete FROM " + MyBook.class.getName());
                    System.out.println(query.execute().hitCount().getAsLong());
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });

            t1.start();
            t2.start();
            t3.start();

            try {
                Thread.sleep(30 * 1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            run.set(false);

            t1.join();
            t2.join();
            t3.join();

        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            System.out.println("Stopping CM");
            if (cacheManager != null) cacheManager.stop();
        }
    }

    private static MyBook randomBook() {
        MyBook b = new MyBook();
        b.title = UUID.randomUUID().toString();
        b.description = UUID.randomUUID().toString();
        b.publicationYear = ThreadLocalRandom.current().nextInt();
        return b;
    }
}