package org.hibernate.search.test.engine.optimizations;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Proxy;

@Entity
@Proxy(lazy = false)
@Table(name="location_group")
public class LocationGroup
{
    @Id()
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long groupId;
    
    @Column(length = 255)
    private String name;
    
    @OneToMany(mappedBy="locationGroup", cascade={ CascadeType.ALL }, fetch=FetchType.LAZY)
    Collection<Location> locations = new ArrayList<Location>();

    
    public LocationGroup()
    {
    }
    
    public LocationGroup(String name)
    {
        this.name = name;
    }
    
    public Long getGroupId()
    {
        return groupId;
    }

    public void setGroupId(Long groupId)
    {
        this.groupId = groupId;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Collection<Location> getLocations()
    {
        return locations;
    }

    public void setLocations(Collection<Location> locations)
    {
        this.locations = locations;
    }

}
