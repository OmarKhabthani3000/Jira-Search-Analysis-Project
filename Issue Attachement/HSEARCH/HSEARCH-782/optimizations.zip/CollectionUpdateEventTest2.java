package org.hibernate.search.test.engine.optimizations;

import java.lang.annotation.ElementType;

import org.hibernate.Transaction;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.cfg.EntityMapping;
import org.hibernate.search.cfg.SearchMapping;
import org.hibernate.search.test.util.FullTextSessionBuilder;
import org.hibernate.search.util.LoggerFactory;
import org.junit.Test;
import org.slf4j.Logger;

public class CollectionUpdateEventTest2
{
    private static final Logger log = LoggerFactory.make();
    
    @Test
    public void testScenario()
    {
        FullTextSessionBuilder fullTextSessionBuilder = createSearchFactory();
        try {
            initializeData( fullTextSessionBuilder );
            FullTextSession fullTextSession = fullTextSessionBuilder.openFullTextSession();
            try 
            {
                LocationGroup group = (LocationGroup) fullTextSession.get(LocationGroup.class, 1L);
                log.debug("LocationGroup name: {}", group.getName());
                
                addLocationToGroupCollection(fullTextSession, group);
                
            } finally {
                fullTextSession.close();
            }
        } finally {
            fullTextSessionBuilder.close();
        }
    }
    
    
    private FullTextSessionBuilder createSearchFactory()
    {
        FullTextSessionBuilder builder = new FullTextSessionBuilder()
            .addAnnotatedClass( LocationGroup.class )
            .addAnnotatedClass( Location.class );
        SearchMapping fluentMapping = builder.fluentMapping();
        EntityMapping locationGroupMapping = fluentMapping.entity( LocationGroup.class );
        
        locationGroupMapping
            .property("name", ElementType.FIELD)
            .property("locations", ElementType.FIELD).containedIn()
        .entity(Location.class).indexed()
            .property("locationId", ElementType.FIELD).documentId()
            .property("name", ElementType.FIELD)
            .property("locationGroup", ElementType.FIELD).indexEmbedded().depth(1);
    
        return builder.build();
    }
    

    /**
     * Initialize the test data.
     * @param fulltextSessionBuilder 
     */
    private void initializeData(FullTextSessionBuilder fulltextSessionBuilder) {
        FullTextSession fullTextSession = fulltextSessionBuilder.openFullTextSession();
            try {
            final Transaction transaction = fullTextSession.beginTransaction();
    
            LocationGroup group = new LocationGroup("Floor 1");
            fullTextSession.persist(group);
            
            for (int i = 0; i < 5; i++)
            {
                Location location = new Location("Room 10" + i);
                fullTextSession.persist(location);
                
                group.getLocations().add(location);
                location.setLocationGroup(group);
                fullTextSession.merge(group);
            }
            transaction.commit();
        }
        finally {
            fullTextSession.close();
        }
    }
    
    private void addLocationToGroupCollection(FullTextSession fullTextSession, LocationGroup group) {
        log.debug("addLocationToGroupCollection");
        final Transaction transaction = fullTextSession.beginTransaction();

        Location location = new Location("New Room");
        fullTextSession.persist( location );
        
        group.getLocations().add(location);
        location.setLocationGroup(group);
        fullTextSession.merge( group );

        transaction.commit();
    }
    
}
