package org.hibernate.search.test.engine.optimizations;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;
import org.hibernate.annotations.Proxy;

@Entity
@Proxy(lazy = false)
@Table(name="location")
public class Location
{
    @Id()
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long locationId;

    @Column(length = 255)
    private String name;
    
    @ManyToOne(fetch=FetchType.LAZY, targetEntity=LocationGroup.class)
    @JoinColumn(name = "location_group_id")
    @LazyToOne(LazyToOneOption.PROXY)
    private LocationGroup locationGroup;

    
    public Location()
    {
    }
    
    public Location(String name)
    {
        this.name = name;
    }
    
    public Long getLocationId()
    {
        return locationId;
    }

    public void setLocationId(Long locationId)
    {
        this.locationId = locationId;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public LocationGroup getLocationGroup()
    {
        return locationGroup;
    }

    public void setLocationGroup(LocationGroup locationGroup)
    {
        this.locationGroup = locationGroup;
    }

}
