package com.persistence;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.search.annotations.Indexed;


/**
 * The persistent class for the Tests database table.
 * 
 */
@Entity
@Table(name="Tests")
@Indexed
public class Test implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int testsID;

	private String id;

	private String name;

  public Test() {
  }

	public int getTestsID() {
		return this.testsID;
	}

	public void setTestsID(int testsID) {
		this.testsID = testsID;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}