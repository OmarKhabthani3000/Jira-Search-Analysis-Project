package org.hibernate.search.bugs;

public enum MyEnum {

	DEFAULT, OTHER;
	
}
