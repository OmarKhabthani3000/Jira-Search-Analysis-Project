package org.hibernate.search.bugs;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
@Indexed
public class YourAnnotatedEntity {

	@Id
	@DocumentId
	private Long id;

	@OneToMany(mappedBy = "parent")
	private List<MyNestedObject> myNestedObjectList = new ArrayList<>();

	protected YourAnnotatedEntity() {
	}

	public YourAnnotatedEntity(Long id) {
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public List<MyNestedObject> getMyNestedObjectList() {
		return myNestedObjectList;
	}

	public void setMyNestedObjectList(List<MyNestedObject> myNestedObjectList) {
		this.myNestedObjectList = myNestedObjectList;
	}

	@IndexedEmbedded
	@Field(name="mostRecentObjectMyEnum", bridge=@FieldBridge(impl=MostRecentNestedObjectMyEnumBridge.class))
	public MyNestedObject getMostRecentObject() {
		if (getMyNestedObjectList() == null)
			return null;
		MyNestedObject mostRecent =  getMyNestedObjectList().stream().max(
				(h1, h2) -> h1.getCreationTime().compareTo(h2.getCreationTime())).orElse(null);
		return mostRecent;
	}
}
