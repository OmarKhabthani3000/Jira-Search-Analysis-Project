package org.hibernate.search.bugs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import org.apache.lucene.search.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.test.SearchTestBase;
import org.hibernate.search.testsupport.TestForIssue;
import org.junit.Test;

public class YourTestCase extends SearchTestBase {

	@Override
	public Class<?>[] getAnnotatedClasses() {
		return new Class<?>[]{ YourAnnotatedEntity.class , MyNestedObject.class };
	}

	@Test
	@TestForIssue(jiraKey = "HSEARCH-NNNNN") // Please fill in the JIRA key of your issue
	public void testYourBug() {
		
		createObjects();
		
		runInitialSearch();

		updateBooleanValue();
		
		runUpdatedBooleanSearch();
	
		updateEnumValue();
		
		runUpdatedEnumQuery();
	}
	
	private void createObjects() {
		Session s = openSession();
		
		YourAnnotatedEntity yourEntity = new YourAnnotatedEntity( 1L );
		
		Transaction tx = s.beginTransaction();
		s.persist( yourEntity );

		MyNestedObject myNestedObject = new MyNestedObject(2L);
		myNestedObject.setMyBool(Boolean.FALSE);
		myNestedObject.setCreationTime(Timestamp.valueOf(LocalDateTime.now()));
		myNestedObject.setParent(yourEntity);
		s.persist(myNestedObject);
		
		yourEntity.getMyNestedObjectList().add(myNestedObject);
		s.persist(yourEntity);
		
		tx.commit();
		s.close();
	}
	
	private void runInitialSearch() {
		FullTextSession session = Search.getFullTextSession( openSession() );
		QueryBuilder qb = session.getSearchFactory().buildQueryBuilder().forEntity( YourAnnotatedEntity.class ).get();
		Query query = qb.keyword().onField( "mostRecentObject.myBool" ).matching( Boolean.FALSE ).createQuery();

		List<YourAnnotatedEntity> result = (List<YourAnnotatedEntity>) session.createFullTextQuery( query ).list();
		assertEquals( 1, result.size() );
		assertEquals( 1L, (long) result.get( 0 ).getId() );
		
		session.close();
	}
	
	private void updateBooleanValue() {
		Session s = openSession();
		
		Transaction tx = s.beginTransaction();

		SQLQuery sqlQuery = s.createSQLQuery("select * from MyNestedObject where id = 2").addEntity(MyNestedObject.class);
		List<MyNestedObject> retrievalList =  sqlQuery.list();
		
		assertNotNull(retrievalList);
		assertEquals(1, retrievalList.size());
		
		MyNestedObject retrievedObject = retrievalList.get(0);
		retrievedObject.setMyBool(Boolean.TRUE);
		s.update(retrievedObject);
		tx.commit();

		s.close();
	}

	private void runUpdatedBooleanSearch() {
		FullTextSession session = Search.getFullTextSession( openSession() );
		QueryBuilder qb = session.getSearchFactory().buildQueryBuilder().forEntity( YourAnnotatedEntity.class ).get();
		Query secondQuery = qb.keyword().onField( "mostRecentObject.myBool" ).matching( Boolean.TRUE ).createQuery();

		List<YourAnnotatedEntity> secondResult = (List<YourAnnotatedEntity>) session.createFullTextQuery( secondQuery ).list();
		assertEquals( 1, secondResult.size() );
		assertEquals( 1L, (long) secondResult.get( 0 ).getId() );
		
		session.close();
	}
	
	private void updateEnumValue() {
		Session s = openSession();
		
		Transaction tx = s.beginTransaction();

		SQLQuery sqlQuery2 = s.createSQLQuery("select * from MyNestedObject where id = 2").addEntity(MyNestedObject.class);
		List<MyNestedObject> retrievalList2 =  sqlQuery2.list();
		
		assertNotNull(retrievalList2);
		assertEquals(1, retrievalList2.size());
		
		MyNestedObject retrievedObject2 = retrievalList2.get(0);
		retrievedObject2.setMyEnum(MyEnum.OTHER);
		s.update(retrievedObject2);
		tx.commit();
		
		s.close();
	}
	
	private void runUpdatedEnumQuery() {
		FullTextSession session = Search.getFullTextSession( openSession() );
		QueryBuilder qb = session.getSearchFactory().buildQueryBuilder().forEntity( YourAnnotatedEntity.class ).get();
		Query thirdQuery = qb.keyword().onField( "mostRecentObjectMyEnum" ).ignoreFieldBridge().matching( MyEnum.OTHER.toString().toLowerCase() ).createQuery();

		List<YourAnnotatedEntity> thirdResult = (List<YourAnnotatedEntity>) session.createFullTextQuery( thirdQuery ).list();
		assertEquals( 1, thirdResult.size() );
		assertEquals( 1L, (long) thirdResult.get( 0 ).getId() );
		
		session.close();
	}
}
