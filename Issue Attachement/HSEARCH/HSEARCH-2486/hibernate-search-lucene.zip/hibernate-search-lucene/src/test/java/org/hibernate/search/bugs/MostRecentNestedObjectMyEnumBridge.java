package org.hibernate.search.bugs;

import org.hibernate.search.bridge.StringBridge;

public class MostRecentNestedObjectMyEnumBridge implements StringBridge {

	@Override
	public String objectToString(Object arg0) {
		String returnValue = null;
		
		if(arg0 != null) {
			MyNestedObject myNestedObject = (MyNestedObject) arg0;
			MyEnum myEnum = myNestedObject.getMyEnum();
			
			if(myEnum != null)
				returnValue = myEnum.toString();
			
				if(returnValue != null)
					returnValue = returnValue.toLowerCase();
		}
		
		return returnValue;
	}

}
