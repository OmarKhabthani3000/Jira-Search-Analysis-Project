package org.hibernate.search.bugs;

import java.sql.Timestamp;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.bridge.builtin.EnumBridge;

@MappedSuperclass
public abstract class MyAbstractParent {

	@Id
	private Long id;
	
	private Timestamp creationTime;
	
//	@Enumerated(EnumType.STRING)
//	@Field(analyze = Analyze.NO, bridge=@FieldBridge(impl=EnumBridge.class))
	private MyEnum myEnum = MyEnum.DEFAULT;
	
	@Field
	private Boolean myBool = Boolean.FALSE;
	
	@ManyToOne
	@ContainedIn
	private YourAnnotatedEntity parent;
	
	protected MyAbstractParent(){}
	
	public MyAbstractParent(Long id) {
		this.id = id;
	}
	
	public Long getId() {
		return id;
	}

	public Timestamp getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}

	public boolean getMyBool() {
		if(myBool == null)
			return false;
		return myBool;
	}

	public void setMyBool(Boolean myBool) {
		this.myBool = myBool;
	}

	public YourAnnotatedEntity getParent() {
		return parent;
	}

	public void setParent(YourAnnotatedEntity parent) {
		this.parent = parent;
	}

	public MyEnum getMyEnum() {
		return myEnum;
	}

	public void setMyEnum(MyEnum myEnum) {
		this.myEnum = myEnum;
	}
	
}
