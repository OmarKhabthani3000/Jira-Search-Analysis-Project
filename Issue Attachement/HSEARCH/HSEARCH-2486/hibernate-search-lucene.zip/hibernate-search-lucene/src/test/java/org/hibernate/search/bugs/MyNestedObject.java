package org.hibernate.search.bugs;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.bridge.builtin.EnumBridge;

@Entity
public class MyNestedObject extends MyAbstractParent {

	protected MyNestedObject() {}
	
	public MyNestedObject(Long id) {
		super(id);
	}
	
//	@Enumerated(EnumType.STRING)
//	@Field(analyze = Analyze.NO, bridge=@FieldBridge(impl=EnumBridge.class))
//	@Override
//	public MyEnum getMyEnum() {
//		return super.getMyEnum();
//	}
	
//	@Override
//	public void setMyEnum(MyEnum myEnum) {
//		super.setMyEnum(myEnum);
//	}
	
}
