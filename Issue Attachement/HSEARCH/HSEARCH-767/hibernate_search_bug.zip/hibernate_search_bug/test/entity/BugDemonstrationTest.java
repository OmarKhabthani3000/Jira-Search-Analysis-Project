package entity;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.TermQuery;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.testng.annotations.Test;

import com.manning.hsia.test.HSiATestCase;

import static org.testng.Assert.*;

/**
 * @author Kyrill Alyoshin
 */
public class BugDemonstrationTest extends HSiATestCase {

    @Override
    protected Class[] getMappings() {
        return new Class[]{Dad.class, Son.class};
    }

    @Test
    public void showBug() throws Exception {
        Dad sourceDad = new Dad("sourceDad");

        Dad targetDad = new Dad("targetDad");

        Son sonToBeAdopted = new Son("sontobeadopted");
        sourceDad.add(sonToBeAdopted);

        Son regularSon = new Son("regularson");
        targetDad.add(regularSon);

        //first operation -> save
        FullTextSession session = Search.getFullTextSession(openSession());
        Transaction tx = session.beginTransaction();
        session.save(sourceDad);
        session.save(targetDad);
        session.save(sonToBeAdopted);
        session.save(regularSon);
        tx.commit();
        session.close();

        //=====================================================================================

        //Awesome, let's move sonToBeAdopted to targetDad
        session = Search.getFullTextSession(openSession());
        tx = session.beginTransaction();

        //!!!we're deliberately keeping target dad detached!!!


        //but let's bring the son to be moved
        sonToBeAdopted = (Son) session.get(Son.class, sonToBeAdopted.getId());
        sourceDad = sonToBeAdopted.getDad();

        sourceDad.getSons().remove(sonToBeAdopted);

        sonToBeAdopted.setDad(targetDad);
        targetDad.add(sonToBeAdopted);

        session.update(sonToBeAdopted);

        tx.commit();
        session.close();


        //===================================================================================

        //All right, let's see what happened during indexing....
        session = Search.getFullTextSession(openSession());
        tx = session.beginTransaction();

        //Well, can we find Dad through his old son? Yes.
        FullTextQuery q = session.createFullTextQuery(new TermQuery(new Term("sons.name", "regularson")), Dad.class);
        Dad result = (Dad) q.uniqueResult();

        //basically test if indexing works at all
        assertNotNull(result, "Dad should be found through his normal son!");

        session.flush();
        session.clear();

        //Well, can we find Dad through his new Son?

        q = session.createFullTextQuery(new TermQuery(new Term("sons.name", "sontobeadopted")), Dad.class);
        result = (Dad) q.uniqueResult();

        //and this one fails miserably
        assertNotNull(result, "Dad should be found through his adopted son too!");

        tx.commit();
        session.close();
    }

}
