package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;


@Entity
@Indexed
@Table(name = "dad")
@SequenceGenerator(name = "dadSeq", sequenceName = "dad_seq")
public class Dad {
    private Long id;
    private String name;

    private Set<Son> sons = new HashSet<Son>();

    public Dad() {
    }

    public Dad(String name) {
        this.name = name;
    }

    @Id
    @DocumentId
    @Column(name = "dad_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dadSeq")
    public Long getId() {
        return id;
    }

    private void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @IndexedEmbedded
    @OneToMany(mappedBy = "dad", fetch = FetchType.LAZY)
    public Set<Son> getSons() {
        return sons;
    }

    private void setSons(Set<Son> sons) {
        this.sons = sons;
    }

    public boolean add(Son son) {
        son.setDad(this);
        return sons.add(son);
    }
}
