package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;

/**
 * @author Kyrill Alyoshin
 */
@Entity
@Table(name = "son")
@SequenceGenerator(name = "sonSeq", sequenceName = "son_seq")
public class Son {
    private Long id;
    private String name;
    private Dad dad;

    public Son() {
    }

    public Son(String name) {
        this.name = name;
    }

    @Id
    @Column(name = "son_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sonSeq")
    public Long getId() {
        return id;
    }

    private void setId(Long id) {
        this.id = id;
    }

    @Field
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @ContainedIn
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "dad_id", nullable = false)
    public Dad getDad() {
        return dad;
    }

    public void setDad(Dad dad) {
        this.dad = dad;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Son)) return false;

        Son son = (Son) o;
        return name.equals(son.getName());
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }
}
