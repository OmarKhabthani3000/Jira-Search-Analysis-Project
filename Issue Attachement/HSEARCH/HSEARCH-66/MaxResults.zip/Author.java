package org.hibernate.search.test.maxResults;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Fields;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Store;

@Entity
@Table(name="authors")
@Indexed(index="authors")
public class Author
{
	protected Long id;
	protected String name;
	protected Set<Book> books = new HashSet<Book>();

	@Id
	@GeneratedValue(generator="id-increment")
	@GenericGenerator(name="id-increment", strategy="increment")
	@DocumentId
	public Long getId()
	{
		return id;
	}
	
	public void setId(Long id)
	{
		this.id = id;
	}
	
	@Fields(fields={
			@Field(name="name",
				   index=Index.TOKENIZED,
				   store=Store.YES),
			@Field(name="nameSort",
				   index=Index.UN_TOKENIZED,
				   store=Store.NO)})
	public String getName()
	{
		return name;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}	
}
