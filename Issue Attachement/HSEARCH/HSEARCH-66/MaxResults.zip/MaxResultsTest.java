package org.hibernate.search.test.maxResults;

import java.io.InputStream;
import java.net.URL;
import java.util.List;
import java.util.Iterator;

import org.apache.lucene.analysis.KeywordAnalyzer;
import org.apache.lucene.analysis.StopAnalyzer;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.MatchAllDocsQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.test.SearchTestCase;

public class MaxResultsTest extends SearchTestCase
{

	public void testMe() throws Exception
	{
		Session sess = openSession();
		Transaction tx = sess.beginTransaction();
		Book book = new Book();
		book.setTitle("Moo Goes The Cow");
		Author author = new Author();
		author.setName("Moo Cow");
		book.addAuthor(author);
		sess.persist(author);
		author = new Author();
		author.setName("Another Moo Cow");
		book.addAuthor(author);
		sess.persist(author);
		author = new Author();
		author.setName("A Third Moo Cow");
		book.addAuthor(author);
		sess.persist(author);
		author = new Author();
		author.setName("Random Moo Cow");
		book.addAuthor(author);
		sess.persist(author);
		sess.save(book);
		
		Book book2 = new Book();
		book2.setTitle("The Cow Goes Moo");
		author = new Author();
		author.setName("Moo Cow The First");
		book2.addAuthor(author);
		sess.persist(author);
		author = new Author();
		author.setName("Moo Cow The Second");
		book2.addAuthor(author);
		sess.persist(author);
		author = new Author();
		author.setName("Moo Cow The Third");
		book2.addAuthor(author);
		sess.persist(author);
		author = new Author();
		author.setName("Moo Cow The Fourth");
		book2.addAuthor(author);
		sess.persist(author);
		sess.save(book2);
		tx.commit();
		sess.clear();

		FullTextSession s = Search.createFullTextSession(sess);
		tx = s.beginTransaction();
		QueryParser parser = new QueryParser("title", new KeywordAnalyzer());
		Query query = parser.parse("title:moo");
		FullTextQuery hibQuery = s.createFullTextQuery(query, Book.class);
		List result = hibQuery.list();
		assertEquals("Should have returned 2 Books", 2, result.size());
		assertEquals("Book 1 should have four authors", 4, ((Book)result.get(0)).getAuthors().size());
		assertEquals("Book 2 should have four authors", 4, ((Book)result.get(1)).getAuthors().size());
		
		tx.commit();
		s.close();
	}
	
	@Override
	protected Class[] getMappings()
	{
		return new Class[]
		{
			Book.class,
			Author.class
		};
	}
}
