package org.hibernate.search.test.maxResults;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Fields;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Store;

@Entity
@Table(name="books")
@Indexed(index="books")
public class Book
{
	protected Long id;
	protected String title;
	protected Set<Author> authors = new HashSet<Author>();

	@Id
	@GeneratedValue(generator="id-increment")
	@GenericGenerator(name="id-increment", strategy="increment")
	@DocumentId
	public Long getId()
	{
		return id;
	}
	
	public void setId(Long id)
	{
		this.id = id;
	}
	
	/**
	 * @return the authors
	 */
    @ManyToMany(cascade=CascadeType.ALL,
			fetch=FetchType.EAGER,
			targetEntity=Author.class)
    @IndexedEmbedded(depth=1)
	public Set<Author> getAuthors()
	{
		return authors;
	}
	
	/**
	 * @param authors the authors to set
	 */
	public void setAuthors(Set<Author> authors)
	{
		this.authors = authors;
	}
	
	public void addAuthor(Author author)
	{
		this.getAuthors().add(author);
	}
	
	/**
	 * @return the title
	 */
	@Column(name="title",
	   		length=255,
	    		nullable=false)
	@Fields(fields={
			@Field(name="title",
				   index=Index.TOKENIZED,
				   store=Store.YES),
			@Field(name="titleSort",
				   index=Index.UN_TOKENIZED,
				   store=Store.NO)})
	public String getTitle()
	{
		return title;
	}
	
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title)
	{
		this.title = title;
	}
}
