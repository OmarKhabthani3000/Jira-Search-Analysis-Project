package org.hibernate.search.bugs;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.apache.lucene.search.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.query.engine.spi.FacetManager;
import org.hibernate.search.query.facet.Facet;
import org.hibernate.search.query.facet.FacetingRequest;
import org.hibernate.search.test.SearchTestBase;
import org.hibernate.search.testsupport.TestForIssue;
import org.junit.Test;

public class YourTestCase extends SearchTestBase {

	@Override
	public Class<?>[] getAnnotatedClasses() {
		return new Class<?>[]{ Book.class };
	}

	@Test
	@TestForIssue(jiraKey = "HSEARCH-NNNNN") // Please fill in the JIRA key of your issue
	public void testYourBug() {

		Session s = openSession();
		
		Transaction tx = s.beginTransaction();
		
		tx.begin();
		
		Book book1 = new Book( 1L );
		Book book2 = new Book( 2L );
		Book book3 = new Book( 3L );

		book1.getCategories().add("category1");
		book2.getCategories().add("category1");
		book2.getCategories().add("category2");
		book3.getCategories().add("category2");
		
		s.persist(book1);
		s.persist(book2);
		s.persist(book3);
		
		tx.commit();
		
		FullTextSession fullTextSession = Search.getFullTextSession(s);
		QueryBuilder builder = fullTextSession.getSearchFactory().buildQueryBuilder().forEntity(Book.class).get();
		String facetName = "myFacet";
		
		FacetingRequest facetingRequest = builder.facet()
				.name(facetName)
				.onField(Book.CATEGORIES)
				.discrete()
				.includeZeroCounts(false)
				.createFacetingRequest();
		
		Query luceneQuery = builder.all().createQuery();
		FullTextQuery fullTextQuery = fullTextSession.createFullTextQuery(luceneQuery, Book.class);
		FacetManager facetManager = fullTextQuery.getFacetManager();
		facetManager.enableFaceting(facetingRequest);
		List<Facet> facets = facetManager.getFacets(facetName);
		
		for (Facet facet : facets) {
			System.out.println(facet.getValue() + " : " + facet.getCount());
		}
		
		assertEquals( 2, facets.size() ); // Because of the bug, it's currently 3. But with my fix it's 2.
		
		s.close();
	}
}
