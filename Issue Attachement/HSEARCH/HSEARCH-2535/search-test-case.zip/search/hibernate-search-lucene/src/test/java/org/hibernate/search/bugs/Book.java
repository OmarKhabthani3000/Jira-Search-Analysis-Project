package org.hibernate.search.bugs;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Facet;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.annotations.Indexed;

@Entity
@Indexed
public class Book {

	public static final String CATEGORIES = "categories";
	
	@Id
	@DocumentId
	private Long id;

	@Field(name = CATEGORIES, bridge = @FieldBridge(impl = StringCollectionFieldBridge.class), analyze = Analyze.NO)
	@Facet(forField = CATEGORIES)
	@ElementCollection
	private List<String> categories = new ArrayList<String>();

	public Book(Long id) {
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public List<String> getCategories() {
		return categories;
	}

}
