package org.foobar;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath*:beans.xml"}) 
@TransactionConfiguration(transactionManager="transactionManager",defaultRollback=false)
public class MassIndexerTest {

	@Inject
	private EntityController entityController;
	
	@Test
	public void test() throws Exception {
		// create a bunch of entities
		entityController.createData();
		
		// create MassIndexer 
		// run indexer
		entityController.massIndex();
	}
}
