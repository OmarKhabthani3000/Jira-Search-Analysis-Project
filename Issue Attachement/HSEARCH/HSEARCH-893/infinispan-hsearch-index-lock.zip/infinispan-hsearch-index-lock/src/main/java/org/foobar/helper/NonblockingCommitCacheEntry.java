package org.foobar.helper;

import com.arjuna.ats.arjuna.common.Uid;

public class NonblockingCommitCacheEntry extends NonblockingCacheEntry {
	/**
	 * For commit_state - the transaction is done, there is no state
	 */
    public static final int NO_STATE_TYPE = -1;

	/**
	 * @param uid transaction identifier
	 * @param transactionName type name of the transaction 
	 */
	public NonblockingCommitCacheEntry(Uid uid, String transactionName) {
		super(uid, transactionName, null, NO_STATE_TYPE);
	}

	@Override
	public CacheAction getCacheAction() {
		return CacheAction.COMMIT;
	}
}
