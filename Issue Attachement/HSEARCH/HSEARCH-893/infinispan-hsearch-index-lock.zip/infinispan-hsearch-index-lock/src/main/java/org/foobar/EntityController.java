package org.foobar;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Used for transaction/session support
 * 
 */
@Component
public class EntityController {
	private Logger logger = Logger.getLogger(getClass());

	@Inject
	private CatalogDAO catalogDAO;
	
	@Inject
	private CatalogItemDAO catalogItemDAO;
	
	@Inject
	private ConsumerDAO consumerDAO;

	@Inject
	private ItemDAO itemDAO;

	@Transactional
	public void createData() {
		Catalog catalog = new Catalog();
		catalog.setName("parts");
		catalogDAO.persist(catalog);
		
		for (int i = 0; i < 25; i++) {
			Item item = new Item();
			item.setName("battery");
			itemDAO.persist(item);
			
			CatalogItem catalogItem = new CatalogItem();
			catalogItem.setCatalog(catalog);
			catalogItem.setItem(item);
			catalogItemDAO.persist(catalogItem);
			
			item.getCatalogItems().add(catalogItem);
			itemDAO.merge(item);
			
			catalog.getCatalogItems().add(catalogItem);
			catalogDAO.merge(catalog);
		}
	}
	
	@Transactional
	public void massIndex() throws Exception {
		EntityManager entityManager = itemDAO.getEntityManager();		
		FullTextEntityManager fullTextEntityManager = org.hibernate.search.jpa.Search.getFullTextEntityManager(entityManager);
		
		logger.info("Starting indexer...");
		fullTextEntityManager.createIndexer(Item.class)
			.batchSizeToLoadObjects(30)
			.threadsForSubsequentFetching(8)
			.threadsToLoadObjects(4)
			.startAndWait();
		logger.info("Indexer complete");
	}
}
