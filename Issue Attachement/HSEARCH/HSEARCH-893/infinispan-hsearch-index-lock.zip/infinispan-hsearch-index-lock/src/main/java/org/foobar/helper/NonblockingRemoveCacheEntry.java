package org.foobar.helper;

import com.arjuna.ats.arjuna.common.Uid;

public class NonblockingRemoveCacheEntry extends NonblockingCacheEntry {
	/**
	 * @param uid transaction identifier
	 * @param transactionName type name of the transaction 
	 * @param fileType the file type when written to a backing file store
	 */
	public NonblockingRemoveCacheEntry(Uid uid, String transactionName, int fileType) {
		super(uid, transactionName, null, fileType);
	}

	@Override
	public CacheAction getCacheAction() {
		return CacheAction.REMOVE;
	}
}
