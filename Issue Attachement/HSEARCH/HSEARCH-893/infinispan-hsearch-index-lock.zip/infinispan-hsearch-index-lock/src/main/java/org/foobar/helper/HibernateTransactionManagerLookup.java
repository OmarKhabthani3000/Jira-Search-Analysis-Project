/**
 * Copyright (c) 2010 Attensa, Inc. All rights reserved. 
 */
package org.foobar.helper;

import java.util.Properties;

import javax.transaction.Transaction;
import javax.transaction.TransactionManager;

import org.hibernate.HibernateException;
import org.hibernate.transaction.JNDITransactionManagerLookup;
import org.hibernate.transaction.TransactionManagerLookup;

/**
 * @author tom
 *
 */
public class HibernateTransactionManagerLookup implements TransactionManagerLookup {

	/**
	 * Assumes that the JBoss transaction manager is named 'jbossTransactionManager' in Spring
	 */
	@Override
	public TransactionManager getTransactionManager(Properties props) throws HibernateException {
		return (TransactionManager) ApplicationContextProxy.getBean("javaTransactionManager");
	}

	/**
	 * See {@link org.hibernate.transaction.JBossTransactionManagerLookup#getUserTransactionName()}
	 */
	@Override
	public String getUserTransactionName() {
		return "java:comp/UserTransaction ";
	}

	/**
	 * See {@link JNDITransactionManagerLookup#getTransactionIdentifier(Transaction)}
	 */
	@Override
	public Object getTransactionIdentifier(Transaction transaction) {
		return transaction;
	}

}
