package org.foobar;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class CatalogDAO {
	@PersistenceContext
	private EntityManager entityManager;

	public Catalog find(Long catalogId) {
		return entityManager.find(Catalog.class, catalogId);
	}
	
	@Transactional
	public void persist(Catalog catalog) {
		entityManager.persist(catalog);
	}

	@Transactional
	public Catalog merge(Catalog catalog) {
		return entityManager.merge(catalog);
	}

	@Transactional
	public void remove(Catalog catalog) {
		entityManager.remove(catalog);
	}
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void evictEntity(Catalog catalog) {
		Session session = entityManager.unwrap(Session.class);
		session.evict(catalog);
	}
	
	public void evictCollection(Long catalogId, String collectionName) {
		Session session = entityManager.unwrap(Session.class);
		session.getSessionFactory().getCache().evictCollection(String.format("%s.%s", Catalog.class.getName(), collectionName), catalogId);
	}
}
