package org.foobar.helper;

import com.arjuna.ats.arjuna.common.Uid;
import com.arjuna.ats.arjuna.state.OutputObjectState;

/**
 * Entry for the transaction cache store
 */
public abstract class NonblockingCacheEntry {
	public enum CacheAction { WRITE, REMOVE, COMMIT };
	
	private Uid uid_;
	
	private String transactionName_;
	
	private OutputObjectState objectState_;
	
	private int fileType_;
	
	public NonblockingCacheEntry(Uid uid, String transactionName, OutputObjectState objectState, int fileType) {
		uid_ = uid;
		transactionName_ = transactionName;
		objectState_ = objectState;
		fileType_ = fileType;
	}

	/**
	 * Defines what type of cache entry this is:
	 * * a WRITE of transaction state
	 * * a REMOVE of transaction state
	 * * a COMMIT of transaction state
	 */
	public abstract CacheAction getCacheAction();
	
	/**
	 * @return the uid
	 */
	public Uid getUid() {
		return uid_;
	}

	/**
	 * @return the transactionName
	 */
	public String getTransactionName() {
		return transactionName_;
	}

	/**
	 * @return the objectState
	 */
	public OutputObjectState getObjectState() {
		return objectState_;
	}

	/**
	 * @return the fileType
	 */
	public int getFileType() {
		return fileType_;
	}
	
	/**
	 * Entries are equal if
	 * - uid is equal
	 * - transactionName is equal
	 * - cacheAction is equal
	 */
	@Override
	public boolean equals(Object object) {
		if (super.equals(object)) {
			return true;
		}
		
		if (object == null || ! object.getClass().equals(getClass())) {
			return false;
		}
		
		NonblockingCacheEntry cacheEntry = (NonblockingCacheEntry) object;
		
		return (uid_ != null && cacheEntry.uid_ != null && uid_.equals(cacheEntry.uid_)
				&& (transactionName_ != null && cacheEntry.transactionName_ != null && transactionName_.equals(cacheEntry.transactionName_))
				&& getCacheAction().equals(cacheEntry.getCacheAction()));
	}
	
	/**
	 * Uid is sufficient for hashcode
	 */
	@Override
	public int hashCode() {
		return uid_.hashCode();
	}
	
	@Override
	public String toString() {
		return String.format("%s[%s]", getClass().getSimpleName(), uid_);
	}
}
