package org.foobar.helper;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * @author tom
 *
 */
@Component("ApplicationContextProxy")
public class ApplicationContextProxy implements ApplicationContextAware {
	
	private static ApplicationContext applicationContext_;

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		applicationContext_ = applicationContext;
	}
	
	public static Object getBean(String name) {
		return applicationContext_.getBean(name);
	}
}
