/**
 * Copyright (c) 2010 Attensa, Inc. All rights reserved. 
 */
package org.foobar.helper;

import javax.transaction.TransactionManager;

import org.infinispan.transaction.lookup.TransactionManagerLookup;

/**
 * @author tom
 *
 */
public class InfinispanTransactionManagerLookup implements TransactionManagerLookup {

	@Override
	public TransactionManager getTransactionManager() throws Exception {
		return (TransactionManager) ApplicationContextProxy.getBean("javaTransactionManager");
	}

}
