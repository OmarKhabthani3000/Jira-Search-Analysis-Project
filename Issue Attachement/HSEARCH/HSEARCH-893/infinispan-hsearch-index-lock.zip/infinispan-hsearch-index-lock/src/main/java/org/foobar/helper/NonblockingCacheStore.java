package org.foobar.helper;

import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;

import org.apache.log4j.Logger;
import org.foobar.helper.NonblockingCacheEntry.CacheAction;

import com.arjuna.ats.arjuna.common.ObjectStoreEnvironmentBean;
import com.arjuna.ats.arjuna.common.Uid;
import com.arjuna.ats.arjuna.exceptions.ObjectStoreException;
import com.arjuna.ats.arjuna.state.InputObjectState;
import com.arjuna.ats.arjuna.state.OutputObjectState;
import com.arjuna.ats.internal.arjuna.objectstore.CacheStore;
import com.arjuna.ats.internal.arjuna.objectstore.HashedStore;
import com.arjuna.ats.internal.arjuna.objectstore.VolatileStore;

/**
 * Replacement for {@link CacheStore}, based upon {@link VolatileStore}.  
 * 
 * Meant to allow for in-memory caching of JBoss JTA transaction state without
 * memory limitations.
 *
 */
public class NonblockingCacheStore extends HashedStore implements Runnable {

    /**
     * Map of transaction Uid to transaction state, {@link NonblockingCacheEntry}. Entries are stored in the cache only 
     * until written to the file store.
     */
    private ConcurrentMap<Uid, NonblockingCacheEntry> cacheEntryMap_ = new ConcurrentHashMap<Uid, NonblockingCacheEntry>();
    
    /**
     * Queue used to track the order of cache operations. Periodically this queue is iterated over, 
     * each entry written to the file store.
     */
    private Queue<NonblockingCacheEntry> cacheEntryQueue_ = new ConcurrentLinkedQueue<NonblockingCacheEntry>();
    
	/**
	 * @param objectStoreEnvironmentBean
	 * @throws ObjectStoreException
	 */
	public NonblockingCacheStore(ObjectStoreEnvironmentBean objectStoreEnvironmentBean) throws ObjectStoreException {
		super(objectStoreEnvironmentBean);

		// start the worker thread
		Thread thread = new Thread(this);
		thread.setDaemon(true);
		thread.start();
	}
	
	private Logger getLogger() {
		return Logger.getLogger(getClass());
	}

    /**
     * Commit the object's state in the object store.
     *
     * @param u The object to work on.
     * @param transactionType The type of the object to work on.
     *
     * @return <code>true</code> if no errors occurred, <code>false</code>
     * otherwise.
     */

    public boolean commit_state(Uid uid, String transactionType) throws ObjectStoreException {
    	if (getLogger().isDebugEnabled()) {
    		getLogger().debug(String.format("commit_state(%s,%s)", uid, transactionType));
    	}
    	
    	NonblockingCacheEntry cacheEntry = new NonblockingCommitCacheEntry(uid, transactionType);
    	cacheEntryQueue_.add(cacheEntry);
    	cacheEntryMap_.put(uid, cacheEntry);

    	return true;
    }

    /**
     * Before we look at the disk let's look in the state cache first for the
     * state, just in case it hasn't been written out to persistent store yet.
     */
    protected InputObjectState read_state(Uid uid, String transactionType, int fileType) throws ObjectStoreException {
    	if (getLogger().isDebugEnabled()) {
    		getLogger().debug(String.format("read_state(%s,%s,%d)", uid, transactionType, fileType));
    	}

    	NonblockingCacheEntry cacheEntry = cacheEntryMap_.get(uid);

    	// if not in the cache then fall back to the disk store
        if (cacheEntry == null) {
        	if (getLogger().isDebugEnabled()) {
        		getLogger().debug(String.format("read_state(%s,%s,%d) - state not found in cache, reading from file store", uid, transactionType, fileType));
        	}
        	
            return super.read_state(uid, transactionType, fileType);
        } else {
        	if (getLogger().isDebugEnabled()) {
        		getLogger().debug(String.format("read_state(%s,%s,%d) - state found in cache", uid, transactionType, fileType));
        	}
        	
        	OutputObjectState objectState = cacheEntry.getObjectState();
        	
        	if (objectState != null) {
        		return new InputObjectState(objectState);
        	} else {
        		return null;
        	}
        }
    }
    
    /**
     * Remove any item in the cache that operates on this state (must be
     * identical uid and file type (shadowed, hidden etc.) This could
     * potentially leave us with states on disk that should have been deleted
     * but weren't because a crash happened before we could do that. Crash
     * recovery should fix this up later though.
     */
    protected boolean remove_state(Uid uid, String transactionType, int fileType) throws ObjectStoreException {
    	if (getLogger().isDebugEnabled()) {
    		getLogger().debug(String.format("remove_state(%s,%s,%d)", uid, transactionType, fileType));
    	}

    	NonblockingCacheEntry cacheEntry = new NonblockingRemoveCacheEntry(uid, transactionType, fileType);
    	cacheEntryQueue_.add(cacheEntry);
    	cacheEntryMap_.put(uid, cacheEntry);

    	return true;
    }
    
    /**
     * If there is already a write operation in the cache for exactly this
     * state and type, then remove it and any corresponding remove_state
     * there might be. This is because write_state overwrites the state
     * rather than appending some operational work. If we used an appender
     * log then obviously this isn't appropriate.
     */
    protected boolean write_state(Uid uid, String transactionType, OutputObjectState state, int fileType) throws ObjectStoreException {
    	if (getLogger().isDebugEnabled()) {
    		getLogger().debug(String.format("write_state(%s,%s,%d) - %d bytes", uid, transactionType, fileType, state.length()));
    	}

    	NonblockingCacheEntry cacheEntry = new NonblockingWriteCacheEntry(uid, transactionType, state, fileType);
    	cacheEntryQueue_.add(cacheEntry);
    	cacheEntryMap_.put(uid, cacheEntry);
    	
    	return true;
    } 
    
    /**
     * Periodically writes the cache contents to disk, in support of
     * crash recovery
     * 
     */
    @Override
    public void run() {
    	// register shutdown thread, which will write cache contents to disk on normal JVM shutdown
    	Runtime.getRuntime().addShutdownHook(new ShutdownThread());
    	
    	while (true) {
    		try {
				Thread.sleep(60000);

				writeCacheContents();
			} catch (InterruptedException e) {
				// if the thread is interrupted write out the cache contents
				getLogger().warn("AttensaCacheStore worker thread has been interrupted, the cache contents will be written to the file store");
				
				writeCacheContents();
			}
    	}
    }
    
    protected void writeCacheContents() {
    	if (getLogger().isDebugEnabled()) {
    		getLogger().debug("writing cache contents to the file store");
    	}
    	
    	// get the number of elements at this point, write the elements to disk
    	// other elements may be added to the cache after determining the queue size
    	// so only remove this many elements
    	int size = cacheEntryQueue_.size();
    	
    	// this set stores the entries to remove from the map
    	for (int i = 0; i < size; i++) {
    		try {
    			// get the top element out of the queue
	    		NonblockingCacheEntry cacheEntry = cacheEntryQueue_.remove();
	        	if (getLogger().isDebugEnabled()) {
	        		getLogger().debug("writing " + cacheEntry);
	        	}
	        	
	        	Uid uid = cacheEntry.getUid();
	    		// remove the entry from the cache as well
	    		NonblockingCacheEntry mapCacheEntry = cacheEntryMap_.remove(uid);
	    		// double check to see if the entries are the same, if not put the entry
	    		// back into the map (it will be in the queue)
	    		if (! mapCacheEntry.equals(cacheEntry)) {
	    			cacheEntryMap_.put(uid, mapCacheEntry);
	    			
	    			// if the current action is remove then don't bother writing out transaction state
	    			if (mapCacheEntry.getCacheAction().equals(NonblockingCacheEntry.CacheAction.REMOVE)) {
	    				continue;
	    			}
	    		}

	    		if (cacheEntry.getCacheAction().equals(CacheAction.COMMIT)) {
	    			super.commit_state(uid, cacheEntry.getTransactionName());
	    		} else if (cacheEntry.getCacheAction().equals(CacheAction.REMOVE)) {
	    			super.remove_state(uid, cacheEntry.getTransactionName(), cacheEntry.getFileType());
	    		} else if (cacheEntry.getCacheAction().equals(CacheAction.WRITE)) {
	    			super.write_state(uid, cacheEntry.getTransactionName(), cacheEntry.getObjectState(), cacheEntry.getFileType());
	    		}

    		} catch (Exception e) {
    			getLogger().error("A problem occurred while writing cached transaction state to the file store", e);
    		}
    	}
    }
    
    /**
     * On JVM shutdown write out the cache contents to the file store
     * 
     * @author tom
     *
     */
    private class ShutdownThread extends Thread {
    	@Override
    	public void run() {
    		getLogger().info("AttensaCacheStore shutdown thread running");
    		
    		writeCacheContents();
    	}
    }
    
}
