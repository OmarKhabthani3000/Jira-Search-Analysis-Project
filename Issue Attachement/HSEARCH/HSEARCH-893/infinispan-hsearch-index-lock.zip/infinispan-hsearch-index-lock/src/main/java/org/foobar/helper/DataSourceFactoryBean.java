/**
 * Copyright (c) 2011 Attensa, Inc. All rights reserved. 
 */
package org.foobar.helper;

import javax.resource.ResourceException;
import javax.resource.spi.ConnectionManager;
import javax.resource.spi.ConnectionRequestInfo;
import javax.resource.spi.ManagedConnectionFactory;
import javax.sql.DataSource;
import javax.transaction.TransactionManager;

import org.apache.commons.lang.StringUtils;
import org.jboss.logging.Logger;
import org.jboss.resource.adapter.jdbc.local.LocalManagedConnectionFactory;
import org.jboss.resource.adapter.jdbc.local.LocalTxDataSource;
import org.jboss.resource.connectionmanager.CachedConnectionManager;
import org.jboss.resource.connectionmanager.InternalManagedConnectionPool;
import org.jboss.resource.connectionmanager.JBossManagedConnectionPool;
import org.jboss.resource.connectionmanager.TransactionSynchronizer;
import org.jboss.resource.connectionmanager.TxConnectionManager;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;

/**
 * This is an implementation of a JBoss connection connectionPool. It is copied from {@link LocalTxDataSource}. This class needed to be created because {@link LocalTxDataSource} has JNDI calls coded
 * in. We aren't using JNDI.
 * 
 * @author tom
 * 
 */
public class DataSourceFactoryBean implements FactoryBean<DataSource>, InitializingBean {

	protected static Logger log = Logger.getLogger(LocalTxDataSource.class);

	private CachedConnectionManager cachedConnectionManager = new CachedConnectionManager();
	private TransactionManager transactionManager;

	private InternalManagedConnectionPool.PoolParams poolParams = new InternalManagedConnectionPool.PoolParams();
	private LocalManagedConnectionFactory managedConnectionFactory = new LocalManagedConnectionFactory();

	private JBossManagedConnectionPool.OnePool connectionPool = new JBossManagedConnectionPool.OnePool(managedConnectionFactory, poolParams, false, log);
	private TxConnectionManager connectionManager;

	private Object datasource;

	public class ConnectionManagerDelegate implements ConnectionManager {
		private static final long serialVersionUID = 1L;

		public Object allocateConnection(ManagedConnectionFactory mcf, ConnectionRequestInfo cxRequestInfo) throws ResourceException {
			return connectionManager.allocateConnection(mcf, cxRequestInfo);
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		TransactionSynchronizer.setTransactionManager(transactionManager);
		
		connectionManager = new TxConnectionManager(cachedConnectionManager, connectionPool, transactionManager);
		connectionManager.setLocalTransactions(true);
		connectionManager.setInterleaving(false);
		connectionPool.setConnectionListenerFactory(connectionManager);
		
		datasource = connectionManager.getPoolingStrategy().getManagedConnectionFactory().createConnectionFactory(new ConnectionManagerDelegate());
	}

	@Override
	public DataSource getObject() throws Exception {
		return (DataSource) datasource;
	}

	@Override
	public Class<?> getObjectType() {
		return DataSource.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}

	public TransactionManager getTransactionManager() {
		return transactionManager;
	}

	public void setTransactionManager(TransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

	public int getMinSize() {
		return poolParams.minSize;
	}

	public void setMinSize(int minSize) {
		poolParams.minSize = minSize;
	}

	public int getMaxSize() {
		return poolParams.maxSize;
	}

	public void setMaxSize(int maxSize) {
		poolParams.maxSize = maxSize;
	}

	public int getBlockingTimeout() {
		return poolParams.blockingTimeout;
	}

	public void setBlockingTimeout(int blockingTimeout) {
		poolParams.blockingTimeout = blockingTimeout;
	}

	public long getIdleTimeout() {
		return poolParams.idleTimeout;
	}

	public void setIdleTimeout(long idleTimeout) {
		poolParams.idleTimeout = idleTimeout;
	}

	public String getDriverClass() {
		return managedConnectionFactory.getDriverClass();
	}

	public void setDriverClass(final String driverClass) {
		managedConnectionFactory.setDriverClass(driverClass);
	}

	public String getConnectionURL() {
		return managedConnectionFactory.getConnectionURL();
	}

	public void setConnectionURL(final String connectionURL) {
		managedConnectionFactory.setConnectionURL(connectionURL);
	}

	public void setUserName(final String userName) {
		managedConnectionFactory.setUserName(userName);
	}

	public void setPassword(final String password) {
		managedConnectionFactory.setPassword(password);
	}

	public void setPreparedStatementCacheSize(int size) {
		managedConnectionFactory.setPreparedStatementCacheSize(size);
	}

	public int getPreparedStatementCacheSize() {
		return managedConnectionFactory.getPreparedStatementCacheSize();
	}

	public boolean getSharePreparedStatements() {
		return managedConnectionFactory.getSharePreparedStatements();
	}

	public void setSharePreparedStatements(boolean sharePS) {
		managedConnectionFactory.setSharePreparedStatements(sharePS);
	}

	public boolean getTxQueryTimeout() {
		return managedConnectionFactory.isTransactionQueryTimeout();
	}

	public void setTxQueryTimeout(boolean qt) {
		managedConnectionFactory.setTransactionQueryTimeout(qt);
	}

	public String getTransactionIsolation() {
		return managedConnectionFactory.getTransactionIsolation();
	}

	public void setTransactionIsolation(String transactionIsolation) {
		managedConnectionFactory.setTransactionIsolation(transactionIsolation);
	}

	public String getNewConnectionSQL() {
		return managedConnectionFactory.getNewConnectionSQL();
	}

	public void setNewConnectionSQL(String newConnectionSQL) {
		managedConnectionFactory.setNewConnectionSQL(newConnectionSQL);
	}

	public String getCheckValidConnectionSQL() {
		return managedConnectionFactory.getCheckValidConnectionSQL();
	}

	public void setCheckValidConnectionSQL(String checkValidConnectionSQL) {
		managedConnectionFactory.setCheckValidConnectionSQL(checkValidConnectionSQL);
	}

	public String getTrackStatements() {
		return managedConnectionFactory.getTrackStatements();
	}

	public void setTrackStatements(String value) {
		managedConnectionFactory.setTrackStatements(value);
	}

	public String getExceptionSorterClassName() {
		return managedConnectionFactory.getExceptionSorterClassName();
	}

	/**
	 * Will set value in underlying connection factory if not empty
	 * 
	 * @param exceptionSorterClassName
	 */
	public void setExceptionSorterClassName(String exceptionSorterClassName) {
		if (! StringUtils.isEmpty(exceptionSorterClassName)) {
			managedConnectionFactory.setExceptionSorterClassName(exceptionSorterClassName);
		}
	}

	public String getValidConnectionCheckerClassName() {
		return managedConnectionFactory.getValidConnectionCheckerClassName();
	}

	/**
	 * Will set value in underlying connection factory if not empty
	 * 
	 * org.jboss.resource.adapter.jdbc.vendor.MySQLValidConnectionChecker com.mysql.jdbc.integration.jboss.MysqlValidConnectionChecker
	 * org.jboss.resource.adapter.jdbc.vendor.OracleValidConnectionChecker
	 * 
	 * @param value
	 */
	public void setValidConnectionCheckerClassName(String value) {
		if (! StringUtils.isEmpty(value)) {
			managedConnectionFactory.setValidConnectionCheckerClassName(value);
		}
	}
}
