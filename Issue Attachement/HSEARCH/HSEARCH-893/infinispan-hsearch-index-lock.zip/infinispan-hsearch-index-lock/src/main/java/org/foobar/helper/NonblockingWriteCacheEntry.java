package org.foobar.helper;

import com.arjuna.ats.arjuna.common.Uid;
import com.arjuna.ats.arjuna.state.OutputObjectState;

public class NonblockingWriteCacheEntry extends NonblockingCacheEntry {

	/**
	 * @param uid transaction identifier
	 * @param transactionName type name of the transaction 
	 * @param objectState the state of the transaction
	 * @param fileType the file type when written to a backing file store
	 */
	public NonblockingWriteCacheEntry(Uid uid, String transactionName, OutputObjectState objectState, int fileType) {
		super(uid, transactionName, objectState, fileType);
	}

	@Override
	public CacheAction getCacheAction() {
		return CacheAction.WRITE;
	}
}
