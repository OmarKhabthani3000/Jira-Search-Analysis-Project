package hibernate.search;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Child {

	@Id
	private final int id;

	private String text;

	public Child(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
