package hibernate.search;

import static javax.persistence.CascadeType.ALL;
import static javax.persistence.FetchType.EAGER;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Root {

	@Id
	private final int id;

	@OneToMany(cascade = ALL, orphanRemoval = true, fetch = EAGER)
	private List<Child> children;

	public Root(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public List<Child> getChildren() {
		return children;
	}

	public void setChildren(List<Child> children) {
		this.children = children;
	}
}
