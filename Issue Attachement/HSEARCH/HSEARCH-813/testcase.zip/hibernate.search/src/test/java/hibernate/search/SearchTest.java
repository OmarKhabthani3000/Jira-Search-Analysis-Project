package hibernate.search;

import static java.lang.annotation.ElementType.METHOD;
import static org.apache.lucene.util.Version.LUCENE_31;
import static org.hibernate.search.Environment.MODEL_MAPPING;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.cfg.SearchMapping;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class SearchTest {

	protected Session testSession;

	@Before
	public void setUp() throws Exception {
		Configuration cfg = new Configuration();
		cfg.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
		cfg.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:demo");
		cfg.setProperty("hibernate.connection.username", "sa");
		cfg.setProperty("hibernate.connection.password", "");
		cfg.setProperty("hibernate.hbm2ddl.auto", "update");
		cfg.addAnnotatedClass(Root.class);
		cfg.addAnnotatedClass(Child.class);
		SearchMapping mapping = new SearchMapping();
		mapping.entity(Root.class).indexed().property("children", METHOD).indexEmbedded()
				.property("text", METHOD).field();
		cfg.getProperties().put(MODEL_MAPPING, mapping);
		testSession = cfg.buildSessionFactory().openSession();
		populateDb();
	}

	@After
	public void tearDown() throws Exception {
		emptyDb();
		testSession.close();
	}

	private void populateDb() {
		Transaction tx = testSession.beginTransaction();
		Child child = new Child(0);
		child.setText("test");
		Root root = new Root(1);
		root.setChildren(Arrays.asList(child));
		testSession.persist(root);
		tx.commit();
	}

	@SuppressWarnings("unchecked")
	private void emptyDb() {
		Transaction tx = testSession.beginTransaction();
		Criteria crit = testSession.createCriteria(Root.class);
		List<Root> docList = crit.list();
		for (Root doc : docList) {
			testSession.delete(doc);
		}
		tx.commit();
	}

	@SuppressWarnings("unchecked")
	private List<Root> searchDocuments(String query) {
		FullTextSession searchSession = Search.getFullTextSession(testSession);
		Transaction tx = searchSession.beginTransaction();
		QueryParser parser = new QueryParser(LUCENE_31, "id", new StandardAnalyzer(LUCENE_31));
		List<Root> result = new ArrayList<Root>();
		try {
			org.apache.lucene.search.Query luceneQuery = parser.parse(query);
			FullTextQuery hibernateQuery = searchSession.createFullTextQuery(luceneQuery,
					Root.class);
			result = hibernateQuery.list();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tx.commit();
		return result;
	}

	@Test
	public void testSearch() {
		// String queryString = "children.id:0";
		String queryString = "children.text:test";
		List<Root> results = searchDocuments(queryString);
		Assert.assertEquals(1, results.size());
		Assert.assertEquals("test", results.get(0).getChildren().get(0).getText());
	}
}
