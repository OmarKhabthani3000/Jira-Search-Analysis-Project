/**
 * Copyright (c) 2011 Attensa, Inc. All rights reserved. 
 */
package org.hibernate.search.event;

import org.hibernate.Transaction;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.backend.Worker;
import org.hibernate.search.engine.SearchFactoryImplementor;
import org.hibernate.search.test.SearchTestCase;
import org.mockito.Mockito;

/**
 * HSEARCH-679 - verify that updates to collections that are not indexed do not trigger indexing.
 * 
 * @author tom
 *
 */
public class CollectionUpdateEventTest extends SearchTestCase {

	public void test() {
		FullTextSession fullTextSession = Search.getFullTextSession( openSession() );
		Catalog catalog = initializeData(fullTextSession);
		try {
			updateCollection(fullTextSession, catalog);
			
			SearchFactoryImplementor searchFactoryImplementor = mockSearchFactoryImplementor();
			FullTextIndexEventListener eventListener = getLuceneEventListener();
			eventListener.searchFactoryImplementor = searchFactoryImplementor;

			Mockito.verifyZeroInteractions(searchFactoryImplementor.getWorker());
		} finally {
			fullTextSession.close();
		}
	}
	
	private SearchFactoryImplementor mockSearchFactoryImplementor() {
		Worker worker = Mockito.mock(Worker.class);
		
		SearchFactoryImplementor searchFactoryImplementor = Mockito.mock(SearchFactoryImplementor.class);
		Mockito.when(searchFactoryImplementor.getWorker()).thenReturn(worker);
		
		return searchFactoryImplementor;
	}
	/**
	 * Initialize the test data.
	 */
	private Catalog initializeData(FullTextSession fullTextSession) {
		final Transaction transaction = fullTextSession.beginTransaction();

		Catalog catalog = new Catalog();
		catalog.setName("parts");
		fullTextSession.persist(catalog);
		
		for (int i = 0; i < 25; i++) {
			Item item = new Item();
			item.setName("battery");
			fullTextSession.persist(item);
			
			CatalogItem catalogItem = new CatalogItem();
			catalogItem.setCatalog(catalog);
			catalogItem.setItem(item);
			fullTextSession.persist(catalogItem);
			
			item.getCatalogItems().add(catalogItem);
			fullTextSession.merge(item);
			
			catalog.getCatalogItems().add(catalogItem);
			fullTextSession.merge(catalog);
		}

		transaction.commit();
		
		return catalog;
	}
	
	/**
	 * Update a non-indexed collection of an entity contained in a collection. No indexing work should be created.
	 */
	private void updateCollection(FullTextSession fullTextSession, Catalog catalog) {
		final Transaction transaction = fullTextSession.beginTransaction();

		Consumer consumer = new Consumer();
		consumer.setName("consumer");
		consumer.getCatalogs().add(catalog);
		fullTextSession.persist(consumer);

		catalog.getConsumers().add(consumer);
		fullTextSession.merge(catalog);

		transaction.commit();
	}
	
	@Override
	protected Class<?>[] getAnnotatedClasses() {
		return new Class[] { Catalog.class, CatalogItem.class, Consumer.class, Item.class };
	}
}
