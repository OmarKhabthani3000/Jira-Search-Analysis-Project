package org.hibernate.search.event;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.hibernate.annotations.Proxy;
import org.hibernate.search.annotations.Analyzer;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
@Proxy(lazy = false)
@Table(name="item")

@Indexed(index="item")
@Analyzer(impl = StandardAnalyzer.class)
public class Item {
	@Id()
	@GeneratedValue(strategy = GenerationType.AUTO)
	@DocumentId
	private Long itemId;

	@OneToMany(mappedBy="item", cascade={ CascadeType.REMOVE, CascadeType.REFRESH }, fetch=FetchType.LAZY)
	@IndexedEmbedded()
	private Set<CatalogItem> catalogItems = new HashSet<CatalogItem>();
	
	@Column(length = 255)
	private String name;

	@Column(length = 255)
	private String color;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the kind
	 */
	public String getColor() {
		return color;
	}

	/**
	 * @param kind the kind to set
	 */
	public void setColor(String kind) {
		this.color = kind;
	}
	
	/**
	 * @return the eggId
	 */
	public Long getItemId() {
		return itemId;
	}

	/**
	 * @param itemId the eggId to set
	 */
	public void setItemId(Long doughnutId) {
		this.itemId = doughnutId;
	}

	/**
	 * @return the catalogItems
	 */
	public Set<CatalogItem> getCatalogItems() {
		return catalogItems;
	}

	/**
	 * @param catalogItems the catalogItems to set
	 */
	public void setCatalogItems(Set<CatalogItem> catalogItems) {
		this.catalogItems = catalogItems;
	}


}
