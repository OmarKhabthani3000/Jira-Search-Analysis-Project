package org.foobar;

import java.util.Random;

import javax.inject.Inject;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath*:beans.xml"}) 
@TransactionConfiguration(defaultRollback=false)
public class CatalogItemTest {
	@Inject
	private CatalogDAO catalogDAO;
	
	@Inject
	private ItemDAO itemDAO;

	@Inject
	private CatalogItemDAO catalogItemDAO;

	@Inject
	private EntityController consumerController;
	
	private Catalog catalog;
	
	@Before
	public void createTestData() {
		catalog = new Catalog();
		catalog.setName("parts");
		catalogDAO.persist(catalog);
		
		for (int i = 0; i < 25; i++) {
			Item item = new Item();
			item.setName("battery");
			itemDAO.persist(item);
			
			CatalogItem catalogItem = new CatalogItem();
			catalogItem.setCatalog(catalog);
			catalogItem.setItem(item);
			catalogItemDAO.persist(catalogItem);
			
			item.getCatalogItems().add(catalogItem);
			itemDAO.merge(item);
			
			catalog.getCatalogItems().add(catalogItem);
			catalogDAO.merge(catalog);
		}
	}
	
	/**
	 * This causes a load of all related entities
	 */
	@Test
	public void testEntityCollectionUpdate() throws Exception {
		Logger.getLogger("org.hibernate.SQL").setLevel(Level.DEBUG);
		consumerController.addConsumer(catalog.getCatalogId());
		Logger.getLogger("org.hibernate.SQL").setLevel(Level.WARN);
	}

	/**
	 * This works as expected - only the entity is updated, no load of related entities for indexing
	 * @throws Exception
	 */
	@Test
	public void testFieldUpdate() throws Exception {
		Logger.getLogger("org.hibernate.SQL").setLevel(Level.DEBUG);
		consumerController.renameCatalog(catalog.getCatalogId(), "catalog" + new Random().nextInt());
		Logger.getLogger("org.hibernate.SQL").setLevel(Level.WARN);
	}
}
