package org.foobar;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class CatalogItemDAO {
	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public void persist(CatalogItem catalogItem) {
		entityManager.persist(catalogItem);
	}

	@Transactional
	public CatalogItem merge(CatalogItem catalogItem) {
		return entityManager.merge(catalogItem);
	}

	@Transactional
	public void remove(CatalogItem catalogItem) {
		entityManager.remove(catalogItem);
	}
}
