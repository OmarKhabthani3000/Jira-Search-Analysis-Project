package org.foobar;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class ConsumerDAO {
	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public void persist(Consumer consumer) {
		entityManager.persist(consumer);
	}

	@Transactional
	public Consumer merge(Consumer consumer) {
		return entityManager.merge(consumer);
	}

	@Transactional
	public void remove(Consumer consumer) {
		entityManager.remove(consumer);
	}
	
	public EntityManager getEntityManager() {
		return entityManager;
	}
}
