package org.foobar;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class ItemDAO {
	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public void persist(Item item) {
		entityManager.persist(item);
	}

	@Transactional
	public Item merge(Item item) {
		return entityManager.merge(item);
	}

	@Transactional
	public void remove(Item item) {
		entityManager.remove(item);
	}
}
