package org.foobar;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Used for transaction/session support
 * 
 */
@Component
public class EntityController {
	private Logger logger = Logger.getLogger(getClass());

	@Inject
	private CatalogDAO catalogDAO;
	
	@Inject
	private ConsumerDAO consumerDAO;

	@Transactional
	public void addConsumer(Long catalogId) {
		Catalog catalog = catalogDAO.find(catalogId);
		
		Consumer consumer = new Consumer();
		consumer.setName("consumer");
		consumer.getCatalogs().add(catalog);
		consumerDAO.persist(consumer);

		logger.debug("UPDATING NON-INDEXED ENTITY COLLECTION");			
		catalog.getConsumers().add(consumer);
		catalogDAO.merge(catalog);
	}
	
	@Transactional
	public void renameCatalog(Long catalogId, String name) {
		Catalog catalog = catalogDAO.find(catalogId);
		
		catalog.setName(name);

		logger.debug("UPDATING NON-INDEXED FIELD");			
		catalogDAO.merge(catalog);
	}
}
