package org.foobar;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class CatalogDAO {
	@PersistenceContext
	private EntityManager entityManager;

	public Catalog find(Long catalogId) {
		return entityManager.find(Catalog.class, catalogId);
	}
	
	@Transactional
	public void persist(Catalog catalog) {
		entityManager.persist(catalog);
	}

	@Transactional
	public Catalog merge(Catalog catalog) {
		return entityManager.merge(catalog);
	}

	@Transactional
	public void remove(Catalog catalog) {
		entityManager.remove(catalog);
	}
	
	public EntityManager getEntityManager() {
		return entityManager;
	}
}
