package org.hibernate.search.test.event;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Proxy;
import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Store;

@Entity
@Proxy(lazy = false)
@Table(name="catalog")
public class Catalog {
	
	@Id()
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Field(index = org.hibernate.search.annotations.Index.UN_TOKENIZED, store = Store.NO)
	private Long catalogId;

	@Column(length = 255)
	private String name;
	
	@OneToMany(mappedBy="catalog", cascade={ CascadeType.REMOVE, CascadeType.REFRESH }, fetch=FetchType.LAZY)
	@ContainedIn
	private Set<CatalogItem> catalogItems = new HashSet<CatalogItem>();

	@ManyToMany(fetch=FetchType.LAZY, mappedBy="catalogs", cascade={CascadeType.PERSIST})
	private List<Consumer> consumers = new ArrayList<Consumer>();

	public Catalog() {
	}

	/**
	 * @return the cartonId
	 */
	public Long getCatalogId() {
		return catalogId;
	}

	/**
	 * @param catalogId the cartonId to set
	 */
	public void setCatalogId(Long catalogId) {
		this.catalogId = catalogId;
	}

	public String getName() {
		return name;
	}

	/**
	 * @param color the color to set
	 */
	public void setName(String color) {
		this.name = color;
	}

	/**
	 * @return the catalogItems
	 */
	public Set<CatalogItem> getCatalogItems() {
		return catalogItems;
	}

	/**
	 * @param catalogItems the catalogItems to set
	 */
	public void setCatalogItems(Set<CatalogItem> catalogItems) {
		this.catalogItems = catalogItems;
	}

	/**
	 * @return the consumers
	 */
	public List<Consumer> getConsumers() {
		return consumers;
	}

	/**
	 * @param consumers the consumers to set
	 */
	public void setConsumers(List<Consumer> consumers) {
		this.consumers = consumers;
	}

}
