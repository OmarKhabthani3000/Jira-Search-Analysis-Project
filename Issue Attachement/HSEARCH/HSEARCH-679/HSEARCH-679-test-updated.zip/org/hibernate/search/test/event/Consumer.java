package org.hibernate.search.test.event;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Proxy;

@Entity
@Proxy(lazy = false)
@Table(name="consumer")
public class Consumer {
	@Id()
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long consumerId;

	@Column(length = 255)
	private String name;
	
	@ManyToMany(cascade={ CascadeType.MERGE, CascadeType.REFRESH, CascadeType.PERSIST}, fetch=FetchType.LAZY)
	@JoinTable( 
        name="consumer_catalog",
        joinColumns=@JoinColumn(name="consumerId"),
        inverseJoinColumns=@JoinColumn(name="catalogId")
    )
	private List<Catalog> catalogs = new ArrayList<Catalog>();

	/**
	 * @return the consumerId
	 */
	public Long getConsumerId() {
		return consumerId;
	}

	/**
	 * @param consumerId the consumerId to set
	 */
	public void setConsumerId(Long consumerId) {
		this.consumerId = consumerId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the catalogs
	 */
	public List<Catalog> getCatalogs() {
		return catalogs;
	}

	/**
	 * @param catalogs the catalogs to set
	 */
	public void setCatalogs(List<Catalog> catalogs) {
		this.catalogs = catalogs;
	}
}
