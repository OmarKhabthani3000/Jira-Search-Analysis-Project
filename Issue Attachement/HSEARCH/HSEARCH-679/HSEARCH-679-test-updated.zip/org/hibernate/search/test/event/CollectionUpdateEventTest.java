package org.hibernate.search.test.event;

import java.io.Serializable;

import org.hibernate.Transaction;
import org.hibernate.event.EventListeners;
import org.hibernate.impl.SessionFactoryImpl;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.backend.Worker;
import org.hibernate.search.engine.SearchFactoryImplementor;
import org.hibernate.search.event.FullTextIndexEventListener;
import org.hibernate.search.test.SearchTestCase;
import org.mockito.Mockito;

/**
 * HSEARCH-679 - verify that updates to collections that are not indexed do not trigger indexing.
 * 
 * @author tom
 *
 */
public class CollectionUpdateEventTest extends SearchTestCase {

	/**
	 * Allows access to SearchFactoryImplementor
	 */
	TestFullTextIndexEventListener eventListener = new TestFullTextIndexEventListener();

	/**
	 * Used for testing indexed operations
	 */
	private CatalogItem testCatalogItem;
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		
		eventListener.initialize(getCfg());
		
		replaceLuceneEventListener();
	}
	
	/**
	 * There should be no index work done in this test
	 */
	public void test() {
		FullTextSession fullTextSession = Search.getFullTextSession( openSession() );
		Catalog catalog = initializeData(fullTextSession);
		try {
			SearchFactoryImplementor searchFactoryImplementor = updateCollection(fullTextSession, catalog);
			
			Mockito.verifyZeroInteractions(searchFactoryImplementor.getWorker());
		} finally {
			fullTextSession.close();
		}
	}
	
	/**
	 * There should have been indexing work done with this test
	 */
	public void testIndexed() {
		FullTextSession fullTextSession = Search.getFullTextSession( openSession() );
		Catalog catalog = initializeData(fullTextSession);
		try {
			SearchFactoryImplementor searchFactoryImplementor = updateIndexedCollection(fullTextSession, catalog);
			
			Mockito.verify(searchFactoryImplementor.getWorker(), Mockito.atLeastOnce());
		} finally {
			fullTextSession.close();
		}
	}
	
	private SearchFactoryImplementor mockSearchFactoryImplementor(SearchFactoryImplementor searchFactoryImplementor) {
		Worker worker = Mockito.mock(Worker.class);
		
		SearchFactoryImplementor spySearchFactoryImplementor = Mockito.spy(searchFactoryImplementor);
		Mockito.when(spySearchFactoryImplementor.getWorker()).thenReturn(worker);
		
		return spySearchFactoryImplementor;
	}
	/**
	 * Initialize the test data.
	 */
	private Catalog initializeData(FullTextSession fullTextSession) {
		final Transaction transaction = fullTextSession.beginTransaction();

		Catalog catalog = new Catalog();
		catalog.setName("parts");
		fullTextSession.persist(catalog);
		
		for (int i = 0; i < 25; i++) {
			Item item = new Item();
			item.setName("battery");
			fullTextSession.persist(item);
			
			CatalogItem catalogItem = new CatalogItem();
			catalogItem.setCatalog(catalog);
			catalogItem.setItem(item);
			fullTextSession.persist(catalogItem);
				
			item.getCatalogItems().add(catalogItem);
			fullTextSession.merge(item);
			
			// save the first catalogItem for later testing
			if (i > 0) {
				catalog.getCatalogItems().add(catalogItem);
				fullTextSession.merge(catalog);
			} else {
				testCatalogItem = catalogItem;
			}
		}

		transaction.commit();
		
		return catalog;
	}
	
	/**
	 * Update a non-indexed collection of an entity contained in a collection. No indexing work should be created.
	 */
	private SearchFactoryImplementor updateCollection(FullTextSession fullTextSession, Catalog catalog) {
		final Transaction transaction = fullTextSession.beginTransaction();
		
		// create a spy on the object, only mocking getWorker()
		SearchFactoryImplementor searchFactoryImplementor = mockSearchFactoryImplementor(eventListener.getSearchFactoryImplementor());
		eventListener.setSearchFactoryImplementor(searchFactoryImplementor);

		Consumer consumer = new Consumer();
		consumer.setName("consumer");
		consumer.getCatalogs().add(catalog);
		fullTextSession.persist(consumer);

		catalog.getConsumers().add(consumer);
		fullTextSession.merge(catalog);

		transaction.commit();
		
		return searchFactoryImplementor;
	}
	
	/**
	 * Update an indexed collection of an entity contained in a collection. No indexing work should be created.
	 */
	private SearchFactoryImplementor updateIndexedCollection(FullTextSession fullTextSession, Catalog catalog) {
		final Transaction transaction = fullTextSession.beginTransaction();

		// create a spy on the object, only mocking getWorker()
		SearchFactoryImplementor searchFactoryImplementor = mockSearchFactoryImplementor(eventListener.getSearchFactoryImplementor());
		eventListener.setSearchFactoryImplementor(searchFactoryImplementor);

		catalog.getCatalogItems().add(testCatalogItem);
		fullTextSession.merge(catalog);

		transaction.commit();
		
		return searchFactoryImplementor;
	}
	
	/**
	 * Replace the standard event listener with the test event listener for the sake of 
	 * allowing assignment of the SearchFactoryImplementor instance
	 */
	protected void replaceLuceneEventListener() {
		SessionFactoryImpl sessionFactoryImpl = ((SessionFactoryImpl) getSessions());
		
		EventListeners eventListeners = sessionFactoryImpl.getEventListeners();
		
		Serializable[][] listenerArray = {eventListeners.getPostInsertEventListeners(),
										  eventListeners.getPostUpdateEventListeners(),
										  eventListeners.getPostDeleteEventListeners(),
										  eventListeners.getPostCollectionRecreateEventListeners(),
										  eventListeners.getPostCollectionRemoveEventListeners(),
										  eventListeners.getPostCollectionUpdateEventListeners(),
										  eventListeners.getFlushEventListeners()};

		for (Serializable[] eventListenerArray : listenerArray) {
			for (int i = 0; i < eventListenerArray.length; i++) {
				if (eventListenerArray[i] instanceof FullTextIndexEventListener) {
					// replace with test listener
					eventListenerArray[i] = eventListener;
				}
			}
		}
	}

	@Override
	protected Class<?>[] getAnnotatedClasses() {
		return new Class[] { Catalog.class, CatalogItem.class, Consumer.class, Item.class };
	}
	
	private class TestFullTextIndexEventListener extends FullTextIndexEventListener {
		public TestFullTextIndexEventListener() {
			super(FullTextIndexEventListener.Installation.SINGLE_INSTANCE);
		}
		
		public void setSearchFactoryImplementor(SearchFactoryImplementor searchFactoryImplementor) {
			this.searchFactoryImplementor = searchFactoryImplementor; 
		}
	}
}
