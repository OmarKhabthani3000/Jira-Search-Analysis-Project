package org.hibernate.search.test.event;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;
import org.hibernate.annotations.NaturalId;
import org.hibernate.annotations.Proxy;
import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
@Proxy(lazy = false)

@Table(name="catalog_item")
public class CatalogItem {

	public CatalogItem() {
	}

	@Id()
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long catalogItemId;

	@ManyToOne(fetch=FetchType.LAZY, targetEntity=Item.class)
	@JoinColumn(name = "itemId")
	@LazyToOne(LazyToOneOption.PROXY)
	@NaturalId
	@ContainedIn
	private Item item;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "catalogId")
	@NaturalId
	// full text search
	@IndexedEmbedded
	private Catalog catalog;

	/**
	 * @return the catalogItemId
	 */
	public Long getCatalogItemId() {
		return catalogItemId;
	}

	/**
	 * @param catalogItemId the catalogItemId to set
	 */
	public void setCatalogItemId(Long catalogItemId) {
		this.catalogItemId = catalogItemId;
	}

	/**
	 * @return the item
	 */
	public Item getItem() {
		return item;
	}

	/**
	 * @param item the item to set
	 */
	public void setItem(Item item) {
		this.item = item;
	}

	/**
	 * @return the catalog
	 */
	public Catalog getCatalog() {
		return catalog;
	}

	/**
	 * @param catalog the catalog to set
	 */
	public void setCatalog(Catalog catalog) {
		this.catalog = catalog;
	}

	
}
