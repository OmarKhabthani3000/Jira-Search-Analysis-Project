

/**
 * Enumeration of all clients 
 * 
 * @author eichhorn
 */
public enum ClientEnum implements LocalizableEnum<ClientEnum>
{
    /**
     * The default and up to now only client of the system.
     */
    A00,
    /**
     * Only for testing purpose.
     */
    ZZZ;

    /**
     * The exact lenght of the internal client code.
     */
    public static final int CLIENT_CODE_LENGTH = 3;
    
    private String clientCode;

    private ClientEnum()
    {
        if (name().length() != CLIENT_CODE_LENGTH)
        {
            throw new IllegalArgumentException("clientNumber must have length " + CLIENT_CODE_LENGTH); //$NON-NLS-1$
        }
    }
    
    /**
     * 
     */
    public String getMessageKey()
    {
        final String messageKey = ResourceBundleKey.ENUM_CLIENT + name();
        return messageKey;
    }

    /**
     * 
     */
    public ClientEnum getValue()
    {
        return this;
    }
    
    /**
     * @return the id of this enum
     */
    @Deprecated
    public String getId()
    {
        return clientCode;
    }
}
