
import java.util.List;

/**
 * @author aveseli
 *
 */
public interface WdbEntryDao extends BaseDao<WdbEntry, WdbEntryKey>
{
    /**
     * @param probDesc
     * @return list
     */
    List<WdbEntry> searchWdbEntries(final String probDesc);
    
    /**
     * method to create lucene index
     */
    void createIndex();

}
