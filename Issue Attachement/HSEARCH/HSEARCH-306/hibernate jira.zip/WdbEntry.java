import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;


/**
 * This class represents an entry in the WDB.
 * 
 * @author aveseli
 * 
 */
@Entity
@Table(name = "t_wdb_entry")
@Indexed
public class WdbEntry extends BaseEntity
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    /**
     * Mapping: <b>WDB_wdbID</b>
     */
    private WdbEntryKey wdbEntryKey;
    /**
     * Mapping: <b>WDB_aktiv</b>
     * 
     * Determines whether to make the wdb entry accessible or not. That means: show the WDB Entry as a search result.
     */
    private boolean active;
    /**
     * Mapping: <b>WDB_land</b>
     * 
     * We need to map the entries to the ISO standard. If the xml file contains "Deutschland" we make a "DE" out of it. We are not going to use our CountryEnum but we have to stick with the ISO standard.
     */
    private String country;
    /**
     * Mapping: <b>WDB_sprache</b>
     * 
     * We need to map the entries to the ISO standard. If the xml file contains "deutsch" we make a "DE" out of it. We are not going to use our LanguageEnum. The reason is that in R1.0 we only support "EN" and "DE". WDB-Entries can be in other
     * languages. Maybe we can define a temporary Enum for the WDB which inherits LanguageEnum and extends the supported languages.
     */
    private String language;
    /**
     * Mapping: <b>WDB_ticketID</b>
     * 
     * We wont be using this property. Reasons:
     * <ul>
     * <li>We are not migrating ticketId data so the reference points to null.</li>
     * <li>After migration the old Ticket IDs will change.</li>
     * </ul>
     */
    private int ticketId;
    /**
     * Mapping: <b>WDB_ticketart</b> This Determines the Ticket Type. In our application we represent ticketId types by two differen entities:
     * <ul>
     * <li>ProductTicket</li>
     * <li>VehicleTicket</li>
     * </ul>
     * We import that value to just have the data in our DB. This property is not used by any functionality.
     */
    private String ticketClassification;
    /**
     * Mapping: <b>WDB_parent_wdbID</b>
     */
    private WdbEntry parentEntry;
    /**
     * Mapping: <b>WDB_problem</b>
     */
    private String problem;
    /**
     * Mapping: <b>WDB_loesung</b>
     */
    private String solution;

    /**
     * Mapping: <b>WDB_ticketkategorie</b>
     * 
     * A mapping has to be defined to map the Category from the current TTS to ours.
     */
    private CategoryEnum category;

    /**
     * Mapping:<b> WDB_hersteller</b>
     */
    private String vehicleManufacturer;
    /**
     * Mapping:<b> WDB_modell</b>
     */
    private String vehicleModel;
    /**
     * Mapping: <b>WDB_motorcode</b>
     */
    private String vehicleEngineCode;
    /**
     * Mapping: <b>WDB_hubraum</b>
     */
    private String vehicleCubicCapacity;
    /**
     * Mapping: <b>WDB_kbanr1</b>
     */
    private String vehicleKbaNr1;
    /**
     * Mapping: <b>WDB_kbanr2</b>
     */
    private String vehicleKbaNr2;
    /**
     * Mapping: <b>WDB_boschschluessel1</b>
     */
    private String vehicleRBKey1;
    /**
     * Mapping: <b>WDB_boschschluessel2</b>
     */
    private String vehicleRBKey2;
    /**
     * Mapping: <b>WDB_erstzulassung</b>
     */
    private String vehicleFirstRegistration;
    /**
     * Mapping: <b>WDB_leistung</b>
     */
    private String vehicleOutput;
    /**
     * Mapping: <b>WDB_identnr</b>
     */
    private String vehicleIdentNo;
    /**
     * Mapping: <b>WDB_steuergeraetenr</b>
     */
    private String vehicleControlUnitNo;
    /**
     * Mapping: <b>WDB_kmstand</b>
     */
    private String vehicleOdometerReading;
    /**
     * Mapping: <b>WDB_systembezeichnung</b>
     */
    private String vehicleSystemDesignation;
    /**
     * Mapping: <b>WDB_ezd_kategorie</b> Seems always to be '0'. Dont exactly know what this Property means.
     */
    private String productDieselCategory;
    /**
     * Mapping: <b>WDB_ezd_dieselerzeugnis</b>
     */
    private String productDieselProduct;
    /**
     * Mapping: <b>WDB_ezd_pumpe</b>
     */
    private String productDieselPumpTypeFormula;
    /**
     * Mapping: <b>WDB_ezd_regler</b>
     */
    private String productDieselControllerTypeFormula;
    /**
     * Mapping:<b> WDB_ezd_kdidnr</b>
     */
    private String productDieselClientIdentNo;
    /**
     * Mapping: <b>WDB_ezd_kombinr</b>
     */
    private String productDieselCombinationZexcelNo;
    /**
     * Mapping:<b> WDB_ezd_fd</b>
     */
    private String productDieselProductionDate;
    /**
     * Mapping: <b>WDB_ezd_pruefwert</b>
     */
    private boolean productDieselTestValues;
    /**
     * Mapping: <b>WDB_ezd_ersatzteilliste</b>
     */
    private boolean productDieselSparePartsList;
    /**
     * Mapping: <b>WDB_eze_elektrikerzeugnis</b>
     */
    private String productElectricalProduct;
    /**
     * Mapping: <b>WDB_eze_erzeugnisnr</b>
     */
    private String productElectricalPartNo;
    /**
     * Mapping: <b>WDB_eze_typformel</b>
     */
    private String productElectricalTypeFormula;
    /**
     * Mapping: <b>WDB_eze_steuergeraetenr</b>
     */
    private String productElectricalControlUnitNo;

    /**
     * @param wdbEntryId
     * @return workshopKey
     */
    public static WdbEntryKey mapId2Key(final WdbEntryId wdbEntryId)
    {
        if (null == wdbEntryId)
        {
            throw new NullPointerException("wdbEntryId must not be null."); //$NON-NLS-1$
        }

        final WdbEntryKey wdbEntryKey = mapId2Key(new WdbEntryKey(), wdbEntryId);
        return wdbEntryKey;
    }

    /**
     * @return the id
     */
    @Id
    @AttributeOverrides( { @AttributeOverride(name = "a1client", column = @Column(name = "key_client", columnDefinition = ColumnDefinition.CLIENT)), @AttributeOverride(name = "a2identifier", column = @Column(name = "key_identifier")) })
    @FieldBridge(impl = WdbEntryKeyBridge.class)
    @DocumentId
    public WdbEntryKey getWdbEntryKey()
    {
        return wdbEntryKey;
    }

    /**
     * @param wdbEntryKey the id to set
     */
    public void setWdbEntryKey(WdbEntryKey wdbEntryKey)
    {
        this.wdbEntryKey = wdbEntryKey;
    }

    /**
     * @return the active
     */
    @Column(columnDefinition = ColumnDefinition.CHAR_1 + " default 'Y'")
    @Type(type = "yes_no")
    public boolean isActive()
    {
        return active;
    }

    /**
     * @param active the active to set
     */
    public void setActive(boolean active)
    {
        this.active = active;
    }

    /**
     * @return the country
     */
    @Enumerated(EnumType.STRING)
    @Column(columnDefinition = ColumnDefinition.VARCHAR_20)
    public String getCountry()
    {
        return country;
    }

    /**
     * @param country the country to set
     */
    public void setCountry(String country)
    {
        this.country = country;
    }

    /**
     * @return the language
     */
    @Column(columnDefinition = ColumnDefinition.CHAR_2)
    public String getLanguage()
    {
        return language;
    }

    /**
     * @param language the language to set
     */
    public void setLanguage(String language)
    {
        this.language = language;
    }

    /**
     * @return the ticketId
     */
    @Column(name = "ticket_id")
    public int getTicketId()
    {
        return ticketId;
    }

    /**
     * @param ticketId the ticketId to set
     */
    public void setTicketId(int ticketId)
    {
        this.ticketId = ticketId;
    }

    /**
     * @return the ticketClassification
     */
    @Column(name = "ticket_classification", columnDefinition = ColumnDefinition.VARCHAR_30)
    public String getTicketClassification()
    {
        return ticketClassification;
    }

    /**
     * @param ticketClassification the ticketClassification to set
     */
    public void setTicketClassification(String ticketClassification)
    {
        this.ticketClassification = ticketClassification;
    }

    /**
     * @return the parentEntry
     */
    @ManyToOne(optional = true)
    @AttributeOverrides( { @AttributeOverride(name = "parentEntry_key_client", column = @Column(name = "test")) })
    public WdbEntry getParentEntry()
    {
        return parentEntry;
    }

    /**
     * @param parentEntry the parentEntry to set
     */
    public void setParentEntry(WdbEntry parentEntry)
    {
        this.parentEntry = parentEntry;
    }

    /**
     * @return the problem
     */
    @Column(columnDefinition = ColumnDefinition.UTF8_VARCHAR_4000)
    @Field(index = org.hibernate.search.annotations.Index.TOKENIZED, store = Store.NO)
    public String getProblem()
    {
        return problem;
    }

    /**
     * @param problem the problem to set
     */
    public void setProblem(String problem)
    {
        this.problem = problem;
    }

    /**
     * @return the solution
     */
    @Column(columnDefinition = ColumnDefinition.UTF8_VARCHAR_4000)
    @Field(index = org.hibernate.search.annotations.Index.TOKENIZED, store = Store.NO)
    public String getSolution()
    {
        return solution;
    }

    /**
     * @param solution the solution to set
     */
    public void setSolution(String solution)
    {
        this.solution = solution;
    }

    /**
     * @return the category
     */
    @Enumerated(EnumType.STRING)
    public CategoryEnum getCategory()
    {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(CategoryEnum category)
    {
        this.category = category;
    }

    /**
     * @return the vehicleManufacturer
     */
    @Column(name = "vehicle_manufacturer", columnDefinition = ColumnDefinition.UTF8_VARCHAR_50)
    public String getVehicleManufacturer()
    {
        return vehicleManufacturer;
    }

    /**
     * @param vehicleManufacturer the vehicleManufacturer to set
     */
    public void setVehicleManufacturer(String vehicleManufacturer)
    {
        this.vehicleManufacturer = vehicleManufacturer;
    }

    /**
     * @return the vehicleModel
     */
    @Column(name = "vehicle_model", columnDefinition = ColumnDefinition.UTF8_VARCHAR_50)
    public String getVehicleModel()
    {
        return vehicleModel;
    }

    /**
     * @param vehicleModel the vehicleModel to set
     */
    public void setVehicleModel(String vehicleModel)
    {
        this.vehicleModel = vehicleModel;
    }

    /**
     * @return the vehicleEngineCode
     */
    @Column(name = "vehicle_engine_code", columnDefinition = ColumnDefinition.VARCHAR_50)
    public String getVehicleEngineCode()
    {
        return vehicleEngineCode;
    }

    /**
     * @param vehicleEngineCode the vehicleEngineCode to set
     */
    public void setVehicleEngineCode(String vehicleEngineCode)
    {
        this.vehicleEngineCode = vehicleEngineCode;
    }

    /**
     * @return the vehicleCubicCapacity
     */
    @Column(name = "vehicle_cubic_capacity", columnDefinition = ColumnDefinition.VARCHAR_30)
    public String getVehicleCubicCapacity()
    {
        return vehicleCubicCapacity;
    }

    /**
     * @param vehicleCubicCapacity the vehicleCubicCapacity to set
     */
    public void setVehicleCubicCapacity(String vehicleCubicCapacity)
    {
        this.vehicleCubicCapacity = vehicleCubicCapacity;
    }

    /**
     * @return the vehicleKbaNr1
     */
    @Column(name = "vehicle_kba_nr_1", columnDefinition = ColumnDefinition.VARCHAR_10)
    public String getVehicleKbaNr1()
    {
        return vehicleKbaNr1;
    }

    /**
     * @param vehicleKbaNr1 the vehicleKbaNr1 to set
     */
    public void setVehicleKbaNr1(String vehicleKbaNr1)
    {
        this.vehicleKbaNr1 = vehicleKbaNr1;
    }

    /**
     * @return the vehicleKbaNr2
     */
    @Column(name = "vehicle_kba_nr_2", columnDefinition = ColumnDefinition.VARCHAR_10)
    public String getVehicleKbaNr2()
    {
        return vehicleKbaNr2;
    }

    /**
     * @param vehicleKbaNr2 the vehicleKbaNr2 to set
     */
    public void setVehicleKbaNr2(String vehicleKbaNr2)
    {
        this.vehicleKbaNr2 = vehicleKbaNr2;
    }

    /**
     * @return the vehicleRBKey1
     */
    @Column(name = "vehicle_rb_key_1", columnDefinition = ColumnDefinition.VARCHAR_10)
    public String getVehicleRBKey1()
    {
        return vehicleRBKey1;
    }

    /**
     * @param vehicleRBKey1 the vehicleRBKey1 to set
     */
    public void setVehicleRBKey1(String vehicleRBKey1)
    {
        this.vehicleRBKey1 = vehicleRBKey1;
    }

    /**
     * @return the vehicleRBKey2
     */
    @Column(name = "vehicle_rb_key_2", columnDefinition = ColumnDefinition.VARCHAR_10)
    public String getVehicleRBKey2()
    {
        return vehicleRBKey2;
    }

    /**
     * @param vehicleRBKey2 the vehicleRBKey2 to set
     */
    public void setVehicleRBKey2(String vehicleRBKey2)
    {
        this.vehicleRBKey2 = vehicleRBKey2;
    }

    /**
     * @return the vehicleFirstRegistration
     */
    @Column(name = "vehicle_first_registration", columnDefinition = ColumnDefinition.VARCHAR_20)
    public String getVehicleFirstRegistration()
    {
        return vehicleFirstRegistration;
    }

    /**
     * @param vehicleFirstRegistration the vehicleFirstRegistration to set
     */
    public void setVehicleFirstRegistration(String vehicleFirstRegistration)
    {
        this.vehicleFirstRegistration = vehicleFirstRegistration;
    }

    /**
     * @return the vehicleOutput
     */
    @Column(name = "vehicle_output", columnDefinition = ColumnDefinition.VARCHAR_10)
    public String getVehicleOutput()
    {
        return vehicleOutput;
    }

    /**
     * @param vehicleOutput the vehicleOutput to set
     */
    public void setVehicleOutput(String vehicleOutput)
    {
        this.vehicleOutput = vehicleOutput;
    }

    /**
     * @return the vehicleIdentNo
     */
    @Column(name = "vehicle_ident_no", columnDefinition = ColumnDefinition.VARCHAR_30)
    public String getVehicleIdentNo()
    {
        return vehicleIdentNo;
    }

    /**
     * @param vehicleIdentNo the vehicleIdentNo to set
     */
    public void setVehicleIdentNo(String vehicleIdentNo)
    {
        this.vehicleIdentNo = vehicleIdentNo;
    }

    /**
     * @return the vehicleControlUnitNo
     */
    @Column(name = "vehicle_control_unit_no", columnDefinition = ColumnDefinition.VARCHAR_30)
    public String getVehicleControlUnitNo()
    {
        return vehicleControlUnitNo;
    }

    /**
     * @param vehicleControlUnitNo the vehicleControlUnitNo to set
     */
    public void setVehicleControlUnitNo(String vehicleControlUnitNo)
    {
        this.vehicleControlUnitNo = vehicleControlUnitNo;
    }

    /**
     * @return the vehicleOdometerReading
     */
    @Column(name = "vehicle_odometer_reading", columnDefinition = ColumnDefinition.VARCHAR_20)
    public String getVehicleOdometerReading()
    {
        return vehicleOdometerReading;
    }

    /**
     * @param vehicleOdometerReading the vehicleOdometerReading to set
     */
    public void setVehicleOdometerReading(String vehicleOdometerReading)
    {
        this.vehicleOdometerReading = vehicleOdometerReading;
    }

    /**
     * @return the vehicleSystemDesignation
     */
    @Column(name = "vehicle_system_designation", columnDefinition = ColumnDefinition.UTF8_VARCHAR_100)
    public String getVehicleSystemDesignation()
    {
        return vehicleSystemDesignation;
    }

    /**
     * @param vehicleSystemDesignation the vehicleSystemDesignation to set
     */
    public void setVehicleSystemDesignation(String vehicleSystemDesignation)
    {
        this.vehicleSystemDesignation = vehicleSystemDesignation;
    }

    /**
     * @return the productDieselCategory
     */
    @Column(name = "pd_category", columnDefinition = ColumnDefinition.VARCHAR_10 + " default '0'")
    public String getProductDieselCategory()
    {
        return productDieselCategory;
    }

    /**
     * @param productDieselCategory the productDieselCategory to set
     */
    public void setProductDieselCategory(String productDieselCategory)
    {
        this.productDieselCategory = productDieselCategory;
    }

    /**
     * @return the productDieselProduct
     */
    @Column(name = "pd_product", columnDefinition = ColumnDefinition.UTF8_VARCHAR_50)
    public String getProductDieselProduct()
    {
        return productDieselProduct;
    }

    /**
     * @param productDieselProduct the productDieselProduct to set
     */
    public void setProductDieselProduct(String productDieselProduct)
    {
        this.productDieselProduct = productDieselProduct;
    }

    /**
     * @return the productDieselPumpTypeFormula
     */
    @Column(name = "pd_pump_type_formula", columnDefinition = ColumnDefinition.VARCHAR_100)
    public String getProductDieselPumpTypeFormula()
    {
        return productDieselPumpTypeFormula;
    }

    /**
     * @param productDieselPumpTypeFormula the productDieselPumpTypeFormula to set
     */
    public void setProductDieselPumpTypeFormula(String productDieselPumpTypeFormula)
    {
        this.productDieselPumpTypeFormula = productDieselPumpTypeFormula;
    }

    /**
     * @return the productDieselControllerTypeFormula
     */
    @Column(name = "pd_controller_type_formula", columnDefinition = ColumnDefinition.VARCHAR_30)
    public String getProductDieselControllerTypeFormula()
    {
        return productDieselControllerTypeFormula;
    }

    /**
     * @param productDieselControllerTypeFormula the productDieselControllerTypeFormula to set
     */
    public void setProductDieselControllerTypeFormula(String productDieselControllerTypeFormula)
    {
        this.productDieselControllerTypeFormula = productDieselControllerTypeFormula;
    }

    /**
     * @return the productDieselClientIdentNo
     */
    @Column(name = "pd_client_ident_no", columnDefinition = ColumnDefinition.VARCHAR_20)
    public String getProductDieselClientIdentNo()
    {
        return productDieselClientIdentNo;
    }

    /**
     * @param productDieselClientIdentNo the productDieselClientIdentNo to set
     */
    public void setProductDieselClientIdentNo(String productDieselClientIdentNo)
    {
        this.productDieselClientIdentNo = productDieselClientIdentNo;
    }

    /**
     * @return the productDieselCombinationZexcelNo
     */
    @Column(name = "pd_combination_no", columnDefinition = ColumnDefinition.VARCHAR_30)
    public String getProductDieselCombinationZexcelNo()
    {
        return productDieselCombinationZexcelNo;
    }

    /**
     * @param productDieselCombinationZexcelNo the productDieselCombinationZexcelNo to set
     */
    public void setProductDieselCombinationZexcelNo(String productDieselCombinationZexcelNo)
    {
        this.productDieselCombinationZexcelNo = productDieselCombinationZexcelNo;
    }

    /**
     * @return the productDieselProductionDate
     */
    @Column(name = "pd_production_date", columnDefinition = ColumnDefinition.VARCHAR_10)
    public String getProductDieselProductionDate()
    {
        return productDieselProductionDate;
    }

    /**
     * @param productDieselProductionDate the productDieselProductionDate to set
     */
    public void setProductDieselProductionDate(String productDieselProductionDate)
    {
        this.productDieselProductionDate = productDieselProductionDate;
    }

    /**
     * @return the productDieselTestValues
     */
    @Column(name = "pd_test_values", columnDefinition = ColumnDefinition.CHAR_1 + " default 'Y'")
    @Type(type = "yes_no")
    public boolean isProductDieselTestValues()
    {
        return productDieselTestValues;
    }

    /**
     * @param productDieselTestValues the productDieselTestValues to set
     */
    public void setProductDieselTestValues(boolean productDieselTestValues)
    {
        this.productDieselTestValues = productDieselTestValues;
    }

    /**
     * @return the productDieselSparePartsList
     */
    @Column(name = "pd_spare_parts_list", columnDefinition = ColumnDefinition.CHAR_1 + " default 'Y'")
    @Type(type = "yes_no")
    public boolean isProductDieselSparePartsList()
    {
        return productDieselSparePartsList;
    }

    /**
     * @param productDieselSparePartsList the productDieselSparePartsList to set
     */
    public void setProductDieselSparePartsList(boolean productDieselSparePartsList)
    {
        this.productDieselSparePartsList = productDieselSparePartsList;
    }

    /**
     * @return the productElectricalProduct
     */
    @Column(name = "pe_product", columnDefinition = ColumnDefinition.UTF8_VARCHAR_50)
    public String getProductElectricalProduct()
    {
        return productElectricalProduct;
    }

    /**
     * @param productElectricalProduct the productElectricalProduct to set
     */
    public void setProductElectricalProduct(String productElectricalProduct)
    {
        this.productElectricalProduct = productElectricalProduct;
    }

    /**
     * @return the productElectricalPartNo
     */
    @Column(name = "pe_part_no", columnDefinition = ColumnDefinition.VARCHAR_20)
    public String getProductElectricalPartNo()
    {
        return productElectricalPartNo;
    }

    /**
     * @param productElectricalPartNo the productElectricalPartNo to set
     */
    public void setProductElectricalPartNo(String productElectricalPartNo)
    {
        this.productElectricalPartNo = productElectricalPartNo;
    }

    /**
     * @return the productElectricalTypeFormula
     */
    @Column(name = "pe_type_formula", columnDefinition = ColumnDefinition.VARCHAR_50)
    public String getProductElectricalTypeFormula()
    {
        return productElectricalTypeFormula;
    }

    /**
     * @param productElectricalTypeFormula the productElectricalTypeFormula to set
     */
    public void setProductElectricalTypeFormula(String productElectricalTypeFormula)
    {
        this.productElectricalTypeFormula = productElectricalTypeFormula;
    }

    /**
     * @return the productElectricalControlUnitNo
     */
    @Column(name = "pe_control_unit_no", columnDefinition = ColumnDefinition.VARCHAR_20)
    public String getProductElectricalControlUnitNo()
    {
        return productElectricalControlUnitNo;
    }

    /**
     * @param productElectricalControlUnitNo the productElectricalControlUnitNo to set
     */
    public void setProductElectricalControlUnitNo(String productElectricalControlUnitNo)
    {
        this.productElectricalControlUnitNo = productElectricalControlUnitNo;
    }

    /**
     * Helper to map a PersonId to a PersonKey
     * 
     * @param wdbEntryKey
     * @param wdbEntryId
     * @return the wdbEntryKey
     */
    private static WdbEntryKey mapId2Key(final WdbEntryKey wdbEntryKey, final WdbEntryId wdbEntryId)
    {
        wdbEntryKey.setA2identifier(wdbEntryId.getIdentifier());
        return wdbEntryKey;
    }
}
