
import java.util.List;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.Query;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;


/**
 * @author aveseli
 * 
 */
public class HibernateWdbEntryDao extends HibernateBaseDao<WdbEntry, WdbEntryKey> implements WdbEntryDao
{
 
    /**
     * @param probDesc
     * @return list
     */
    public List<WdbEntry> searchWdbEntries(final String probDesc)
    {
        FullTextSession fullTextSession = Search.getFullTextSession(getSession());
      
        MultiFieldQueryParser parser = new MultiFieldQueryParser(new String[] { "problem", "solution" }, new StandardAnalyzer());
        Query query = null;
        try
        {
            query = parser.parse(probDesc);
        }
        catch (ParseException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        org.hibernate.Query hibQuery = fullTextSession.createFullTextQuery(query, WdbEntry.class);
        List<WdbEntry> resultList = hibQuery.list();
        return resultList;
    }

    
    /**
     * method to create index
     */
    public void createIndex()
    {
        FullTextSession fullTextSession = Search.getFullTextSession(getSession());
        List<WdbEntry> wdbList = getSession().createQuery("from WdbEntry as wdb").list();
        for (WdbEntry wdbEntry : wdbList)
        {
            fullTextSession.index(wdbEntry);
        }

    }
}
