
import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Transient;


/**
 * Key for WDB Entry
 * 
 * @author aveseli
 * 
 */
@Embeddable
public class WdbEntryKey implements Serializable
{
    /**
     * default serial version UID
     */
    private static final long serialVersionUID = 1L;

    /**
     * The client attribute is needed to separate visibility of the data (in further releases).
     */
    private ClientEnum a1client;

    /**
     * The country of the workshop.
     */
    private long a2identifier;


    /**
     * for hibernate
     */
    public WdbEntryKey()
    {
        // for hibernate
    }

    /**
     * @param identifier
     */
    public WdbEntryKey(final long identifier)
    {
        this.a2identifier = identifier;
    }

    /**
     * @return the client
     */
    @Transient
    public ClientEnum getClient()
    {
        return getA1client();
    }

    /**
     * Returns the id of the WdbEntry.
     * 
     * @return the id of the WdbEntry.
     */
    @Transient
    public long getIdentifier()
    {
        return this.a2identifier;
    }
    
    
    /**
     * @return the client
     */
    @Enumerated(EnumType.STRING)
    public ClientEnum getA1client()
    {
        if (null != a1client)
        {
            return a1client;
        }

        final UserContext userContext = UserContextHolder.getContext();
        if (null == userContext)
        {
            throw new NullPointerException("userContext must not be null."); //$NON-NLS-1$
        }
        a1client = userContext.getClient();

        return a1client;
    }

    /**
     * @param client the client to set
     */
    void setA1client(final ClientEnum client)
    {
        this.a1client = client;
    }
    
    

    /**
     * @return the a2identifier
     */
    public long getA2identifier()
    {
        return a2identifier;
    }

    /**
     * @param a2identifier the a2identifier to set
     */
    public void setA2identifier(long a2identifier)
    {
        this.a2identifier = a2identifier;
    }
    
    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        final StringBuffer stringBuffer = new StringBuffer(32);
        stringBuffer.append(a2identifier);
        return stringBuffer.toString();
    }

    /**
     * @return string
     */
    public String toStringForLucene()
    {
        final StringBuffer stringBuffer = new StringBuffer(32);
        stringBuffer.append(a1client);
        stringBuffer.append(Constants.ID_COMPONENT_DELIMITER);
        stringBuffer.append(a2identifier);
        return stringBuffer.toString();
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((a1client == null) ? 0 : a1client.hashCode());
        result = prime * result + (int) (a2identifier ^ (a2identifier >>> 32));
        return result;
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        WdbEntryKey other = (WdbEntryKey) obj;
        if (a1client == null)
        {
            if (other.a1client != null)
            {
                return false;
            }
        }
        else if (!a1client.equals(other.a1client))
        {
            return false;
        }
        if (a2identifier != other.a2identifier)
        {
            return false;
        }
        return true;
    }
    
    
}
