import org.hibernate.search.bridge.TwoWayStringBridge;

/**
 * WdbEntryKey bridge. A bridge to convert WdbEntryKey to String and from String back to Object.
 * 
 * @author mkhopkar
 */
public class WdbEntryKeyBridge implements TwoWayStringBridge
{

    /**
     * @param stringValue
     * @return Object
     */
    public Object stringToObject(String stringValue)
    {
        WdbEntryKey key = new WdbEntryKey();
        final String regexp = String.valueOf(Constants.ID_COMPONENT_DELIMITER);
        final String[] splittedValue = stringValue.split(regexp);
        final ClientEnum client = ClientEnum.valueOf(splittedValue[0]);
        final String identifier = splittedValue[1];
        key.setA1client(client);
        key.setA2identifier(new Long(identifier));
        return key; // WdbEntry.mapId2Key(WdbEntryId.valueOf(stringValue));
    }

    /**
     * @param object
     * @return String
     */
    public String objectToString(Object object)
    {
        String wdbKey = ((WdbEntryKey) object).toStringForLucene();
        return wdbKey;
    }   
    
}