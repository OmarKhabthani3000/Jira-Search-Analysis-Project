package org.mycompany.hibernate.search;

import java.lang.annotation.ElementType;
import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.util.Version;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.event.def.DefaultFlushEventListener;
import org.hibernate.search.Environment;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.cfg.SearchMapping;
import org.hibernate.search.event.FullTextIndexEventListener;

public class SearchTest extends TestCase {

  protected Session testSession;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    
    Configuration cfg = new Configuration();
    cfg.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
    cfg.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
    cfg.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:demo");
    cfg.setProperty("hibernate.connection.username", "sa");
    cfg.setProperty("hibernate.connection.password", "");
    cfg.setProperty("hibernate.connection.pool_size", "1");
    cfg.setProperty("hibernate.hbm2ddl.auto", "update");
    cfg.setProperty("hibernate.show_sql", "false");
    cfg.setProperty("hibernate.search.autoregister_listeners", "false");
    cfg.setProperty("hibernate.search.default.indexBase", "target");
    cfg.addResource("classes.hbm.xml");

    cfg.setProperty("hibernate.cache.provider_class", "org.hibernate.cache.HashtableCacheProvider");
    FullTextIndexEventListener fullTextIndexListener = new FullTextIndexEventListener();
    cfg.setListener("post-update", fullTextIndexListener);
    cfg.setListener("post-insert", fullTextIndexListener);
    cfg.setListener("post-delete", fullTextIndexListener);
    cfg.setListener("post-collection-recreate", fullTextIndexListener);
    cfg.setListener("post-collection-remove", fullTextIndexListener);
    cfg.setListener("post-collection-update", fullTextIndexListener);
    String[] listeners = new String[] {DefaultFlushEventListener.class.getName(), FullTextIndexEventListener.class.getName()};
    cfg.setListeners("flush", listeners);

    SearchMapping mapping = new SearchMapping();
    mapping
      .entity(MySubClass.class).indexed()
        .property("dbid", ElementType.FIELD).documentId()
        .property("field1", ElementType.METHOD).field().name("sub_one")
        .property("field2", ElementType.METHOD).field().name("sub_two")
        .property("field3", ElementType.METHOD).field().name("sub_three")
    ;
    cfg.getProperties().put(Environment.MODEL_MAPPING, mapping);

    this.testSession = cfg.buildSessionFactory().openSession();
    this.populateDB();
  }

  @Override
  protected void tearDown() throws Exception {
    this.emptyDB();
    this.testSession.close();
    super.tearDown();
  }

  private void populateDB() {
    Transaction tx = this.testSession.beginTransaction();
    MySubClass first = new MySubClass("first", "field", 2);
    this.testSession.persist(first);
    MySubClass second = new MySubClass("second", "field", 3);
    this.testSession.persist(second);
    MySubClass third = new MySubClass("third", "field", 5);
    this.testSession.persist(third);
    tx.commit();
  }
  
  @SuppressWarnings("unchecked")
  private void emptyDB() {
    Transaction tx = this.testSession.beginTransaction();
    Criteria crit = this.testSession.createCriteria(MySubClass.class);
    List<MySubClass> docList = crit.list();
    for (MySubClass doc : docList) {
      testSession.delete(doc);
    }
    tx.commit();
  }
  
  @SuppressWarnings("unchecked")
  private List<MySubClass> searchDocuments(String query) {
    FullTextSession searchSession = Search.getFullTextSession(this.testSession);
    Transaction tx = searchSession.beginTransaction();
    
    QueryParser parser = new QueryParser(Version.LUCENE_29, "sub_one", new StandardAnalyzer(Version.LUCENE_29));
    List<MySubClass> result = new ArrayList<MySubClass>();
    try {
      org.apache.lucene.search.Query luceneQuery = parser.parse(query);
      FullTextQuery hibernateQuery = searchSession.createFullTextQuery(luceneQuery, MySubClass.class);
      result = hibernateQuery.list();
    } catch (ParseException e) {
      e.printStackTrace();
    }
    tx.commit();
    return result;
  }

  public void testSimpleSearch() {
    String queryString = "sub_three:5";
    List<MySubClass> processes = this.searchDocuments(queryString);
    assertEquals(1, processes.size());
    assertEquals("third", processes.get(0).getField1());
  }
}
