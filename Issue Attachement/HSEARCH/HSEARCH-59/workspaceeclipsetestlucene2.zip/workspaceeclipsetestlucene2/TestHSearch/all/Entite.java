package all;
import org.hibernate.search.annotations.*;


@Indexed
public class Entite
{
	@DocumentId
	private Integer id;

	@Field(index=Index.TOKENIZED, store=Store.YES)
	private String titre;

	@IndexedEmbedded
	private Categorie categorie;

	public Entite() { }
	
	public Entite(String titre, Categorie categorie)
	{
		this.titre = titre;
		this.categorie = categorie;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public Categorie getCategorie() {
		return categorie;
	}

	public void setCategorie(Categorie categorie) {
		this.categorie = categorie;
	}
}
