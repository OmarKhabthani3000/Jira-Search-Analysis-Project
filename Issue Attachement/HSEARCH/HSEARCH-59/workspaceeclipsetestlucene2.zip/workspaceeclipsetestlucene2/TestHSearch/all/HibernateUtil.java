package all;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;


public class HibernateUtil
{
	private static final Configuration configuration;
	private static final SessionFactory sessionFactory;

	static
	{
		try
		{
			configuration = new Configuration();
			configuration.configure("hibernate.cfg.xml"); // lecture du hibernate.cfg.xml au lieu du hibernate.properties
			
			// sert a creer des instances de sessions hibernate
			sessionFactory = configuration.buildSessionFactory();

		} catch (HibernateException e) {
			throw new RuntimeException("Probleme de configuration Hibernate : "+ e.getMessage(), e);
		}
	}

	public static final ThreadLocal<Session> session = new ThreadLocal<Session>();

	/**
	 * Recupere une session (ou en cree une)
	 * et lance une transaction
	 * @return la session
	 */
	public static Session getSessionActuelle()
	{
		Session s = (Session) session.get();
		
		// ouvre une nouvelle Session, si ce Thread n'en a aucune
		if (s == null)
		{
			s = sessionFactory.openSession();
			session.set(s);		
		}
		return s;
	}

	/**
	 * Ferme la session si elle existe
	 */
	public static void fermerSession()
	{
		Session s = (Session) session.get();
		session.set(null);
		if (s != null)
			s.close();
	}
	
	/**
	 * Creation des tables necessaires
	 * Si deja presentes, elles sont ecrasees !
	 */
	public static void reinitialiserDonnees()
	{
		SchemaExport se = new SchemaExport(configuration);
		se.create(true,true);
	}
	
	public static void main(String[] args) {
		reinitialiserDonnees();

		Session session = HibernateUtil.getSessionActuelle();

		Transaction tx = session.beginTransaction();
		Categorie categorie = new Categorie("nomcategorie");
		session.persist(categorie);
		Entite entite = new Entite("entite 1", categorie);
		session.persist(entite);
		tx.commit();
		      
		HibernateUtil.fermerSession();
		
		/* If I do the 4 following lines : in my Entite indexes, categorie.nom value is "<not available>"
		session = HibernateUtil.getSessionActuelle();
		entite = (Entite) session.get(Entite.class, new Integer(1));
		FullTextSession fullTextSession = Search.createFullTextSession(session);
		fullTextSession.index(entite);
		*/

		fermerSession();
	}
}
