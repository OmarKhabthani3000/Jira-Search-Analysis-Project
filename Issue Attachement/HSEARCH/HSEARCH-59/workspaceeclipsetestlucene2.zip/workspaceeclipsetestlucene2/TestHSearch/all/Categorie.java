package all;
import org.hibernate.search.annotations.*;

@Indexed
public class Categorie {

	@DocumentId
	private Integer id;

	@Field(index=Index.TOKENIZED, store=Store.YES)
	private String nom;
	
	public Categorie() {}
	
	public Categorie(String nom)
	{
		this.nom = nom;
	}

	public String toString()
	{
		return(nom);
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
}