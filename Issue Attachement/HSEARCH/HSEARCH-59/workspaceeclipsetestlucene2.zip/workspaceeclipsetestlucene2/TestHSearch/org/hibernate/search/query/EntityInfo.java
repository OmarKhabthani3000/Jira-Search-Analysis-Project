//$Id: $
package org.hibernate.search.query;

import java.io.Serializable;

/**
 * @author Emmanuel Bernard
 */
class EntityInfo {
	public Class clazz;
	public Serializable id;
}
