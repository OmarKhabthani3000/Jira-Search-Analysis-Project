package org.hibernate.search.test;

import java.util.List;

import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;


public class AnnoOnDifferentGetterNameTest extends SearchTestCase {

    @Override
    protected Class<?>[] getAnnotatedClasses() {
        return new Class[] { Book.class };
    }


    public void testChangeToEntity() throws Exception {
        Book book = new Book("foo");
        Session s = openSession();
        Transaction tx = s.beginTransaction();
        s.persist( book );
        tx.commit();

        FullTextSession session = Search.getFullTextSession( s );
        QueryParser parser = new QueryParser( getTargetLuceneVersion(), "txtfld", SearchTestCase.standardAnalyzer );
        Query query;
        List<?> result;


        query = parser.parse( "foo" );
        result = session.createFullTextQuery( query, Book.class ).list();
        assertEquals( "unable to find book with text 'foo'", 1, result.size() );

        s.clear();

        //Let's change the text of book
        tx = s.beginTransaction();

        book = ( Book ) s.get( Book.class, book.getId() );
        book.setText( "bar" );
        tx.commit();

        s.clear();

        session = Search.getFullTextSession( s );
        tx = s.beginTransaction();

        //check if the old value of book.text ('foo') is not matched anymore
        query = parser.parse( "foo" );
        result = session.createFullTextQuery( query, Book.class ).list();
        assertEquals( "change on simple string field not reflected in root index", 0, result.size() );

        //check if the new value of book.text ('bar') is matched
        query = parser.parse( "bar" );
        result = session.createFullTextQuery( query, Book.class ).list();
        assertEquals( "change on simple string field not reflected in root index", 1, result.size() );

        tx.commit();

        s.clear();
        s.close();
    }

}
