
import java.util.Properties;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.junit.Before;
import org.junit.Test;

import at.sit.cors.model.HibDocument;

public class FileLeakTest {

	private EntityManagerFactory emf = null;
	
	@Before
	public void setup(){
		emf = Persistence.createEntityManagerFactory("cors",getProperties());
	}
	
	private static Properties getProperties(){
		Properties props = new Properties();
		props.put("hibernate.connection.driver_class","org.h2.Driver");
		props.put("hibernate.dialect","org.hibernate.dialect.H2Dialect");
		props.put("hibernate.cache.provider_class","org.hibernate.cache.NoCacheProvider");
		props.put("hibernate.jdbc.charSet","UTF-8");
		props.put("hibernate.hbm2ddl.auto","create-drop");
		
		props.put("hibernate.connection.url","jdbc:h2:mem:test");
		props.put("hibernate.connection.username","sa");
		props.put("hibernate.connection.password","");

		props.put("hibernate.search.default.sourceBase","C:/lucene/fileleaktest/shared");
		props.put("hibernate.search.default.indexBase","C:/lucene/fileleaktest/master");
		props.put("hibernate.search.default.refresh","300");
		props.put("hibernate.search.default.directory_provider","org.hibernate.search.store.FSMasterDirectoryProvider");
		
		return props;
	}
	
	
	public FullTextSession getFulltextSession(){
		EntityManager em = emf.createEntityManager();
		Session session = (Session) em.getDelegate();
		FullTextSession fullTextSession = Search.getFullTextSession(session);
		return fullTextSession;
	}
	
	
	public void createDocuments(int size){
		FullTextSession session = getFulltextSession();
		try{
			session.getTransaction().begin();
			for(int i = 0; i < size; i++){
				HibDocument d = new HibDocument(UUID.randomUUID().toString(),UUID.randomUUID().toString(),UUID.randomUUID().toString());
				session.persist(d);
			}
			session.getTransaction().commit();

		}finally{
			session.close();
		}
	}
	
	
	public void batchIndex(){
		FullTextSession session = getFulltextSession();
		try {
			//tried with trans and without- same effect
			session.getTransaction().begin();
			session.createIndexer().batchSizeToLoadObjects(30)
			.threadsForSubsequentFetching(4)
			.threadsToLoadObjects(2)
			.startAndWait();
			session.getTransaction().commit();
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}finally{
			session.close();
		}
	}
	
	
	@Test
	public void testForLeaks(){
		//on second run we re-create again, not ideal, can use filebased Db here but i dont see this as an issue but can adjust it
		createDocuments(50000);
		while(true){
			try {
				batchIndex();
				Thread.currentThread().sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	
}
