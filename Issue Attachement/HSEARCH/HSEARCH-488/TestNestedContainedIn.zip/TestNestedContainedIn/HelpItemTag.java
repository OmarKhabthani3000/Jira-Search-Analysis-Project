import javax.persistence.*;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.IndexedEmbedded;

@Entity()
public class HelpItemTag
{

	private static final long serialVersionUID = 1L;

	@Id()
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Version()
	private Long version;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "helpItem", nullable = false)
	@ContainedIn
	private HelpItem helpItem;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "tag", nullable = false)
	@IndexedEmbedded
	private Tag tag;

	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	public Long getVersion()
	{
		return version;
	}

	public void setVersion(Long version)
	{
		this.version = version;
	}

	public HelpItem getHelpItem()
	{
		return helpItem;
	}

	public void setHelpItem(HelpItem helpItem)
	{
		this.helpItem = helpItem;
	}

	public Tag getTag()
	{
		return tag;
	}

	public void setTag(Tag tag)
	{
		this.tag = tag;
	}
}