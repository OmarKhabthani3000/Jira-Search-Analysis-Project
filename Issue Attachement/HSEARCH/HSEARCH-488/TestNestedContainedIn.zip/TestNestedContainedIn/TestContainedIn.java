import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import junit.framework.TestCase;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.HSQLDialect;
import org.hibernate.jdbc.Work;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;

public class TestContainedIn extends TestCase
{

	private Session session;

	public TestContainedIn(String string)
	{
		super(string);

	}

	@Override
	protected void setUp() throws Exception
	{

		AnnotationConfiguration configuration = new AnnotationConfiguration();
		configuration.setProperty(Environment.DRIVER, "org.hsqldb.jdbcDriver");
		configuration.setProperty(Environment.URL, "jdbc:hsqldb:mem:ContainedInTest");
		configuration.setProperty(Environment.USER, "sa");
		configuration.setProperty(Environment.DIALECT, HSQLDialect.class.getName());
		configuration.setProperty(Environment.SHOW_SQL, "true");
		configuration.setProperty("hibernate.search.default.directory_provider",
			"org.hibernate.search.store.RAMDirectoryProvider");

		configuration.addAnnotatedClass(HelpItem.class);
		configuration.addAnnotatedClass(Tag.class);
		configuration.addAnnotatedClass(HelpItemTag.class);
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		session = sessionFactory.openSession();

		Transaction tx = session.beginTransaction();
		session.doWork(new Work()
		{
			@Override
			public void execute(Connection connection) throws SQLException
			{
				Statement statement = connection.createStatement();
				statement
					.execute("create table helpitem (id BIGINT IDENTITY, version BIGINT, title CHARACTER(100))");
				statement
					.execute("create table tag (id BIGINT IDENTITY, version BIGINT, name CHARACTER(100))");
				statement
					.execute("create table helpitemtag (id BIGINT IDENTITY, version BIGINT, helpitem BIGINT, tag CHARACTER(100))");

			}
		});
		tx.commit();
	}

	@Override
	protected void tearDown() throws Exception
	{
		Transaction tx = session.beginTransaction();
		session.doWork(new Work()
		{
			@Override
			public void execute(Connection connection) throws SQLException
			{
				Statement statement = connection.createStatement();
				statement.execute("drop table helpitemtag");
				statement.execute("drop table tag");
				statement.execute("drop table helpitem");

			}
		});
		tx.commit();
	}

	public void testAddHelpItem()
	{
		String tagName = "animal";
		createHelpItem(tagName);
		doQuery(tagName);
	}

	public void testChangeTagName()
	{
		String tagName = "animal";
		createHelpItem(tagName);
		HelpItem check = doQuery(tagName);
		Tag tag = check.getTags().get(0).getTag();

		Transaction tx = session.beginTransaction();
		String newTagName = "automobile";
		tag.setName(newTagName);
		session.saveOrUpdate(tag);
		tx.commit();

		doQuery(newTagName);
	}

	private void createHelpItem(String tagName)
	{
		Transaction tx = session.beginTransaction();
		HelpItem helpItem = new HelpItem();
		helpItem.setTitle("The quick brown fox jumps over the lazy dog.");

		Tag tag = new Tag();
		tag.setName(tagName);

		HelpItemTag helpItemTag = new HelpItemTag();
		helpItemTag.setHelpItem(helpItem);
		helpItemTag.setTag(tag);

		helpItem.getTags().add(helpItemTag);
		tag.getHelpItems().add(helpItemTag);

		session.save(helpItem);
		session.save(tag);
		session.save(helpItemTag);

		tx.commit();
	}

	private HelpItem doQuery(String tagName)
	{
		FullTextSession fullTextSession = Search.getFullTextSession(session);
		Query termQuery = new TermQuery(new Term("tags.tag.name", tagName));
		FullTextQuery fullTextQuery =
			fullTextSession.createFullTextQuery(termQuery, HelpItem.class);
		HelpItem check = (HelpItem) fullTextQuery.uniqueResult();
		assertNotNull("No HelpItem with Tag '" + tagName + "' found in Lucene index.", check);
		assertTrue(check.getTags().get(0).getTag().getName().equals(tagName));
		return check;
	}
}
