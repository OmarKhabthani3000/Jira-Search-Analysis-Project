package org.hibernate.search.bugs;

import java.util.*;
import javax.persistence.*;
import org.hibernate.search.annotations.*;
import org.hibernate.search.bugs.*;

@Entity
@Indexed
public class Foo {
	@Id
	@DocumentId
	private Long id;

	@Field
	private String name;

	@ContainedIn
	@IndexedEmbedded(depth = 1, prefix = "bar_")
	@OneToMany(mappedBy = "foo")
	private Set<Bar> bars = new HashSet<Bar>();

	public Foo(Long id, String name) {
		this.id = id;
		this.name = name;
	}

	public Long getId() { return id; }
	public String getName() { return name; }
	public Set<Bar> getBars() { return bars; }
	
	public String toString() {
		return "Foo: id=" + id + ", name=" + name + ", bars: " + bars;
	}
}