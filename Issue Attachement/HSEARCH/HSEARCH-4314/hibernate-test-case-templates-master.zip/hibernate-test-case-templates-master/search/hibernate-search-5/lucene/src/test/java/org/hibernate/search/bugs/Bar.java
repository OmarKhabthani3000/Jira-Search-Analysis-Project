package org.hibernate.search.bugs;

import javax.persistence.*;
import org.hibernate.search.annotations.*;
import org.hibernate.search.bugs.*;

@Entity
@Indexed
public class Bar {
	@Id
	@DocumentId
	private Long id;
	
	@Field
	private String name;
	
	@Field
	private String visibility;

	@ContainedIn
	@IndexedEmbedded(depth = 1, prefix = "foo_")
	@ManyToOne
	@JoinColumn(name = "FOO_ID")
	private Foo foo;

	public Bar(Long id, String name, String visibility, Foo foo) {
		this.id = id;
		this.name = name;
		this.visibility = visibility;
		this.foo = foo;
	}

	public Long getId() { return id; }
	public String getName() { return name; }
	public String getVisibility() { return visibility; }
	public Foo getFoo() { return foo; }
	
	public String toString() {
		return "Bar: id=" + id + ", name=" + name + ", visibility=" + visibility;
	}
}