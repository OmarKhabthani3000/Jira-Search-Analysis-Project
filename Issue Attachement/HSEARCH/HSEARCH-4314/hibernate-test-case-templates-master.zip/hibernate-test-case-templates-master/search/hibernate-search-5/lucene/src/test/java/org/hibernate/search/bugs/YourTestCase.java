package org.hibernate.search.bugs;

import static org.junit.Assert.assertEquals;

import java.util.*;
import org.apache.lucene.search.*;
import org.hibernate.*;
import org.hibernate.search.*;
import org.hibernate.search.bugs.*;
import org.hibernate.search.query.dsl.*;
import org.hibernate.search.testsupport.*;
import org.junit.*;

public class YourTestCase extends SearchTestBase {
	@Override
	public Class<?>[] getAnnotatedClasses() {
		return new Class<?>[]{ Foo.class, Bar.class };
	}

	@Test
	@TestForIssue(jiraKey = "HSEARCH-NNNNN") // Please fill in the JIRA key of your issue
	@SuppressWarnings("unchecked")
	public void testYourBug() {
		try (Session s = getSessionFactory().openSession()) {
			Transaction tx = s.beginTransaction();

			Foo foo1 = new Foo(1L, "Foo1");
			s.persist(foo1);

			Bar bar1 = new Bar(1L, "Bar1", "public", foo1);
			foo1.getBars().add(bar1);
			s.persist(bar1);

			Bar bar2 = new Bar(2L, "Bar2", "private", foo1);
			foo1.getBars().add(bar2);
			s.persist(bar2);

			tx.commit();

			FullTextSession session = Search.getFullTextSession(s);

			QueryBuilder qb = session.getSearchFactory().buildQueryBuilder().forEntity(Foo.class).get();

			BooleanJunction<?> bool = qb.bool();
			bool.must(qb.keyword().onField("bar_name").matching("Bar2").createQuery());
			bool.must(qb.keyword().onField("bar_visibility").matching("public").createQuery());

			org.apache.lucene.search.Query query = bool.createQuery();
	
			System.out.println("########################");
			System.out.println("# executing query: " + query);

			List<?> results = (List<?>) session.createFullTextQuery(query).list();
			
			System.out.println("# " + results.size() + " results returned: ");
			for (Object result : results)
				System.out.println("# " + result);
			System.out.println("########################");
		}
	}
}
