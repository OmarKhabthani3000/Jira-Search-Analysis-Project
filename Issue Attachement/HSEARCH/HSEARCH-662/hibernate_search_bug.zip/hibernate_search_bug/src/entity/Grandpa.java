package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "grandpa")
@SequenceGenerator(name = "grandpaSeq", sequenceName = "grandpa_seq")
public class Grandpa {

    private Long id;
    private String name;

    public Grandpa() {
    }

    public Grandpa(String name) {
        this.name = name;
    }

    @Id
    @Column(name = "grandpa_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "grandpaSeq")
    public Long getId() {
        return id;
    }

    private void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
