package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Store;


@Entity
@Table(name = "dad")
@SequenceGenerator(name = "dadSeq", sequenceName = "dad_seq")
public class Dad {
    private Long id;
    private String name;
    private Grandpa grandpa;

    private Set<Son> sons = new HashSet<Son>();

    public Dad() {
    }

    public Dad(String name) {
        this.name = name;
    }

    @Id
    @Column(name = "dad_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dadSeq")
    public Long getId() {
        return id;
    }

    private void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "grandpa_id")
    public Grandpa getGrandpa() {
        return grandpa;
    }

    public void setGrandpa(Grandpa grandpa) {
        this.grandpa = grandpa;
    }


    @Field(store = Store.YES)
    @Transient
    public Long getGrandpaId() {
        return grandpa != null ? grandpa.getId() : null;
    }

    @ContainedIn
    @OneToMany(mappedBy = "dad", fetch = FetchType.LAZY)
    public Set<Son> getSons() {
        return sons;
    }

    private void setSons(Set<Son> sons) {
        this.sons = sons;
    }

    public boolean add(Son son) {
        son.setDad(this);
        return sons.add(son);
    }
}
