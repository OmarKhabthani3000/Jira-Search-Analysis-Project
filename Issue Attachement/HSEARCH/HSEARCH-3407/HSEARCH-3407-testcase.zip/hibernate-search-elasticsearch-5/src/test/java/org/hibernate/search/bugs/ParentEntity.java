package org.hibernate.search.bugs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
@Indexed
public class ParentEntity {

  @Id
  @DocumentId
  private Long id;

  @IndexedEmbedded
  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "parent")
  private List<ChildEntity> children = new ArrayList<>();

  protected ParentEntity() {
  }

  public ParentEntity(Long id, ChildEntity... childEntities) {
    this.id = id;
    Arrays.stream(childEntities).forEach(this::addChildEntity);
  }

  public Long getId() {
    return id;
  }

  public List<ChildEntity> getChildren() {
    return Collections.unmodifiableList(children);
  }

  public void addChildEntity(ChildEntity child) {
    child.setParent(this);
    this.children.add(child);
  }

}
