package org.hibernate.search.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;

@Entity
@Indexed
public class ChildEntity {

  @Id
  @DocumentId
  private Long id;

  @ContainedIn
  @ManyToOne
  private ParentEntity parent;

  @Field
  private boolean booleanProperty;

  protected ChildEntity() {
  }

  public ChildEntity(Long id, boolean booleanProperty) {
    this.id = id;
    this.booleanProperty = booleanProperty;
  }

  public Long getId() {
    return id;
  }

  public boolean getBooleanProperty() {
    return booleanProperty;
  }

  public void setBooleanProperty(boolean booleanProperty) {
    this.booleanProperty = booleanProperty;
  }

  protected void setParent(ParentEntity parent) {
    this.parent = parent;
  }

}
