package org.hibernate.search.bugs;

import java.util.List;

import org.apache.lucene.search.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.elasticsearch.ElasticsearchQueries;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.query.engine.spi.QueryDescriptor;
import org.hibernate.search.testsupport.TestForIssue;
import org.junit.After;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class YourIT extends SearchTestBase {

  @Override
  public Class<?>[] getAnnotatedClasses() {
    return new Class<?>[] {ParentEntity.class, ChildEntity.class};
  }

  @Test
  @TestForIssue(jiraKey = "HSEARCH-3407")
  @SuppressWarnings("unchecked")
  public void testYourBug() {
    try (Session s = getSessionFactory().openSession()) {
      ChildEntity childEntity1 = new ChildEntity(1L, true);
      ChildEntity childEntity2 = new ChildEntity(2L, false);
      ParentEntity yourEntity1 = new ParentEntity(1L, childEntity1, childEntity2);

      Transaction tx = s.beginTransaction();
      s.persist(yourEntity1);
      tx.commit();

      FullTextSession session = Search.getFullTextSession(s);
      QueryBuilder qb = session.getSearchFactory().buildQueryBuilder().forEntity(ParentEntity.class).get();

      // finding ParentEntities with a children having boolean property "true" should match 1L
      Query query = qb.keyword().onField("children.booleanProperty").matching(true).createQuery();

      List<ParentEntity> result = session.createFullTextQuery(query).list();
      assertEquals(1, result.size());
      assertEquals(1l, (long) result.get(0).getId());

      // finding ParentEntities with a children having boolean property "false" should also match 1L
      query = qb.keyword().onField("children.booleanProperty").matching(false).createQuery();

      result = session.createFullTextQuery(query).list();
      assertEquals(1, result.size());
      assertEquals(1l, (long) result.get(0).getId());
    }
  }

  @After
  public void deleteTestData() {
    try (Session s = getSessionFactory().openSession()) {
      FullTextSession session = Search.getFullTextSession(s);
      Transaction tx = s.beginTransaction();

      QueryDescriptor query = ElasticsearchQueries.fromJson("{ 'query': { 'match_all' : {} } }");
      List<?> result = session.createFullTextQuery(query, ParentEntity.class).list();

      for (Object entity : result) {
        session.delete(entity);
      }

      tx.commit();
    }
  }

}
