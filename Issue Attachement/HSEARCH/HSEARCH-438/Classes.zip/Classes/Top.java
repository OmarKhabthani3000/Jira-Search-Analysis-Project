package com.test.entities;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
@Table(name = "top")
@Indexed(index = "work")
public class Top {

	private int id;
	private String name;
	private Date added;
	private Set<? extends Parent> parents = new HashSet<Parent>(0);
	
	@Id
	@DocumentId
	@GeneratedValue
    @Column(name = "id", unique = true, nullable = false) 
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "name")
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	@Column(name = "added")
	@Temporal(TemporalType.DATE)
	public Date getAdded() {
		return added;
	}
	
	public void setAdded(Date added) {
		this.added = added;
	}
	
	@IndexedEmbedded(depth=100)
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "top", cascade = CascadeType.ALL)
	public Set<? extends Parent> getParents() {
		return parents;
	}
	
	public void setParents(Set<? extends Parent> parents) {
		this.parents = parents;
	}
}
