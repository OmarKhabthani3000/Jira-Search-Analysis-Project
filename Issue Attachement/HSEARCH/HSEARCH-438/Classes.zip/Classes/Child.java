package com.test.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;

@Entity
@Table(name = "child")
public class Child extends Parent {

	private String childName;
	
	@Field(name = "childName", index=Index.TOKENIZED)
	@Column(name = "name")
	public String getChildName() {
		return childName;
	}
	
	public void setChildName(String childName) {
		this.childName = childName;
	}
}
