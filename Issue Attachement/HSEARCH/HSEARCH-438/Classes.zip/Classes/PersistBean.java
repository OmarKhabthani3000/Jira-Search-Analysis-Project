package com.test.session;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.test.entities.Child;
import com.test.entities.Parent;
import com.test.entities.Top;

@Stateless(name="PersistService")
public class PersistBean implements PersistService {

	@PersistenceContext(unitName = "workPU")
	private EntityManager em;
	
	public void persist() {
		System.out.println("************START  SERVICE***************");
		
		// Create new top level entity
		Top top = new Top();
		top.setName("House");
		top.setAdded(new Date());
			
		System.out.println("Tops id is: " + top.getId());	
		
		// Create new child bean, this is also a parent.
		Child child = new Child();
		
		// Set parent attributes
		child.setParentName("DadName");
		child.setTop(top);
		
		// Set child attributes
		child.setChildName("ChildName");
		
		// Add the child to the tops list of children
		Set<Child> children = new HashSet<Child>(0);
		children.add(child);
		top.setParents(children);
		//top.getParents().add(child);
		
		// Persist top level bean
		em.persist(top);
		
		System.out.println("************END  SERVICE***************");
	}
}
