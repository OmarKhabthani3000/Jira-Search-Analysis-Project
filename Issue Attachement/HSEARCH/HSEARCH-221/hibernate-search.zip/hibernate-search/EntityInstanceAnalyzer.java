package org.hibernate.search;

import java.io.Serializable;

public class EntityInstanceAnalyzer implements Serializable {
    private Class analyzerClass;
    private Class[] analyzerParameterTypes;
    private Object[] analyzerParameterValues;

    public EntityInstanceAnalyzer(Class analyzerClass) {
        this.analyzerClass = analyzerClass;
    }

    public EntityInstanceAnalyzer(Class analyzerClass, Class[] analyzerParameterTypes, Object[] analyzerParameterValues) {
        this.analyzerClass = analyzerClass;
        this.analyzerParameterTypes = analyzerParameterTypes;
        this.analyzerParameterValues = analyzerParameterValues;
    }

    public Class getAnalyzerClass() {
        return analyzerClass;
    }

    public Class[] getAnalyzerParameterTypes() {
        return analyzerParameterTypes;
    }

    public Object[] getAnalyzerParameterValues() {
        return analyzerParameterValues;
    }
}
