package org.hibernate.search;

import org.apache.lucene.analysis.Analyzer;

import java.io.Serializable;

public class EntityInstanceAnalyzer implements Serializable {
    private Class<? extends Analyzer> analyzerClass;
    private Class[] analyzerParameterTypes;
    private Object[] analyzerParameterValues;

    public EntityInstanceAnalyzer(Class<? extends Analyzer> analyzerClass) {
        this(analyzerClass, null, null);
    }

    public EntityInstanceAnalyzer(Class<? extends Analyzer> analyzerClass, Class[] analyzerParameterTypes, Object[] analyzerParameterValues) {
        if (analyzerClass == null) {
            throw new NullPointerException("Analyzer Class must not be null.");
        }

        this.analyzerClass = analyzerClass;
        this.analyzerParameterTypes = analyzerParameterTypes;
        this.analyzerParameterValues = analyzerParameterValues;
    }

    public Class<? extends Analyzer> getAnalyzerClass() {
        return analyzerClass;
    }

    public Class[] getAnalyzerParameterTypes() {
        return analyzerParameterTypes;
    }

    public Object[] getAnalyzerParameterValues() {
        return analyzerParameterValues;
    }
}
