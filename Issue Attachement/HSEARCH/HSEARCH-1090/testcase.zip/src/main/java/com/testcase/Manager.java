package com.testcase;

import com.testcase.entitites.Page;
import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.dsl.QueryBuilder;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

/**
 * @author Bostjan Lah
 */
public class Manager {
    private static final String PERSISTENCE_UNIT_NAME = "testcasePersistenceUnit";
    private static final int READER_SLEEP_TIME = 1000;
    private EntityManagerFactory entityManagerFactory;

    public void open() {
        entityManagerFactory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
    }

    public void close() {
        entityManagerFactory.close();
    }

    public void addPage(String name, String description) {
        Page page = new Page();
        page.setName(name);
        page.setDescription(description);

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        try {
            entityManager.persist(page);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            entityManager.getTransaction().rollback();
        } finally {
            entityManager.close();
        }
    }

    public int countHits(String searchText) throws InterruptedException {
        FullTextEntityManager entityManager = Search.getFullTextEntityManager(entityManagerFactory.createEntityManager());
        entityManager.getTransaction().begin();
        try {
            QueryBuilder queryBuilder = entityManager.getSearchFactory().buildQueryBuilder().forEntity(Page.class).get();
            Query query = queryBuilder.keyword().onField("description").matching(searchText).createQuery();
            FullTextQuery fullTextQuery = entityManager.createFullTextQuery(query, Page.class);
            List<Page> pages = (List<Page>) fullTextQuery.getResultList();
            Thread.sleep(READER_SLEEP_TIME);
            return pages.size();
        } finally {
            entityManager.getTransaction().rollback();
            entityManager.close();
        }
    }
}
