package com.testcase;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Random;

/**
 * User: Bostjan Lah
 */
public class TestCase {
    private static final Logger log = LoggerFactory.getLogger(TestCase.class);

    private static final int LINES = 100000;
    private static final int MIN_WORD_LENGTH = 3;

    private static final int MAIN_SLEEP_TIME = 30 * 60 * 1000; // 30min
    private static final int WRITER_SLEEP_TIME = 1000;

    private final Manager manager;

    public TestCase() {
        manager = new Manager();
    }

    public void runTest() {
        manager.open();

        Thread[] readers = new Thread[2];
        Thread writer = new Thread(new Writer());

        try {
            readers[0] = new Thread(new Reader(0));
            readers[1] = new Thread(new Reader(1));
            writer.start();
            readers[0].start();
            readers[1].start();
            Thread.sleep(MAIN_SLEEP_TIME);

        } catch (InterruptedException ignored) {

        } finally {
            writer.interrupt();
            readers[0].interrupt();
            readers[1].interrupt();
            try {
                writer.join();
                readers[0].join();
                readers[1].join();
            } catch (InterruptedException e) {
            }
            manager.close();
        }
    }

    public static void main(String[] args) {
        TestCase testCase = new TestCase();
        testCase.runTest();
    }

    private final class Writer implements Runnable {

        @Override
        public void run() {
            Random rand = new Random();
            InputStream inputStream = null;
            final List<String> lines;
            try {
                inputStream = getClass().getResourceAsStream("/lines.txt");
                lines = IOUtils.readLines(inputStream, "UTF-8");
            } catch (IOException e) {
                log.error("Unable to load lines!", e);
                return;
            } finally {
                IOUtils.closeQuietly(inputStream);
            }
            while (true) {
                try {
                    final int from = rand.nextInt(LINES - 10000);
                    storeData(lines, from, from + 10 + rand.nextInt(200));
                    Thread.sleep(WRITER_SLEEP_TIME);
                } catch (InterruptedException e) {
                    break;
                }
            }
        }

        private void storeData(List<String> lines, int from, int to) {
            log.info("Loading lines {} to {}", from, to);

            StringBuilder page = new StringBuilder();
            for (int i = from; i < to; i++) {
                page.append(lines.get(i));
            }
            manager.addPage(String.valueOf(from), page.toString());
        }
    }

    private final class Reader implements Runnable {

        private final int index;

        public Reader(int i) {
            index = i;
        }

        @Override
        public void run() {
            String alphabet = "abcdefghijklmnopqrstuvwxyz";
            Random rand = new Random();

            try {
                while (true) {
                    int len = MIN_WORD_LENGTH + rand.nextInt(alphabet.length() - MIN_WORD_LENGTH);
                    StringBuilder randomWord = new StringBuilder();
                    for (int i = 0; i < len; i++) {
                        randomWord.append(alphabet.charAt(i));
                    }
                    log.info("{} hits: {}", index, manager.countHits(randomWord.toString()));
                }
            } catch (InterruptedException ignored) {
            }
        }
    }

}
