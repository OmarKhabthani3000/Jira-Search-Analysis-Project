package com.manning.hsia.dvdstore.model;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

public interface IItem
{

    public abstract Set<IActor> getActors();

    public abstract void setActors(Set<IActor> actors);

    public abstract Director getDirector();

    public abstract void setDirector(Director director);

    public abstract Integer getId();

    public abstract String getEan();

    public abstract void setEan(String ean);

    public abstract void setId(Integer id);

    public abstract String getTitle();

    public abstract void setTitle(String title);

    public abstract String getDescription();

    public abstract void setDescription(String description);

    public abstract String getImageURL();

    public abstract void setImageURL(String imageURL);

    public abstract double getPrice();

    public abstract void setPrice(double price);

    public abstract Map<String, String> getRatePerDubbing();

    public abstract void setRatePerDoubling(Map<String, String> ratePerDubbing);

    public abstract Rating getRating();

    public abstract void setRating(Rating rating);

    public abstract Collection<Country> getDistributedIn();

    public abstract void setDistributedIn(Collection<Country> distributedIn);

}