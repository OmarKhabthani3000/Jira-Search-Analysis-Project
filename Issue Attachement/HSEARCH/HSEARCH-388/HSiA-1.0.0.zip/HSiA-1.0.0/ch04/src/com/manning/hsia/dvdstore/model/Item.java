package com.manning.hsia.dvdstore.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.CollectionOfElements;
import org.hibernate.annotations.MapKey;
import org.hibernate.search.annotations.Boost;
import org.hibernate.search.annotations.ClassBridge;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.annotations.Fields;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Parameter;
import org.hibernate.search.annotations.Store;

import com.manning.hsia.dvdstore.bridge.ItemPromotionBridge;
import com.manning.hsia.dvdstore.bridge.MapKeyPerFieldBridge;
import com.manning.hsia.dvdstore.bridge.PaddedRoundedPriceBridge;

/**
 * Example 4.1, 4.7, 4.9, 4.12, 4.13
 */
@Entity
@Indexed
@ClassBridge(    //Mark the use of a class bridge 
		name="promotion",            //recommended namespace
		index=Index.UN_TOKENIZED,    //Class Bridges have properties similar to @Field 
		impl=ItemPromotionBridge.class )  //class bridge implementation used 
public class Item implements IItem {
	@Id @GeneratedValue
	@DocumentId
	private Integer id;
	
	@Fields({
		@Field(index=Index.TOKENIZED),
		@Field(name="title_sort", index=Index.UN_TOKENIZED)
	})
	@Boost(2)
	private String title;
	
	@Field
	private String description;
	
	@Field(index=Index.UN_TOKENIZED, store=Store.YES)
	private String ean;
	
	@Field
	@FieldBridge(                                         //property marked to use a bridge
			impl=PaddedRoundedPriceBridge.class,          //declare the bridge implementation
			params= { @Parameter(name="pad", value="3"),  //optionally provide parameters 
					  @Parameter(name="round", value="5") }
			)
	private double price;
	
	private String imageURL;
	
	@IndexedEmbedded    //mark the association for indexing 
	private Rating rating;
	
	@CollectionOfElements 
	@IndexedEmbedded        //collection elements embedded in the document
	private Collection<Country> distributedIn = new ArrayList<Country>();
	
	@Field(store=Store.YES)
	@FieldBridge(impl=MapKeyPerFieldBridge.class)   //bridge implementation
	@CollectionOfElements
	@MapKey
	private Map<String, String> ratePerDubbing = new HashMap<String, String>();
	
	@ManyToMany (targetEntity = Actor.class)
	@IndexedEmbedded  //embed actors when indexing
	private Set<IActor> actors = new HashSet<IActor>();
	
	@ManyToOne 
	@IndexedEmbedded   //embed director when indexing
	private Director director;
	
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#getActors()
     */
	public Set<IActor> getActors() {
		return actors;
	}

	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#setActors(java.util.Set)
     */
	public void setActors(Set<IActor> actors) {
		this.actors = actors;
	}

	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#getDirector()
     */
	public Director getDirector() {
		return director;
	}

	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#setDirector(com.manning.hsia.dvdstore.model.Director)
     */
	public void setDirector(Director director) {
		this.director = director;
	}

	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#getId()
     */
	public Integer getId() {
		return id;
	}
	
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#getEan()
     */
	public String getEan() {
		return ean;
	}
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#setEan(java.lang.String)
     */
	public void setEan(String ean) {
		this.ean = ean;
	}
	
	
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#setId(java.lang.Integer)
     */
	public void setId(Integer id) {
		this.id = id;
	}
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#getTitle()
     */
	public String getTitle() {
		return title;
	}
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#setTitle(java.lang.String)
     */
	public void setTitle(String title) {
		this.title = title;
	}
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#getDescription()
     */
	public String getDescription() {
		return description;
	}
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#setDescription(java.lang.String)
     */
	public void setDescription(String description) {
		this.description = description;
	}

	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#getImageURL()
     */
	public String getImageURL() {
		return imageURL;
	}
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#setImageURL(java.lang.String)
     */
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}

	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#getPrice()
     */
	public double getPrice() {
		return price;
	}

	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#setPrice(double)
     */
	public void setPrice(double price) {
		this.price = price;
	}

	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#getRatePerDubbing()
     */
	public Map<String, String> getRatePerDubbing() {
		return ratePerDubbing;
	}

	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#setRatePerDoubling(java.util.Map)
     */
	public void setRatePerDoubling(Map<String, String> ratePerDubbing) {
		this.ratePerDubbing = ratePerDubbing;
	}

	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#getRating()
     */
	public Rating getRating() {
		return rating;
	}

	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#setRating(com.manning.hsia.dvdstore.model.Rating)
     */
	public void setRating(Rating rating) {
		this.rating = rating;
	}

	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#getDistributedIn()
     */
	public Collection<Country> getDistributedIn() {
		return distributedIn;
	}

	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IItem#setDistributedIn(java.util.Collection)
     */
	public void setDistributedIn(Collection<Country> distributedIn) {
		this.distributedIn = distributedIn;
	}
	
}
