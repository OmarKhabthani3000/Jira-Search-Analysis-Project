package com.manning.hsia.dvdstore.model;

import java.util.Set;

public interface IActor
{

    public abstract Set<IItem> getItems();

    public abstract void setItems(Set<IItem> items);

    public abstract Integer getId();

    public abstract void setId(Integer id);

    public abstract String getName();

    public abstract void setName(String name);

}