package com.manning.hsia.dvdstore.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;


/**
 * Example 4.13
 */
@Entity
@Indexed
public class Actor implements IActor{
	@Id @GeneratedValue @DocumentId private Integer id;
	@Field private String name;
	
	@ManyToMany(mappedBy="actors", targetEntity = Item.class)
	@ContainedIn      //actor is contained in item index
	private Set<IItem> items = new HashSet<IItem>();
	
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IActor#getItems()
     */
	public Set<IItem> getItems() {
		return items;
	}
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IActor#setItems(java.util.Set)
     */
	public void setItems(Set<IItem> items) {
		this.items = items;
	}
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IActor#getId()
     */
	public Integer getId() {
		return id;
	}
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IActor#setId(java.lang.Integer)
     */
	public void setId(Integer id) {
		this.id = id;
	}
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IActor#getName()
     */
	public String getName() {
		return name;
	}
	/* (non-Javadoc)
     * @see com.manning.hsia.dvdstore.model.IActor#setName(java.lang.String)
     */
	public void setName(String name) {
		this.name = name;
	}
}
