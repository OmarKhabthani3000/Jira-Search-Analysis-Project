package test;

import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestMain
{
	public static final int ENTITY_COUNT = 10000;
	
	private static final Logger LOG = LoggerFactory.getLogger(TestMain.class);

	static SessionFactory sessionFactory;

	public static void main(String[] args) throws InterruptedException
	{
		AnnotationConfiguration cfg = new AnnotationConfiguration()
			.addAnnotatedClass(Test.class)
			.setProperty("hibernate.dialect", "org.hibernate.dialect.H2Dialect")
			.setProperty("hibernate.connection.driver_class", "org.h2.Driver")
			.setProperty("hibernate.connection.url", "jdbc:h2:mem:test")
			.setProperty("hibernate.connection.username", "sa")
			.setProperty("hibernate.connection.password", "sa")
			.setProperty("hibernate.hbm2ddl.auto", "create")
			.setProperty(
				"hibernate.search.default.directory_provider",
				"org.hibernate.search.store.RAMDirectoryProvider");
		sessionFactory = cfg.buildSessionFactory();

		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		for (int i = 1; i < ENTITY_COUNT; i++)
		{
			session.save(new Test("This is a test " + i));
			if (i % 1000 == 0)
			{
				LOG.info("Inserted " + i);
				tx.commit();
				tx = session.beginTransaction();
			}
		}
		tx.commit();
		session.close();

		Thread reindexThread = new Thread(new ReindexerThread());
		reindexThread.start();

		session = sessionFactory.openSession();
		ScrollableResults results = session.createCriteria(Test.class).scroll(ScrollMode.FORWARD_ONLY);
		for (int i = 1; results.next(); i++)
		{
			Test test = (Test) results.get(0);
			if (i % 1000 == 0)
			{
				LOG.info("Changed " + i);
				test.setText("This is a new test " + i);
				tx = session.beginTransaction();
				session.saveOrUpdate(test);
				tx.commit();
				tx = session.beginTransaction();
			}
		}
		tx.commit();
		session.close();

		reindexThread.join();
		sessionFactory.close();
	}
}

class ReindexerThread implements Runnable
{
	private static final Logger LOG = LoggerFactory.getLogger(ReindexerThread.class);

	public void run()
	{
		FullTextSession ftSession = Search.getFullTextSession(TestMain.sessionFactory.openSession());
		try
		{
			ftSession.createIndexer(Test.class).startAndWait();
		}
		catch (InterruptedException e)
		{
			LOG.error("Error reindexing Test", e);
		}
	}
}
