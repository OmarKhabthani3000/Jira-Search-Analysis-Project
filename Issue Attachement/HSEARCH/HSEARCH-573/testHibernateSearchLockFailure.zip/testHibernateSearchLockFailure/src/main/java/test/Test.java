package test;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;

@Entity
@Indexed
@GenericGenerator(strategy = "sequence", name = "TEST_SEQ")
public class Test
{
	@Id
	@DocumentId
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TEST_SEQ")
	private Long id;

	@Column(length = 50)
	@Field
	private String text;

	Test()
	{
		super();
	}

	public Test(String text)
	{
		this();
		this.text = text;
	}

	public Long getId()
	{
		return id;
	}

	public String getText()
	{
		return text;
	}

	public void setText(String text)
	{
		this.text = text;
	}

	@Override
	public String toString()
	{
		return "Test [id=" + id + ", text=" + text + "]";
	}
}
