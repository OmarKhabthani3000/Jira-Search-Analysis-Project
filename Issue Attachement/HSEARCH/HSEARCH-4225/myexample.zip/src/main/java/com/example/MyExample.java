package com.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.CacheMode;
import org.hibernate.FlushMode;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MyExample {

    private static final Logger LOGGER = LoggerFactory.getLogger(MyExample.class);
    private static final int BATCH_SIZE = 100;

    public static void main(String[] args) throws IOException {
        String indexBase = Files.createTempDirectory("MyExample-index").toString();
        LOGGER.debug("Using indexBase: {}", indexBase);
        Properties properties = new Properties();
        properties.put("hibernate.search.default.indexBase", indexBase);
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("com.example", properties);

        BufferedReader obj = new BufferedReader(new InputStreamReader(System.in));
        String str;
        long count = 0;
        do {
            System.out.println("Enter 's' to save a new entity.");
            System.out.println("Enter 'i' to re-index all entities.");
            System.out.println("Enter 'q' to quit.");
            str = obj.readLine();
            if (str.equals("s")) {
                // Create new entity (user interaction)
                try (Session session = entityManagerFactory.createEntityManager().unwrap(Session.class)) {
                    session.save(new MyEntity("A" + ++count));
                    session.flush();
                }
            } else if (str.equals("i")) {
                // Re-index entities outside a transaction. This will leave the SessionImpl instance in memory, although it is properly closed.
                try (Session session = entityManagerFactory.createEntityManager().unwrap(Session.class)) {
                    FullTextSession fullTextSession = Search.getFullTextSession(session);
                    fullTextSession.setFlushMode(FlushMode.MANUAL);
                    fullTextSession.setCacheMode(CacheMode.IGNORE);
                    ScrollableResults results = fullTextSession.createCriteria(MyEntity.class)
                            .setFetchSize(BATCH_SIZE)
                            .scroll(ScrollMode.FORWARD_ONLY);
                    int index = 0;
                    while (results.next()) {
                        index++;
                        LOGGER.debug("Re-indexing {}", results.get(0));
                        fullTextSession.index(results.get(0));
                        if (index % BATCH_SIZE == 0) {
                            fullTextSession.flushToIndexes();
                            fullTextSession.clear();
                        }
                    }
                    fullTextSession.flushToIndexes();
                    fullTextSession.clear();
                }
            }
        } while (!str.equals("q"));
        entityManagerFactory.close();
    }
}
