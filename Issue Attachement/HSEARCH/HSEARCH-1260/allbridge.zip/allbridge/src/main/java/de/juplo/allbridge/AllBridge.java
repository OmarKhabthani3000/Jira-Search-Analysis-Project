package de.juplo.allbridge;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.apache.lucene.document.Document;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.bridge.LuceneOptions;
import org.hibernate.search.bridge.ParameterizedBridge;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



/**
 *
 * @author kai
 */
public class AllBridge
    implements
      org.hibernate.search.bridge.FieldBridge,
      ParameterizedBridge
{
  private final static Logger log = LoggerFactory.getLogger(AllBridge.class);

  /**
   * Field-name of the all-property
   * Default: <code>ALL</code>
   */
  public final static String NAME_PROPERTY = "name";

  /**
   * Depth for recursion.
   * If set to <code>0</code>, the recursion is performed endlessly, which
   * might lead to problems with cyclic references.
   * Default: <code>0</code>
   */
  public final static String DEPTH_PROPERTY = "depth";

  private int depth = 0;


  @Override
  public void setParameterValues(Map<String, String> parameters)
  {
    try
    {
      if (parameters.get(DEPTH_PROPERTY) != null)
        depth = Integer.parseInt(parameters.get(DEPTH_PROPERTY));
    }
    catch (Exception e)
    {
      log.error("Could not parse depth-property: {}", parameters.get(DEPTH_PROPERTY));
    }
  }

  @Override
  public void set( String name, Object value, Document doc, LuceneOptions opts)
  {
    recursion(depth, name, value, doc, opts);
  }

  public void recursion(
      int depth,
      String name,
      Object value,
      Document doc,
      LuceneOptions opts
      )
  {
    if (value == null)
      return;

    Class<?> clazz;
    Collection collection = null;
    if (value instanceof Collection)
    {
      collection = (Collection)value;
      if (collection.isEmpty())
        return;

      clazz = collection.iterator().next().getClass();
    }
    else
      clazz = value.getClass();

    Set<Object> recursions = new HashSet<Object>();

    /** Alle @Field-Annotationen (private und öffentliche) einsammeln */
    do
    {
      for (java.lang.reflect.Field field : clazz.getDeclaredFields())
      {
        if (field.isAnnotationPresent(Field.class))
        {
          log.debug("Found annotated field {} in class {}", field, clazz);
          try
          {
            field.setAccessible(true);
            if (collection == null)
              handleField(name, field.get(value), doc, opts);
            else
              for (Object entry : collection)
                handleField(name, field.get(entry), doc, opts);
          }
          catch (IllegalAccessException e)
          {
            log.error("Could not access field {} of class {}: {}", field, clazz, e);
          }
        }
      }

      for (Method method : clazz.getDeclaredMethods())
      {
        if (method.isAnnotationPresent(Field.class))
        {
          log.debug("Found annotated field {} in class {}", method, clazz);
          try
          {
            if (method.getReturnType().equals(void.class))
            {
              String methodName = method.getName();
              if (!methodName.startsWith("set"))
              {
                log.error("Method {} has no return type and does not start with \"set\"", methodName);
                continue;
              }

              methodName = methodName.substring(3);
              try
              {
                method = method.getClass().getMethod("get" + methodName, (Class<?>[]) null);
              }
              catch (NoSuchMethodException e1)
              {
                try
                {
                  method = method.getClass().getMethod("is" + methodName, (Class<?>[]) null);
                }
                catch (NoSuchMethodException e2)
                {
                  log.error("Method {} has no return type and there does not exist an according parameterless method get{} or is{}", method.getName(), methodName, methodName);
                }
              }
            }

            method.setAccessible(true);
            if (collection == null)
              handleField(name, method.invoke(value, (Object[]) null), doc, opts);
            else
              for (Object entry : collection)
                handleField(name, method.invoke(entry, (Object[]) null), doc, opts);
          }
          catch(Exception e)
          {
            log.error("Error while accessing method {}: {}", method, e);
          }
        }
      }

      clazz = clazz.getSuperclass();
    }
    while (clazz != null);

    if (depth == 1)
    {
      /** Last recursion. Exit! */
      return;
    }

    for (Object recursion : recursions)
      recursion(depth-1, name, recursion, doc, opts);
  }

  private void handleField(String name, Object value, Document doc, LuceneOptions opts)
  {
    if (value == null)
      return;

    opts.addFieldToDocument(name, value.toString(), doc);
  }
}
