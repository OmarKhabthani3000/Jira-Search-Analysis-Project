package de.juplo.allbridge.test;


import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.hibernate.search.exception.ErrorContext;
import org.hibernate.search.exception.ErrorHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



/**
 * ErrorHandler, that throws an exception for every error.
 * @author kai
 */
public class CollectErrorsErrorHandler implements ErrorHandler
{
  private final static Logger log =
      LoggerFactory.getLogger(CollectErrorsErrorHandler.class);

  public final static Set<String> errors = new HashSet<String>();


  public static boolean hasErrors()
  {
    return !errors.isEmpty();
  }

  public static String getErrorMessage()
  {
    StringBuilder builder = new StringBuilder();

    Iterator<String> iterator = errors.iterator();
    do
    {
      builder.append(iterator.next());
      if (iterator.hasNext())
        builder.append(", ");
    }
    while (iterator.hasNext());

    errors.clear();

    return builder.toString();
  }

  @Override
  public void handle(ErrorContext context)
  {
    log.debug(context.toString(), context.getThrowable());
    errors.add(context.toString());
  }

  @Override
  public void handleException(String errorMsg, Throwable exception)
  {
    log.debug(errorMsg, exception);
    errors.add(errorMsg + ": " + exception.getMessage());
  }
}
