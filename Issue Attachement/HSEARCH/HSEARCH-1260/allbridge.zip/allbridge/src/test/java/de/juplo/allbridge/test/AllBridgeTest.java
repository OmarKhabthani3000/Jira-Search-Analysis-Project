package de.juplo.allbridge.test;


import java.util.Properties;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.search.Search;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



/**
 * @author kai
 */
public class AllBridgeTest
{
  private final static Logger log = LoggerFactory.getLogger(AllBridgeTest.class);


  /**
   * This test-case raises no exception.
   * @throws Exception
   */
  @Test
  public void testA() throws Exception
  {
    log.info("Test A");
    Properties properties = new Properties();
    properties.load(AllBridgeTest.class.getResourceAsStream("/hibernate.properties"));
    Configuration configuration = new Configuration();
    configuration.addProperties(properties);
    configuration.addAnnotatedClass(de.juplo.allbridge.test.a.Foo.class);
    configuration.addAnnotatedClass(de.juplo.allbridge.test.a.Bar.class);
    SessionFactory sessionFactory = configuration.buildSessionFactory();
    Search
        .getFullTextSession(sessionFactory.openSession())
        .createIndexer()
        .purgeAllOnStart(true)
        .startAndWait();
    if (CollectErrorsErrorHandler.hasErrors())
      Assert.fail(CollectErrorsErrorHandler.getErrorMessage());
  }

  /**
   * This test-case raises the LazyInitializationException in MassIndexer.
   * @throws Exception
   */
  @Test
  public void testB() throws Exception
  {
    log.info("Test B");
    Properties properties = new Properties();
    properties.load(AllBridgeTest.class.getResourceAsStream("/hibernate.properties"));
    Configuration configuration = new Configuration();
    configuration.addProperties(properties);
    configuration.addAnnotatedClass(de.juplo.allbridge.test.b.Foo.class);
    configuration.addAnnotatedClass(de.juplo.allbridge.test.b.Bar.class);
    configuration.addAnnotatedClass(de.juplo.allbridge.test.b.FooBar.class);
    SessionFactory sessionFactory = configuration.buildSessionFactory();
    Search
        .getFullTextSession(sessionFactory.openSession())
        .createIndexer()
        .purgeAllOnStart(true)
        .startAndWait();
    if (CollectErrorsErrorHandler.hasErrors())
      Assert.fail(CollectErrorsErrorHandler.getErrorMessage());
  }
}
