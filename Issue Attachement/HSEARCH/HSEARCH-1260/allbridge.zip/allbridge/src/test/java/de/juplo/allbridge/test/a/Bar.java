package de.juplo.allbridge.test.a;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import org.hibernate.search.annotations.Field;



/**
 * Bar
 * @author kai
 */
@Entity(name="bar_a")
public class Bar
{
  @Id
  private Long id;
  @Field(name="ALL")
  public String name;
  @ManyToOne
  public Foo foo;
}
