package de.juplo.allbridge.test.b;


import de.juplo.allbridge.AllBridge;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.annotations.IndexedEmbedded;



/**
 * Bar
 * @author kai
 */
@Entity(name="bar_b")
public class Bar
{
  @Id
  private Long id;
  @Field(name="ALL")
  public String name;
  @OneToOne(mappedBy="bar")
  public Foo foo;
  @OneToMany(mappedBy="bar")
  @IndexedEmbedded(prefix="foobar.")
  @Field(name="ALL", bridge=@FieldBridge(impl=AllBridge.class))
  public Set<FooBar> foobars;
}
