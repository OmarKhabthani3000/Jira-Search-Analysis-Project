package de.juplo.allbridge.test.b;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import org.hibernate.search.annotations.Field;



/**
 *
 * @author kai
 */
@Entity(name="foobar_b")
public class FooBar
{
  @Id
  private Long id;
  @Field(name="ALL")
  public String name;
  @ManyToOne
  public Bar bar;
}
