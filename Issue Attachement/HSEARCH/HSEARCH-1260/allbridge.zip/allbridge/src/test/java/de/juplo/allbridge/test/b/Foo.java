package de.juplo.allbridge.test.b;


import de.juplo.allbridge.AllBridge;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;



/**
 * Foo
 * @author kai
 */
@Entity(name="foo_b")
@Indexed
public class Foo
{
  @Id
  private Long id;
  @Field(name="ALL")
  public String name;
  @OneToOne
  @IndexedEmbedded(prefix="bar.")
  @Field(name="ALL", bridge=@FieldBridge(impl=AllBridge.class))
  public Bar bar;
}
