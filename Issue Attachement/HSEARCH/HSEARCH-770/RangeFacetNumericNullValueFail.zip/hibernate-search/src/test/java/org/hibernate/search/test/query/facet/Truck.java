/*
 * for testing faceting with Integer fields with null values
 */

package org.hibernate.search.test.query.facet;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.NumericField;

@Entity
@Indexed
public class Truck {
	@Id
	@GeneratedValue
	private int id;

	@Field(index = Index.UN_TOKENIZED)
	@NumericField
	private Integer horsePower;

	private Truck() {
	}

	public Truck(Integer horsePower) {
		this.horsePower = horsePower;
	}

	public int getId() {
		return id;
	}
	
	public Integer getHorsePower() {
		return horsePower;
	}


	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append( "Truck" );
		sb.append( "{id=" ).append( id );
		sb.append( ", horsePower='" ).append( horsePower );
		sb.append( '}' );
		return sb.toString();
	}
}


