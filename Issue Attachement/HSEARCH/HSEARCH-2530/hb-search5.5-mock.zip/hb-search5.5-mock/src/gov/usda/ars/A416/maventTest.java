package gov.usda.ars.A416;

import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.search.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.query.dsl.QueryBuilder;

public class maventTest {

	public static void main(String[] args) {
		// testHibernate();
		// testHibernateSearch(); // (old way) 4.x
		// testHibernateSearch2(); // new way for 5.5.5
		// testHibernateSearchUsingJPA();

	}

	private static void testHibernateSearchUsingJPA() {

	}

	private static void testHibernateSearch2() {
		FullTextSession fullTextSession = HibernateUtil.getFullTextSession();
		Transaction tx = fullTextSession.beginTransaction();

		// create native Lucene query using the query DSL
		// alternatively you can write the Lucene query using the Lucene query
		// parser
		// or the Lucene programmatic API. The Hibernate Search DSL is
		// recommended though
		QueryBuilder qb = fullTextSession.getSearchFactory()
				.buildQueryBuilder().forEntity(A416_GoAris_V.class).get();
		org.apache.lucene.search.Query query = qb.keyword()
				.onFields("approach").matching("approach").createQuery();

		// wrap Lucene query in a org.hibernate.Query
		org.hibernate.Query hibQuery = fullTextSession.createFullTextQuery(
				query, A416_GoAris_V.class);

		hibQuery.setFirstResult(0);
		hibQuery.setMaxResults(5);

		// execute search
		List result = hibQuery.list();

		System.out.println(result);

		fullTextSession.close();

	}

	private static void testHibernateSearch() {
		FullTextSession fullTextSession = HibernateUtil.getFullTextSession();
		fullTextSession.getTransaction().begin();

		QueryBuilder queryBuilder = fullTextSession.getSearchFactory()
				.buildQueryBuilder().forEntity(A416_GoAris_V.class).get();

		Query luceneQuery = queryBuilder.keyword().onFields("approach")
				.matching("cow").createQuery();

		FullTextQuery fullTextQuery = fullTextSession.createFullTextQuery(
				luceneQuery, A416_GoAris_V.class).setProjection(
				FullTextQuery.DOCUMENT_ID, FullTextQuery.EXPLANATION,
				FullTextQuery.THIS);

		List<Object[]> hitList = new ArrayList<Object[]>();
		try {
			hitList = fullTextQuery.list();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			fullTextSession.getTransaction().commit();
		}

		System.out.println(hitList);

	}

	private static void testHibernate() {
		Session hbSession = HibernateUtil.getSession();
		hbSession.beginTransaction();

		String hql = "from A416_GoAris_V a where a.accn_No = '400389'";
		org.hibernate.Query query = hbSession.createQuery(hql);
		List<String> results = query.list();

		if (results != null) {
			List<String> listOfPrjTitle = (List<String>) results;

			for (String each : listOfPrjTitle) {
				System.out.println(each);
			}
		}

		hbSession.close();
	}
}
