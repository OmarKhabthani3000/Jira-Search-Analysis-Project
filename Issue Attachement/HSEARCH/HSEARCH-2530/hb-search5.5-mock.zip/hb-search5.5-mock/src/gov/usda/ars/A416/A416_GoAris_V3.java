package gov.usda.ars.A416;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;

@Entity
@Indexed
public class A416_GoAris_V3 {

	@Id
	@DocumentId
	// @Field//(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private Integer accn_No;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String prj_Title;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String modecode;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String city;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String perf_Inst_Long_Desc;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String state_Name;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String country_Desc;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String project_Number;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String agreement_Number;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String approach;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String objective;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String outgoing_Relation_To_Parent;

	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String outgoing_inhouse_prj;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String outgoing_inhouse_accn;

	@Field(index = Index.YES, analyze = Analyze.NO, store = Store.NO)
	private String seq_No_425;

	public String getSeq_No_425() {
		return seq_No_425;
	}

	public void setSeq_No_425(String seq_No_425) {
		this.seq_No_425 = seq_No_425;
	}

	public Integer getAccn_No() {
		return accn_No;
	}

	public void setAccn_No(Integer accn_No) {
		this.accn_No = accn_No;
	}

	public String getPrj_Title() {
		return prj_Title;
	}

	public void setPrj_Title(String prj_Title) {
		this.prj_Title = prj_Title;
	}

	public String getModecode() {
		return modecode;
	}

	public void setModecode(String modecode) {
		this.modecode = modecode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPerf_Inst_Long_Desc() {
		return perf_Inst_Long_Desc;
	}

	public void setPerf_Inst_Long_Desc(String perf_Inst_Long_Desc) {
		this.perf_Inst_Long_Desc = perf_Inst_Long_Desc;
	}

	public String getState_Name() {
		return state_Name;
	}

	public void setState_Name(String state_Name) {
		this.state_Name = state_Name;
	}

	public String getCountry_Desc() {
		return country_Desc;
	}

	public void setCountry_Desc(String country_Desc) {
		this.country_Desc = country_Desc;
	}

	public String getProject_Number() {
		return project_Number;
	}

	public void setProject_Number(String project_Number) {
		this.project_Number = project_Number;
	}

	public String getAgreement_Number() {
		return agreement_Number;
	}

	public void setAgreement_Number(String agreement_Number) {
		this.agreement_Number = agreement_Number;
	}

	public String getApproach() {
		return approach;
	}

	public void setApproach(String approach) {
		this.approach = approach;
	}

	public String getObjective() {
		return objective;
	}

	public void setObjective(String objective) {
		this.objective = objective;
	}

	public String getOutgoing_Relation_To_Parent() {
		return outgoing_Relation_To_Parent;
	}

	public void setOutgoing_Relation_To_Parent(
			String outgoing_Relation_To_Parent) {
		this.outgoing_Relation_To_Parent = outgoing_Relation_To_Parent;
	}

	public String getOutgoing_inhouse_prj() {
		return outgoing_inhouse_prj;
	}

	public void setOutgoing_inhouse_prj(String outgoing_inhouse_prj) {
		this.outgoing_inhouse_prj = outgoing_inhouse_prj;
	}

	public String getOutgoing_inhouse_accn() {
		return outgoing_inhouse_accn;
	}

	public void setOutgoing_inhouse_accn(String outgoing_inhouse_accn) {
		this.outgoing_inhouse_accn = outgoing_inhouse_accn;
	}

	@Override
	public String toString() {
		return "A416_GoAris_V [accn_No=" + accn_No + ", prj_Title=" + prj_Title
				+ ", modecode=" + modecode + ", city=" + city
				+ ", perf_Inst_Long_Desc=" + perf_Inst_Long_Desc
				+ ", state_Name=" + state_Name + ", country_Desc="
				+ country_Desc + ", project_Number=" + project_Number
				+ ", agreement_Number=" + agreement_Number + ", approach="
				+ approach + ", objective=" + objective
				+ ", outgoing_Relation_To_Parent="
				+ outgoing_Relation_To_Parent + "]";
	}

}
