package hb.search.mock;

import gov.usda.ars.A416.HibernateUtil;

import java.util.List;

import org.hibernate.Transaction;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.query.dsl.QueryBuilder;

public class Test {
	public static void main(String[] args) {
		testHibernateSearch();
	}

	private static void testHibernateSearch() {
		FullTextSession fullTextSession = HibernateUtil.getFullTextSession();
		Transaction tx = fullTextSession.beginTransaction();

		QueryBuilder qb = fullTextSession.getSearchFactory()
				.buildQueryBuilder().forEntity(Company.class).get();
		org.apache.lucene.search.Query query = qb.keyword().onFields("name")
				.matching("Paul").createQuery();

		org.hibernate.Query hibQuery = fullTextSession.createFullTextQuery(
				query, Company.class);

		hibQuery.setFirstResult(0);
		hibQuery.setMaxResults(5);

		@SuppressWarnings("unchecked")
		List<Company> result = hibQuery.list();

		System.out.println(result.get(0).getAddress());

		fullTextSession.close();

	}
}
