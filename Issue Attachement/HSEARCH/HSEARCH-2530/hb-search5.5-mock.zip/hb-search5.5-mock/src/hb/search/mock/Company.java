package hb.search.mock;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;

/*
 * @author RAdhikari
 
 */
@Entity
@Indexed
public class Company {
	@Id
	@DocumentId
	private Integer id;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String name;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String address;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
