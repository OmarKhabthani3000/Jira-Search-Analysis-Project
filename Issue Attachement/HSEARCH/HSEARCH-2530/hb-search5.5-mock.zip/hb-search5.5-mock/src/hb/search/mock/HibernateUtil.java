package hb.search.mock;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

/**
 * Helper class to get hibernate-session full-text-session. Hibernate-session
 * helps to get connected with database. Full-text-session help to get connected
 * both with database as well as lucene-index store
 * 
 * @author RAdhikari
 * 
 */
public class HibernateUtil {

	private static SessionFactory sessionFactory = null;

	private static SessionFactory configureSessionFactory()
			throws HibernateException {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate-search.cfg.xml");

		// sessionFactory = configuration.buildSessionFactory();
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
				.applySettings(configuration.getProperties()).build();
		// logger.info("ServiceRegistry created successfully");
		sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		// logger.info("SessionFactory created successfully");

		return sessionFactory;
	}

	static {
		configureSessionFactory();
	}

	private HibernateUtil() {
	}

	public static Session getSession() {
		return sessionFactory.getCurrentSession();
	}

	/*
	 * public static FullTextSession getFullTextSession() { if (sessionFactory
	 * == null) configureSessionFactory(); return
	 * Search.getFullTextSession(getSession()); }
	 */

}
