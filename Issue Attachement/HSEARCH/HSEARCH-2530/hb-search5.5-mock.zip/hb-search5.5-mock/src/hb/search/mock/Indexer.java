package hb.search.mock;

import org.hibernate.Session;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;

public class Indexer {

	private static void doIndex() throws InterruptedException {

		Session session = HibernateUtil.getSession();

		Long startTime = System.currentTimeMillis();
		FullTextSession fullTextSession = Search.getFullTextSession(session);
		fullTextSession.createIndexer().startAndWait();

		fullTextSession.close();
		Long endTime = System.currentTimeMillis();

		Long secs = (endTime - startTime)/1000;
		Long mins = secs / 60;
		Long remSecs = secs - mins * 60;
		System.out.println("Total run time: " + mins + " mins, " + remSecs
				+ " secs");

	}

	public static void main(String[] args) throws InterruptedException {
		 doIndex();
	}
}
