import junit.framework.TestCase;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.HSQLDialect;
import org.hibernate.jdbc.Work;

public class ProxyTestCase extends TestCase {

	private SessionFactory sessionFactory;
	private Session session;

	public ProxyTestCase(String string) {
		super(string);
	}

	@Override
	protected void setUp() throws Exception {
		AnnotationConfiguration configuration = new AnnotationConfiguration();
		configuration.setProperty("hibernate.bytecode.use_reflection_optimizer","true");
		configuration.setProperty(Environment.DRIVER, "org.hsqldb.jdbcDriver");
		configuration.setProperty(Environment.URL, "jdbc:hsqldb:mem:ProxyTestCase");
		configuration.setProperty(Environment.USER, "sa");
		configuration.setProperty(Environment.DIALECT, HSQLDialect.class.getName());
		configuration.setProperty(Environment.SHOW_SQL, "true");
		configuration.setProperty("hibernate.search.default.directory_provider",
			"org.hibernate.search.store.RAMDirectoryProvider");
		
		configuration.addAnnotatedClass(Comment.class);
		configuration.addAnnotatedClass(Profile.class);
		sessionFactory = configuration.buildSessionFactory();
		session = sessionFactory.openSession();

		Transaction tx = session.beginTransaction();
		session.doWork(new Work() {
			@Override
			public void execute(Connection connection) throws SQLException
			{
				Statement statement = connection.createStatement();
				statement.execute("create table profile (profileid BIGINT IDENTITY)");
				statement.execute("create table comment (commentid BIGINT IDENTITY, profileid BIGINT, rootid BIGINT, content CHARACTER(100))");
			}
		});
		tx.commit();
		session.close();
	}

	@Override
	protected void tearDown() throws Exception {
		session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.doWork(new Work() {
			@Override
			public void execute(Connection connection) throws SQLException
			{
				Statement statement = connection.createStatement();
				statement.execute("drop table profile");
				statement.execute("drop table comment");
			}
		});
		tx.commit();
		session.close();
	}

	public void testDeleteParent() {
		createTestData();
		
		session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		IComment c = (IComment)session.load(Comment.class, 2);
		session.delete(c);
		tx.commit();
		session.close();
	}
	
	public void createTestData() {
		session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		IProfile p = new Profile();
		p.setId(1);
		session.save(p);
		
		IComment c1 = new Comment();
		c1.setId(2);
		c1.setProfile((IProfile)session.get(Profile.class, 1));
		c1.setContent("c1");
		c1.setRootComment(null);
		session.save(c1);
		
		IComment c2 = new Comment();
		c2.setId(3);
		c2.setProfile((IProfile)session.get(Profile.class, 1));
		c2.setContent("c2");
		c2.setRootComment(c1);
		session.save(c2);
		
		IComment c3 = new Comment();
		c3.setId(4);
		c3.setProfile((IProfile)session.get(Profile.class, 1));
		c3.setContent("c3");
		c3.setRootComment(c1);
		session.save(c3);
		
		tx.commit();
		session.close();
	}

}
