import java.util.Set;

public interface IProfile {

	public Integer getId();
	public void setId(Integer id);
	
	public Set<IComment> getComments();
	public void setComments(Set<IComment> c);
}
