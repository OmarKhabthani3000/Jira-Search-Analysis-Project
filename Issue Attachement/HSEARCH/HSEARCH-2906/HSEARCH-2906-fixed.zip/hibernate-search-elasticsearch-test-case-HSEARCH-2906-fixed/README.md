[![Build Status](https://travis-ci.org/frekele/hibernate-search-elasticsearch-test-case.svg?branch=master)](https://travis-ci.org/frekele/hibernate-search-elasticsearch-test-case)


# hibernate-search + elasticsearch 5.x.x - Test Case

### HSEARCH-2906