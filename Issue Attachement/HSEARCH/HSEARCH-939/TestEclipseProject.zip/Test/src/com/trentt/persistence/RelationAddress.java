package com.trentt.persistence;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;


@Indexed
@Entity
@Table(name="RelationAddresses")
public class RelationAddress implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int relationAddressesID;

	@Field(index=Index.TOKENIZED, store=Store.NO)
	private String address;

	@ContainedIn
    @ManyToOne
	@JoinColumn(name="RelationsID")
	private Relation relation;

    public RelationAddress() {
    }

	public int getRelationAddressesID() {
		return this.relationAddressesID;
	}

	public void setRelationAddressesID(int relationAddressesID) {
		this.relationAddressesID = relationAddressesID;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Relation getRelation() {
		return this.relation;
	}

	public void setRelation(Relation relation) {
		this.relation = relation;
	}
	
}