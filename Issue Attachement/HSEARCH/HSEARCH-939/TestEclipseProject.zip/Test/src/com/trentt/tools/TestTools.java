package com.trentt.tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.NamingException;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.query.dsl.QueryBuilder;

import com.trentt.persistence.Relation;
import com.trentt.persistence.RelationAddress;

public class TestTools {
	private static TestTools tools;
	
	private Session session;
	private Connection conn;
	
	private void run(){
		System.out.println(System.getProperty("java.vm.version"));
		try{
			connect();
			
			// Make sure address field is set to value 'AStreet'
			updateAddress(1, "AStreet");
			
			// Create fresh full index
			createHibernateSearchIndex();
		
			// Try finding relation by 'AStreet'
			int resultSize = performSearch("AStreet");
			System.out.println("Searching for Relation by address value 'AStreet'"); 
			System.out.println("	Found results: " + resultSize + " (1 expected)");
		
			// Alter the address and change 'AStreet' to 'BStreet'
			updateAddress(1, "BStreet");
		
			// reindex the changed record only 
			updateIndex(RelationAddress.class, 1);
			
			// Try finding relation by 'AStreet'
			resultSize = performSearch("AStreet");
			System.out.println("Searching for Relation by address value 'AStreet'"); 
			System.out.println("	Found results: " + resultSize + " (0 expected)");
			
			// Try finding relation by 'AStreet'
			resultSize = performSearch("BStreet");
			System.out.println("Searching for Relation by address value 'BStreet'");
			System.out.println("	Found results: " + resultSize + " (1 expected)");
			
			// reindex the full relation entity
			updateIndex(Relation.class, 1);
			
			// Try finding relation by 'AStreet'
			resultSize = performSearch("AStreet");
			System.out.println("Searching for Relation by address value 'AStreet'"); 
			System.out.println("	Found results: " + resultSize + " (0 expected)");
			
			// Try finding relation by 'AStreet'
			resultSize = performSearch("BStreet");
			System.out.println("Searching for Relation by address value 'BStreet'");
			System.out.println("	Found results: " + resultSize + " (1 expected)");
		}catch(NamingException e){
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private void updateIndex(Class<?> entityClass, int id){
		System.out.println("About to update the index for id: " + id + " (class: " + entityClass.toString() + ")");
		FullTextSession fullTextSession = Search.getFullTextSession(session);
		Transaction tx = fullTextSession.beginTransaction();
		
		Object address = fullTextSession.load(entityClass, id);
		fullTextSession.index(address);
					
		System.out.println("	Update done. Performing commit()...");
		
		tx.commit();
	}
	
	private void updateAddress(int id, String newAddress) throws SQLException{
		System.out.println("Updating address (id: " + id + ") to value: '" + newAddress + "' (through sql)");
		PreparedStatement stmt = conn.prepareStatement("UPDATE RelationAddresses SET Address = ? WHERE RelationAddressesID = ?");
		stmt.setString(1, newAddress);
		stmt.setInt(2, id);
		stmt.execute();
	}
	
	private void createHibernateSearchIndex() throws InterruptedException{
		FullTextSession fullTextSession = Search.getFullTextSession(session);
		fullTextSession.createIndexer().startAndWait();
		System.out.println("New full index created");
	}
	
	private int performSearch(String searchFor){
		FullTextSession fullTextSession = Search.getFullTextSession(session);
		
		String[] onFields = new String[]{"name", "relationAddresses.address"};
    	
    	QueryBuilder qb = fullTextSession.getSearchFactory().buildQueryBuilder().forEntity(Relation.class).get();
		org.apache.lucene.search.Query luceneQuery = qb.keyword().onFields(onFields).matching(searchFor).createQuery();
		
		FullTextQuery persistenceQuery = fullTextSession.createFullTextQuery(luceneQuery, Relation.class);
		
		// Execute search
		// List<Object> result = persistenceQuery.getResultSize();
		return persistenceQuery.getResultSize();
	}
	
	private void connect() throws NamingException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
		SessionFactory sessionFactory = new Configuration().configure("META-INF/hibernate.cfg.xml").buildSessionFactory();
		session = sessionFactory.openSession();
		
		Properties props = new Configuration().configure("META-INF/hibernate.cfg.xml").getProperties();
		
		Class.forName ("com.mysql.jdbc.Driver").newInstance ();
		String dbUrl = props.get("hibernate.connection.url").toString();
		String dbUsername = props.get("hibernate.connection.username").toString();
		String dbPassword = props.get("hibernate.connection.password").toString();
		
		conn = DriverManager.getConnection (dbUrl, dbUsername, dbPassword);
	}
	
	public static void main(String[] args) {
		if(tools == null) tools = new TestTools();
		tools.run();
	}
}
