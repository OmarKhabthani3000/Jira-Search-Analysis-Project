package com.trentt.persistence;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Store;

import java.util.Set;


@Indexed
@Entity
@Table(name="Relations")
public class Relation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int relationsID;

	@Field(index=Index.TOKENIZED, store=Store.NO)
	private String name;
	
	@OneToMany(mappedBy="relation")
	private Set<Member> members;

	@IndexedEmbedded
	@OneToMany(mappedBy="relation")
	private Set<RelationAddress> relationAddresses;

    public Relation() {
    }

	public int getRelationsID() {
		return this.relationsID;
	}

	public void setRelationsID(int relationsID) {
		this.relationsID = relationsID;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Member> getMembers() {
		return this.members;
	}

	public void setMembers(Set<Member> members) {
		this.members = members;
	}
	
	public Set<RelationAddress> getRelationAddresses() {
		return this.relationAddresses;
	}

	public void setRelationAddresses(Set<RelationAddress> relationAddresses) {
		this.relationAddresses = relationAddresses;
	}
	
}