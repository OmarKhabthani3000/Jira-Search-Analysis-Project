package com.trentt.persistence;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the Members database table.
 * 
 */
@Entity
@Table(name="Members")
public class Member implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int membersID;

	private String memberCode;

	//bi-directional many-to-one association to Relation
    @ManyToOne
	@JoinColumn(name="RelationsID")
	private Relation relation;

    public Member() {
    }

	public int getMembersID() {
		return this.membersID;
	}

	public void setMembersID(int membersID) {
		this.membersID = membersID;
	}

	public String getMemberCode() {
		return this.memberCode;
	}

	public void setMemberCode(String memberCode) {
		this.memberCode = memberCode;
	}

	public Relation getRelation() {
		return this.relation;
	}

	public void setRelation(Relation relation) {
		this.relation = relation;
	}
	
}