package org.test.hibsearch.action;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.test.hibsearch.model.Color;

@Stateless
public class ObjectManagementServerBean implements ObjectManagementServer {

    @PersistenceContext
    private EntityManager em;

    @Override
    public void createColor(Color color) {
        em.persist(color);
        em.flush();
    }

    @Override
    public void deleteColor(Color color) {
        em.merge(color);
        em.remove(color);
        em.flush();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Color> findColors() {
        return em.createQuery("select c from Color c").getResultList();
    }

    @Override
    public void updateColor(Color color) {
        color = em.merge(color);
        em.flush();
    }

}
