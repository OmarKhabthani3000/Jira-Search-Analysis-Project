package org.test.hibsearch.action;

import javax.security.auth.Destroyable;


public interface ObjectManagement extends Destroyable {

    void findColors();

    void addColor();

    void removeColor();

    void updateColor();

}
