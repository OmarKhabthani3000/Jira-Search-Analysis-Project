package org.test.hibsearch.action;

import javax.ejb.Local;

@Local
public interface Authenticator {

    boolean authenticate();

}
