package org.test.hibsearch.action;

import java.util.List;

import javax.ejb.Local;

import org.test.hibsearch.model.Color;

@Local
public interface ObjectManagementServer {

    void createColor(Color color);

    void deleteColor(Color color);

    List<Color> findColors();

    void updateColor(Color color);

}
