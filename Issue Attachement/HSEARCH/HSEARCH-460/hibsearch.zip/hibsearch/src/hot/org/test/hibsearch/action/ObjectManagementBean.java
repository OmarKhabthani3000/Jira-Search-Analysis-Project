package org.test.hibsearch.action;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Remove;
import javax.ejb.Stateful;
import javax.security.auth.DestroyFailedException;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Destroy;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.test.hibsearch.model.Color;

@Stateful
@Scope(ScopeType.CONVERSATION)
@Name("objectManagementBean")
public class ObjectManagementBean implements ObjectManagement {

    @DataModelSelection
    private Color selectedColor;

    @DataModel
    private List<Color> colors;

    @EJB
    private ObjectManagementServer objectManagementServer;

    @Override
    public void addColor() {
        Color color = new Color();
        String colorName = Color.ColorName.values()[(int) (Math.random() * Color.ColorName.values().length)].toString();
        color.setName(colorName);
        objectManagementServer.createColor(color);
        colors = null;
    }

    @Override
    public void updateColor() {
        if (selectedColor != null) {
            String colorName = Color.ColorName.values()[(int) (Math.random() * Color.ColorName.values().length)].toString();
            selectedColor.setName(colorName);
            objectManagementServer.updateColor(selectedColor);
            colors = null;
        }
    }

    @Factory("colors")
    @Override
    public void findColors() {
        colors = objectManagementServer.findColors();
    }

    @Override
    public void removeColor() {
        if (selectedColor != null) {
            objectManagementServer.deleteColor(selectedColor);
            colors = null;
        }
    }

    @Destroy
    @Remove
    @Override
    public void destroy() throws DestroyFailedException {
    }

    @Override
    public boolean isDestroyed() {
        return false;
    }

}
