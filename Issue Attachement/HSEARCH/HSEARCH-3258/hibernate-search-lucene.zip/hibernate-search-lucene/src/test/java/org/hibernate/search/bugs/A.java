package org.hibernate.search.bugs;

import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
@Indexed
@Table(name = "[a]")
public class A {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "[id]")
    private Integer id;

    @Column(name = "[title]")
    private String title;

    @IndexedEmbedded(includeEmbeddedObjectId = true, includePaths = {"id","c.id"})
    @OneToMany(mappedBy = "a", fetch = FetchType.LAZY)
    private Collection<B> bCollection;

    //======================================//
    public A(String title) {
        this.title = title;
    }

    public A() {
    }

    //======================================//
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Collection<B> getaCollection() {
        return getbCollection();
    }

    public void setaCollection(Collection<B> aCollection) {
        this.setbCollection(aCollection);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Collection<B> getbCollection() {
        return bCollection;
    }

    public void setbCollection(Collection<B> bCollection) {
        this.bCollection = bCollection;
    }

}
