package org.hibernate.search.bugs;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.apache.lucene.search.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
//import org.hibernate.search.testsupport.TestForIssue;
import org.junit.Test;

public class YourTestCase extends SearchTestBase {

    @Override
    public Class<?>[] getAnnotatedClasses() {
        return new Class<?>[]{A.class, B.class, C.class};
    }

    @Test
//    @TestForIssue(jiraKey = "HSEARCH-NNNNN") // Please fill in the JIRA key of your issue
    @SuppressWarnings("unchecked")
    public void testYourBug() {
        try (Session s = getSessionFactory().openSession()) {

            C c1 = new C("1");
            C c2 = new C("2");
            C c3 = new C("3");

            A a = new A("1");

            Transaction tx = s.beginTransaction();
            s.persist(c1);
            s.persist(c2);
            s.persist(c3);

            s.persist(a);
            tx.commit();

            //a=> where bCollection.c.id = c1.id
            // expect false => result false
            List<A> result = searchByCId(s, c1);
            assertEquals(false, result.size() > 0);

            //Now I create new b that related to a and c1
            B b = new B(a, c1);
            Transaction tx2 = s.beginTransaction();
            s.persist(b);
            tx2.commit();

            //a=> where bCollection.c.id = c1.id
            // expect true => result false ??
            List<A> result2 = searchByCId(s, c1);
            assertEquals(true, result2.size() > 0);

            //rebuild the Index files
            try {
                Search.getFullTextSession(s).createIndexer().purgeAllOnStart(true).startAndWait();
            } catch (InterruptedException e) {

            }
            //a=> where bCollection.c.id = c1.id
            // expect true => result true
            List<A> result3 = searchByCId(s, c1);
            assertEquals(true, result3.size() > 0);

        }
    }

    private List<A> searchByCId(final Session s, C c1) {
        FullTextSession session = Search.getFullTextSession(s);
        QueryBuilder qb = session.getSearchFactory().buildQueryBuilder().forEntity(A.class).get();
        Query query = qb.keyword().onField("bCollection.c.id").matching(c1.getId()).createQuery();
        List<A> result = (List<A>) session.createFullTextQuery(query).getResultList();
        return result;
    }

}
