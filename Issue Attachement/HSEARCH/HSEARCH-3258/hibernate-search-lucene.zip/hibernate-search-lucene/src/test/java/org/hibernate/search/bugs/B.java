/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.hibernate.search.bugs;

import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
@Indexed
@Table(name = "[b]")
public class B {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @ContainedIn
    @IndexedEmbedded(includeEmbeddedObjectId = true, includePaths = {"id"})
    @JoinColumn(name = "[a_id]", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private A a;

    @IndexedEmbedded(includeEmbeddedObjectId = true, includePaths = {"id"})
    @JoinColumn(name = "[c_id]", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private C c;

    //======================================//
    public B(A a, C c) {
        this.a = a;
        this.c = c;
    }

    public B() {
    }

    //======================================//
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public A getA() {
        return a;
    }

    public void setA(A a) {
        this.a = a;
    }

    public C getC() {
        return c;
    }

    public void setC(C c) {
        this.c = c;
    }

}
