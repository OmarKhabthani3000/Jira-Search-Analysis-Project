/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.hibernate.search.bugs;

import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Indexed;

/**
 *
 * @author Dev1
 */
@Entity
public class C {

    public C() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;

    @Column(name = "[title]")
    private String title;

    @ContainedIn
    @OneToMany(mappedBy = "c", fetch = FetchType.LAZY)
    private Collection<B> bCollection;

    //======================================//
    public C(String title) {
        this.title = title;
    }

    //======================================//
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Collection<B> getbCollection() {
        return bCollection;
    }

    public void setbCollection(Collection<B> bCollection) {
        this.bCollection = bCollection;
    }
}
