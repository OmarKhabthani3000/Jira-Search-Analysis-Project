/*
 * JBoss, Home of Professional Open Source
 * Copyright 2008-12, Red Hat Middleware LLC, and others contributors as indicated
 * by the @authors tag. All rights reserved.
 * See the copyright.txt in the distribution for a
 * full listing of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU Lesser General Public License, v. 2.1.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License,
 * v.2.1 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 */
package issue;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static org.junit.Assert.assertEquals;

public class OrderColumnTest {

    @Test
    public void shouldUpdateProductList() throws Exception {
        String orderId = insert();
        update(orderId);

        JpaConnection jpaConnection = new JpaConnection().open();
        try {
            Order fetchedOrder = jpaConnection.findOrder(orderId);

            assertEquals("other", fetchedOrder.getName());   // entity OK
            assertEquals(20., fetchedOrder.getProducts().get(0).getPrice(), 0); // inner collection KO
        } finally {
            jpaConnection.close();
        }
    }

    private String insert() throws Exception {
        JpaConnection jpaConnection = new JpaConnection().open();
        List<Product> products = new ArrayList<>();
        Product p1 = new Product("P1", 10.);
        products.add(p1);
        Product p2 = new Product("P2", 15.);
        products.add(p2);
        String orderId = new Random().nextInt() + "";
        Order order = new Order();
        order.setId(orderId);
        order.setName("test");
        order.setProducts(products);
        try {
            jpaConnection.store(order);
        } finally {
            jpaConnection.close();
        }
        return orderId;
    }

    private void update(String orderId) throws Exception {
        JpaConnection jpaConnection = new JpaConnection().open();
        try {
            Order fetchedOrder = jpaConnection.findOrder(orderId);
            jpaConnection.updateOrder(fetchedOrder, "other");
            Product fetchedP1 = fetchedOrder.getProducts().get(0);
            jpaConnection.updateProduct(fetchedP1, 20.);
        } finally {
            jpaConnection.close();
        }
    }

}
