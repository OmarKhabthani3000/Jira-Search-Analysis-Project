package issue;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.HashMap;

public class JpaConnection {

    private EntityManagerFactory entityManagerFactory = null;

    private EntityManager entityManager = null;

    public void store(Order order) throws Exception {
        entityManager.getTransaction().begin();
        entityManager.persist(order);
        entityManager.flush();
        entityManager.getTransaction().commit();
    }

    public void updateOrder(Order order, String name) throws Exception {
        entityManager.getTransaction().begin();
        order.setName(name);
        entityManager.getTransaction().commit();
    }

    public void updateProduct(Product product, double price) throws Exception {
        entityManager.getTransaction().begin();
        product.setPrice(price);
        entityManager.getTransaction().commit();
    }

    public Order findOrder(String id) throws Exception {
        return entityManager.find(Order.class, id);
    }

    public JpaConnection open() {
        entityManagerFactory = Persistence.createEntityManagerFactory("default-pu", new HashMap<String, Object>());
        entityManager = entityManagerFactory.createEntityManager();
        return this;
    }

    public void close() {
        if (entityManager != null) {
            entityManager.close();
        }
        if (entityManagerFactory != null) {
            entityManagerFactory.close();
        }
    }
}
