package org.ogmtest.cms.data.service;

import org.ogmtest.cms.data.entity.blog.BlogEntry;
import org.ogmtest.data.service.except.ServiceException;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;

/**
 * Author: apostle
 * Skype: thirteenth.apostle
 * Email: pavel.martinov@gmail.com
 * Date: 3/19/2015
 * Time: 11:18 PM
 */
@Singleton
@Startup
public class TestDataSingleton {
    @EJB
    BlogEntryService blogEntryService;

    @PostConstruct
    private void init() {
        BlogEntry blogEntry = new BlogEntry();
        blogEntry.setBody("TEST");
        try {
            blogEntryService.create(blogEntry);
        } catch (ServiceException e) {
            e.printStackTrace();
        }
    }
}
