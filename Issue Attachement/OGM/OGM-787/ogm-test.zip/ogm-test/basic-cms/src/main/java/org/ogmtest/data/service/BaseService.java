package org.ogmtest.data.service;

import org.ogmtest.data.entity.IEntity;
import org.ogmtest.data.service.except.ServiceException;

import java.io.Serializable;

/**
 * User: pavel.martinov@gmail.com
 * Skype: thirteenth.apostle
 * Date: 11/6/13
 * Time: 11:22 PM
 */
public interface BaseService<T extends IEntity> {
    T find(Serializable id);
    T get(Serializable id) throws ServiceException;
    void update(T entity) throws ServiceException;
    Serializable insert(T entity) throws ServiceException;
    Serializable insert(T entity, boolean withFlush) throws ServiceException;
    void persist(T entity) throws ServiceException;
    long getTotalNumber();
    void delete(T entity) throws ServiceException;
    int deleteById(Serializable id) throws ServiceException;
    T merge(T entity) throws ServiceException;
    void detach(T entity);
}
