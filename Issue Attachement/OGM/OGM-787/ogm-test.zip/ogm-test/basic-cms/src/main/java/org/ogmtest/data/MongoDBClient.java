package org.ogmtest.data;

import com.mongodb.DB;

/**
 * Created by pmartynov on 5/23/2014.
 */
public interface MongoDBClient {
    public DB getDB();
}
