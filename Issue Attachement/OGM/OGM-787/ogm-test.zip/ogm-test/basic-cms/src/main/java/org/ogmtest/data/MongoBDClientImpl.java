package org.ogmtest.data;

import com.mongodb.DB;
import com.mongodb.MongoClient;

/**
 * Created by pmartynov on 5/23/2014.
 */
public abstract class MongoBDClientImpl implements MongoDBClient {

    protected MongoClient mongoClient;
    protected String databaseName;


    @Override
    public DB getDB() {
        return mongoClient.getDB(databaseName);
    }

}
