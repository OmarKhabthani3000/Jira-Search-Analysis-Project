package org.ogmtest.cms.data.service;

import org.ogmtest.data.entity.IEntity;
import org.ogmtest.data.service.BaseServiceImpl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

/**
 * Created by pmartynov on 5/10/2014.
 */
public abstract class BaseBlogServiceImpl<T extends IEntity> extends BaseServiceImpl<T> {

    public static final String PERSISTENT_UNIT_NAME = "blog-data-pu";

    @PersistenceContext(unitName = PERSISTENT_UNIT_NAME, type= PersistenceContextType.TRANSACTION)
    protected EntityManager entityManager;

    @Override
    public EntityManager getEntityManager() {
        return entityManager;
    }

}
