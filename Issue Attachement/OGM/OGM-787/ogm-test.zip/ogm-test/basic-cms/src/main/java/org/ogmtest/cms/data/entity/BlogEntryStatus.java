package org.ogmtest.cms.data.entity;

/**
 * Created by pmartynov on 5/24/2014.
 */
public enum BlogEntryStatus {
    created, ready, prooved, published, hidden, removed
}
