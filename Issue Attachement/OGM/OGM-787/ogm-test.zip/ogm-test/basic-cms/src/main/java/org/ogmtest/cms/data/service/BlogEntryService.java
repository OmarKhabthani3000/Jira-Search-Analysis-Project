package org.ogmtest.cms.data.service;

import org.ogmtest.cms.data.entity.blog.BlogEntry;
import org.ogmtest.data.service.BaseService;
import org.ogmtest.data.service.except.ServiceException;

import javax.ejb.Local;
import java.util.List;

/**
 * Created by pmartynov on 5/24/2014.
 */
@Local
public interface BlogEntryService extends BaseService<BlogEntry> {
    void create(BlogEntry blogEntry) throws ServiceException;
    List<BlogEntry> list(int start, int number);
    Long count();
}
