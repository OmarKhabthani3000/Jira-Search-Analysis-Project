package org.ogmtest.cms.data.service;

import com.mongodb.MongoClient;
import org.ogmtest.data.MongoBDClientImpl;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import java.net.UnknownHostException;
import java.util.Map;

/**
 * Author: apostle
 * Skype: thirteenth.apostle
 * Email: pavel.martinov@gmail.com
 * Date: 10/26/2014
 * Time: 9:57 PM
 */
@Stateless
public class MongoDBCmsDataClientEJB extends MongoBDClientImpl implements MongoDBCmsDataClient {
    public static final String PERSISTENT_UNIT_NAME = "blog-data-pu";

    @PersistenceContext(unitName = PERSISTENT_UNIT_NAME, type= PersistenceContextType.TRANSACTION)
    protected EntityManager entityManager;

    @PostConstruct
    private void init() {
        Map<String, Object> properties = entityManager.getEntityManagerFactory().getProperties();
        String host = (String) properties.get("hibernate.ogm.datastore.host");
        databaseName = (String) properties.get("hibernate.ogm.datastore.database");
        try {
            mongoClient = new MongoClient(host);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

}
