package org.ogmtest.data.service.except;


/**
 * User: pavel.martinov@gmail.com
 * Skype: thirteenth.apostle
 * Date: 11/6/13
 * Time: 11:24 PM
 */
public class ServiceException extends Exception {
    public ServiceException(Throwable cause) {
        super(cause);
    }

    public ServiceException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public ServiceException() {
    }

    public ServiceException(String message) {
        super(message);
    }

    public ServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}