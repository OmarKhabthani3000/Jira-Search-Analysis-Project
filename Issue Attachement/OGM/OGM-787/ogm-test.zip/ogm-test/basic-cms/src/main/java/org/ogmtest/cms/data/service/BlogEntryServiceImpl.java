package org.ogmtest.cms.data.service;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import org.ogmtest.cms.data.entity.blog.BlogEntry;
import org.ogmtest.data.service.except.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.util.List;

/**
 * Created by pmartynov on 5/24/2014.
 */
@Stateless
public class BlogEntryServiceImpl extends BaseBlogServiceImpl<BlogEntry> implements BlogEntryService {

    @EJB
    MongoDBCmsDataClient mongoDBProjectDataClient;

    private static final Logger logger = LoggerFactory.getLogger(BlogEntryServiceImpl.class);

    @Override
    public Logger getLogger() {
        return logger;
    }

    @Override
    public void create(BlogEntry blogEntry) throws ServiceException {
        persist(blogEntry);
    }

    @Override
    public List<BlogEntry> list(int start, int number) {
        javax.persistence.Query query = getEntityManager().createQuery("select bel from BlogEntryLocalized bel order by bel.creationTime DESC, bel.creationTime DESC")
                .setFirstResult(start)
                .setMaxResults(number);
        List<BlogEntry> blogEntryList = query.getResultList();
        return blogEntryList;
    }

    @Override
    public Long count() {
        DB db = mongoDBProjectDataClient.getDB();
        DBCollection projectCollection = db.getCollection(BlogEntry.TABLE_NAME);
        return projectCollection.count();

    }
}
