package org.ogmtest.data.service;

import org.ogmtest.data.entity.IEntity;
import org.ogmtest.data.service.except.ServiceException;
import org.slf4j.Logger;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.validation.ConstraintViolationException;
import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

/**
 * User: pavel.martinov@gmail.com
 * Skype: thirteenth.apostle
 * Date: 11/6/13
 * Time: 11:17 PM
 */
public abstract class BaseServiceImpl<T extends IEntity> implements BaseService<T> {

    protected Class<T> entityClass;

    public abstract Logger getLogger();
    
    public abstract EntityManager getEntityManager();


    public BaseServiceImpl() {
        super();
        Type[] actualTypeArguments = ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments();
        try {
            entityClass = ((Class<T>) actualTypeArguments[0]);
        } catch (Exception ignored) {

        }
    }

    @Override
    public Serializable insert(T entity) throws ServiceException {
        if (null == entity) {
            throw new ServiceException("Attempt to insert an null entity");
        }
        insert(entity, true);
        return entity.getId();
    }

    @Override
    public Serializable insert(T entity, boolean withFlush) throws ServiceException {
        try {
            getLogger().info("Inserting: " + entity);

            getEntityManager().persist(entity);

            if (withFlush) {
                getEntityManager().flush();
            }

            getLogger().info("Inserted: " + entity);
            return entity.getId();
        } catch (Exception e) {
            getLogger().error(String.format("Failed insert for %s", entity), e);
            if (e.getCause() instanceof ConstraintViolationException) {
                throw new ServiceException(e.getMessage());
            }
            throw new ServiceException(e.getMessage());
        }
    }

    @Override
    public void delete(T entity) throws ServiceException {
        try {
            getLogger().info("Deleting: " + entity);
            getEntityManager().remove(get(entity.getId()));
            getEntityManager().flush();
            getLogger().info("Deleted: " + entity);

        } catch (Exception e) {
            e.printStackTrace();
            throw new ServiceException(e.getMessage()); //TODO
        }
    }

    @Override
    public int deleteById(Serializable id) throws ServiceException {
        T entity = find(id);
        if (null == entity) {
            return 0;
        }
        delete(entity);
        return 1;
    }

    @Override
    public void persist(T entity) throws ServiceException {
        try {
            getLogger().info("Inserting: " + entity);
            if (null != entity.getId()) {
                entity = getEntityManager().merge(entity);
            }
            getEntityManager().persist(entity);
            getEntityManager().flush();

            getLogger().info("Inserted: " + entity);
        } catch (PersistenceException e) {
            getLogger().info("Failed insert for " + entity, e);
            throw new ServiceException(String.format("can.not.insert.entity %s", entity.getClass().getSimpleName()));
        } catch (ConstraintViolationException cve) {
            getLogger().info("Failed insert for " + entity, cve);
            throw new ServiceException("Validation fails", cve);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public long getTotalNumber() {
        long res = 0;
        getLogger().info("getting getTotalNumber of " + entityClass.getSimpleName());
        List<Object> resultList = getEntityManager().createQuery(sqlCount()).getResultList();
        if (resultList != null && resultList.size() == 1) {
            res = (Long) resultList.get(0);
        }
        getLogger().info("Count: " + res);
        return res;
    }

    @Override
    public T find(Serializable id) {
        return getEntityManager().find(entityClass, id);
    }

    @Override
    public T get(Serializable id) throws ServiceException {
        if (id == null) {
            throw new ServiceException("ID CANNOT BE NULL"); //TODO
        }
        T byId = getEntityManager().find(entityClass, id);
        if (byId == null) {
            throw new ServiceException("CANT FIND BY ID"); //TODO
        }
        return byId;
    }

    @Override
    public void update(T entity) throws ServiceException {
        try {
            getLogger().info("Updating: " + entity);

            entity = merge(entity);

            getEntityManager().flush();

            getLogger().info("Updated: " + entity);
        } catch (PersistenceException e) {
            getLogger().error("Update Failed for " + entity, e);
            throw new ServiceException(e.getMessage()); //TODO
        } catch (ConstraintViolationException cve) {
            throw new ServiceException("Validation failed", cve);
        } catch (Exception e) {
            getLogger().error("Update failed for: " + entity, e);
            throw new ServiceException(e.getMessage()); //TODO
        }
    }

    @Override
    public T merge(T entity) throws ServiceException {
        return getEntityManager().merge(entity);
    }

    @Override
    public void detach(T entity) {
        getEntityManager().detach(entity);
    }

    private String sqlSelectAll() {
        return String.format("SELECT e FROM %s e", entityClass.getSimpleName());
    }

    private String sqlCount() {
        return String.format("SELECT COUNT(e) FROM %s e", entityClass.getSimpleName());
    }


}
