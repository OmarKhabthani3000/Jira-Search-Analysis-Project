package org.ogmtest.cms.data.service;

import org.ogmtest.data.MongoDBClient;

import javax.ejb.Local;

/**
 * Author: apostle
 * Skype: thirteenth.apostle
 * Email: pavel.martinov@gmail.com
 * Date: 10/26/2014
 * Time: 10:01 PM
 */
@Local
public interface MongoDBCmsDataClient extends MongoDBClient {
}
