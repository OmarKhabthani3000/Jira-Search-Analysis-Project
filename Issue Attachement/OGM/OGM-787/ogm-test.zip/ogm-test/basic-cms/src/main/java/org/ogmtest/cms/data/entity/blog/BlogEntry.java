package org.ogmtest.cms.data.entity.blog;

import org.ogmtest.cms.data.entity.BlogEntryStatus;
import org.ogmtest.data.entity.IEntity;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

/**
 * Created by pmartynov on 5/24/2014.
 */
@Entity
@Table(name = "blog_entity_body")
@NamedQueries({
        @NamedQuery(name = "blog_entry_number", query = "select count(bel) from BlogEntry bel"),
})
public class BlogEntry implements IEntity {

    public static final String TABLE_NAME = "blog_entity_body";

    @Id
    private String id;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "creation_time")
    protected Date creationTime;

    @Column(name = "status")
    @Enumerated
    private BlogEntryStatus status;

    @Column(name = "published")
    private Date published;


    @Column(name = "body")
    protected String body;

    @PrePersist
    protected void prePersist() {
        if (null == id) {
            setId(UUID.randomUUID().toString().replace("-", ""));
        }
        if (null == creationTime) {
            creationTime = new Date();
        }
        if (null == status) {
            status = BlogEntryStatus.created;
        }
    }

    public BlogEntryStatus getStatus() {
        return status;
    }

    public void setStatus(BlogEntryStatus status) {
        this.status = status;
    }

    public Date getPublished() {
        return published;
    }

    public void setPublished(Date published) {
        this.published = published;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(Date creationTime) {
        this.creationTime = creationTime;
    }
}
