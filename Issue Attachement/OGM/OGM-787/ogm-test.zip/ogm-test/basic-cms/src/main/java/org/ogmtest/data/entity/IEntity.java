package org.ogmtest.data.entity;

import java.io.Serializable;

/**
 * User: pavel.martinov@gmail.com
 * Skype: thirteenth.apostle
 * Date: 11/6/13
 * Time: 11:18 PM
 */

public interface IEntity extends Serializable {
    Serializable getId();
}
