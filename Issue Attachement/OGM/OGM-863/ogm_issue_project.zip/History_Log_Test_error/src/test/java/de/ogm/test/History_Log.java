package de.ogm.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import javax.persistence.EntityManager;
import javax.xml.bind.JAXBException;

import de.entities.DummyLogEntry;
import de.entities.LogEntry;
import de.entities.LogEntryList;
import de.ogm.test.HibernateUtil.DB_TYPE;

/**
 * 
 * hey, thank you for wanting to help me.
 * i altered in the persistence file only the IP, USER and PASSWORD
 * the methods dowsn't make sence anymore, because I tried to minimalize the Project.
 * normally there is a lot of fileWriting involved :)
 * 
 */
public class History_Log {

	static BufferedReader console = new BufferedReader(new InputStreamReader(
			System.in));

	static Runtime rt = Runtime.getRuntime();
	static String xmlFile = "C:\\Users\\MOTZA\\Documents\\__BA\\Bachelor-Thesis\\log\\log.xml";

	public static void main(String[] args) throws IOException, JAXBException, InterruptedException {


		startTest();

	}

	public static void startTest() throws IOException, JAXBException {

		System.out.println("starting .....");
		int[] Ns = {
				10
		};
		int[] numEntrieses = {
				100,
		};
		for (int N : Ns) {
			for (int numEntries : numEntrieses) {
				for (DB_TYPE db : DB_TYPE.values()) {
					try {
						System.out.println("starting test for " + db.name());
						test_writing_power(db, N, numEntries);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
	}


	public static void insertLogs(LogEntryList allEntries, EntityManager manager) {
		insertLogs(allEntries, 0, manager);
	}

	public static void insertLogs(LogEntryList allEntries, int numEntries, EntityManager manager) {

		deleteAllEntries("LogEntry", manager);
		manager.getTransaction().begin();

		List<LogEntry> entries = allEntries.getLogEntries();
		if (numEntries > 0) {
			entries = entries.subList(0, numEntries);
		}
		for (LogEntry entry : entries) {
			manager.persist(entry);
		}
		manager.getTransaction().commit();
		manager.close();
		HibernateUtil.closeManagerFactory();

	}


	private static void test_writing_power(DB_TYPE db, int N, int numEntries) throws IOException, JAXBException {

		LogEntryList entries = DummyLogEntry.generateDummyEntries(numEntries);
		long mintime = Long.MAX_VALUE;
		long maxtime = 0;
		long akttime = 0;
		for (int i = 0; i < N; i++) {
			System.out.println((i + 1) + ". time:");
			// set Time
			final long timeStart = System.currentTimeMillis();
			insertLogs(entries, numEntries, HibernateUtil.getEntityManager(db));
			// set Time
			akttime = System.currentTimeMillis() - timeStart;
			if (akttime < mintime) {
				mintime = akttime;
			}
			if (akttime > maxtime) {
				maxtime = akttime;
			}

		}

		System.out.println("finished");
	}


	public static void deleteAllEntries(String tableName, EntityManager manager) {

		try {

			manager.getTransaction().begin();
			for (LogEntry le : manager.createQuery("FROM " + tableName, LogEntry.class).getResultList()) {
				manager.remove(manager.merge(le));
			}
			manager.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
