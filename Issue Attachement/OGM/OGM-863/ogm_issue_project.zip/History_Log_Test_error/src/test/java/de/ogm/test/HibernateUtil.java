package de.ogm.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class HibernateUtil {
	//
	private static EntityManagerFactory entityManagerFactory;

	public enum DB_TYPE {
		MONGO_DB("mongoDB", "_mongo.csv"),
		// PSQL("psql", "_psql.csv"),
		// MARIA_DB("mariaDB", "_maria.csv"),
		// COUCH_DB("couchDB", "_couchDBTests.csv"),
		cassandra("cassandra", "_cassandraTests.csv"),

		;

		private String persUnit;
		private String fileEnd;

		private DB_TYPE(String persUnit, String fileEnd) {
			this.persUnit = persUnit;
			this.fileEnd = fileEnd;
		}

		public String getPersUnit() {
			return persUnit;
		}

		public String getFileEnd() {
			return fileEnd;
		}

	}


	public static void closeManagerFactory() {
		if (entityManagerFactory != null && entityManagerFactory.isOpen()) {
			entityManagerFactory.close();
		}
	}

	public static EntityManager getEntityManager(DB_TYPE db) {
		entityManagerFactory = Persistence.createEntityManagerFactory(db.getPersUnit());
		return entityManagerFactory.createEntityManager();
	}


}