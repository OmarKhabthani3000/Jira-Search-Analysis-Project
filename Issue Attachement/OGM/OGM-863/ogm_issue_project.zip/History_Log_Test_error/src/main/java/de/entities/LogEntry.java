package de.entities;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LogEntry", namespace = "http://www.rohde-schwarz.de/schemas/types/logEntry", propOrder = {
		"id", "log_index", "code", "date", "level", "activity",
		"component", "resource", "parameters", "serverErrorCode", "userName", "objectName", "parametersList"
})
@Entity
// @Table(name = "HISTORY_LOG")
@Indexed
public class LogEntry {


	
	public enum LEVEL {
		error,
		warning,
		info;
	}
	

	public LogEntry(String id, long log_index, String code, long date, LEVEL level, String activity, String resource, String component, String serverErrorCode,
			String objectName, String userName) {
		super();
		this.id = id;
		this.log_index = log_index;
		this.code = code;
		this.date = date;
		this.level = level;
		this.activity = activity;
		this.resource = resource;
		this.component = component;
		this.serverErrorCode = serverErrorCode;
		this.objectName = objectName;
		this.userName = userName;
	}

	public static final String TYPE_NAME = "LogEntry";
	public static final String DEFAULT_USERNAME = "SYSTEM";
	public static final String AVHE_CONTROL_USERNAME = "AVHE_CONTROL";
	

	@XmlElement(required = true)
	@Id
	private String id = "GUID_FOR_EMPTY";

	@XmlElement(required = true, name = "index")
	@Field(analyze = Analyze.NO)
	private long log_index = 0;

	@XmlElement(required = true)
	@Field(analyze = Analyze.NO)
	private String code;

	@XmlElement(required = true)
	@Field(analyze = Analyze.NO)
	private long date;

	@XmlElement(required = true)
	@Field(analyze = Analyze.NO)
	@Enumerated(EnumType.STRING)
	private LEVEL level;


	@XmlElement(required = true)
	@Field(analyze = Analyze.NO)
	private String activity;
	
	@XmlElement(required = true)
	@Field(analyze = Analyze.NO)
	private String resource;

	@XmlElement(required = true)
	@Field(analyze = Analyze.NO)
	private String component;

	@XmlElement(required = true)
	@Field(analyze = Analyze.NO)
	private String serverErrorCode;

	@XmlElement(required = true)
	@Field(analyze = Analyze.NO)
	private String objectName;

	@XmlElement(required = true)
	@Field(analyze = Analyze.NO)
	private String userName = DEFAULT_USERNAME;

	@XmlElement(required = true)
	@Transient
	private Map<String, String> parameters = new HashMap<>();

	@OneToMany(cascade = CascadeType.ALL)
	@IndexedEmbedded
	private Set<Parameter> parametersList;

	
	public LogEntry() {
		for (Entry<String, String> entry : parameters.entrySet()) {
			parametersList.add(new Parameter(log_index, entry.getKey(), entry.getValue()));
		}
	}




	/**
	 * Gets the activity.
	 * 
	 * @return the activity
	 */
	public String getActivity() {
		return activity;
	}

	/**
	 * Sets the activity.
	 * 
	 * @param activity
	 * the activity to set
	 */
	public void setActivity(String activity) {
		this.activity = activity;
	}

	/**
	 * Gets the resource.
	 * 
	 * @return the resource
	 */
	public String getResource() {
		return resource;
	}

	/**
	 * Sets the resource.
	 * 
	 * @param resource
	 * the resource to set
	 */
	public void setResource(String resource) {
		this.resource = resource;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder stringBuilder = new StringBuilder();
		int i = 1;
		for (Map.Entry<String, String> entry : parameters.entrySet()) {
			stringBuilder.append(i + "" + entry.getKey() + "=" + entry.getValue() + ", ");
			i++;
		}

		return "LogEntry [id=" + id + ", index=" + log_index // + " , code=" + code + ", date=" + date + ", level=" + level + ", activity=" +
															// activity
				// + ", resource="
				// + resource + ", String=" + component + ", serverErrorCode=" + serverErrorCode + ", userName=" + userName +
				// ", parameters="
				// + stringBuilder.toString()
				+ "]";
	}

	/**
	 * Gets the server error code.
	 * 
	 * @return the serverErrorCode
	 */
	public String getServerErrorCode() {
		return serverErrorCode;
	}

	/**
	 * Sets the server error code.
	 * 
	 * @param serverErrorCode
	 * the serverErrorCode to set
	 */
	public void setServerErrorCode(String serverErrorCode) {
		this.serverErrorCode = serverErrorCode;
	}

	/**
	 * Gets the parameters.
	 * 
	 * @return the parameters
	 */
	public Map<String, String> getParameters() {
		return parameters;
	}

	/**
	 * Gets the index.
	 * 
	 * @return the index
	 */
	public long getIndex() {
		return log_index;
	}

	/**
	 * Sets the index.
	 * 
	 * @param indexx
	 * the index to set
	 */
	public void setIndex(long indexx) {
		this.log_index = indexx;
	}


	/**
	 * Gets the date.
	 * 
	 * @return the date
	 */
	public long getDate() {
		return date;
	}

	/**
	 * Sets the date.
	 * 
	 * @param date the new date
	 */
	public void setDate(long date) {
		this.date = date;
	}

	/**
	 * Gets the iD.
	 * 
	 * @return the iD
	 */
	public String getID() {
		return id;
	}

	/**
	 * Sets the iD.
	 * 
	 * @param id the new iD
	 */
	public void setID(String id) {
		this.id = id;
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Sets the code.
	 * 
	 * @param code the new code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Gets the level.
	 * 
	 * @return the level
	 */
	public LEVEL getLevel() {
		return level;
	}

	/**
	 * Sets the level.
	 * 
	 * @param level the new level
	 */
	public void setLevel(LEVEL level) {
		this.level = level;
	}

	/**
	 * Gets the user name.
	 * 
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Sets the user name.
	 * 
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (activity == null ? 0 : activity.hashCode());
		result = prime * result + (code == null ? 0 : code.hashCode());
		result = prime * result + (component == null ? 0 : component.hashCode());
		result = prime * result + (int) (date ^ date >>> 32);
		result = prime * result + (id == null ? 0 : id.hashCode());
		result = prime * result + (int) (log_index ^ log_index >>> 32);
		result = prime * result + (level == null ? 0 : level.hashCode());
		result = prime * result + (parameters == null ? 0 : parameters.hashCode());
		result = prime * result + (resource == null ? 0 : resource.hashCode());
		result = prime * result + (serverErrorCode == null ? 0 : serverErrorCode.hashCode());
		result = prime * result + (userName == null ? 0 : userName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LogEntry other = (LogEntry) obj;
		if (activity != other.activity)
			return false;
		if (code != other.code)
			return false;
		if (component != other.component)
			return false;
		if (date != other.date)
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (log_index != other.log_index)
			return false;
		if (level != other.level)
			return false;
		if (parameters == null) {
			if (other.parameters != null)
				return false;
		} else if (!parameters.equals(other.parameters))
			return false;
		if (resource != other.resource)
			return false;
		if (serverErrorCode != other.serverErrorCode)
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		return true;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

}

