package de.entities;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LogEntryList", propOrder = { "logEntries" })
@XmlRootElement(name = "LogEntryList", namespace = "http://www.rohde-schwarz.de/schemas/types/logEntryList")
public class LogEntryList {


	/** The log entries. */
	@XmlElement(namespace = "http://www.rohde-schwarz.de/schemas/types/logEntry")
	private List<LogEntry> logEntries = new ArrayList<>();

	/** The total size of all elements without using a limit. */
	@XmlTransient
	private int totalSize = 0;

	/** The Constant AND. */
	public static final String AND = " AND ";

	/** The Constant OR. */
	public static final String OR = " OR ";

	/** The Constant ANY. */
	public static final String ANY = "*";

	/**
	 * Instantiates a new log entry list.
	 */
	public LogEntryList() {
	}

	/**
	 * Instantiates a new log entry list.
	 * 
	 * @param copyMe
	 * the copy me
	 */
	public LogEntryList(LogEntryList copyMe) {
		logEntries = new ArrayList<>(copyMe.logEntries);
		totalSize = copyMe.totalSize;
	}

	/**
	 * Instantiates a new log entry list.
	 * 
	 * @param entries the entries
	 * @param clearTimeStamp the clear time stamp
	 */
	public LogEntryList(Collection<LogEntry> entries) {
		this.logEntries.addAll(entries);
	}

	/**
	 * Gets the log entries.
	 * 
	 * @return the log entries
	 */
	public List<LogEntry> getLogEntries() {
		return logEntries;
	}

	/**
	 * Gets the.
	 * 
	 * @param index
	 * the index
	 * @return the log entry
	 */
	public LogEntry get(int index) {
		return this.logEntries.get(index);
	}

	/**
	 * Sets the log entries.
	 * 
	 * @param entries
	 * the new log entries
	 */
	public void setLogEntries(List<LogEntry> entries) {
		this.logEntries = entries;
	}

	/**
	 * Adds the.
	 * 
	 * @param e
	 * the e
	 * @return true, if successful
	 */
	public boolean add(LogEntry e) {
		return logEntries.add(e);
	}

	/**
	 * Adds the all.
	 * 
	 * @param c
	 * the c
	 * @return true, if successful
	 */
	public boolean addAll(Collection<? extends LogEntry> c) {
		return logEntries.addAll(c);
	}

	/**
	 * Size.
	 * 
	 * @return the int
	 */
	public int size() {
		return logEntries.size();
	}

	/**
	 * Removes the all.
	 */
	public void removeAll() {
		this.logEntries.clear();
	}

	/**
	 * To array.
	 * 
	 * @return the log entry[]
	 */
	public LogEntry[] toArray() {
		return logEntries.toArray(new LogEntry[logEntries.size()]);
	}

	/**
	 * Sort by date.
	 * 
	 * @param comparator
	 * the comparator
	 * @param ascendening
	 * the ascendening
	 */
	public void sort(final Comparator<LogEntry> comparator, boolean ascendening) {

		if (!ascendening) {
			Collections.sort(logEntries, new Comparator<LogEntry>() {
				@Override
				public int compare(LogEntry o1, LogEntry o2) {
					return comparator.compare(o2, o1);
				}
			});
		} else {
			Collections.sort(logEntries, comparator);
		}
	}

	/**
	 * The total size of all elements without using a limit.
	 * 
	 * @return the totalSize
	 */
	public int getTotalSize() {
		return totalSize;
	}

	/**
	 * Sets the total size.
	 * 
	 * @param totalSize
	 * the totalSize to set
	 */
	public void setTotalSize(int totalSize) {
		this.totalSize = totalSize;
	}

	@Override
	public String toString() {
		String text = "[ ";
		for (LogEntry entry : logEntries) {
			text += entry.toString() + ",\n";
		}
		return text;// super.toString();
	}


}

