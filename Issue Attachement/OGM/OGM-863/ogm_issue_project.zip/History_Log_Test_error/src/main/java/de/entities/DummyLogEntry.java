package de.entities;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;

import de.entities.LogEntry.LEVEL;

public class DummyLogEntry {

	private static SecureRandom random;

	public static LogEntryList generateDummyEntries(int N) {
		ArrayList<LogEntry> entries = new ArrayList<>();
		for(int i = 0; i < N; i++){
			random = new SecureRandom();
			entries.add(new LogEntry(new BigInteger(130, random).toString(32), random.nextLong(), new BigInteger(130, random).toString(32), (new Date())
					.getTime(),
					LEVEL.error, new BigInteger(130, random).toString(32), new BigInteger(130, random).toString(32), new BigInteger(130, random).toString(32),
					new BigInteger(130, random).toString(32), new BigInteger(130, random).toString(32), new BigInteger(130, random).toString(32))
					);
		}
		
		return new LogEntryList(entries);
		
	}

}
