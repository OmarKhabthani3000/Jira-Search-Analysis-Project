package de.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PARAMETERS")
public class Parameter {

	@Id
	private long log_index;
	private String key;
	private String value;

	public Parameter(long log_index, String key, String value) {
		this.log_index = log_index;
		this.key = key;
		this.value = value;
	}

	public long getLog_index() {
		return log_index;
	}

	public void setLog_index(long log_index) {
		this.log_index = log_index;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
