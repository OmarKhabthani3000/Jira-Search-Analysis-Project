package com.gregoriopalama.example;

public interface ExampleServiceBeanLocal {
	public String test();
}
