package com.gregoriopalama.example;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Stateless
@LocalBean
@Path("/exampleService")
public class ExampleServiceBean implements ExampleServiceBeanLocal  {
	@Inject
	EntityManager entityManager;
	

	@GET
    @Produces(MediaType.APPLICATION_JSON)
	@Path("/test")
	@Override
	public String test() {
		Person person = new Person();
		person.setName("Gregorio");
		person.setAddress("Via dei Frentani");
		
		insert(person);
		
		return "OK";
	}
	
	private Person insert(Person person) {
		entityManager.persist(person);
		
		return person;
	}


}
