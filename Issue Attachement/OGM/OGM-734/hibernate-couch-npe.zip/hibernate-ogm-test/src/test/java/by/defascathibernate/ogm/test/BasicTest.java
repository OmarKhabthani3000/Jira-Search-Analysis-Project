package by.defascathibernate.ogm.test;

import by.defascat.hibernate.ogm.test.entity.UserProfile;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import org.junit.After;
import org.junit.Assert;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

/**
 *
 * @author andy
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public abstract class BasicTest {

    protected EntityManager em;
    protected EntityManagerFactory emf;

    protected abstract String getDataSource();

    protected abstract String getNativeQuery(final String newCity);

    @After
    public void after() {
        em.close();
        emf.close();
    }

    @Before
    public void setup() {
        emf = Persistence.createEntityManagerFactory(getDataSource());
        em = emf.createEntityManager();
    }

    @Test
    public void test5FindJPQL() {
        final String newCity = "Borovlyany";
        final Query jpqlQuery = em.createQuery("from UserProfile p where p.address.city = '" + newCity + "'");
        // jpqlQuery.setParameter("city", newCity); - not supported in Neo4J
        final List<UserProfile> items = jpqlQuery.getResultList();
        Assert.assertEquals(1, items.size());
        Assert.assertEquals("testuser", items.get(0).getName());
        Assert.assertEquals(newCity, items.get(0).getAddress().getCity());
    }
}
