import com.notifywell.ean.EANSearchHelper;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class EANSearchTests {

    @Test
    public final void test01GetProductByBarcode() throws Exception {
        String ean = "05052319711639"; // search for this EAN code
        String product = EANSearchHelper.getProductByEan(ean);

        System.out.println(">>>>> test01GetProductByBarcode product = " + product);
    }

    @Test
    public final void test02GetProductByBarcodePrefix() throws Exception {
        EANSearchHelper.getProductByBarcodePrefix();
    }

    @Test
    public final void test03GetProductByProduct() throws Exception {
        EANSearchHelper.getProductByProduct();
    }
}
