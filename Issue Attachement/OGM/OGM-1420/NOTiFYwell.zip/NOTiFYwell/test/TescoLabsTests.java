import com.google.gson.Gson;
import com.notifywell.gson.tesco.CalcNutrient;
import com.notifywell.gson.tesco.GdaRef;
import com.notifywell.gson.tesco.Product;
import com.notifywell.gson.tesco.Tesco;
import com.notifywell.gson.tesco.TescoProducts;
import com.notifywell.tesco.TescoHelper;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.net.URI;
import java.util.Iterator;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TescoLabsTests {

    final static String OCP_APIM_SUBSCRIPTION_KEY = "Ocp-Apim-Subscription-Key";
    final static String OCP_APIM_SUBSCRIPTION_KEY_VALUE = "68c52a783af74cf6997dc536861d0d8f";

    @Test
    public final void test01GetProductByGTIN() throws Exception {
//        HttpClient httpclient = HttpClients.createDefault();
//
//        try {
//            URIBuilder uriBuilder = new URIBuilder("https://dev.tescolabs.com/product/");
//
//            uriBuilder.setParameter("gtin", "05000157024671");
//            //uriBuilder.setParameter("tpnb", "{string}");
//            //uriBuilder.setParameter("tpnc", "{string}");
//            //builder.setParameter("catid", "{string}");
//
//            URI uri = uriBuilder.build();
//            HttpGet request = new HttpGet(uri);
//            request.setHeader(OCP_APIM_SUBSCRIPTION_KEY, OCP_APIM_SUBSCRIPTION_KEY_VALUE);
//
//            // Request body
//            StringEntity stringEntity = new StringEntity("{body}");
//            //request.setEntity(stringEntity);
//
//            HttpResponse response = httpclient.execute(request);
//            HttpEntity entity = response.getEntity();
//
//            if (entity != null) {
//                System.out.println(EntityUtils.toString(entity));
//            }
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }

        //String gTIN = "05000157024671";
        String gTIN = "05052319711639";

        String json = TescoHelper.getProductByGTIN(gTIN);

        System.out.println("********** test01GetProductByGTIN json = " + json);
    }

    @Test
    public final void test02SearchByGrocery() {

        // query string - The search term to query by.
        //final String QUERY = "Heinz Baked Beans";
        final String QUERY = "Beans";

        // offset number - For use to add pagenation for search results e.g. 10 to start with the 11th result. Default is 0.

        // limit number - The number of results to return. Default is 10.

        HttpClient httpclient = HttpClients.createDefault();

        try {
            //URIBuilder builder = new URIBuilder("https://dev.tescolabs.com/grocery/products/?query={query}&offset={offset}&limit={limit}");
            URIBuilder uriBuilder = new URIBuilder("https://dev.tescolabs.com/grocery/products/?query=" + QUERY + "&offset=0&limit=10");

            System.out.println(">>>>> test02SearchByGrocery QUERY = " + QUERY);
            System.out.println(">>>>> test02SearchByGrocery uriBuilder = " + uriBuilder.toString());

            URI uri = uriBuilder.build();
            HttpGet request = new HttpGet(uri);
            request.setHeader(OCP_APIM_SUBSCRIPTION_KEY, OCP_APIM_SUBSCRIPTION_KEY_VALUE);

            // Request body
            StringEntity stringEntity = new StringEntity("{body}");
            //request.setEntity(stringEntity);

            HttpResponse response = httpclient.execute(request);
            HttpEntity entity = response.getEntity();

            String entityString = EntityUtils.toString(entity);
            if (entityString != null) {
                System.out.println(">>>>> JSON entityString = " + entityString);
            }

            //GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
            //Gson gson = gsonBuilder.create();

            Gson gson = new Gson();
            // deserialize

            System.out.println(">>>>> entity = " + entity);
            if (entity != null) {
                Tesco tesco = gson.fromJson(entityString, Tesco.class);

                System.out.println(">>>>> tesco = " + tesco);
//                System.out.println(">>>>> result = " + result.getProducts().get(0).getGtin());
//                System.out.println(">>>>> result = " + result.getProducts().get(0).getTpnb());

                System.out.println(">>>>> result getProducts size = " + tesco.getUk().getGhs().getProducts().getResults().size());
                TescoHelper.getResults(tesco.getUk().getGhs().getProducts().getResults());

//                int tPnb = tescoProducts.getUk().getGhs().getProducts().getResults().get(0).getTpnb();
                int tPnb = 51627961;
                System.out.println("***** test02SearchByGrocery tPnb = " + tPnb);

                getTescoProduct(tPnb);

//                long gTin = Long.parseLong("05000157024671");
//                getProductByGTIN(gTin);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

//    private void getResults(List<Result> resultList) {
//        int count = 0;
//
//        Iterator iterator = resultList.iterator();
//        while (iterator.hasNext()) {
//            Result result = (Result) iterator.next();
//
//            System.out.println(">>>>> getResults count = " + count);
//            System.out.println(">>>>> getResults getTpnb = " + result.getTpnb());
//            System.out.println(">>>>> getResults getTpnb = " + result.getName());
//
//            count++;
//        }
//    }

    /**
     * @param tPnb int
     */
    private void getTescoProduct(final int tPnb) {
        System.out.println(">>>>> 2 getTescoProduct tPnb = " + tPnb);

        HttpClient httpclient = HttpClients.createDefault();

        try {
            URIBuilder uriBuilder = new URIBuilder("https://dev.tescolabs.com/product/");

            uriBuilder.setParameter("tpnb", Integer.toString(tPnb));

            URI uri = uriBuilder.build();
            HttpGet request = new HttpGet(uri);
            request.setHeader(OCP_APIM_SUBSCRIPTION_KEY, OCP_APIM_SUBSCRIPTION_KEY_VALUE);

            // Request body
            StringEntity stringEntity = new StringEntity("{body}");

            HttpResponse response = httpclient.execute(request);
            HttpEntity entity = response.getEntity();

            if (entity != null) {
                String entityString = EntityUtils.toString(entity);

                System.out.println(">>>>> getTescoProduct entityString = " + entityString);

                Gson gson = new Gson();
                TescoProducts tescoProducts = gson.fromJson(entityString, TescoProducts.class);
                System.out.println(">>>>> getTescoProduct tescoProducts = " + tescoProducts.getProducts().size());

                Iterator iterator = tescoProducts.getProducts().iterator();

                while (iterator.hasNext()) {
                    Product product = (Product) iterator.next();
                    System.out.println("********** getTescoProduct product getGtin = " + product.getGtin());
                    System.out.println("********** getTescoProduct product getBrand = " + product.getBrand());
                    System.out.println("********** getTescoProduct product getDescription = " + product.getDescription());

                    System.out.println(">>>>> getTescoProduct product = " + product.getIngredients().size());

                    // Ingredients
                    Iterator iteratorIngredients = product.getIngredients().iterator();
                    while (iteratorIngredients.hasNext()) {
                        String ingredients = iteratorIngredients.next().toString();
                        System.out.println(">>>>> iteratorIngredients ingredients = " + ingredients);

                    }

                    // GDA
                    System.out.println(">>>>> 2 getTescoProduct getGdaRefs = " + product.getGda().getGdaRefs().size());
                    Iterator iteratorGdaRefs = product.getGda().getGdaRefs().iterator();
                    while (iteratorGdaRefs.hasNext()) {
                        GdaRef gdaRef = (GdaRef) iteratorGdaRefs.next();
                        System.out.println(">>>>> 2 iteratorGdaRefs gdaRef = " + gdaRef.getGdaDescription());
                    }

                    // Nutrition
                    System.out.println(">>>>> 2 getTescoProduct getCalcNutrients = " + product.getCalcNutrition().getCalcNutrients().size());
                    Iterator iteratorCalcNutrients = product.getCalcNutrition().getCalcNutrients().iterator();
                    while (iteratorCalcNutrients.hasNext()) {
                        CalcNutrient calcNutrient = (CalcNutrient) iteratorCalcNutrients.next();
//                        System.out.println(">>>>> 2.1 iteratorCalcNutrients getName = " + calcNutrient.getName());
//                        System.out.println(">>>>> 2.2 iteratorCalcNutrients getValuePer100 = " + calcNutrient.getValuePer100());
//                        System.out.println(">>>>> 2.3 iteratorCalcNutrients getValuePerServing = " + calcNutrient.getValuePerServing());
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     *
     * @param gTin long
     */
    private void getProductByGTIN(final long gTin) {
        System.out.println(">>>>> getTescoProduct gTin = " + gTin);

        HttpClient httpclient = HttpClients.createDefault();

        try {
            URIBuilder uriBuilder = new URIBuilder("https://dev.tescolabs.com/product/");

            uriBuilder.setParameter("gtin", Long.toString(gTin));
            URI uri = uriBuilder.build();

            HttpGet request = new HttpGet(uri);
            request.setHeader(OCP_APIM_SUBSCRIPTION_KEY, OCP_APIM_SUBSCRIPTION_KEY_VALUE);

            // Request body
            StringEntity stringEntity = new StringEntity("{body}");

            HttpResponse response = httpclient.execute(request);
            HttpEntity entity = response.getEntity();

            if (entity != null) {
                System.out.println(EntityUtils.toString(entity));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
