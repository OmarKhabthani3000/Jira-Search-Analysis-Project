import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SQLiteTests {

    @Test
    public final void test01SQLiteGetConnection() {
        Connection connection = null;
        try {
            String url = "jdbc:sqlite:/Users/NOTiFY/NOTiFYwellEJB.db";
            connection = DriverManager.getConnection(url);

            System.out.println(">>>> test01SQLiteGetConnection connection = " + !connection.isClosed());
        } catch (SQLException sqle) {
            System.out.println(">>>>> test01SQLiteGetConnection SQLException = " + sqle.getMessage());
        }

        try {
            Assert.assertTrue("test01SQLiteGetConnection", !Objects.requireNonNull(connection).isClosed());
        } catch (SQLException sqle) {
            System.out.println(">>>>> test01SQLiteGetConnection Assert.assertTrue = " + sqle.getMessage());
        }

        try {
            if (!Objects.requireNonNull(connection).isClosed()) {
                connection.close();
            }
        } catch (SQLException sqle) {
            System.out.println(">>>>> test01SQLiteGetConnection connection SQLException = " + sqle.getMessage());
        }
    }

    @Test
    public final void test02SQLiteGetResultSet() {
        Connection connection = null;
        try {
            String url = "jdbc:sqlite:/Users/NOTiFY/NOTiFYwellEJB.db";
            connection = DriverManager.getConnection(url);

            System.out.println(">>>> test02SQLiteGetResultSet connection = " + !connection.isClosed());
        } catch (SQLException sqle) {
            System.out.println(">>>>> test02SQLiteGetResultSet SQLException = " + sqle.getMessage());
        }

        String sql = "SELECT * FROM FOOD_COSMETIC_MEDICINE_SQLITE";

        try {
            Statement statement = Objects.requireNonNull(connection).createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                String barCode = resultSet.getString("BARCODE");
                String json = resultSet.getString("JSON");

                System.out.println("barCode = " + barCode);
                System.out.println("json = " + json);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException sqle) {
                System.out.println(">>>>> test02SQLiteGetResultSet connection SQLException = " + sqle.getMessage());
            }
        }

    }
}
