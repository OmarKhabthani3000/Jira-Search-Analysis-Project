import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.notifywell.mongodb.MongoDBHelper;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

/**
 * Created by NOTiFY on 29/11/2016.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MongoDBTests {

    private static final String DATABASE_NAME = "notifyWellDB";
    private static final String FOODS_COSMETICS_MEDICINES_COLLECTION_NAME = "foodsCosmeticsMedicines";

//    @BeforeClass
//    public static void setUpClass() {
//    }

    /**
     *
     */
    public MongoDBTests() {
    }

    @Test
    public final void test01createNOTiFYwellDatabase() {
        System.out.println(">>>>> test01createNOTiFYwellDatabase .....");

        MongoDatabase mongoDatabase = MongoDBHelper.getMongoDatabaseNotifyWellDB();

        System.out.println(">>>>> test01createNOTiFYwellDatabase mongoDatabase getName = " + mongoDatabase.getName());

        String databaseName = mongoDatabase.getName();

        Assert.assertEquals("test01createNOTiFYwellDatabase", DATABASE_NAME, databaseName);
    }

    @Test
    public final void test02CreateFoodsCosmeticsMedicinesCollections() {
        System.out.println(">>>>> test02CreateFoodsCosmeticsMedicinesCollections .....");

        MongoCollection mongoCollection = MongoDBHelper.getFoodsCosmeticsMedicinesCollection();

        String collectionName = mongoCollection.getNamespace().getCollectionName();

        System.out.println(">>>>> test02CreateFoodsCosmeticsMedicinesCollections collectionName = " + collectionName);
        Assert.assertEquals("test02CreateFoodsCosmeticsMedicinesCollections", FOODS_COSMETICS_MEDICINES_COLLECTION_NAME, collectionName);
    }

    @Test
    public final void test03GetFoodsCosmeticsMedicinesCollectionCount() {
        System.out.println(">>>>> test03GetFoodsCosmeticsMedicinesCollectionCount ......");

        long collectionCount = MongoDBHelper.getFoodsCosmeticsMedicinesCollectionCount();
        System.out.println(">>>>> test03GetFoodsCosmeticsMedicinesCollectionCount collectionCount = " + collectionCount);

        Assert.assertEquals("test03GetFoodsCosmeticsMedicinesCollectionCount", 0L, collectionCount);
    }

    //@Test
    public final void test04CreateFoodCosmeticMedicineDocument() {
        Document document = MongoDBHelper.createFoodCosmeticMedicineDocument();
        System.out.println(">>>>> test04CreateFoodCosmeticMedicineDocument document = " + document.toJson());

        Assert.assertNotNull("test04CreateFoodCosmeticMedicineDocument", document.toJson());
    }

    @Test
    public final void test05CreateFoodCosmeticMedicineDocumentII() {
        System.out.println(">>>>> test05CreateFoodCosmeticMedicineDocumentII .....");

        Document document = MongoDBHelper.createFoodCosmeticMedicineDocumentII();
        System.out.println(">>>>> test05CreateFoodCosmeticMedicineDocumentII document = " + document.toJson());

        Assert.assertNotNull("test05CreateFoodCosmeticMedicineDocumentII", document.toJson());
    }

    @Test
    public final void test06InsertFoodCosmeticMedicineDocument() {
        Document document;
        MongoCollection mongoCollection = MongoDBHelper.getFoodsCosmeticsMedicinesCollection();

        for (int i = 0; i < 10; i++) {
            document = MongoDBHelper.createFoodCosmeticMedicineDocumentII();
            System.out.println(">>>>> test06InsertFoodCosmeticMedicineDocument document = " + document.toJson());

            MongoDBHelper.insertOneFoodCosmeticMedicineDocument(mongoCollection, document);
        }
        System.out.println(">>>>>> test06InsertFoodCosmeticMedicineDocument getFoodsCosmeticsMedicinesCollectionCount = " + MongoDBHelper.getFoodsCosmeticsMedicinesCollectionCount());

        long collectionCount = MongoDBHelper.getFoodsCosmeticsMedicinesCollectionCount();
        System.out.println(">>>>> test06InsertFoodCosmeticMedicineDocument collectionCount = " + collectionCount);

        Assert.assertEquals("test06InsertFoodCosmeticMedicineDocument", 10L, collectionCount);
    }

    @Test
    public final void test07GetObjectId() {
        ObjectId lastObjectId = null;

        for (int i = 0; i < 10; i++) {
            ObjectId thisObjectId = MongoDBHelper.getObjectId();
            System.out.println(">>>>> test07GetObjectId thisObjectId = " + thisObjectId);
            Assert.assertNotSame(lastObjectId, thisObjectId);

            lastObjectId = thisObjectId;
        }
    }
}