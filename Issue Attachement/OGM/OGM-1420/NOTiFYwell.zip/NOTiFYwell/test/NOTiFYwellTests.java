import com.google.gson.Gson;
import com.notifywell.controller.NOTiFYwellController;
import com.notifywell.gson.eansearch.EANProduct;
import com.notifywell.gson.mongodb.FoodsCosmeticsMedicines;
import com.notifywell.gson.tesco.TescoProducts;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.io.IOException;
import java.math.BigInteger;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class NOTiFYwellTests {

    /**
     *
     */
    private static final String CONTENT_TYPE = "Content-type";

    /**
     *
     */
    private static final String APPLICATION_JSON = "application/json";

    /**
     *
     */
    private static final int SC_OK = 200;

    /**
     *
     */
    private static final int SC_NO_CONTENT = 204;

    /**
     * @throws IOException
     */
    @Test
    public final void test01NOTiFYwellGetProductByBarcode() throws IOException {
        System.out.println(">>>>> test01NOTiFYwellGetProductByBarcode .....");

        // Bonne Maman® Bonne Maman apricot conserve
        String url = "http://localhost:8080/NOTiFYwell/notifywell/product-by-ean/3045320094022";

        // Heinz Baked Beanz
        //String url = "http://localhost:8080/NOTiFYwell/notifywell/product-by-ean/5000157024671";
        // AWS EC2
        //String url = "http://35.178.45.87:8080/NOTiFYwell/notifywell/product-by-ean/5000157024671";

        System.out.println(">>>>> test01NOTiFYwellGetProductByBarcode url = " + url);

        HttpGet httpGet = new HttpGet(url);
        //HttpPost httpPost = new HttpPost(url);
        httpGet.setHeader(CONTENT_TYPE, APPLICATION_JSON);

        //Execute and get the response.
        HttpClient httpClient = HttpClientBuilder.create().build();
        HttpResponse response = httpClient.execute(httpGet);

        System.out.println(">>>>> test01NOTiFYwellGetProductByBarcode response getStatus = " + response.getStatusLine().getStatusCode());
        System.out.println(">>>>> test01NOTiFYwellGetProductByBarcode response getEntity = " + EntityUtils.toString(response.getEntity()));

        Assert.assertEquals(SC_OK, response.getStatusLine().getStatusCode());
    }

    /**
     * @throws IOException
     */
    @Test
    public final void test02NOTiFYwellGetProductByBarcode() throws IOException {
        System.out.println(">>>>> test02NOTiFYwellGetProductByBarcode .....");

        // Tesco Everyday Value Baked Beans In Tomato Sauce 420g
        //String url = "http://localhost:8080/NOTiFYwell/notifywell/product-by-ean/05052319711639";

        // AWS EC2
        String url = "http://35.178.45.87:8080/NOTiFYwell/notifywell/product-by-ean/05052319711639";

        System.out.println(">>>>> test01NOTiFYwellGetProductByBarcode url = " + url);

        HttpGet httpGet = new HttpGet(url);
        //HttpPost httpPost = new HttpPost(url);
        httpGet.setHeader(CONTENT_TYPE, APPLICATION_JSON);

        //Execute and get the response.
        HttpClient httpClient = HttpClientBuilder.create().build();
        HttpResponse response = httpClient.execute(httpGet);

        System.out.println(">>>>> test01NOTiFYwellGetProductByBarcode response getStatus = " + response.getStatusLine().getStatusCode());
        System.out.println(">>>>> test01NOTiFYwellGetProductByBarcode response getEntity = " + EntityUtils.toString(response.getEntity()));

        Assert.assertEquals(SC_OK, response.getStatusLine().getStatusCode());
    }

    /**
     * @throws IOException
     */
    @Test
    public final void test03IsProductInformation() throws IOException {
        System.out.println(">>>>> test04IsProductInformation .....");

        // Tesco Everyday Value Baked Beans In Tomato Sauce 420g
        //String url = "http://localhost:8080/NOTiFYwell/notifywell/product-by-ean/05052319711639";
        String url = "http://35.178.45.87:8080/NOTiFYwell/notifywell/product-by-ean/05052319711639";

        //Heinz Baked Beanz
        //String url = "http://localhost:8080/NOTiFYwell/notifywell/product-by-ean/5000157024671";
        //String url = "http://35.178.45.87:8080/NOTiFYwell/notifywell/product-by-ean/5000157024671";

        // Scott's Oats old fashioned porridge cereal
        //String url = "http://localhost:8080/NOTiFYwell/notifywell/product-by-ean/5000108022190";

        // Unknown/Invalid product
        //String url = "http://localhost:8080/NOTiFYwell/notifywell/product-by-ean/9000123456789";

        // AWS EC2
        //String url = "http://35.176.72.174:8080/NOTiFYwell/notifywell/product-by-ean/05052319711639";

        System.out.println(">>>>> test04IsProductInformation url = " + url);

        HttpGet httpGet = new HttpGet(url);
        httpGet.setHeader(CONTENT_TYPE, APPLICATION_JSON);

        //Execute and get the response.
        HttpClient httpClient = HttpClientBuilder.create().build();
        HttpResponse response = httpClient.execute(httpGet);

        System.out.println(">>>>> test04IsProductInformation response = " + response.getStatusLine().getStatusCode());

        if (response.getStatusLine().getStatusCode() != SC_NO_CONTENT) {
            String json = EntityUtils.toString(response.getEntity());

            if (json.length() > 0) {
                System.out.println(">>>>> test04IsProductInformation response getStatus = " + response.getStatusLine().getStatusCode());
                System.out.println(">>>>> test04IsProductInformation response json = " + json);

                Gson gson = new Gson();

                TescoProducts tescoProducts = null;
                try {
                    tescoProducts = gson.fromJson(json, TescoProducts.class);
                } catch (Exception e) {
                    System.out.println(">>>>> test04IsProductInformation tescoProducts Exception = " + e);

                }

                System.out.println(">>>>> test04IsProductInformation tescoProducts getProducts = " + tescoProducts.getProducts());
                if (tescoProducts.getProducts() != null) {
                    System.out.println(">>>>> test04IsProductInformation tescoProducts = " + tescoProducts.getProducts().get(0).getGtin());
                    System.out.println(">>>>> test04IsProductInformation tescoProducts = " + tescoProducts.getProducts().get(0).getIngredients());
                } else {
                    EANProduct eanProduct = gson.fromJson(json, EANProduct.class);
                    if (eanProduct.getEan() != null && eanProduct.getName() != null) {
                        System.out.println(">>>>> test04IsProductInformation eanProduct getEan = " + eanProduct.getEan());
                        System.out.println(">>>>> test04IsProductInformation eanProduct getName = " + eanProduct.getName());
                    } else {
                        System.out.println(">>>>> test04IsProductInformation else .....");

                        FoodsCosmeticsMedicines foodsCosmeticsMedicines = gson.fromJson(json, FoodsCosmeticsMedicines.class);

                        System.out.println(">>>>> test04IsProductInformation foodsCosmeticsMedicines = " + foodsCosmeticsMedicines);

                        if (foodsCosmeticsMedicines != null) {
                            System.out.println(">>>>> test04IsProductInformation foodsCosmeticsMedicines = " + foodsCosmeticsMedicines.getEan());
                        }
                    }
                }
            }
            Assert.assertEquals(SC_OK, response.getStatusLine().getStatusCode());
            //Assert.assertTrue("getIngredients . ZERO", tescoProducts.getProducts().get(0).getIngredients().size() > 0);
        } else {
            Assert.assertEquals(SC_NO_CONTENT, response.getStatusLine().getStatusCode());

        }
    }

    /**
     * @throws IOException
     */
    @Test
    public final void test04GetLastUpdated() throws IOException {
        System.out.println(">>>>> test05GetLastUpdated .....");

        // Tesco Everyday Value Baked Beans In Tomato Sauce 420g
        String url = "http://localhost:8080/NOTiFYwell/notifywell/product-by-ean/05052319711639";
        System.out.println(">>>>> test04IsProductInformation url = " + url);

        HttpGet httpGet = new HttpGet(url);
        httpGet.setHeader(CONTENT_TYPE, APPLICATION_JSON);

        //Execute and get the response.
        HttpClient httpClient = HttpClientBuilder.create().build();
        HttpResponse response = httpClient.execute(httpGet);

        System.out.println(">>>>> test04IsProductInformation response = " + response.getStatusLine().getStatusCode());

        LocalDateTime localDateTime = null;
        if (response.getStatusLine().getStatusCode() != SC_NO_CONTENT) {
            String json = EntityUtils.toString(response.getEntity());

            if (json.length() > 0) {
                System.out.println(">>>>> test04IsProductInformation response getStatus = " + response.getStatusLine().getStatusCode());
                System.out.println(">>>>> test04IsProductInformation response json = " + json);

                Gson gson = new Gson();

                FoodsCosmeticsMedicines foodsCosmeticsMedicines = gson.fromJson(json, FoodsCosmeticsMedicines.class);

                System.out.println(">>>>> test04IsProductInformation foodsCosmeticsMedicines = " + foodsCosmeticsMedicines);


                if (foodsCosmeticsMedicines != null) {
                    System.out.println(">>>>> test04IsProductInformation foodsCosmeticsMedicines getEan = " + foodsCosmeticsMedicines.getEan());
                    System.out.println(">>>>> test04IsProductInformation foodsCosmeticsMedicines getTimestampLastupdated = " + foodsCosmeticsMedicines.getTimestampLastupdated());
                    // .get$date()

                    long longValue = foodsCosmeticsMedicines.getTimestampLastupdated().get$date().longValue();

                    localDateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(longValue), ZoneId.systemDefault());
                    System.out.println(">>>>> test04IsProductInformation localDateTime = " + localDateTime);
                }
            }
            Assert.assertEquals("2018-02-14T13:00", localDateTime.toString());
        }
    }

    @Test
    public final void test05GetListFoodsCosmeticsMedicines() throws IOException {
        System.out.println(">>>>> test05GetListFoodsCosmeticsMedicines .....");

        String url = "http://localhost:8080/NOTiFYwell/notifywell/get-foods-cosmetics-medicines/";
        System.out.println(">>>>> test05getListFoodsCosmeticsMedicines url = " + url);

        HttpGet httpGet = new HttpGet(url);
        httpGet.setHeader(CONTENT_TYPE, APPLICATION_JSON);

        //Execute and get the response.
        HttpClient httpClient = HttpClientBuilder.create().build();
        HttpResponse response = httpClient.execute(httpGet);

        System.out.println(">>>>> test05GetListFoodsCosmeticsMedicines response getStatus = " + response.getStatusLine().getStatusCode());
        System.out.println(">>>>> test05GetListFoodsCosmeticsMedicines response getEntity = " + EntityUtils.toString(response.getEntity()));

        Assert.assertEquals(SC_OK, response.getStatusLine().getStatusCode());
    }
}
