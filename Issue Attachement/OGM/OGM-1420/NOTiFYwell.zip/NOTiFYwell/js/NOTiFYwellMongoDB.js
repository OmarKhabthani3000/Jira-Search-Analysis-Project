var lastupdated = new ISODate("2018-02-14T13:00:00Z")
//var lastupdated = new ISODate()
print(">>>>> lastupdated = " + lastupdated);

//var objectOd = ObjectId()
//print(">>>>> objectId = " + objectId);

db = connect("localhost:27017/notifyWellDB");
db.dropDatabase();

var dbName = db.getName()
print(">>>>> dbName = " + dbName);

db.createCollection("foodsCosmeticsMedicines");
var collectionFoodsCosmeticsMedicines = db.getCollection("foodsCosmeticsMedicines")
print(">>>>> dbName.collectionFoodsCosmeticsMedicines = " + collectionFoodsCosmeticsMedicines);

var collectionNames = db.getCollectionNames();
print(">>>>> collectionNames = " + collectionNames.length);
print(">>>>> collectionNames = " + collectionNames);

collectionFoodsCosmeticsMedicines.insertOne(
    {
        // _id MongoDB default PK.
        //_id: "",
        ean: "05052319711639",
        gtin: "",
        tpnb: "",
        tpnc: "",
        description: "",
        brand: "",
        supermarket: "",

        // Arrays of data
        //qtyContents: [
        //        "Apple",
        //        "Banana",
        //        "Orange",
        //        "Peach"
        //],

        qtyContents: [
            {
                quantity: "1.1",
                totalQuantity: "1.2",
                quantityUom: "1.3",
                netContents: "1.4",
                avgMeasure: "1.5"
            },

            {
                quantity: "2.1",
                totalQuantity: "2.2",
                quantityUom: "2.3",
                netContents: "2.4",
                avgMeasure: "2.5"
            }
        ],

        productCharacteristics: {
            isFood: "",
            isDrink: "",
            healthScore: "",
            isHazardous: "",
            storageType: ""
        },

        lifestyle: {
            name: "Lifestyle",
            value: "Suitable for Vegetarians"
        },

        product_name: "",
        quantity_grammes: "",
        portion_serving_sachet_item_amount: "",
        live: "",
        timestamp_lastupdated: lastupdated,


        // Arrays of data
        ingredients: {
            ingredient_name: ""
        },

        // Arrays of data
        nutrients: {
            nutrient_name: ""
        },

        // Arrays of data
        e_numbers: {
            e_number_name: ""
        },

        // Arrays of data
        chemicals_minerals_vitamins: {
            chemical_mineral_vitamin_name: ""
        }
    }
);

// load('/Users/NOTiFY/IdeaProjects/NOTiFYwell/js/NOTiFYwellMongoDB.js')
// db
// use notifyWelldb
// db.foodsCosmeticsMedicines.find()
// db.foodsCosmeticsMedicines.find({"qtyContents" : {$all : ["1.1"]}})