db = connect("localhost:27017/notifyWellDB");
//db.dropDatabase();

var dbName = db.getName()
print(">>>>> dbName = " + dbName);

var collectionName = db.getCollection('foodsCosmeticsMedicines').getName()
print(">>>>> collectionName = " + collectionName);

db.foodsCosmeticsMedicines.drop()