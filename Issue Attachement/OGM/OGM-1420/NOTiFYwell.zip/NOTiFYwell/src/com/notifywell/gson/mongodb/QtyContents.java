
package com.notifywell.gson.mongodb;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class QtyContents {

    @SerializedName("quantity")
    @Expose
    private String quantity;
    @SerializedName("totalQuantity")
    @Expose
    private String totalQuantity;
    @SerializedName("quantityUom")
    @Expose
    private String quantityUom;
    @SerializedName("netContents")
    @Expose
    private String netContents;
    @SerializedName("avgMeasure")
    @Expose
    private String avgMeasure;

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(String totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public String getQuantityUom() {
        return quantityUom;
    }

    public void setQuantityUom(String quantityUom) {
        this.quantityUom = quantityUom;
    }

    public String getNetContents() {
        return netContents;
    }

    public void setNetContents(String netContents) {
        this.netContents = netContents;
    }

    public String getAvgMeasure() {
        return avgMeasure;
    }

    public void setAvgMeasure(String avgMeasure) {
        this.avgMeasure = avgMeasure;
    }

}
