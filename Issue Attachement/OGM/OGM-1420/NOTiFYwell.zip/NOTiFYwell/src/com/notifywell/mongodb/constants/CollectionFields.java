package com.notifywell.mongodb.constants;

/**
 * Created by NOTiFY on 30/11/2016.
 */
public final class CollectionFields {

    // 'Foods Cosmetics Medicines' collection
    public static final String GTIN = "gtin";
    public static final String BRAND_SUPERMARKET = "brand_supermarket";
    public static final String PRODUCT_NAME = "product_name";
    public static final String QUANTITY_GRAMMES = "quantity_grammes";
    public static final String PORTION_SERVING_SACHET_ITEM_AMOUNT = "portion_serving_sachet_item_amount";
    public static final String LIVE = "live";
    public static final String TIMESTAMP_LASTUPDATED = "timestamp_lastupdated";

    // Foods Cosmetics Medicines collection  - Arrays []
    public static final String INGREDIENT = "ingredient";
    public static final String NUTRIENT = "nutrient";
    public static final String E_NUMBER = "e_number";
    public static final String CHEMICAL_MINERAL_VITAMIN = "chemical_mineral_vitamin";
}