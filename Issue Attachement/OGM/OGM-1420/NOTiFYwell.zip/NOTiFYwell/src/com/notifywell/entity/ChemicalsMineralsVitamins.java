package com.notifywell.entity;

import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class ChemicalsMineralsVitamins implements Serializable {

    private String chemicalMineralVitaminName;

    /**
     *
     */
    public ChemicalsMineralsVitamins() {
    }

    /**
     *
     * @return String
     */
    public String getChemicalMineralVitaminName() {
        return this.chemicalMineralVitaminName;
    }

    /**
     *
     * @param chemicalMineralVitaminName String
     */
    public void setChemicalMineralVitaminName(String chemicalMineralVitaminName) {
        this.chemicalMineralVitaminName = chemicalMineralVitaminName;
    }
}
