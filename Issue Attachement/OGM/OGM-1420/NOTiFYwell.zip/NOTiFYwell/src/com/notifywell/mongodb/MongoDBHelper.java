package com.notifywell.mongodb;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Indexes;
import com.notifywell.mongodb.constants.CollectionFields;
import org.bson.BsonArray;
import org.bson.BsonInt32;
import org.bson.BsonString;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by NOTiFY on 30/11/2016.
 */
public class MongoDBHelper {

    private static final String DATABASE_NAME = "notifyWellDB";
    private static final String FOODS_COSMETICS_MEDICINES_COLLECTION_NAME = "foodsCosmeticsMedicines";

    //private static CodecRegistry pojoCodecRegistry;

    /**
     * @return MongoClient
     */
    private static MongoClient getMongoDBClient() {
        String LOCALHOST = "localhost";
        int MONGODB_PORT = 27017;

        //pojoCodecRegistry = fromRegistries(MongoClient.getDefaultCodecRegistry(), fromProviders(PojoCodecProvider.builder().automatic(true).build()));

        return new MongoClient(LOCALHOST, MONGODB_PORT);
        //return new MongoClient(LOCALHOST, MongoClientOptions.builder().codecRegistry(pojoCodecRegistry).build());
    }

    private static void cleanup() {
        // refresh the collection each time ...
        MongoDatabase mongoDatabase = MongoDBHelper.getMongoDatabaseNotifyWellDB();
        MongoCollection mongoCollection = mongoDatabase.getCollection(MongoDBHelper.FOODS_COSMETICS_MEDICINES_COLLECTION_NAME);
        mongoCollection.drop();
    }

    /**
     * @return MongoDatabase
     */
    public static MongoDatabase getMongoDatabaseNotifyWellDB() {

        MongoClient mongoClient = MongoDBHelper.getMongoDBClient();

        //mongoClient.dropDatabase(DATABASE_NAME);

        MongoDatabase mongoDatabase = mongoClient.getDatabase(MongoDBHelper.DATABASE_NAME);
        System.out.println(">>>>> getMongoDBDatabaseNotifyWellDB getName = " + mongoDatabase.getName());

        return mongoDatabase;
    }

    /**
     *
     */
    public static void dropFoodsCosmeticsMedicinesCollection() {
        MongoClient mongoClient = MongoDBHelper.getMongoDBClient();

        MongoDatabase mongoDatabase = mongoClient.getDatabase(MongoDBHelper.DATABASE_NAME);
        mongoDatabase.getCollection(MongoDBHelper.FOODS_COSMETICS_MEDICINES_COLLECTION_NAME).drop();

        MongoCollection<Document> mongoCollection = mongoDatabase.getCollection(MongoDBHelper.FOODS_COSMETICS_MEDICINES_COLLECTION_NAME);
        mongoCollection.createIndex(Indexes.ascending(CollectionFields.GTIN));

        System.out.println(">>>>> dropFoodsCosmeticsMedicinesCollection mongoCollection = " + mongoCollection);
    }

    /**
     * @return MongoCollection
     */
    public static MongoCollection<Document> getFoodsCosmeticsMedicinesCollection() {

        MongoClient mongoClient = MongoDBHelper.getMongoDBClient();

        MongoDatabase mongoDatabase = mongoClient.getDatabase(MongoDBHelper.DATABASE_NAME);
        System.out.println(">>>>> getFoodsCosmeticsMedicinesCollection mongoDatabase = " + mongoDatabase.getName());

        //mongoDatabase.getCollection(MongoDBHelper.FOODS_COSMETICS_MEDICINES_COLLECTION_NAME).drop();
        //mongoDatabase.createCollection(MongoDBHelper.FOODS_COSMETICS_MEDICINES_COLLECTION_NAME);

        System.out.println(">>>>> getFoodsCosmeticsMedicinesCollection getCollection = " + mongoDatabase.getCollection(MongoDBHelper.FOODS_COSMETICS_MEDICINES_COLLECTION_NAME).getNamespace().getFullName());

        //return mongoDatabase.getCollection(MongoDBHelper.FOODS_COSMETICS_MEDICINES_COLLECTION_NAME).withCodecRegistry(pojoCodecRegistry);
        return mongoDatabase.getCollection(MongoDBHelper.FOODS_COSMETICS_MEDICINES_COLLECTION_NAME);
    }


    /**
     * @return long
     */
    public static long getFoodsCosmeticsMedicinesCollectionCount() {

        MongoClient mongoClient = MongoDBHelper.getMongoDBClient();

        MongoDatabase mongoDatabase = mongoClient.getDatabase(MongoDBHelper.DATABASE_NAME);
        System.out.println(">>>>> getFoodsCosmeticsMedicinesCollection mongoDatabase = " + mongoDatabase.getName());

        MongoCollection<Document> mongoCollection = mongoDatabase.getCollection(MongoDBHelper.FOODS_COSMETICS_MEDICINES_COLLECTION_NAME);
        //mongoCollection.createIndex(Indexes.ascending(CollectionFields.GTIN));

        System.out.println(">>>>> getFoodsCosmeticsMedicinesCollectionCount mongoCollection count = " + mongoCollection.count());

        return mongoCollection.count();
    }

    /**
     * @return Document
     */
    public static Document createFoodCosmeticMedicineDocument() {
        Document foodCosmeticMedicineDocument = new Document();

        foodCosmeticMedicineDocument
                .append(CollectionFields.GTIN, MongoDBHelper.getObjectId())
                .append(CollectionFields.BRAND_SUPERMARKET, new BsonString(""))
                .append(CollectionFields.PRODUCT_NAME, new BsonString(""))
                .append(CollectionFields.QUANTITY_GRAMMES, new BsonInt32(0))
                .append(CollectionFields.PORTION_SERVING_SACHET_ITEM_AMOUNT, new BsonString(""))
                .append(CollectionFields.LIVE, new BsonString(""))
                .append(CollectionFields.TIMESTAMP_LASTUPDATED, new BsonString(""))

                // Arrays
                .append(CollectionFields.INGREDIENT, new BsonArray(Arrays.asList(new BsonInt32(1), new BsonInt32(2))))
                .append(CollectionFields.NUTRIENT, new BsonArray(Arrays.asList(new BsonInt32(3), new BsonInt32(4))))
                .append(CollectionFields.E_NUMBER, new BsonArray(Arrays.asList(new BsonInt32(5), new BsonInt32(6))))
                .append(CollectionFields.CHEMICAL_MINERAL_VITAMIN, new BsonArray(Arrays.asList(new BsonInt32(7), new BsonInt32(8))));

        return foodCosmeticMedicineDocument;
    }

    /**
     * @return Document
     */
    public static Document createFoodCosmeticMedicineDocumentII() {

        Document foodCosmeticMedicineDocument = new Document();

        foodCosmeticMedicineDocument.append(CollectionFields.GTIN, MongoDBHelper.getObjectId());
        foodCosmeticMedicineDocument.append(CollectionFields.BRAND_SUPERMARKET, new BsonString(""));
        foodCosmeticMedicineDocument.append(CollectionFields.PRODUCT_NAME, new BsonString(""));
        foodCosmeticMedicineDocument.append(CollectionFields.QUANTITY_GRAMMES, new BsonInt32(0));
        foodCosmeticMedicineDocument.append(CollectionFields.PORTION_SERVING_SACHET_ITEM_AMOUNT, new BsonString(""));
        foodCosmeticMedicineDocument.append(CollectionFields.LIVE, new BsonString(""));
        foodCosmeticMedicineDocument.append(CollectionFields.TIMESTAMP_LASTUPDATED, new BsonString(""));

        List<DBObject> ingredientArray = new ArrayList<DBObject>();
        List<DBObject> nutrientArray = new ArrayList<DBObject>();
        List<DBObject> eNumberArray = new ArrayList<DBObject>();
        List<DBObject> chemicalMineralVitaminArray = new ArrayList<DBObject>();

        foodCosmeticMedicineDocument.append(CollectionFields.INGREDIENT, ingredientArray);
        foodCosmeticMedicineDocument.append(CollectionFields.NUTRIENT, nutrientArray);
        foodCosmeticMedicineDocument.append(CollectionFields.E_NUMBER, eNumberArray);
        foodCosmeticMedicineDocument.append(CollectionFields.CHEMICAL_MINERAL_VITAMIN, chemicalMineralVitaminArray);

        return foodCosmeticMedicineDocument;
    }


    /**
     * @param ean String
     * @return Document
     */
    public static Document findByByEAN(final String ean) {
        BasicDBObject query = new BasicDBObject();
        query.put("ean", new ObjectId(ean));

        MongoCollection<Document> mongoCollection = getFoodsCosmeticsMedicinesCollection();

        mongoCollection.find();

        return null;
    }

    /**
     * @param eventCollection              MongoCollection
     * @param foodCosmeticMedicineDocument Document
     */
    public static void insertOneFoodCosmeticMedicineDocument(MongoCollection<Document> eventCollection, Document foodCosmeticMedicineDocument) {
        System.out.println(">>>>> insertOneFoodCosmeticMedicineDocument foodCosmeticMedicineDocument = " + foodCosmeticMedicineDocument.toJson());

        eventCollection.insertOne(foodCosmeticMedicineDocument);
    }

    /**
     * @return ObjectId
     */
    public static ObjectId getObjectId() {
        return new ObjectId();
    }
}
