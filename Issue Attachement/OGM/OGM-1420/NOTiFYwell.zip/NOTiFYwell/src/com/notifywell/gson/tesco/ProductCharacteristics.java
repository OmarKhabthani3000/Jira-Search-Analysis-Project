package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class ProductCharacteristics implements Serializable {

    private final static long serialVersionUID = -8846437086949401729L;
    @SerializedName("isFood")
    @Expose
    private boolean isFood;
    @SerializedName("isDrink")
    @Expose
    private boolean isDrink;
    @SerializedName("healthScore")
    @Expose
    private int healthScore;
    @SerializedName("isHazardous")
    @Expose
    private boolean isHazardous;
    @SerializedName("storageType")
    @Expose
    private String storageType;

    public boolean isIsFood() {
        return isFood;
    }

    public void setIsFood(boolean isFood) {
        this.isFood = isFood;
    }

    public boolean isIsDrink() {
        return isDrink;
    }

    public void setIsDrink(boolean isDrink) {
        this.isDrink = isDrink;
    }

    public int getHealthScore() {
        return healthScore;
    }

    public void setHealthScore(int healthScore) {
        this.healthScore = healthScore;
    }

    public boolean isIsHazardous() {
        return isHazardous;
    }

    public void setIsHazardous(boolean isHazardous) {
        this.isHazardous = isHazardous;
    }

    public String getStorageType() {
        return storageType;
    }

    public void setStorageType(String storageType) {
        this.storageType = storageType;
    }

}
