package com.notifywell.gson.eansearch;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Productlist implements Serializable {

    private final static long serialVersionUID = 4816431480737862223L;
    @SerializedName("ean")
    @Expose
    private String ean;
    @SerializedName("name")
    @Expose
    private String name;

    public String getEan() {
        return ean;
    }

    public void setEan(String ean) {
        this.ean = ean;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
