package com.notifywell.sqlite;

public class SQLiteHelper {

    public static void createSQLiteDatabase() {

    }
}
