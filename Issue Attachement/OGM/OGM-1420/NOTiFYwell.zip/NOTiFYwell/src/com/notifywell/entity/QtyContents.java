package com.notifywell.entity;

import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class QtyContents implements Serializable {

    private String quantity;
    private String totalQuantity;
    private String quantityUom;
    private String netContents;
    private String avgMeasure;

    /**
     *
     */
    public QtyContents() {
    }

    /**
     * @return String
     */
    public String getQuantity() {
        return this.quantity;
    }

    /**
     * @param quantity String
     */
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    /**
     * @return String
     */
    public String getTotalQuantity() {
        return this.totalQuantity;
    }

    /**
     * @param totalQuantity String
     */
    public void setTotalQuantity(String totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    /**
     * @return String
     */
    public String getQuantityUom() {
        return this.quantityUom;
    }

    /**
     * @param quantityUom String
     */
    public void setQuantityUom(String quantityUom) {
        this.quantityUom = quantityUom;
    }

    /**
     * @return String
     */
    public String getNetContents() {
        return this.netContents;
    }

    /**
     * @param netContents String
     */
    public void setNetContents(String netContents) {
        this.netContents = netContents;
    }

    /**
     * @return String
     */
    public String getAvgMeasure() {
        return this.avgMeasure;
    }

    /**
     * @param avgMeasure String
     */
    public void setAvgMeasure(String avgMeasure) {
        this.avgMeasure = avgMeasure;
    }
}
