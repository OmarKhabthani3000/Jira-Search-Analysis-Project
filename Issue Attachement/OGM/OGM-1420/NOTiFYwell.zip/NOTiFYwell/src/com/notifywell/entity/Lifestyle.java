package com.notifywell.entity;

import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class Lifestyle implements Serializable {

    private String name;
    private String vaue;

    /**
     *
     */
    public Lifestyle() {
    }

    /**
     *
     * @return
     */
    public String getName() {
        return this.name;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return
     */
    public String getVaue() {
        return this.vaue;
    }

    /**
     *
     * @param vaue
     */
    public void setVaue(String vaue) {
        this.vaue = vaue;
    }
}
