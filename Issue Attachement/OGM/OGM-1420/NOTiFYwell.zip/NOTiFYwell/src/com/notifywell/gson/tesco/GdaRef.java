package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class GdaRef implements Serializable {

    private final static long serialVersionUID = -3166069907320251106L;
    @SerializedName("gdaDescription")
    @Expose
    private String gdaDescription;
    @SerializedName("headers")
    @Expose
    private List<String> headers = null;
    @SerializedName("footers")
    @Expose
    private List<String> footers = null;
    @SerializedName("values")
    @Expose
    private List<Value> values = null;

    public String getGdaDescription() {
        return gdaDescription;
    }

    public void setGdaDescription(String gdaDescription) {
        this.gdaDescription = gdaDescription;
    }

    public List<String> getHeaders() {
        return headers;
    }

    public void setHeaders(List<String> headers) {
        this.headers = headers;
    }

    public List<String> getFooters() {
        return footers;
    }

    public void setFooters(List<String> footers) {
        this.footers = footers;
    }

    public List<Value> getValues() {
        return values;
    }

    public void setValues(List<Value> values) {
        this.values = values;
    }

}
