package com.notifywell.webservices;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 */
@ApplicationPath("notifywell")
public class ApplicationConfig extends Application {
    public ApplicationConfig() {
    }
}


