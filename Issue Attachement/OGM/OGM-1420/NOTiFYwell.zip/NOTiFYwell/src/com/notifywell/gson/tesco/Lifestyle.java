package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Lifestyle implements Serializable {

    private final static long serialVersionUID = 2793501609286000219L;
    @SerializedName("lifestyle")
    @Expose
    private Lifestyle_ lifestyle;

    public Lifestyle_ getLifestyle() {
        return lifestyle;
    }

    public void setLifestyle(Lifestyle_ lifestyle) {
        this.lifestyle = lifestyle;
    }

}
