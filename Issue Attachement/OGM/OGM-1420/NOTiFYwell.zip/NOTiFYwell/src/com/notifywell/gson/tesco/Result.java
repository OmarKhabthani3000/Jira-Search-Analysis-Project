
package com.notifywell.gson.tesco;

import java.io.Serializable;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Result implements Serializable
{

    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("tpnb")
    @Expose
    private int tpnb;
    @SerializedName("ContentsMeasureType")
    @Expose
    private String contentsMeasureType;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("UnitOfSale")
    @Expose
    private int unitOfSale;
    @SerializedName("description")
    @Expose
    private List<String> description = null;
    @SerializedName("AverageSellingUnitWeight")
    @Expose
    private float averageSellingUnitWeight;
    @SerializedName("UnitQuantity")
    @Expose
    private String unitQuantity;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("ContentsQuantity")
    @Expose
    private float contentsQuantity;
    @SerializedName("price")
    @Expose
    private float price;
    @SerializedName("unitprice")
    @Expose
    private float unitprice;
    private final static long serialVersionUID = 7657374582635456929L;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getTpnb() {
        return tpnb;
    }

    public void setTpnb(int tpnb) {
        this.tpnb = tpnb;
    }

    public String getContentsMeasureType() {
        return contentsMeasureType;
    }

    public void setContentsMeasureType(String contentsMeasureType) {
        this.contentsMeasureType = contentsMeasureType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getUnitOfSale() {
        return unitOfSale;
    }

    public void setUnitOfSale(int unitOfSale) {
        this.unitOfSale = unitOfSale;
    }

    public List<String> getDescription() {
        return description;
    }

    public void setDescription(List<String> description) {
        this.description = description;
    }

    public float getAverageSellingUnitWeight() {
        return averageSellingUnitWeight;
    }

    public void setAverageSellingUnitWeight(float averageSellingUnitWeight) {
        this.averageSellingUnitWeight = averageSellingUnitWeight;
    }

    public String getUnitQuantity() {
        return unitQuantity;
    }

    public void setUnitQuantity(String unitQuantity) {
        this.unitQuantity = unitQuantity;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public float getContentsQuantity() {
        return contentsQuantity;
    }

    public void setContentsQuantity(float contentsQuantity) {
        this.contentsQuantity = contentsQuantity;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public float getUnitprice() {
        return unitprice;
    }

    public void setUnitprice(float unitprice) {
        this.unitprice = unitprice;
    }

}
