package com.notifywell.interfaces;

//import javax.ejb.Local;

/**
 * Created by NOTiFY on 11/01/2018.
 */
//@Local
public interface NOTiFYwellLocal extends NOTiFYwellCommonBusiness {

}
