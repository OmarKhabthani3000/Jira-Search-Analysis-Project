package com.notifywell.entity;

import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class Enumbers implements Serializable {

    private String eNumberName;

    /**
     *
     */
    public Enumbers() {
    }

    /**
     *
     * @return String
     */
    public String geteNumberName() {
        return this.eNumberName;
    }

    /**
     *
     * @param eNumberName String
     */
    public void seteNumberName(String eNumberName) {
        this.eNumberName = eNumberName;
    }
}
