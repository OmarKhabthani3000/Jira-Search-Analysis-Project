package com.notifywell.ejb;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.notifywell.entity.FoodsCosmeticsMedicines;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Stateless
@LocalBean
@TransactionManagement(TransactionManagementType.CONTAINER)
public class FoodsCosmeticsMedicinesEJB {

    /**
     *
     */
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     *
     */
    @PersistenceContext(unitName = "nOTiFYwellMongoDBPersistenceUnit")
    private EntityManager entityManager;

    /**
     *
     * @return String
     */
    public String getAllFoodsCosmeticsMedicinesJSON() {
        logger.info(">>>>> getAllFoodsCosmeticsMedicinesJSON = ");

        Query query = entityManager.createQuery("FROM FoodsCosmeticsMedicines f");
        List<com.notifywell.entity.FoodsCosmeticsMedicines> foodsCosmeticsMedicinesList = query.getResultList();
        logger.info(">>>>> getAllFoodsCosmeticsMedicinesJSON foodsCosmeticsMedicinesList = " + foodsCosmeticsMedicinesList.size());

        for (FoodsCosmeticsMedicines foodsCosmeticsMedicines : foodsCosmeticsMedicinesList) {
            logger.info(">>>>> getAllFoodsCosmeticsMedicinesJSON id = " + foodsCosmeticsMedicines.getId());
            logger.info(">>>>> getAllFoodsCosmeticsMedicinesJSON ean = " + foodsCosmeticsMedicines.getEan());
            logger.info(">>>>> getAllFoodsCosmeticsMedicinesJSON description = " + foodsCosmeticsMedicines.getDescription());

            logger.info(">>>>> getAllFoodsCosmeticsMedicinesJSON getQtyContentsList = " + foodsCosmeticsMedicines.getQtyContentsList());
            logger.info(">>>>> getAllFoodsCosmeticsMedicinesJSON getProductCharacteristics getProductCharacteristics = " + foodsCosmeticsMedicines.getProductCharacteristics().getIsFood());
            logger.info(">>>>> getAllFoodsCosmeticsMedicinesJSON getLifestyle getLifestyle = " + foodsCosmeticsMedicines.getLifestyle().getName());
        }

        Gson gson = getGsonBuilder().create();
        // deserialize
        String json = gson.toJson(foodsCosmeticsMedicinesList);

        logger.info(json);

        return json;
    }

    /**
     * @return List<FoodsCosmeticsMedicines>
     */
    public List<FoodsCosmeticsMedicines> getAllFoodsCosmeticsMedicines() {
        String json = null;

        Query query = entityManager.createQuery("FROM FoodsCosmeticsMedicines f");
        List<com.notifywell.entity.FoodsCosmeticsMedicines> foodsCosmeticsMedicinesList = query.getResultList();
        logger.info(">>>>> getAllFoodsCosmeticsMedicines foodsCosmeticsMedicinesList = " + foodsCosmeticsMedicinesList.size());

        for (com.notifywell.entity.FoodsCosmeticsMedicines foodsCosmeticsMedicines : foodsCosmeticsMedicinesList) {
            logger.info(">>>>> foodsCosmeticsMedicines id = " + foodsCosmeticsMedicines.getId());
            logger.info(">>>>> foodsCosmeticsMedicines ean = " + foodsCosmeticsMedicines.getEan());
            logger.info(">>>>> foodsCosmeticsMedicines description = " + foodsCosmeticsMedicines.getDescription());
        }

        //return Response.ok(json, MediaType.APPLICATION_JSON).build();
        return foodsCosmeticsMedicinesList;
    }

    /**
     * @return GsonBuilder
     */
    private GsonBuilder getGsonBuilder() {

        final String GSON_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

        return new GsonBuilder()
                .excludeFieldsWithoutExposeAnnotation()
                .setDateFormat(GSON_DATE_FORMAT)
                .serializeNulls()
                .setPrettyPrinting();
    }
}
