package com.notifywell.interfaces;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import java.io.IOException;

/**
 * Created by NOTiFY on 11/01/2018.
 */
public interface NOTiFYwellCommonBusiness {

    /**
     *
     * @return Response
     * @throws IOException IOException
     */
    Response getListFoodsCosmeticsMedicines() throws IOException;

    /**
     *
     * @param ean String
     * @return Response
     */
    //Response getProductByEAN(HttpHeaders httpHeaders, String httpPost, String ean);
    Response getProductByEAN(String ean) throws IOException;

}
