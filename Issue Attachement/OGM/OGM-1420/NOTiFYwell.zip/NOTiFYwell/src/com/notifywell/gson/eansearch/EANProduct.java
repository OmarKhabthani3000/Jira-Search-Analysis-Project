package com.notifywell.gson.eansearch;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class EANProduct {

    @SerializedName("ean")
    @Expose
    private String ean;
    @SerializedName("name")
    @Expose
    private String name;

    public String getEan() {
        return ean;
    }

    public void setEan(String ean) {
        this.ean = ean;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "EANProduct{" +
                "ean='" + ean + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}