package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class Product implements Serializable {

    private final static long serialVersionUID = -3553801005685566479L;
    @SerializedName("gtin")
    @Expose
    private String gtin;
    @SerializedName("tpnb")
    @Expose
    private String tpnb;
    @SerializedName("tpnc")
    @Expose
    private String tpnc;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("brand")
    @Expose
    private String brand;
    @SerializedName("qtyContents")
    @Expose
    private QtyContents qtyContents;
    @SerializedName("productCharacteristics")
    @Expose
    private ProductCharacteristics productCharacteristics;
    @SerializedName("ingredients")
    @Expose
    private List<String> ingredients = null;
    @SerializedName("gda")
    @Expose
    private Gda gda;
    @SerializedName("calcNutrition")
    @Expose
    private CalcNutrition calcNutrition;
    @SerializedName("storage")
    @Expose
    private List<String> storage = null;
    @SerializedName("pkgDimensions")
    @Expose
    private List<PkgDimension> pkgDimensions = null;
    @SerializedName("productAttributes")
    @Expose
    private List<ProductAttribute> productAttributes = null;

    public String getGtin() {
        return gtin;
    }

    public void setGtin(String gtin) {
        this.gtin = gtin;
    }

    public String getTpnb() {
        return tpnb;
    }

    public void setTpnb(String tpnb) {
        this.tpnb = tpnb;
    }

    public String getTpnc() {
        return tpnc;
    }

    public void setTpnc(String tpnc) {
        this.tpnc = tpnc;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public QtyContents getQtyContents() {
        return qtyContents;
    }

    public void setQtyContents(QtyContents qtyContents) {
        this.qtyContents = qtyContents;
    }

    public ProductCharacteristics getProductCharacteristics() {
        return productCharacteristics;
    }

    public void setProductCharacteristics(ProductCharacteristics productCharacteristics) {
        this.productCharacteristics = productCharacteristics;
    }

    public List<String> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<String> ingredients) {
        this.ingredients = ingredients;
    }

    public Gda getGda() {
        return gda;
    }

    public void setGda(Gda gda) {
        this.gda = gda;
    }

    public CalcNutrition getCalcNutrition() {
        return calcNutrition;
    }

    public void setCalcNutrition(CalcNutrition calcNutrition) {
        this.calcNutrition = calcNutrition;
    }

    public List<String> getStorage() {
        return storage;
    }

    public void setStorage(List<String> storage) {
        this.storage = storage;
    }

    public List<PkgDimension> getPkgDimensions() {
        return pkgDimensions;
    }

    public void setPkgDimensions(List<PkgDimension> pkgDimensions) {
        this.pkgDimensions = pkgDimensions;
    }

    public List<ProductAttribute> getProductAttributes() {
        return productAttributes;
    }

    public void setProductAttributes(List<ProductAttribute> productAttributes) {
        this.productAttributes = productAttributes;
    }

}
