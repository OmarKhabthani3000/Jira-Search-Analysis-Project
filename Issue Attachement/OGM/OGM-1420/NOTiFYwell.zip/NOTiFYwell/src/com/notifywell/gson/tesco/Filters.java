package com.notifywell.gson.tesco;

import java.io.Serializable;

public class Filters implements Serializable {

    private final static long serialVersionUID = 514763188867945361L;

}
