package com.notifywell.entity;

import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class Ingredients implements Serializable {

    /*

     */
    private String ingredientName;

    /**
     *
     */
    public Ingredients() {
    }

    /**
     *
     * @return String
     */
    public String getIngredientName() {
        return this.ingredientName;
    }

    /**
     *
     * @param ingredientName String
     */
    public void setIngredientName(String ingredientName) {
        this.ingredientName = ingredientName;
    }
}
