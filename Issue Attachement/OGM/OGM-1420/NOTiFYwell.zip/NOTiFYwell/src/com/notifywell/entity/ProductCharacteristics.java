package com.notifywell.entity;

import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class ProductCharacteristics implements Serializable {

    private String isFood;
    private String isDrink;
    private String healthScore;
    private String isHazardous;
    private String storageType;

    /**
     *
     */
    public ProductCharacteristics() {
    }

    public String getIsFood() {
        return this.isFood;
    }

    public void setIsFood(String isFood) {
        this.isFood = isFood;
    }

    public String getIsDrink() {
        return this.isDrink;
    }

    public void setIsDrink(String isDrink) {
        this.isDrink = isDrink;
    }

    public String getHealthScore() {
        return this.healthScore;
    }

    public void setHealthScore(String healthScore) {
        this.healthScore = healthScore;
    }

    public String getIsHazardous() {
        return this.isHazardous;
    }

    public void setIsHazardous(String isHazardous) {
        this.isHazardous = isHazardous;
    }

    public String getStorageType() {
        return this.storageType;
    }

    public void setStorageType(String storageType) {
        this.storageType = storageType;
    }
}
