
package com.notifywell.gson.mongodb;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ChemicalsMineralsVitamins {

    @SerializedName("chemical_mineral_vitamin_name")
    @Expose
    private String chemicalMineralVitaminName;

    public String getChemicalMineralVitaminName() {
        return chemicalMineralVitaminName;
    }

    public void setChemicalMineralVitaminName(String chemicalMineralVitaminName) {
        this.chemicalMineralVitaminName = chemicalMineralVitaminName;
    }

}
