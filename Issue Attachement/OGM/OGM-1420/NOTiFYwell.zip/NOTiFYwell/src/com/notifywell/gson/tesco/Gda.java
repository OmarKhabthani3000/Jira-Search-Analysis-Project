package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class Gda implements Serializable {

    private final static long serialVersionUID = -3294034513885625897L;
    @SerializedName("gdaRefs")
    @Expose
    private List<GdaRef> gdaRefs = null;

    public List<GdaRef> getGdaRefs() {
        return gdaRefs;
    }

    public void setGdaRefs(List<GdaRef> gdaRefs) {
        this.gdaRefs = gdaRefs;
    }

}
