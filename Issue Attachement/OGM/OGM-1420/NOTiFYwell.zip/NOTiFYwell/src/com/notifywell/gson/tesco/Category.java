package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class Category implements Serializable {

    private final static long serialVersionUID = -4087010328688872752L;
    @SerializedName("cooking_instructions")
    @Expose
    private List<CookingInstruction> cookingInstructions = null;
    @SerializedName("lifestyle")
    @Expose
    private List<Lifestyle> lifestyle = null;

    public List<CookingInstruction> getCookingInstructions() {
        return cookingInstructions;
    }

    public void setCookingInstructions(List<CookingInstruction> cookingInstructions) {
        this.cookingInstructions = cookingInstructions;
    }

    public List<Lifestyle> getLifestyle() {
        return lifestyle;
    }

    public void setLifestyle(List<Lifestyle> lifestyle) {
        this.lifestyle = lifestyle;
    }

}
