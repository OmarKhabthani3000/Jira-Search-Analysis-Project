package com.notifywell.tesco;

import com.notifywell.gson.tesco.Result;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.net.URI;
import java.util.Iterator;
import java.util.List;

public class TescoHelper {

    final static String OCP_APIM_SUBSCRIPTION_KEY = "Ocp-Apim-Subscription-Key";
    final static String OCP_APIM_SUBSCRIPTION_KEY_VALUE = "68c52a783af74cf6997dc536861d0d8f";

    /**
     *
     */
    public final static String getProductByGTIN(final String gTIN) throws IOException {
        System.out.println(">>>>> getProductByGTIN gTIN = " + gTIN);

        HttpClient httpclient = HttpClients.createDefault();
        HttpEntity entity = null;

        String json = null;
        try {
            URIBuilder uriBuilder = new URIBuilder("https://dev.tescolabs.com/product/");

            uriBuilder.setParameter("gtin", gTIN);

            URI uri = uriBuilder.build();
            HttpGet request = new HttpGet(uri);
            request.setHeader(OCP_APIM_SUBSCRIPTION_KEY, OCP_APIM_SUBSCRIPTION_KEY_VALUE);

            // Request body
            StringEntity stringEntity = new StringEntity("{body}");
            //request.setEntity(stringEntity);

            HttpResponse response = httpclient.execute(request);
            entity = response.getEntity();

            if (entity != null) {
                json = EntityUtils.toString(entity);
                System.out.println(">>>>> getProductByGTIN json = " + json);

            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return json;
    }

    /**
     *
     * @param resultList List
     */
    public final static void getResults(List<Result> resultList) {
        int count = 0;

        Iterator iterator = resultList.iterator();
        while (iterator.hasNext()) {
            Result result = (Result) iterator.next();

            System.out.println(">>>>> getResults count = " + count);
            System.out.println(">>>>> getResults getTpnb = " + result.getTpnb());
            System.out.println(">>>>> getResults getTpnb = " + result.getName());

            count++;
        }
    }

}
