
package com.notifywell.gson.mongodb;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ENumbers {

    @SerializedName("e_number_name")
    @Expose
    private String eNumberName;

    public String getENumberName() {
        return eNumberName;
    }

    public void setENumberName(String eNumberName) {
        this.eNumberName = eNumberName;
    }

}
