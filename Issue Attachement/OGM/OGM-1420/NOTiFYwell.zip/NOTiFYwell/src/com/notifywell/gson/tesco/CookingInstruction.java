package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class CookingInstruction implements Serializable {

    private final static long serialVersionUID = 1256327983361302766L;
    @SerializedName("cooking_method")
    @Expose
    private CookingMethod cookingMethod;
    @SerializedName("cooking_instructions")
    @Expose
    private CookingInstructions cookingInstructions;

    public CookingMethod getCookingMethod() {
        return cookingMethod;
    }

    public void setCookingMethod(CookingMethod cookingMethod) {
        this.cookingMethod = cookingMethod;
    }

    public CookingInstructions getCookingInstructions() {
        return cookingInstructions;
    }

    public void setCookingInstructions(CookingInstructions cookingInstructions) {
        this.cookingInstructions = cookingInstructions;
    }

}
