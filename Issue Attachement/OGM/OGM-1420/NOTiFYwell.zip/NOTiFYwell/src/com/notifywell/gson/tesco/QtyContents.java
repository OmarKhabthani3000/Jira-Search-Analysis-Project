package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class QtyContents implements Serializable {

    private final static long serialVersionUID = 9146788911429524718L;
    @SerializedName("quantity")
    @Expose
    private float quantity;
    @SerializedName("totalQuantity")
    @Expose
    private float totalQuantity;
    @SerializedName("quantityUom")
    @Expose
    private String quantityUom;
    @SerializedName("netContents")
    @Expose
    private String netContents;

    public float getQuantity() {
        return quantity;
    }

    public void setQuantity(float quantity) {
        this.quantity = quantity;
    }

    public float getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(float totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public String getQuantityUom() {
        return quantityUom;
    }

    public void setQuantityUom(String quantityUom) {
        this.quantityUom = quantityUom;
    }

    public String getNetContents() {
        return netContents;
    }

    public void setNetContents(String netContents) {
        this.netContents = netContents;
    }

}
