package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class Products implements Serializable {

    private final static long serialVersionUID = 8791593846458654985L;
    @SerializedName("input_query")
    @Expose
    private String inputQuery;
    @SerializedName("output_query")
    @Expose
    private String outputQuery;
    @SerializedName("filters")
    @Expose
    private Filters filters;
    @SerializedName("totals")
    @Expose
    private Totals totals;
    @SerializedName("queryPhase")
    @Expose
    private String queryPhase;
    @SerializedName("config")
    @Expose
    private String config;
    @SerializedName("results")
    @Expose
    private List<Result> results = null;
    @SerializedName("suggestions")
    @Expose
    private List<Suggestion> suggestions = null;

    public String getInputQuery() {
        return inputQuery;
    }

    public void setInputQuery(String inputQuery) {
        this.inputQuery = inputQuery;
    }

    public String getOutputQuery() {
        return outputQuery;
    }

    public void setOutputQuery(String outputQuery) {
        this.outputQuery = outputQuery;
    }

    public Filters getFilters() {
        return filters;
    }

    public void setFilters(Filters filters) {
        this.filters = filters;
    }

    public Totals getTotals() {
        return totals;
    }

    public void setTotals(Totals totals) {
        this.totals = totals;
    }

    public String getQueryPhase() {
        return queryPhase;
    }

    public void setQueryPhase(String queryPhase) {
        this.queryPhase = queryPhase;
    }

    public String getConfig() {
        return config;
    }

    public void setConfig(String config) {
        this.config = config;
    }

    public List<Result> getResults() {
        return results;
    }

    public void setResults(List<Result> results) {
        this.results = results;
    }

    public List<Suggestion> getSuggestions() {
        return suggestions;
    }

    public void setSuggestions(List<Suggestion> suggestions) {
        this.suggestions = suggestions;
    }

}
