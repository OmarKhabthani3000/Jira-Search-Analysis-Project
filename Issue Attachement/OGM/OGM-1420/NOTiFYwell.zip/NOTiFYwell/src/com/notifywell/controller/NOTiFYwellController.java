package com.notifywell.controller;

import com.notifywell.ejb.FoodsCosmeticsMedicinesEJB;
import com.notifywell.entity.FoodsCosmeticsMedicines;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Model;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Model
@Path("/")
public class NOTiFYwellController {

    /**
     *
     */
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     *
     */
    @Inject
    private FoodsCosmeticsMedicinesEJB foodsCosmeticsMedicinesEJB;

    /**
     *
     */
    public NOTiFYwellController() {
    }

    /**
     * @return Response
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/get-foods-cosmetics-medicines")
    public Response getAllFoodsCosmeticsMedicinesJSON() {
        logger.info(">>>>> NOTiFYwellController getAllFoodsCosmeticsMedicinesJSON .....");

        String json = foodsCosmeticsMedicinesEJB.getAllFoodsCosmeticsMedicinesJSON();

        return Response.ok(json, MediaType.APPLICATION_JSON).build();
    }

    /**
     *
     * @return List<FoodsCosmeticsMedicines>
     */
    public List<FoodsCosmeticsMedicines> getAllFoodsCosmeticsMedicines() {
        logger.info(">>>>> NOTiFYwellController NOTiFYwellController .....");

        List<FoodsCosmeticsMedicines> foodsCosmeticsMedicinesList = foodsCosmeticsMedicinesEJB.getAllFoodsCosmeticsMedicines();

        return foodsCosmeticsMedicinesList;
    }
}

