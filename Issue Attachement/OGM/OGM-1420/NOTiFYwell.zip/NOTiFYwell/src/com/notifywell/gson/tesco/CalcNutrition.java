package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class CalcNutrition implements Serializable {

    private final static long serialVersionUID = -5991725617275085431L;
    @SerializedName("per100Header")
    @Expose
    private String per100Header;
    @SerializedName("perServingHeader")
    @Expose
    private String perServingHeader;
    @SerializedName("calcNutrients")
    @Expose
    private List<CalcNutrient> calcNutrients = null;

    public String getPer100Header() {
        return per100Header;
    }

    public void setPer100Header(String per100Header) {
        this.per100Header = per100Header;
    }

    public String getPerServingHeader() {
        return perServingHeader;
    }

    public void setPerServingHeader(String perServingHeader) {
        this.perServingHeader = perServingHeader;
    }

    public List<CalcNutrient> getCalcNutrients() {
        return calcNutrients;
    }

    public void setCalcNutrients(List<CalcNutrient> calcNutrients) {
        this.calcNutrients = calcNutrients;
    }

}
