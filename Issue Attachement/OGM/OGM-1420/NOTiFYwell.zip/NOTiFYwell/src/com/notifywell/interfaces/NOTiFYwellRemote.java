package com.notifywell.interfaces;

//import javax.ejb.Remote;

/**
 * Created by NOTiFY on 03/05/2017.
 */
//@Remote
public interface NOTiFYwellRemote extends NOTiFYwellCommonBusiness {

}
