package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class CalcNutrient implements Serializable {

    private final static long serialVersionUID = -2210441543541649347L;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("valuePer100")
    @Expose
    private String valuePer100;
    @SerializedName("valuePerServing")
    @Expose
    private String valuePerServing;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValuePer100() {
        return valuePer100;
    }

    public void setValuePer100(String valuePer100) {
        this.valuePer100 = valuePer100;
    }

    public String getValuePerServing() {
        return valuePerServing;
    }

    public void setValuePerServing(String valuePerServing) {
        this.valuePerServing = valuePerServing;
    }

}
