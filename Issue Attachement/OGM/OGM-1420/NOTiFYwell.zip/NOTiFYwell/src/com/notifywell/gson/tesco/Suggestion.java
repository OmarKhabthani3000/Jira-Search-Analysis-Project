package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Suggestion implements Serializable {

    private final static long serialVersionUID = 2072365137665033447L;
    @SerializedName("text")
    @Expose
    private String text;
    @SerializedName("score")
    @Expose
    private float score;
    @SerializedName("freq")
    @Expose
    private int freq;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public float getScore() {
        return score;
    }

    public void setScore(float score) {
        this.score = score;
    }

    public int getFreq() {
        return freq;
    }

    public void setFreq(int freq) {
        this.freq = freq;
    }

}
