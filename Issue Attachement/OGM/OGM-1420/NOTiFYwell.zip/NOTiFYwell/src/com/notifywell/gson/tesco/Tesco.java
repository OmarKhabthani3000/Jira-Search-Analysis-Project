package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Tesco implements Serializable {

    private final static long serialVersionUID = -5940652856523212541L;
    @SerializedName("uk")
    @Expose
    private Uk uk;

    public Uk getUk() {
        return uk;
    }

    public void setUk(Uk uk) {
        this.uk = uk;
    }

}
