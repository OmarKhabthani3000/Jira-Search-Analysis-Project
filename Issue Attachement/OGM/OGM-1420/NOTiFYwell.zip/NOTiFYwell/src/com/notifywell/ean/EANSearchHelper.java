package com.notifywell.ean;

import com.google.gson.Gson;
import com.notifywell.gson.eansearch.EANSearch;
import com.notifywell.gson.eansearch.Productlist;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EANSearchHelper {

    /**
     *
     */
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     *
     */
    final static String API_TOKEN = "Biggles-1957"; // your private API access token

    /**
     *
     */
    public static String getProductByEan(final String ean) {
//        String productName = "uknown";
        System.out.println(">>>>> EANSearchHelper getProductByEan ean = " + ean);

        StringBuffer apiResult = new StringBuffer(0);
        try {
            URL url = new URL("http://api.ean-search.org/api?token=" + API_TOKEN + "&op=barcode-lookup&ean=" + ean + "&format=json");

            InputStream is = url.openStream();
            int pointer = 0;
            //StringBuffer apiResult = new StringBuffer();

            while ((pointer = is.read()) != -1) {
                apiResult.append((char) pointer);
            }

            System.out.println(">>>>> EANSearchHelper getProductByEan apiResult = " + apiResult.toString());

            // you can use a real XML parser,
            // but a regular expression is much faster

//            Pattern p = Pattern.compile("<name>(.*)</name>");
//            Matcher m = p.matcher(apiResult);
//            if (m.find()) {
//                productName = m.group(1);
//            }
        } catch (MalformedURLException mue) {
            mue.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (RuntimeException rte) {
            rte.printStackTrace();
        }
//        System.out.println(">>>>> getProductByEan EAN = " + ean + " Product = " + productName);

        return  apiResult.toString();
    }

    /**
     *
     */
    public static void getProductByBarcodePrefix() {
        //&op=barcode-prefix-search&prefix=0885909

        //String prefix = "0885909"; // search for this prefix EAN code
        String prefix = "8410076600"; // search for this prefix EAN code

        try {
            URL url = new URL("http://api.ean-search.org/api?token=" + API_TOKEN + "&op=barcode-prefix-search&prefix=" + prefix + "&format=json" + "&page=1");

            System.out.println(">>>>> getProductByBarcodePrefix url = " + url.toString());

            InputStream is = url.openStream();
            int pointer = 0;
            StringBuffer apiResult = new StringBuffer(0);

            while ((pointer = is.read()) != -1) {
                apiResult.append((char) pointer);
            }

            System.out.println(">>>>> getProductByBarcodePrefix apiResult = " + apiResult.toString());

            Gson gson = new Gson();
            EANSearch eanSearch = gson.fromJson(apiResult.toString(), EANSearch.class);

            System.out.println(">>>>> getProductByBarcodePrefix eanSearch getProductlist size = " + eanSearch.getProductlist().size());

            Iterator iterator = eanSearch.getProductlist().iterator();
            while (iterator.hasNext()) {
                Productlist productlist = (Productlist) iterator.next();

                System.out.println(">>>>> getProductByBarcodePrefix productlist getEan = " + productlist.getEan());
                System.out.println(">>>>> getProductByBarcodePrefix productlist getName = " + productlist.getName());
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     *
     */
    public static void getProductByProduct() {
        // http://api.ean-search.org/api?token=abcdef&op=product-search&name=iPod

        String productName = "Baked";

        try {
            URL url = new URL("http://api.ean-search.org/api?token=" + API_TOKEN + "&op=product-search&name=" + productName + "&format=json" + "&page=0");

            System.out.println(">>>>> getProductByProduct url = " + url.toString());

            InputStream is = url.openStream();
            int pointer = 0;
            StringBuffer apiResult = new StringBuffer(0);

            while ((pointer = is.read()) != -1) {
                apiResult.append((char) pointer);
            }

            System.out.println(">>>>> getProductByProduct apiResult = " + apiResult.toString());

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
