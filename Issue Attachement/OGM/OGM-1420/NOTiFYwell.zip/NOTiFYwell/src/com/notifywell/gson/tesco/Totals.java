package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Totals implements Serializable {

    private final static long serialVersionUID = -4692151057795423109L;
    @SerializedName("all")
    @Expose
    private int all;
    @SerializedName("new")
    @Expose
    private int _new;
    @SerializedName("offer")
    @Expose
    private int offer;

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }

    public int getNew() {
        return _new;
    }

    public void setNew(int _new) {
        this._new = _new;
    }

    public int getOffer() {
        return offer;
    }

    public void setOffer(int offer) {
        this.offer = offer;
    }

}
