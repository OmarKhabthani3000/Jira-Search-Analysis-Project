
package com.notifywell.gson.mongodb;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class FoodsCosmeticsMedicines {

    @SerializedName("_id")
    @Expose
    private Id id;
    @SerializedName("ean")
    @Expose
    private String ean;
    @SerializedName("gtin")
    @Expose
    private String gtin;
    @SerializedName("tpnb")
    @Expose
    private String tpnb;
    @SerializedName("tpnc")
    @Expose
    private String tpnc;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("brand")
    @Expose
    private String brand;
    @SerializedName("supermarket")
    @Expose
    private String supermarket;
    @SerializedName("qtyContents")
    @Expose
    private QtyContents qtyContents;
    @SerializedName("productCharacteristics")
    @Expose
    private ProductCharacteristics productCharacteristics;
    @SerializedName("lifestyle")
    @Expose
    private Lifestyle lifestyle;
    @SerializedName("product_name")
    @Expose
    private String productName;
    @SerializedName("quantity_grammes")
    @Expose
    private String quantityGrammes;
    @SerializedName("portion_serving_sachet_item_amount")
    @Expose
    private String portionServingSachetItemAmount;
    @SerializedName("live")
    @Expose
    private String live;
    @SerializedName("timestamp_lastupdated")
    @Expose
    private TimestampLastupdated timestampLastupdated;
    @SerializedName("ingredients")
    @Expose
    private Ingredients ingredients;
    @SerializedName("nutrients")
    @Expose
    private Nutrients nutrients;
    @SerializedName("e_numbers")
    @Expose
    private ENumbers eNumbers;
    @SerializedName("chemicals_minerals_vitamins")
    @Expose
    private ChemicalsMineralsVitamins chemicalsMineralsVitamins;

    public Id getId() {
        return id;
    }

    public void setId(Id id) {
        this.id = id;
    }

    public String getEan() {
        return ean;
    }

    public void setEan(String ean) {
        this.ean = ean;
    }

    public String getGtin() {
        return gtin;
    }

    public void setGtin(String gtin) {
        this.gtin = gtin;
    }

    public String getTpnb() {
        return tpnb;
    }

    public void setTpnb(String tpnb) {
        this.tpnb = tpnb;
    }

    public String getTpnc() {
        return tpnc;
    }

    public void setTpnc(String tpnc) {
        this.tpnc = tpnc;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getSupermarket() {
        return supermarket;
    }

    public void setSupermarket(String supermarket) {
        this.supermarket = supermarket;
    }

    public QtyContents getQtyContents() {
        return qtyContents;
    }

    public void setQtyContents(QtyContents qtyContents) {
        this.qtyContents = qtyContents;
    }

    public ProductCharacteristics getProductCharacteristics() {
        return productCharacteristics;
    }

    public void setProductCharacteristics(ProductCharacteristics productCharacteristics) {
        this.productCharacteristics = productCharacteristics;
    }

    public Lifestyle getLifestyle() {
        return lifestyle;
    }

    public void setLifestyle(Lifestyle lifestyle) {
        this.lifestyle = lifestyle;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getQuantityGrammes() {
        return quantityGrammes;
    }

    public void setQuantityGrammes(String quantityGrammes) {
        this.quantityGrammes = quantityGrammes;
    }

    public String getPortionServingSachetItemAmount() {
        return portionServingSachetItemAmount;
    }

    public void setPortionServingSachetItemAmount(String portionServingSachetItemAmount) {
        this.portionServingSachetItemAmount = portionServingSachetItemAmount;
    }

    public String getLive() {
        return live;
    }

    public void setLive(String live) {
        this.live = live;
    }

    public TimestampLastupdated getTimestampLastupdated() {
        return timestampLastupdated;
    }

    public void setTimestampLastupdated(TimestampLastupdated timestampLastupdated) {
        this.timestampLastupdated = timestampLastupdated;
    }

    public Ingredients getIngredients() {
        return ingredients;
    }

    public void setIngredients(Ingredients ingredients) {
        this.ingredients = ingredients;
    }

    public Nutrients getNutrients() {
        return nutrients;
    }

    public void setNutrients(Nutrients nutrients) {
        this.nutrients = nutrients;
    }

    public ENumbers getENumbers() {
        return eNumbers;
    }

    public void setENumbers(ENumbers eNumbers) {
        this.eNumbers = eNumbers;
    }

    public ChemicalsMineralsVitamins getChemicalsMineralsVitamins() {
        return chemicalsMineralsVitamins;
    }

    public void setChemicalsMineralsVitamins(ChemicalsMineralsVitamins chemicalsMineralsVitamins) {
        this.chemicalsMineralsVitamins = chemicalsMineralsVitamins;
    }

}
