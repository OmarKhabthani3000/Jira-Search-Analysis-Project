package com.notifywell.ejb;

import com.google.gson.Gson;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.notifywell.ean.EANSearchHelper;
import com.notifywell.gson.eansearch.EANError;
import com.notifywell.gson.eansearch.EANProduct;
import com.notifywell.gson.mongodb.FoodsCosmeticsMedicines;
import com.notifywell.gson.tesco.TescoProducts;
import com.notifywell.mongodb.MongoDBHelper;
import com.notifywell.tesco.TescoHelper;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.time.Instant;

@Stateless
@LocalBean
@TransactionManagement(TransactionManagementType.CONTAINER)
@Path("/")
public class NOTiFYwellEJB {
    // implements NOTiFYwellLocal {

    /**
     *
     */
    static final String PATH_QUERY_PARAM_EAN = "ean";

    /**
     *
     */
    static final String EAN = "ean";

    /**
     *
     */
    static final String BRAND = "brand";

    /**
     *
     */
    static final String DESCRIPTION = "description";

    /**
     *
     */
    static final String TIMESTAMP_LASTUPDATED = "timestamp_lastupdated";

    /**
     *
     */
    static final String INVALID_BARCODE = "Invalid barcode";

    /**
     *
     */
    static final int ZERO = 0;

    /**
     *
     */
    private static MongoClient mongoClient = null;

    /**
     *
     */
    private static MongoDatabase mongoDatabase = null;

    /**
     *
     */
    private static MongoCollection mongoCollection = null;

    /**
     *
     */
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @PersistenceContext(unitName = "nOTiFYwellMySQLPersistenceUnit")
    private EntityManager entityManager;

    /**
     *
     */
    @PersistenceContext(unitName = "nOTiFYwellMongoDBPersistenceUnit")
    private EntityManager mongoDBEntityManager;

    public NOTiFYwellEJB() {
    }

    /**
     * @param ean String
     * @return Response
     * @throws IOException IOException
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/product-by-ean/{ean}")
    public Response getProductByEAN(@PathParam(NOTiFYwellEJB.PATH_QUERY_PARAM_EAN) final String ean) throws IOException {
        logger.info(">>>>> getProductByEAN ean = {}", ean);

        // See if this product is already in the MongoDB database collection
        Document document = this.getProductFromMongoDBByEAN(ean);

        String json = null;
        // Barcode does not exist in the MongoDB database collection
        if (document == null) {

            // Not in the database, so get from Tesco or finally EAN-Search.
            Gson gson = new Gson();

            json = TescoHelper.getProductByGTIN(ean);

            if (json != null) {
                TescoProducts tescoProducts = gson.fromJson(json, TescoProducts.class);
                logger.info(">>>>> getTescoProduct tescoProducts = {}", tescoProducts.getProducts().size());

                if (tescoProducts.getProducts().isEmpty()) {
                    json = EANSearchHelper.getProductByEan(ean);
                    logger.info(">>>>> getProductByEAN json = {}", json);

                    // Test if 'ean search' has return an error - invalid barcode
                    EANError eanError[] = gson.fromJson(json, EANError[].class);
                    logger.info(">>>>> getProductByEAN eanError length = {}", eanError.length);

                    if (eanError.length > ZERO) {
                        if (!eanError[ZERO].getError().equals(INVALID_BARCODE)) {
                            EANProduct eanProductArray[] = gson.fromJson(json, EANProduct[].class);
                            logger.info(">>>>> getProductByEAN eanProductArray = {}", eanProductArray.length);

                            for (EANProduct anEanProductArray : eanProductArray) {
                                //logger.info(">>>>> EAN.org eanProduct[] = {}", anEanProductArray.toString());

                                EANProduct eanProduct = anEanProductArray;
                                logger.info(">>>>> EAN.org eanProduct = {}", eanProduct.toString());

                                if (eanProduct.getEan() == null) {
                                    break;
                                } else {
                                    this.persistEANProduct(eanProduct);
                                }
                            }
                        } else {
                            logger.info(">>>>> getProductByEAN eanError getError = {}", eanError[ZERO].getError());
                            logger.info(">>>>> getProductByEAN eanError ean = {}", ean);
                            FoodsCosmeticsMedicines foodsCosmeticsMedicines = new FoodsCosmeticsMedicines();
                            foodsCosmeticsMedicines.setEan(ean);

                            insertFoodsCosmeticsMedicines(foodsCosmeticsMedicines);

                            //json = null;
                            return Response.noContent().build();
                        }
                    }
                }
                this.persistTescoProduct(tescoProducts);
            }
            return Response.ok(json, MediaType.APPLICATION_JSON).build();
        } else {
            logger.info("***** document = {}", document.toJson());

            json = document.toJson();

            return Response.ok(json, MediaType.APPLICATION_JSON).build();
        }
    }

    /**
     * @param ean String
     * @return Document
     */
    private final Document getProductFromMongoDBByEAN(final String ean) {
        logger.info(">>>>> getProductFromMongoDBByEAN ean = {}", ean);

        MongoDatabase mongoDatabase = MongoDBHelper.getMongoDatabaseNotifyWellDB();
        MongoCollection<Document> mongoCollection = MongoDBHelper.getFoodsCosmeticsMedicinesCollection();

        BasicDBObject basicDBObject = new BasicDBObject();
        basicDBObject.put(EAN, ean);

        Document document = mongoCollection.find(basicDBObject).first();
        logger.info("***** getProductFromMongoDBByEAN document = {}", document);

        if (document == null) {
            return null;
        } else {
            String barCode = document.getString(EAN);
            logger.info("***** getProductFromMongoDBByEAN barCode = {}", barCode);

            return document;
        }
    }

    /**
     * @param foodsCosmeticsMedicines FoodsCosmeticsMedicines
     */
    private final void insertFoodsCosmeticsMedicines(final FoodsCosmeticsMedicines foodsCosmeticsMedicines) {
        logger.error(">>>>> insertFoodsCosmeticsMedicines foodsCosmeticsMedicines = {}", foodsCosmeticsMedicines.getEan());

        MongoDatabase mongoDatabase = MongoDBHelper.getMongoDatabaseNotifyWellDB();
        MongoCollection<Document> mongoCollection = MongoDBHelper.getFoodsCosmeticsMedicinesCollection();

        Document document = new Document();
        document.put(EAN, foodsCosmeticsMedicines.getEan());
        document.put(BRAND, foodsCosmeticsMedicines.getBrand());
        document.put(TIMESTAMP_LASTUPDATED, getTimeStampNow());

        mongoCollection.insertOne(document);
    }

    /**
     * @param tescoProducts TescoProducts
     */
    private final void persistTescoProduct(final TescoProducts tescoProducts) {
        logger.info(">>>>> persistTescoProduct tescoProducts getGtin = " + tescoProducts.getProducts().get(ZERO).getGtin());
        logger.info(">>>>> persistTescoProduct tescoProducts getBrand = " + tescoProducts.getProducts().get(ZERO).getBrand());

        MongoDatabase mongoDatabase = MongoDBHelper.getMongoDatabaseNotifyWellDB();
        MongoCollection<Document> mongoCollection = MongoDBHelper.getFoodsCosmeticsMedicinesCollection();

        Document document = new Document();
        document.put(EAN, tescoProducts.getProducts().get(ZERO).getGtin());
        document.put(BRAND, tescoProducts.getProducts().get(ZERO).getBrand());
        document.put(DESCRIPTION, tescoProducts.getProducts().get(ZERO).getDescription());
        document.put(TIMESTAMP_LASTUPDATED, getTimeStampNow());

        mongoCollection.insertOne(document);
    }

    /**
     * @param eanProduct EANProduct
     */
    private final void persistEANProduct(final EANProduct eanProduct) {
        logger.info(">>>>> persistTescoProduct eanProduct getEan = " + eanProduct.getEan());
        logger.info(">>>>> persistTescoProduct eanProduct getName = " + eanProduct.getName());

        MongoDatabase mongoDatabase = MongoDBHelper.getMongoDatabaseNotifyWellDB();
        MongoCollection<Document> mongoCollection = MongoDBHelper.getFoodsCosmeticsMedicinesCollection();

        Document document = new Document();
        document.put(EAN, eanProduct.getEan());
        document.put(TIMESTAMP_LASTUPDATED, getTimeStampNow());

        mongoCollection.insertOne(document);
    }

    /**
     * @return long
     */
    private final long getTimeStampNow() {
        Instant instant = Instant.now();
        return instant.toEpochMilli();
    }
}
