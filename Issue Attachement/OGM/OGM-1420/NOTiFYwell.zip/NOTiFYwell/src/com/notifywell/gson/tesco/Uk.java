package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Uk implements Serializable {

    private final static long serialVersionUID = 425026447574981009L;
    @SerializedName("ghs")
    @Expose
    private Ghs ghs;

    public Ghs getGhs() {
        return ghs;
    }

    public void setGhs(Ghs ghs) {
        this.ghs = ghs;
    }

}
