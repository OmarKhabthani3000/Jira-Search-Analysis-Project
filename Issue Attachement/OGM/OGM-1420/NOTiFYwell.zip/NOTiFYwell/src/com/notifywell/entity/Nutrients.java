package com.notifywell.entity;

import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class Nutrients implements Serializable {

    private String nutrientName;

    /**
     *
     */
    public Nutrients() {
    }

    /**
     *
     * @return String
     */
    public String getNutrientName() {
        return this.nutrientName;
    }

    /**
     *
     * @param nutrientName String
     */
    public void setNutrientName(String nutrientName) {
        this.nutrientName = nutrientName;
    }
}
