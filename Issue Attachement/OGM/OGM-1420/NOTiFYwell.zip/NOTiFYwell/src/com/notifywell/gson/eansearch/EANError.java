package com.notifywell.gson.eansearch;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class EANError {

    /**
     *
     */
    @SerializedName("error")
    @Expose
    private String error;

    /**
     *
     * @return String
     */
    public String getError() {
        return error;
    }

    /**
     *
     * @param error String
     */
    public void setError(String error) {
        this.error = error;
    }

    @Override
    public String toString() {
        return "EANError{" +
                "error='" + error + '\'' +
                '}';
    }
}