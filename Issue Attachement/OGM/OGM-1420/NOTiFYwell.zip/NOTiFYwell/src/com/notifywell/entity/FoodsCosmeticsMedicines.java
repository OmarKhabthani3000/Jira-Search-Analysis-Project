package com.notifywell.entity;

import com.google.gson.annotations.Expose;
import org.hibernate.annotations.Type;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.List;

@Entity
@Indexed
@Table(name = "foodsCosmeticsMedicines")
public class FoodsCosmeticsMedicines implements Serializable {

    /**
     *
     */
    @Expose(deserialize = true, serialize = true)
    @Id
    @Type(type = "objectid")
    private String id;

    /**
     *
     */
    @Expose(deserialize = true, serialize = true)
    @Column(name = "ean")
    private String ean;

    /**
     *
     */
    @Expose(deserialize = true, serialize = true)
    @Column(name = "description")
    private String description;

    /**
     *
     */
    @ElementCollection
    private List<QtyContents> qtyContentsList;

    //@Embedded
    //QtyContents qtyContents;

    @Embedded
    ProductCharacteristics productCharacteristics;

    @Embedded
    Lifestyle lifestyle;

    @Embedded
    Ingredients ingredients;

    @Embedded
    Nutrients nutrients;

    @Embedded
    Enumbers enumbers;

    @Embedded
    ChemicalsMineralsVitamins chemicalsMineralsVitamins;

    /**
     * @return String
     */
    public String getId() {
        return this.id;
    }

    /**
     * @param id String
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return String
     */
    public String getEan() {
        return this.ean;
    }

    /**
     * @param ean String
     */
    public void setEan(String ean) {
        this.ean = ean;
    }

    /**
     * @return String
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * @param description String
     */
    public void setDescription(String description) {
        this.description = description;
    }

    //public QtyContents getQtyContents() {
    //    return this.qtyContents;
    //}

    //public void setQtyContents(QtyContents qtyContents) {
    //    this.qtyContents = qtyContents;
    //}

    public List<QtyContents> getQtyContentsList() {
        return this.qtyContentsList;
    }

    public void setQtyContentsList(List<QtyContents> qtyContentsList) {
        this.qtyContentsList = qtyContentsList;
    }

    /**
     * @return ProductCharacteristics
     */
    public ProductCharacteristics getProductCharacteristics() {
        return this.productCharacteristics;
    }

    /**
     * @param productCharacteristics ProductCharacteristics
     */
    public void setProductCharacteristics(ProductCharacteristics productCharacteristics) {
        this.productCharacteristics = productCharacteristics;
    }

    /**
     * @return Lifestyle
     */
    public Lifestyle getLifestyle() {
        return this.lifestyle;
    }

    /**
     * @param lifestyle
     */
    public void setLifestyle(Lifestyle lifestyle) {
        this.lifestyle = lifestyle;
    }

    /**
     * @return Ingredients
     */
    public Ingredients getIngredients() {
        return this.ingredients;
    }

    /**
     * @param ingredients Ingredients
     */
    public void setIngredients(Ingredients ingredients) {
        this.ingredients = ingredients;
    }

    /**
     * @return Nutrients
     */
    public Nutrients getNutrients() {
        return this.nutrients;
    }

    /**
     * @param nutrients Nutrients
     */
    public void setNutrients(Nutrients nutrients) {
        this.nutrients = nutrients;
    }

    /**
     * @return Enumbers
     */
    public Enumbers getEnumbers() {
        return this.enumbers;
    }

    /**
     * @param enumbers Enumbers
     */
    public void setEnumbers(Enumbers enumbers) {
        this.enumbers = enumbers;
    }

    /**
     * @return ChemicalsMineralsVitamins
     */
    public ChemicalsMineralsVitamins getChemicalsMineralsVitamins() {
        return this.chemicalsMineralsVitamins;
    }

    /**
     * @param chemicalsMineralsVitamins ChemicalsMineralsVitamins
     */
    public void setChemicalsMineralsVitamins(ChemicalsMineralsVitamins chemicalsMineralsVitamins) {
        this.chemicalsMineralsVitamins = chemicalsMineralsVitamins;
    }
}
