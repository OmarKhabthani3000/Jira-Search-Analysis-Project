
package com.notifywell.gson.mongodb;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ProductCharacteristics {

    @SerializedName("isFood")
    @Expose
    private String isFood;
    @SerializedName("isDrink")
    @Expose
    private String isDrink;
    @SerializedName("healthScore")
    @Expose
    private String healthScore;
    @SerializedName("isHazardous")
    @Expose
    private String isHazardous;
    @SerializedName("storageType")
    @Expose
    private String storageType;

    public String getIsFood() {
        return isFood;
    }

    public void setIsFood(String isFood) {
        this.isFood = isFood;
    }

    public String getIsDrink() {
        return isDrink;
    }

    public void setIsDrink(String isDrink) {
        this.isDrink = isDrink;
    }

    public String getHealthScore() {
        return healthScore;
    }

    public void setHealthScore(String healthScore) {
        this.healthScore = healthScore;
    }

    public String getIsHazardous() {
        return isHazardous;
    }

    public void setIsHazardous(String isHazardous) {
        this.isHazardous = isHazardous;
    }

    public String getStorageType() {
        return storageType;
    }

    public void setStorageType(String storageType) {
        this.storageType = storageType;
    }

}
