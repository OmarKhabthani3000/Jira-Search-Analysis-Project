package com.notifywell.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.ext.Provider;
import java.io.IOException;

/**
 *
 */
@SuppressWarnings("SpellCheckingInspection")
@Provider
public class CorsResponseFilter implements ContainerResponseFilter {

    /**
     *
     */
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     *
     */
    public CorsResponseFilter() {
        //logger.info(">>>>> CorsResponseFilter");
    }

    /**
     * @param requestContext  ContainerRequestContext
     * @param responseContext ContainerResponseContext
     * @throws IOException IOException
     */
    @Override
    public void filter(final ContainerRequestContext requestContext, final ContainerResponseContext responseContext) throws IOException {
        //logger.info(">>>>> filter requestContext = " + requestContext + " responseContext = " + responseContext);

        responseContext.getHeaders().add("Content-Type", "application/json");

        //PipeLineHelper.getHeaderFields(responseContext.getHeaders());

        responseContext.getHeaders().add("Access-Control-Allow-Origin", "*");
        responseContext.getHeaders().add("Access-Control-Allow-Credentials", "true");
        responseContext.getHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        responseContext.getHeaders().add("Access-Control-Allow-Headers", "Accept, Authorization, Content-Type, X-Requested-With, x-username, x-password");
        responseContext.getHeaders().add("Access-Control-Max-Age", "header-value=1");

        //PipeLineHelper.getHeaderFields(responseContext.getHeaders());

        String requestHeader = requestContext.getHeaderString("Access-Control-Request-Headers");

        if (requestHeader != null && !requestHeader.equals("")) {
            responseContext.getHeaders().add("Access-Control-Allow-Headers", requestHeader);
        }
    }
}
