package com.notifywell.gson.tesco;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class PkgDimension implements Serializable {

    private final static long serialVersionUID = -738160409128850653L;
    @SerializedName("no")
    @Expose
    private int no;
    @SerializedName("height")
    @Expose
    private float height;
    @SerializedName("width")
    @Expose
    private float width;
    @SerializedName("depth")
    @Expose
    private float depth;
    @SerializedName("dimensionUom")
    @Expose
    private String dimensionUom;
    @SerializedName("weight")
    @Expose
    private float weight;
    @SerializedName("weightUom")
    @Expose
    private String weightUom;
    @SerializedName("volume")
    @Expose
    private float volume;
    @SerializedName("volumeUom")
    @Expose
    private String volumeUom;

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getDepth() {
        return depth;
    }

    public void setDepth(float depth) {
        this.depth = depth;
    }

    public String getDimensionUom() {
        return dimensionUom;
    }

    public void setDimensionUom(String dimensionUom) {
        this.dimensionUom = dimensionUom;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public String getWeightUom() {
        return weightUom;
    }

    public void setWeightUom(String weightUom) {
        this.weightUom = weightUom;
    }

    public float getVolume() {
        return volume;
    }

    public void setVolume(float volume) {
        this.volume = volume;
    }

    public String getVolumeUom() {
        return volumeUom;
    }

    public void setVolumeUom(String volumeUom) {
        this.volumeUom = volumeUom;
    }

}
