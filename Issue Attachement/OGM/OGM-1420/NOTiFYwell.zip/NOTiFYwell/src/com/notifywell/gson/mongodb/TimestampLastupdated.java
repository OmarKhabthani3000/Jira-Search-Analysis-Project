
package com.notifywell.gson.mongodb;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TimestampLastupdated {

    @SerializedName("$date")
    @Expose
    //private Integer $date;
    private Long $date;

    //public Integer get$date() {
    //    return $date;
    //}

    public Long get$date() {
        return $date;
    }

    //public void set$date(Integer $date) {
    //    this.$date = $date;
    //}
    public void set$date(Long $date) {
        this.$date = $date;
    }

}
