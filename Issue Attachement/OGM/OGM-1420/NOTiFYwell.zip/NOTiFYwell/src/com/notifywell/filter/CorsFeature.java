package com.notifywell.filter;

import org.jboss.resteasy.plugins.interceptors.CorsFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.Feature;
import javax.ws.rs.core.FeatureContext;

/**
 *
 */
//@Provider
public class CorsFeature implements Feature {

    /**
     *
     */
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     *
     */
    public CorsFeature() {
        logger.info(">>>>> CorsFeature .....");
    }

    /**
     * @param featureContext FeatureContext
     * @return boolean
     */
    @Override
    public boolean configure(final FeatureContext featureContext) {
        logger.info(">>>>> configure .....");

        CorsFilter corsFilter = new CorsFilter();
        corsFilter.getAllowedOrigins().add("*");
        featureContext.register(corsFilter);

        return true;
    }
}
