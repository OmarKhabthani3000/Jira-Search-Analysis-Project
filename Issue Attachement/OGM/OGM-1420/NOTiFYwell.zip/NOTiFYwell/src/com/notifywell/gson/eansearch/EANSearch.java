package com.notifywell.gson.eansearch;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class EANSearch implements Serializable {

    private final static long serialVersionUID = 1016171028582002861L;
    @SerializedName("page")
    @Expose
    private int page;
    @SerializedName("moreproducts")
    @Expose
    private boolean moreproducts;
    @SerializedName("productlist")
    @Expose
    private List<Productlist> productlist = null;

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public boolean isMoreproducts() {
        return moreproducts;
    }

    public void setMoreproducts(boolean moreproducts) {
        this.moreproducts = moreproducts;
    }

    public List<Productlist> getProductlist() {
        return productlist;
    }

    public void setProductlist(List<Productlist> productlist) {
        this.productlist = productlist;
    }

}
