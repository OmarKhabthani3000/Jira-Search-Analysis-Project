package com.ebcont.service;

import java.util.Arrays;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.ebcont.model.LogEntry;
import com.ebcont.model.LogSubEvent;
import com.ebcont.model.SystemData;
import com.ebcont.model.UserRole;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class LogService {

	@PersistenceContext(name = "mongodb")
	private EntityManager em;

	public LogEntry log() {
		LogEntry entry = new LogEntry();

		initSystemData(entry);
		initSubsystems(entry);

		em.persist(entry);

		createLogSubEvents(entry, "Log Event1");
		createLogSubEvents(entry, "Log Event2");
		
		return entry;
	}

	private void createLogSubEvents(LogEntry logEntry, String name) {
		LogSubEvent sub = new LogSubEvent();
		
		sub.setEventName(name);
		sub.setLogEntry(logEntry);
		
		em.persist(sub);

//		logEntry.getSubEvents().add(sub);
		
	}

	private void initSubsystems(LogEntry entry) {
		entry.setSubsystems(Arrays.asList("PAYMENT", "DEBIT"));
	}

	private void initSystemData(LogEntry entry) {
		SystemData systemData = new SystemData();
		systemData.setEventType("READ");
		systemData.setSystemId("SERVICEBUS-NODE1");
		entry.setSystemData(systemData);
	}

	public void createUserRole(String user, String role) {
		UserRole r = new UserRole();
		r.setUser("jimmy");
		r.setRole("user");

		em.persist(r);
	}

	public LogEntry find(String id) {
		return em.find(LogEntry.class, id);
	}

	public List<LogEntry> findOthers(String id) {
		TypedQuery<LogEntry> query = em.createNamedQuery(LogEntry.FIND_OTHERS, LogEntry.class);
		query.setParameter("id", id);
		query.setMaxResults(2);
		return query.getResultList();
	}

}
