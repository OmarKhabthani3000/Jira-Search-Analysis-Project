package com.ebcont.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class LogSubEvent {

	@Id
	private String id = java.util.UUID.randomUUID().toString();

	private String eventName;

	@ManyToOne(optional = false)
	private LogEntry logEntry;

	public LogSubEvent() {
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public LogEntry getLogEntry() {
		return logEntry;
	}

	public void setLogEntry(LogEntry logEntry) {
		this.logEntry = logEntry;
	}

	@Override
	public String toString() {
		return "LogGroup [id=" + id + ", logEntry=" + logEntry + "]";
	}

}
