package com.ebcont.facade;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import com.ebcont.model.LogEntry;
import com.ebcont.service.LogService;

@Stateless
@Path("logs")
public class LogFacade {

	@Inject
	private LogService logService;
	
	// http://localhost:8080/hibernate-ogm/resources/logs
	@GET
	public String log() {
		LogEntry entry = logService.log();
		
//		logService.createUserRole("max", "user");
		
		return entry.getId();
	}
	
	// http://localhost:8080/hibernate-ogm/resources/logs/log-id-111cf93e-1d84-4517-ab3d-5fa9fd5b4a91
	@GET
	@Path("log-id-{id}")
	public String getLogEntry(@PathParam("id") String id) {
		
		logService.findOthers(id);
		
		LogEntry entry = logService.find(id);
		return "" + entry.getSubsystems().size();
	}
	
}
