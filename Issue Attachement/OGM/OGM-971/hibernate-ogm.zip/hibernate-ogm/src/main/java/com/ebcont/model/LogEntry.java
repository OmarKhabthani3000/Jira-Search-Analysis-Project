package com.ebcont.model;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

@Entity
@Table(name = "logs")
@NamedQueries({ @NamedQuery(name = LogEntry.FIND_OTHERS, query = "SELECT l FROM LogEntry l WHERE l.id <> :id") })
public class LogEntry {
	public static final String FIND_OTHERS = "LogEntry.findOthers";
	@Id
	private String id = java.util.UUID.randomUUID().toString();

	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Calendar logTimestamp = Calendar.getInstance();

	@Embedded
	private SystemData systemData;

	@ElementCollection(fetch = FetchType.EAGER)
	private List<String> subsystems;

	@Version
	private long version;

	@OneToMany(mappedBy = "logEntry")
	private List<LogSubEvent> subEvents = new ArrayList<>();

	public LogEntry() {
	}

	public List<LogSubEvent> getSubEvents() {
		return subEvents;
	}

	public void setSubEvents(List<LogSubEvent> subEvents) {
		this.subEvents = subEvents;
	}

	public List<String> getSubsystems() {
		return subsystems;
	}

	public void setSubsystems(List<String> subsystems) {
		this.subsystems = subsystems;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public SystemData getSystemData() {
		return systemData;
	}

	public void setSystemData(SystemData systemData) {
		this.systemData = systemData;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Calendar getLogTimestamp() {
		return logTimestamp;
	}

	public void setLogTimestamp(Calendar logTimestamp) {
		this.logTimestamp = logTimestamp;
	}

	@Override
	public String toString() {
		return "LogEntry [id=" + id + ", logTimestamp=" + logTimestamp.getTime() + "]";
	}

}
