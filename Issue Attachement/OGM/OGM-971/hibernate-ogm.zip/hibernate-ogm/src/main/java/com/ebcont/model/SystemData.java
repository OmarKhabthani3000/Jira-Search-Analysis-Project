package com.ebcont.model;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class SystemData implements Serializable {
	private static final long serialVersionUID = 7187956505209337457L;

	private String systemId;
	private String eventType;

	public SystemData() {
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	@Override
	public String toString() {
		return "SystemData [systemId=" + systemId + ", eventType=" + eventType + "]";
	}

}
