/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;

import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 *
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
				TestEntity.class
		};
	}

	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/test/";
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );

		configuration.setProperty( AvailableSettings.SHOW_SQL, Boolean.TRUE.toString() );
		configuration.setProperty( AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString() );
		//configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, "true" );
	}

	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		TestEntity testEntity = new TestEntity();
		testEntity.setCreationDateAndTime( new Timestamp( new Date().getTime() ) );
		testEntity.setDestructionDate( new Date() );
		s.persist( testEntity );
		tx.commit();
		s.clear();
		tx = s.beginTransaction();
		TestEntity loadedTestEntity = s.get( TestEntity.class, testEntity.getId() );
		assertEquals( testEntity, loadedTestEntity );
		tx.commit();
		s.close();
	}

	@Entity
	public static class TestEntity {
		@Id
		@GeneratedValue(generator = "uuid")
		@GenericGenerator(name = "uuid", strategy = "uuid2")
		private String id;

		private Timestamp creationDateAndTime;

		private Date destructionDate;

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public Timestamp getCreationDateAndTime() {
			return creationDateAndTime;
		}

		public void setCreationDateAndTime(Timestamp creationDateAndTime) {
			this.creationDateAndTime = creationDateAndTime;
		}

		public Date getDestructionDate() {
			return destructionDate;
		}

		public void setDestructionDate(Date destructionDate) {
			this.destructionDate = destructionDate;
		}

		@Override
		public boolean equals(Object o) {
			if ( this == o ) {
				return true;
			}
			if ( !( o instanceof TestEntity ) ) {
				return false;
			}
			TestEntity that = (TestEntity) o;
			return Objects.equals( id, that.id ) &&
					Objects.equals( creationDateAndTime, that.creationDateAndTime ) &&
					Objects.equals( that.destructionDate, destructionDate );
		}

		@Override
		public int hashCode() {

			return Objects.hash( id, creationDateAndTime, destructionDate );
		}

		@Override
		public String toString() {
			return "TestEntity{" +
					"id='" + id + '\'' +
					", creationDateAndTime=" + creationDateAndTime +
					", destructionDate=" + destructionDate +
					'}';
		}
	}
}
