package by.defascathibernate.ogm.test;

import by.defascat.hibernate.ogm.test.entity.UserProfile;
import java.util.List;
import java.util.function.Consumer;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import org.junit.After;
import org.junit.Assert;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

/**
 *
 * @author andy
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public abstract class BasicTest {

    protected EntityManager em;
    protected EntityManagerFactory emf;

    protected abstract String getDataSource();

    protected abstract String getNativeQuery(final String newCity);

    @After
    public void after() {
        em.close();
        emf.close();
    }

    @Before
    public void setup() {
        emf = Persistence.createEntityManagerFactory(getDataSource());
        em = emf.createEntityManager();
    }

    private void doInTransaction(Consumer<EntityManager> function) {
        EntityTransaction tm = em.getTransaction();
        tm.begin(); // NEO4J requires explicit transaction for each query.
        try {
            function.accept(em);
            tm.commit();
        } catch (Throwable e) {
            try {
                tm.rollback();
            } catch(Throwable e1) {
            }
            throw e;
        }
    }

    // Does not work in Couch
    // Does not work in Neo4J
    @Test
    public void test5FindJPQL() {
        doInTransaction(
                em -> {
                    final String newCity = "Borovlyany";
                    final Query jpqlQuery = em.createQuery("from UserProfile p where p.address.city = :city");
                    jpqlQuery.setParameter("city", newCity);
                    final List<UserProfile> items = jpqlQuery.getResultList();
                    Assert.assertEquals(1, items.size());
                    Assert.assertEquals("testuser", items.get(0).getName());
                    Assert.assertEquals(newCity, items.get(0).getAddress().getCity());
                }
        );
    }
}
