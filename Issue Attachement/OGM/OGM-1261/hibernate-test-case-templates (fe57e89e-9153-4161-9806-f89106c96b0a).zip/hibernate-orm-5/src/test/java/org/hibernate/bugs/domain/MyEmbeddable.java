package org.hibernate.bugs.domain;

import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;

@Embeddable
public class MyEmbeddable {

    private String text;

    @ElementCollection
    private List<MyNestedElementCollectionEmbeddable> myNestedElementCollectionEmbeddables;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public List<MyNestedElementCollectionEmbeddable> getMyNestedElementCollectionEmbeddables() {
        return myNestedElementCollectionEmbeddables;
    }

    public void setMyNestedElementCollectionEmbeddables(List<MyNestedElementCollectionEmbeddable> myNestedElementCollectionEmbeddables) {
        this.myNestedElementCollectionEmbeddables = myNestedElementCollectionEmbeddables;
    }
}
