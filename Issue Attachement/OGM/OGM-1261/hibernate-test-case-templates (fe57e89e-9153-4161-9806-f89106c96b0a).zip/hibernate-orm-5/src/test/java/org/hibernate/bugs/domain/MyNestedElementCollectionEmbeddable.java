package org.hibernate.bugs.domain;

import javax.persistence.Embeddable;

@Embeddable
public class MyNestedElementCollectionEmbeddable {

    private String collectionValue;

    public String getCollectionValue() {
        return collectionValue;
    }

    public void setCollectionValue(String collectionValue) {
        this.collectionValue = collectionValue;
    }
}
