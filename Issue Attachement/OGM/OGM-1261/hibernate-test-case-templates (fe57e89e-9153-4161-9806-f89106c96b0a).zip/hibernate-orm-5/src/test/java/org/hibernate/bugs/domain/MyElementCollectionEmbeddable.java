package org.hibernate.bugs.domain;

import javax.persistence.Embeddable;

@Embeddable
public class MyElementCollectionEmbeddable {

    private String elementCollectionValue;

    public String getElementCollectionValue() {
        return elementCollectionValue;
    }

    public void setElementCollectionValue(String elementCollectionValue) {
        this.elementCollectionValue = elementCollectionValue;
    }
}
