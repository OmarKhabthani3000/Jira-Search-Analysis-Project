package org.hibernate.bugs;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

import java.util.Collections;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.bugs.domain.MyElementCollectionEmbeddable;
import org.hibernate.bugs.domain.MyEmbeddable;
import org.hibernate.bugs.domain.MyEntity;
import org.hibernate.bugs.domain.MyNestedElementCollectionEmbeddable;
import org.hibernate.type.TypeHelper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void saveNestedElementCollectionWithoutFix() throws Exception {
        TypeHelper.applyBugFix = false;
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        saveAndReadEntityWithElementCollections(entityManager);

        entityManager.getTransaction().commit();

        MyEntity myEntityFromDB = entityManager.find(MyEntity.class, 1L);
        assertThat(myEntityFromDB.getMyElementCollectionEmbeddable(), notNullValue());
        assertThat(myEntityFromDB.getMyEmbeddable().getMyNestedElementCollectionEmbeddables(), notNullValue());

        entityManager.close();
    }

    @Test
    public void saveNestedElementCollectionWithFix() throws Exception {
        TypeHelper.applyBugFix = true;
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        saveAndReadEntityWithElementCollections(entityManager);

        entityManager.getTransaction().commit();

        MyEntity myEntityFromDB = entityManager.find(MyEntity.class, 1L);
        assertThat(myEntityFromDB.getMyElementCollectionEmbeddable(), notNullValue());
        assertThat(myEntityFromDB.getMyEmbeddable().getMyNestedElementCollectionEmbeddables(), notNullValue());

        entityManager.close();
    }

    private void saveAndReadEntityWithElementCollections(EntityManager entityManager) {
        // Do stuff...
        MyNestedElementCollectionEmbeddable myEmbeddableAsCollection = new MyNestedElementCollectionEmbeddable();
        myEmbeddableAsCollection.setCollectionValue("NESTED ELEMENT COLLECTION VALUE");

        MyEmbeddable myEmbeddable = new MyEmbeddable();
        myEmbeddable.setMyNestedElementCollectionEmbeddables(Collections.singletonList(myEmbeddableAsCollection));
        myEmbeddable.setText("EMBEDDABLE TEXT");

        MyElementCollectionEmbeddable myElementCollectionEmbeddable = new MyElementCollectionEmbeddable();
        myElementCollectionEmbeddable.setElementCollectionValue("ELEMENT COLLECTION VALUE");

        MyEntity entity = new MyEntity();
        entity.setId(1L);
        entity.setMyEmbeddable(myEmbeddable);
        entity.setMyElementCollectionEmbeddable(Collections.singletonList(myElementCollectionEmbeddable));

        entityManager.merge(entity);
    }
}
