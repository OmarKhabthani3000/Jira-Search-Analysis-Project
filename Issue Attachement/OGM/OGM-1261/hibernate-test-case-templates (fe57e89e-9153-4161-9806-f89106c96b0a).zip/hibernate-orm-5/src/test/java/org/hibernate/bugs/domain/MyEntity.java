package org.hibernate.bugs.domain;

import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MyEntity {

    @Id
    private Long id;

    @Embedded
    private MyEmbeddable myEmbeddable;

    public List<MyElementCollectionEmbeddable> getMyElementCollectionEmbeddable() {
        return myElementCollectionEmbeddable;
    }

    public void setMyElementCollectionEmbeddable(List<MyElementCollectionEmbeddable> myElementCollectionEmbeddable) {
        this.myElementCollectionEmbeddable = myElementCollectionEmbeddable;
    }

    @ElementCollection
    private List<MyElementCollectionEmbeddable> myElementCollectionEmbeddable;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public MyEmbeddable getMyEmbeddable() {
        return myEmbeddable;
    }

    public void setMyEmbeddable(MyEmbeddable myEmbeddable) {
        this.myEmbeddable = myEmbeddable;
    }

}
