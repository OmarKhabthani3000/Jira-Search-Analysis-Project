package model.family;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Entity
@Slf4j
@Getter
@Setter
@DiscriminatorValue("MAN")
public class Man extends Person {

    @OneToOne
    private Woman wife;

    @OneToMany(mappedBy = "mother")
    private List<Child> children = new ArrayList<>();

}
