package model.family;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Entity
@Slf4j
@Getter
@Setter
@DiscriminatorValue("CHILD")
public class Child extends Person {

    @OneToOne
    private Woman mother;

    @OneToOne
    private Man father;

}
