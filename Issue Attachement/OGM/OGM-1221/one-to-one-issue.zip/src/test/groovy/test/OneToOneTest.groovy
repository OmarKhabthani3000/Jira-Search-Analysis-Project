package test

import model.family.Child
import model.family.Man
import model.family.Woman
import org.junit.Before
import org.junit.Test

import javax.persistence.EntityManager
import javax.persistence.Persistence

/**
 * Created by florek.mariusz on 2016-11-17.
 */
class OneToOneTest {

    EntityManager em

    @Before
    public void setUp() {
        em = Persistence.createEntityManagerFactory("primary-neo4j").createEntityManager()
    }

    @Test
    void testPersist() {
        def man = new Man(name: 'John')
        def woman = new Woman(name: 'Jane')
        def child1 = new Child(name: 'Susan')
        def child2 = new Child(name: 'Mark')
        man.wife = woman
        woman.husband = man
        woman.children = [child1, child2] as List<Child>
        man.children = [child1, child2] as List<Child>

        man.children.each {
            it.father = man
        }
        woman.children.each {
            it.mother = woman
        }

        def tx = em.getTransaction()
        tx.begin()

        em.persist(man)
        em.persist(woman)
        em.persist(child1)
        em.persist(child2)

        em.flush()

        // not working with TABLE_PER_CLASS
        // https://hibernate.atlassian.net/browse/OGM-732
//        def people = em.createQuery('select o from Person o', Person)
//                .resultList

        tx.commit()
    }
}
