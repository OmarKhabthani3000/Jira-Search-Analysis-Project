package main;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

@Entity
public class MyEntity implements Serializable{

    public static enum EntityType{
        TYPE_1("Type 1"),
        TYPE_2("Type 2"),
        ;
        public final String description;
        private EntityType(String description){
            this.description = description;
        }// constr
    }// enum

    @Id
    // Hibernate EntityManager 3.3.2.GA creates varbinary column for this.
    @Enumerated(value = EnumType.ORDINAL)
    private EntityType id;

    private String description;

    public MyEntity() {
    }

    public MyEntity(EntityType id) {
        this.id = id;
        this.description = id.description;
    }

    public EntityType getId() {
        return id;
    }

    public void setId(EntityType id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}// class
