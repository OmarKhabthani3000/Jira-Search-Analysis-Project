package main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.cfg.AnnotationConfiguration; // deprecated
import org.hibernate.cfg.Environment;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class Main {

    private static String PERSISTENCE_UNIT_NAME = "TestPU";

    private static EntityManagerFactory emf;
    private static EntityManager em;
    private static EntityTransaction trans;

    public static void main(String[] args) {

        setUp(PERSISTENCE_UNIT_NAME);
        trans.begin();
        MyEntity testEntityCreate = new MyEntity(MyEntity.EntityType.TYPE_1);
        em.persist(testEntityCreate);
        MyEntity testEntityRetrieve = em.find(MyEntity.class, MyEntity.EntityType.TYPE_1);
        System.out.println("retrieved type description = " + testEntityRetrieve.getDescription());
        trans.commit();
        close();

    }// method

    private static void setUp(String puName) {
    	
        try
        {
            AnnotationConfiguration configuration = new AnnotationConfiguration();

            configuration
            .addAnnotatedClass(MyEntity.class)
            .setProperty(Environment.USER, "sa")
            .setProperty(Environment.PASS, "")
            .setProperty(Environment.URL, "jdbc:hsqldb:mem:TestPU")
            .setProperty(Environment.DIALECT, "org.hibernate.dialect.HSQLDialect")
            .setProperty(Environment.DRIVER, "org.hsqldb.jdbcDriver");

            SchemaExport schema = new SchemaExport(configuration);
            schema.setOutputFile("db/create-schema.sql");

            schema.create(true, true);
        }
        catch ( Exception e )
        {
            e.printStackTrace();
            System.exit(666);
        }
    
        emf = Persistence.createEntityManagerFactory(puName);
        em = emf.createEntityManager();
        trans = em.getTransaction();
    }

    private static void close() {
        em.close();
        emf.close();
    }

}