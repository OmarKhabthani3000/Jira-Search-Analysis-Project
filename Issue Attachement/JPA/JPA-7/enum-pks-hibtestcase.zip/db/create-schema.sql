drop table MyEntity if exists
create table MyEntity (id integer not null, description varchar(255), primary key (id))
