package hibtest;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Foo implements Serializable {
   private Long id;
   private Integer version;
   private String fooNumber;
   private Set bars = new HashSet();

   public Foo() {
   }
   public Long getId() {
      return id;
   }
   public Integer getVersion() {
      return version;
   }
   public String getFooNumber() {
      return fooNumber;
   }
   public void setFooNumber(String fooNumber) {
      this.fooNumber = fooNumber;
   }
   public Set getBars() {
      return bars;
   }
   public boolean equals(Object obj) {
      if (obj == null || !obj.getClass().equals(getClass())) {
         return false;
      }
      Foo foo2 = (Foo)obj;
      return foo2.fooNumber.equals(fooNumber);
   }
   public int hashCode() {
      return fooNumber.hashCode();
   }
}