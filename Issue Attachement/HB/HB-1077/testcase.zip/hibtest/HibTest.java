package hibtest;

import java.util.Iterator;

import net.sf.hibernate.*;
import net.sf.hibernate.cfg.Configuration;

public class HibTest {
   public static void main(String[] args) throws HibernateException {
      SessionFactory sf = new Configuration().configure().buildSessionFactory();
      Session session = sf.openSession();
      Transaction tx = session.beginTransaction();
      System.out.println("Get Foo");
      Foo foo = (Foo)session.load(Foo.class, new Long(10853));
      System.out.println("Initialize Bars");
      Hibernate.initialize(foo.getBars());
//      Iterator it = foo.getBars().iterator();
//      while (it.hasNext()) {
//         Bar bar = (Bar)it.next();
//         Hibernate.initialize(bar.getSubs());
//      }
      tx.commit();
      session.close();
      System.out.println("Changing Foo");
      System.out.println("Session2");
      Session session2 = sf.openSession();
      Transaction tx2 = session2.beginTransaction();
      System.out.println("Doing reattach");
      session2.saveOrUpdateCopy(foo);
      tx2.commit();
      session2.close();
   }
}