package hibtest;

import java.io.Serializable;

public class Sub implements Serializable {
   private String id;
   private String descEng;
   private String descFre;

   private Sub() {
   }
   public String getId() {
      return id;
   }
   public String getDescEng() {
      return descEng;
   }
   public String getDescFre() {
      return descFre;
   }
   public boolean equals(Object obj) {
      if (obj == null || !obj.getClass().equals(getClass())) {
         return false;
      }
      Sub sub2 = (Sub)obj;
      return id.equals(sub2.id);
   }
   public int hashCode() {
      return id.hashCode();
   }
}