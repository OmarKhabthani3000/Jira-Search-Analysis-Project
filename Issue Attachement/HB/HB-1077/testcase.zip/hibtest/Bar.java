package hibtest;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Bar implements Serializable {
   private Long id;
   private Integer version;
   private Set subs = new HashSet();

   public Bar() {
   }
   public Long getId() {
      return id;
   }
   public Integer getVersion() {
      return version;
   }
   public Set getSubs() {
      return subs;
   }
   public boolean equals(Object obj) {
      if (obj == null || !obj.getClass().equals(getClass())) {
         return false;
      }
      Bar bar2 = (Bar)obj;
      return bar2.id.equals(id);
   }
   public int hashCode() {
      return id.hashCode();
   }
}