package detached;

import java.util.HashSet;
import java.util.Set;

/**
 * @hibernate.class table="FLOW_VERTEX"
 */
public class Vertex extends DomainObject {

	public Vertex() {
		_sourceEdges = new HashSet();
		_sinkEdges = new HashSet();
  }//Vertex

  public String toString() {
	  return super.toString() + " flow=" + id( _flow );
  }//toString()

  /**
	 * This method is only needed for the Hibernate mapping.
   * @hibernate.id column="VERTEX_ID" type="long" generator-class="native" unsaved-value="-1"
   */
  public long getId() {
    return super.getId();
  }//getId()

  
  private Flow _flow;
  /**
   * @hibernate.many-to-one column="FLOW_ID" not-null="true" class="detached.Flow"
   */
  public Flow getFlow() {
    return _flow;
  }//getFlow()

  public void setFlow( Flow flow ) {
    assert flow != null : "flow != null";
    _flow = flow;
  }//setFlow()

  
	private Set _sourceEdges;
	/**
	 * @hibernate.set role="sourceEdges" cascade="all-delete-orphan" lazy="false" inverse="true"
	 * @hibernate.collection-key column="SOURCE_VERTEX_ID"
	 * @hibernate.collection-one-to-many class="detached.Edge"
	 */
	public Set getSourceEdges() {
	  return _sourceEdges;
	}//getSourceEdges()

	public void setSourceEdges( Set edges ) {
	  assert edges != null : "edges != null";
	  _sourceEdges = edges;
	}//setSourceEdges()
  
  public void addSourceEdge( Edge edge ) {
	  assert edge != null : "edge != null";
	  assert ! _sourceEdges.contains( edge ) : "! _sourceEdges.contains( edge )";
	  _sourceEdges.add( edge );
	  edge.setSourceVertex( this );
  }//addSourceEdge()
	
  public void removeSourceEdge( Edge edge ) {
	  assert edge != null : "edge != null";
	  assert _sourceEdges.contains( edge ) : "_sourceEdges.contains( edge )";
	  _sourceEdges.remove( edge );
  }//addSourceEdge()

  public boolean isSourceEdge( Edge edge ) {
	  return _sourceEdges.contains( edge );
  }//isSourceEdge()


  private Set _sinkEdges;
  /**
   * @hibernate.set role="sinkEdge" cascade="all-delete-orphan" lazy="false" inverse="true"
   * @hibernate.collection-key column="SINK_VERTEX_ID"
   * @hibernate.collection-one-to-many class="detached.Edge"
   */
  public Set getSinkEdges() {
	  return _sinkEdges;
  }//getSinkEdges()

  public void setSinkEdges( Set edges ) {
	  assert edges != null : "edges != null";
	  _sinkEdges = edges;
  }//setSinkEdges()
  
	  public void addSinkEdge( Edge edge ) {
		  assert edge != null : "edge != null";
	  assert ! _sinkEdges.contains( edge ) : "! _sinkEdge.contains( edge )";
	  _sinkEdges.add( edge );
	  edge.setSinkVertex( this );
  }//addSinkEdge()

  public void removeSinkEdge( Edge edge ) {
	  assert edge != null : "edge != null";
	  assert _sinkEdges.contains( edge ) : "_sinkEdge.contains( edge )";
	  _sinkEdges.remove( edge );
  }//addSinkEdge()

  public boolean isSinkEdge( Edge edge ) {
	  return _sinkEdges.contains( edge );
  }//isSourceEdge()

}//Vertex
