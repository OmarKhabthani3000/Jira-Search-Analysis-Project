package detached;

import junit.framework.TestCase;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;

public class Test extends TestCase {
	
	public static void main( String[] args ) throws HibernateException {
		(new Test()).testDetachedObjects();
	}//main()

	public void testDetachedObjects() throws HibernateException {
		Configuration configuration = new Configuration();
		configuration.addClass( Flow.class );
		configuration.addClass( Vertex.class );
		configuration.addClass( Edge.class );
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Flow flow = new Flow();
		Vertex source = new Vertex();
		flow.addVertex( source );
		Vertex sink = new Vertex();
		flow.addVertex( sink );
		Edge edge = new Edge();
		source.addSourceEdge( edge );
		sink.addSinkEdge( edge );
		session.saveOrUpdate( edge );
		session.flush();  
	}//testDetachedObjects()
	
}//Test
