package detached;

import java.io.Serializable;

public abstract class DomainObject implements Serializable {
	
	public static String id( DomainObject domainObject ) {
		return domainObject == null ? "null" : String.valueOf( domainObject.getId() );
	}//id()

	public static final long UNSAVED_VALUE = -1;
	
	public DomainObject() {
		_id = UNSAVED_VALUE;
	}//DomainObject()
	
	public String toString() {
		int index = getClass().getName().lastIndexOf('.') + 1;
		return getClass().getName().substring( index ) + ": id=" + _id;
	}//toString()

	public boolean equals( Object object ) {
		if( object == null ) return false;
		if( object == this ) return true;
		if( ! object.getClass().equals( getClass() ) ) return false;
		// Cannot compare new objects when their primary key hasn't been assigned yet.
		if( ((DomainObject) object).getId() == UNSAVED_VALUE 
			|| getId() == UNSAVED_VALUE ) return false;
		if( ((DomainObject) object).getId() == getId() ) return true;
		return false;
	}//equals()
	
	public int hashCode() {
		return hashKey().hashCode();
	}//hashCode()

	public String hashKey() {
		return getClass().getName() + getId();
	}//hashCode()

	protected long _id;

	public long getId() {
		return _id;
	}//getId()

	protected void setId( long id ) {
		_id = id;
	}//setId()
	
}//DomainObject
