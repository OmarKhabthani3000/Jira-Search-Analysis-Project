package detached;

/**
 * @hibernate.class table="FLOW_EDGE"
 */
public class Edge extends DomainObject {
	
	public Edge() {
	}//Edge()

	public String toString() {
		return super.toString()
			+ " sourceVertex=" + id( _sourceVertex ) 
			+ " sinkVertex=" + id( _sinkVertex );
	}//toString()


	/**
	 * This method is only needed for the Hibernate mapping.
	 * @hibernate.id column="FLOW_EDGE_ID" type="long" generator-class="native" unsaved-value="-1"
	 */
	public long getId() {
		return super.getId();
	}//getId()


  private Vertex _sourceVertex;
  /**
	 * @hibernate.many-to-one column="SOURCE_VERTEX_ID" not-null="true" class="detached.Vertex"
   */
  public Vertex getSourceVertex() {
  	return _sourceVertex;
  }//getSourceVertex()
  public void setSourceVertex( Vertex vertex ) {
  	assert vertex != null : "vertex != null";
		_sourceVertex = vertex;
  }//setSourceVertex()


	private Vertex _sinkVertex;
	/**
	 * @hibernate.many-to-one column="SINK_VERTEX_ID" not-null="true" class="detached.Vertex"
	 */
	public Vertex getSinkVertex() {
		return _sinkVertex;
	}//getSinkVertex()
	public void setSinkVertex( Vertex vertex ) {
		assert vertex != null : "vertex != null";
		_sinkVertex = vertex;
	}//setSinkVertex()


}//Edge
