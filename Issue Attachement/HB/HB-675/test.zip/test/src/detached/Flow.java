package detached;

import java.util.HashSet;
import java.util.Set;

/**
 * @hibernate.class table="FLOW"
 */
public class Flow extends DomainObject {
	
	public Flow() {
		_vertices = new HashSet();
	}//Flow()
	
	public String toString() {
		return super.toString() + " vertices=" + _vertices.size();
	}//toString()


	/**
	 * This method is only needed for the Hibernate mapping.
	 * @hibernate.id column="FLOW_ID" type="long" generator-class="native" unsaved-value="-1"
	 */
	public long getId() {
		return super.getId();
	}//getId()


	private Set _vertices;
	/**
   * @hibernate.set role="vertices" cascade="all-delete-orphan" lazy="false" inverse="true"
   * @hibernate.collection-key column="FLOW_ID"
   * @hibernate.collection-one-to-many class="detached.Vertex"
   */
  public Set getVertices() {
		return _vertices;
	}//getVertices()

	public void setVertices( Set vertices ) {
		assert vertices != null : "vertices != null";
		_vertices = vertices;
	}//setVertices()
	
	public void addVertex( Vertex vertex ) {
		assert vertex != null : "vertex != null";
		assert ! _vertices.contains( vertex ) : "! _vertices.contains( vertex )";
		_vertices.add( vertex );
		vertex.setFlow( this );
	}//addVertex()
	
	public void removeVertex( Vertex vertex ) {
		assert vertex != null : "vertex != null";
		assert _vertices.contains( vertex ) : "_vertices.contains( vertex )";
		boolean removed = _vertices.remove( vertex );		
		assert removed : "_vertices.remove( vertex )";
	}//addVertex()

}//Flow
