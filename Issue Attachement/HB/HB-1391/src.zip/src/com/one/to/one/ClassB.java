package com.one.to.one;

/**
* TODO To change the template for this generated type comment go to
* Window - Preferences - Java - Code Style - Code Templates.
*
* @author Perumal Bose.
*/
public class ClassB
{
    //~ Constructors -----------------------------------------------------------

    /**
     * Creates a new ClassB object.
     */
    public ClassB(  )
    {
        super(  );
    }

    //~ Methods ----------------------------------------------------------------

    /**
     * @param classA The classA to set.
     */
    public void setClassA( ClassA classA )
    {
        this.classA = classA;
    }


    /**
     * @return Returns the classA.
     */
    public ClassA getClassA(  )
    {
        return this.classA;
    }


    /**
     * @param id The id to set.
     */
    public void setId( Long id )
    {
        this.id = id;
    }


    /**
     * @return Returns the id.
     */
    public Long getId(  )
    {
        return this.id;
    }

    //~ Instance variables -----------------------------------------------------

    private ClassA classA;
    private Long id;
}