package com.one.to.one;
/**
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates.
 *
 * @author Perumal Bose.
 */
public class ClassA
{
    //~ Constructors -----------------------------------------------------------

    /**
     * Creates a new ClassA object.
     */
    public ClassA(  )
    {
        super(  );
    }

    //~ Methods ----------------------------------------------------------------

    /**
     * @param classB The classB to set.
     */
    public void setClassB( ClassB classB )
    {
        this.classB = classB;
    }


    /**
     * @return Returns the classB.
     */
    public ClassB getClassB(  )
    {
        return this.classB;
    }


    /**
     * @param id The id to set.
     */
    public void setId( Long id )
    {
        this.id = id;
    }


    /**
     * @return Returns the id.
     */
    public Long getId(  )
    {
        return this.id;
    }

    //~ Instance variables -----------------------------------------------------

    private ClassB classB;
    private Long id;
}