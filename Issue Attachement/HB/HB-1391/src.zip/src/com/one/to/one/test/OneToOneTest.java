package com.one.to.one.test;

import com.one.to.one.ClassA;
import com.one.to.one.ClassB;

import junit.framework.TestCase;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;


/**
 * @author pbose
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OneToOneTest extends TestCase
{
    //~ Methods ----------------------------------------------------------------

    /**
     * //TODO: DOCUMENT ME!
     *
     * @param session //TODO: DOCUMENT ME!
     *
     * @return //TODO: DOCUMENT ME!
     *
     * @throws HibernateException //TODO: DOCUMENT ME!
     */
    public static ClassA createClassA( Session session )
        throws HibernateException
    {
        ClassA newClassA = new ClassA(  );
        newClassA.setId( insretId );
        session.save( newClassA );

        ClassB newClassB = createClassB(  );
//        newClassA.setClassB( newClassB );
//        newClassB.setClassA( newClassA );
        session.save( newClassB );

        return newClassA;
    }


    /**
     * //TODO: DOCUMENT ME!
     *
     * @return //TODO: DOCUMENT ME!
     */
    public static ClassB createClassB(  )
    {
        ClassB newClassB = new ClassB(  );
        newClassB.setId( insretId );

        return newClassB;
    }


    /**
     * //TODO: DOCUMENT ME!
     *
     * @param args //TODO: DOCUMENT ME!
     */
    public static void main( String args[] )
    {
    }


    /**
     * Insert data into ClassA and ClassB
     * @throws Exception
     */
    public void testInsertData(  ) throws Exception
    {
        Configuration config = new Configuration(  );
        config.configure(  );

        SessionFactory sessionFactory = config.buildSessionFactory(  );
        Session session = sessionFactory.openSession(  );
        Transaction tx = null;

        try
        {
            tx = session.beginTransaction(  );
            ClassA newClassA = createClassA( session );
            tx.commit(  );
        }
        catch ( Exception e ){if ( tx != null ){tx.rollback(  );} throw e;}
        
        QueryData();
    }

    public void QueryData() throws Exception{
        Configuration config = new Configuration(  );
        config.configure(  );

        SessionFactory sessionFactory = config.buildSessionFactory(  );
        Session session = sessionFactory.openSession(  );
        Transaction tx = null;
        
        try {

            Long newIdB = ((ClassB) session.get(ClassB.class,searchId)).getId();
            Long newIdA = ((ClassA) session.get(ClassA.class,searchId)).getId();

            System.out.println("The Id of A ## "+newIdA);
            System.out.println("The Id of B ## "+newIdB);
            assertNotNull( newIdA );
        }
        catch (Exception e) {if ( tx != null ){tx.rollback(  );}}
        finally {session.close();}
    }
    /*
     * @see TestCase#setUp()
     */
    protected void setUp(  ) throws Exception
    {
        super.setUp(  );
    }


    /*
     * @see TestCase#tearDown()
     */
    protected void tearDown(  ) throws Exception
    {
        super.tearDown(  );
    }
    private static final Long insretId = new Long(50);
    private static final Long searchId = new Long(50);
}