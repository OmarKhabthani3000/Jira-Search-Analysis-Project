package gov.ca.dcss.arch.persistence.hibernate.dialect;

import net.sf.hibernate.dialect.DB2Dialect;

/**
 * @author jblanton
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class DB2CSEDialect extends DB2Dialect
{
    //~ Constructors -----------------------------------------------------------

    /**
     * Creates a new DB2UDBDialect object.
     */
    public DB2CSEDialect(  )
    {
        super(  );
    }

    //~ Methods ----------------------------------------------------------------

    /**
     * @see net.sf.hibernate.dialect.Dialect#getLimitString(java.lang.String, boolean, int)
     */
    public String getLimitString( String sql,
                                  boolean hasOffset,
                                  int limit )
    {
        return new StringBuffer( sql.length(  ) + 40 )
                 .append( sql )
                 .append( " fetch first " )
                 .append( limit )
                 .append( " rows only " )
                 .toString(  );
    }

    /**
     * @see net.sf.hibernate.dialect.Dialect#supportsLimitOffset()
     */
    public boolean supportsLimitOffset(  )
    {
        return false;
    }

    /**
     * @see net.sf.hibernate.dialect.Dialect#supportsVariableLimit()
     */
    public boolean supportsVariableLimit(  )
    {
        return false;
    }
}
