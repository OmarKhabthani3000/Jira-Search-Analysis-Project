package com.fgl.ina.stylecreation;

import com.fgl.ina.stylecreation.ordering.ProductOrderDetails;
import com.fgl.ina.stylecreation.details.ProductDetails;
import com.fgl.ina.stylecreation.details.ProductDescription;
import com.fgl.ina.stylecreation.comments.ProductComment;
import com.fgl.ina.stylecreation.coloursize.ProductColourAndSize;
import com.fgl.ina.stylecreation.availability.ProductAvailability;

import java.util.Set;
import java.util.TreeSet;
import java.util.Map;
import java.util.HashMap;
import java.util.Collection;

/**
 * INA Product bean
 * @author David Duffy, Jessica Wong
 */
public class Product {
	private int productID;
	private ProductDetails details;
	private ProductOrderDetails orders;
	private Set comments;
	private Set colours = null;
	private Set sizes = null;
	private Collection colourSizes = null;
	private Set availability=null;

	private Map productDescriptions=null;

	public Product() {
	}

	public Product(int productID) {
		this.productID = productID;
		details = new ProductDetails(1, 2);
		orders = new ProductOrderDetails();
		colours = new TreeSet();
		sizes = new TreeSet();
		colourSizes = null;	// new ArrayList();
		comments= new TreeSet();
		availability=new TreeSet();
		productDescriptions = new HashMap();
		productDescriptions.put("en", new ProductDescription(0, "en"));
		productDescriptions.put("fr", new ProductDescription(0, "fr"));
	}

	/**
	 * The ID of this product.
	 * @return this product's ID.
	 */
	public int getProductID() {
		return productID;
	}

	/**
	 * Sets the ID of this product.
	 * @param productID the new ID for this product
	 */
	public void setProductID(int productID) {
		this.productID = productID;
	}

	public ProductDetails getDetails() {
		return details;
	}

	public void setDetails(ProductDetails details) {
		this.details = details;
	}

	public ProductOrderDetails getOrders() {
		return orders;
	}

	public void setOrders(ProductOrderDetails orders) {
		this.orders = orders;
	}

	public Collection getColourSizes() {
		return colourSizes;
	}

	public void setColourSizes(Collection colourSizes) {
		this.colourSizes = colourSizes;
	}

	public Set getComments() {
		return comments;
	}

	public void setComments(Set comments) {
		this.comments = comments;
	}

	public Set getColours() {
		return colours;
	}

	public void setColours(Set colours) {
		this.colours = colours;
	}

	public Set getSizes() {
		return sizes;
	}

	public void setSizes(Set sizes) {
		this.sizes = sizes;
	}

	public Map getProductDescriptions() {
		return productDescriptions;
	}

	public void setProductDescriptions(Map productDescriptions) {
		this.productDescriptions = productDescriptions;
	}

	public boolean addComment(ProductComment comment) {
		comment.setProduct(this);
		return comments.add(comment);
	}

	public boolean addCustomer(ProductAvailability customer){
		customer.setProduct(this);
		return availability.add(customer);
	}

	public Set getAvailability() {
		return availability;
	}

	public void setAvailability(Set availability) {
		this.availability = availability;
	}


	/**
	 * Adds the specified colour and size combination to this product instance.
	 * @param colourSize the instance of {@link ProductColourAndSize} to add to this product
	 * @return the success of adding the instance to the Set of other instances.
	 */
	public boolean addColourSize(ProductColourAndSize colourSize) {
		colourSize.setParentProduct(this);
		return colourSizes.add(colourSize);
	}
}
