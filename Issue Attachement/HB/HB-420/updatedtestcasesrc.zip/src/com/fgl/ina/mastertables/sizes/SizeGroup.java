package com.fgl.ina.mastertables.sizes;

import java.util.Set;

/**
 * Bean holding a logical grouping of Sizes.
 * @author David Duffy
 */
public class SizeGroup {
	private int groupID;
	private Set descriptions;
	private Set sizes;

	/**
	 * The unique identifier of this size group instance.
	 * @return the ID of this size group.
	 */
	public int getGroupID() {
		return groupID;
	}

	/**
	 * Sets the unique identifier of this size group instance.
	 * @param groupID the new ID
	 */
	public void setGroupID(int groupID) {
		this.groupID = groupID;
	}

	/**
	 * Gets the Set of Desccriptions describing this size group.
	 * @return the Set of Descriptions for this size group.
	 */
	public Set getDescriptions() {
		return descriptions;
	}

	/**
	 * Sets the Set of Descriptions describing this size group.
	 * @param descriptions the new Set of Descriptions
	 */
	public void setDescriptions(Set descriptions) {
		this.descriptions = descriptions;
	}

	/**
	 * Gets the Set of Sizes.
	 * @return the Set of Sizes.
	 */
	public Set getSizes() {
		return sizes;
	}

	/**
	 * Sets the Set of Sizes.
	 * @param sizes the new Set of Sizes
	 */
	public void setSizes(Set sizes) {
		this.sizes = sizes;
	}

}
