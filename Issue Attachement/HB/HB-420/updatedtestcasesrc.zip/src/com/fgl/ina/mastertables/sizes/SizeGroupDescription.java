package com.fgl.ina.mastertables.sizes;

import com.fgl.ina.common.i18n.Description;

/**
 * Internationalized description for a {@link SizeGroup}.
 * @author David Duffy
 */
public class SizeGroupDescription extends Description {
}
