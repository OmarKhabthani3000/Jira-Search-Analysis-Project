package com.fgl.ina.stylecreation.lookups;



/**
 *
 * @author Jessica Wong
 */
public class UserOption {
	private int userID=0;
	private String userName=null;
	private String emailAddress=null;

	/**
	 * Gets this user's ID
	 * @return this user's ID
	 */
	public int getUserID() {
		return userID;
	}

	/**
	 * Set this user's id
	 * @param userID
	 */
	public void setUserID(int userID) {
		this.userID = userID;
	}

	/**
	 * Gets this user's username
	 * @return this user's username
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Sets this user's userName
	 * @param userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

}

