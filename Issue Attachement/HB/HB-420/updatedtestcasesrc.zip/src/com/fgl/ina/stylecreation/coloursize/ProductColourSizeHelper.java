package com.fgl.ina.stylecreation.coloursize;

import com.fgl.ina.stylecreation.Product;
import com.fgl.ina.services.DataAccessService;
import com.fgl.ina.mastertables.sizes.Size;
import com.fgl.ina.mastertables.colours.Colour;
import net.sf.hibernate.Session;

import java.util.Iterator;

/**
 * Should this lonely method maybe go on the product itself?
 * No, products shouldn't know about their own persistance.
 * @author David Duffy
 */
public class ProductColourSizeHelper {
	private ProductColourSizeHelper() {}	// we should not need to make one of these

//	private static boolean sizeExists(int sizeID, Iterator iterator) {
//		while (iterator.hasNext()) {
//			ProductColourAndSize colourSize = (ProductColourAndSize)iterator.next();
//			if (colourSize.getSize().getSizeID() == sizeID) {
//				return true;
//			}
//		}
//		return false;
//	}
//
//	private static boolean colourExists(int colourID, Iterator iterator) {
//		while (iterator.hasNext()) {
//			ProductColourAndSize colourSize = (ProductColourAndSize)iterator.next();
//			if (colourSize.getColour().getColourID() == colourID) {
//				return true;
//			}
//		}
//		return false;
//	}

	public static void createColourSizesForSize(Session session, Product product, int sizeID) throws Exception {
		Iterator coloursIterator = product.getColours().iterator();
		while (coloursIterator.hasNext()) {
			Colour productColour = (Colour)coloursIterator.next();

			createAndInsertColourSize(session, product, productColour.getColourID(), sizeID);
		}
	}

	public static void createColourSizesForColour(Session session, Product product, int colourID) throws Exception {
		Iterator sizesIterator = product.getSizes().iterator();
		while (sizesIterator.hasNext()) {
			Size productSize = (Size)sizesIterator.next();

			createAndInsertColourSize(session, product, colourID, productSize.getSizeID());
		}
	}

	private static void createAndInsertColourSize(Session session, Product product, int colourID, int sizeID) throws Exception {
		Size size = (Size)DataAccessService.get(session, Size.class, new Integer(sizeID));
		if (size == null) throw new Exception("Could not load size for ID: " + sizeID);

		Colour colour = (Colour)DataAccessService.get(session, Colour.class, new Integer(colourID));
		if (colour == null) throw new Exception("Could not load colour for ID: " + colourID);

		ProductColourAndSize newColourSize = new ProductColourAndSize(colour, size);
		product.addColourSize(newColourSize);
		DataAccessService.saveCompositeObject(session, newColourSize);
	}

	/**
	 * Removes all of the {@link ProductColourAndSize} instances from th specified {@link Product} where
	 * the @link Size} has the specified ID.
	 * @param session the persistance layer session to use
	 * @param product the owning parent Product to operate on
	 * @param sizeID the ID of the size to remove all combinations for
	 * @throws Exception
	 */
	public static void removeColourSizesForSize(Session session, Product product, int sizeID) throws Exception {
		Iterator colourSizeIterator = product.getColourSizes().iterator();
		while (colourSizeIterator.hasNext()) {
			ProductColourAndSize colourSize = (ProductColourAndSize)colourSizeIterator.next();
			if (colourSize.getSize().getSizeID() == sizeID) {
				colourSizeIterator.remove();
				DataAccessService.delete(session, colourSize);
			}
		}
	}

	/**
	 * Removes all of the {@link ProductColourAndSize} instances from the specified {@link Product} where
	 * the {@link Colour} has the specified ID.
	 * @param session the persistance layer session to use
	 * @param product the owning parent Product to operate on
	 * @param colourID the ID of the Colour to remove all combinations for
	 * @throws Exception
	 */
	public static void removeColourSizesForColour(Session session, Product product, int colourID) throws Exception {
		Iterator colourSizeIterator = product.getColourSizes().iterator();
		while (colourSizeIterator.hasNext()) {
			ProductColourAndSize colourSize = (ProductColourAndSize)colourSizeIterator.next();
			if (colourSize.getColour().getColourID() == colourID) {
				colourSizeIterator.remove();
				DataAccessService.delete(session, colourSize);
			}
		}
	}
}
