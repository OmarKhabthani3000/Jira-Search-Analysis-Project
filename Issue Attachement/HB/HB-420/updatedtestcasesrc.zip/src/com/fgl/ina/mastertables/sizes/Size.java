package com.fgl.ina.mastertables.sizes;

import java.util.Set;

/**
 *
 * @author David Duffy
 */
public class Size {
	private int sizeID;
	private String nrfSizeCode;
	private Set descriptions;

	/**
	 * Gets the ID of this Size instance.
	 * @return the size ID.
	 */
	public int getSizeID() {
		return sizeID;
	}

	/**
	 * Sets the ID of this Size instance.
	 * @param sizeID the new size ID
	 */
	public void setSizeID(int sizeID) {
		this.sizeID = sizeID;
	}

	/**
	 * Gets the NRF size code.
	 * @return the NRF for this Size code.
	 */
	public String getNrfSizeCode() {
		return nrfSizeCode;
	}

	/**
	 * Sets the NRF size code.
	 * @param nrfSizeCode the new code
	 */
	public void setNrfSizeCode(String nrfSizeCode) {
		this.nrfSizeCode = nrfSizeCode;
	}

	/**
	 * Gets the Set of internationalized size descriptions.
	 * @return the internationalized size descriptions.
	 */
	public Set getDescriptions() {
		return descriptions;
	}

	/**
	 * Sets the Set of internationalized size descriptions.
	 * @param descriptions the new Set of descriptions
	 */
	public void setDescriptions(Set descriptions) {
		this.descriptions = descriptions;
	}
}
