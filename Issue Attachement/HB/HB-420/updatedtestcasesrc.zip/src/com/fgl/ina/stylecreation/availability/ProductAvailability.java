package com.fgl.ina.stylecreation.availability;

import com.fgl.ina.stylecreation.Product;

import java.io.Serializable;

/**
 * A product has customers.  The customer must be available for it's brand.
 * @author Jessica Wong
 */
public class ProductAvailability implements Serializable{
	private Product product;
	private int customerID=0;

	/**
	 * Gets the customer id
	 * @return this customer id
	 */
	public int getCustomerID() {
		return customerID;
	}

	/**
	 * Sets the customer id
	 * @param customerID
	 */
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	/**
	 * Gets the product
	 * @return the product object (includes a set of available-selected customers)
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 * Sets this product
	 * @param product
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

}
