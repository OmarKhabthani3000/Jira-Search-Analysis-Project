package com.fgl.ina.mastertables.colours;

import java.util.Set;

/**
 * A colour bean.
 * @author David Duffy
 */
public class Colour {
	private int colourID;
	private String nrfColourCode;
	private Set descriptions;

	/**
	 * Gets the ID of this Colour instance.
	 * @return the colour ID.
	 */
	public int getColourID() {
		return colourID;
	}

	/**
	 * Sets the ID of this Colour instance.
	 * @param colourID the new colour ID
	 */
	public void setColourID(int colourID) {
		this.colourID = colourID;
	}

	/**
	 * Gets the NRF colour code.
	 * @return the NRF for this Colour code.
	 */
	public String getNrfColourCode() {
		return nrfColourCode;
	}

	/**
	 * Sets the NRF colour code.
	 * @param nrfColourCode the new code
	 */
	public void setNrfColourCode(String nrfColourCode) {
		this.nrfColourCode = nrfColourCode;
	}

	/**
	 * Gets the Set of internationalized colour descriptions.
	 * @return the internationalized colour descriptions.
	 */
	public Set getDescriptions() {
		return descriptions;
	}

	/**
	 * Sets the Set of internationalized colour descriptions.
	 * @param descriptions the new Set of descriptions
	 */
	public void setDescriptions(Set descriptions) {
		this.descriptions = descriptions;
	}
}
