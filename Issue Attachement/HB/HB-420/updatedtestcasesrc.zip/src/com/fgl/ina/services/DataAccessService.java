package com.fgl.ina.services;

import net.sf.hibernate.Session;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.HibernateException;

import java.util.List;
import java.io.Serializable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Generic Data Access Services
 * @author Jessica Wong, David Duffy
 */
public class DataAccessService {
	private static final Log log=LogFactory.getLog(DataAccessService.class);

	/**
	 * Explicitly calls persistance layer save to insert a new record of a composite-id type which is its own identifier.
	 * I have no idea if this method makes any sense...
	 * @param obj the Object instance to insert
	 * @throws HibernateException
	 */
	public static void saveCompositeObject(Session session, Object obj) throws HibernateException {
		session.save(obj, (Serializable)obj);
		session.flush();
	}

	/**
	 * Explicitly calls persistance layer save to insert a new record.
	 * @param session the persistance layer session to use
	 * @param obj the Object to persist
	 * @throws HibernateException
	 */
	public static void save(Session session, Object obj) throws HibernateException {
		session.save(obj);
		session.flush();
	}

	/**
	 * Persists the passed in Object if it is mapped in the O/R mapping layer.
	 * @param obj the Object to persist
	 * @return a useless hardcoded String which should be changed to something else...
	 * @throws Exception
	 */
	public static boolean saveOrUpdate(Session session, Object obj) throws Exception {
		boolean status = false;
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			session.saveOrUpdate(obj);
			tx.commit();
			status=true;
		} catch (Exception e) {
			tx.rollback();
			log.error("error saving or updating " +  obj.getClass().getName(), e);
		}

		return status;
	}

	/**
	 * Gets all instances of the specified {@link Class}.
	 * @param objectClass the class type to retrieve persisted instances for
	 * @return all the persisted instances of the specified class.
	 * @throws Exception
	 */
	public static List get(Session session, Class objectClass) throws Exception {
		return session.createCriteria(objectClass).list();
	}

	/**
	 * Gets the instance of the specified class with the specified id
	 * @param session
	 * @param objectClass
	 * @return
	 * @throws HibernateException
	 */
	public static Object get(Session session, Class objectClass, Integer ID) throws HibernateException {
		return session.get(objectClass, ID);
	}

	/**
	 * Deletes the specified object (this is a dangerous method, it should not be called on anything that could
	 * still be referenced by something in the database which would cause a key constraint violation).
	 * @param session the persistance session to use
	 * @param obj the Object instance to un-persist
	 * @throws HibernateException
	 */
	public static void delete(Session session, Object obj) throws HibernateException {
		session.delete(obj);
		session.flush();
	}

	/**
	 * Tests if an instance of the specified type of Object exists with the specified ID value.
	 *
	 * @param session the persistance session to use
	 * @param objectClass the Class to try to find a matching instance of
	 * @param ID the ID of the searched for instance
	 * @return true if the instance exists.
	 */
	public static boolean objectExists(Session session, Class objectClass, Integer ID) {
		StringBuffer hqlString = new StringBuffer("select count(obj) from ");
		hqlString.append(objectClass.getName());
		hqlString.append(" obj where obj.id = ");
		hqlString.append(ID);

		boolean exists = false;
		try {
			exists = (((Integer)session.iterate(hqlString.toString()).next()).intValue() > 0);
		} catch(HibernateException he) {
			if (log.isWarnEnabled()) {
				log.warn("Error trying to determine if object exists", he);
			}
		}
		return (exists);
	}
}
