package com.fgl.ina.stylecreation.comments;

import java.util.Date;
import java.io.Serializable;

import com.fgl.ina.stylecreation.lookups.UserOption;
import com.fgl.ina.stylecreation.Product;

/**
 *
 * @author Jessica Wong
 */
public class ProductComment implements Serializable {
	private Product product;
	private int commentID=0;
	private Date date=null;
	private int status=0;
	private int userID=0;
	private UserOption user=null;
	private String comment=null;

	/**
	 * Gets the date for this comment
	 * @return this comment's date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * Sets this comment's date
	 * @param date
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * Gets the status of the product when this comment was made
	 * @return this status
	 */
	public int getStatus() {
		return status;
	}

	/**
	 * Sets the status of the product when this comment was made
	 * @param status
	 */
	public void setStatus(int status) {
		this.status = status;
	}

	/**
	 * Gets the id of the user who made this comment
	 * @return this comment's userid
	 */
	public int getUserID() {
		return userID;
	}

	/**
	 * Sets the id of the user who made this comment
	 * @param userID
	 */
	public void setUserID(int userID) {
		this.userID = userID;
	}

	/**
	 * Gets the comment
	 * @return this comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * Sets this commment
	 * @param comment
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * Gets the id for this comment
	 * @return the commentID
	 */
	public int getCommentID() {
		return commentID;
	}

	/**
	 * Sets the comment id for this comment
	 * @param commentID
	 */
	public void setCommentID(int commentID) {
		this.commentID = commentID;
	}

	/**
	 * Gets the User for this comment
	 * @return the user details for the user who made this comment
	 */
	public UserOption getUser() {
		return user;
	}

	/**
	 * Sets the UserOption representing the user who made this comment
	 * @param user
	 */
	public void setUser(UserOption user) {
		this.user = user;
	}

	/**
	 * Gets this product
	 * @return this product
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 * Sets this product
	 * @param product
	 */
	public void setProduct(Product product) {
		this.product = product;
	}


}
