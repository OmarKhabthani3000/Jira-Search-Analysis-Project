package com.fgl.ina.common.i18n;

import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

import java.io.Serializable;

/**
 * Holder bean for an internationalized description in a particular language.<br>
 * This class should not be directly instantiated because it does not (and should not) have an O/R mapping.
 * <br><br>
 * Any classes needing to implement this functionality should extend this class or reference extensions of this class.
 * @author David Duffy
 */
abstract public class Description implements Serializable {
	/** the ID of the description */
	protected int ID;
	/** the language code for the {@link #description} in this instance */
	protected String language = "en";	// is defaulting this here good or bad?
	/** the internationalized description of this instance */
	protected String description;

	/**
	 * Gets the ID
	 * @return the ID
	 */
	public int getID() {
		return ID;
	}

	/**
	 * Sets the ID
	 * @param ID the new ID
	 */
	public void setID(int ID) {
		this.ID = ID;
	}

	/**
	 * Gets the locale specific language code of the language that the {@link #description} is in.
	 * @return the lanugage code.
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * Sets the code of the language that the {@link #description} is in.
	 * @param language the new lanugage code
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * Gets the internationalized description of this instance.
	 * @return the internationalized description.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description for this instance.
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Compares an Object to this instance for equality.
	 * <br>
	 * This overrides the default {@link Object#equals(Object)} implementation in a manner which is potentially
	 * subjective because a true value will also be returned from this method if the attributes match and not
	 * just if it is the same reference.
	 *
	 * @param compareTo the Object to compare this to
	 * @return true if this instance is the same instance as Object or all of the attributes match.
	 */
	public boolean equals(Object compareTo) {
		Log log = LogFactory.getLog(Description.class);
		if (compareTo == null) {
			log.debug("Description: compareTo == null");
			return false;
		}
		// check if it is literally the same object
		if (super.equals(compareTo)) {
			log.debug("Description: super.equals(compareTo) == true");
			return true;
		}
		// check if it is at least an instance of this type
		if (!(compareTo instanceof Description)) {
			log.debug("Description: compareTo ! instanceof Description");
			return false;
		}
		Description compareMe = (Description)compareTo;
		log.debug("Description: this == " + this);
		log.debug("Description: compareMe == " + compareMe);

		// compare the key attributes (anything which is not part of the key should be irrelevant)
		if (this.ID == compareMe.getID()) {
			if (((this.language != null && compareMe.getLanguage() != null)
					&& (this.language.compareTo(compareMe.getLanguage()) == 0))
					|| (this.language == null && compareMe.getLanguage() == null))
			{
				log.debug("Description: this.properties equals compareMe.properties");
				return true;
			}
		}
		if (log.isDebugEnabled()) {
			log.debug("Description: this != compareMe" +
				"\tthis.ID = " + this.ID + " : compareMe.ID = " + compareMe.getID() +
				"\tthis.language = " + this.language + " : compareMe.language = " + compareMe.getLanguage());
		}
		return false;
	}


	/**
	 * Provides a hash value for this instance that is unique to the values of the key properties.
	 * <br>Note: two instances of Description with the same values will have the same hash (right now).
	 * @return the unique (per property values) hashing code for this instance.
	 */
	public int hashCode() {
		return new HashCodeBuilder()
			.append(ID)
			.append(language)
			.toHashCode();	// I have no idea what this generates...
	}
}
