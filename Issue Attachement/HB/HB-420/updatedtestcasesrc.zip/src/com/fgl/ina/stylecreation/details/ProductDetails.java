package com.fgl.ina.stylecreation.details;

import java.util.*;
import java.io.Serializable;

/**
 *
 * @author Jessica Wong
 */
public class ProductDetails implements Serializable{
		private String vpn=null;
		private Integer season=null;
		private int status=0;
		private int vendorNumber=0;
		private String vendorDesc=null;
		private Integer hierarchyID=null;
		private int submittedVia=0;
		private Date submittedDate=null;
		private Integer brand=null;
		private Integer ctyOrigin=null;
		private String inco=null;
		private Float vendorFirstCost = null;
		private Integer currency1=null;
		private Integer currency2=null;
		private Integer currency3=null;
		private Integer payment1=null;
		private Integer payment2=null;
		private Integer payment3=null;
		private String imageURL=null;

		public ProductDetails() {}

		public ProductDetails(int status, int submittedVia) {
			this.status = status;
			this.submittedVia = submittedVia;
			this.submittedDate = new Date();
		}

		/**
		 * Gets the vpn of the product
		 * @return the vpn
		 */
		public String getVpn() {
			return vpn;
		}

		/**
		 * Sets the vpn of the product
		 * @param vpn the new vpn
		 */
		public void setVpn(String vpn) {
			this.vpn = vpn;
		}

		/**
		 * Gets the season for the product
		 * @return the season
		 */
		public Integer getSeason() {
			return season;
		}

		/**
		 * Sets the season for the product
		 * @param season the new season
		 */
		public void setSeason(Integer season) {
			this.season = season;
		}

		/**
		 * Gets the status for the product
		 * @return the status of the product
		 */
		public int getStatus() {
			return status;
		}

		/**
		 * Sets the status of the product
		 * @param status the new status
		 */
		public void setStatus(int status) {
			this.status = status;
		}

		/**
		 * Gets the vendor number for this product
		 * @return the vendor number for this product
		 */
		public int getVendorNumber() {
			return vendorNumber;
		}

		/**
		 * Sets the vendor number for this product
		 * @param vendorNumber the new vendor number
		 */
		public void setVendorNumber(int vendorNumber) {
			this.vendorNumber = vendorNumber;
		}

		/**
		 * Gets the vendor description for this product
		 * @return the vendor description for this product
		 */
		public String getVendorDesc() {
			return vendorDesc;
		}

		/**
		 * Sets the vendor description for this product
		 * @param vendorDesc the new vendor description
		 */
		public void setVendorDesc(String vendorDesc) {
			this.vendorDesc = vendorDesc;
		}


//		/**
//		 * Gets the sub class code for this product
//		 * @return the sub class code for this product
//		 */
//		public Integer getSubClassCode() {
//			return subClassCode;
//		}
//
//		/**
//		 * Sets the sub class code for this product
//		 * @param subClassCode
//		 */
//		public void setSubClassCode(Integer subClassCode) {
//			this.subClassCode = subClassCode;
//		}

		/**
		 * Gets the submitted method type for this product
		 * @return the submitted via type for this product
		 */
		public int getSubmittedVia() {
			return submittedVia;
		}

		/**
		 * Sets the submitted via type for this product
		 * @param submittedVia the new submitted via type
		 */
		public void setSubmittedVia(int submittedVia) {
			this.submittedVia = submittedVia;
		}



		/**
		 * Gets the submitted date for this product
		 * @return this submitted date
		 */
		public Date getSubmittedDate() {
			return submittedDate;
		}

		/**
		 * Sets the submitted date for this product
		 * @param submittedDate the new submitted date
		 */
		public void setSubmittedDate(Date submittedDate) {
			this.submittedDate = submittedDate;
		}

		/**
		 * Gets the brand for this product
		 * @return this brand
		 */
		public Integer getBrand() {
			return brand;
		}

		/**
		 * Sets the brand for this product
		 * @param brand the new brand
		 */
		public void setBrand(Integer brand) {
			this.brand = brand;
		}

		/**
		 * Gets the country of origin for this product
		 * @return this country of origin
		 */
		public Integer getCtyOrigin() {
			return ctyOrigin;
		}

		/**
		 * Sets the country of origin
		 * @param ctyOrigin the new country of origin
		 */
		public void setCtyOrigin(Integer ctyOrigin) {
			this.ctyOrigin = ctyOrigin;
		}

		/**
		 * Gets the inco terms for this product
		 * @return the inco terms
		 */
		public String getInco() {
			return inco;
		}

		/**
		 * Sets the inco terms for this product
		 * @param inco the new inco term
		 */
		public void setInco(String inco) {
			this.inco = inco;
		}

		/**
		 * Sets the currency 1 type for this product
		 * @return the currency 1 type for this product
		 */
		public Integer getCurrency1() {
			return currency1;
		}

		/**
		 * Sets the currency 1 type for this product
		 * @param currency1
		 */
		public void setCurrency1(Integer currency1) {
			this.currency1 = currency1;
		}

		/**
		 * Sets the currency 2 type for this product
		 * @return the currency 2 type for this produc
		 */
		public Integer getCurrency2() {
			return currency2;
		}

		/**
		 * Sets the currency 2 type for this product
		 * @param currency2
		 */
		public void setCurrency2(Integer currency2) {
			this.currency2 = currency2;
		}

		/**
		 * Sets the currency 3 type for this product
		 * @return the currency 2 type for this produc
		 */
		public Integer getCurrency3() {
			return currency3;
		}

		/**
		 * Sets the currency 3 type for this product
		 * @param currency3
		 */
		public void setCurrency3(Integer currency3) {
			this.currency3 = currency3;
		}

		/**
		 * Sets the payment 1 type for this product
		 * @return the payment 2 type
		 */
		public Integer getPayment1() {
			return payment1;
		}

		/**
		 * Sets the payment 1 type for this product
		 * @param payment1 the new payment 1
		 */
		public void setPayment1(Integer payment1) {
			this.payment1 = payment1;
		}

		/**
		 * Sets the payment 2 type for this product
		 * @return the payment 2
		 */
		public Integer getPayment2() {
			return payment2;
		}

		/**
		 * Sets the payment 2 type for this product
		 * @param payment2 the new payment 2
		 */
		public void setPayment2(Integer payment2) {
			this.payment2 = payment2;
		}

		/**
		 * Sets the payment 3 type for this product
		 * @return the payment 3 type
		 */
		public Integer getPayment3() {
			return payment3;
		}

		/**
		 * Sets the payment 3 type for this product
		 * @param payment3 the new payment 3
		 */
		public void setPayment3(Integer payment3) {
			this.payment3 = payment3;
		}

	public Integer getHierarchyID() {
			return hierarchyID;
		}

	public void setHierarchyID(Integer hierarchyID) {
		this.hierarchyID = hierarchyID;
	}

	public String toString(){
		StringBuffer str = new StringBuffer("\n");
		str.append(getClass().getName());
		str.append("\n\tvpn:\t");
		str.append(this.getVpn());
		str.append("\n\tvendor:\t");
		str.append(this.getVendorNumber());
		str.append("\n\tseason:\t");
		str.append(this.getSeason());
		str.append("\n\tstatus:\t");
		str.append(this.getStatus());
		str.append("\n\tsubmittedVia:\t");
		str.append(this.getSubmittedVia());
		str.append("\n\tsubmittedDate:\t");
		str.append(this.getSubmittedDate());

		return str.toString();
	}

	public String getImageURL() {
		return imageURL;
	}

	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}

	public Float getVendorFirstCost() {
		return vendorFirstCost;
	}

	public void setVendorFirstCost(Float vendorFirstCost) {
		this.vendorFirstCost = vendorFirstCost;
	}

}

