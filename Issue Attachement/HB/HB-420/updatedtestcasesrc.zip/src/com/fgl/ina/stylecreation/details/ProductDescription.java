package com.fgl.ina.stylecreation.details;

import com.fgl.ina.common.i18n.Description;

/**
 *
 * @author Jessica Wong
 */
public class ProductDescription extends Description {

	private String techSpec=null;

	public ProductDescription() {}

	public ProductDescription(int ID, String language) {
		this.ID = ID;
		this.language=language;
	}


	public String getTechSpec() {
		return techSpec;
	}

	public void setTechSpec(String techSpec) {
		this.techSpec = techSpec;
	}


}
