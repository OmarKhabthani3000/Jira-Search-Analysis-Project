package com.fgl.ina.stylecreation.ordering;

import java.util.Date;

/**
 * Prodcut order details
 * @author Jessica Wong
 */
public class ProductOrderDetails {
		private int productID=0;
		private Integer uom=null;
		private int innerPack=0;
		private Integer outerPack=null;
		private Float outerPackVol=null;
		private Date orderDate1=null;
		private Date orderDate2=null;
		private Date orderDate3=null;
		private Date shipDate1=null;
		private Date shipDate2=null;
		private Date shipDate3=null;
		private Integer minOrderStyle=null;
		private Integer minOrderColour=null;
		private Integer minOrderSize=null;

	public String toString(){
		// TODO: convert to StringBuffer...
		String str=null;
		str = "ProductOrderDetails: id=" + this.getProductID() + " uom=" + this.getUom();
		str = str + " innerPack=" + this.getInnerPack() + " outerPack=" + this.getOuterPack();
		str = str + " orderDt1=" + this.getOrderDate1() + " shipDt1=" + this.getShipDate1();

		return str;
	}
	public Integer getUom() {
		return uom;
	}

	public void setUom(Integer uom) {
		this.uom = uom;
	}

	public int getInnerPack() {
		return innerPack;
	}

	public void setInnerPack(int innerPack) {
		this.innerPack = innerPack;
	}

	public Integer getOuterPack() {
		return outerPack;
	}

	public void setOuterPack(Integer outerPack) {
		this.outerPack = outerPack;
	}

	public Float getOuterPackVol() {
		return outerPackVol;
	}

	public void setOuterPackVol(Float outerPackVol) {
		this.outerPackVol = outerPackVol;
	}

	public Date getOrderDate1() {
		return orderDate1;
	}

	public void setOrderDate1(Date orderDate1) {
		this.orderDate1 = orderDate1;
	}

	public Date getOrderDate2() {
		return orderDate2;
	}

	public void setOrderDate2(Date orderDate2) {
		this.orderDate2 = orderDate2;
	}

	public Date getOrderDate3() {
		return orderDate3;
	}

	public void setOrderDate3(Date orderDate3) {
		this.orderDate3 = orderDate3;
	}

	public Date getShipDate1() {
		return shipDate1;
	}

	public void setShipDate1(Date shipDate1) {
		this.shipDate1 = shipDate1;
	}

	public Date getShipDate2() {
		return shipDate2;
	}

	public void setShipDate2(Date shipDate2) {
		this.shipDate2 = shipDate2;
	}

	public Date getShipDate3() {
		return shipDate3;
	}

	public void setShipDate3(Date shipDate3) {
		this.shipDate3 = shipDate3;
	}

	public Integer getMinOrderStyle() {
		return minOrderStyle;
	}

	public void setMinOrderStyle(Integer minOrderStyle) {
		this.minOrderStyle = minOrderStyle;
	}

	public Integer getMinOrderColour() {
		return minOrderColour;
	}

	public void setMinOrderColour(Integer minOrderColour) {
		this.minOrderColour = minOrderColour;
	}

	public Integer getMinOrderSize() {
		return minOrderSize;
	}

	public void setMinOrderSize(Integer minOrderSize) {
		this.minOrderSize = minOrderSize;
	}

	public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}


}

