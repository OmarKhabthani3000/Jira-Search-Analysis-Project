package com.fgl.ina.stylecreation.coloursize;

import com.fgl.ina.mastertables.sizes.Size;
import com.fgl.ina.mastertables.colours.Colour;
import com.fgl.ina.stylecreation.Product;
import com.fgl.ina.stylecreation.barcodes.ProductBarcode;

import java.io.Serializable;
import java.util.Collection;

import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * The x-ref holder for a product colour and size combination.
 * @author David Duffy
 */
public class ProductColourAndSize implements Serializable {
	private Product parentProduct;
	private Colour colour;
	private Size size;
	private boolean available;
	private Collection barcodes;

	/**
	 * Default empty constructor
	 */
	public ProductColourAndSize() {}

	/**
	 * Populating constructor
	 * @param colour the Colour in the combination
	 * @param size the Size in the combination
	 */
	public ProductColourAndSize(Colour colour, Size size) {
		this.colour = colour;
		this.size = size;
		available = true;
	}

	/**
	 * Populating constructor
	 * @param parent the owning Product of this colour and size combination.
	 * @param colour the Colour in the combination
	 * @param size the Size in the combination
	 */
	public ProductColourAndSize(Product parent, Colour colour, Size size) {
		this(colour, size);
		this.parentProduct = parent;
	}

	public Product getParentProduct() {
		return parentProduct;
	}

	public void setParentProduct(Product parentProduct) {
		this.parentProduct = parentProduct;
	}

	public Colour getColour() {
		return colour;
	}

	public void setColour(Colour colour) {
		this.colour = colour;
	}

	public Size getSize() {
		return size;
	}

	public void setSize(Size size) {
		this.size = size;
	}

	public boolean isAvailable() {
		return available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	/**
	 * Gets the Set of {@link ProductBarcode} instances for this colour and size combination.
	 * @return the Set of barcodes.
	 */
	public Collection getBarcodes() {
		return barcodes;
	}

	/**
	 * Sets the Set of {@link ProductBarcode} instances for this colour and size combination.
	 * @param barcodes the new Set of barcodes
	 */
	public void setBarcodes(Collection barcodes) {
		this.barcodes = barcodes;
	}

	/**
	 * Adds a new barcode to this colour and size combination.
	 * @param barcode the new {@link ProductBarcode}
	 * @return the result of trying to add the barcode to the Set.
	 */
	public boolean addBarcode(ProductBarcode barcode) {
		barcode.setParentColourSize(this);
		return barcodes.add(barcode);
	}

	/**
	 * Test for object equality.
	 * @param obj the Object to compare this to
	 * @return true if they are the same or at least have the "same" properties.
	 */
	public boolean equals(Object obj) {
		try {
			if (obj != null) {
				if (obj instanceof ProductColourAndSize) {
					ProductColourAndSize compareMe = (ProductColourAndSize)obj;
					if ((this.parentProduct.getProductID() == compareMe.getParentProduct().getProductID())
						&& (this.colour.getColourID() == compareMe.getColour().getColourID())
						&& (this.size.getSizeID() == compareMe.getSize().getSizeID()))
					{
						return true;
					}
				}
			}
		} catch (NullPointerException npe) {
			/* it's not a truly safe assumption that if something is null they don't match and skip testing for null */
		}
		return false;
	}

	/**
	 * Generates a "unique" hash code for this instance (unique to the extent of {@link #equals(Object)} returning false).
	 * @return the hash code.
	 */
	public int hashCode() {
		return new HashCodeBuilder()
			.append(parentProduct.getProductID())
			.append(colour.getColourID())
			.append(size.getSizeID())
			.toHashCode();
	}
}
