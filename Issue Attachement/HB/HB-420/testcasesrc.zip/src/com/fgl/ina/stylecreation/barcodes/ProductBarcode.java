package com.fgl.ina.stylecreation.barcodes;

import com.fgl.ina.stylecreation.coloursize.ProductColourAndSize;
import com.fgl.ina.stylecreation.lookups.BarcodeType;

import java.io.Serializable;

/**
 * Holds the information for one record in the product_barcode table.
 * @author David Duffy
 */
public class ProductBarcode implements Serializable {
	public static final int UPC = 1;		// 1
	public static final int EAN = UPC + 1;	// 2
	public static final int JAN = EAN + 1;	// 3
	public static final int INA = JAN + 1;	// 4

	private int ID;
	private String barcode;
	private ProductColourAndSize parentColourSize;
	private BarcodeType barcodeType;
	private boolean primary;

	public ProductBarcode() {}

	public ProductBarcode(String barcode, ProductColourAndSize parentColourSize, BarcodeType barcodeType) {
		this.barcode = barcode;
		this.parentColourSize = parentColourSize;
		this.barcodeType = barcodeType;
		this.primary = false;
	}

	public int getID() {
		return ID;
	}

	public void setID(int ID) {
		this.ID = ID;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public ProductColourAndSize getParentColourSize() {
		return parentColourSize;
	}

	public void setParentColourSize(ProductColourAndSize parentColourSize) {
		this.parentColourSize = parentColourSize;
	}

	public BarcodeType getBarcodeType() {
		return barcodeType;
	}

	public void setBarcodeType(BarcodeType barcodeType) {
		this.barcodeType = barcodeType;
	}

	public boolean isPrimary() {
		return primary;
	}

	public void setPrimary(boolean primary) {
		this.primary = primary;
	}

	/**
	 * Tries to convert the specified barcode string to a long to check if it is a valid sequence of numbers only.
	 * @param barcode the String to check for numeric values only
	 * @return the long representation of the barcode.
	 */
	private static long getBarcodeAsLongNumber(String barcode) {
		if (barcode == null) throw new IllegalArgumentException("Barcode cannot be null.");
		try {
			return Long.parseLong(barcode);
		} catch (NumberFormatException nfe) {
			throw new IllegalArgumentException("Barcode must not contain characters other than numbers (0-9).");
		}
	}

	/**
	 * Calculates the check digit for the specified barcode in UPC (12) format.<br>
	 * This method uses the algorithm found on the UCC website at
	 * <a href="http://www.uc-council.org/ean_ucc_system/index.html">UCC</a>.<br>
	 *
	 * @param barcodeNumber the long representation of the barcode to calculate the check digit for
	 * @return the calculated check digit.
	 */
	private static int calculateCheckDigit(long barcodeNumber, int length) {
		long working = barcodeNumber;

		int checkDigit = 0;
		int factor = 3;
		int weightedTotal = 0;
		for (int index = length; index > 0; --index) {
			int current = (int)(working % 10);	// Get the value of each digit starting with the lowest
			working/=10;						// divide by 10 to move to the next digit
			//multiply by the weighting factor which is 3,1,3,1... and add the sum together
			weightedTotal = weightedTotal + current * factor;
			factor = 4 - factor;				//change factor for next calculation
		}
		// Find the Check Digit (x) by solving for (x) where (weightedTotal + x) Mod 10 = 0;
		checkDigit = ((1000 - weightedTotal) % 10);
		return checkDigit;
	}

	/**
	 * Calculates the check digit for the specified barcode in UPC (12) format.
	 * @param barcode the String representation of the barcode to calculate the check digit for
	 * @return the calculated check digit.
	 */
	public static int calculateCheckDigitForUPC(String barcode) {
		long number = getBarcodeAsLongNumber(barcode);
		if (barcode.length() != 11) {
			throw new IllegalArgumentException("UPC barcode length must be 11 characters.");
		}
		return calculateCheckDigit(number, barcode.length());
	}

	/**
	 * Calculates the check digit for the specified barcode in EAN (13) format.
	 * @param barcode the String representation of the barcode to calculate the check digit for
	 * @return the calculated check digit.
	 */
	public static int calculateCheckDigitForEAN(String barcode) {
		long number = getBarcodeAsLongNumber(barcode);
		if (barcode.length() != 12) {
			throw new IllegalArgumentException("EAN barcode length must be 12 characters.");
		}
		return calculateCheckDigit(number, barcode.length());
	}

	/**
	 * Calculates the check digit for the specified barcode in INA (UPC) format.<br>
	 * This implementation (rightly) assumes that INA format is the same as UPC format and passes
	 * the processing responsibility to {@link #calculateCheckDigitForUPC(String)}.
	 * @param barcode the String representation of the barcode to calculate the check digit for
	 * @return the calculated check digit.
	 */
	public static int calculateCheckDigitForINA(String barcode) {
		return calculateCheckDigitForUPC(barcode);
	}

	/**
	 * Calculates the check digit for the specified barcode in JAN format.<br>
	 * Current implementation assumes that JAN is the same as EAN...
	 * @param barcode the String representation of the barcode to calculate the check digit for
	 * @return the calculated check digit.
	 */
	public static int calculateCheckDigitForJAN(String barcode) {
		return calculateCheckDigitForEAN(barcode);
	}

	/**
	 * Validates the barcode's check digit.
	 * @return true if the bar code is valid.
	 */
	public boolean validateBarcode() {
		return validateBarcode(barcodeType.getID(), barcode);
	}

	public static boolean validateBarcode(int type, String barcode) {
		if (type == UPC) return validateUPCBarcode(barcode);
		if (type == INA) return validateINABarcode(barcode);
		if (type == EAN) return validateEANBarcode(barcode);
		if (type == JAN) return validateJANBarcode(barcode);
		return false;	// should we throw an Exception for an unknown type?  Should we change type to be a typed "Enum"?
	}

	private static boolean validateINABarcode(String barcode) {
		return validateUPCBarcode(barcode);
	}

	/**
	 * Validates the barcode by validating its check digit.<br>
	 * @param barcode the barcode (in String format) to validate.
	 * @return true if the bar code is valid.
	 */
	private static boolean validateUPCBarcode(String barcode) {
		if (barcode != null && barcode.length() == 12) {
			if (calculateCheckDigitForUPC(barcode.substring(0, 11)) == Integer.parseInt(barcode.substring(11, 12))) {
				return true;
			}
		}
		return false;
	}

	private static boolean validateJANBarcode(String barcode) {
		return validateEANBarcode(barcode);
	}

	private static boolean validateEANBarcode(String barcode) {
		if (barcode != null && barcode.length() == 13) {
			if (calculateCheckDigitForEAN(barcode.substring(0, 12)) == Integer.parseInt(barcode.substring(12, 13))) {
				return true;
			}
		}
		return false;
	}
}
