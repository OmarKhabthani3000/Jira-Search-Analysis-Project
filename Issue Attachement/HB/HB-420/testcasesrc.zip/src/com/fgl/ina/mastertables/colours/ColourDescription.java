package com.fgl.ina.mastertables.colours;

import com.fgl.ina.common.i18n.Description;

/**
 * I18N description holder for instances of {@link Colour}.
 * @author David Duffy
 */
public class ColourDescription extends Description {
}
