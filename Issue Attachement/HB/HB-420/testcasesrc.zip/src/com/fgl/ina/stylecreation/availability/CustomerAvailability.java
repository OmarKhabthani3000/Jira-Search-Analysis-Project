package com.fgl.ina.stylecreation.availability;

/**
 * A customer available for the brand, including it's id and name as well
 * as an indicator(available) to indicate whether it is selected for the product.
 * @author Jessica Wong
 */
public class CustomerAvailability {
	private int customerID=0;
	private String customerName=null;
	private boolean available=false;

/**
 * Reset the class properties
 */
	public void reset(){
		available=false;
		customerID=0;
		customerName=null;
	}

	/**
	 * Get the customer id for this customer
	 * @return the customer id
	 */
	public int getCustomerID() {
		return customerID;
	}

	/**
	 * Sets the customer id for this customer
	 * @param customerID
	 */
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	/**
	 * Gets the customer name for this customer
	 * @return this customer's name
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * Set the customer name for this customer
	 * @param customerName
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * Gets the available indicator for this product
	 * @return  true if this customer has been selected for this product
	 */
	public boolean isAvailable() {
		return available;
	}

	/**
	 * Sets the available indicator for this product:
	 * 	true if the customer is selected for this product
	 * @param available
	 */
	public void setAvailable(boolean available) {
		this.available = available;
	}


}
