package com.fgl.ina.mastertables.sizes;

import com.fgl.ina.common.i18n.Description;

/**
 * Size bean I18N description.
 * @author David Duffy
 */
public class SizeDescription extends Description {
}
