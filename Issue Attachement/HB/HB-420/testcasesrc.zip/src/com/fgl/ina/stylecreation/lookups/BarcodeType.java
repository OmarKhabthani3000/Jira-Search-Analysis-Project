package com.fgl.ina.stylecreation.lookups;

import com.fgl.ina.common.i18n.Description;

/**
 * Value Object bean for holding a lookup of a barcode type.
 * @author David Duffy
 */
public class BarcodeType {
	private int ID;
	private String code;

	/**
	 * Gets the ID of this type.
	 * @return this barcode type's ID.
	 */
	public int getID() {
		return ID;
	}

	/**
	 * Sets the ID of this type.
	 * @param ID the new ID
	 */
	public void setID(int ID) {
		this.ID = ID;
	}

	/**
	 * Gets the Barcode type code.<br>
	 * One of:
	 * <ul>
	 * <li>UPC</li>
	 * <li>EAN</li>
	 * <li>JAN</li>
	 * <li>INA</li>
	 * </ul>
	 * @return the code.
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Sets the Barcode type code.<br>
	 * One of:
	 * <ul>
	 * <li>UPC</li>
	 * <li>EAN</li>
	 * <li>JAN</li>
	 * <li>INA</li>
	 * </ul>
	 * @param code the new code
	 */
	public void setCode(String code) {
		this.code = code;
	}
}
