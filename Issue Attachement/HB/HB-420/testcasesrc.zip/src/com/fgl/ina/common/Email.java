package com.fgl.ina.common;

import javax.mail.Session;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.InternetAddress;
import java.util.Properties;
import java.util.Date;

/**
 * Email services
 * @author Jessica Wong
 */
public class Email {

	/**
	 * Send an email
	 * @param smtpServer
	 * @param to Email address
	 * @param from Email address
	 * @param subject string subject for email
	 * @param body string body of email
	 * @return boolean true if successfull
	 */
	public static boolean sendEmail(String smtpServer, String to, String from
							   , String subject, String body) {

		boolean status = false;

		try {
			Properties properties = System.getProperties();

			// -- Attaching to default Session, or we could start a new one --

			properties.put("mail.smtp.host", smtpServer);
			Session session = Session.getDefaultInstance(properties, null);

			// -- Create a new message --
			Message msg = new MimeMessage(session);

			// -- Set the FROM and TO fields --
			msg.setFrom(new InternetAddress(from));
			//comma delimited list
			msg.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(to, false));

			// -- We could include CC recipients too --
			// if (cc != null)
			// msg.setRecipients(Message.RecipientType.CC
			// ,InternetAddress.parse(cc, false));

			// -- Set the subject and body text --
			msg.setSubject(subject);
			msg.setText(body);

			// -- Set some other header information --
			msg.setHeader("", "");
			msg.setSentDate(new Date());

			// -- Send the message --
			Transport.send(msg);

			System.out.println("Message sent OK.");
			status = true;

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
}
