package com.fgl.ina.common;

/**
 * The bean for currency information from <code>currency_code</code> table
 * @author Jessica Wong
 */

public class CurrencyCode {
	private int currencyID =0;
	private String currencyCode = null;

	/**
	 * Gets the ID of this currency instance.
	 * @return this currency's ID.
	 */
	public int getCurrencyID() {
		return currencyID;
	}

	/**
	 * Sets the ID for this currency instance.
	 * @param currencyID the new id
	 */
	public void setCurrencyID(int currencyID) {
		this.currencyID = currencyID;
	}

	/**
	 * Gets the 3 letter Code of this currency instance.
	 * @return this currency's code.
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * Sets the Code for this currency instance.
	 * @param currencyCode the new code
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

}
