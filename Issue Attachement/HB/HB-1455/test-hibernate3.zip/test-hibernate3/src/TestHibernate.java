import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import test.TestObject;

/*
 * (c) Copyright 2004 BODET S.A. 
 * All Rights Reserved. 
 * 
 * $Log: $ 
 */

/** 
 * TODO Commentaire de la classe 
 *
 * Date de cr�ation : 25 f�vr. 2005 
 * Derni�re modif : $Date:$ par $Author:$ 
 * @author cesbrons 
 * @version $Revision: $ 
 */
public class TestHibernate
{
    public static void main(String[] args)
    {
        try
        {
            SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
            Session session = sessionFactory.openSession();
            Transaction tx = session.beginTransaction();
            TestObject test = new TestObject();
            test.setName("test");
            test.getMyBag().add("item1");
            session.save(test);
            tx.commit();
            session.close();

            session = sessionFactory.openSession();
            tx = session.beginTransaction();
            test = (TestObject) session.get(TestObject.class, new Integer(1));
            test.getMyBag().add("item2");
            test.getMyBag().remove("item1");
            tx.commit();
            session.close();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
