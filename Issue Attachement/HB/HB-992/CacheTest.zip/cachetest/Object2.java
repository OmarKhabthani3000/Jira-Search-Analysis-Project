package cachetest;

/**
 * an Object referenced by MainObject
 * 
 * @author voelkl
 * 
 * @hibernate.class
 * 		table="object2"
 * 
 * @hibernate.cache
 * 		usage="read-write" 
 */
public class Object2 {
	private Long id;
	private String dummy;
	private MainObject belongsToMainObj;

	/**
	 * @return
	 * 
	 * @hibernate.id
	 * 		generator-class="foreign"
	 * 		column="id"
	 * @hibernate.generator-param
	 *		name="property"
	 *		value="belongsToMainObj" 
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 
	 * @param l
	 */
	public void setId(Long l) {
		this.id = l;
	}
	
	/**
	 * @return
	 * 
	 * @hibernate.property
	 */
	public String getDummy() {
		return dummy;
	}

	/**
	 * @param string
	 */
	public void setDummy(String string) {
		dummy = string;
	}

	/**
	 * @return
	 * 
	 * @hibernate.one-to-one
	 * 		constrained="true"
	 */
	public MainObject getBelongsToMainObj() {
		return belongsToMainObj;
	}

	/**
	 * @param object
	 */
	public void setBelongsToMainObj(MainObject object) {
		belongsToMainObj = object;
	}

}
