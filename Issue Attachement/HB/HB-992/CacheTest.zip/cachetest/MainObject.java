
package cachetest;

/**
 * @author voelkl
 * 
 * @hibernate.class
 * 		table="mainobject"
 * 
 * @hibernate.cache
 * 		usage="read-write" 
 *
 */
public class MainObject {
	private Long id;
	private String description;
	private Object2 obj2;

	/**
	 * @return
	 * 
	 * @hibernate.id
	 * 	generator-class="native"
	 * 	column="id"
	 * @hibernate.generator-param
	 *	name="sequence"
	 *	value="seq_mainobj" 
	 */
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return
	 * 
	 * @hibernate.one-to-one
	 * 		cascade="all"
	 */
	public Object2 getObj2() {
		return obj2;
	}

	/**
	 * @return
	 * 
	 * @hibernate.property
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param string
	 */
	public void setDescription(String string) {
		description = string;
	}

	/**
	 * @param object2
	 */
	public void setObj2(Object2 object2) {
		this.obj2 = object2;
		if (object2 != null) {
			object2.setBelongsToMainObj(this);
		}
	}

}
