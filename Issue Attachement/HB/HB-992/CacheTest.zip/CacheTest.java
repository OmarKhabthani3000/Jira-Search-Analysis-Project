import java.io.Serializable;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;
import cachetest.MainObject;
import cachetest.Object2;

/**
 * Simple testcase to illustrate the cache-problem
 * with one-to-one relations
 * 
 * @author voelkl
 */
public class CacheTest {
	//milliseconds to wait between each try
	public static final long WAIT = 10000;
	
	private static SessionFactory factory;
	private Serializable generatedId;

	public static void main(String[] args) {
		CacheTest myCac = new CacheTest();
		Long obj2Id;
		long timeWaited = 0;

		try {
			//create the session-factory
			Configuration cfg =
				new Configuration().addClass(MainObject.class).addClass(
					Object2.class);
			factory = cfg.buildSessionFactory();

			//create a new MainObject
			myCac.createMainObject();
			System.out.println("\nNewly generated:");
			myCac.readMainObject();

			//create and add Ojbect2
			myCac.addObject2();
			System.out.println("\nObject2 added ?:");

			//here the newly created Object2 is written to the database
			//but the MainObject does not know it yet
			obj2Id = myCac.readMainObject();

//			while (obj2Id == null){
//				//wait shortly -> no effect (only after ~120sec)
//				try {
//					Thread.sleep(WAIT);
//				} catch (InterruptedException e1) {
//					e1.printStackTrace();
//				}
//				obj2Id = myCac.readMainObject();
//				timeWaited += WAIT;
//				
//				System.out.println("time(sec): " + timeWaited/1000 + " obj2-id: " + obj2Id + "\n");
//			}

			//evict cache -> this works !
			System.out.println("\nEvicting cache !");
			factory.evict(MainObject.class);

			//second try to read the object2
			System.out.println("\nObject2 added ? (2. Try):");
			myCac.readMainObject();

			//delete object2
//			myCac.deleteObject2();
//			System.out.println("\nObject2 deleted:");
//			myCac.readMainObject();
			
		} catch (HibernateException e) {
			System.out.println("trouble mit Hibernate");
			e.printStackTrace();
		}
	}

	/**
	 * creates a new MainObject
	 * 
	 * one hibernate transaction !
	 */
	private void createMainObject() throws HibernateException {
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();

		MainObject mo = new MainObject();
		mo.setDescription("Main Test");

		generatedId = session.save(mo);

		tx.commit();
		session.close();
	}

	/**
	 * loads the newly created MainObject
	 * and adds a new Object2 to it
	 * 
	 * one hibernate transaction
	 */
	private void addObject2() throws HibernateException {
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();

		MainObject mo =
			(MainObject) session.load(MainObject.class, generatedId);

		Object2 toAdd = new Object2();
		toAdd.setDummy("test");

		//toAdd should now be saved by cascade
		mo.setObj2(toAdd);

		tx.commit();
		session.close();
	}

	/**
	 * reads the newly created MainObject 
	 * and its Object2 if it exists
	 * 
	 * one hibernate transaction
	 */
	private Long readMainObject() throws HibernateException {
		Long returnId = null;
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();

		Serializable id = generatedId;

		MainObject mo = (MainObject) session.load(MainObject.class, id);
		Object2 added = mo.getObj2();
		
		if(added != null){
			returnId = added.getId();
		}

		System.out.println("read MainObject:");
		System.out.println(
			"ID: " + mo.getId() + " descr.: " + mo.getDescription());
		if (added == null) {
			System.out.println("\tObject2: null");
		} else {
			System.out.println("\tObject2: " + added.getId());
			System.out.println("\tObj2 dumy: " + added.getDummy());
		}

		tx.commit();
		session.close();
		
		return returnId;
	}

	private void deleteObject2() throws HibernateException {
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();

		Serializable id = generatedId;

		MainObject mo = (MainObject) session.load(MainObject.class, id);
		mo.setObj2(null);

		tx.commit();
		session.close();
	}
	
	private void readObject2() throws HibernateException{
		Long moId = null;
		
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		
		Object2 obj2 = (Object2) session.load(Object2.class, generatedId);
		MainObject mo = obj2.getBelongsToMainObj();
		if (mo != null){
			moId = mo.getId();
		}
		
		System.out.println("\nobj2: " + obj2.getId() + " belongsTo: " + moId + "\n");
	}
}
