package jdo;

import java.util.Date;

/**
 * A simple test class to test for generation of Castor's mapping.xml.
 *
 * @castor:class id="id"
 *               table="TBL_CSRZ"
 *               key-generator="IDENTITY"
 *               auto-complete="false"
 *
 * @version $Revision: 1.2 $
 * @author Shining (nshi@163.com)
 */
public class CSRZ
{
    private int id;

	private int kjnd_bh;

	private String dw_bzdm;

	private String zt_bm;

	private Date kssj;

	private Date jssj;

	private String tbzt;

	private String bz;

    /**
     * @castor:field get-method="getID" set-method="setID"
     * @castor:field-sql name="CSRZ_ID" type="integer"
     * @castor:field-xml
     */
    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    /**
     * @castor:field get-method="getKJND" set-method="setKJND" 
     * @castor:field-sql name="CSRZ_KJND_BH" type="integer"
     * @castor:field-xml
	 */
    public int getKjnd_bh()
    {
        return kjnd_bh;
    }

	public void setKjnd_bh(int kjnd_bh)
	{
		this.kjnd_bh = kjnd_bh;
	}

    /**
     * @castor:field type="string"  get-method="getDWBZDM" set-method="setDWBZDM" 
     * @castor:field-sql name="CSRZ_DW_BZDM" type="char"
     * @castor:field-xml
     */
	public String getDw_bzdm()
	{
		return dw_bzdm;
	}

	public void setDw_bzdm(String dw_bzdm)
	{
		this.dw_bzdm = dw_bzdm;
	}

    /**
     * @castor:field type="string" get-method="getZTBM" set-method="setZTBM" 
     * @castor:field-sql name="CSRZ_ZT_BM" type="char"
     * @castor:field-xml
     */
	public String getZt_bm()
	{
		return zt_bm;
	}

	public void setZt_bm(String zt_bm)
	{
		this.zt_bm = zt_bm;
	}

    /**
     * @castor:field type="date" get-method="getKSSJ" set-method="setKSSJ" 
     * @castor:field-sql name="CSRZ_KSSJ" type="char"
     * @castor:field-xml
     */
	public Date getKssj()
	{
		return kssj;
	}

	public void setKssj(Date kssj)
	{
		this.kssj = kssj;
	}

    /**
     * @castor:field type="date"  get-method="getJSSJ" set-method="setJSSJ" 
     * @castor:field-sql name="CSRZ_JSSJ" type="date"
     * @castor:field-xml
     */
	public Date getJssj()
	{
		return jssj;
	}

	public void setJssj(Date jssj)
	{
		this.jssj = jssj;
	}

    /**
     * @castor:field type="string"  get-method="getTBZT" set-method="setTBZT" 
     * @castor:field-sql name="CSRZ_TBZT" type="char"
     * @castor:field-xml
     */
	public String getTbzt()
	{
		return tbzt;
	}

	public void setTbzt(String tbzt)
	{
		this.tbzt = tbzt;
	}

    /**
     * @castor:field type="string"  get-method="getBZ" set-method="setBZ" 
     * @castor:field-sql name="CSRZ_BZ" type="char"
     * @castor:field-xml
     */
	public String getBz()
	{
		return bz;
	}

	public void setBz(String bz)
	{
		this.bz = bz;
	}
}