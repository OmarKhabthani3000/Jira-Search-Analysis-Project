/*
 * Created on 2003-7-12
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package jdo;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class FLYS {
	private String bm;
	

	/**
	 * @return
	 */
	public String getBm() {
		return bm;
	}

	/**
	 * @param string
	 */
	public void setBm(String string) {
		bm = string;
	}

}
