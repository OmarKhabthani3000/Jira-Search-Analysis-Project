/*
 * Created on 2003-6-26
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package jdo;

/**
 *
 * @castor:class id="bzdm"
 *               table="TBL_DEPARTMENT_DW"
 *               auto-complete="false"
 *
 * @version $Revision: 1.2 $
 * @author XRS (nbxrs@163.com)
 */
public class DepartmentDW {
	private String bzdm;
	private Department department;
	
	/**
	 * @castor:field type="string" get-method="getBzdm" set-method="setBzdm"
	 * @castor:field-sql name="DEPTDW_BZDM" type="char"
	 * @castor:field-xml
	 */		
	public String getBzdm() {
		return bzdm;
	}
	
	public void setBzdm(String bzdm) {
		this.bzdm = bzdm;
	}
	/**
	 * @castor:field type="com.fims.jdo.Department"
	 * @castor:field-sql name="DEPARTMENT_CODE"
	 * @castor:field-xml
	 */	
	public Department getDepartment() {
		return department;
	}
	
	public void setDepartment(Department department) {
		this.department = department;
	}
}
