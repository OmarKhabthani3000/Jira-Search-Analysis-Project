/*
 * Created on 2003-7-9
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package jdo;

import java.sql.SQLException;
import java.util.Date;
import java.util.Iterator;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class Test {

	private SessionFactory sessions;
	private Configuration ds;
	
	public Test() {
			
	}
	
	public static void main(String[] args) {
		Test test = new Test();
		//test.runCSRZ();
		test.runNCS();
	}
	
	public void runCSRZ() {
		try {
			// configure the Configuration
			ds  = new Configuration().addClass(jdo.CSRZ.class);

			// build a SessionFactory
			sessions = ds.buildSessionFactory();
			
			Session sess = sessions.openSession();
			
			CSRZ csrz = null;
			
			csrz = new CSRZ();
			csrz.setKjnd_bh(2002);
			csrz.setDw_bzdm("0001");
			csrz.setZt_bm("01");
			csrz.setKssj(new Date());
			csrz.setJssj(new Date());
			csrz.setTbzt("�ɹ�");
			csrz.setBz("I love this game");
			
			sess.save(csrz);
			sess.flush();
			sess.connection().commit();
			sess.close();
						
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void runNCS() {
		try {
			// configure the Configuration
			ds  = new Configuration()
					.addClass(jdo.NCS.class)
					.addClass(jdo.NCSHB.class);

			// build a SessionFactory
			sessions = ds.buildSessionFactory();

			Session sess = sessions.openSession();
			
			NCS ncs = null;

			Iterator iter = sess.iterate("FROM NCS ncs");
			while (iter.hasNext()) {
				ncs = (NCS) iter.next();
				sess.delete(ncs);
			}
			
			/*ncs = new NCS();
			ncs.setDw_bzdm("0001");
			ncs.setZt_bm("01");
			ncs.setFlys_bm("[][][][][][][][]");
			ncs.setYefx(1);
			ncs.setYE(1000.00);
			
			NCSHB ncshb = null;
			ncshb = new NCSHB();
			ncshb.setNcs(ncs);
			ncshb.setHb_dm("RMB");
			ncshb.setYe(1000.00);
			ncs.addHb(ncshb);
			
			sess.save(ncs);
			
			ncs = new NCS();
			ncs.setDw_bzdm("0002");
			ncs.setZt_bm("01");
			ncs.setFlys_bm("[01][][][][][][][]");
			ncs.setYefx(1);
			ncs.setYE(900.00);
			
			ncshb = new NCSHB();
			ncshb.setNcs(ncs);
			ncshb.setHb_dm("RMB");
			ncshb.setYe(900.00);
			ncs.addHb(ncshb);

			ncshb = new NCSHB();
			ncshb.setNcs(ncs);
			ncshb.setHb_dm("USD");
			ncshb.setYe(100.00);
			ncs.addHb(ncshb);

			sess.save(ncs);
			
			sess.delete(ncs);
			
			sess.flush();*/
			sess.connection().commit();
			sess.close();
						
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
