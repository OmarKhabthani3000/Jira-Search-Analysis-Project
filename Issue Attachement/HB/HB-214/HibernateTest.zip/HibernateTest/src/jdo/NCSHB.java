/*
 * Created on 2003-7-10
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package jdo;

import java.io.Serializable;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class NCSHB implements Serializable {
	private NCS ncs;
	private String hb_dm;
	private double ye;
	/**
	 * @return
	 */
	public String getHb_dm() {
		return hb_dm;
	}

	/**
	 * @return
	 */
	public double getYe() {
		return ye;
	}

	/**
	 * @return
	 */
	public NCS getNcs() {
		return ncs;
	}

	/**
	 * @param string
	 */
	public void setHb_dm(String string) {
		hb_dm = string;
	}

	/**
	 * @param d
	 */
	public void setYe(double d) {
		ye = d;
	}

	/**
	 * @param ncs
	 */
	public void setNcs(NCS ncs) {
		this.ncs = ncs;
	}

}
