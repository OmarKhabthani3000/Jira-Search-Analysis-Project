/*
 * Created on 2003-7-10
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package jdo;

import java.io.Serializable;
import java.util.Set;
import java.util.HashSet;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class NCS implements Serializable {
	private String dw_bzdm;
	private String zt_bm;
	private String flys_bm;
	private FLYS flys;
	private int yefx;
	private double ye;
	private Set hbs;
	
	/**
	 * @return
	 */
	public String getDw_bzdm() {
		return dw_bzdm;
	}

	/**
	 * @return
	 */
	public String getFlys_bm() {
		return flys_bm;
	}

	/**
	 * @return
	 */
	public double getYE() {
		return ye;
	}

	/**
	 * @return
	 */
	public int getYefx() {
		return yefx;
	}

	/**
	 * @return
	 */
	public String getZt_bm() {
		return zt_bm;
	}

	/**
	 * @param string
	 */
	public void setDw_bzdm(String string) {
		dw_bzdm = string;
	}

	/**
	 * @param string
	 */
	public void setFlys_bm(String string) {
		flys_bm = string;
	}

	/**
	 * @param d
	 */
	public void setYE(double d) {
		ye = d;
	}

	/**
	 * @param string
	 */
	public void setYefx(int i) {
		yefx = i;
	}

	/**
	 * @param string
	 */
	public void setZt_bm(String string) {
		zt_bm = string;
	}

	public Set getHbs() {
		 return hbs;
	}
	 
	void setHbs(Set hbs) {
		this.hbs = hbs;
	}
	
	void addHb(NCSHB ncshb)
	{
		if (hbs == null)
			hbs = new HashSet();
		hbs.add(ncshb);
	}
	/**
	 * @return
	 */
	public FLYS getFlys() {
		return flys;
	}

	/**
	 * @param flys
	 */
	public void setFlys(FLYS flys) {
		this.flys = flys;
	}

}
