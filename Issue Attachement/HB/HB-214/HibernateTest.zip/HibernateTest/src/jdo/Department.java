/*
 * Created on 2003-6-26
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package jdo;

import java.util.Vector;

/**
 *
 * @castor:class id="code"
 *               table="TBL_DEPARTMENT"
 *               auto-complete="false"
 *
 * @version $Revision: 1.2 $
 * @author XRS (nbxrs@163.com)
 */
public class Department {
	private String code;
	private String name;
	
	private Vector dws = new Vector();

	/**
	 * @castor:field type="string" get-method="getCode" set-method="setCode"
	 * @castor:field-sql name="DEPARTMENT_CODE" type="char"
	 * @castor:field-xml
	 */
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @castor:field type="string" get-method="getName" set-method="setName"
	 * @castor:field-sql name="DEPARTMENT_NAME" type="char"
	 * @castor:field-xml
	 */
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @castor:field type="com.fims.jdo.DepartmentDW" collection="vector" required="true"
	 * @castor:field-sql many-key="DEPARTMENT_CODE"
	 * @castor:field-xml
	 */
	
	public DepartmentDW createDw()
	{
		return new DepartmentDW();
	}
		
	public Vector getDws() {
		return dws; 
	}
	
	public void addDw(DepartmentDW dw) {
		dws.add(dw);
		dw.setDepartment(this);			
	}
	
	public String toString() {
		return code + "  " + name;
	}
}
