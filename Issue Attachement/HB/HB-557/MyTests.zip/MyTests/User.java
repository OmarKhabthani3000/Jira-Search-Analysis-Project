/*
 * Copyright (c) 2003 SSI Schaefer Noell GmbH
 *
 * $Header: /home/cvs/data1/InternalProjects/acx/Implementation/src/java/test/com/ssn/acx/api/persistence/collections/User.java,v 1.2 2003/12/05 14:44:17 cpruente Exp $
 *
 * Change History
 *   $Log: User.java,v $
 *   Revision 1.2  2003/12/05 14:44:17  cpruente
 *   second example for user/group/permission
 *
 */
import java.util.*;
import java.util.Set;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * Test class for persistence unit tests
 *
 * @author <a href="mailto:pruente@ssi-schaefer-noell.com">pruente</a>
 * @version $Revision: 1.2 $, $Date: 2003/12/05 14:44:17 $, $Author: cpruente $
 */
public class User extends Actor {

  /** nullable persistent field */
  private String firstname;

  /** persistent field */
  private Set groups = new HashSet();

  /** a copy of the set for better access */
  private Map mgroups = null;

  /** full constructor */
  public User(java.lang.String name, java.lang.String firstname, Set groups, Set permissions) {
    super(name, permissions);
    this.firstname = firstname;
    if( groups != null) {
      this.groups = groups;
    }
    copyGroups();
  }

  public User addGroup(Group group) {
    groups.add(group);
    mgroups.put(group.getName(), group);
    return this;
  }
  
  public User removeGroup(Group group) {
    groups.remove(group);
    return this;
  }
  /**
   * Copies the groups into a map for access by name. 
   */
  private void copyGroups() {
    if (mgroups == null) {
      mgroups = new HashMap();
      for (Iterator iter = groups.iterator(); iter.hasNext();) {
        Group g = (Group) iter.next();
        mgroups.put(g.getName(), g);
      }
    }
  }

  /** default constructor */
  public User() {
  }

  public java.lang.String getFirstname() {
    return this.firstname;
  }

  public void setFirstname(java.lang.String firstname) {
    this.firstname = firstname;
  }

  public java.util.Set getGroups() {
    return this.groups;
  }

  public void setGroups(java.util.Set groups) {
    this.groups = groups;
  }

  public String toString() {
    return new ToStringBuilder(this).append("id", getId()).toString();
  }

  /**
   * @return
   */
  public Map getMgroups() {
    copyGroups();
    return mgroups;
  }

}
