/*
 * Copyright (c) 2003 SSI Schaefer Noell GmbH
 *
 * $Header: /home/cvs/data1/InternalProjects/acx/Implementation/src/java/test/com/ssn/acx/api/persistence/collections/Actor.java,v 1.2 2003/12/05 14:58:43 cpruente Exp $
 *
 * Change History
 *   $Log: Actor.java,v $
 *   Revision 1.2  2003/12/05 14:58:43  cpruente
 *   header corrected
 *
 */
import java.io.Serializable;
import java.util.*;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * Test class for persistence unit tests
 *
 * @author <a href="mailto:pruente@ssi-schaefer-noell.com">pruente</a>
 * @version $Revision: 1.2 $, $Date: 2003/12/05 14:58:43 $, $Author: cpruente $
 */
public class Actor implements Serializable {

  /** identifier field */
  private Long id;

  /** persistent field */
  private String name;

  /** persistent field */
  private Set permissions = new HashSet();

  /** full constructor */
  public Actor(java.lang.String name, Set permissions) {
    this.name = name;
    if(permissions != null) {
      this.permissions = permissions;
    }
  }
  
  public Actor addPermission(Permission permission) {
    permissions.add(permission);
    return this;
  }

  /** default constructor */
  public Actor() {
  }

  public java.lang.Long getId() {
    return this.id;
  }

  public void setId(java.lang.Long id) {
    this.id = id;
  }

  public java.lang.String getName() {
    return this.name;
  }

  public void setName(java.lang.String name) {
    this.name = name;
  }

  public java.util.Set getPermissions() {
    return this.permissions;
  }

  public void setPermissions(java.util.Set permissions) {
    this.permissions = permissions;
  }

  public String toString() {
    return new ToStringBuilder(this).append("id", getId()).toString();
  }

  public boolean equals(Object other) {
    if (!(other instanceof Actor))
      return false;
    Actor castOther = (Actor) other;
    return new EqualsBuilder().append(this.getId(), castOther.getId()).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder().append(getId()).toHashCode();
  }

}
