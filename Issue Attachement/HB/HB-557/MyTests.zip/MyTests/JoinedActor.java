
import java.util.List;

import org.apache.log4j.Logger;

import net.sf.hibernate.*;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.tool.hbm2ddl.SchemaExport;

/**
 * Standard operations
 *
 * @author <a href="mailto:pruente@ssi-schaefer-noell.com">pruente</a>
 * @version $Revision: 1.5 $, $Date: 2003/12/15 10:44:25 $, $Author: cpruente $
 */

public class JoinedActor {
  //static public Logger logger = Logger.getLogger(JoinedActor.class);

  /** The class unique name */
  private final static String cuName = "jat";

  public void testSearchUser(SessionFactory factory) throws Exception {
    Permission read = new Permission(JoinedActor.cuName + "IPUGread", "permission for reading");
    Permission write = new Permission(JoinedActor.cuName + "IPUGwrite", "permission for writing");

    User u1 = new User(JoinedActor.cuName + "IPUGfirstUser", "firstName", null, null);
    u1.addPermission(read).addPermission(write);

    User u2 = new User(JoinedActor.cuName + "IPUGsecondUser", "firstName2", null, null);
    u2.addPermission(read).addPermission(read);

    Group g = new Group("firstGroup", "this is the first group", null, null);
    g.addPermission(read);
    u1.addGroup(g);

    Session session = factory.openSession();
    Transaction ta = session.beginTransaction();
    session.save(read);
    session.save(write);
    session.save(g);
    session.save(u1);
    session.save(u2);
    ta.commit();

    session = factory.openSession();

    Query q = session.getNamedQuery("User.by.firstName");
    q.setString("firstName", u2.getFirstname());
    List result = q.list();

    System.out.println("Expected a single element:" + result.size());
  }
  
  /**
   * Creates the schema from the current configDocument.
   * @throws PersistenceOpenSessionException
   */
  public void createSchemaObjects(Configuration configuration) throws Exception {
    boolean script = true;
    boolean export = true;
    String outFile = null;

    try {
      new SchemaExport(configuration).setOutputFile(outFile).setDelimiter(null).create(script, export);
    } catch (HibernateException e) {
      System.err.println("Problems during creating schema with Hibernate!");
      throw e;
    }

  }

  public static void main(String[] args) throws Exception {
    //JoinedActor.logger.debug("hello Hibernate");
    JoinedActor ja = new JoinedActor();

    Configuration configuration = new Configuration();

    try {
      configuration.addFile("CollectionJoinedActor.hbm.xml");
      ja.createSchemaObjects(configuration);
      SessionFactory sessionFactory = configuration.buildSessionFactory();
      ja.testSearchUser(sessionFactory);
    } catch (HibernateException e) {
      System.err.println("Problems during configuring Hibernate!");
      System.err.println(e);
      throw e;
    } catch (Exception e) {
      System.err.println("Problems:");
      System.err.println(e);
      throw e;
    }
  }
}
