/*
 * Copyright (c) 2003 SSI Schaefer Noell GmbH
 *
 * $Header: /home/cvs/data1/InternalProjects/acx/Implementation/src/java/test/com/ssn/acx/api/persistence/collections/Permission.java,v 1.2 2003/12/05 14:58:43 cpruente Exp $
 *
 * Change History
 *   $Log: Permission.java,v $
 *   Revision 1.2  2003/12/05 14:58:43  cpruente
 *   header corrected
 *
 */
import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * Test class for persistence unit tests
 *
 * @author <a href="mailto:pruente@ssi-schaefer-noell.com">pruente</a>
 * @version $Revision: 1.2 $, $Date: 2003/12/05 14:58:43 $, $Author: cpruente $
 */
public class Permission implements Serializable {

    /** identifier field */
    private Long id;

    /** persistent field */
    private String name;

    /** nullable persistent field */
    private String description;

    /** full constructor */
    public Permission(java.lang.String name, java.lang.String description) {
        this.name = name;
        this.description = description;
    }

    /** default constructor */
    public Permission() {
    }

    /** minimal constructor */
    public Permission(java.lang.String name) {
        this.name = name;
    }

    public java.lang.Long getId() {
        return this.id;
    }

    public void setId(java.lang.Long id) {
        this.id = id;
    }

    public java.lang.String getName() {
        return this.name;
    }

    public void setName(java.lang.String name) {
        this.name = name;
    }

    public java.lang.String getDescription() {
        return this.description;
    }

    public void setDescription(java.lang.String description) {
        this.description = description;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof Permission) ) return false;
        Permission castOther = (Permission) other;
        return new EqualsBuilder()
            .append(this.getId(), castOther.getId()).append(this.getName(), castOther.getName())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getId()).append(getName())
            .toHashCode();
    }

}
