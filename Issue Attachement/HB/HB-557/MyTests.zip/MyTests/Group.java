/*
 * Copyright (c) 2003 SSI Schaefer Noell GmbH
 *
 * $Header: /home/cvs/data1/InternalProjects/acx/Implementation/src/java/test/com/ssn/acx/api/persistence/collections/Group.java,v 1.3 2003/12/05 14:58:43 cpruente Exp $
 *
 * Change History
 *   $Log: Group.java,v $
 *   Revision 1.3  2003/12/05 14:58:43  cpruente
 *   header corrected
 *
 */
import java.io.Serializable;
import java.util.*;
import java.util.Set;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * Test class for persistence unit tests
 *
 * @author <a href="mailto:pruente@ssi-schaefer-noell.com">pruente</a>
 * @version $Revision: 1.3 $, $Date: 2003/12/05 14:58:43 $, $Author: cpruente $
 */
public class Group extends Actor implements Serializable {

  /** nullable persistent field */
  private String description;

  /** persistent field */
  private Set users = new HashSet();

  /** full constructor */
  public Group(java.lang.String name, java.lang.String description, Set users, Set permissions) {
    super(name, permissions);
    this.description = description;
    if(users != null) {
      this.users = users;
    }
  }

  /** default constructor */
  public Group() {
  }

  public Group addUser(User user) {
    users.add(user);
    return this;
  }

  public java.lang.String getDescription() {
    return this.description;
  }

  public void setDescription(java.lang.String description) {
    this.description = description;
  }

  public java.util.Set getUsers() {
    return this.users;
  }

  public void setUsers(java.util.Set users) {
    this.users = users;
  }

  public String toString() {
    return new ToStringBuilder(this).append("id", getId()).toString();
  }

}
