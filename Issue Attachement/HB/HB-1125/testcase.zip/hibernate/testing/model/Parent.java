/******************************************************************************
 *
 *                 Columbia University, School Of Law (CLS)
 *
 *                            PROPRIETARY DATA
 *
 *      THIS DOCUMENT CONTAINS TRADE SECRET DATA WHICH IS THE PROPERTY OF
 *      CLS.  THIS DOCUMENT IS SUBMITTED TO RECIPIENT IN CONFIDENCE.
 *      INFORMATION CONTAINED HEREIN MAY NOT BE USED, COPIED OR
 *      DISCLOSED IN WHOLE OR IN PART EXCEPT AS PERMITTED BY WRITTEN AGREEMENT
 *      SIGNED BY AN OFFICER OF IT AT CLS
 *
 *      THIS MATERIAL IS ALSO COPYRIGHTED AS AN UNPUBLISHED WORK UNDER
 *      SECTIONS 104 AND 408 OF TITLE 17 OF THE UNITED STATES CODE.
 *      UNAUTHORIZED USE, COPYING OR OTHER REPRODUCTION IS PROHIBITED BY LAW.
 *
 ******************************************************************************/
package hibernate.testing.model;

import hibernate.testing.HibernateSessionFactoryHolder;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import net.sf.hibernate.LockMode;
import net.sf.hibernate.Session;

/**
 * TODO - Desc.
 *
 * @author <a href="mailto:alex@law.columbia.edu">Alex Shneyderman</a>
 * @since  $Date$
 * @version $Revision$
 * <pre>
 * $Log$ </pre>
 */
public class Parent {

    protected Long id;
    
    protected String name;
    protected Set children = new HashSet ();
    protected Long version;

    public Set getChildren () {
        return children;
    }
    public void setChildren (Set children) {
        this.children = children;
    }
    public Long getId () {
        return id;
    }
    public void setId (Long id) {
        this.id = id;
    }
    public String getName () {
        return name;
    }
    public void setName (String name) {
        this.name = name;
    }
    
    public void addChild (Child c) throws Exception {
        if (this.getId () == null) {
            c.setParent (this);
            getChildren ().add (c);
            return;
        }
        
        Session s = HibernateSessionFactoryHolder.getSessionFactory ().openSession ();
        try {
            s.lock (this, LockMode.READ); // will throw exception if versions do not match
            
            if (getChildren ().size () >= 4) {
                throw new RuntimeException ("Too many kids.");
            }
            
            c.setParent (this);
            getChildren ().add (c);
            
            s.saveOrUpdate (this);
            s.flush ();
        } finally {
            try { s.close (); } catch (Throwable t) {}
        }
    }
    
    public Set listChildren () throws Exception {
        if (this.getId () == null) {
            return Collections.unmodifiableSet (getChildren ());
        } else {
            Session s = HibernateSessionFactoryHolder.getSessionFactory ().openSession ();
            try {
                s.lock (this, LockMode.READ); 
                return Collections.unmodifiableSet (getChildren ());
            } finally {
                try { s.close (); } catch (Throwable t) {}
            }
        }
    }
    
    public void removeChild (Child c) throws Exception {
        if (this.getId () == null) {
            this.getChildren().remove (c);
        } else {
            Session s = HibernateSessionFactoryHolder.getSessionFactory ().openSession ();
            try {
                s.lock (this, LockMode.READ); // will throw exception if versions do not match
                
                if (getChildren ().remove (c)) { // this assumes cascades are on
                    s.saveOrUpdate (this);
                    s.flush ();
                }
                
            } finally {
                try { s.close (); } catch (Throwable t) {}
            }
        }
    }
    
    

}
