/******************************************************************************
 *
 *                 Columbia University, School Of Law (CLS)
 *
 *                            PROPRIETARY DATA
 *
 *      THIS DOCUMENT CONTAINS TRADE SECRET DATA WHICH IS THE PROPERTY OF
 *      CLS.  THIS DOCUMENT IS SUBMITTED TO RECIPIENT IN CONFIDENCE.
 *      INFORMATION CONTAINED HEREIN MAY NOT BE USED, COPIED OR
 *      DISCLOSED IN WHOLE OR IN PART EXCEPT AS PERMITTED BY WRITTEN AGREEMENT
 *      SIGNED BY AN OFFICER OF IT AT CLS
 *
 *      THIS MATERIAL IS ALSO COPYRIGHTED AS AN UNPUBLISHED WORK UNDER
 *      SECTIONS 104 AND 408 OF TITLE 17 OF THE UNITED STATES CODE.
 *      UNAUTHORIZED USE, COPYING OR OTHER REPRODUCTION IS PROHIBITED BY LAW.
 *
 ******************************************************************************/
package hibernate.testing.model;

/**
 * TODO - Desc.
 *
 * @author <a href="mailto:alex@law.columbia.edu">Alex Shneyderman</a>
 * @since  $Date$
 * @version $Revision$
 * <pre>
 * $Log$ </pre>
 */
public class Child {

    protected Long id;
    protected Parent parent;
    protected String name;
    protected Long version;
    
    public Long getId () {
        return id;
    }
    public void setId (Long id) {
        this.id = id;
    }
    public String getName () {
        return name;
    }
    public void setName (String name) {
        this.name = name;
    }
    public Parent getParent () {
        return parent;
    }
    public void setParent (Parent parent) {
        this.parent = parent;
    }
    
}
