package hibernate.testing;

import hibernate.testing.model.Child;
import hibernate.testing.model.Parent;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import junit.framework.TestCase;
import net.sf.hibernate.LockMode;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.StaleObjectStateException;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;

public class LockModeTestCase extends TestCase {
    
    SessionFactory sf;
    Parent p;
    
    protected void setUp () throws Exception {

        // create session factory
        try {
            
            sf = new Configuration()
                      .configure ("/hibernate.cfg.xml")
                      .buildSessionFactory ();

        } catch (Exception e) {
            e.printStackTrace ();
            throw e;
        }
        
        // create some fixtures here
        Session s = null;
        try {
            s = sf.openSession ();
            p = new Parent ();
            p.setName ("test parent");
            Set children = new HashSet (); 
            for (int i = 0; i < 2; i++) {
                Child c = new Child (); c.setName ("child " + String.valueOf (i+1)); c.setParent (p);
                children.add (c);
            }
            p.setChildren (children);
            s.saveOrUpdate (p);
            s.flush ();
        } catch (Exception e) {
            e.printStackTrace ();
            throw e;
        } finally {
            s.close ();
        } 
        
    }
    
    public void testFailingTest () throws Exception {
        Session s0 = sf.openSession ();
        Transaction ts0 = s0.beginTransaction ();
        try {
            Parent p0 = (Parent) s0.load (Parent.class, p.getId ());
            for (Iterator iter = p0.getChildren ().iterator (); iter.hasNext ();) {
                Child element = (Child) iter.next ();
                element.setName ("Updated name");
                break;
            }
        } finally {
            ts0.commit ();
            s0.close ();
        }

        Session s1 = sf.openSession ();
        Transaction ts1 = s1.beginTransaction ();
        boolean bShallCommit = true;
        try {
            try {
                s1.lock (p, LockMode.READ);
            } catch (StaleObjectStateException sose) {
                bShallCommit = false;
                ts1.rollback ();
            }
        } finally  {
            if (bShallCommit) { ts1.commit (); }
        }

        Transaction ts11 = s1.beginTransaction ();
        bShallCommit = true;
        try{
            try {
                s1.lock (p, LockMode.READ);
                fail ("Object has to be stale still");
            } catch (StaleObjectStateException sose) {
                bShallCommit = false;
                try { ts11.rollback (); } catch (Throwable t) { t.printStackTrace (); }
            }
        } finally  {
            if (bShallCommit) {
                try { ts11.commit (); } catch (Throwable t) { t.printStackTrace (); }
            }
            try { s1.close (); } catch (Throwable t) { t.printStackTrace (); }
        }
    }
    
    public void testPassingTest () throws Exception {
    
            Session s0 = sf.openSession ();
            try {
                Parent p0 = (Parent) s0.load (Parent.class, p.getId ());
                p0.setName ("name update");
                s0.flush ();
            } finally {
                try { s0.close (); } catch (Throwable t) {}
            }
            
            Session s1 = sf.openSession ();
            try {
                try {
                    s1.lock (p, LockMode.READ);
                    fail ("Object has to be stale still");
                } catch (StaleObjectStateException sose) {
                    // this is correct
                }
            
                try {
                    s1.lock (p, LockMode.READ);
                    fail ("Object has to be stale still");
                } catch (StaleObjectStateException sose) {
                    // this is correct
                }
            } finally  {
                try { s1.close (); } catch (Throwable t) {}
            }
            
        }
    

}
