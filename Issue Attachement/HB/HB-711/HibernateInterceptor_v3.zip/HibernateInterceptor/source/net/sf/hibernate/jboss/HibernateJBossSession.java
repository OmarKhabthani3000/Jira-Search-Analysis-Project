package net.sf.hibernate.jboss;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.RollbackException;
import javax.transaction.Synchronization;
import javax.transaction.SystemException;
import javax.transaction.TransactionManager;

import org.jboss.logging.Logger;
import org.jboss.tm.TransactionLocal;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;

/**
 * Provides the Session opened by the HibernateInterceptor to the
 * EJBs wanting to access it. Implements the ThreadLocalSession pattern.
 * 
 * @author Michael Gloegl (gloegl@oktiron.net)
 */
public class HibernateJBossSession {
    
    private static ThreadLocal sessionLocal = new ThreadLocal();
    private static TransactionLocal transactionLocal = new TransactionLocal();
    private Session session;
    private static SessionFactory sessionFactory;
    private static String sessionScope;
    private static Logger log = Logger.getLogger(HibernateJBossSession.class);
    private static InitialContext context;
    
    /**
     * Called by HibernateInterceptor before continuing in the invocation
     * chain. Opens a new Session if none exists.
     */
    static boolean openSessionIfNotExists(String sessionFactoryJNDI, String sessionScope) throws HibernateException {
        Session session = getSession(sessionScope);
        boolean createNew = false;
        if (session == null) {
            log.debug("Opening new Hibernate Session");
            session = getSessionFactory(sessionFactoryJNDI).openSession();
            HibernateJBossSession.sessionScope = sessionScope;
            setSession(session, sessionScope);
            createNew = true;
        }
        return createNew;
    }
    
    private static Session getSession(String sessionScope) {
        if (sessionScope.equals("transaction")) {
            return (Session) transactionLocal.get();
        } else {
            return (Session) sessionLocal.get();
        }
    }
    
    private static void setSession(final Session hjs, String sessionScope) throws HibernateException {
        if (sessionScope.equals("transaction")) {
            try {
				if (context == null) {
					 context = new InitialContext();
				}
				TransactionManager tm = (TransactionManager) context.lookup("java:/TransactionManager");
				
				tm.getTransaction().registerSynchronization(new Synchronization() {

					public void beforeCompletion() {
					}

					public void afterCompletion(int arg0) {
						try {
							hjs.close();
						}
						catch (HibernateException e) {
							log.error("Could not close session on end of transaction", e);
						}
					}});
				
				transactionLocal.set(hjs);
			}
			catch (NamingException e) {
				throw new HibernateException(e);
			}
			catch (IllegalStateException e) {
				throw new HibernateException(e);
			}
			catch (RollbackException e) {
				throw new HibernateException(e);
			}
			catch (SystemException e) {
				throw new HibernateException(e);
			}
        } else {
            sessionLocal.set(hjs);
        }
    }
    
    /**
     * Use this to retrieve the Session opened by the HibernateInterceptor
     * when inside an EJB. Do not close the Session, this will be handled
     * by the Interceptor.
     * @return The Hibernate Session opened by the Interceptor 
     */
    public static Session getSession() throws HibernateException {
        Session session = getSession(sessionScope);
        if (session == null) {
            throw new RuntimeException("Interceptor did not initialize Session");
        }
        return session;
    }
    
    /**
     * Called by HibernateInterceptor after returning from the invocation
     * chain, when thread session scope is used. Closes the Session.
     */
    static void closeSession() throws HibernateException {
        Session session = getSession(sessionScope);
        log.debug("Closing Hibernate Session");
        session.close();
        setSession(null, sessionScope);
    }

    private static SessionFactory getSessionFactory(String sessionFactoryJNDI) {
        if (sessionFactory == null) {
            sessionFactory = lookupSessionFactory(sessionFactoryJNDI);
        }
        return sessionFactory;
    }

    private static SessionFactory lookupSessionFactory(String sessionFactoryJNDI) {
        try {
            InitialContext context = new InitialContext();
            return (SessionFactory) context.lookup(sessionFactoryJNDI);
        } catch (NamingException e) {
            throw new RuntimeException(e);
        }
    }
}
