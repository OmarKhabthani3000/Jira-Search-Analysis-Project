package net.sf.hibernate.jboss;

import org.jboss.ejb.plugins.AbstractInterceptor;
import org.jboss.invocation.Invocation;
import org.jboss.metadata.XmlLoadable;
import org.w3c.dom.Element;

/**
 * An Interceptor managing Hibernate Sessions. Opens a Session on the
 * first invocation and closes it after the invocation Stack is finished.
 * 
 * @author Michael Gloegl (gloegl@oktiron.net)
 */
public class HibernateInterceptor
    extends AbstractInterceptor
    implements XmlLoadable {

    private String sessionFactoryJNDI;
    private String sessionScope;

    public Object invoke(Invocation arg0) throws Exception {
        this.log.debug("Invoked Method: " + arg0.method);
        this.log.debug("right before invocation");
        boolean createdHere = HibernateJBossSession.openSessionIfNotExists(sessionFactoryJNDI, sessionScope);
        
        // Note: Won't we run into problems using this approach?
        
        this.log.debug("Created Here? " + createdHere);
        try {
            return super.invoke(arg0);
        } finally {
            this.log.debug("Hibernate Interceptor after invocation");
            if (createdHere && !this.sessionScope.equals("transaction")) {
                HibernateJBossSession.closeSession();
            }
        }
    }

    public void create() throws Exception {
        this.log.debug("Creating Hibernate Interceptor");
        super.create();
    }

    public void importXml(Element interceptorConfigElement) throws Exception {
        this.log.debug(
            "HibernateInterceptor will lookup Session Factory at JNDI name "
                + interceptorConfigElement.getAttribute("sessionFactoryJNDI"));
        this.sessionFactoryJNDI =
            interceptorConfigElement.getAttribute("sessionFactoryJNDI");        
        this.sessionScope =
            interceptorConfigElement.getAttribute("sessionScope");
    }

}
