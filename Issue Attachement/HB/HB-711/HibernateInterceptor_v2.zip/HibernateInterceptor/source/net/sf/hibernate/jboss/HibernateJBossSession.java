package net.sf.hibernate.jboss;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.jboss.logging.Logger;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;

/**
 * Provides the Session opened by the HibernateInterceptor to the
 * EJBs wanting to access it. Implements the ThreadLocalSession pattern.
 * 
 * @author Michael Gloegl (gloegl@oktiron.net)
 */
public class HibernateJBossSession {
    
    private static ThreadLocal sessionLocal = new ThreadLocal();
    private Session session;
    private static SessionFactory sessionFactory;
    private static Logger log = Logger.getLogger(HibernateJBossSession.class);
    
    /**
     * Called by HibernateInterceptor before continuing in the invocation
     * chain. Opens a new Session if none exists.
     */
    static boolean openSessionIfNotExists(String sessionFactoryJNDI) throws HibernateException {
        HibernateJBossSession hjs = (HibernateJBossSession) sessionLocal.get();
        boolean createNew = false;
        if (hjs == null) {
            hjs = new HibernateJBossSession();
            log.debug("Opening new Hibernate Session");
            hjs.session = getSessionFactory(sessionFactoryJNDI).openSession();
            sessionLocal.set(hjs);
            createNew = true;
        }
        return createNew;
    }
    
    /**
     * Use this to retrieve the Session opened by the HibernateInterceptor
     * when inside an EJB. Do not close the Session, this will be handled
     * by the Interceptor.
     * @return The Hibernate Session opened by the Interceptor 
     */
    public static Session getSession() throws HibernateException {
        HibernateJBossSession session = (HibernateJBossSession) sessionLocal.get();
        if (session == null) {
            throw new RuntimeException("Interceptor did not initialize Session");
        }
        return session.session;
    }
    
    /**
     * Called by HibernateInterceptor after returning from the invocation
     * chain. Closes the Session if the interceptor is the first one in
     * the chain.
     */
    static void closeSession() throws HibernateException {
        HibernateJBossSession session = (HibernateJBossSession) sessionLocal.get();
        log.debug("Closing Hibernate Session");
        session.session.close();
    }

    private static SessionFactory getSessionFactory(String sessionFactoryJNDI) {
        if (sessionFactory == null) {
            sessionFactory = lookupSessionFactory(sessionFactoryJNDI);
        }
        return sessionFactory;
    }

    private static SessionFactory lookupSessionFactory(String sessionFactoryJNDI) {
        try {
            InitialContext context = new InitialContext();
            return (SessionFactory) context.lookup(sessionFactoryJNDI);
        } catch (NamingException e) {
            throw new RuntimeException(e);
        }
    }
}
