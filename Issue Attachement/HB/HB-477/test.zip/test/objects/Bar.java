package objects;

import java.io.Serializable;

/**
 * Bar.
 * 
 * @author ...
 * @version 1.0
 */
public class Bar implements Serializable {

	private Integer id;
	private String libelle;
	private Integer version;

	/**
	 * Constructor.
	 */
	public Bar() {
	}

	/**
	 * @return Returns the id.
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id The id to set.
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return Returns the string.
	 */
	public String getLibelle() {
		return libelle;
	}

	/**
	 * @param string The string to set.
	 */
	public void setLibelle(String string) {
		this.libelle = string;
	}

	/**
	 * @return Returns the version.
	 */
	public Integer getVersion() {
		return version;
	}

	/**
	 * @param version The version to set.
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}

}