package objects;

import java.io.Serializable;

/**
 * Foo.
 * 
 * @author ...
 * @version 1.0
 */
public class Foo implements Serializable {

	private FooPK fooPK;
	private String libelle;
	private Bar bar;

	/**
	 * Constructor.
	 */
	public Foo() {
	}

	/**
	 * @return
	 */
	public FooPK getFooPK() {
		return fooPK;
	}

	/**
	 * @param compId
	 */
	public void setFooPK(FooPK compId) {
		this.fooPK = compId;
	}

	/**
	 * @return
	 */
	public String getLibelle() {
		return libelle;
	}

	/**
	 * @param libelle
	 */
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	/**
	 * @return Returns the bar.
	 */
	public Bar getBar() {
		return bar;
	}

	/**
	 * @param bar The bar to set.
	 */
	public void setBar(Bar bar) {
		this.bar = bar;
	}

}