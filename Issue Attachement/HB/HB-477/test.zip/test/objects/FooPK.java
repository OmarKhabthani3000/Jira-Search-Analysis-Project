package objects;

import java.io.Serializable;

/**
 * FooPK. Primary key for data object Foo.
 * 
 * @author ...
 * @version 1.0
 */
public class FooPK implements Serializable {

	private Integer fooPK1;
	private Integer fooPK2;

	/**
	 * Constructor.
	 */
	public FooPK() {
	}

	/**
	 * @return Returns the fooPK1.
	 */
	public Integer getFooPK1() {
		return fooPK1;
	}

	/**
	 * @param fooPK1 The fooPK1 to set.
	 */
	public void setFooPK1(Integer fooPK1) {
		this.fooPK1 = fooPK1;
	}

	/**
	 * @return Returns the fooPK2.
	 */
	public Integer getFooPK2() {
		return fooPK2;
	}

	/**
	 * @param fooPK2 The fooPK2 to set.
	 */
	public void setFooPK2(Integer fooPK2) {
		this.fooPK2 = fooPK2;
	}

}