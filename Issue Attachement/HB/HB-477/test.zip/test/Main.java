import java.util.Iterator;
import java.util.List;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.MappingException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;

/**
 * Hibernate Test : Main<br>
 * 
 * Description :
 * 
 * @author ...
 * @version 1.0
 */

public class Main {

	/**
	 * Point d'entr�e.
	 * @param args arguments de la ligne de commande
	 */
	public static void main(String[] args) {

		Configuration cfg = new Configuration();

		try {
			cfg.addClass(objects.Bar.class);
			cfg.addClass(objects.Foo.class);
		} catch (MappingException e) {
			System.out.println("Mapping problem");
			System.exit(-1);
		}

		try {

			SessionFactory sessionFactory = cfg.buildSessionFactory();
			Session session = sessionFactory.openSession();

			//List liste = session.find("from Foo foo left outer join foo.bar bar");
			List liste = session.find("from Foo");

			Iterator it = liste.iterator();
			while (it.hasNext()) {
				Object object = it.next();
				System.out.println(object.toString());
			}

			session.close();

		} catch (HibernateException e) {
			System.err.println("Erreur : " + e.getMessage());
		}
	}
}
