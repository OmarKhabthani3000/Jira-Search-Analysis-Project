/*
 * SubChild.java
 *
 * Created on February 8, 2004, 8:06 AM
 */

package criteriatest;

/**
 *
 * @author  jerry
 */
public class SubChild extends Child {
    
    /**
     * Holds value of property parent.
     */
    private Parent parent;
    
    /** Creates a new instance of SubChild */
    public SubChild() {
    }
    
    /**
     * Getter for property parent.
     * @return Value of property parent.
     */
    public Parent getParent() {
        return this.parent;
    }
    
    /**
     * Setter for property parent.
     * @param parent New value of property parent.
     */
    public void setParent(Parent parent) {
        this.parent = parent;
    }
    
}
