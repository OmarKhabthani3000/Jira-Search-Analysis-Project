/*
 * Parent.java
 *
 * Created on February 8, 2004, 8:05 AM
 */

package criteriatest;

import java.util.Set;

/**
 *
 * @author  jerry
 */
public class Parent {
    
    /**
     * Holds value of property id.
     */
    private Integer id;
    
    /**
     * Holds value of property subChildren.
     */
    private Set subChildren;
    
    /** Creates a new instance of Parent */
    public Parent() {
    }
    
    /**
     * Getter for property id.
     * @return Value of property id.
     */
    public Integer getId() {
        return this.id;
    }
    
    /**
     * Setter for property id.
     * @param id New value of property id.
     */
    public void setId(Integer id) {
        this.id = id;
    }
    
    /**
     * Getter for property subChildren.
     * @return Value of property subChildren.
     */
    public Set getSubChildren() {
        return this.subChildren;
    }
    
    /**
     * Setter for property subChildren.
     * @param subChildren New value of property subChildren.
     */
    public void setSubChildren(Set subChildren) {
        this.subChildren = subChildren;
    }
    
}
