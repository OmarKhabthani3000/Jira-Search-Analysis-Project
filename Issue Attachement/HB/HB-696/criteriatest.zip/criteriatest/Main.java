/*
 * Main.java
 *
 * Created on February 8, 2004, 8:29 AM
 */

package criteriatest;

import java.util.List;
import net.sf.hibernate.Criteria;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.expression.Expression;

/**
 *
 * @author  jerry
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    public void go() throws Exception {
        SessionFactory factory = new Configuration().configure(getClass().getResource("/hibernate.cfg.xml")).buildSessionFactory();
        Session session = factory.openSession();
        
        Criteria criteria = session.createCriteria(Parent.class);
        Criteria childrenCriteria = criteria.createCriteria("subChildren");
        childrenCriteria.add( Expression.eq("quantity", new Integer(12)) );
        
        List results = criteria.list();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Main main = new Main();
            main.go();
        } catch( Throwable t ) {
            t.printStackTrace();
        }
    }
    
}
