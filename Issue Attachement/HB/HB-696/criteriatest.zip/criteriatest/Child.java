/*
 * Child.java
 *
 * Created on February 8, 2004, 8:06 AM
 */

package criteriatest;

/**
 *
 * @author  jerry
 */
public class Child {
    
    /**
     * Holds value of property id.
     */
    private Integer id;
    
    /**
     * Holds value of property quantity.
     */
    private int quantity;
    
    /** Creates a new instance of Child */
    public Child() {
    }
    
    /**
     * Getter for property id.
     * @return Value of property id.
     */
    public Integer getId() {
        return this.id;
    }
    
    /**
     * Setter for property id.
     * @param id New value of property id.
     */
    public void setId(Integer id) {
        this.id = id;
    }
    
    /**
     * Getter for property quantity.
     * @return Value of property quantity.
     */
    public int getQuantity() {
        return this.quantity;
    }
    
    /**
     * Setter for property quantity.
     * @param quantity New value of property quantity.
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
}
