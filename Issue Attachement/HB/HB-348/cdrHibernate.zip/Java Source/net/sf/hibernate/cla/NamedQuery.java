package net.sf.hibernate.cla;

/**
 * Created on Sep 18, 2003
 * 
 * The NamedQuery Object is a representation of a Hibernate native sql query.
 * These objects are made to be pulled from the namedQuery map in the 
 * session.
 * 
 * @see net.sf.hibernate.cla.NamedQueryConfiguration
 * @author Christopher D Riccio
 */
public class NamedQuery {
   private String queryName = null;
   private String query = null;
   private String[] aliases = null;
   private Class[] classes = null;
  
   public String[] getAliases() {
      return aliases;
   }

   public Class[] getClasses() {
      return classes;
   }

   public String getQuery() {
      return query;
   }

   public void setAliases(String[] strings) {
      aliases = strings;
   }

   public void setClasses(Class[] classes) {
      this.classes = classes;
   }

   public void setQuery(String string) {
      query = string;
   }
   public String getQueryName() {
      return queryName;
   }

   public void setQueryName(String string) {
      queryName = string;
   }
}
