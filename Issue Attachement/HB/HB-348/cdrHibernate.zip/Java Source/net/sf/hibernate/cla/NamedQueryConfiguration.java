package net.sf.hibernate.cla;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Attribute;
import org.dom4j.Element;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.cfg.Environment;
import net.sf.hibernate.util.XMLHelper;

/**
 * Created on Sep 18, 2003
 * 
 * An instance of the NamedQueryConfiguration can be used to load native
 * sql queries from a designated query file (defaults to namedQueries.xml).
 * It can be used to get a Map containing key queryName and value 
 * <tt>NamedQuery</tt>.
 * 
 * @see net.sf.hibernate.cla.NamedQuery
 * @author Christopher D Riccio
 */
public class NamedQueryConfiguration {
   
   private static Log log = LogFactory.getLog( NamedQueryConfiguration.class );
   
   /**
    * Get the namedQuery file as an <tt>InputStream</tt>. 
    *    
    * @param resource Name of resource you wish to load.
    * @return An <tt>InputStream</tt> created from the resource
    * @throws HibernateException
    */
   private InputStream getNamedQueryConfigurationInputStream( String resource ) 
           throws HibernateException {

      log.info( "Named Query Configuration resource: " + resource );

      InputStream stream = Environment.class.getResourceAsStream( resource );
      if ( stream == null ) {
         log.warn( resource + " not found" );
         throw new HibernateException( resource + " not found" );
      }
      return stream;
   }
   
   /**
    * Use the queries specified in an application
    * resource named <tt>namedQueries.xml</tt>.
    *     
    * @return A <tt>Map</tt> of <tt>NamedQuery</tt>s
    * @throws HibernateException
    */
   public Map configure() throws HibernateException{
      return configure( "/namedQueries.xml" );
   }
   
   /**
    * Use the queries specified in the given application
    * resource. The format of the resource is defined in
    * <tt>namedQuery.dtd</tt>.
    *
    * The resource is found via <tt>getConfigurationInputStream(resource)</tt>.
    * @param resource Name of resource you wish to load.
    * @return A <tt>Map</tt> of <tt>NamedQuery</tt>s
    * @throws HibernateException
    */
   public Map configure( String resource ) throws HibernateException {
      InputStream stream = getNamedQueryConfigurationInputStream( resource );
      return configure(stream, resource);
   }
   
   /**
    * Use the queries specified in the document.
    * The format of the document is defined in
    * <tt>namedQuery.dtd</tt>.
    *
    * @param url URL from which you wish to load the queries
    * @return A <tt>Map</tt> of <tt>NamedQuery</tt>s
    * @throws HibernateException
    */
   public Map configure( URL url ) throws HibernateException {
      try {
         return configure( url.openStream(), url.toString() );
      }
      catch (IOException ioe) {
         throw new HibernateException("could not configure from URL: " + url, ioe);
      }
   }

   /**
    * Use the queries specified in the application file.
    * The format of the document is defined in
    * <tt>namedQuery.dtd</tt>.
    *
    * @param configFile <tt>File</tt> from which you wish to load the queries
    * @return A <tt>Map</tt> of <tt>NamedQuery</tt>s
    * @throws HibernateException
    */
   public Map configure( File configFile ) throws HibernateException {
      try {
         return configure( new FileInputStream( configFile ), configFile.toString() );
      }
      catch ( FileNotFoundException fnfe ) {
         throw new HibernateException( "could not find file: " + configFile, fnfe );
      }
   }

   /**
    * Use the queries specified in the given applicatoin resource.
    * The format of the document is defined in
    * <tt>namedQuery.dtd</tt>.
    *
    * @param stream Inputstream to be read from
    * @param resourceName The name to use in warning/error messages
    * @return A <tt>Map</tt> of <tt>NamedQuery</tt>s
    * @throws HibernateException
    */
   protected Map configure( InputStream stream, String resourceName ) throws HibernateException {

      org.dom4j.Document doc;
      try {
         doc = XMLHelper.createSAXReader(resourceName).read( new InputSource(stream) );
      }
      catch (Exception e) {
         log.error("problem parsing configuration" + resourceName, e);
         throw new HibernateException("problem parsing configuration" + resourceName, e);
      }
      return configure(doc);
   }
   
   /**
    * Use the queries specified in the given XML document.
    * The format of the file is defined in
    * <tt>namedQueries.dtd</tt>.
    *
    * @param document an XML document from which you wish to load the configuration
    * @return A <tt>Map</tt> of <tt>NamedQuery</tt>s
    * @throws HibernateException if there is problem in accessing the file.
    */
   public Map configure( Document document ) throws HibernateException {

      org.dom4j.Document doc;
      try {
         doc = XMLHelper.createDOMReader().read( document );
      }
      catch (Exception e) {
         log.error( "problem parsing document", e );
         throw new HibernateException( "problem parsing document", e );
      }
      return configure(doc);
   }

   /**
    * load queries based on the given dom4j Document
    *
    * @param document a dom4j XML document
    * @return A <tt>Map</tt> of <tt>NamedQuery</tt>s
    * @throws HibernateException if there is problem in accessing the file.
    */
   private Map configure( org.dom4j.Document doc ) throws HibernateException {

      Map queryMap = new HashMap();
      Element sfNode = doc.getRootElement();
      String name = "named-sql-query";

      Iterator elements = sfNode.elementIterator();
      while ( elements.hasNext() ) {
         Element queryElem = (Element) elements.next();
         String elemname = queryElem.getName();
         if ( "sql-query".equals( elemname ) ) {
            NamedQuery nq = new NamedQuery();
            Attribute queryName = queryElem.attribute( "name" );
            if ( queryName != null && !queryName.getText().trim().equals( "" ) ) {
               log.debug( name + "<-" + queryName.getText() );
               Iterator returns = queryElem.elementIterator();
               
               Class[] classes = null;
               String[] aliases = null;
               int i = 0;
               while ( returns.hasNext() ) {
                  Element qReturn = (Element) returns.next();
                  boolean isReturn = "return".equals( qReturn.getName() );
                  if ( isReturn ) {
                     try {
                        classes = new Class[ queryElem.elements().size() ];
                        aliases = new String[ queryElem.elements().size() ];
                        classes[ i ] = Class.forName( qReturn.attribute( "class" ).getText() );
                        aliases[ i ] = qReturn.attribute( "alias" ).getText();
                     }
                     // should we throw an exception or just log and continue?
                     catch ( ClassNotFoundException cnfe ) {
                        throw new HibernateException( "Class Not ( " +
                                  qReturn.attribute( "class" ).getText() +
                                  " ) found in named query " + queryName.getText() );
                     }
                  }
                  else {
                     // should we throw an exception or just log and continue?
                     log.debug( name + "<-improper element in query - " + queryName + " - ingnoring!" );
                  }
                  i++;    
               }
               // build named query
               nq.setQueryName( queryName.getText() );
               nq.setQuery( queryElem.getText() );
               nq.setClasses( classes );
               nq.setAliases( aliases );
               queryMap.put( queryName.getText(), nq );
            }
            else {
               // should we throw an exception or just log and continue?
               log.debug( name + "<-Unnamed query - " + queryElem.getText() + " - ignoring!");
            }
         }
      }
      log.info( "Named Queries loaded" );
      return queryMap;
   }
}
