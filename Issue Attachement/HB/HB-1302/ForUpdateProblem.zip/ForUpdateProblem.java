package com.tryout;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.Properties;

import net.sf.hibernate.LockMode;
import net.sf.hibernate.Query;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;

public class ForUpdateProblem {
	private String hibernateProperties;

	private String password = "pguserpw";
	private String username = "pg_user";
	private String connectionUrl = "jdbc:postgresql://localhost:5432/dev";

	Session session;
	Transaction tx;

	String configDir = "testfiles" + File.separator + "config";
	String propertyPagesDir = "testfiles" + File.separator + "propertypages";

	public Session getSession() {
		return session;
	}
	void setUpHibernateSession() throws Exception {

		Configuration cfg = new Configuration();

		if (hibernateProperties != null) {
			File file = new File(hibernateProperties);
			InputStream is;
			try {
				is = new FileInputStream(file);
			} catch (FileNotFoundException e) {
				return;
			}
			if (is == null) {
				return;
			}
			try {
				Properties props = new Properties();
				props.load(is);
				cfg.addProperties(props);
			} catch (IOException ex) {
				return;
			}
		}

		cfg
			.setProperty("hibernate.connection.url", connectionUrl)
			.setProperty("hibernate.connection.username", username)
			.setProperty("hibernate.connection.password", password)
			.addResource("TestTable.hbm");
		SessionFactory sf = cfg.buildSessionFactory();

		session = sf.openSession();

		Connection c = session.connection();
		c.setAutoCommit(false);
		tx = session.beginTransaction();
	}

	void setSession(Session session) {
		this.session = session;
	}

	void finish() throws Exception {
		session.flush();
		tx.commit();
	}

	public void run(String[] args) throws Exception {
		try {
			//			parseCmdLine( args );
			PreparedStatement pstmt;

			try {
				setUpHibernateSession();
				getSession().flush();
				Connection conn = getSession().connection();
				pstmt =
					conn.prepareStatement(
						"CREATE TABLE TEST_TABLE (COLUMN1 NUMERIC PRIMARY KEY,COLUMN2 NUMERIC)");
				pstmt.execute();
				finish();
			} catch (Exception ex) {
				finish();
				ex.printStackTrace();
			}

// here's the problem:
			try {
				setUpHibernateSession();
				getSession().flush();
				Query query =
					getSession().createQuery(
						"from TestTable as t where t.column1= 1 and t.column2= 2");

//				query.setLockMode("", LockMode.UPGRADE); // query works:
				// select testtable0_.column1 as column1, testtable0_.column2 as column2 from TEST_TABLE testtable0_ where (testtable0_.column1=1 )and(testtable0_.column2=2 )

//				query.setLockMode("t", LockMode.UPGRADE); // query works:
				// select testtable0_.column1 as column1, testtable0_.column2 as column2 from TEST_TABLE testtable0_ where (testtable0_.column1=1 )and(testtable0_.column2=2 ) for update of testtable0_
				
				query.setLockMode("this", LockMode.UPGRADE); // query does not work:
				// select testtable0_.column1 as column1, testtable0_.column2 as column2 from TEST_TABLE testtable0_ where (testtable0_.column1=1 )and(testtable0_.column2=2 ) for update of this

/*
from the hibernate API:

setLockMode

public void setLockMode(String alias,
                        LockMode lockMode)

    Set the lockmode for the objects idententified by the given alias that appears in the FROM clause.

    Parameters:
        alias - a query alias, or this for a collection filter

 */

				List result = query.list();
				System.out.println("Num of result entries: " + result.size());
				finish();
			} catch (Exception ex) {
				finish();
				ex.printStackTrace();
			}

			try {
				setUpHibernateSession();
				getSession().flush();
				Connection conn = getSession().connection();
				pstmt = conn.prepareStatement("DROP TABLE TEST_TABLE");
				pstmt.execute();
				finish();
			} catch (Exception ex) {
				finish();
				ex.printStackTrace();
			}
		} catch (Exception ex) {
		}
	}

	private void print(String s) {
		System.out.println(s);
	}

	public static void main(String[] args) throws Exception {
		ForUpdateProblem it = new ForUpdateProblem();
		it.run(args);
	}
}

/*
TestTable.hbm:

<?xml version="1.0"?>
<!DOCTYPE hibernate-mapping PUBLIC
	"-//Hibernate/Hibernate Mapping DTD//EN"
	"http://hibernate.sourceforge.net/hibernate-mapping-2.0.dtd" >

<hibernate-mapping package="com.tryout">
	<class name="TestTable" table="TEST_TABLE">
		<id
			column="column1"
			name="column1"
			type="integer"
		>
			<generator class="assigned"/>
		</id>
		<property
			column="column2"
			name="column2"
			not-null="false"
			type="integer"
		 />
	</class>
</hibernate-mapping>
**/