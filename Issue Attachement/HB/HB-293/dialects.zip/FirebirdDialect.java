package net.sf.hibernate.dialect;

import java.sql.Types;

import net.sf.hibernate.cfg.Environment;

/**
 * An SQL dialect for Firebird.
 * @author Gavin King
 */

public class FirebirdDialect extends InterBaseDialect {
    
	public FirebirdDialect() {
		super();
	}
	
	public String getDropSequenceString(String sequenceName) {
        return "drop generator " + sequenceName;
    }
	
	public String getLimitString(String sql) {
		StringBuffer pagingSelect = new StringBuffer(100);
		pagingSelect.append(sql);
		pagingSelect.insert(6, " first ? skip ?");
		return pagingSelect.toString();
	}

	public boolean bindLimitParametersFirst() {
		return true;
	}

    public boolean bindLimitParametersInReverseOrder() {
        return true;
    }

}