package net.sf.hibernate.dialect;

import java.sql.Types;

import net.sf.hibernate.cfg.Environment;

/**
 * An SQL dialect for Interbase.
 * @author Gavin King
 */

public class InterbaseDialect extends Dialect {

	public InterbaseDialect() {
		super();
		register( Types.BIT, "SMALLINT" );
		register( Types.BIGINT, "NUMERIC(18,0)" );
		register( Types.SMALLINT, "SMALLINT" );
		register( Types.TINYINT, "SMALLINT" );
		register( Types.INTEGER, "INTEGER" );
		register( Types.CHAR, "CHAR(1)" );
		register( Types.VARCHAR, "VARCHAR($l)" );
		register( Types.FLOAT, "FLOAT" );
		register( Types.DOUBLE, "DOUBLE PRECISION" );
		register( Types.DATE, "DATE" );
		register( Types.TIME, "TIME" );
		register( Types.TIMESTAMP, "TIMESTAMP" );
		register( Types.VARBINARY, "BLOB" );
		register( Types.NUMERIC, "NUMERIC(18, $l)" );
		register( Types.BLOB, "BLOB" );
		register( Types.CLOB, "BLOB SUB_TYPE 1" );
		
		getDefaultProperties().setProperty(Environment.USE_OUTER_JOIN, "true");
		getDefaultProperties().setProperty(Environment.STATEMENT_BATCH_SIZE, NO_BATCH);
		getDefaultProperties().setProperty(Environment.STATEMENT_CACHE_SIZE, "0");
	}
	
	public String getAddColumnString() {
		return "add";
	}
    
	public String getSequenceNextValString(String sequenceName) {
		return "select gen_id( " + sequenceName + ", 1 ) from RDB$DATABASE";
	}
    
	public String getCreateSequenceString(String sequenceName) {
		return "create generator " + sequenceName;
	}
    
	public String getDropSequenceString(String sequenceName) {
		return "delete from RDB$GENERATORS where RDB$GENERATOR_NAME = '" + sequenceName.toUpperCase() + "'";
	}
	
    public boolean supportsForUpdateOf() {
        return true;
    }

	public boolean supportsSequences() {
		return true;
	}

	public boolean supportsLimit() {
		return true;
	}
 
	public String getLimitString(String sql) {
		StringBuffer pagingSelect = new StringBuffer(100);
		pagingSelect.append(sql);
		pagingSelect.insert(6, " rows ? to ? ");
		return pagingSelect.toString();
	}

	public boolean bindLimitParametersFirst() {
		return false;
	}

    public boolean bindLimitParametersInReverseOrder() {
        return false;
    }

}