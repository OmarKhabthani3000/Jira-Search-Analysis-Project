package net.sf.hibernate.dialect;

import net.sf.hibernate.MappingException;

/**
 * Informix9 dialect. This class is extends the Informix 7 dialect
 * <br>
 * Seems to work with Informix Dynamic Server Version 9.4, 
 * Informix JDBC driver version 2.21JC5.
 * @author Finn McCann
 */
public class Informix9Dialect extends InformixDialect {
	
	public Informix9Dialect() {
		super();
	}	

	/**
	 * @see net.sf.hibernate.dialect.Dialect#getIdentityColumnString()
	 */
	public String getIdentityColumnString() throws MappingException {
		return "SERIAL8 NOT NULL";
	}

	/**
	 * @see net.sf.hibernate.dialect.Dialect#hasDataTypeInIdentityColumn()
	 * Informix9 has it's own SERIAL8 datatype.
	 * @return boolean
	 */
	public boolean hasDataTypeInIdentityColumn() {
		return false;
	}

	/**
	 * The syntax used to add a foreign key constraint to a table. 
	 * Informix constraint name must be at the end.
	 * @return String
	 */
	public String getAddForeignKeyConstraintString(String constraintName, String[] foreignKey, String referencedTable, String[] primaryKey) {
		return new StringBuffer(30)
		.append(" add constraint ")
		.append(" foreign key (")
		.append( StringHelper.join(StringHelper.COMMA_SPACE, foreignKey) )
		.append(") references ")
		.append(referencedTable)
		.append(" constraint ")
		.append(constraintName)
		.toString();
	}
	
	/**
	 * The syntax used to add a primary key constraint to a table.
	 * Informix constraint name must be at the end.
	 * @return String
	 */
	public String getAddPrimaryKeyConstraintString(String constraintName) {
		return " add constraint primary key constraint " + constraintName + " ";
	}
}

