package org.hibernate.test;

import java.util.Comparator;

public class SimpleAdrKey implements Comparator
{
	private final String adr;

	public SimpleAdrKey()
	{
		this.adr = null;
	}

	public SimpleAdrKey(String adr)
	{
		this.adr = adr;
	}

	public int compare(Object o1, Object o2)
	{
		String s1, s2;
		if (o1 instanceof SimpleAdrKey)
			s1 = ((SimpleAdrKey) o1).adr;
		else
			s1 = ((Simple) o1).getAddress();
		if (o2 instanceof SimpleAdrKey)
			s2 = ((SimpleAdrKey) o2).adr;
		else
			s2 = ((Simple) o2).getAddress();

		return s1.compareTo(s2);
	}
}