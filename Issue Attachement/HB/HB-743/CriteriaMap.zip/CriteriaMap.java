//$Id: FooBarTest.java,v 1.1.2.24 2004/02/22 01:51:37 oneovthafew Exp $
package org.hibernate.test;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import net.sf.hibernate.Session;
import net.sf.hibernate.Transaction;

import java.util.Date;
import java.util.Map;

public class CriteriaMap extends TestCase
{

	private final static String[] VALUES =
		{
			"addr1", "addr2", "addr3", "addr4", "addr5", "addr6"
		};

	public CriteriaMap(String arg)
	{
		super(arg);
	}

	public void testMap() throws Exception
	{
		Session s = openSession();
		Transaction t = s.beginTransaction();
		for (int i = 0; i < VALUES.length; i++)
		{
			String value = VALUES[i];

			Simple simple = new Simple();
			simple.setAddress(value);
			simple.setCount(i);
			simple.setDate(new Date());
			simple.setName(value);
			simple.setPay(new Float(17f * i));
			s.save(simple, new Long(i));
		}
		t.commit();
		s.close();

		s = openSession();
		t = s.beginTransaction();

		{
			Map map = s.createCriteria(Simple.class).map(new SimpleNameKey());
			Simple simple = (Simple) map.get(new SimpleNameKey(VALUES[2]));
			assertTrue(simple != null);
			assertTrue(simple.getName().equals(VALUES[2]));
		}

		{
			Map map = s.createCriteria(Simple.class).map(new SimpleAdrKey());
			Simple simple = (Simple) map.get(new SimpleAdrKey(VALUES[3]));
			assertTrue(simple != null);
			assertTrue(simple.getName().equals(VALUES[3]));
		}

		t.commit();
		s.close();
	}

	public static Test suite()
	{
		return new TestSuite(CriteriaMap.class);
	}

	public static void main(String[] args) throws Exception
	{
		TestRunner.run(suite());
	}

	protected String[] getMappings()
	{
		return new String[]{
			"Simple.hbm.xml",
		};
	}

}
