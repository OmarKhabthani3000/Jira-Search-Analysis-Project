package org.hibernate.test;

import java.util.Comparator;

public class SimpleNameKey implements Comparator
{
	private final String name;

	public SimpleNameKey()
	{
		this.name = null;
	}

	public SimpleNameKey(String name)
	{
		this.name = name;
	}

	public int compare(Object o1, Object o2)
	{
		String s1, s2;
		if (o1 instanceof SimpleNameKey)
			s1 = ((SimpleNameKey) o1).name;
		else
			s1 = ((Simple) o1).getName();
		if (o2 instanceof SimpleNameKey)
			s2 = ((SimpleNameKey) o2).name;
		else
			s2 = ((Simple) o2).getName();

		return s1.compareTo(s2);
	}
}