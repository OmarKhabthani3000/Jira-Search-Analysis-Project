
package com.qxlva;

import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.Query;
import net.sf.hibernate.cfg.Configuration;

import java.util.List;

/**
 *
 * @author Simon Knott
 */
public class TestCacheDAO
{

    private static SessionFactory sessionFactory;

    static {
        try
        {
            sessionFactory = new Configuration().addClass(TestCache.class).buildSessionFactory();
        }
        catch (HibernateException he)
        {
            he.printStackTrace();
        }
    }

    public static void testCache() {

        Session currentSession = null;
        List results = null;
        try
        {
            currentSession = sessionFactory.openSession();

            TestCache queryBean = new TestCache();
            queryBean.setType(new Integer(1));

            Query selectionQuery = currentSession.createQuery("from TestCache tc where tc.type=:type");
            selectionQuery.setProperties(queryBean);
            selectionQuery.setCacheable(true);
            results = selectionQuery.list();

        }
        catch (HibernateException he)
        {
            he.printStackTrace();
        }
        finally
        {
            try
            {
                if (currentSession != null)
                {
                    currentSession.close();
                }
                else
                {
                    throw new HibernateException("Could not close hibernate session, as session was NULL.");
                }
            }
            catch (HibernateException he)
            {
                he.printStackTrace();
            }
        }

    }

    public static void main(String[] args) throws Exception {
        testCache();

        Thread.sleep(1000);

        testCache();
    }
}
