
package com.qxlva;

import com.qxlva.nissa.pensions.bo.Address;

/**
 * Business object for a Collection Agency Office.
 *
 * @hibernate.class table="TESTCACHE"
 * mutable="false"
 */
public class TestCache
{

    private String id;

    private String name;

    private Integer type;

    private String addressId;

    private Address address;

    /**
     * Gets the unique ID of the collection agency office.
     *
     * @return The unique ID of the collection agency office
     *
     * @hibernate.id column="TCID" type="string" length="255" generator-class="native" unsaved-value="null"
     */
    public String getId()
    {
        return id;
    }

    /**
     * Sets the unique ID of the collection agency.
     *
     * @param id The unique ID of the collection agency
     */
    public void setId(String id)
    {
       this.id = id;
    }

    /**
     * Gets the name of the collection agency.
     *
     * @return The name of the collection agency
     *
     * @hibernate.property column="TCNAME" type="string" length="100" not-null="false"
     */
    public String getName()
    {
        return name;
    }

    /**
     * Sets the name of the collection agency.
     *
     * @param name The name of the collection agency
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * Gets the type of the collection agency.
     *
     * @return The type of the collection agency
     *
     * @hibernate.property column="TCTYPE" type="integer"
     */
    public Integer getType()
    {
        return type;
    }

    /**
     * Sets the type of the collection agency.
     *
     * @param type The type of the collection agency
     */
    public void setType(Integer type)
    {
        this.type = type;
    }

    /**
     * Gets the address id of the collection agency.
     *
     * @return The address id of the collection agency
     *
     * @hibernate.property column="ADDRESSID" type="string" length="255" not-null="false"
     */
    public String getAddressId()
    {
        return addressId;
    }

    /**
     * Sets the address ID of the collection agency.
     *
     * @param addressId The address id
     */
    public void setAddressId(String addressId)
    {
        this.addressId = addressId;
    }

    /**
     * Gets the address of the collection agency.
     *
     * @return The address of the collection agency.
     */
    public Address getAddress()
    {
        return address;
    }

    /**
     * Sets the address of the collection agency.
     *
     * @param address The address of the collection agency
     */
    public void setAddress(Address address)
    {
        this.address = address;
    }

}
