package mypackage;

public class Child 
{
  protected long id;
  protected String name;

  public Child()
  {
  }

  public long getId()
  {
    return id;
  }

  public void setId(long newId)
  {
    id = newId;
  }

  public String getName()
  {
    return name;
  }

  public void setName(String newName)
  {
    name = newName;
  }
}