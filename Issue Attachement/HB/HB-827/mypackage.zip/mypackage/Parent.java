package mypackage;
import java.util.List;

public class Parent 
{
  protected long id;
  protected String name;
  protected List childs;

  public Parent()
  {
  }

  public long getId()
  {
    return id;
  }

  public void setId(long newId)
  {
    id = newId;
  }

  public String getName()
  {
    return name;
  }

  public void setName(String newName)
  {
    name = newName;
  }

  public List getChilds()
  {
    return childs;
  }

  public void setChilds(List newChilds)
  {
    childs = newChilds;
  }
}