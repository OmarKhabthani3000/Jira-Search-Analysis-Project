package mypackage;

import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Session;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.Hibernate;
import java.sql.DriverManager;
import java.sql.Connection;
import java.util.List;
import java.util.Iterator;
import oracle.jdbc.driver.*;

public class Prueba 
{
  public static void main(String[] args) throws Exception
  {
    Transaction    transaction;
    Configuration  configuration = new Configuration ();
    SessionFactory factory;
    Session        session;
    Parent         parent;
    Child          child;

    configuration.addClass (Parent.class);
    configuration.addClass (Child.class);    

    factory = configuration.buildSessionFactory ();
    session = factory.openSession ();

    parent = new Parent ();
    parent.setName ("Example");

    transaction = session.beginTransaction ();
    session.saveOrUpdate (parent);
    transaction.commit ();
    session.clear ();

    parent = (Parent) session.find ("from Parent where name = ?", "Example", Hibernate.STRING).get (0);
    session.clear ();
    
    child  = new Child ();
    child.setName ("Example Child");

    parent.getChilds ().add (child);
  }
}