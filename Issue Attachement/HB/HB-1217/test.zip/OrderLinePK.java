package hibernate.test;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class OrderLinePK implements Serializable {

    /** identifier field */
    private String orderId;

    /** identifier field */
    private Integer line;

    /** full constructor */
    public OrderLinePK(String orderId, Integer line) {
        this.orderId = orderId;
        this.line = line;
    }

    /** default constructor */
    public OrderLinePK() {
    }

    public String getOrderId() {
        return this.orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public Integer getLine() {
        return this.line;
    }

    public void setLine(Integer line) {
        this.line = line;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("orderId", getOrderId())
            .append("line", getLine())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof OrderLinePK) ) return false;
        OrderLinePK castOther = (OrderLinePK) other;
        return new EqualsBuilder()
            .append(this.getOrderId(), castOther.getOrderId())
            .append(this.getLine(), castOther.getLine())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getOrderId())
            .append(getLine())
            .toHashCode();
    }

}
