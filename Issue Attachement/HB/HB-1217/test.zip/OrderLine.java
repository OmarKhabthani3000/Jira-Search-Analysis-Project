package hibernate.test;

import java.io.Serializable;
import java.util.List;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class OrderLine implements Serializable {

    /** identifier field */
    private hibernate.test.OrderLinePK comp_id;

    /** persistent field */
    private List orderLineItemList;

    /** full constructor */
    public OrderLine(hibernate.test.OrderLinePK comp_id, List orderLineItemList) {
        this.comp_id = comp_id;
        this.orderLineItemList = orderLineItemList;
    }

    /** default constructor */
    public OrderLine() {
    }

    public hibernate.test.OrderLinePK getComp_id() {
        return this.comp_id;
    }

    public void setComp_id(hibernate.test.OrderLinePK comp_id) {
        this.comp_id = comp_id;
    }

    public List getOrderLineItemList() {
        return this.orderLineItemList;
    }

    public void setOrderLineItemList(List orderLineItemList) {
        this.orderLineItemList = orderLineItemList;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof OrderLine) ) return false;
        OrderLine castOther = (OrderLine) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
