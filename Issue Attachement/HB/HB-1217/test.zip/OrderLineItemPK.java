package hibernate.test;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class OrderLineItemPK implements Serializable {

    /** identifier field */
    private String itemId;

    /** identifier field */
    private hibernate.test.OrderLine orderline;

    /** full constructor */
    public OrderLineItemPK(String itemId, hibernate.test.OrderLine orderline) {
        this.itemId = itemId;
        this.orderline = orderline;
    }

    /** default constructor */
    public OrderLineItemPK() {
    }

    public String getItemId() {
        return this.itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public hibernate.test.OrderLine getOrderline() {
        return this.orderline;
    }

    public void setOrderline(hibernate.test.OrderLine orderline) {
        this.orderline = orderline;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("itemId", getItemId())
            .append("orderline", getOrderline())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof OrderLineItemPK) ) return false;
        OrderLineItemPK castOther = (OrderLineItemPK) other;
        return new EqualsBuilder()
            .append(this.getItemId(), castOther.getItemId())
            .append(this.getOrderline(), castOther.getOrderline())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getItemId())
            .append(getOrderline())
            .toHashCode();
    }

}
