package hibernate.test;

import java.io.Serializable;
import java.util.List;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class OrderLineItem implements Serializable {

    /** identifier field */
    private hibernate.test.OrderLineItemPK comp_id;

    /** persistent field */
    private List orderLineItemOptionList;

    /** full constructor */
    public OrderLineItem(hibernate.test.OrderLineItemPK comp_id, List orderLineItemOptionList) {
        this.comp_id = comp_id;
        this.orderLineItemOptionList = orderLineItemOptionList;
    }

    /** default constructor */
    public OrderLineItem() {
    }

    public hibernate.test.OrderLineItemPK getComp_id() {
        return this.comp_id;
    }

    public void setComp_id(hibernate.test.OrderLineItemPK comp_id) {
        this.comp_id = comp_id;
    }

    public List getOrderLineItemOptionList() {
        return this.orderLineItemOptionList;
    }

    public void setOrderLineItemOptionList(List orderLineItemOptionList) {
        this.orderLineItemOptionList = orderLineItemOptionList;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof OrderLineItem) ) return false;
        OrderLineItem castOther = (OrderLineItem) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
