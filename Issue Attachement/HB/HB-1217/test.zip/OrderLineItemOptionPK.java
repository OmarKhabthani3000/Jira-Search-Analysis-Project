package hibernate.test;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class OrderLineItemOptionPK implements Serializable {

    /** identifier field */
    private String optionId;

    /** identifier field */
    private hibernate.test.OrderLineItem orderlineitem;

    /** full constructor */
    public OrderLineItemOptionPK(String optionId, hibernate.test.OrderLineItem orderlineitem) {
        this.optionId = optionId;
        this.orderlineitem = orderlineitem;
    }

    /** default constructor */
    public OrderLineItemOptionPK() {
    }

    public String getOptionId() {
        return this.optionId;
    }

    public void setOptionId(String optionId) {
        this.optionId = optionId;
    }

    public hibernate.test.OrderLineItem getOrderlineitem() {
        return this.orderlineitem;
    }

    public void setOrderlineitem(hibernate.test.OrderLineItem orderlineitem) {
        this.orderlineitem = orderlineitem;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("optionId", getOptionId())
            .append("orderlineitem", getOrderlineitem())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof OrderLineItemOptionPK) ) return false;
        OrderLineItemOptionPK castOther = (OrderLineItemOptionPK) other;
        return new EqualsBuilder()
            .append(this.getOptionId(), castOther.getOptionId())
            .append(this.getOrderlineitem(), castOther.getOrderlineitem())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getOptionId())
            .append(getOrderlineitem())
            .toHashCode();
    }

}
