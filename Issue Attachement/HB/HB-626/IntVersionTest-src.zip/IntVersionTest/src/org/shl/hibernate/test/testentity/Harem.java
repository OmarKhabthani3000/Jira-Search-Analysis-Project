package org.shl.hibernate.test.testentity;

import java.io.Serializable;

/**
 *
 * @author shl
 */
public class Harem implements Serializable
{
	private Long manId;
	private Long womanId;
	private java.util.Date startDate;
	private java.util.Date lastVisitDate;

	private MoslemMan husband;
	private Woman wife;

	//IT_WORKS
	/*
	Integer version = null;
	public Integer getVersion()
	{
		return version;
	}
	*/

	//NO_IT_DOESNOT_WORK
	int version = -1;
	public int getVersion()
	{
		return version;
	}

	public Long getManId()
	{
		return manId;
	}

	public void setManId(Long manId)
	{
		this.manId = manId;
	}

	public Long getWomanId()
	{
		return womanId;
	}

	public void setWomanId(Long womanId)
	{
		this.womanId = womanId;
	}

	public java.util.Date getStartDate()
	{
		return startDate;
	}

	public void setStartDate(java.util.Date startDate)
	{
		this.startDate = startDate;
	}

	public java.util.Date getLastVisitDate()
	{
		return lastVisitDate;
	}

	public void setLastVisitDate(java.util.Date lastVisitDate)
	{
		this.lastVisitDate = lastVisitDate;
	}

	public MoslemMan getHusband()
	{
		return husband;
	}

	public void setHusband(MoslemMan husband)
	{
		this.husband = husband;
	}

	public Woman getWife()
	{
		return wife;
	}

	public void setWife(Woman wife)
	{
		this.wife = wife;
	}

	public boolean equals(Object o)
	{
		if (this == o) return true;
		if (!(o instanceof Harem)) return false;

		final Harem harem = (Harem) o;

		if (manId != null ? !manId.equals(harem.manId) : harem.manId != null) return false;
		if (womanId != null ? !womanId.equals(harem.womanId) : harem.womanId != null) return false;

		return true;
	}

	public int hashCode()
	{
		int result;
		result = (manId != null ? manId.hashCode() : 0);
		result = 29 * result + (womanId != null ? womanId.hashCode() : 0);
		return result;
	}
}
