package org.shl.hibernate.test;

import junit.framework.TestCase;
import junit.framework.Test;
import junit.framework.TestSuite;
import net.sf.hibernate.Session;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;
import org.shl.hibernate.test.testentity.MoslemMan;
import org.shl.hibernate.test.testentity.Woman;
import org.shl.hibernate.test.testentity.Harem;

import java.util.Date;

/**
 *
 * @author shl
 */
public class IntVersionTest extends TestCase
{
	private SessionFactory sessionFactory;

	protected void setUp() throws Exception
	{
		super.setUp();
	}

	protected void tearDown() throws Exception
	{
		super.tearDown();
	}

	public void testLiteralIntVersion()
			throws HibernateException
	{
		Session session = null;
		Transaction tx = null;

		try
		{
			session = openSession();

			//-- INSERT

			tx = session.beginTransaction();

			printDebug("sessionFactory=" + session.getSessionFactory());
			printDebug("session=" + session);

			MoslemMan man = new MoslemMan();
			Woman woman = new Woman();

			man.setName("man" + getSomeValue());
			woman.setName("woman" + getSomeValue());

			man.addToHarem(woman);

			session.save(man);

			assertNotNull(man.getId());

			session.flush();
			tx.commit();
			tx = null;

			//-- SELECT BY ID

			tx = session.beginTransaction();

			MoslemMan readMan = (MoslemMan) session.load(MoslemMan.class, man.getId());
			Harem readHarem = (Harem) readMan.getHarem().get(0);

			//-- CHECKS
			assertEquals(man.getId(), readMan.getId());

			//IT_WORKS
			//assertTrue(readHarem.getVersion().intValue() == 0);
			
			//NO_IT_DOESNOT_WORK
			assertTrue(readHarem.getVersion() == 0);

			//-- UPDATE

			readHarem.setLastVisitDate(new Date(333333333));
			session.update(readHarem);

			session.flush();
			tx.commit();
			tx = null;


		}
		catch (Exception e)
		{
			if (null != tx)
				tx.rollback();

			throw new RuntimeException(e);
		}
		finally
		{
			if (null != session)
				session.close();
		}
	}

	public static Test suite()
	{
		return new TestSuite(IntVersionTest.class);
	}

	public static void main(String argv[])
	{
		junit.textui.TestRunner.run(suite());
	}

	protected static final void printDebug(String msg)
	{
		System.out.println(msg);
	}

	private long getSomeValue()
	{
		return (new Date()).getTime();
	}

	private void buildSessionFactory()
			throws HibernateException

	{
		Configuration config = new Configuration();

		final String path = "org/shl/hibernate/test/testentity/";
		config.addResource(path + "MoslemMan.hbm.xml", IntVersionTest.class.getClassLoader());
		config.addResource(path + "Woman.hbm.xml", IntVersionTest.class.getClassLoader());
		config.addResource(path + "Harem.hbm.xml", IntVersionTest.class.getClassLoader());

		sessionFactory = config.buildSessionFactory();
	}

	private Session openSession()
			throws HibernateException
	{
		if (null == sessionFactory)
			buildSessionFactory();

		return sessionFactory.openSession();
	}
}
