package org.shl.hibernate.test.testentity;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author shl
 */
public class MoslemMan
{
	private Long id;
	private String name;

	/** List of Harem objects */
	private List harem = new ArrayList();

	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public List getHarem()
	{
		return harem;
	}

	public void setHarem(List harem)
	{
		this.harem = harem;
	}

	public void addToHarem(Woman woman)
	{
		Harem record = new Harem();

		record.setHusband(this);
		record.setWife(woman);
		record.setStartDate(new Date());
		record.setLastVisitDate(new Date());

		harem.add(record);
	}
}
