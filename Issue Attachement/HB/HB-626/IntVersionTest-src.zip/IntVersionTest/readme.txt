./build/

./lib/		libs, maybe some of them are unnecessary

./misc/		consists hibernate (hibernate.properties) and
		log4j (log4j.properties) configurations,
		*DO NOT FORGET* to tune hibernate.properties
		for your database

./sql/		cosists schema.sql, *RUN* it before starting
		the JUnit test

./src/		Java sorces and hibernate mappings

./hibernate.log	hibernate output


Focus you attention on the "binding '-1' to parameter: 1", that is binding -1 to version column.

11:00:35,531 DEBUG SQL:223 - insert into "Harem" ("version", "startDate", "lastVisitDate", "manId", "womanId") values (?, ?, ?, ?, ?)
Hibernate: insert into "Harem" ("version", "startDate", "lastVisitDate", "manId", "womanId") values (?, ?, ?, ?, ?)
11:00:35,532 DEBUG BatcherImpl:227 - preparing statement
11:00:35,533 DEBUG EntityPersister:389 - Dehydrating entity: [org.shl.hibernate.test.testentity.Harem#org.shl.hibernate.test.testentity.Harem@0]
11:00:35,536 DEBUG IntegerType:46 - binding '-1' to parameter: 1
11:00:35,539 DEBUG DateType:46 - binding '22  2004' to parameter: 2
11:00:35,542 DEBUG DateType:46 - binding '22  2004' to parameter: 3
11:00:35,544 DEBUG LongType:46 - binding '983041' to parameter: 4
11:00:35,545 DEBUG LongType:46 - binding '1015809' to parameter: 5
		

Best regards,
Leonid Shlyapnikov shl@vlinkmail.com
