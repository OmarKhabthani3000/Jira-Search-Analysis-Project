/* PostreSQL 7.4.1 */

DROP TABLE hibernate_unique_key;
DROP TABLE "Harem";
DROP TABLE "MoslemMan";
DROP TABLE "Woman";

CREATE TABLE hibernate_unique_key
(
	next_hi INT8
);
INSERT INTO hibernate_unique_key VALUES(0);

CREATE TABLE "MoslemMan"
(
	"id" INT8 PRIMARY KEY,
	"name" varchar(64)
);

CREATE TABLE "Woman"
(
	"id" INT8 PRIMARY KEY,
	"name" varchar(64)
);

CREATE TABLE "Harem"
(
	"manId" INT8 NOT NULL,
	"womanId" INT8 NOT NULL,
	"startDate" DATE,
	"lastVisitDate" DATE,
	"version" INT
);
ALTER TABLE "Harem" ADD CONSTRAINT PK_HAREM PRIMARY KEY ("manId", "womanId");
