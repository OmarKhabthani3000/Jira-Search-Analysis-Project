/*
 * AbstractIdentifierGenerator.java
 *
 * Created on Tue Aug 17 13:51:58 EDT 2004   
 */

package com.deg.helix.util.hibernate.persistence;

import net.sf.hibernate.id.SequenceGenerator;
import net.sf.hibernate.id.IdentifierGeneratorFactory;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.MappingException;
import net.sf.hibernate.dialect.Dialect;
import net.sf.hibernate.engine.SessionImplementor;
import net.sf.hibernate.type.Type;
import net.sf.hibernate.util.PropertiesHelper;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.Serializable;
import org.apache.log4j.Logger;
import java.util.Properties;
import java.sql.ResultSet;

public abstract class AbstractIdentifierGenerator extends SequenceGenerator {
	
	/** Logger - Log is never enough! */
	protected Logger logger = Logger.getLogger( AbstractIdentifierGenerator.class );
	
	/** Table Name */
	protected String tableName;
	
	/** Type */
	protected Type type;
	
	/** Configure */
	public void configure(Type type, Properties params, Dialect dialect) throws MappingException {
		this.tableName = PropertiesHelper.getString( "table", params, "mytable" );
		this.type = type;
		super.configure( type, params, dialect );
	}
	
	/** Generate Identifier */
	public synchronized Serializable generate(SessionImplementor session, Object obj) throws SQLException, HibernateException {
		Serializable id = getExistingObject( session, obj );
		if ( id == null ) {
			return super.generate( session, obj );
		} else {
			logger.debug("Reusing Object: " + obj);
			return id;
		}
	}
	
	/** Get Existing Object */
	protected abstract Serializable getExistingObject(SessionImplementor session, Object obj) throws SQLException, HibernateException;
	
	/** Generate Existing Object SQL */
	protected abstract String generateExistingObjectSql( Object obj );

}
