/*
 * AddressIdentifierGenerator.java
 *
 * Created on Tue Aug 17 13:51:58 EDT 2004   
 */

package com.deg.helix.common.address;

import net.sf.hibernate.id.SequenceGenerator;
import net.sf.hibernate.id.IdentifierGeneratorFactory;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.MappingException;
import net.sf.hibernate.dialect.Dialect;
import net.sf.hibernate.engine.SessionImplementor;
import net.sf.hibernate.type.Type;
import net.sf.hibernate.util.PropertiesHelper;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.Serializable;
import org.apache.log4j.Logger;
import java.util.Properties;
import java.sql.ResultSet;

public class AddressIdentifierGenerator extends com.deg.helix.util.hibernate.persistence.AbstractIdentifierGenerator {
	
	/** Logger - Log is never enough! */
	private Logger logger = Logger.getLogger( AddressIdentifierGenerator.class );
	
	/** Get Existing Object */
	protected Serializable getExistingObject(SessionImplementor session, Object obj) throws SQLException, HibernateException {
		PreparedStatement st = session.getBatcher().prepareStatement( generateExistingObjectSql(obj) );
		Address addr = (Address)obj;
		st.setString( 1, addr.getStreetAddress() );
		st.setString( 2, addr.getCity() );
		st.setString( 3, addr.getState() );
		st.setString( 4, addr.getZipcode() );
		try {
			ResultSet rs = st.executeQuery();
			final Serializable result;
			try {
				rs.next();
				result = IdentifierGeneratorFactory.get( rs, type, session, obj );
			} finally {
				rs.close();
			}
			logger.info("Sequence identifier generated: " + result);
			return result;
		} catch (SQLException sqle) {
			logger.error( sqle );
			throw sqle;
		} finally {
			session.getBatcher().closeStatement(st);
		}	
	}
	
	/** Generate Existing Object SQL */
	protected String generateExistingObjectSql( Object obj ) {
		StringBuffer sb = new StringBuffer();
		sb.append("select addressId as id from ");
		sb.append( tableName );
		sb.append( " where 1=1 ");
		sb.append( "and streetAddress = ? ");
		sb.append( "and city = ? ");
		sb.append( "and state = ? ");
		sb.append( "and zipcode = ? ");
		return sb.toString();
	}

}
