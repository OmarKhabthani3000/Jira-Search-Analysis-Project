/*
 * ReuseExistingPersister.java
 *
 * Created on Tue Aug 17 13:51:58 EDT 2004   
 */

package com.deg.helix.util.hibernate.persistence;

import net.sf.hibernate.persister.*;
import net.sf.hibernate.mapping.*;
import net.sf.hibernate.engine.*;
import net.sf.hibernate.loader.*;
import net.sf.hibernate.HibernateException;
import java.io.Serializable;
import org.apache.log4j.Logger;
import java.sql.ResultSet;

public class ReuseExistingPersister extends EntityPersister {
	
	/** Logger - Log is never enough! */
	protected Logger logger = Logger.getLogger( ReuseExistingPersister.class );
	
	/** Factory */
	protected SessionFactoryImplementor factory = null;
	
	/** Constructor */
	public ReuseExistingPersister(PersistentClass model, SessionFactoryImplementor factory) throws HibernateException {
		super( model, factory );	
		this.factory = factory;
	}
	
	/** Insert Method with Primary Key */
	public void insert(Serializable id, Object[] fields, boolean[] notNull, String sql, Object object, SessionImplementor session) throws HibernateException {
		boolean alreadyExists = doesObjectExist( id, object, session );    
		if ( !alreadyExists)
			super.insert( id, fields, notNull, sql, object, session );
	}
	
	/** Does Object Exist */
	protected boolean doesObjectExist( Serializable id, Object optionalObject, SessionImplementor session ) throws HibernateException {
		try {
			UniqueEntityLoader loader = createEntityLoader(factory);
			Object obj = loader.load(session, id, optionalObject);	
			if ( obj == null ) {
				return false;
			} else {
				return true;
			}
		} catch ( java.sql.SQLException se ) {
			logger.error( se );
			throw new HibernateException( se.getMessage() );
		}
	}

}
