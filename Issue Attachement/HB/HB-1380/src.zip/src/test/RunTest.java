/*
 * Created on 7/01/2005
 *
 */
package test;

import java.util.List;
import java.util.Properties;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Query;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.cfg.Environment;

/**
 * @author Jason
 * 
 */
public class RunTest {

    public static void main(String args[]) {
        try {
            new RunTest().runTest();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private final SessionFactory sessions;

    private RunTest() {
        try {
            Configuration cfg = new Configuration();

            cfg.addResource("test/TestObject.hbm.xml");
            Properties props = new Properties();
            props.setProperty(Environment.DIALECT,
                    "net.sf.hibernate.dialect.MySQLDialect");
            props.setProperty(Environment.USER, "root");
            props.setProperty(Environment.PASS, "letmein");
            props.setProperty(Environment.URL,
                    "jdbc:mysql://localhost/test?autoReconnect=true");
            props.setProperty(Environment.DRIVER, "com.mysql.jdbc.Driver");
            props.setProperty(Environment.CACHE_PROVIDER,
                    "net.sf.hibernate.cache.EhCacheProvider");
            props.setProperty(Environment.USE_QUERY_CACHE, "true");
            props.setProperty(Environment.SHOW_SQL, "true");
            cfg.setProperties(props);

            sessions = cfg.buildSessionFactory();
        } catch (HibernateException he) {
            throw new RuntimeException(he);
        }
    }

    private void runTest() throws Exception {

        List all = getAll();

        //clear the db
        for (int i = 0; i < all.size(); i++) {
            TestObject o = (TestObject) all.get(i);
            delete(o);
        }
        

        TestObject o = new TestObject();
        o.setText("my test obj 1");
        
        TestObject o2 = new TestObject();
        o2.setText("my test obj 2");

        //insert 2 new obj into empty db
        TxSession txSession = start();
        txSession.s.saveOrUpdate(o);
        txSession.s.saveOrUpdate(o2);
        end(txSession);

        //update to force a flush of the query cache and set the test case up
        o.setText("my test obj 1 - updated");
        txSession = start();
        txSession.s.saveOrUpdate(o);
        end(txSession);
        
        //current state of query in cache
        all = getAll();
        System.out.println("Current state of query in cache, 2 objects, 1 updated: " + all);
        
        //test update
        o2.setText("my test obj 2 - updated");
        txSession = start();
        txSession.s.saveOrUpdate(o2);
        end(txSession);
        
        //current state of query in cache
        all = getAll();
        System.out.println("Current state of query in cache, 2 objects, 2 updated: " + all);
        
        //test delete
        delete(o2);

        //current state of query in cache
        all = getAll();
        System.out.println("Current state of query in cache, object 1 only: " + all);

        TestObject o3 = new TestObject();
        o3.setText("my test obj 3");

        //test insert
        txSession = start();
        txSession.s.saveOrUpdate(o3);
        end(txSession);
        
        //current state of query in cache
        all = getAll();
        System.out.println("Current state of query in cache should be, 2 objects, 1 & 3: " + all);
    }
    
    private void delete(TestObject o) throws HibernateException {
        TxSession txSession = start();
        
        txSession.s.delete(o);
        
        end(txSession);
    }

    //caching the get all query
    private List getAll() throws HibernateException {
        TxSession txSession = start();
        try {
            Query q = txSession.s
                    .createQuery("select n from test.TestObject as n");
            q.setCacheable(true);
            return q.list();
        } finally {
            end(txSession);
        }
    }

    class TxSession {
        private final Session s;

        private final Transaction tx;

        private TxSession(Session s, Transaction tx) {
            this.s = s;
            this.tx = tx;
        }
    }

    private TxSession start() throws HibernateException {
        Session session = sessions.openSession();

        Transaction tx = session.beginTransaction();

        return new TxSession(session, tx);
    }

    private void end(TxSession txSession) throws HibernateException {
        txSession.tx.commit();

        txSession.s.flush();
        txSession.s.close();
    }
}