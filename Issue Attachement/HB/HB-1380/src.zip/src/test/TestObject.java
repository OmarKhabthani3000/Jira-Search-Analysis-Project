/*
 * Created on 7/01/2005
 */
package test;

import java.io.Serializable;


/**
 * @author Jason
 *
 */
public class TestObject implements Serializable {
    private Long id;

    private int version;
    
    private String text;
    
    
    /**
     * @return Returns the id.
     */
    public Long getId() {
        return id;
    }
    /**
     * @param id The id to set.
     */
    public void setId(Long id) {
        this.id = id;
    }
    /**
     * @return Returns the version.
     */
    public int getVersion() {
        return version;
    }
    /**
     * @param version The version to set.
     */
    public void setVersion(int version) {
        this.version = version;
    }
    public int hashCode() {
        return (id != null ? id.hashCode() : 0);
    }
    
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null) return false;
        
        if (o.getClass() != this.getClass()) return false;
        
        return id != null ? id.equals(((TestObject)o).id) : id == ((TestObject)o).id; 
    }
    
    /**
     * @return Returns the text.
     */
    public String getText() {
        return text;
    }
    /**
     * @param text The text to set.
     */
    public void setText(String text) {
        this.text = text;
    }
    
    public String toString() {
        return "ID: " + id  + ", text: " + text + ", version: " + version;
    }
}
