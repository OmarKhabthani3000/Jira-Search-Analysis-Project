//$Id$
package net.sf.hibernate.dialect;

/**
 * An SQL dialect compatible with MS SQL Server.
 * @author <a href="mailto:jkristian@docent.com">John Kristian</a>
 */
public class MicrosoftSQLServerDialect extends SybaseDialect {

	/**
	 * Use the SQL server idiom "insert table(...) values(...) select SCOPE_IDENTITY()".
	 */
	public String addIdentitySelectToInsert(String insertSQL) {
		return insertSQL + " select SCOPE_IDENTITY()";
	}

}
