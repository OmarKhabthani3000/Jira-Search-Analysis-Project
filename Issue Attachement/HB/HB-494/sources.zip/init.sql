create table ORGANIZATION
(
  ORGANIZATION_ID NUMBER not null,
  NAME VARCHAR2(50) not null,
  WORKING_TIME_SET_ID NUMBER
);

create table PROJECT
(
  PROJECT_ID NUMBER not null,
  NAME VARCHAR2(50) not null
);

create table PROJECT_ORGANIZATION
(
  PROJECT_ID      NUMBER not null,
  ORGANIZATION_ID NUMBER not null,
  WEIGHT NUMBER not null
);

create table WORKING_TIME_SET
(
  WORKING_TIME_SET_ID NUMBER not null
);

create table WORKING_TIME
(
  WORKING_TIME_SET_ID NUMBER not null,
  WEEK_DAY NUMBER not null,
  WORKING_TIME_START DATE not null,
  WORKING_TIME_END DATE not null,
  IS_WORKING_DAY NUMBER(1) not null
);


insert into project (project_id, name) values (1, 'test');
insert into project_organization (project_id, organization_id, weight) values (1, 100, 0);
insert into organization (organization_id, name, working_time_set_id) values (100, 'org', 200);
insert into working_time_set (working_time_set_id) values (200);
insert into working_time (working_time_set_id, week_day, working_time_start, working_time_end, is_working_day) values (200, 0, sysdate, sysdate, 1);

