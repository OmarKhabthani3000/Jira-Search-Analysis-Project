public class ProjectOrganization
{
    private Organization organization;
    private double weight;

    public int hashCode()
    {
        return (organization == null) ? 0 : organization.hashCode();
    }

    public boolean equals(Object object)
    {
        if (object == this)
            return true;
        else if ( !(object instanceof ProjectOrganization) )
            return false;

        ProjectOrganization other = (ProjectOrganization) object;

        return (organization == null) ? (other.getOrganization() == null) : organization.equals(other.getOrganization());
    }

    public Organization getOrganization()
    {
        return organization;
    }

    public void setOrganization(Organization organization)
    {
        this.organization = organization;
    }

    public double getWeight()
    {
        return weight;
    }

    public void setWeight(double weight)
    {
        this.weight = weight;
    }
}
