public class WorkingTimeSet
{
    private Long id;
    private WorkingTime[] times;

    public int hashCode()
    {
        return (id == null) ? 0 : id.hashCode();
    }

    public boolean equals(Object object)
    {
        if (object == this)
            return true;
        else if ( !(object instanceof WorkingTimeSet) )
            return false;

        WorkingTimeSet other = (WorkingTimeSet) object;

        return (id == null) ? (other.getId() == null) : id.equals(other.getId());
    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public WorkingTime[] getTimes()
    {
        return times;
    }

    public void setTimes(WorkingTime[] times)
    {
        this.times = times;
    }
}
