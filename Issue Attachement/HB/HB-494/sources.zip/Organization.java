public class Organization
{
    private Long id;
    private String name;
    private WorkingTimeSet workingTimeSet;

    public int hashCode()
    {
        return (id == null) ? 0 : id.hashCode();
    }

    public boolean equals(Object object)
    {
        if (object == this)
            return true;
        else if ( !(object instanceof Organization) )
            return false;

        Organization other = (Organization) object;

        return id == null ? (other.getId() == null) : id.equals(other.getId());
    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public WorkingTimeSet getWorkingTimeSet()
    {
        return workingTimeSet;
    }

    public void setWorkingTimeSet(WorkingTimeSet workingTimeSet)
    {
        this.workingTimeSet = workingTimeSet;
    }
}
