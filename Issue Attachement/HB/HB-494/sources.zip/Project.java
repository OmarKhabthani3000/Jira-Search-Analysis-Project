
import java.util.Set;

public class Project
{
    private Long id;
    private String name;
    private Set projectOrganizations;

    public int hashCode()
    {
        return (id == null) ? 0 : id.hashCode();
    }

    public boolean equals(Object object)
    {
        if (object == this)
            return true;
        else if ( !(object instanceof Project) )
            return false;

        Project other = (Project) object;

        return (id == null) ? (other.getId() == null) : id.equals(other.getId());
    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Set getProjectOrganizations()
    {
        return projectOrganizations;
    }

    public void setProjectOrganizations(Set projectOrganizations)
    {
        this.projectOrganizations = projectOrganizations;
    }

}
