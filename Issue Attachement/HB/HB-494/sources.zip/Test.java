
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.cfg.Configuration;

import java.sql.*;

/**
 * Created by IntelliJ IDEA.
 * User: dimas
 * Date: Nov 24, 2003
 * Time: 1:36:58 AM
 * To change this template use Options | File Templates.
 */
public class Test
{
    public static void main(String[] args)
    {
        SessionFactory sessionFactory = null;
        Configuration hibernateConfig = new Configuration();
        try
        {
            hibernateConfig.configure();
            sessionFactory = hibernateConfig.buildSessionFactory();
        }
        catch (HibernateException exception)
        {
            exception.printStackTrace(System.err);
            System.exit(0);
        }

        Connection conn = null;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@HOSTNAME:1521:SID", "USERNAME", "PASSWORD");
        }
        catch (Exception exception)
        {
            exception.printStackTrace(System.err);
            System.exit(0);
        }

        Session session = sessionFactory.openSession(conn);

        try
        {
            Project project = (Project) session.load(Project.class, new Long(1));

            project.getProjectOrganizations().iterator();
        }
        catch (HibernateException exception)
        {
            exception.printStackTrace(System.err);
            System.exit(0);
        }
    }
}
