import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;

/**
 * @author boringj
 *
 */
public class UserRoleDriver {
	
	private static SessionFactory sf = null;
	private static Configuration cfg = null;

	public static void main(String[] args) throws HibernateException {
		
		try {
			cfg = new Configuration();
			cfg.addClass(AppUser.class);
			cfg.addClass(Role.class);
			sf = cfg.buildSessionFactory();
		}
		catch (Exception e ){
			e.printStackTrace();
			return;
		}
		
		Session sess = null; Transaction xac = null;
		Role roleA = null; Role roleB = null; AppUser user = null; UserRole userxref = null;
		
		// TRANSACTION / UOW #1
		try {
			sess = sf.openSession();
			xac = sess.beginTransaction();
			
			roleA = new Role( new Long (1), "Role A");
			roleB = new Role( new Long (2), "Role B");
			user = new AppUser( new Long(100), "Jeff Boring ");
			
			userxref = new UserRole("Serving as role A on project", roleA, user );
			user.getRoles().add( userxref );
			
			sess.save( roleA );
			sess.save( roleB );
			sess.save( user );
			
			xac.commit();
		}
		catch (Exception e ){
			e.printStackTrace();
			xac.rollback();
		}
		finally {
			try {
				sess.close();
			} 
			catch (HibernateException e1) { e1.printStackTrace(); }
		}
		
		//	TRANSACTION / UOW #2
		 try {
			 sess = sf.openSession();
			 xac = sess.beginTransaction();
			 
			 roleB = (Role) sess.load( Role.class, new Long(2) );
			 user = (AppUser) sess.load( AppUser.class, new Long(100) );
			
			 userxref = new UserRole("Serving as role B on project", roleB, user );
			 user.getRoles().add( userxref );
			
			 sess.save( user );
			
			 xac.commit();
		 }
		 catch (Exception e ){
			 e.printStackTrace();
			 xac.rollback();
		 }
		 finally {
			 try {
				 sess.close();
			 } 
			catch (HibernateException e1) { e1.printStackTrace(); }
			}
		
		
	}
}
