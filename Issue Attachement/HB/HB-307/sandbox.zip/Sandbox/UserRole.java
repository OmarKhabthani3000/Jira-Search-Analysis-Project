import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class UserRole {
	private AppUser user;
	private Role role;
	private String noteComment;
	
	public UserRole( String parm, Role myRole, AppUser user ) {
		setNoteComment( parm );
		setRole( myRole );
		setUser( user );
	}
	
	public UserRole(  ) {}
	
	
	/**/
	public boolean equals(Object other) {
		if ( !(other instanceof UserRole) ) return false;
		UserRole castOther = (UserRole) other;
			return new EqualsBuilder()
					.append(this.getRole().getRoleskey(), castOther.getRole().getRoleskey() )
					.append(this.getUser().getUserskey(), castOther.getUser().getUserskey() )
					.isEquals();
	}

	public int hashCode() {
			return new HashCodeBuilder()
					.append( this.getRole().getRoleskey() )
					.append( this.getUser().getUserskey() )
					.toHashCode();
	}
	
	/**
	 * @return
	 */
	public Role getRole() {
		return role;
	}

	/**
	 * @return
	 */
	public AppUser getUser() {
		return user;
	}

	/**
	 * @param role
	 */
	public void setRole(Role role) {
		this.role = role;
	}

	/**
	 * @param user
	 */
	public void setUser(AppUser user) {
		this.user = user;
	}

	/**
	 * @return
	 */
	public String getNoteComment() {
		return noteComment;
	}

	/**
	 * @param string
	 */
	public void setNoteComment(String string) {
		noteComment = string;
	}

}	