public class Role {
	private Long roleskey;
	private String roleDescrip;
	
	
	public Role(  ) {}
	public Role( Long key, String descr ) {
		setRoleskey( key );
		setRoleDescrip( descr );
	}
	
	
	/**
	 * @return
	 */
	public Long getRoleskey() {
		return roleskey;
	}

	/**
	 * @param long1
	 */
	public void setRoleskey(Long long1) {
		roleskey = long1;
	}

	/**
	 * @return
	 */
	public String getRoleDescrip() {
		return roleDescrip;
	}

	/**
	 * @param string
	 */
	public void setRoleDescrip(String string) {
		roleDescrip = string;
	}

}	