import java.util.HashSet;
import java.util.Set;

public class AppUser {
	private Long userskey;
	private String Name;
	private Set roles = new HashSet();
	
	public AppUser(  ) {}
	public AppUser( Long key, String parm ) {
		setUserskey( key );
		setName( parm );
		
	}
	/**
	 * @return
	 */
	public String getName() {
		return Name;
	}

	/**
	 * @param string
	 */
	public void setName(String string) {
		Name = string;
	}

	/**
	 * @return
	 */
	public Set getRoles() {
		return roles;
	}

	/**
	 * @param set
	 */
	public void setRoles(Set set) {
		roles = set;
	}

	/**
	 * @return
	 */
	public Long getUserskey() {
		return userskey;
	}

	/**
	 * @param long1
	 */
	public void setUserskey(Long long1) {
		userskey = long1;
	}

}	