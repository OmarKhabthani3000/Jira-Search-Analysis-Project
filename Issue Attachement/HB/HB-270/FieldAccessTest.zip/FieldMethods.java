//$Id: Location.java,v 1.3 2003/01/05 02:11:23 oneovthafew Exp $
package net.sf.hibernate.test;

import java.io.Serializable;
import java.util.*;

import net.sf.hibernate.util.ReflectHelper;

public class FieldMethods
       extends FieldSuper 
       implements Serializable,ReflectHelper.AccessibleViaMethodsOnly {

	private int id;
	private String description;

	 void setId(int id) {
		this.id = id;
	}

	 int getId() {
		return id;
	}

	 void setDescription(String d) {
            description = d;
  	}

	 String getDescription() {
            return description;
  	}
}






