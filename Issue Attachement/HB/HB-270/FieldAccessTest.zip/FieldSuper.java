//$Id: Location.java,v 1.3 2003/01/05 02:11:23 oneovthafew Exp $
package net.sf.hibernate.test;

import java.io.Serializable;
import java.util.Locale;

import net.sf.hibernate.util.ReflectHelper;

public class FieldSuper implements Serializable,ReflectHelper.AccessibleViaFieldsOnly {
	public Integer streetNumber;
	public String city;
	public String streetName;
}






