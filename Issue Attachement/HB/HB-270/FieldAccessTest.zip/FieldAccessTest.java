//$Id: FumTest.java,v 1.5 2003/06/15 12:45:08 oneovthafew Exp $
package net.sf.hibernate.test;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import junit.framework.Test;
import junit.framework.TestSuite;
import net.sf.hibernate.Hibernate;
import net.sf.hibernate.LockMode;
import net.sf.hibernate.Query;
import net.sf.hibernate.Session;
import net.sf.hibernate.dialect.MckoiDialect;
import net.sf.hibernate.type.DateType;
import net.sf.hibernate.type.EntityType;
import net.sf.hibernate.type.StringType;
import net.sf.hibernate.type.Type;

public class FieldAccessTest extends TestCase {
	
	public FieldAccessTest(String arg) {
		super(arg);
	}
		
	public void testBasic() throws Exception {
		Session s = sessions.openSession();

                FieldSibling fs = new FieldSibling();
                fs.id = 1;
                fs.name = "FooBar";
                s.save(fs);

		Field fld = new Field();
		fld.streetNumber = new Integer(1);
		fld.city = "SPb";
		fld.streetName = "Kulturi";
		fld.countryCode = "RU";
		fld.description = "no desc";
		fld.sibling = fs;
		s.save(fld);

		List list = s.find("from fld in class net.sf.hibernate.test.Field");
		assertEquals(1,list.size());
		
		list = s.find("select fld.sibling from fld in class net.sf.hibernate.test.Field where fld.sibling.name = 'FooBar'");
		assertEquals(1,list.size());

		s.delete( fld );
		s.flush();
		s.connection().commit();
		s.close();
	}
	
	public void testBadSetter() throws Exception {
		Session s = sessions.openSession();

                FieldBadSetter bs = new FieldBadSetter();
                s.save(bs);

		List list = s.find("from fld in class net.sf.hibernate.test.FieldBadSetter");
		assertEquals(1,list.size());
                bs = (FieldBadSetter)list.get(0); 

		s.flush();
		s.connection().commit();
		s.close();
        }

	public void testSubAccessibleViaMethodsSuperViaFields() throws Exception {
		Session s = sessions.openSession();

                FieldMethods bm = new FieldMethods();
		bm.setId(5);
		bm.setDescription("foo");
                s.save(bm);

		List list = s.find("from fld in class net.sf.hibernate.test.FieldMethods");
		assertEquals(1,list.size());

		s.flush();
		s.connection().commit();
		s.close();
        }

	public static Test suite() throws Exception {
		try {
			TestCase.exportSchema( new String[] {
				"Field.hbm.xml"
			} );
			return new TestSuite(FieldAccessTest.class);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
}







