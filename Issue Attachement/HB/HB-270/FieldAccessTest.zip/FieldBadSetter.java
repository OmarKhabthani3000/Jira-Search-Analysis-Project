//$Id: Location.java,v 1.3 2003/01/05 02:11:23 oneovthafew Exp $
package net.sf.hibernate.test;

import java.io.Serializable;
import java.util.*;

import net.sf.hibernate.util.ReflectHelper;

public class FieldBadSetter extends FieldSuper implements ReflectHelper.AccessibleViaFieldsOnly {

  Integer id;

  public void setCity(int n)
  {
    throw new IllegalArgumentException("wrong setter");
  }

}






