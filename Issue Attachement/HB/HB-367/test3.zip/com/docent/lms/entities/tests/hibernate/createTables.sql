/** Create the tables used by the tests in this package.
 * These statements are in the SQL dialect of Microsoft SQL Server.
 */
CREATE TABLE DRPermission(
    ID                  int              IDENTITY(1,1),
    categoryID          int              NOT NULL,
    version             int              DEFAULT 1 NOT NULL,
    code                nvarchar(255)     NULL,
    permissionString    nvarchar(255)     NOT NULL,
    description         nvarchar(2000)    NULL,
    CONSTRAINT DRPK20 PRIMARY KEY CLUSTERED (ID)
)

CREATE INDEX DRRef203450 ON DRPermission(categoryID)

CREATE UNIQUE INDEX DRPermissionCode on DRPermission(code)

CREATE TABLE DRRole(
    ID             int              IDENTITY(1,1),
    version        int              DEFAULT 1 NOT NULL,
    name           nvarchar(255)     NULL,
    description    nvarchar(2000)    NULL,
    CONSTRAINT DRPK19 PRIMARY KEY CLUSTERED (ID)
)

CREATE INDEX i_DRRole_name ON DRRole(name)

CREATE UNIQUE INDEX DRRoleName on DRRole(name)

CREATE TABLE DRRolePermissionMap(
    roleID          int    NOT NULL,
    permissionID    int    NOT NULL,
    version         int    DEFAULT 1 NOT NULL,
    isGrant         int    NULL,
    CONSTRAINT DRPK21 PRIMARY KEY CLUSTERED (roleID, permissionID)
)

CREATE INDEX DRRef1930 ON DRRolePermissionMap(roleID)

CREATE INDEX DRRef2033 ON DRRolePermissionMap(permissionID)

ALTER TABLE DRRolePermissionMap ADD CONSTRAINT RefDRRole30 
    FOREIGN KEY (roleID)
    REFERENCES DRRole(ID)

ALTER TABLE DRRolePermissionMap ADD CONSTRAINT RefDRPermission33 
    FOREIGN KEY (permissionID)
    REFERENCES DRPermission(ID)

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_NAME', 'Can Change Others Name', 'Permission to change first and lastname fields for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_EMAIL', 'Can Change Others Email', 'Permission to change email field for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_PASSWORD', 'Can Change Others Password', 'Permission to change password fields for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_JOB_CATEGORY', 'Can Change Others Job Category', 'Permission to change job category field for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_MANAGER', 'Can Change Others Manager', 'Permission to change manager field for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_ROLES', 'Can Change Others Roles', 'Permission to change role assignments for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_DOMAINS', 'Can Change Others Domains', 'Permission to change domain assignments for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_LOCALE', 'Can Change Others Locale', 'Permission to change locale field for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_TIMEZONE', 'Can Change Others Timezone', 'Permission to change timezone field for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_CURRENCY', 'Can Change Others Currency', 'Permission to change the currency field for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_LOCATION', 'Can Change Others Location', 'Permission to change the location field for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_STATUS', 'Can Change Others Status', 'Permission to change status field for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_DOCENT_LIVE_ACCOUNT', 'Can Change Others Docent Live Account', 'Permission to change Docent Live user account for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OWN_NAME', 'Can Change Own Name', 'Permission to change first and lastname fields on one''''s own user record (change your own name).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OWN_EMAIL', 'Can Change Own Email', 'Permission to change email field on one''''s own user record (change your own email address).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OWN_LOCALE', 'Can Change Own Locale', 'Permission to change locale field on one''''s own user record (change your own locale).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OWN_TIMEZONE', 'Can Change Own Timezone', 'Permission to change timezone field on one''''s own user record (change your own timezone).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OWN_CURRENCY', 'Can Change Own Currency', 'Permission to change the currency field on one''''s own user record (change your own currency).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OWN_LOCATION', 'Can Change Own Location', 'Permission to change the location field on one''''s own user record (change your own location).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OWN_DOCENT_LIVE_ACCOUNT', 'Can Change Own Docent Live Account', 'Permission to change Docent Live user account on one''''s own user record (change your own Docent Live account).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_ENROLL_ANYONE', 'Can Enroll Anyone', 'Permission to (batch) enroll any user, not only oneself and one''''s group members.', 3

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_OVERRIDE_LEARNING_ACTIVITY_PRICES', 'Can Override Learning Activity Prices', 'Permission to change the price of particular learning activity enrollments.', 4

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHARGE_AGAINST_ANY_ACCOUNT', 'Can Charge Against Any Account', 'Permission to charge against any account, not only those assigned to the user.', 4

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CDSReport:student_report', 'CDSReport:student_report', 'Permission to launch student CDS reports', 5

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CDSReport:instructor_report', 'CDSReport:instructor_report', 'Permission to launch instructor CDS reports', 5

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CDSReport:manager_report', 'CDSReport:manager_report', 'Permission to launch manager CDS reports', 5

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CDSReport:system_administrator_report', 'CDSReport:system_administrator_report', 'Permission to launch system administrator CDS reports', 5

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CDSReport:training_coordinator_report', 'CDSReport:training_coordinator_report', 'Permission to launch training coordinator CDS reports', 5

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_OTHERS_WAITLIST_PRIORITY', 'Can Change Others Waitlist Priority', 'Permission to change the waitlist priority field for users other than oneself (administrative).', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_ADD_PERSONAL_LEARNING_ACTIVITY', 'Can Add Personal Learning Activity', 'Permission to request a personal learning activity', 6

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_APPROVE_PERSONAL_LEARNING_ACTIVITY', 'Can Approve Personal Learning Activity', 'Permission to approve a personal learning activity', 7

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'ACCESS_PEAK', 'Access Peak', 'Work with the Docent Peak Performance server', 8

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_DELETE_MESSAGES', 'Can Delete Messages', 'Can delete messages', 8

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_EDIT_MESSAGES', 'Can Edit Messages', 'Can edit messages', 8

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_REFUND_AMOUNT', 'Can Change Refund Amount', 'Can change the refund amount for the users in the event of their unenrollment or no-show', 4

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_EDIT_SESSION_CODE', 'Can Edit Session Code', 'Can change the auto-generated code of a Learning Activity session.', 10

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_ENROLLED_STATUS_TO_NO_SHOW', 'Can Change Enrolled Status to No-Show', 'Can change enrolled enrollment status to no-show enrollment status', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_CHANGE_WAITLIST_STATUS_TO_ENROLLED', 'Can Change Waitlist Status to Enrolled', 'Can grant enrolled enrollment status to students on the waitlist', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'VIEW_OWN_LEARNING_PLAN', 'View Own Learning Plan', 'User can view own learning plan.', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'ADD_TO_OWN_LEARNING_PLAN', 'Add To Own Learning Plan', 'User can manage items they add to their own learning plan.', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_OWN_LEARNING_PLAN', 'Manage Own Learning Plan', 'User can manage all items on their learning plan.', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'VIEW_SUBORDINATES_LEARNING_PLAN', 'View Subordinates Learning Plan', 'Managers can view their cascaded reports learning plans.', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'ADD_TO_SUBORDINATES_LEARNING_PLAN', 'Add To Subordinates Learning Plan', 'Manager can manage items they have added to their cascaded reports learning plans.', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_SUBORDINATES_LEARNING_PLAN', 'Manage Subordinates Learning Plan', 'Manager can manage all items on their cascaded reports learning plans.', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'VIEW_ALL_LEARNING_PLAN', 'View All Learning Plan', 'Can view any learning plan.', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'ADD_TO_ALL_LEARNING_PLAN', 'Add To All Learning Plan', 'User can manage items they have added to any learning plan.', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_ALL_LEARNING_PLAN', 'Manage All Learning Plan', 'Use can manage all items on any learning plan.', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_ACCESS_DOCENT_ANALYTICS', 'Can Access Docent Analytics', 'User can access Docent Analytics.', 8

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'VIEW_MY_LEARNING', 'View My Learning', 'View My Learning', 11

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'BROWSE_CATALOG', 'Browse Catalog', 'Browse Catalog', 11

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'VIEW_MANAGER_TAB', 'View Manager Tab', 'View Manager Tab', 11

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'VIEW_INSTRUCTOR_TAB', 'View Instructor Tab', 'View Instructor Tab', 11

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'VIEW_ADMINISTRATION_TAB', 'View Administration Tab', 'View Administration Tab', 11

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'ALWAYS_GRANTED', 'Always Granted', 'Always Granted', 6

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'VIEW_LEARNING_ADMIN_SUBMENU', 'View Learning Admin Submenu', 'View Learning Admin Submenu', 11

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_ADMIN_REPORTS', 'Run Admin Reports', 'Run Admin Reports', 11

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'VIEW_SYSTEM_ADMIN_SUBMENU', 'View System Admin Submenu', 'View System Admin Submenu', 11

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_LEARNING_ACTIVITIES', 'Manage Learninng Activities', 'Manage Learning Activities', 9

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_COMPETENCIES', 'Manage Competencies', 'Manage Competencies', 9

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_CATALOG_SECTIONS', 'Manage Catalog Sections', 'Manage Catalog Sections', 9

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_RESOURCES', 'Manage Resources', 'Manage Resources', 9

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_SCORE_MAPS', 'Manage Score Maps', 'Manage Score Maps', 9

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_FORUMS', 'Manage Forums', 'Manage Forums', 9

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_GROUP_LEARNING_PLANS', 'Manage Group Learning Plans', 'Manage Group Learning Plans', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_BATCH_ENROLL', 'Can Batch Enroll', 'Can Batch Enroll', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_ENROLLMENTS', 'Manage Enrollments', 'Manage Enrollments', 2

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_USERS', 'Manage Users', 'Manage Users', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_AUDIENCES', 'Manage Audiences', 'Manage Audiences', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_ACCOUNTS', 'Manage Accounts', 'Manage Accounts', 4

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_JOB_CATEGORIES', 'Manage Job Categories', 'Manage Job Categories', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_LOCATIONS', 'Manage Locations', 'Manage Locations', 1

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_ENROLLMENT_REPORTS', 'Run Enrollment Reports', 'Run Enrollment Reports', 5

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_REVENUE_REPORTS', 'Run Revenue Reports', 'Run Revenue Reports', 5

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_EXPENSE_REPORTS', 'Run Expense Reports', 'Run Expense Reports', 5

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_LEARNING_ACTIVITY_RESULTS_REPORTS', 'Run Learning Activity Results Reports', 'Run Learning Activity Results Reports', 5

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_CDS_REPORTS', 'Run CDS Reports', 'Run CDS Reports', 5

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_RESOURCE_REPORTS', 'Run Resource Reports', 'Run Resource Reports', 5

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_DOMAINS', 'Manage Domains', 'Manage Domains', 12

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_DOMAIN_REPORTS', 'Run Domain Reports', 'Run Domain Reports', 12

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_AUDIT_TRAIL_REPORT_FOR_USERS', 'Run Audit Report For Users', 'Run Audit Report For Users', 13

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_AUDIT_TRAIL_REPORT_FOR_LEARNING_ACTIVITIES', 'Run Audit Report For Learning Activities', 'Run Audit Report For Learning Activities', 13

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_AUDIT_TRAIL_REPORT_FOR_GROUP_LEARNING_PLANS', 'Run Audit Report For Group Learning Plans', 'Run Audit Report For Group Learning Plans', 13

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_SYSTEM_REPORTS', 'Run System Reports', 'Run System Reports', 14

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_ROLES_AND_PERMISSIONS', 'Manage Roles and Permissions', 'Manage Roles and Permissions', 14

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_SERVERS', 'Manage Servers', 'Manage Servers', 14

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_AUTOMATED_TASKS', 'Manage Automated Tasks', 'Manage Automated Tasks', 14

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_SYSTEM_PARAMETERS', 'Manage System Parameters', 'Manage System Parameters', 14

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_PASSWORD_POLICIES', 'Manage Password Policies', 'Manage Password Policies', 14

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'ADMINISTER_ELECTRONIC_SIGNATURE', 'Administer Electronic Signature', 'Administer Electronic Signature', 14

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_EMAIL_SETUP', 'Manage Email Setup', 'Manage Email Setup', 15

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_NOTIFICATIONS', 'Manage Notifications', 'Manage Notifications', 15

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_E-COMMERCE_SERVER', 'Manage E-Commerce Server', 'Manage E-Commerce Server', 16

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_CURRENCY_SETUP', 'Manage Currency Setup', 'Manage Currency Setup', 16

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_EXCHANGE_RATE', 'Manage Exchange Rate', 'Manage Exchange Rate', 16

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT '360-DEGREE_ASSESSMENTS', '360-Degree Assessments', '360-Degree Assessments', 7

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_COMPETENCY_AND_GAP_REPORT', 'Run Competency And Gap Report', 'Run Competency And Gap Report', 7

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'SELF_ENROLL', 'Self Enroll', 'Self Enroll', 6

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'RUN_XML_BASED_REPORTS', 'Run XML Based Reports', 'Run XML Based Reports', 5

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_PAY_BY_ACCOUNT', 'Can Pay By Account', 'Can Pay By Account', 4

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_PAY_WITH_MULTIPLE_ACCOUNTS', 'Can Pay By Multiple Accounts', 'Can Pay By Multiple Accounts', 4

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_CDS_REPORTS', 'Manage CDS Reports', 'Manage CDS Reports', 5

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_RETURN_FROM_CONTENT_DELIVERY_SERVERS', 'Can Return From Content Delivery Servers', 'Can Return From Content Delivery Servers', 8

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'USE_FORUMS', 'Use Forums', 'Use Forums', 8

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_ACCESS_WEB_SERVICES', 'Can Access Web Services', 'Web Services permission', 8

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_SELF', 'Manage Self', 'Manage Self Profile', 11

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'MANAGE_SUBORDINATE_USERS', 'Manage Subordinate Users', 'Manage Group Members', 7

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'CAN_ACCESS_CENTRA', 'Can Access Centra', 'Can Access Centra', 8

INSERT INTO DRPermission (code, permissionString, description, categoryId)
 SELECT 'EDIT_USERS', 'Edit Users', 'Edit Users', 1

insert into DRRole (Name, Description)
VALUES ('Student', 'All users in the system are Students by default.  Students have access to course catalogs, enrollment screens, and the search screen')

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'CDSReport:student_report'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'ACCESS_PEAK'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'CAN_CHANGE_OWN_NAME'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'CAN_CHANGE_OWN_EMAIL'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'CAN_CHANGE_OWN_LOCALE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'CAN_CHANGE_OWN_TIMEZONE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'CAN_CHANGE_OWN_CURRENCY'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'CAN_CHANGE_OWN_LOCATION'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'CAN_CHANGE_OWN_DOCENT_LIVE_ACCOUNT'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'CAN_ADD_PERSONAL_LEARNING_ACTIVITY'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'VIEW_OWN_LEARNING_PLAN'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'ADD_TO_OWN_LEARNING_PLAN'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'VIEW_MY_LEARNING'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'BROWSE_CATALOG'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'ALWAYS_GRANTED'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'RUN_CDS_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'SELF_ENROLL'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'RUN_XML_BASED_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'CAN_PAY_BY_ACCOUNT'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'CAN_RETURN_FROM_CONTENT_DELIVERY_SERVERS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'USE_FORUMS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'CAN_ACCESS_WEB_SERVICES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Student'
AND P.Code = 'MANAGE_SELF'

insert into DRRole (Name, Description)
VALUES ('Manager', 'Managers are users who manage students progress through the learning program')

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'BROWSE_CATALOG'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_RETURN_FROM_CONTENT_DELIVERY_SERVERS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CDSReport:manager_report'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'ACCESS_PEAK'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_CHANGE_OTHERS_NAME'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_CHANGE_OTHERS_EMAIL'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_CHANGE_OTHERS_PASSWORD'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_CHANGE_OTHERS_JOB_CATEGORY'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_CHANGE_OTHERS_LOCATION'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_CHANGE_OWN_NAME'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_CHANGE_OWN_EMAIL'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_CHANGE_OWN_LOCALE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_CHANGE_OWN_TIMEZONE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_CHANGE_OWN_CURRENCY'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_CHANGE_OWN_LOCATION'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_CHANGE_OWN_DOCENT_LIVE_ACCOUNT'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_APPROVE_PERSONAL_LEARNING_ACTIVITY'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'VIEW_SUBORDINATES_LEARNING_PLAN'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'MANAGE_SUBORDINATES_LEARNING_PLAN'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'VIEW_MANAGER_TAB'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'ALWAYS_GRANTED'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_BATCH_ENROLL'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'RUN_CDS_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = '360-DEGREE_ASSESSMENTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'RUN_COMPETENCY_AND_GAP_REPORT'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'RUN_XML_BASED_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_PAY_BY_ACCOUNT'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'CAN_PAY_WITH_MULTIPLE_ACCOUNTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'MANAGE_SELF'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'MANAGE_SUBORDINATE_USERS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Manager'
AND P.Code = 'MANAGE_GROUP_LEARNING_PLANS'

insert into DRRole (Name, Description)
VALUES ('Training Coordinator', 'Training Coordinators administer learning programs')

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CDSReport:training_coordinator_report'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_ENROLL_ANYONE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_OVERRIDE_LEARNING_ACTIVITY_PRICES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_CHARGE_AGAINST_ANY_ACCOUNT'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_CHANGE_REFUND_AMOUNT'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_CHANGE_WAITLIST_STATUS_TO_ENROLLED'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_CHANGE_ENROLLED_STATUS_TO_NO_SHOW'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_EDIT_SESSION_CODE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_CHANGE_OWN_NAME'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_CHANGE_OWN_EMAIL'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_CHANGE_OWN_LOCALE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_CHANGE_OWN_TIMEZONE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_CHANGE_OWN_CURRENCY'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_CHANGE_OWN_LOCATION'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_CHANGE_OWN_DOCENT_LIVE_ACCOUNT'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_EDIT_MESSAGES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_DELETE_MESSAGES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'VIEW_ALL_LEARNING_PLAN'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'MANAGE_ALL_LEARNING_PLAN'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'VIEW_ADMINISTRATION_TAB'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'ALWAYS_GRANTED'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'VIEW_LEARNING_ADMIN_SUBMENU'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'RUN_ADMIN_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'MANAGE_LEARNING_ACTIVITIES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'MANAGE_COMPETENCIES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'MANAGE_CATALOG_SECTIONS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'MANAGE_RESOURCES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'MANAGE_SCORE_MAPS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'MANAGE_FORUMS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'MANAGE_GROUP_LEARNING_PLANS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_BATCH_ENROLL'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'MANAGE_ENROLLMENTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'MANAGE_AUDIENCES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'MANAGE_ACCOUNTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'RUN_ENROLLMENT_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'RUN_CDS_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'RUN_RESOURCE_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'RUN_DOMAIN_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'RUN_AUDIT_TRAIL_REPORT_FOR_LEARNING_ACTIVITIES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'RUN_AUDIT_TRAIL_REPORT_FOR_GROUP_LEARNING_PLANS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'RUN_LEARNING_ACTIVITY_RESULTS_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'RUN_XML_BASED_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'MANAGE_CDS_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'USE_FORUMS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'MANAGE_SELF'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'CAN_ACCESS_CENTRA'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Training Coordinator'
AND P.Code = 'EDIT_USERS'

insert into DRRole (Name, Description)
VALUES ('Instructor', 'Instructors teach instructor led courses and input students'''' results from those courses into the system')

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CDSReport:instructor_report'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CAN_CHANGE_OWN_NAME'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CAN_CHANGE_OWN_EMAIL'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CAN_CHANGE_OWN_LOCALE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CAN_CHANGE_OWN_TIMEZONE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CAN_CHANGE_OWN_CURRENCY'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CAN_CHANGE_OWN_LOCATION'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CAN_CHANGE_OWN_DOCENT_LIVE_ACCOUNT'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CAN_EDIT_MESSAGES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CAN_DELETE_MESSAGES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CAN_CHANGE_ENROLLED_STATUS_TO_NO_SHOW'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'VIEW_INSTRUCTOR_TAB'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'ALWAYS_GRANTED'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'RUN_ADMIN_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CAN_BATCH_ENROLL'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'RUN_ENROLLMENT_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'RUN_REVENUE_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'RUN_EXPENSE_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'RUN_LEARNING_ACTIVITY_RESULTS_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'RUN_CDS_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CAN_RETURN_FROM_CONTENT_DELIVERY_SERVERS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'RUN_XML_BASED_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'USE_FORUMS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'MANAGE_SELF'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Instructor'
AND P.Code = 'CAN_ACCESS_CENTRA'

insert into DRRole (Name, Description)
VALUES ('System Administrator', 'System administrators administer users, locations, course delivery sites, system security, and ecommerce setup')

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CDSReport:system_administrator_report'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'ACCESS_PEAK'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_NAME'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_EMAIL'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_PASSWORD'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_JOB_CATEGORY'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_MANAGER'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_ROLES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_DOMAINS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_LOCALE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_TIMEZONE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_CURRENCY'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_LOCATION'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_STATUS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_WAITLIST_PRIORITY'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OTHERS_DOCENT_LIVE_ACCOUNT'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OWN_NAME'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OWN_EMAIL'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OWN_LOCALE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OWN_TIMEZONE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OWN_CURRENCY'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OWN_LOCATION'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_CHANGE_OWN_DOCENT_LIVE_ACCOUNT'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'VIEW_ADMINISTRATION_TAB'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'ALWAYS_GRANTED'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'VIEW_LEARNING_ADMIN_SUBMENU'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'RUN_ADMIN_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'VIEW_SYSTEM_ADMIN_SUBMENU'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_USERS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_JOB_CATEGORIES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_LOCATIONS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'RUN_REVENUE_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'RUN_EXPENSE_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'RUN_LEARNING_ACTIVITY_RESULTS_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'RUN_CDS_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_DOMAINS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'RUN_DOMAIN_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'RUN_AUDIT_TRAIL_REPORT_FOR_USERS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'RUN_SYSTEM_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_ROLES_AND_PERMISSIONS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_SERVERS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_AUTOMATED_TASKS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_SYSTEM_PARAMETERS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_PASSWORD_POLICIES'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'ADMINISTER_ELECTRONIC_SIGNATURE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_EMAIL_SETUP'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_NOTIFICATIONS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_E-COMMERCE_SERVER'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_CURRENCY_SETUP'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_EXCHANGE_RATE'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'RUN_XML_BASED_REPORTS'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'MANAGE_SELF'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'CAN_ACCESS_CENTRA'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'System Administrator'
AND P.Code = 'EDIT_USERS'

insert into DRRole (Name, Description)
VALUES ('Anonymous', 'The anonymous user belongs to this role by default.  Any user who does not log into the system will have the permissions granted to this role')

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Anonymous'
AND P.Code = 'BROWSE_CATALOG'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Anonymous'
AND P.Code = 'ALWAYS_GRANTED'

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Anonymous'
AND P.Code = 'CAN_RETURN_FROM_CONTENT_DELIVERY_SERVERS'

insert into DRRole (Name, Description)
VALUES ('Analytics: User', 'Analytics users can access Docent Analytics as a basic user.')

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Analytics: User'
AND P.Code = 'CAN_ACCESS_DOCENT_ANALYTICS'

insert into DRRole (Name, Description)
VALUES ('Analytics: Analyst', 'Analysts can access Docent Analytics as a power user.')

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Analytics: Analyst'
AND P.Code = 'CAN_ACCESS_DOCENT_ANALYTICS'

insert into DRRole (Name, Description)
VALUES ('Web Services Admin', 'Web Services Admin role. Only users in this role can use web services.')

insert into DRRolePermissionMap (RoleID, PermissionID, IsGrant)
SELECT R.ID, P.ID, 1
FROM DRRole R, DRPermission P
WHERE R.Name = 'Web Services Admin'
AND P.Code = 'CAN_ACCESS_WEB_SERVICES'
