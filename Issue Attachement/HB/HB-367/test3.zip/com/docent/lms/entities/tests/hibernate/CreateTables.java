package com.docent.lms.entities.tests.hibernate;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.SQLException;
import java.sql.Statement;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** Create the database tables and data that are necessary to run tests in this package.
 *
 * @author Copyright (c) 2003 by Docent, Inc.  All Rights Reserved.
 * @author <a href="mailto:jkristian@docent.com?subject=tests.hibernate.CreateTables">John Kristian</a>
 */
public class CreateTables {

    public static void main(String[] args)
    {
        Configuration configuration = new Configuration();
        try {
            SessionFactory sessionFactory = configuration.buildSessionFactory();
            try {
                Transaction transaction = null;
                Session session = sessionFactory.openSession();
                try {
                    transaction = session.beginTransaction();
                    Statement statement = session.connection().createStatement();
                    try {
                        BufferedReader file = new BufferedReader(new FileReader("createTables.sql"));
                        try {
                            String line;
                            do {
                                StringBuffer sql = new StringBuffer();
                                while ((line = file.readLine()) != null && line.trim().length() > 0) {
                                    if (sql.length() > 0) sql.append("\n");
                                    sql.append(line);
                                }
                                log.info(sql.toString());
                                try {
                                    statement.executeUpdate(sql.toString());
                                } catch(SQLException e) {
                                    log.error(e);
                                }
                            } while (line != null);
                        } finally {file.close();}
                    } finally {statement.close();}
                    transaction.commit();
                    transaction = null;
                } finally {
                    if (transaction != null) try {
                        transaction.rollback();
                    } catch(Exception e) {
                        log.error("transaction.rollback: " + e);
                    }
                    session.close();
                }
            } finally {sessionFactory.close();}
        } catch(Throwable e) {
            log.error("failed", e);
        }
    }

    protected static final Log log = LogFactory.getLog(CreateTables.class);

}
