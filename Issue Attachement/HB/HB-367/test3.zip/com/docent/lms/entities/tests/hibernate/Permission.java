package com.docent.lms.entities.tests.hibernate;

import java.util.Set;

/** A permission in an access control system.
 *
 * @author Copyright (c) 2003 by Docent, Inc.  All Rights Reserved.
 * @author <a href="mailto:jkristian@docent.com">John Kristian</a>
 */
public class Permission extends Entity {

    /** Identifier equality (ids are equal). */
    public boolean equals(Object that)
    {
        return (getId() == null) ? super.equals(that) /* Java object identity */ :
            ((that instanceof Permission) && getId().equals(((Permission)that).getId())); /* database id */
    }

    /** Identifier equality (ids are equal). */
    public int hashCode()
    {
        return (getId() == null) ? super.hashCode() /* Java object identity */ :
            getId().hashCode(); /* database id */
    }

    public String toString()
    {
        return "Permission#" + getId() + "@" + instance;
    }

    public Long getId()
    {return id;}
    private void setId(Long id)
    {
        log.debug(this + ".setId(" + id + ")");
        this.id = id;
    }
    private Long id;

    public long getVersion()
    {return version;}
    private void setVersion(long version)
    {this.version = version;}
    private long version;

    public String getCode()
    {return code;}
    public void setCode(String code)
    {this.code = code;}
    private String code;

    public Set getAssociations()
    {return associations;}
    private void setAssociations(Set associations)
    {this.associations = associations;}
    private Set associations; // contains RolePermissionAssociations

}
