package com.docent.lms.entities.tests.hibernate;

import java.util.Iterator;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.MappingException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** Test caching of associations between roles and permissions.
 *
 * @author Copyright (c) 2003 by Docent, Inc.  All Rights Reserved.
 * @author <a href="mailto:jkristian@docent.com?subject=tests.hibernate.Scan">John Kristian</a>
 */
public class Scan {

    public static void main(String[] args)
    {
        try {
            testScan(); 
        } catch(Throwable ignored) {}
    }

    /** Read associations between roles and permissions, in two consecutive sessions.
     * The first session copies objects from the database to the global JCS cache;
     * the second session find the same objects in the cache.
     */
    public static void testScan()
        throws Throwable
    {
        String testName = "testScan";
        log.info(testName);
        try {
            SessionFactory sessionFactory = buildSessionFactory();
            try {
                Session session = openSession(sessionFactory, new Context());
                try {
                    scan(session);
                    session.close();
                    session = openSession(sessionFactory, new Context());
                    scan(session);
                } finally {
                    session.close();
                }
            } finally {
                sessionFactory.close();
            }
        } catch(Throwable e) {
            log.error(testName + " failed", e);
            throw e; // report this error to JUnit
        }
    }

    protected static void scan(Session session)
        throws HibernateException
    {
        for (Iterator i = session.iterate("FROM entity IN CLASS " + Role.class.getName()); i.hasNext(); ) {
            Role role = (Role)(i.next());
            for (Iterator j = role.getAssociations().iterator(); j.hasNext(); ) {
                RolePermissionAssociation association = (RolePermissionAssociation)(j.next());
                Permission permission = association.getId().getPermission();
                if (!role.getAssociations().contains(association)) {
                    log.error("!" + role + ".associations.contains(" + association + ")");
                }
                if (!permission.getAssociations().contains(association)) {
                    log.error("!" + permission + ".associations.contains(" + association + ")");
                }
            }
        }
    }

    protected static Session openSession(SessionFactory factory, Context context)
        throws HibernateException
    {
        Session session = factory.openSession(context);
        context.setSession(session);
        return session;
    }

    static SessionFactory buildSessionFactory()
        throws Exception
    {
        configureClass(Permission.class);
        configureClass(Role.class);
        configureClass(RolePermissionAssociation.class);
        return configuration.buildSessionFactory();
    }

    protected static void configureClass(Class persistentClass)
        throws MappingException
    {
        if (configuration.getClassMapping(persistentClass) == null) {
            configuration.addClass(persistentClass);
        }
    }

    static Configuration configuration = new Configuration();

    protected static final Log log = LogFactory.getLog(Scan.class);

}
