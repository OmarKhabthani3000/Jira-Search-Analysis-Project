Here is a test case for a problem with Hibernate, reported as
http://opensource.atlassian.com/projects/hibernate/secure/ViewIssue.jspa?key=HB-367

See Scan.java for the code that elicited the problem (I ran it via Scan.bat).
See log.txt for an example stack trace, with preceding DEBUG level logging.
To create tables and test data, run CreateTables.bat (after localizing run.bat).

Part of the problem, it appears, is that Hibernate uses a RolePermissionAssociation$Id
as a key for a JCS region map, but the Id refers to a Role whose id has not been loaded.
Subsequently, Hibernate loads the Role id, which changes the RolePermissionAssociation
Id.hashCode(), which causes the Id to be 'lost' in the JCS region map.  For example:

DEBUG [net.sf.hibernate.cache.ReadWriteCache] Cached: {Role#null@673, Permission#48@674}@675
DEBUG [net.sf.hibernate.impl.SessionImpl] done materializing entity [com.docent.lms.entities.tests.hibernate.RolePermissionAssociation#{Role#null@673, Permission#48@674}@675]
WARN  [com.docent.lms.entities.tests.hibernate.Role] Role#null@673.setId(8)

Eventually, the JCS region contains several such lost keys in its map but nothing in its
list (all entries were evicted because the map contains more keys than the cache size limit).
At this point, JCS throws the problematic exception.

The problem occurs faster if JCS is configured with a small cache size, as in cache.ccf:
jcs.default.cacheattributes.MaxObjects=10
But when MaxObjects is less than 10, the problem does not occur (surprisingly).

Alternative test data for Microsoft SQL Server can be created by executing DropTables.bat
and then createTables.sql (e.g. using Query Analyzer).  These test data elicit different
log output; in particular, Scan detects several lost entries in Hibernate collections:

ERROR [Scan] !Role#8@1045.associations.contains(RolePermissionAssociation#{Role#8@1045, Permission#48@1046}@1047)
ERROR [Scan] !Role#7@1049.associations.contains(RolePermissionAssociation#{Role#7@1049, Permission#48@1046}@1050)
ERROR [Scan] !Role#6@1058.associations.contains(RolePermissionAssociation#{Role#6@1058, Permission#54@1062}@1063)

- John Kristian <jkristian@docent.com>
