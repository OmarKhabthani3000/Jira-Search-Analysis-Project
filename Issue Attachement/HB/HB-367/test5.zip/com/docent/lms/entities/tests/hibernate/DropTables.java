package com.docent.lms.entities.tests.hibernate;

import net.sf.hibernate.tool.hbm2ddl.SchemaExport;

/** Create the database tables and data that are necessary to run tests in this package.
 *
 * @author Copyright (c) 2003 by Docent, Inc.  All Rights Reserved.
 * @author <a href="mailto:jkristian@docent.com?subject=tests.hibernate.CreateTables">John Kristian</a>
 */
public class DropTables {

    public static void main(String[] args)
        throws Exception
    {
        Scan.buildSessionFactory();
        (new SchemaExport(Scan.configuration)).drop(false, true);
    }

}
