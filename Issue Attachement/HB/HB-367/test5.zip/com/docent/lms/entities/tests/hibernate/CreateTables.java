package com.docent.lms.entities.tests.hibernate;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import net.sf.hibernate.Hibernate;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Query;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.tool.hbm2ddl.SchemaExport;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** Create the database tables and data that are necessary to run tests in this package.
 *
 * @author Copyright (c) 2003 by Docent, Inc.  All Rights Reserved.
 * @author <a href="mailto:jkristian@docent.com?subject=tests.hibernate.CreateTables">John Kristian</a>
 */
public class CreateTables {

    public static void main(String[] args)
        throws HibernateException
    {
        try {
            SessionFactory sessionFactory = Scan.buildSessionFactory();
            try {
                (new SchemaExport(Scan.configuration)).create(false, true);
                Transaction transaction = null;
                Session session = sessionFactory.openSession();
                try {
                    transaction = session.beginTransaction();
                    {
                        BufferedReader file = new BufferedReader(new FileReader("createPermissions.txt"));
                        try {
                            String line;
                            while ((line = file.readLine()) != null) {
                                line = line.trim(); 
                                if (line.length() <= 0) continue;
                                int space = line.indexOf(" ");
                                Permission permission = new Permission(line);
                                session.save(permission);
                            }
                        } finally {
                            file.close();
                        }
                    }
                    {
                        Query roleByName = session.createQuery
                            ("FROM o IN CLASS " + Role.class.getName() + " WHERE o.name = ?");
                        Query permissionByCode = session.createQuery
                            ("FROM o IN CLASS " + Permission.class.getName() + " WHERE o.code = ?");
                        BufferedReader file = new BufferedReader(new FileReader("createAssociations.txt"));
                        try {
                            String line;
                            while ((line = file.readLine()) != null) {
                                line = line.trim();
                                if (line.length() <= 0) continue;
                                int space = line.indexOf(" ");
                                if (space < 0) continue;
                                String permissionCode = line.substring(0, space);
                                String roleName = line.substring(space+1);
                                if (log.isInfoEnabled()) {
                                    log.info("new RolePermissionAssociation(" + roleName + ", " + permissionCode + ")");
                                }
                                RolePermissionAssociation association = new RolePermissionAssociation
                                    (new RolePermissionAssociation.Id(getRole(session, roleByName, roleName),
                                                                      getPermission(session, permissionByCode, permissionCode)));
                                session.save(association);
                            }
                        } finally {
                            file.close();
                        }
                    }
                    session.flush();
                    transaction.commit();
                    transaction = null;
                } finally {
                    if (transaction != null) try {
                        transaction.rollback();
                    } catch(Exception e) {
                        log.error("transaction.rollback: " + e);
                    }
                    session.close();
                }
            } finally {
                sessionFactory.close();
            }
        } catch(Throwable e) {
            log.error("failed", e);
        }
    }

    private static Role getRole(Session session, Query query, String name)
        throws HibernateException
    {
        Role result = (Role)(get(query, name));
        if (result == null) {
            result = new Role(name);
            session.save(result);
        }
        return result;
    }

    private static Permission getPermission(Session session, Query query, String code)
        throws HibernateException
    {
        Permission result = (Permission)(get(query, code));
        if (result == null) {
            result = new Permission(code);
            session.save(result);
        }
        return result;
    }

    private static Object get(Query query, String parameter)
        throws HibernateException
    {
        query.setParameter(0, parameter, Hibernate.STRING);
        Iterator i = query.iterate();
        return i.hasNext() ? i.next() : null;
    }

    protected static final Log log = LogFactory.getLog(CreateTables.class);

}
