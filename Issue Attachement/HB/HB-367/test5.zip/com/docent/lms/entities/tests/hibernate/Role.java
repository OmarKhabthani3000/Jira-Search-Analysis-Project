package com.docent.lms.entities.tests.hibernate;

import java.util.Set;

/** A role in a role-based access control system.
 *
 * @author Copyright (c) 2003 by Docent, Inc.  All Rights Reserved.
 * @author <a href="mailto:jkristian@docent.com">John Kristian</a>
 */
public class Role extends Entity {

    public Role() {}

    public Role(String name)
    {
        this.name = name;
    }

    /** Identifier equality (ids are equal). */
    public boolean equals(Object that)
    {
        return (getId() == null) ? super.equals(that) /* Java object identity */ :
            ((that instanceof Role) && getId().equals(((Role)that).getId())); /* database id */
    }

    /** Identifier equality (ids are equal). */
    public int hashCode()
    {
        if (getId() == null) {
            if (hashCoded++ < 2 && log.isDebugEnabled()) try {
                throw new RuntimeException();
            } catch(RuntimeException e) {
                log.debug(this + ".hashCode()", e);
            }
            return super.hashCode(); /* Java object identity */
        } else {
            hashCoded++;
            return getId().hashCode(); /* database id */
        }
    }

    private long hashCoded = 0;

    public String toString()
    {
        return "Role#" + getId() + "@" + instance;
    }

    public Long getId()
    {return id;}
    private void setId(Long id)
    {
        if (id != this.id && (id == null || ! id.equals(this.id))) {
            if (this.id == null || hashCoded != 0) {
                try {
                    throw new RuntimeException();
                } catch(RuntimeException e) {
                    log.warn(this + ".setId(" + id + ")", e);
                }
            } else if (log.isDebugEnabled()) {
                log.debug(this + ".setId(" + id + ")");
            }
        }
        this.id = id;
    }
    private Long id;

    public long getVersion()
    {return version;}
    private void setVersion(long version)
    {this.version = version;}
    private long version;

    public String getName()
    {return name;}
    private void setName(String name)
    {this.name = name;}
    private String name;

    public Set getAssociations()
    {return associations;}
    private void setAssociations(Set associations)
    {this.associations = associations;}
    private Set associations; // contains RolePermissionAssociations

}
