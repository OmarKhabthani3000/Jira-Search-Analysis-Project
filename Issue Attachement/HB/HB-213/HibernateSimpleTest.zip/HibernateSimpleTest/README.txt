This project is intended to be a very simple sandbox for 
testing issues with hibernate and for then submitting simple test cases to 
JIRA (issue tracking software for Hibernate).

The Ant script will create a directory named HibernateSimpleTest_lib 
as a sibling to the directory that HibernateSimpleTest itself is unzipped into.
(This avoids fiddling with deleting libs and stuff 
when zipping for submitting issues)

You should place JDBC and ancillary (runtime) jars in the 
HibernateSimpleTest_lib directory .
(such as log4j and p6spy jars)

You will need to edit etc/hibernate.properties in order to point it at your DB.
(if you use p6spy, edit the p6spy.properties file to point at your real driver)

If running the create.schema target, the hibernate.properties file will be
used as a properties file in order to connect to the DB.  This means
that you must make sure your JDBC driver is on app.run.classpath.  If 
you're using p6spy, remember that the p6spy jar and the directory (etc) that
p6spy.properties is in must be on the classpath and the p6spy.properties file
must point to the real driver name.

DO NOT add dependencies to test code that require anything to build other than
the jars that are distributed with hibernate.

