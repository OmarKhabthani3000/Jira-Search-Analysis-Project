/*
 * Name.java
 *
 * Created on 27 July 2003, 13:58
 */

package sbt.hb.test.contacts.domain;

/**
 *
 * @author  TolleyS
 */
public class Name {
    
}
