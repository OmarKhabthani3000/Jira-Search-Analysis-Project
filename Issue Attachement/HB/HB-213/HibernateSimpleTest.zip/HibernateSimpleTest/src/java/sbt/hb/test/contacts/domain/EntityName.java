/*
 * IndividualName.java
 *
 * Created on 27 July 2003, 13:20
 */

package sbt.hb.test.contacts.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 *
 * @author  TolleyS
 */
public class EntityName extends Name {
    
	private String entityName;

    public EntityName() {
    }
    
    public String toString(){
        return ToStringBuilder.reflectionToString(this);
    }
    
    /** 
     * @hibernate:property column = "t_entity_name" not-null = "true"
     */
    public java.lang.String getEntityName() {
        return entityName;
    }
    
    /** Setter for property entityName.
     * @param entityName New value of property entityName.
     *
     */
    public void setEntityName(java.lang.String entityName) {
        this.entityName = entityName;
    }
    
}
