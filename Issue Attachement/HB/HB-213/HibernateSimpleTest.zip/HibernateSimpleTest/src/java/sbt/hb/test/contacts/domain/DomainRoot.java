/*
 * RootDomain.java
 *
 * Created on 22 July 2003, 15:53
 */

package sbt.hb.test.contacts.domain;

/**
 *
 * @author  TolleyS
 */
public abstract class DomainRoot {
    
    protected Long id;
    
    public DomainRoot() {
    }

	/**
     * @hibernate:id 
     *    unsaved-value = "null" 
     *    generator-class = "net.sf.hibernate.id.TableHiLoGenerator"
     * @hibernate.generator-param 
     *    name="table" 
     *    value="sbt_id_gen"
     * @hibernate.generator-param 
     *    name="column" 
     *    value="n_key_next"
	 */
	abstract public Long getId(); 
	
	public void setId(Long id) 
	{
	   this.id = id;
	}
    
}
