/*
 * Main.java
 *
 * Created on 27 July 2003, 12:49
 */

package sbt.hb.test.contacts;

import java.util.Iterator;
import java.util.List;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import sbt.hb.test.TestSessionFactory;
import sbt.hb.test.Util;
import sbt.hb.test.contacts.domain.*;

/**
 *
 * @author  TolleyS
 */
public class Main {
    
    private static final Log log = LogFactory.getLog(Main.class);
    
    public static void main(String[] args)
    throws Exception {
        System.out.println("Starting main");
        log.debug("Starting main");
        new Main().doTest();
    }

    public Main() {
    }

    public void doTest() 
    throws HibernateException {
        SessionFactory sf = TestSessionFactory.getSessionFactory();
        
        Session session = sf.openSession();
        
        Long indivId = null;
        Long entityId = null;
        Transaction transaction = session.beginTransaction();
        try {
            log.debug("creating entity...");
            indivId = createIndividual(session);
            entityId = createEntity(session);
            log.debug("committing create operations");
            transaction.commit();
        }
        catch( HibernateException he ){
            transaction.rollback();
            Util.pause();
            throw he;
        }
        
        session.close();
        session = sf.openSession();
        
        transaction = session.beginTransaction();
        try {
            log.debug("loading and finding...");
            doLoadContacts(session, indivId, entityId);
            doFindContacts(session);
//            doFindContactNames(session);
            transaction.commit();
        }
        catch( HibernateException he ){
            transaction.rollback();
            throw he;
        }
        finally {
            Util.pause();
        }            
        
    }
    
    public Long createIndividual(Session session)
    throws HibernateException {
        
        ContactIndividual ci = new ContactIndividual();
        IndividualName name = new IndividualName();
        name.setGivenNames("forename");
        name.setSurname("postname");
        
        ci.setName(name);
        ci.setPersonTitle("Mr");
        ci.setEmailAddress("me@here.com");
        
        session.save(ci);
        
        return ci.getId();
    }
    
    public Long createEntity(Session session)
    throws HibernateException {
        
        ContactEntity ce = new ContactEntity();
        EntityName name = new EntityName();
        name.setEntityName("enty");
        
        ce.setName(name);
        ce.setAcn("acn");
        ce.setEmailAddress("enty@here.com");
        
        session.save(ce);
        
        return ce.getId();
    }

    public void doFindContacts(Session session)
    throws HibernateException {
        String query = "from sbt.hb.test.contacts.domain.Contact as _contact";
        List result = session.find(query); 
        for( Iterator i=result.iterator(); i.hasNext(); ){
            
            Contact o = (Contact) i.next();
            log.debug("id: " + o.getId());
            log.debug("name: " + o.getName());
            
        }
    }
    
    public void doFindContactNames(Session session)
    throws HibernateException {
        log.debug("doFindContactNames"); 
        String query = 
            " select _contact.name" + 
                " from sbt.hb.test.contacts.domain.Contact as _contact";
        List result = session.find(query); 
        for( Iterator i=result.iterator(); i.hasNext(); ){
            
            Name o = (Name) i.next();
            log.debug("name: " + o);
            
        }
    }

    public void doLoadContacts(Session session, Long i, Long e)
    throws HibernateException {
        log.debug("loading entities...");
        ContactIndividual ci = (ContactIndividual) 
            session.load(ContactIndividual.class, i);
        log.debug("ContactIndividual: " + ci);
        
        if( ci.getName() == null ){
            throw new IllegalStateException("shouldn't be null");
        }
        ContactEntity ce = (ContactEntity) 
            session.load(ContactEntity.class, e);
        log.debug("ContactEntity: " + ce);
        
    }
}
