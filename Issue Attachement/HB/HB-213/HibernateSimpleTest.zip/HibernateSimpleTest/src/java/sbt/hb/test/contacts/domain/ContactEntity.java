/*
 * ContactEntity.java
 *
 * Created on 27 July 2003, 13:02
 */

package sbt.hb.test.contacts.domain;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author  TolleyS
 * @hibernate:joined-subclass table="sbt_contact_entity" 
 * @hibernate.joined-subclass-key column="n_key_contact_entity"
 */
public class ContactEntity extends Contact {
    private static final Log log = LogFactory.getLog(ContactEntity.class);
    
	private EntityName name;
	private String acn;
    
    public ContactEntity() {
    }
    
    /**
     * Returns entity name
     * @return String
     * @hibernate.component class="sbt.hb.test.contacts.domain.EntityName"
     */
    public Name getName() {
        return name;
    }    
    
    public void setName(Name _name) {
        log.debug("setName(): " + _name);
        this.name = (EntityName) _name;
    }
    
	/**
	 * Returns id.
	 * @return long
	 * @hibernate:id column = "n_key_contact_entity" 
	 */
	public Long getId() {
		return id;
	}

    /**
     * Returns ACN.
     * @return String
     * @hibernate:property column = "t_acn" not-null="true"
     */
    public java.lang.String getAcn() {
        return acn;
    }
    
    /** Setter for property acn.
     * @param acn New value of property acn.
     *
     */
    public void setAcn(java.lang.String acn) {
        this.acn = acn;
    }
    
}
