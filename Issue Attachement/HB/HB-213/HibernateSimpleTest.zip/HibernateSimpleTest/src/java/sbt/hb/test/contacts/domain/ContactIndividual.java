/*
 * ContactIndividual.java
 *
 * Created on 27 July 2003, 13:02
 */

package sbt.hb.test.contacts.domain;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author  TolleyS
 * @hibernate:joined-subclass table="sbt_contact_indiv" 
 * @hibernate.joined-subclass-key column="n_key_contact_indiv"
 */
public class ContactIndividual extends Contact {
    private static final Log log = LogFactory.getLog(ContactIndividual.class);
    
    private IndividualName name;
	private String personTitle;
    
    public ContactIndividual() {
    }

	/**
	* Returns the id.
	* @return Long
	* @hibernate:id column = "n_key_contact_indiv"
	*/
	public Long getId() {
		return id;
	}
    
    /**
     * @hibernate:property column = "t_person_title" not-null = "true"
     */
    public java.lang.String getPersonTitle() {
        return personTitle;
    }
    
    public void setPersonTitle(java.lang.String personTitle) {
        this.personTitle = personTitle;
    }
    
    /** 
     * 
     * @hibernate.component class="sbt.hb.test.contacts.domain.IndividualName"
     */
    public Name getName() {
        return name;
    }
    
    /** Setter for property name.
     * @param name New value of property name.
     *
     */
    public void setName(Name name) {
        log.debug("this.systemId="+System.identityHashCode(this)+", this.id="+this.id+", indiv setName(): " + name);
//        new RuntimeException().printStackTrace();
        this.name = (IndividualName) name;
    }
    
}
