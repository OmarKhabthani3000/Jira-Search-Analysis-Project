/*
 * TestSessionFactory.java
 *
 * Created on 23 July 2003, 12:20
 */

package sbt.hb.test;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author  TolleyS
 */
public class TestSessionFactory {
    private static final Log log = LogFactory.getLog(TestSessionFactory.class);
    
    public static SessionFactory getSessionFactory(String configXMLFile)
    throws HibernateException {
        log.debug("Configuring...");
        Configuration cfg = new Configuration();
        cfg.configure(configXMLFile);
        SessionFactory sf = cfg.buildSessionFactory();
        log.debug("Done configuring");
        return sf;
    }
    
    public static SessionFactory getSessionFactory()
    throws HibernateException {
        return getSessionFactory("/hibernate.cfg.xml");
    }    
    
}
