/*
 * Contact.java
 *
 * Created on 27 July 2003, 13:02
 */

package sbt.hb.test.contacts.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 *
 * @author  TolleyS
 * @hibernate:class table = "sbt_contact"
 */
public abstract class Contact extends DomainRoot {
    
	private String emailAddress;

    public Contact() {
    }

    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
    
    /**
     * @hibernate.component
     */
    public abstract Name getName();

    public abstract void setName(Name name);
    
    /**
     * Returns id.
     * @return Long
     * @hibernate:id column = "n_key_contact" 
     */
    public Long getId() {
        return id;
    }
    
	/**
	 * Returns email address.
	 * @return String
	 * @hibernate:property column = "t_email_addr" not-null="true"
	 */
    public java.lang.String getEmailAddress() {
        return emailAddress;
    }
    
    /** Setter for property emailAddress.
     * @param emailAddress New value of property emailAddress.
     *
     */
    public void setEmailAddress(java.lang.String emailAddress) {
        this.emailAddress = emailAddress;
    }
    
}
