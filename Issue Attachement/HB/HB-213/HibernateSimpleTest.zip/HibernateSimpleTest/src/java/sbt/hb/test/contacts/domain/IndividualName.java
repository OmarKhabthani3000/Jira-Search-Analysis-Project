/*
 * IndividualName.java
 *
 * Created on 27 July 2003, 13:20
 */

package sbt.hb.test.contacts.domain;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author  TolleyS
 */
public class IndividualName extends Name{
    private static final Log log = LogFactory.getLog(IndividualName.class); 
	private String surname;
	private String givenNames;

    public IndividualName() {
    }
    
    public String toString(){
        return ToStringBuilder.reflectionToString(this);
    }
    
    /** Getter for property surname.
     * @return Value of property surname.
     * @hibernate:property column = "t_surname" not-null = "true"
     */
    public java.lang.String getSurname() {
        return surname;
    }
    
    /** Setter for property surname.
     * @param surname New value of property surname.
     *
     */
    public void setSurname(java.lang.String surname) {
        this.surname = surname;
    }
    
    /** Getter for property givenNames.
     * @return Value of property givenNames.
     * @hibernate:property column = "t_given_names" not-null = "true"
     */
    public java.lang.String getGivenNames() {
        return givenNames;
    }
    
    /** Setter for property givenNames.
     * @param givenNames New value of property givenNames.
     *
     */
    public void setGivenNames(java.lang.String givenNames) {
        log.debug("this.systemId="+System.identityHashCode(this)+", setGivenNames: " + givenNames);
        this.givenNames = givenNames;
    }
    
}
