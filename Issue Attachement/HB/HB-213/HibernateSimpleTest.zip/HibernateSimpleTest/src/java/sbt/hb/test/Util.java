/*
 * Util.java
 *
 * Created on 23 July 2003, 20:30
 */

package sbt.hb.test;

/**
 *
 * @author  TolleyS
 */
public class Util {
    
    public static void pause(){
        try { Thread.sleep(200); } catch( InterruptedException ie ){ }
    }        
    
}
