package org.hibernate.auction;

public class User
 {
  private Long id;
  private String userName;

  public Long getId()
   {
    return id;
   }

  public void setId(Long long1)
   {
    id = long1;
   }

  public String getUserName()
   {
    return userName;
   }

  public void setUserName(String string)
   {
    userName = string;
   }
 }
