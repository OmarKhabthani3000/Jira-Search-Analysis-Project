package org.hibernate.auction;

import net.sf.hibernate.*;
import net.sf.hibernate.cfg.*;

import java.util.Iterator;

public class Main
 {
  private SessionFactory factory;

  public void test() throws Exception
   {
    Session s = factory.openSession();
    Transaction tx = s.beginTransaction();

    System.out.print("check user 'xxx' existence:  ");

    Query query = s.createQuery("from User where UserName = ?");
    query.setParameter(0, "xxx", Hibernate.STRING);
    query.setCacheable(true);
    Iterator iter = query.list().iterator();
    User user = null;
    if (iter.hasNext()) user = (User) iter.next();

    if (user == null)
     System.out.println("not exists");
    else
     System.out.println("exists");

    user = new User();
    user.setUserName("xxx");
    s.save(user);

    System.out.println("user 'xxx' created");

    System.out.print("re-check user 'x' existence: ");

    query = s.createQuery("from User where UserName = ?");
    query.setParameter(0, "xxx", Hibernate.STRING);
    query.setCacheable(true);
    iter = query.list().iterator();
    User seller1 = null;
    if (iter.hasNext()) seller1 = (User) iter.next();

    if (seller1 == null)
     System.out.println("not exists");
    else
     System.out.println("exists");

    tx.commit();
    s.close();
   }

  public static void main(String[] args) throws Exception
   {
    final Main main = new Main();
    Configuration cfg = new Configuration().addClass(User.class).setProperty(Environment.HBM2DDL_AUTO, "create");
    main.factory = cfg.buildSessionFactory();
    main.test();
    main.factory.close();
   }
 }
