package jcscache;

import java.io.Serializable;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;


public class Test {
	private SessionFactory sf = null;
	private Serializable   maleId;
	private Serializable   femaleId;


	private void configure() throws HibernateException {
		// Create a new Hibernate Configuration instance
		Configuration cfg = new Configuration();
		cfg = cfg.configure();
		
		// Create the hibernate session factory
		sf = cfg.buildSessionFactory();
	}
	
	
	private void create() throws HibernateException {
		// Create two new instances
		Male   male   = new Male("Male");
		Female female = new Female("Female");
		
		// Get a session
		Session session = sf.openSession();
		
		// Persist them
		maleId = session.save(male);
		femaleId = session.save(female);
		
		// Close session
		session.flush();
		session.close();
	}
	
	
	private void reload() throws HibernateException {
		
		// Reopen a new session
		Session session = sf.openSession();
		
		// Try to reload objects
		Male   reloadedMale   = (Male)   session.load(Male.class, maleId);
		Female reloadedFemale = (Female) session.load(Female.class, femaleId);
		
		// Close session
		session.close();
	}
		
	
	
	public static void main(String[] args) {
		try {
			Test t = new Test();
			t.configure();
			t.create();
			t.reload();
			t.reload();
		} 
		catch (HibernateException e) {
			e.printStackTrace();
		}
	}
}
