/*
 * Created on Aug 21, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package jcscache;

public class Female extends Human {

	/**
	 * 
	 */
	public Female() {
		super();
	}

	/**
	 * @param aName
	 */
	public Female(String aName) {
		super(aName);
	}

}
