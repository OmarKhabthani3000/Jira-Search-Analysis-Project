/*
 * Created on Aug 21, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package jcscache;

public class Male extends Human {

	/**
	 * 
	 */
	public Male() {
		super();
	}

	/**
	 * @param aName
	 */
	public Male(String aName) {
		super(aName);
	}

}
