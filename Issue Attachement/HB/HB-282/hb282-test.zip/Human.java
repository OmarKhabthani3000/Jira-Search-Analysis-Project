/*
 * Created on Aug 21, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package jcscache;

import java.io.Serializable;


public class Human implements Serializable {
	
	private long uid;
	private String name;
	
	public Human() {
	}
	
	public Human(String aName) {
		this();
		setName(aName);
	}
	
	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return
	 */
	public long getUid() {
		return uid;
	}

	/**
	 * @param uid
	 */
	public void setUid(long uid) {
		this.uid = uid;
	}
}
