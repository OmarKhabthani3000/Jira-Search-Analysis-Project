
import java.util.Iterator;

import java.util.*;
import net.sf.hibernate.*;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.tool.hbm2ddl.SchemaExport;

public class CasTest {
   public static void main(String[] args) throws HibernateException, java.sql.SQLException {
        Configuration cfg = new Configuration()
            .addClass(Foo.class)
            .addClass(Bar.class);

      SessionFactory sf = cfg.buildSessionFactory();
      new SchemaExport(cfg).create(true, true);

      Session session = sf.openSession();
      Bar bar = new Bar();
      bar.setName( "N1" );
      bar.setCity( "ShenZhen" );
      session.save( bar );
      session.flush();
      session.connection().commit();
      session.close();

      // open another session, new bar is persisted, but for bar object, it is a detached object
      Session session2 = sf.openSession();
      Foo foo = new Foo();
      foo.setName( "China" );
      if( foo.getBars() == null )
          foo.setBars( new ArrayList() );
      Bar b2 = (Bar)session2.createCriteria( Bar.class ).uniqueResult();  // first we load bar object
      System.out.println("bar =" + bar + ",  b2=" + b2 );
      foo.getBars().add( bar );   // but, but we put the detached object to foo

      session2.saveOrUpdateCopy( foo );  //because we use cascade="all", we also update bar
      session2.flush();
      session2.connection().commit();
      session2.close();
   }
}
