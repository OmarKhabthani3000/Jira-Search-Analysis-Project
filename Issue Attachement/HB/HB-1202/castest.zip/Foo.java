// default package

import java.io.Serializable;
import java.util.List;
import org.apache.commons.lang.builder.ToStringBuilder;


/** @author Hibernate CodeGenerator */
public class Foo implements Serializable {

    /** identifier field */
    private Long id;

    /** nullable persistent field */
    private String name;

    /** persistent field */
    private List bars;

    /** full constructor */
    public Foo(String name, List bars) {
        this.name = name;
        this.bars = bars;
    }

    /** default constructor */
    public Foo() {
    }

    /** minimal constructor */
    public Foo(List bars) {
        this.bars = bars;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List getBars() {
        return this.bars;
    }

    public void setBars(List bars) {
        this.bars = bars;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

}
