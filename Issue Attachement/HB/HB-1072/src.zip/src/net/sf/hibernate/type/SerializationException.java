//$Id: SerializationException.java,v 1.3.2.1 2003/11/21 16:06:40 oneovthafew Exp $
package net.sf.hibernate.type;

import net.sf.hibernate.HibernateException;

/**
 * Thrown when a property cannot be serializaed/deserialized
 * @author Gavin King
 */
public class SerializationException extends HibernateException {
	
	public SerializationException(String message, Exception root) {
		super(message, root);
	}
	
}






