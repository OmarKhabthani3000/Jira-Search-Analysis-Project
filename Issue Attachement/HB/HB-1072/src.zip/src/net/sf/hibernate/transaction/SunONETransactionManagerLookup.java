//$Id: SunONETransactionManagerLookup.java,v 1.1.2.1 2004/01/14 20:47:47 oneovthafew Exp $
package net.sf.hibernate.transaction;

/**
 * TransactionManager lookup strategy for Sun ONE Application Server 7
 * @author Robert Davidson
 */
public class SunONETransactionManagerLookup extends JNDITransactionManagerLookup {

	protected String getName() {
		return "java:/TransactionManager";
	}

	public String getUserTransactionName() {
		return "UserTransaction";
	}
}
