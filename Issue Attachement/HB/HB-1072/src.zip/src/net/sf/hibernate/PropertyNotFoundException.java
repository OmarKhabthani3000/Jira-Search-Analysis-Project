//$Id: PropertyNotFoundException.java,v 1.4.2.1 2003/11/27 13:24:16 oneovthafew Exp $
package net.sf.hibernate;

/**
 * Indicates that an expected getter or setter method could not be
 * found on a class.
 * 
 * @author Gavin King
 */
public class PropertyNotFoundException extends MappingException {
	
	public PropertyNotFoundException(String s) {
		super(s);
	}
	
}






