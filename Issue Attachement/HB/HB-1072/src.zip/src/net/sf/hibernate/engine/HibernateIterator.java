//$Id: HibernateIterator.java,v 1.1.2.2 2003/11/27 16:09:59 oneovthafew Exp $
package net.sf.hibernate.engine;

import java.sql.SQLException;
import java.util.Iterator;

/**
 * An iterator that may be "closed"
 * @see net.sf.hibernate.Hibernate#close(java.util.Iterator)
 * @author Gavin King
 */
public interface HibernateIterator extends Iterator {
	public void close() throws SQLException;
}
