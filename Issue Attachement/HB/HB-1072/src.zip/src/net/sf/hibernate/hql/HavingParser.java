//$Id: HavingParser.java,v 1.3.2.1 2003/08/03 12:06:27 oneovthafew Exp $
package net.sf.hibernate.hql;

/**
 * Parses the having clause of a hibernate query and translates it to an
 * SQL having clause.
 */
public class HavingParser extends WhereParser {
	
	void appendToken(QueryTranslator q, String token) {
		q.appendHavingToken(token);
	}
	
}
