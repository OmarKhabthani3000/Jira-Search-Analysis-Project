//$Id: AssertionFailure.java,v 1.4.2.4 2003/12/06 02:41:54 oneovthafew Exp $
package net.sf.hibernate;

import net.sf.hibernate.exception.NestableRuntimeException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Indicates failure of an assertion: a possible bug in Hibernate.
 *
 * @author Gavin King
 */

public class AssertionFailure extends NestableRuntimeException {
	
	private static final Log log;

	static {
		if (LOG.ON) {
			log = LogFactory.getLog(AssertionFailure.class);
		} else {
			log = null;
		}
	}
	
	private static final String MESSAGE = "an assertion failure occured (this may indicate a bug in Hibernate, but is more likely due to unsafe use of the session)";

	public AssertionFailure(String s) {
		super(s);
		if (LOG.ON) {
			log.error(MESSAGE, this);
		}
	}
	
	public AssertionFailure(String s, Throwable t) {
		super(s, t);
		if (LOG.ON) {
			log.error(MESSAGE, t);
		}
	}
	
}






