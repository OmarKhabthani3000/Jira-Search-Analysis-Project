//$Id: TreeCacheProvider.java,v 1.1.2.2 2004/01/20 18:30:25 oneovthafew Exp $
package net.sf.hibernate.cache;

import java.util.Properties;

/**
 * Support for JBoss TreeCache
 * @author Gavin King
 */
public class TreeCacheProvider implements CacheProvider {

	public Cache buildCache(String regionName, Properties properties)
		throws CacheException {
		return new TreeCache(regionName, properties);
	}

	public long nextTimestamp() {
		return System.currentTimeMillis() / 100;
	}

}
