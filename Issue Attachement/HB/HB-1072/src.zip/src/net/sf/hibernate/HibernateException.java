//$Id: HibernateException.java,v 1.5.2.1 2003/10/25 07:43:51 oneovthafew Exp $
package net.sf.hibernate;

import net.sf.hibernate.exception.NestableException;

/**
 * Any exception that occurs inside the persistence layer
 * or JDBC driver. <tt>SQLException</tt>s are always wrapped
 * by instances of <tt>JDBCException</tt>.
 * 
 * @see JDBCException
 * @author Gavin King
 */

public class HibernateException extends NestableException {
	
	public HibernateException(Throwable root) {
		super(root);
	}
	
	
	public HibernateException(String string, Throwable root) {
		super(string, root);
	}
	
	public HibernateException(String s) {
		super(s);
	}
}






