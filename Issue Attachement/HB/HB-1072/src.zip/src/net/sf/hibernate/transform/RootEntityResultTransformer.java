//$Id: RootEntityResultTransformer.java,v 1.1.2.1 2003/12/27 07:16:01 oneovthafew Exp $
package net.sf.hibernate.transform;

import java.util.List;

/**
 * @author Gavin King
 */
public class RootEntityResultTransformer implements ResultTransformer {

	public Object transformTuple(Object[] tuple, String[] aliases) {
		return tuple[ tuple.length-1 ];
	}

	public List transformList(List collection) {
		return collection;
	}

}
