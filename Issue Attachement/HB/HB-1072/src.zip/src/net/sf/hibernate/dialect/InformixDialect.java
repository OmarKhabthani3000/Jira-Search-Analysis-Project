//$id$
package net.sf.hibernate.dialect;

import java.sql.Types;
import net.sf.hibernate.MappingException;

/**
 * Informix dialect. This class is required in order to use Hibernate with
 * Informix.<br>
 * <br>
 * Seems to work with Informix Dynamic Server Version 7.31.UD3,
 * Informix JDBC driver version 2.21JC3.
 * @author Steve Molitor
 */
public class InformixDialect extends Dialect {

	/**
	 * Creates new <code>InformixDialect</code> instance. Sets up the JDBC /
	 * Informix type mappings.
	 */
	public InformixDialect() {
		super();

		registerColumnType(Types.BIGINT, "INT8");
		registerColumnType(Types.BINARY, "BYTE");
		registerColumnType(Types.BIT, "SMALLINT"); // Informix doesn't have a bit type
		registerColumnType(Types.CHAR, "CHAR($l)");
		registerColumnType(Types.DATE, "DATE");
		registerColumnType(Types.DECIMAL, "DECIMAL");
		registerColumnType(Types.DOUBLE, "DOUBLE");
		registerColumnType(Types.FLOAT, "FLOAT");
		registerColumnType(Types.INTEGER, "INTEGER");
		registerColumnType(Types.LONGVARBINARY, "BLOB"); // or BYTE
		registerColumnType(Types.LONGVARCHAR, "CLOB"); // or TEXT?
		registerColumnType(Types.NUMERIC, "DECIMAL"); // or MONEY
		registerColumnType(Types.REAL, "SMALLFLOAT");
		registerColumnType(Types.SMALLINT, "SMALLINT");
		registerColumnType(Types.TIMESTAMP, "DATETIME YEAR TO FRACTION(5)");
		registerColumnType(Types.TIME, "DATETIME HOUR TO SECOND");
		registerColumnType(Types.TINYINT, "SMALLINT");
		registerColumnType(Types.VARBINARY, "BYTE");
		registerColumnType(Types.VARCHAR, "VARCHAR($l)");
	}

	public String getAddColumnString() {
		return "add";
	}

	public boolean supportsIdentityColumns() {
		return true;
	}

	public String getIdentitySelectString() throws MappingException {
		return "select first 1 dbinfo('sqlca.sqlerrd1') from systables";
	}

	public String getIdentityColumnString() throws MappingException {
		return "SERIAL8 NOT NULL";
	}

	public boolean hasDataTypeInIdentityColumn() {
		return false;
	}
}