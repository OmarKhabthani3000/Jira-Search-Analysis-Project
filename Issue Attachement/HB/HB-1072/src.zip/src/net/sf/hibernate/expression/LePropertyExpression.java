//$Id: LePropertyExpression.java,v 1.1.2.1 2004/05/31 04:58:41 oneovthafew Exp $
package net.sf.hibernate.expression;

/**
 * @author Gavin King
 */
public class LePropertyExpression extends PropertyExpression {

	public LePropertyExpression(String propertyName, String otherPropertyName) {
		super(propertyName, otherPropertyName);
	}

	String getOp() {
		return "<=";
	}

}
