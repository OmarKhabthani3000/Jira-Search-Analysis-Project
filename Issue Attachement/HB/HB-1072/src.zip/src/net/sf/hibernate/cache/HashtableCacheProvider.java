//$Id: HashtableCacheProvider.java,v 1.1.2.1 2003/09/02 08:27:39 oneovthafew Exp $
package net.sf.hibernate.cache;

import java.util.Properties;

/**
 * @author Gavin King
 */
public class HashtableCacheProvider implements CacheProvider {

	public Cache buildCache(String regionName, Properties properties)
		throws CacheException {
		return new HashtableCache();
	}

	public long nextTimestamp() {
		return Timestamper.next();
	}

}
