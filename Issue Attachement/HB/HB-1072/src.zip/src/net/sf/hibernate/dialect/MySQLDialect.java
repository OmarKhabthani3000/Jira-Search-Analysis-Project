//$Id: MySQLDialect.java,v 1.11.2.13 2004/05/28 21:11:37 gloeglm Exp $
package net.sf.hibernate.dialect;

import java.sql.Types;

import net.sf.hibernate.Hibernate;
import net.sf.hibernate.cfg.Environment;
import net.sf.hibernate.util.StringHelper;

/**
 * An SQL dialect for MySQL.
 * @author Gavin King
 */
public class MySQLDialect extends Dialect {
	public MySQLDialect() {
		super();
		registerColumnType( Types.BIT, "BIT" );
		registerColumnType( Types.BIGINT, "BIGINT" );
		registerColumnType( Types.SMALLINT, "SMALLINT" );
		registerColumnType( Types.TINYINT, "TINYINT" );
		registerColumnType( Types.INTEGER, "INTEGER" );
		registerColumnType( Types.CHAR, "CHAR(1)" );
		registerColumnType( Types.VARCHAR, "LONGTEXT" );
		registerColumnType( Types.VARCHAR, 16777215, "MEDIUMTEXT" );
		registerColumnType( Types.VARCHAR, 65535, "TEXT" );
		registerColumnType( Types.VARCHAR, 255, "VARCHAR($l)" );
		registerColumnType( Types.FLOAT, "FLOAT" );
		registerColumnType( Types.DOUBLE, "DOUBLE PRECISION" );
		registerColumnType( Types.DATE, "DATE" );
		registerColumnType( Types.TIME, "TIME" );
		registerColumnType( Types.TIMESTAMP, "DATETIME" );
		registerColumnType( Types.VARBINARY, "LONGBLOB" );
		registerColumnType( Types.VARBINARY, 16777215, "MEDIUMBLOB" );
		registerColumnType( Types.VARBINARY, 65535, "BLOB" );
		registerColumnType( Types.VARBINARY, 255, "VARCHAR($l) BINARY" );
		registerColumnType( Types.NUMERIC, "NUMERIC(19, $l)" );
		registerColumnType( Types.BLOB, "LONGBLOB" );
		registerColumnType( Types.BLOB, 16777215, "MEDIUMBLOB" );
		registerColumnType( Types.BLOB, 65535, "BLOB" );
		registerColumnType( Types.CLOB, "LONGTEXT" );
		registerColumnType( Types.CLOB, 16777215, "MEDIUMTEXT" );
		registerColumnType( Types.CLOB, 65535, "TEXT" );
		
		registerFunction("ascii", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("bin", new StandardSQLFunction(Hibernate.STRING) );
		registerFunction("char_length", new StandardSQLFunction(Hibernate.LONG) );
		registerFunction("character_length", new StandardSQLFunction(Hibernate.LONG) );
		registerFunction("lcase", new StandardSQLFunction() );
		registerFunction("lower", new StandardSQLFunction() );
		registerFunction("length", new StandardSQLFunction(Hibernate.LONG) );
		registerFunction("ltrim", new StandardSQLFunction() );
		registerFunction("ord", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("quote", new StandardSQLFunction() );
		registerFunction("reverse", new StandardSQLFunction() );
		registerFunction("rtrim", new StandardSQLFunction() );
		registerFunction("soundex", new StandardSQLFunction() );
		registerFunction("space", new StandardSQLFunction(Hibernate.STRING) );
		registerFunction("ucase", new StandardSQLFunction() );
		registerFunction("upper", new StandardSQLFunction() );
		registerFunction("unhex", new StandardSQLFunction(Hibernate.STRING) );
		
		registerFunction("abs", new StandardSQLFunction() );
		registerFunction("sign", new StandardSQLFunction(Hibernate.INTEGER) );
		
		registerFunction("acos", new StandardSQLFunction(Hibernate.DOUBLE) );
		registerFunction("asin", new StandardSQLFunction(Hibernate.DOUBLE) );
		registerFunction("atan", new StandardSQLFunction(Hibernate.DOUBLE) );
		registerFunction("cos", new StandardSQLFunction(Hibernate.DOUBLE) );
		registerFunction("cot", new StandardSQLFunction(Hibernate.DOUBLE) );
		registerFunction("crc32", new StandardSQLFunction(Hibernate.LONG) );
		registerFunction("exp", new StandardSQLFunction(Hibernate.DOUBLE) );
		registerFunction("ln", new StandardSQLFunction(Hibernate.DOUBLE) );
		registerFunction("log", new StandardSQLFunction(Hibernate.DOUBLE) );
		registerFunction("log2", new StandardSQLFunction(Hibernate.DOUBLE) );
		registerFunction("log10", new StandardSQLFunction(Hibernate.DOUBLE) );
		registerFunction("pi", new NoArgSQLFunction(Hibernate.DOUBLE) );
		registerFunction("rand", new NoArgSQLFunction(Hibernate.DOUBLE) );
		registerFunction("sin", new NoArgSQLFunction(Hibernate.DOUBLE) );
		registerFunction("sqrt", new NoArgSQLFunction(Hibernate.DOUBLE) );
		registerFunction("tan", new NoArgSQLFunction(Hibernate.DOUBLE) );

		registerFunction("radians", new StandardSQLFunction(Hibernate.DOUBLE) );
		registerFunction("degrees", new StandardSQLFunction(Hibernate.DOUBLE) );

		registerFunction("ceiling", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("ceil", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("floor", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("round", new StandardSQLFunction(Hibernate.INTEGER) );

		registerFunction("curdate", new NoArgSQLFunction(Hibernate.DATE) );
		registerFunction("current_date", new NoArgSQLFunction(Hibernate.DATE) );
		registerFunction("curtime", new NoArgSQLFunction(Hibernate.TIME) );
		registerFunction("current_time", new NoArgSQLFunction(Hibernate.TIME) );
		registerFunction("current_timestamp", new NoArgSQLFunction(Hibernate.TIMESTAMP) );
		registerFunction("date", new StandardSQLFunction(Hibernate.DATE) );
		registerFunction("day", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("dayofmonth", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("dayname", new StandardSQLFunction(Hibernate.STRING) );
		registerFunction("dayofweek", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("dayofyear", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("from_days", new StandardSQLFunction(Hibernate.DATE) );
		registerFunction("from_unixtime", new StandardSQLFunction(Hibernate.TIMESTAMP) );
		registerFunction("hour", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("last_day", new StandardSQLFunction(Hibernate.DATE) );
		registerFunction("localtime", new NoArgSQLFunction(Hibernate.TIMESTAMP));
		registerFunction("localtimestamp", new NoArgSQLFunction(Hibernate.TIMESTAMP) );
		registerFunction("microseconds", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("minute", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("month", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("monthname", new StandardSQLFunction(Hibernate.STRING) );
		registerFunction("now", new NoArgSQLFunction(Hibernate.TIMESTAMP) );
		registerFunction("quarter", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("second", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("sec_to_time", new StandardSQLFunction(Hibernate.TIME) );
		registerFunction("sysdate", new NoArgSQLFunction(Hibernate.TIMESTAMP) );
		registerFunction("time", new StandardSQLFunction(Hibernate.TIME) );
		registerFunction("time", new StandardSQLFunction(Hibernate.TIMESTAMP) );
		registerFunction("time_to_sec", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("to_days", new StandardSQLFunction(Hibernate.LONG) );
		registerFunction("unix_timestamp", new StandardSQLFunction(Hibernate.LONG) );
		registerFunction("utc_date", new NoArgSQLFunction(Hibernate.STRING) );
		registerFunction("utc_time", new NoArgSQLFunction(Hibernate.STRING) );
		registerFunction("utc_timestamp", new NoArgSQLFunction(Hibernate.STRING) );
		registerFunction("week", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("weekday", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("weekofyear", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("year", new StandardSQLFunction(Hibernate.INTEGER) );
		registerFunction("yearweek", new StandardSQLFunction(Hibernate.INTEGER) );
		
		registerFunction("hex", new StandardSQLFunction(Hibernate.STRING) );
		registerFunction("oct", new StandardSQLFunction(Hibernate.STRING) );
		
		registerFunction("octet_length", new StandardSQLFunction(Hibernate.LONG) );
		registerFunction("bit_length", new StandardSQLFunction(Hibernate.LONG) );
		
		registerFunction("bit_count", new StandardSQLFunction(Hibernate.LONG) );
		registerFunction("encrypt", new StandardSQLFunction(Hibernate.STRING) );
		registerFunction("md5", new StandardSQLFunction(Hibernate.STRING) );
		registerFunction("sha1", new StandardSQLFunction(Hibernate.STRING) );
		registerFunction("sha", new StandardSQLFunction(Hibernate.STRING) );

		getDefaultProperties().setProperty(Environment.STATEMENT_BATCH_SIZE, DEFAULT_BATCH_SIZE);
	}
	
	public String getAddColumnString() {
		return "add column";
	}
	public boolean dropConstraints() {
		return false;
	}
	public boolean qualifyIndexName() {
		return false;
	}
	
	public boolean supportsIdentityColumns() {
		return true;
	}
	public String getIdentitySelectString() {
		return "SELECT LAST_INSERT_ID()";
	}
	
	public String getIdentityColumnString() {
		return "NOT NULL AUTO_INCREMENT";
	}
	
	public String getAddForeignKeyConstraintString(String constraintName, String[] foreignKey, String referencedTable, String[] primaryKey) {
		String cols = StringHelper.join(StringHelper.COMMA_SPACE, foreignKey);
		return new StringBuffer(30)
			.append(" add index ")
			.append(constraintName)
			.append(" (")
			.append(cols)
			.append("), add constraint ")
			.append(constraintName)
			.append(" foreign key (")
			.append(cols)
			.append(") references ")
			.append(referencedTable)
			.append(" (")
			.append( StringHelper.join(StringHelper.COMMA_SPACE, primaryKey) )
			.append(')')
			.toString();
	}
	
	public boolean supportsLimit() {
		return true;
	}

	public String getLimitString(String sql, boolean hasOffset) {
		return new StringBuffer( sql.length()+20 )
			.append(sql)
			.append( hasOffset ? " limit ?, ?" : " limit ?")
			.toString();
	}

	public char closeQuote() {
		return '`';
	}

	public char openQuote() {
		return '`';
	}

	public boolean supportsIfExistsBeforeTableName() {
		return true;
	}

	public char getSchemaSeperator() {
	  return StringHelper.UNDERSCORE;
	}

}







