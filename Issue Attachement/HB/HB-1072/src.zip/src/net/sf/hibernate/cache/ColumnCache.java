/*
 * Created on 2004-jul-05
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package net.sf.hibernate.cache;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

/**
 * @author Kaj Bjurman, HiQ
 *
 * Hibernate uses String indices to read from a resultset. That is very slow on 
 * some Oracle drivers.
 * 
 * The class is threadsafe 
 */
public class ColumnCache {

	private static ColumnCache instance;
	
	/**
	 * HashMap with current resultsets. 
	 * The key is a ResultSet, the value is another HashMap.
	 * The value HashMap is used to cache the column indices, as Integer.
	 * I.e The value HashMap has column name (String) as key, and index (Integer) as value
	 */
	private HashMap rsCache;
	
	private ColumnCache() {
		rsCache = new HashMap();
	}

	public static synchronized ColumnCache getInstance() {
		if (instance == null) {
			instance = new ColumnCache();
		}
		return instance;
	}

	public void addResultSet(ResultSet rs) {
		rsCache.put(rs, new HashMap());
	}

	public void removeResultSet(ResultSet rs) {
		rsCache.remove(rs);
	}
	
	public int getIndex(ResultSet rs, String columnName) throws SQLException {
		HashMap cache = (HashMap)rsCache.get(rs);
		if (cache == null) {
			throw new SQLException("The resultset " + rs + " is not in cache");
		}
		synchronized (cache) {
			Integer index = (Integer)cache.get(columnName);
			if (index == null) {
				index = new Integer(rs.findColumn(columnName));
				if (index == null) {
					throw new SQLException("The column " + columnName + " does not exist is resultset " + rs);
				}
				cache.put(columnName, index);
			}
			return index.intValue();
		}
	}
	
	
	
}
