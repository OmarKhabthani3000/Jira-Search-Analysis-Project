//$Id: SetType.java,v 1.9.2.2 2004/01/26 04:57:09 oneovthafew Exp $
package net.sf.hibernate.type;

import net.sf.hibernate.collection.CollectionPersister;
import net.sf.hibernate.collection.PersistentCollection;
import net.sf.hibernate.collection.Set;
import net.sf.hibernate.engine.SessionImplementor;

public class SetType extends PersistentCollectionType {
	
	public SetType(String role) {
		super(role);
	}
	
	public PersistentCollection instantiate(SessionImplementor session, CollectionPersister persister) {
		return new Set(session);
	}
	
	public Class getReturnedClass() {
		return java.util.Set.class;
	}
	
	public PersistentCollection wrap(SessionImplementor session, Object collection) {
		return new Set( session, (java.util.Set) collection );
	}
	
}
