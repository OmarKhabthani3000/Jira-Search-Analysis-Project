//$Id: JBossTransactionManagerLookup.java,v 1.4 2003/04/25 03:40:36 oneovthafew Exp $
package net.sf.hibernate.transaction;

/**
 * A <tt>TransactionManager</tt> lookup strategy for JBoss
 * @author Gavin King
 */
public final class JBossTransactionManagerLookup extends JNDITransactionManagerLookup {
	
	protected String getName() {
		return "java:/TransactionManager";
	}
	
	public String getUserTransactionName() {
		return "UserTransaction";
	}
	
}






