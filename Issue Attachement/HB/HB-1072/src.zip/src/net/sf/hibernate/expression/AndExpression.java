//$Id: AndExpression.java,v 1.3.2.1 2003/08/12 12:51:00 oneovthafew Exp $
package net.sf.hibernate.expression;


/**
 * A logical "and"
 * @author Gavin King
 */
public class AndExpression extends LogicalExpression {
	
	String getOp() {
		return "and";
	}
		
	AndExpression(Criterion lhs, Criterion rhs) {
		super(lhs, rhs);
	}

}
