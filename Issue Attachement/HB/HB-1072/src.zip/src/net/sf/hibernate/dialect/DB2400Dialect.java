//$Id: DB2400Dialect.java,v 1.1.2.2 2004/05/01 08:49:34 oneovthafew Exp $
package net.sf.hibernate.dialect;

/** 
 * An SQL dialect for DB2/400. This class provides support for  
 * DB2 Universal Database for iSeries, also known as DB2/400. 
 * 
 * @author Peter DeGregorio (pdegregorio) 
 * 
 */
public class DB2400Dialect extends DB2Dialect {

   public boolean supportsIdentityColumns() {
      return false;
   }

   public boolean supportsSequences() {
      return false;
   }

   public boolean supportsLimit() {
      return true;
   }

   public boolean supportsLimitOffset() {
      return false;
   }

   public String getLimitString(String sql, boolean hasOffset, int limit) {
      return new StringBuffer(sql.length() + 40)
         .append(sql)
         .append(" fetch first ")
         .append(limit)
         .append(" rows only ")
         .toString();
   }

   public boolean useMaxForLimit() {
      return true;
   }

   public boolean supportsVariableLimit() {
      return false;
   }

}