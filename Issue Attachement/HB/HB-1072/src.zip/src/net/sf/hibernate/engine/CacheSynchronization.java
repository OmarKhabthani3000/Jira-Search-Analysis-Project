//$Id: CacheSynchronization.java,v 1.1.2.1 2003/08/26 06:31:17 oneovthafew Exp $
package net.sf.hibernate.engine;

import javax.transaction.Status;
import javax.transaction.Synchronization;

import net.sf.hibernate.LOG;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author Gavin King
 */
public final class CacheSynchronization implements Synchronization {

	private static final Log log = LogFactory.getLog(CacheSynchronization.class);
	
	private final SessionImplementor session;
	
	public CacheSynchronization(SessionImplementor session) {
		this.session = session;
	}

	public void beforeCompletion() {
		if (LOG.ON) {
			log.trace("transaction before completion callback");
		}
	}

	public void afterCompletion(int status) {
		if (LOG.ON) {
			if ( log.isTraceEnabled() ) log.trace("transaction after completion callback, status: " + status);
		}
		session.afterTransactionCompletion(status==Status.STATUS_COMMITTED);
	}

}
