//$Id: IdentifierGenerationException.java,v 1.5 2003/04/25 03:40:33 oneovthafew Exp $
package net.sf.hibernate.id;

import net.sf.hibernate.HibernateException;

/**
 * Thrown by <tt>IdentifierGenerator</tt> implementation class when
 * ID generation fails.
 *
 * @see IdentifierGenerator
 * @author Gavin King
 */

public class IdentifierGenerationException extends HibernateException {
	
	public IdentifierGenerationException(String msg) {
		super(msg);
	}
	
	public IdentifierGenerationException(String msg, Throwable t) {
		super(msg, t);
	}
	
}






