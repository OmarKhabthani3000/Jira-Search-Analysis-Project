//$Id: MutableType.java,v 1.4.2.1 2003/11/09 12:19:08 oneovthafew Exp $
package net.sf.hibernate.type;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.engine.SessionImplementor;

/**
 * Superclass for mutable nullable types
 * @author Gavin King
 */
public abstract class MutableType extends NullableType {
	
	public final boolean isMutable() {
		return true;
	}
	
	public boolean hasNiceEquals() {
		return false; //default ... may be overridden
	}
	
	public Object copy(
		Object original,
		Object target,
		SessionImplementor session,
		Object owner)
		throws HibernateException {
		return deepCopy(original);
	}

}






