//$Id: ResultTransformer.java,v 1.1.2.1 2003/12/27 07:16:01 oneovthafew Exp $
package net.sf.hibernate.transform;

import java.util.List;

/**
 * Implementors define a strategy for transforming criteria query
 * results into the actual application-visible query result list.
 * @see net.sf.hibernate.Criteria#setResultTransformer(ResultTransformer)
 * @author Gavin King
 */
public interface ResultTransformer {
	public Object transformTuple(Object[] tuple, String[] aliases);
	public List transformList(List collection);
}
