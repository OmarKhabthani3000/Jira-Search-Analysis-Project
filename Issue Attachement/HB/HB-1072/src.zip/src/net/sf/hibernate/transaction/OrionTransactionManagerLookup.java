//$Id: OrionTransactionManagerLookup.java,v 1.4 2003/04/25 03:40:36 oneovthafew Exp $
package net.sf.hibernate.transaction;

/**
 * TransactionManager lookup strategy for Orion
 * @author Gavin King
 */
public class OrionTransactionManagerLookup
extends JNDITransactionManagerLookup {
	
	/**
	 * @see net.sf.hibernate.transaction.JNDITransactionManagerLookup#getName()
	 */
	protected String getName() {
		return "java:comp/UserTransaction";
	}
	
	public String getUserTransactionName() {
		return "java:comp/UserTransaction";
	}
	
}






