//$Id: SQLServerDialect.java,v 1.1.2.4 2004/01/10 12:02:02 oneovthafew Exp $
package net.sf.hibernate.dialect;

/**
 * A dialect for Microsoft SQL Server 2000
 * @author Gavin King
 */
public class SQLServerDialect extends SybaseDialect {
	
	public boolean bindLimitParametersFirst() {
		return super.bindLimitParametersFirst();
	}

	public String getLimitString(String querySelect, boolean hasOffset, int limit) {
		if (hasOffset) throw new UnsupportedOperationException("sql server has no offset");
		return new StringBuffer( querySelect.length()+6 )
			.append(querySelect)
			.insert( getAfterSelectInsertPoint(querySelect), " top " + limit )
			.toString();
	}

	/**
	 * Use <tt>insert table(...) values(...) select SCOPE_IDENTITY()</tt>
	 * 
	 * @author <a href="mailto:jkristian@docent.com">John Kristian</a>
	 */
	public String appendIdentitySelectToInsert(String insertSQL) {
		return insertSQL + " select SCOPE_IDENTITY()";
	}

	public boolean supportsLimit() {
		return true;
	}

	public boolean useMaxForLimit() {
		return true;
	}

	public boolean supportsLimitOffset() {
		return false;
	}

	public boolean supportsVariableLimit() {
		return false;
	}

	private static int getAfterSelectInsertPoint(String sql) {
		return sql.startsWith("select distinct") ? 15 : 6;
	}

}
