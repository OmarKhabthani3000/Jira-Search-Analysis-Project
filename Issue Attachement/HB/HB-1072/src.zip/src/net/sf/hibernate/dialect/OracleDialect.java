//$Id: OracleDialect.java,v 1.9 2003/04/25 03:40:32 oneovthafew Exp $
package net.sf.hibernate.dialect;

import net.sf.hibernate.sql.CaseFragment;
import net.sf.hibernate.sql.DecodeCaseFragment;
import net.sf.hibernate.sql.OracleJoinFragment;
import net.sf.hibernate.sql.JoinFragment;

/**
 * An SQL dialect for Oracle, compatible with Oracle 8.
 * @author Gavin King
 */
public class OracleDialect extends Oracle9Dialect {
	
	public OracleDialect() {
		super();
	}	
	public JoinFragment createOuterJoinFragment() {
		return new OracleJoinFragment();
	}
	public CaseFragment createCaseFragment() {
		return new DecodeCaseFragment();
	}

}








