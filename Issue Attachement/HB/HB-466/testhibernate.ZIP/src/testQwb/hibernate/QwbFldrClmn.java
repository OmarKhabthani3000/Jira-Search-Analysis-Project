package testQwb.hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class QwbFldrClmn implements Serializable {

    /** identifier field */
    private Integer fldrClmnNum;

    /** persistent field */
    private int fldrNum;

    /** persistent field */
    private int sqncNum;

    /** persistent field */
    private Date creatTs;

    /** persistent field */
    private String creatUserId;

    /** nullable persistent field */
    private Date updtTs;

    /** nullable persistent field */
    private String updtUserId;

    /** persistent field */
    private testQwb.hibernate.QwbDataSrcClmn qwbDataSrcClmn;

    /** full constructor */
    public QwbFldrClmn(Integer fldrClmnNum, int fldrNum, int sqncNum, Date creatTs, String creatUserId, Date updtTs, String updtUserId, testQwb.hibernate.QwbDataSrcClmn qwbDataSrcClmn) {
        this.fldrClmnNum = fldrClmnNum;
        this.fldrNum = fldrNum;
        this.sqncNum = sqncNum;
        this.creatTs = creatTs;
        this.creatUserId = creatUserId;
        this.updtTs = updtTs;
        this.updtUserId = updtUserId;
        this.qwbDataSrcClmn = qwbDataSrcClmn;
    }

    /** default constructor */
    public QwbFldrClmn() {
    }

    /** minimal constructor */
    public QwbFldrClmn(Integer fldrClmnNum, int fldrNum, int sqncNum, Date creatTs, String creatUserId, testQwb.hibernate.QwbDataSrcClmn qwbDataSrcClmn) {
        this.fldrClmnNum = fldrClmnNum;
        this.fldrNum = fldrNum;
        this.sqncNum = sqncNum;
        this.creatTs = creatTs;
        this.creatUserId = creatUserId;
        this.qwbDataSrcClmn = qwbDataSrcClmn;
    }

    public Integer getFldrClmnNum() {
        return this.fldrClmnNum;
    }

    public void setFldrClmnNum(Integer fldrClmnNum) {
        this.fldrClmnNum = fldrClmnNum;
    }

    public int getFldrNum() {
        return this.fldrNum;
    }

    public void setFldrNum(int fldrNum) {
        this.fldrNum = fldrNum;
    }

    public int getSqncNum() {
        return this.sqncNum;
    }

    public void setSqncNum(int sqncNum) {
        this.sqncNum = sqncNum;
    }

    public Date getCreatTs() {
        return this.creatTs;
    }

    public void setCreatTs(Date creatTs) {
        this.creatTs = creatTs;
    }

    public String getCreatUserId() {
        return this.creatUserId;
    }

    public void setCreatUserId(String creatUserId) {
        this.creatUserId = creatUserId;
    }

    public Date getUpdtTs() {
        return this.updtTs;
    }

    public void setUpdtTs(Date updtTs) {
        this.updtTs = updtTs;
    }

    public String getUpdtUserId() {
        return this.updtUserId;
    }

    public void setUpdtUserId(String updtUserId) {
        this.updtUserId = updtUserId;
    }

    public testQwb.hibernate.QwbDataSrcClmn getQwbDataSrcClmn() {
        return this.qwbDataSrcClmn;
    }

    public void setQwbDataSrcClmn(testQwb.hibernate.QwbDataSrcClmn qwbDataSrcClmn) {
        this.qwbDataSrcClmn = qwbDataSrcClmn;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("fldrClmnNum", getFldrClmnNum())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof QwbFldrClmn) ) return false;
        QwbFldrClmn castOther = (QwbFldrClmn) other;
        return new EqualsBuilder()
            .append(this.getFldrClmnNum(), castOther.getFldrClmnNum())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getFldrClmnNum())
            .toHashCode();
    }

}
