package testQwb.hibernate;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class QwbDataSrcClmn implements Serializable {

    /** identifier field */
    private Integer clmnNum;

    /** persistent field */
    private int dataSrcNum;

    /** persistent field */
    private String clmnName;

    /** persistent field */
    private String attrName;

    /** nullable persistent field */
    private String clmnDesc;

    /** persistent field */
    private String dataTypeCd;

    /** persistent field */
    private int dataOfstCnt;

    /** persistent field */
    private short dataLngthCnt;

    /** persistent field */
    private boolean dataScaleCnt;

    /** persistent field */
    private String nullSw;

    /** nullable persistent field */
    private String cdTblName;

    /** nullable persistent field */
    private String lstName;

    /** persistent field */
    private String ngtvNumSw;

    /** nullable persistent field */
    private String dataFrmtTxt;

    /** nullable persistent field */
    private String sasFldName;

    /** nullable persistent field */
    private String pcSasFldName;

    /** nullable persistent field */
    private String sasLabelTxt;

    /** persistent field */
    private Date creatTs;

    /** persistent field */
    private String creatUserId;

    /** nullable persistent field */
    private Date updtTs;

    /** nullable persistent field */
    private String updtUserId;

    /** persistent field */
    private int sqncNum;

    /** nullable persistent field */
    private String sasCmtTxt;

    /** nullable persistent field */
    private String slctTxt;

    /** nullable persistent field */
    private String tmpltOnlySw;

    /** persistent field */
    private String newClmnSw;

    /** persistent field */
    private String fldrUpgrdSw;

    /** nullable persistent field */
    private Integer padKeySqncNum;

    /** persistent field */
    private Set qwbFldrClmns;

    /** full constructor */
    public QwbDataSrcClmn(Integer clmnNum, int dataSrcNum, String clmnName, String attrName, String clmnDesc, String dataTypeCd, int dataOfstCnt, short dataLngthCnt, boolean dataScaleCnt, String nullSw, String cdTblName, String lstName, String ngtvNumSw, String dataFrmtTxt, String sasFldName, String pcSasFldName, String sasLabelTxt, Date creatTs, String creatUserId, Date updtTs, String updtUserId, int sqncNum, String sasCmtTxt, String slctTxt, String tmpltOnlySw, String newClmnSw, String fldrUpgrdSw, Integer padKeySqncNum, Set qwbFldrClmns) {
        this.clmnNum = clmnNum;
        this.dataSrcNum = dataSrcNum;
        this.clmnName = clmnName;
        this.attrName = attrName;
        this.clmnDesc = clmnDesc;
        this.dataTypeCd = dataTypeCd;
        this.dataOfstCnt = dataOfstCnt;
        this.dataLngthCnt = dataLngthCnt;
        this.dataScaleCnt = dataScaleCnt;
        this.nullSw = nullSw;
        this.cdTblName = cdTblName;
        this.lstName = lstName;
        this.ngtvNumSw = ngtvNumSw;
        this.dataFrmtTxt = dataFrmtTxt;
        this.sasFldName = sasFldName;
        this.pcSasFldName = pcSasFldName;
        this.sasLabelTxt = sasLabelTxt;
        this.creatTs = creatTs;
        this.creatUserId = creatUserId;
        this.updtTs = updtTs;
        this.updtUserId = updtUserId;
        this.sqncNum = sqncNum;
        this.sasCmtTxt = sasCmtTxt;
        this.slctTxt = slctTxt;
        this.tmpltOnlySw = tmpltOnlySw;
        this.newClmnSw = newClmnSw;
        this.fldrUpgrdSw = fldrUpgrdSw;
        this.padKeySqncNum = padKeySqncNum;
        this.qwbFldrClmns = qwbFldrClmns;
    }

    /** default constructor */
    public QwbDataSrcClmn() {
    }

    /** minimal constructor */
    public QwbDataSrcClmn(Integer clmnNum, int dataSrcNum, String clmnName, String attrName, String dataTypeCd, int dataOfstCnt, short dataLngthCnt, boolean dataScaleCnt, String nullSw, String ngtvNumSw, Date creatTs, String creatUserId, int sqncNum, String newClmnSw, String fldrUpgrdSw, Set qwbFldrClmns) {
        this.clmnNum = clmnNum;
        this.dataSrcNum = dataSrcNum;
        this.clmnName = clmnName;
        this.attrName = attrName;
        this.dataTypeCd = dataTypeCd;
        this.dataOfstCnt = dataOfstCnt;
        this.dataLngthCnt = dataLngthCnt;
        this.dataScaleCnt = dataScaleCnt;
        this.nullSw = nullSw;
        this.ngtvNumSw = ngtvNumSw;
        this.creatTs = creatTs;
        this.creatUserId = creatUserId;
        this.sqncNum = sqncNum;
        this.newClmnSw = newClmnSw;
        this.fldrUpgrdSw = fldrUpgrdSw;
        this.qwbFldrClmns = qwbFldrClmns;
    }

    public Integer getClmnNum() {
        return this.clmnNum;
    }

    public void setClmnNum(Integer clmnNum) {
        this.clmnNum = clmnNum;
    }

    public int getDataSrcNum() {
        return this.dataSrcNum;
    }

    public void setDataSrcNum(int dataSrcNum) {
        this.dataSrcNum = dataSrcNum;
    }

    public String getClmnName() {
        return this.clmnName;
    }

    public void setClmnName(String clmnName) {
        this.clmnName = clmnName;
    }

    public String getAttrName() {
        return this.attrName;
    }

    public void setAttrName(String attrName) {
        this.attrName = attrName;
    }

    public String getClmnDesc() {
        return this.clmnDesc;
    }

    public void setClmnDesc(String clmnDesc) {
        this.clmnDesc = clmnDesc;
    }

    public String getDataTypeCd() {
        return this.dataTypeCd;
    }

    public void setDataTypeCd(String dataTypeCd) {
        this.dataTypeCd = dataTypeCd;
    }

    public int getDataOfstCnt() {
        return this.dataOfstCnt;
    }

    public void setDataOfstCnt(int dataOfstCnt) {
        this.dataOfstCnt = dataOfstCnt;
    }

    public short getDataLngthCnt() {
        return this.dataLngthCnt;
    }

    public void setDataLngthCnt(short dataLngthCnt) {
        this.dataLngthCnt = dataLngthCnt;
    }

    public boolean isDataScaleCnt() {
        return this.dataScaleCnt;
    }

    public void setDataScaleCnt(boolean dataScaleCnt) {
        this.dataScaleCnt = dataScaleCnt;
    }

    public String getNullSw() {
        return this.nullSw;
    }

    public void setNullSw(String nullSw) {
        this.nullSw = nullSw;
    }

    public String getCdTblName() {
        return this.cdTblName;
    }

    public void setCdTblName(String cdTblName) {
        this.cdTblName = cdTblName;
    }

    public String getLstName() {
        return this.lstName;
    }

    public void setLstName(String lstName) {
        this.lstName = lstName;
    }

    public String getNgtvNumSw() {
        return this.ngtvNumSw;
    }

    public void setNgtvNumSw(String ngtvNumSw) {
        this.ngtvNumSw = ngtvNumSw;
    }

    public String getDataFrmtTxt() {
        return this.dataFrmtTxt;
    }

    public void setDataFrmtTxt(String dataFrmtTxt) {
        this.dataFrmtTxt = dataFrmtTxt;
    }

    public String getSasFldName() {
        return this.sasFldName;
    }

    public void setSasFldName(String sasFldName) {
        this.sasFldName = sasFldName;
    }

    public String getPcSasFldName() {
        return this.pcSasFldName;
    }

    public void setPcSasFldName(String pcSasFldName) {
        this.pcSasFldName = pcSasFldName;
    }

    public String getSasLabelTxt() {
        return this.sasLabelTxt;
    }

    public void setSasLabelTxt(String sasLabelTxt) {
        this.sasLabelTxt = sasLabelTxt;
    }

    public Date getCreatTs() {
        return this.creatTs;
    }

    public void setCreatTs(Date creatTs) {
        this.creatTs = creatTs;
    }

    public String getCreatUserId() {
        return this.creatUserId;
    }

    public void setCreatUserId(String creatUserId) {
        this.creatUserId = creatUserId;
    }

    public Date getUpdtTs() {
        return this.updtTs;
    }

    public void setUpdtTs(Date updtTs) {
        this.updtTs = updtTs;
    }

    public String getUpdtUserId() {
        return this.updtUserId;
    }

    public void setUpdtUserId(String updtUserId) {
        this.updtUserId = updtUserId;
    }

    public int getSqncNum() {
        return this.sqncNum;
    }

    public void setSqncNum(int sqncNum) {
        this.sqncNum = sqncNum;
    }

    public String getSasCmtTxt() {
        return this.sasCmtTxt;
    }

    public void setSasCmtTxt(String sasCmtTxt) {
        this.sasCmtTxt = sasCmtTxt;
    }

    public String getSlctTxt() {
        return this.slctTxt;
    }

    public void setSlctTxt(String slctTxt) {
        this.slctTxt = slctTxt;
    }

    public String getTmpltOnlySw() {
        return this.tmpltOnlySw;
    }

    public void setTmpltOnlySw(String tmpltOnlySw) {
        this.tmpltOnlySw = tmpltOnlySw;
    }

    public String getNewClmnSw() {
        return this.newClmnSw;
    }

    public void setNewClmnSw(String newClmnSw) {
        this.newClmnSw = newClmnSw;
    }

    public String getFldrUpgrdSw() {
        return this.fldrUpgrdSw;
    }

    public void setFldrUpgrdSw(String fldrUpgrdSw) {
        this.fldrUpgrdSw = fldrUpgrdSw;
    }

    public Integer getPadKeySqncNum() {
        return this.padKeySqncNum;
    }

    public void setPadKeySqncNum(Integer padKeySqncNum) {
        this.padKeySqncNum = padKeySqncNum;
    }

    public Set getQwbFldrClmns() {
        return this.qwbFldrClmns;
    }

    public void setQwbFldrClmns(Set qwbFldrClmns) {
        this.qwbFldrClmns = qwbFldrClmns;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("clmnNum", getClmnNum())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof QwbDataSrcClmn) ) return false;
        QwbDataSrcClmn castOther = (QwbDataSrcClmn) other;
        return new EqualsBuilder()
            .append(this.getClmnNum(), castOther.getClmnNum())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getClmnNum())
            .toHashCode();
    }

}
