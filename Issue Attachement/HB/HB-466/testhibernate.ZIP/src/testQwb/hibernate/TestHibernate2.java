package testQwb.hibernate;

import java.util.Iterator;
import java.util.List;

import net.sf.hibernate.Hibernate;
import net.sf.hibernate.Query;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;

public class TestHibernate2 {

  static String DATA_SRC_NUM = "2000";

  public static void main(String[] args) {


    try {

      QwbDataSrcClmn clm = null;

      SessionFactory sessions = new Configuration()
                .addClass(QwbDataSrcClmn.class)
                .addClass(QwbFldrClmn.class)
                .buildSessionFactory();

      System.out.println("opening session");

      Session session = sessions.openSession();
      Transaction t = session.beginTransaction();

      long start = System.currentTimeMillis();

      System.out.println("now iterating");

      Iterator it = session.iterate(
                "from QwbDataSrcClmn as f where f.dataSrcNum = :dataSrcNum",
                DATA_SRC_NUM, Hibernate.STRING);
                start = System.currentTimeMillis();

      while (it.hasNext() ) {
        clm = (QwbDataSrcClmn)it.next();
      }

      System.out.println("****************  iterate non-cached took " + (System.currentTimeMillis() - start));

      t.commit();
      session.close();

      sessions.close();

    } catch (Exception e) {
      e.printStackTrace();
    }

  }

}
