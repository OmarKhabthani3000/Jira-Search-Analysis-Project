package com.tangible.test;

import com.tangible.test.bo.User;
import com.tangible.test.bo.Project;
import com.tangible.test.bo.UserDetails;
import com.tangible.test.bo.Role;
import com.tangible.test.dao.UserDAO;
import com.tangible.test.dao.ProjectDAO;
import com.tangible.test.dao.SessionHandler;
import net.sf.hibernate.HibernateException;
import org.apache.log4j.Logger;

/**
 * Tangible Class Description
 *
 * @author Simon
 *         Date: 10-Jun-2004
 */
public class MainTest {

    private int uniqueNumber;

    private User user;

    private UserDAO userDAO;
    private ProjectDAO projectDAO;

    private Logger logger;

    private Project project;

    public static void main(String args[]) {
        MainTest maintest = new MainTest();

        maintest.setup();
        maintest.test();
        maintest.cleanUp();
    }

    private void test() {
        project = insertProject();
        updateProject(project);
    }

    private void updateProject(Project project) {
        project.setName("NEW_PROJECT_NAME");

        Role firstUsersRole = (Role) project.getUserDetails(user).getRoles().iterator().next();
        project.removeRole(firstUsersRole);
        project.removeUser(user);

        logger.info("\n\n** UPDATING PROJECT **\n");

        try {
            projectDAO.update(project);
        } catch (HibernateException he) {
            logger.error("Error inserting project", he);
        } finally {
            SessionHandler.closeCurrentSession();
        }
        logger.info("\n\n** UPDATED PROJECT **\n");

    }

    private Project insertProject() {

        Project project = new Project();

        Role roleOne = new Role();
        Role roleTwo = new Role();
        roleOne.setName("ROLE_1");
        roleTwo.setName("ROLE_2");

        project.addRole(roleOne);
        project.addRole(roleTwo);

        project.setName("PROJECT|" + getUniqueNumber());

        UserDetails userOneDetails = new UserDetails();
        userOneDetails.setLockedForProject(true);
        userOneDetails.setAdminUser(false);
        userOneDetails.addRole(roleOne);

        project.addUser(user, userOneDetails);

        logger.info("\n\n** INSERTING PROJECT **\n");

        try {
            projectDAO.insert(project);

        } catch (HibernateException he) {
            logger.error("Error inserting project", he);
        } finally {
            SessionHandler.closeCurrentSession();
        }

        logger.info("\n\n** INSERTED PROJECT **\n\n");

        return project;
    }

    private void setup() {
        user = getPersistedUser();
        SessionHandler.closeCurrentSession();
    }

    public MainTest() {
        userDAO = new UserDAO();
        projectDAO = new ProjectDAO();
        logger = Logger.getLogger(this.getClass());
    }

    private void cleanUp() {

        logger.info("\n\n** DELETING PROJECT **\n");

        try {
            projectDAO.delete(project);
        } catch (HibernateException he) {
            logger.error("Error deleting project", he);
        }

        logger.info("\n\n** DELETED PROJECT **\n\n");


            try {
                userDAO.delete(user);
            } catch (HibernateException he) {
                logger.error("Error deleting user", he);
            }

    }

    private User getPersistedUser() {

        User user = new User();

        user.setName("USER_NAME|" + getUniqueNumber());

        try {
            userDAO.insert(user);
        } catch (HibernateException he) {
            logger.error("Error inserting user", he);
        }

        return user;
    }

    private int getUniqueNumber() {
        return ++uniqueNumber;
    }

}
