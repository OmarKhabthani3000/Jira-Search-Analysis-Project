package com.tangible.test.dao;

import com.tangible.test.bo.User;

/**
 * Tangible Class Description
 *
 * @author Simon
 *         Date: 10-Jun-2004
 */
public class UserDAO extends BaseDAO {

    protected Class getDAOObjectClass() {
        return User.class;
    }

    protected boolean isUpdateWithCopy() {
        return false;
    }
}
