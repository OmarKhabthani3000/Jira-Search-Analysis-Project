package com.tangible.test.dao;

import com.tangible.test.bo.Project;


/**
 * Tangible Class Description
 *
 * @author Simon
 *         Date: 10-Jun-2004
 */
public class ProjectDAO extends BaseDAO {

    protected Class getDAOObjectClass() {
        return Project.class;
    }

    protected boolean isUpdateWithCopy() {
        return true;
    }
}
