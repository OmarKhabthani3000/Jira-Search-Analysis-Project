package com.tangible.test.dao;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;
import org.apache.log4j.Logger;

/**
 * Tangible Class Description
 *
 * @author Simon
 *         Date: 10-Jun-2004
 */
public class SessionHandler {

    private static ThreadLocal session;
    private static SessionFactory factory;
    private static Logger logger;

    static {
        session = new ThreadLocal();
        logger = Logger.getLogger(SessionHandler.class);
        try {
            factory = new Configuration().configure().buildSessionFactory();
        } catch (HibernateException he) {
            getLogger().fatal("Hibernate error configuring session factory", he);
        } catch (Exception e) {
            getLogger().fatal("General error configuring session factory", e);
        }
    }

    private static Logger getLogger() {
        return logger;
    }

    public static Session getCurrentSession() {

        Session currentSession = (Session) session.get();

        if (currentSession == null) {
            try {
                currentSession = factory.openSession();
                session.set(currentSession);
            } catch (HibernateException he) {
                getLogger().error("Error opening session", he);
            }
        }

        return currentSession;

    }

    public static void closeCurrentSession() {
        Session currentSession = (Session) session.get();

        if (currentSession != null) {
            try {
                currentSession.close();
            } catch (HibernateException he) {
                getLogger().error("Error closing session", he);
            }
            session.set(null);
        }
    }

}
