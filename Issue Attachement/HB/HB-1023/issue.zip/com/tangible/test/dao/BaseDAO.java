package com.tangible.test.dao;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.Transaction;
import org.apache.log4j.Logger;

import java.io.Serializable;

/**
 * Tangible Class Description
 *
 * @author Simon
 *         Date: 10-Jun-2004
 */
public abstract class BaseDAO {

    private Logger logger;

    public BaseDAO() {
        logger = Logger.getLogger(getDAOClass());
    }

    private Class getDAOClass() {
        return this.getClass();
    }

    protected Logger getLogger() {
        return logger;
    }

    public void insert(Object insertObject) throws HibernateException {
        try {
            Session session = SessionHandler.getCurrentSession();
            Transaction trans = session.beginTransaction();

            session.save(insertObject);

            session.flush();
            trans.commit();
        } catch (HibernateException he) {
            getLogger().error("Error inserting object", he);
            throw he;
        }
    }

    public void delete(Object deleteObject) throws HibernateException {
        try {
            Session session = SessionHandler.getCurrentSession();
            Transaction trans = session.beginTransaction();

            session.delete(deleteObject);

            session.flush();
            trans.commit();
        } catch (HibernateException he) {
            getLogger().error("Error deleting object", he);
            throw he;
        }
    }

    public void update(Object updateObject) throws HibernateException {
        try {
            Session session = SessionHandler.getCurrentSession();
            Transaction trans = session.beginTransaction();

            if (isUpdateWithCopy()) {
                session.saveOrUpdateCopy(updateObject);
            } else {
                session.saveOrUpdate(updateObject);
            }

            session.flush();
            trans.commit();
        } catch (HibernateException he) {
            getLogger().error("Error updating object", he);
            throw he;
        }
    }

    public void load(Serializable primaryKey) throws HibernateException {
        try {
            Session session = SessionHandler.getCurrentSession();
            Transaction trans = session.beginTransaction();

            session.load(getDAOObjectClass(), primaryKey);

            session.flush();
            trans.commit();
        } catch (HibernateException he) {
            getLogger().error("Error loading object", he);
            throw he;
        }
    }

    protected abstract Class getDAOObjectClass();

    protected abstract boolean isUpdateWithCopy();
}
