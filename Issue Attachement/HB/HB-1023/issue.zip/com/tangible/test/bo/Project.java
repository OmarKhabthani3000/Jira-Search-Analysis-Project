package com.tangible.test.bo;

import java.util.Set;
import java.util.Map;
import java.util.HashSet;
import java.util.HashMap;

/**
 * Tangible Class Description
 *
 * @author Simon
 *         Date: 10-Jun-2004
 * @hibernate.class
 * table="PROJECT"
 */
public class Project {

    private int id;
    private String name;

    private Map userDetails;
    private Set roles;

    /**
     * @hibernate.id
     * generator-class="native"
     * type="int"
     * column="PROJECT_ID"
     * unsaved-value="0"
     * @return
     */
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    /**
     * @hibernate.property
     * column="PROJECT_NAME"
     * type="string"
     * length="25"
     * @return
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * @hibernate.map cascade="all-delete-orphan"
     * @hibernate.index-many-to-many column="USER_ID" class="com.tangible.test.bo.User"
     * @hibernate.collection-key column="PROJECT_ID"
     * @hibernate.collection-one-to-many class="com.tangible.test.bo.UserDetails"
     * @return
     */
    public Map getUserDetails() {
        if (userDetails == null) {
            userDetails = new HashMap();
        }

        return userDetails;
    }

    public void setUserDetails(Map userDetails) {
        this.userDetails = userDetails;
    }

    /**
     * @hibernate.set cascade="all-delete-orphan"
     * @hibernate.collection-key column="PROJECT_ID"
     * @hibernate.collection-one-to-many class="com.tangible.test.bo.Role"
     * @return
     */
    public Set getRoles() {

        if (roles == null) {
            roles = new HashSet();
        }
        return roles;
    }

    public void setRoles(Set roles) {
        this.roles = roles;
    }

    public void addRole(Role role) {
        getRoles().add(role);
    }

    public void removeRole(Role role) {
        getRoles().remove(role);
    }

    public void addUser(User user, UserDetails userDetails) {
        getUserDetails().put(user, userDetails);
    }

    public UserDetails getUserDetails(User user) {
        return (UserDetails) getUserDetails().get(user);
    }

    public void removeUser(User user) {
        getUserDetails().remove(user);
    }
}
