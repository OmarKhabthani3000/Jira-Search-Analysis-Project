package com.tangible.test.bo;

/**
 * Tangible Class Description
 *
 * @author Simon
 *         Date: 10-Jun-2004
 * @hibernate.class
 * table="TANGIBLE_USER"
 */
public class User {

    private int id;
    private String name;

    /**
     * @return
     * @hibernate.id generator-class="native"
     * type="int"
     * column="USER_ID"
     * unsaved-value="0"
     */
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return
     * @hibernate.property column="USERNAME"
     * type="string"
     * length="25"
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;

        final User user = (User) o;

        if (!name.equals(user.name)) return false;

        return true;
    }

    public int hashCode() {
        return name.hashCode();
    }
}
