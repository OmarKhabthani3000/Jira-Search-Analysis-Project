package com.tangible.test.bo;

import java.util.HashSet;
import java.util.Set;

/**
 * Tangible Class Description
 *
 * @author Simon
 *         Date: 10-Jun-2004
 * @hibernate.class table="PROJECT_USER"
 */
public class UserDetails {

    private boolean adminUser;
    private boolean lockedForProject;
    private Set roles;
    private int id;

    /**
     * @return
     * @hibernate.id generator-class="native"
     * type="int"
     * column="PROJECT_USER_ID"
     * unsaved-value="0"
     */
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return
     * @hibernate.property type="boolean"
     * column="ADMIN_USER"
     */
    public boolean isAdminUser() {
        return adminUser;
    }

    public void setAdminUser(boolean adminUser) {
        this.adminUser = adminUser;
    }

    /**
     * @return
     * @hibernate.property type="boolean"
     * column="LOCKED_FOR_PROJECT"
     */
    public boolean isLockedForProject() {
        return lockedForProject;
    }

    public void setLockedForProject(boolean lockedForProject) {
        this.lockedForProject = lockedForProject;
    }

    /**
     * @return
     * @hibernate.set table="PROJECT_USER_ROLES" cascade="none"
     * @hibernate.collection-key column="PROJECT_USER_ID"
     * @hibernate.collection-many-to-many column="ROLE_ID" class="com.tangible.test.bo.Role"
     */
    public Set getRoles() {

        if (roles == null) {
            roles = new HashSet();
        }
        return roles;
    }

    public void setRoles(Set roles) {
        this.roles = roles;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UserDetails)) return false;

        final UserDetails details = (UserDetails) o;

        if (adminUser != details.adminUser) return false;
        if (lockedForProject != details.lockedForProject) return false;
        if (!roles.equals(details.roles)) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (adminUser ? 1 : 0);
        result = 29 * result + (lockedForProject ? 1 : 0);
        result = 29 * result + roles.hashCode();
        return result;
    }

    public void addRole(Role role) {
        getRoles().add(role);
    }

    public void removeRole(Role role) {
        getRoles().remove(role);
    }
}
