package com.tangible.test.bo;

/**
 * Tangible Class Description
 *
 * @author Simon
 *         Date: 10-Jun-2004
 * @hibernate.class
 * table="TANGIBLE_ROLE"
 */
public class Role {

    private int id;
    private String name;

    /**
     * @return
     * @hibernate.id generator-class="native"
     * type="int"
     * column="ROLE_ID"
     * unsaved-value="0"
     */
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return
     * @hibernate.property column="ROLE_NAME"
     * type="string"
     * length="25"
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Role)) return false;

        final Role role = (Role) o;

        if (!name.equals(role.name)) return false;

        return true;
    }

    public int hashCode() {
        return name.hashCode();
    }
}
