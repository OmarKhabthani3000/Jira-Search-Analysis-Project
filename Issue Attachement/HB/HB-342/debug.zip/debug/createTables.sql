/** Create the tables used by the tests in this package.
 * These commands are in the SQL dialect of Microsoft SQL Server.
 */
CREATE TABLE DRPermission(
    ID                  int              IDENTITY(1,1),
    version             int              DEFAULT 1 NOT NULL,
    code                nvarchar(255)     NULL,
    permissionString    nvarchar(255)     NOT NULL,
    description         nvarchar(2000)    NULL,
    CONSTRAINT DRPK20 PRIMARY KEY CLUSTERED (ID)
) 

CREATE TABLE DRRole(
    ID             int              IDENTITY(1,1),
    version        int              DEFAULT 1 NOT NULL,
    name           nvarchar(255)     NULL,
    description    nvarchar(2000)    NULL,
    CONSTRAINT DRPK19 PRIMARY KEY CLUSTERED (ID)
) 

CREATE TABLE DRRolePermissionMap(
    roleID          int    NOT NULL,
    permissionID    int    NOT NULL,
    version         int    DEFAULT 1 NOT NULL,
    isGrant         int    NULL,
    CONSTRAINT DRPK21 PRIMARY KEY CLUSTERED (roleID, permissionID)
) 
