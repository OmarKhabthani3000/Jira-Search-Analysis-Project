Here is a test case for a problem with Hibernate, reported as
http://opensource.atlassian.com/projects/hibernate/secure/ViewIssue.jspa?key=HB-342

See log.txt for an example stack trace, with preceding DEBUG level logging.
See TestCache.java for the code that elicited the problem.
See createTables.sql for SQL that created the tables used in this test case.

Part of the problem, it appears, is that Hibernate uses a RolePermissionAssociation$Id
as a key for a JCS region map, but the Id refers to a Role whose id has not been loaded.
Subsequently, Hibernate loads the Role id, which changes the RolePermissionAssociation
Id.hashCode(), which causes the Id to be 'lost' in the JCS region map.  For example:

2003-09-17 13:49:52,328 DEBUG [net.sf.hibernate.cache.ReadWriteCache] Cached: {Role#null@686, Permission#65@757}@758
2003-09-17 13:49:52,328 DEBUG [net.sf.hibernate.impl.SessionImpl] done materializing entity [com.docent.lms.entities.tests.hibernate.RolePermissionAssociation#{Role#null@686, Permission#65@757}@758]
2003-09-17 13:49:52,328 DEBUG [com.docent.lms.entities.tests.hibernate.Role] Role#null@686.setId(4)

Eventually, the JCS region contains several such lost keys in its map but nothing in its
list (all entries were spooled because the map contains more keys than the cache size limit).
At this point, JCS throws the problematic exception.

The problem occurs faster if JCS is configured with a small cache size, as in cache.ccf
jcs.default.cacheattributes.MaxObjects=10

- John Kristian <jkristian@docent.com>
