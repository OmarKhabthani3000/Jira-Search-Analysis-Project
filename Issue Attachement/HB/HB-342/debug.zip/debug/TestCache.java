package com.docent.lms.entities.tests.hibernate;

import com.docent.lms.entities.reference.EntityUtility;
import java.util.Iterator;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.MappingException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;
import org.apache.cactus.ServletTestCase;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** Test caching of associations between roles and permissions.
 * <a href="http://jakarta.apache.org/cactus/">Cactus</a> provides supporting infrastructure.
 *
 * @author Copyright (c) 2003 by Docent, Inc.  All Rights Reserved.
 * @author <a href="mailto:jkristian@docent.com">John Kristian</a>
 */
public class TestCache extends ServletTestCase {

    /** <a href="http://junit.org/">JUnit</a> boilerplate */
    public TestCache(String name)
    {
        super(name);
    }

    /** Read associations between roles and permissions, in two consecutive sessions.
     * The first session copies objects from the database to the global JCS cache;
     * the second session find the same objects in the cache, including
     * RolePermissionAssociation objects whose id contains a reference to Role
     * objects that are (regrettably) contained in the first (closed) session.
     * Each such Role contains a lazy Set, which (regrettably) fails to initialize
     * because its session is closed, propagating an exception from Set.iterator().
    public void testAssociation()
        throws Throwable
    {
        String testName = "testAssociation";
        log.info(testName);
        try {
            SessionFactory sessionFactory = buildSessionFactory();
            try {
                Session session = openSession(sessionFactory, new Context());
                try {
                    assertTrue("session.contains(role)", session.contains(findRole(session)));

                    session.close();
                    session = openSession(sessionFactory, new Context());

                    Role role = findRole(session);
                    // assertTrue("session.contains(role)", session.contains(role));
                    for (Iterator i = role.getAssociations().iterator(); // An exception is thrown here.
                         i.hasNext(); )
                    {
                        RolePermissionAssociation association = (RolePermissionAssociation)(i.next());
                        assertTrue("session.contains(association)", session.contains(association));
                        Permission permission = association.getId().getPermission();
                        assertTrue("session.contains(permission)", session.contains(permission));
                        break;
                    }
                } finally {
                    session.close();
                }
            } finally {
                sessionFactory.close();
            }
        } catch(Throwable e) {
            log.error(testName + " failed", e);
            throw e; // report this error to JUnit
        }
    }
     */

    public void testScan()
        throws Throwable
    {
        String testName = "testScan";
        log.info(testName);
        try {
            SessionFactory sessionFactory = buildSessionFactory();
            try {
                Session session = openSession(sessionFactory, new Context());
                try {
                    scan(session);
                    session.close();
                    session = openSession(sessionFactory, new Context());
                    scan(session);
                } finally {
                    session.close();
                }
            } finally {
                sessionFactory.close();
            }
        } catch(Throwable e) {
            log.error(testName + " failed", e);
            throw e; // report this error to JUnit
        }
    }

    protected void scan(Session session)
        throws HibernateException
    {
        for (Iterator i = session.iterate("FROM entity IN CLASS " + Role.class.getName()); i.hasNext(); ) {
            Role role = (Role)(i.next());
            for (Iterator j = role.getAssociations().iterator(); j.hasNext(); ) {
                RolePermissionAssociation association = (RolePermissionAssociation)(j.next());
                Permission permission = association.getId().getPermission();
                assertTrue("session.contains(permission)", session.contains(permission));
            }
        }
    }

    protected static Role findRole(Session session)
        throws Exception
    {
        for (Iterator i = session.iterate("FROM entity IN CLASS " + Permission.class.getName()); i.hasNext(); ) {
            Permission permission = (Permission)(i.next());
            assertTrue("session.contains(permission)", session.contains(permission));
            for (Iterator j = permission.getAssociations().iterator(); j.hasNext(); ) {
                RolePermissionAssociation association = (RolePermissionAssociation)(j.next());
                assertTrue("session.contains(association)", session.contains(association));
                Role role = association.getId().getRole();
                return role;
            }
        }
        return null;
    }

    protected Session openSession(SessionFactory factory, Context context)
        throws HibernateException
    {
        Session session = factory.openSession(context);
        context.setSession(session);
        return session;
    }

    protected SessionFactory buildSessionFactory()
        throws Exception
    {
        Configuration configuration = EntityUtility.getConfiguration();
        configureClass(configuration, Permission.class);
        configureClass(configuration, Role.class);
        configureClass(configuration, RolePermissionAssociation.class);
        return configuration.buildSessionFactory();
    }

    protected void configureClass(Configuration configuration, Class persistentClass)
        throws MappingException
    {
        if (configuration.getClassMapping(persistentClass) == null) {
            configuration.addClass(persistentClass);
        }
    }

    protected final static Log log = LogFactory.getLog(TestCache.class);

}
