package com.docent.lms.entities.tests.hibernate;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** A utility class, implementing behaviors common to all entities.
 *
 * @author Copyright (c) 2003 by Docent, Inc.  All Rights Reserved.
 * @author <a href="mailto:jkristian@docent.com">John Kristian</a>
 */
public class Entity {

    protected Log log;

    public Entity()
    {
        log = LogFactory.getLog(getClass());
    }

    /** Distinguishes this entity from all others. */
    protected final long instance = getSequenceNumber();

    /** Generate a sequence number.  The generator is a static field of this class. */
    public static synchronized long getSequenceNumber()
    {
        return nextSequenceNumber++;
    }

    private static long nextSequenceNumber = 1;

}
