package com.docent.lms.entities.tests.hibernate;

import java.io.Serializable;
import java.util.Set;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** A relationship between a role and a permission.
 *
 * @author Copyright (c) 2003 by Docent, Inc.  All Rights Reserved.
 * @author <a href="mailto:jkristian@docent.com">John Kristian</a>
 */
public class RolePermissionAssociation implements SessionAware {

    /** The identifier of a RolePermissionAssociation. */
    public static final class Id implements Serializable {

        public Role getRole()
        {return role;}
        private void setRole(Role role)
        {this.role = role;}
        private Role role;

        public Permission getPermission()
        {return permission;}
        private void setPermission(Permission permission)
        {this.permission = permission;}
        private Permission permission;

        public boolean equals(Object obj)
        {
            if (!(obj instanceof Id)) return false;
            Id that = (Id)obj;
            if (!(this.role.equals(that.role))) return false;
            if (!(this.permission.equals(that.permission))) return false;
            return true;
        }

        public int hashCode()
        {
            int result = 0;
            if (null!=role) result ^= role.hashCode();
            if (null!=permission) result ^= permission.hashCode();
            return result;
        }

        public Id() {}

        public Id(Role role, Permission permission)
        {
            this.role = role;
            this.permission = permission;
        }

        void setSession(Session session)
            throws HibernateException
        {
            if (role != null && ! session.contains(role)) {
                role = (Role)(session.load(Role.class, role.getId()));
            }
            if (permission != null && ! session.contains(permission)) {
                permission = (Permission)(session.load(Permission.class, permission.getId()));
            }
        }

        public String toString()
        {
            return "{" + role + ", " + permission + "}";
        }

    }

    public String toString()
    {
        return "RolePermissionAssociation#" + getId();
    }

    public RolePermissionAssociation.Id getId()
    {return id;}
    private Id id;
    private void setId(RolePermissionAssociation.Id id)
        throws HibernateException
    {
        if (log.isWarnEnabled()) {
            if (log.isDebugEnabled()) {
                log.debug("idChanged(" + this.id + " -> " + id + ")");
            }
            if (session != null) {
                assertSessionContains(this);
                assertSessionContains(id.getRole());
                assertSessionContains(id.getPermission());
                // id.setSession(session); // to work around the problem
            }
        }
        this.id = id;
    }
    private void assertSessionContains(Object entity)
    {
        if ( ! session.contains(entity)) {
            log.warn("! session.contains(" + entity + ")");
        }
    }

    /** Identifier equality (ids are equal). */
    public boolean equals(Object that)
    {
        return (getId() == null) ? super.equals(that) /* Java object identity */ :
            ((that instanceof RolePermissionAssociation)
             && getId().equals(((RolePermissionAssociation)that).getId())); /* database id */
    }

    /** Identifier equality (ids are equal). */
    public int hashCode()
    {
        return (getId() == null) ? super.hashCode() /* Java object identity */ :
            getId().hashCode(); /* database id */
    }

    public long getVersion()
    {return version;}
    private void setVersion(long version)
    {this.version = version;}
    private long version;

    /** Get whether permission is granted (true) or denied (false). */
    public boolean isGrant()
    {return grant;}
    private void setGrant(boolean grant)
    {this.grant = grant;}
    private boolean grant;

    public void setSession(Session session)
    {this.session = session;}
    private Session session;

    protected Log log;

    public RolePermissionAssociation()
    {
        log = LogFactory.getLog(getClass());
    }

}
