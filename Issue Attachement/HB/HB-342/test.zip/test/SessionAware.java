package com.docent.lms.entities.tests.hibernate;

import net.sf.hibernate.Session;

public interface SessionAware {

    public void setSession(Session session);

}
