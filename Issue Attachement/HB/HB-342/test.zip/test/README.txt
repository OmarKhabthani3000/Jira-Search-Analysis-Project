Here is a test case for a problem with Hibernate, reported as
http://opensource.atlassian.com/projects/hibernate/secure/ViewIssue.jspa?key=HB-342

See log.txt for an example stack trace, with preceding DEBUG level logging.
See TestCache.java for the code that elicited the problem.
See createTables.sql for SQL that created the tables used in this test case.

- John Kristian <jkristian@docent.com>
