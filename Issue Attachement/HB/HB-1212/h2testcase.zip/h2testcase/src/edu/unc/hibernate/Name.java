package edu.unc.hibernate;

/**
 * Created by IntelliJ IDEA.
 * User: ses
 * Date: Sep 3, 2004
 * Time: 7:15:06 PM
 * To change this template use File | Settings | File Templates.
 */

import org.apache.log4j.Logger;

public class Name {
    private static Logger logger = Logger.getLogger(Name.class);
    private Integer id;

    public Name() {
    }

    public Name(String first, String last) {
        this.first = first;
        this.last = last;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirst() {
        return first;
    }

    public void setFirst(String first) {
        this.first = first;
    }

    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last;
    }

    private String first;
    private String last;
}
