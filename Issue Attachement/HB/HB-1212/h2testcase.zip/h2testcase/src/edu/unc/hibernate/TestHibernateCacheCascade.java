package edu.unc.hibernate;

/**
 * Created by IntelliJ IDEA.
 * User: ses
 * Date: Sep 3, 2004
 * Time: 7:25:33 PM
 * To change this template use File | Settings | File Templates.
 */

import org.apache.log4j.Logger;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.tool.hbm2ddl.DatabaseMetadata;
import net.sf.hibernate.dialect.HSQLDialect;
import junit.framework.TestCase;
import junit.framework.Test;
import junit.framework.TestSuite;
import junit.extensions.TestSetup;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.io.PrintWriter;

public class TestHibernateCacheCascade extends TestCase {
    private static Logger logger = Logger.getLogger(TestHibernateCacheCascade.class);
    private static SessionFactory factory;
    private Session session;
    private Transaction transaction;
    protected void setUp() throws Exception {
        super.setUp();
        this.session = factory.openSession();
        assertNotNull("session is null",session);

        Connection conn = session.connection();
        Statement st = conn.createStatement();
        assertFalse(st.execute("delete from Weasel"));
        assertFalse(st.execute("delete from Name"));
        st.close();
        this.transaction = session.beginTransaction();
    }

    protected void tearDown() throws Exception {
        this.transaction.commit();
        this.transaction = null;
        session.close();
        this.session = null;
        logger.info("session closed");
        super.tearDown();    //To change body of overridden methods use File | Settings | File Templates.
    }

    public void testSaveWithoutChange() throws Exception {
        Weasel weasel1 = new Weasel();
        weasel1.setName(new Name("fred","weasel"));
        weasel1.setId(new Integer(1));
        session.save(weasel1);

        Weasel weasel2 = new Weasel();
        weasel2.setName(new Name("simon","weasel"));
        weasel2.setId(new Integer(2));
        session.save(weasel2);

        assertNotNull("weasel1.id is null",weasel1.getId());
        assertNotNull("weasel2.id is null",weasel2.getId());
        assertNotNull("weasel1.name.id is null",weasel1.getName().getId());
        assertNotNull("weasel2.name.id is null",weasel2.getName().getId());
    }


    public void testSaveThenChange() throws Exception {
        Weasel weasel1 = new Weasel();
        weasel1.setId(new Integer(1));
        weasel1.setName(new Name("fred","weasel"));
        session.save(weasel1);
        assertNotNull("weasel1.id is null",weasel1.getId());
        assertNotNull("weasel1.name.id is null",weasel1.getName().getId());

        weasel1.setName(new Name("altered","weasel"));
        assertNull("weasel1.name.id is not null",weasel1.getName().getId());

        Weasel weasel2 = new Weasel();
        weasel2.setId(new Integer(2));
        weasel2.setName(new Name("simon","weasel"));
        session.save(weasel2);

        assertNotNull("weasel2.id is null",weasel2.getId());
        assertNotNull("weasel2.name.id is null",weasel2.getName().getId());
        session.flush();
        session.evict(weasel1);
        Weasel weasel3 = (Weasel) session.load(Weasel.class, new Integer(1));
        assertNotNull("weasel3 is null");
        assertEquals("alterned name","altered",weasel3.getName().getFirst());

    }

    public void testSaveFlushThenChange() throws Exception {
        Weasel weasel1 = new Weasel();
        weasel1.setId(new Integer(1));
        weasel1.setName(new Name("fred","weasel"));
        session.save(weasel1);
        assertNotNull("weasel1.id is null",weasel1.getId());
        assertNotNull("weasel1.name.id is null",weasel1.getName().getId());
        session.flush();

        weasel1.setName(new Name("altered","weasel"));
        assertNull("weasel1.name.id is not null",weasel1.getName().getId());

        Weasel weasel2 = new Weasel();
        weasel2.setId(new Integer(2));
        weasel2.setName(new Name("simon","weasel"));
        session.save(weasel2);

        assertNotNull("weasel2.id is null",weasel2.getId());
        assertNotNull("weasel2.name.id is null",weasel2.getName().getId());
        session.flush();
        session.evict(weasel1);
        Weasel weasel3 = (Weasel) session.load(Weasel.class, new Integer(1));
        assertNotNull("weasel3 is null");
        assertEquals("alterned name","altered",weasel3.getName().getFirst());

    }


    public static Test suite() {
        return new TestSetup(new TestSuite(TestHibernateCacheCascade.class)) {
            private  final HSQLDialect dialect = new HSQLDialect();
            protected void setUp() throws Exception {
                DriverManager.setLogWriter(new PrintWriter(System.out));
                Configuration cfg = new Configuration();
                factory =  cfg.configure().buildSessionFactory();
                assertNotNull("factory is null",factory);
                Session session = factory.openSession();
                assertNotNull("session is null",session);
                Connection conn = session.connection();
                assertNotNull("connection is null",conn);
                assertFalse("connection is closed",conn.isClosed());
               //executeScript(conn,cfg.generateDropSchemaScript(dialect));
                cfg.generateSchemaUpdateScript(dialect, new DatabaseMetadata(conn, dialect));
                executeScript(conn,cfg.generateSchemaUpdateScript(dialect, new DatabaseMetadata(conn, dialect)));
                session.close();

            }
            private void executeScript(Connection conn,String[] commands) throws SQLException {
                Statement st = conn.createStatement();
                for (int i = 0 ; i < commands.length; i++) {
                    String s = commands[i];
                  st.execute(s);
                }
            }

        };
    }


}
