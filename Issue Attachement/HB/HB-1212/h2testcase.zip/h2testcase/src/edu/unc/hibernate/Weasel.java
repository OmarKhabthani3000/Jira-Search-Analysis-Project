package edu.unc.hibernate;

/**
 * Created by IntelliJ IDEA.
 * User: ses
 * Date: Sep 3, 2004
 * Time: 7:14:41 PM
 * To change this template use File | Settings | File Templates.
 */

import org.apache.log4j.Logger;

public class Weasel {
    private static Logger logger = Logger.getLogger(Weasel.class);
    private Integer id;
    private Name name;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }
}
