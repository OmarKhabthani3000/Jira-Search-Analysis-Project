package com.hibernate.test.persistence;

import java.io.Serializable;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class NetPortalGroup implements Serializable {

    /** identifier field */
    private long id;

    /** persistent field */
    private String name;

    /** nullable persistent field */
    private java.util.Date expirationDate;

    /** persistent field */
    private int maxNoSimSess;

    /** persistent field */
    private int maxNoSess;

    /** persistent field */
    private Set subnetRights;

    /** full constructor */
    public NetPortalGroup(java.lang.String name, java.util.Date expirationDate, int maxNoSimSess, int maxNoSess, Set subnetRights) {
        this.name = name;
        this.expirationDate = expirationDate;
        this.maxNoSimSess = maxNoSimSess;
        this.maxNoSess = maxNoSess;
        this.subnetRights = subnetRights;
    }

    /** default constructor */
    public NetPortalGroup() {
    }

    /** minimal constructor */
    public NetPortalGroup(java.lang.String name, int maxNoSimSess, int maxNoSess, Set subnetRights) {
        this.name = name;
        this.maxNoSimSess = maxNoSimSess;
        this.maxNoSess = maxNoSess;
        this.subnetRights = subnetRights;
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public java.lang.String getName() {
        return this.name;
    }

    public void setName(java.lang.String name) {
        this.name = name;
    }

    public java.util.Date getExpirationDate() {
        return this.expirationDate;
    }

    public void setExpirationDate(java.util.Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    public int getMaxNoSimSess() {
        return this.maxNoSimSess;
    }

    public void setMaxNoSimSess(int maxNoSimSess) {
        this.maxNoSimSess = maxNoSimSess;
    }

    public int getMaxNoSess() {
        return this.maxNoSess;
    }

    public void setMaxNoSess(int maxNoSess) {
        this.maxNoSess = maxNoSess;
    }

    public java.util.Set getSubnetRights() {
        return this.subnetRights;
    }

    public void setSubnetRights(java.util.Set subnetRights) {
        this.subnetRights = subnetRights;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof NetPortalGroup) ) return false;
        NetPortalGroup castOther = (NetPortalGroup) other;
        return new EqualsBuilder()
            .append(this.getId(), castOther.getId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getId())
            .toHashCode();
    }

}
