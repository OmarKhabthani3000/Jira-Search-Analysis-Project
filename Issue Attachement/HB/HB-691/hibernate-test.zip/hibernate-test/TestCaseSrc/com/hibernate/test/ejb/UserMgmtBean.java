package com.hibernate.test.ejb;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

import com.hibernate.test.dao.DAOException;
import com.hibernate.test.persistence.NetPortalGroup;
import com.hibernate.test.persistence.NetPortalNetwork;
import com.hibernate.test.persistence.PersistentSession;

/**
 * Bean implementation class for Enterprise Bean: UserMgmt
 */
public class UserMgmtBean implements javax.ejb.SessionBean {
	private javax.ejb.SessionContext mySessionCtx;
	/**
	 * getSessionContext
	 */
	public javax.ejb.SessionContext getSessionContext() {
		return mySessionCtx;
	}
	/**
	 * setSessionContext
	 */
	public void setSessionContext(javax.ejb.SessionContext ctx) {
		mySessionCtx = ctx;
	}
	/**
	 * ejbCreate
	 */
	public void ejbCreate() throws javax.ejb.CreateException {
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() {
	}

	public NetPortalGroup addGroup(NetPortalGroup group) throws DAOException {
		PersistentSession session = null;
		session = new PersistentSession();

		UsersDAO dao = new UsersDAO(session);
		long id = 0;
		try {
			id = dao.createGroup(group);
		} catch (DAOException e) {
			e.printStackTrace();
			mySessionCtx.setRollbackOnly();
			throw e;
		} finally {
			session.close();
		}

		return group;
	}

	public NetPortalNetwork addNetwork(NetPortalNetwork net) throws DAOException {
		PersistentSession session = null;
		session = new PersistentSession();

		UsersDAO dao = new UsersDAO(session);
		long id = 0;
		try {
			id = dao.createNetwork(net);
		} catch (DAOException e) {
			e.printStackTrace();
			mySessionCtx.setRollbackOnly();
			throw e;
		} finally {
			session.close();
		}

		return net;
	}

	public NetPortalGroup updateGroup(NetPortalGroup group) throws DAOException {
		PersistentSession session = null;
		session = new PersistentSession();

		UsersDAO dao = new UsersDAO(session);
		try {
			dao.updateGroup(group);
		} catch (DAOException e) {
			e.printStackTrace();
			mySessionCtx.setRollbackOnly();
			throw e;
		} finally {
			session.close();
		}
		return group;
	}

	public NetPortalGroup getGroup(String groupName) throws DAOException {
		NetPortalGroup group = null;

		PersistentSession session = null;
		session = new PersistentSession();
		UsersDAO dao = new UsersDAO(session);
		try {
			group = dao.getGroup(groupName);
		} catch (DAOException e) {
			e.printStackTrace();
			mySessionCtx.setRollbackOnly();
			throw e;
		} finally {
			session.close();
		}
		return group;
	}
	
	
}
