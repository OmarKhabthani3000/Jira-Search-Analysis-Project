package com.hibernate.test;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.ejb.CreateException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;


import com.hibernate.test.dao.DAOException;
import com.hibernate.test.ejb.UserMgmt;
import com.hibernate.test.ejb.UserMgmtHome;
import com.hibernate.test.persistence.NetPortalGroup;
import com.hibernate.test.persistence.NetPortalNetwork;
import com.hibernate.test.persistence.PersistentSession;


/**
 * @author serban
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class UserHelper {
	private static UserMgmt userMgmt;

	static {
		// TODO Auto-generated constructor stub
		Properties properties = new java.util.Properties();
		properties.put(
			javax.naming.Context.INITIAL_CONTEXT_FACTORY,
			"org.jnp.interfaces.NamingContextFactory");
		String url = "";
		url += "localhost";
		url += ":";
		url += "1099";
		properties.put(Context.PROVIDER_URL, url);
		properties.put(
			Context.URL_PKG_PREFIXES,
			"org.jboss.naming:org.jnp.interfaces");
		InitialContext initialContext = null;
		try {
			initialContext = new javax.naming.InitialContext(properties);
		} catch (NamingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		Object objHome = null;
		UserMgmtHome userHome = null;
		try {
			userHome = (UserMgmtHome) initialContext.lookup("UserMgmt");
		} catch (NamingException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		try {
			userMgmt = userHome.create();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CreateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public NetPortalGroup addGroup(NetPortalGroup group) throws DAOException {
		NetPortalGroup ret=null;
		try {
			ret=userMgmt.addGroup(group);
		} catch (RemoteException e) {
			e.printStackTrace();
			throw new DAOException(e);
		}
		return ret;
	}

	public NetPortalNetwork addNetwork(NetPortalNetwork net) throws DAOException {
		NetPortalNetwork ret=null;
		try {
			ret=userMgmt.addNetwork(net);
		} catch (RemoteException e) {
			e.printStackTrace();
			throw new DAOException(e);
		}
		return ret;
	}

	public NetPortalGroup updateGroup(NetPortalGroup group) throws DAOException {
		NetPortalGroup ret = null;
		try {
			ret = userMgmt.updateGroup(group);
		} catch (RemoteException e) {
			e.printStackTrace();
			throw new DAOException(e);
		}
		return ret;  
	}

	public NetPortalGroup getGroup(String groupName) throws DAOException {
		NetPortalGroup group = null;
		try {
			group = userMgmt.getGroup(groupName);
		} catch (RemoteException e) {
			e.printStackTrace();
			throw new DAOException(e);
		} 
		return group;
	}

}
