package com.hibernate.test.persistence;

import java.sql.SQLException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.tool.hbm2ddl.SchemaExport;

/**
 * @author serban
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class HibernateSession {
	private final static String hibernateResource = "java:/hibernate/HibernateFactory";

	static Log log = LogFactory.getLog(HibernateSession.class.getName());

	private Transaction transaction = null;
	private Session s = null;
	private static SessionFactory factory = null;
//	private static Properties properties;  

	public static final ThreadLocal session = new ThreadLocal();
	
//	static {
//		properties = new java.util.Properties();
//		properties.put(
//			javax.naming.Context.INITIAL_CONTEXT_FACTORY,
//			"org.jnp.interfaces.NamingContextFactory");
//		properties.put(Context.PROVIDER_URL, "localhost:1099");
//		properties.put(
//			Context.URL_PKG_PREFIXES,
//			"org.jboss.naming:org.jnp.interfaces");
//		
//	}

	private Session currentSession()
	// TODO Auto-generated constructor stub
		throws HibernateException, NamingException {
		Session s = (Session) session.get();

		if (s == null) {
			Context jndiContext = new InitialContext();
			factory = (SessionFactory) jndiContext.lookup(hibernateResource);
			s = factory.openSession();
			session.set(s);
			log.info("Session opened");
		}

//		if (s == null) {
//			s = HibernateSessionFactory.currentFactory().openSession();
//			session.set(s);
//			log.info("Session opened");
//		}

		return s;
	}

	public Session newSession() throws NamingException, HibernateException {

		//		s = this.currentFactory().openSession();
		s = this.currentSession();
		return s;
	}

	/**
	 * 
	public void closeSession() throws HibernateException {
		if (s != null) {
			//s.disconnect();
			s.close();
			log.info("Session closed");
		}
	}
	*/

	public static void closeSession() throws HibernateException {

		Session s = (Session) session.get();
		session.set(null);
		if (s != null) {
			s.close();
			log.info("Session closed");
		}
	}

	public void disconnect() throws HibernateException {
		s.disconnect();
	}

	public void reconnect() throws HibernateException {
		s.reconnect();
	}

	public void flush() throws HibernateException {
		s.flush();
	}

	public void beginTransaction() throws HibernateException {
		log.info("beginTransaction");
		transaction = s.beginTransaction();
	}

	public void commit() throws HibernateException {
		if (transaction == null)
			throw new HibernateException("Transaction is null");
		transaction.commit();
		//		try {
		//			s.connection().commit();
		//		} catch (HibernateException e) {
		//		} catch (SQLException e) {
		//		}
		log.info("commit");
	}

	public void rollback() throws HibernateException {
		if (transaction == null)
			throw new HibernateException("Transaction is null");
		transaction.rollback();
	}

}
