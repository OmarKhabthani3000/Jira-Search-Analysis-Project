package com.hibernate.test.persistence;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class NetPortalSubnetwork implements Serializable {

    /** identifier field */
    private long id;

    /** nullable persistent field */
    private com.hibernate.test.persistence.NetPortalNetwork network;

    /** full constructor */
    public NetPortalSubnetwork(com.hibernate.test.persistence.NetPortalNetwork network) {
        this.network = network;
    }

    /** default constructor */
    public NetPortalSubnetwork() {
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public com.hibernate.test.persistence.NetPortalNetwork getNetwork() {
        return this.network;
    }

    public void setNetwork(com.hibernate.test.persistence.NetPortalNetwork network) {
        this.network = network;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof NetPortalSubnetwork) ) return false;
        NetPortalSubnetwork castOther = (NetPortalSubnetwork) other;
        return new EqualsBuilder()
            .append(this.getId(), castOther.getId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getId())
            .toHashCode();
    }

}
