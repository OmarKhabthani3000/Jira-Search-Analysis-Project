package com.hibernate.test.persistence;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class SubnetRightHolder implements Serializable {

    /** identifier field */
    private long id;

    /** persistent field */
    private short accessState;

    /** nullable persistent field */
    private com.hibernate.test.persistence.NetPortalGroup group;

    /** nullable persistent field */
    private com.hibernate.test.persistence.NetPortalSubnetwork subnet;

    /** full constructor */
    public SubnetRightHolder(short accessState, com.hibernate.test.persistence.NetPortalGroup group, com.hibernate.test.persistence.NetPortalSubnetwork subnet) {
        this.accessState = accessState;
        this.group = group;
        this.subnet = subnet;
    }

    /** default constructor */
    public SubnetRightHolder() {
    }

    /** minimal constructor */
    public SubnetRightHolder(short accessState) {
        this.accessState = accessState;
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public short getAccessState() {
        return this.accessState;
    }

    public void setAccessState(short accessState) {
        this.accessState = accessState;
    }

    public com.hibernate.test.persistence.NetPortalGroup getGroup() {
        return this.group;
    }

    public void setGroup(com.hibernate.test.persistence.NetPortalGroup group) {
        this.group = group;
    }

    public com.hibernate.test.persistence.NetPortalSubnetwork getSubnet() {
        return this.subnet;
    }

    public void setSubnet(com.hibernate.test.persistence.NetPortalSubnetwork subnet) {
        this.subnet = subnet;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof SubnetRightHolder) ) return false;
        SubnetRightHolder castOther = (SubnetRightHolder) other;
        return new EqualsBuilder()
            .append(this.getId(), castOther.getId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getId())
            .toHashCode();
    }

}
