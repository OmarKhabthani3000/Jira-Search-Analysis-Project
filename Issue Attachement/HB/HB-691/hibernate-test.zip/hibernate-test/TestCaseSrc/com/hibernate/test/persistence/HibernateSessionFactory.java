package com.hibernate.test.persistence;

import javax.naming.NamingException;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;

/**
 * @author serban
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public abstract class HibernateSessionFactory {

	private static SessionFactory sessionFactory = null;

	public static  SessionFactory currentFactory()
		throws NamingException, HibernateException {
		if (sessionFactory == null) {
			Configuration cfg = new Configuration();
			sessionFactory = cfg.configure().buildSessionFactory();
		}
		return sessionFactory;
	}


}
