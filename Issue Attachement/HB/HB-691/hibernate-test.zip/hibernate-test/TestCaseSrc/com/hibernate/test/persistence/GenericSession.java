package com.hibernate.test.persistence;

import com.hibernate.test.dao.DAOException;

import net.sf.hibernate.Session;

/**
 * @author serban
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public interface GenericSession {
	public Session getPersistentSession() throws DAOException;

	public void close() throws DAOException;

	public void disconnect() throws DAOException;

	public void reconnect() throws DAOException;

	public void flush() throws DAOException;

	public void beginTransaction() throws DAOException;

	public void commit() throws DAOException;

	public void rollback() throws DAOException;

}
