package com.hibernate.test.ejb;

import java.rmi.RemoteException;
import java.util.Hashtable;

import com.hibernate.test.dao.DAOException;
import com.hibernate.test.persistence.NetPortalGroup;
import com.hibernate.test.persistence.NetPortalNetwork;

/**
 * Remote interface for Enterprise Bean: UserMgmt
 */
public interface UserMgmt extends javax.ejb.EJBObject {
	public NetPortalGroup updateGroup(NetPortalGroup group)
		throws DAOException, RemoteException;
	public NetPortalGroup addGroup(NetPortalGroup group)
		throws DAOException, RemoteException;
	public NetPortalGroup getGroup(String groupName)
		throws DAOException, RemoteException;
	public NetPortalNetwork addNetwork(NetPortalNetwork net)
		throws DAOException, RemoteException;

}
