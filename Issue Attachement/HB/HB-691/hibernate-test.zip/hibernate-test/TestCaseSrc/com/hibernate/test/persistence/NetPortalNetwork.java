package com.hibernate.test.persistence;

import java.io.Serializable;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class NetPortalNetwork implements Serializable {

    /** identifier field */
    private long id;

    /** nullable persistent field */
    private String description;

    /** nullable persistent field */
    private boolean globalVlanId;

    /** persistent field */
    private Set subnet;

    /** full constructor */
    public NetPortalNetwork(java.lang.String description, boolean globalVlanId, Set subnet) {
        this.description = description;
        this.globalVlanId = globalVlanId;
        this.subnet = subnet;
    }

    /** default constructor */
    public NetPortalNetwork() {
    }

    /** minimal constructor */
    public NetPortalNetwork(Set subnet) {
        this.subnet = subnet;
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public java.lang.String getDescription() {
        return this.description;
    }

    public void setDescription(java.lang.String description) {
        this.description = description;
    }

    public boolean isGlobalVlanId() {
        return this.globalVlanId;
    }

    public void setGlobalVlanId(boolean globalVlanId) {
        this.globalVlanId = globalVlanId;
    }

    public java.util.Set getSubnet() {
        return this.subnet;
    }

    public void setSubnet(java.util.Set subnet) {
        this.subnet = subnet;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof NetPortalNetwork) ) return false;
        NetPortalNetwork castOther = (NetPortalNetwork) other;
        return new EqualsBuilder()
            .append(this.getId(), castOther.getId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getId())
            .toHashCode();
    }

}
