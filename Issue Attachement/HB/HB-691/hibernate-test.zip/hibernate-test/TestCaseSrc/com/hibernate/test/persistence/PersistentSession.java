package com.hibernate.test.persistence;

import javax.naming.NamingException;

import com.hibernate.test.dao.DAOException;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;

/**
 * @author serban
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class PersistentSession implements GenericSession{

	public Session getPersistentSession() {
		return sess;
	}

	public void close() throws DAOException {
		try {
			hs.closeSession();
		} catch (HibernateException e) {
			throw new DAOException(e);
		}

	}

	public void disconnect() throws DAOException {
		try {
			hs.disconnect();
		} catch (HibernateException e) {
			throw new DAOException(e);
		}

	}

	public void reconnect() throws DAOException {
		try {
			hs.reconnect();
		} catch (HibernateException e) {
			throw new DAOException(e);
		}

	}

	public void flush() throws DAOException {
		try {
			hs.flush();
		} catch (HibernateException e) {
			throw new DAOException(e);
		}

	}

	public PersistentSession() throws DAOException {
		try {
			hs = new HibernateSession();
//			sess = HibernateSession.currentSession();
			sess = hs.newSession();
		} catch (NamingException e) {
			throw new DAOException(e);
		} catch (HibernateException e) {
			throw new DAOException(e);
		}
	}

	public void beginTransaction() throws DAOException {
		try {
			hs.beginTransaction();
		} catch (HibernateException e) {
			throw new DAOException(e);
		}
	}

	public void commit() throws DAOException {
		try {
			hs.commit();
		} catch (HibernateException e) {
			throw new DAOException(e);
		}
	}

	public void rollback() throws DAOException {
		try {
			hs.rollback();
		} catch (HibernateException e) {
			throw new DAOException(e);
		}
	}
	private Session sess;
	private HibernateSession hs;
}
