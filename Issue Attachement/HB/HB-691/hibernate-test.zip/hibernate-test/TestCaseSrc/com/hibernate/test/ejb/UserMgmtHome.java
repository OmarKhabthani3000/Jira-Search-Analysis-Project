package com.hibernate.test.ejb;
/**
 * Home interface for Enterprise Bean: UserMgmt
 */
public interface UserMgmtHome extends javax.ejb.EJBHome {
	/**
	 * Creates a default instance of Session Bean: UserMgmt
	 */
	public UserMgmt create()
		throws javax.ejb.CreateException, java.rmi.RemoteException;
}
