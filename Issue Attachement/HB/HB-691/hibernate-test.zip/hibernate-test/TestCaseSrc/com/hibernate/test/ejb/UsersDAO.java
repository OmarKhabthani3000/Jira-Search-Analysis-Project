package com.hibernate.test.ejb;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import net.sf.hibernate.Hibernate;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.ObjectNotFoundException;
import net.sf.hibernate.Query;
import net.sf.hibernate.type.Type;

import com.hibernate.test.dao.BaseDAO;
import com.hibernate.test.dao.DAOException;
import com.hibernate.test.persistence.NetPortalGroup;
import com.hibernate.test.persistence.NetPortalNetwork;
import com.hibernate.test.persistence.PersistentSession;
import com.hibernate.test.persistence.SubnetRightHolder;

public class UsersDAO extends BaseDAO {

	public long createGroup(NetPortalGroup group) throws DAOException {
		try {
			sess.getPersistentSession().save(group);
			sess.getPersistentSession().flush();
		} catch (HibernateException e) {

			throw new DAOException(e);
		}
		return group.getId();
	}

	public long createNetwork(NetPortalNetwork network) throws DAOException {
		try {
			sess.getPersistentSession().save(network);
			sess.getPersistentSession().flush();
		} catch (HibernateException e) {

			throw new DAOException(e);
		}
		return network.getId();
	}

	public void updateGroup(NetPortalGroup group) throws DAOException {
		try {
			sess.getPersistentSession().saveOrUpdate(group);
			sess.getPersistentSession().flush();
		} catch (HibernateException e) {

			throw new DAOException(e);
		}
	}

	public UsersDAO(PersistentSession sess) {
		super(sess);
	}

	public NetPortalGroup getGroup(String groupName) throws DAOException {
		NetPortalGroup gr = null;
		List result = null;
		try {
			Query q =
				sess.getPersistentSession().createQuery(
					"from netportalgroup in class com.hibernate.test.persistence.NetPortalGroup where netportalgroup.name = :groupName");
			q.setString("groupName", groupName);
			result = q.list();
			if (result.size() == 0)
				throw new DAOException();
			gr = (NetPortalGroup) result.get(0);
			if(!Hibernate.isInitialized(gr.getSubnetRights())){
				Hibernate.initialize(gr.getSubnetRights());
			}
		} catch (HibernateException e) {
			throw new DAOException(e);
		}
		return gr;
	}

}
