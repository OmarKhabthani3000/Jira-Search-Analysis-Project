package com.hibernate.test.dao;

import com.hibernate.test.persistence.GenericSession;
import com.hibernate.test.persistence.PersistentSession;

/**
 * @author serban
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class BaseDAO {

    public BaseDAO(GenericSession sess) {
        this.sess = sess;
    }

	public GenericSession getSession() {
		return this.sess;
	}
    protected GenericSession sess;
}
