package com.hibernate.test.persistence;

import java.sql.SQLException;
import javax.naming.NamingException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.tool.hbm2ddl.SchemaExport;

/**
 * @author serban
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class HibernateReadSession {

	static Log log = LogFactory.getLog(HibernateReadSession.class.getName());

	private Transaction transaction = null;
	private Session s = null;

	public static final ThreadLocal session = new ThreadLocal();

	private static Session currentSession() throws HibernateException, NamingException {

		Session s = (Session) session.get();
		if (s == null) {
			s = HibernateSessionFactory.currentFactory().openSession();
			session.set(s);
		}
		return s;
	}

	public Session newSession() throws NamingException, HibernateException {

//		s = this.currentFactory().openSession();
		s = this.currentSession();
		log.info("Read Session opened");
		return s;
	}
	
	/**
	 * 
	public void closeSession() throws HibernateException {
		if (s != null) {
			//s.disconnect();
			s.close();
			log.info("Session closed");
		}
	}
	*/

    public static void closeSession() 
        throws HibernateException { 
        
       Session s = (Session) session.get(); 
       session.set(null); 
       if (s != null) s.close(); 
	   log.info("Read Session closed");
    } 

	public void disconnect() throws HibernateException {
		s.disconnect();
	}

	public void reconnect() throws HibernateException {
		s.reconnect();
	}

	public void flush() throws HibernateException {
		s.flush();
	}

	public void beginTransaction() throws HibernateException {
		log.info("Read beginTransaction");
		transaction = s.beginTransaction();
	}

	public void commit() throws HibernateException {
		if (transaction == null)
			throw new HibernateException("Transaction is null");
		transaction.commit();
		//		try {
		//			s.connection().commit();
		//		} catch (HibernateException e) {
		//		} catch (SQLException e) {
		//		}
		log.info("Read commit");
	}

	public void rollback() throws HibernateException {
		if (transaction == null)
			throw new HibernateException("Transaction is null");
		transaction.rollback();
	}

}
