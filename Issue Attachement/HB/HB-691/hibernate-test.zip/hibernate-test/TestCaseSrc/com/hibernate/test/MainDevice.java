package com.hibernate.test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.hibernate.test.dao.DAOException;
import com.hibernate.test.persistence.NetPortalGroup;
import com.hibernate.test.persistence.NetPortalNetwork;
import com.hibernate.test.persistence.NetPortalSubnetwork;
import com.hibernate.test.persistence.SubnetRightHolder;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.tool.hbm2ddl.SchemaExport;

public class MainDevice {

	SessionFactory sessionFactory = null;
	private Session session;
	private Transaction transaction;

	public static void main(String[] args)
		throws HibernateException {
		MainDevice myObj = new MainDevice();
		myObj.go();
	}

	private void initHibernate() throws HibernateException {

		// Load Configuration and build SessionFactory
		Configuration cfg = new Configuration();
		sessionFactory = cfg.configure().buildSessionFactory();
		new SchemaExport(cfg).create(true, true);
		//new SchemaUpdate(cfg).execute(true);
	}

	private void go() throws HibernateException{
		initHibernate();

		UserHelper uh = new UserHelper();


		NetPortalGroup gr1 = new NetPortalGroup();
		
		SubnetRightHolder defaultHolder = new SubnetRightHolder();
		defaultHolder.setAccessState((short) 2);
		defaultHolder.setGroup(gr1);

		NetPortalNetwork defNetwork = new NetPortalNetwork();
		defNetwork.setDescription("default network");

		NetPortalSubnetwork defSubnet = new NetPortalSubnetwork();
		defSubnet.setNetwork(defNetwork);
		Set subnets = new HashSet();
		subnets.add(defSubnet);

		defNetwork.setSubnet(subnets);

		defaultHolder.setSubnet(defSubnet);

		Set subnetRights = new HashSet();
		subnetRights.add(defaultHolder);
		gr1.setSubnetRights(subnetRights);

		gr1.setMaxNoSess(1);
		gr1.setName("group");
		Set groups = new HashSet();
		groups.add(gr1);

		try {
			uh.addGroup(gr1);
			System.out.println("group added");
			gr1 = uh.getGroup("group");
			System.out.println("group retrieved");
			SubnetRightHolder newHolder = new SubnetRightHolder();
			newHolder.setSubnet(new NetPortalSubnetwork()); 
			gr1.getSubnetRights().add(newHolder);
			uh.updateGroup(gr1) ;
			System.out.println("group updated");
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void beginTransaction() throws HibernateException {

		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
	}

	private void endTransaction(boolean commit) throws HibernateException {

		if (commit) {
			transaction.commit();
		} else {
			transaction.rollback();
		}
		session.close();
	}

}
