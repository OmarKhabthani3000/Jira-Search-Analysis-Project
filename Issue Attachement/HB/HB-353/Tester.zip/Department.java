import java.io.Serializable;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class Department implements Serializable {

    /** persistent field */
    private String deptno;

    /** persistent field */
    private String deptname;

    /** nullable persistent field */
    private String mgrno;

    /** persistent field */
    private String admrdept;

    /** nullable persistent field */
    private String location;

    /** full constructor */
    public Department(java.lang.String deptno, java.lang.String deptname, java.lang.String mgrno, java.lang.String admrdept, java.lang.String location) {
        this.deptno = deptno;
        this.deptname = deptname;
        this.mgrno = mgrno;
        this.admrdept = admrdept;
        this.location = location;
    }

    /** default constructor */
    public Department() {
    }
   
    public Department( String s ) {
       this.deptno = s;
    }

    /** minimal constructor */
    public Department(java.lang.String deptno, java.lang.String deptname, java.lang.String admrdept) {
        this.deptno = deptno;
        this.deptname = deptname;
        this.admrdept = admrdept;
    }

    public java.lang.String getDeptno() {
        return this.deptno;
    }

    public void setDeptno(java.lang.String deptno) {
        this.deptno = deptno;
    }

    public java.lang.String getDeptname() {
        return this.deptname;
    }

    public void setDeptname(java.lang.String deptname) {
        this.deptname = deptname;
    }

    public java.lang.String getMgrno() {
        return this.mgrno;
    }

    public void setMgrno(java.lang.String mgrno) {
        this.mgrno = mgrno;
    }

    public java.lang.String getAdmrdept() {
        return this.admrdept;
    }

    public void setAdmrdept(java.lang.String admrdept) {
        this.admrdept = admrdept;
    }

    public java.lang.String getLocation() {
        return this.location;
    }

    public void setLocation(java.lang.String location) {
        this.location = location;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .toString();
    }

}
