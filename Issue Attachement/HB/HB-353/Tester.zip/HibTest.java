import java.util.List;

import Department;

import net.sf.hibernate.Query;
import net.sf.hibernate.Session;
import net.sf.hibernate.cfg.Configuration;

/**
 * Created on Sep 22, 2003
 * @author CDR
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class HibTest {
   
   private static Department d = new Department( "C01" );
   
   public static void main( String[] args ) throws Exception {
      Session session = null;
      List results = null;
      try {
         session = new Configuration().configure().buildSessionFactory().openSession();
         String qString = "select   {d.*} " +            "from  department {d} " +            "where {d}.deptno = :deptno";
         Query query = session.createSQLQuery( qString, "d", Department.class );
         if ( d != null ) {
            query.setProperties( d );
         }
         results = query.list();
      }
      catch ( Exception e ) {
         System.out.println( e.toString() );
      }
      finally {
         if ( session != null )
            session.close();
      }
   }
}
