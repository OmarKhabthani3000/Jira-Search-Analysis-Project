public class Foo
{
    private Integer id;
    private String text;

    /**
     * @return
     */
    public Integer getId()
    {
        return id;
    }

    /**
     * @return
     */
    public String getText()
    {
        return text;
    }

    /**
     * @param integer
     */
    public void setId(Integer integer)
    {
        id = integer;
    }

    /**
     * @param string
     */
    public void setText(String string)
    {
        text = string;
    }

}
