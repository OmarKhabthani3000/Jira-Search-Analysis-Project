public class Bar
{
    private Foo foo;
    private String text;

    /**
     * @return
     */
    public Foo getFoo()
    {
        return foo;
    }

    /**
     * @return
     */
    public String getText()
    {
        return text;
    }

    /**
     * @param foo
     */
    public void setFoo(Foo foo)
    {
        this.foo = foo;
    }

    /**
     * @param string
     */
    public void setText(String string)
    {
        text = string;
    }

}
