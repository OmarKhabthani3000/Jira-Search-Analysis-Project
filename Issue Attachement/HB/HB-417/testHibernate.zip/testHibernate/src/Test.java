import net.sf.hibernate.Criteria;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.expression.Expression;

public class Test {

	public static void main(String[] args)
	{
        try
        {
            SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
            Session session = sessionFactory.openSession();

            Criteria criteria = session.createCriteria(Foo.class);
            criteria.add(Expression.eq("id", new Integer(1)));
            Foo foo = (Foo) criteria.uniqueResult();
            System.out.println("Foo :" + foo.getId());

            criteria = session.createCriteria(Bar.class);
            criteria.createCriteria("foo").add(Expression.eq("id", new Integer(1)));
            Bar bar = (Bar) criteria.uniqueResult();
            System.out.println("Bar :" + bar.getFoo().getId());

            session.close();
            
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
