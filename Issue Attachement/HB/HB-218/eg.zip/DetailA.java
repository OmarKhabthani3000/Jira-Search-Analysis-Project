//$Id:$
package eg;

/**
 * @author Chris Hane
 * Date: Jul 28, 2003
 */
public class DetailA extends AbsDetail {

}
