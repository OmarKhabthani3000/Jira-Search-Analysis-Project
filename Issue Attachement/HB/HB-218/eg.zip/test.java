//$Id:$
package eg;

import eg.Father;
import eg.IDetail;
import eg.DetailA;
import eg.DetailB;
import eg.IFather;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;

import java.util.Properties;

/**
 * @author Chris Hane
 * Date: Jul 28, 2003
 */
public class test {
      private static Session session;

      public static void main(String[] args) throws Exception {
         Properties props = new Properties();
         props.setProperty("hibernate.dialect", "net.sf.hibernate.dialect.MySQLDialect");
         props.setProperty("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
         props.setProperty("hibernate.connection.url", "jdbc:mysql:///xxxxxx");
         props.setProperty("hibernate.connection.username", "xxxxx");
         props.setProperty("hibernate.connection.password", "xxxxx");
         props.setProperty("hibernate.connection.pool_size", "5");
         props.setProperty("hibernate.statement_cache.size", "0");
         Configuration configuration = new Configuration();
         configuration.addClass(eg.IDetail.class);
//         configuration.addClass(eg.IFather.class);
      configuration.addClass(eg.Father.class);
         configuration.addProperties(props);

         SessionFactory factory = configuration.buildSessionFactory();
         session = factory.openSession();

         Father f = null;
         DetailA dA = null;
         DetailB dB = (DetailB) session.load(DetailB.class, new Long(4));
         System.out.println(dB.getTestValue());
      }
}
