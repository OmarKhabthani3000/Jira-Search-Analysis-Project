//$Id:$
package eg;

/**
 * @author Chris Hane
 * Date: Jul 28, 2003
 */
public class AbsDetail implements IDetail {

   private long detailID;
   private String testValue;
   private IFather father;

   public long getDetailID() {
      return detailID;
   }

   public void setDetailID(long detailID) {
      this.detailID = detailID;
   }

   public IFather getFather() {
      return father;
   }

   public void setFather(IFather father) {
      this.father = father;
   }

   public String getTestValue() {
      return testValue;
   }

   public void setTestValue(String testValue) {
      this.testValue = testValue;
   }

}
