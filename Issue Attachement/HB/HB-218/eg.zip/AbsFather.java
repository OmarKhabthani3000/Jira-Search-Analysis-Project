//$Id:$
package eg;

import java.util.HashSet;
import java.util.Set;

/**
 * @author Chris Hane
 * Date: Jul 28, 2003
 */
public abstract class AbsFather implements IFather {
   private long fatherID;
   private String fatherValue;
   private Set details = new HashSet();

   public Set getDetails() {
      return details;
   }

   public void setDetails(Set details) {
      this.details = details;
   }

   public long getFatherID() {
      return fatherID;
   }

   public void setFatherID(long fatherID) {
      this.fatherID = fatherID;
   }

   public String getFatherValue() {
      return fatherValue;
   }

   public void setFatherValue(String fatherValue) {
      this.fatherValue = fatherValue;
   }

}
