//$Id:$
package eg;

import java.util.Set;

/**
 * @author Chris Hane
 * Date: Jul 28, 2003
 */
public interface IDetail {

   public void setDetailID(long id);
   public long getDetailID();

   public void setFather(IFather father);
   public IFather getFather();

   public void setTestValue(String s);
   public String getTestValue();

}
