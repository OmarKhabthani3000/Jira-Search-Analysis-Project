CREATE TABLE `test_detail` (
  `detailID` bigint(20) NOT NULL auto_increment,
  `type` varchar(4) NOT NULL default '',
  `testValue` varchar(100) default '',
  `father` bigint(20) default NULL,
  PRIMARY KEY  (`detailID`)
) TYPE=MyISAM;

CREATE TABLE `test_father` (
  `fatherID` bigint(20) NOT NULL auto_increment,
  `fatherValue` varchar(100) default '',
  `type` char(1) NOT NULL default '',
  PRIMARY KEY  (`fatherID`)
) TYPE=MyISAM;

insert into test_father values (1, "Father1", "F");
insert into test_father values (2, "Father2", "F");
insert into test_father values (3, "Father3", "F");

insert into test_detail values (1, "A", "Detail A1 - F1", 1);
insert into test_detail values (2, "A", "Detail A2 - F2", 2);
insert into test_detail values (3, "B", "Detail B1 - F3", 3);