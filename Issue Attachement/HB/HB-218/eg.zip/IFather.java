//$Id:$
package eg;

import java.util.Set;

/**
 * @author Chris Hane
 * Date: Jul 28, 2003
 */
public interface IFather {

   public Set getDetails();

   public void setDetails(Set details);

   public long getFatherID();

   public void setFatherID(long fatherID);

   public String getFatherValue();

   public void setFatherValue(String fatherValue);

}
