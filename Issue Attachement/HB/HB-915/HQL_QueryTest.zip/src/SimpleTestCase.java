import java.util.Iterator;

import metadata.DimValueBag;
import metadata.Dimension;
import metadata.IntegerDimValue;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Query;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.cfg.Configuration;
import questions.DBAssessQuestion;

/**
 * @author voelkl
 *
 */
public class SimpleTestCase {
	Session session;
	Transaction tx;

	public static void main(String[] args) {

		SimpleTestCase myTest = new SimpleTestCase();

		try {
			Configuration cfg =
				new Configuration()
					.addClass(Dimension.class)
					.addClass(DimValueBag.class)
					.addClass(IntegerDimValue.class)
					.addClass(DBAssessQuestion.class);

			SessionFactory factory = cfg.buildSessionFactory();

			myTest.session = factory.openSession();
			myTest.tx = myTest.session.beginTransaction();

			//setup database by creating some objects for the test
			myTest.setUp();
			//searchTest -> HERE IS THE PROBLEM !
			myTest.queryTest();

			myTest.tx.commit();
			myTest.session.close();

		} catch (HibernateException e) {
			System.out.println("trouble mit Hibernate");
			e.printStackTrace();
		}
	}

	private void queryTest() throws HibernateException {
		String queryString;

		//get the dimvalues that will serve as search-criteria
		IntegerDimValue searchVal1 = (IntegerDimValue) session.get(IntegerDimValue.class, new Long(1));
		//IntegerDimValue searchVal2 = (IntegerDimValue) session.get(IntegerDimValue.class, new Long(2));

		queryString =
			"select qst.id "
				+ "from questions.DBAssessQuestion as qst "
				+ "join qst.metaData.values value "
				+ "where value in elements ( "
				+ " from metadata.IntegerDimValue as dimVal "
				+ " where dimVal.dimension = :dimension "
				+ " and dimVal.intValue = :intValue  "
				+ ")";

		Query query = session.createQuery(queryString);
		
		//the following statement throws the exception:
		//net.sf.hibernate.QueryException: Named parameter does not appear in Query: dimension
		//which I do not understand at all
		query.setEntity("dimension", searchVal1.getDimension());
		query.setEntity("intValue", searchVal1.getIntValue());

		System.out.println("Query-Results:");
		Iterator itr = query.iterate();

		while (itr.hasNext()) {
			System.out.println("res: " + itr.next());
		}

	}

	/**
	 * erzeugt eine Frage mit mehrsprachigen Antwortm�glichkeiten
	 * (Fragentext bislang nicht mehrsprachig)
	 * @throws HibernateException
	 */
	private void setUp() throws HibernateException {

		//some dimensions
		Dimension dim1 = new Dimension(new Long(1));
		Dimension dim2 = new Dimension(new Long(2));
		Dimension dim3 = new Dimension(new Long(3));
		session.save(dim1);
		session.save(dim2);
		session.save(dim3);

		//create a new question with some metadata
		DBAssessQuestion question = new DBAssessQuestion();

		DimValueBag metadata = new DimValueBag();
		metadata.addDimValue(new IntegerDimValue(dim1, new Integer(10)));
		metadata.addDimValue(new IntegerDimValue(dim2, new Integer(20)));
		question.setMetaData(metadata);

		session.save(question);

	}

}
