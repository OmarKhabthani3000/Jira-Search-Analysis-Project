
package questions;

import metadata.DimValueBag;

/**
 * @author voelkl
 * 
* @hibernate.class
 * 	table="questions"
 * 
 */
public class DBAssessQuestion {

	private Long id;
	private DimValueBag metaData;

	/**
	 * Constructor
	 */
	public DBAssessQuestion() {
	}

	//GETTER below

	/**
	 * @hibernate.id
	 * 		generator-class="native"
	 * 		column="question_id"
	 * @hibernate.generator-param
	 *		name="sequence"
	 *		value="hib_seq_question" 
	 */
	public Long getId() {
		return id;
	}
	
	/**
	 * @return
	 * 
	 * @hibernate.many-to-one
	 * 	cascade="all"
	 */
	public DimValueBag getMetaData() {
		return metaData;
	}


	//SETTER below

	public void setMetaData(DimValueBag metaData) {
		this.metaData = metaData;
	}

	/**
	 * @param long1
	 */
	public void setId(Long long1) {
		id = long1;
	}

}
