
package metadata;


/**
 * DB_AssessmentManagement
 * @author IFIS 2004
 * 
 * @hibernate.class
 *  	table="dimvalues"
 */
public class IntegerDimValue  {
	
	

	private Long id;
	/**
	 * @supplierCardinality 1
	 * @clientCardinality 0..
	 */
	private Dimension dimension;
	private Integer intValue;
	
	/**
	 * Constructor
	 * @param dim
	 * @throws IFISInvalidDimValueException thrown if the DimValue is not valid
	 * 			within the given dimension
	 */
	public IntegerDimValue(Dimension dim, Integer value) {		
		this.dimension = dim;
		this.intValue = value;
	}
	/**
	 * non-public default Constructor for Hibernate
	 */
	protected IntegerDimValue() {
	}




	/**
	 * @hibernate.id
	 * 	generator-class="native"
	 * 	column="dimvalue_id"
	 * @hibernate.generator-param
	 *	name="sequence"
	 *	value="hib_seq_dimvalue" 
	 */
	public Long getId() {
		return id;
	}
	/**
	 * @param long1
	 */
	public void setId(Long long1) {
		id = long1;
	}

	/**
	 * @hibernate.many-to-one
	 * 	column="dimension_id"
	 */
	public Dimension getDimension() {
		return this.dimension;
	}
	private void setDimension(Dimension dimension) {
		this.dimension = dimension;
	}
	
	/**
	 * @return
	 * 
	 * @hibernate.property
	 */
	public Integer getIntValue() {
		return intValue;
	}
	private void setIntValue(Integer integer) {
		intValue = integer;
	}

}
