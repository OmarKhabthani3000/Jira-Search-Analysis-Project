package metadata;

/**
 * Dimension
 * predicate of a RDF-Triple
 * (subject is the owner of this object, object is the DimValues)
 * 
 * 
 * @author voelkl
 * 
 * @hibernate.class
 * 	table="dimensions"
 * 
 */
public class Dimension  {

	private Long id;

	/**
	 * Constructor
	 */
	public Dimension(Long id) {
		this.id = id;
	}
	/* 
	 * Constructor
	 * for hibernate
	 */
	private Dimension(){
	}

	
	

	/**
	 * 	2 Dimensions are regarded as equal if their IDs are equal
	 */
	public boolean equals(Object obj) {
		if (!(obj instanceof Dimension)) {
			return false;
		}
		return this.getId().longValue()
			== ((Dimension) obj).getId().longValue();
	}

	//GETTER and SETTER below
	/**
	 * 
	 * @hibernate.id
	 * 	generator-class="assigned"
	 * 	column="dimension_id" 
	 */
	public Long getId() {
		return id;
	}
	private void setId(Long long1) {
		id = long1;
	}



}
