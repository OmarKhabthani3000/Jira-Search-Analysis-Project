
package metadata;

import java.util.LinkedList;
import java.util.List;

/**
 * @author voelkl
 * container for metadata, e.g. in questions
 * 
 * @hibernate.class
 * 	table="dimvaluebags" 
 */
public class DimValueBag {

	/**
	 * artificial id created and managed by hibernate
	 */
	private Long id;

	/**
	 * List of DimValues as metadata of the referencing object
	 * 
	 * @associates IntegerDimValue
	 * @supplierCardinality 0..* 
	 * @clientCardinality 0..*
	 */
	private List values = new LinkedList();


	/**
	 * adds the given DimValue to this metadata-list
	 * @param dimVal
	 */
	public void addDimValue(IntegerDimValue dimVal) {
		values.add(dimVal);
	}

	/**
	 * removes the DimValue for the given dimension from the metadata
	 * the DimValue is compared by equals / "isOfQuality" !
	 *  
	 * @param dimVal the value to be removed
	 * @return true if there was such a values
	 */
	public boolean removeDimValue(IntegerDimValue dimVal) {
		return values.remove(dimVal);
	}



	//GETTER and SETTER below
	//used by Hibernate
	/**
	 * @hibernate.id
	 * 	generator-class="native"
	 * 	column="dimvaluebag_id"
	 * @hibernate.generator-param
	 *	name="sequence"
	 *	value="hib_seq_dimvaluebag" 
	 */
	private Long getId() {
		return id;
	}
	/**
	 * @hibernate.list
	 *  	table="dimvalbag_values"
	 * 		cascade="all-delete-orphan"
	 * @hibernate.collection-key
	 * 		column="dimvaluebag"
	 * @hibernate.collection-index
	 * 		column="position"
	 * @hibernate.collection-many-to-many
	 * 		column="value"
	 * 		class="metadata.IntegerDimValue"
	 * 
	 */
	private List getValues() {
		return values;
	}
	private void setId(Long long1) {
		id = long1;
	}
	private void setValues(List values) {
		this.values = values;
	}

}
