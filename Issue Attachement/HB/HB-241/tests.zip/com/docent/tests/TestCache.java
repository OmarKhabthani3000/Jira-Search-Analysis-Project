package com.docent.tests;

import com.docent.lms.entities.reference.EntityUtility;
import java.util.Iterator;
import net.sf.hibernate.MappingException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;
import org.apache.cactus.ServletTestCase;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** Test caching of associations between roles and permissions.
 * <a href="http://jakarta.apache.org/cactus/">Cactus</a> provides supporting infrastructure.
 *
 * @author Copyright (c) 2003 by Docent, Inc.  All Rights Reserved.
 * @author <a href="mailto:jkristian@docent.com">John Kristian</a>
 */
public class TestCache extends ServletTestCase {

    /** <a href="http://junit.org/">JUnit</a> boilerplate */
    public TestCache(String name)
    {
        super(name);
    }

    /** Read associations between roles and permissions, in two consecutive sessions.
     * The first session copies objects from the database to the global JCS cache;
     * the second session find the same objects in the cache, including
     * RolePermissionAssociation objects whose id contains a reference to Role
     * objects that are (regrettably) contained in the first (closed) session.
     * Each such Role contains a lazy Set, which (regrettably) fails to initialize
     * because its session is closed, propagating an exception from Set.iterator().
     */
    public void testAssociation()
        throws Exception
    {
        String testName = "testAssociation";
        log.debug(testName);
        try {
            Configuration configuration = EntityUtility.getConfiguration();
            configureClass(configuration, Permission.class);
            configureClass(configuration, Role.class);
            configureClass(configuration, RolePermissionAssociation.class);
            SessionFactory sessionFactory = configuration.buildSessionFactory();
            try {
                Context context = new Context();
                Session session = sessionFactory.openSession(context);
                context.setSession(session);
                try {
                    assertTrue("session.contains(role)", session.contains(findRole(session)));

                    session.close();
                    context = new Context();
                    session = sessionFactory.openSession(context);
                    context.setSession(session);

                    Role role = findRole(session);
                    // assertTrue("session.contains(role)", session.contains(role));
                    for (Iterator i = role.getAssociations().iterator(); // An exception is thrown here.
                         i.hasNext(); )
                    {
                        RolePermissionAssociation association = (RolePermissionAssociation)(i.next());
                        assertTrue("session.contains(association)", session.contains(association));
                        Permission permission = association.getId().getPermission();
                        assertTrue("session.contains(permission)", session.contains(permission));
                        break;
                    }
                } finally {
                    session.close();
                }
            } finally {
                sessionFactory.close();
            }
        } catch(Exception e) {
            log.error(testName + " failed", e);
            throw e; // report this error to JUnit
        }
    }

    protected static Role findRole(Session session)
        throws Exception
    {
        for (Iterator i = session.iterate("FROM entity IN CLASS " + Permission.class.getName()); i.hasNext(); ) {
            Permission permission = (Permission)(i.next());
            assertTrue("session.contains(permission)", session.contains(permission));
            for (Iterator j = permission.getAssociations().iterator(); j.hasNext(); ) {
                RolePermissionAssociation association = (RolePermissionAssociation)(j.next());
                assertTrue("session.contains(association)", session.contains(association));
                Role role = association.getId().getRole();
                return role;
            }
        }
        return null;
    }

    protected void configureClass(Configuration configuration, Class persistentClass)
        throws MappingException
    {
        if (configuration.getClassMapping(persistentClass) == null) {
            configuration.addClass(persistentClass);
        }
    }

    protected final static Log log = LogFactory.getLog(TestCache.class);

}
