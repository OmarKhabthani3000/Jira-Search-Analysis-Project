package com.docent.tests;

import java.util.Set;

/** A role in a role-based access control system.
 *
 * @author Copyright (c) 2003 by Docent, Inc.  All Rights Reserved.
 * @author <a href="mailto:jkristian@docent.com">John Kristian</a>
 */
public class Role {

    /** Identifier equality (ids are equal). */
    public boolean equals(Object that)
    {
        return (getId() == null) ? super.equals(that) /* Java object identity */ :
            ((that instanceof Role) && getId().equals(((Role)that).getId())); /* database id */
    }

    /** Identifier equality (ids are equal). */
    public int hashCode()
    {
        return (getId() == null) ? super.hashCode() /* Java object identity */ :
            getId().hashCode(); /* database id */
    }

    public Long getId()
    {return id;}
    private void setId(Long id)
    {this.id = id;}
    private Long id;

    public long getVersion()
    {return version;}
    private void setVersion(long version)
    {this.version = version;}
    private long version;

    public String getName()
    {return name;}
    private void setName(String name)
    {this.name = name;}
    private String name;

    public Set getAssociations()
    {return associations;}
    private void setAssociations(Set associations)
    {this.associations = associations;}
    private Set associations; // contains RolePermissionAssociations

}
