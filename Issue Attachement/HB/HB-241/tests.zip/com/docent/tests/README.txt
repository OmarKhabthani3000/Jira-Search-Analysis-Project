Here is a test case for a problem with Hibernate.
The problem is that Hibernate propagates an exception from Set.iterator().

See log.txt for a stack trace of this exception preceded by a DEBUG trace.
See TestCache.java (specifically javadoc for TestCache.testAssociation())
for a summary of events preceding the exception.

To work around this problem, I intend to make my entities' setId method
replace the new id's reference fields, if necessary, with references to
entities in the same Session as the containing entity.  For example, see
RolePermissionAssociation.setId (search for 'work around').  Critique and
better ideas are welcome.

- John Kristian <jkristian@docent.com>
