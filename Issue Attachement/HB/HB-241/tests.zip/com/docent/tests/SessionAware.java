package com.docent.tests;

import net.sf.hibernate.Session;

public interface SessionAware {

    public void setSession(Session session);

}
