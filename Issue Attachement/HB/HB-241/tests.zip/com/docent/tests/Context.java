package com.docent.tests;

import java.io.Serializable;
import java.util.Iterator;
import net.sf.hibernate.CallbackException;
import net.sf.hibernate.Interceptor;
import net.sf.hibernate.Session;
import net.sf.hibernate.type.Type;

class Context implements SessionAware, Interceptor {

    public void setSession(Session session)
    {this.session = session;}
    private Session session;

    public Object instantiate(Class clazz, Serializable id)
        throws CallbackException
    {
        Object entity = null;
        try {
            entity = clazz.newInstance();
        } catch(Exception e) {
            throw new CallbackException(e);
        }
        if (entity instanceof SessionAware) {
            ((SessionAware)entity).setSession(session);
        }
        return entity;
    }

    public int[] findDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState, String[] propertyNames, Type[] types)
    {return null; /* choose default behavior */}

    public Boolean isUnsaved(Object entity)
    {return null; /* choose default behavior */}

    public void onDelete(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types)
        throws CallbackException
    {}

    public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState, String[] propertyNames, Type[] types)
        throws CallbackException
    {return false; /* no change */}

    public boolean onLoad(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types)
        throws CallbackException
    {return false; /* no change */}

    public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types)
        throws CallbackException
    {return false; /* no change */}

    public void postFlush(Iterator entities)
        throws CallbackException
    {}

    public void preFlush(Iterator entities)
        throws CallbackException
    {}

}

