import java.io.Serializable;
import java.net.URL;
import java.util.*;

import net.sf.hibernate.*;
import net.sf.hibernate.cfg.Configuration;

/** Cascading delete 2, now we can delete the folder, be we can't delete the link */
public class DeleteTest {
	
	/**	 */
	public static void main(String[] args) {
		Session session = null;
		// initializastion...
		try {
			URL configFile = DeleteTest.class.getResource("/deletetest.hbm.xml");
			Configuration configuration = new Configuration().addURL(configFile);
			SessionFactory sessionFactory = configuration.buildSessionFactory();
			try {
				session = sessionFactory.openSession();

				// start a transaction
				Transaction t = session.beginTransaction();
				// a simple folder with a document and a simple link to it
				Folder folder = new Folder(null, "testFolder", "/testFolder");
				Document document = new Document(folder, "test", "test.txt");
				Link link = new Link(folder, "linkt to test", document);
				session.save(folder);
				// commit and save the new instances...
				t.commit();

				// start new transaction
				t = session.beginTransaction();
				// select the Link instance and delete it
				List list = session.find("select o from Link as o");
				for (int i = 0; i < list.size(); ++i) {
					session.delete(list.get(i));
				}
				// Commit throws an net.sf.hibernate.HibernateException: Flush during cascade is dangerous!
				// Because the link hase bee not removed from the document.
				t.commit();
			} catch (HibernateException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			} finally {
				if (session != null) {
					session.clear();
				}
			}
			
			// second 
			try {
				session = sessionFactory.openSession();
				Transaction t = session.beginTransaction();

				// select the Folder instance and delete it
				List list = session.find("select o from Folder as o");
				for (int i = 0; i < list.size(); ++i) {
					session.delete(list.get(i));
				}
				// Folder can be now deleted!
				t.commit();

			} catch (HibernateException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			} finally {
				if (session != null) {
					session.clear();
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
}
