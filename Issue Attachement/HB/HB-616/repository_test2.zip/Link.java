import java.io.*;
import java.util.*;
import net.sf.hibernate.*;

/** Simple Link class, which shows to a document */
public class Link extends RepositoryItem {

	private Document item;
	
	public Link() {
	}

	public Link(Folder parent, String name, Document item) {
		super(parent, name);
		setNewItem(item);
	}

    /**
     * @hibernate.many-to-one
     *  column="itemId"
     */
	public Document getItem() {
		return item;
	}
	
	private void setItem(Document item) {
		this.item = item;
	}
	
	public void setNewItem(Document item) {
		if (this.item != item) {
			if (this.item != null) {
				this.item.removeLink(this);
			}
			setItem(item);
			if (item != null) {
				item.addLink(this);
			}
		}
	}
	
	public boolean onDelete(Session s) throws CallbackException {
//		setNewItem(null);
		return super.onDelete(s);
	}
}
