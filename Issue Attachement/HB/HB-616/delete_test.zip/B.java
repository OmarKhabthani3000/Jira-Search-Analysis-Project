import java.io.*;
import net.sf.hibernate.*;

/** Simple class B, with father child  A */
public class B implements Lifecycle {

	private int id;
	
	private A father;
	
	public B() {
	}

    /**
     * @hibernate.id
     *  generator-class="native"
     *  column="id"
     */
	private int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

    /**
     * @hibernate.many-to-one
     *  column="fatherId"
     */
	public A getFather() {
		return father;
	}
	
	private void setFather(A father) {
		this.father = father;
	}
	
	public void setNewFather(A father) {
		if (this.father != father) {
			setFather(father);
			if (father != null) {
				father.setNewChild(this);
			}
		}
	}
	
	public void onLoad(Session s, Serializable id) {
	}
	
	public boolean onSave(Session s) throws CallbackException {
		return NO_VETO;
	}

	public boolean onUpdate(Session s) throws CallbackException {
		return NO_VETO;
	}
	
	public boolean onDelete(Session s) throws CallbackException {
		setNewFather(null);
		return NO_VETO;
	}
}
