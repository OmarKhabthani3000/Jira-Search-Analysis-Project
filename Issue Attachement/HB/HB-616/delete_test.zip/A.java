import java.io.*;
import net.sf.hibernate.*;

/** Simple class A, with a child  B */
public class A implements Lifecycle {
	
	private int id;
	
	private B child;
	
	public A() {
	}
	
    /**
     * @hibernate.id
     *  generator-class="native"
     *  column="id"
     */
	public int getId() {
		return id;
	}

 	public void setId(int id) {
		this.id = id;
	}

    /**
     * @hibernate.many-to-one
     *  column="childId"
     */
	public B getChild() {
		return child;
	}
	
	protected void setChild(B child) {
		this.child = child;
	}
	
	public void setNewChild(B child) {
		if (this.child != child) {
			setChild(child);
			if (child != null) {
				child.setNewFather(this);
			}
		}
	}
	
	public void onLoad(Session s, Serializable id) {
	}
	
	public boolean onSave(Session s) throws CallbackException {
		return NO_VETO;
	}

	public boolean onUpdate(Session s) throws CallbackException {
		return NO_VETO;
	}
	
	public boolean onDelete(Session s) throws CallbackException {
		if (this.child != null) {
			B child = this.child;
			setNewChild(null);
			try {
				s.delete(child);
			} catch (HibernateException e) {
				throw new CallbackException(e);
			}
		}
		return NO_VETO;
	}
}
