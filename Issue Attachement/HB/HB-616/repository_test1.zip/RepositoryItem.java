import java.io.*;
import java.util.*;
import net.sf.hibernate.*;

/** Simple class B, with parent child  Folder */
public abstract class RepositoryItem implements Lifecycle {

	private int id;
	
	private Folder parent;
	
	private String name;

	public RepositoryItem() {
	}

	public RepositoryItem(Folder parent, String name) {
		setName(name);
		setNewParent(parent);
	}

    /**
     * @hibernate.id
     *  generator-class="native"
     *  column="id"
     */
	private int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/**
	 *@hibernate.property
	 */
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
    /**
     * @hibernate.many-to-one
     *  column="parentId"
     */
	public Folder getParent() {
		return parent;
	}
	
	private void setParent(Folder parent) {
		this.parent = parent;
	}
	
	public void setNewParent(Folder parent) {
		if (this.parent != parent) {
			if (this.parent != null) {
				this.parent.removeChild(this);
			}
			setParent(parent);
			if (parent != null) {
				parent.addChild(this);
			}
		}
	}
	
	public void onLoad(Session s, Serializable id) {
	}
	
	public boolean onSave(Session s) throws CallbackException {
		return NO_VETO;
	}

	public boolean onUpdate(Session s) throws CallbackException {
		return NO_VETO;
	}
	
	public boolean onDelete(Session s) throws CallbackException {
		setNewParent(null);
		return NO_VETO;
	}
}
