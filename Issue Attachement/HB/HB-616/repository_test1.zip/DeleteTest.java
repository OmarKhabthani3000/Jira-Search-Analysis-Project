import java.io.Serializable;
import java.net.URL;
import java.util.*;

import net.sf.hibernate.*;
import net.sf.hibernate.cfg.Configuration;

/** Cascading delete */
public class DeleteTest {
	
	/**	 */
	public static void main(String[] args) {
		Session session = null;
		try {
			URL configFile = DeleteTest.class.getResource("/deletetest.hbm.xml");
			Configuration configuration = new Configuration().addURL(configFile);
			SessionFactory sessionFactory = configuration.buildSessionFactory();
			try {
				// initializastion...
				session = sessionFactory.openSession();

				// start a transaction
				Transaction t = session.beginTransaction();
				// a simple folder with a document and a simple link to it
				Folder folder = new Folder(null, "testFolder", "/testFolder");
				Document document = new Document(folder, "test", "test.txt");
				Link link = new Link(folder, "linkt to test", document);
				session.save(folder);
				// commit and save the new instances...
				t.commit();

				// start new transaction
				t = session.beginTransaction();
				// select the Folder instance and delete it, cascading thus the deletion to the instances of children.
				// This works with Hibernate 2.0.3, but not with 2.1.1!! 
				List list = session.find("select o from Folder as o");
				for (int i = 0; i < list.size(); ++i) {
					session.delete(list.get(i));
				}
				// Commit throws an SQLException with Hibernate 2.1.1: 
				// "DELETE statement conflicted with COLUMN REFERENCE constraint".
				// Why? 2.0.3 saves first the changes and then deletes the objects, thus
				// avoiding the foreign reference problems! 2.1.1 does not save any 
				// changes and deletes the objects directly, causing foreign key exception.
				t.commit();

			} catch (HibernateException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			} finally {
				if (session != null) {
					session.clear();
				}
			}
			try {
				// initializastion...
				session = sessionFactory.openSession();

				// start a transaction
				Transaction t = session.beginTransaction();
				// select the Link instance and delete it
				List list = session.find("select o from Link as o");
				for (int i = 0; i < list.size(); ++i) {
					session.delete(list.get(i));
				}
				// now it works...
				t.commit();

			} catch (HibernateException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			} finally {
				if (session != null) {
					session.clear();
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
}
