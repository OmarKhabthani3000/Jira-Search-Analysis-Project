import java.io.*;
import java.util.*;
import net.sf.hibernate.*;

/** Simple Document */
public class Document extends RepositoryItem {

	private String path;
	
	private List links;

	public Document() {
	}

	public Document(Folder parent, String name, String path) {
		super(parent, name);
		setPath(path);
	}

	/**
	 * @hibernate.property
	 *
	 */
	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
    /**
	 * @hibernate.bag
     *  lazy="true"
	 *	inverse="true"
	 *  cascade="all"
     * @hibernate.collection-key
     *  column="itemId"
     * @hibernate.collection-one-to-many
	 *	class="Link"
     */
	public List getLinks() {
		if (links == null) {
			links = new ArrayList();
		}
		return links;
	}
	
	protected void setLinks(List links) {
		this.links = links;
	}
	
	public void addLink(Link link) {
		if (!getLinks().contains(link)) {
			getLinks().add(link);
		}
	}
	
	public boolean removeLink(Link link) {
		return getLinks().remove(link);
	}
	
	public boolean onDelete(Session s) throws CallbackException {
/*		try {
			ArrayList links = new ArrayList(getLinks());
			for (Iterator i = links.iterator(); i.hasNext(); ) {
				s.delete(i.next());
			}
		} catch (HibernateException e) {
			throw new CallbackException(e);
		}*/
		return super.onDelete(s);
	}
}
