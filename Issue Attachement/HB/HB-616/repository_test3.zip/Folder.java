import java.io.*;
import java.util.*;
import net.sf.hibernate.*;

/** Simple Folder class */
public class Folder extends Document {
	
	private List children;
	
	public Folder() {
	}
	
	public Folder(Folder parent, String name, String path) {
		super(parent, name, path);
	}

    /**
	 * @hibernate.bag
     *  lazy="true"
	 *	inverse="true"
	 *  cascade="all"
     * @hibernate.collection-key
     *  column="parentId"
     * @hibernate.collection-one-to-many
	 *	class="RepositoryItem"
     */
	public List getChildren() {
		if (children == null) {
			children = new ArrayList();
		}
		return children;
	}
	
	protected void setChildren(List children) {
		this.children = children;
	}
	
	public void addChild(RepositoryItem child) {
		if (!getChildren().contains(child)) {
			getChildren().add(child);
		}
	}
	
	public boolean removeChild(RepositoryItem child) {
		return getChildren().remove(child);
	}

	public boolean onDelete(Session s) throws CallbackException {
/*		try {
			ArrayList children = new ArrayList(getChildren());
			for (Iterator i = children.iterator(); i.hasNext(); ) {
				s.delete(i.next());
			}
		} catch (HibernateException e) {
			throw new CallbackException(e);
		}*/
		return super.onDelete(s);
	}
}
