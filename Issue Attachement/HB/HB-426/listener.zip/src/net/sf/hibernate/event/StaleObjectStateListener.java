package net.sf.hibernate.event;

/** An observer of failures of optimistic concurrency control.
 * This interface conforms to the JavaBeans API specification section 6 'Events'.
 *
 * @author <a href="mailto:jkristian@docent.com">John Kristian</a>
 */
public interface StaleObjectStateListener extends java.util.EventListener {
    /** Stale object state has been detected. */
    public void staleObjectState(StaleObjectStateEvent event);
}
