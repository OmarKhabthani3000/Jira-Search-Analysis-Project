package net.sf.hibernate.event;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import net.sf.hibernate.Session;
import net.sf.hibernate.StaleObjectStateException;

/** A notification that optimistic concurrency control failed.
 * Class methods enable registration of listeners for such events.
 * This class conforms to the JavaBeans API specification section 6 'Events'.
 *
 * @author <a href="mailto:jkristian@docent.com">John Kristian</a>
 */
public class StaleObjectStateEvent extends java.util.EventObject {

    /** Get the session of the object whose state is stale. */
    public Session getSession() {
        return (Session)(getSource());
    }
	
    /** Get the class of the object whose state is stale. */
    public Class getPersistentClass() {
        return persistentClass;
    }
	
    /** Get the identifier of the object whose state is stale. */
    public Serializable getIdentifier() {
        return identifier;
    }
	
    protected Class persistentClass;
    protected Serializable identifier;

    protected StaleObjectStateEvent(Session source, Class persistentClass, Serializable identifier) {
        super(source);
        this.persistentClass = persistentClass;
        this.identifier = identifier;
    }

    /** Register a listener. */
    public static void addStaleObjectStateListener(StaleObjectStateListener listener) {
        synchronized(listeners) {
            listeners.add(listener);
        }
    }

    /** Unregister a listener. */
    public static void removeStaleObjectStateListener(StaleObjectStateListener listener) {
        synchronized(listeners) {
            listeners.remove(listener);
        }
    }

    private static final ArrayList listeners = new ArrayList();

    /** Notify all registered listeners that optimistic concurrency control failed. */
    public static void notify(Session session, StaleObjectStateException e) {
        List recipients;
        synchronized(listeners) {
            if (listeners.isEmpty()) return; // a performance optimization
            recipients = (List)(listeners.clone());
            // Cloning the list prevents the recipients from affecting delivery of this event.
            // In particular, recipients may add or remove listeners without derailing the Iterator below.
        }
        (new StaleObjectStateEvent(session, e.getPersistentClass(), e.getIdentifier())).notify(recipients);
    }

    /** Notify listeners that optimistic concurrency control failed. */
    protected void notify(Collection listeners) {
        for (Iterator i = listeners.iterator(); i.hasNext(); ) {
            try {
                ((StaleObjectStateListener)(i.next())).staleObjectState(this);
            } catch(Exception ignored) {}
        }
    }

}
