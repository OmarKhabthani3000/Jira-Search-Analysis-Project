
import junit.framework.TestCase;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;

public class TestRequest extends TestCase
{
   /** Current Hibernate Session Factory. */
   private SessionFactory mSessionFactory;

   /** Current Hibernate Session. */
   private Session mSession;


   public void setUp() throws Exception
   {
      Configuration configuration = new Configuration();
      configuration.addClass( Request.class );
      mSessionFactory = configuration.buildSessionFactory();
   }

   public void tearDown() throws Exception
   {
      closeSession();
      mSessionFactory.close();
   }


   public void testRequest() throws Exception
   {
      // Open Session.
      openSession();

      // Create a new Object with no Reference property.
      Request request = new Request();
      request.setStatus( Status.OPEN );

      // Save Object.
      mSession.save( request );
      assertNotNull( "Saved id is null.", request.getId() );

      // Open new Session to avoid cache.
      openSession();

      // Get saved Object.
      Request retrievedRequest =
         (Request) mSession.get( Request.class, request.getId() );

      // Compare original and retrieved objects.
      assertNotNull( "Retrieved object is null.", retrievedRequest );
      assertEquals( "id", request.getId(), retrievedRequest.getId() );
      assertEquals( "reference", request.getReference(), retrievedRequest.getReference() );
      assertEquals( "status", request.getStatus(), retrievedRequest.getStatus() );
   }


   private void openSession() throws Exception
   {
      closeSession();
      mSession = mSessionFactory.openSession();
   }

   private void closeSession() throws Exception
   {
      if( mSession != null && mSession.isOpen() ) mSession.close();
   }
}
