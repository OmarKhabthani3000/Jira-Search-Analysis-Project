
import java.io.Serializable;

public class Request implements Serializable
{
   private Long mId;

   private String mReference;

   private Status mStatus;

   public Long getId()
   {
      return mId;
   }

   public void setId( Long id )
   {
      mId = id;
   }

   public String getReference()
   {
      return mReference;
   }

   public void setReference( String reference )
   {
      mReference = reference;
   }

   public Status getStatus()
   {
      return mStatus;
   }

   public void setStatus( Status status )
   {
      mStatus = status;
   }
}
