
import net.sf.hibernate.UserType;
import net.sf.hibernate.HibernateException;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Types;


public class StatusUserType implements UserType
{
   private static final int mSqlType = Types.INTEGER;


   public int[] sqlTypes()
   {
      return new int[] { mSqlType };
   }


   public Class returnedClass()
   {
      return Status.class;
   }


   public boolean equals( Object object1, Object object2 )
      throws HibernateException
   {
      if( object1 == object2 )
      {
         return true;
      }
      if( object1 == null || object2 == null )
      {
         return false;
      }
      return object1.equals( object2 );
   }


   public Object nullSafeGet( ResultSet resultSet,
                              String[] columnNames,
                              Object owner )
      throws HibernateException, SQLException
   {
      if( resultSet.wasNull() )
      {
         return null;
      }
      Integer value = new Integer( resultSet.getInt( columnNames[0] ) );
      return Status.getByValue( value );
   }


   public void nullSafeSet( PreparedStatement preparedStatement,
                            Object object,
                            int index )
      throws HibernateException, SQLException
   {
      if( object == null )
      {
         preparedStatement.setNull( index, mSqlType );
      }
      else
      {
         preparedStatement.setObject( index, ((Status) object).getValue(), mSqlType );
      }
   }


   public Object deepCopy( Object object ) throws HibernateException
   {
      return object;
   }


   public boolean isMutable()
   {
      return false;
   }
}
