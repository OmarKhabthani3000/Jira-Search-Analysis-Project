
import java.io.Serializable;
import java.util.Map;
import java.util.HashMap;

public class Status implements Serializable
{
   private Integer mValue;
   private String  mLabel;

   private static final Map mValues = new HashMap();
   private static final Map mLabels = new HashMap();

   public static final Status OPEN    = new Status( 1, "Open" );
   public static final Status PENDING = new Status( 2, "Pending" );
   public static final Status CLOSED  = new Status( 3, "Closed" );


   private Status( int value, String label )
   {
      mValue = new Integer( value );
      mValues.put( mValue, this );

      mLabel = label;
      mLabels.put( mLabel, this );
   }


   public Integer getValue()
   {
      return mValue;
   }

   public String getLabel()
   {
      return mLabel;
   }

   public String toString()
   {
      return mLabel + "=" + mValue;
   }


   public static Status getByValue( Integer value )
   {
      return (Status) mValues.get( value );
   }

   public static Status getByLabel( String label )
   {
      return (Status) mLabels.get( label );
   }
}
