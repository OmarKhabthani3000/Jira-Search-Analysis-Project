
import java.util.Iterator;

import net.sf.hibernate.*;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.tool.hbm2ddl.SchemaExport;

public class HibTest {
   public static void main(String[] args) throws HibernateException, java.sql.SQLException {
        Configuration cfg = new Configuration()
            .addClass(Foo.class)
            .addClass(Sub.class)
            .addClass(Bar.class);

      SessionFactory sf = cfg.buildSessionFactory();
      new SchemaExport(cfg).create(true, true);

      Session session = sf.openSession();
      Sub sub = new Sub();
      session.save( sub );

      Bar bar1 = new Bar();
      bar1.setSub( sub );
      Bar bar2 = new Bar();
      Foo foo = new Foo();
      foo.setLeftBar( bar1 );
      foo.setRightBar( bar2 );
      foo.setName( "FuGui" );
      session.save( foo );
      session.flush();
      session.connection().commit();
      session.close();

      System.out.println("Session2");
      Session session2 = sf.openSession();
      foo.setName( "China" );
      session2.saveOrUpdateCopy(foo);
      session2.flush();
      session2.connection().commit();
      session2.close();
   }
}
