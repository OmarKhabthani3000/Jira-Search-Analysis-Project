//$Id: PersistentEnum.java,v 1.4 2003/04/25 03:40:30 oneovthafew Exp $
package net.sf.hibernate;

/**
 * Implementors of <tt>PersistentStringEnum</tt> are enumerated types persisted to
 * the database as <tt>VARCHAR</tt>s. As well as implementing <tt>toString()</tt>,
 * a <tt>PersistentStringEnum</tt> must also provide a static method with the
 * signature:<br>
 * <br>
 * 		<tt>public static PersistentStringEnum fromString(String s)</tt>
 *
 * @author Gavin King
 */

public interface PersistentStringEnum {
	public String toString();
}






