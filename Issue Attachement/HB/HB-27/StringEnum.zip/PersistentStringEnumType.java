//$Id: PersistentEnumType.java,v 1.6 2003/04/25 03:40:37 oneovthafew Exp $
package net.sf.hibernate.type;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import net.sf.hibernate.AssertionFailure;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.MappingException;
import net.sf.hibernate.PersistentStringEnum;
import net.sf.hibernate.engine.SessionImplementor;
import net.sf.hibernate.util.ReflectHelper;

/**
 * A type for Hibernate <tt>PersistentStringEnum</tt>
 * @see net.sf.hibernate.PersistentStringEnum
 * @author Gavin King
 */
public class PersistentStringEnumType
	extends ImmutableType
	implements LiteralType {

	private static final Class[] STRING_ARG = new Class[] { String.class };
	private final Class enumClass;
	private final Method method;

	/**
	 * Constructor.
	 * @param enumClass
	 * @throws MappingException
	 */
	public PersistentStringEnumType(Class enumClass) throws MappingException {
		this.enumClass = enumClass;
		try {
			method = enumClass.getDeclaredMethod("fromString", STRING_ARG);
			if (!ReflectHelper.isPublic(enumClass, method))
				method.setAccessible(true);
		} catch (NoSuchMethodException nme) {
			throw new MappingException(
				"PersistentStringEnum class did not implement fromString(String): "
					+ enumClass.getName());
		}
	}

	/**
	 * Returns an object of the correct type from a
	 * result set.
	 */
	public Object get(ResultSet rs, String name)
		throws HibernateException, SQLException {
		String code = rs.getString(name);
		if (rs.wasNull()) {
			return null;
		} else {
			return getInstance(code);
		}
	}

	/**
	 * Returns an instance of an enumerated type.
	 * @param code
	 * @return
	 * @throws HibernateException
	 */
	public Object getInstance(String code) throws HibernateException {
		try {
			return method.invoke(null, new Object[] { code });
		} catch (IllegalArgumentException iae) {
			throw new AssertionFailure(
				"Could not invoke fromString() from PersistentStringEnumType",
				iae);
		} catch (InvocationTargetException ite) {
			throw new HibernateException(
				"InvocationTargetException occurred inside fromString()",
				ite);
		} catch (IllegalAccessException iae) {
			throw new HibernateException(
				"IllegalAccessException occurred calling fromString)",
				iae);
		}
	}

	/**
	 * Returns true if the enumerated type instances are equal.
	 */
	public boolean equals(Object x, Object y) {
		return (x == y)
			|| (x != null
				&& y != null
				&& x.getClass() == y.getClass()
				&& ((PersistentStringEnum) x).toString()
					== ((PersistentStringEnum) y).toString());
	}

	/**
	 * Returns the class for this enumerated type.
	 */
	public Class getReturnedClass() {
		return enumClass;
	}

	/**
	 * Sets an 
	 */
	public void set(PreparedStatement st, Object value, int index)
		throws SQLException {

		if (value == null) {
			st.setNull(index, Types.VARCHAR);
		} else {
			st.setString(index, ((PersistentStringEnum) value).toString());
		}
	}

	/**
	 * Returns the Hibernate SQL type.
	 */
	public int sqlType() {
		return Types.VARCHAR;
	}

	/**
	 * Returns the name of the enumerated type class.
	 */
	public String getName() {
		return enumClass.getName();
	}

	/**
	 * Returns an XML compliant representation of a
	 * enumerated type instance.
	 */
	public String toXML(Object value) {
		return (value == null)
			? null
			: ((PersistentStringEnum) value).toString();
	}
	
	/**
	 * Returns an enumerated type instance from a cache.
	 */
	public Object assemble(
		Serializable cached,
		SessionImplementor session,
		Object owner)
		throws HibernateException {
		if (cached == null) {
			return null;
		} else {
			return getInstance((String)cached);
		}
	}

	/**
	 * 
	 */
	public Serializable disassemble(Object value, SessionImplementor session)
		throws HibernateException {
		return (value == null)
			? null
			: ((PersistentStringEnum) value).toString();
	}

	/**
	 * 
	 */
	public String objectToSQLString(Object value) throws Exception {
		return ((PersistentStringEnum) value).toString();
	}
}
