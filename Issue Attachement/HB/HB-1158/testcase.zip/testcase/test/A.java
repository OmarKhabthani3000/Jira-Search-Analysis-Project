package test;

import java.io.Serializable;
import java.math.BigDecimal;
import org.apache.commons.lang.builder.ToStringBuilder;


/** @author Hibernate CodeGenerator */
public class A implements Serializable {

    /** identifier field */
    private BigDecimal id;

    /** nullable persistent field */
    private String name;

    /** nullable persistent field */
    private test.B b;

    /** nullable persistent field */
    private test.C c;

    /** full constructor */
    public A(BigDecimal id, String name, test.B b) {
        this.id = id;
        this.name = name;
        this.b = b;
    }

    /** default constructor */
    public A() {
    }

    /** minimal constructor */
    public A(BigDecimal id) {
        this.id = id;
    }

    public BigDecimal getId() {
        return this.id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public test.B getB() {
        return this.b;
    }

    public void setB(test.B b) {
        this.b = b;
    }

    public test.C getC() {
        return this.c;
    }

    public void setC(test.C c) {
        this.c = c;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

}
