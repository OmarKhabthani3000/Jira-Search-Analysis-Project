package test;

import java.io.Serializable;
import java.math.BigDecimal;
import org.apache.commons.lang.builder.ToStringBuilder;


/** @author Hibernate CodeGenerator */
public class C implements Serializable {

    /** identifier field */
    private BigDecimal id;

    /** nullable persistent field */
    private String name;

    /** full constructor */
    public C(BigDecimal id, String name) {
        this.id = id;
        this.name = name;
    }

    /** default constructor */
    public C() {
    }

    /** minimal constructor */
    public C(BigDecimal id) {
        this.id = id;
    }

    public BigDecimal getId() {
        return this.id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

}
