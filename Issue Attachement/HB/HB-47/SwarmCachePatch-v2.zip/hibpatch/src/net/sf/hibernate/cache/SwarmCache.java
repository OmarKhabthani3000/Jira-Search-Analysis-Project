package net.sf.hibernate.cache;

import net.sf.swarmcache.*;
import java.io.Serializable;
import org.apache.commons.logging.*;

/**
 * Cache implementation for SwarmCache.
 *
 * @author John Watkinson
 */
public class SwarmCache implements Cache {

    private static final Log log = LogFactory.getLog(SwarmCache.class);

    private static CacheFactory cacheFactory;

    /**
     * Sets up SwarmCache to use an LRU caching algorithm locally.
     */
    static {
        // Configure cache
        CacheConfiguration conf = new CacheConfiguration();
        conf.setCacheType(CacheConfiguration.TYPE_LRU);
        cacheFactory = new CacheFactory(conf);
    }

    private ObjectCache cache = null;

    /**
     * Instantiates the cache with the associated region name.
     */
    public void setRegion(String regionName) throws CacheException {
        log.info("SwarmCache for region '" + regionName + "' created.");
        cache = cacheFactory.createCache(regionName);
    }

    public Object get(Object key) throws CacheException {
        return cache.get((Serializable)key);
    }

    public void put(Object oKey, Object value) throws CacheException {
        Serializable key = (Serializable)oKey;
        if (value == null) {
            // It's actually a flush
            log.debug("Clearing: " + key);
            cache.clear(key);
        } else {
            if (cache.get(key) != null) {
                // Indicate a re-cache
                log.debug("Re-cache");
                cache.clear(key);
            }
            cache.put(key, value);
        }
    }

    public void setTimeout(int timeout) {
        // Not needed by SwarmCache
    }
}