
import java.io.Serializable;

/**
 * @author Ville Peurala
 */
public class Child implements Serializable {
    private static final long serialVersionUID = 1977L;

    // fields

    private java.lang.Integer childId;
    private java.lang.String name;
    private Parent parent;

    // property getters and setters

    public java.lang.Integer getChildId() {
        return this.childId;
    }
    protected void setChildId(java.lang.Integer newValue) {
        this.childId = newValue;
    }
    public java.lang.String getName() {
        return this.name;
    }
    public void setName(java.lang.String newValue) {
        this.name = newValue;
    }
    public Parent getParent() {
        return this.parent;
    }
    public void setParent(Parent newValue) {
        this.parent = newValue;
    }
}