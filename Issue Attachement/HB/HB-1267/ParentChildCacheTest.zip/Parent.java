
import java.io.Serializable;

/**
 * @author Ville Peurala
 */
public class Parent implements Serializable {
    private static final long serialVersionUID = 1977L;

    // fields

    private java.lang.Integer parentId;
    private java.lang.String name;
    private java.util.List children = new java.util.ArrayList();

    // getters and setters

    public java.lang.Integer getParentId() {
        return this.parentId;
    }
    protected void setParentId(java.lang.Integer newValue) {
        this.parentId = newValue;
    }
    public java.lang.String getName() {
        return this.name;
    }
    public void setName(java.lang.String newValue) {
        this.name = newValue;
    }
    public java.util.List getChildren() {
        return this.children;
    }
}