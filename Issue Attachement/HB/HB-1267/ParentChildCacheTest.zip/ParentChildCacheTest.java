
import java.sql.Connection;

import junit.framework.TestCase;
import net.sf.cglib.proxy.Enhancer;
import net.sf.hibernate.Hibernate;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;

/**
 * This test case shows that when using a cache, lazy loading proxies are
 * returned to the caller even after Hibernate.initialize() is explicitly
 * called. If caching is turned off for collection "children" on Parent, this
 * test passes. If caching is turned on for that collection, this test fails.
 * @author Ville Peurala
 */
public class ParentChildCacheTest extends TestCase {

    /**
     * HSQLDB is used with AUTOCOMMIT ON, so there's no need to explicitly open
     * and commit transactions. I have also tried this with manual transactions,
     * and they don't affect the behaviour of this test case in any way.
     * @throws Exception
     */
    public void testInitializedObjectsShouldNotBeProxies() throws Exception {
        Configuration cfg = new Configuration().configure();
        SessionFactory factory = cfg.buildSessionFactory();
        // Create the tables in one session
        Session ddlSession = factory.openSession();
        Connection conn = ddlSession.connection();
        conn
                .createStatement()
                .execute(
                        "CREATE TABLE Parent (Parent_id INT NOT NULL IDENTITY, Name VARCHAR(64) NOT NULL, PRIMARY KEY(Parent_id))");
        conn
                .createStatement()
                .execute(
                        "CREATE TABLE Child (Child_id INT NOT NULL IDENTITY, Name VARCHAR(64) NOT NULL, Parent_id INT NOT NULL, PRIMARY KEY(Child_id), CONSTRAINT FK_Child_Parent_0 FOREIGN KEY (Parent_id) REFERENCES Parent(Parent_id))");
        conn.createStatement().execute(
                "INSERT INTO Parent (Parent_id, Name) VALUES (1, 'Ukko')");
        conn
                .createStatement()
                .execute(
                        "INSERT INTO Child (Child_id, Name, Parent_id) VALUES (1, 'Pekka', 1)");
        ddlSession.close();

        Child childWhichComesFromDatabase = this
                .getFirstChildOfParentWithId1WhenChildrenAreInitializedAndSessionIsClosed(factory);
        // This assertion passes.
        assertFalse(
                "Objects from an explicitly initialized collection should not be enhanced by CGLIB (if they are, they are lazy loading proxies)",
                Enhancer.isEnhanced(childWhichComesFromDatabase.getClass()));

        Child childWhichComesFromCacheHit = this
                .getFirstChildOfParentWithId1WhenChildrenAreInitializedAndSessionIsClosed(factory);
        // This assertion fails.
        assertFalse(
                "Objects from an explicitly initialized collection should not be enhanced by CGLIB (if they are, they are lazy loading proxies)",
                Enhancer.isEnhanced(childWhichComesFromCacheHit.getClass()));

        conn.close();
    }

    private Child getFirstChildOfParentWithId1WhenChildrenAreInitializedAndSessionIsClosed(
            SessionFactory sessionFactory) throws HibernateException {
        Session session = sessionFactory.openSession();
        Parent parent = (Parent) session.createQuery(
                "FROM Parent AS parent WHERE parent.parentId = 1")
                .uniqueResult();
        Hibernate.initialize(parent.getChildren());
        session.close();
        return (Child) parent.getChildren().get(0);
    }

}