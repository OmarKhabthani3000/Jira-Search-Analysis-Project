// Generated using Velocity
package fr.infologic.stocks.modele;

public class Piece implements java.io.Serializable 
{

    private String idExt;
	private PiecePK piecePK;

	public void setPiecePK(fr.infologic.stocks.modele.PiecePK pk) {
		this.piecePK = pk;
	}
	
	public fr.infologic.stocks.modele.PiecePK getPiecePK() {
		return piecePK;
	}

    public String getIdExt() {
        return idExt;
    }

    public void setIdExt(String idExt) {
        this.idExt = idExt;
    }

}
