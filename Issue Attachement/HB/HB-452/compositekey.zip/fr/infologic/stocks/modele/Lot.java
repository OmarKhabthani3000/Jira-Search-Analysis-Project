// Generated using Velocity
package fr.infologic.stocks.modele;

public class Lot implements java.io.Serializable 
{
	private String idExt;
	private LotPK lotPK;

	public void setLotPK(fr.infologic.stocks.modele.LotPK pk) {
		this.lotPK = pk;
	}
	public fr.infologic.stocks.modele.LotPK getLotPK() {
		return lotPK;
	}
        
    public String getIdExt() {
        return idExt;
    }

    public void setIdExt(String idExt) {
        this.idExt = idExt;
    }
}
