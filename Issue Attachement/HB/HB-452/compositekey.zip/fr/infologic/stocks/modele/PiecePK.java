/*
 * Created on 3 nov. 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package fr.infologic.stocks.modele;

import java.io.Serializable;

public class PiecePK implements Serializable
{	
	private fr.infologic.stocks.modele.Lot lot;
	private Integer noPiece;
	
	public fr.infologic.stocks.modele.Lot getLot() {
		return lot;
	}

	public void setLot(fr.infologic.stocks.modele.Lot lot) {
		this.lot = lot;
	}

	public Integer getNoPiece() {
		return noPiece;
	}

	public void setNoPiece(Integer noPiece) {
		this.noPiece = noPiece;
	}
}
