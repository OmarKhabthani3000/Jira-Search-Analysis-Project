package fr.infologic.stocks.modele;

import java.io.Serializable;

public class LotPK implements Serializable
{
	
	private fr.infologic.stocks.modele.Produit prod;
	private Integer noLot;

	public fr.infologic.stocks.modele.Produit getProd() {
		return prod;
	}

	public void setProd(fr.infologic.stocks.modele.Produit prod) {
		this.prod = prod;
	}
    
	public Integer getNoLot() {
		return noLot;
	}

	public void setNoLot(Integer noLot) {
		this.noLot = noLot;
	}
}
