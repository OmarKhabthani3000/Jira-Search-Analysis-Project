// Generated using Velocity
package fr.infologic.stocks.modele;

public class Mouv implements java.io.Serializable 
{
    private Integer noMouv;
    private fr.infologic.stocks.modele.Piece piece;

    public Integer getNoMouv() {
        return noMouv;
    }

    public void setNoMouv(Integer noMouv) {
        this.noMouv = noMouv;
    }

    public fr.infologic.stocks.modele.Piece getPiece() {
        return piece;
    }

    public void setPiece(fr.infologic.stocks.modele.Piece piece) {
        this.piece = piece;
    }
}
