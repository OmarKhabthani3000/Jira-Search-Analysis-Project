package fr.infologic.stocks.modele;

import java.util.List;
import net.sf.hibernate.Hibernate;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;

/*
 * Minimal class to reproduce query exception
 * could not resolve property type: piece.id.lot.id [from fr.infologic.stocks.modele.Mouv as mouv where mouv.piece.piecePK.lot.lotPK.prod = ? ]
 */
public class Main
{
	public static void main(String[] args) throws HibernateException
	{
		
		Configuration cfg = new Configuration()
			.addClass(Produit.class)
			.addClass(Lot.class)
			.addClass(Piece.class)
			.addClass(Mouv.class)
		;
		SessionFactory sessionFactory =	cfg.buildSessionFactory();

		Session session = sessionFactory.openSession();

		List mouvs = session.find(
				"from fr.infologic.stocks.modele.Mouv as mouv " +
				"where mouv.piece.piecePK.lot.lotPK.prod = ? ",
						new Integer(0),
						Hibernate.INTEGER
		);	
		
		session.close();		
	}
}
