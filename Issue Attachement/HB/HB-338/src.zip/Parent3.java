
public abstract class Parent3 
{
	private long id=0;
	private Parent2 parent;


	public long getId()
	{
		return id;
	}

	public void setId(long l)
	{
		id= l;
	}

	/**
	 * @return
	 */
	public Parent2 getParent()
	{
		return parent;
	}

	/**
	 * @param parent2
	 */
	public void setParent(Parent2 parent2)
	{
		parent= parent2;
	}

}
