drop sequence seq_test;
create sequence seq_test start with 10000;

drop table parent1 cascade constraints;
create table parent1 
(id integer primary key);

drop table parent2 cascade constraints;
create table parent2
	(id integer primary key,
	 parentid integer not null,
	 constraint FK_p2_to_p1 foreign key (parentid) references parent1 (id) on delete cascade
	 );

drop table parent3 cascade constraints;
create table parent3
	(id integer primary key,
	parentid integer not null,
	class char(1) not null,
	constraint FK_p3_to_p2 foreign key (parentid) references parent2 (id) on delete cascade
	);
	
drop table EntityChild cascade constraints;
create table EntityChild
	(
	id integer primary key,
	parentid integer not null,
	str varchar2(30),
	constraint FK_EntityChild_TO_p3 foreign key (parentid) references parent3 (id) on delete cascade
	);

drop table valueChilds cascade constraints;
create table valueChilds
	(
	id integer primary key,
	parentid integer not null,
	str varchar2(30),
	type integer,
	constraint FK_ValueChild_to_Entity foreign key (parentid) references EntityChild (id) on delete cascade
	);
	