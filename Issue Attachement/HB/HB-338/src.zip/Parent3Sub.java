import java.util.*;

public class Parent3Sub extends Parent3
{

	private Set items;

	public Set getItems()
	{
		return items;
	}

	public void setItems(Set set)
	{
		items= set;
	}

	public void addItem(EntityChild ec)
	{
		if (items == null)
			items= new HashSet();
		items.add(ec);
		ec.setParent(this);
	}

}
