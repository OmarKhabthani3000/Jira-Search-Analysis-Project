import java.util.*;
public class Parent2 
{

	private long id= 0;
	private Parent1 parent;
	private List parent3s;

	public long getId()
	{
		return id;
	}

	public List getParent3s()
	{
		return parent3s;
	}

	public void setId(long l)
	{
		id= l;
	}

	public void setParent3s(List list)
	{
		parent3s= list;
	}

	/**
	 * @return
	 */
	public Parent1 getParent()
	{
		return parent;
	}

	/**
	 * @param parent1
	 */
	public void setParent(Parent1 parent1)
	{
		parent= parent1;
	}

	public void addParent3(Parent3 p3)
	{
		if (parent3s == null)
			parent3s= new LinkedList();
		parent3s.add(p3);
		p3.setParent(this);
	}

	
}
