
public class ValueChild
{

	private String str;
	private IntValue valueType;
	
	public ValueChild()
	{
	}
	
	public ValueChild(String str1)
	{
		this.str=str1;
	}
	
	public ValueChild(String str1, IntValue type)
	{
		str=str1;
		valueType=type;
	}

	public String getStr()
	{
		return str;
	}

	public void setStr(String string)
	{
		str= string;
	}

	public IntValue getValueType()
	{
		return valueType;
	}

	public void setValueType(IntValue value)
	{
		valueType= value;
	}

}
