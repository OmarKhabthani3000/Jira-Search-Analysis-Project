The relationship.
Parent1---Parent2: 1 to N
Parent2---Parent3: 1 to N.
 Parent3 is a abstract class.
 Parent3Sub is a subclass of parent3.
Parent3Subc----EntityChild: 1 to N
EntityChild---ValueChild: 1 to N(idbag is used here).


