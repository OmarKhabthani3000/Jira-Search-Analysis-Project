import java.util.*;
import net.sf.hibernate.*;
import net.sf.hibernate.cfg.*;
import java.io.*;
import java.net.*;

public class Test
{
	public static SessionFactory sf;
	public static Session session;

	public static void main(String[] args)
	{

		try
		{
			Configuration config= new Configuration();
			ClassLoader tcl= Thread.currentThread().getContextClassLoader();
			Properties prop= new Properties();
			URL url= tcl.getResource("hibernate.properties");
			InputStream in= url.openStream();
			prop.load(in);
			config.setProperties(prop);
			config.addResource("example.hbm.xml", tcl);

			sf= config.buildSessionFactory();
			session= sf.openSession();

			Parent1 p1= createParent1();
			//can modification done out of transaction be saved. 
			long startTime= System.currentTimeMillis();
			Transaction tx= session.beginTransaction();
			session.save(p1);
			tx.commit();
			long endTime= System.currentTimeMillis();
			System.out.println("total time(in ms):" + (endTime - startTime));

		} catch (Exception e)
		{
			e.printStackTrace();
		} finally
		{
			if (session != null)
				try
				{
					session.close();
					//ssession.close();
				} catch (HibernateException e1)
				{
					e1.printStackTrace();
				}
		}
	}

	public static Parent1 createParent1()
	{
		Parent1 p1= new Parent1();
		Parent2 p2= new Parent2();
		Parent3Sub p3= new Parent3Sub();

		p1.addParent2(p2);
		p2.addParent3(p3);

		EntityChild ec= new EntityChild();
		ec.setStr("entity str");
		ec.addValueChild(new ValueChild("test str1", new IntValue(50)));
		p3.addItem(ec);
		return p1;
	}


}
