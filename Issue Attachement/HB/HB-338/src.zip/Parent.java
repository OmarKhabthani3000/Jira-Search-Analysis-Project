import java.util.*;

public class Parent
{
	private long id=0;
	private List values;
	private Set children;
	
	public Set getChildren()
	{
		return children;
	}

	public long getId()
	{
		return id;
	}


	public List getValues()
	{
		return values;
	}

	public void setChildren(Set list)
	{
		children= list;
	}
	public void addChild(EntityChild ec)
	{
		if (children==null)
			children=new HashSet();
		
		children.add(ec);
		//ec.setParent(this);
	}

	public void setId(long l)
	{
		id= l;
	}
	public void setValues(List list)
	{
		values= list;
	}
	
	public void addValue(ValueChild vc)
	{
		if (values==null)
			values=new LinkedList();
		values.add(vc);
	}

}
