import java.util.*;
public class Parent1 
{
	private long id= 0;
	private List parent2s;

	public long getId()
	{
		return id;
	}

	public List getParent2s()
	{
		return parent2s;
	}

	public void setId(long l)
	{
		id= l;
	}

	public void setParent2s(List list)
	{
		parent2s= list;
	}

	public void addParent2(Parent2 p2)
	{
		if (parent2s == null)
			parent2s= new LinkedList();
		parent2s.add(p2);
		p2.setParent(this);
	}

}
