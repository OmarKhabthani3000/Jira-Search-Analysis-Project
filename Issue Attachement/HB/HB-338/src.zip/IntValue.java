/*
 * Created on 2003-9-18
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author jzhang
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class IntValue
{
	private int intValue;
	
	public IntValue(){}
	public IntValue(int v){
		intValue=v;
	}
	
	public int getIntValue()
	{
		return intValue;
	}


	public void setIntValue(int i)
	{
		intValue= i;
	}

}
