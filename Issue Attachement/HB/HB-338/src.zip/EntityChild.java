import java.util.*;
public class EntityChild
{
	private long id;
	private String str;
	private Parent3 parent;
	private List valueChilds;

	public EntityChild()
	{
	}
	public EntityChild(String str)
	{
		this.str= str;
	}

	public long getId()
	{
		return id;
	}

	public Parent3 getParent()
	{
		return parent;
	}

	public String getStr()
	{
		return str;
	}

	public void setId(long l)
	{
		id= l;
	}

	public void setParent(Parent3 parent)
	{
		this.parent= parent;
	}

	public void setStr(String string)
	{
		str= string;
	}

	public List getValueChilds()
	{
		return valueChilds;
	}

	public void setValueChilds(List set)
	{
		valueChilds= set;
	}
	public void addValueChild(ValueChild vc)
	{
		if (valueChilds == null)
			valueChilds= new LinkedList();
		valueChilds.add(vc);
	}

}
