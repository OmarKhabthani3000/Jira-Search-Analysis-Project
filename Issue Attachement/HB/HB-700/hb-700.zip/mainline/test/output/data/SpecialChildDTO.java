package data;

import java.io.Serializable;
import org.apache.commons.lang.builder.ToStringBuilder;


/** @author Hibernate CodeGenerator */
abstract public class SpecialChildDTO extends Child implements java.io.Serializable {

    /** full constructor */
    public SpecialChildDTO(my.Parent parent) {
        super(parent);
    }

    /** default constructor */
    public SpecialChildDTO() {
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

}
