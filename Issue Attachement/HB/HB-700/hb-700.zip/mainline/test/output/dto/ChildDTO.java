package dto;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


/** @author Hibernate CodeGenerator */
abstract public class ChildDTO implements Serializable {

    /** identifier field */
    private Long id;

    /** persistent field */
    private dto.ParentDTO parent;

    /** full constructor */
    public ChildDTO(dto.ParentDTO parent) {
        this.parent = parent;
    }

    /** default constructor */
    public ChildDTO() {
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public dto.ParentDTO getParent() {
        return this.parent;
    }

    public void setParent(dto.ParentDTO parent) {
        this.parent = parent;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof ChildDTO) ) return false;
        ChildDTO castOther = (ChildDTO) other;
        return new EqualsBuilder()
            .append(this.getId(), castOther.getId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getId())
            .toHashCode();
    }

}
