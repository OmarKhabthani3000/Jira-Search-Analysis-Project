//$Id: Renderer.java,v 1.2 2003/12/07 19:41:34 maxcsaucdk Exp $
package net.sf.hibernate.tool.hbm2java;


import java.io.PrintWriter;
import java.util.Map;
import java.util.Properties;


public interface Renderer {
	
	/** Called with the optional list of properties from config.xml */ 
	public void configure(Properties properties);
	
    /** 
     * 
     * @param savedToPackage what package is this class placed in
     * @param savedToClass what classname does it really get
     * @param classMapping what classmapping is this for
     * @param class2classmap A complete map from classname to the classmapping
     * @param writer where we want the output
     * @throws Exception
     */    
	public void render(String savedToPackage, String savedToClass, ClassMapping classMapping, Map class2classmap, PrintWriter writer) throws Exception;
}






