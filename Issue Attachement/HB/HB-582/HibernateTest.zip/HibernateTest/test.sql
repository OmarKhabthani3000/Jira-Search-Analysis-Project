/*==============================================================*/
/* Database name:  test                                         */
/* DBMS name:      Microsoft SQL Server 2000                    */
/* Created on:     2003-12-22 17:15:56                          */
/*==============================================================*/

/*==============================================================*/
/* Table: "group"                                               */
/*==============================================================*/
create table "group" (
   group_id             char(10)             not null,
   group_name           char(20)             not null,
   constraint PK_GROUP primary key  (group_id)
)
go


/*==============================================================*/
/* Table: person                                                */
/*==============================================================*/
create table person (
   group_id             char(10)             not null,
   person_id            char(10)             not null,
   person_name          char(20)             not null,
   constraint PK_PERSON primary key  (group_id, person_id)
)
go


/*==============================================================*/
/* Index: Relationship_group_person_FK                          */
/*==============================================================*/
create   index Relationship_group_person_FK on person (
group_id
)
go


alter table person
   add constraint FK_PERSON_RELATIONS_GROUP foreign key (group_id)
      references "group" (group_id)
go