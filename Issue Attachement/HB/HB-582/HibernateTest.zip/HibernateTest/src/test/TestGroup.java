/*
 * �������� 2003-8-18
 *
 * �����������ļ�ģ��Ϊ
 * ���� > ��ѡ�� > Java > �������� > �����ע��
 */
package test;

import java.sql.SQLException;
import java.util.*;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.MappingException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;

/**
 * @author Administrator
 *
 * ��������������ע�͵�ģ��Ϊ
 * ���� > ��ѡ�� > Java > �������� > �����ע��
 */
public class TestGroup extends TestCase {

	/**
	 * Confirguration DataSource
	 */
	private Configuration ds = null;

	/**
	 * 
	 */
	public TestGroup() {
		super();
		// TODO �Զ����ɹ��캯�����
	}

	/**
	 * @param arg0
	 */
	public TestGroup(String arg0) {
		super(arg0);
		// TODO �Զ����ɹ��캯�����
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(suite());
	}

	public static Test suite() {
		//construct a TestSuite using the .class property of 
		//the TestCase.
		return new TestSuite(TestGroup.class);
	}

	private Session getSession() throws HibernateException {
		try {
			SessionFactory sessions =
				new Configuration().configure().buildSessionFactory();
			return sessions.openSession();
		} catch (MappingException e) {
			e.printStackTrace();
			return null;
		} catch (HibernateException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * Insert Group
	 */
	public void testInsertGroup() throws HibernateException, SQLException {
		Session sess = getSession();

		for (int i = 0; i < 5; i++) {
			Group group = new Group();
			group.setId(Integer.toString(i + 1).trim());
			group.setName("group" + group.getId());

			if (group.getPersons() == null) {
				HashSet persons = new HashSet();
				group.setPersons(persons);
			}

			for (int j = 0; j < 5; j++) {
				Person person = new Person();
				person.setId(Integer.toString((i + 1) * 10 + j + 1));
				person.setName("person" + person.getId());
				person.setGroup(group);
				group.getPersons().add(person);
			}

			sess.save(group);
			sess.flush();
			sess.connection().commit();
		}
		sess.close();
	}	

	/**
	 * Insert Tasks
	 */
	public void testLoadGroup() throws HibernateException {
		Session session = getSession();		
		if (session != null) {
			Group group = (Group) session.load(Group.class, "1");
			if (group != null) {
				System.out.println(group.getPersons().size());
				Iterator iter = group.getPersons().iterator();
				while (iter.hasNext()) {
					Person p = (Person)iter.next();
					System.out.println("id:" + p.getId() + "  name:" + p.getName());
				}
			}
		}
	}

}