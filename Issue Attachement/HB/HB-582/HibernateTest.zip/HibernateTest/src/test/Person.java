/*
 * Created on 2003-12-23
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package test;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Person{
	private String id;
	private String name;
    private Group group;
	/**
	 * @return
	 */
	public Group getGroup() {
		return group;
	}

	/**
	 * @return
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param group
	 */
	public void setGroup(Group group) {
		this.group = group;
	}

	/**
	 * @param string
	 */
	public void setId(String string) {
		id = string;
	}

	/**
	 * @param string
	 */
	public void setName(String string) {
		name = string;
	}

    /*
	public boolean equals(Object obj) {
		if (super.equals(obj))
			return true;

		if (obj instanceof Person) {
			Person tmp = (Person) obj;
			return this.id.equals(tmp.id)
				&& this.group.getId().equals(tmp.group.getId());
		} else
			return false;
	}

	public int hashCode() {
		return (group.getId() + this.getId()).hashCode();
	}*/
}
