package com.notiva.example;

import junit.framework.TestCase;
import net.sf.hibernate.Session;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.dialect.HSQLDialect;

import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * Created by IntelliJ IDEA.
 * User: jcarreira
 * Date: Oct 13, 2003
 * Time: 3:48:04 PM
 * To change this template use Options | File Templates.
 */
public abstract class HibernateTestCase extends TestCase {
    Configuration configuration;
    public void setUp() {
        try {
            configuration = SessionFactoryManager.getConfiguration();
            String[] buildScripts = configuration.generateSchemaCreationScript(new HSQLDialect());
            Session session = SessionFactoryManager.getSession();
            Connection conn = session.connection();
            for (int i = 0; i < buildScripts.length; i++) {
                String buildScript = buildScripts[i];
                PreparedStatement stmt = conn.prepareCall(buildScript);
                stmt.execute();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void tearDown() {
         try {
            Session session = SessionFactoryManager.getSession();
            String[] dropScripts = configuration.generateDropSchemaScript(new HSQLDialect());
            Connection conn = session.connection();
            for (int i = 0; i < dropScripts.length; i++) {
                String dropScript = dropScripts[i];
                PreparedStatement stmt = conn.prepareCall(dropScript);
                stmt.execute();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
