package com.notiva.example;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;

import java.util.List;
import java.util.Set;

public class LazyInitializationTest extends HibernateTestCase {
    String parentId;

    public void setUp() {
        super.setUp();
        Session session;
        try {
            session = SessionFactoryManager.getSession();
            Parent parent = new Parent();
            parent.setName("Parent");
            for (int i = 0; i < 10; i++) {
                Child child = new Child();
                child.setName("Child " + i);
                parent.addChild(child);
                session.save(child);
            }
            session.save(parent);
            SessionFactoryManager.commit();
            parentId = parent.getId();
        } catch (Exception e) {
            throw new RuntimeException("Unable to save parent to database");
        }

        SessionFactoryManager.destroy();
    }

    public void testParentAndChildrenAreInDatabase() throws HibernateException {
        Session session = SessionFactoryManager.getSession();
        List parents = session.find("from parent in class Parent");
        assertEquals(1, parents.size());
        Parent parent = (Parent) parents.get(0);
        Set children = parent.getChildren();
        assertNotNull(children);
        assertEquals(10, children.size());
    }

    public void testLazyInitializationIsNotEnabledOnFind() throws HibernateException {
        Session session = SessionFactoryManager.getSession();
        List parents = session.find("from parent in class Parent");
        assertEquals(1, parents.size());
        Parent parent = (Parent) parents.get(0);
        // make sure it's loaded, not lazy
        SessionFactoryManager.destroy();
        Set children = parent.getChildren();
        assertNotNull(children);
        assertEquals(10, children.size());
    }

    public void testLazyInitializationIsNotEnabledOnLoad() throws HibernateException {
        Session session = SessionFactoryManager.getSession();
        Parent parent = (Parent) session.load(Parent.class, parentId);
        assertNotNull(parent);
        // make sure it's loaded, not lazy
        SessionFactoryManager.destroy();
        Set children = parent.getChildren();
        assertNotNull(children);
        assertEquals(10, children.size());
    }

    private void checkChildren(Parent parent) {

    }

}
