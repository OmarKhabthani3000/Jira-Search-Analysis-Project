package com.notiva.example;

import junit.framework.TestCase;
import net.sf.hibernate.Session;
import net.sf.hibernate.HibernateException;
import com.notiva.example.SessionFactoryManager;

/**
 * com.notiva.example.SessionFactoryManagerTest
 * @author Jason Carreira
 * Created Mar 4, 2003 1:23:02 AM
 */
public class SessionFactoryManagerTest extends TestCase {
    public void testSession() {
        try {
            Session session = SessionFactoryManager.getSession();
            assertNotNull(session);
        } catch (HibernateException e) {
            e.printStackTrace();
            fail();
        }
    }

    public void testSameSession() {
        try {
            Session session1 = SessionFactoryManager.getSession();
            Session session2 = SessionFactoryManager.getSession();
            assertEquals(session1, session2);
        } catch (HibernateException e) {
            e.printStackTrace();
            fail();
        }
    }

    public void testDifferentSessionOnClose() {
        try {
            Session session1 = SessionFactoryManager.getSession();
            session1.close();
            Session session2 = SessionFactoryManager.getSession();
            assertFalse(session1 == session2);
        } catch (HibernateException e) {
            e.printStackTrace();
            fail();
        }
    }
}