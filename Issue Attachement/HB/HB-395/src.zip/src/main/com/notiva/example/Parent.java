package com.notiva.example;

import com.notiva.example.Child;
import com.notiva.example.DataObject;

import java.util.Set;
import java.util.HashSet;

public class Parent extends DataObject {

    private String name;
    private Set children;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set getChildren() {
        return children;
    }

    public void setChildren(Set children) {
        this.children = children;
    }

    public void addChild(Child child) {
        if (children == null) {
            children = new HashSet();
        }
        child.setParent(this);
        children.add(child);
    }
}
