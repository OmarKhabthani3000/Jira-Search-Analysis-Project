package com.notiva.example;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.InputStream;
import java.sql.SQLException;
import java.util.Properties;

import com.notiva.example.Child;
import com.notiva.example.Parent;

/**
 * com.notiva.example.SessionFactoryManagerTest
 * @author Jason Carreira
 * Created Mar 4, 2003 12:29:23 AM
 */
public class SessionFactoryManager {
    private static final Log LOG = LogFactory.getLog(SessionFactoryManager.class);
    private static final Configuration CONFIGURATION = buildConfiguration();
    private static final SessionFactory FACTORY = buildSesionFactory(CONFIGURATION);
    private static ThreadLocal localSession = new ThreadLocal();

    private static SessionFactory buildSesionFactory(Configuration configuration) {
        try {
            return configuration.buildSessionFactory();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static Configuration buildConfiguration() {
        Configuration configuration = null;
        try {
            Properties databaseProps = new Properties();
            InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("database.properties");
            if (is != null) {
                databaseProps.load(is);
            } else {
                LOG.error("Unable to find database.properties");
            }
            configuration = new Configuration()
                            .addClass(Parent.class)
                            .addClass(Child.class)
                            .setProperties(databaseProps);
        } catch (Exception e) {
            LOG.error("Caught exception while building configuration.",e);
        }
        return configuration;
    }

    public static boolean hasSession() {
        Session session = (Session) localSession.get();
        return (session != null);
    }

    public static Session getSession() throws HibernateException {
        Session session = (Session) localSession.get();
        if ((session == null) || (!session.isOpen())) {
            session = FACTORY.openSession();
            localSession.set(session);
        }
        return session;
    }

    public static void commit() throws HibernateException, SQLException {
        if (!hasSession()) {
            throw new IllegalStateException("Attempted to commit a transaction when there was no Session.");
        }
        Session session = getSession();
        session.flush();
        session.connection().commit();
    }

    public static void rollback() throws HibernateException, SQLException {
        if (hasSession()) {
            getSession().connection().rollback();
        }
    }

    public static void destroy() {
        if (hasSession()) {
            try {
                Session session = getSession();
                if (session.isOpen()) {
                    session.close();
                }
            } catch (HibernateException e) {
                LOG.warn("Caught Exception while trying to clean up Session.");
            } finally {
                localSession.set(null);
            }
        }
    }

    public static Configuration getConfiguration() {
        return CONFIGURATION;
    }
}
