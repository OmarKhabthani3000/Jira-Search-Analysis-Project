package com.notiva.example;

/**
 * Created by IntelliJ IDEA.
 * User: jcarreira
 * Date: Oct 13, 2003
 * Time: 3:35:50 PM
 * To change this template use Options | File Templates.
 */
public abstract class DataObject {
    private String id;
    private int version;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public boolean equalsA(Object o) {
        if (this == o) return true;
        if (!(o.getClass() == this.getClass())) return false;

        final DataObject dataObject = (DataObject) o;

        if (id != dataObject.id) return false;
        if (version != dataObject.version) return false;

        return true;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o.getClass() == this.getClass())) return false;

        final DataObject dataObject = (DataObject) o;

        if (version != dataObject.version) return false;
        if (id != null ? !id.equals(dataObject.id) : dataObject.id != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (id != null ? id.hashCode() : 0);
        result = 29 * result + version;
        return result;
    }
}
