package test;

import net.sf.hibernate.*;
import net.sf.hibernate.cfg.*;
import java.sql.*;
import javax.sql.*;
import java.math.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class Main {

    static SessionFactory sessionFactory;

    static private Log log = LogFactory.getLog(Main.class);

    static {
        try {
            // Create the SessionFactory
            sessionFactory = new Configuration().configure().buildSessionFactory();
        } catch (Throwable ex) {
            log.error("Initial SessionFactory creation failed.", ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    // arguments: [hostname] [port] [user] [password]

    public static void main(String[] args) throws Exception {
        String connstring = "jdbc:oracle:thin:@" + args[0] + ":" + args[1] + ":" + args[2];
        DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
        Connection con = DriverManager.getConnection(connstring, args[2], args[3]);
        con.setAutoCommit(false);
        Session session = sessionFactory.openSession(con);
        // Does extra queries - see logs for proof
        A a = (A)session.get(A.class, new BigDecimal("1"));
        session.clear();
        // Also does extra queries
        Query q = session.createQuery("from test.A a left outer join fetch a.b left outer join fetch a.c where a.id = 1");
        q.list();
        session.clear();
        // Also does extra queries
        q = session.createQuery("from test.A a left outer join a.b left outer join a.c where a.id = 1");
        q.list();
    }

}
