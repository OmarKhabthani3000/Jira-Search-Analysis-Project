package test;

import java.io.Serializable;
import java.math.BigDecimal;
import org.apache.commons.lang.builder.ToStringBuilder;


/** @author Hibernate CodeGenerator */
public class B implements Serializable {

    private A a;

    /** identifier field */
    private BigDecimal id;

    /** nullable persistent field */
    private String name;

    /** full constructor */
    public B(BigDecimal id, String name) {
        this.id = id;
        this.name = name;
    }

    /** default constructor */
    public B() {
    }

    /** minimal constructor */
    public B(BigDecimal id) {
        this.id = id;
    }

    public BigDecimal getId() {
        return this.id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public A getA() {
        return this.a;
    }

    public void setA(A a) {
        this.a = a;
    }
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

}
