// Don't edit this file; it is automatically generated.
package com.docent.lms.entities;

import com.docent.exceptions.DocentException;
import com.docent.lms.entities.Entity;
import java.io.Serializable;
import java.util.Map;
import com.docent.lms.entities.enums.EntityStatus;
import com.docent.lms.entities.Role;
import com.docent.lms.entities.Permission;

/** A relationship between a role and a permission.
         * A permission can be granted to any role or denied to any role.
         * A denial overrides a grant; that is, a principal who is both granted
         * and denied the same permission lacks that permission for access control.
            
 * @author entity.java.xsl, developed by <a href="mailto:jkristian@docent.com?subject=entity.java.xsl">John Kristian</a>
 */
public interface RolePermissionAssociation extends Entity {
    // Don't edit this interface; it is automatically generated.

    /** Delete this entity from the database.
     * @throws DocentException the entity was not deleted from the database */
    public void delete()
        throws DocentException;

    /** The source of all RolePermissionAssociation objects.
     * @author entity.java.xsl, developed by <a href="mailto:jkristian@docent.com?subject=entity.java.xsl">John Kristian</a>
     */
    public interface Factory {
        // Don't edit this interface; it is automatically generated.

        /** Get an HQL query for all entities of this type.
         * @throws DocentException  */
        public String getAll()
            throws DocentException;

        /** Get the entity with the given id.
         * @param id identifies the desired entity
         * @throws DocentException no such entity was found */
        public RolePermissionAssociation getById(Id id)
            throws DocentException;

        /** 
         * @param role 
         * @param permission 
         * @throws DocentException  */
        public RolePermissionAssociation create(Role role, Permission permission)
            throws DocentException;

    }

    /** Get the version.&nbsp;
     * <b>This property is queryable as "version".</b>
 */
    public long getVersion();

    /** Get whether permission is granted (true) or denied (false).&nbsp;
     * <b>This property is queryable as "grant".</b>
 */
    public boolean isGrant();
    /** Set whether permission is granted (true) or denied (false).
     * @param grant the new value
     * @throws DocentException the value was not changed */
    public void setGrant(boolean grant)
        throws DocentException;

    /** Get the identifier. */
    public RolePermissionAssociation.Id getId();

    /** The identifier of a RolePermissionAssociation.
     * @author entity.java.xsl, developed by <a href="mailto:jkristian@docent.com?subject=entity.java.xsl">John Kristian</a>
     */
    public static final class Id implements Serializable {
        // Don't edit this class; it is automatically generated.

        /** Get the role.&nbsp;
         * <b>This property is queryable as "role".</b>
 */
        public Role getRole()
        {return role;}
        /** Set the role.
         * @param role the new value
         * @throws DocentException the value was not changed */
        private void setRole(Role role)
            throws DocentException
        {this.role = role;}
        private Role role;

        /** Get the permission.&nbsp;
         * <b>This property is queryable as "permission".</b>
 */
        public Permission getPermission()
        {return permission;}
        /** Set the permission.
         * @param permission the new value
         * @throws DocentException the value was not changed */
        private void setPermission(Permission permission)
            throws DocentException
        {this.permission = permission;}
        private Permission permission;

        public Id() {}
        public Id(Role role, Permission permission)
        {
            this.role = role;
            this.permission = permission;
        }
        public String toString()
        {
            StringBuffer buf = new StringBuffer();
            buf.append("{");
            if (role == null) buf.append(role);
            else buf.append(role.getEntityId());
            buf.append(", ");
            if (permission == null) buf.append(permission);
            else buf.append(permission.getEntityId());
            buf.append("}");
            return buf.toString();
        }
        public String toString(boolean verbose)
        {
            if ( ! verbose) return toString();
            StringBuffer buf = new StringBuffer();
            buf.append("{");
            buf.append("role=");
            buf.append(role);
            buf.append(", ");
            buf.append("permission=");
            buf.append(permission);
            buf.append("}");
            return buf.toString();
        }
        public boolean equals(Object obj)
        {
            if (!(obj instanceof Id)) return false;
            Id that = (Id)obj;
            if (!(this.role.equals(that.role))) return false;
            if (!(this.permission.equals(that.permission))) return false;
            return true;
        }
        public int hashCode()
        {
            int result = 0;
            if (null!=role) result ^= role.hashCode();
            if (null!=permission) result ^= permission.hashCode();
            return result;
        }
    }
    /** A reserved value, which is not stored in the database. */
    public static final Id UNSAVED_id = null;

}
