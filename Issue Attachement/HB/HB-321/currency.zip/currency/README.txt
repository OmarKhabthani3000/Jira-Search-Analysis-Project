hibernate*.txt are comparable excerpts from JBoss log files.
The difference between them is the version of hibernate2.jar.
