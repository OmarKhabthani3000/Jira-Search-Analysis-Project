// Don't edit this file; it is automatically generated.
package com.docent.lms.entities;

import com.docent.exceptions.DocentException;
import com.docent.lms.entities.Entity;
import java.io.Serializable;
import java.util.Map;
import com.docent.lms.entities.enums.EntityStatus;
import com.docent.lms.entities.Currency;

/** Localized properties of a Currency.
 * @author entity.java.xsl, developed by <a href="mailto:jkristian@docent.com?subject=entity.java.xsl">John Kristian</a>
 */
public interface Currency_T extends Entity {
    // Don't edit this interface; it is automatically generated.

    /** Delete this entity from the database.
     * @throws DocentException the entity was not deleted from the database */
    public void delete()
        throws DocentException;

    /** Get the identifier. */
    public Currency_T.Id getId();

    /** The identifier of a Currency_T.
     * @author entity.java.xsl, developed by <a href="mailto:jkristian@docent.com?subject=entity.java.xsl">John Kristian</a>
     */
    public static final class Id implements Serializable {
        // Don't edit this class; it is automatically generated.

        /** Get the entity.&nbsp;
         * <b>This property is queryable as "entity".</b>
 */
        public Currency getEntity()
        {return entity;}
        /** Set the entity.
         * @param entity the new value
         * @throws DocentException the value was not changed */
        private void setEntity(Currency entity)
            throws DocentException
        {this.entity = entity;}
        private Currency entity;

        /** Get the localeId.&nbsp;
         * <b>This property is queryable as "localeId".</b>
 */
        public Long getLocaleId()
        {return localeId;}
        /** Set the localeId.
         * @param localeId the new value
         * @throws DocentException the value was not changed */
        private void setLocaleId(Long localeId)
            throws DocentException
        {this.localeId = localeId;}
        private Long localeId;

        public Id() {}
        public Id(Currency entity, Long localeId)
        {
            this.entity = entity;
            this.localeId = localeId;
        }
        public String toString()
        {
            StringBuffer buf = new StringBuffer();
            buf.append("{");
            if (entity == null) buf.append(entity);
            else buf.append(entity.getEntityId());
            buf.append(", ");
            buf.append(localeId);
            buf.append("}");
            return buf.toString();
        }
        public String toString(boolean verbose)
        {
            if ( ! verbose) return toString();
            StringBuffer buf = new StringBuffer();
            buf.append("{");
            buf.append("entity=");
            buf.append(entity);
            buf.append(", ");
            buf.append("localeId=");
            buf.append(localeId);
            buf.append("}");
            return buf.toString();
        }
        public boolean equals(Object obj)
        {
            if (!(obj instanceof Id)) return false;
            Id that = (Id)obj;
            if (!(this.entity.equals(that.entity))) return false;
            if (!(this.localeId.equals(that.localeId))) return false;
            return true;
        }
        public int hashCode()
        {
            int result = 0;
            if (null!=entity) result ^= entity.hashCode();
            if (null!=localeId) result ^= localeId.hashCode();
            return result;
        }
    }
    /** A reserved value, which is not stored in the database. */
    public static final Id UNSAVED_id = null;

    /** The source of all Currency_T objects.
     * @author entity.java.xsl, developed by <a href="mailto:jkristian@docent.com?subject=entity.java.xsl">John Kristian</a>
     */
    public interface Factory {
        // Don't edit this interface; it is automatically generated.

        /** Get an HQL query for all entities of this type.
         * @throws DocentException  */
        public String getAll()
            throws DocentException;

        /** Get the entity with the given id.
         * @param id identifies the desired entity
         * @throws DocentException no such entity was found */
        public Currency_T getById(Id id)
            throws DocentException;

        /** Create a new persistent localization.
         * @return a new localization, which is persistent.
         * @param id identifies the locale and entity to be localized
         * @throws DocentException the localization was not created */
        public Currency_T create(Id id)
            throws DocentException;

    }

    /** Get the name.&nbsp;
     * <b>This property is queryable as "name".</b>
 */
    public String getName();
    /** Set the name.
     * @param name the new value
     * @throws DocentException the value was not changed */
    public void setName(String name)
        throws DocentException;

}
