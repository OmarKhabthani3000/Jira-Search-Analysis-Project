//$Id:$
package org.hibernate.test;

import org.hibernate.test.util.HibernateTestCase;

import net.sf.hibernate.Session;
import net.sf.hibernate.Transaction;

/**
 * @author Emmanuel
 */
public class MyABCTest extends HibernateTestCase {

	/**
	 * @param x
	 */
	public MyABCTest(String x) {
		super(x);
	}
	
	public String[] getMappings() {
		return new String[] { "A.hbm.xml", "D.hbm.xml", "C.hbm.xml"};
	}
	
	public void testHibernate() throws Exception {
		
		Transaction tx = null;
		Session session = null;
		//populate DB
		session = openSession();
		tx = session.beginTransaction();
		session.find("select d.b.c.id from D as d"); //works
		session.find("select d.b.c.name from D as d"); //don't works once you need to load c
		session.close();
	}

}
