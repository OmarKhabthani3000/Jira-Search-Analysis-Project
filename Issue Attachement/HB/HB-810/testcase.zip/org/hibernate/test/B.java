////$Id:$
package org.hibernate.test;

/**
 * @author Emmanuel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class B extends A {

}
