////$Id:$
package org.hibernate.test;

/**
 * @author Emmanuel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class D {
	private Integer id;
	private B b;
	/**
	 * @return
	 */
	public B getB() {
		return b;
	}

	/**
	 * @return
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param b
	 */
	public void setB(B b) {
		this.b = b;
	}

	/**
	 * @param integer
	 */
	public void setId(Integer integer) {
		id = integer;
	}

}
