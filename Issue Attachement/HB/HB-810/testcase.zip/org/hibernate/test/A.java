////$Id:$
package org.hibernate.test;

/**
 * @author Emmanuel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class A {
	private Integer id;
		private C c;

		/**
		 * @return
		 */
		public C getC() {
			return c;
		}

	/**
	 * @return
	 */
	public Integer getId() {
		return id;
	}

		/**
		 * @param c
		 */
		public void setC(C c) {
			this.c = c;
		}

	/**
	 * @param integer
	 */
	public void setId(Integer integer) {
		id = integer;
	}

}
