
package com.hibernate.dao;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.FlushMode;
import net.sf.hibernate.cfg.Configuration;

/**
 * &copy; Copyright <A href="http://www.test.com">Quicksilva</A> 2004
 * <p/>
 * A class representing the object to handle Hibernate session allocation.
 * <p/>
 * Created on 15-Apr-2004, at 10:32:01.<BR/> Project: Hibernate Examples.<BR/> Filename: SessionHandler.java.
 *
 * @author Simon Knott
 */
public class SessionHandler
{

    /**
     * The static Session Factory configuration object, used for generating the Hibernate sessions.
     */
    private static SessionFactory factory;

    /**
     * A static variable holding the current Hibernate session to use in transactions.
     */
    private static Session currentSession;

    /**
     * The initialiser for the Session Factory.
     */
    static
    {
        try
        {
            factory = new Configuration().configure().buildSessionFactory();
        }
        catch (HibernateException he)
        {
            he.printStackTrace();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    /**
     * Gets the current Hibernate session.  If none exists, then a new session is retrieved from the Session Factory.
     *
     * @return The Hibernate session to use.
     *
     * @throws HibernateException Thrown if there is an error retrieving a new Hibernate session from the Session
     *                            Factory.
     */
    public static synchronized Session getCurrentSession() throws HibernateException
    {
        if (currentSession == null)
        {
            currentSession = factory.openSession();
        }

        return currentSession;
    }

    /**
     * Closes the current Hibernate session.
     *
     * @throws HibernateException Thrown if there is an error closing the Hibernate session.
     */
    public static synchronized void closeSession() throws HibernateException
    {
        if (currentSession != null)
        {
            currentSession.flush();
            currentSession.close();
            currentSession = null;
        }
    }

}
