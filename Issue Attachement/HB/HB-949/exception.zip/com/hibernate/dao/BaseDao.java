/*
 * $$Author$$
 * $$Date$$
 * $$Revision$$
 * $$Id$$
 * $$Log$$
 */

package com.hibernate.dao;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.Transaction;

import java.io.Serializable;

/**
 * &copy; Copyright <A href="http://www.test.com">Quicksilva</A> 2004
 * <p/>
 * A class representing the base abstract Data Access Object, which will be extended and implemented by all Data Access
 * Objects that use the Hibernate persistence framework.  Due to the loose coupling between objects and their
 * persistence, it is possible to have all of the generic CRUD and findByPrimaryKey methods in this class.  Any more
 * specific queries are placed in the subclasses.
 * <p/>
 * Created on 13-Apr-2004, at 11:43:01.<BR/> Project: Hibernate Examples.<BR/> Filename: BaseDao.java.
 *
 * @author Simon Knott
 */
public abstract class BaseDao
{

    /**
     * Inserts a new object into the database, using Hibernate.  Depending on the Hibernate mapping configuration this
     * insert will also cascade through the child objects.
     *
     * @param objectToInsert The object to persist.
     *
     * @throws HibernateException Thrown if there is an error inserting the object.
     */
    public void insert(Object objectToInsert) throws HibernateException
    {

        try
        {
            Session hibernateSession = SessionHandler.getCurrentSession();

            Transaction trans = hibernateSession.beginTransaction();

            hibernateSession.save(objectToInsert);

            trans.commit();
        }
        catch (HibernateException e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Updates an existing object in the database, using Hibernate.  Depending on the Hibernate mapping configuration
     * this update will also cascade inserts and updates through the child objects.  If specified, this will also
     * compare against the most recent copy in the database and remove all orphaned children - this is needed if there
     * are some unidirectional mappings.
     *
     * @param objectToUpdate The object to update.
     *
     * @throws HibernateException Thrown if there is an error updating the object.
     */
    public void update(Object objectToUpdate) throws HibernateException
    {

        try
        {
            Session hibernateSession = SessionHandler.getCurrentSession();

            Transaction trans = hibernateSession.beginTransaction();

            if (updateWithCopy())
            {
                hibernateSession.saveOrUpdateCopy(objectToUpdate);
            }
            else
            {
                hibernateSession.saveOrUpdate(objectToUpdate);
            }

            trans.commit();
        }
        catch (HibernateException e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Deletes an object from the database, using Hibernate.  Depending upon the Hibernate mapping configuration, this
     * may also cascade to children objects.
     *
     * @param objectToDelete The object to delete.
     *
     * @throws HibernateException Thrown if there is an error deleting the object.
     */
    public void delete(Object objectToDelete) throws HibernateException
    {

        try
        {
            Session hibernateSession = SessionHandler.getCurrentSession();

            Transaction trans = hibernateSession.beginTransaction();

            hibernateSession.delete(objectToDelete);

            trans.commit();
        }
        catch (HibernateException e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Deletes an object from the database, using Hibernate, based upon the Object's primary key value.  This will
     * actually load the original object first, to ensure that cascaded deletes occur correctly.
     *
     * @param primaryKey The object's primary key.
     *
     * @throws HibernateException Thrown if there is an error either loading the object to be deleted, or in deleting
     *                            the object.
     */
    public void deleteByPrimaryKey(Serializable primaryKey) throws HibernateException
    {
        try
        {
            Session hibernateSession = SessionHandler.getCurrentSession();

            Transaction trans = hibernateSession.beginTransaction();

            hibernateSession.delete(loadByPrimaryKey(primaryKey));

            trans.commit();
        }
        catch (HibernateException e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Loads an object based upon the object's primary key.  This load depends upon the getDaoObjectClass method, to
     * retrieve the correct class type of the object to be loaded.  The primary key passed in must implement
     * serializable.
     *
     * @param primaryKey The object's primary key.
     *
     * @return The persisted object, null if no object was found.
     * 
     * @throws HibernateException Thrown if there is an error loading the object.
     */
    public Object loadByPrimaryKey(Serializable primaryKey) throws HibernateException
    {

        Object persistedObject = null;

        try
        {
            Session hibernateSession = SessionHandler.getCurrentSession();
            persistedObject = hibernateSession.load(getDaoObjectClass(), primaryKey);

        }
        catch (HibernateException e)
        {
            e.printStackTrace();
            throw e;
        }

        return persistedObject;
    }

    /**
     * Retrieves the class of the Object that the subclass DAOs are specialised for.
     *
     * @return The class of the Object used by the DAO.
     */
    abstract Class getDaoObjectClass();

    /**
     * Whether the DAO should call the saveOrUpdate or the saveOrUpdateCopy method.  The latter should be used if the
     * parent class to be persisted will not leave orphaned objects behind (when using bidirectional mappings).  If
     * there is a risk of orphaned child objects, then use update with copy, to delete orphans.
     *
     * @return True if update with copy should be used.
     */
    abstract boolean updateWithCopy();
}
