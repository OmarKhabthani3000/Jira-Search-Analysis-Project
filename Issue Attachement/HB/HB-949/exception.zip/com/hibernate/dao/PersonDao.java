
package com.hibernate.dao;

import com.hibernate.bo.Person;

/**
 * &copy; Copyright <A href="http://www.test.com">Quicksilva</A> 2004
 * <p/>
 * A class representing the Data Access Object for Person objects.
 * <p/>
 * Created on 13-Apr-2004, at 11:43:01.<BR/> Project: Hibernate Examples.<BR/> Filename: PersonDao.java.
 *
 * @author Simon Knott
 */
public class PersonDao extends BaseDao
{

    /**
     * Retrieves the class of the Object that the subclass DAOs are specialised for.
     *
     * @return The class of the Object used by the DAO.
     */
    Class getDaoObjectClass()
    {
        return Person.class;
    }

    /**
     * Whether the DAO should call the saveOrUpdate or the saveOrUpdateCopy method.  The latter should be used if the
     * parent class to be persisted will not leave orphaned objects behind (when using bidirectional mappings).  If
     * there is a risk of orphaned child objects, then use update with copy, to delete orphans.
     *
     * @return True if update with copy should be used.
     */
    boolean updateWithCopy()
    {
        return true;
    }
}
