/*
 * $$Author$$
 * $$Date$$
 * $$Revision$$
 * $$Id$$
 * $$Log$$
 */

package com.hibernate.dao.test;

import junit.framework.TestCase;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.io.Serializable;

import com.hibernate.dao.SessionHandler;
import com.hibernate.dao.BaseDao;
import com.hibernate.dao.CarDao;
import com.hibernate.dao.PersonDao;
import com.hibernate.bo.Person;
import com.hibernate.bo.CarDetails;
import com.hibernate.bo.Car;

/**
 * &copy; Copyright <A href="http://www.test.com">Quicksilva</A> 2004
 * <p/>
 * A class representing the base abstract Test Case, for testing Hibernate based Data Access Objects.
 * <p/>
 * Created on 13-Apr-2004, at 14:51:22.<BR/> Project: Hibernate Examples.<BR/> Filename: HibernateTest.java.
 * 
 * @author Simon Knott
 */
public class HibernateTest
{

    /**
     * The DAO used for persisting Car objects.
     */
    private CarDao carDao;

    /**
     * Holds a list of cars to use in the testing of Person persistence.
     */
    private List cars;

    /**
     * A collection of objects created during the test.  This is used for clearing up the database after the test has
     * run.
     */
    private Collection objectCollection;

    /**
     * The DAO used for persisting Person objects.
     */
    private PersonDao personDao;

    public static void main(String[] args)
    {
        HibernateTest newTest = new HibernateTest();
        newTest.setUp();

        newTest.testUpdate();

        newTest.tearDown();
    }

    /**
     * Sets up any prerequisites of this test case.  All subclasses must call super.setup() to ensure that all
     * initialisation is carried out correctly. This method is called before every test is executed.
     */
    protected void setUp()
    {
        objectCollection = new ArrayList();
        personDao = new PersonDao();
        carDao = new CarDao();

        try
        {
            cars = insertCars();
        }
        catch (HibernateException he)
        {
            he.printStackTrace();
        }
    }

    /**
     * Tears the test down, closing the Hibernate session and deleting any test data needed for the Test Case.  This is
     * run at the end of every test that is run.
     */
    protected void tearDown()
    {
        try
        {
            SessionHandler.closeSession();
        }
        catch (HibernateException he)
        {
            he.printStackTrace();
        }

        // CLEAN UP PERSON OBJECTS
        for (Iterator iter = objectCollection.iterator(); iter.hasNext();)
        {
            try
            {
                personDao.delete(iter.next());
                iter.remove();
            }
            catch (HibernateException he)
            {
                he.printStackTrace();
            }
        }

        // CLEAN UP CAR OBJECTS
        for (Iterator iter = cars.iterator(); iter.hasNext();)
        {
            try
            {
                carDao.delete(iter.next());
            }
            catch (HibernateException he)
            {
                he.printStackTrace();
            }
        }
    }

    /**
     * Deletes an object for this test case.
     * 
     * @param objectToDelete The object to deletePerson.
     * 
     * @throws HibernateException Thrown if there is an error deleting the object.
     */
    void deletePerson(Object objectToDelete) throws HibernateException
    {
        personDao.delete(objectToDelete);
    }

    /**
     * Inserts a new car, needed for testing Person persistence.
     * 
     * @return The company that has been inserted.
     * 
     * @throws HibernateException Thrown if there is an error inserting the company.
     */
    private Car insertNewCar() throws HibernateException
    {
        Car newCar = TestObjectFactory.getCar();
        carDao.insert(newCar);

        SessionHandler.closeSession();

        return newCar;
    }

    /**
     * Inserts new cars, needed for testing Person persistence.
     * 
     * @return The company that has been inserted.
     * 
     * @throws HibernateException Thrown if there is an error inserting the company.
     */
    private List insertCars() throws HibernateException
    {
        List cars = new ArrayList();

        cars.add(insertNewCar());
        cars.add(insertNewCar());

        return cars;
    }

    /**
     * Gets an object that can be persisted by the DAO being tested.  This object will be preinitialised.
     * 
     * @return The object to be persisted.
     */
    protected Object getNewPerson()
    {
        Person newPerson = TestObjectFactory.getPerson();

        CarDetails firstCarDetails = TestObjectFactory.getCarDetails();
        CarDetails secondCarDetails = TestObjectFactory.getCarDetails();

        newPerson.addNewCar((Car) cars.get(0), firstCarDetails);
        newPerson.addNewCar((Car) cars.get(1), secondCarDetails);

        return newPerson;
    }

    /**
     * Inserts a new object into the database, using the DAO being tested.
     * 
     * @return The object that has been inserted in the database.
     * 
     * @throws HibernateException Thrown if there has been an error inserting the object into the database.
     */
    protected Object insertNewPerson() throws HibernateException
    {
        Object objectToInsert = getNewPerson();

        personDao.insert(objectToInsert);
        objectCollection.add(objectToInsert);

        SessionHandler.closeSession();

        return objectToInsert;
    }

    /**
     * Tests the updating of an object.  More than one record is initially inserted into the database, to test that the
     * correct object is updated.
     */
    public void testUpdate()
    {
        try
        {
            Person createdObject = (Person) insertNewPerson();

            Person persistedObject = (Person)personDao.loadByPrimaryKey(new Integer(createdObject.getId()));

            //THIS NEXT LINE CAUSES EXCEPTION TO BE THROWN
            SessionHandler.closeSession();

            persistedObject.setName("NEW_NAME");

            System.out.println("\n\nBEGIN TESTING UPDATE\n");

            personDao.update(persistedObject);
        }
        catch (HibernateException he)
        {
            he.printStackTrace();
            System.out.println("\nFAILED TESTING UPDATE\n\n");
        }
        catch (NullPointerException npe)
        {
            npe.printStackTrace();
            System.out.println("\nFAILED TESTING UPDATE\n\n");
        }

        System.out.println("\nEND TESTING UPDATE\n\n");
    }
}