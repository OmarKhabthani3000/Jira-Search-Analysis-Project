/*
 * $$Author$$
 * $$Date$$
 * $$Revision$$
 * $$Id$$
 * $$Log$$
 */

package com.hibernate.dao.test;

import com.hibernate.bo.Car;
import com.hibernate.bo.CarDetails;
import com.hibernate.bo.Person;

import java.util.GregorianCalendar;

/**
 * Copyright &copy;2004 Quicksilva<br/> <A href="http://www.test.com">Quicksilva</A> 2004
 * <p/>
 * A class representing a factory for creating objects, for use in the JUnit Test Cases.
 * <p/>
 * Created on 08-Apr-2004, at 17:21:33.<BR/> Project: Hibernate Examples.<BR/> Filename: TestObjectFactory.java.
 * 
 * @author Simon Knott
 */
public abstract class TestObjectFactory
{

    /**
     * The unique number used to ensure all objects returned are unique.
     */
    private static int uniqueNumber;

    /**
     * Gets a unique Car object.
     *
     * @return A Car object.
     */
    public static Car getCar()
    {
        int appendNumber = getNextUniqueNumber();

        Car car = new Car();
        car.setModel("GTI Turbo " + appendNumber);
        car.setName("Punto " + appendNumber);

        return car;
    }

    /**
     * Gets a unique CarDetails object.
     *
     * @return A CarDetails object.
     */
    public static CarDetails getCarDetails()
    {
        int appendNumber = getNextUniqueNumber();

        CarDetails carDetails = new CarDetails();
        carDetails.setCarTaxDue(new GregorianCalendar());
        carDetails.setColour("BLUE " + appendNumber);
        carDetails.setNumberPlate("S" + appendNumber + " UHJ");
        carDetails.setSecondHand((appendNumber % 2) == 0);

        return carDetails;
    }


    /**
     * Gets the next unique number in the sequence.
     *
     * @return A unique number.
     */
    protected static synchronized int getNextUniqueNumber()
    {
        return ++uniqueNumber;
    }

    /**
     * Gets a unique Person object.  The returned object will have two unique dogs assigned to it.
     *
     * @return A Person object.
     */
    public static Person getPerson()
    {

        int appendNumber = getNextUniqueNumber();

        Person person = new Person();
        person.setName("PERSON_" + appendNumber);

        return person;
    }

}