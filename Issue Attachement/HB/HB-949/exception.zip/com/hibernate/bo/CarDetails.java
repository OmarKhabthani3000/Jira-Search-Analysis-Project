/*
 * $$Author$$
 * $$Date$$
 * $$Revision$$
 * $$Id$$
 * $$Log$$
 */

package com.hibernate.bo;

import java.util.Calendar;

/**
 * &copy; Copyright <A href="http://www.test.com">Quicksilva</A> 2004
 * <p/>
 * A class representing the details of a car, specific for a particular person.
 * <p/>
 * Created on 21-Apr-2004, at 17:48:05.<BR/> Project: Hibernate Examples.<BR/> Filename: CarDetails.java.
 *
 * @author Simon Knott
 */
public class CarDetails
{

    /**
     * The number plate of the car.
     */
    private String numberPlate;

    /**
     * The colour of the car.
     */
    private String colour;

    /**
     * The date on which the car tax is due.
     */
    private Calendar carTaxDue;

    /**
     * Whether the car is second hand.
     */
    private boolean secondHand;

    /**
     * Gets the number plate of the car.
     *
     * @return The number plate.
     *
     * @hibernate.property column="NUMBER_PLATE" type="string" length="10" not-null="true"
     */
    public String getNumberPlate()
    {
        return numberPlate;
    }

    /**
     * Sets the number plate of the car.
     *
     * @param numberPlate The number plate.
     */
    public void setNumberPlate(String numberPlate)
    {
        this.numberPlate = numberPlate;
    }

    /**
     * Gets the car's colour.
     *
     * @return The colour of the car.
     *
     * @hibernate.property column="COLOUR" type="string" length="20" not-null="true"
     */
    public String getColour()
    {
        return colour;
    }

    /**
     * Sets the car's colour.
     *
     * @param colour The colour of the car.
     */
    public void setColour(String colour)
    {
        this.colour = colour;
    }

    /**
     * Gets the due date of the car tax.
     *
     * @return The car tax's due date.
     *
     * @hibernate.property column="CAR_TAX_DUE_DATE" type="calendar" not-null="true"
     */
    public Calendar getCarTaxDue()
    {
        return carTaxDue;
    }

    /**
     * Sets the due date of the car tax.
     *
     * @param carTaxDue The car tax's due date.
     */
    public void setCarTaxDue(Calendar carTaxDue)
    {
        this.carTaxDue = carTaxDue;
    }

    /**
     * Gets whether the car is second hand.
     *
     * @return Returns true if the car is second hand.
     *
     * @hibernate.property column="SECOND_HAND" type="yes_no"
     */
    public boolean isSecondHand()
    {
        return secondHand;
    }

    /**
     * Sets whether the car is second hand.
     *
     * @param secondHand Whether the car is second hand.
     */
    public void setSecondHand(boolean secondHand)
    {
        this.secondHand = secondHand;
    }

}