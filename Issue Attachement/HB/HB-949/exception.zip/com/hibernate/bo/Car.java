/*
 * $$Author$$
 * $$Date$$
 * $$Revision$$
 * $$Id$$
 * $$Log$$
 */

package com.hibernate.bo;

/**
 * &copy; Copyright <A href="http://www.test.com">Quicksilva</A> 2004
 * <p/>
 * A class reprenting a type of car.
 * <p/>
 * Created on 21-Apr-2004, at 17:33:26.<BR/> Project: Hibernate Examples.<BR/> Filename: Car.java.
 *
 * @author Simon Knott
 * @hibernate.class table="CAR"
 */
public class Car
{

    /**
     * Gets the unique ID of the car.
     *
     * @return The unique ID.
     *
     * @hibernate.id column="CAR_ID" type="int" generator-class="native" unsaved-value="0"
     */
    public int getId()
    {
        return id;
    }

    /**
     * Gets the name of the car.
     *
     * @return The name of the car.
     *
     * @hibernate.property column="CAR_NAME" type="string" length="20" not-null="true"
     */
    public String getName()
    {
        return name;
    }

    /**
     * Gets the model of the car.
     *
     * @return The car model.
     *
     * @hibernate.property column="MODEL" type="string" length="20" not-null="true"
     */
    public String getModel()
    {
        return model;
    }

    /**
     * The unique ID of the car.
     */
    private int id;
    //private Manufacturer ;

    /**
     * The name of the car.
     */
    private String name;

    /**
     * The model of the car.
     */
    private String model;

    /**
     * Sets the unique ID of the car.
     *
     * @param id The unique ID.
     */
    void setId(int id)
    {
        this.id = id;
    }

    /**
     * Sets the name of the car.
     *
     * @param name The name.
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * Sets the model of the car.
     *
     * @param model The car model.
     */
    public void setModel(String model)
    {
        this.model = model;
    }

}