/*
 * $$Author$$
 * $$Date$$
 * $$Revision$$
 * $$Id$$
 * $$Log$$
 */

package com.hibernate.bo;

import java.util.HashMap;
import java.util.Map;

/**
 * &copy; Copyright <A href="http://www.test.com">Quicksilva</A> 2004
 * <p/>
 * A class representing a Person.  This class holds all data that is relevant to a Person.
 * <p/>
 * Created on 28-Apr-2004, at 11:17:58.<BR/> Project: Hibernate Examples.<BR/> Filename: Person.java.
 *
 * @author Simon Knott
 * @hibernate.class table="PERSON"
 */
public class Person
{

    /**
     * The unique ID of the person.
     */
    private int id;

    /**
     * The person's full name.
     */
    private String name;

    /**
     * A map of the cars owned by the person.  The key of the map is the Car owned, and the value are the relevant car
     * details.
     */
    private Map ownedCars;

    /**
     * Gets the person's full name.
     *
     * @return The full name.
     *
     * @hibernate.property column="FULL_NAME" type="string" length="20"
     */
    public String getName()
    {
        return name;
    }

    /**
     * Sets the person's full name.
     *
     * @param name The full name.
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * Gets the person's unique ID.
     *
     * @return The unique ID.
     *
     * @hibernate.id column="PERSON_ID" type="int" unsaved-value="0" generator-class="native"
     */
    public int getId()
    {
        return id;
    }

    /**
     * Sets the person's unique ID.
     *
     * @param id The unique ID.
     */
    public void setId(int id)
    {
        this.id = id;
    }

    /**
     * Gets a map of the owned cars.  The key to the map is a Car object, specifying the type of car.  The value will be
     * a CarDetails object, detailing the more personal data of the car.
     *
     * @return A map of owned cars.
     *
     * @hibernate.map table="OWNED_CARS" cascade="none"
     * @hibernate.index-many-to-many column="CAR_ID" class="com.test.bo.Car"
     * @hibernate.collection-key column="PERSON_ID"
     * @hibernate.collection-composite-element class="com.test.bo.CarDetails"
     */
    public synchronized Map getOwnedCars()
    {
        if (ownedCars == null)
        {
            ownedCars = new HashMap();
        }
        return ownedCars;
    }

    /**
     * Sets the map of owned cars.
     *
     * @param ownedCars The map of owned cars.
     */
    synchronized void setOwnedCars(Map ownedCars)
    {
        this.ownedCars = ownedCars;
    }

    /**
     * Adds a newly owned car.
     *
     * @param newCar     The new car's type.
     * @param newDetails The new car's details.
     */
    public void addNewCar(Car newCar, CarDetails newDetails)
    {
        getOwnedCars().put(newCar, newDetails);
    }

}
