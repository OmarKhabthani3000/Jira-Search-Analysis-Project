package com.wgh;

import java.io.Serializable;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class RentAmenity implements Serializable {

    /** nullable persistent field */
    private int category;

    /** persistent field */
    private String amenity_key;

    /** full constructor */
    public RentAmenity(int category, java.lang.String amenity_key) {
        this.category = category;
        this.amenity_key = amenity_key;
    }

    /** default constructor */
    public RentAmenity() {
    }

    public int getCategory() {
        return this.category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public java.lang.String getAmenity_key() {
        return this.amenity_key;
    }

    public void setAmenity_key(java.lang.String amenity_key) {
        this.amenity_key = amenity_key;
    }


}
