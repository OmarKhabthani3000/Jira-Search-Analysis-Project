package com.wgh;

import net.sf.hibernate.*;
import net.sf.hibernate.cfg.Configuration;

import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.Logger;

import java.util.*;
import java.io.*;

public class Test
{

    private static SessionFactory sessionfactory;
    private static Logger Log = Logger.getLogger("com.wgh");



    public static void testHibernate() throws Exception
    {
        // web page first creates the bean and saves it in the web session
        // (bean might be loaded from db or created new)
        Session session1 = sessionfactory.openSession();
        Rent r = new Rent();
        session1.close();   //



        // later web page retrieves the bean from the web session and save/updates it.
        Session session2 = sessionfactory.openSession();
        SortedMap am = new TreeMap();
        am.put("airconditioning", new RentAmenity(1,"airconditioning"));
        am.put ("pool", new RentAmenity(1,"pool"));
        r.setName("Merriwether Arms");
        r.setAmenities(am);

        session2.saveOrUpdate(r);
        session2.flush();
        session2.connection().commit();
        session2.close();

        Log.info("Successful completion.");


    }


    // Test <hbm-file> <hibernate.properties> <log4j.properties>
    public static void main(String argv[])
    {
        String hpropfile = null;
        String hbmfile = null;
        String lfile = null;
        if (argv.length == 0) {
            hpropfile = "hibernate.properties";
            hbmfile = "Data.hbm.xml";
            lfile = "log4j.properties";
        } else if (argv.length == 1) {
            hpropfile = argv[0];
            hbmfile = "Data.hbm.xml";
            lfile = "log4j.properties";
        } else if (argv.length == 1) {
            hpropfile = argv[0];
            hbmfile = argv[1];
            lfile = "log4j.properties";
        } else {
            hpropfile = argv[0];
            hbmfile = argv[1];
            lfile = argv[2];
        }

        try {
            initHibernate(hpropfile,hbmfile,lfile);
            testHibernate();
        } catch (Exception E) {
            Log.error("Unsuccessful completion.  " + E);
            System.exit(1);
        }

    }

    public static void initHibernate(String hpropfile, String hbmfile, String lfile) throws Exception
    {
        System.out.println("Hibernate data file: " + hbmfile);
        System.out.println("Hibernate property file: " + hpropfile);
        System.out.println("Log property file: " + lfile);

        // init log
        PropertyConfigurator.configure(lfile);

        // init hibernate
        Properties p = new Properties();
        p.load(new FileInputStream(hpropfile));

        Configuration cfg = new Configuration().addFile(hbmfile);
        cfg.setProperties(p);

        sessionfactory = cfg.buildSessionFactory();

    }

}

