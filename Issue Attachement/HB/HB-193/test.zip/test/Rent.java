package com.wgh;

import java.io.Serializable;
import java.util.Collection;
import java.util.SortedMap;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class Rent implements Serializable {

    /** identifier field */
    private Long rent_id;

    /** nullable persistent field */
    private String name;

    /** persistent field */
    private SortedMap amenities;

    /** default constructor */
    public Rent() {
    }


    public java.lang.Long getRent_id() {
        return this.rent_id;
    }

    public void setRent_id(java.lang.Long rent_id) {
        this.rent_id = rent_id;
    }

    public java.lang.String getName() {
        return this.name;
    }

    public void setName(java.lang.String name) {
        this.name = name;
    }

    public java.util.SortedMap getAmenities() {
        return this.amenities;
    }

    public void setAmenities(java.util.SortedMap amenities) {
        this.amenities = amenities;
    }


}
