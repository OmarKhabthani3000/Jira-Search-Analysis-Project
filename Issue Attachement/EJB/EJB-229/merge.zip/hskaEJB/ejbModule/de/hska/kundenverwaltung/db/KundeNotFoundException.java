package de.hska.kundenverwaltung.db;

import java.io.Serializable;

public class KundeNotFoundException extends Exception {
	private static final long serialVersionUID = -6882528175294418164L;
	public static final Serializable KEINE_ID = -1L;
	public static final String KEIN_NACHNAME = null;
	public static final int KEINE_PLZ = -1;
	
	private Serializable id = KEINE_ID;
	private String nachname = KEIN_NACHNAME;
	private int plz = KEINE_PLZ;
	
	public KundeNotFoundException(Serializable id) {
		super("Kein Kunde gefunden mit id=" + id);
		this.id = id;
	}
	public KundeNotFoundException(String nachname) {
		super("Kein Kunde gefunden mit Nachname=" + nachname);
		this.nachname = nachname;
	}
	public KundeNotFoundException(int plz) {
		super("Kein Kunde gefunden mit PLZ=" + plz);
		this.plz = plz;
	}

	public Serializable getId() {
		return id;
	}

	public String getNachname() {
		return nachname;
	}

	public int getPlz() {
		return plz;
	}
}
