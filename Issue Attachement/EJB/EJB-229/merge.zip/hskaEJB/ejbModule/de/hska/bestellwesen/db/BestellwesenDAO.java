package de.hska.bestellwesen.db;

import static de.hska.bestellwesen.db.Lieferung.LIEFERUNG_BY_NR_FETCH_BESTELLUNGEN;
import static de.hska.util.EjbConstants.BEGIN;
import static de.hska.util.EjbConstants.END;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class BestellwesenDAO {
	private static BestellwesenDAO dao = new BestellwesenDAO();
	private static final Log LOG = LogFactory.getLog(BestellwesenDAO.class);
	private static final boolean DEBUG = LOG.isDebugEnabled();

	public static BestellwesenDAO getInstance() {
		return dao;
	}
	
	@SuppressWarnings("unchecked")
	public List<Lieferung> findLieferungenByNr(EntityManager em, String lieferNr) throws LieferungNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findLieferungByNr: " + lieferNr);

		final Query query = em.createNamedQuery(LIEFERUNG_BY_NR_FETCH_BESTELLUNGEN);
		query.setParameter("lieferNr", lieferNr);

		List<Lieferung> lieferungen = query.getResultList();
		if (lieferungen == null || lieferungen.isEmpty()) {
			if (DEBUG) LOG.debug(END + "findLieferungByNr: keine Datensaetze");
			throw new LieferungNotFoundException(lieferNr);
		}

		if (DEBUG) LOG.debug(END + "findLieferungByNr: " + lieferungen);

		return lieferungen;
	}


	public void neueBestellung(EntityManager em, Bestellung bestellung) {
		if (DEBUG) LOG.debug(BEGIN + "neueBestellung: " + bestellung);

		em.persist(bestellung);   // der n:1 referenzierte Kunde wird mitabgespeichert

		if (DEBUG) LOG.debug(END + "neueBestellung: " + bestellung);
	}
}
