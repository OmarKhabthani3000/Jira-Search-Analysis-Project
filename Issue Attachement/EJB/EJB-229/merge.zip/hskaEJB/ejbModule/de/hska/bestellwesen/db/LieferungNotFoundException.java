package de.hska.bestellwesen.db;

public class LieferungNotFoundException extends Exception {
	private static final long serialVersionUID = -8892585794078428306L;
	private String lieferNr;
	
	public LieferungNotFoundException(String lieferNr) {
		super("Keine Lieferung gefunden");
		this.lieferNr = lieferNr;
	}

	public String getId() {
		return lieferNr;
	}
}
