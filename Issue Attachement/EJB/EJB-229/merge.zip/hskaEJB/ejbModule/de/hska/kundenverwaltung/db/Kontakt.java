package de.hska.kundenverwaltung.db;

import static javax.persistence.GenerationType.AUTO;
import static javax.persistence.TemporalType.DATE;
import static de.hska.util.EjbConstants.KEINE_ID;
import static de.hska.util.EjbConstants.ERSTE_VERSION;

import java.io.Serializable;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.Version;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@Entity
@Table(name="kontakt")
public class Kontakt implements Serializable {
	private static final long serialVersionUID = -7413263914964650939L;
	protected static final Log LOG = LogFactory.getLog(Kontakt.class);
	protected static final boolean DEBUG = LOG.isDebugEnabled();
	protected static final boolean TRACE = LOG.isTraceEnabled();

	@Id
	@GeneratedValue(strategy=AUTO, generator="kontakt_sequence_name")
	@SequenceGenerator(name="kontakt_sequence_name", sequenceName="kontakt_ko_id_seq", allocationSize=1)
	@Column(name="ko_id", nullable=false)
	private Long id = KEINE_ID;

	@Version
	private int version = ERSTE_VERSION;
	
	@Column(nullable=false)
	@Temporal(DATE)
	private Date datum = null;
	
	@Column
	private String inhalt = null;
	
	@PostPersist
	protected void logDbId() {
		if (DEBUG) LOG.debug("Neuer Kontakt mit ID=" + id + " : " + this);
	}

	@PostUpdate
	protected void logNeueVersion() {
		if (TRACE) LOG.trace("Kontakt ID=" + id + " geaendert: neue Version=" + version);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public Date getDatum() {
		return datum;
	}

	public void setDatum(Date datum) {
		this.datum = datum;
	}
	
	public String getDatumAsString(int style, Locale locale) {
		final DateFormat f = DateFormat.getDateInstance(style, locale);
		return f.format(datum);
	}

	public String getInhalt() {
		return inhalt;
	}

	public void setInhalt(String inhalt) {
		this.inhalt = inhalt;
	}

	@Override
	public String toString() {
		return "{id=" + id + ", version=" + version + ", datum=" + getDatumAsString(DateFormat.MEDIUM, Locale.GERMANY) + ", inhalt=" + inhalt + '}';
	}
	
	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other instanceof Kontakt == false) return false;

		final Kontakt k = (Kontakt) other;
		return id.equals(k.id) && version == k.version && datum.equals(k.datum);
	}
	
	@Override
	public int hashCode() {
		int result = 37 + version;        // Version als Offset
		result ^= id.intValue();          // Bit-weise XOR
		result ^= datum.hashCode();
		return result;
	}
}
