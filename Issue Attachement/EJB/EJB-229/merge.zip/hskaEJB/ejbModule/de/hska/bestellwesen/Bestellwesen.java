package de.hska.bestellwesen;

import static de.hska.util.EjbConstants.BEAN_NAME_PRAEFIX;
import static de.hska.util.EjbConstants.BEAN_NAME_SUFFIX;

import java.util.Collection;
import de.hska.bestellwesen.db.Bestellung;
import de.hska.bestellwesen.db.Lieferung;
import de.hska.bestellwesen.db.LieferungNotFoundException;
import de.hska.kundenverwaltung.db.KundeNotFoundException;
import de.hska.util.EjbNotFoundException;


public interface Bestellwesen {
	static final String JNDI_NAME = BEAN_NAME_PRAEFIX + Bestellwesen.class.getSimpleName() + BEAN_NAME_SUFFIX;
	
	/**
	 * Zu gegebener Bestell-Nr werden alle Lieferungen gesucht. Zwischen Bestellungen
	 * und Lieferungen gibt es eine N:M-Beziehung
	 * @param nr der Bestellung
	 * @return Die gefundenen Lieferungen
	 * @throws LieferungNotFoundException 
	 */
	Collection<Lieferung> findLieferungen(String nr) throws LieferungNotFoundException;
	
	/**
	 * Zu einem Kunden mit gegebener Kunden-ID wird eine neue Bestellung erzeugt.
	 * @param kundeId die ID des vorhandenen Kunden
	 * @param text Beschreibung der Bestellung
	 * @return Die neue, persistente Bestellung
	 * @throws KundeNotFoundException 
	 * @throws EjbNotFoundException
	 */
	Bestellung neueBestellung(Long kundeId, String text) throws KundeNotFoundException, EjbNotFoundException;
}