package de.hska.kundenverwaltung.db;

import static de.hska.kundenverwaltung.db.Kunde.KUNDE_ALL;
import static de.hska.kundenverwaltung.db.Kunde.KUNDE_BY_NACHNAME;
import static de.hska.kundenverwaltung.db.Kunde.KUNDE_BY_NACHNAME_FETCH_BESTELLUNGEN;
import static de.hska.kundenverwaltung.db.Kunde.KUNDE_BY_ID_FETCH_BESTELLUNGEN;
import static de.hska.kundenverwaltung.db.Kunde.KUNDE_BY_PLZ;
import static de.hska.kundenverwaltung.db.Kunde.KONTAKTE_BY_KUNDE_ID;
import static de.hska.kundenverwaltung.db.Wartungsvertrag.WARTUNGSVERTRAG_BY_KUNDE_ID;
import static de.hska.util.ConcurrencyException.UpdatedOrDeleted.updated;
import static de.hska.util.ConcurrencyException.UpdatedOrDeleted.deleted;
import static de.hska.util.EjbConstants.BEGIN;
import static de.hska.util.EjbConstants.END;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.hska.util.ConcurrencyException;


/**
 *  DB-Zugriffsschicht f&uuml;r das Package "de.hska.kundenverwaltung"
 */
final public class KundenverwaltungDAO {
	private static KundenverwaltungDAO dao = new KundenverwaltungDAO();
	private static final Log LOG = LogFactory.getLog(KundenverwaltungDAO.class);
	private static final boolean DEBUG = LOG.isDebugEnabled();
	private static final boolean TRACE = LOG.isTraceEnabled();

	public static KundenverwaltungDAO getInstance() {
		return dao;
	}

	/**
	 * @return Alle persistenten Kunden
	 */
	@SuppressWarnings("unchecked")
	public List<Kunde> findAllKunden(EntityManager em) {
		if (DEBUG) LOG.debug(BEGIN + "findAllKunden");

		Query query = em.createNamedQuery(KUNDE_ALL);
		List<Kunde> kunden = query.getResultList();
		if (kunden == null)
			kunden = new ArrayList<Kunde>();

		if (DEBUG) LOG.debug(END + "findAllKunden");
		return kunden;
	}

	/**
	 */
	@SuppressWarnings("unchecked")
	public List<Kunde> findKundenByNachname(EntityManager em, String nachname) throws KundeNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findKundenByNachname: " + nachname);

		final Query query = em.createNamedQuery(KUNDE_BY_NACHNAME);
		query.setParameter("nachname", nachname);
		final List<Kunde> kunden = query.getResultList();   // Query operiert auf Cache

		if (kunden == null || kunden.isEmpty()) {
			if (DEBUG) LOG.debug(END + "findKundenByNachname: keine Datensaetze");
			throw new KundeNotFoundException(nachname);
		}

		if (DEBUG) LOG.debug(END + "findKundenByNachname: " + kunden.size() + " Anzahl Datensaetze");

		return kunden;
	}


	/**
	 */
	@SuppressWarnings("unchecked")
	public List<Kunde> findKundenMitBestellungenByNachname(EntityManager em, String nachname) throws KundeNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findKundenMitBestellungenByNachname: " + nachname);

		// Bestellungen mitladen
		final Query query = em.createNamedQuery(KUNDE_BY_NACHNAME_FETCH_BESTELLUNGEN);
		query.setParameter("nachname", nachname);
		final List<Kunde> kunden = query.getResultList();

		if (kunden == null || kunden.isEmpty()) {
			if (DEBUG) LOG.debug(END + "findKundenByNachname: keine Datensaetze");
			throw new KundeNotFoundException(nachname);
		}

		if (DEBUG) LOG.debug(END + "findKundenMitBestellungenByNachname: " + kunden.size() + " Anzahl Datensaetze");

		return kunden;
	}

	
	/**
	 */
	public Kunde findKundeById(EntityManager em, Long id) throws KundeNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findKundeById: " + id);

		final Kunde kunde = em.find(Kunde.class, id);
		if (kunde == null) {
			if (DEBUG) LOG.debug(END + "findKundeById: kein Datensatz");
			throw new KundeNotFoundException(id);
		}

		if (DEBUG) LOG.debug(END + "findKundeById: " + kunde);
		return kunde;
	}

	/**
	 */
	public Kunde findKundeMitBestellungenById(EntityManager em, Long id) throws KundeNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findKundeMitBestellungenById: " + id);

		final Query query = em.createNamedQuery(KUNDE_BY_ID_FETCH_BESTELLUNGEN);
		query.setParameter("id", id);

		Kunde kunde = null;
		try {
			kunde = (Kunde) query.getSingleResult();
		}
		catch (NoResultException e) {
			if (DEBUG) LOG.debug(END + "findKundeMitBestellungenById: kein Datensatz");
			throw new KundeNotFoundException(id);
		}

		if (DEBUG) LOG.debug(END + "findKundeMitBestellungenById: " + kunde);
		return kunde;
	}


	/**
	 */
	@SuppressWarnings("unchecked")
	public List<Wartungsvertrag> findWartungsvertraegeByKundeId(EntityManager em, Long kundeId) throws WartungsvertragNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findWartungsvertraegeByKundeId: " + kundeId);
		
		final Query query = em.createNamedQuery(WARTUNGSVERTRAG_BY_KUNDE_ID);
		query.setParameter("kundeId", kundeId);

		List<Wartungsvertrag> wartungsvertraege = query.getResultList();

		if (wartungsvertraege == null || wartungsvertraege.isEmpty()) {
			if (DEBUG) LOG.debug(END + "findWartungsvertraegeByKundeId: keine Datensaetze");
			throw new WartungsvertragNotFoundException(kundeId);
		}
		
		if (DEBUG) LOG.debug(END + "findWartungsvertraegeByKundeId: " + wartungsvertraege.size() + " Anzahl Datensaetze");

		return wartungsvertraege;
	}
	
	
	/**
	 */
	public Collection<Kunde> updateKunden(EntityManager em, Collection<Kunde> kunden) {
		if (DEBUG) LOG.debug(BEGIN + "updateKunden");

		if (kunden == null || kunden.isEmpty()) {
			if (DEBUG) LOG.debug(END + "updateKunden: leere Collection");
			return new ArrayList<Kunde>(0);
		}

		Collection<Kunde> aktualisierteKunden = new ArrayList<Kunde>(kunden.size());
		for (Kunde k : kunden) {
			if (TRACE) LOG.trace("Kunde = " + k);
			
			// Wurde der Kunde konkurrierend geloescht?
			// merge() legt bei Bedarf einen NEUEN Datensatz an
			final Kunde tmp = em.find(Kunde.class, k.getId());
			if (tmp == null) {
				throw new ConcurrencyException(k.getId(), k.getClass().getSimpleName(), deleted);
			}

			// TODO Bug von JBoss, falls das zu aendernde Entity "detached" ist und eine 1:1-Bez hat
			// Workaround: das referenzierte Objekt vor dem Aufruf von merge() explizit laden
			//final Betreuer tmpBetreuer = em.find(Betreuer.class, k.getBetreuer().getId());
			//k.setBetreuer(tmpBetreuer);
			
			try {
				k = em.merge(k);
			}
			catch (IllegalArgumentException e) {
				throw new ConcurrencyException(k.getId(), k.getClass().getSimpleName(), updated);
			}
			aktualisierteKunden.add(k);
		}

		if (DEBUG) LOG.debug(END + "updateKunden");
		return aktualisierteKunden;
	}


	/**
	 */
	public void deleteKunden(EntityManager em, Collection<Kunde> kunden) {
		if (DEBUG) LOG.debug(BEGIN + "deleteKunden");

		if (kunden == null || kunden.isEmpty()) {
			if (DEBUG) LOG.debug(END + "deleteKunden: leere Collection");
			return;
		}

		for (Kunde k: kunden) {			
			if (k == null)
				continue;

			if (TRACE) LOG.trace("Kunde wird gel�scht:" + k);
			final Kunde managedKunde = em.find(Kunde.class, k.getId());
			
			// Wurde der Kunde konkurrierend geloescht?
			if (managedKunde == null) {
				throw new ConcurrencyException(k.getId(), k.getClass().getSimpleName(), deleted);
			}

			// Wurde der Kunde konkurrierend aktualisiert?
			if (managedKunde.getVersion() > k.getVersion()) {
				throw new ConcurrencyException(k.getId(), k.getClass().getSimpleName(), updated);
			}
			
			em.remove(managedKunde);
		}
		
		if (DEBUG) LOG.debug(END + "deleteKunden");
	}


	/**
	 */
	public Collection<Kunde> insertKunden(EntityManager em, Collection<Kunde> kunden) {
		if (DEBUG) LOG.debug(BEGIN + "insertKunden");
		if (kunden == null || kunden.isEmpty()) {
			if (DEBUG) LOG.debug(END + "insertKunden: leere Collection");
			return new ArrayList<Kunde>(0);
		}
		if (TRACE) LOG.trace("Anzahl Datensaetze: " + kunden.size());

		for (Kunde k: kunden) {
			if (TRACE) LOG.trace("Neuer persistenter Datensatz: " + k);
			em.persist(k);
		}

		if (DEBUG) LOG.debug(END + "insertKunden");
		return kunden;
	}

	public Betreuer findBetreuerById(EntityManager em, Long id) throws BetreuerNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findBetreuerById: " + id);

		final Betreuer betreuer = em.find(Betreuer.class, id);
		if (betreuer == null) {
			if (DEBUG) LOG.debug(END + "findBetreuerById: kein Datensatz gefunden");
			throw new BetreuerNotFoundException(id);
		}

		if (DEBUG) LOG.debug(END + "findBetreuerById: " + betreuer);
		return betreuer;
	}

	@SuppressWarnings("unchecked")
	public List<Kunde> findKundenByPLZ(EntityManager em, int plz) throws KundeNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findKundenByPLZ: " + plz);

		final Query query = em.createNamedQuery(KUNDE_BY_PLZ);
		query.setParameter("plz", plz);
		List<Kunde> kunden = query.getResultList();

		if (kunden == null || kunden.isEmpty()) {
			if (DEBUG) LOG.debug(END + "findKundenByPLZ: keine Datensaetze");
			throw new KundeNotFoundException(plz);
		}

		if (DEBUG) LOG.debug(END + "findKundenByPLZ: " + kunden.size() + " Anzahl Datensaetze");

		return kunden;
	}

	@SuppressWarnings("unchecked")
	public List<Kontakt> findKundeKontakteById(EntityManager em, Long kundeId) throws KontaktNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findKundeKontakteById: " + kundeId);

		final Query query = em.createNamedQuery(KONTAKTE_BY_KUNDE_ID);
		query.setParameter("kundeId", kundeId);
		List<Kontakt> kontakte = query.getResultList();

		if (kontakte == null || kontakte.isEmpty()) {
			if (DEBUG) LOG.debug(END + "findKundeKontakteById: keine Datensaetze gefunden");
			throw new KontaktNotFoundException(kundeId);
		}

		if (DEBUG) LOG.debug(END + "findKundeKontakteById: " + kontakte.size() + " Anzahl Datensaetze");

		return kontakte;
	}
}