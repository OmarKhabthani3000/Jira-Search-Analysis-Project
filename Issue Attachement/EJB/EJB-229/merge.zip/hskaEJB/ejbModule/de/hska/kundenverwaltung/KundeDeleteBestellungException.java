package de.hska.kundenverwaltung;

import java.io.Serializable;

import javax.ejb.ApplicationException;

import de.hska.kundenverwaltung.db.Kunde;

@ApplicationException(rollback=true)
public class KundeDeleteBestellungException extends Exception {
	private static final long serialVersionUID = 2237194289969083093L;
	private Serializable kundeId;
	private int anzahlBestellungen;

	public KundeDeleteBestellungException(Kunde kunde) {
		super("Kunde mit ID=" + kunde.getId() + " kann nicht geloescht werden: " +
			  kunde.getBestellungen().size() + " Bestellungen");
		this.kundeId = kunde.getId();
		this.anzahlBestellungen = kunde.getBestellungen().size();
	}

	public Serializable getKundeId() {
		return kundeId;
	}
	public int getAnzahlBestellungen() {
		return anzahlBestellungen;
	}
}
