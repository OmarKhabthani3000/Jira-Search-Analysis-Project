package de.hska.kundenverwaltung.db;

import java.io.Serializable;

public class BetreuerNotFoundException extends Exception {
	private static final long serialVersionUID = -7157018744023740232L;
	private Serializable id;
	
	public BetreuerNotFoundException(Serializable id) {
		super("Kein Betreuer gefunden");
		this.id = id;
	}

	public Serializable getId() {
		return id;
	}
}
