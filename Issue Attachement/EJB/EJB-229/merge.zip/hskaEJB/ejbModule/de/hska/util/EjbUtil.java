package de.hska.util;

import static de.hska.util.EjbConstants.BEGIN;
import static de.hska.util.EjbConstants.END;

import java.io.IOException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.hska.bestellwesen.Bestellwesen;
import de.hska.kundenverwaltung.Kundenverwaltung;


public class EjbUtil {
	private static final Log LOG = LogFactory.getLog(EjbUtil.class);
	private static final boolean DEBUG = LOG.isDebugEnabled();

	/**
	 */
	static class HskaCallbackHandler implements CallbackHandler {
		private String username;
		private char[] password;

		/**
		 */
		public HskaCallbackHandler(String username, char[] password) {
			super();
			this.username = username;
			this.password = password;
		}

		/**
		 */
		public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
			for (int i = 0; i < callbacks.length; i++) {
				if (callbacks[i] instanceof NameCallback) {
					final NameCallback nc = (NameCallback) callbacks[i];
					nc.setName(username);
				}
				else if (callbacks[i] instanceof PasswordCallback) {
					final PasswordCallback pc = (PasswordCallback) callbacks[i];
					pc.setPassword(password);
				}
				else {
					LOG.warn("Unzulaessiger Callback: " + callbacks[i]);
					throw new UnsupportedCallbackException(callbacks[i], "Unzulaessiger Callback");
				}
			}
		}
	}
	
	/**
	 */
	public static LoginContext login(String loginCtxName, String username, String password) {
		if (DEBUG) LOG.debug(BEGIN + "login: " + loginCtxName + ", " + username + ", " + password);
		LoginContext loginCtx = null;
		final HskaCallbackHandler handler = new HskaCallbackHandler(username, password.toCharArray());
		try {
			loginCtx = new LoginContext(loginCtxName, handler);
			loginCtx.login();
		}
		catch (LoginException e) {
			LOG.warn(e.getMessage());
		}
		if (DEBUG) LOG.debug(END + "login");
		return loginCtx;
	}
	
	/**
	 */
	public static void logout(LoginContext loginCtx) {
		if (DEBUG) LOG.debug(BEGIN + "logout");
		try {
			if (loginCtx != null)
				loginCtx.logout();
		}
		catch (LoginException e) {
			LOG.warn(e.getMessage());
		}
		if (DEBUG) LOG.debug(END + "logout");		
	}

	/**
	 */
	public static Kundenverwaltung getKundenverwaltung() throws EjbNotFoundException {
		Kundenverwaltung kv = null;
		try {
			final Context ctx = new InitialContext();
			kv = (Kundenverwaltung) ctx.lookup(Kundenverwaltung.JNDI_NAME);
			ctx.close();
		}
		catch (NamingException e) {
			LOG.error("Kein SessionBean mit Namen " + Kundenverwaltung.JNDI_NAME);
			throw new EjbNotFoundException(Kundenverwaltung.JNDI_NAME);
		}
		return kv;
	}

	/**
	 */
	public static Bestellwesen getBestellwesen() throws EjbNotFoundException {
		Bestellwesen bw = null;
		try {
			final Context ctx = new InitialContext();
			bw = (Bestellwesen) ctx.lookup(Bestellwesen.JNDI_NAME);
			ctx.close();
		}
		catch (NamingException e) {
			LOG.error("Kein SessionBean mit Namen " + Bestellwesen.JNDI_NAME);
			throw new EjbNotFoundException(Bestellwesen.JNDI_NAME);
		}
		return bw;
	}
}
