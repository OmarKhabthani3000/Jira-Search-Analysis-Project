package de.hska.kundenverwaltung.db;

import static javax.persistence.GenerationType.AUTO;
import static javax.persistence.TemporalType.DATE;
import static javax.persistence.TemporalType.TIMESTAMP;
import static java.util.GregorianCalendar.YEAR;
import static de.hska.util.EjbConstants.KEINE_ID;
import static de.hska.util.EjbConstants.ERSTE_VERSION;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import javax.persistence.Entity;

import javax.persistence.Table;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.Embedded;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.QueryHint;
import javax.persistence.SecondaryTable;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.Transient;
import javax.persistence.Version;
import javax.persistence.Column;
import javax.persistence.OneToMany;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.hska.bestellwesen.db.Bestellung;

// Alternativen bei @Inheritance
//   strategy=SINGLE_TABLE (=default), TABLE_PER_CLASS, JOINED
// Alternativen bei @DiscriminatorColumn
//   discriminatorType=STRING (=default), CHAR, INTEGER
@Entity
@Table(name="kunde")
@SecondaryTable(name="kunde_details", pkJoinColumns=@PrimaryKeyJoinColumn(name="kunde_fk"))
@Inheritance
@DiscriminatorColumn(name="art", length=1)
@NamedQueries({
	@NamedQuery(name = Kunde.KUNDE_ALL,
	        query = "SELECT k FROM Kunde k",
	        hints={@QueryHint(name="org.hibernate.cacheable", value="true"),
		           @QueryHint(name="org.hibernate.cacheRegion", value="org.hibernate.cache.StandardQueryCache")}),
	@NamedQuery(name = Kunde.KUNDE_BY_NACHNAME,
		        query = "SELECT k FROM Kunde k WHERE k.nachname = :nachname",
		        hints={@QueryHint(name="org.hibernate.cacheable", value="true"),
			           @QueryHint(name="org.hibernate.cacheRegion", value="org.hibernate.cache.StandardQueryCache")}),
	@NamedQuery(name = Kunde.KUNDE_BY_NACHNAME_FETCH_BESTELLUNGEN,
			    query = "SELECT DISTINCT k FROM Kunde k LEFT JOIN FETCH k.bestellungen b WHERE k.nachname = :nachname"),
	@NamedQuery(name = Kunde.KUNDE_BY_ID_FETCH_BESTELLUNGEN,
			    query = "SELECT DISTINCT k FROM Kunde k LEFT JOIN FETCH k.bestellungen b WHERE k.id = :id"),
	@NamedQuery(name = Kunde.KUNDE_BY_PLZ,
			    query = "SELECT k FROM Kunde k WHERE k.adresse.plz = :plz"),
	@NamedQuery(name = Kunde.KONTAKTE_BY_KUNDE_ID,
					    query = "SELECT kontakt FROM Kunde kunde RIGHT JOIN kunde.kontakte kontakt WHERE kunde.id = :kundeId")
})
public abstract class Kunde implements java.io.Serializable {
	protected static final Log LOG = LogFactory.getLog(Kunde.class);
	protected static final boolean DEBUG = LOG.isDebugEnabled();
	protected static final boolean TRACE = LOG.isTraceEnabled();
	
	public static final String PRIVATKUNDE = "P";
	public static final String FIRMENKUNDE = "F";

	public static final String KUNDE_ALL = "kunde.all";
	public static final String KUNDE_BY_NACHNAME = "kunde.byNachname";
	public static final String KUNDE_BY_NACHNAME_FETCH_BESTELLUNGEN = "kunde.byNachname.fetchBestellungen";
	public static final String KUNDE_BY_ID_FETCH_BESTELLUNGEN = "kunde.byId.fetchBestellungen";
	public static final String KUNDE_BY_PLZ = "kunde.byPlz";
	public static final String KONTAKTE_BY_KUNDE_ID = "kunde.kontakte.byKundeId";

	// Alternativen: TABLE, SEQUENCE, IDENTITY, AUTO, NONE (=default)
	@Id
	@GeneratedValue(strategy=AUTO, generator="kunde_sequence_name")
	@SequenceGenerator(name="kunde_sequence_name", sequenceName="kunde_k_id_seq", allocationSize=1)
	@Column(name="k_id", nullable=false)
	protected Long id = KEINE_ID;

	@Version
	protected int version = ERSTE_VERSION;

	@Column(length=32, nullable=false)
	protected String nachname = "";

	@Column(length=32)
	protected String vorname = "";

	@Column(length=8, nullable=false, unique=true)
	protected String kundennr = "NnVn-001";

	@Column
	@Temporal(DATE)
	protected Date seit = null;
	
	@Transient
	protected int anzJahre;

	@OneToOne(mappedBy="kunde")
	protected Betreuer betreuer;

	// Default: fetch=LAZY, keine Kaskadierungen
	// Alternativen: cascade={PERSIST}, cascade={MERGE}, cascade={REMOVE}, cascade={REFRESH}, cascade={c1, c2}, cascade={ALL}
	@OneToMany(mappedBy="kunde")
	@OrderBy("id ASC")
	protected List<Bestellung> bestellungen = new ArrayList<Bestellung>();

	@Embedded
	protected Adresse adresse;
	
	@Column(table="kunde_details", length=128*1024)
	protected String details;
	
	@OneToMany
	@JoinTable(name="kunde_kontakt",
			   joinColumns={@JoinColumn(name="kunde_fk")},
			                inverseJoinColumns={@JoinColumn(name="kontakt_fk")})
	@OrderBy("datum DESC")
	protected List<Kontakt> kontakte = new ArrayList<Kontakt>();

	@OneToMany(mappedBy="kunde")
	protected List<Wartungsvertrag> wartungsvertraege = new ArrayList<Wartungsvertrag>();
	
	@Column
	protected String password = "";
	
	@Column(nullable=false)
	@Temporal(TIMESTAMP)
	protected Date erzeugt = null;

	@Column(nullable=false)
	@Temporal(TIMESTAMP)
	protected Date aktualisiert = null;
	
	public Kunde() {
		super();
	}

	@PrePersist
	protected void prePersist() {
		erzeugt = new Date();
		preUpdate();
	}
	
	@PostPersist
	protected void logDbId() {
		if (DEBUG) LOG.debug("Neuer Kunde mit ID=" + id + " : " + this);
	}

	@PreUpdate
	protected void preUpdate() {
		aktualisiert = new Date();
	}
	
	@PostUpdate
	protected void logNeueVersion() {
		if (TRACE) LOG.trace("Kunde ID=" + id + " geaendert: neue Version=" + version);
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}

	public String getNachname() {
		return nachname;
	}
	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public String getVorname() {
		return vorname;
	}
	public void setVorname(String vorname) {
		this.vorname = vorname;
	}
	
	public String getKundennr() {
		return kundennr;
	}
	public void setKundennr(String kundennr) {
		this.kundennr = kundennr;
	}

	public Date getSeit() {
		return seit;
	}
	public void setSeit(Date seit) {
		this.seit = seit;
	}

	public int getAnzJahre() {
		final GregorianCalendar now = new GregorianCalendar();
		final GregorianCalendar seitCal = new GregorianCalendar();
		Date temp = seit;
		if (temp == null)
			temp = new Date();
		seitCal.setTime(temp);
	
		anzJahre = now.get(YEAR) - seitCal.get(YEAR);
		
		return anzJahre;
	}

	// Parameter, z.B. DateFormat.MEDIUM, Locale.GERMANY
	// MEDIUM fuer Format dd.MM.yyyy
	public String getSeitAsString(int style, Locale locale) {
		Date temp = seit;
		if (temp == null)
			temp = new Date();
		final DateFormat f = DateFormat.getDateInstance(style, locale);
		return f.format(temp);
	}
	
	// Parameter, z.B. DateFormat.MEDIUM, Locale.GERMANY
	// MEDIUM fuer Format dd.MM.yyyy
	public void setSeit(String seit, int style, Locale locale) {
		final DateFormat f = DateFormat.getDateInstance(style, locale);
		try {
			this.seit = f.parse(seit);
		}
		catch (ParseException e) {
			LOG.warn("Kein gueltiges Datumsformat fuer: " + seit);
		}
	}

	public Betreuer getBetreuer() {
		return betreuer;
	}

	public void setBetreuer(Betreuer betreuer) {
		this.betreuer = betreuer;
	}

	public List<Bestellung> getBestellungen() {
		return bestellungen;
	}
	public void setBestellungen(List<Bestellung> bestellungen) {
		this.bestellungen = bestellungen;
	}

	public Adresse getAdresse() {
		return adresse;
	}
	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}
	
	abstract public String getArt();

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public List<Kontakt> getKontakte() {
		return kontakte;
	}
	public void setKontakte(List<Kontakt> kontakte) {
		this.kontakte = kontakte;
	}

	public List<Wartungsvertrag> getWartungsvertraege() {
		return wartungsvertraege;
	}

	public void setWartungsvertraege(List<Wartungsvertrag> wartungsvertraege) {
		this.wartungsvertraege = wartungsvertraege;
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String passwort) {
		this.password = passwort;
	}

	public Date getAktualisiert() {
		return aktualisiert;
	}
	public void setAktualisiert(Date aktualisiert) {
		this.aktualisiert = aktualisiert;
	}

	public Date getErzeugt() {
		return erzeugt;
	}
	public void setErzeugt(Date erzeugt) {
		this.erzeugt = erzeugt;
	}
	
	@Override
	public String toString() {
		return "id=" + id + ", version=" + version +
			   ", nachname=" + nachname + ", vorname=" + vorname +
			   ", nr=" + kundennr +
			   ", seit=" + getSeitAsString(DateFormat.MEDIUM, Locale.GERMANY) +
			   ", anzJahre=" + getAnzJahre() +
			   ", password=" + password +
			   ", erzeugt=" + erzeugt +
			   ", aktualisiert=" + aktualisiert;
	}

	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other instanceof Kunde == false) return false;

		final Kunde k = (Kunde) other;
		boolean result = id.equals(k.id) && nachname.equals(k.nachname);
		if (result == false)
			return false;
		if (vorname != null)    // Vorname kann evtl. fehlen
			return vorname.equals(k.vorname);
		return k.vorname == null;
	}
	
	@Override
	public int hashCode() {
		int result = 37 + version;        // Version als Offset
		result ^= id.intValue();          // Bit-weise XOR
		result ^= nachname.hashCode();
		if (vorname != null)
			result ^= vorname.hashCode();
		return result;
	}
}