package de.hska.kundenverwaltung;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class KundeCreateAdresseException extends Exception {
	private static final long serialVersionUID = 4255133082483647701L;
	private String nachname;
	private String vorname;

	public KundeCreateAdresseException(String nachname, String vorname) {
		super("Kunde \"" + nachname + ", " + vorname + "\" hat keine Adresse");
		this.nachname = nachname;
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}
	public String getVorname() {
		return vorname;
	}
}
