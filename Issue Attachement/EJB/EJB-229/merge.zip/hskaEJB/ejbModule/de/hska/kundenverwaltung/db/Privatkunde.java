package de.hska.kundenverwaltung.db;

import static de.hska.kundenverwaltung.db.Kunde.PRIVATKUNDE;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(PRIVATKUNDE)
public final class Privatkunde extends Kunde {
	private static final long serialVersionUID = 133152931415808605L;
	public enum Familienstand { ledig, verheiratet, geschieden, verwitwet };
	private Familienstand familienstand;

	public Familienstand getFamilienstand() {
		return familienstand;
	}
	public void setFamilienstand(Familienstand familienstand) {
		this.familienstand = familienstand;
	}

	@Override
	public String getArt() {
		return PRIVATKUNDE;
	}

	@Override
	public String toString() {
		return "{" + super.toString() + ", familienstand=" + familienstand + '}';
	}
}
