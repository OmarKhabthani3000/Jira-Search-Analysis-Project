package de.hska.kundenverwaltung;

import static de.hska.util.EjbConstants.BEGIN;
import static de.hska.util.EjbConstants.END;
import static de.hska.util.EjbConstants.PERSISTENCE_CONTEXT_HSKA;
import static de.hska.util.EjbConstants.HASH_ALGORITHM;
import static de.hska.util.EjbConstants.HASH_ENCODING;
import static de.hska.util.EjbConstants.HASH_CHARSET;
import static de.hska.util.EjbConstants.ROLLE_MITARBEITER;
import static de.hska.util.EjbConstants.ROLLE_ADMIN;
import static de.hska.util.EjbConstants.LOGIN_DOMAIN_HSKA;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.MANDATORY;
import static org.jboss.security.Util.createPasswordHash;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.annotation.PreDestroy;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.annotation.security.SecurityDomain;

import de.hska.kundenverwaltung.db.Betreuer;
import de.hska.kundenverwaltung.db.BetreuerNotFoundException;
import de.hska.kundenverwaltung.db.Kontakt;
import de.hska.kundenverwaltung.db.KontaktNotFoundException;
import de.hska.kundenverwaltung.db.KundeNotFoundException;
import de.hska.kundenverwaltung.db.KundenverwaltungDAO;
import de.hska.kundenverwaltung.db.Kunde;
import de.hska.kundenverwaltung.db.Wartungsvertrag;
import de.hska.kundenverwaltung.db.WartungsvertragNotFoundException;

@Stateless
@Remote(Kundenverwaltung.class)
@Local(KundenverwaltungLocal.class)
@RolesAllowed(ROLLE_MITARBEITER)  // Eigentlich unsinnig, aber das Beispiel soll ja ueberschaubar sein
@SecurityDomain(LOGIN_DOMAIN_HSKA)
public class KundenverwaltungBean implements Kundenverwaltung {
	private static final Log LOG = LogFactory.getLog(KundenverwaltungBean.class);
	private static final boolean DEBUG = LOG.isDebugEnabled();

	@PersistenceContext(name=PERSISTENCE_CONTEXT_HSKA)
	private EntityManager em;

	@PreDestroy
	public void preDestroy() {
		if (DEBUG) LOG.debug("KundenverwaltungBean wird geloescht");
	}

	/**
	 * @return Alle persistenten Kunden
	 */
	@TransactionAttribute(REQUIRED)
	public Collection<Kunde> findAllKunden() {
		if (DEBUG) LOG.debug(BEGIN + "findAllKunden");

		final KundenverwaltungDAO dao = KundenverwaltungDAO.getInstance();
		final Collection<Kunde> kunden = dao.findAllKunden(em);

		if (DEBUG) LOG.debug(END + "findAllKunden");
		return kunden;
	}

	
	/**
	 * Suche nach Kunden mit gleichem Nachnamen.
	 * @param nachname Suchkriterium
	 * @return Liste mit gefundenen Datens&auml;tzen
	 * @throws KundeNotFoundException 
	 */
	@TransactionAttribute(REQUIRED)
	public List<Kunde> findKunden(String nachname) throws KundeNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findKunden: " + nachname);
		
		final KundenverwaltungDAO dao = KundenverwaltungDAO.getInstance();
		final List<Kunde> kunden = dao.findKundenByNachname(em, nachname);

		if (DEBUG) LOG.debug(END + "findKunden");
		return kunden;
	}

	/**
	 * Suche nach Kunden mit gleichem Nachnamen.
	 * @param nachname Suchkriterium
	 * @return Liste mit gefundenen Datens&auml;tzen
	 * @throws KundeNotFoundException 
	 */
	@TransactionAttribute(REQUIRED)
	public List<Kunde> findKundenMitBestellungen(String nachname) throws KundeNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findKundenMitBestellungen: " + nachname);
		
		final KundenverwaltungDAO dao = KundenverwaltungDAO.getInstance();
		final List<Kunde> kunden = dao.findKundenMitBestellungenByNachname(em, nachname);

		if (DEBUG) LOG.debug(END + "findKundenMitBestellungen");
		return kunden;
	}

	/**
	 * Suche nach einem Kunden mit gegebener ID
	 * @param id Die ID des gesuchten Kunden
	 * @return Das Kundenobjekt oder null, wenn kein Kunde mit der gegebenen ID existiert
	 * @throws KundeNotFoundException 
	 */
	@TransactionAttribute(REQUIRED)
	public Kunde findKunde(Long id) throws KundeNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findKunde: " + id);
		
		final KundenverwaltungDAO dao = KundenverwaltungDAO.getInstance();
		final Kunde kunde = dao.findKundeById(em, id);

		if (DEBUG) LOG.debug(END + "findKunde: " + kunde);
		return kunde;
	}

	/**
	 * Suche nach einem Kunden mit gegebener ID einschlie&szlig;lich seiner Bestellungen
	 * @param id Die ID des gesuchten Kunden
	 * @return Das Kundenobjekt oder null, wenn kein Kunde mit der gegebenen ID existiert
	 * @throws KundeNotFoundException 
	 */
	@TransactionAttribute(REQUIRED)
	public Kunde findKundeMitBestellungen(Long id) throws KundeNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findKundeMitBestellungen: " + id);
		
		final KundenverwaltungDAO dao = KundenverwaltungDAO.getInstance();
		final Kunde kunde = dao.findKundeMitBestellungenById(em, id);

		if (DEBUG) LOG.debug(END + "findKundeMitBestellungen: " + kunde);
		return kunde;
	}

	/**
	 * Zu einem Kunden mit gegebener Kunden-Id die zugeh&ouml;rigen Wartungsvertr&auml;ge ermitteln
	 * @param kundeId Die Kunde-ID
	 * @return Eine Liste mit den ermittelten Wartungsvertr&auml;gen
	 * @throws WartungsvertragNotFoundException 
	 */
	@TransactionAttribute(REQUIRED)
	public List<Wartungsvertrag> findWartungsvertraege(Long kundeId) throws WartungsvertragNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findWartungsvertraege: " + kundeId);
		
		final KundenverwaltungDAO dao = KundenverwaltungDAO.getInstance();
		final List<Wartungsvertrag> wartungsvertraege = dao.findWartungsvertraegeByKundeId(em, kundeId);
		
		if (DEBUG) LOG.debug(END + "findWartungsvertraege");
		return wartungsvertraege;
	}
	
	
	/**
	 * Eine Menge von Kunden soll gel&ouml;scht werden.
	 * NUR wegen Prog3: mengenwertige Schnittstelle, weil die komplizierter ist als nur einen Kunden zu l&ouml;schen
	 * @param kunden Zu l&ouml;schende Datens&auml;tze
	 * @throws KundeDeleteBestellungException falls der zu l&ouml;schende Kunde mind. eine Bestellung hat.
	 */
	@TransactionAttribute(REQUIRED)
	@RolesAllowed(ROLLE_ADMIN)
	public void deleteKunden(Collection<Kunde> kunden)
		        throws KundeDeleteBestellungException {
		if (DEBUG) LOG.debug(BEGIN + "deleteKunden");

		if (kunden == null || kunden.isEmpty()) {
			if (DEBUG) LOG.debug(END + "deleteKunden: leere Collection");
			return;
		}

		// Gibt es Kunden mit Bestellungen?
		for (Kunde k: kunden) {
			// Werden Constraints durch das Loeschen verletzt?
			final boolean hasBestellungen = hasBestellungen(k);
			if (hasBestellungen == true) {
				if (DEBUG) LOG.debug(END + "deleteKunde: " + k.getBestellungen().size() + " Bestellungen vorhanden");
				throw new KundeDeleteBestellungException(k);
			}
		}

		final KundenverwaltungDAO dao = KundenverwaltungDAO.getInstance();
		dao.deleteKunden(em, kunden);
		
		if (DEBUG) LOG.debug(END + "deleteKunden: " + kunden.size() + " Datensaetze geloescht");
	}


	/**
	 * Neue Kunden sollen angelegt werden.
	 * NUR wegen Prog3: mengenwertige Schnittstelle, weil die komplizierter ist als nur einen Kunden zu erzeugen
	 * @param kunden Neue Kundendaten
	 * @throws KundeCreateAdresseException Falls der Kunde keine Adresse hat
	 */
	@TransactionAttribute(REQUIRED)
	public Collection<Kunde> createKunden(Collection<Kunde> kunden) throws KundeCreateAdresseException {
		if (DEBUG) LOG.debug(BEGIN + "createKunden");
		if (kunden == null || kunden.isEmpty()) {
			if (DEBUG) LOG.debug(END + "createKunden: leere Collection");
			return new ArrayList<Kunde>(0);
		}

		// Werden alle Constraints beim Einfuegen gewahrt?
		// Passwort verschluesseln
		for (Kunde k: kunden) {
			final boolean hasAdresse = hasAdresse(k);
			if (hasAdresse == false) {
				if (DEBUG)
					LOG.debug(END + "createKunden: keine Adresse");
				throw new KundeCreateAdresseException(k.getNachname(), k.getVorname());
			}
			
			final String verschluesselt = createPasswordHash(HASH_ALGORITHM, HASH_ENCODING, HASH_CHARSET, null, k.getPassword());
			k.setPassword(verschluesselt);
		}

		final KundenverwaltungDAO dao = KundenverwaltungDAO.getInstance();
		kunden = dao.insertKunden(em, kunden);
		
		if (DEBUG) LOG.debug(END + "createKunden");
		return kunden;
	}

	/**
	 * Existierende Kundendaten sollen ge&auml;ndert werden.
	 * NUR wegen Prog3: mengenwertige Schnittstelle, weil die komplizierter ist als nur einen Kunden zu &auml;ndern.
	 * @param kunden Zu &auml;ndernde Kundendaten. Die Kunden-ID muss gesetzt sein.
	 * @return Die Menge der aktualisierten Kunden
	 */
	@TransactionAttribute(REQUIRED)
	public Collection<Kunde> updateKunden(Collection<Kunde> kunden) {
		if (DEBUG) LOG.debug(BEGIN + "updateKunden");

		final KundenverwaltungDAO dao = KundenverwaltungDAO.getInstance();
		kunden = dao.updateKunden(em, kunden);
		
		if (DEBUG) LOG.debug(END + "updateKunden");
		return kunden;
	}

	/**
	 * Einen Betreuer suchen, der in 1:1 Beziehung mit einem Kunden steht
	 * @param id Die ID des gesuchten Betreuers
	 * @return
	 * @throws BetreuerNotFoundException 
	 */
	@TransactionAttribute(REQUIRED)
	public Betreuer findBetreuer(Long id) throws BetreuerNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findBetreuer: " + id);
		
		final KundenverwaltungDAO dao = KundenverwaltungDAO.getInstance();
		final Betreuer betreuer = dao.findBetreuerById(em, id);

		if (DEBUG) LOG.debug(END + "findBetreuer: " + betreuer);
		return betreuer;
	}

	/**
	 * Alle Kunden ermitteln, die die gleiche PLZ haben
	 * @param plz Die gemeinsame PLZ von den gesuchten Kunden
	 * @return Die Liste mit den gefundenen Kunden
	 * @throws KundeNotFoundException 
	 */
	@TransactionAttribute(REQUIRED)
	public List<Kunde> findKundenByPLZ(int plz) throws KundeNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findKunden: " + plz);

		final KundenverwaltungDAO dao = KundenverwaltungDAO.getInstance();
		final List<Kunde> kunden = dao.findKundenByPLZ(em, plz);

		if (DEBUG) LOG.debug(END + "findKunden");
		return kunden;
	}

	/**
	 * Zu gegebener Kunden-ID werden alle Kontakte gesucht. Zwischen Kunde und
	 * Kontakte existiert eine <it>gerichtete</it> 1:N-Beziehung
	 * @param kundeId Die ID des Kunden, zu dem alle Kontakte gesucht werden
	 * @return Eine Liste mit den gefundenen Kontakten
	 * @throws KontaktNotFoundException 
	 */
	@TransactionAttribute(REQUIRED)
	public Collection<Kontakt> findKontakteByKundeId(Long kundeId) throws KontaktNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findKontakteByKundeId: " + kundeId);
		
		final KundenverwaltungDAO dao = KundenverwaltungDAO.getInstance();
		final Collection<Kontakt> kontakte = dao.findKundeKontakteById(em, kundeId);

		if (DEBUG) LOG.debug(END + "findKontakteByKundeId: " + kontakte);
		return kontakte;
	}
	
	/**
	 * Aktualisierung des Passworts eines Kunden
	 * @param kunde Kundenobjekt
	 * @param passwort neues, noch unverschl&uuml;sseltes Passwort
	 * @return Der aktualisierte Kunde
	 */
	@TransactionAttribute(REQUIRED)
	public Kunde setPassword(Kunde kunde, String passwort) {
		if (DEBUG) LOG.debug(BEGIN + "setPassword: " + kunde + ", " + passwort);

		String verschluesselt = createPasswordHash(HASH_ALGORITHM, HASH_ENCODING, HASH_CHARSET, null, passwort);
		kunde.setPassword(verschluesselt);

		Collection<Kunde> kunden = new ArrayList<Kunde>(1);
		kunden.add(kunde);
		final KundenverwaltungDAO dao = KundenverwaltungDAO.getInstance();
		kunden = dao.updateKunden(em, kunden);
		kunde = kunden.iterator().next();
		
		if (DEBUG) LOG.debug(END + "setPassword: " + kunde.getPassword());
		return kunde;
	}
	
	/**
	 * Vergleich des verschluesselte Kunden-Passwortes mit einem anderen
	 * Passwort im Klartext.
	 * @param kunde Kundenobjekt
	 * @param passwort Das unverschl&uuml;sselte Passwort im Klartext
	 * @return true, falls das unverschl&uuml;sselte Passwort die gleiche
	 *         Codierung ergibt; false ansonsten.
	 */
	public boolean checkPassword(Kunde kunde, String passwort) {
		if (DEBUG) LOG.debug(BEGIN + "checkPassword: " + kunde + ", " + passwort);

		String verschluesselt = createPasswordHash(HASH_ALGORITHM, HASH_ENCODING, HASH_CHARSET, null, passwort);
		final boolean result = verschluesselt.equals(kunde.getPassword());
		
		if (DEBUG) LOG.debug(END + "checkPassword: " + result);
		return result;
	}
	
	/**
	 */
	@TransactionAttribute(MANDATORY)
	private boolean hasBestellungen(Kunde kunde) {
		if (DEBUG) LOG.debug(BEGIN + "checkDeleteKunde: " + kunde);
		
		boolean result = false;
		
		// Gibt es den Kunden und hat er mehr als eine Bestellung
		if (kunde != null && !kunde.getBestellungen().isEmpty())
			result = true;
		
		if (DEBUG) LOG.debug(END + "checkDeleteKunde: " + result);
		return result;
	}

	/**
	 */
	@TransactionAttribute(MANDATORY)
	private boolean hasAdresse(Kunde kunde) {
		if (DEBUG) LOG.debug(BEGIN + "checkCreateKunde: " + kunde);
		
		boolean result = false;
		
		// Gibt es den Kunden und hat er keine Adresse
		if (kunde != null && kunde.getAdresse() != null)
			result = true;
		
		if (DEBUG) LOG.debug(END + "checkCreateKunde: " + result);
		return result;
	}
}
