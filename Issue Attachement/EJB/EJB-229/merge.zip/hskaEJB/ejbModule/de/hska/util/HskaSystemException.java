package de.hska.util;

public class HskaSystemException extends RuntimeException {
	private static final long serialVersionUID = 7294078700257616332L;
	public static final String KV_IS_NULL= "Das SessionBean fuer Kundenverwaltung ist null";

	public HskaSystemException(String msg) {
		super("Interner Fehler: " + msg);
	}
}
