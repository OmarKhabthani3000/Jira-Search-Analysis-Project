package de.hska.kundenverwaltung.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PostUpdate;
import javax.persistence.Table;

import javax.persistence.Version;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@Entity
@Table(name="wartungsvertrag")
@NamedQueries({
	@NamedQuery(name = Wartungsvertrag.WARTUNGSVERTRAG_BY_KUNDE_ID,
			    query = "SELECT w FROM Wartungsvertrag w WHERE w.kunde.id = :kundeId")
})
public class Wartungsvertrag implements Serializable {
	private static final long serialVersionUID = -5955263122430830600L;
	protected static final Log LOG = LogFactory.getLog(Wartungsvertrag.class);
	protected static final boolean TRACE = LOG.isTraceEnabled();
	
	public static final String WARTUNGSVERTRAG_BY_KUNDE_ID = "wartungsvertrag.byKundeId";

	@EmbeddedId
	private WartungsvertragPK pk = null;

	@Version
	private int version = 0;
	
	@Column
	private String inhalt = null;

	@ManyToOne
	@JoinColumn(name="kunde_fk")
	private Kunde kunde = null;

	@PostUpdate
	protected void logNeueVersion() {
		if (TRACE) LOG.trace("Wartungsvertrag mit Schluessel=" + pk + " geaendert: neue Version=" + version);
	}

	public WartungsvertragPK getPk() {
		return pk;
	}

	public void setPk(WartungsvertragPK pk) {
		this.pk = pk;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getInhalt() {
		return inhalt;
	}

	public void setInhalt(String inhalt) {
		this.inhalt = inhalt;
	}

	public Kunde getKunde() {
		return kunde;
	}

	public void setKunde(Kunde kunde) {
		this.kunde = kunde;
	}

	@Override
	public String toString() {
		return "{nr=" + pk.nr + ", datum=" + pk.datum + ", version=" + version + ", inhalt=" + inhalt + '}';
	}
	
	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other instanceof Wartungsvertrag == false) return false;

		final Wartungsvertrag w = (Wartungsvertrag) other;
		return pk.equals(w.pk) && version == w.version;
	}
	
	@Override
	public int hashCode() {
		int result = 37 + version;        // Version als Offset
		result ^= pk.hashCode();          // Bit-weise XOR
		return result;
	}
}
