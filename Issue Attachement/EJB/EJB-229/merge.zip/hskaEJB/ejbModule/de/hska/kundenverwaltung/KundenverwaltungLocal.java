package de.hska.kundenverwaltung;

public interface KundenverwaltungLocal extends Kundenverwaltung {

}
