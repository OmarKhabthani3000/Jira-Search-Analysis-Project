package de.hska.util;

import java.io.Serializable;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class ConcurrencyException extends RuntimeException {
	public enum UpdatedOrDeleted {updated, deleted}
	private static final long serialVersionUID = 6028363977039775169L;
	private Serializable id;
	private String classname;
	private UpdatedOrDeleted updatedOrDeleted;

	public ConcurrencyException(Serializable id, String classname, UpdatedOrDeleted updatedOrDeleted) {
		super(updatedOrDeleted.equals(UpdatedOrDeleted.updated) ?
			  "Fehler bei optimistischer Synchronisation: ID=" + id + ", Klasse=" + classname + " wurde aktualisiert" :
			  "Fehler bei optimistischer Synchronisation: ID=" + id + ", Klasse=" + classname + " wurde geloescht"  );
		this.id = id;
		this.classname = classname;
		this.updatedOrDeleted = updatedOrDeleted;
	}

	public Serializable getId() {
		return id;
	}
	
	public String getClassname() {
		return classname;
	}

	public UpdatedOrDeleted getUpdatedOrDeleted() {
		return updatedOrDeleted;
	}
}
