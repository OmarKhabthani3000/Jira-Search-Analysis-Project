package de.hska.bestellwesen.db;

import static javax.persistence.CascadeType.PERSIST;
import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.GenerationType.AUTO;
import static de.hska.util.EjbConstants.KEINE_ID;
import static de.hska.util.EjbConstants.ERSTE_VERSION;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OrderBy;
import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Version;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@Entity
@Table(name="lieferung")
@NamedQueries({
	@NamedQuery(name = Lieferung.LIEFERUNG_BY_NR_FETCH_BESTELLUNGEN,
			    query = "SELECT DISTINCT l FROM Lieferung l LEFT JOIN FETCH l.bestellungen WHERE l.lieferNr LIKE :lieferNr")
})
public class Lieferung implements java.io.Serializable {
	public enum TransportArt { strasse, schiene, luft, wasser };
	
	private static final long serialVersionUID = 7560752199018702446L;
	protected static final Log LOG = LogFactory.getLog(Geschenkverpackung.class);
	protected static final boolean DEBUG = LOG.isDebugEnabled();
	protected static final boolean TRACE = LOG.isTraceEnabled();
	
	public static final String LIEFERUNG_BY_NR_FETCH_BESTELLUNGEN = "lieferung.byNr.fetchBestellungen";

	@Id
	@GeneratedValue(strategy=AUTO, generator="lieferung_sequence_name")
	@SequenceGenerator(name="lieferung_sequence_name", sequenceName="lieferung_l_id_seq", allocationSize=1)
	@Column(name="l_id", nullable=false)
	private Long id = KEINE_ID;

	@Version
	private int version = ERSTE_VERSION;

	@Column(name="liefernr", length=12, unique=true)
	private String lieferNr;
	
	@Column(name="transport_art")
	@Enumerated(STRING)
	private TransportArt transportArt;

	@ManyToMany(mappedBy="lieferungen", cascade={PERSIST, MERGE})
	@OrderBy("id ASC")
	private List<Bestellung> bestellungen;

	public Lieferung() {
		super();
	}
	
	@PostPersist
	protected void logDbId() {
		if (DEBUG) LOG.debug("Neue Lieferung mit ID=" + id + " : " + this);
	}

	@PostUpdate
	protected void logNeueVersion() {
		if (TRACE) LOG.trace("Lieferung ID=" + id + " geaendert: neue Version=" + version);
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}

	public String getLieferNr() {
		return lieferNr;
	}
	public void setLieferNr(String lieferNr) {
		this.lieferNr = lieferNr;
	}

	public TransportArt getTransportArt() {
		return transportArt;
	}

	public void setTransportArt(TransportArt transportArt) {
		this.transportArt = transportArt;
	}

	public List<Bestellung> getBestellungen() {
		return bestellungen;
	}
	public void setBestellungen(List<Bestellung> bestellungen) {
		this.bestellungen = bestellungen;
	}

	@Override
	public String toString() {
		return "{id=" + id + ", version=" + version + ", lieferNr=" + lieferNr + ", transportArt=" + transportArt + '}';
	}

	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other instanceof Lieferung == false) return false;

		final Lieferung l = (Lieferung) other;
		return id.equals(l.id) && version == l.version && lieferNr.equals(l.lieferNr);
	}
	
	@Override
	public int hashCode() {
		int result = 37 + version;        // Version als Offset
		result ^= id.intValue();          // Bit-weise XOR
		result ^= lieferNr.hashCode();
		return result;
	}
}