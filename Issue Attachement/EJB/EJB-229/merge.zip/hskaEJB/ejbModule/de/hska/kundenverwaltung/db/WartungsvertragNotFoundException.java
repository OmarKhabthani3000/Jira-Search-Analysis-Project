package de.hska.kundenverwaltung.db;

import java.io.Serializable;

public class WartungsvertragNotFoundException extends Exception {
	private static final long serialVersionUID = 5234678176501206166L;
	private Serializable id;
	
	public WartungsvertragNotFoundException(Serializable id) {
		super("Keine Wartungsvertraege gefunden");
		this.id = id;
	}

	public Serializable getId() {
		return id;
	}
}
