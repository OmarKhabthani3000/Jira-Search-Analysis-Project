package de.hska.bestellwesen;

import static javax.ejb.TransactionAttributeType.REQUIRED;
import static de.hska.util.EjbConstants.BEGIN;
import static de.hska.util.EjbConstants.END;
import static de.hska.util.EjbConstants.PERSISTENCE_CONTEXT_HSKA;
import static de.hska.util.EjbConstants.ROLLE_MITARBEITER;
import static de.hska.util.EjbConstants.LOGIN_DOMAIN_HSKA;
import static de.hska.util.HskaSystemException.KV_IS_NULL;

import java.util.Collection;

import javax.annotation.PreDestroy;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.annotation.security.SecurityDomain;

import de.hska.bestellwesen.db.Bestellung;
import de.hska.bestellwesen.db.BestellwesenDAO;
import de.hska.bestellwesen.db.Lieferung;
import de.hska.bestellwesen.db.LieferungNotFoundException;
import de.hska.kundenverwaltung.KundenverwaltungLocal;
import de.hska.kundenverwaltung.db.Kunde;
import de.hska.kundenverwaltung.db.KundeNotFoundException;
import de.hska.util.EjbNotFoundException;
import de.hska.util.HskaSystemException;


@Stateless
@Remote(Bestellwesen.class)
@RolesAllowed(ROLLE_MITARBEITER)
@SecurityDomain(LOGIN_DOMAIN_HSKA)
public class BestellwesenBean implements Bestellwesen {
	private static final Log LOG = LogFactory.getLog(BestellwesenBean.class);
	private static final boolean DEBUG = LOG.isDebugEnabled();
	
	@PersistenceContext(name=PERSISTENCE_CONTEXT_HSKA)
	private EntityManager em;
	
	@EJB
	private KundenverwaltungLocal kv;

	@PreDestroy
	public void preDestroy() {
		if (DEBUG) LOG.debug("BestellwesenBean wird geloescht");
	}

	/**
	 * Zu gegebener Bestell-Nr werden alle Lieferungen gesucht. Zwischen Bestellungen
	 * und Lieferungen gibt es eine N:M-Beziehung
	 * @param nr der Bestellung
	 * @return Die gefundenen Lieferungen
	 * @throws LieferungNotFoundException 
	 */
	@TransactionAttribute(REQUIRED)
	public Collection<Lieferung> findLieferungen(String nr) throws LieferungNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "findLieferungen: " + nr);

		final BestellwesenDAO dao = BestellwesenDAO.getInstance();
		final Collection<Lieferung> lieferungen = dao.findLieferungenByNr(em, nr);

		if (DEBUG) LOG.debug(END + "findLieferungen");
		return lieferungen;
	}

	
	/**
	 * Zu einem Kunden mit gegebener Kunden-ID wird eine neue Bestellung erzeugt.
	 * @param kundeId die ID des vorhandenen Kunden
	 * @param text Beschreibung der Bestellung
	 * @return Die neue, persistente Bestellung
	 * @throws KundeNotFoundException 
	 * @throws EjbNotFoundException 
	 */
	@TransactionAttribute(REQUIRED)
	public Bestellung neueBestellung(Long kundeId, String text) throws KundeNotFoundException, EjbNotFoundException {
		if (DEBUG) LOG.debug(BEGIN + "neueBestellung: " + kundeId + ", " + text);

		if (kv == null) {
			LOG.error("neueBestellung: kv == null");
			if (DEBUG) LOG.debug(END + "neueBestellung: kv == null");
			throw new HskaSystemException(KV_IS_NULL);
		}
		final Kunde kunde = kv.findKundeMitBestellungen(kundeId);
		
		if (kunde == null) {
			if (DEBUG) LOG.debug(END + "neueBestellung: Kunde nicht gefunden");
			return null;
		}
		
		// Transientes Bestellungsobjekt erstellen inkl. Beziehung zu Kunde
		Bestellung bestellung = new Bestellung();
		bestellung.setKunde(kunde);
		bestellung.setText(text);
		kunde.getBestellungen().add(bestellung);

		// Abspeichern des Bestellungsobjektes
		final BestellwesenDAO dao = BestellwesenDAO.getInstance();
		dao.neueBestellung(em, bestellung);

		if (DEBUG) LOG.debug(END + "neueBestellung: " + bestellung);
		return bestellung;
	}
}
