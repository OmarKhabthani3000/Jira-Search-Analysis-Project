package de.hska.kundenverwaltung.db;

import static de.hska.kundenverwaltung.db.Kunde.FIRMENKUNDE;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity 
@DiscriminatorValue(FIRMENKUNDE)
public class Firmenkunde extends Kunde {
	private static final long serialVersionUID = 3224665468219250145L;
	@Column
	private int rabatt;
	
	public Firmenkunde() {
		super();
	}

	public int getRabatt() {
		return rabatt;
	}
	public void setRabatt(int rabatt) {
		this.rabatt = rabatt;
	}

	@Override
	public String getArt() {
		return FIRMENKUNDE;
	}

	@Override
	public String toString() {
		return "{" + super.toString() + ", rabatt=" + rabatt + '}';
	}
}
