package de.hska.kundenverwaltung;

import static de.hska.util.EjbConstants.BEAN_NAME_PRAEFIX;
import static de.hska.util.EjbConstants.BEAN_NAME_SUFFIX;

import java.util.Collection;
import java.util.List;

import de.hska.kundenverwaltung.db.Betreuer;
import de.hska.kundenverwaltung.db.BetreuerNotFoundException;
import de.hska.kundenverwaltung.db.Kontakt;
import de.hska.kundenverwaltung.db.KontaktNotFoundException;
import de.hska.kundenverwaltung.db.Kunde;
import de.hska.kundenverwaltung.db.KundeNotFoundException;
import de.hska.kundenverwaltung.db.Wartungsvertrag;
import de.hska.kundenverwaltung.db.WartungsvertragNotFoundException;

public interface Kundenverwaltung {
	static final String JNDI_NAME = BEAN_NAME_PRAEFIX + Kundenverwaltung.class.getSimpleName() + BEAN_NAME_SUFFIX;

	/**
	 * @return Alle persistenten Kunden
	 */
	Collection<Kunde> findAllKunden();

	/**
	 * Suche nach Kunden mit gleichem Nachnamen.
	 * @param nachname Suchkriterium
	 * @return Liste mit gefundenen Datens&auml;tzen
	 * @throws KundeNotFoundException 
	 */
	List<Kunde> findKunden(String nachname) throws KundeNotFoundException;

	/**
	 * Suche nach Kunden mit gleichem Nachnamen einschlie&szlich ihrer Bestellungen.
	 * @param nachname Suchkriterium
	 * @return Liste mit gefundenen Datens&auml;tzen
	 * @throws KundeNotFoundException 
	 */
	List<Kunde> findKundenMitBestellungen(String nachname) throws KundeNotFoundException;

	/**
	 * Suche nach einem Kunden mit gegebener ID
	 * @param id Die ID des gesuchten Kunden
	 * @return Das Kundenobjekt oder null, wenn kein Kunde mit der gegebenen ID existiert
	 * @throws KundeNotFoundException 
	 */
	Kunde findKunde(Long id) throws KundeNotFoundException;

	/**
	 * Suche nach einem Kunden mit gegebener ID einschlie&szlich der Bestellungen.
	 * @param id Die ID des gesuchten Kunden
	 * @return Das Kundenobjekt oder null, wenn kein Kunde mit der gegebenen ID existiert
	 * @throws KundeNotFoundException 
	 */
	Kunde findKundeMitBestellungen(Long id) throws KundeNotFoundException;

	/**
	 * Zu einem Kunden mit gegebener Kunden-Id die zugeh&ouml;rigen Wartungsvertr&auml;ge ermitteln
	 * @param kundeId Die Kunde-ID
	 * @return Eine Liste mit den ermittelten Wartungsvertr&auml;gen
	 * @throws WartungsvertragNotFoundException 
	 */
	List<Wartungsvertrag> findWartungsvertraege(Long kundeId) throws WartungsvertragNotFoundException;

	/**
	 * Eine Menge von Kunden soll gel&ouml;scht werden.
	 * NUR wegen Prog3: mengenwertige Schnittstelle, weil die komplizierter ist als nur einen Kunden zu l&ouml;schen
	 * @param kunden Zu l&ouml;schende Datens&auml;tze
	 * @throws KundeDeleteBestellungException falls parallel ein gleicher Datensatz ge&auml;ndert oder
	 * 		gel&ouml;scht wurde
	 */
	void deleteKunden(Collection<Kunde> kunden)	throws KundeDeleteBestellungException;

	/**
	 * Neue Kunden sollen angelegt werden.
	 * NUR wegen Prog3: mengenwertige Schnittstelle, weil die komplizierter ist als nur einen Kunden zu erzeugen
	 * @param kunden Neue Kundendaten
	 * @throws KundeCreateAdresseException Falls der Kunde keine Adresse hat
	 */
	Collection<Kunde> createKunden(Collection<Kunde> kunden) throws KundeCreateAdresseException;

	/**
	 * Existierende Kundendaten sollen ge&auml;ndert werden.
	 * NUR wegen Prog3: mengenwertige Schnittstelle, weil die komplizierter ist als nur einen Kunden zu &auml;ndern.
	 * @param kunden Zu &auml;ndernde Kundendaten. Die Kunden-ID muss gesetzt sein.
	 * @return Die Menge der aktualisierten Kunden
	 */
	Collection<Kunde> updateKunden(Collection<Kunde> kunden);

	/**
	 * Einen Betreuer suchen, der in 1:1 Beziehung mit einem Kunden steht
	 * @param id Die ID des gesuchten Betreuers
	 * @return
	 * @throws BetreuerNotFoundException 
	 */
	Betreuer findBetreuer(Long id) throws BetreuerNotFoundException;

	/**
	 * Alle Kunden ermitteln, die die gleiche PLZ haben
	 * @param plz Die gemeinsame PLZ von den gesuchten Kunden
	 * @return Die Liste mit den gefundenen Kunden
	 * @throws KundeNotFoundException 
	 */
	List<Kunde> findKundenByPLZ(int plz) throws KundeNotFoundException;

	/**
	 * Zu gegebener Kunden-ID werden alle Kontakte gesucht. Zwischen Kunde und
	 * Kontakte existiert eine <it>gerichtete</it> 1:N-Beziehung
	 * @param kundeId Die ID des Kunden, zu dem alle Kontakte gesucht werden
	 * @return Eine Liste mit den gefundenen Kontakten
	 * @throws KontaktNotFoundException 
	 */
	Collection<Kontakt> findKontakteByKundeId(Long kundeId) throws KontaktNotFoundException;

	/**
	 * Aktualisierung des Passworts eines Kunden
	 * @param kunde Kundenobjekt
	 * @param password neues, noch unverschl&uuml;sseltes Passwort
	 * @return Der aktualisierte Kunde
	 */
	Kunde setPassword(Kunde kunde, String password);

	/**
	 * Vergleich des verschluesselte Kunden-Passwortes mit einem anderen
	 * Passwort im Klartext.
	 * @param kunde Kundenobjekt
	 * @param password Das unverschl&uuml;sselte Passwort im Klartext
	 * @return true, falls das unverschl&uuml;sselte Passwort die gleiche
	 *         Codierung ergibt; false ansonsten.
	 */
	boolean checkPassword(Kunde kunde, String password);
}