package de.hska.util;

public class EjbNotFoundException extends Exception {
	private static final long serialVersionUID = 822156196951101405L;

	public EjbNotFoundException(String jndiName) {
		super("Kein SessionBean mit dem Namen " + jndiName + " gefunden");
	}
}
