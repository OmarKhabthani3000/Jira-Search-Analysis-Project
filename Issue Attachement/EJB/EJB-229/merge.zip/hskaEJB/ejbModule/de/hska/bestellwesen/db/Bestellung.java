package de.hska.bestellwesen.db;

import static javax.persistence.GenerationType.AUTO;
import static de.hska.util.EjbConstants.KEINE_ID;
import static de.hska.util.EjbConstants.ERSTE_VERSION;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Version;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.hska.kundenverwaltung.db.Kunde;

@Entity
@Table(name="bestellung")
public class Bestellung implements java.io.Serializable {
	private static final long serialVersionUID = 7560752199018702446L;
	protected static final Log LOG = LogFactory.getLog(Bestellung.class);
	protected static final boolean DEBUG = LOG.isDebugEnabled();
	protected static final boolean TRACE = LOG.isTraceEnabled();

	@Id
	@GeneratedValue(strategy=AUTO, generator="bestellung_sequence_name")
	@SequenceGenerator(name="bestellung_sequence_name", sequenceName="bestellung_b_id_seq", allocationSize=1)
	@Column(name="b_id", nullable=false)
	private Long id = KEINE_ID;

	@Version
	private int version = ERSTE_VERSION;

	@Column(length=32)
	private String text = "";

	@ManyToOne
	@JoinColumn(name="kunde_fk")
	private Kunde kunde;

	@ManyToMany
	@JoinTable(name="bestellung_lieferung",
			   joinColumns={@JoinColumn(name="bestellung_fk")},
			                inverseJoinColumns={@JoinColumn(name="lieferung_fk")})
	@OrderBy("lieferNr DESC")
	private List<Lieferung> lieferungen = new ArrayList<Lieferung>();
	
	@OneToOne
	@JoinColumn(name="geschenkverpackung_fk")
	private Geschenkverpackung geschenkverpackung;

	public Bestellung() {
		super();
	}
	
	@PostPersist
	protected void logDbId() {
		if (DEBUG) LOG.debug("Neue Bestellung mit ID=" + id + " : " + this);
	}

	@PostUpdate
	protected void logNeueVersion() {
		if (TRACE) LOG.trace("Bestellung ID=" + id + " geaendert: neue Version=" + version);
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}

	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}

	public Kunde getKunde() {
		return kunde;
	}
	public void setKunde(Kunde kunde) {
		this.kunde = kunde;
	}

	public List<Lieferung> getLieferungen() {
		return lieferungen;
	}
	public void setLieferungen(List<Lieferung> lieferungen) {
		this.lieferungen = lieferungen;
	}

	public Geschenkverpackung getGeschenkverpackung() {
		return geschenkverpackung;
	}

	public void setGeschenkverpackung(Geschenkverpackung geschenkverpackung) {
		this.geschenkverpackung = geschenkverpackung;
	}

	@Override
	public String toString() {
		return "{id=" + id + ", version=" + version + ", text=" + text + '}';
	}

	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other instanceof Bestellung == false) return false;

		final Bestellung b = (Bestellung) other;
		return id.equals(b.id) && version == b.version && text.equals(b.text);
	}
	
	@Override
	public int hashCode() {
		int result = 37 + version;        // Version als Offset
		result ^= id.intValue();          // Bit-weise XOR
		result ^= text.hashCode();
		return result;
	}
}