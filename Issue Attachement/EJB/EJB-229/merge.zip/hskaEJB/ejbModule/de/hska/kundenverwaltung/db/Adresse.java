package de.hska.kundenverwaltung.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Adresse implements Serializable {
	private static final long serialVersionUID = -5108148468525006134L;

	@Column(nullable=false)
	private int plz;

	@Column(length=32, nullable=false)
	private String ort;

	@Column(length=32, nullable=false)
	private String strasse;

	@Column(length=4)
	private String hausnr;

	public Adresse() {
		super();
	}

	public Adresse(int plz, String ort, String strasse, String hausnr) {
		super();
		this.plz = plz;
		this.ort = ort;
		this.strasse = strasse;
		this.hausnr = hausnr;
	}

	public int getPlz() {
		return plz;
	}
	public void setPlz(int plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return ort;
	}
	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getHausnr() {
		return hausnr;
	}
	public void setHausnr(String hausnr) {
		this.hausnr = hausnr;
	}

	@Override
	public String toString() {
		return "{plz=" + plz + ", ort=" + ort + ", strasse=" + strasse + ", hausnr=" + hausnr + '}';
	}
}
