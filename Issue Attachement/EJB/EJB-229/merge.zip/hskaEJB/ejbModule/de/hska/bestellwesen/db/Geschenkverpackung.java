package de.hska.bestellwesen.db;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.GenerationType.AUTO;
import static de.hska.util.EjbConstants.KEINE_ID;
import static de.hska.util.EjbConstants.ERSTE_VERSION;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@Entity
@Table(name="geschenkverpackung")
public class Geschenkverpackung implements Serializable {
	private static final long serialVersionUID = -6824763459214716853L;
	protected static final Log LOG = LogFactory.getLog(Geschenkverpackung.class);
	protected static final boolean DEBUG = LOG.isDebugEnabled();
	protected static final boolean TRACE = LOG.isTraceEnabled();

	public enum Art { weihnachten, ostern, geburtstag, heirat };
	
	@Id
	@GeneratedValue(strategy=AUTO, generator="geschenkverpackung_sequence_name")
	@SequenceGenerator(name="geschenkverpackung_sequence_name", sequenceName="geschenkverpackung_g_id_seq", allocationSize=1)
	@Column(name="g_id", nullable=false)
	private Long id = KEINE_ID;

	@Version
	@Column(nullable=false)
	private int version = ERSTE_VERSION;

	@Column(length=11, nullable=false)
	@Enumerated(STRING)
	private Art art;

	@Column(length=2000)
	private String text;

	@PostPersist
	protected void logDbId() {
		if (DEBUG) LOG.debug("Neue Geschenkverpackung mit ID=" + id + " : " + this);
	}

	@PostUpdate
	protected void logNeueVersion() {
		if (TRACE) LOG.trace("Geschenkverpackung ID=" + id + " geaendert: neue Version=" + version);
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}

	public Art getArt() {
		return art;
	}
	public void setArt(Art art) {
		this.art = art;
	}

	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
	@Override
	public String toString() {
		return "{id= " + id + ", version=" + version + ", art=" + art + ", text=" + text + '}';
	}

	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other instanceof Geschenkverpackung == false) return false;

		final Geschenkverpackung g = (Geschenkverpackung) other;
		boolean result = id.equals(g.id) && version == g.version;
		if (text != null)
			result = result && text.equals(g.text);
		if (art != null)
			result = result && art.equals(g.art);
		return result;
	}
	
	@Override
	public int hashCode() {
		int result = 37 + version;        // Version als Offset
		result ^= id.intValue();          // Bit-weise XOR
		if (text != null)
			result ^= text.hashCode();
		if (art != null)
			result ^= art.hashCode();
		return result;
	}
}
