package de.hska.kundenverwaltung.db;

import java.io.Serializable;

public class KontaktNotFoundException extends Exception {
	private static final long serialVersionUID = 8381230255977582101L;
	private Serializable id;
	
	public KontaktNotFoundException(Serializable id) {
		super("Keine Kontakte gefunden");
		this.id = id;
	}

	public Serializable getId() {
		return id;
	}
}
