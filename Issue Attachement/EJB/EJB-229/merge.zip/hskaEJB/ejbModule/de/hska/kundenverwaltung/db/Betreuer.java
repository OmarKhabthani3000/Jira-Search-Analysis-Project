package de.hska.kundenverwaltung.db;

import static javax.persistence.GenerationType.AUTO;
import static de.hska.util.EjbConstants.KEINE_ID;
import static de.hska.util.EjbConstants.ERSTE_VERSION;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@Entity
@Table(name="betreuer")
public class Betreuer implements Serializable {
	private static final long serialVersionUID = -4090693388150752068L;
	protected static final Log LOG = LogFactory.getLog(Betreuer.class);
	protected static final boolean DEBUG = LOG.isDebugEnabled();
	protected static final boolean TRACE = LOG.isTraceEnabled();

	@Id
	@GeneratedValue(strategy=AUTO, generator="betreuer_sequence_name")
	@SequenceGenerator(name="betreuer_sequence_name", sequenceName="betreuer_b_id_seq", allocationSize=1)
	@Column(name="b_id", nullable=false)
	private Long id = KEINE_ID;

	@Version
	private int version = ERSTE_VERSION;

	@Column(length=32, nullable=false)
	private String name = "";

	@OneToOne
	@JoinColumn(name="kunde_fk")
	private Kunde kunde = null;

	public Betreuer() {
		super();
	}
	
	@PostPersist
	protected void logDbId() {
		if (DEBUG) LOG.debug("Neuer Betreuer mit ID=" + id + " : " + this);
	}

	@PostUpdate
	protected void logNeueVersion() {
		if (TRACE) LOG.trace("Betreuer ID=" + id + " geaendert: neue Version=" + version);
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public Kunde getKunde() {
		return kunde;
	}
	public void setKunde(Kunde kunde) {
		this.kunde = kunde;
	}

	@Override
	public String toString() {
		return "{id=" + id + ", name=" + name + "}";
	}
	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other instanceof Betreuer == false) return false;

		final Betreuer b = (Betreuer) other;
		return id.equals(b.id) && version == b.version && name.equals(b.name);
	}
	
	@Override
	public int hashCode() {
		int result = 37 + version;        // Version als Offset
		result ^= id.intValue();          // Bit-weise XOR
		result ^= name.hashCode();
		return result;
	}
}
