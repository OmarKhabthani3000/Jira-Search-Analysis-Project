package de.hska.kundenverwaltung.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class WartungsvertragPK implements Serializable {
	private static final long serialVersionUID = 9155270685609346099L;

	@Column(nullable=false)
	public long nr;
	@Column(nullable=false)
	public Date datum;
	
	public WartungsvertragPK() {
		super();
	}
	
	@Override
	public boolean equals(Object other) {
		if (this == other)
			return true;
		if (other instanceof WartungsvertragPK == false)
			return false;
		final WartungsvertragPK pk = (WartungsvertragPK) other;
		return nr == pk.nr && datum.equals(pk.datum);
	}

	@Override
	public int hashCode() {
		final int result = (int) (nr % Integer.MAX_VALUE);
		return result + datum.hashCode();
	}
}
