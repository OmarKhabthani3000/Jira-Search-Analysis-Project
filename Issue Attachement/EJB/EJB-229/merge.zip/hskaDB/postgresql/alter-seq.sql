ALTER SEQUENCE kunde_k_id_seq START WITH 6;
ALTER SEQUENCE betreuer_b_id_seq START WITH 44;
ALTER SEQUENCE geschenkverpackung_g_id_seq START WITH 54;
ALTER SEQUENCE bestellung_b_id_seq START WITH 16;
ALTER SEQUENCE lieferung_l_id_seq START WITH 25;
ALTER SEQUENCE kontakt_ko_id_seq START WITH 64;
