SET search_path TO hska;
SET datestyle TO 'DMY';

--   Voraussetzungen fuer COPY:
--   1) Superuser der Datenbank
--   2) Absoluter Pfadname fuer Datei oder relativ zu %PGDATA%

COPY kunde
	FROM '@BASEDIR@/csv/kunde.csv'
	DELIMITER ';' CSV HEADER;

COPY kunde_details
	FROM '@BASEDIR@/csv/kunde_details.csv'
	DELIMITER ';' CSV HEADER;

COPY hska_role
	FROM '@BASEDIR@/csv/hska_role.csv'
	DELIMITER ';' CSV HEADER;

COPY betreuer
	FROM '@BASEDIR@/csv/betreuer.csv'
	DELIMITER ';' CSV HEADER;

COPY wartungsvertrag
	FROM '@BASEDIR@/csv/wartungsvertrag.csv'
	DELIMITER ';' CSV HEADER;

COPY geschenkverpackung
	FROM '@BASEDIR@/csv/geschenkverpackung.csv'
	DELIMITER ';' CSV HEADER;

COPY bestellung
	FROM '@BASEDIR@/csv/bestellung.csv'
	DELIMITER ';' CSV HEADER;

COPY lieferung
	FROM '@BASEDIR@/csv/lieferung.csv'
	DELIMITER ';' CSV HEADER;

COPY bestellung_lieferung
	FROM '@BASEDIR@/csv/bestellung_lieferung.csv'
	DELIMITER ';' CSV HEADER;

COPY kontakt
	FROM '@BASEDIR@/csv/kontakt.csv'
	DELIMITER ';' CSV HEADER;

COPY kunde_kontakt
	FROM '@BASEDIR@/csv/kunde_kontakt.csv'
	DELIMITER ';' CSV HEADER;
	