SET search_path TO hska;

-- Anmerkung zu SERIAL und SEQUENCE:
--    CREATE TABLE tablename (colname SERIAL);
--       entspricht
--    CREATE SEQUENCE tablename_colname_seq;
--    CREATE TABLE tablename( colname INTEGER DEFAULT nextval('tablename_colname_seq') NOT NULL);
--
--    SERIAL8 basiert auf BIGINT: fuer 2**31 verschiedene IDs

-- Anmerkung zu Constraints, z.B. NOT NULL, und zu INDEX:
--   Besser waere es CREATE TABLE ohne Constraints und INDEXE durchzufuehren,
--   anschliessend die Tabellen mit konsistenten Daten zu befuellen und danach
--   erst die CONSTRAINTS mit ALTER TABLE zu definieren sowie CREATE INDEX
--   durchzufuehren.
--   Wenn gleich zu Beginn die Constraints definiert werden, werden sie
--   bei jedem Einfuegen eines (konsistenten!) Datensatzes unnoetigerweise
--   ueberprueft. Deshalb dauert der Einfuegevorgang laenger als noetig!


CREATE TABLE kunde(
	k_id SERIAL NOT NULL PRIMARY KEY,
	version INTEGER DEFAULT 0,
	nachname VARCHAR(32) NOT NULL,
	vorname VARCHAR(32),
	kundennr VARCHAR(8) NOT NULL UNIQUE,
	seit DATE,
	art CHAR(1) DEFAULT 'P',
	plz INTEGER NOT NULL,
	ort VARCHAR(32) NOT NULL,
	strasse VARCHAR(32),
	hausnr VARCHAR(4),
	familienstand INTEGER,
	rabatt INTEGER,
	password text NOT NULL,
	erzeugt TIMESTAMP NOT NULL,
	aktualisiert TIMESTAMP NOT NULL
);

CREATE TABLE kunde_details(
	kunde_fk INTEGER NOT NULL PRIMARY KEY,
	version INTEGER DEFAULT 0,
	details TEXT NOT NULL,
	FOREIGN KEY (kunde_fk) REFERENCES kunde(k_id)
);


CREATE TABLE hska_role(
	username VARCHAR(8) NOT NULL,
	role VARCHAR(16),
	FOREIGN KEY (username) REFERENCES kunde(kundennr)
);
CREATE INDEX hska_role_username_index ON hska_role(username);


CREATE TABLE betreuer(
	b_id SERIAL NOT NULL PRIMARY KEY,
	version INTEGER DEFAULT 0,
	name VARCHAR(32) NOT NULL,
	kunde_fk INTEGER NOT NULL,
	FOREIGN KEY (kunde_fk) REFERENCES kunde(k_id)
);
CREATE INDEX betreuer_kunde_index ON betreuer(kunde_fk);


CREATE TABLE wartungsvertrag(
	nr INTEGER NOT NULL,
	datum DATE NOT NULL,
	version INTEGER DEFAULT 0,
	inhalt TEXT DEFAULT '',
	kunde_fk INTEGER NOT NULL,
	PRIMARY KEY(nr, datum),
	FOREIGN KEY (kunde_fk) REFERENCES kunde(k_id)
);


CREATE TABLE kontakt(
	ko_id SERIAL NOT NULL PRIMARY KEY,
	version INTEGER DEFAULT 0,
	datum DATE NOT NULL,
	inhalt TEXT DEFAULT ''
);


CREATE TABLE kunde_kontakt(
	kunde_fk INTEGER NOT NULL,
	kontakt_fk INTEGER NOT NULL,
	PRIMARY KEY(kunde_fk, kontakt_fk),
	FOREIGN KEY (kunde_fk) REFERENCES kunde(k_id),
	FOREIGN KEY (kontakt_fk) REFERENCES kontakt(ko_id)
);


CREATE TABLE geschenkverpackung(
	g_id SERIAL NOT NULL PRIMARY KEY,
	version INTEGER DEFAULT 0,
	art VARCHAR(11) NOT NULL,
	text TEXT
);


CREATE TABLE bestellung(
	b_id SERIAL NOT NULL PRIMARY KEY,
	version INTEGER DEFAULT 0,
	text VARCHAR(32) NOT NULL,
	kunde_fk INTEGER NOT NULL,
	geschenkverpackung_fk INTEGER,
	FOREIGN KEY (kunde_fk) REFERENCES kunde(k_id),
	FOREIGN KEY (geschenkverpackung_fk) REFERENCES geschenkverpackung(g_id)
);
CREATE INDEX bestellung_kunde_index ON bestellung(kunde_fk);
CREATE INDEX bestellung_geschenkverpackung_index ON bestellung(geschenkverpackung_fk);


CREATE TABLE lieferung(
	l_id SERIAL NOT NULL PRIMARY KEY,
	version INTEGER DEFAULT 0,
	liefernr VARCHAR(12) NOT NULL UNIQUE,
	transport_art VARCHAR(7)
);


CREATE TABLE bestellung_lieferung(
	bestellung_fk INTEGER NOT NULL,
	lieferung_fk INTEGER NOT NULL,
	PRIMARY KEY(bestellung_fk, lieferung_fk),
	FOREIGN KEY (lieferung_fk) REFERENCES lieferung(l_id),
	FOREIGN KEY (bestellung_fk) REFERENCES bestellung(b_id)
);
