SET search_path TO hska;

DROP TABLE bestellung_lieferung;

DROP TABLE lieferung;

DROP INDEX bestellung_kunde_index;
DROP INDEX bestellung_geschenkverpackung_index;
DROP TABLE bestellung;

DROP TABLE geschenkverpackung;


DROP TABLE kunde_kontakt;
DROP TABLE kontakt;


DROP INDEX betreuer_kunde_index;
DROP TABLE betreuer;


DROP TABLE wartungsvertrag;

DROP INDEX hska_role_username_index;
DROP TABLE hska_role;
DROP TABLE kunde_details;
DROP TABLE kunde;

