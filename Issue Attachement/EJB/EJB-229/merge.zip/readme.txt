Directories
* hska: project to build the EAR file and deployment for JBoss
* hskaDB: database project for PostgreSQL 8.1.4
* hskaEJB: project for EJB3 with session beans and entities
* hskaTestClient: project for an EJB3 client with JUnit4

Database setup for PostgreSQL 8.1.4
* cd hska
  ant db-load
* assumption: superuser = postgres
              password is empty
  can be changed in hskaDB/postgresql/build.properties
  ** db.admin
  ** db.admin.password
* A new database is created: hskadb
                    Account: hska
                   Password: hskapassword
* In %JBOSS_HOME%\server\default\deploy\postgres-ds.xml
  the database hskadb has to be inserted as a datasource.

Deployment and test:
* cd hska
  ant deploy
  <Start JBoss>
  ant test
* Find the JUnit report in hskaTestClient\log\junit-html
* Failure in hskaEJB\ejbModule\de\hska\kundenverwaltung\db\KundenverwaltungDAO.java
  in line 187

Resetting the database:
* cd hska
  ant db-reload