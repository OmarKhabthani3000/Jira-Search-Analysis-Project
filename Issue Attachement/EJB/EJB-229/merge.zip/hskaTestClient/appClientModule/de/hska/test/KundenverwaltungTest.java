package de.hska.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import static de.hska.util.EjbConstants.LOGIN_DOMAIN_HSKA;
import static de.hska.util.EjbUtil.login;
import static de.hska.util.EjbUtil.logout;
import static de.hska.util.EjbUtil.getKundenverwaltung;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.ejb.EJBAccessException;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.login.LoginContext;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hska.kundenverwaltung.KundeCreateAdresseException;
import de.hska.kundenverwaltung.KundeDeleteBestellungException;
import de.hska.kundenverwaltung.Kundenverwaltung;
import de.hska.kundenverwaltung.db.Adresse;
import de.hska.kundenverwaltung.db.Betreuer;
import de.hska.kundenverwaltung.db.BetreuerNotFoundException;
import de.hska.kundenverwaltung.db.Kontakt;
import de.hska.kundenverwaltung.db.KontaktNotFoundException;
import de.hska.kundenverwaltung.db.Kunde;
import de.hska.kundenverwaltung.db.KundeNotFoundException;
import de.hska.kundenverwaltung.db.Privatkunde;
import de.hska.kundenverwaltung.db.Wartungsvertrag;
import de.hska.kundenverwaltung.db.WartungsvertragNotFoundException;

public class KundenverwaltungTest {
	private static final String USERNAME = "AlAl-001";
	private static final String PASSWORD = "AlAl-001password";
	private static final String PASSWORD_FALSCH = "wrongpassword";
	private static final String USERNAME_ADMIN = "AlAd-001";
	private static final String PASSWORD_ADMIN = "AlAd-001password";

	private static final String VORHANDENER_KUNDE_NACHNAME = "Alpha";
	private static final String NICHT_VORHANDENER_KUNDE_NACHNAME = "Beta";
	private static final int VORHANDENE_PLZ = 76133;
	private static final int NICHT_VORHANDENE_PLZ = 11111;
	private static final Long VORHANDENE_BETREUER_ID = Long.valueOf(41);
	private static final Long NICHT_VORHANDENE_BETREUER_ID = Long.valueOf(0);
	private static final Long KUNDE_ID_MIT_WARTUNGSVERTRAG = Long.valueOf(1);
	private static final Long KUNDE_ID_OHNE_WARTUNGSVERTRAG = Long.valueOf(3);
	private static final String NEUER_KUNDE_NACHNAME = "Alpha";
	private static final String NEUER_KUNDE_NR = "Al__-001";
	private static final String NEUER_KUNDE_PASSWORD = "Al__-001password";
	private static final int NEUER_KUNDE_PLZ = 76133;
	private static final String NEUER_KUNDE_ORT = "Karlsruhe";
	private static final String NEUER_KUNDE_STRASSE = "Moltkestra�e";
	private static final String NEUER_KUNDE_HAUSNR = "40";
	private static final Long DELETE_KUNDE_ID_MIT_BESTELLUNGEN = Long.valueOf(2);
	private static final Long DELETE_KUNDE_ID_OHNE_BESTELLUNGEN = Long.valueOf(3);
	private static final Long NACHNAME_AENDERN_KUNDE_ID = Long.valueOf(4);
	private static final String NACHNAME_AENDERN_NEUER_NACHNAME = "Deltaa";
	private static final Long KUNDE_ID_MIT_KONTAKTEN = Long.valueOf(1);
	private static final Long KUNDE_ID_OHNE_KONTAKTE = Long.valueOf(2);
	private static final Long VORHANDENER_KUNDE_ID_PASSWORD = Long.valueOf(4);
	private static final String NEUES_PASSWORD = "P1";

	private Kundenverwaltung kv;

	private LoginContext loginCtx;

	/**
	 */
	@Before
	public void setUp() throws Exception {
		kv = getKundenverwaltung();
		loginCtx = login(LOGIN_DOMAIN_HSKA, USERNAME, PASSWORD);	
	}
	
	/**
	 */
	@After
	public void tearDown() throws Exception {
		logout(loginCtx);	
		kv = null;
	}

	/**
	 */
	@Test
	public void findKundenMitNachnameVorhanden() throws KundeNotFoundException {
		final Collection<Kunde> kunden = kv.findKunden(VORHANDENER_KUNDE_NACHNAME);
		for (Kunde k: kunden) {
			assertEquals(VORHANDENER_KUNDE_NACHNAME, k.getNachname());
		}
	}
	
	/**
	 */
	@Test
	public void findKundenMitNachnameNichtVorhanden() {
		try {
			kv.findKunden(NICHT_VORHANDENER_KUNDE_NACHNAME);
		}
		catch (KundeNotFoundException e) {
			assertEquals(NICHT_VORHANDENER_KUNDE_NACHNAME, e.getNachname());
			return;
		}
		fail("Kunden gefunden trotz NICHT-VORHANDENEM Nachnamen");
	}

	/**
	 */
	@Test
	public void findKundenMitPLZVorhanden() throws KundeNotFoundException {
		final Collection<Kunde> kunden = kv.findKundenByPLZ(VORHANDENE_PLZ);
		assertFalse(kunden.isEmpty());
		for (Kunde k: kunden) {
			assertNotNull(k.getAdresse());
			assertEquals(VORHANDENE_PLZ, k.getAdresse().getPlz());
		}
	}

	/**
	 */
	@Test
	public void findKundenMitPLZNichtVorhanden() {
		try {
			kv.findKundenByPLZ(NICHT_VORHANDENE_PLZ);
		}
		catch (KundeNotFoundException e) {
			assertEquals(NICHT_VORHANDENE_PLZ, e.getPlz());
			return;
		}
		fail("Kunde gefunden trotz NICHT-VORHANDENER Plz");
	}

	/**
	 */
	@Test
	public void findBetreuerVorhanden() throws BetreuerNotFoundException {
		final Betreuer betreuer = kv.findBetreuer(VORHANDENE_BETREUER_ID);
		assertNotNull(betreuer);
		final Kunde kunde = betreuer.getKunde();
		assertNotNull(kunde);
		assertSame(betreuer, kunde.getBetreuer());
	}

	/**
	 */
	@Test
	public void findBetreuerNichtVorhanden() {
		try {
			kv.findBetreuer(NICHT_VORHANDENE_BETREUER_ID);
		}
		catch (BetreuerNotFoundException e) {
			assertEquals(NICHT_VORHANDENE_BETREUER_ID, e.getId());
			return;
		}
		fail("Betreuer gefunden trotz NICHT-VORHANDENER ID=" + NICHT_VORHANDENE_BETREUER_ID);
	}
	
	/**
	 */
	@Test
	public void findWartungsvertraegeVorhanden() throws WartungsvertragNotFoundException {
		final Collection<Wartungsvertrag> wartungsvertraege = kv.findWartungsvertraege(KUNDE_ID_MIT_WARTUNGSVERTRAG);
		assertFalse(wartungsvertraege.isEmpty());
		for (Wartungsvertrag w: wartungsvertraege) {
			final Kunde k = w.getKunde();
			assertNotNull(k);
			assertEquals(KUNDE_ID_MIT_WARTUNGSVERTRAG, k.getId());
		}
	}

	/**
	 */
	@Test
	public void findWartungsvertraegeNichtVorhanden() {
		try {
			kv.findWartungsvertraege(KUNDE_ID_OHNE_WARTUNGSVERTRAG);
		}
		catch (WartungsvertragNotFoundException e) {
			assertEquals(KUNDE_ID_OHNE_WARTUNGSVERTRAG, e.getId());
			return;
		}
		fail("Wartungsvertraege gefunden obwohl der Kunde KEINE hat: ID=" + KUNDE_ID_OHNE_WARTUNGSVERTRAG);
	}

	/**
	 */
	@Test
	public void createKunde() throws KundeCreateAdresseException {
		final Collection<Kunde> kundenVorher = kv.findAllKunden();

		Kunde neuerKunde = new Privatkunde();
		neuerKunde.setNachname(NEUER_KUNDE_NACHNAME);
		neuerKunde.setKundennr(NEUER_KUNDE_NR);
		neuerKunde.setPassword(NEUER_KUNDE_PASSWORD);
		final Adresse adresse = new Adresse(NEUER_KUNDE_PLZ, NEUER_KUNDE_ORT, NEUER_KUNDE_STRASSE, NEUER_KUNDE_HAUSNR);
		neuerKunde.setAdresse(adresse);

		final Date datumVorher = new Date();
		
		Collection<Kunde> neueKunden = new ArrayList<Kunde>(1);
		neueKunden.add(neuerKunde);
		neueKunden = kv.createKunden(neueKunden);

		assertEquals(1, neueKunden.size());
		neuerKunde = neueKunden.iterator().next();
		
		assertTrue(datumVorher.getTime() < neuerKunde.getErzeugt().getTime());

		final Collection<Kunde> kundenNachher = kv.findAllKunden();
		
		assertEquals(kundenVorher.size()+1, kundenNachher.size());
		for (Kunde k: kundenVorher) {
			assertTrue(k.getId() < neuerKunde.getId());
			assertTrue(k.getErzeugt().getTime() < neuerKunde.getErzeugt().getTime());
		}
	}
	
	/**
	 */
	@Test
	public void createKundeOhneAdresse() {
		final Kunde neuerKunde = new Privatkunde();
		neuerKunde.setNachname(NEUER_KUNDE_NACHNAME);
		neuerKunde.setAdresse(null);
		Collection<Kunde> neueKunden = new ArrayList<Kunde>(1);
		neueKunden.add(neuerKunde);
		
		try {
			kv.createKunden(neueKunden);
		}
		catch (KundeCreateAdresseException e) {
		    // Exception muss geworfen werden: neuer Kunde hat keine Adresse
			return;
		}
		fail("Kunde OHNE Adresse erzeugt");
	}
	
	/**
	 */
	@Test
	public void deleteKundeOhneBestellungen() throws KundeDeleteBestellungException, KundeNotFoundException {
		logout(loginCtx);
		loginCtx = login(LOGIN_DOMAIN_HSKA, USERNAME_ADMIN, PASSWORD_ADMIN);

		final Collection<Kunde> kundenVorher = kv.findAllKunden();

		final Kunde kunde = kv.findKundeMitBestellungen(DELETE_KUNDE_ID_OHNE_BESTELLUNGEN);
		assertNotNull(kunde);
		
		final Collection<Kunde> kunden = new ArrayList<Kunde>(1);
		kunden.add(kunde);
		kv.deleteKunden(kunden);

		final Collection<Kunde> kundenNachher = kv.findAllKunden();
		
		assertEquals(kundenVorher.size()-1, kundenNachher.size());
	}

	/**
	 */
	@Test
	public void deleteKundeMitBestellungen() throws KundeNotFoundException {
		logout(loginCtx);
		loginCtx = login(LOGIN_DOMAIN_HSKA, USERNAME_ADMIN, PASSWORD_ADMIN);

		final Kunde kunde = kv.findKundeMitBestellungen(DELETE_KUNDE_ID_MIT_BESTELLUNGEN);
		assertNotNull(kunde);

		final Collection<Kunde> kunden = new ArrayList<Kunde>(1);
		kunden.add(kunde);
		try {
			kv.deleteKunden(kunden);
		}
		catch (KundeDeleteBestellungException e) {
			// Exception muss geworfen werden: zu loeschender Kunde hat Bestellungen
			return;
		}

		fail("Kunde MIT Bestellungen geloescht: ID=" + DELETE_KUNDE_ID_MIT_BESTELLUNGEN);
	}
	
	/**
	 */
	@Test
	public void neuerNameFuerKunde() throws KundeNotFoundException {
		Kunde kunde = kv.findKunde(NACHNAME_AENDERN_KUNDE_ID);
		assertNotNull(kunde);
		kunde.setNachname(NACHNAME_AENDERN_NEUER_NACHNAME);

		Collection<Kunde> kunden = new ArrayList<Kunde>(1);
		kunden.add(kunde);
		kunden = kv.updateKunden(kunden);

		assertTrue(1 == kunden.size());
		kunde = kunden.iterator().next();
		assertNotNull(kunde);
		assertEquals(NACHNAME_AENDERN_NEUER_NACHNAME, kunde.getNachname());
		
		kunde = kv.findKunde(NACHNAME_AENDERN_KUNDE_ID);
		assertNotNull(kunde);
		assertEquals(NACHNAME_AENDERN_NEUER_NACHNAME, kunde.getNachname());
	}

	/**
	 */
	@Test
	public void findKontakte() throws KontaktNotFoundException {
		final Collection<Kontakt> kontakte = kv.findKontakteByKundeId(KUNDE_ID_MIT_KONTAKTEN);
		assertFalse(kontakte.isEmpty());
	}

	/**
	 */
	@Test
	public void findKeineKontakte() {
		try {
			kv.findKontakteByKundeId(KUNDE_ID_OHNE_KONTAKTE);
		}
		catch (KontaktNotFoundException e) {
			assertEquals(KUNDE_ID_OHNE_KONTAKTE, e.getId());
			return;
		}
		fail("Kontakte gefunden obwohl der Kunde KEINE hat: ID=" + KUNDE_ID_OHNE_KONTAKTE);
	}
	
	/**
	 */
	@Test
	public void setUndCheckPassword() throws KundeNotFoundException {
		Kunde kunde = kv.findKunde(VORHANDENER_KUNDE_ID_PASSWORD);
		assertNotNull(kunde);
		kunde = kv.setPassword(kunde, NEUES_PASSWORD);

		kunde = kv.findKunde(VORHANDENER_KUNDE_ID_PASSWORD);
		boolean result = kv.checkPassword(kunde, NEUES_PASSWORD);
		assertTrue(result);

		result = kv.checkPassword(kunde, PASSWORD_FALSCH);
		assertFalse(result);
	}
	
	/**
	 */
	@Test
	public void fehlendeBerechtigung() throws KundeNotFoundException, KundeDeleteBestellungException {
		Kunde kunde = kv.findKunde(DELETE_KUNDE_ID_MIT_BESTELLUNGEN);
		assertNotNull(kunde);

		final Collection<Kunde> kunden = new ArrayList<Kunde>(1);
		kunden.add(kunde);
		try {
			kv.deleteKunden(kunden);
		}
		catch (EJBAccessException e) {
			final Exception cause = e.getCausedByException();
			assertTrue(cause instanceof SecurityException);
			return;
		}
		fail("Delete durchgefuehrt, obwohl die Berechtigung FEHLT");
	}

	/**
	 */
	@Test
	public void falschesPassword() throws KundeNotFoundException {
		logout(loginCtx);
		loginCtx = login(LOGIN_DOMAIN_HSKA, USERNAME, PASSWORD_FALSCH);
		try {
			kv.findKunden(VORHANDENER_KUNDE_NACHNAME);
		}
		catch(EJBAccessException e) {
			final Exception cause = e.getCausedByException();
			assertTrue(cause instanceof FailedLoginException);
			return;
		}

		fail("Operation durchgefuehrt trotz FALSCHEM Password");
	}
}