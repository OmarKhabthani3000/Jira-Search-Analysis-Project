package de.hska.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import static de.hska.util.EjbConstants.LOGIN_DOMAIN_HSKA;
import static de.hska.util.EjbUtil.login;
import static de.hska.util.EjbUtil.logout;
import static de.hska.util.EjbUtil.getBestellwesen;

import java.util.Collection;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.security.auth.login.LoginContext;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hska.bestellwesen.Bestellwesen;
import de.hska.bestellwesen.db.Bestellung;
import de.hska.bestellwesen.db.Lieferung;
import de.hska.bestellwesen.db.LieferungNotFoundException;
import de.hska.kundenverwaltung.db.Kunde;
import de.hska.kundenverwaltung.db.KundeNotFoundException;
import de.hska.util.EjbNotFoundException;


public class BestellwesenTest {
	private static final String USERNAME = "AlAl-001";
	private static final String PASSWORD = "AlAl-001password";

	private static final String LIEFER_NR_VORHANDEN = "20051005%";
	private static final String LIEFER_NR_NICHT_VORHANDEN = "0%";
	private static final Long VORHANDENE_KUNDE_ID = Long.valueOf(1);
	private static final String TEXT_NEUE_BESTELLUNG = "Neue_Bestellung_Kunde_1";
	
	@EJB
	private Bestellwesen bw;

	@Resource
	private LoginContext loginCtx;


	/**
	 */
	@Before
	public void setUp() throws Exception {
		bw = getBestellwesen();		
		loginCtx = login(LOGIN_DOMAIN_HSKA, USERNAME, PASSWORD);
	}
	
	/**
	 */
	@After
	public void tearDown() throws Exception {
		logout(loginCtx);
		bw = null;
	}
	
	/**
	 */
	@Test
	public void findLieferungVorhanden() throws LieferungNotFoundException {
		final Collection<Lieferung> lieferungen = bw.findLieferungen(LIEFER_NR_VORHANDEN);
		assertFalse(lieferungen.isEmpty());

		final String lieferNrPraefix = LIEFER_NR_VORHANDEN.substring(0, LIEFER_NR_VORHANDEN.length()-2);
		for (Lieferung l: lieferungen) {
			assertTrue(l.getLieferNr().startsWith(lieferNrPraefix));

			final Collection<Bestellung> bestellungen = l.getBestellungen();
			assertFalse(bestellungen.isEmpty());
			for (Bestellung b: bestellungen) {
				assertNotNull(b.getKunde());
			}
		}
	}

	/**
	 */
	@Test
	public void findLieferungNichtVorhanden() {
		try {
			bw.findLieferungen(LIEFER_NR_NICHT_VORHANDEN);
		}
		catch (LieferungNotFoundException e) {
			assertEquals(LIEFER_NR_NICHT_VORHANDEN, e.getId());
			return;
		}
		fail("Lieferung gefunden obwohl die LieferNr NICHT existiert: " + LIEFER_NR_NICHT_VORHANDEN);
	}
	
	/**
	 */
	@Test
	public void neueBestellung() throws KundeNotFoundException, EjbNotFoundException {
		final Bestellung bestellung = bw.neueBestellung(VORHANDENE_KUNDE_ID, TEXT_NEUE_BESTELLUNG);
		assertNotNull(bestellung);
		final Kunde kunde = bestellung.getKunde();
		assertNotNull(kunde);
		assertEquals(VORHANDENE_KUNDE_ID, bestellung.getKunde().getId());
	}
}