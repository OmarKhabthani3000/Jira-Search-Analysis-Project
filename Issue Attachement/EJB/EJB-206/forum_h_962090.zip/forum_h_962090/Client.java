import javax.persistence.*;
import java.util.*;

public class Client {
 private static EntityManagerFactory emf;
 public static void main(String[] args) throws Exception {
   emf = Persistence.createEntityManagerFactory("pu1");
   EntityManager em = emf.createEntityManager();
   em.getTransaction().begin();
   String id = args[0];
   Incident i = em.find(Incident.class, id);
   if (i == null) {
    i = new Incident(id);
    IncidentStatus ist = new IncidentStatus(id);
    i.setIncidentStatus(ist);
    ist.setIncident(i);
    em.persist(i);
   } 
   System.out.println(i);
   em.getTransaction().commit();
   em.close();
 }
}
