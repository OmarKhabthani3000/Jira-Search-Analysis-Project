
EJB3PendingOrderPersistenceTests contains the test that fails 
because the orphaned PendingOrderLineItem was not deleted