/* Copyright 2005. Chris Richardson (cer@acm.org). All rights reserved. */

/* Copyright (c) 2002 Chris Richardson. All Rights Reserved */


package net.chrisrichardson.foodToGo.util;

import java.io.*;


public class NotYetImplementedException extends RuntimeException {
    private Exception e;

    public NotYetImplementedException(Exception e) {
    	this.e = e;
    }

    public NotYetImplementedException() {
        super("Not Yet Implemented");
    }

    public NotYetImplementedException(String m) {
        super("Not Yet Implemented:" + m);
    }
	public void printStackTrace() {
		super.printStackTrace();
		if (e != null) {
			System.out.println("Nested exception -----");
			e.printStackTrace();
		}

	}

	public void printStackTrace(PrintStream arg0) {
		super.printStackTrace(arg0);
		if (e != null) {
			arg0.println("Nested exception -----");
			e.printStackTrace(arg0);
		}
	}

	public void printStackTrace(PrintWriter arg0) {
		super.printStackTrace(arg0);
		if (e != null) {
			arg0.println("Nested exception -----");
			e.printStackTrace(arg0);
		}
	}
}
