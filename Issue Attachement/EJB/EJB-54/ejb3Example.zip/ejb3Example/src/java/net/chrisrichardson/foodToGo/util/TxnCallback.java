/* Copyright 2005. Chris Richardson (cer@acm.org). All rights reserved. */

package net.chrisrichardson.foodToGo.util;


public interface TxnCallback {
    public void execute() throws Throwable;
}