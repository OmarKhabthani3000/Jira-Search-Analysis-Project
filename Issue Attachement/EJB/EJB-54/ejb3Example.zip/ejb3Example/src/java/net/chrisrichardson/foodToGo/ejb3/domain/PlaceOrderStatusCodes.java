/* Copyright 2005. Chris Richardson (cer@acm.org). All rights reserved. */

package net.chrisrichardson.foodToGo.ejb3.domain;


public interface PlaceOrderStatusCodes {

    public static final int OK = 99;
    public static final int CONFIRM_CHANGE = 1;
    public static final int INVALID_DELIVERY_INFO = 2;
    public static final int DOES_NOT_MEET_MINIMUM = 3;
    

}
