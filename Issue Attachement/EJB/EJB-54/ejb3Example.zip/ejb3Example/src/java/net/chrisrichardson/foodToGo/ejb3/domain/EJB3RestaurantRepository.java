/* Copyright 2005. Chris Richardson (cer@acm.org). All rights reserved. */

package net.chrisrichardson.foodToGo.ejb3.domain;

import java.util.*;

import javax.ejb.*;
import javax.persistence.*;

@Stateless
public class EJB3RestaurantRepository implements
        RestaurantRepository {

    @PersistenceContext
    private EntityManager entityManager;

    public EJB3RestaurantRepository() {
        
    }
    
    public EJB3RestaurantRepository(
            EntityManager entityManager) {
        this.entityManager = entityManager;

    }

    public Restaurant findRestaurant(
            String restaurantId) {
        return entityManager.find(Restaurant.class,
                new Integer(restaurantId));
    }

    public List findAvailableRestaurants(
            Address deliveryAddress, Date deliveryTime) {
        Query query = entityManager
                .createNamedQuery("Restaurant.findAvailableRestaurants");
        Calendar c = Calendar.getInstance();
        c.setTime(deliveryTime);
        int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);
        String zipCode = deliveryAddress.getZip();

        query.setParameter("dayOfWeek", new Integer(
                dayOfWeek));
        query.setParameter("hour", new Integer(hour));
        query.setParameter("minute", new Integer(
                minute));
        query.setParameter("zipCode", new Integer(
                zipCode));
        return query.getResultList();

    }

    public boolean isRestaurantAvailable(
            Address deliveryAddress, Date deliveryDate) {
        return !findAvailableRestaurants(
                deliveryAddress, deliveryDate)
                .isEmpty();
    }

    public void setEntityManager(
            EntityManager entityManager) {
        this.entityManager = entityManager;
    }

}