/* Copyright 2005. Chris Richardson (cer@acm.org). All rights reserved. */

/* Copyright (c) 2002 Chris Richardson. All Rights Reserved */

package net.chrisrichardson.foodToGo.ejb3.domain;

import java.io.*;
import javax.persistence.*;

@Entity(access = AccessType.FIELD)
@Table(name = "FTGO_PENDING_ORDER_LINE_ITEM")
public class PendingOrderLineItem implements
        Serializable {

    @Id(generate = GeneratorType.AUTO)
    private int id;

    @ManyToOne
    @JoinColumn(name = "item_id")
    private MenuItem menuItem;

    private int quantity;

    @SuppressWarnings("unused")
    @Column(name="LINE_ITEM_INDEX")
    private int index;

    public PendingOrderLineItem() {
    }

    public int getId() {
        return id;
    }

    public PendingOrderLineItem(int index,
            int quantity, MenuItem menuItem) {
        this.index = index;
        this.quantity = quantity;
        this.menuItem = menuItem;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public MenuItem getMenuItem() {
        return menuItem;
    }

    public String getName() {
        return menuItem.getName();
    }

    public double getPrice() {
        return menuItem.getPrice();
    }

    public void setMenuItem(MenuItem item) {
        this.menuItem = (MenuItem) item;
    }

    public double getExtendedPrice() {
        return getPrice() * getQuantity();
    }


}
