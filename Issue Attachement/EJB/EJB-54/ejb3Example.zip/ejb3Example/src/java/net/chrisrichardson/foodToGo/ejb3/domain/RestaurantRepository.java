/* Copyright 2005. Chris Richardson (cer@acm.org). All rights reserved. */

package net.chrisrichardson.foodToGo.ejb3.domain;

import java.util.*;

import javax.ejb.*;

@Local
public interface RestaurantRepository {

    public List findAvailableRestaurants(
        Address deliveryAddress,
        Date deliveryTime);

    public boolean isRestaurantAvailable(Address deliveryAddress, Date deliveryDate);

    public Restaurant findRestaurant(String restaurantId);


}
