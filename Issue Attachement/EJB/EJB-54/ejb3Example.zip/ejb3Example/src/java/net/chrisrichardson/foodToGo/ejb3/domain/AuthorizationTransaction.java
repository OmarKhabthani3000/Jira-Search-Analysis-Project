/* Copyright 2005. Chris Richardson (cer@acm.org). All rights reserved. */

package net.chrisrichardson.foodToGo.ejb3.domain;

import java.util.*;

/**
 * The result of authorizing a credit card
 */

public interface AuthorizationTransaction {   
    
    public static int AUTHORIZED = 1;
    public static int REJECTED = 2;
    public static int PENDING = 3;
    
    public int getStatus();
    public Date getCreationDate();
    public Date getAuthorizationDate();
    public PaymentInformation getPaymentInformation();

}
