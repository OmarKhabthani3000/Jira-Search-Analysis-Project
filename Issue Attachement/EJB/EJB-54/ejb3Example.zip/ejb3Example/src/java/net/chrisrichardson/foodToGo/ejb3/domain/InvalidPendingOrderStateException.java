/* Copyright 2005. Chris Richardson (cer@acm.org). All rights reserved. */

/* Copyright (c) 2002 Chris Richardson. All Rights Reserved */


package net.chrisrichardson.foodToGo.ejb3.domain;

public class InvalidPendingOrderStateException extends Exception {
    public InvalidPendingOrderStateException() {
    }

    public InvalidPendingOrderStateException(String s) {
        super(s);
    }

}
