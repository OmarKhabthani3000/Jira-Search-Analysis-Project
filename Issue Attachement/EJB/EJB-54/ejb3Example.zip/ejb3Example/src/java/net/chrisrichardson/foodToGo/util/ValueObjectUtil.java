/* Copyright 2005. Chris Richardson (cer@acm.org). All rights reserved. */

package net.chrisrichardson.foodToGo.util;


public class ValueObjectUtil {

	public static boolean safeEquals(String x, String y) {
	    return (x == null || y == null) ? x == y : x.equals(y);
	}
	public static int safeHash(String x) {
	    return x == null ? 0 : x.hashCode();
	}
}
