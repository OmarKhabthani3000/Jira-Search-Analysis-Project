/* Copyright 2005. Chris Richardson (cer@acm.org). All rights reserved. */

package net.chrisrichardson.foodToGo.ejb3.domain;

import java.io.*;

public interface Coupon extends Serializable {
    public double getDeliveryChargeDiscount(PendingOrder order);

    public double getSubtotalDiscount(PendingOrder order);

    public String getCode();
    
    public int getId();
}

/*
@Entity(access = AccessType.FIELD)
@Table(name = "FTGO_COUPON")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE, discriminatorType = DiscriminatorType.STRING)
@DiscriminatorColumn(name = "COUPON_TYPE", nullable = true)
public abstract class Coupon implements Serializable {

    @Id(generate = GeneratorType.AUTO)
    private int id;

    private String code;

    public Coupon() {
    }

    private Coupon(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public abstract double getDeliveryChargeDiscount(
            PendingOrder pendingOrder);

    public abstract double getSubtotalDiscount(
            PendingOrder pendingOrder);

}

*/
