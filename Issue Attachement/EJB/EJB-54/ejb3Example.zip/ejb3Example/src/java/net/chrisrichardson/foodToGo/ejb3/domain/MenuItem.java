/* Copyright 2005. Chris Richardson (cer@acm.org). All rights reserved. */

package net.chrisrichardson.foodToGo.ejb3.domain;

import java.io.*;
import javax.persistence.*;

@Entity (access=AccessType.FIELD)
@Table(name="MENU_ITEM")
public class MenuItem implements Serializable {

    // begin(fields)

    @Id(generate = GeneratorType.AUTO)
    private int id;

    private int version;

    private String name;

    private double price;

    
    // end(fields)

    // begin(methods)

    public MenuItem() {
    }

    public MenuItem(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setName(String name) {
        this.name = name;
    }

    // end(methods)
}