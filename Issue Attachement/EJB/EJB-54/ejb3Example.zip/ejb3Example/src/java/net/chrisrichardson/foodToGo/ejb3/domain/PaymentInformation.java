/* Copyright 2005. Chris Richardson (cer@acm.org). All rights reserved. */

/* Copyright (c) 2002 Chris Richardson. All Rights Reserved */


package net.chrisrichardson.foodToGo.ejb3.domain;

import java.io.*;

import javax.persistence.*;
/**
 * Contains the payment information of an order or pending order
 */

@Embeddable(access = AccessType.FIELD)
public class PaymentInformation implements Serializable {
    private String type;
    private String name;
    private String number;
    private int month;
    private int year;
    
    @Embedded
    @AttributeOverrides
    ( {
        @AttributeOverride(name = "street1", column = @Column(name = "PAYMENT_STREET1") ),
        @AttributeOverride(name = "street2", column = @Column(name = "PAYMENT_STREET2") ),
        @AttributeOverride(name = "city", column = @Column(name = "PAYMENT_CITY")),
        @AttributeOverride(name = "state", column = @Column(name = "PAYMENT_STATE")),
        @AttributeOverride(name = "zip", column = @Column(name = "PAYMENT_ZIP")) })
    private Address address;

    public PaymentInformation() {
    }

    public PaymentInformation(String type, String name, String number, int month, int year, Address address) {
        this.type = type;
        this.name = name;
        this.number = number;
        this.month = month;
        this.year = year;
        this.address = address;
    }

    public String getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public String getNumber() {
        return number;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    public Address getAddress() {
        return address;
    }
}
