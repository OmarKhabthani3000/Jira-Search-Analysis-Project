/* Copyright 2005. Chris Richardson (cer@acm.org). All rights reserved. */

package net.chrisrichardson.foodToGo.ejb3.domain;

import java.io.*;

import javax.persistence.*;

@Entity (access=AccessType.FIELD)
@Table(name="ZIP_CODE")
public class ZipCode implements Serializable {

    @Id
    private String zipCode;

    ZipCode() {
        
    }
    
    public ZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getZipCode() {
        return zipCode;
    }

}
