package test;

import java.util.Set;
import java.util.TreeSet;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import test.ejb.Famille;
import test.ejb.Produit;
import test.ejb.Stock;
import test.ejb.dao.ProduitDAO;
import test.ejb.facade.ProduitSessionFacadeBean;
import junit.framework.TestCase;

public class ProduitSessionFacadeTest extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
		System.setProperty("java.naming.factory.initial","org.jnp.interfaces.NamingContextFactory");
		System.setProperty("java.naming.provider.url","jnp://localhost:1099");
		System.setProperty("java.naming.factory.url.pkgs","org.jboss.naming:org.jnp.interfaces");
		
	}

	/*
	 * Test method for 'test.ejb.facade.ProduitSessionFacadeBean.sauver(Produit)'
	 */
	public void testSauver() {
		Produit produit = new Produit();
		produit.setCodeProduit("P-006");
		Stock stock = new Stock();
		produit.setStock(stock);
		
		Set<Produit> produits = new TreeSet<Produit>();
		produits.add(produit);
		
		//
		Famille f = new Famille();
		f.setCodeFamille("F-003");
		f.setNomFamille("a");
		f.setProduits(produits);
		
		Famille f2 = new Famille();
		f2.setCodeFamille("F-004");
		f2.setNomFamille("b");
		f2.setProduits(produits);

		Set<Famille> familles = new TreeSet<Famille>();
		familles.add(f);
		familles.add(f2);
		
		
		produit.setFamilles(familles);
		
		try {
			InitialContext ctx = new InitialContext();
			ProduitDAO bean = (ProduitDAO)ctx.lookup(
					"ProduitSessionFacadeBean/remote");
			
			produit = bean.sauver(produit);
		} catch (NamingException e) {
			e.printStackTrace();
			fail();
			
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
			fail();
			
		}

	}

	/*
	 * Test method for 'test.ejb.facade.ProduitSessionFacadeBean.modifier(Produit)'
	 */
	/*public void testModifier() {

	}*/

}
