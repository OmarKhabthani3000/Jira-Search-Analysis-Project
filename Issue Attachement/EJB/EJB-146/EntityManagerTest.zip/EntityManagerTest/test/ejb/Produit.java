package test.ejb;

	import java.io.Serializable;
	import java.util.Set;
	import java.util.TreeSet;

	import javax.persistence.CascadeType;
	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.FetchType;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.JoinColumn;
	import javax.persistence.JoinTable;
	import javax.persistence.ManyToMany;
	import javax.persistence.OneToOne;
	import javax.persistence.Table;
	import javax.persistence.Version;

	@Entity
	@Table(name = "produit")
	public class Produit implements Serializable, Comparable
	{

		private long produitID;

		private String codeProduit;

		private String libelleProduit;

		private Set<Classe> classes;

		private Set<Famille> familles;

		private Stock stock;
		
		private long version;
		
		public Produit()
		{
			//this.stock = new Stock();
			//stock.setProduit(this);
			classes = new TreeSet<Classe>();
			familles = new TreeSet<Famille>();
		}

		@Version()
		@Column(name="version")
		public long getVersion()
		{
			return version;
		}

		public void setVersion(long version)
		{
			this.version = version;
		}

		@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE }, fetch = FetchType.EAGER)
		@JoinTable(name = "classe_produit", 
				   joinColumns = { @JoinColumn(name = "produit_id") }, 
				   inverseJoinColumns = { @JoinColumn(name = "classe_id") })
		public Set<Classe> getClasses()
		{
			return classes;
		}

		public void setClasses(Set<Classe> classes)
		{
			this.classes = classes;
		}

		@Column(name = "code_produit")
		public String getCodeProduit()
		{
			return codeProduit;
		}

		public void setCodeProduit(String codeProduit)
		{
			this.codeProduit = codeProduit;
		}

		@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE }, fetch = FetchType.EAGER )
		@JoinTable(name = "famille_produit", 
				   joinColumns = { @JoinColumn(name = "produit_id") }, 
				   inverseJoinColumns = { @JoinColumn(name = "famille_id") })	
		public Set<Famille> getFamilles()
		{
			return familles;
		}

		public void setFamilles(Set<Famille> familles)
		{
			this.familles = familles;
		}

		@Column(name = "libelle_produit")
		public String getLibelleProduit()
		{
			return libelleProduit;
		}

		public void setLibelleProduit(String libelleProduit)
		{
			this.libelleProduit = libelleProduit;
		}

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name = "produit_id")
		public long getProduitID()
		{
			return produitID;
		}

		public void setProduitID(long produitID)
		{
			this.produitID = produitID;
		}

		@OneToOne(cascade = {CascadeType.ALL})
		@JoinColumn(name = "stock_id")
		public Stock getStock()
		{
			return stock;
		}

		public void setStock(Stock stock)
		{
			this.stock = stock;
		}
		
		public boolean equals(Object obj)
		{
			if(obj == this)
				return true;
			if(!(obj instanceof Produit))
				return false;
			else
				return getCodeProduit().equalsIgnoreCase(((Produit)obj).getCodeProduit());
		}
		
		public int hashCode()
		{
			int result = 17;
			result = 37 * result + getCodeProduit().hashCode();
			return result;
		}
		
		public String toString()
		{
			return this.getLibelleProduit();
		}

		public int compareTo(Object obj)
		{
			if(!(obj instanceof Produit))
				return -1;
			else
			return this.getCodeProduit().compareTo(((Produit)obj).getCodeProduit());
		}
}
