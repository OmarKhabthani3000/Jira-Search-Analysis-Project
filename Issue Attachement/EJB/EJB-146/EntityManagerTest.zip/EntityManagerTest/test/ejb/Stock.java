package test.ejb;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;



@Entity
@Table(name = "stock")
public class Stock implements Serializable
{

	private long stockID;

	private int seuilAlerte;

	private long inventaire;

	private Produit produit;
	
	private long version;
	
	public Stock()
	{
		this.inventaire = 0;
	}

	@Version()
	@Column(name="version")
	public long getVersion()
	{
		return version;
	}

	public void setVersion(long version)
	{
		this.version = version;
	}

	@Column(name = "inventaire")
	public long getInventaire()
	{
		return inventaire;
	}

	public void setInventaire(long inventaire)
	{
		this.inventaire = inventaire;
	}

	@OneToOne(cascade = {CascadeType.ALL})
	@JoinColumn(name = "produit_id")
	public Produit getProduit()
	{
		return produit;
	}

	public void setProduit(Produit produit)
	{
		this.produit = produit;
	}

	@Column(name = "seuil_alerte")
	public int getSeuilAlerte()
	{
		return seuilAlerte;
	}

	public void setSeuilAlerte(int seuilAlerte)
	{
		this.seuilAlerte = seuilAlerte;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "stock_id")
	public long getStockID()
	{
		return stockID;
	}

	public void setStockID(long stockID)
	{
		this.stockID = stockID;
	}
	
	public boolean equals(Object obj)
	{
		if(obj == this)
			return true;
		if(!(obj instanceof Stock))
			return false;
		else
			return getProduit().equals(((Stock)obj).getProduit());
	}
	
	public int hashCode()
	{
		return getProduit().hashCode();
	}

}