package test.ejb.facade;

import java.util.Collection;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import test.ejb.Produit;
import test.ejb.dao.ProduitDAO;


@Stateless
public class ProduitSessionFacadeBean implements ProduitDAO
{
	@PersistenceContext
	private EntityManager manager;
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public Produit sauver(Produit produit)
	{
		return modifier(produit);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public Produit modifier(Produit produit)
	{
		manager.merge(produit);
		return findProduitByCode(produit.getCodeProduit());
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void supprimer(Produit produit)
	{
		manager.remove(produit);
	}

	//@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public Collection<Produit> selectAll()
	{
		return manager.createQuery("from Produit").getResultList();
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public Produit findProduitByID(long produitID)
	{
		Produit produit =
		 (Produit)manager.createQuery("from Produit p where p.produitID = ?1")
		.setParameter(1,produitID)
		.getSingleResult();
		manager.refresh(produit);
		return produit;
	}

	public Produit findProduitByCode(String codeProduit)
	{
		Produit produit =
			 (Produit) (Produit)manager.createQuery("from Produit p where p.codeProduit = ?1")
		.setParameter(1,codeProduit)
		.getSingleResult();
		
		manager.refresh(produit);
		return produit;
	}

}
