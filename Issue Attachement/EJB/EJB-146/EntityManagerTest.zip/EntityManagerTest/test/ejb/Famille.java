package test.ejb;


import java.io.Serializable;
import java.util.Collection;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Version;


@Entity
@Table(name = "famille")
public class Famille implements Serializable, Comparable
{

	private long familleID;

	private String codeFamille;

	private String nomFamille;

	private String description;

	private Set<Produit> produits;
	
	private long version;

	@Version()
	@Column(name = "version")
	public long getVersion()
	{
		return version;
	}

	public void setVersion(long version)
	{
		this.version = version;
	}

	@Column(name = "code_famille")
	public String getCodeFamille()
	{
		return codeFamille;
	}

	public void setCodeFamille(String codeFamille)
	{
		this.codeFamille = codeFamille;
	}

	@Column(name = "description")
	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "famille_id")
	public long getFamilleID()
	{
		return familleID;
	}

	public void setFamilleID(long familleID)
	{
		this.familleID = familleID;
	}

	@Column(name = "nom_famille")
	public String getNomFamille()
	{
		return nomFamille;
	}

	public void setNomFamille(String nomFamille)
	{
		this.nomFamille = nomFamille;
	}

    @ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE }, fetch = FetchType.LAZY, mappedBy="familles" )
	public Set<Produit> getProduits()
	{
		return produits;
	}

	public void setProduits(Set<Produit> produits)
	{
		this.produits = produits;
	}
	
	public boolean equals(Object obj)
	{
		if(obj == this)
			return true;
		if(!(obj instanceof Famille))
			return false;
		else
			return getCodeFamille().equalsIgnoreCase(((Famille)obj).getCodeFamille());
	}
	
	public int hashCode()
	{
		return getCodeFamille().hashCode();
	}

	
	public String toString()
	{
		return this.getNomFamille();
	}

	public int compareTo(Object obj)
	{
		if(!(obj instanceof Famille))
			return -1;
		else
		return this.getNomFamille().compareTo(((Famille)obj).getNomFamille());
	}
}