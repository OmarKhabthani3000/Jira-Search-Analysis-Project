package test.ejb.dao;

import java.io.Serializable;
import java.util.Collection;

import javax.ejb.Remote;

import test.ejb.Produit;



@Remote
public interface ProduitDAO extends Serializable
{
	public Produit sauver(Produit produit);
	
	public Produit modifier(Produit produit);
	
	public void supprimer(Produit produit);
	
	public Collection<Produit> selectAll();
	
	public Produit findProduitByID(long produitID);
	
	public Produit findProduitByCode(String codeProduit);
}
