package test.ejb;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "classe")
public class Classe implements Serializable,Comparable
{

	private long classeID;

	private String codeClasse;

	private String libelleClasse;

	private String description;

	private Set<Produit> produits;
	
	private long version;
	
	@Version()
	@Column(name="version")
	public long getVersion()
	{
		return version;
	}

	public void setVersion(long version)
	{
		this.version = version;
	}
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "classe_id")
	public long getClasseID()
	{
		return classeID;
	}

	public void setClasseID(long classeID)
	{
		this.classeID = classeID;
	}

	@Column(name = "code_classe")
	public String getCodeClasse()
	{
		return codeClasse;
	}

	public void setCodeClasse(String codeClasse)
	{
		this.codeClasse = codeClasse;
	}

	@Column(name = "description")
	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	@Column(name = "libelle_classe")
	public String getLibelleClasse()
	{
		return libelleClasse;
	}

	public void setLibelleClasse(String libelleClasse)
	{
		this.libelleClasse = libelleClasse;
	}

	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE }, fetch = FetchType.LAZY, mappedBy="classes" )
	public Set<Produit> getProduits()
	{
		return produits;
	}

	public void setProduits(Set<Produit> produits)
	{
		this.produits = produits;
	}
	
	public boolean equals(Object obj)
	{
		if(obj == this)
			return true;
		if(!(obj instanceof Classe))
			return false;
		else
			return getCodeClasse().equalsIgnoreCase(((Classe)obj).getCodeClasse());
	}
	
	public int hashCode()
	{
		return getCodeClasse().hashCode();
	}

	
	public String toString()
	{
		return this.getLibelleClasse();
	}

	public int compareTo(Object obj)
	{
		if(!(obj instanceof Classe))
			return -1;
		else
		return this.getLibelleClasse().compareTo(((Classe)obj).getLibelleClasse());
	}
}