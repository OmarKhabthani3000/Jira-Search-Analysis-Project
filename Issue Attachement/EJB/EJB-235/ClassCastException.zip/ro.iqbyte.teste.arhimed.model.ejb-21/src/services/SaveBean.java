package services;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import model.Student;
import model.Teacher;

/******************************************************************************
 * Class name: SaveBean.java
 *
 * Date: 12.09.2006 - 18:42:50
 *
 * Copyright (c) 2006 IQBYTE Romania. All rights reserved.
 * IQBYTE - PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *****************************************************************************/

/**
 *
 *
 * @author JTONIC
 *
 */
@Stateless
public class SaveBean implements Save {

	@PersistenceContext(unitName = "arhimed")
	EntityManager em;

	/**
	 * @see Save#saveTeacher(model.Teacher)
	 */
	public Teacher saveTeacher(Teacher teacher) {
		return em.merge(teacher);
	}

	public Student saveStudent(Student student) {
		return em.merge(student);
	}

	public Student findStudent(Long studentId) {
		return em.find(Student.class, studentId);
	}

	public Teacher findTeacher(Long teacherId) {
		return em.find(Teacher.class, teacherId);
	}

	/**
	 * @see services.Save#removeStudent(Long, Long)
	 */
	public Student removeStudent(Long teacherId, Long studentId) {
		Teacher t = em.find(Teacher.class, teacherId);
		Student s = em.find(Student.class, studentId);
		if (t == null)
			throw new IllegalArgumentException("[jtonic] The teacher for the given ID doesn't exists."); //$NON-NLS-1$
		if (s != null)
			t.removeStudent(s);
		em.remove(t);
		return s;
	}

	/**
	 * @see services.Save#removeTeacher(Long, Long)
	 */
	public Teacher removeTeacher(Long studentId, Long teacherId) {
		Student s = em.find(Student.class, studentId);
		Teacher t = em.find(Teacher.class, teacherId);
		if (s == null)
			throw new IllegalArgumentException("[jtonic] The student for the given ID doesn't exists."); //$NON-NLS-1$
		if (t != null)
			t.removeStudent(s);
		em.remove(s);
		return t;
	}

}
