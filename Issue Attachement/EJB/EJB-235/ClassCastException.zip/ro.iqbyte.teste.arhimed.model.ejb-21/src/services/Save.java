package services;
import javax.ejb.Remote;

import model.Student;
import model.Teacher;


/******************************************************************************
 * Class name: Save.java
 *
 * Date: 12.09.2006 - 18:41:07
 *
 * Copyright (c) 2006 IQBYTE Romania. All rights reserved.
 * IQBYTE - PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *****************************************************************************/

/**
 *
 *
 * @author JTONIC
 *
 */
@Remote
public interface Save {

	Teacher saveTeacher(Teacher teacher);

	Student saveStudent(Student student);

	Student findStudent(Long studentId);

	Teacher findTeacher(Long teacherId);

	Student removeStudent(Long teacherId, Long studentId);

	Teacher removeTeacher(Long studentId, Long teacherId);



}
