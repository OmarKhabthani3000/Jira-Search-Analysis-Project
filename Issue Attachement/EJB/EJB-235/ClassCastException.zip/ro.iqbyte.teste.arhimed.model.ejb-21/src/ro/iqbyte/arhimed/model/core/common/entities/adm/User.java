package ro.iqbyte.arhimed.model.core.common.entities.adm;

import static javax.persistence.CascadeType.*;

import java.util.*;

import javax.persistence.*;

import org.hibernate.validator.Pattern;

import ro.iqbyte.arhimed.model.core.common.entities.Names;
import ro.iqbyte.arhimed.model.core.common.entities.PersistableObject;

@Entity
@Table(name = Names.TBL_USERS)
public class User extends PersistableObject {

	public static final String ADMIN_USERNAME = "admin"; //$NON-NLS-1$
	public static final String ADMIN_FIRST_PASSWORD = "admin"; //$NON-NLS-1$
	public static final int USERNAME_MIN_LENGTH = 5;
	public static final int USERNAME_MAX_LENGTH = 30;
	public static final int PASSWORD_MIN_LENGTH = 5;
	public static final int PASSWORD_MAX_LENGTH = 30;

	public static final String PROP_ALIAS = "alias"; //$NON-NLS-1$
	public static final String PROP_FIRST_USER = "firstUser"; //$NON-NLS-1$
	public static final String PROP_PASSWORD = "password"; //$NON-NLS-1$
	public static final String PROP_CREATION_DATE = "creationDate"; //$NON-NLS-1$
	public static final String PROP_ACTIVE = "active"; //$NON-NLS-1$
	public static final String PROP_CREATED_USERS = "createdUsers"; //$NON-NLS-1$
	public static final String PROP_MEDICAL_PERSONNEL = "medicalPersonnel"; //$NON-NLS-1$
	public static final String PROP_ROLES = "roles"; //$NON-NLS-1$

	@Pattern(regex = "\\w{5,}", message = "Numele utilizatorului trebuie sa contina cel putin 5 caractere")
	private String alias;

	private boolean superUser;

	@Basic(optional = false)
	private boolean active = true;

	@Basic(optional = false)
	private String password;

	@Temporal(TemporalType.TIMESTAMP)
	private Calendar creationDate;

	private boolean firstUser = false;

	/**
	 * cascadare trebuie sa fie {@link CascadeType#PERSIST}, {@link CascadeType#MERGE},
	 * {@link CascadeType#REFRESH}
	 */
	@ManyToMany(cascade = { PERSIST, MERGE, REFRESH }, fetch = FetchType.EAGER)
	private Set<Role> roles = new HashSet<Role>();

	/**
	 * ATENTIE!!! Aceasta relatie trebuie sa ramana pe {@link CascadeType#REMOVE remove}
	 */
	@OneToOne(cascade = REFRESH, optional = true)
	private MedicalPersonnel medicalPersonnel;

	public User() {
	}

	public User(String alias, String password) {
		this(alias, password, null);
	}

	public User(String alias, String password, MedicalPersonnel medicalPersonnel) {
		this.alias = alias;
		setPassword(password);
		setMedicalPersonnel(medicalPersonnel);
	}

	public boolean isActive() {
		return this.active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getAlias() {
		return this.alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public Calendar getCreationDate() {
		return this.creationDate;
	}

	public void setCreationDate(Calendar creationDate) {
		this.creationDate = creationDate;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public MedicalPersonnel getMedicalPersonnel() {
		return this.medicalPersonnel;
	}

	public void setMedicalPersonnel(MedicalPersonnel person) {
		if (person != null) {
			person.setUser(this);
		}
		this.medicalPersonnel = person;
	}

	/**
	 * @return the roles
	 */
	public Set<Role> getRoles() {
		return this.roles;
	}

	public void addRole(Role role) {
		if (role != null) {
			getRoles().add(role);
		}
	}

	public void removeRole(Role role) {
		if (role != null) {
			getRoles().remove(role);
		}
	}

	/**
	 * @param roles
	 *            the roles to set
	 */
	protected void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	/**
	 * @return the superUser
	 */
	public boolean isSuperUser() {
		return this.superUser;
	}

	/**
	 * @param superUser
	 *            the superUser to set
	 */
	public void setSuperUser(boolean superUser) {
		this.superUser = superUser;
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = super.hashCode();
		result = PRIME * result + (this.active ? 1231 : 1237);
		result = PRIME * result + ((this.alias == null) ? 0 : this.alias.hashCode());
		result = PRIME * result + ((this.creationDate == null) ? 0 : this.creationDate.hashCode());
		result = PRIME * result + ((this.password == null) ? 0 : this.password.hashCode());
		result = PRIME * result + (this.superUser ? 1231 : 1237);
		result = PRIME * result + (this.firstUser ? 1231 : 1237);
		return result;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		final User other = (User) obj;
		if (this.active != other.active)
			return false;
		if (this.alias == null) {
			if (other.alias != null)
				return false;
		} else if (!this.alias.equals(other.alias))
			return false;
		if (this.creationDate == null) {
			if (other.creationDate != null)
				return false;
		} else if (!this.creationDate.equals(other.creationDate))
			return false;
		if (this.password == null) {
			if (other.password != null)
				return false;
		} else if (!this.password.equals(other.password))
			return false;
		if (this.firstUser != other.firstUser)
			return false;
		if (this.superUser != other.superUser)
			return false;
		return true;
	}

	/**
	 * @return the firstUser
	 */
	public boolean isFirstUser() {
		return this.firstUser;
	}

	/**
	 * @param firstUser
	 *            the firstUser to set
	 */
	public void setFirstUser(boolean firstUser) {
		this.firstUser = firstUser;
	}

	public boolean hasRole(String roleName) {
		Set<Role> assignedroles = getRoles();
		for (Role role : assignedroles) {
			if (role.getRoleName().equals(roleName)) {
				return true;
			}
		}
		return false;
	}

	public boolean isMedicalPersonnel() {
		return getMedicalPersonnel() != null;
	}
}