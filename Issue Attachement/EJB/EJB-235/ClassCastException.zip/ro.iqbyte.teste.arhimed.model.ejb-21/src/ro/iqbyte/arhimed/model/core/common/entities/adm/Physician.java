package ro.iqbyte.arhimed.model.core.common.entities.adm;

import javax.persistence.Entity;
import javax.persistence.Table;

import ro.iqbyte.arhimed.model.core.common.entities.Names;

@Entity
@Table(name = Names.TBL_PHYSICIANS)
public class Physician extends MedicalPersonnel {

	public static final String PROP_CONTRACT_NO_CAS = "contractNoCas"; //$NON-NLS-1$
	public static final String PROP_ACADEMIC_TITLE = "academicTitle"; //$NON-NLS-1$
	public static final String PROP_SCIENTIFIC_TITLE = "scientificTitle"; //$NON-NLS-1$
	public static final String PROP_PROFESSION = "profession"; //$NON-NLS-1$

	private String contractNoCas;
	private String academicTitle;
	private String scientificTitle;
	private String profession;

	/**
	 * JPA only
	 *
	 */
	protected Physician() {
	}

	/**
	 *
	 * @param ssn
	 * @param firstName
	 * @param lastName
	 */
	public Physician(String ssn, String firstName, String lastName) {
		super(ssn, firstName, lastName);
	}

	public String getContractNoCas() {
		return this.contractNoCas;
	}

	public void setContractNoCas(String contractNoCAS) {
		this.contractNoCas = contractNoCAS;
	}

	/**
	 * @return the academicTitle
	 */
	public String getAcademicTitle() {
		return this.academicTitle;
	}

	/**
	 * @return the profession
	 */
	public String getProfession() {
		return this.profession;
	}

	/**
	 * @return the scientificTitle
	 */
	public String getScientificTitle() {
		return this.scientificTitle;
	}

	/**
	 * @param academicTitle
	 *            the academicTitle to set
	 */
	public void setAcademicTitle(String academicTitle) {
		this.academicTitle = academicTitle;
	}

	/**
	 * @param profession
	 *            the profession to set
	 */
	public void setProfession(String profession) {
		this.profession = profession;
	}

	/**
	 * @param scientificTitle
	 *            the scientificTitle to set
	 */
	public void setScientificTitle(String scientificTitle) {
		this.scientificTitle = scientificTitle;
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = super.hashCode();
		result = PRIME * result
				+ ((this.academicTitle == null) ? 0 : this.academicTitle.hashCode());
		result = PRIME * result
				+ ((this.contractNoCas == null) ? 0 : this.contractNoCas.hashCode());
		result = PRIME * result + ((this.profession == null) ? 0 : this.profession.hashCode());
		result = PRIME * result
				+ ((this.scientificTitle == null) ? 0 : this.scientificTitle.hashCode());
		return result;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Physician other = (Physician) obj;
		if (this.academicTitle == null) {
			if (other.academicTitle != null)
				return false;
		} else if (!this.academicTitle.equals(other.academicTitle))
			return false;
		if (this.contractNoCas == null) {
			if (other.contractNoCas != null)
				return false;
		} else if (!this.contractNoCas.equals(other.contractNoCas))
			return false;
		if (this.profession == null) {
			if (other.profession != null)
				return false;
		} else if (!this.profession.equals(other.profession))
			return false;
		if (this.scientificTitle == null) {
			if (other.scientificTitle != null)
				return false;
		} else if (!this.scientificTitle.equals(other.scientificTitle))
			return false;
		return true;
	}

	/**
	 * @see ro.iqbyte.arhimed.model.core.common.entities.adm.MedicalPersonnel#getMedicalPersonnelType()
	 */
	@Override
	public MedicalPersonnelType getMedicalPersonnelType() {
		return MedicalPersonnelType.PHYSICIAN;
	}
}
