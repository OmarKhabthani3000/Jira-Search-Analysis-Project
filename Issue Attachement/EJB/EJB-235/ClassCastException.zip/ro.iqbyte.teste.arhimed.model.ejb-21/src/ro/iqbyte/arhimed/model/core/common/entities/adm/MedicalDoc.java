/******************************************************************************
 * Class name: MedicalDoc.java
 *
 * Date: 04.10.2006 - 12:14:52
 *
 * Copyright (c) 2006 IQBYTE Romania. All rights reserved.
 * IQBYTE - PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *****************************************************************************/
package ro.iqbyte.arhimed.model.core.common.entities.adm;

import javax.persistence.*;

import ro.iqbyte.arhimed.model.core.common.entities.Names;
import ro.iqbyte.arhimed.model.core.common.entities.PersistableObject;

/**
 *
 *
 * @author JTONIC
 *
 */

@Entity
@Table(name = Names.MEDICAL_DOCS_TBL)
public class MedicalDoc extends PersistableObject {

	public static final String PROP_SERIAL_NO = "serialNo"; //$NON-NLS-1$

	public static final String PROP_MEDICAL_PERSONNEL = "medicalPersonnel"; //$NON-NLS-1$

	@Basic(optional = false)
	private String serialNo;

	@ManyToOne(cascade = CascadeType.REFRESH)
	private MedicalPersonnel medicalPersonnel;

	public MedicalDoc() {
	}

	public MedicalDoc(String serialNo) {
		this.serialNo = serialNo;
	}

	protected String getSerialNo() {
		return this.serialNo;
	}

	protected void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public MedicalPersonnel getMedicalPersonnel() {
		return this.medicalPersonnel;
	}

	public void setMedicalPersonnel(MedicalPersonnel medicalPersonnel) {
		this.medicalPersonnel = medicalPersonnel;
	}

}
