package ro.iqbyte.arhimed.model.core.common.entities.adm;

import java.io.Serializable;

import javax.persistence.*;

import ro.iqbyte.arhimed.model.core.common.entities.Names;
import ro.iqbyte.arhimed.model.core.common.entities.PersistableObject;

@Entity
@Table(name = Names.TBL_PERSONS)
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Person extends PersistableObject {

	public static final String PROP_CONTACT_INFO = "contactInfo";//$NON-NLS-1$
	public static final String PROP_STABLE_ADDRESS = "stableAddress";//$NON-NLS-1$

	public enum PersonType {
		INDIVIDUAL, INSTITUTION;
	}

	@Embeddable
	public static class ContactInfo implements Serializable {

		public static final Object ID = "ContactInfo"; //$NON-NLS-1$
		public static final String NLS_CLASS = "Contact info";
		public static final String NLS_PHONE_NO = "Phone";
		public static final String NLS_CELL_PHONE = "Cell phone";
		public static final String NLS_EMAIL = "Email";
		public static final String NLS_WEB_PAGE = "Web page";

		public static final String PROP_PHONE_NO = "phoneNo"; //$NON-NLS-1$
		public static final String PROP_CELL_PHONE = "cellPhone"; //$NON-NLS-1$
		public static final String PROP_EMAIL = "email"; //$NON-NLS-1$
		public static final String PROP_WEB_PAGE = "webPage"; //$NON-NLS-1$

		private String phoneNo;
		private String cellPhone;
		private String email;
		private String webPage;

		public ContactInfo() {
		}

		/**
		 * @param phoneNo
		 * @param cellPhone
		 * @param email
		 * @param webPage
		 */
		public ContactInfo(String phoneNo, String cellPhone, String email, String webPage) {
			this.cellPhone = cellPhone;
			this.email = email;
			this.webPage = webPage;
			this.phoneNo = phoneNo;
		}

		/**
		 * @return the PhoneNo
		 */
		public String getPhoneNo() {
			return this.phoneNo;
		}

		/**
		 * @param phoneNo
		 *            the Phone to set
		 */
		public void setPhoneNo(String phoneNo) {
			this.phoneNo = phoneNo;
		}

		/**
		 * @return the cellPhone
		 */
		public String getCellPhone() {
			return this.cellPhone;
		}

		/**
		 * @param cellPhone
		 *            the cellPhone to set
		 */
		public void setCellPhone(String cellPhone) {
			this.cellPhone = cellPhone;
		}

		/**
		 * @return the email
		 */
		public String getEmail() {
			return this.email;
		}

		/**
		 * @param email
		 *            the email to set
		 */
		public void setEmail(String email) {
			this.email = email;
		}

		/**
		 * @return the webPage
		 */
		public String getWebPage() {
			return this.webPage;
		}

		/**
		 * @param webPage
		 *            the webPage to set
		 */
		public void setWebPage(String webPage) {
			this.webPage = webPage;
		}

		/**
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {
			final int PRIME = 31;
			int result = 1;
			result = PRIME * result + ((this.cellPhone == null) ? 0 : this.cellPhone.hashCode());
			result = PRIME * result + ((this.email == null) ? 0 : this.email.hashCode());
			result = PRIME * result + ((this.phoneNo == null) ? 0 : this.phoneNo.hashCode());
			result = PRIME * result + ((this.webPage == null) ? 0 : this.webPage.hashCode());
			return result;
		}

		/**
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final ContactInfo other = (ContactInfo) obj;
			if (this.cellPhone == null) {
				if (other.cellPhone != null)
					return false;
			} else if (!this.cellPhone.equals(other.cellPhone))
				return false;
			if (this.email == null) {
				if (other.email != null)
					return false;
			} else if (!this.email.equals(other.email))
				return false;
			if (this.phoneNo == null) {
				if (other.phoneNo != null)
					return false;
			} else if (!this.phoneNo.equals(other.phoneNo))
				return false;
			if (this.webPage == null) {
				if (other.webPage != null)
					return false;
			} else if (!this.webPage.equals(other.webPage))
				return false;
			return true;
		}

	}

	@Embedded
	private ContactInfo contactInfo;

	@Enumerated(EnumType.STRING)
	private PersonType personType = getPersonType();

	protected Person() {
	}

	public abstract PersonType getPersonType();

	public ContactInfo getContactInfo() {
		return this.contactInfo;
	}

	public void setContactInfo(ContactInfo contactInfo) {
		this.contactInfo = contactInfo;
	}
	
	
	
	

}