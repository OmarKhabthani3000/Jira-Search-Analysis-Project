package ro.iqbyte.arhimed.model.core.common.entities.adm;

import java.util.Calendar;

import javax.persistence.*;

import ro.iqbyte.arhimed.model.core.common.entities.Names;
import ro.iqbyte.common.util.StringUtils;

@Entity
@Table(name = Names.TBL_INDIVIDUALS)
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Individual extends Person {

	public static final String PROP_SSN = "ssn"; //$NON-NLS-1$
	public static final String PROP_FIRST_NAME = "firstName"; //$NON-NLS-1$
	public static final String PROP_LAST_NAME = "lastName"; //$NON-NLS-1$
	public static final String PROP_ID_CARD = "idCard"; //$NON-NLS-1$
	public static final String PROP_BIRTH_DATE = "birthDate"; //$NON-NLS-1$
	public static final String PROP_GENDER = "gender"; //$NON-NLS-1$
	public static final String PROP_INDIVIDUAL_TYPE = "individualType"; //$NON-NLS-1$
	public static final String PROP_FLOATING_ADDRESS = "floatingAddress";//$NON-NLS-1$

	public enum Gender {
		MALE, FEMALE;
	}

	public enum IndividualType {
		PATIENT, MEDICAL_PERSONNEL;
	}

	/**
	 * CNP-ul persoanei
	 */
	@Column(unique = true, nullable = false)
	private String ssn;

	@Basic(optional = false)
	private String firstName;

	@Basic(optional = false)
	private String lastName;

	private String idCard;

	@Temporal(TemporalType.DATE)
	private Calendar birthDate;

	@Basic(optional = false)
	@Enumerated(EnumType.STRING)
	private Gender gender;

	@Enumerated(EnumType.STRING)
	protected IndividualType individualType = getIndividualType();

	protected Individual() {
	}

	public Individual(String ssn, String firstName, String lastName) {
		this(ssn, firstName, lastName, null, null, null);
	}

	public Individual(String ssn, String firstName, String lastName,
			String idCard, Calendar birthDate, Gender gender) {

		setSsn(ssn);
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.idCard = idCard;
		this.birthDate = birthDate;
		this.gender = gender;
	}

	public Individual(String ssn, String firstName, String lastName,
			Gender gender) {
		this(ssn, firstName, lastName, null, null, gender);
	}

	public abstract IndividualType getIndividualType();

	@Override
	public PersonType getPersonType() {
		return PersonType.INDIVIDUAL;
	}

	public Calendar getBirthDate() {
		return this.birthDate;
	}

	public void setBirthDate(Calendar birthDate) {
		this.birthDate = birthDate;
	}

	public String getIdCard() {
		return this.idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String name) {
		this.firstName = name;
	}

	public Gender getGender() {
		return this.gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public String getSsn() {
		return this.ssn;
	}

	public void setSsn(String ssn) {
		//@FIXME [jman, jtonic, jcristal] trebuie facuta validarea
//		if(!BaseValidator.isCNP(ssn)) {
//			throw new IllegalArgumentException("Invalid ssn!"); //$NON-NLS-1$
//		}
		this.ssn = ssn;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String surname) {
		this.lastName = surname;
	}

	/**
	 * @return concatenarea dintre first name un spatiu si last name
	 */
	@Transient
	public String getFullName() {
		return StringUtils.safeString(this.getFirstName()) + StringUtils.ONE_BLANK_CHAR_STRING
				+ StringUtils.safeString(this.getLastName());
	}
	
	


}