/******************************************************************************
 * Class name: Names.java
 *
 * Date: 16.08.2006 - 20:25:56
 *
 * Copyright (c) 2006 IQBYTE Romania. All rights reserved.
 * IQBYTE - PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *****************************************************************************/
package ro.iqbyte.arhimed.model.core.common.entities;

/**
 *
 *
 * @author JTONIC
 *
 */
public class Names {
	public static final String MEDICAL_DOCS_TBL = "MEDICAL_DOCS";

	public static final String DRUG_PRESCRIPTION_TBL = "DRUG_PRESCRIPTIONS";
	public static final String DRUG_PRESCRIPTION__CODE__col = "code";

	public static final String VOUCHER__SERVE_FOR__col = "SERVE_FOR"; //$NON-NLS-1$
	public static final String DIAGNOSTIC__DIAGNOSTIC_TYPE__col = "DIAGNOSTIC_TYPE"; //$NON-NLS-1$

	public static final String DISEASES_TBL = "DISEASES"; //$NON-NLS-1$
	public static final String DIAGNOSTICS_TBL = "DIAGNOSTICS"; //$NON-NLS-1$
	public static final String SANGUIN_GROUPS_TBL = "SANGUIN_GROUPS"; //$NON-NLS-1$
	public static final String COL_MEDICAL_ACTS_differentValue = "DIFFERENT_VALUE"; //$NON-NLS-1$

	public static final String TBL_BODY_PARTS = "BODY_PARTS"; //$NON-NLS-1$
	public static final String TBL_MEDICAL_RESULTS = "MEDICAL_RESULTS"; //$NON-NLS-1$
	public static final String TBL_PATIENTS = "PATIENTS"; //$NON-NLS-1$
	public static final String TBL_CLINICAL_CASES = "CLINICAL_CASES"; //$NON-NLS-1$
	public static final String TBL_MEDICAL_ACTIVITIES = "MEDICAL_ACTIVITIES"; //$NON-NLS-1$
	public static final String TBL_REMAINDERS = "REMAINDERS"; //$NON-NLS-1$
	public static final String TBL_SCHEDULERS = "SCHEDULERS"; //$NON-NLS-1$
	public static final String TBL_SCHEDULE_EVENTS = "SCHEDULE_EVENTS"; //$NON-NLS-1$
	public static final String TBL_APPOINTMENTS = "APPOINTMENTS"; //$NON-NLS-1$
	public static final String TBL_MEDICAL_APPOINTMENTS = "MEDICAL_APPOINTMENTS"; //$NON-NLS-1$
	public static final String TBL_PARTICIPATIONS = "PARTICIPATIONS"; //$NON-NLS-1$
	public static final String TBL_MEDICAL_ACTS = "MEDICAL_ACTS"; //$NON-NLS-1$
	public static final String TBL_MEDICAL_ACTIONS = "MEDICAL_ACTIONS"; //$NON-NLS-1$

	public static final String TBL_ADMINISTRATIVE_UNITS = "ADMINISTRATIVE_UNITS"; //$NON-NLS-1$
	public static final String TBL_CABINETS = "CABINETS"; //$NON-NLS-1$
	public static final String TBL_INDIVIDUALS = "INDIVIDUALS"; //$NON-NLS-1$
	public static final String TBL_ADDRESSES = "ADDRESSES"; //$NON-NLS-1$
	public static final String TBL_ECHOGRAPHIES = "ECHOGRAPHIES"; //$NON-NLS-1$
	public static final String TBL_MEDICAL_ANALYSIS = "MEDICAL_ANALYSIS"; //$NON-NLS-1$
	public static final String TBL_MEDICAL_UNITS = "MEDICAL_UNITS"; //$NON-NLS-1$
	public static final String TBL_MEDICAL_PERSONNELS = "MEDICAL_PERSONNELS"; //$NON-NLS-1$
	public static final String TBL_NURSES = "NURSES"; //$NON-NLS-1$
	public static final String TBL_MEDICAL_TESTS = "MEDICAL_TESTS"; //$NON-NLS-1$
	public static final String TBL_SPECIALIZED_INVESTIGATIONS = "SPECIALIZED_INVESTIGATIONS"; //$NON-NLS-1$
	public static final String TBL_XRAYS = "XRAYS"; //$NON-NLS-1$
	public static final String TBL_MISC_ACTIONS = "MISC_ACTIONS"; //$NON-NLS-1$
	public static final String TBL_TREATMENTS = "TREATMENTS"; //$NON-NLS-1$
	public static final String TBL_MEDICAMENTARY_TREATMENTS = "MEDICAMENTARY_TREATMENTS"; //$NON-NLS-1$
	public static final String TBL_PERSONS = "PERSONS"; //$NON-NLS-1$
	public static final String TBL_PHYSICIANS = "PHYSICIANS"; //$NON-NLS-1$
	public static final String TBL_PHYSICAL_TREATMENTS = "PHYSICAL_TREATMENTS"; //$NON-NLS-1$
	public static final String TBL_ROLES = "ROLES"; //$NON-NLS-1$
	public static final String TBL_MEDICINE = "MEDICINES"; //$NON-NLS-1$
	public static final String TBL_SPECIALIZATIONS = "SPECIALIZATIONS"; //$NON-NLS-1$
	public static final String TBL_SPECIALIZATION_GROUPS = "SPECIALIZATION_GROUPS"; //$NON-NLS-1$
	public static final String TBL_USERS = "USERS"; //$NON-NLS-1$

	public static final String TBL_H_ADDRESSES = "ADDRESSES_H"; //$NON-NLS-1$
	public static final String TBL_H_INDIVIDUALS = "INDIVIDUALS_H"; //$NON-NLS-1$
	public static final String TBL_H_USERS = "USERS_H"; //$NON-NLS-1$


	public static final String COL_MEDICAL_ADVICE__advice = "ADVICE"; //$NON-NLS-1$
	public static final String COL_MEDICAL_ADVICE__category = "CATEGORY"; //$NON-NLS-1$


	public static final String COL_MEDICAL_ACTION__denomination = "DENOMINATION"; //$NON-NLS-1$

	public static final String COL_DRUG_CLASS__active_substance = "ACTIVE_SUBSTANCE"; //$NON-NLS-1$

	public static final String COL_DRUG_FORM__naming = "NAMING"; //$NON-NLS-1$

	public static final String COL_MANUFACTURER__naming = "NAMING"; //$NON-NLS-1$
	public static final String COL_MANUFACTURER__country = "COUNTRY"; //$NON-NLS-1$

	public static final String COL_PACKING__description = "DESCRIPTION"; //$NON-NLS-1$

	public static final String COL_MEASURE_UNIT__naming = "NAMING"; //$NON-NLS-1$

	public static final String COL_MEDICINE__drug_class = "DRUG_CLASS"; //$NON-NLS-1$
	public static final String COL_MEDICINE__label = "LABEL"; //$NON-NLS-1$
	public static final String COL_MEDICINE__drug_form = "DRUG_FORM"; //$NON-NLS-1$
	public static final String COL_MEDICINE__packing = "PACKING"; //$NON-NLS-1$
	public static final String COL_MEDICINE__manufacturer = "MANUFACTURER"; //$NON-NLS-1$
	public static final String COL_MEDICINE__measure_unit = "MEASURE_UNIT"; //$NON-NLS-1$

	public static final String COL_MEDICAL_RESULTS__results = "RESULTS"; //$NON-NLS-1$

	public static final String MEDICAL_DOC_TBL = "MEDICAL_DOCS"; //$NON-NLS-1$
	public static final String PATIENT_DOC_TBL = "PATIENT_DOCS"; //$NON-NLS-1$
	public static final String DIAGNOSTIC_AWARE_DOC_TBL = "DIAGNOSTIC_AWARE_DOCS"; //$NON-NLS-1$
	public static final String LETTER_TBL = "LETTERS";  //$NON-NLS-1$
	public static final String RECEIPT_TBL = "RECEIPTS";  //$NON-NLS-1$
	public static final String VOUCHER_TBL = "VOUCHERS";  //$NON-NLS-1$
	public static final String STOMATOLOGY_FILE_TBL = "STOMATOLOGY_FILES";  //$NON-NLS-1$
	public static final String STOMATOLOGY_MR_TBL = "STOMATOLOGY_MRS";  //$NON-NLS-1$
	public static final String RECEIPT_RECORD_TBL = "RECEIPT_RECORDS";  //$NON-NLS-1$
	public static final String DIAGNOSTIC_AWARE_MR_TBL = "DIAGNOSTIC_AWARE_MRS";  //$NON-NLS-1$


}
