package ro.iqbyte.arhimed.model.core.common.entities.adm;

import static javax.persistence.CascadeType.*;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import ro.iqbyte.arhimed.model.core.common.entities.Names;

@Entity
@Table(name = Names.TBL_MEDICAL_PERSONNELS)
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class MedicalPersonnel extends Individual {

	public static final String PROP_MEDICAL_PERSONNEL_TYPE = "medicalPersonnelType"; //$NON-NLS-1$
	public static final String PROP_USER = "user"; //$NON-NLS-1$
	public static final String PROP_MEDICAL_DOCS = "medicalDocs";

	public enum MedicalPersonnelType {
		PHYSICIAN, NURSE;
	}

	@Enumerated(EnumType.STRING)
	@Basic(optional = false)
	private MedicalPersonnelType medicalPersonnelType = getMedicalPersonnelType();

	/**
	 * ATENTIE!!! Aceasta relatie trebuie sa ramana pe {@link CascadeType#REFRESH refresh}. Nu trebuie sa fie
	 */
	@OneToOne(mappedBy = User.PROP_MEDICAL_PERSONNEL, cascade = REFRESH)
	private User user;

	@OneToMany(mappedBy = MedicalDoc.PROP_MEDICAL_PERSONNEL, cascade = {PERSIST, MERGE, REFRESH})
	private Set<MedicalDoc> medicalDocs = new HashSet<MedicalDoc>();

	protected MedicalPersonnel() {
	}

	public MedicalPersonnel(String ssn, String firstName, String lastName) {
		super(ssn, firstName, lastName);
	}

	public abstract MedicalPersonnelType getMedicalPersonnelType();

	/**
	 * @see ro.iqbyte.arhimed.model.core.common.entities.adm.Individual#getIndividualType()
	 */
	@Override
	public IndividualType getIndividualType() {
		return IndividualType.MEDICAL_PERSONNEL;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Set<MedicalDoc> getMedicalDocs() {
		return this.medicalDocs;
	}

	protected void setMedicalDocs(Set<MedicalDoc> medicalDocs) {
		this.medicalDocs = medicalDocs;
	}

	public void addMedicalDoc(MedicalDoc medicalDoc) {
		this.medicalDocs.add(medicalDoc);
		medicalDoc.setMedicalPersonnel(this);
	}

}
