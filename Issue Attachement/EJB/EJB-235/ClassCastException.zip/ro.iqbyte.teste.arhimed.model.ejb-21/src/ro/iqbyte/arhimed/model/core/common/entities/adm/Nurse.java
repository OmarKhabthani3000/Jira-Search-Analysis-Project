package ro.iqbyte.arhimed.model.core.common.entities.adm;

import javax.persistence.Entity;
import javax.persistence.Table;

import ro.iqbyte.arhimed.model.core.common.entities.Names;

/**
 * Asistent medical
 *
 * @author Cristinel Angheluta
 *
 * <br/> Date: May 26, 2006 - 2:50:23 PM <br/>
 */
@Entity
@Table(name = Names.TBL_NURSES)
public class Nurse extends MedicalPersonnel {

	/**
	 * JPA only
	 *
	 */
	protected Nurse() {
	}

	public Nurse(String ssn, String firstName, String lastName) {
		super(ssn, firstName, lastName);
	}

	/**
	 * @see ro.iqbyte.arhimed.model.core.common.entities.adm.MedicalPersonnel#getMedicalPersonnelType()
	 */
	@Override
	public MedicalPersonnelType getMedicalPersonnelType() {
		return MedicalPersonnelType.NURSE;
	}
}
