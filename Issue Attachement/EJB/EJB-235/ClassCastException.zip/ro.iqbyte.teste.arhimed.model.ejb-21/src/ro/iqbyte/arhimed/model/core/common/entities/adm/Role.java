/***************************************************************************************************
 * Class roleName: Role.java
 *
 * Version:
 *
 * Date: Jul 12, 2006 - 11:22:16 AM
 *
 * Copyright (c) 2006 IQBYTE Romania. All rights reserved.
 **************************************************************************************************/
package ro.iqbyte.arhimed.model.core.common.entities.adm;

import javax.persistence.Entity;
import javax.persistence.Table;

import ro.iqbyte.arhimed.model.core.common.entities.Names;
import ro.iqbyte.arhimed.model.core.common.entities.PersistableObject;

/**
 * Declara rolurile avute de un user.
 *
 * @author jman
 *
 */
@Entity
@Table(name = Names.TBL_ROLES)
public class Role extends PersistableObject {

	// ***** STATIC FIELDS --------------------------------------------------//

	public static final String ADMIN_ROLE = "administrator"; //$NON-NLS-1$
	public static final String USERS_ROLE = "utilizator"; //$NON-NLS-1$

	public static final String PROP_ROLE_NAME = "roleName"; //$NON-NLS-1$
	public static final String PROP_ROLE_GROUP = "roleGroup"; //$NON-NLS-1$

	// ***** OBJECT FIELDS --------------------------------------------------//

	private String roleName;
	private String roleGroup;

	// ***** CONSTRUCTORS ---------------------------------------------------//

	public Role() {
	}

	public Role(String name, String group) {
		setRoleName(name);
		setRoleGroup(group);
	}

	// ***** PUBLIC METHODS -------------------------------------------------//

	/**
	 * @return the roleGroup
	 */
	public String getRoleGroup() {
		return this.roleGroup;
	}

	/**
	 * @param group
	 *            the roleGroup to set
	 */
	public void setRoleGroup(String group) {
		this.roleGroup = group;
	}

	/**
	 * @return the roleName
	 */
	public String getRoleName() {
		return this.roleName;
	}

	/**
	 * @param name
	 *            the roleName to set
	 */
	public void setRoleName(String name) {
		this.roleName = name;
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = super.hashCode();
		result = PRIME * result + ((this.roleGroup == null) ? 0 : this.roleGroup.hashCode());
		result = PRIME * result + ((this.roleName == null) ? 0 : this.roleName.hashCode());
		return result;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Role other = (Role) obj;
		if (this.roleGroup == null) {
			if (other.roleGroup != null)
				return false;
		} else if (!this.roleGroup.equals(other.roleGroup))
			return false;
		if (this.roleName == null) {
			if (other.roleName != null)
				return false;
		} else if (!this.roleName.equals(other.roleName))
			return false;

		return true;
	}

}
