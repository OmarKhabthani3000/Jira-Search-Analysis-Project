package ro.iqbyte.arhimed.model.core.common.entities;

import java.io.Serializable;

public interface Persistable<K extends Serializable> extends Serializable {

	String PROP_ID = "id"; //$NON-NLS-1$

	K getId();
}
