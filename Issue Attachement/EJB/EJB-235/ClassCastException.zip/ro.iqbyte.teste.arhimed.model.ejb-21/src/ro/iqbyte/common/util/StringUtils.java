/**
 * Created: 07.07.2006 - 14:25:08
 */
package ro.iqbyte.common.util;


/**
 * @author JTONIC
 *
 * </p>Created: 07.07.2006 - 14:25:08</p>
 *
 */
public class StringUtils {
	public static final String EMPTY_STRING = ""; //$NON-NLS-1$
	public static final String ONE_BLANK_CHAR_STRING = " "; //$NON-NLS-1$
	public static final String ONE_PERIOD = "."; //$NON-NLS-1$
	public static final String OPENED_SQUARED_BRACKET = "["; //$NON-NLS-1$
	public static final String CLOSED_SQUARED_BRACKET = "]"; //$NON-NLS-1$
	public static final String ID = "ID"; //$NON-NLS-1$

	public static final String DOT = "."; //$NON-NLS-1$
	public static final String NULL = "null"; //$NON-NLS-1$
	public static final String DOT_NULL = DOT + NULL;

	/**
	 * @param string Sirul de caractere de verificat pentru null
	 * @return un string vid daca sirul e null, altfel sirul.
	 */
	public static String safeString(String string) {
		return safeString(string, false);
	}

	/**
	 * @param string Sirul de caractere de verificat pentru null
	 * @param trim inlatura spatiile albe de la inceput si sfarsitul stringului
	 * @return un string vid daca sirul e null, altfel sirul.
	 */
	public static String safeString(String string, boolean trim) {
		return (string == null ? EMPTY_STRING : (trim == true ? string.trim() : string));
	}

	/**
	 * @param string
	 * @param trim
	 * @return null daca stringul (trunchiat pentru trim = true) are lungimea 0, altminteri stringul trunchiat in functie de trim
	 */
	public static String nullIfEmpty(String string, boolean trim) {
		String tmp = safeString(string, trim);
		return tmp.length() == 0 ? null : tmp;
	}

	/**
	 * @param string
	 * @return null daca stringul are lungimea 0, altminteri stringul
	 */
	public static String nullIfEmpty(String string) {
		return nullIfEmpty(string, false);
	}
}
