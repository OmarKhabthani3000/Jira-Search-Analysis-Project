/******************************************************************************
 * Class name: ICustomToString.java
 *
 * Date: 24.07.2006 - 21:05:10
 *
 * Copyright (c) 2006 IQBYTE Romania. All rights reserved.
 * IQBYTE - PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *****************************************************************************/
package ro.iqbyte.common.util;


/**
 *
 *
 * @author JTONIC
 *
 */
public interface ICustomToString {
	public void setToString(String toString);

}
