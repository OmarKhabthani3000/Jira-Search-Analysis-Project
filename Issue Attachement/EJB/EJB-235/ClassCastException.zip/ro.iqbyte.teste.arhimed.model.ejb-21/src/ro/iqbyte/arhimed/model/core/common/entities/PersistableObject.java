package ro.iqbyte.arhimed.model.core.common.entities;

import java.sql.Timestamp;

import javax.persistence.*;

import ro.iqbyte.common.util.ICustomToString;

@Entity
@Table(name = "PERSISTENT_OBJECT")
@Inheritance(strategy = InheritanceType.JOINED)
public class PersistableObject implements Persistable<Long>, ICustomToString {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected Long id;

	// @OneToMany(mappedBy = HistoryObject.PROP_PO)
	// private Set<HistoryObject> historyObjects = new HashSet<HistoryObject>();

	@SuppressWarnings("unused")
	@Version
	@Basic(optional = false)
	private Timestamp version;

	@Transient
	private String toString;

	protected PersistableObject() {
	}

	protected PersistableObject(String toString) {
		this.toString = toString;
	}

	public Long getId() {
		return this.id;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		if (this.toString != null)
			return this.toString;
		return super.toString();
	}

	/**
	 * @param toString
	 *            the toString to set
	 */
	public void setToString(String toString) {
		this.toString = toString;
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((this.id == null) ? 0 : this.id.hashCode());
		return result;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final PersistableObject other = (PersistableObject) obj;
		if (this.id == null) {
			if (other.id != null)
				return false;
		} else if (!this.id.equals(other.id))
			return false;
		return true;
	}

}
