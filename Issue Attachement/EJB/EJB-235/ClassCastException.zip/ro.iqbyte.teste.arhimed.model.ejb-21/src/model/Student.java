/******************************************************************************
 * Class name: Student.java
 *
 * Date: 12.09.2006 - 17:59:40
 *
 * Copyright (c) 2006 IQBYTE Romania. All rights reserved.
 * IQBYTE - PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *****************************************************************************/
package model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

/**
 *
 *
 * @author JTONIC
 *
 */
@Entity
@Table(name = "STUDENTS")
public class Student implements Serializable {

	private static final String PROP_ID = "student"; //$NON-NLS-1$
	private static final String PROP_FIRST_NAME = "firstName"; //$NON-NLS-1$
	private static final String PROP_LAST_NAME = "lastName"; //$NON-NLS-1$
	private static final String PROP_TEACHERS = "lastName"; //$NON-NLS-1$

	@Id
	@GeneratedValue
	private Long id;

	private String firstName;

	private String lastName;

	@ManyToMany(mappedBy = Teacher.PROP_STUDENTS, cascade = { CascadeType.MERGE, CascadeType.REFRESH })
	private Set<Teacher> teachers = new HashSet<Teacher>();

	public Student() {
	}

	public Student(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Long getId() {
		return this.id;
	}

	public Set<Teacher> getTeachers() {
		return this.teachers;
	}

	public void assignTeacher(Teacher teacher) {
		this.teachers.add(teacher);
	}

	public void removeTeacher(Teacher teacher) {
		this.teachers.remove(teacher);
	}

	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((this.firstName == null) ? 0 : this.firstName.hashCode());
		result = PRIME * result + ((this.lastName == null) ? 0 : this.lastName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Student other = (Student) obj;
		if (this.firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!this.firstName.equals(other.firstName))
			return false;
		if (this.lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!this.lastName.equals(other.lastName))
			return false;
		return true;
	}


}
