/******************************************************************************
 * Class name: Teacher.java
 *
 * Date: 12.09.2006 - 18:09:25
 *
 * Copyright (c) 2006 IQBYTE Romania. All rights reserved.
 * IQBYTE - PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *****************************************************************************/
package model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

/**
 *
 *
 * @author JTONIC
 *
 */
@Entity
@Table(name = "TEACHERS")
public class Teacher implements Serializable {

	public static final String PROP_ID = "id"; //$NON-NLS-1$
	public static final String PROP_FIRST_NAME = "firstName"; //$NON-NLS-1$
	public static final String PROP_LAST_NAME = "lastName"; //$NON-NLS-1$
	public static final String PROP_STUDENTS = "students"; //$NON-NLS-1$

	@Id
	@GeneratedValue
	private Long id;
	private String lastName;
	private String firstName;

	@ManyToMany(cascade = { CascadeType.MERGE, CascadeType.REFRESH })
	private Set<Student> students = new HashSet<Student>();

	public Teacher() {
	}

	public Teacher(String lastName, String firstName) {
		super();
		this.lastName = lastName;
		this.firstName = firstName;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Long getId() {
		return this.id;
	}

	public Set<Student> getStudents() {
		return this.students;
	}

	public void addStudent(Student student) {
		this.students.add(student);
		student.assignTeacher(this);
	}

	public void removeStudent(Student student) {
		this.students.remove(student);
//		student.removeTeacher(this);
	}

	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((this.firstName == null) ? 0 : this.firstName.hashCode());
		result = PRIME * result + ((this.lastName == null) ? 0 : this.lastName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Teacher other = (Teacher) obj;
		if (this.firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!this.firstName.equals(other.firstName))
			return false;
		if (this.lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!this.lastName.equals(other.lastName))
			return false;
		return true;
	}


}
