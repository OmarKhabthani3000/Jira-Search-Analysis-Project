/******************************************************************************
 * Class name: Address.java
 *
 * Date: 13.09.2006 - 12:47:28
 *
 * Copyright (c) 2006 IQBYTE Romania. All rights reserved.
 * IQBYTE - PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *****************************************************************************/
package com.titan.domain;

import java.io.Serializable;

import javax.persistence.*;

/**
 *
 *
 * @author JTONIC
 *
 */
@Entity
@Table(name = "ADDRESSES")
public class Address implements Serializable {

	@Id
	@GeneratedValue
	private Long id;

	private String street;
	private Integer no;
	private String city;
	private String county;
	private String country;
	private Long zipCode;

	public Address() {
		super();
	}

	public Address(String street, Long zipCode) {
		this.street = street;
		this.zipCode = zipCode;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCounty() {
		return this.county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public Integer getNo() {
		return this.no;
	}

	public void setNo(Integer no) {
		this.no = no;
	}

	public String getStreet() {
		return this.street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public Long getZipCode() {
		return this.zipCode;
	}

	public void setZipCode(Long zipCode) {
		this.zipCode = zipCode;
	}

	public Long getId() {
		return this.id;
	}

}
