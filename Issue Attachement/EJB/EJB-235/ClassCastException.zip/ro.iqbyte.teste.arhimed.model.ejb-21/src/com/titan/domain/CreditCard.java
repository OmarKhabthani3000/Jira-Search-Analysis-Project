/******************************************************************************
 * Class name: CreditCard.java
 *
 * Date: 13.09.2006 - 17:35:26
 *
 * Copyright (c) 2006 IQBYTE Romania. All rights reserved.
 * IQBYTE - PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *****************************************************************************/
package com.titan.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

/**
 *
 *
 * @author JTONIC
 *
 */
@Entity
@Table(name = "CREDIT_CARDS")
public class CreditCard implements Serializable {

	@Id
	@GeneratedValue
	private int id;
	private Date expiration;
	private String number;
	private String name;
	private String organization;
	@OneToOne(mappedBy = "creditCard", cascade = { CascadeType.MERGE, CascadeType.REFRESH })
	private Customer customer;

	public Customer getCustomer() {
		return this.customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Date getExpiration() {
		return this.expiration;
	}

	public void setExpiration(Date expiration) {
		this.expiration = expiration;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNumber() {
		return this.number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getOrganization() {
		return this.organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public int getId() {
		return this.id;
	}

}
