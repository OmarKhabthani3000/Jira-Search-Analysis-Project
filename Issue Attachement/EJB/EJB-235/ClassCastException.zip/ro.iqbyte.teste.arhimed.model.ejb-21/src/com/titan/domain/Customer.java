package com.titan.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "CUSTOMERS")
public class Customer implements java.io.Serializable {

	@Id
	@GeneratedValue
	private Long id;

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "ADDRESS_ID")
	private Address address;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CREDIT_CARD_ID")
	private CreditCard creditCard;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "CUSTOMERS_PHONES", joinColumns = { @JoinColumn(name = "CUSTOMER_ID") }, inverseJoinColumns = { @JoinColumn(name = "PHONE_ID") })
	private Set<Phone> phones = new HashSet<Phone>();

	public Customer() {
	}

	public Long getId() {
		return this.id;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public CreditCard getCreditCard() {
		return this.creditCard;
	}

	public void setCreditCard(CreditCard creditCard) {
		this.creditCard = creditCard;
	}

	public Set<Phone> getPhones() {
		return this.phones;
	}

	public void setPhones(Set<Phone> phones) {
		this.phones = phones;
	}

	public void addPhone(Phone phone) {
		this.phones.add(phone);
	}

}
