/******************************************************************************
 * Class name: TitanServiceBean.java
 *
 * Date: 13.09.2006 - 16:35:25
 *
 * Copyright (c) 2006 IQBYTE Romania. All rights reserved.
 * IQBYTE - PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *****************************************************************************/
package com.titan.services;

import java.util.Set;

import javax.ejb.Stateless;
import javax.persistence.*;

import com.titan.domain.*;

import ro.iqbyte.arhimed.model.core.common.entities.adm.MedicalPersonnel;
import ro.iqbyte.arhimed.model.core.common.entities.adm.User;

/**
 *
 *
 * @author JTONIC
 *
 */
@Stateless
public class TitanServiceBean implements TitanService {

	@PersistenceContext(unitName = "arhimed")
	EntityManager em;

	/**
	 * @see com.titan.services.TitanService#saveCustomer(com.titan.domain.Customer)
	 */
	public void saveCustomer(Customer customer) {
		em.persist(customer);
	}

	/**
	 * @see com.titan.services.TitanService#dropAddress(Long, Long)
	 */
	public void dropAddress(Long customerId, Long addressId) {
		Customer customer = em.find(Customer.class, customerId);
		Address address = em.find(Address.class, addressId);
		customer.setAddress(null);
		em.remove(address);
		em.merge(customer);

	}

	/**
	 * @see com.titan.services.TitanService#dropCreditCard(java.lang.Long)
	 */
	public void dropCreditCard(Long customerId) {
		Customer customer = em.find(Customer.class, customerId);
		em.remove(customer.getCreditCard());
		customer.setCreditCard(null);
	}

	/**
	 * @see com.titan.services.TitanService#dropPhones(java.lang.Long)
	 */
	public void dropPhones(Long customerId) {
		Customer customer = em.find(Customer.class, customerId);
		Set<Phone> phones = customer.getPhones();
		for (Phone phone : phones) {
			em.remove(phone);
		}
		customer.setPhones(null);
		em.merge(customer);
	}

	public void saveMedicalPersonnel(MedicalPersonnel medicalPersonnel) {
		em.persist(medicalPersonnel);
	}

	public void saveUser(User user) {
		em.persist(user.getMedicalPersonnel());
		em.persist(user);
	}

	/**
	 * @see com.titan.services.TitanService#getMedicalPersonnelForId(java.lang.Long)
	 */
	public MedicalPersonnel getMedicalPersonnelForId(Long medicalPersonnelId) {
		MedicalPersonnel medicalPersonnel = em.find(MedicalPersonnel.class, medicalPersonnelId);
		return medicalPersonnel;
	}

	/**
	 * @see com.titan.services.TitanService#getUserForId(java.lang.Long)
	 */
	public User getUserForId(Long userId) {
		User user = em.find(User.class, userId);
		return user;
	}

	/**
	 * @see com.titan.services.TitanService#getUserForIdAndVisitMP(java.lang.Long)
	 */
	public User getUserForIdAndVisitMP(Long userId) {
		User user = em.find(User.class, userId);
		MedicalPersonnel mp = user.getMedicalPersonnel();
		mp = em.merge(mp);
		return user;
	}

	/**
	 * @see com.titan.services.TitanService#visitMedicalPersonnel(java.lang.Long)
	 */
	public MedicalPersonnel visitMedicalPersonnel(Long id) {
		MedicalPersonnel mp = em.find(MedicalPersonnel.class, id);
		mp = em.merge(mp);
		mp.getMedicalDocs().size();
		return mp;
	}

	public MedicalPersonnel mergeMedicalPersonnel(MedicalPersonnel mp) {
		return em.merge(mp);
	}

	public MedicalPersonnel findMedicalPersonnelBySsn(String ssn) {
		Query qry = em.createQuery("FROM MedicalPersonnel mp WHERE mp.ssn = :ssn"); //$NON-NLS-1$
		qry.setParameter("ssn", ssn); //$NON-NLS-1$
		return (MedicalPersonnel) qry.getSingleResult();
	}

}
