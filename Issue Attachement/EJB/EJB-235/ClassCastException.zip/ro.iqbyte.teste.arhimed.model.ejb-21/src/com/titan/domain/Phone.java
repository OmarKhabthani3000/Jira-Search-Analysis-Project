package com.titan.domain;

import javax.persistence.*;

@Entity
@Table(name = "PHONES")
public class Phone implements java.io.Serializable {

	@Id
	@GeneratedValue
	private int id;
	private String number;
	private int type;

	// required default constructor
	public Phone() {
	}

	public Phone(String number, int type) {
		this.number = number;
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
}
