/******************************************************************************
 * Class name: TitanService.java
 *
 * Date: 13.09.2006 - 16:34:27
 *
 * Copyright (c) 2006 IQBYTE Romania. All rights reserved.
 * IQBYTE - PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *****************************************************************************/
package com.titan.services;

import javax.ejb.Remote;

import com.titan.domain.Customer;

import ro.iqbyte.arhimed.model.core.common.entities.adm.MedicalPersonnel;
import ro.iqbyte.arhimed.model.core.common.entities.adm.User;


/**
 *
 *
 * @author JTONIC
 *
 */
@Remote
public interface TitanService {
	void saveCustomer(Customer customer);

	void dropAddress(Long customerId, Long Address);

	void dropCreditCard(Long customerId);

	void dropPhones(Long customerId);

	void saveMedicalPersonnel(MedicalPersonnel medicalPersonnel);

	void saveUser(User user);

	MedicalPersonnel getMedicalPersonnelForId(Long medicalPersonnelId);

	User getUserForId(Long userId);

	User getUserForIdAndVisitMP(Long userId);

	MedicalPersonnel visitMedicalPersonnel(Long id);

	MedicalPersonnel mergeMedicalPersonnel(MedicalPersonnel mp);
	
	MedicalPersonnel findMedicalPersonnelBySsn(String ssn);

}
