package ro.iqbyte.arhimed.model.teste;

import java.util.Set;

import javax.naming.*;

import com.titan.domain.*;
import com.titan.services.TitanService;

import ro.iqbyte.arhimed.model.core.common.entities.adm.*;
import ro.iqbyte.arhimed.model.core.common.entities.adm.Individual.Gender;

import model.Student;
import model.Teacher;
import services.Save;

public class Main {

	public static void main(String[] args) {
		try {
			Context ctx = new InitialContext();

			TitanService ts = (TitanService) ctx.lookup("TitanServiceBean/remote"); //$NON-NLS-1$

			// Save save = (Save) ctx.lookup("SaveBean/remote"); //$NON-NLS-1$

			// save(save);

			// removeStudent(save, 3L, 4L);

			// removeTeacher(save, 2L, 1L);


			// persistCustomerWithAddress(ts);

			// dropAddress(ts, 1L, 2L);

			// persistCustomerWithCreditCard(ts);

			// dropCreditCard(ts, 1L);

			// persistCustomerWithPhones(ts);

			// dropPhones(ts, 1L);

//			 Nurse nurse1 = new Nurse("1", "Nurse1", "Nurse1"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
//			 nurse1.setGender(Gender.FEMALE);
//			 Physician physician1 = new Physician("2", "Physician1", "Physician1");
//			 //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
//			 physician1.setGender(Gender.MALE);
//
//			 MedicalDoc medDoc1 = new MedicalDoc("1");
//			 MedicalDoc medDoc2 = new MedicalDoc("2");
//
//			 nurse1.addMedicalDoc(medDoc1);
//			 nurse1.addMedicalDoc(medDoc2);
//
//			 MedicalDoc medDoc3 = new MedicalDoc("3");
//			 MedicalDoc medDoc4 = new MedicalDoc("4");
//
//			 physician1.addMedicalDoc(medDoc3);
//			 physician1.addMedicalDoc(medDoc4);
//
//			 User userNurse1 = new User("userNurse1", "userNurse1", nurse1); //$NON-NLS-1$ //$NON-NLS-2$
//			 User userPhysician1 = new User("userPhysician1", "userPhysician1", physician1); //$NON-NLS-1$
//			 //$NON-NLS-2$
//
//			 saveUser(ts, userNurse1);
//			 saveUser(ts, userPhysician1);
//			 System.out.println("S-a salvat userii");

			 MedicalPersonnel mp = getMedicalPersonnelForId(ts, 1L);
			 mp = visitMedicalPersonnel(ts, mp);
			if (mp instanceof Nurse) {
				Nurse nurse = (Nurse) mp;
				Set<MedicalDoc> medicalDocs = nurse.getMedicalDocs();
				for (MedicalDoc doc : medicalDocs) {
					System.out.println("Doc Id = " + doc.getId()); //$NON-NLS-1$
				}
				System.out.println("Nurse = " + nurse.getFirstName()); //$NON-NLS-1$
			}
			if (mp instanceof Physician) {
				Physician physician = (Physician) mp;
				Set<MedicalDoc> medicalDocs = physician.getMedicalDocs();
				for (MedicalDoc doc : medicalDocs) {
					System.out.println("Doc Id = " + doc.getId()); //$NON-NLS-1$
				}
				System.out.println("Physician = " + physician.getFirstName()); //$NON-NLS-1$
			}

			// User user = getUserForId(ts, 2L);
			// MedicalPersonnel mp = user.getMedicalPersonnel();
			// mp = visitMedicalPersonnel(ts, mp);
			// if (mp instanceof Nurse) {
			// Nurse nurse = (Nurse) mp;
			// System.out.println("Nurse = " + nurse.getFirstName()); //$NON-NLS-1$
			// }
			// if (mp instanceof Physician) {
			// Physician physician = (Physician) mp;
			// System.out.println("Physician = " + physician.getFirstName()); //$NON-NLS-1$
			// }

			System.out.println("terminat"); //$NON-NLS-1$
		} catch (NamingException ex) {
			ex.printStackTrace();
		}

	}

	private static void saveMedicalPersonnel(TitanService ts, MedicalPersonnel medicalPersonnel) {
		ts.saveMedicalPersonnel(medicalPersonnel);
	}

	private static void dropPhones(TitanService ts, Long customerId) {
		ts.dropPhones(customerId);
	}

	private static void persistCustomerWithPhones(TitanService ts) {
		Customer customer = new Customer();

		Address address = new Address("Street 1", 1L); //$NON-NLS-1$

		CreditCard creditCard = new CreditCard();
		creditCard.setName("Credit card 1");
		creditCard.setNumber("1");
		creditCard.setCustomer(customer);

		customer.setAddress(address);
		customer.setCreditCard(creditCard);

		customer.addPhone(new Phone("1", 1));
		customer.addPhone(new Phone("2", 2));

		ts.saveCustomer(customer);

	}

	private static void persistCustomerWithAddress(TitanService ts) {
		Customer customer = new Customer();
		Address address = new Address("street 1", 1L); //$NON-NLS-1$
		customer.setAddress(address);

		ts.saveCustomer(customer);

	}

	private static void persistCustomerWithCreditCard(TitanService ts) {
		Customer customer = new Customer();

		Address address = new Address("Street 1", 1L); //$NON-NLS-1$

		CreditCard creditCard = new CreditCard();
		creditCard.setName("Credit card 1");
		creditCard.setNumber("1");
		creditCard.setCustomer(customer);

		customer.setAddress(address);
		customer.setCreditCard(creditCard);

		ts.saveCustomer(customer);
	}

	public static void dropAddress(TitanService titanService, Long customerId, Long addressId) {
		titanService.dropAddress(customerId, addressId);
	}

	public static void dropCreditCard(TitanService titanService, Long customerId) {
		titanService.dropCreditCard(customerId);
	}

	private static void save(Save save) {
		Teacher teacher = new Teacher("Daniel", "Mocanu");
		Student student = new Student("Antonel", "Pazargic");
		teacher.addStudent(student);

		Teacher teacherPer = save.saveTeacher(teacher);
		System.out.println("TeacherId = " + teacherPer.getId());
		System.out.println("StudentId = " + (teacherPer.getStudents().iterator().next()).getId());
	}

	private static void removeStudent(Save save, Long teacherId, Long studentId) {
		save.removeStudent(teacherId, studentId);
	}

	private static void removeTeacher(Save save, Long studentId, Long teacherId) {
		save.removeTeacher(studentId, teacherId);
	}

	private static void saveUser(TitanService ts, User user) {
		ts.saveUser(user);
	}

	private static MedicalPersonnel getMedicalPersonnelForId(TitanService ts, Long id) {
		return ts.getMedicalPersonnelForId(id);
	}

	private static User getUserForIdAndVisitMP(TitanService ts, Long id) {
		return ts.getUserForIdAndVisitMP(id);
	}

	private static User getUserForId(TitanService ts, Long id) {
		return ts.getUserForId(id);
	}

	private static MedicalPersonnel visitMedicalPersonnel(TitanService ts, MedicalPersonnel mp) {
		Long id = mp.getId();
		return ts.visitMedicalPersonnel(id);
	}
}
