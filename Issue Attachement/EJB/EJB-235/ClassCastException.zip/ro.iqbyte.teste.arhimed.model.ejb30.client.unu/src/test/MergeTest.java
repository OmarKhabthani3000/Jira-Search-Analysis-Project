package test;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.junit.*;

import com.titan.services.TitanService;

import ro.iqbyte.arhimed.model.core.common.entities.adm.*;
import ro.iqbyte.arhimed.model.core.common.entities.adm.Individual.Gender;

public class MergeTest {

	Context ctx;
	TitanService ts;

	@Before
	public void setUp() throws Exception {
		ctx = new InitialContext();
		ts = (TitanService) ctx.lookup("TitanServiceBean/remote"); //$NON-NLS-1$
	}

	@After
	public void tearDown() throws Exception {
		ctx.close();
	}

	@Test
//	@Ignore
	public void saveTest() {
		insertUsers();
	}

	@Test
//	@Ignore
	public void mergeTest() {
		MedicalPersonnel mp = ts.findMedicalPersonnelBySsn("1112"); //$NON-NLS-1$
		mp = ts.mergeMedicalPersonnel(mp);
		if (mp instanceof Nurse) {
			Nurse nurse = (Nurse) mp;
			System.out.println("Nurse full name = " + nurse.getFullName()); //$NON-NLS-1$
		}
		if (mp instanceof Physician) {
			Physician physician = (Physician) mp;
			System.out.println("Physician full name = " + physician.getFullName()); //$NON-NLS-1$
		}
	}

	private void insertUsers() {
		Nurse nurse2 = new Nurse("1112", "Nurse2", "Nurse2"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
		nurse2.setGender(Gender.FEMALE);
		Physician physician2 = new Physician("1122", "Physician2", "Physician2");//$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
		physician2.setGender(Gender.MALE);
		MedicalDoc medDoc1 = new MedicalDoc("1111"); //$NON-NLS-1$
		MedicalDoc medDoc2 = new MedicalDoc("1112"); //$NON-NLS-1$
		nurse2.addMedicalDoc(medDoc1);
		nurse2.addMedicalDoc(medDoc2);
		MedicalDoc medDoc3 = new MedicalDoc("1113"); //$NON-NLS-1$
		MedicalDoc medDoc4 = new MedicalDoc("1114"); //$NON-NLS-1$
		physician2.addMedicalDoc(medDoc3);
		physician2.addMedicalDoc(medDoc4);
		User userNurse2 = new User("userNurse112", "userNurse112", nurse2); //$NON-NLS-1$ //$NON-NLS-2$
		User userPhysician2 = new User("userPhysician112", "userPhysician112", physician2); //$NON-NLS-1$//$NON-NLS-2$
		ts.saveUser(userNurse2);
		ts.saveUser(userPhysician2);
	}

}
