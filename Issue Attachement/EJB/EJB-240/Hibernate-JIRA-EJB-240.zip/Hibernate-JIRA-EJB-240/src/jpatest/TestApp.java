package springdeveloper;

import jpatest.Employee;
import jpatest.Address;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 */
public class TestApp
{
    public static void main( String[] args )
    {
        System.out.println( "TestApp!" );
        TestApp app = new TestApp();
        app.run();

    }

    private void run() {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("main");

        EntityManager em = emf.createEntityManager();

        runPersistenceTest(em);

        em.close();

    }

    public void runPersistenceTest(EntityManager em) {

        em.getTransaction().begin();

        Employee e = new Employee();
        e.setId(Long.valueOf(100));
        e.setName("Bubba");
        e.setHomeAddress(new Address("123 Main St", "New York", "NY", "11111"));
        e.setMailAddress(new Address("P.O. Box 123", "New York", "NY", "11111"));

        em.persist(e);

        em.getTransaction().commit();

    }
}
