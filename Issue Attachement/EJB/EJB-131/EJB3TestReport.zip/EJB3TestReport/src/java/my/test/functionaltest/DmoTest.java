package my.test.functionaltest;

import java.util.ArrayList;

import javax.naming.InitialContext;

import junit.framework.TestCase;

import my.test.dmo.A;
import my.test.dmo.B;
import my.test.dmo.C;
import my.test.server.ReportTestServiceInterface;


public class DmoTest extends TestCase {


    public void testNestedLists() {
        InitialContext context;
        try {
            context = new InitialContext();
            System.out.println("Looking up Interface");

            ReportTestServiceInterface testService = (ReportTestServiceInterface) context.lookup("TestReportServiceBean/remote");
            A a = createTestA();
            
            Long aId = testService.save(a);
            
            assertNotNull(aId);
            A loadedA = testService.findCriterionGroupById(aId);

            assertEquals("a.getBList().size()",a.getBList().size(), loadedA.getBList().size());
            assertEquals("b1.getCList().size()",a.getBList().iterator().next().getCList().size(), loadedA.getBList().iterator().next().getCList().size());
                    
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }
    
    private static A createTestA() {        
        ArrayList<C> c1 = new ArrayList<C>();
        c1.add(new C("B1 Value 1"));
        c1.add(new C("B1 Value 2"));
        
        ArrayList<C> c2 = new ArrayList<C>();
        c2.add(new C("B2 Value 1"));
        c2.add(new C("B2 Value 2"));
        
        ArrayList<B> criteria2 = new ArrayList<B>();
        criteria2.add(new B(c1));        
        criteria2.add(new B(c2));        
        return new A(criteria2,true);
    }

}
