package my.test.server;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import my.test.dmo.A;

@Stateless
public class TestReportServiceBean implements ReportTestServiceInterface {
    @PersistenceContext
    static private EntityManager em;


    public Long save(A a) {
        em.persist(a);
        //Here the list sizes are the same
        System.out.println("a.getB:"+ a.getBList().size());
        System.out.println("loadedA.getB:"+ em.find(A.class, a.getId()).getBList().size());
        return a.getId();
    }

    public A findCriterionGroupById(Long itemId) {
        A loadedA = em.find(A.class, itemId);
        //But here are not!
        System.out.println("loadedA.getB:"+ loadedA.getBList().size());        
        return loadedA;    }

}
