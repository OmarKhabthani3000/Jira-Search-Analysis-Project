package my.test.dmo;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class C implements Serializable {
    private static final long serialVersionUID = -8231282509371079598L;

    private Long id;

    private String value;
    
    protected C() {
    }

    public C(String value) {
        this.value=value;
    }

    @Id
    @GeneratedValue
    public Long getId() {
        return id;
    }

    protected void setId(Long id) {
        this.id = id;
    }
    
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


}
