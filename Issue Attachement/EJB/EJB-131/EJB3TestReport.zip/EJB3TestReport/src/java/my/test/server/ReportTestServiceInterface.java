package my.test.server;


import javax.ejb.Remote;

import my.test.dmo.A;


@Remote
public interface ReportTestServiceInterface {

	
    public Long save(A criterionGroup);

    public A findCriterionGroupById(Long itemId);
    
    
}