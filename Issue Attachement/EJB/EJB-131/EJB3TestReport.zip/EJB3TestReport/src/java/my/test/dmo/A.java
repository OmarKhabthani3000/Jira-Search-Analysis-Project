package my.test.dmo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class A implements Serializable {
    private static final long serialVersionUID = 2511041297534386467L;
    private Long id;
    private List<B> bList;
    
    protected A(){
    }
    
    public A(List<B> criteria, boolean uniq){
        this.bList=criteria;
    }

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    public List<B> getBList() {
        return bList;
    }
    
    protected void setBList(List<B> criteria) {
        this.bList = criteria;
    }
    
    @Id
    @GeneratedValue
    public Long getId() {
        return id;
    }
    
    protected void setId(Long id) {
        this.id = id;
    }
    
}
