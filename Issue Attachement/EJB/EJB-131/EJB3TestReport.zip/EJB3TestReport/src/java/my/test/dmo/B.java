package my.test.dmo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class B implements Serializable {

    private static final long serialVersionUID = -5605962658114733783L;

    private Long id;

    private List<C> cList;
            
    protected B() {
        
    }

    public B(List<C> selections) {
        this.cList=selections;
    }
    
    @Id
    @GeneratedValue
    public Long getId() {
        return id;
    }

    protected void setId(Long id) {
        this.id = id;
    }
    
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    public List<C> getCList() {
        return cList;
    }

    protected void setCList(List<C> selections) {
        this.cList = selections;
    }    
}
