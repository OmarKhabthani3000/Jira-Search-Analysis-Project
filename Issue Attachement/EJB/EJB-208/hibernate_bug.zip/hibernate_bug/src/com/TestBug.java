package com;

import junit.framework.TestCase;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestBug extends TestCase {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("manager");
        EntityManager firstSession = emf.createEntityManager();

        Subclass u = new Subclass();
        firstSession.getTransaction().begin();
        firstSession.persist(u);
        firstSession.getTransaction().commit();
        Long newId = u.getId();
        System.out.println("new ID is:" + newId);
        firstSession.close();

        EntityManager secondSession =emf.createEntityManager();
        secondSession.getTransaction().begin();

        // 1.
        Subclass result1 = secondSession.find(Subclass.class, newId);
        System.out.println("1. result is:" + result1);

        // 2.
        Subclass result2 = (Subclass) secondSession.find(AbstractSuperclass.class, newId);
        System.out.println("2. result is:" + result2);

        secondSession.getTransaction().commit();
        secondSession.close();

        emf.close();
    }
}
