package com;

import javax.persistence.Entity;


@Entity
public class Subclass extends AbstractSuperclass {
}
