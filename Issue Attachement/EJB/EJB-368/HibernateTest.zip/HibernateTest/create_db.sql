create database example;
create schema example authorization example;
GRANT ALL ON SCHEMA example TO example;

CREATE TABLE example.country (
  country_id SERIAL,
  name VARCHAR(100) NOT NULL,
  code INTEGER NOT NULL,
  CONSTRAINT pk_country PRIMARY KEY (country_id)
);
ALTER TABLE example.country OWNER TO example;


CREATE TABLE example.province (
  province_id SERIAL,
  country_id INTEGER NOT NULL,
  name VARCHAR(100) NOT NULL,
  CONSTRAINT pk_province PRIMARY KEY (province_id),
  CONSTRAINT fk_province0 FOREIGN KEY (country_id) REFERENCES example.country (country_id)
);
ALTER TABLE example.province OWNER TO example;

CREATE TABLE example.email_address (
  email_address_id SERIAL,
  address varchar(200) NOT NULL,
  CONSTRAINT pk_email_address PRIMARY KEY (email_address_id)
);
ALTER TABLE example.email_address OWNER TO example;
