package example;

import example.domain.Country;
import example.domain.Province;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 * Author: Henriette Harmse Date: 19-Jun-2008 Dariel Solutions
 */
public class Main {

  public static void main(String args[]) {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("example");
    EntityManager em = emf.createEntityManager();

    EntityTransaction tx = em.getTransaction();
    System.out.println("################### tx="+tx);
    tx.begin();
    Country country = new Country("Country", 1);
    em.persist(country);
    tx.commit();
    em.close();


    EntityManager em1 = emf.createEntityManager();
    EntityTransaction tx1 = em1.getTransaction();

    System.out.println("################# tx1="+tx1);
    tx1.begin();
//    Country country1 = em.find(Country.class, country.getId());
    Province province = new Province("Province", country);
    em1.persist(province);
    tx1.commit();
    em1.close();
  }

}
