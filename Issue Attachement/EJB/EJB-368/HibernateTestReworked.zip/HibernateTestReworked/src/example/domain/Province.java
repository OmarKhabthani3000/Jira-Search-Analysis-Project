package example.domain;

public class Province {
  private Integer id;
  private Country country;
  private String name;

  public Province() {
  }

  public Province(String name, Country country) {
    setName(name);
    setCountry(country);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();

    sb.append(super.toString())
            .append("id [" + id)
            .append("] name [").append(getName())
            .append("] country [").append(getCountry()).append("]");

    return sb.toString();
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }
  
  public Country getCountry() {
    return country;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}
