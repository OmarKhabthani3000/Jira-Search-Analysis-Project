package example.domain;


public class Country {

  private Integer id;
  private String name;
  private Integer code;

  public Country() {
  }

  public Country(String name, Integer code) {
    setName(name);
    setCode(code);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();

    sb.append(super.toString())
            .append("id [" + id)
            .append("] name [").append(String.valueOf(getName()))
            .append("] code [").append(String.valueOf(getCode())).append("]");

    return sb.toString();
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Integer getCode() {
    return code;
  }

  public void setCode(Integer code) {
    this.code = code;
  }
}
