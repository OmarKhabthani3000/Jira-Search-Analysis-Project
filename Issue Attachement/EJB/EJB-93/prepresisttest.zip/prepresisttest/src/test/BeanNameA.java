/*
 * Created on 26.10.2005
 */
package test;

import java.io.Serializable;

import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratorType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

@SuppressWarnings({"serial", "unused"})
@Entity(access=AccessType.FIELD)
public class BeanNameA implements Serializable{
   @Id(generate = GeneratorType.AUTO)
   private int id;
   
   @OneToOne(cascade = CascadeType.ALL, optional=true)
   private BeanNameB beanNameB;

   public void makeNewBeanNameB(){
       beanNameB = new BeanNameB();
   }

    @PreUpdate
    public void preUpdate() {
        System.out.println("BeanNameA.preUpdate");
    }

    @PrePersist
    public void prePersist() {
        System.out.println("BeanNameA.prePersist");
    }

    @PostUpdate
    public void postUpdate() {
        System.out.println("BeanNameA.postUpdate");
    }

    @PostPersist
    public void postPersist() {
        System.out.println("BeanNameA.postPersist");
    }

    @PostLoad
    public void postLoad() {
        System.out.println("BeanNameA.postLoad");
    }
   
   public int getId(){
      return id;
   }
}
