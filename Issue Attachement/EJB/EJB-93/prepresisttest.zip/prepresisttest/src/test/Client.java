/*
 * JBoss, the OpenSource J2EE webOS
 *
 * Distributable under LGPL license.
 * See terms of license at gnu.org.
 */
package test;


import javax.naming.InitialContext;



/**
 * Comment
 *
 * @author <a href="mailto:bill@jboss.org">Bill Burke</a>
 * @version $Revision: 1.1.6.3 $
 */
public class Client
{
   public static void main(String[] args) throws Exception
   {
      InitialContext ctx = new InitialContext();
      FirstFacade facade = (FirstFacade) ctx.lookup(FirstFacade.class.getName());
      
      facade.doBeanNameA();
      System.out.println("Done");
   }
}
