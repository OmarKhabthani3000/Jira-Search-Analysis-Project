package test;

import java.util.List;

import javax.ejb.Remote;

@Remote
public interface FirstFacade {
    public int doBeanNameA();
    
    public List<BeanNameA> doQuery();
    
    public List doQuery(String query);
}
