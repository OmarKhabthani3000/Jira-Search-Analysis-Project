/*
 * Created on 08.12.2005
 */
package test;

import java.io.Serializable;

import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.GeneratorType;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

@SuppressWarnings({"serial", "unused"})
@Entity(access=AccessType.FIELD)
public class BeanNameB implements Serializable {
    @Id(generate = GeneratorType.AUTO)
    private int id;
   
    private long creationtime;

    @PreUpdate
    public void preUpdate() {
        System.out.println("BeanNameB.preUpdate");
    }

    @PrePersist
    public void prePersist() {
        this.creationtime = System.currentTimeMillis();
        System.out.println("BeanNameB.prePersist");
    }

    @PostUpdate
    public void postUpdate() {
        System.out.println("BeanNameB.postUpdate");
    }

    @PostPersist
    public void postPersist() {
        System.out.println("BeanNameB.postPersist");
    }

    @PostLoad
    public void postLoad() {
        System.out.println("BeanNameB.postLoad");
    }
}
