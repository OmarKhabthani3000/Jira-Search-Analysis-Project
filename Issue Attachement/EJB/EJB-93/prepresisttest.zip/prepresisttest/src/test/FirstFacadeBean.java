/*
 * Created on 26.10.2005
 */
package test;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public @Stateless class FirstFacadeBean implements FirstFacade {
    @PersistenceContext
    EntityManager manager;
    
    public int doBeanNameA() {
        BeanNameA bean = new BeanNameA();

        manager.persist(bean);
        manager.flush();
        
        manager.refresh(bean);
        System.out.println("---------------");
        bean.makeNewBeanNameB();
        manager.flush();
        

        return bean.getId();
    }

    @SuppressWarnings("unchecked")
    public List<BeanNameA> doQuery() {
        String queryString = "select x from BeanNameA x WHERE x.ts > '2005-10-10'";
        return manager.createQuery(queryString).getResultList();
    }

    public List doQuery(String query) {
        return manager.createQuery(query).getResultList();
    }

}
