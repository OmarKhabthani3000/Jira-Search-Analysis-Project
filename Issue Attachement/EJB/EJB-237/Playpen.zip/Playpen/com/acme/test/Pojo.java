package com.acme.test;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;


@Entity @Table(name="TEST_POJO", uniqueConstraints=@UniqueConstraint(columnNames={"PojoName"}))
public class Pojo implements Serializable {
    private Long ID = new Long(0);
    private String name;
    private Long version = new Long(0);
    private Collection<Attribute> Attributes = null;
    
    public Pojo() {
    	super();
        this.Attributes = new HashSet<Attribute>();
    }
    
    public Pojo(String name)
    {
        this();
        this.name = name;
    }

    @TableGenerator(
            name="ELEMENT_ID_GEN", 
            table="ELEMENT_ID_GEN", 
            pkColumnName="GEN_PK_ID", 
            valueColumnName="GEN_PK_VALUE", 
            pkColumnValue="NEXT_VALUE", 
            allocationSize=1)
    @Id @GeneratedValue(strategy=GenerationType.TABLE, generator="ELEMENT_ID_GEN") 
    @Column(name="PojoID")
    public Long getID() { return ID; }
    private void setID(Long ID) { this.ID = ID; } 
    
    @Version @Column(name="PojoVersion", nullable=false, updatable=true, unique=false) 
	public Long getVersion() { return version; }
    private void setVersion(Long version) { this.version = version; } 
    
    @Basic @Column(name="PojoName", nullable=true, updatable=false, unique=true) 
    public String getName() { return name; }
    private void setName(String name) { this.name = name; }

    @OneToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER, mappedBy="pojo", targetEntity=Attribute.class)
    public Collection<Attribute> getAttributes() { return Attributes; }
    private void setAttributes(Collection<Attribute> Attributes) { this.Attributes = Attributes; }

    public String toString() { return getName(); }
}
