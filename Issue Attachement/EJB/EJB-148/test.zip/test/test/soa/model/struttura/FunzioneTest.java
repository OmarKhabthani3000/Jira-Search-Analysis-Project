package soa.model.struttura;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;

import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.transaction.TransactionManager;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class FunzioneTest extends TestCase {

	public FunzioneTest(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testEntityManager() throws Exception {
		// This is a transactionally aware EntityManager and must be accessed
		// within a JTA transaction
		// Why aren't we using javax.persistence.Persistence? Well, our
		// persistence.xml file uses
		// jta-datasource which means that it is created by the EJB
		// container/embedded JBoss.
		// using javax.persistence.Persistence will just cause us an error

		// Obtain JBoss transaction
		TransactionManager tm = (TransactionManager) getInitialContext()
				.lookup("java:/TransactionManager");

		EntityManager em = (EntityManager) getInitialContext().lookup(
				"java:/cbidb");

		tm.begin();

		FunzioneInfoLog infoLog1 = new FunzioneInfoLog();
		infoLog1.setInfo("Conto");
		infoLog1.setTipo("String");
		infoLog1.setAttivo(true);
		FunzioneInfoLog infoLog2 = new FunzioneInfoLog();
		infoLog2.setInfo("filiale");
		infoLog2.setTipo("String");
		infoLog2.setAttivo(true);

		Set<FunzioneInfoLog> infoLog = new HashSet<FunzioneInfoLog>();
		infoLog.add(infoLog1);
		infoLog.add(infoLog2);

		Funzione funzione = new Funzione();
		funzione.setClasse("abc");
		funzione.setMetodo("met");
		funzione.setAttivo(true);
		funzione.setLivelloLog("DEBUG");
		funzione.setLivelloTrace("FATAL");
		funzione.setInfoLog(infoLog);

		em.persist(funzione);

		assertTrue(funzione.getId() > 0);

		int id = funzione.getId();

		System.out.println("created fun in DB with id: " + id);

		tm.commit();

		tm.begin();
		funzione = em.find(Funzione.class, id);
		tm.commit();
		
		
		assertNotNull(funzione);
		assertEquals(2, funzione.getInfoLog().size());
				
		tm.begin();
		funzione = em.find(Funzione.class, id);
		tm.commit();

	}

	public void testDummy() throws Exception {
		assertTrue(true);
	}

	public static Test suite() {
		TestSuite suite = new TestSuite(FunzioneTest.class);
		return suite;
	}

	public static InitialContext getInitialContext() throws Exception {
		Hashtable props = getInitialContextProperties();
		return new InitialContext(props);
	}

	private static Hashtable getInitialContextProperties() {
		Hashtable props = new Hashtable();
		props.put("java.naming.factory.initial",
				"org.jnp.interfaces.LocalOnlyContextFactory");
		props.put("java.naming.factory.url.pkgs",
				"org.jboss.naming:org.jnp.interfaces");
		return props;
	}

}
