package soa;

import java.net.URL;

import junit.extensions.TestSetup;
import junit.framework.Test;
import junit.framework.TestSuite;

import org.jboss.ejb3.embedded.EJB3StandaloneBootstrap;
import org.jboss.ejb3.embedded.EJB3StandaloneDeployer;

public class AllModelTests {

	public static Test suite() {
		TestSuite suite = new TestSuite("Test for soa.model");
		// $JUnit-BEGIN$
//		suite.addTestSuite(soa.model.security.EnvironmentTest.class);
		suite.addTestSuite(soa.model.struttura.FunzioneTest.class);
		// $JUnit-END$

		// setup test so that embedded JBoss is started/stopped once for all
		// tests here.
		TestSetup wrapper = new TestSetup(suite) {
			protected void setUp() {
				startupEmbeddedJboss();
			}

			protected void tearDown() {
				shutdownEmbeddedJboss();
			}
		};

		return wrapper;

		// return suite;
	}

	public static void startupEmbeddedJboss() {
		EJB3StandaloneBootstrap.boot(null);
		// EJB3StandaloneBootstrap.scanClasspath();

		try {
			EJB3StandaloneDeployer deployer = EJB3StandaloneBootstrap
					.createDeployer();
			URL deployDir = new URL(
					"file://////D:/Eclipse%20Workspaces/SOA_EJB3/Soa/build");
			deployer.getDeployDirs().add(deployDir);
			deployer.create();
			deployer.start();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void shutdownEmbeddedJboss() {
		EJB3StandaloneBootstrap.shutdown();
	}

}
