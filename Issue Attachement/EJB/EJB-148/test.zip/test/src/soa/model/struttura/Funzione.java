package soa.model.struttura;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;

import org.hibernate.annotations.CollectionOfElements;
import org.hibernate.annotations.Where;

@Entity
@Table(name = "funzioni")
public class Funzione implements Serializable {
	private int id;
	private String classe;
	private String metodo;
	private boolean attivo;
	private String livelloLog;
	private String livelloTrace;
	private Set<FunzioneInfoLog> infoLog = new HashSet<FunzioneInfoLog>();

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getClasse() {
		return classe;
	}

	public void setClasse(String classe) {
		this.classe = classe;
	}

	public String getMetodo() {
		return metodo;
	}

	public void setMetodo(String metodo) {
		this.metodo = metodo;
	}


	@CollectionOfElements(fetch= FetchType.EAGER)
	@JoinTable(name = "funzioni_infolog", joinColumns = @JoinColumn(name = "id"))
	@Where(clause="attivo=true")
	public Set<FunzioneInfoLog> getInfoLog() {
		return infoLog;
	}

	public void setInfoLog(Set<FunzioneInfoLog> infoLog) {
		this.infoLog = infoLog;
	}

	public boolean isAttivo() {
		return attivo;
	}

	public void setAttivo(boolean attivo) {
		this.attivo = attivo;
	}

	public String getLivelloLog() {
		return livelloLog;
	}

	public void setLivelloLog(String livelloLog) {
		this.livelloLog = livelloLog;
	}

	public String getLivelloTrace() {
		return livelloTrace;
	}

	public void setLivelloTrace(String livelloTrace) {
		this.livelloTrace = livelloTrace;
	}
}

