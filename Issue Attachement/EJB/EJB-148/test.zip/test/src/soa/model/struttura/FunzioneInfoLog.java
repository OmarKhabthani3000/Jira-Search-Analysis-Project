package soa.model.struttura;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class FunzioneInfoLog implements Serializable {

	// private int id;
	private String info;
	private String tipo;
	private boolean attivo;

	public boolean isAttivo() {
		return attivo;
	}

	public void setAttivo(boolean attivo) {
		this.attivo = attivo;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}
	
	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		final FunzioneInfoLog infoLog = (FunzioneInfoLog) o;
		if (!info.equals(infoLog.getInfo()))
			return false;
		if (!tipo.equals(infoLog.getTipo()))
			return false;
		return true;
	}

	public int hashCode() {
		return (int) (info + "-" + tipo).hashCode();
	}


}
