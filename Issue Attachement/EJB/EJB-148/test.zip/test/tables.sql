CREATE DATABASE cbi;
USE cbi;

DROP TABLE IF EXISTS `cbi`.`funzioni`;
CREATE TABLE  `cbi`.`funzioni` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `classe` varchar(45) NOT NULL,
  `metodo` varchar(45) NOT NULL,
  `attivo` tinyint(1) NOT NULL default '0',
  `livellolog` varchar(5) NOT NULL,
  `livellotrace` varchar(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `cbi`.`funzioni` (`id`,`classe`,`metodo`,`attivo`,`livellolog`,`livellotrace`) VALUES
 (1,'cbi.bean.cc.SampleBean','sample','1', 'DEBUG', 'WARN'),
 (2,'cbi.bean.cc.DemoBean','test','1', 'DEBUG', 'INFO');



DROP TABLE IF EXISTS `cbi`.`funzioni_infolog`;
CREATE TABLE  `cbi`.`funzioni_infolog` (
  `id` int(10) unsigned NOT NULL,
  `info` varchar(10) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `attivo` tinyint(1) NOT NULL default '0',
  KEY `FKDCE1D8EE4DE4E04F` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `cbi`.`funzioni_infolog` (`id`,`info`,`tipo`,`attivo`) VALUES
 (1,'filiale','String','1'),
 (1,'Conto','String','1'),
 (2,'filiale','String','1'),
 (2,'Conto','String','1');

