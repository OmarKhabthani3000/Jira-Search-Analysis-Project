package test.service.ejb;


import test.domain.*;
import test.service.*;

import javax.ejb.*;
import javax.persistence.*;
import java.util.*;

@Stateless
@Remote(value = test.service.PKManager.class)
public class PKManagerBean implements PKManager {
    @PersistenceContext(unitName = "bug")
    private EntityManager manager = null;


    public List<Conference> getOldConferences() {
        return manager.createQuery("FROM " + Conference.class.getName() + " AS c ORDER BY c.date DESC")
                .getResultList();
    }
}
