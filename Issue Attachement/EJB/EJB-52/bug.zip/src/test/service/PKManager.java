package test.service;

import test.domain.*;

import java.io.*;
import java.util.*;

public interface PKManager extends Serializable {
    List<Conference> getOldConferences();
}
