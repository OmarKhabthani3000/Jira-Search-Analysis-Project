package test;

import test.service.*;

import javax.naming.*;

public class Main {
    public static void main(String[] args) throws Exception {
        PKManager manager = (PKManager) new InitialContext().lookup(PKManager.class.getName());
        System.out.println("conferences count: " + manager.getOldConferences());
    }
}
