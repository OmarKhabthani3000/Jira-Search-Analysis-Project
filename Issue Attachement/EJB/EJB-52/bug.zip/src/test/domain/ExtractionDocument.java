package test.domain;

import org.hibernate.annotations.*;
import static org.hibernate.annotations.CacheConcurrencyStrategy.READ_WRITE;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.*;

@Entity
@Table(name = "portal_pk_docs_extraction")
@Cache(usage = READ_WRITE)
@org.hibernate.annotations.Entity(dynamicInsert = true, dynamicUpdate = true)
@Proxy
public class ExtractionDocument implements Serializable {
    private Long id;
    private byte[] body;
    private ExtractionDocumentInfo documentInfo;

    public ExtractionDocument() {
    }

    public ExtractionDocument(ExtractionDocumentInfo documentInfo) {
        this.documentInfo = documentInfo;
    }


    @Id(generate = GeneratorType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @OneToOne
    @JoinColumn(name = "document_info_id", unique = true)
    public ExtractionDocumentInfo getDocumentInfo() {
        return documentInfo;
    }

    public void setDocumentInfo(ExtractionDocumentInfo documentInfo) {
        this.documentInfo = documentInfo;
    }

    @Column(nullable = false)
    public byte[] getBody() {
        return body;
    }

    public void setBody(byte[] body) {
        this.body = body;
    }
}
