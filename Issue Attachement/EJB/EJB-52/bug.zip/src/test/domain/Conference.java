package test.domain;

import org.hibernate.annotations.*;
import static org.hibernate.annotations.CacheConcurrencyStrategy.READ_WRITE;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.CascadeType;
import java.io.*;
import java.util.*;

@Entity
@Table(name = "portal_pk_conference")
@Inheritance(
        strategy = InheritanceType.SINGLE_TABLE,
        discriminatorType = DiscriminatorType.CHAR,
        discriminatorValue = "X"
)
@DiscriminatorColumn(name = "type")

@Cache(usage = READ_WRITE)
@org.hibernate.annotations.Entity(dynamicInsert = true, dynamicUpdate = true)

public class Conference implements Serializable {
    private Long id;
    private Date date;
    private test.domain.ExtractionDocumentInfo extractionDocument;



    @OneToOne(mappedBy = "conference", cascade = CascadeType.ALL)
    public test.domain.ExtractionDocumentInfo getExtractionDocument() {
        return extractionDocument;
    }

    public void setExtractionDocument(test.domain.ExtractionDocumentInfo extractionDocument) {
        this.extractionDocument = extractionDocument;
    }


    public Conference() {
        date = new Date();
    }

    @Id(generate = GeneratorType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Column(name = "c_date", nullable = false)
    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final Conference that = (Conference) o;

        return !(date != null ? !date.equals(that.date) : that.date != null);

    }

    public int hashCode() {
        return (date != null ? date.hashCode() : 0);
    }
}
