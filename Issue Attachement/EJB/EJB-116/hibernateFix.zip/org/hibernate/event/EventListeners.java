//$Id: EventListeners.java,v 1.6 2005/10/16 13:27:54 epbernard Exp $
package org.hibernate.event;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

import org.hibernate.AssertionFailure;
import org.hibernate.MappingException;
import org.hibernate.cfg.Configuration;
import org.hibernate.event.def.DefaultAutoFlushEventListener;
import org.hibernate.event.def.DefaultDeleteEventListener;
import org.hibernate.event.def.DefaultDirtyCheckEventListener;
import org.hibernate.event.def.DefaultEvictEventListener;
import org.hibernate.event.def.DefaultFlushEntityEventListener;
import org.hibernate.event.def.DefaultFlushEventListener;
import org.hibernate.event.def.DefaultInitializeCollectionEventListener;
import org.hibernate.event.def.DefaultLoadEventListener;
import org.hibernate.event.def.DefaultLockEventListener;
import org.hibernate.event.def.DefaultMergeEventListener;
import org.hibernate.event.def.DefaultPersistEventListener;
import org.hibernate.event.def.DefaultPostLoadEventListener;
import org.hibernate.event.def.DefaultPreLoadEventListener;
import org.hibernate.event.def.DefaultRefreshEventListener;
import org.hibernate.event.def.DefaultReplicateEventListener;
import org.hibernate.event.def.DefaultSaveEventListener;
import org.hibernate.event.def.DefaultSaveOrUpdateCopyEventListener;
import org.hibernate.event.def.DefaultSaveOrUpdateEventListener;
import org.hibernate.event.def.DefaultUpdateEventListener;
import org.hibernate.event.def.DefaultPersistOnFlushEventListener;
import org.hibernate.util.Cloneable;

/**
 * A convience holder for all defined session event listeners.
 *
 * @author Steve Ebersole
 */
public class EventListeners extends Cloneable implements Serializable {

   private List<LoadEventListener> loadEventListeners = Arrays.asList((LoadEventListener)new DefaultLoadEventListener());
   private List<SaveOrUpdateEventListener> saveOrUpdateEventListeners = Arrays.asList((SaveOrUpdateEventListener)new DefaultSaveOrUpdateEventListener());
   private List<MergeEventListener> mergeEventListeners = Arrays.asList((MergeEventListener)new DefaultMergeEventListener());
   private List<PersistEventListener> persistEventListeners = Arrays.asList((PersistEventListener)new DefaultPersistEventListener());
   private List<PersistEventListener> persistOnFlushEventListeners = Arrays.asList((PersistEventListener)new DefaultPersistOnFlushEventListener());
   private List<ReplicateEventListener> replicateEventListeners = Arrays.asList((ReplicateEventListener)new DefaultReplicateEventListener());
   private List<DeleteEventListener> deleteEventListeners = Arrays.asList((DeleteEventListener)new DefaultDeleteEventListener());
   private List<AutoFlushEventListener> autoFlushEventListeners = Arrays.asList((AutoFlushEventListener)new DefaultAutoFlushEventListener());
   private List<DirtyCheckEventListener> dirtyCheckEventListeners = Arrays.asList((DirtyCheckEventListener)new DefaultDirtyCheckEventListener());
   private List<FlushEventListener> flushEventListeners = Arrays.asList((FlushEventListener)new DefaultFlushEventListener());
   private List<EvictEventListener> evictEventListeners = Arrays.asList((EvictEventListener)new DefaultEvictEventListener());
   private List<LockEventListener> lockEventListeners = Arrays.asList((LockEventListener)new DefaultLockEventListener());
   private List<RefreshEventListener> refreshEventListeners = Arrays.asList((RefreshEventListener)new DefaultRefreshEventListener());
   private List<FlushEntityEventListener> flushEntityEventListeners = Arrays.asList((FlushEntityEventListener)new DefaultFlushEntityEventListener());
   private List<InitializeCollectionEventListener> initializeCollectionEventListeners =
         Arrays.asList((InitializeCollectionEventListener)new DefaultInitializeCollectionEventListener());

   private List<PostLoadEventListener> postLoadEventListeners = Arrays.asList((PostLoadEventListener)new DefaultPostLoadEventListener());
   private List<PreLoadEventListener> preLoadEventListeners = Arrays.asList((PreLoadEventListener)new DefaultPreLoadEventListener());
   
   private List<PreDeleteEventListener> preDeleteEventListeners = (List<PreDeleteEventListener>)new ArrayList<PreDeleteEventListener>();
   private List<PreUpdateEventListener> preUpdateEventListeners = new ArrayList<PreUpdateEventListener>();
   private List<PreInsertEventListener> preInsertEventListeners = new ArrayList<PreInsertEventListener>();
   private List<PostDeleteEventListener> postDeleteEventListeners = new ArrayList<PostDeleteEventListener>();
   private List<PostUpdateEventListener> postUpdateEventListeners = new ArrayList<PostUpdateEventListener>();
   private List<PostInsertEventListener> postInsertEventListeners = new ArrayList<PostInsertEventListener>();
   private List<PostDeleteEventListener> postCommitDeleteEventListeners = new ArrayList<PostDeleteEventListener>();
   private List<PostUpdateEventListener> postCommitUpdateEventListeners = new ArrayList<PostUpdateEventListener>();
   private List<PostInsertEventListener> postCommitInsertEventListeners = new ArrayList<PostInsertEventListener>();

   private List<SaveOrUpdateEventListener> saveEventListeners = Arrays.asList((SaveOrUpdateEventListener)new DefaultSaveEventListener());
   private List<SaveOrUpdateEventListener> updateEventListeners = Arrays.asList((SaveOrUpdateEventListener)new DefaultUpdateEventListener());
   private List<MergeEventListener> saveOrUpdateCopyEventListeners = Arrays.asList((MergeEventListener)new DefaultSaveOrUpdateCopyEventListener());//saveOrUpdateCopy() is deprecated!

   private static Map<String, Class> eventInterfaceFromType;

   static {
      eventInterfaceFromType = new HashMap<String, Class>();

      eventInterfaceFromType.put("auto-flush", AutoFlushEventListener.class);
      eventInterfaceFromType.put("merge", MergeEventListener.class);
      eventInterfaceFromType.put("create", PersistEventListener.class);
      eventInterfaceFromType.put("create-onflush", PersistEventListener.class);
      eventInterfaceFromType.put("delete", DeleteEventListener.class);
      eventInterfaceFromType.put("dirty-check", DirtyCheckEventListener.class);
      eventInterfaceFromType.put("evict", EvictEventListener.class);
      eventInterfaceFromType.put("flush", FlushEventListener.class);
      eventInterfaceFromType.put("flush-entity", FlushEntityEventListener.class);
      eventInterfaceFromType.put("load", LoadEventListener.class);
      eventInterfaceFromType.put("load-collection", InitializeCollectionEventListener.class);
      eventInterfaceFromType.put("lock", LockEventListener.class);
      eventInterfaceFromType.put("refresh", RefreshEventListener.class);
      eventInterfaceFromType.put("replicate", ReplicateEventListener.class);
      eventInterfaceFromType.put("save-update", SaveOrUpdateEventListener.class);
      eventInterfaceFromType.put("save", SaveOrUpdateEventListener.class);
      eventInterfaceFromType.put("update", SaveOrUpdateEventListener.class);
      eventInterfaceFromType.put("pre-load", PreLoadEventListener.class);
      eventInterfaceFromType.put("pre-update", PreUpdateEventListener.class);
      eventInterfaceFromType.put("pre-delete", PreDeleteEventListener.class);
      eventInterfaceFromType.put("pre-insert", PreInsertEventListener.class);
      eventInterfaceFromType.put("post-load", PostLoadEventListener.class);
      eventInterfaceFromType.put("post-update", PostUpdateEventListener.class);
      eventInterfaceFromType.put("post-delete", PostDeleteEventListener.class);
      eventInterfaceFromType.put("post-insert", PostInsertEventListener.class);
      eventInterfaceFromType.put("post-commit-update", PostUpdateEventListener.class);
      eventInterfaceFromType.put("post-commit-delete", PostDeleteEventListener.class);
      eventInterfaceFromType.put("post-commit-insert", PostInsertEventListener.class);
      eventInterfaceFromType = Collections.unmodifiableMap( eventInterfaceFromType );
   }

   public Class getListenerClassFor(String type) {
      Class clazz = (Class) eventInterfaceFromType.get(type);
      
      if (clazz == null) {
         throw new MappingException("Unrecognized listener type [" + type + "]");
      }

      return clazz;
   }

    public LoadEventListener[] getLoadEventListeners() {
        return (LoadEventListener[])loadEventListeners.toArray();
    }

    public void setLoadEventListeners(LoadEventListener... loadEventListener) {
        this.loadEventListeners = Arrays.asList(loadEventListener);
    }

    public void addLoadEventListeners(LoadEventListener loadEventListener) {
        this.loadEventListeners.add(loadEventListener);
    }

   public ReplicateEventListener[] getReplicateEventListeners() {
      return (ReplicateEventListener[])replicateEventListeners.toArray();
   }

   public void setReplicateEventListeners(ReplicateEventListener... replicateEventListener) {
      this.replicateEventListeners = Arrays.asList(replicateEventListener);
   }

   public void addReplicateEventListener(ReplicateEventListener replicateEventListener) {
      this.replicateEventListeners.add(replicateEventListener);
   }

   public DeleteEventListener[] getDeleteEventListeners() {
      return (DeleteEventListener[])deleteEventListeners.toArray();
   }

   public void setDeleteEventListeners(DeleteEventListener... deleteEventListener) {
      this.deleteEventListeners = Arrays.asList(deleteEventListener);
   }

   public void addDeleteEventListener(DeleteEventListener deleteEventListener) {
      this.deleteEventListeners.add(deleteEventListener);
   }

   public AutoFlushEventListener[] getAutoFlushEventListeners() {
      return (AutoFlushEventListener[])autoFlushEventListeners.toArray();
   }

   public void setAutoFlushEventListeners(AutoFlushEventListener... autoFlushEventListener) {
      this.autoFlushEventListeners = Arrays.asList(autoFlushEventListener);
   }

   public void addAutoFlushEventListener(AutoFlushEventListener autoFlushEventListener) {
      this.autoFlushEventListeners.add(autoFlushEventListener);
   }

   public DirtyCheckEventListener[] getDirtyCheckEventListeners() {
      return (DirtyCheckEventListener[])dirtyCheckEventListeners.toArray();
   }

   public void setDirtyCheckEventListeners(DirtyCheckEventListener... dirtyCheckEventListener) {
      this.dirtyCheckEventListeners = Arrays.asList(dirtyCheckEventListener);
   }

   public void addDirtyCheckEventListener(DirtyCheckEventListener dirtyCheckEventListener) {
      this.dirtyCheckEventListeners.add(dirtyCheckEventListener);
   }

   public FlushEventListener[] getFlushEventListeners() {
      return (FlushEventListener[])flushEventListeners.toArray();
   }

   public void setFlushEventListeners(FlushEventListener... flushEventListener) {
      this.flushEventListeners = Arrays.asList(flushEventListener);
   }

   public void addFlushEventListener(FlushEventListener flushEventListener) {
      this.flushEventListeners.add(flushEventListener);
   }

   public EvictEventListener[] getEvictEventListeners() {
      return (EvictEventListener[])evictEventListeners.toArray();
   }

   public void setEvictEventListeners(EvictEventListener... evictEventListener) {
      this.evictEventListeners = Arrays.asList(evictEventListener);
   }

   public void addEvictEventListener(EvictEventListener evictEventListener) {
      this.evictEventListeners.add(evictEventListener);
   }

   public LockEventListener[] getLockEventListeners() {
      return (LockEventListener[])lockEventListeners.toArray();
   }

   public void setLockEventListeners(LockEventListener... lockEventListener) {
      this.lockEventListeners = Arrays.asList(lockEventListener);
   }

   public void addLockEventListener(LockEventListener lockEventListener) {
      this.lockEventListeners.add(lockEventListener);
   }

   public RefreshEventListener[] getRefreshEventListeners() {
      return (RefreshEventListener[])refreshEventListeners.toArray();
   }

   public void setRefreshEventListeners(RefreshEventListener... refreshEventListener) {
      this.refreshEventListeners = Arrays.asList(refreshEventListener);
   }

   public void addRefreshEventListener(RefreshEventListener refreshEventListener) {
      this.refreshEventListeners.add(refreshEventListener);
   }

   public InitializeCollectionEventListener[] getInitializeCollectionEventListeners() {
      return (InitializeCollectionEventListener[])initializeCollectionEventListeners.toArray();
   }

   public void setInitializeCollectionEventListeners(InitializeCollectionEventListener... initializeCollectionEventListener) {
      this.initializeCollectionEventListeners = Arrays.asList(initializeCollectionEventListener);
   }
   
   public void addInitializeCollectionEventListener(InitializeCollectionEventListener initializeCollectionEventListener) {
      this.initializeCollectionEventListeners.add(initializeCollectionEventListener);
   }
   
   public FlushEntityEventListener[] getFlushEntityEventListeners() {
      return (FlushEntityEventListener[])flushEntityEventListeners.toArray();
   }
   
   public void setFlushEntityEventListeners(FlushEntityEventListener... flushEntityEventListener) {
      this.flushEntityEventListeners = Arrays.asList(flushEntityEventListener);
   }
   
   public void addFlushEntityEventListener(FlushEntityEventListener flushEntityEventListener) {
      this.flushEntityEventListeners.add(flushEntityEventListener);
   }
   
   public SaveOrUpdateEventListener[] getSaveOrUpdateEventListeners() {
      return (SaveOrUpdateEventListener[])saveOrUpdateEventListeners.toArray();
   }
   
   public void setSaveOrUpdateEventListeners(SaveOrUpdateEventListener... saveOrUpdateEventListener) {
      this.saveOrUpdateEventListeners = Arrays.asList(saveOrUpdateEventListener);
   }
   
   public void addSaveOrUpdateEventListener(SaveOrUpdateEventListener saveOrUpdateEventListener) {
      this.saveOrUpdateEventListeners.add(saveOrUpdateEventListener);
   }
   
   public MergeEventListener[] getMergeEventListeners() {
      return (MergeEventListener[])mergeEventListeners.toArray();
   }
   
   public void setMergeEventListeners(MergeEventListener... mergeEventListener) {
      this.mergeEventListeners = Arrays.asList(mergeEventListener);
   }
   
   public void addMergeEventListener(MergeEventListener mergeEventListener) {
      this.mergeEventListeners.add(mergeEventListener);
   }
   
   public PersistEventListener[] getPersistEventListeners() {
      return (PersistEventListener[])persistEventListeners.toArray();
   }
   
   public void setPersistEventListeners(PersistEventListener... createEventListener) {
      this.persistEventListeners = Arrays.asList(createEventListener);
   }

   public void addPersistEventListener(PersistEventListener createEventListener) {
      this.persistEventListeners.add(createEventListener);
   }

   public PersistEventListener[] getPersistOnFlushEventListeners() {
      return (PersistEventListener[])persistOnFlushEventListeners.toArray();
   }

   public void setPersistOnFlushEventListeners(PersistEventListener... createEventListener) {
      this.persistOnFlushEventListeners = Arrays.asList(createEventListener);
   }
   
   public void addPersistOnFlushEventListener(PersistEventListener createEventListener) {
      this.persistOnFlushEventListeners.add(createEventListener);
   }
   
   public MergeEventListener[] getSaveOrUpdateCopyEventListeners() {
      return (MergeEventListener[])saveOrUpdateCopyEventListeners.toArray();
   }
   
   public void setSaveOrUpdateCopyEventListeners(MergeEventListener... saveOrUpdateCopyEventListener) {
      this.saveOrUpdateCopyEventListeners = Arrays.asList(saveOrUpdateCopyEventListener);
   }
   
   public void addSaveOrUpdateCopyEventListener(MergeEventListener saveOrUpdateCopyEventListener) {
      this.saveOrUpdateCopyEventListeners.add(saveOrUpdateCopyEventListener);
   }
   
   public SaveOrUpdateEventListener[] getSaveEventListeners() {
      return (SaveOrUpdateEventListener[])saveEventListeners.toArray();
   }
   
   public void setSaveEventListeners(SaveOrUpdateEventListener... saveEventListener) {
      this.saveEventListeners = Arrays.asList(saveEventListener);
   }
   
   public void addSaveEventListener(SaveOrUpdateEventListener saveEventListener) {
      this.saveEventListeners.add(saveEventListener);
   }
   
   public SaveOrUpdateEventListener[] getUpdateEventListeners() {
      return (SaveOrUpdateEventListener[])updateEventListeners.toArray();
   }
   
   public void setUpdateEventListeners(SaveOrUpdateEventListener... updateEventListener) {
      this.updateEventListeners = Arrays.asList(updateEventListener);
   }

   public void addUpdateEventListener(SaveOrUpdateEventListener updateEventListener) {
      this.updateEventListeners.add(updateEventListener);
   }

   public PostLoadEventListener[] getPostLoadEventListeners() {
      return (PostLoadEventListener[])postLoadEventListeners.toArray();
   }

   public void setPostLoadEventListeners(PostLoadEventListener... postLoadEventListener) {
      this.postLoadEventListeners = Arrays.asList(postLoadEventListener);
   }

   public void addPostLoadEventListener(PostLoadEventListener postLoadEventListener) {
      this.postLoadEventListeners.add(postLoadEventListener);
   }

   public PreLoadEventListener[] getPreLoadEventListeners() {
      return (PreLoadEventListener[])preLoadEventListeners.toArray();
   }

   public void setPreLoadEventListeners(PreLoadEventListener... preLoadEventListener) {
      this.preLoadEventListeners = Arrays.asList(preLoadEventListener);
   }

   public void addPreLoadEventListener(PreLoadEventListener preLoadEventListener) {
      this.preLoadEventListeners.add(preLoadEventListener);
   }

   public PostDeleteEventListener[] getPostDeleteEventListeners() {
      return (PostDeleteEventListener[])postDeleteEventListeners.toArray();
   }
   
   public PostInsertEventListener[] getPostInsertEventListeners() {
      return (PostInsertEventListener[])postInsertEventListeners.toArray();
   }
   
   public PostUpdateEventListener[] getPostUpdateEventListeners() {
      return (PostUpdateEventListener[])postUpdateEventListeners.toArray();
   }
   
   public void setPostDeleteEventListeners(PostDeleteEventListener... postDeleteEventListener) {
      this.postDeleteEventListeners = Arrays.asList(postDeleteEventListener);
   }
   
   public void addPostDeleteEventListener(PostDeleteEventListener postDeleteEventListener) {
      this.postDeleteEventListeners.add(postDeleteEventListener);
   }
   
   public void setPostInsertEventListeners(PostInsertEventListener... postInsertEventListener) {
      this.postInsertEventListeners = Arrays.asList(postInsertEventListener);
   }
   
   public void addPostInsertEventListener(PostInsertEventListener postInsertEventListener) {
      this.postInsertEventListeners.add(postInsertEventListener);
   }
   
   public void setPostUpdateEventListeners(PostUpdateEventListener... postUpdateEventListener) {
      this.postUpdateEventListeners = Arrays.asList(postUpdateEventListener);
   }
   
   public void addPostUpdateEventListener(PostUpdateEventListener postUpdateEventListener) {
      this.postUpdateEventListeners.add(postUpdateEventListener);
   }
   
   public PreDeleteEventListener[] getPreDeleteEventListeners() {
      return (PreDeleteEventListener[])(preDeleteEventListeners.toArray());
   }
   
   public void setPreDeleteEventListeners(PreDeleteEventListener... preDeleteEventListener) {
      this.preDeleteEventListeners = Arrays.asList(preDeleteEventListener);
   }
   
   public void addPreDeleteEventListener(PreDeleteEventListener preDeleteEventListener) {
      this.preDeleteEventListeners.add(preDeleteEventListener);
   }
   
   public PreInsertEventListener[] getPreInsertEventListeners() {
      return (PreInsertEventListener[])preInsertEventListeners.toArray();
   }
   
   public void setPreInsertEventListeners(PreInsertEventListener... preInsertEventListener) {
      this.preInsertEventListeners = Arrays.asList(preInsertEventListener);
   }
   
   public void addPreInsertEventListener(PreInsertEventListener... preInsertEventListener) {
	  List<PreInsertEventListener> l = (List<PreInsertEventListener>)Arrays.asList(preInsertEventListener);
	  for (PreInsertEventListener e : l)
		  this.preInsertEventListeners.add(e);
   }
   
   public PreUpdateEventListener[] getPreUpdateEventListeners() {
      return (PreUpdateEventListener[])preUpdateEventListeners.toArray();
   }
   
   public void setPreUpdateEventListeners(PreUpdateEventListener... preUpdateEventListener) {
      this.preUpdateEventListeners = Arrays.asList(preUpdateEventListener);
   }
   
   public void addPreUpdateEventListener(PreUpdateEventListener... preUpdateEventListener) {
	  List<PreUpdateEventListener> l = (List<PreUpdateEventListener>)Arrays.asList(preUpdateEventListener);
	  for (PreUpdateEventListener e : l)
		  this.preUpdateEventListeners.add(e);
   }
   
   /**
    * Call <tt>initialize()</tt> on any listeners that implement
    * <tt>Initializable</tt>.
    * @see Initializable
    */
   public void initializeListeners(Configuration cfg) {
      Field[] fields = getClass().getDeclaredFields();
      for ( int i = 0; i < fields.length; i++ ) {
         Object[] listeners;
         try {
            Object listener = fields[i].get(this);
            if (listener instanceof Object[]) {
               listeners = (Object[]) listener;
            }
            else {
               continue;
            }

         }
         catch (Exception e) {
            throw new AssertionFailure("could not init listeners");
         }
         int length = listeners.length;
         for (int index = 0 ; index < length ; index++) {
            Object listener = listeners[index];
            if (listener instanceof Initializable ) {
               ( (Initializable) listener ).initialize(cfg);
            }
         }

      }
   }

   public PostDeleteEventListener[] getPostCommitDeleteEventListeners() {
      return (PostDeleteEventListener[])postCommitDeleteEventListeners.toArray();
   }

   public void setPostCommitDeleteEventListeners(
         PostDeleteEventListener... postCommitDeleteEventListeners) {
      this.postCommitDeleteEventListeners = Arrays.asList(postCommitDeleteEventListeners);
   }

   public void addPostCommitDeleteEventListener(
         PostDeleteEventListener postCommitDeleteEventListeners) {
      this.postCommitDeleteEventListeners.add(postCommitDeleteEventListeners);
   }

   public PostInsertEventListener[] getPostCommitInsertEventListeners() {
      return (PostInsertEventListener[])postCommitInsertEventListeners.toArray();
   }

   public void setPostCommitInsertEventListeners(
         PostInsertEventListener... postCommitInsertEventListeners) {
      this.postCommitInsertEventListeners = Arrays.asList(postCommitInsertEventListeners);
   }

   public void addPostCommitInsertEventListener(
         PostInsertEventListener postCommitInsertEventListeners) {
      this.postCommitInsertEventListeners.add(postCommitInsertEventListeners);
   }

   public PostUpdateEventListener[] getPostCommitUpdateEventListeners() {
      return (PostUpdateEventListener[])postCommitUpdateEventListeners.toArray();
   }

   public void setPostCommitUpdateEventListeners(
         PostUpdateEventListener... postCommitUpdateEventListeners) {
      this.postCommitUpdateEventListeners = Arrays.asList(postCommitUpdateEventListeners);
   }

   public void addPostCommitUpdateEventListener(
         PostUpdateEventListener postCommitUpdateEventListeners) {
      this.postCommitUpdateEventListeners.add(postCommitUpdateEventListeners);
   }

} 
