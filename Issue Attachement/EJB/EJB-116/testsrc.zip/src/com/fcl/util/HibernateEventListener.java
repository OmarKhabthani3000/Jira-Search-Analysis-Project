package com.fcl.util;

import java.util.Hashtable;
import java.util.Set;
import java.util.Map;
import java.util.Iterator;
import java.lang.reflect.Method;
import entity.Customer;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.event.Initializable;
import org.hibernate.event.PostDeleteEvent;
import org.hibernate.event.PostDeleteEventListener;
import org.hibernate.event.PostInsertEvent;
import org.hibernate.event.PostInsertEventListener;
import org.hibernate.event.PreUpdateEvent;
import org.hibernate.event.PreUpdateEventListener;
import org.hibernate.event.PostUpdateEvent;
import org.hibernate.event.PostUpdateEventListener;
import org.hibernate.event.SaveOrUpdateEvent;
import org.hibernate.event.SaveOrUpdateEventListener;

import javax.naming.InitialContext;
import javax.ejb.SessionContext;
import javax.annotation.Resource;
import java.security.Principal;

/**
 */
public class HibernateEventListener implements PostDeleteEventListener,
		PostInsertEventListener, PreUpdateEventListener, PostUpdateEventListener,
		SaveOrUpdateEventListener
{

	/** The JACC PolicyContext key for the current HttpServletRequest */
	private static final String WEB_REQUEST_KEY = "javax.servlet.http.HttpServletRequest";

	/** The JACC PolicyContext key for the current Subject */
	private static final String SUBJECT_CONTEXT_KEY = "javax.security.auth.Subject.container";

	/**
	 * 
	 */
	private static final long	serialVersionUID	= 12345678L;

	public void onPostDelete(PostDeleteEvent event)
	{
		final Object entity = event.getEntity();
		System.out.println("Deleting " + entity);
	}

	public void onPostInsert(PostInsertEvent event)
	{
		final Object entity = event.getEntity();
		System.out.println("Inserting " + entity + " ID = " + event.getId());
	}
	
	public void onSaveOrUpdate(SaveOrUpdateEvent event)
	{
		final Object entity = event.getEntity();
		System.out.println("save-update event on " + entity);
		Customer cust = (Customer)entity;
		Class c = entity.getClass();
		Class[] intf = c.getInterfaces();
		if (intf != null && intf.length > 0)
		{
			for (int i = 0; i < intf.length; i++)
			{
				System.out.println("Customer entity implements " + intf[i].getName());
			}
		}
		Method[] m = c.getMethods();
		if (m != null && m.length > 0)
		{
			for (int i = 0; i < m.length; i++)
			{
				System.out.println(m[i].getName() + "()");
			}
		}
	}

	public boolean onPreUpdate(PreUpdateEvent event)
	{
		new Exception().printStackTrace();
		final Object entity = event.getEntity();
		System.out.println("About to update " + entity);
		Customer cust = (Customer)entity;
		Class c = entity.getClass();
		Class[] intf = c.getInterfaces();
		if (intf != null && intf.length > 0)
		{
			for (int i = 0; i < intf.length; i++)
			{
				System.out.println("Customer entity implements " + intf[i].getName());
			}
		}
		Method[] m = c.getMethods();
		if (m != null && m.length > 0)
		{
			for (int i = 0; i < m.length; i++)
			{
				System.out.println(m[i].getName() + "()");
			}
		}
		Object[] state = event.getState();
		if (state != null && state.length > 0)
		{
			for (int i = 0; i < state.length; i++)
			{
				System.out.println(state[i].toString());
			}
		}
		return true;
	}

	public void onPostUpdate(PostUpdateEvent event)
	{
		HibernateEventLogger l = HibernateEventLoggerBean.getInstance();
		l.onPostUpdate(event);

/*		final Object entity = event.getEntity();

		Subject s = null;
		try
		{
			HttpServletRequest request = (HttpServletRequest)PolicyContext.getContext(WEB_REQUEST_KEY);
			System.out.println("User: " + request.getRemoteUser());
			Principal p = ctx.getCallerPrincipal();
			System.out.println("User: " + (p != null ? p.getName() : "null"));
			for (Iterator i = PolicyContext.getHandlerKeys().iterator(); i.hasNext(); )
			{
				String k = (String)i.next();
				System.out.println("PolicyContext has \"" + k + "\"");
				Object o = PolicyContext.getContext(k);
				if (o != null)
					System.out.println(" it is a " + o.getClass().getName());
			}
			s = (Subject)PolicyContext.getContext(SUBJECT_CONTEXT_KEY);
			System.out.println("Subject: " + s);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		System.out.println("Updating " + entity);

		Class c = entity.getClass();
		Class[] intf = c.getInterfaces();
		if (intf != null && intf.length > 0)
		{
			for (int i = 0; i < intf.length; i++)
			{
				System.out.println("Customer entity implements " + intf[i].getName());
			}
		}
		Method[] m = c.getMethods();
		if (m != null && m.length > 0)
		{
			for (int i = 0; i < m.length; i++)
			{
				System.out.println(m[i].getName() + "()");
			}
		}

		String[] propNames = event.getPersister().getPropertyNames();
		Object[] oldState = event.getOldState();
		Object[] newState = event.getState();
		if (oldState != null && oldState.length > 0)
		{
			for (int i = 0; i < oldState.length; i++)
			{
				if (!newState[i].equals(oldState[i]))
				System.out.println(propNames[i] + " from " + oldState[i].toString() + " to " + newState[i].toString());
			}
		}*/
	}
}