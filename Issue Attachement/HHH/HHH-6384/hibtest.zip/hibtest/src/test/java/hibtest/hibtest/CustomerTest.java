package hibtest.hibtest;

import javax.persistence.Persistence;

import junit.framework.TestCase;

public class CustomerTest extends TestCase {
	public void testCustomer() {
		Persistence.createEntityManagerFactory("customers");
	}
}
