package hhhplussign;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	private EntityManagerFactory emf;
	private EntityManager em;
	private String PERSISTENCE_UNIT_NAME = "hhhplussign";

	public static void main(String[] args) {
		Main hello = new Main();
		hello.initEntityManager();
		hello.read();
		hello.closeEntityManager();
	}

	private void initEntityManager() {
		emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		em = emf.createEntityManager();
	}

	private void closeEntityManager() {
		em.close();
		emf.close();
	}


	private void read() {
		String queryString = "SELECT b, (SELECT COUNT(*) FROM Category c) + 1 AS second FROM Book b";
		
		
		Book b = (Book) em.createQuery(queryString).getSingleResult();
		System.out.println("Query returned: " + b);
	}
}
