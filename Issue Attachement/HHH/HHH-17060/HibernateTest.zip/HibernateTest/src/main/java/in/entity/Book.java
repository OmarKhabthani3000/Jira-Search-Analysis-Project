package in.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Setter
@Getter
@Table(name = "book")
public class Book {
    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    String title;
    Long authorId;
    int pages;

    public Book(String title, Long authorId, int pages) {
        this.title = title;
        this.authorId = authorId;
        this.pages = pages;
    }
}