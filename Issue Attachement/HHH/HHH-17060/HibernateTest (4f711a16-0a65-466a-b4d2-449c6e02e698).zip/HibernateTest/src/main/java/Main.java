import in.entity.Author;
import in.entity.Book;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

public class Main {
    private final static EntityManagerFactory emf = Persistence.createEntityManagerFactory("PROJECT_NAME");

    public static EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public static void main(String[] args) {
        EntityManager em = getEntityManager();
        insertBooksAndAuthors(em);
        var em1 = getEntityManager();
        // test1(em1);
         test(em1);
    }

    private static void test1(EntityManager em1) {
        em1.getTransaction().begin();
        List<Object[]> results = em1.createQuery(
                """
                SELECT b.authorId, b.id, b.title FROM Book b, Author a where b.authorId = a.id
                """
        ).getResultList();

        for (Object[] result : results) {
            System.out.println(result[0] + " " + result[1] + " - " + result[2]);
        }

        em1.getTransaction().commit();
        em1.close();
    }

    private static void test(EntityManager em1) {
        em1.getTransaction().begin();
        List<Object[]> results = em1.createQuery(
        """
        SELECT b.authorId, b.id, b.title FROM Book b INNER JOIN Author a ON b.authorId = a.id
        """
        ).getResultList();

        for (Object[] result : results) {
            System.out.println(result[0] + " " + result[1] + " - " + result[2]);
        }

        em1.getTransaction().commit();
        em1.close();
    }

    private static void insertBooksAndAuthors(EntityManager em) {
        em.getTransaction().begin();
        Author a1 = new Author("Author 1");
        Author a2 = new Author("Author 1");
        em.persist(a1);
        em.persist(a2);

        Book b1 = new Book("Book 1", a1.getId(), 100);
        Book b2 = new Book("Book 2", a1.getId(), 100);
        Book b3 = new Book("Book 3", a2.getId(), 100);
        em.persist(b1);
        em.persist(b2);
        em.persist(b3);
        em.getTransaction().commit();
        em.close();
    }
}