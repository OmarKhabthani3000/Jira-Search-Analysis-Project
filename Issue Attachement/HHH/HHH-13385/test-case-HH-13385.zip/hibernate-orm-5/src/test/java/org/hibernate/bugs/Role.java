package org.hibernate.bugs;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

@Entity
public class Role {
  @Id
  @Column(nullable = false)
  private long id;

  @ElementCollection
  @Column(nullable = false)
  @CollectionTable(joinColumns = @JoinColumn(name = "role_id"))
  private Set<String> permissions = new HashSet<>();

  public Set<String> getPermissions() {
    return Collections.unmodifiableSet(permissions);
  }

  public void addPermission(String permission) {
    this.permissions.add(permission);
  }

  public boolean removePermission(String permission) {
    return this.permissions.remove(permission);
  }
}
