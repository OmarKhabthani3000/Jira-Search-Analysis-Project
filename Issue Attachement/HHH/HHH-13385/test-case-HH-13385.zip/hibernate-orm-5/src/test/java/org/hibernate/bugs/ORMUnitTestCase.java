/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import java.util.Collections;

import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.registry.internal.StandardServiceRegistryImpl;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.resource.transaction.spi.DdlTransactionIsolator;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.hibernate.tool.schema.extract.spi.DatabaseInformation;
import org.hibernate.tool.schema.extract.spi.TableInformation;
import org.hibernate.tool.schema.internal.Helper;
import org.hibernate.tool.schema.internal.HibernateSchemaManagementTool;
import org.hibernate.tool.schema.internal.exec.JdbcContext;
import org.hibernate.tool.schema.spi.SchemaManagementTool;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework. Although ORMStandaloneTestCase is perfectly
 * acceptable as a reproducer, usage of this class is much preferred. Since we nearly always include a regression test with bug fixes, providing your reproducer
 * using this method simplifies the process. What's even better? Fork hibernate-orm itself, add your test case directly to a module's unit tests, then submit it
 * as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

  @Override
  protected Class[] getAnnotatedClasses() {
    return new Class[] {Role.class};
  }

  @Override
  protected String[] getMappings() {
    return new String[] {};
  }

  // If those mappings reside somewhere other than resources/org/hibernate/test, change this.
  @Override
  protected String getBaseForMappings() {
    return "org/hibernate/test/";
  }

  // Add in any settings that are specific to your test. See resources/hibernate.properties for the defaults.
  @Override
  protected void configure(Configuration configuration) {
    super.configure(configuration);

    configuration.setProperty(AvailableSettings.SHOW_SQL, Boolean.TRUE.toString());
    configuration.setProperty(AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString());
    // configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, "true" );
  }

  @Test
  public void hhh13385Test() throws Exception {
    // setup to retrieve DatabaseInformation
    StandardServiceRegistryImpl serviceRegistry = serviceRegistry();
    HibernateSchemaManagementTool tool = (HibernateSchemaManagementTool) serviceRegistry.getService(SchemaManagementTool.class);
    JdbcContext jdbcContext = tool.resolveJdbcContext(Collections.emptyMap());
    DdlTransactionIsolator isolator = tool.getDdlTransactionIsolator(jdbcContext);
    MetadataSources metadataSources = new MetadataSources(serviceRegistry);
    DatabaseInformation buildDatabaseInformation =
        Helper.buildDatabaseInformation(serviceRegistry, isolator, metadataSources.getMetadataBuilder().build().getDatabase().getDefaultNamespace().getName());

    TableInformation tableInformation =
        buildDatabaseInformation.getTableInformation(new Identifier("DB1", false), new Identifier("public", false), new Identifier("Role_permissions", false));

    tableInformation.getPrimaryKey(); // throws IndexOutOfBoundsException
  }
}
