package br.com.teste;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@ToString
@EqualsAndHashCode(of = { "id" })
@Table(name = "SISTEMA", uniqueConstraints = { @UniqueConstraint(columnNames = { "nome" }) })
public class Sistema implements Identificavel<Integer> {

	private static final long serialVersionUID = -2040078673756323789L;

	public enum Metadados {
		ADMINISTRACAO(1), GESTAO_ANIMAL(2);

		@Getter
		private Integer pk;

		private Metadados(Integer pk) {
			this.pk = pk;
		}
	}

	@Id
	@Getter
	@Setter
	@Column(name = "PK", insertable = false, updatable = false)
	private Integer id;

	@Getter
	@Setter
	@NotNull
	@NotEmpty
	@Column(name = "NOME", nullable = false)
	private String nome;

	@Getter
	@Setter
	@NotNull
	@NotEmpty
	@Column(name = "URL", nullable = false)
	private String url;
}
