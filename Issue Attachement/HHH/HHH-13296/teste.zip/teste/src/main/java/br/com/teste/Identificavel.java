package br.com.teste;

import java.io.Serializable;

public interface Identificavel<ID extends Serializable> extends Dominio {

	public ID getId();

	public void setId(ID id);
}
