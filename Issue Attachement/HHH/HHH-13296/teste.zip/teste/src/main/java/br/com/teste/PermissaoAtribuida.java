package br.com.teste;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@ToString
@Table(name = "PERMISSAO_ATRIBUIDA")
@EqualsAndHashCode(of = { "id" })
public class PermissaoAtribuida implements Identificavel<PermissaoAtribuida.Id> {

	private static final long serialVersionUID = 8218649203735419673L;

	@Getter
	@Setter
	@NotNull
	@EmbeddedId
	private Id id;

	@Embeddable
	@EqualsAndHashCode(of = { "permissao", "papel" })
	public static class Id implements Serializable {

		private static final long serialVersionUID = 2623642601543065038L;

		@Getter
		@Setter
		@NotNull
		@ManyToOne(optional = false, fetch = FetchType.LAZY)
		@JoinColumn(name = "FK_PERMISSAO", nullable = false)
		private Permissao permissao;

		@Getter
		@Setter
		@NotNull
		@ManyToOne(optional = false, fetch = FetchType.LAZY)
		@JoinColumn(name = "FK_PAPEL", nullable = false)
		private Papel papel;

		public Id() {
			super();
		}

		public Id(@NotNull Permissao permissao, @NotNull Papel papel) {
			super();
			this.permissao = permissao;
			this.papel = papel;
		}

		@Override
		public String toString() {
			Integer idPermissao = Objects.nonNull(permissao) ? permissao.getId() : null;
			Integer idPapel = Objects.nonNull(papel) ? papel.getId() : null;
			return "Id [permissao=" + idPermissao + ", papel=" + idPapel + "]";
		}
	}

	public PermissaoAtribuida() {
		super();
	}

	public PermissaoAtribuida(@NotNull Id id) {
		super();
		this.id = id;
	}

	public PermissaoAtribuida(@NotNull Permissao permissao, @NotNull Papel papel) {
		super();
		this.id = new Id(permissao, papel);
	}

}
