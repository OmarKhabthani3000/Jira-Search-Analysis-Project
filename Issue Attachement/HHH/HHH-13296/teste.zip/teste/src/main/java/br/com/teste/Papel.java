package br.com.teste;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@ToString
@Table(name = "PAPEL")
@EqualsAndHashCode(of = { "id" })
public class Papel implements Identificavel<Integer> {

	private static final long serialVersionUID = -2699336324671066579L;

	@Id
	@Getter
	@Setter
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PK", insertable = false, updatable = false)
	private Integer id;

	@Getter
	@Setter
	@NotNull
	@NotEmpty
	@Column(name = "NOME", nullable = false)
	private String nome;

	@Getter
	@Setter
	@NotNull
	@ManyToOne
	@JoinColumn(name = "FK_SISTEMA", nullable = false)
	private Sistema sistema;

	@Getter
	@Setter
	@OneToMany(mappedBy = "id.papel", cascade = { CascadeType.ALL }, orphanRemoval = true)
	private List<PermissaoAtribuida> permissoesAtribuidas = new ArrayList<>();

}
