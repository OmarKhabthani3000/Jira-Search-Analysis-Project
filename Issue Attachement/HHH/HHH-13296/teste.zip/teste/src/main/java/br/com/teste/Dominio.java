package br.com.teste;

import java.io.Serializable;

public interface Dominio extends Serializable {

}
