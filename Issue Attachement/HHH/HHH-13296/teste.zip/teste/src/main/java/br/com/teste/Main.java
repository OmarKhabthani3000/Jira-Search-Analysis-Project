package br.com.teste;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;

public class Main {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("sgsbe");
		EntityManager manager = factory.createEntityManager();

		System.out.println("========================Incluir=========================");
		Papel papel = incluir(manager);

		System.out.println("========================Buscar=========================");
		Optional<Papel> optional = buscarPorId(manager, papel.getId());

		System.out.println("========================Atualizar=========================");
		atualizar(manager, optional.get());

		factory.close();
	}

	private static Papel incluir(EntityManager manager) {
		Sistema s = new Sistema();
		s.setId(Sistema.Metadados.ADMINISTRACAO.getPk());

		Papel papel = new Papel();
		papel.setNome("Teste forca bruta");
		papel.setSistema(s);

		Permissao permissao = new Permissao();
		permissao.setId(1);

		PermissaoAtribuida atribuida = new PermissaoAtribuida(permissao, papel);

		List<PermissaoAtribuida> lista = new ArrayList<PermissaoAtribuida>();
		lista.add(atribuida);

		papel.setPermissoesAtribuidas(lista);

		manager.getTransaction().begin();
		manager.persist(papel);
		manager.getTransaction().commit();
		return papel;
	}

	public static Optional<Papel> buscarPorId(EntityManager manager, Integer id) {
		try {
			CriteriaBuilder builder = manager.getCriteriaBuilder();
			CriteriaQuery<Papel> query = builder.createQuery(Papel.class);
			Root<Papel> entidade = query.from(Papel.class);
			query.where(builder.equal(entidade.get("id"), id));
			entidade.fetch("permissoesAtribuidas", JoinType.LEFT);
			return Optional.of(manager.createQuery(query).getSingleResult());
		} catch (NoResultException e) {
			return Optional.empty();
		}
	}

	public static void atualizar(EntityManager manager, Papel papel) {
		Permissao permissao = new Permissao();
		permissao.setId(2);
		PermissaoAtribuida atribuida = new PermissaoAtribuida(permissao, papel);

		papel.getPermissoesAtribuidas().add(atribuida);

		manager.getTransaction().begin();
		manager.merge(papel);
		papel = buscarPorId(manager, papel.getId()).get();
		manager.getTransaction().commit();
	}
}
