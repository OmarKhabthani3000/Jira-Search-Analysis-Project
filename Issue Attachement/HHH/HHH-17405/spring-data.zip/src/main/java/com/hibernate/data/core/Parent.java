package com.hibernate.data.core;

import jakarta.persistence.CascadeType;
import jakarta.persistence.FetchType;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.OneToMany;
import java.util.LinkedList;
import java.util.List;
import lombok.Data;

@Data
@MappedSuperclass
public abstract class Parent<C extends Child<?>> {

    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<C> children = new LinkedList<>();


    public abstract Long getId();

    public abstract void setId(Long id);


}