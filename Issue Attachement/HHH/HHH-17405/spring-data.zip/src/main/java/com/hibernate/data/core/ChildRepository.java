package com.hibernate.data.core;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface ChildRepository<C extends Child<?>> extends JpaRepository<C, Long> {

    boolean existsByIdAndParentId(Long id, Long parentId);

}
