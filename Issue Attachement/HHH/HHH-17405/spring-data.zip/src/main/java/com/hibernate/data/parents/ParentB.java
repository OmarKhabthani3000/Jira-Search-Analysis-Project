package com.hibernate.data.parents;

import com.hibernate.data.children.ChildB;
import com.hibernate.data.core.Parent;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class ParentB extends Parent<ChildB> {

    @Id
    private Long id;

}
