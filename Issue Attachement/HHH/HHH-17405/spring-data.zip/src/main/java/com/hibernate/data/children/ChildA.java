package com.hibernate.data.children;

import com.hibernate.data.core.Child;
import com.hibernate.data.parents.ParentA;
import jakarta.persistence.Entity;
import lombok.Data;

@Data
@Entity
public class ChildA extends Child<ParentA> {
}
