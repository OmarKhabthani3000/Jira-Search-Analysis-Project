package com.hibernate.data.children;

import com.hibernate.data.core.ChildRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChildARepository extends ChildRepository<ChildA> {
}
