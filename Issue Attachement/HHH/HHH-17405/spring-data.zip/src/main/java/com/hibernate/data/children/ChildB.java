package com.hibernate.data.children;

import com.hibernate.data.core.Child;
import com.hibernate.data.parents.ParentB;
import jakarta.persistence.Entity;
import lombok.Data;

@Data
@Entity
public class ChildB extends Child<ParentB> {
}
