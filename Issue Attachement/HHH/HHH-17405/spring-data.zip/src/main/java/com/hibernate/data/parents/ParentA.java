package com.hibernate.data.parents;

import com.hibernate.data.children.ChildA;
import com.hibernate.data.core.Parent;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class ParentA extends Parent<ChildA> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

}