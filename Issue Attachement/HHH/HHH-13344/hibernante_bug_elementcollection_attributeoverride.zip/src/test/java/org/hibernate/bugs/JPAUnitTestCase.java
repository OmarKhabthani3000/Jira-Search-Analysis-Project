package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.hibernate.bugs.model.Analysis;
import org.hibernate.bugs.model.DomainReference;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		// insert
		Analysis analysis = new Analysis();
		analysis.setCube(new DomainReference("001"));
		Set<DomainReference> blendedCubes = new HashSet<>(Arrays.asList(new DomainReference("001"), new DomainReference("002")));
		analysis.setBlendedCubes(blendedCubes);

		entityManager.persist(analysis);

		// Do stuff...
		entityManager.getTransaction().commit();
		entityManager.close();

		entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		Query query = entityManager.createQuery("select analys from analysis analys inner join analys.blendedCubes blendedcub1_ where blendedcub1_.id='001'");

		query.getResultList();

		entityManager.close();
	}
}
