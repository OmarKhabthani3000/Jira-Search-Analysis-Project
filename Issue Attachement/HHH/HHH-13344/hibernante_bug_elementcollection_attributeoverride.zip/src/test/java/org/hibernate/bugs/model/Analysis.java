package org.hibernate.bugs.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity(name = "analysis")
public class Analysis {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Embedded
    @AttributeOverride(name = "id", column = @Column(name = "cube_id"))
    private DomainReference cube;

    // Blending Info
    @ElementCollection
    @AttributeOverride(name = "id", column = @Column(name = "cube_id"))
    private Set<DomainReference> blendedCubes = new HashSet<>();

    public DomainReference getCube() {
        return cube;
    }

    public void setCube(DomainReference cube) {
        this.cube = cube;
    }

    public Set<DomainReference> getBlendedCubes() {
        return blendedCubes;
    }

    public void setBlendedCubes(Set<DomainReference> blendedCubes) {
        this.blendedCubes = blendedCubes;
    }
}
