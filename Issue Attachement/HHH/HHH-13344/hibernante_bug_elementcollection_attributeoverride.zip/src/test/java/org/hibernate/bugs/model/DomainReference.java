package org.hibernate.bugs.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class DomainReference {
    @Column(columnDefinition = "VARCHAR(36)")
    private String id;

    public DomainReference() {

    }

    public DomainReference(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId() {
        this.id = id;
    }
}
