
import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestFamily extends TestCase {


	private static SessionFactory sessionFactory;
	static {
	try {
	 Configuration cfg = new Configuration();
	 sessionFactory= cfg.configure().buildSessionFactory();
	 SessionFactory sef=cfg.buildSessionFactory();
	 SchemaExport se =new SchemaExport(cfg);
	 se.create(true, true); 
	} catch (Throwable ex) {
	throw new ExceptionInInitializerError(ex);
	}
	}
	public static SessionFactory getSessionFactory() {
	// Alternatively, you could look up in JNDI here
	return sessionFactory;
	}
	public static void shutdown() {
	// Close caches and connection pools
	getSessionFactory().close();
	}	
	
	public void testFamily (){
		
		Session session1 = getSessionFactory().openSession();
		Transaction tx1 = session1.beginTransaction();
		
		Parent parent = new Parent ();		
		Child child = new Child ();
		child.setFirstName("Ben");
		
		parent.getChildren().put(child.getFirstName(), child);
		child.setParent(parent);		
		
		session1.save(parent);
		
		tx1.commit();
		session1.close();
		
		Session session2 = getSessionFactory().openSession();
	
		Parent parent2 = (Parent)session2.get(Parent.class, parent.getId());
		Child child2 = parent2.getChildren().get(child.getFirstName());
		
		session2.close();
		
	}
	
}
