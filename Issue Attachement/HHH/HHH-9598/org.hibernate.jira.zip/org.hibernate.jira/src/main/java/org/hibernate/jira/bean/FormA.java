/**
 * Copyright (C) 2014 by Genigraph
 * All rights reserved.
 *
 * All usage rights are governed by the applicable Genigraph agreement.
 */
package org.hibernate.jira.bean;

public class FormA
{
   private FormB value;

   private Integer id;

   public FormA()
   {
   }

   public FormB getValue()
   {
      return value;
   }

   public void setValue(final FormB value)
   {
      this.value = value;
   }

   public Integer getId()
   {
      return id;
   }

   public void setId(final Integer id)
   {
      this.id = id;
   }
}
