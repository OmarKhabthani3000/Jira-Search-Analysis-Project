package org.hibernate.jira;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import junit.framework.TestCase;

import org.hibernate.jira.bean.FormA;
import org.hibernate.jira.bean.FormB;

public class MyTestCase extends TestCase {
	private EntityManagerFactory emf;

	@Override
	protected void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("my-pu");

		final EntityManager em = emf.createEntityManager();

		em.close();
	}

	@Override
	protected void tearDown() throws Exception {

		final EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		removeAll(em, "FormA");
		removeAll(em, "FormB");
		em.getTransaction().commit();
		em.close();
		emf.close();
	}

	private void removeAll(final EntityManager em, String tableName) {
		List objects = getAll(em, tableName);
		for (Object o : objects) {
			em.remove(o);
		}
	}

	private List getAll(final EntityManager em, String tableName) {
		List objects = em.createQuery("from " + tableName).getResultList();
		// System.out.println(tableName + ": " + objects.size());
		return objects;
	}

	private int getNumberOf(final EntityManager em, String tableName) {
		List objects = em.createQuery("from " + tableName).getResultList();
		return objects.size();
	}

	public void testInTwoEm() throws Exception {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		final FormA a = new FormA();
		final FormB b = new FormB();
		a.setValue(b);
		em.persist(a);
		em.persist(b);

		em.getTransaction().commit();
		em.close();

		em = emf.createEntityManager();
		em.getTransaction().begin();

		assert getNumberOf(em, "FormB") == 1;

		removeAll(em, "FormB");

		em.getTransaction().commit();

		assertEquals(0, getNumberOf(em, "FormB"));

		em.close();
	}

	public void testInOneEm() throws Exception {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		final FormA a = new FormA();
		final FormB b = new FormB();
		a.setValue(b);
		em.persist(a);
		em.persist(b);

		em.getTransaction().commit();
//		em.clear();

		em.getTransaction().begin();
		
		assert getNumberOf(em, "FormB") == 1;

		removeAll(em, "FormB");

		em.getTransaction().commit();

		assertEquals(0, getNumberOf(em, "FormB"));

		em.close();
	}
}
