package com.eyrolles.sportTracker.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Une instance de cette classe repr�sente une Team.
 * Des players et des games sont associ�s � cette team. 
 * Son cycle de vie est ind�pendant de celui des objets associ�s
 * @author Anthony Patricio <anthony@hibernate.org>  
 */
public class Team implements Serializable{

    private Long id;
    private String name;
	public  Team(){}
	public  Team(String name){this.name = name;}
	private Set players = new HashSet();
    
    public void addPlayer(Player p){
        this.getPlayers().add(p);
    }
    
    public void removePlayer(Player p){
        this.getPlayers().remove(p);
    }
    /**
     * @return Returns the id.
     */
    public Long getId() {
        return id;
    }
    /**
     * @param id The id to set.
     */
    public void setId(Long id) {
        this.id = id;
    }
    /**
     * @return Returns the name.
     */
    public String getName() {
        return name;
    }
    /**
     * @param name The name to set.
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return Returns the players.
     */
    public Set getPlayers() {
        return players;
    }
    /**
     * @param players The players to set.
     */
    public void setPlayers(Set players) {
        this.players = players;
    }
}
