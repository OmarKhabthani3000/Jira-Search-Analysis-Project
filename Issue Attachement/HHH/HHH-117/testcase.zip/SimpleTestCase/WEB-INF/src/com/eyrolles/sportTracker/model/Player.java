package com.eyrolles.sportTracker.model;

import java.io.Serializable;


/**
 * Une instance de cette classe repr�sente un Player.
 * Un player est associ� � une team. Son cycle de vie
 * n'est pas li� � la Team. * 
 * @author Anthony Patricio <anthony@hibernate.org>  
 */

public class Player implements Serializable{
	private Long id;
	private String name;
	public  Player(){}
	public  Player(String name){this.name = name;}
    /**
     * @return Returns the id.
     */
    public Long getId() {
        return id;
    }
    /**
     * @param id The id to set.
     */
    public void setId(Long id) {
        this.id = id;
    }
    /**
     * @return Returns the name.
     */
    public String getName() {
        return name;
    }
    /**
     * @param name The name to set.
     */
    public void setName(String name) {
        this.name = name;
    }
}
