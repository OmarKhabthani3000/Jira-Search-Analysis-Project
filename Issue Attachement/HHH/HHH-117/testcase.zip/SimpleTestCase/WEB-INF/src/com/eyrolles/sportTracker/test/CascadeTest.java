package com.eyrolles.sportTracker.test;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import utils.HibernateUtil;

import com.eyrolles.sportTracker.model.Player;
import com.eyrolles.sportTracker.model.Team;

/**
 * @author totoo
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CascadeTest extends TestCase {

	
	public void testDeleteOrphan() throws Exception  {
	    init();
		System.out.println("==========testDeleteOrphan========");
    	Session session = HibernateUtil.getSession();
	    Transaction tx = session.beginTransaction();
        try{

		    Team team = (Team)session.get(Team.class,new Long(1));		    
		    Player player = (Player)team.getPlayers().iterator().next();
		    team.removePlayer(player);
		    tx.commit();
        }
	    catch (Exception e) {
	        if (tx!=null) tx.rollback();	
	    }
	    finally {
	        HibernateUtil.closeSession();
	    }
	    System.out.println("==========testDeleteOrphan========");
	    
	}
    
 
    
    public void init(){
	    Session session = HibernateUtil.getSession();
	    Transaction tx=null;
	    try {
	        tx = session.beginTransaction();
	        Team teamA = new Team("Team A");
	        Team teamB = new Team("Team B");

	        Player pa1 = new Player("pa1");
	        Player pa2 = new Player("pa2");
	        Player pa3 = new Player("pa3");
	        Player pa4 = new Player("pa4");
	        Player pa5 = new Player("pa5");
	        Player pa6 = new Player("pa6");
	        Player pa7 = new Player("pa7");
	        Player pa8 = new Player("pa8");
	        Player pa9 = new Player("pa9");
	        Player pa10 = new Player("pa10");
   
	        teamA.getPlayers().add(pa1);
	        teamA.getPlayers().add(pa2);
	        teamA.getPlayers().add(pa3);
	        teamA.getPlayers().add(pa4);
	        teamA.getPlayers().add(pa5);
	        teamA.getPlayers().add(pa6);
	        teamA.getPlayers().add(pa7);
	        teamA.getPlayers().add(pa8);
	        teamA.getPlayers().add(pa9);
	        teamA.getPlayers().add(pa10);
	        
	        
	        Player pb1 = new Player("pb1");
	        Player pb2 = new Player("pb2");
	        Player pb3 = new Player("pb3");
	        Player pb4 = new Player("pb4");
	        Player pb5 = new Player("pb5");
	        Player pb6 = new Player("pb6");
	        Player pb7 = new Player("pb7");
	        Player pb8 = new Player("pb8");
	        Player pb9 = new Player("pb9");
	        Player pb10 = new Player("pb10");
	        
        
	        teamB.getPlayers().add(pb1);
	        teamB.getPlayers().add(pb2);
	        teamB.getPlayers().add(pb3);
	        teamB.getPlayers().add(pb4);
	        teamB.getPlayers().add(pb5);
	        teamB.getPlayers().add(pb6);
	        teamB.getPlayers().add(pb7);
	        teamB.getPlayers().add(pb8);
	        teamB.getPlayers().add(pb9);
	        teamB.getPlayers().add(pb10);
	        
	        session.create(teamA);
	        session.create(teamB);		        
	        
	        tx.commit();
	    }
	    catch (Exception e) {
	        if (tx!=null) tx.rollback();	
	    }
	    finally {
	        HibernateUtil.closeSession();
	    }
	}

    
    
    
    
    
    
    public CascadeTest(String x) {
		super(x);
	}

	public static Test suite() {
		return new TestSuite(CascadeTest.class);
	}

	public static void main(String[] args) throws Exception {
		TestRunner.run( suite() );
	}
}
