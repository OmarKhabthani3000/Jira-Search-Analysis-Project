package com.myapp;

import static org.junit.Assert.assertFalse;

import java.sql.PreparedStatement;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.jpa.QueryHints;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.myapp.entities.MyEntity;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/META-INF/spring/application.xml" })
public class NonTransactionalQueryCacheTest {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private PlatformTransactionManager transactionManager;

	private TransactionStatus txStatus;

	@Test
	public void resultsShouldBeCachedOnRollback() throws Exception {
		MyEntity entity = new MyEntity();
		entity.setId(1);
		entity.setName("my entity");

		// Step 1: Create a new record
		beginTransaction();
		entityManager.persist(entity);
		entityManager.flush();
		commitTransaction();

		Thread.sleep(1500);

		// Step 2: Execute query to cache results, then rollback the transaction
		beginTransaction();
		TypedQuery<MyEntity> query = createReadAllQuery();
		List<MyEntity> results = query.getResultList();
		assertFalse(results.isEmpty());
		rollbackTransaction();

		// Step 3: Use jdbc to delete the record (bypassing second level cache
		// invalidation)
		beginTransaction();
		try (PreparedStatement ps = entityManager.unwrap(SessionImplementor.class).connection()
				.prepareStatement("delete from MyEntity")) {
			ps.execute();
		}
		commitTransaction();

		// Step 4: Re-execute the query. Second level cache hit and the same
		// results from step 2 should be returned
		beginTransaction();
		query = createReadAllQuery();
		results = query.getResultList();
		assertFalse(results.isEmpty());
		rollbackTransaction();
	}

	private TypedQuery<MyEntity> createReadAllQuery() {
		TypedQuery<MyEntity> query = entityManager.createQuery("select e from MyEntity e", MyEntity.class);
		query.setHint(QueryHints.HINT_CACHEABLE, Boolean.TRUE);
		return query;
	}

	private void beginTransaction() {
		TransactionDefinition def = new DefaultTransactionDefinition(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
		txStatus = transactionManager.getTransaction(def);
	}

	private void commitTransaction() {
		transactionManager.commit(txStatus);
	}

	private void rollbackTransaction() {
		transactionManager.rollback(txStatus);
	}
}
