package com.myapp.transaction;

import javax.transaction.TransactionManager;

import org.infinispan.transaction.lookup.TransactionManagerLookup;

import com.atomikos.icatch.jta.J2eeTransactionManager;

public class AtomikosInfinispanTransactionManagerLookup implements TransactionManagerLookup {

    @Override
    public TransactionManager getTransactionManager() throws Exception {
        return new J2eeTransactionManager();
    }

}
