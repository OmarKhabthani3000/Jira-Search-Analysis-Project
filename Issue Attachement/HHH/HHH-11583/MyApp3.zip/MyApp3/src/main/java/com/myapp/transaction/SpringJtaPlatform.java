package com.myapp.transaction;

import javax.transaction.TransactionManager;
import javax.transaction.UserTransaction;

import org.hibernate.engine.transaction.jta.platform.internal.AbstractJtaPlatform;
import org.springframework.transaction.jta.JtaTransactionManager;
import org.springframework.util.Assert;

public class SpringJtaPlatform extends AbstractJtaPlatform {

	private static final long serialVersionUID = 1L;

	private final JtaTransactionManager transactionManager;

	public SpringJtaPlatform(JtaTransactionManager transactionManager) {
		Assert.notNull(transactionManager, "TransactionManager must not be null");
		this.transactionManager = transactionManager;
	}

	protected boolean hasTransactionManager() {
		return true;
	}

	@Override
	protected TransactionManager locateTransactionManager() {
		return transactionManager.getTransactionManager();
	}

	@Override
	protected UserTransaction locateUserTransaction() {
		return transactionManager.getUserTransaction();
	}

}
