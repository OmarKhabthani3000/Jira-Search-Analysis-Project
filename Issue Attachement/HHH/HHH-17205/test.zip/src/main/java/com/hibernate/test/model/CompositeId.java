package com.hibernate.test.model;

import lombok.Data;

@Data
public class CompositeId {
    private String first;
    private String second;
}
