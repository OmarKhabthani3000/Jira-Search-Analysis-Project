package com.hibernate.test;

import com.hibernate.test.model.ParentEntity;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
@Transactional
public class ApplicationEventListener {

    @Autowired
    private EntityManager entityManager;

    @EventListener(ApplicationReadyEvent.class)
    public void applicationReady() {
        var query = entityManager.createQuery("select p from ParentEntity p where p.first = :first", ParentEntity.class);
        query.setParameter("first","1");

        var result = query.getSingleResult();
        System.out.println(result);
    }
}
