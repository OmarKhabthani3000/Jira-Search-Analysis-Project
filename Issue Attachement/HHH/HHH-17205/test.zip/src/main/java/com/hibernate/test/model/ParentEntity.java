package com.hibernate.test.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@IdClass(CompositeId.class)
public class ParentEntity {

    @Id
    @Column(name = "col1")
    private String first;

    @Id
    @Column(name = "col2")
    private String second;

    @OneToOne(mappedBy = "parentEntity")
    private ChildEntity childEntity;

}
