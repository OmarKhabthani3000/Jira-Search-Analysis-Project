package com.hibernate.test.model;

import jakarta.persistence.*;

@Entity
@IdClass(CompositeId.class)
public class ChildEntity {

    @Id
    @Column(name = "col1")
    private String first;

    @Id
    @Column(name = "col2")
    private String second;

    @OneToOne
    @JoinColumn(name = "col1", referencedColumnName = "col1")
    @JoinColumn(name = "col2", referencedColumnName = "col2")
    private ParentEntity parentEntity;
}
