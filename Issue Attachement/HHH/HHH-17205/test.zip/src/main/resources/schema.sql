
create table parent_entity (
    col1 varchar(255) not null,
    col2 varchar(255) not null,
    primary key (col1, col2));

create table child_entity (
    col1 varchar(255) not null,
    col2 varchar(255) not null,
    primary key (col1, col2),
    foreign key (col1, col2) references parent_entity(col1, col2));
