
insert into parent_entity (col1, col2) values('1', 'one');

insert into child_entity (col1, col2) values('1', 'one');
