package com.offia.test.testHibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
//import org.hibernate.service.ServiceRegistry;
//import org.hibernate.service.ServiceRegistryBuilder;
import org.junit.Test;

import com.offia.domain.Book;

public class TestFetchWithTextField {

	@SuppressWarnings("unchecked")
	@Test
	public void testHibernateSqlQueryWithSessionCache(){
//		Configuration cfg = new Configuration().configure();
//		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
//				.applySettings(cfg.getProperties()).buildServiceRegistry();
//		SessionFactory sf = cfg.buildSessionFactory(serviceRegistry);
//		Session session = sf.openSession();
//		Transaction tx = session.beginTransaction();
//		
//		List<Object[]> objlist = session.createSQLQuery("select {b.*},{bd.*} from Book as b left outer join BookDetail as bd on bd.book_id = b.id where b.id in (1,2,3)")//
//								.addEntity("b",Book.class)//
//								.addJoin("bd", "b.detail")
//								.list();
//		Book book = (Book) ((Object[])objlist.get(0))[0];
//		BookDetail bd = (BookDetail) ((Object[])objlist.get(0))[1];
//		tx.commit();
//		session.close();
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testHibernateQueryWithSessionCache(){
		Configuration cfg = new Configuration().configure();
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
				.applySettings(cfg.getProperties()).buildServiceRegistry();
		SessionFactory sf = cfg.buildSessionFactory(serviceRegistry);
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		List<Book> booklist = session.createQuery("from Book b").list();
		//List<Book> objlist = session.createCriteria(Book.class).list();
									
		tx.commit();
		session.close();
	}

}
