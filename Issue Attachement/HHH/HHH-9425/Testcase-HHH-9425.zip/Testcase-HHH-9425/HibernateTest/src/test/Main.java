package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main
{
	/**
	 * Creates or deletes the 4th child of Foo Entity.
	 *
	 * Parent entity is marked as dirty since collection was changed.
	 * With generated version column the 'hasColumn' flag is set to true but there is no column to update!
	 *
	 * Line 2606: AbstractEntityPersister.generateUpdateString(...)
	 *
	 * @param args
	 */
	public static void main(final String[] args)
	{
		final Configuration configuration = new Configuration();
		configuration.configure();

		final SessionFactory sf = configuration.buildSessionFactory();

		final Session session = sf.openSession();

		try
		{
			final Transaction tr = session.beginTransaction();

			// start child creation or deletion

			final Foo parent = (Foo) session.get(Foo.class, 1l);

			Foo child4 = null;

			for (final Foo child : parent.getChildren())
				if (child.getName().equals("Child4"))
				{
					child4 = child;
					break;
				}

			// add new child
			if (child4 == null)
			{
				child4 = new Foo();
				child4.setName("Child4");
				child4.setParent(child4);
				parent.getChildren().add(child4);
			}
			// remove
			else
				parent.getChildren().remove(child4);
			// child4.setParent(null);

		}
		catch (final RuntimeException e)
		{
			final Transaction tr = session.getTransaction();

			if (tr != null && tr.isActive())
				tr.rollback();
			throw e;
		}
		finally
		{
			if (session != null && session.isOpen())
			{
				final Transaction tr = session.getTransaction();
				if (tr != null && tr.isActive())
					tr.commit(); // calls implicit session.flush();

				session.close();
			}
		}

		sf.close();
	}
}
