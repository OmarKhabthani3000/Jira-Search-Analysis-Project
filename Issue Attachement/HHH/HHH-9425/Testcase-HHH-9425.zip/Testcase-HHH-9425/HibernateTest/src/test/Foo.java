package test;

import java.util.HashSet;
import java.util.Set;

public class Foo
{
	private Long id;
	private Long version;
	private String name;
	private Foo parent;

	private Set<Foo> children = new HashSet<>();

	public Long getId()
	{
		return this.id;
	}

	public void setId(final Long id)
	{
		this.id = id;
	}

	public Long getVersion()
	{
		return this.version;
	}

	public void setVersion(final Long version)
	{
		this.version = version;
	}

	public String getName()
	{
		return this.name;
	}

	public void setName(final String name)
	{
		this.name = name;
	}

	public Foo getParent()
	{
		return this.parent;
	}

	public void setParent(final Foo parent)
	{
		this.parent = parent;
	}

	public Set<Foo> getChildren()
	{
		return this.children;
	}

	public void setChildren(final Set<Foo> children)
	{
		this.children = children;
	}

	@Override
	public boolean equals(final Object obj)
	{
		if (this == obj)
			return true;

		if (obj instanceof Foo)
		{
			if (this.id == null)
				return false;
			return this.id.equals(((Foo) obj).id);
		}

		return false;
	}

	@Override
	public int hashCode()
	{
		final int hash = 5;
		return 7 * hash + (this.id != null ? this.id.hashCode() : 0);
	}
}
