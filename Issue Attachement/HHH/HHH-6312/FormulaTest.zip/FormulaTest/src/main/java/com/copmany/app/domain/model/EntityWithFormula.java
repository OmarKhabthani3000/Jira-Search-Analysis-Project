package com.copmany.app.domain.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Formula;

@Entity
@Table(name = "e_with_f")
public class EntityWithFormula implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id", updatable = false)
	private int id;

	@Column(name = "label_id", nullable = true)
	private int labelId;

	@Formula("(label_id is null or label_id=:CurrentLabel.id)")
	private boolean accessible;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getLabelId() {
		return labelId;
	}

	public void setLabelId(int labelId) {
		this.labelId = labelId;
	}

	public boolean isAccessible() {
		return accessible;
	}

	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null || !(obj instanceof EntityWithFormula)) {
			return false;
		}

		EntityWithFormula other = (EntityWithFormula) obj;
		return id == other.getId();
	}

	@Override
	public String toString() {
		return String.format(
				"EntityWithFormula(id = %s,labelId = %s,accessible = %s)", id,
				labelId, accessible);
	}

}
