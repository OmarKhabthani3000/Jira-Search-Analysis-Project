package com.copmany.app.domain.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "e_without_f")
public class EntityWithoutFormula implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id", updatable = false)
	private int id;

	@ManyToOne
	@JoinColumn(name = "entity_with_formula_id", referencedColumnName = "id")
	private EntityWithFormula entityWithFormula;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public EntityWithFormula getEntityWithFormula() {
		return entityWithFormula;
	}

	public void setEntityWithFormula(EntityWithFormula entityWithFormula) {
		this.entityWithFormula = entityWithFormula;
	}

	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null || !(obj instanceof EntityWithoutFormula)) {
			return false;
		}

		EntityWithoutFormula other = (EntityWithoutFormula) obj;
		return id == other.getId();
	}

	@Override
	public String toString() {
		return String.format(
				"EntityWithoutFormula(id = %s,entityWithFormula = %s)", id,
				entityWithFormula);
	}

}
