package com.company.app;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.copmany.app.domain.model.EntityWithFormula;
import com.copmany.app.domain.model.EntityWithoutFormula;

@ContextConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class Tests {

	@Autowired
	SessionFactory sessionFactory;

	int labelId = 100;

	@Before
	public void setup() {
		Session session = sessionFactory.openSession();
		setCurrentLabel(session);
		// begin transaction
		session.beginTransaction();
		// add row for the entity with formula
		EntityWithFormula ewf = new EntityWithFormula();
		ewf.setId(1);
		ewf.setLabelId(100);
		session.persist(ewf);
		// add row for the entity without formula
		EntityWithoutFormula ewof = new EntityWithoutFormula();
		ewof.setId(1);
		ewof.setEntityWithFormula(ewf);
		session.persist(ewof);
		// commit
		session.getTransaction().commit();
		session.close();
	}

	@After
	public void tearDown() {
		Session session = sessionFactory.openSession();
		setCurrentLabel(session);

		// begin transaction
		session.beginTransaction();
		// remove ewof
		EntityWithoutFormula ewof = (EntityWithoutFormula) session.get(
				EntityWithoutFormula.class, 1);
		session.delete(ewof);
		// remove ewf
		EntityWithFormula ewf = (EntityWithFormula) session.get(
				EntityWithFormula.class, 1);
		session.delete(ewf);
		// commit
		session.getTransaction().commit();
		session.close();
	}

	@Test
	public void testDirectQueryOnEntityWithFormula() {
		Session session = sessionFactory.openSession();
		try {
			setCurrentLabel(session);

			Query q = session
					.createQuery("select ewf from EntityWithFormula ewf");
			List<EntityWithFormula> lewf = q.list();
			Assert.assertTrue(lewf.size() == 1);
		} finally {
			session.close();
		}
	}

	@Test
	public void testIndirectQueryOnEntityWithFormula() {
		Session session = sessionFactory.openSession();
		try {
			setCurrentLabel(session);

			Query q = session
					.createQuery("select ewof from EntityWithoutFormula ewof");
			List<EntityWithoutFormula> lewof = q.list();
			Assert.assertTrue(lewof.size() == 1);

			EntityWithoutFormula ewof = lewof.get(0);
			Assert.assertTrue(ewof.getEntityWithFormula().isAccessible());
		} finally {
			session.close();
		}
	}

	private void setCurrentLabel(Session session) {
		if (session.getEnabledFilter("CurrentLabel") == null) {
			session.enableFilter("CurrentLabel").setParameter("id", labelId);
		}
	}

}
