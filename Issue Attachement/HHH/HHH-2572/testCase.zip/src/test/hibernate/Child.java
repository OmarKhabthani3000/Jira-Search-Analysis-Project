package test.hibernate;

import java.util.HashSet;
import java.util.Set;

public class Child {
	private Long id;
	private String name;
	private Set<GrandChild> children = new HashSet<GrandChild>();
	private Parent parent;

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<GrandChild> getChildren() {
		return children;
	}

	public void setChildren(Set<GrandChild> children) {
		this.children = children;
	}

	public void add(GrandChild grandChild) {
		grandChild.setParent(this);
		children.add(grandChild);
	}
}
