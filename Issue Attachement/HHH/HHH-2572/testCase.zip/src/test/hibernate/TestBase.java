package test.hibernate;

import junit.framework.TestCase;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

public class TestBase extends TestCase {

	protected Session session;
	private Transaction transaction;

	protected void begin() {
		transaction = session.beginTransaction();
	}

	protected void commit() {
		transaction.commit();
	}

	protected void persist(Object entity) {
		session.persist(entity);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		SessionFactory factory = new Configuration().configure()
				.buildSessionFactory();
		session = factory.openSession();
	}
}
