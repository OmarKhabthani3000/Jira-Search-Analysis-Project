package test.hibernate;

public class TestMerge extends TestBase {
	private Child child;
	private Parent parent;

	@Override
	protected void setUp() throws Exception {
		super.setUp();

		begin();
		parent = new Parent();
		child = new Child();
		parent.add(child);

		persist(parent);
		commit();
	}

	public void testMergeDetachedInstance() throws Exception {
		child.add(new GrandChild());
		session.evict(parent);

		try {
			session.merge(parent);
		} catch (NullPointerException e) {
			return;
		}

		fail("expect exception");
	}

}
