package test.hibernate;

import java.util.HashSet;
import java.util.Set;

public class Parent {
	private Long id;
	private String name;
	private Set<Child> children = new HashSet<Child>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Child> getChildren() {
		return children;
	}

	public void setChildren(Set<Child> children) {
		this.children = children;
	}

	public void add(Child child) {
		child.setParent(this);
		children.add(child);
	}
}
