package com.sulake.hibernate.data;

/**
 * @author Johno Crawford (johno@sulake.com)
 */
public class Test {

    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
