package com.sulake.hibernate.bootstrap;

import com.sulake.hibernate.data.Test;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.io.IOException;

/**
 * @author Johno Crawford (johno@sulake.com)
 */
public class Main {

    public static void main(String[] args) throws IOException {

        Configuration config = new Configuration().
                setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect").
                setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbc.JDBCDriver").
                setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:test").
                setProperty("hibernate.connection.username", "sa").
                setProperty("hibernate.connection.password", "").
                setProperty("hibernate.connection.pool_size", "1").
                setProperty("hibernate.connection.autocommit", "true").
                setProperty("hibernate.cache.provider_class", "org.hibernate.cache.HashtableCacheProvider").
                setProperty("hibernate.hbm2ddl.auto", "create-drop").
                setProperty("hibernate.show_sql", "false").
                setProperty("hibernate.jdbc.batch_size", "0").
                setProperty("hibernate.generate_statistics", "true");

        config.addResource("Test.hbm.xml");

        SessionFactory sessionFactory = config.buildSessionFactory();

        Query query = sessionFactory.openSession().createQuery("from " + Test.class.getName() + " t where t.id = ?");
        query.setLong(0, 1L);

        for (int i = 0; i < 2000; i++) {
            query.list();
        }
    }
}
