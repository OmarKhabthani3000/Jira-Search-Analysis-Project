package issue.hibernateissue2;

import javax.persistence.Entity;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Child extends Parent {

    private String childProperty;

}
