INSERT INTO `parent` VALUES (1, 'parent');
INSERT INTO `child` VALUES (1, 'child');