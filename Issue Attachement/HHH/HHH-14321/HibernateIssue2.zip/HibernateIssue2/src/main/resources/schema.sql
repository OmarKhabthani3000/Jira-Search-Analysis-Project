CREATE TABLE `parent` (
    `id` INT NOT NULL AUTO_INCREMENT,
    PRIMARY KEY (`id`),
    `parent_property` VARCHAR(10)
);

CREATE TABLE `child` (
    `id` INT NOT NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT `parent_child_id_fk` FOREIGN KEY (`id`)
        REFERENCES `parent` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
    `child_property` VARCHAR(10)
);