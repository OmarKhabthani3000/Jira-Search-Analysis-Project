package hhh9177;

public interface ExampleService {

	Foo createFoo();

	Bar createBar();

	void removeFoo(Long fooId);
	
	void removeBar(Long barId);

	void updateFooWithForceIncrementAndExceptionDuringCommit(Long fooId);
	
	void updateFooWithForceIncrementAndNoException(Long fooId);
	
	Foo getFoo(Long fooId);

	Bar getBar(Long barId);

	void updateBar(Long barId);


}
