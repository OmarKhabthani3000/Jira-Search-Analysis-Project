package hhh9177;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ExampleServiceImpl implements ExampleService {
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	@Transactional
	public Foo createFoo(){
		Foo foo = new Foo();
		foo.setRequiredString("text");
		entityManager.persist(foo);
		return foo;
	}
	
	@Override
	@Transactional
	public Bar createBar(){
		Bar bar = new Bar();
		entityManager.persist(bar);
		return bar;
	}
	
	@Override
	@Transactional
	public void removeFoo(Long id){		
		entityManager.remove(entityManager.getReference(Foo.class, id));
	}

	@Override
	@Transactional
	public void removeBar(Long id) {
		entityManager.remove(entityManager.getReference(Bar.class, id));		
	}
	
	@Override
	@Transactional
	public void updateFooWithForceIncrementAndExceptionDuringCommit(Long fooId){
		Foo foo = getFoo(fooId);
		entityManager.lock(foo, LockModeType.OPTIMISTIC_FORCE_INCREMENT);
		foo.setRequiredString(null);
	}

	@Override
	@Transactional(readOnly=true)
	public Foo getFoo(Long fooId) {
		return entityManager.find(Foo.class, fooId);
	}
	
	@Override
	@Transactional(readOnly=true)
	public Bar getBar(Long barId) {
		return entityManager.find(Bar.class, barId);
	}

	@Override
	public void updateFooWithForceIncrementAndNoException(Long fooId) {
		Foo foo = getFoo(fooId);
		entityManager.lock(foo, LockModeType.OPTIMISTIC_FORCE_INCREMENT);
		
	}
	
	@Override
	public void updateBar(Long barId) {
		Bar bar = getBar(barId);
		bar.setOptionalString("someText");
		
	}
	
}
