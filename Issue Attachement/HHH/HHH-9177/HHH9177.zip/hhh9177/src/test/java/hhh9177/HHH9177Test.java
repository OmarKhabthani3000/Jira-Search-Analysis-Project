package hhh9177;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.EntityManagerFactoryUtils;
import org.springframework.orm.jpa.EntityManagerHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.support.TransactionSynchronizationManager;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/META-INF/spring/applicationContext.xml" })
public class HHH9177Test {

	@Autowired
	ExampleService service;

	@Autowired
	EntityManagerFactory emf;

	private Foo foo;

	private Bar bar;

	@Before
	public void setup() {
		foo = service.createFoo();
		bar = service.createBar();
	}

	@After
	public void tearDown() {
		service.removeFoo(foo.getId());
		service.removeBar(bar.getId());
	}

	@Test
	public void testWithoutException() {
		Integer fooVersion1 = service.getFoo(foo.getId()).getVersion();

		try {
			openEntityManagerInView();
			// 1st TX : Change Foo. Lock Mode FORCE_INCREMENT.
			service.updateFooWithForceIncrementAndNoException(foo.getId());

			// 2nd TX: Change another entity. Don't load or touch Foo.
			service.updateBar(bar.getId());

		} finally {
			closeEntityManagerInView();
		}

		Integer fooVersion2 = service.getFoo(foo.getId()).getVersion();
		Assert.assertEquals(
				"The version should have changed, since LockModeType for foo is FORCE_INCREMENT.",
				(Integer) (fooVersion1 + 1), fooVersion2);

	}

	@Test
	// This test illustrates hhh9177. It fails.
	//While it is probably not really well-defined in JPA specification, whether the Version of Foo should be incremented during the 2nd TX (updateBar),
	//Hiberate should at least be consistent regarding whether or not to increment. 
	//This test case shows, that the version of Foo is incremented in 2nd TX, but only, if the first TX has an Exception during Commit.	
	public void testWithException() {
		Integer fooVersion1 = service.getFoo(foo.getId()).getVersion();

		try {
			openEntityManagerInView();

			// 1st TX : Change Foo to invalid state. Lock Mode FORCE_INCREMENT.
			try {
				service.updateFooWithForceIncrementAndExceptionDuringCommit(foo
						.getId());
				Assert.fail("An exception is expected here, since the entity is not valid.");
			} catch (Exception e) {
				// OK. Expected Exception.
				// e.printStackTrace();
			}

			// 2nd TX: Change another entity. Don't load or touch Foo.
			service.updateBar(bar.getId());

		} finally {
			closeEntityManagerInView();
		}

		Integer fooVersion2 = service.getFoo(foo.getId()).getVersion();
		Assert.assertEquals(
				"The version should not have changed, since in the test case testWithoutException it did not change in the 2nd TX.",
				fooVersion1, fooVersion2);
	}

	private void closeEntityManagerInView() {
		EntityManagerHolder emHolder = (EntityManagerHolder) TransactionSynchronizationManager
				.unbindResource(emf);
		EntityManagerFactoryUtils.closeEntityManager(emHolder
				.getEntityManager());

	}

	private void openEntityManagerInView() {
		EntityManager em = emf.createEntityManager();
		EntityManagerHolder emHolder = new EntityManagerHolder(em);
		TransactionSynchronizationManager.bindResource(emf, emHolder);

	}
}
