package testing;

import jakarta.persistence.LockModeType;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

/**
 * @author Sven Strickroth
 */
public class Main {
	public static void main(String[] args) {
		StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder().configure().build();
		MetadataSources metadataSources = new MetadataSources(standardRegistry);
		metadataSources.addAnnotatedClass(User.class);
		Metadata metadata = metadataSources.getMetadataBuilder().build();
		var sessionFactory = metadata.getSessionFactoryBuilder().build();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();

		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Integer> criteria = builder.createQuery(Integer.class);
		Root<User> root = criteria.from(User.class);
		criteria.select(builder.sum(root.get(User_.uid)));
		Query<Integer> query = session.createQuery(criteria);
		query.setLockMode(LockModeType.PESSIMISTIC_WRITE);
		query.uniqueResult();

		tx.commit();
		session.close();
		sessionFactory.close();
	}
}
