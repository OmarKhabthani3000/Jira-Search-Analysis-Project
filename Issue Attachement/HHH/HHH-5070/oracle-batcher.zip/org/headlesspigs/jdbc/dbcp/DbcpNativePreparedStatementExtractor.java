package org.headlesspigs.jdbc.dbcp;

import org.headlesspigs.jdbc.NativePreparedStatementExtractorAdapter;

/**
 * Subclass which returns the class and method names of the
 * <code>PreparedStatement</code> wrapper specific to DBCP.
 * <p>
 * date 14/01/2010
 * </p>
 * 
 * @version 1.0
 * @author Leandro Quiroga <a>leaqui@gmail.com</a>
 */
public class DbcpNativePreparedStatementExtractor extends
		NativePreparedStatementExtractorAdapter {

	private static final String CLASS_NAME = "org.apache.commons.dbcp.DelegatingStatement";

	private static final String METHOD_NAME = "getDelegate";

	@Override
	public String getNativePreparedStatementClassName() {
		return CLASS_NAME;
	}

	@Override
	public String getNativePreparedStatementMethodName() {
		return METHOD_NAME;
	}
}
