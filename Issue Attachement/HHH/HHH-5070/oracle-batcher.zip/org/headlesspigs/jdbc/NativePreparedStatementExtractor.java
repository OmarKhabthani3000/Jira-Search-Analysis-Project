package org.headlesspigs.jdbc;

import java.sql.PreparedStatement;

/**
 * Defines an interface for extracting the native <code>PreparedStatement</code>
 * wrapped in another <code>PreparedStatement</code>, usually backed by a
 * connection pool.
 * <p>
 * date 19/01/2010
 * </p>
 * 
 * @version 1.0
 * @author Leandro Quiroga <a>leaqui@gmail.com</a>
 */
public interface NativePreparedStatementExtractor {

	/**
	 * @param preparedStatement
	 *            <code>PreparedStatement</code> wrapping the native
	 *            <code>PreparedStatement</code>.
	 * @return the native <code>PreparedStatement/code>
	 */
	public PreparedStatement getNativePreparedStatement(
			PreparedStatement preparedStatement);

}
