package org.headlesspigs.jdbc.c3p0;

import java.lang.reflect.Method;
import java.sql.PreparedStatement;

import org.headlesspigs.jdbc.NativePreparedStatementExtractor;
import org.hibernate.HibernateException;

import com.mchange.v2.c3p0.C3P0ProxyStatement;

/**
 * <code>NativePreparedStatementExtractor</code> specific to C3P0. C3P0 has a
 * weird reflection based mechanism to retrieve the underlying native prepared
 * statement, which prevent this implementation from inheriting from
 * <code>NativePreparedStatementExtractorAdapter</code> as the other
 * implementations do.
 * <p>
 * date 14/01/2010
 * </p>
 * 
 * @version 1.0
 * @author Leandro Quiroga <a>leaqui@gmail.com</a>
 */
public class C3P0NativePreparedStatementExtractor implements
		NativePreparedStatementExtractor {

	public PreparedStatement getNativePreparedStatement(
			final PreparedStatement preparedStatement) {
		try {
			final Method getRawStatementMethod = this.getClass().getMethod(
					"getRawStatement", new Class[] { PreparedStatement.class });
			return (PreparedStatement) ((C3P0ProxyStatement) preparedStatement)
					.rawStatementOperation(getRawStatementMethod, null,
							new Object[] { C3P0ProxyStatement.RAW_STATEMENT });
		} catch (Exception e) {
			throw new HibernateException(e);
		}
	}

	public static PreparedStatement getRawStatement(
			final PreparedStatement preparedStatement) {
		return preparedStatement;
	}
}
