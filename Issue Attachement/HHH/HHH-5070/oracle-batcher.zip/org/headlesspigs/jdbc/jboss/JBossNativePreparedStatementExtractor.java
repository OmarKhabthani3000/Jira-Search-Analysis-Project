package org.headlesspigs.jdbc.jboss;

import org.headlesspigs.jdbc.NativePreparedStatementExtractorAdapter;

/**
 * Subclass which returns the class and method names of the
 * <code>PreparedStatement</code> wrapper specific to the connection pooling
 * implemented in JBoss.
 * <p>
 * date 14/01/2010
 * </p>
 * 
 * @version 1.0
 * @author Leandro Quiroga <a>leaqui@gmail.com</a>
 */
public class JBossNativePreparedStatementExtractor extends
		NativePreparedStatementExtractorAdapter {

	private static final String CLASS_NAME = "org.jboss.resource.adapter.jdbc.WrappedPreparedStatement";

	private static final String METHOD_NAME = "getUnderlyingStatement";

	@Override
	public String getNativePreparedStatementClassName() {
		return CLASS_NAME;
	}

	@Override
	public String getNativePreparedStatementMethodName() {
		return METHOD_NAME;
	}
}
