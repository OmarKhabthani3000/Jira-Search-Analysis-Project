package org.headlesspigs.hibernate.jdbc;

import org.headlesspigs.jdbc.NativePreparedStatementExtractor;
import org.hibernate.HibernateException;
import org.hibernate.Interceptor;
import org.hibernate.jdbc.Batcher;
import org.hibernate.jdbc.BatcherFactory;
import org.hibernate.jdbc.ConnectionManager;

/**
 * BatcherFactory that creates an <code>OracleBatchingBatcher</code>. In order
 * for Hibernate to use it, the following java system property must be set:
 * 
 * <code>hibernate.jdbc.factory_class=org.headlesspigs.hibernate.jdbc.OracleBatchingBatcherFactory</code>
 * <p>
 * <code>OracleBatchingBatcher</code> depends on a
 * <code>NativePreparedStatementExtractor</code> to unwrap
 * <code>PreparedStatement</code>s, usually wrapped by a connection pool, in
 * order to access Oracle's JDBC extension interface
 * <code>oracle.jdbc.OraclePreparedStatement</code>.
 * <p>
 * The <code>NativePreparedStatementExtractor</code> implementation to be used
 * depends on the chosen connection pool, and must be set in the system property
 * <code>native.prepared.statement.class.name</code><br>
 * We've implemented statements extractors for three pools: <a
 * href="http://www.mchange.com/projects/c3p0/index.html">C3P0</a>, <a
 * href="http://commons.apache.org/dbcp/">DBCP</a> and JBoss:
 * <ul>
 * <li>org.headlesspigs.jdbc.c3p0.C3P0NativePreparedStatementExtractor</li>
 * <li>org.headlesspigs.jdbc.dbcp.DbcpNativePreparedStatementExtractor</li>
 * <li>org.headlesspigs.jdbc.jboss.JBossNativePreparedStatementExtractor</li>
 * </ul>
 * </p>
 * 
 * @see NativePreparedStatementExtractor, C3P0NativePreparedStatementExtractor,
 *      DbcpNativePreparedStatementExtractor,
 *      JBossNativePreparedStatementExtractor
 * @version 1.0
 * @author Diego del R�o <a>diego.del.rio@gmail.com</a>
 * @version 1.1 14/01/2010
 * @author Leandro Quiroga <a>leaqui@gmail.com</a>
 */
public class OracleBatchingBatcherFactory implements BatcherFactory {

	/**
	 * System property name that specifies the class name of the native prepared
	 * statement extractor to use
	 */
	private static final String NATIVE_PREPARED_STATEMENT_EXTRACTOR_CLASS_NAME = "native.prepared.statement.class.name";

	private NativePreparedStatementExtractor nativePreparedStatementExtractor;

	/**
	 * Instantiates the <code>NativePreparedStatementExtractor</code> specified
	 * in the system property <code>native.prepared.statement.class.name</code>
	 */
	public OracleBatchingBatcherFactory() {
		final String extractorClassName = System
				.getProperty(NATIVE_PREPARED_STATEMENT_EXTRACTOR_CLASS_NAME);
		try {
			final Class extractorClass = Class.forName(extractorClassName);
			this
					.setNativePreparedStatementExtractor((NativePreparedStatementExtractor) extractorClass
							.newInstance());
		} catch (final Exception e) {
			throw new HibernateException(
					"An error ocurred while trying to instantiate a NativePreparedStatementExtractor. NATIVE_PREPARED_STATEMENT_EXTRACTOR_CLASS_NAME = "
							+ extractorClassName, e);
		}
	}

	/**
	 * Creates an <code>OracleBatchingBatcher</code> with its corresponding
	 * <code>NativePreparedStatementExtractor</code>.
	 * 
	 * @return an <code>OracleBatchingBatcher</code>.
	 * @see org.hibernate.jdbc.BatcherFactory#createBatcher(org.hibernate.jdbc.ConnectionManager,
	 *      org.hibernate.Interceptor)
	 */
	public Batcher createBatcher(final ConnectionManager connectionManager,
			final Interceptor interceptor) {
		return new OracleBatchingBatcher(connectionManager, interceptor, this
				.getNativePreparedStatementExtractor());
	}

	private NativePreparedStatementExtractor getNativePreparedStatementExtractor() {
		return nativePreparedStatementExtractor;
	}

	private void setNativePreparedStatementExtractor(
			final NativePreparedStatementExtractor nativePreparedStatementExtractor) {
		this.nativePreparedStatementExtractor = nativePreparedStatementExtractor;
	}
}
