package org.headlesspigs.hibernate.jdbc;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import oracle.jdbc.OraclePreparedStatement;

import org.apache.log4j.Logger;
import org.headlesspigs.jdbc.NativePreparedStatementExtractor;
import org.hibernate.HibernateException;
import org.hibernate.Interceptor;
import org.hibernate.StaleStateException;
import org.hibernate.jdbc.BatchedTooManyRowsAffectedException;
import org.hibernate.jdbc.BatchingBatcher;
import org.hibernate.jdbc.ConnectionManager;
import org.hibernate.jdbc.Expectation;
import org.hibernate.jdbc.Expectations;

/**
 * <code>BatchingBatcher</code> that relies on
 * <code>oracle.jdbc.OraclePreparedStatement</code> to batch jdbc prepared
 * statements.<br>
 * In order to access the underlying
 * <code>oracle.jdbc.OraclePreparedStatement</code>, it's necessary to unwrap
 * the <code>PreparedStatement</code> managed by the connection pool in use.
 * This batcher delegates this task to a
 * <code>NativePreparedStatementExtractor</code>
 * 
 * @see OracleBatchingBatcherFactory
 * @version 1.0
 * @author Diego del R�o <a>diego.del.rio@gmail.com</a>
 * @version 1.1 13/01/2010
 * @author Leandro Quiroga <a>leaqui@gmail.com</a>
 */
public class OracleBatchingBatcher extends BatchingBatcher {

	private static final Logger LOGGER = Logger
			.getLogger(OracleBatchingBatcher.class);

	private int batchSize;

	private NativePreparedStatementExtractor nativePreparedStatementExtractor;

	/**
	 * Constructor, currently used by <code>OracleBatchingBatcherFactory</code>
	 */
	public OracleBatchingBatcher(
			final ConnectionManager connectionManager,
			final Interceptor interceptor,
			final NativePreparedStatementExtractor nativePreparedStatementExtractor) {
		super(connectionManager, interceptor);
		this
				.setNativePreparedStatementExtractor(nativePreparedStatementExtractor);
	}

	@Override
	public PreparedStatement prepareBatchStatement(final String sql)
			throws SQLException, HibernateException {
		final PreparedStatement stmt = super.prepareBatchStatement(sql);

		final boolean isDebugEnabled = LOGGER.isDebugEnabled();
		if (isDebugEnabled) {
			LOGGER.debug("PreparedStatement implementation: " + stmt);
		}

		final OraclePreparedStatement oracleStmt = (OraclePreparedStatement) this
				.getOraclePreparedStatement(stmt);
		final int stmtHashcode = stmt.hashCode();
		final int executeBatch = oracleStmt.getExecuteBatch();

		if (isDebugEnabled) {
			LOGGER.debug("Returning statement " + stmt + " (" + stmtHashcode
					+ ") with batch size " + executeBatch);
		}
		if (executeBatch == 1) {
			final int newExecuteBatch = this.getFactory().getSettings()
					.getJdbcBatchSize() + 1;
			oracleStmt.setExecuteBatch(newExecuteBatch);

			if (isDebugEnabled) {
				LOGGER.debug("Setting new batch size for statement " + stmt
						+ " (" + stmtHashcode + "): " + newExecuteBatch);
			}
		}
		return stmt;
	}

	/**
	 * Returns the <code>OraclePreparedStatement</code> wrapped in the given
	 * <code>PreparedStatement</code>
	 */
	protected OraclePreparedStatement getOraclePreparedStatement(
			final PreparedStatement preparedStatement) {
		return (OraclePreparedStatement) this
				.getNativePreparedStatementExtractor()
				.getNativePreparedStatement(preparedStatement);
	}

	@Override
	public void addToBatch(Expectation expectation) throws SQLException,
			HibernateException {
		if (!expectation.canBeBatched()) {
			throw new HibernateException(
					"Attempting to batch an operation which cannot be batched");
		}

		final boolean isDebugEnabled = LOGGER.isDebugEnabled();
		if (isDebugEnabled) {
			LOGGER.debug("Request to add statement to batch with expectation "
					+ expectation);
		}
		if (expectation.equals(Expectations.BASIC)) {
			batchSize++;
			if (isDebugEnabled) {
				LOGGER.debug("Basic expectation " + expectation
						+ ". Batch size incremented: " + batchSize);
			}
		}

		final int jdbcBatchSize = this.getFactory().getSettings()
				.getJdbcBatchSize();

		if (isDebugEnabled) {
			LOGGER.debug("Statement added to batch (" + batchSize + "/"
					+ jdbcBatchSize + ")");
		}

		this.getStatement().executeUpdate();

		if (batchSize == jdbcBatchSize) {
			this.doExecuteBatch(this.getStatement());
		}
	}

	@Override
	protected void doExecuteBatch(PreparedStatement ps) throws SQLException,
			HibernateException {
		final boolean isDebugEnabled = LOGGER.isDebugEnabled();

		if (batchSize == 0) {
			if (isDebugEnabled) {
				LOGGER.debug("no batched statements to execute");
			}
		} else {
			if (isDebugEnabled) {
				LOGGER.debug("Executing batch size: " + batchSize);
			}

			try {
				this.checkRowCounts(this.getOraclePreparedStatement(ps)
						.sendBatch());
			} catch (RuntimeException re) {
				LOGGER.error("Exception executing batch: ", re);
				throw re;
			} finally {
				batchSize = 0;
			}
		}
	}

	protected void checkRowCounts(int rowCount) {
		if (batchSize > rowCount) {
			throw new StaleStateException(
					"Batch update returned unexpected row count from update; actual row count: "
							+ rowCount + "; expected: " + batchSize);
		}
		if (batchSize < rowCount) {
			String msg = "Batch update returned unexpected row count from update; actual row count: "
					+ rowCount + "; expected: " + batchSize;
			throw new BatchedTooManyRowsAffectedException(msg, batchSize,
					rowCount, 0);
		}
	}

	private NativePreparedStatementExtractor getNativePreparedStatementExtractor() {
		return nativePreparedStatementExtractor;
	}

	private void setNativePreparedStatementExtractor(
			final NativePreparedStatementExtractor nativePreparedStatementExtractor) {
		this.nativePreparedStatementExtractor = nativePreparedStatementExtractor;
	}
}
