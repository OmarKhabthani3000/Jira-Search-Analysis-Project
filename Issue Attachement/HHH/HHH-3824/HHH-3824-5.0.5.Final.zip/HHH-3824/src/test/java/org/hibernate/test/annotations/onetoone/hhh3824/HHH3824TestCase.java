package org.hibernate.test.annotations.onetoone.hhh3824;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;

import junit.framework.TestCase;

public class HHH3824TestCase extends TestCase
{
   private static final Logger LOGGER = Logger.getLogger(HHH3824TestCase.class);

   private SessionFactory sessionFactory;


   @Before
   public void setUp() throws Exception
   {
      // A SessionFactory is set up once for an application
      sessionFactory = new Configuration().configure().buildSessionFactory();
   }

   @After
   public void tearDown() throws Exception
   {
      if( sessionFactory != null )
      {
         sessionFactory.close();
      }
   }

   public void testOneToOneJoinById() throws Exception
   {
      LOGGER.info("[BEGIN] testOneToOneJoinById");
      Session session = sessionFactory.openSession();
      session.beginTransaction();

      Parent1 parent = new Parent1(10, 11);
      Child1 child = new Child1(13, parent);

      session.save(parent);
      session.save(child);

      session.getTransaction().commit();
      session.close();

      // get the child
      session = sessionFactory.openSession();
      session.beginTransaction();

      Child1 c = (Child1) session.createQuery("FROM Child1 WHERE id = 13").uniqueResult();
      LOGGER.info("c1=" + c);

      session.getTransaction().commit();
      session.close();

      Assert.assertNotNull(c.parent.child);
      LOGGER.info("[END] testOneToOneJoinById");
   }

   public void testOneToOneJoinByUniqueId() throws Exception
   {
      LOGGER.info("[BEGIN] testOneToOneJoinByUniqueId");
      Session session = sessionFactory.openSession();
      session.beginTransaction();

      Parent2 parent = new Parent2(20, 21);
      Child2 child = new Child2(22, parent);

      session.save(parent);
      session.save(child);

      session.getTransaction().commit();
      session.close();

      // get the child
      session = sessionFactory.openSession();
      session.beginTransaction();

      Child2 c = (Child2) session.createQuery("FROM Child2 WHERE id = 22").uniqueResult();
      LOGGER.info("c2=" + c);

      session.getTransaction().commit();
      session.close();

      Assert.assertNotNull(c.parent.child);
      LOGGER.info("[END] testOneToOneJoinByUniqueId");
   }
}
