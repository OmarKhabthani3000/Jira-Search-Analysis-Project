package org.hibernate.test.annotations.onetoone.hhh3824;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

/**
 * Child1 and Child2 are the same, except for the @JoinColumn.
 */
@Entity
@SuppressWarnings("serial")
public class Child2 implements Serializable
{
   @Id
   public long id;

   @OneToOne(optional = false)
   @JoinColumn(name = "parentIdFK", referencedColumnName = "uniqueId")
   public Parent2 parent;


   public Child2()
   {
   }

   public Child2( long id, Parent2 parent )
   {
      this.id = id;
      this.parent = parent;
      this.parent.child = this;
   }

   public String toString()
   {
      StringBuilder sb = new StringBuilder();

      sb.append("Child[id=");
      sb.append(id);
      sb.append("; parent=");
      sb.append(parent);
      sb.append("]");

      return sb.toString();
   }
}
