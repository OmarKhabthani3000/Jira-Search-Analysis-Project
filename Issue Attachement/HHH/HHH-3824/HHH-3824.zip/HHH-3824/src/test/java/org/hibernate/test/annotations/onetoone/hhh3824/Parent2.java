package org.hibernate.test.annotations.onetoone.hhh3824;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;

/**
 * Parent1 and Parent2 are the same.
 */
@Entity
@SuppressWarnings("serial")
public class Parent2 implements Serializable
{
   @Id
   @GeneratedValue(generator = "increment")
   @GenericGenerator(name = "increment", strategy = "increment")
   public long id;

   public long uniqueId;

   @OneToOne(mappedBy = "parent")
   public Child2 child;


   public Parent2()
   {
   }

   public Parent2( long uniqueId )
   {
      this.uniqueId = uniqueId;
   }

   public String toString()
   {
      StringBuilder sb = new StringBuilder();

      sb.append("Parent[id=");
      sb.append(id);
      sb.append("; uniqueId=");
      sb.append(uniqueId);
      sb.append("; child=");

      if( child == null )
      {
         sb.append("null");
      }
      else
      {
         sb.append("Child[id=");
         sb.append(child.id);
         sb.append("]");
      }

      sb.append("]");

      return sb.toString();
   }
}
