package org.hibernate.test.annotations.onetoone.hhh3824;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HHH3824TestCase extends TestCase
{
   private SessionFactory sessionFactory;


   @Override
   protected void setUp() throws Exception
   {
      // A SessionFactory is set up once for an application
      sessionFactory = new Configuration().configure() // configures settings
                                                       // from hibernate.cfg.xml
            .buildSessionFactory();
   }

   @Override
   protected void tearDown() throws Exception
   {
      if( sessionFactory != null )
      {
         sessionFactory.close();
      }
   }

   public void testOneToOneJoinById() throws Exception
   {
      // DB setup
      Session session = sessionFactory.openSession();
      session.beginTransaction();

      Parent1 parent = new Parent1(33);
      Child1 child = new Child1(parent);

      session.save(new Parent1(31));
      session.save(parent);
      session.save(child);

      session.getTransaction().commit();
      session.close();

      // get the child
      session = sessionFactory.openSession();
      session.beginTransaction();

      Child1 c = (Child1) session.createQuery("FROM Child1 WHERE id = 1").uniqueResult();
      System.out.println("c1=" + c);

      session.getTransaction().commit();
      session.close();

      Assert.assertNotNull(c.parent.child);
   }

   public void testOneToOneJoinByUniqueId() throws Exception
   {
      Session session = sessionFactory.openSession();
      session.beginTransaction();

      Parent2 parent = new Parent2(33);
      Child2 child = new Child2(parent);

      session.save(new Parent2(31));
      session.save(parent);
      session.save(child);

      session.getTransaction().commit();
      session.close();

      // get the child
      session = sessionFactory.openSession();
      session.beginTransaction();

      Child2 c = (Child2) session.createQuery("FROM Child2 WHERE id = 1").uniqueResult();
      System.out.println("c2=" + c);

      session.getTransaction().commit();
      session.close();

      Assert.assertNotNull(c.parent.child);
   }
}
