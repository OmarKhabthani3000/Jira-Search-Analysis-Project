package org.hibernate.bugs;

import jakarta.persistence.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "invoices")
public class Invoice implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String number;

    @OneToMany(mappedBy = "invoice", cascade = {CascadeType.ALL}, orphanRemoval = true)
    private List<InvoiceLine> lines = new ArrayList<>();

    public Invoice(String number) {
        this.number = number;
    }

    public Invoice addLine(int index) {
        this.lines.add(new InvoiceLine(this, index));
        return this;
    }

    // region boilerplate
    public Invoice() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public List<InvoiceLine> getLines() {
        return lines;
    }

    public void setLines(List<InvoiceLine> lines) {
        this.lines = lines;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Invoice invoice = (Invoice) o;
        return Objects.equals(number, invoice.number);
    }

    @Override
    public int hashCode() {
        return Objects.hash(number);
    }

    @Override
    public String toString() {
        return "Invoice{" +
                "number='" + number + '\'' +
                "lines='" + lines + '\'' +
                '}';
    }
    // endregion
}
