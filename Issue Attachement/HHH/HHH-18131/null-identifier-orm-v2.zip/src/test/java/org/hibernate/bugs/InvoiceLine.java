package org.hibernate.bugs;

import jakarta.persistence.*;

import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "invoice_lines")
@IdClass(InvoiceLine.InvoiceLineId.class)
public class InvoiceLine implements Serializable {
    @Id
    @ManyToOne(optional = false)
    @JoinColumn(name = "invoice_id", updatable = false)
    private Invoice invoice;

    @Id
    @Column(nullable = false)
    private Integer index;

    public InvoiceLine(Invoice invoice, Integer index) {
        this.invoice = invoice;
        this.index = index;
    }

    // region boilerplate
    public InvoiceLine() {
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InvoiceLine address = (InvoiceLine) o;
        return Objects.equals(index, address.index);
    }

    @Override
    public int hashCode() {
        return Objects.hash(index);
    }

    @Override
    public String toString() {
        return "InvoiceLine{" +
                "index='" + index + '\'' +
                '}';
    }
    // endregion

    public static class InvoiceLineId {
        private Long invoice;
        private Integer index;

        public InvoiceLineId() {
        }

        public Long getInvoice() {
            return invoice;
        }

        public void setInvoice(Long invoice) {
            this.invoice = invoice;
        }

        public Integer getIndex() {
            return index;
        }

        public void setIndex(Integer index) {
            this.index = index;
        }
    }
}
