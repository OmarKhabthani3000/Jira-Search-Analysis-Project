package nl.kennisnet.teleblik.shared.data.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratorType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;

/**
 * The class <code>Term</code> is the base class for termen with attached fragmenten.
 */
@Entity
@Table(name = "term")
public class Term implements Serializable {


   private Long id;
   private Indeling indeling;


   /**
    * Returns the database identifier for this term.
    * @return the database identifier for this term
    */
   @Id(generate = GeneratorType.AUTO)
   public Long getId() {
      return id;
   }

   /**
    * Sets the database identifier for this term. This setter is private since clients should not be able
    * to alter database identifiers.
    * @param id database identifier
    */
   @SuppressWarnings({"UNUSED_SYMBOL" })
   private void setId(final Long id) {
      this.id = id;
   }

   /**
    * Returns the indeling to which this term belongs.
    * @return the indeling to which this term belongs
    */
   @ManyToOne(cascade = { CascadeType.REFRESH }, optional = false, fetch = FetchType.EAGER)
   @Cascade({ org.hibernate.annotations.CascadeType.EVICT, org.hibernate.annotations.CascadeType.LOCK,
         org.hibernate.annotations.CascadeType.REFRESH })
   @JoinColumn(name = "indeling_id")
   public Indeling getIndeling() {
      return indeling;
   }

   /**
    * Sets the indeling property for this term. Each term must have an indeling. This setter is private since
    * the indeling for a term should only be set at construction time and never be modified afterwards.
    * @param indeling the indeling to which this term belongs
    */
   void setIndeling(final Indeling indeling) {
      this.indeling = indeling;
   }
}
