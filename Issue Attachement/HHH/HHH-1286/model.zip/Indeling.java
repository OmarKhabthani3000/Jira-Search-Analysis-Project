package nl.kennisnet.teleblik.shared.data.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratorType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Cascade;

/**
 * The class <code>Indeling</code> models an indeling to which termen belong. Each term belongs to exactly one
 * indeling.
 */
@Entity
@Table(name = "indeling", uniqueConstraints = { @UniqueConstraint(columnNames = { "naam" }) })
public class Indeling implements Serializable {


   private Long id;
   private Set<Term> termen = new HashSet<Term>();


   /**
    * Returns the database identifier of this indeling.
    * @return the database identifier of this indeling
    */
   @Id(generate = GeneratorType.AUTO)
   public Long getId() {
      return id;
   }

   /**
    * Sets the database identifier for this indeling. This setter is private since clients should not be able
    * to alter database identifiers.
    * @param id database identifier
    */
   @SuppressWarnings({"UNUSED_SYMBOL" })
   private void setId(final Long id) {
      this.id = id;
   }

   /**
    * Returns the termen that belong to this indeling.
    * @return the termen that belong to this indeling
    */
   @OneToMany(
         mappedBy = "indeling",
         targetEntity = Term.class,
         cascade = { CascadeType.REMOVE })
   @Cascade(value = { org.hibernate.annotations.CascadeType.REMOVE })
   public Set<Term> getTermen() {
      return termen;
   }

   /**
    * Sets the termen that belong to this indeling. Note that these are all termen that belong to the indeling,
    * not just the termen that appear at the highest level of the indeling.
    * @param termen the termen that belong to this indeling
    */
   @SuppressWarnings({"AssignmentToCollectionOrArrayFieldFromParameter" })
   public void setTermen(final Set<Term> termen) {
      this.termen = termen;
   }
}
