@NamedQueries(
   {
      /**
       * Returns all <code>Term</code> objects that belong to a particular <code>Indeling</code>.
       * @param indeling the <code>Indeling</code> to which the returned termen should belong, ordered by their
       *  <code>naam</code> property
       */
      @NamedQuery(name = "findTermenByIndeling",
            queryString = "from Term where indeling = :indeling")
   }
)
package nl.kennisnet.teleblik.shared.data.model;

import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/*
 * $Log: package-info.java,v $
 * Revision 1.35  2005/12/16 10:19:50  wildenberg01
 * - alias for term for query findTermenByIndeling (Hibernate bug)
 *
 * Revision 1.34  2005/12/12 09:33:07  wburg
 * findParentOfTerm deleted
 *
 * Revision 1.33  2005/12/12 09:15:18  wburg
 * named query findChildrenOfTerm deleted
 *
 * Revision 1.32  2005/12/08 14:44:38  wildenberg01
 * - changed query findParentOfTerm
 *
 * Revision 1.31  2005/12/08 09:11:51  wburg
 * removed getNrFragmentenRecursive
 *
 * Revision 1.30  2005/12/07 12:25:17  wburg
 * inserted addtional queries voor termcache
 *
 * Revision 1.29  2005/12/07 07:44:39  wildenberg01
 * - reformatted
 * - implemented query for finding fragmentIds for term
 *
 * Revision 1.28  2005/12/06 15:33:40  wburg
 * spaties ipv tabjes
 * Revision 1.27 2005/12/06 15:07:41 wburg
 * namequeries opgenomen voor CacheImpl
 *
 * Revision 1.26 2005/11/25 15:07:59 wildenberg01 - added query
 * findTermenByIndeling
 *
 * Revision 1.25 2005/09/16 14:45:48 wildenberg01 - added query
 * getTermenForFragment (unsure if it works)
 *
 * Revision 1.24 2005/09/16 12:47:54 stover01 - fixed bug showing detailpage
 * searchresult
 *
 * Revision 1.23 2005/09/12 11:44:54 wildenberg01 - reformatted
 *
 * Revision 1.22 2005/09/08 14:29:49 wildenberg01 - added named query
 * getAdditionalResultInfoByFragmentId
 *
 * Revision 1.21 2005/09/01 13:01:49 wildenberg01 - added NamedQuery
 * getScreenshotInfoByFragmentId
 *
 * Revision 1.20 2005/08/26 16:06:10 wildenberg01 - added named query
 * getTalenOrderedByNaam
 *
 * Revision 1.19 2005/08/26 09:16:52 wildenberg01 - changed inner join to left
 * join for two queries
 *
 * Revision 1.18 2005/08/25 06:36:56 wildenberg01 - added two named queries for
 * user and group retrieval
 *
 * Revision 1.17 2005/08/12 09:48:48 wildenberg01 - removed named query
 * findGebruikersGroepByEntreeCode
 *
 * Revision 1.16 2005/08/08 11:23:13 wildenberg01 - changed Gebruiker -
 * GebruikersGroup relation to ManyToMany
 *
 * Revision 1.15 2005/08/05 07:29:43 wildenberg01 - added 2 named queries
 * (findGebruikerByEntreeId, findGebruikersGroepByEntreeCode) - added some
 * JavaDoc
 *
 * Revision 1.14 2005/08/02 07:34:15 wildenberg01 - added type beeldType
 *
 * Revision 1.13 2005/07/21 09:34:48 wildenberg01 - added TypeDef listType
 *
 * Revision 1.12 2005/07/07 14:09:25 wildenberg01 - added enumerated type
 * FragmentStatus
 *
 * Revision 1.11 2005/07/06 14:36:39 wildenberg01 - renamed NIBGDatumUserType to
 * NibgDatumUserType
 *
 * Revision 1.10 2005/07/06 12:43:38 wildenberg01 - added nibgDatum type
 *
 * Revision 1.9 2005/07/05 14:25:25 wildenberg01 - added enum types bouwNiveau,
 * onderwijsType and schoolSoort
 *
 * Revision 1.8 2005/07/05 14:19:31 wildenberg01 - added moeilijkheidsGraad enum
 *
 * Revision 1.7 2005/07/04 09:12:52 wildenberg01 - added gebruiksRol enum type
 *
 * Revision 1.6 2005/06/30 16:10:17 wildenberg01 - added typedef mediaType
 *
 * Revision 1.5 2005/06/28 09:09:19 wildenberg01 - added type definitions
 * soortOnderwijsMateriaal, ternary and fragmentTijdstip
 *
 * Revision 1.4 2005/06/24 08:37:27 wildenberg01 - added typedef for
 * indelingsType
 *
 * Revision 1.3 2005/06/24 08:03:23 wildenberg01 - changed indelingsType to
 * termGebruik
 *
 * Revision 1.2 2005/06/23 15:14:01 wildenberg01 - added a TypeDef for
 * TermGebruik enum
 *
 * Revision 1.1 2005/06/22 12:07:33 wildenberg01 - package-level file for
 * package-level annotations and documentation
 *
 */