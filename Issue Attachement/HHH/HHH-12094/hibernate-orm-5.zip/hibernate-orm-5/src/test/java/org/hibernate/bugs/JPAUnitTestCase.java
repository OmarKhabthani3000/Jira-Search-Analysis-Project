package org.hibernate.bugs;

import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.test.BLEntry;
import com.test.BLEntryType;
import com.test.BLRecord;
import com.test.EmailBLEntry;
import com.test.IpBLEntry;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        BLRecord blRecord = new BLRecord();
        blRecord.setEntries(new HashSet<>());

        EmailBLEntry emailBLEntry = new EmailBLEntry();
        emailBLEntry.setValue("test@email.com");
        emailBLEntry.setRecord(blRecord);

        IpBLEntry ipBLEntry = new IpBLEntry();
        ipBLEntry.setValue("127.0.0.1");
        ipBLEntry.setRecord(blRecord);

        blRecord.getEntries().add(emailBLEntry);
        blRecord.getEntries().add(ipBLEntry);

        entityManager.persist(blRecord);

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<BLRecord> query = cb.createQuery(BLRecord.class);
        Root<BLRecord> root = query.from(BLRecord.class);
        Join<BLRecord, BLEntry> join = root.join("entries");
        query.groupBy(root.get("id")).having(cb.equal(cb.count(root), 1));
        query.where(cb.and(cb.equal(join.type(), EmailBLEntry.class),
                cb.equal(BLEntryType.EMAIL.getValuePath(cb, join), "test@email.com")));
        TypedQuery<BLRecord> typedQuery = entityManager.createQuery(query);
        List<BLRecord> blRecords = typedQuery.getResultList();

        Assert.assertEquals(1, blRecords.size());

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
