package com.test;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("IP")
public class IpBLEntry extends BLEntry {

    @Override
    public BLEntryType getType() {
        return BLEntryType.IP;
    }

}
