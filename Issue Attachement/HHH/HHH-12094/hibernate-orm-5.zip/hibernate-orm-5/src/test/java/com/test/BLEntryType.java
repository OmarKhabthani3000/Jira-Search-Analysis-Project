package com.test;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Path;

public enum BLEntryType {

    EMAIL(EmailBLEntry.class) {
        @Override
        public BLEntry createBLEntry() {
            return new EmailBLEntry();
        }

        @Override
        public Path<String> getValuePath(CriteriaBuilder cb, Join<BLRecord, BLEntry> join) {
            return cb.treat(join, EmailBLEntry.class).get("value");
        }
    },

    IP(IpBLEntry.class) {
        @Override
        public BLEntry createBLEntry() {
            return new IpBLEntry();
        }

        @Override
        public Path<String> getValuePath(CriteriaBuilder cb, Join<BLRecord, BLEntry> join) {
            return cb.treat(join, IpBLEntry.class).get("value");
        }
    };

    private final Class<? extends BLEntry> entryClass;

    public abstract BLEntry createBLEntry();

    public abstract Path<String> getValuePath(CriteriaBuilder cb, Join<BLRecord, BLEntry> join);

    BLEntryType(Class<? extends BLEntry> entryClass) {
        this.entryClass = entryClass;
    }

    public Class<? extends BLEntry> getEntryClass() {
        return entryClass;
    }

}
