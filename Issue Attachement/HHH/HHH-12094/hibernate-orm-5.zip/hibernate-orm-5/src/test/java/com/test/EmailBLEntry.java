package com.test;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("EMAIL")
public class EmailBLEntry extends BLEntry {

    @Override
    public BLEntryType getType() {
        return BLEntryType.EMAIL;
    }

}
