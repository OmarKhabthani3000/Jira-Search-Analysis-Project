package com.example.demo;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@Getter
@AllArgsConstructor
@Embeddable
@NoArgsConstructor
class ChildEntityWrapper {

    //Fetch type eager does not work
    @OneToMany(fetch = FetchType.EAGER ,cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "parent_entity_id", referencedColumnName = "id")
    List<ChildEntity> childEntities;
}
