CREATE TABLE public.parent_entity (
    id serial PRIMARY KEY
);

CREATE TABLE public.child_entity(
    id serial PRIMARY KEY,
    parent_entity_id integer REFERENCES public.parent_entity(id)
);