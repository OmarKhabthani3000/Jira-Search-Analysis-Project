package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {
    @Autowired
	ParentEntityRepository repository;

	@Test
	void contextLoads() {

		final ParentEntity locSavedEntity = repository.save(new ParentEntity(new ChildEntityWrapper()));
		repository.delete(locSavedEntity);
	}

}
