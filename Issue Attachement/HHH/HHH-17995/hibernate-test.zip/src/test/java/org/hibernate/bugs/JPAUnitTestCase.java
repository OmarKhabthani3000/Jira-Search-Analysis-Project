package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import static org.junit.Assert.assertEquals;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import org.hibernate.bugs.entity.Time;
import org.hibernate.bugs.entity.MyEntity;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		final Instant instant = Instant.now();
		final Instant start = instant.minusSeconds(3600L);
		final Instant end = instant.plusSeconds(3600L);

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		MyEntity entity = new MyEntity(UUID.randomUUID());
		entity.setCreationTime(Time.from(instant));
		entity.setStartTime(Time.from(start));
		entity.setEndTime(Time.from(end));
		entity.setReady(true);
		entityManager.persist(entity);

		List<MyEntity> results = entityManager.createNamedQuery(MyEntity.GET_LATEST, MyEntity.class)
		        .setParameter("start", Time.from(instant))
		        .setParameter("end", Time.from(instant))
		        .getResultList();

		assertEquals(1, results.size());

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
