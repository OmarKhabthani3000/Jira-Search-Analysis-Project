package org.hibernate.bugs.entity;

import java.io.Serializable;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

import org.hibernate.annotations.Type;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "my_table")
@NamedQueries({
        @NamedQuery(name = MyEntity.GET_LATEST,
                query = "SELECT s FROM MyEntity AS s WHERE (s.id, s.creationTime) IN "
                        + "(SELECT innerS.id, max(innerS.creationTime) FROM MyEntity AS innerS "
                        + "WHERE innerS.endTime >= :start AND innerS.startTime <= :end "
                        + "AND innerS.ready = true GROUP BY innerS.id)"),
        @NamedQuery(name = MyEntity.GET_LATEST2,
                query = "SELECT s FROM MyEntity AS s WHERE (s.id, s.creationTime) IN "
                        + "(SELECT innerS.id, max(innerS.creationTime) FROM MyEntity AS innerS "
                        + "WHERE innerS.ready = true GROUP BY innerS.id)") 
})
public class MyEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final String GET_LATEST = "getLatest";
    public static final String GET_LATEST2 = "getLatest2";

    @Id
    @Column
    @Setter(value = AccessLevel.NONE)
    private UUID id;

    @Column(name = "is_ready")
    private boolean ready;

    @Column(name = "start_time")
    private Time startTime;

    @Column(name = "end_time")
    private Time endTime;

    @Column(name = "creation_time")
    private Time creationTime;

    public MyEntity(final UUID id) {
        this.id = id;
    }
}
