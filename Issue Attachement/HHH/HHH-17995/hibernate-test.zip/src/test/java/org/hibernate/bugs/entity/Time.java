package org.hibernate.bugs.entity;

import java.time.Instant;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalField;
import java.time.temporal.TemporalUnit;

public class Time implements Temporal {
    private final Instant instant;

    public static Time from(final Instant instant) {
        return new Time(instant);
    }

    public Time(final Instant instant) {
        this.instant = instant;
    }

    @Override
    public boolean isSupported(final TemporalField field) {
        return instant.isSupported(field);
    }

    @Override
    public long getLong(final TemporalField field) {
        return instant.getLong(field);
    }

    @Override
    public boolean isSupported(final TemporalUnit unit) {
        return instant.isSupported(unit);
    }

    @Override
    public Temporal with(final TemporalField field, final long newValue) {
        return instant.with(field, newValue);
    }

    @Override
    public Temporal plus(final long amountToAdd, final TemporalUnit unit) {
        return instant.plus(amountToAdd, unit);
    }

    @Override
    public long until(final Temporal endExclusive, final TemporalUnit unit) {
        return instant.until(endExclusive, unit);
    }
}
