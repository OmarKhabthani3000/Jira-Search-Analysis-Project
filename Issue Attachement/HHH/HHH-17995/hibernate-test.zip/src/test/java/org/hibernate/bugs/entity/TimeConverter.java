package org.hibernate.bugs.entity;

import java.util.Date;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = true)
public class TimeConverter implements AttributeConverter<Time, Date> {

    @Override
    public Date convertToDatabaseColumn(final Time time) {
        if (time == null) {
            return null;
        }

        return Date.from(java.time.Instant.from(time));
    }

    @Override
    public Time convertToEntityAttribute(final Date date) {
        if (date == null) {
            return null;
        }

        return Time.from(date.toInstant());
    }
}