package org.hibernate.bugs;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh10613Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		CentsAndDollarsAccount centsAndDollarsAccount = new CentsAndDollarsAccount();
		centsAndDollarsAccount.setCents( 1245L );
		entityManager.persist( centsAndDollarsAccount );

		entityManager.clear();

		centsAndDollarsAccount = entityManager.find(CentsAndDollarsAccount.class, centsAndDollarsAccount.getId() );
		assertEquals(12.45d, centsAndDollarsAccount.getDollars(), 0.01);

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	@Test
	public void testCastWorksForJPQL() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		CentsAccount centsAccount = new CentsAccount();
		centsAccount.setCents( 1245L );
		entityManager.persist( centsAccount );

		Double dollars = (Double) entityManager.createQuery(
				"select cast(a.cents as double) / 100 as dollars from CentsAccount a" )
				.getSingleResult();
		assertEquals(12.45d, dollars, 0.01);

		entityManager.getTransaction().commit();
		entityManager.close();
	}

}
