package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.Formula;

/**
 * @author Vlad Mihalcea
 */
@Entity(name = "CentsAndDollarsAccount")
public class CentsAndDollarsAccount {

	@Id
	@GeneratedValue
	private Long id;

	private Long cents;

	@Formula( "cast(a.cents as double) / 100" )
	private Double dollars;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCents() {
		return cents;
	}

	public void setCents(Long cents) {
		this.cents = cents;
	}

	public Double getDollars() {
		return dollars;
	}
}
