package org.hibernate.bugs;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.bugs.entities.Person;
import org.hibernate.cfg.AvailableSettings;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Reproducer for issue: Loading an entity from second level cache and accessing
 * a lazy Basic attribute yields an exception.
 * 
 * Based on: org.hibernate.bugs.JPAUnitTestCase
 * 
 * NOTE: For this test to reproduce the issue the supplied adapted pom.xml has
 * to be used, otherwise bytecode enhancement is not active.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory("templatePU",
				getTestSpecificPersistenceUnitSettings());
	}

	private Map<Object, Object> getTestSpecificPersistenceUnitSettings() {
		Map<Object, Object> result = new HashMap<>(1);
		result.put(AvailableSettings.USE_SECOND_LEVEL_CACHE, Boolean.TRUE.toString());
		return result;
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void errorLoadingFromCacheWithLazyPropertyTest() throws Exception {

		// create new Person entity
		Long personId = createPersonTx1();

		// load previously created Person entity in new transaction to get it
		// into cache
		loadPersonTx2(personId);

		// load same person again - this time from 2nd level cache - and access
		// lazy property
		loadPersonAndAccessLazyPropertyTx3(personId);
	}

	protected Long createPersonTx1() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		final Person person = new Person();
		person.setLazyAttribute("does_not_matter");
		entityManager.persist(person);

		entityManager.getTransaction().commit();
		entityManager.close();
		return person.getId();
	}

	protected void loadPersonTx2(Long personId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		entityManager.find(Person.class, personId);

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	protected void loadPersonAndAccessLazyPropertyTx3(Long personId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		final Person person = entityManager.find(Person.class, personId);
		person.getLazyAttribute();

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
