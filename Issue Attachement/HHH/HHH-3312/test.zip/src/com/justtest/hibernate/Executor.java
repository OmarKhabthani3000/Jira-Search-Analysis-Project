package com.justtest.hibernate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * User: Grisha Klimov
 * Date: May 29, 2008
 * Time: 7:40:34 PM
 */

@Entity
@Table(name = "executors")
public class Executor implements Serializable {

    private static final long serialVersionUID = 7106619829921752104L;

    @Id
    @GeneratedValue
    private Long id;

    @Column(name = "service_name")
    private String serviceName;

    @ManyToMany
    @JoinTable(name = "executors_rules",
            joinColumns = {@JoinColumn(name = "executor_id")},
            inverseJoinColumns = {@JoinColumn(name = "rule_id")})
    private List<Rule> availableRules;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public List<Rule> getAvailableRules() {
        return availableRules;
    }

    public void setAvailableRules(List<Rule> availableRules) {
        this.availableRules = availableRules;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Executor executor = (Executor) o;

        if (id != null ? !id.equals(executor.id) : executor.id != null) return false;
        if (serviceName != null ? !serviceName.equals(executor.serviceName) : executor.serviceName != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        result = (id != null ? id.hashCode() : 0);
        result = 31 * result + (serviceName != null ? serviceName.hashCode() : 0);
        return result;
    }
}
