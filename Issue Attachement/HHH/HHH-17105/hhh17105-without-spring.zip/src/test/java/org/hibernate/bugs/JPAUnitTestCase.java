package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Version;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.util.Arrays;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {
	private final Logger logger = LogManager.getLogger();

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh17105Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		logger.info("SETUP, Hibernate {}", Version.getVersionString());
		createUser(entityManager);

		var user = entityManager.find(User.class, "user");
		Assertions.assertEquals(setOf(new Project("p1")), user.getManagedProjects());
		Assertions.assertEquals(setOf(new Project("p1"), new Project("p2")), user.getOtherProjects());


		logger.info("REMOVE user FROM p1 managers");
		var p1 = entityManager.find(Project.class, "p1");
		p1.getManagers().remove(user);
		Assertions.assertEquals(setOf(user), p1.getMembers());
		entityManager.persist(user);
		entityManager.flush();
		entityManager.clear();

		logger.info("CHECK");
		user = entityManager.find(User.class, "user");
		Assertions.assertEquals(Collections.emptySet(), user.getManagedProjects());
		//	Expected :[Project{name='p1'}, Project{name='p2'}]
		//	Actual   :[Project{name='p2'}]
		Assertions.assertEquals(setOf(new Project("p1"), new Project("p2")), user.getOtherProjects());

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	private void createUser(EntityManager em) {
		var user = new User("user");

		var project1 = new Project("p1");
		project1.getManagers().add(user);
		project1.getMembers().add(user);

		var project2 = new Project("p2");
		project2.getMembers().add(user);

		em.persist(user);
		em.persist(project1);
		em.persist(project2);
		em.flush();
		em.clear();
	}

	private <T> Set<T> setOf(T... values) {
		return Arrays.stream(values).collect(Collectors.toSet());
	}
}

