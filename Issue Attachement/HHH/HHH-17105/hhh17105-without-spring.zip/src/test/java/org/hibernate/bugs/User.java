package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import org.hibernate.annotations.WhereJoinTable;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "users")
public class User implements Serializable {
    @Id
    private String name;

    @ManyToMany(mappedBy = "managers")
    @WhereJoinTable(clause = "role = 'MANAGER'")
    private Set<Project> managedProjects = new HashSet<>();

    @ManyToMany(mappedBy = "members")
    @WhereJoinTable(clause = "role = 'MEMBER'")
    private Set<Project> otherProjects = new HashSet<>();

    public User(String name) {
        this.name = name;
    }

    // region boilerplate
    public User() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Project> getManagedProjects() {
        return managedProjects;
    }

    public void setManagedProjects(Set<Project> managedProjects) {
        this.managedProjects = managedProjects;
    }

    public Set<Project> getOtherProjects() {
        return otherProjects;
    }

    public void setOtherProjects(Set<Project> otherProjects) {
        this.otherProjects = otherProjects;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(name, user.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                '}';
    }
    // endregion
}
