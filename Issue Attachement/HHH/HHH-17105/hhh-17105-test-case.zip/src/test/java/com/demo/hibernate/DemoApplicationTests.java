package com.demo.hibernate;

import jakarta.persistence.*;
import org.hibernate.Version;
import org.junit.jupiter.api.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.*;
import org.springframework.transaction.annotation.Transactional;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.Arrays;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;

@SpringBootTest
@ActiveProfiles("test")
@TestPropertySource(locations = "classpath:application.yml")
@Testcontainers
class DemoApplicationTests {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private static final PostgreSQLContainer<?> dbContainer = new PostgreSQLContainer<>("postgres:15.3")
			.withDatabaseName("demodb")
			.withUsername("demouser")
			.withPassword("demopwd");

	@DynamicPropertySource
	static void properties(DynamicPropertyRegistry registry) {
		dbContainer.start();
		registry.add("spring.datasource.url", dbContainer::getJdbcUrl);
		registry.add("spring.datasource.username", dbContainer::getUsername);
		registry.add("spring.datasource.password", dbContainer::getPassword);
	}

	private void createUser(EntityManager em) {
		var user = new User("user");

		var project1 = new Project("p1");
		project1.getManagers().add(user);
		project1.getMembers().add(user);

		var project2 = new Project("p2");
		project2.getMembers().add(user);

		em.persist(user);
		em.persist(project1);
		em.persist(project2);
		em.flush();
		em.clear();
	}

	private <T> Set<T> setOf(T... values) {
		return Arrays.stream(values).collect(Collectors.toSet());
	}

	@Test
	@Transactional
	void test_max_id_date(@Autowired EntityManager em) {
		logger.info("SETUP, Hibernate {}", Version.getVersionString());
		createUser(em);

		var user = em.find(User.class, "user");
		Assertions.assertEquals(setOf(new Project("p1")), user.getManagedProjects());
		Assertions.assertEquals(setOf(new Project("p1"), new Project("p2")), user.getOtherProjects());


		logger.info("REMOVE user FROM p1 managers");
		var p1 = em.find(Project.class, "p1");
		p1.getManagers().remove(user);
		Assertions.assertEquals(setOf(user), p1.getMembers());
		em.persist(user);
		em.flush();
		em.clear();

		logger.info("CHECK");
		user = em.find(User.class, "user");
		Assertions.assertEquals(Collections.emptySet(), user.getManagedProjects());
		//	Expected :[Project{name='p1'}, Project{name='p2'}]
		//	Actual   :[Project{name='p2'}]
		Assertions.assertEquals(setOf(new Project("p1"), new Project("p2")), user.getOtherProjects());
	}
}
