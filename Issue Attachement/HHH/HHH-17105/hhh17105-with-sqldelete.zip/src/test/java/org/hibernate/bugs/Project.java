package org.hibernate.bugs;

import jakarta.persistence.*;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.SQLInsert;
import org.hibernate.annotations.WhereJoinTable;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "projects")
public class Project implements Serializable {
    @Id
    private String name;

    @ManyToMany
    @JoinTable(
            name = "project_users",
            joinColumns = {@JoinColumn(name = "project_id")},
            inverseJoinColumns = {@JoinColumn(name = "user_id")}
    )
    @WhereJoinTable(clause = "role = 'MANAGER'")
    @SQLInsert(sql = "INSERT INTO project_users (project_id, user_id, role) VALUES (?, ?, 'MANAGER')")
    @SQLDelete(sql = "DELETE FROM project_users WHERE project_id = ? AND user_id = ? AND role = 'MANAGER'")
    private Set<User> managers = new HashSet<>();

    @ManyToMany
    @JoinTable(
            name = "project_users",
            joinColumns = {@JoinColumn(name = "project_id")},
            inverseJoinColumns = {@JoinColumn(name = "user_id")}
    )
    @WhereJoinTable(clause = "role = 'MEMBER'")
    @SQLInsert(sql = "INSERT INTO project_users (project_id, user_id, role) VALUES (?, ?, 'MEMBER')")
    @SQLDelete(sql = "DELETE FROM project_users WHERE project_id = ? AND user_id = ? AND role = 'MEMBER'")
    private Set<User> members = new HashSet<>();

    public Project(String name) {
        this.name = name;
    }

    // region boilerplate
    public Project() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<User> getManagers() {
        return managers;
    }

    public void setManagers(Set<User> managers) {
        this.managers = managers;
    }

    public Set<User> getMembers() {
        return members;
    }

    public void setMembers(Set<User> members) {
        this.members = members;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Project project = (Project) o;
        return Objects.equals(name, project.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    @Override
    public String toString() {
        return "Project{" +
                "name='" + name + '\'' +
                '}';
    }

    // endregion
}
