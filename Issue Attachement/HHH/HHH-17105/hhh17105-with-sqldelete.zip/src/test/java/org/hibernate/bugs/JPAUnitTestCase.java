package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Version;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {
	private final Logger logger = LogManager.getLogger();

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh17105Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		logger.info("SETUP, Hibernate {}", Version.getVersionString());
		createObjects(entityManager);

		var p1 = entityManager.find(Project.class, "p1");
		var p2 = entityManager.find(Project.class, "p2");
		var user1 = entityManager.find(User.class, "user1");
		var user2 = entityManager.find(User.class, "user2");

		Assertions.assertEquals(setOf(p1, p2), user1.getManagedProjects());
		Assertions.assertEquals(setOf(p1, p2), user1.getOtherProjects());

		Assertions.assertEquals(setOf(p1, p2), user2.getManagedProjects());
		Assertions.assertEquals(setOf(p1, p2), user2.getOtherProjects());

		logger.info("REMOVE user1 FROM p1 managers");

		p1.getManagers().remove(user1);

		entityManager.persist(user1);
		entityManager.flush();
		entityManager.clear();

		logger.info("CHECK");

		p1 = entityManager.find(Project.class, "p1");
		p2 = entityManager.find(Project.class, "p2");
		user1 = entityManager.find(User.class, "user1");
		user2 = entityManager.find(User.class, "user2");

		Assertions.assertEquals(setOf(p2), user1.getManagedProjects());
		Assertions.assertEquals(setOf(p1, p2), user1.getOtherProjects());

		Assertions.assertEquals(setOf(user2), p1.getManagers());
		Assertions.assertEquals(setOf(user1, user2), p1.getMembers());

		Assertions.assertEquals(setOf(p1, p2), user2.getManagedProjects());
		Assertions.assertEquals(setOf(p1, p2), user2.getOtherProjects());

		Assertions.assertEquals(setOf(user1, user2), p2.getManagers());
		Assertions.assertEquals(setOf(user1, user2), p2.getMembers());

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	private void createObjects(EntityManager em) {
		var user1 = new User("user1");
		var user2 = new User("user2");

		var project1 = new Project("p1");
		project1.getManagers().add(user1);
		project1.getManagers().add(user2);
		project1.getMembers().add(user1);
		project1.getMembers().add(user2);

		var project2 = new Project("p2");
		project2.getManagers().add(user1);
		project2.getManagers().add(user2);
		project2.getMembers().add(user1);
		project2.getMembers().add(user2);

		em.persist(user1);
		em.persist(user2);
		em.persist(project1);
		em.persist(project2);
		em.flush();
		em.clear();
	}

	private <T> Set<T> setOf(T... values) {
		return Arrays.stream(values).collect(Collectors.toSet());
	}
}
