package org.hibernate.bugs;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Objects;

// this class exists only to tell Hibernate to crate 'role' column in HSQL table
@Entity
@Table(name = "project_users")
public class ProjectUsers {
    @Id
    @Column(name = "project_id")
    private String projectId;

    @Id
    @Column(name = "user_id")
    private String userId;

    @Id
    private String role;

    // region boilerplate
    public ProjectUsers() {
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProjectUsers that = (ProjectUsers) o;
        return Objects.equals(projectId, that.projectId) && Objects.equals(userId, that.userId) && Objects.equals(role, that.role);
    }

    @Override
    public int hashCode() {
        return Objects.hash(projectId, userId, role);
    }

    @Override
    public String toString() {
        return "ProjectUsers{" +
                "projectId='" + projectId + '\'' +
                ", userId='" + userId + '\'' +
                ", role='" + role + '\'' +
                '}';
    }
    // endregion
}
