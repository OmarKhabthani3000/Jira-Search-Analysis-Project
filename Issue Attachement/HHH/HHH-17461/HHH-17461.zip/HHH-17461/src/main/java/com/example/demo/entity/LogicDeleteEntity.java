/*
 * Copyright (c) 2022-Present. Jinan Yuanchuang Network Technology Co., Ltd.
 * All rights reserved.
 * 项目名称：TopIAM 企业数字身份管控平台
 * 版权说明：本软件属济南源创网络科技有限公司所有，受著作权法和国际版权条约的保护。在未获得济南源创网络科技有限公司正式授权情况下，任何企业和个人，未经授权擅自复制、修改、分发本程序的全部或任何部分，将要承担一切由此导致的民事或刑事责任。
 */
package com.example.demo.entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;


@MappedSuperclass
@Setter
@Getter
public class LogicDeleteEntity<PK extends Serializable> extends IdEntity<PK> {

    @JsonIgnore
    @Column(name = "is_deleted")
    private Boolean            deleted;
}
