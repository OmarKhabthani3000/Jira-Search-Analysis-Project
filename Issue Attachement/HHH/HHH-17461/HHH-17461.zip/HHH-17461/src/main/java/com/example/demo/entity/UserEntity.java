package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.SoftDelete;


@Setter
@Getter
@ToString
@Entity
@Table(name = "sys_user")
@SoftDelete(columnName = "is_deleted")
public class UserEntity extends LogicDeleteEntity<Long> {

    @Column(name = "name_")
    private String name;
    @Column(name = "password_")
    private String password;
    @Column(name = "email_")
    private String email;
    @Column(name = "remark_")
    private String remark;
}
