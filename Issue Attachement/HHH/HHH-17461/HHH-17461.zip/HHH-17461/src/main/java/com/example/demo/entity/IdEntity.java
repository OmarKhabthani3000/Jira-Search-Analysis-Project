/*
 * Copyright (c) 2022-Present. Jinan Yuanchuang Network Technology Co., Ltd.
 * All rights reserved.
 * 项目名称：TopIAM 企业数字身份管控平台
 * 版权说明：本软件属济南源创网络科技有限公司所有，受著作权法和国际版权条约的保护。在未获得济南源创网络科技有限公司正式授权情况下，任何企业和个人，未经授权擅自复制、修改、分发本程序的全部或任何部分，将要承担一切由此导致的民事或刑事责任。
 */
package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
@ToString
@MappedSuperclass
public class IdEntity<PK extends Serializable> implements Serializable {

    @Serial
    private static final long serialVersionUID = -7087131058152893045L;

    /**
     * ID
     */
    @Id
    @Column(name = "id_")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private PK id;
}
