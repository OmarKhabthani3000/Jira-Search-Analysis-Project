package org.hibernate.hh5811;

import org.hibernate.SessionFactory;
import org.hibernate.hhh5811.TestEntity;
import org.junit.Test;
import org.unitils.UnitilsJUnit4;
import org.unitils.database.annotations.Transactional;
import org.unitils.database.util.TransactionMode;
import org.unitils.dbunit.annotation.DataSet;
import org.unitils.dbunit.annotation.ExpectedDataSet;
import org.unitils.orm.hibernate.annotation.HibernateSessionFactory;

@Transactional(TransactionMode.ROLLBACK)
@DataSet
public class LobTest extends UnitilsJUnit4 {
	@HibernateSessionFactory({ "hibernate.cfg.xml" })
	private SessionFactory sessionFactory;

	@Test
	@ExpectedDataSet("LobTest-result.xml")
	public void testGetNativeCharArray() {
		sessionFactory.getCurrentSession().get(TestEntity.class, 4L);
	}
	
	@Test
	@ExpectedDataSet("LobTest-result.xml")
	public void testGetNativeCharWrapperArray() {
		sessionFactory.getCurrentSession().get(TestEntity.class, 3L);
	}

	@Test
	@ExpectedDataSet("LobTest-result.xml")
	public void testGetNativeByteArray() {
		sessionFactory.getCurrentSession().get(TestEntity.class, 2L);
	}
	
	@Test
	@ExpectedDataSet("LobTest-result.xml")
	public void testGetNativeByteWrapperArray() {
		sessionFactory.getCurrentSession().get(TestEntity.class, 1L);
	}
}
