package org.hibernate.hhh5811;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Version;

@Entity
public class TestEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Version
	private Long version;

	@Lob
	private Byte[] nativeByteWrapperArray;

	@Lob
	private byte[] nativeByteArray;
	
	@Lob
	private Character[] nativeCharWrapperArray;

	@Lob
	private char[] nativeCharArray;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}

	public Byte[] getNativeByteWrapperArray() {
		return nativeByteWrapperArray;
	}

	public void setNativeByteWrapperArray(Byte[] nativeByteWrapperArray) {
		this.nativeByteWrapperArray = nativeByteWrapperArray;
	}

	public byte[] getNativeByteArray() {
		return nativeByteArray;
	}

	public void setNativeByteArray(byte[] nativeByteArray) {
		this.nativeByteArray = nativeByteArray;
	}

	public Character[] getNativeCharWrapperArray() {
		return nativeCharWrapperArray;
	}

	public void setNativeCharWrapperArray(Character[] nativeCharWrapperArray) {
		this.nativeCharWrapperArray = nativeCharWrapperArray;
	}

	public char[] getNativeCharArray() {
		return nativeCharArray;
	}

	public void setNativeCharArray(char[] nativeCharArray) {
		this.nativeCharArray = nativeCharArray;
	}
}
