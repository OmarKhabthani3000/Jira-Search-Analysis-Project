package test;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import domain.Activity;
import domain.Deal;

public class Test {
	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(Test.class);

	public Test() throws HibernateException {
		sessionFactory = new Configuration().configure().buildSessionFactory();
	}

	public static void main(String[] args) throws Exception {
		new Test().run();
	}

	private void run() {
		try {
			Session session = currentSession();
			Transaction txn = session.beginTransaction();

			// ---------- Start test code

			Deal deal = new Deal();
			deal.setName("Test Deal");
			session.saveOrUpdate(deal);

			Activity activity = new Activity();
			activity.setName("Test Activity");
			session.saveOrUpdate(activity);

			activity.addDeal(deal);
			session.flush();

			deal.setName("Deal Name 2");
			session.flush();

			// ---------- End test code

			txn.commit();
			closeSession();
		} catch (HibernateException he) {
			log.error("error", he);
		}
	}

	// ------------------------- Session helper methods

	private static final ThreadLocal session = new ThreadLocal();
	private Set sessions = new HashSet();
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	private Session currentSession() throws HibernateException {
		Session s = (Session) session.get();
		// Open a new Session, if this Thread has none yet
		if (s == null) {
			s = sessionFactory.openSession();
			session.set(s);
			sessions.add(s);
			log.debug("Creating new Hibernate Session: " + Thread.currentThread().getName());
		} else {
			log.debug("Returning existing session: " + s.toString());
		}
		return s;
	}

	@SuppressWarnings("unchecked")
	private void closeSession() throws HibernateException {
		Session s = (Session) session.get();
		session.set(null);
		if (s != null)
			s.close();
		log.debug("Closing Hibernate Session: " + (s != null ? s.toString() : "null"));
		sessions.remove(s);
	}

}
