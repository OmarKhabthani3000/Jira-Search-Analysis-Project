package data;

import java.io.Serializable;
import java.util.Date;

public interface Persistent extends Serializable {

   // ---------------------- Accessor Methods

   public Long getId();

   public void setId(final Long id);

   public int getVersion();

   void setVersion(final int version);

   public Date getCreated();

   void setCreated(final Date created);

   // ---------------------- Common Methods

   public boolean equals(Object o);

   public int hashCode();

   // ---------------------- Business Methods

   public boolean isPersistent();

}