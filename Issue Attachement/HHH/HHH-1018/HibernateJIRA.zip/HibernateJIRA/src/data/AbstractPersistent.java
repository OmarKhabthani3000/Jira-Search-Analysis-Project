package data;

import java.util.Date;

/**
 * This class is a convenience superclass for all persistent business objects.
 * It supports versioning.
 * 
 * @author Connor Barry
 */
public abstract class AbstractPersistent implements Persistent {

	Long id;
	int version;
	Date created = new Date();

	// ------------------------ Accessor Methods

	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(final int version) {
		this.version = version;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(final Date created) {
		this.created = created;
	}

	// ------------------------ Common Methods

	@Override
	public abstract boolean equals(Object o);

	@Override
	public abstract int hashCode();

	// ------------------------ Business Methods

	public boolean isPersistent() {
		return (this.id != null);
	}

}
