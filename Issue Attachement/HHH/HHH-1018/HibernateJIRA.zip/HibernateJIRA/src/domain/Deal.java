package domain;

import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import data.AbstractPersistent;

public class Deal extends AbstractPersistent implements Comparable<Deal> {
	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(Deal.class);
	private static final long serialVersionUID = 1L;

	private SortedSet<Activity> activities = new TreeSet<Activity>();
	private String name;

	// ---------------------------- Accessor Methods

	public SortedSet<Activity> getActivities() {
		return activities;
	}

	public void setActivities(SortedSet<Activity> activities) {
		this.activities = activities;
	}

	public void addActivity(Activity activity) {
		activities.add(activity);
		activity.getDeals().add(this);
	}

	public void removeActivity(Activity activity) {
		activities.remove(activity);
		activity.getDeals().remove(this);
	}

	// ------------------

	public String getName() {
		return name;
	}

	public void setName(String titleText) {
		this.name = titleText;
	}

	// ---------------------------- Common Methods

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || (o.getClass() != getClass()))
			return false;
		Deal d = (Deal) o;
		return (name == d.getName() || (name != null && name.equals(d.getName())));
	}

	@Override
	public int hashCode() {
		int hash = 7;
		hash = 31 * hash + (name == null ? 0 : name.hashCode());
		return hash;
	}

	public int compareTo(Deal d) {
		if (equals(d))
			return 0;
		if (name != null && d.getName() != null)
			return name.compareToIgnoreCase(d.getName()) > 0 ? 1 : -1;
		return -1;
	}

}