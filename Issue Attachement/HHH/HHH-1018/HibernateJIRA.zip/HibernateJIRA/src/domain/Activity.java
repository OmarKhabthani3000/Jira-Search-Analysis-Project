package domain;

import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import data.AbstractPersistent;

public class Activity extends AbstractPersistent implements Comparable {
	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(Activity.class);
	private static final long serialVersionUID = -5670593335143618715L;

	private String name;
	private SortedSet<Deal> deals = new TreeSet<Deal>();

	// -------------------------- Accessor Methods

	public SortedSet<Deal> getDeals() {
		return deals;
	}

	protected void setDeals(SortedSet<Deal> deals) {
		this.deals = deals;
	}

	public void addDeal(Deal deal) {
		deals.add(deal);
		deal.getActivities().add(this);
	}

	public void removeDeal(Deal deal) {
		deals.remove(deal);
		deal.getActivities().remove(this);
	}

	// -----------------------

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// -------------------------- Common Methods

	@Override
	public String toString() {
		return name;
	}

	public int compareTo(Object o) {
		if (equals(o))
			return 0;
		Activity a = (Activity) o;
		return name.compareToIgnoreCase(a.getName()) > 0 ? 1 : -1;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || (o.getClass() != getClass()))
			return false;
		Activity oo = (Activity) o;
		return name == oo.getName() || (name != null && name.equals(oo.getName()));
	}

	@Override
	public int hashCode() {
		int hash = 7;
		hash = 31 * hash + (name == null ? 0 : name.hashCode());
		return hash;
	}
}