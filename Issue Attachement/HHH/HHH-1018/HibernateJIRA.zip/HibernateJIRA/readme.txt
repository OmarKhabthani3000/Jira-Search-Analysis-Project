I ran the test using mysql 5.0.13.

To create the test database:

open a terminal window
switch to the hibernateJIRA directory, and run the command:
mysql -uroot -proot test < create-db.sql
...substituting root / root for your login and password and test for your database.

Once the database is created, run ant in the hibernateJIRA directory and you should see the following:

C:\webapps\Hibernate JIRA>ant
Buildfile: build.xml

compile:

runTest:
     [java] Hibernate: insert into deals (version, created, name) values (?, ?,?)
     [java] Hibernate: insert into activities (version, created, name) values (?, ?, ?)
     [java] Hibernate: update deals set version=?, created=?, name=? where id=? and version=?
     [java] Hibernate: update activities set version=?, created=?, name=? where id=? and version=?
     [java] Hibernate: insert into activity_deals (activity_id, deal_id) values(?, ?)
     [java] Hibernate: update deals set version=?, created=?, name=? where id=? and version=?
     [java] Hibernate: update activities set version=?, created=?, name=? where id=? and version=?
     [java] Hibernate: insert into activity_deals (activity_id, deal_id) values (?, ?)
     [java] 0    [main] ERROR org.hibernate.util.JDBCExceptionReporter  - Duplicate entry '2-2' for key 1
     [java] 0    [main] ERROR org.hibernate.event.def.AbstractFlushingEventListener  - Could not synchronize database state with session
     [java] org.hibernate.exception.ConstraintViolationException: Could not execute JDBC batch update
     [java]     at org.hibernate.exception.SQLStateConverter.convert(SQLStateConverter.java:69)
     [java]     at org.hibernate.exception.JDBCExceptionHelper.convert(JDBCExceptionHelper.java:43)
     [java]     at org.hibernate.jdbc.AbstractBatcher.executeBatch(AbstractBatcher.java:200)
     [java]     at org.hibernate.engine.ActionQueue.executeActions(ActionQueue.java:230)
     [java]     at org.hibernate.engine.ActionQueue.executeActions(ActionQueue.java:143)
     [java]     at org.hibernate.event.def.AbstractFlushingEventListener.performExecutions(AbstractFlushingEventListener.java:296)
     [java]     at org.hibernate.event.def.DefaultFlushEventListener.onFlush(DefaultFlushEventListener.java:27)
     [java]     at org.hibernate.impl.SessionImpl.flush(SessionImpl.java:877)   
     [java]     at test.Test.run(Test.java:48)
     [java]     at test.Test.main(Test.java:26)
     [java] Caused by: java.sql.BatchUpdateException: Duplicate entry '2-2' for key 1
     [java]     at com.mysql.jdbc.ServerPreparedStatement.executeBatch(ServerPreparedStatement.java:642)
     [java]     at org.hibernate.jdbc.BatchingBatcher.doExecuteBatch(BatchingBatcher.java:58)
     [java]     at org.hibernate.jdbc.AbstractBatcher.executeBatch(AbstractBatcher.java:193)
     [java]     ... 7 more
     [java] 15   [main] ERROR test.Test  - error
     [java] org.hibernate.exception.ConstraintViolationException: Could not execute JDBC batch update
     [java]     at org.hibernate.exception.SQLStateConverter.convert(SQLStateConverter.java:69)
     [java]     at org.hibernate.exception.JDBCExceptionHelper.convert(JDBCExceptionHelper.java:43)
     [java]     at org.hibernate.jdbc.AbstractBatcher.executeBatch(AbstractBatcher.java:200)
     [java]     at org.hibernate.engine.ActionQueue.executeActions(ActionQueue.java:230)
     [java]     at org.hibernate.engine.ActionQueue.executeActions(ActionQueue.java:143)
     [java]     at org.hibernate.event.def.AbstractFlushingEventListener.performExecutions(AbstractFlushingEventListener.java:296)
     [java]     at org.hibernate.event.def.DefaultFlushEventListener.onFlush(DefaultFlushEventListener.java:27)
     [java]     at org.hibernate.impl.SessionImpl.flush(SessionImpl.java:877)
     [java]     at test.Test.run(Test.java:48)
     [java]     at test.Test.main(Test.java:26)
     [java] Caused by: java.sql.BatchUpdateException: Duplicate entry '2-2' for key 1
     [java]     at com.mysql.jdbc.ServerPreparedStatement.executeBatch(ServerPreparedStatement.java:642)
     [java]     at org.hibernate.jdbc.BatchingBatcher.doExecuteBatch(BatchingBatcher.java:58)
     [java]     at org.hibernate.jdbc.AbstractBatcher.executeBatch(AbstractBatcher.java:193)
     [java]     ... 7 more

BUILD SUCCESSFUL