    drop table if exists activities;

    drop table if exists activity_deals;

    drop table if exists deals;

    create table activities (
        id bigint not null auto_increment,
        version integer not null,
        created datetime,
        name varchar(255) not null,
        primary key (id)
    );

    create table activity_deals (
        activity_id bigint not null,
        deal_id bigint not null,
        primary key (activity_id, deal_id)
    );

    create table deals (
        id bigint not null auto_increment,
        version integer not null,
        created datetime,
        name varchar(255),
        primary key (id)
    );

    alter table activity_deals 
        add index FK849420575F413D44 (deal_id), 
        add constraint FK849420575F413D44 
        foreign key (deal_id) 
        references deals (id);

    alter table activity_deals 
        add index FK84942057991B0164 (activity_id), 
        add constraint FK84942057991B0164 
        foreign key (activity_id) 
        references activities (id);
