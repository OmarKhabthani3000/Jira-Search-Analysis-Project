import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Bar {
    @Id
    private Integer id;

    @OneToOne(cascade = { CascadeType.ALL })
    AbstractFoo myFoo;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public AbstractFoo getMyFoo() {
        return myFoo;
    }

    public void setMyFoo(AbstractFoo myFoo) {
        this.myFoo = myFoo;
    }
}
