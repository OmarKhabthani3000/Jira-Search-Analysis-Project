
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("KAPUT")
public class GreatFoo extends AbstractFoo {

}
