import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public abstract class AbstractFoo {
 
    @Id
    private Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
