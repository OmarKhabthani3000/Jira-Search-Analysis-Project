// $Id$
// Copyright (c) 2008 Boiron - Tous droits r�serv�s.

import junit.framework.TestCase;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.Restrictions;
import org.junit.Test;

public class TestHHH3828 extends TestCase {
    @Test
    public void testHHH3828() {
        Session session = new AnnotationConfiguration().configure().buildSessionFactory().openSession();
        Transaction t = session.beginTransaction();
        Criteria crit = session.createCriteria(Bar.class).createAlias("myFoo", "foo");
        crit.add(Restrictions.eq("foo.class", GreatFoo.class));
        crit.list();
        GreatFoo foo = new GreatFoo();
        Bar b = new Bar();
        b.setMyFoo(foo);
        foo.setId(1);
        b.setId(1);
        session.persist(b);
        session.flush();
        t.commit();
        // OK, one BAR in DB
        assertEquals(1, session.createCriteria(Bar.class).list().size());
        crit = session.createCriteria(Bar.class).createAlias("myFoo", "foo").add(
                Restrictions.eq("foo.class", GreatFoo.class));
        // KO, filter on DTYPE doesn't work
        assertEquals(1, crit.list().size());
    }
}
