package org.hibernate.jira.testcase;

import junit.framework.TestCase;

import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

/**
 * Junit Testcase for Oracle ORA-00936 with bulk delete / joined subclass (where /
 * and)
 * 
 * @author Heiko H�ter
 * @created 19.09.2005
 */
public class InvalidExpressionJoinedSubclass extends TestCase {
    private SessionFactory sessionFactory;

    @Override
    protected void setUp() throws Exception {
        DOMConfigurator.configure(this.getClass().getResource("logger.xml"));

        Configuration cfg = new Configuration().configure(getClass()
                .getResource("hibernate.cfg.xml"));

        SchemaExport schemaExport = new SchemaExport(cfg);
        schemaExport.create(false, true);

        this.sessionFactory = cfg.buildSessionFactory();
    }

    @Override
    protected void tearDown() throws Exception {
        this.sessionFactory.close();
    }

    public void test() {
        Session session = this.sessionFactory.openSession();
        try {
            session.createQuery("delete from SubObjekt where propertyA='1234'")
                    .executeUpdate();
        } finally {
            session.close();
        }
    }
}
