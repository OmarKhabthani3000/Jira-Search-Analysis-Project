package org.hibernate.jira.testcase;

public class SubObjekt extends SuperObjekt {
    private String propertyA;

    /**
     * @return Returns the propertyA.
     */
    public String getPropertyA() {
        return propertyA;
    }

    /**
     * @param propertyA The propertyA to set.
     */
    public void setPropertyA(String propertyA) {
        this.propertyA = propertyA;
    }
}
