package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Address {
	@Id
	private final String name;

	public Address(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}	
}
