package com.example.demo.model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Version;

@Entity
public class Person {
	
	@Id
	private final String name;
	
	@Version
	private final Long version = null;
	
	@MapsId
	@OneToOne
	@JoinColumn(name = "name")
	private final Address address;

	public Person(Address address) {
		this.name = address.getName();
		this.address = address;
	}
	
	public String getName() {
		return name;
	}
	
	public Address getAddress() {
		return address;
	}
}
