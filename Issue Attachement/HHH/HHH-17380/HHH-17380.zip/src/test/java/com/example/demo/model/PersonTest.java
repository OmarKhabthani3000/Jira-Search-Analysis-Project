package com.example.demo.model;

import static org.assertj.core.api.Assertions.assertThatCode;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureTestEntityManager;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@SpringBootTest
@AutoConfigureTestEntityManager
public class PersonTest {
	@Autowired
	private TestEntityManager entityManager;

	@Test
	void test() {
		var address = new Address("Alex");
		entityManager.persistAndFlush(address);
		var person = new Person(address);
		assertThatCode(() -> entityManager.persist(person)).doesNotThrowAnyException();
	}

}
