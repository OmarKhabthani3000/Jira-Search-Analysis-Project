package hhh5911;

import javax.persistence.EntityManager;

import org.junit.AfterClass;
import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Hhh5911Test {
    private static ClassPathXmlApplicationContext applicationContext;

    private static PersistenceService persistenceService;

    @BeforeClass
    public static void beforeClass() {
        applicationContext = new ClassPathXmlApplicationContext("/hhh5911/spring.xml");
        persistenceService = applicationContext.getBean(PersistenceService.class);

        persistenceService.executeTransactionally(new Runnable() {
            @Override
            public void run() {
                EntityManager entityManager = persistenceService.getEntityManager();

                Entity entity = new Entity();
                entity.setId(1);
                entity.setValue1("1");
                entity.setValue2("2");

                entityManager.persist(entity);
            }
        });
    }

    @AfterClass
    public static void afterClass() {
        if (applicationContext != null) {
            applicationContext.close();
        }
    }

    @Test
    public void test() {
        final EntityManager entityManager = persistenceService.getEntityManager();

        persistenceService.executeTransactionally(new Runnable() {
            @Override
            public void run() {
                Entity entity = entityManager.find(Entity.class, 1L);

                entity.setValue1("11");
                entity.setValue2("22");
            }
        });

        persistenceService.executeTransactionally(new Runnable() {
            @Override
            public void run() {
                Entity entity = entityManager.find(Entity.class, 1L);

                assertEquals("1", entity.getValue1());
                assertEquals("22", entity.getValue2());
                assertEquals(1, entity.getVersion());
            }
        });

        persistenceService.executeTransactionally(new Runnable() {
            @Override
            public void run() {
                Entity entity = entityManager.find(Entity.class, 1L);

                entity.setValue1("111");

                entityManager.flush();

                // Fails because the version is incremented even if all changes were reverted by the interceptor.
                // If this line is uncommented, the entire test succeeds.
                assertEquals(1, entity.getVersion());
            }
        });

        persistenceService.executeTransactionally(new Runnable() {
            @Override
            public void run() {
                Entity entity = entityManager.find(Entity.class, 1L);

                assertEquals("1", entity.getValue1());
                assertEquals("22", entity.getValue2());

                // Succeeds because no database update was performed in the previous transaction, so the version is
                // still 1.
                assertEquals(1, entity.getVersion());
            }
        });
    }
}
