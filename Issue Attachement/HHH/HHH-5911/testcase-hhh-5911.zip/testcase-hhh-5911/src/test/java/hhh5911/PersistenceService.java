package hhh5911;

import javax.persistence.EntityManager;

import org.hibernate.Session;

public interface PersistenceService {
    void executeTransactionally(Runnable task);

    Session getSession();

    EntityManager getEntityManager();
}
