package hhh5911;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.springframework.transaction.annotation.Transactional;

public class PersistenceServiceImpl implements PersistenceService {
    @PersistenceContext
    private EntityManager entityManager;

    @Transactional
    public void executeTransactionally(Runnable task) {
        task.run();
    }

    @Override
    public EntityManager getEntityManager() {
        return entityManager;
    }

    @Override
    public Session getSession() {
        return (Session) getEntityManager().getDelegate();
    }
}
