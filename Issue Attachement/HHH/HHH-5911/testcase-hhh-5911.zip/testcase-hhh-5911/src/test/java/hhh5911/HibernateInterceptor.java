package hhh5911;

import java.io.Serializable;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

public class HibernateInterceptor extends EmptyInterceptor {
    private static final long serialVersionUID = 1L;

    public static boolean equal(Object a, Object b) {
        return a == b || (a != null && a.equals(b));
    }

    /**
     * Changes made to {@code value1} property is always reverted.
     */
    @Override
    public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState,
            String[] propertyNames, Type[] types) {
        boolean stateChanged = false;

        for (int i = 0; i < propertyNames.length; i++) {
            String propertyName = propertyNames[i];

            if ("value1".equals(propertyName) && !equal(currentState[i], previousState[i])) {
                currentState[i] = previousState[i];
                stateChanged = true;
                break;
            }
        }

        return stateChanged;
    }
}
