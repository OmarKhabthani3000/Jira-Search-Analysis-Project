package com.example.demo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@IdClass(ZBookPK.class) //for composite primary key
@Table(name = "ZBOOK_T")
@DynamicInsert
@DynamicUpdate
public class ZBook
{
    //for composite primary key
    @Id
    @Column(unique = false, nullable = false)
    private String fileid;

    //for composite primary key
    @Id
    @Column(unique = true, nullable = false)
    private String versionid;

    @Column(name = "description")
    private String description;

    @Column(name = "title")
    private String title;

    //Constructor
    public ZBook(final String fileid, final String versionid)
    {
        this.fileid = fileid;
        this.versionid = versionid;
    }

    public String getFileId()
    {
        return fileid;
    }

    public void setFileId(final String fileid)
    {
        this.fileid = fileid;
    }

    public String getVersionid()
    {
        return versionid;
    }

    public void setVersionid(final String versionid)
    {
        this.versionid = versionid;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(final String title) {
        this.title = title;
    }

}
