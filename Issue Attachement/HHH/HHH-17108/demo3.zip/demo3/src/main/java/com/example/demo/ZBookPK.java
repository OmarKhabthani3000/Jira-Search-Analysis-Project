
package com.example.demo;

import java.io.Serializable;

import com.google.common.base.Objects;

public class ZBookPK implements Serializable
{
    private static final long serialVersionUID = 1L;

    protected String fileid;

    protected String versionid;

    public ZBookPK()
    {
        this(null);
    }

    public ZBookPK(final String fileid)
    {
        this(fileid, "");
    }

    public ZBookPK(final String fileid, final String versionid)
    {
        this.fileid = fileid;
        this.versionid = versionid;
    }

    @Override
    public boolean equals(final Object object)
    {
        if (super.equals(object))
        {
            return true;
        }
        if (object instanceof ZBookPK)
        {
            ZBookPK pk = (ZBookPK) object;
            return Objects.equal(fileid, pk.fileid) && Objects.equal(versionid, pk.versionid);
        }
        return false;
    }

    @Override
    public int hashCode()
    {
        return Objects.hashCode(fileid, versionid);
    }

}
