
package com.example.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.NativeQuery;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.List;

public class H2HibernateTest {

    private static SessionFactory sessionFactory = null;
    private Session session = null;

    @BeforeAll
    public static void setup(){
        try {
            StandardServiceRegistry standardRegistry
                    = new StandardServiceRegistryBuilder()
                    .configure("hibernate-h2-test.cfg.xml")
                    .build();

            Metadata metadata = new MetadataSources(standardRegistry)
                    .addAnnotatedClass(ZBook.class)
                    .addAnnotatedClass(ZPublisher.class)
                    .getMetadataBuilder()
                    .build();

            sessionFactory = metadata
                    .getSessionFactoryBuilder().build();

        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    @BeforeEach
    public void setupThis(){
        session = sessionFactory.openSession();
        session.beginTransaction();
    }

    @AfterEach
    public void tearThis(){
        session.getTransaction().commit();
    }

    @AfterAll
    public static void tear(){
        sessionFactory.close();
    }

    /**
     * Note: demo3 tests using a composite key in book, which causes an error:
     *
     * org.hibernate.exception.SQLGrammarException: Unable to find column position by name: descript3_0_0_ [Column "descript3_0_0_" not found
     * [42122-220]] [n/a]
     */
    @Test
    public void testNativeQueryWithEntity_test2()
    {
        String fileid = "file1";
        String versionid = "version1";

        ZPublisher publisher = new ZPublisher(fileid);
        publisher.setVersionid(versionid);
        publisher.setDescription("Dodo Books");
        session.persist(publisher);
        assertEquals(fileid, publisher.getFileId());
        assertEquals(versionid, publisher.getVersionid());

        ZBook book = new ZBook(fileid, versionid);
        book.setTitle("Birdwatchers Guide to Dodos");
        book.setDescription("A complete guide");
        session.persist(book);
        assertEquals(fileid, book.getFileId());
        assertEquals(versionid, book.getVersionid());

        //Test
        NativeQuery query = session
            .createNativeQuery("select {book.*}, {publisher.*} from zbook_t book, ZPUBLISHER_T publisher where book.fileid = publisher.fileid"); // and book.versionid = publisher.versionid
        query.addEntity("book", ZBook.class);
        query.addEntity("publisher", ZPublisher.class);
        List<Object[]> results2 = query.list();
        assertEquals(1, results2.size());
        Object[] row = results2.get(0);
        assertEquals(2, row.length);
        ZBook retrievedBook = (ZBook) row[0];
        ZPublisher retrievedPublisher = (ZPublisher) row[1];

        assertEquals("A complete guide", retrievedBook.getDescription());
        assertEquals("Dodo Books", retrievedPublisher.getDescription());
    }

}
