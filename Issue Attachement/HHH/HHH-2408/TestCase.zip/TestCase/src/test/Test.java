package test;

public class Test {
	@SuppressWarnings ("unused")
	public static void main(String[] args) throws Exception {
		StandaloneSpringFactory factory = StandaloneSpringFactory.getInstance();
		IGenericDao dao = (IGenericDao) factory.getBean("genericDao");
		dao.executeUpdate("Issue.refreshDueDate", new Param("branchId", 987L));
	}
}
