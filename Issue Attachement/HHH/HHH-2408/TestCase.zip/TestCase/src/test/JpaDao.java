package test;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.FlushModeType;
import javax.persistence.Query;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class JpaDao implements IGenericDao {
	private EntityManager em;

	private Query prepareQuery(String queryName, Object... queryArgs) {
		em.setFlushMode(FlushModeType.COMMIT);
		Query query = em.createNamedQuery(queryName);
		for (int paramIndex = 0; paramIndex != queryArgs.length; paramIndex++) {
			query.setParameter(paramIndex, queryArgs[paramIndex]);
		}
		return query;
	}
	private Query prepareQuery(String queryName, Param... queryArgs) {
		em.setFlushMode(FlushModeType.COMMIT);
		Query query = em.createNamedQuery(queryName);
		for (Param param : queryArgs) {
			query.setParameter(param.getName(), param.getValue());
		}
		return query;
	}
	public <E extends PersistentEntity> void delete(E object) {
		em.remove(object);
	}
	public void executeUpdate(String queryName, Object... queryArgs) {
		prepareQuery(queryName, queryArgs).executeUpdate();
	}
	public void executeUpdate(String queryName, Param... queryArgs) {
		prepareQuery(queryName, queryArgs).executeUpdate();
	}
	public void flush() {
		em.flush();
	}
	@SuppressWarnings ("unchecked")
	public <E extends PersistentEntity> List<E> getAll(Class<E> clazz) {
		em.setFlushMode(FlushModeType.COMMIT);
		return em.createQuery("SELECT e FROM " + clazz.getSimpleName() + " e")
				.getResultList();
	}
	public <E extends PersistentEntity> E getById(Class<E> clazz, long id) {
		em.setFlushMode(FlushModeType.COMMIT);
		return em.find(clazz, id);
	}
	@SuppressWarnings ("unchecked")
	public List<Object[]> getByNativeQuery(String sql, Param... queryArgs) {
		Session session = (Session) em.getDelegate();
		SQLQuery query = session.createSQLQuery(sql);
		for (Param arg : queryArgs) {
			if (arg.getValue() == null) {
				query.setParameter(arg.getName(), arg.getValue(),
						Hibernate.STRING);
			} else {
				query.setParameter(arg.getName(), arg.getValue());
			}
		}
		return query.list();
	}
	@SuppressWarnings ("unchecked")
	public <E extends PersistentEntity> List<E> getByQuery(String queryName,
			Object... queryArgs) {
		return prepareQuery(queryName, queryArgs).getResultList();
	}
	@SuppressWarnings ("unchecked")
	public <E extends PersistentEntity> List<E> getByQuery(String queryName,
			Param... queryArgs) {
		return prepareQuery(queryName, queryArgs).getResultList();
	}
	@SuppressWarnings ("unchecked")
	public <E extends PersistentEntity> E getUniqueByQuery(String queryName,
			Object... queryArgs) {
		return (E) prepareQuery(queryName, queryArgs).getSingleResult();
	}
	@SuppressWarnings ("unchecked")
	public <E extends PersistentEntity> E getUniqueByQuery(String queryName,
			Param... queryArgs) {
		return (E) prepareQuery(queryName, queryArgs).getSingleResult();
	}
	public <E extends PersistentEntity> void refresh(E object) {
		if (!object.isNew()) {
			em.refresh(object);
		}
	}
	public <E extends PersistentEntity> void save(E... entities) {
		for (PersistentEntity entity : entities) {
			em.persist(entity);
		}
	}
	public void setEm(EntityManager em) {
		this.em = em;
	}
}
