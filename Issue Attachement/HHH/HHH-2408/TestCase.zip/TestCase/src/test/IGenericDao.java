package test;

import java.util.List;

/**
 * Generic DAO interface, exposing persistence operations for the subclasses of
 * PersistentEntity
 */
public interface IGenericDao {
	/**
	 * Deletes the specified entity, either with regular or soft-delete.
	 */
	<E extends PersistentEntity> void delete(E object);
	void executeUpdate(String queryName, Object... queryArgs);
	void executeUpdate(String queryName, Param... queryArgs);
	void flush();
	/**
	 * Retrieves all entities of the specified type
	 */
	<E extends PersistentEntity> List<E> getAll(Class<E> clazz);
	/**
	 * Retrieves the persistent entity by its unique id, or null if no entity
	 * could be found.
	 */
	<E extends PersistentEntity> E getById(Class<E> clazz, long id);
	/**
	 * Retrieves all entites of the specified type from a native query.
	 */
	List<Object[]> getByNativeQuery(String query, Param... queryArgs);
	/**
	 * Retrieves all entites of the specified type from a named query.
	 */
	<E extends PersistentEntity> List<E> getByQuery(String queryName,
			Object... queryArgs);
	/**
	 * Retrieves all entites of the specified type from a named query.
	 */
	<E extends PersistentEntity> List<E> getByQuery(String queryName,
			Param... queryArgs);
	/**
	 * Returns unique value from named query, or null if no values found.
	 */
	<E extends PersistentEntity> E getUniqueByQuery(String queryName,
			Object... queryArgs);
	/**
	 * Returns unique value from named query, or null if no values found.
	 */
	<E extends PersistentEntity> E getUniqueByQuery(String queryName,
			Param... queryArgs);
	<E extends PersistentEntity> void refresh(E object);
	/**
	 * Persists the specified entity(-ies). Might assign a new identifier(-s) in
	 * case of transient instance(-s).
	 */
	<E extends PersistentEntity> void save(E... entities);
}
