package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StandaloneSpringFactory {
	private static StandaloneSpringFactory instance = new StandaloneSpringFactory();

	public static StandaloneSpringFactory getInstance() {
		return instance;
	}

	private ApplicationContext context;

	private StandaloneSpringFactory() {
		context = new ClassPathXmlApplicationContext("applicationContext.xml");
	}
	public Object getBean(String beanName) {
		return context.getBean(beanName);
	}
	public ApplicationContext getContext() {
		return context;
	}
}
