package test;

import javax.persistence.Entity;

@Entity
public class Branch extends PersistentEntity {
}
