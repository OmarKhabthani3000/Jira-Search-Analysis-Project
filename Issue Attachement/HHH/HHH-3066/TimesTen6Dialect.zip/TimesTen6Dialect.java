package org.hibernate.dialect;

import java.sql.Types;

import org.hibernate.Hibernate;
import org.hibernate.dialect.function.VarArgsSQLFunction;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.function.NoArgSQLFunction;
import org.hibernate.dialect.function.SQLFunctionTemplate;
import org.hibernate.dialect.function.StandardSQLFunction;
import org.hibernate.sql.JoinFragment;
import org.hibernate.sql.OracleJoinFragment;

/**
 * A SQL dialect for TimesTen 6.
 *
 * Known limitations:
 *
 *  1. No CLOB/BLOB support (VARCHAR & VARBINARY are used as substitutes).
 *  2. No cascade delete support.
 *  3. No Calendar support.
 *  4. No support for updating primary keys.
 *
 * @author Jason Feldhaus (jason.feldhaus@oracle.com)
 */
 
public class TimesTen6Dialect
  extends Dialect
{

  public TimesTen6Dialect()
  {
    super();
    registerColumnType(Types.BIT, "TINYINT");
    registerColumnType(Types.BIGINT, "BIGINT");
    registerColumnType(Types.SMALLINT, "SMALLINT");
    registerColumnType(Types.TINYINT, "TINYINT");
    registerColumnType(Types.INTEGER, "INTEGER");
    registerColumnType(Types.CHAR, "CHAR(1)");
    registerColumnType(Types.VARCHAR, "VARCHAR($l)");
    registerColumnType(Types.FLOAT, "FLOAT");
    registerColumnType(Types.DOUBLE, "DOUBLE");
    registerColumnType(Types.DATE, "DATE");
    registerColumnType(Types.TIME, "TIME");
    registerColumnType(Types.TIMESTAMP, "TIMESTAMP");
    registerColumnType(Types.VARBINARY, "VARBINARY($l)");
    registerColumnType(Types.NUMERIC, "DECIMAL($p, $s)");
    
    // TimesTen has no BLOB/CLOB support, but these types may be suitable
    // for some applications. The length is limited to 4MB.
    registerColumnType(Types.BLOB, "VARBINARY(4194304)");
    registerColumnType(Types.CLOB, "VARCHAR(4194304)");


    // properties
    getDefaultProperties().setProperty(
      Environment.USE_STREAMS_FOR_BINARY, "true");
                                       
    getDefaultProperties().setProperty(
      Environment.STATEMENT_BATCH_SIZE, DEFAULT_BATCH_SIZE);
      
      
    registerFunction("lower", new StandardSQLFunction("lower"));
    registerFunction("upper", new StandardSQLFunction("upper"));
    registerFunction("rtrim", new StandardSQLFunction("rtrim"));
    registerFunction( "concat", 
     new VarArgsSQLFunction( Hibernate.STRING, "(", "||", ")" ) );
    registerFunction("mod", new StandardSQLFunction("mod"));
    registerFunction("to_char", 
       new StandardSQLFunction("to_char", Hibernate.STRING));
    registerFunction("instr", 
      new StandardSQLFunction("instr", Hibernate.INTEGER) );
    registerFunction("substr", 
      new StandardSQLFunction("substr", Hibernate.STRING) );
    registerFunction("substring", 
      new StandardSQLFunction( "substr", Hibernate.STRING ) );
    registerFunction("locate", 
      new SQLFunctionTemplate( Hibernate.INTEGER, "instr(?2,?1)" ) );
    registerFunction( "str", 
      new StandardSQLFunction("to_char", Hibernate.STRING) );
                     
                     
    registerFunction("to_date", 
      new StandardSQLFunction("to_date", Hibernate.TIMESTAMP));
    registerFunction("sysdate", 
      new NoArgSQLFunction("sysdate", Hibernate.TIMESTAMP, false));
    registerFunction("getdate", 
      new NoArgSQLFunction("getdate", Hibernate.TIMESTAMP, false));
                                     
    registerFunction("current_date", 
      new NoArgSQLFunction("sysdate", Hibernate.DATE, false));
    registerFunction("current_time", 
      new NoArgSQLFunction("sysdate", Hibernate.TIME, false));
    registerFunction("current_timestamp", 
      new NoArgSQLFunction("sysdate", Hibernate.TIMESTAMP, false));
                                      
                                          
    registerFunction("nvl", new StandardSQLFunction("nvl"));
    registerFunction( "user", 
      new NoArgSQLFunction("user", Hibernate.STRING, false) );
    registerFunction( "rowid", 
      new NoArgSQLFunction("rowid", Hibernate.LONG, false) );

  }

  public boolean dropConstraints()
  {
    return true;
  }

  public boolean qualifyIndexName()
  {
    return false;
  }

  public boolean supportsUnique()
  {
    return true;
  }

  public boolean supportsUniqueConstraintInCreateAlterTable()
  {
    return false;
  }

  public String getAddColumnString()
  {
    return "add";
  }

  public boolean supportsSequences()
  {
    return true;
  }

  public String getSelectSequenceNextValString(String sequenceName)
  {
    return sequenceName + ".nextval";
  }

  public String getSequenceNextValString(String sequenceName)
  {
    return "select " + sequenceName + ".nextval from sys.dual";
  }

  public String getCreateSequenceString(String sequenceName)
  {
    return "create sequence " + sequenceName;
  }

  public String getDropSequenceString(String sequenceName)
  {
    return "drop sequence " + sequenceName;
  }

  public String getQuerySequencesString()
  {
    return "select NAME from sys.sequences";
  }

  public JoinFragment createOuterJoinFragment()
  {
    return new OracleJoinFragment();
  }


  public boolean supportsForUpdateNowait()
  {
    return false;
  }

  public String getForUpdateString()
  {
    return " for update";
  }

  public boolean supportsColumnCheck()
  {
    return false;
  }

  public boolean supportsTableCheck()
  {
    return false;
  }

  public boolean supportsLimitOffset()
  {
    return true;
  }

  public boolean supportsVariableLimit()
  {
    return false;
  }

  public boolean supportsLimit()
  {
    return true;
  }

  public boolean useMaxForLimit()
  {
    return true;
  }

  public String getLimitString(String querySelect, int offset, int limit)
  {
    if (offset > 0)
    {
      // use the 'ROWS M to N' syntax
      return new StringBuffer(querySelect.length() + 13).
        append(querySelect).insert(6, " rows " + offset + " to " + limit).toString();
    }

    // use the 'FIRST N' syntax
    return new StringBuffer(querySelect.length() + 9).
      append(querySelect).insert(6, " first " + limit).toString();
  }

  public boolean supportsCurrentTimestampSelection()
  {
    return true;
  }

  public String getCurrentTimestampSelectString()
  {
    return "select sysdate from sys.dual";
  }


  public boolean isCurrentTimestampSelectStringCallable()
  {
    return false;
  }

  public boolean supportsTemporaryTables()
  {
    return true;
  }

  public String generateTemporaryTableName(String baseTableName)
  {
    String name = super.generateTemporaryTableName(baseTableName);
    return name.length() > 30? name.substring(1, 30): name;
  }

  public String getCreateTemporaryTableString()
  {
    return "create global temporary table";
  }

  public String getCreateTemporaryTablePostfix()
  {
    return "on commit delete rows";
  }


  public boolean supportsUnionAll() 
  {
    return true;
  }

  public boolean supportsCascadeDelete()
  {
    return false;
  }
  
  public boolean supportsCircularCascadeDeleteConstraints()
  {
    return false;
  }

  public boolean supportsEmptyInList()
  {
    return true;
  }
}
