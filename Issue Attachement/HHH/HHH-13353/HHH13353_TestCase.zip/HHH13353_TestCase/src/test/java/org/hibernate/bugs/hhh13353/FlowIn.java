package org.hibernate.bugs.hhh13353;

import java.util.Map;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Book.java This class maps to a table in database.
 * 
 * @author www.codejava.net
 *
 */

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "FlowIn")
@Access(value = AccessType.FIELD)
@Cacheable(value = false)
public class FlowIn {

	public FlowIn() {
	}

	@EmbeddedId
	private FlowInId codeObject = new FlowInId();

	@OneToMany(targetEntity = BlocRecord.class, cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "flowIn", orphanRemoval = true)
	@MapKey(name = "blocRecordId.messageType")
	private Map<java.lang.String, BlocRecord> blocRecord = new java.util.HashMap<>();



}
