package org.hibernate.bugs.hhh13353;



import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class FlowInId implements Serializable {

	// generated serialVersionUID
	private static final long serialVersionUID = -8512098024980515252L;
	
	
	@Column(name = "identifier_")
	private java.lang.String identifier;



}// end Class
