package org.hibernate.bugs.hhh13353;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class HHH13353MapKeyTestCase {

	private SessionFactory sessionFactory ;

	@Before
	public void init() {
		StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.configure() // configures settings from hibernate.cfg.xml
				.build();
		try {
			sessionFactory = new MetadataSources(registry).buildMetadata().buildSessionFactory();
		} catch (Exception ex) {
			ex.printStackTrace();
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}

	@After
	public void destroy() {
		if(sessionFactory !=null){
		sessionFactory.close();
		}
	}

	@Test
	public void hhh13353Test() throws Exception {
		
	}
	
}
