package net.codejava.hibernate;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "blocRecord")
@Access(value = AccessType.FIELD)
public class BlocRecord {

	@EmbeddedId
	private BlocRecordId blocRecordId = new BlocRecordId();

	@MapsId("flowIn")
	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumns({
			@JoinColumn(name = "flowin_identifier_", referencedColumnName = "identifier_", unique = false, nullable = false) })
	private FlowIn flowIn;

	@Column(name = "description_", unique = false, nullable = true, insertable = true, updatable = true, length = 255)
	private String description;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
