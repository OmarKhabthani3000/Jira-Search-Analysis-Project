package bug;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;


/**
 *
 */

public class Test {

    private final SessionFactory sessionFactory = buildSessionFactory();

    @org.junit.Test
    public void test() {

        final Session s = sessionFactory.getCurrentSession();
        final Transaction t = s.getTransaction();
        t.begin();
        s.createQuery("FROM TestEntity t WHERE t.testEnum = bug.TestEnum.VALUE");
        t.commit();
    }


    private static SessionFactory buildSessionFactory() {
        org.h2.Driver.load();

        final Configuration configuration = new Configuration();
        configuration.addAnnotatedClass(TestEntity.class).addAttributeConverter(TestConverter.class);
        configuration.configure();

        final ServiceRegistry serviceRegistry =
                new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();

        return configuration.buildSessionFactory(serviceRegistry);
    }
}
