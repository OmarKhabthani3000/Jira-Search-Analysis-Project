package bug;

import javax.persistence.AttributeConverter;
import javax.persistence.Convert;

/**
 *
 */
@Convert(converter = TestConverter.class)
public enum TestEnum {

    VALUE;


}
