package bug;

import javax.persistence.AttributeConverter;

/**
 *
 */
@javax.persistence.Converter(autoApply = true)
public class TestConverter implements AttributeConverter<TestEnum, Integer> {

    @Override
    public Integer convertToDatabaseColumn(TestEnum attribute) {
        return 1;
    }

    @Override
    public TestEnum convertToEntityAttribute(Integer dbData) {
        return TestEnum.VALUE;
    }
}
