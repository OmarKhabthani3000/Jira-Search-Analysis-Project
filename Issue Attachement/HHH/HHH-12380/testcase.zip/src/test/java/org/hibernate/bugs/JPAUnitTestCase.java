package org.hibernate.bugs;

import org.hibernate.bugs.model.Book;
import org.hibernate.bugs.model.BookStore;
import org.hibernate.bugs.model.Comment;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Arrays;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {
	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Add your tests, using standard JUnit.
	@Test
	public void hhh12380Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		entityManager.getTransaction().begin();

		Book mainBook = new Book();
		mainBook.setComment(new Comment("asdadf"));
		mainBook.setComments(Arrays.asList(new Comment("12345")));

		BookStore bookStore = new BookStore();
		bookStore.setBook(mainBook);

		// Fails when persisting bookStore
		entityManager.persist(bookStore);
		// Success when persisting mainBook
//		entityManager.persist(mainBook);

		entityManager.getTransaction().commit();

		entityManager.clear();
		entityManager.close();
	}
}
