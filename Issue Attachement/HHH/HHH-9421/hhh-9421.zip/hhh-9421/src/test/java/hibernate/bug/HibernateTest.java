package hibernate.bug;

import hibernate.bug.model.Document;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {

    private EntityManagerFactory emf;

    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");

        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        // Create one of each entity type
        Document doc = new Document();
        doc.getMap().put("abc", "123");
        doc.getMap().put("def", "456");
        em.persist(doc);

        em.flush();
        tx.commit();
        em.close();
    }

    @Test
    public void testTypeForNoInheritance() {
        EntityManager em = emf.createEntityManager();
        
        List<Document> results = em.createQuery("FROM Document d JOIN d.map m WHERE KEY(m) = :key AND VALUE(m) = :value", Document.class)
                .setParameter("key", "abc")
                .setParameter("value", "123")
                .getResultList();
        assertEquals(1, results.size());
        
        em.close();
    }
}
