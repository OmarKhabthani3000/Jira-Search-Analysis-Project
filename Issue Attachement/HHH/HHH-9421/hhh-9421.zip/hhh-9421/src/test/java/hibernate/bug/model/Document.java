package hibernate.bug.model;

import java.util.HashMap;
import java.util.Map;
import javax.persistence.*;

@Entity
public class Document {

    private long id;
    private Map<String, String> map = new HashMap<String, String>(0);

    @Id
    @GeneratedValue
    public long getId() {
        return this.id;
    }

    public void setId(final long id) {
        this.id = id;
    }

    @ElementCollection(fetch = FetchType.LAZY)
    @MapKeyColumn(name = "name")
    @Column(name = "value")
    public Map<String, String> getMap() {
        return map;
    }

    public void setMap(Map<String, String> map) {
        this.map = map;
    }
}
