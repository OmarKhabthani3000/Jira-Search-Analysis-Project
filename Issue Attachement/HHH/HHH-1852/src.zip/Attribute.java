package org.endea.model.framework.entity;

import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class Attribute<E extends Entity> extends
        Instance<AttributeType>
{
    private String data;

    @ManyToOne(optional = false)
    private AttributeType type;

    // ///

    protected Attribute()
    {
    }

    public Attribute(E entity, AttributeType type)
    {
        super(type);

        entity.getAttributes().add(this);
    }

    // ///

    public String getData()
    {
        return data;
    }

    public void setData(String data)
    {
        this.data = data;
    }

    public abstract E getEntity();

    @Override
    public AttributeType getType()
    {
        return type;
    }

    // ///

    @Override
    protected void setType(AttributeType type)
    {
        this.type = type;
    }
}
