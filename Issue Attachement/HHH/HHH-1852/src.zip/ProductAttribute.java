package org.endea.model.product;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.endea.model.framework.entity.Attribute;
import org.endea.model.framework.entity.AttributeType;

@Entity
@Table(name = "product_productattribute")
public class ProductAttribute extends Attribute<Product>
{
    @ManyToOne(optional = false)
    private Product entity;

    // ///

    protected ProductAttribute()
    {
    }

    public ProductAttribute(Product entity, AttributeType type)
    {
        super(entity, type);
        this.entity = entity;
    }

    // ///

    @Override
    public Product getEntity()
    {
        return entity;
    }
}
