Run against Oracle 11g Release 2. The databse character set is important.

*** FIRST TEST ***

--- Config ---
NLS_CHARACTERSET: AL32UTF8

--- Starting JDBC Test ---
Exception message: ORA-24816: Expanded non LONG bind data supplied after actual LONG or LOB column

--- Starting JDBC2 Test ---
JDBC2 test finished successfully

--- Starting Hibernate Test ---
SLF4J: Failed to load class "org.slf4j.impl.StaticLoggerBinder".
SLF4J: Defaulting to no-operation (NOP) logger implementation
SLF4J: See http://www.slf4j.org/codes.html#StaticLoggerBinder for further details.
Hibernate: insert into lob_test (lobValue, qwerty, id) values (?, ?, ?)
Exception message: Could not execute JDBC batch update
Exception message: ORA-24816: Expanded non LONG bind data supplied after actual LONG or LOB column

done


*** SECOND TEST ***

--- Config ---
NLS_CHARACTERSET: WE8MSWIN1252

--- Starting JDBC Test ---
JDBC test finished successfully

--- Starting JDBC2 Test ---
JDBC2 test finished successfully

--- Starting Hibernate Test ---
SLF4J: Failed to load class "org.slf4j.impl.StaticLoggerBinder".
SLF4J: Defaulting to no-operation (NOP) logger implementation
SLF4J: See http://www.slf4j.org/codes.html#StaticLoggerBinder for further details.
Hibernate: insert into lob_test (lobValue, qwerty, id) values (?, ?, ?)
Hibernate test finished successfully

done
