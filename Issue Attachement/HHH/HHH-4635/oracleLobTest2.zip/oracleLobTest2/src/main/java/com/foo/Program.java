package com.foo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Program {

	private static final String conString = "jdbc:oracle:thin:oratest/oratest@127.0.0.1:1521:oradb2";
	private static SessionFactory sessionFactory;

	public static void main(String[] args) throws Exception {
		
		reset();
		
		printConfig();
		
		try {
			System.out.println("--- Starting JDBC Test ---");
			jdbcTest();
			System.out.println("JDBC test finished successfully\n");
		} catch (Exception e) {
			print( e );
		}
		
		try {
			System.out.println("--- Starting JDBC2 Test ---");
			jdbcTest2();
			System.out.println("JDBC2 test finished successfully\n");
		} catch (Exception e) {
			print( e );
		}

		try {
			System.out.println("--- Starting Hibernate Test ---");
			hibernateTest();
			System.out.println("Hibernate test finished successfully\n");
		} catch (Exception e) {
			print( e );
		}
		System.out.println("done");
	}
	
	private static void printConfig() throws Exception {
		System.out.println("--- Config ---");
		String sql = "select value from V$NLS_PARAMETERS where parameter = 'NLS_CHARACTERSET'";
		Connection con = DriverManager.getConnection(conString);		
		PreparedStatement stmt = con.prepareStatement(sql);
		
		ResultSet rs =  stmt.executeQuery();
		rs.next();
		String s = rs.getString(1);
		System.out.println( "NLS_CHARACTERSET: " + s);
		System.out.println();
	}

	private static void reset() throws Exception {
		Connection con = DriverManager.getConnection(conString);
		
		PreparedStatement stmt = con.prepareStatement("drop table lob_test");
		try {
			stmt.executeUpdate();
		} catch( Exception e ) {
		}
		stmt.close();
		
		
		stmt = con.prepareStatement("create table lob_test( id number(19), lobValue blob, qwerty varchar2(4000) )");
		stmt.executeUpdate();
	}
	
	private static void print( Throwable t ) {
		while( t != null ) {
			System.out.println( "Exception message: " + t.getMessage() );
			t = t.getCause();
		}
	}

	private static void jdbcTest() throws Exception {
		Connection con = DriverManager.getConnection(conString);
		con.setAutoCommit(false);

		String sql = "insert into lob_test ( lobValue, qwerty, id) values (?, ?, ?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setObject(1, new byte[9999]);
		stmt.setString(2, randomString(1001));
		stmt.setInt(3, 1);
		stmt.executeUpdate();
		con.commit();
	}
	
	private static void jdbcTest2() throws Exception {
		Connection con = DriverManager.getConnection(conString);
		con.setAutoCommit(false);

		String sql = "insert into lob_test ( qwerty, id, lobValue) values (?, ?, ?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, randomString(1001));
		stmt.setInt(2, 1);
		stmt.setObject(3, new byte[9999]);
		stmt.executeUpdate();
		con.commit();
	}
	
	private static String randomString( int count ) {
		StringBuilder buffer = new StringBuilder(count);
		for( int i = 0; i < count; i++ ) {
			buffer.append( 'a' );
		}
		return buffer.toString();
	}

	private static void hibernateTest() {
		Session session = getSessionFactory().openSession();
		session.beginTransaction();
		LobTestEntity entity = new LobTestEntity();
		entity.setId(1L);
		entity.setLobValue(Hibernate.createBlob(new byte[9999]));
		entity.setQwerty(randomString(1001));
		session.save(entity);
		session.getTransaction().commit();
	}
	
	private static SessionFactory getSessionFactory() {
		if( sessionFactory == null ) {
			sessionFactory = buildSessionFactory();
		}
		return sessionFactory;
	}

	private static SessionFactory buildSessionFactory()
			throws HibernateException {
		Configuration cfg = new Configuration();
		cfg.addAnnotatedClass(LobTestEntity.class);
		cfg.setProperty( "hibernate.connection.url", conString );
		cfg.setProperty( "hibernate.show_sql", "true" );
		return cfg.buildSessionFactory();
	}
}
