/*------------------------------------------------------------------------------
 * COPYRIGHT Ericsson 2010
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *----------------------------------------------------------------------------*/
package hhh7629.dm.helper;

import org.hibernate.collection.internal.PersistentBag;
import org.hibernate.collection.spi.PersistentCollection;
import org.hibernate.proxy.HibernateProxy;

/**
 * 
 * The purpose of this class is to consolidate common DM related
 * properties or methods among different persistence providers into
 * one place.
 * 
 */
public class DmHelper {
    @SuppressWarnings("unchecked")
    public static <T> T resolveEntity(T entity) {
        if (entity instanceof HibernateProxy) {
            return (T) ((HibernateProxy) entity).getHibernateLazyInitializer().getImplementation();
        } else if ((entity instanceof PersistentCollection) || (entity instanceof PersistentBag)) {
            ((PersistentCollection) entity).forceInitialization();
        }
        return entity;
    }
}
