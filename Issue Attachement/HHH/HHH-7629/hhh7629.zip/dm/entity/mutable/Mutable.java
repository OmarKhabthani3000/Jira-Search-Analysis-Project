/*------------------------------------------------------------------------------
 * COPYRIGHT Ericsson 2008-2010
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *----------------------------------------------------------------------------*/

package hhh7629.dm.entity.mutable;


import hhh7629.dm.entity.base.Entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@MappedSuperclass
public abstract class Mutable extends Entity
{
        /**
         * 
         */
        private static final long serialVersionUID = 8744313863607677640L;
        
        @Column(name="MODIFICATION_DATE")
        @Temporal(TemporalType.TIMESTAMP)
        protected Date modificationDate;
        
        //
        //  getters and setters
        //
        
        public Date getModificationDate() {
                return modificationDate;
        }
        
        public void setModificationDate(Date modificationDate) {
                this.modificationDate = modificationDate;
        }
}