/*
 * ------------------------------------------------------------------------------
 *  COPYRIGHT Ericsson 2008-2010
 * 
 *  The copyright to the computer program(s) herein is the property of
 *  Ericsson Inc. The programs may be used and/or copied only with written
 *  permission from Ericsson Inc. or in accordance with the terms and
 *  conditions stipulated in the agreement/contract under which the
 *  program(s) have been supplied.
 * ------------------------------------------------------------------------------
 */

package hhh7629.dm.entity.mutable;

public enum ActiveStatus {
    DELETED, ACTIVE, INACTIVE, WAIT, INITIAL, DELETABLE
}
