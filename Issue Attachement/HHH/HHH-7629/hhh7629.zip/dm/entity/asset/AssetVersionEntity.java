/*------------------------------------------------------------------------------
 * COPYRIGHT Ericsson 2008-2010
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *----------------------------------------------------------------------------*/

package hhh7629.dm.entity.asset;

import hhh7629.dm.entity.mutable.VersionEntity;
import hhh7629.dm.entity.packageasset.PackageAssetVersionEntity;
import hhh7629.dm.helper.DmHelper;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name = "IAP_CA_CS_ASSET_VER")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "ASSET_TYPE", discriminatorType = DiscriminatorType.STRING, length = 10)
public abstract class AssetVersionEntity extends VersionEntity {
    /**
         * 
         */
    private static final long serialVersionUID = 5564958520006065197L;

    @JoinTable(name = "IAP_CA_CS_PACKAGE_ASSET_ASSOC", joinColumns = { @JoinColumn(name = "ASSET_VER_ID", referencedColumnName = "ID") }, inverseJoinColumns = { @JoinColumn(name = "PACKAGE_ASSET_VER_ID", referencedColumnName = "ID") })
    @ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.MERGE, CascadeType.REFRESH })
    private Set<PackageAssetVersionEntity> packageAssetVersions;

    public Set<PackageAssetVersionEntity> getPackageAssetVersions() {
        return DmHelper.resolveEntity(packageAssetVersions);
    }

    public void setPackageAssetVersions(Set<PackageAssetVersionEntity> packageAssetVersions) {
        this.packageAssetVersions = packageAssetVersions;
    }

}
