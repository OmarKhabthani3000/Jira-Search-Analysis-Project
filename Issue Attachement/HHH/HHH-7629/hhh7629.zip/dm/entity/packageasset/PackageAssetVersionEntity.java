/*------------------------------------------------------------------------------
 * COPYRIGHT Ericsson 2008-2010
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *----------------------------------------------------------------------------*/

package hhh7629.dm.entity.packageasset;

import hhh7629.dm.entity.asset.AssetVersionEntity;
import hhh7629.dm.helper.DmHelper;

import java.util.Collection;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name = "IAP_CA_CS_PACKAGE_ASSET_VER")
@DiscriminatorValue("PACKAGE")
public class PackageAssetVersionEntity extends AssetVersionEntity {
    /**
         *
         */
    private static final long serialVersionUID = 3901357611147407943L;

    @JoinTable(name = "IAP_CA_CS_PACKAGE_ASSET_ASSOC", joinColumns = { @JoinColumn(name = "PACKAGE_ASSET_VER_ID", referencedColumnName = "ID") }, inverseJoinColumns = { @JoinColumn(name = "ASSET_VER_ID", referencedColumnName = "ID") })
    @ManyToMany(fetch = FetchType.LAZY)
    private Collection<AssetVersionEntity> assetVersions;

    @Column(name = "STREAM_TYPES")
    private String streamTypes;

    public Collection<AssetVersionEntity> getAssetVersions() {
        DmHelper.resolveEntity(assetVersions);
        return assetVersions;
    }

    public void setAssetVersions(Set<AssetVersionEntity> assetVersions) {
        this.assetVersions = assetVersions;
    }

    public String getStreamType() {
        return streamTypes;
    }

    public void setStreamType(String streamTypes) {
        this.streamTypes = streamTypes;
    }

    @Override
    public String getEntityName() {
        return "PACKAGE VERSION(id=" + getId() + "):" + "[" + getVersionNumber()
                + "]";
    }

}
