/*------------------------------------------------------------------------------
 * COPYRIGHT Ericsson 2008-2010
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *----------------------------------------------------------------------------*/

package hhh7629.dm.entity.base;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@MappedSuperclass
public abstract class Entity implements Serializable {

    /**
         * 
         */
    private static final long serialVersionUID = 2076196173565611104L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "sequence")
    @Column(name = "ID")
    @SequenceGenerator(name = "sequence", sequenceName = "IAP_CA_CS_SEQ", allocationSize = 1000)
    protected long id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isSameEntity(Entity entity) {
        return (id > 0) && (entity != null) && (id == entity.getId());
    }

    public String getEntityIdentifier() {
        return "[" + getClass().getName() + " id=" + String.valueOf(id) + "]";
    }

    static protected final int USER_NAME_LENGTH = 32;

    //
    //  for identification
    //

    public abstract String getEntityName();

    //
    //  for tracking
    //

    @Column(name = "CREATION_DATE", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    protected Date creationDate = new Date();

    //
    //  getters and setters
    //

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }
}
