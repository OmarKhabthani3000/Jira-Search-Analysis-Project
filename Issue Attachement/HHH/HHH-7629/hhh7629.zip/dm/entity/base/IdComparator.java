/*------------------------------------------------------------------------------
 * COPYRIGHT Ericsson 2008-2010
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *----------------------------------------------------------------------------*/

package hhh7629.dm.entity.base;

import java.io.Serializable;
import java.util.Comparator;

public class IdComparator<T extends Entity> implements Comparator<T>, Serializable
{
        
        
        /**
         * 
         */
        private static final long serialVersionUID = 2481989768403814692L;

        public int compare(T t1, T t2)
        {
                if (t1 == null) {
                        if (t2 == null) {
                                return 0;
                        }
                        return -1;
                }
                
                if (t2 == null) {
                        return 1;
                }
                
                long id1 = t1.getId();
                long id2 = t2.getId();
                
                if (id1 < id2) {
                        return -1;
                }
                
                if (id1 > id2) {
                        return 1;
                }
                
                return 0;
        }

        @Override
        public boolean equals(Object obj)
        {
                return this == obj;
        }
}
