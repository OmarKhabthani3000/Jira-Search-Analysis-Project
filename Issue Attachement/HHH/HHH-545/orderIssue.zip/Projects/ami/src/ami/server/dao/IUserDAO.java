package ami.server.dao;

import java.util.*;

import ami.server.dto.*;

public interface IUserDAO {

  public void add(UserDTO obj) throws Exception;

  public void delete(UserDTO obj) throws Exception;

  public void update(UserDTO obj) throws Exception;

  public UserDTO load(Integer id) throws Exception;

  public List<UserDTO> find(UserDTO obj) throws Exception;
}
