package ami.server.dto;

import java.io.*;

public class SongDTO extends BaseDTO {

  private AlbumDTO album = null;
  private String title = null;
  private Integer trackNumber = null;
  private ArtistDTO artist = null;

  public SongDTO() {
    super();
  }

  public AlbumDTO getAlbum() {
    return album;
  }

  public String getTitle() {
    return title;
  }

  public ArtistDTO getArtist() {
    return artist;
  }

  public Integer getTrackNumber() {
    return trackNumber;
  }

  public void setAlbum(AlbumDTO album) {
    this.album = album;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public void setArtist(ArtistDTO artist) {
    this.artist = artist;
  }

  public void setTrackNumber(Integer trackNumber) {
    this.trackNumber = trackNumber;
  }
}
