package ami.server.dao;

import java.util.*;

import ami.server.dto.*;

public interface IGenreDAO {

  public void add(GenreDTO obj) throws Exception;

  public void delete(GenreDTO obj) throws Exception;

  public void update(GenreDTO obj) throws Exception;

  public GenreDTO load(Integer id) throws Exception;

  public List<GenreDTO> find(GenreDTO obj) throws Exception;
}
