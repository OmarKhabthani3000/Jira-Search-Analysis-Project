package ami.server.dao;

import java.util.*;

import ami.server.dto.*;

public interface IAlbumDAO {

  public void add (AlbumDTO obj) throws Exception;

  public void delete (AlbumDTO obj) throws Exception;

  public void update (AlbumDTO obj) throws Exception;

  public AlbumDTO load (Integer id) throws Exception;

  public List<AlbumDTO> find (AlbumDTO obj) throws Exception;
}
