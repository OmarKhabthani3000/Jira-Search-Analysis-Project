package ami.server.dto;

import java.util.*;

public class SongListDTO extends BaseDTO {

  private String name = null;
  private String description = null;
  private String imageFileUrl = null;
  private List<SongDTO> songs = null;

  public SongListDTO() {
    super();
    songs = new ArrayList();
  }

  public String getDescription() {
    return description;
  }

  public String getImageFileUrl() {
    return imageFileUrl;
  }

  public String getName() {
    return name;
  }

  public List getSongs() {
    return songs;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setImageFileUrl(String imageFileUrl) {
    this.imageFileUrl = imageFileUrl;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setSongs(List songs) {
    this.songs = songs;
  }
}
