package ami.server.dao.hibernate;

import java.util.*;

import org.hibernate.*;
import org.hibernate.criterion.*;

import ami.server.dao.*;
import ami.server.dto.*;

public class ArtistDAO implements IArtistDAO {

  public ArtistDAO() {
  }

  /**
   * add
   *
   * @param obj ArtistDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IArtistDAO method
   */
  public void add(ArtistDTO obj) throws Exception {
    HibernateUtil.getSession().saveOrUpdate(obj);
  }

  /**
   * delete
   *
   * @param obj ArtistDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IArtistDAO method
   */
  public void delete(ArtistDTO obj) throws Exception {
    HibernateUtil.getSession().delete(obj);
  }

  /**
   * update
   *
   * @param obj ArtistDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IArtistDAO method
   */
  public void update(ArtistDTO obj) throws Exception {
    HibernateUtil.getSession().update(obj);
  }

  /**
   * load
   *
   * @param id Integer
   * @return ArtistDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IArtistDAO method
   */
  public ArtistDTO load(Integer id) throws Exception {
    return (ArtistDTO) HibernateUtil.getSession().load(ArtistDTO.class, id);
  }

  /**
   * find
   *
   * @param obj ArtistDTO
   * @return List
   * @throws Exception
   * @todo Implement this ami.server.dao.IArtistDAO method
   */
  public List<ArtistDTO> find(ArtistDTO obj) throws Exception {
    Criteria criteria = HibernateUtil.getSession().createCriteria(ArtistDTO.class);
    criteria.add(Example.create(obj));

    return criteria.list();
  }

  public List<ArtistDTO> findOrderBy (ArtistDTO obj, Order[] orderBy) throws Exception {
    Criteria criteria = HibernateUtil.getSession().createCriteria(ArtistDTO.class);
    criteria.add(Example.create(obj));

    for (int i=0; i<orderBy.length; i++) {
      criteria.addOrder(orderBy[i]);
    }

    return criteria.list();
  }
}
