package ami.server.dao.hibernate;

import java.util.*;

import org.hibernate.*;
import org.hibernate.criterion.*;

import ami.server.dao.*;
import ami.server.dto.*;

public class UserDAO implements IUserDAO {

  public UserDAO() {
  }

  /**
   * add
   *
   * @param obj UserDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IUserDAO method
   */
  public void add(UserDTO obj) throws Exception {
    HibernateUtil.getSession().saveOrUpdate(obj);
  }

  /**
   * delete
   *
   * @param obj UserDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IUserDAO method
   */
  public void delete(UserDTO obj) throws Exception {
    HibernateUtil.getSession().delete(obj);
  }

  /**
   * update
   *
   * @param obj UserDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IUserDAO method
   */
  public void update(UserDTO obj) throws Exception {
    HibernateUtil.getSession().update(obj);
  }

  /**
   * load
   *
   * @param id Integer
   * @return UserDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IUserDAO method
   */
  public UserDTO load(Integer id) throws Exception {
    return (UserDTO) HibernateUtil.getSession().load(UserDTO.class, id);
  }

  /**
   * find
   *
   * @param obj UserDTO
   * @return List
   * @throws Exception
   * @todo Implement this ami.server.dao.IUserDAO method
   */
  public List<UserDTO> find(UserDTO obj) throws Exception {
    Criteria criteria = HibernateUtil.getSession().createCriteria(UserDTO.class);
    criteria.add(Example.create(obj));

    return criteria.list();
  }

  public List<UserDTO> findOrderBy (UserDTO obj, Order[] orderBy) throws Exception {
    Criteria criteria = HibernateUtil.getSession().createCriteria(UserDTO.class);
    criteria.add(Example.create(obj));

    for (int i=0; i<orderBy.length; i++) {
      criteria.addOrder(orderBy[i]);
    }

    return criteria.list();
  }
}
