package ami.server.dao.hibernate;

import java.util.*;

import org.hibernate.*;
import org.hibernate.criterion.*;

import ami.server.dao.*;
import ami.server.dto.*;

public class SongDAO implements ISongDAO {

  public SongDAO() {
  }

  /**
   * add
   *
   * @param obj SongDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.ISongDAO method
   */
  public void add(SongDTO obj) throws Exception {
    HibernateUtil.getSession().saveOrUpdate(obj);
  }

  /**
   * delete
   *
   * @param obj SongDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.ISongDAO method
   */
  public void delete(SongDTO obj) throws Exception {
    HibernateUtil.getSession().delete(obj);
  }

  /**
   * update
   *
   * @param obj SongDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.ISongDAO method
   */
  public void update(SongDTO obj) throws Exception {
    HibernateUtil.getSession().update(obj);
  }

  /**
   * load
   *
   * @param id Integer
   * @return SongDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.ISongDAO method
   */
  public SongDTO load(Integer id) throws Exception {
    return (SongDTO) HibernateUtil.getSession().load(SongDTO.class, id);
  }

  /**
   * find
   *
   * @param obj SongDTO
   * @return List
   * @throws Exception
   * @todo Implement this ami.server.dao.ISongDAO method
   */
  public List<SongDTO> find(SongDTO obj) throws Exception {
    Criteria criteria = HibernateUtil.getSession().createCriteria(SongDTO.class);
    criteria.add(Example.create(obj));

    return criteria.list();
  }

  public List<SongDTO> findOrderBy (SongDTO obj, Order[] orderBy) throws Exception {
    Criteria criteria = HibernateUtil.getSession().createCriteria(SongDTO.class);
    criteria.add(Example.create(obj));

    for (int i=0; i<orderBy.length; i++) {
      criteria.addOrder(orderBy[i]);
    }

    return criteria.list();
  }
}
