package ami.server.dao;

import java.util.*;

import ami.server.dto.*;

public interface IArtistDAO {

  public void add (ArtistDTO obj) throws Exception;

  public void delete (ArtistDTO obj) throws Exception;

  public void update (ArtistDTO obj) throws Exception;

  public ArtistDTO load (Integer id) throws Exception;

  public List<ArtistDTO> find (ArtistDTO obj) throws Exception;
}
