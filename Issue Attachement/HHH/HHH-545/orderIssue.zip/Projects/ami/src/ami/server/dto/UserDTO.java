package ami.server.dto;

import java.util.*;

public class UserDTO extends BaseDTO {

  private String username = null;
  private String password = null;
  private Date lastLoginDate = null;
  private List<RoleDTO> roles = null;

  public UserDTO() {
    super();
    roles = new ArrayList();
  }

  public String getPassword() {
    return password;
  }

  public String getUsername() {
    return username;
  }

  public List<RoleDTO> getRoles() {
    return roles;
  }

  public Date getLastLoginDate() {
    return lastLoginDate;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public void setRoles(List<RoleDTO> roles) {
    this.roles = roles;
  }

  public void setLastLoginDate(Date lastLoginDate) {
    this.lastLoginDate = lastLoginDate;
  }
}
