package ami.server.dao.hibernate;

import java.util.*;

import org.hibernate.*;
import org.hibernate.criterion.*;

import ami.server.dao.*;
import ami.server.dto.*;

public class GenreDAO implements IGenreDAO {

  public GenreDAO() {
  }

  /**
   * add
   *
   * @param obj GenreDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IGenreDAO method
   */
  public void add(GenreDTO obj) throws Exception {
    HibernateUtil.getSession().saveOrUpdate(obj);
  }

  /**
   * delete
   *
   * @param obj GenreDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IGenreDAO method
   */
  public void delete(GenreDTO obj) throws Exception {
    HibernateUtil.getSession().delete(obj);
  }

  /**
   * update
   *
   * @param obj GenreDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IGenreDAO method
   */
  public void update(GenreDTO obj) throws Exception {
    HibernateUtil.getSession().update(obj);
  }

  /**
   * load
   *
   * @param id Integer
   * @return GenreDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IGenreDAO method
   */
  public GenreDTO load(Integer id) throws Exception {
    return (GenreDTO) HibernateUtil.getSession().load(GenreDTO.class, id);
  }

  /**
   * find
   *
   * @param obj GenreDTO
   * @return List
   * @throws Exception
   * @todo Implement this ami.server.dao.IGenreDAO method
   */
  public List<GenreDTO> find(GenreDTO obj) throws Exception {
    Criteria criteria = HibernateUtil.getSession().createCriteria(GenreDTO.class);
    criteria.add(Example.create(obj));

    return criteria.list();
  }

  public List<GenreDTO> findOrderBy (GenreDTO obj, Order[] orderBy) throws Exception {
    Criteria criteria = HibernateUtil.getSession().createCriteria(GenreDTO.class);
    criteria.add(Example.create(obj));

    for (int i=0; i<orderBy.length; i++) {
      criteria.addOrder(orderBy[i]);
    }

    return criteria.list();
  }

}
