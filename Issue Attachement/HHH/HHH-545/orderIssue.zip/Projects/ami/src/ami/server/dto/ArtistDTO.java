package ami.server.dto;

import java.io.*;

public class ArtistDTO extends BaseDTO {

  private String name = null;
  private String searchName = null;

  public ArtistDTO() {
    super();
  }

  public String getName() {
    return name;
  }

  public String getSearchName() {
    return searchName;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setSearchName(String searchName) {
    this.searchName = searchName;
  }
}
