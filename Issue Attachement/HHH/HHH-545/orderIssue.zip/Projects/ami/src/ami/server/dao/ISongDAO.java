package ami.server.dao;

import java.util.*;

import ami.server.dto.*;

public interface ISongDAO {

  public void add (SongDTO obj) throws Exception;

  public void delete (SongDTO obj) throws Exception;

  public void update (SongDTO obj) throws Exception;

  public SongDTO load (Integer id) throws Exception;

  public List<SongDTO> find (SongDTO obj) throws Exception;
}
