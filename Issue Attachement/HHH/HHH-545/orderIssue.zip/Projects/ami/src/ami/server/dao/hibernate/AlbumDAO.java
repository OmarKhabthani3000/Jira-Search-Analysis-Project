package ami.server.dao.hibernate;

import java.util.*;

import org.hibernate.*;
import org.hibernate.criterion.*;

import ami.server.dao.*;
import ami.server.dto.*;


public class AlbumDAO implements IAlbumDAO {

  public AlbumDAO() {
  }

  /**
   * add
   *
   * @param obj AlbumDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IAlbumDAO method
   */
  public void add(AlbumDTO obj) throws Exception {
    HibernateUtil.getSession().saveOrUpdate(obj);
  }

  /**
   * delete
   *
   * @param obj AlbumDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IAlbumDAO method
   */
  public void delete(AlbumDTO obj) throws Exception {
    HibernateUtil.getSession().delete(obj);
  }

  /**
   * update
   *
   * @param obj AlbumDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IAlbumDAO method
   */
  public void update(AlbumDTO obj) throws Exception {
    HibernateUtil.getSession().update(obj);
  }

  /**
   * load
   *
   * @param id Integer
   * @return AlbumDTO
   * @throws Exception
   * @todo Implement this ami.server.dao.IAlbumDAO method
   */
  public AlbumDTO load(Integer id) throws Exception {
    return (AlbumDTO) HibernateUtil.getSession().load(AlbumDTO.class, id);
  }

  /**
   * find
   *
   * @param obj AlbumDTO
   * @return List
   * @throws Exception
   * @todo Implement this ami.server.dao.IAlbumDAO method
   */
  public List<AlbumDTO> find(AlbumDTO obj) throws Exception {
    Criteria criteria = HibernateUtil.getSession().createCriteria(AlbumDTO.class);
    criteria.add(Example.create(obj));

    return criteria.list();
  }

  public List<AlbumDTO> findOrderBy (AlbumDTO obj, Order[] orderBy) throws Exception {

    Criteria criteria = HibernateUtil.getSession().createCriteria(AlbumDTO.class);
    criteria.add(Example.create(obj));

    for (int i=0; i<orderBy.length; i++) {
      criteria.addOrder(orderBy[i]);
    }

    return criteria.list();
  }
}
