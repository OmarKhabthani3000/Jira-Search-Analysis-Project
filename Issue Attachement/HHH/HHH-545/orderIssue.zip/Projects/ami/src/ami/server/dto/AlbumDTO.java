package ami.server.dto;

import java.io.*;
import java.util.*;

public class AlbumDTO extends BaseDTO {

  private String title = null;
  private String upc = null;
  private List<SongDTO> songs = null;
  private ArtistDTO artist = null;
  private List<GenreDTO> genres = null;

  public AlbumDTO() {
    super();
    songs = new ArrayList();
    genres = new ArrayList();
  }

  public List<SongDTO> getSongs() {
    return songs;
  }

  public String getTitle() {
    return title;
  }

  public String getUpc() {
    return upc;
  }

  public ArtistDTO getArtist() {
    return artist;
  }

  public List<GenreDTO> getGenres() {
    return genres;
  }

  public void setSongs(List<SongDTO> songs) {
    this.songs = songs;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public void setUpc(String upc) {
    this.upc = upc;
  }

  public void setArtist(ArtistDTO artist) {
    this.artist = artist;
  }

  public void setGenres(List<GenreDTO> genres) {
    this.genres = genres;
  }

  public void addSong(SongDTO song) {
    songs.add(song);
  }

  public void removeSong(SongDTO song) {
    songs.remove(song);
  }
}
