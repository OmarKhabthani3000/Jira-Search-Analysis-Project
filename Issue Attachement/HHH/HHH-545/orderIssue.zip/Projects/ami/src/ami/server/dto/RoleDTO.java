package ami.server.dto;

import java.io.*;
import java.util.*;

public class RoleDTO extends BaseDTO {

  private String name = null;
  private String description = null;
  private List<UserDTO> users = null;

  public RoleDTO() {
    super();
    users = new ArrayList();
  }

  public String getName() {
    return name;
  }

  public String getDescription() {
    return description;
  }

  public List<UserDTO> getUsers() {
    return users;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setUsers(List<UserDTO> users) {
    this.users = users;
  }
}
