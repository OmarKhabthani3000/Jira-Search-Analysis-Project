package ami.server.dao;

import java.util.*;

import ami.server.dto.*;

public interface IRoleDAO {

  public void add(RoleDTO obj) throws Exception;

  public void delete(RoleDTO obj) throws Exception;

  public void update(RoleDTO obj) throws Exception;

  public RoleDTO load(Integer id) throws Exception;

  public List<RoleDTO> find(RoleDTO obj) throws Exception;
}
