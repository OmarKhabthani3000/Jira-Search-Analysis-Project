package ami.server.dto;

import java.io.*;

public class GenreDTO extends BaseDTO {

  private String name = null;
  private String description = null;
  private String imageFileUrl = null;

  public GenreDTO() {
    super();
  }

  public String getDescription() {
    return description;
  }

  public String getImageFileUrl() {
    return imageFileUrl;
  }

  public String getName() {
    return name;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setImageFileUrl(String imageFileUrl) {
    this.imageFileUrl = imageFileUrl;
  }

  public void setName(String name) {
    this.name = name;
  }
}
