package com.example.demo;

import java.util.*;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import jakarta.persistence.*;

@SpringBootApplication
public class DemoApplication {
  public static void main(String[] args) {
    SpringApplication.run(DemoApplication.class, args);
  }
}

@Repository
interface DemoRepository extends JpaRepository<DemoEntity, UUID> {
  @EntityGraph(attributePaths = {"sublistEmbeddables"})
  DemoEntity findWithSublistEmbeddablesByUuid(UUID uuid);
}

@Embeddable
class DemoEmbeddable {
  @Column
  private String content;
  public String getContent() {return content;}
  public void setContent(String content) {this.content = content;}

  @Override
  public String toString() {
    return "DemoEmbeddable(" + content + ")";
  }
}

@Entity
class DemoEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private UUID uuid;

  @ElementCollection
  @CollectionTable
  private List<DemoEmbeddable> sublistEmbeddables;

  public UUID getUuid() { return uuid; }
  public void setUuid(UUID uuid) { this.uuid = uuid; }
  public List<DemoEmbeddable> getSublistEmbeddables() { return sublistEmbeddables; }
  public void setSublistEmbeddables(List<DemoEmbeddable> sublistEmbeddables) { this.sublistEmbeddables = sublistEmbeddables; }

  @Override
  public String toString() {
    return "DemoEntity [uuid=" + uuid + ",\n sublistEmbeddables=" + sublistEmbeddables;
  }
}
