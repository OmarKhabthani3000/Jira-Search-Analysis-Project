package com.example.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class DemoApplicationTests {
  
    @Autowired DemoRepository repository;
    @Autowired TestEntityManager testEntityManager;
    
    private static final String CONTENT = "demo1";
    
    DemoEntity entity;
    
    void assertDataLoaded(DemoEntity fetchedEntity) {
    assertNotSame(entity, fetchedEntity, "should have been refetched");
    DemoEmbeddable fetchedEmbeddable = fetchedEntity.getSublistEmbeddables().get(0);
    assertNotNull(fetchedEmbeddable);
    assertEquals(CONTENT, fetchedEmbeddable.getContent());
  }
    
  @Test
  void eagerFetchublistEmbeddable() {
    
    entity = new DemoEntity();
    DemoEmbeddable embeddable = new DemoEmbeddable();
    embeddable.setContent("demo1");
    entity.setSublistEmbeddables(List.of(embeddable));
    System.out.println("Saving " + entity);
    repository.save(entity);
    System.out.println("Saved uuid=" + entity.getUuid() + ", will flush");
    testEntityManager.flush();
    System.out.println("Flushed, will clear");
    testEntityManager.clear();
    System.out.println("cleared");
    
    System.out.println("Fetch entity directly with embeddable sublist");
    DemoEntity fetchedEntityDirect = repository.findWithSublistEmbeddablesByUuid(entity.getUuid());
    System.out.println("Eager fetched sublist: " + fetchedEntityDirect);
    assertDataLoaded(fetchedEntityDirect);
    
    System.out.println("clear");
    testEntityManager.clear();
    System.out.println("cleared");

    System.out.println("PreFetch entity without relations");
    DemoEntity fetchedEntityPrefetch = repository.findById(entity.getUuid()).get();
    System.out.println("Fetch entity with embeddable sublist");
    repository.findWithSublistEmbeddablesByUuid(entity.getUuid());
    System.out.println("Eager fetched sublist: " + fetchedEntityPrefetch);
    assertDataLoaded(fetchedEntityPrefetch);
  }
}
