package tutorial;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class CisExtArelation {
	@Id
	@GeneratedValue
	private Long	id;
	
	private String totoC;
	
	

	public String getTotoC() {
		return totoC;
	}

	public void setTotoC(String totoC) {
		this.totoC = totoC;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getId() {
		return id;
	}

	

}
