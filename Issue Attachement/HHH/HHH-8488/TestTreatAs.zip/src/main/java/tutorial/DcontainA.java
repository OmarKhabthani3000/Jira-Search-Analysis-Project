package tutorial;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class DcontainA {
	@Id
	@GeneratedValue
	private Long	id;

	public void setId(long id) {
		this.id = id;
	}

	public long getId() {
		return id;
	}

	@ManyToOne
	private A a;

	public A getA() {
		return a;
	}

	public void setA(A a) {
		this.a = a;
	}
	
	
	

}
