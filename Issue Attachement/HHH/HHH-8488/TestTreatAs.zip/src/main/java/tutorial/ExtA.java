package tutorial;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class ExtA extends A{

	@ManyToOne
	private CisExtArelation c;

	public CisExtArelation getC() {
		return c;
	}

	public void setC(CisExtArelation c) {
		this.c = c;
	}
	
	

}
