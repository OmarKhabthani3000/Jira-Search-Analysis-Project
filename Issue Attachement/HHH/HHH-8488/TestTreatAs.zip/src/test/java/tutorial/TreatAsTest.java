package tutorial;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import org.junit.Ignore;
import org.junit.Test;

public class TreatAsTest extends AbstractIT {

	/**
	 * DcontainA has a @ManyToOne relation with A<br>
	 * <br>
	 * A exists to extended<br>
	 * <br>
	 * ExtA extends A<br>
	 * <br>
	 * ExtA has a @ManyToOne relation with CisExtArelation<br>
	 * <br>
	 * CisExtArelation has totoC attribute<br>
	 * <br>
	 * <br>
	 * This test try to get all D :<br>
	 * - in relation with a A<br>
	 * - being a ExtA<br>
	 * - having a relation with a CisExtArelation<br>
	 * - having an attribute totoC="plop"<br>
	 * <br>
	 */

	@Test
	public void testTreatAsExtA() {

		// Get entityManager
		EntityManager em = Persistence.createEntityManagerFactory("tutorialPU").createEntityManager();

		// Get CriteriaBuilder
		CriteriaBuilder cb = em.getCriteriaBuilder();

		// Create query returing "DcontainA"
		CriteriaQuery<DcontainA> critD = cb.createQuery(DcontainA.class);

		// From DcontainA
		Root<DcontainA> rootD = critD.from(DcontainA.class);

		// Select DcontainA
		critD.select(rootD);

		// having a "a" relation
		Join<DcontainA, A> dJoinToA = rootD.join("a");

		// referencing a ExtA
		Join<DcontainA, ExtA> dJoinToExtA = cb.treat(dJoinToA, ExtA.class);

		// Having a "C" in "c" relation
		Join<ExtA, CisExtArelation> extAJoinC = dJoinToExtA.join("c");

		// where c.totoC = "plop"
		critD.where(cb.equal(extAJoinC.get("totoC"), "plop"));

		// /!\ POUF /!\
		em.createQuery(critD).getResultList();

		//
		// java.lang.IllegalArgumentException:
		// org.hibernate.hql.internal.ast.QuerySyntaxException:
		// Invalid path: 'generatedAlias2.totoC'

		// [select generatedAlias0
		// from tutorial.DcontainA as generatedAlias0
		// inner join generatedAlias0.a as generatedAlias1
		// where generatedAlias2.totoC=:param0]

		// Caused by:
		// org.hibernate.hql.internal.ast.QuerySyntaxException:
		// Invalid path: 'generatedAlias2.totoC'
		// [select generatedAlias0
		// from tutorial.DcontainA as generatedAlias0
		// inner join generatedAlias0.a as
		// generatedAlias1
		// where generatedAlias2.totoC=:param0]
		// at org.hibernate.hql
		// .internal.ast.QuerySyntaxException.convert(QuerySyntaxException
		// .java:74)
		//

	}

	@Test
	@Ignore
	public void testExtAWhereCisPlop() {

		// Get entityManager
		EntityManager em = Persistence.createEntityManagerFactory("tutorialPU").createEntityManager();

		// Get CriteriaBuilder
		CriteriaBuilder cb = em.getCriteriaBuilder();

		// Create query returing "DcontainA"
		CriteriaQuery<ExtA> critExtA = cb.createQuery(ExtA.class);

		// From DcontainA
		Root<ExtA> rootExtA = critExtA.from(ExtA.class);

		// Select DcontainA
		critExtA.select(rootExtA);

		// Having a "C" in "c" relation
		Join<ExtA, CisExtArelation> extAJoinC = rootExtA.join("c");

		// where c.totoC = "plop"
		critExtA.where(cb.equal(extAJoinC.get("totoC"), "plop"));

		// /!\ POUF /!\
		em.createQuery(critExtA).getResultList();

	}
}
