package org.hibernate.bugs;

import static org.junit.Assert.fail;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestBug {

    private EntityManager em;

    @Before
    public void setup() {

        em = Persistence.createEntityManagerFactory("test").createEntityManager();
    }

    @After
    public void teardown() {
        em.close();
    }
    
    /*
     * This works.
     * Generated SQL:
     * select 
     * 	myentity0_.id as col_0_0_, 
     * 	embeddedma2_.embeddedMap as col_1_0_ 
     * from MyEntity myentity0_ 
     * 	inner join MyEntityParent myentitypa1_ on myentity0_.parent_id=myentitypa1_.id 
     * left outer join MyEntityParent_embeddedMap embeddedma2_ on myentitypa1_.id=embeddedma2_.MyEntityParent_id and (embeddedma2_.embeddedMap_KEY='key');
     */
    @Test
    public void testQuery() {
    	String qString = 
    			"select e.id, VALUE(map) " +
    			"from MyEntity e join e.parent p " +
    			"left join p.embeddedMap map on KEY(map) = 'key'";
    	Query query = em.createQuery(qString);
    	List<?> result = query.getResultList();
    }
    
    /*
     * This fails
     * 
     * generated SQL:
     * select 	
     * 	myentity0_.id as col_0_0_, 
     * 	embeddedma2_.embeddedMap as col_1_0_ 
     * from MyEntity myentity0_ 
     * left outer join MyEntityParent myentitypa1_ on myentity0_.parent_id=myentitypa1_.id and (embeddedma2_.embeddedMap_KEY='key2') 
     * left outer join MyEntityParent_embeddedMap embeddedma2_ on myentitypa1_.id=embeddedma2_.MyEntityParent_id
     * 
     */
    @Test
    public void testQuery2() {
    	String qString = 
    			"select e.id, VALUE(map) " +
    			"from MyEntity e " +
    			"left join e.parent.embeddedMap map on KEY(map) = 'key'";
    	Query query = em.createQuery(qString);
    	List<?> result = query.getResultList();
    }
    
    
    
    

}
