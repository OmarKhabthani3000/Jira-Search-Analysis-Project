package org.hibernate.bugs.model;

import java.util.Map;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class MyEntity {

    @Id
    @GeneratedValue
    private Long id;
    
    private String name;

    @ElementCollection
    private Map<String, String> embeddedMap;
    
    @ManyToOne
    private MyEntityParent parent;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Map<String, String> getEmbeddedMap() {
		return embeddedMap;
	}

	public void setEmbeddedMap(Map<String, String> embeddedMap) {
		this.embeddedMap = embeddedMap;
	}

	public MyEntityParent getParent() {
		return parent;
	}

	public void setParent(MyEntityParent parent) {
		this.parent = parent;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
  
}
