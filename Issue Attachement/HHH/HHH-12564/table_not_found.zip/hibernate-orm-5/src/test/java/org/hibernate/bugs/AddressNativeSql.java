package org.hibernate.bugs;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Immutable;

@Entity
@Immutable
public class AddressNativeSql implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private String id;
	
	@Column(name="STREET")
	private String street;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof AddressNativeSql){
			return id.equals(((AddressNativeSql) obj).id);
		}
		return false;
	}
	
	@Override
	public int hashCode() {	
		return id.hashCode();
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString() + ", id:" +id + ",street:" +street;
	}

}
