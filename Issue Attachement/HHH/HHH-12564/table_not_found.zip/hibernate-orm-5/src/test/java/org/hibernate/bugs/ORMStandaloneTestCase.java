package org.hibernate.bugs;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.engine.jdbc.connections.spi.JdbcConnectionAccess;
import org.hibernate.internal.SessionFactoryImpl;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a standalone test case for Hibernate ORM.  Although this is perfectly
 * acceptable as a reproducer, usage of ORMUnitTestCase is preferred!
 */
public class ORMStandaloneTestCase {

	private SessionFactoryImpl sf;

	@Before
	public void setup() {
		StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
				// Add in any settings that are specific to your test. See resources/hibernate.properties for the defaults.
				.applySetting("hibernate.jdbc.fetch_size", "102")
				.applySetting("hibernate.generate_statistics", "true")
				.applySetting("hibernate.use_sql_comments", "false" )
				.applySetting("hibernate.cache.use_second_level_cache", "true")
				.applySetting("hibernate.cache.region.factory_class", "org.hibernate.cache.ehcache.EhCacheRegionFactory" )
				.applySetting("net.sf.ehcache.configurationResourceName", "META-INF/HibernateEHCache.xml")
				.applySetting("hibernate.cache.use_query_cache", "true")
				.applySetting("hibernate.hbm2ddl.auto", "none" )
				.applySetting("hibernate.batch_fetch_style", "padded" )

				.applySetting( "hibernate.show_sql", "true" );



		Metadata metadata = new MetadataSources( srb.build() )
				// Add your entities here.
					.addAnnotatedClass(org.hibernate.bugs.AddressNativeSql.class )
				.buildMetadata();

		sf = (SessionFactoryImpl) metadata.buildSessionFactory();

		JdbcConnectionAccess connectionAccess = sf.getJdbcServices().getBootstrapJdbcConnectionAccess();
		Connection connection;
		try {
			connection = connectionAccess.obtainConnection();

			connection.setAutoCommit(true);
			Statement stmt = connection.createStatement();

			stmt.execute("create table ADDRESS_TEST (ID VARCHAR2(15),STREET VARCHAR2(15))");
			stmt.execute("insert into ADDRESS_TEST (ID ,STREET ) VALUES('1', 'test1' ) ");
			stmt.execute("insert into ADDRESS_TEST (ID ,STREET ) VALUES('2', 'test2' )");
			stmt.execute("insert into ADDRESS_TEST (ID ,STREET ) VALUES('3', 'test3' )");
			stmt.execute("insert into ADDRESS_TEST (ID ,STREET ) VALUES('4', 'test4' )");
			stmt.execute("insert into ADDRESS_TEST (ID ,STREET ) VALUES('5', 'test5' )");
			stmt.execute("insert into ADDRESS_TEST (ID ,STREET ) VALUES('6', 'test6' )");
			stmt.execute("insert into ADDRESS_TEST (ID ,STREET ) VALUES('7', 'test7' )");
			stmt.execute("insert into ADDRESS_TEST (ID ,STREET ) VALUES('8', 'test8' )");
			stmt.close();
			connection.commit();
			connection.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = sf.createEntityManager();

		Query nativeQuery = entityManager.createNativeQuery("SELECT A.ID, A.STREET FROM ADDRESS_TEST A WHERE ID=:setmetoone",org.hibernate.bugs.AddressNativeSql.class);
		nativeQuery.setParameter("setmetoone", 1);
		nativeQuery.setHint("org.hibernate.cacheable", true);
		List list = nativeQuery.getResultList();

		entityManager.clear();//if comment then not reproducible
		
		nativeQuery = entityManager.createNativeQuery("SELECT A.ID, A.STREET FROM ADDRESS_TEST A WHERE ID=:setmetoone",org.hibernate.bugs.AddressNativeSql.class);
		nativeQuery.setParameter("setmetoone", 1);
		nativeQuery.setHint("org.hibernate.cacheable", true);
		list = nativeQuery.getResultList();
	}
}
