package org.example;

import org.example.entity.Group;
import org.example.entity.GroupHolder;
import org.example.entity.Phone;
import org.example.entity.User;
import org.example.entity.UserInfo;
import org.junit.jupiter.api.Test;

import java.util.List;

public class UserDaoTest {

    private final UserDao userDao = new UserDao();

    @Test
    public void test() {
        GroupHolder groupHolder = new GroupHolder();
        Group group = new Group();
        groupHolder.setGroup(group);
        group.setGroupHolder(groupHolder);
        User user = new User();
        user.setName("Joe Black");
        user.setGroup(group);
        UserInfo info = new UserInfo();
        info.setGroup(group);
        info.setUser(user);
        info.setInfo("Test info");
        user.setInfo(info);
        Phone phone = new Phone();
        phone.setNumber("1234567890");
        phone.setInfo(info);
        info.setPhoneList(List.of(phone));
        group.setName("Test");
        group.getUsers().add(user);

        userDao.inTransaction(() -> userDao.save(group));

        userDao.inTransaction(() -> {
            var foundGroupHolder = userDao.findGroupHolderById(groupHolder.getId());
            var foundUser = foundGroupHolder.getGroup().getUsers().get(0);

            System.out.println("Going to refresh");
            userDao.refresh(foundUser.getInfo());
        });
    }
}
