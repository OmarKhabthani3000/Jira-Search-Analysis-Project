package org.example.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import org.hibernate.annotations.BatchSize;

@Entity
@BatchSize(size=5)
public class Phone {
    @Id
    private String number;

    @JoinColumn(name = "INFO_ID")
    @ManyToOne
    private UserInfo info;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public UserInfo getInfo() {
        return info;
    }

    public void setInfo(UserInfo info) {
        this.info = info;
    }
}
