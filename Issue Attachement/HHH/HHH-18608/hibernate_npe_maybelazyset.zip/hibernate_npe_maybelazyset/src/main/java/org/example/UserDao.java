package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Root;
import org.example.entity.GroupHolder;
import org.example.entity.User;
import org.hibernate.Hibernate;

public class UserDao {

    private final EntityManagerFactory emf;

    private EntityManager entityManager;

    public UserDao() {
        emf = Persistence.createEntityManagerFactory("default");
    }

    public void inTransaction(Runnable runnable) {
        try (var em = emf.createEntityManager()) {
            this.entityManager = em;
            runnable.run();
            this.entityManager = null;
        }
    }

    public void save(Object entity) {
        entityManager.getTransaction().begin();
        entityManager.persist(entity);
        entityManager.flush();
        entityManager.clear();
        entityManager.getTransaction().commit();
    }

    public GroupHolder findGroupHolderById(long id) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<GroupHolder> query = criteriaBuilder.createQuery(GroupHolder.class);
        Root<GroupHolder> from = query.from(GroupHolder.class);
        from.fetch("group", JoinType.INNER);
        query.where(criteriaBuilder.equal(from.get("id"), id));
        GroupHolder groupHolder = entityManager.createQuery(query).getSingleResult();
        Hibernate.initialize(groupHolder.getGroup().getUsers());
        return groupHolder;
    }

    public User findByName(String name) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<User> query = criteriaBuilder.createQuery(User.class);
        Root<User> from = query.from(User.class);
        query.where(criteriaBuilder.equal(from.get("name"), name));
        User user = entityManager.createQuery(query).getSingleResult();
        Hibernate.initialize(user.getInfo().getPhoneList());
        Hibernate.initialize(user.getGroup().getUsers());
        return user;
    }

    public void refresh(Object entity) {
        entityManager.refresh(entity);
    }
}