rootProject.name = "hibernate_npe_maybelazyset"

