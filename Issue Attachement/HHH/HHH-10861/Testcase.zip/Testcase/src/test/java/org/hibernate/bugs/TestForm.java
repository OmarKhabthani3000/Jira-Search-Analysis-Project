package org.hibernate.bugs;

public class TestForm {
    private String a;
    private String b;

    public TestForm() {
    }

    public TestForm(String a, String b) {
        this.a = a;
        this.b = b;
    }

    public String getA() {
        return a;
    }

    public void setA(String a) {
        this.a = a;
    }

    public String getB() {
        return b;
    }

    public void setB(String b) {
        this.b = b;
    }
}
