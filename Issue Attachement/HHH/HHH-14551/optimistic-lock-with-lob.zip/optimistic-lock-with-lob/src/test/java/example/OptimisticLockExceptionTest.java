package example;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

import example.model.LobEntity;
import example.service.LobService;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.orm.ObjectOptimisticLockingFailureException;

@SpringBootTest
public class OptimisticLockExceptionTest {

  private final AtomicInteger optimisticLockExceptionCounter = new AtomicInteger(0);

  @Autowired
  private LobService lobService;

  @Test
  public void testIfOptimisticLockExceptionIsThrown() {
    LobEntity lobEntity = lobService.create();

    new Thread(() -> update(lobEntity.getId(), 1)).start();
    new Thread(() -> update(lobEntity.getId(), 0)).start();

    try {
      Thread.sleep(2000);
    } catch (InterruptedException e) {
    }

    assertThat(optimisticLockExceptionCounter.get(), equalTo(1));
  }

  private void update(long id, int waitSeconds) {
    try {
      lobService.update(id, waitSeconds);
    } catch (ObjectOptimisticLockingFailureException e) {
      optimisticLockExceptionCounter.incrementAndGet();
    } catch (Exception e) {
      System.out.println("an eccor occured during update");
      e.printStackTrace();
    }
  }

}
