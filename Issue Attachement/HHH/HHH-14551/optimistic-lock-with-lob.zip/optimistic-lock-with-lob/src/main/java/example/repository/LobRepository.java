package example.repository;

import example.model.LobEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LobRepository extends JpaRepository<LobEntity, Long> {

}
