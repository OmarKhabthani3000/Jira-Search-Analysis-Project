package example.service;

import static java.util.UUID.randomUUID;

import example.model.LobEntity;
import example.repository.LobRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class LobService {

  private final LobRepository lobRepository;

  public LobService(LobRepository lobRepository) {
    this.lobRepository = lobRepository;
  }

  @Transactional
  public LobEntity create() {
    return lobRepository.save(new LobEntity(randomUUID().toString()));
  }

  @Transactional
  public void update(Long id, int waitSeconds) {
    lobRepository.findById(id).ifPresent(lobEntity -> lobEntity.setData(randomUUID().toString()));
    wait(waitSeconds);
  }

  private void wait(int waitSeconds) {
    if (waitSeconds <= 0) {
      return;
    }
    try {
      Thread.sleep(waitSeconds * 1000);
    } catch (InterruptedException e) {
    }
  }
}
