package example.model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Version;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
public class LobEntity implements Serializable {

  private static final String SEQ_GENERATOR = "SEQ_GENERATOR";

  @Id
  @GenericGenerator(name = SEQ_GENERATOR, strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
      parameters = {
          @Parameter(name = "sequence_name", value = "lob_test"),
          @Parameter(name = "increment_size", value = "1")
      })
  @GeneratedValue(generator = SEQ_GENERATOR, strategy = GenerationType.SEQUENCE)
  private Long id;

  @Version
  private long version;

  @Lob
  private String data;

  public LobEntity() {
  }

  public LobEntity(String data) {
    this.data = data;
  }

  public void setData(String data) {
    this.data = data;
  }

  public Long getId() {
    return id;
  }
}
