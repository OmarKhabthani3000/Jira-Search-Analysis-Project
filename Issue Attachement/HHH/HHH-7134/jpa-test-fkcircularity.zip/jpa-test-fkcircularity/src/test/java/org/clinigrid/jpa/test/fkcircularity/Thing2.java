package org.clinigrid.jpa.test.fkcircularity;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(schema = "schema2", name = "thing")
public class Thing2 extends Thing1 {

	public Thing2() {
		super();
	}

	public Thing2(String string, Integer integer) {
		super(string);
		this.integer = integer;
	}

	@Basic
	private Integer integer;

	public Integer getInteger() {
		return integer;
	}
}
