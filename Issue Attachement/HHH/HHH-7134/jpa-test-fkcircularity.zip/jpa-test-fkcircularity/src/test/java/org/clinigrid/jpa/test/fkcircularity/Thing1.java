package org.clinigrid.jpa.test.fkcircularity;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(schema = "schema1", name = "thing")
public class Thing1 {

	public Thing1() {
		super();
	}

	public Thing1(String string) {
		this.string = string;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Basic
	private String string;

	public Integer getId() {
		return id;
	}

	public String getString() {
		return string;
	}
}
