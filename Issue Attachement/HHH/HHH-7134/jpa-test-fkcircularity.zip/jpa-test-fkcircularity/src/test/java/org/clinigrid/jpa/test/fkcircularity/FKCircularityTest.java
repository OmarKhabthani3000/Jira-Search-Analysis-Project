package org.clinigrid.jpa.test.fkcircularity;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import junit.framework.TestCase;

public class FKCircularityTest extends TestCase {

	public void test() {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("default");
		EntityManager em = emf.createEntityManager();
		EntityTransaction trans = em.getTransaction();

		Thing1 thing1 = new Thing1("test");
		Thing2 thing2 = new Thing2("test", 0);

		trans.begin();
		em.persist(thing1);
		em.persist(thing2);
		trans.commit();

		em.close();
		emf.close();
	}
}
