package org.nuiton.entities;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;
import org.junit.Test;

public class AppTest {

    @Test(expected=Exception.class)
    public void testNullNaturalId() {

        // Create a session
        //Configuration configuration = new Configuration();
        //configuration.configure();
        StandardServiceRegistryBuilder serviceRegistryBuilder = new StandardServiceRegistryBuilder();
        serviceRegistryBuilder.configure();
        ServiceRegistry serviceRegistry = serviceRegistryBuilder.build();
        MetadataSources sources = new MetadataSources(serviceRegistry);
        Metadata metadata = sources.buildMetadata();
        SessionFactory sessionFactory = metadata.buildSessionFactory();
        Session session = sessionFactory.openSession();

        // Start transaction
        Transaction tx = session.beginTransaction();

        // create entity and leave field with null value
        // this should not be possible :
        // https://docs.jboss.org/hibernate/orm/5.0/manual/en-US/html/ch05.html#mapping-declaration-naturalid
        Building building = new Building();
        session.save(building);
        
        tx.commit();
        session.close();
        serviceRegistryBuilder.destroy(serviceRegistry);

    }
    
    @Test
    public void testNotNullNaturalId() {

        // Create a session
        //Configuration configuration = new Configuration();
        //configuration.configure();
        StandardServiceRegistryBuilder serviceRegistryBuilder = new StandardServiceRegistryBuilder();
        serviceRegistryBuilder.configure();
        ServiceRegistry serviceRegistry = serviceRegistryBuilder.build();
        MetadataSources sources = new MetadataSources(serviceRegistry);
        Metadata metadata = sources.buildMetadata();
        SessionFactory sessionFactory = metadata.buildSessionFactory();
        Session session = sessionFactory.openSession();

        // Start transaction
        Transaction tx = session.beginTransaction();

        // create entity and leave field with null value
        // this should not be possible :
        // https://docs.jboss.org/hibernate/orm/5.0/manual/en-US/html/ch05.html#mapping-declaration-naturalid
        Building building = new Building();
        building.setName("main street");
        building.setNumber(1L);
        session.save(building);
        
        tx.commit();
        session.close();
        serviceRegistryBuilder.destroy(serviceRegistry);

    }

}
