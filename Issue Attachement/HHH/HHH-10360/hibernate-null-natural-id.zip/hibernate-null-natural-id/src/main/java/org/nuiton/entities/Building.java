package org.nuiton.entities;

import java.io.Serializable;

public class Building implements Serializable {

    protected Long id;

    protected Long number;

    protected String name;

    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }

    public Long getNumber() {
        return number;
    }
    
    public void setNumber(Long number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
