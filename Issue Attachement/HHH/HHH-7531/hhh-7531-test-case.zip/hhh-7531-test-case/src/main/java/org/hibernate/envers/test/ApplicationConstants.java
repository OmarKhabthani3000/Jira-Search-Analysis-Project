package org.hibernate.envers.test;

/**
 * @author 502077553
 *
 */
public class ApplicationConstants {


	// Perisistence and Data Constants
	public static final String	STICKY_IN_JOB				= "STICKY_IN_JOB";
	public static final String	STICKY						= "STICKY";

	// Request Parameter Constants

	// Table mapping
	public static final String	REPORT_SCHEMA				= "customer";
	public static final String	SEARCH_TABLE				= "search_test";
	public static final String	SEARCH_PARAM_TABLE			= "search_param_test";
	public static final String	AUDIT_TABLE_SUFFIX			= "_AUDIT";

}