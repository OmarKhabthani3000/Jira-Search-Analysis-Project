package org.hibernate.envers.test;

import org.hibernate.cfg.Environment;
import org.hibernate.ejb.Ejb3Configuration;
import org.hibernate.ejb.EntityManagerFactoryImpl;
import org.hibernate.service.BootstrapServiceRegistryBuilder;

import org.junit.*;

import javax.persistence.EntityManager;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

public class HHH7531Test {
	static private Ejb3Configuration cfg = null;
	static private EntityManagerFactoryImpl emf = null;
	private EntityManager em = null;

	@BeforeClass
	public static void init() {
		cfg = new Ejb3Configuration();
		cfg.configure( getConnectionProviderProperties() );
		configure( cfg );
		emf = (EntityManagerFactoryImpl) cfg.buildEntityManagerFactory( new BootstrapServiceRegistryBuilder() );
	}

	@AfterClass
	public static void destroy() {
		emf.close();
	}

	@Before
	public void setUp() {
		em = emf.createEntityManager();
	}

	@After
	public void tearDown() {
		em.close();
	}

	@Test
	public void testHERE() {
		em.getTransaction().begin();
		Search	mock	= new Search();
		mock.setName("testsearch");
		SearchParameter searchParameter = new SearchParameter();
		searchParameter.setName("Param_test1");
		Set<SearchParameter> paramSet = new HashSet<SearchParameter>();
		paramSet.add( searchParameter );
		mock.setSearchParams( paramSet );
		em.persist( mock );
		em.getTransaction().commit();

		em.getTransaction().begin();
		mock = em.find( Search.class, mock.getId() );
		mock.setName( "Param_test1" );
		em.merge( mock );
		em.getTransaction().commit();
	}

	private static void configure(Ejb3Configuration cfg) {
		cfg.addAnnotatedClass( Search.class );
		cfg.addAnnotatedClass( SearchParameter.class );
	}

	public static final String DRIVER = "org.h2.Driver";
	public static final String URL = "jdbc:h2:mem:%s;DB_CLOSE_DELAY=-1;MVCC=TRUE;INIT=CREATE SCHEMA IF NOT EXISTS " + ApplicationConstants.REPORT_SCHEMA;
	public static final String USER = "sa";
	public static final String PASS = "";

	public static Properties getConnectionProviderProperties(String dbName) {
		Properties props = new Properties( null );
		props.put( Environment.DRIVER, DRIVER );
		props.put( Environment.URL, String.format( URL, dbName ) );
		props.put( Environment.USER, USER );
		props.put( Environment.PASS, PASS );
		props.put( Environment.SHOW_SQL, "true" );
		props.put( Environment.FORMAT_SQL, "false" );
		props.put( Environment.HBM2DDL_AUTO, "create-drop" );
		return props;
	}

	public static Properties getConnectionProviderProperties() {
		return getConnectionProviderProperties( "db1" );
	}
}