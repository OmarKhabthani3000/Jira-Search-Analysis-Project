/**
 * 
 */
package dao.search;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;

import dao.AbstractDaoTest;
import domain.search.Search;
import domain.search.SearchParameter;

/**
 * @author 501988786
 * 
 */
public class SearchDaoTest extends AbstractDaoTest<SearchDao> {

	
	/**
	 * @param daoClass
	 */
	public SearchDaoTest() {
		super(SearchDao.class);
		// groupReportAssocDao = ctx.getBean(SecurityGroupReportAssocDao.class);
	}

	/**
	 * Test method for {@link dao.AbstractJPADao#create(java.lang.Object)}
	 */
	@Test
	@Transactional
	public final void testCreateSearch() {
		Search	mock	= new Search();
		mock.setName("testsearch");
		SearchParameter searchParameter = new SearchParameter();
		searchParameter.setName("Param_test1");
		Set<SearchParameter> paramSet = new HashSet<SearchParameter>();
		paramSet.add(searchParameter);
		mock.setSearchParams(paramSet);

		Search search = srv.save(mock);
		assertNotNull(search.getId());

	}


	/**
	 * Test method for {@link dao.AbstractJPADao#update(java.lang.Object)}
	 */
	//@Test
	 @Transactional
	public final void testUpdateSearch() {

		Search search = dao.readFirstHQL("from Search search inner join fetch search.searchParams where  search.name='Param_test%'");
		System.out.println("Search Object : " + search);
		Long searchId = search.getId();
		System.out.println("Search Id : " + searchId);
		String oldValue = search.getName();
		Set<SearchParameter> oldParameters = search.getSearchParams();
		String newValue = "Param_test1";

		// search.getSearchParams().clear();
		search.setName(newValue);
		search = dao.update(search);

		search = null;
		search = dao.read(searchId);
		assertEquals(newValue, search.getName());
		// assertTrue(search.getSearchParams().isEmpty());

		search.setName(oldValue);
		search.setSearchParams(oldParameters);
		search = dao.update(search);
		search = null;
		search = dao.read(searchId);
		// assertNotNull(search);
		assertEquals(oldValue, search.getName());
		// assertNotNull(search.getSearchParams());

	}

	

}
