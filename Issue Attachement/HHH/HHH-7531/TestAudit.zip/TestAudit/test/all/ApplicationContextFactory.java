/**
 * 
 */
package all;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author 501988786
 * 
 */
public final class ApplicationContextFactory {

	private static ClassPathXmlApplicationContext	ctx;

	public static ClassPathXmlApplicationContext getCtx() {

		if (ctx == null)
			ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		return ctx;
	}

}
