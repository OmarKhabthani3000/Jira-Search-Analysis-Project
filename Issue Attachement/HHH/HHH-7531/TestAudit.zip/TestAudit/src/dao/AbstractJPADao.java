/**
 * The subclasses of this class provide persistence, 
 * dealing with typed results (i.e. no casting required)
 */
package dao;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.MappedSuperclass;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import domain.AbstractDomainObject;

/**
 * @author 501988786
 * 
 * @param <T>
 */
public abstract class AbstractJPADao<T extends AbstractDomainObject> {

	// EM to be removed from here into service
	@PersistenceContext(name = "CIRPersistenceService")
	protected EntityManager		em;
	//
	protected final Class<T>	entityClass;
	protected final String		selectClause;
	protected final String		countClause;
	protected final Logger		log;
	protected final String		entityType;
	protected Long				startTime;

	// This constructor MUST be called by subtypes
	protected AbstractJPADao(Class<T> entityClass, Class<? extends AbstractJPADao<T>> loggerClass) {
		this.entityClass = entityClass;
		this.log = LoggerFactory.getLogger(loggerClass);
		this.entityType = entityClass.getSimpleName();
		this.selectClause = "from " + entityType + " where id != '-1' ";
		this.countClause = "select count (*) from " + entityType + " where id != '-1' ";
	}

	// This constructor MUST be called by report daos
	protected AbstractJPADao(Class<T> entityClass, Class<? extends AbstractJPADao<T>> loggerClass, boolean isIdFiltered) {
		this.entityClass = entityClass;
		this.log = LoggerFactory.getLogger(loggerClass);
		this.entityType = entityClass.getSimpleName();
		this.selectClause = "from " + entityType;
		this.countClause = "count (*) from " + entityType;

	}

	// CRUD JPA Implentation
	@Transactional
	public T create(T t) {
		log.debug("Creating new " + entityType + "...");
		startTime = System.currentTimeMillis();
		em.persist(t);
		// int a = 25 / 0; -- force abort for testing
		System.out.println("Created  new" + identify(t) + deltatime(startTime));
		log.debug("Created  new" + identify(t) + deltatime(startTime));
		return t;
	}

	public T create(EntityManager em, T t) {

		log.debug("xxxx Creating new " + entityType + "...");
		startTime = System.currentTimeMillis();
		em.persist(t);
		// int a = 25 / 0; -- force abort for testing
		log.debug("Created  new" + identify(t) + deltatime(startTime));
		return t;

	}

	@Transactional
	public T read(Object key) {
		log.debug("Finding " + entityType + " with id#" + key + "...");
		startTime = System.currentTimeMillis();
		T t = em.find(entityClass, key);
		log.debug("Found   " + identify(t) + deltatime(startTime));
		// t.forceInitializeCollections();
		return t;
	}

	public T read(EntityManager em, Object key) {
		log.debug("Finding " + entityType + " with id#" + key + "...");
		startTime = System.currentTimeMillis();
		T t = em.find(entityClass, key);
		log.debug("Found   " + identify(t) + deltatime(startTime));
		// t.forceInitializeCollections();
		return t;
	}

	@Transactional
	public T update(T t) {
		log.debug("Updating" + identify(t) + "...");
		startTime = System.currentTimeMillis();
		t = em.merge(t);
		log.debug("Updated " + identify(t) + deltatime(startTime));
		return t;
	}

	public T update(EntityManager em, T t) {
		log.debug("Updating" + identify(t) + "...");
		startTime = System.currentTimeMillis();
		t = em.merge(t);
		log.debug("Updated " + identify(t) + deltatime(startTime));
		return t;
	}

	@Transactional
	public T delete(T t) {
		log.debug("Deleting " + t + "...");
		startTime = System.currentTimeMillis();
		t = em.find(entityClass, t.getId());
		em.remove(t);
		log.debug("Deleted  " + identify(t) + deltatime(startTime));
		return t;
	}

	public T delete(EntityManager em, T t) {
		log.debug("Deleting " + t + "...");
		startTime = System.currentTimeMillis();
		t = em.find(entityClass, t.getId());
		em.remove(t);
		log.debug("Deleted  " + identify(t) + deltatime(startTime));
		return t;
	}

	@Transactional
	public T save(T t) {
		return t.getId() == null ? create(t) : update(t);
	}

	public T save(EntityManager em, T t) {
		return t.getId() == null ? create(em, t) : update(em, t);
	}

	// Queries

	// Single result
	public T readOne(String ql, Object... params) {
		log.debug("Finding any " + entityType + " objects" + ql + "...");
		startTime = System.currentTimeMillis();
		TypedQuery<T> q = em.createQuery(selectClause + ql, entityClass);
		int i = 1;
		for (Object p : params) {
			q.setParameter(i, p);
			i++;
		}
		q.setMaxResults(1);
		T t = q.getSingleResult();
		log.debug("Found" + identify(t) + deltatime(startTime));
		return t;
	}

	public T readOne(EntityManager em, String ql, Object... params) {
		log.debug("Finding any " + entityType + " objects" + ql + "...");
		startTime = System.currentTimeMillis();
		TypedQuery<T> q = em.createQuery(selectClause + ql, entityClass);
		int i = 1;
		for (Object p : params) {
			q.setParameter(i, p);
			i++;
		}
		q.setMaxResults(1);
		T t = q.getSingleResult();
		log.debug("Found" + identify(t) + deltatime(startTime));
		return t;
	}

	public T readFirst(String ql, Object... params) {
		log.debug("Finding first " + entityType + " objects where " + ql + "...");
		startTime = System.currentTimeMillis();
		TypedQuery<T> q = em.createQuery(selectClause + ql, entityClass);
		int i = 1;
		for (Object p : params) {
			q.setParameter(i, p);
			i++;
		}
		q.setMaxResults(1);
		List<T> c = q.getResultList();
		log.debug("Found " + c.size() + " " + entityType + " objects" + deltatime(startTime));
		return c.size() > 0 ? c.get(0) : null;
	}

	public T readFirst(EntityManager em, String ql, Object... params) {
		log.debug("Finding first " + entityType + " objects where " + ql + "...");
		startTime = System.currentTimeMillis();
		TypedQuery<T> q = em.createQuery(selectClause + ql, entityClass);
		int i = 1;
		for (Object p : params) {
			q.setParameter(i, p);
			i++;
		}
		q.setMaxResults(1);
		List<T> c = q.getResultList();
		log.debug("Found " + c.size() + " " + entityType + " objects" + deltatime(startTime));
		return c.size() > 0 ? c.get(0) : null;
	}

	// Collections

	public Long count(EntityManager em, StringBuffer ql) {

		log.debug("Counting " + entityType + " objects ...");
		startTime = System.currentTimeMillis();
		int i = ql.indexOf("from");
		String query;
		if (i == -1) {
			query = countClause + ql;
		} else {
			query = "select count(distinct " + entityType + ")" +
					ql.substring(i);
		}
		TypedQuery<Long> q = em.createQuery(query, Long.class);
		Long count = q.getSingleResult();
		log.debug("Counted total of " + count + " " + entityType + " objects"
				+ deltatime(startTime));
		return new Long(count);
	}

	
	public Long countNativeQuery(EntityManager em, String query, Object... parameters) {

		log.debug("Counting " + entityType + " objects ...");
		startTime = System.currentTimeMillis();
		Query q = em.createNativeQuery("select count (*) from (" + query + ")");
		int i = 1;
		for (Object p : parameters) {
			q.setParameter(i, p);
			i++;
		}
		Long count = ((BigDecimal) q.getSingleResult()).longValue();
		log.debug("Counted total of " + count + " " + entityType + " objects" + deltatime(startTime));
		return count;

	}

	public Collection<T> readList() {
		log.debug("Finding all " + entityType + " objects ...");
		startTime = System.currentTimeMillis();
		TypedQuery<T> q = em.createQuery(selectClause, entityClass);
		Collection<T> c = q.getResultList();
		log.debug("Found " + c.size() + " " + entityType + " objects" + deltatime(startTime));
		return c;
	}

	public Collection<T> readList(EntityManager em) {
		log.debug("Finding all " + entityType + " objects ...");
		startTime = System.currentTimeMillis();
		TypedQuery<T> q = em.createQuery(selectClause, entityClass);
		Collection<T> c = q.getResultList();
		log.debug("Found " + c.size() + " " + entityType + " objects" + deltatime(startTime));
		return c;
	}

	public Collection<T> readList(EntityManager em, String first, String limit, String ql) {
		log.debug("Selecting " + selectClause + ql + "...");
		startTime = System.currentTimeMillis();
		TypedQuery<T> q = null;
		if (ql != null && !ql.toUpperCase().contains("FROM"))
			ql = selectClause + ql;

		q = em.createQuery(ql, entityClass);
		if (first != null) {
			q.setFirstResult(Integer.parseInt(first));
		}
		if (limit != null) {
			q.setMaxResults(Integer.parseInt(limit));
		}
		Collection<T> c = q.getResultList();
		log.debug("Selected " + c.size() + " " + entityType + " in " + deltatime(startTime));
		return c;
	}

	public Collection<T> readListFromSql(EntityManager em, String first, String limit, String ql) {
		log.debug("Selecting " + selectClause + ql + "...");
		startTime = System.currentTimeMillis();
		Query q = null;
		if (ql != null && !ql.toUpperCase().contains("FROM"))
			ql = selectClause + ql;
		q = em.createNativeQuery(ql, entityClass);
		if (first != null) {
			q.setFirstResult(Integer.parseInt(first));
		}
		if (limit != null) {
			q.setMaxResults(Integer.parseInt(limit));
		}
		@SuppressWarnings("unchecked")
		Collection<T> c = q.getResultList();
		log.debug("Selected " + c.size() + " " + entityType + " in " + deltatime(startTime));
		return c;
	}

	public Collection<T> readList(EntityManager em, String first, String limit, StringBuffer ql) {
		return readList(em, first, limit, ql.toString());
	}

	public Collection<T> readList(String ql, Object... params) {
		log.debug("Finding all " + entityType + " objects" + ql + "...");
		startTime = System.currentTimeMillis();
		TypedQuery<T> q = em.createQuery(selectClause + ql, entityClass);
		int i = 1;
		for (Object p : params) {
			q.setParameter(i, p);
			i++;
		}
		Collection<T> c = q.getResultList();
		log.debug("Found " + c.size() + " " + entityType + " objects" + deltatime(startTime));
		return c;
	}

	public Collection<T> executeNamedQuery(EntityManager em, String first, String limit, String queryName, Object... params) {
		log.debug("Executing the named query" + queryName + "...");
		startTime = System.currentTimeMillis();

		Query q = em.createNamedQuery(queryName);
		int i = 1;
		for (Object p : params) {
			q.setParameter(i, p);
			i++;
		}
		if (first != null) {
			q.setFirstResult(Integer.parseInt(first));
		}
		if (limit != null) {
			q.setMaxResults(Integer.parseInt(limit));
		}
		@SuppressWarnings("unchecked")
		Collection<T> c = q.getResultList();
		log.debug("Selected " + c.size() + " " + entityType + " in " + deltatime(startTime));
		return c;
	}

	public Collection<? extends AbstractDomainObject> executeNativeQuery(EntityManager em, Class<? extends AbstractDomainObject> clazz, String first,
			String limit, String queryName,
			Object... params) {
		log.debug("Executing the named query" + queryName + "...");
		startTime = System.currentTimeMillis();

		Query q = em.createNativeQuery(queryName, clazz);
		int i = 1;
		for (Object p : params) {
			q.setParameter(i, p);
			i++;
		}
		if (first != null) {
			q.setFirstResult(Integer.parseInt(first));
		}
		if (limit != null) {
			q.setMaxResults(Integer.parseInt(limit));
		}
		@SuppressWarnings("unchecked")
		Collection<? extends AbstractDomainObject> c = q.getResultList();
		log.debug("Selected " + c.size() + " " + entityType + " in " + deltatime(startTime));
		return c;
	}

	public Collection<T> readList(EntityManager em, String ql, Object... params) {
		log.debug("Finding all " + entityType + " objects" + ql + "...");
		startTime = System.currentTimeMillis();
		TypedQuery<T> q = em.createQuery(selectClause + ql, entityClass);
		int i = 1;
		for (Object p : params) {
			q.setParameter(i, p);
			i++;
		}
		Collection<T> c = q.getResultList();
		log.debug("Found " + c.size() + " " + entityType + " objects" + deltatime(startTime));
		return c;
	}

	@SuppressWarnings("unchecked")
	public Collection<T> readList(String q1, LinkedHashMap<String, Object> parameterMap) {
		log.debug("Querying " + entityType + "By the native query " + q1 + "...");
		startTime = System.currentTimeMillis();
		Query q = em.createNativeQuery(q1, entityClass);
		if (parameterMap != null) {
			Set<String> keys = parameterMap.keySet();
			for (String key : keys) {
				q.setParameter(key, parameterMap.get(key));
			}
		}
		Collection<T> c = q.getResultList();
		log.debug("Found " + c.size() + " " + entityType + " Objects" + deltatime(startTime));
		return c;
	}

	@SuppressWarnings("unchecked")
	public Collection<T> readList(EntityManager em, String q1, LinkedHashMap<String, Object> parameterMap) {
		log.debug("Querying " + entityType + "By the native query " + q1 + "...");
		startTime = System.currentTimeMillis();
		Query q = em.createNativeQuery(q1, entityClass);
		if (parameterMap != null) {
			Set<String> keys = parameterMap.keySet();
			for (String key : keys) {
				q.setParameter(key, parameterMap.get(key));
			}
		}
		Collection<T> c = q.getResultList();
		log.debug("Found " + c.size() + " " + entityType + " Objects" + deltatime(startTime));
		return c;
	}

	
	
	private String identify(T t) {

		if (t != null)
			return " " + entityType + " #" + t.getId() + "/" + t.getName() + " ";
		else
			return "";

	}

	protected String deltatime(Long startTime) {

		return " in " + (System.currentTimeMillis() - startTime) + " ms";
	}

	@SuppressWarnings("unchecked")
	public String getNamedNativeQueryText(Class<? extends AbstractDomainObject> clazz, String namedQueryKey) {

		NamedNativeQueries namedQueriesAnnotation = clazz.getAnnotation(NamedNativeQueries.class);
		NamedNativeQuery[] namedQueryAnnotations = namedQueriesAnnotation.value();

		String hql = null;
		for (NamedNativeQuery namedQuery : namedQueryAnnotations) {
			if (namedQuery.name().equals(namedQueryKey)) {
				hql = namedQuery.query();
				break;
			}
		}

		if (hql == null) {
			if (clazz.getSuperclass().getAnnotation(MappedSuperclass.class) != null) {
				hql = getNamedNativeQueryText((Class<? extends AbstractDomainObject>) clazz.getSuperclass(), namedQueryKey);
			}
		}
		return hql;
	}

	
}
