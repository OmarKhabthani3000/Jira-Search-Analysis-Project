/**
 * 
 */
package dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import service.CIRPersistenceService;

import all.ApplicationContextFactory;

import domain.AbstractDomainObject;

/**
 * @author 501988786
 * 
 */

public abstract class AbstractDaoTest<T extends AbstractJPADao<? extends AbstractDomainObject>> {

	protected final ApplicationContext	ctx		= ApplicationContextFactory.getCtx();									;
	protected Logger					log;
	protected T							dao;
	protected CIRPersistenceService		srv;

	protected AbstractDaoTest(Class<T> daoClass) {

		log = LoggerFactory.getLogger(getClass());
		dao = ctx.getBean(daoClass);
		srv = ctx.getBean(CIRPersistenceService.class);
	}

}
