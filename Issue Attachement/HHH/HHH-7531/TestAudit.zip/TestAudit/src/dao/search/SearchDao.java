package dao.search;

import java.util.Collection;
import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import dao.AbstractJPADao;
import domain.search.Search;

@Repository
public class SearchDao extends AbstractJPADao<Search> {

	/**
	 * @param entityClass
	 * @param loggerClass
	 */

	public SearchDao() {
		super(Search.class, SearchDao.class);
	}

	private static final String	order	= " order by searchdate desc";

	public Collection<Search> readAdminPublicByUser(Long userId) {
		return readList(" and isSticky is null and template_type='ADMIN' and user_id = " + userId + order);
	}

	public Collection<Search> readAdminPublicByUserReport(Long userId, String reportName) {
		return readList(" and isSticky is null and template_type='ADMIN' and user_id = " + userId + " and report_name = '" + reportName + "' "
				+ order);
	}

	public Collection<Search> readAllByUser(Long userId) {
		return readList(" and IS_STICKY is null and USER_ID = " + userId);
	}

	public Collection<Search> readAllByUserReport(Long userId, String reportName) {
		return readList(" and isSticky is null and user.id = " + userId + " and report_name='"
				+ reportName + "'" + order);
	}

	public Search readSticky(Long userId, String reportName) {
		return readFirstHQL(" from Search search inner join fetch search.searchParams where search.templateType = 'PRIVATE' and search.isSticky='STICKY' and search.user.id = "
				+ userId + " and search.report.name='" + reportName + "'" + order);
	}

	public Search readSearchById(Long searchId) {
		return readFirstHQL(" from Search search inner join fetch search.searchParams where search.id='" + searchId + "'");
	}

	public Search readFirstHQL(String ql, Object... params) {
		log.debug("Finding first " + entityType + " objects where " + ql + "...");
		startTime = System.currentTimeMillis();
		TypedQuery<Search> q = em.createQuery(ql, entityClass);
		int i = 1;
		for (Object p : params) {
			q.setParameter(i, p);
			i++;
		}
		q.setMaxResults(1);
		List<Search> c = q.getResultList();
		log.debug("Found " + c.size() + " " + entityType + " objects" + deltatime(startTime));
		return c.size() > 0 ? c.get(0) : null;
	}

}
