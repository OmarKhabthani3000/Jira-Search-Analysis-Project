/**
 * 
 */
package controller;

/**
 * @author 501988786
 * 
 */
public class MinifyTemplate {

	private boolean	keepID;
	private boolean	keepName;
	private boolean	keepPrimitives;
	private boolean	keepEntities;
	private boolean	keepCollections;
	private boolean	keepPlanNumber;

	public static enum loadMask {
		ID, ID_NAME, ID_NAME_PRIMITIVES, ID_NAME_PRIMITIVES_ENTITIES, FULL, ID_FALSE_NAME,ID_NAME_PLANNUMBER
	};

	/**
	 * @param none
	 *            - default ID_NAME
	 */
	public MinifyTemplate() {
		this(MinifyTemplate.loadMask.ID_NAME);
	}

	/**
	 * @param loadMask
	 */
	public MinifyTemplate(MinifyTemplate.loadMask loadMask) {

		switch (loadMask) {

		case ID:
			keepID = true;
			keepName = false;
			keepPrimitives = false;
			keepEntities = false;
			keepCollections = false;
			break;

		case ID_NAME:
			keepID = true;
			keepName = true;
			keepPrimitives = false;
			keepEntities = false;
			keepCollections = false;
			break;

		case ID_NAME_PRIMITIVES:
			keepID = true;
			keepName = true;
			keepPrimitives = true;
			keepEntities = false;
			keepCollections = false;
			break;

		case ID_NAME_PRIMITIVES_ENTITIES:
			keepID = true;
			keepName = true;
			keepPrimitives = true;
			keepEntities = true;
			keepCollections = false;
			break;

		case FULL:
			keepID = true;
			keepName = true;
			keepPrimitives = true;
			keepEntities = true;
			keepCollections = true;
			break;
			
		case ID_FALSE_NAME:
			keepID = false;
			keepName = true;
			keepPrimitives = false;
			keepEntities = false;
			keepCollections = false;
			break;
			
		case ID_NAME_PLANNUMBER:
			keepID = true;
			keepName = true;
			keepPrimitives = false;
			keepEntities = false;
			keepCollections = false;
			keepPlanNumber=true;
			break;

		default:
			keepID = false;
			keepName = false;
			keepPrimitives = false;
			keepEntities = false;
			keepCollections = false;
		}

	}

	/**
	 * @return the keepName
	 */
	public boolean isKeepName() {
		return keepName;
	}

	/**
	 * @return the keepEntities
	 */
	public boolean isKeepEntities() {
		return keepEntities;
	}

	/**
	 * @return the keepCollections
	 */
	public boolean isKeepCollections() {
		return keepCollections;
	}

	/**
	 * @return the keepID
	 */
	public boolean isKeepID() {
		return keepID;
	}

	/**
	 * @return the keepPrimitives
	 */
	public boolean isKeepPrimitives() {
		return keepPrimitives;
	}
	
	public boolean isKeepPlanNumber() {
		return keepPlanNumber;
	}

}
