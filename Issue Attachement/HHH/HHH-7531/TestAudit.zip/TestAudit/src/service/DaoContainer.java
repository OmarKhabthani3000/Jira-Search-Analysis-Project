/**
 * This is a container for Daos
 */
package service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import dao.AbstractJPADao;
import dao.search.SearchDao;
import domain.AbstractDomainObject;
import domain.search.Search;


/**
 * @author 501988786
 * 
 */
@SuppressWarnings(value = { "serial", "unused" })
@Component
public class DaoContainer extends
		HashMap<Class<? extends AbstractDomainObject>, AbstractJPADao<? extends AbstractDomainObject>> {
	
	private SearchDao								searchDao;

	DaoContainer() {
	};
	
	/**
	 * @param searchDao
	 *            the searchDao to set
	 */
	@Autowired
	public void setSearchDao(SearchDao searchDao) {
		put(Search.class, searchDao);
	}

	
}
