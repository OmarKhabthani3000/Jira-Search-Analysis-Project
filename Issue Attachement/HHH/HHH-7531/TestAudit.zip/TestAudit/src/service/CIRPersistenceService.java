/**
 * 
 */
package service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import controller.MinifyTemplate;
import dao.AbstractJPADao;
import domain.AbstractDomainObject;
import domain.search.Search;

/**
 * @author 501988786
 * 
 */
@Service
public class CIRPersistenceService {

	@PersistenceContext(name = "CIRPersistenceService")
	protected EntityManager	em;

	@Autowired
	protected DaoContainer	daos;

	/**
	 * @return the em
	 */
	public EntityManager getEm() {
		return em;
	}

	/**
	 * @param em
	 *            the em to set
	 */
	public void setEm(EntityManager em) {
		this.em = em;
	}

	/**
	 * @return the daos
	 */
	public DaoContainer getDaos() {
		return daos;
	}

	/**
	 * @param daos
	 *            the daos to set
	 */
	public void setDaos(DaoContainer daos) {
		this.daos = daos;
	}

	

	
	

	@SuppressWarnings("unchecked")
	@Transactional
	public <T extends AbstractDomainObject> T read(T t) {
		AbstractJPADao<T> d = (AbstractJPADao<T>) daos.get(t.getClass());
		return d.read(em, t.getId());
	}

	public <T extends AbstractDomainObject> T read(T t, Object key) {
		@SuppressWarnings("unchecked")
		AbstractJPADao<T> d = (AbstractJPADao<T>) daos.get(t.getClass());
		return d.read(em, key);
	}

	public <T extends AbstractDomainObject> T read(T t, String criteria, Object... key) {
		@SuppressWarnings("unchecked")
		AbstractJPADao<T> d = (AbstractJPADao<T>) daos.get(t.getClass());
		return d.readOne(em, criteria, key);
	}


	

	// /////////////////////// CRUD ////////////////////
	@Transactional
	public <T extends AbstractDomainObject> T save(T t) {
		@SuppressWarnings("unchecked")
		AbstractJPADao<T> d = (AbstractJPADao<T>) daos.get(t.getClass());
		return d.save(em, t);
	}

	@Transactional
	public <T extends AbstractDomainObject> T create(T t) {
		@SuppressWarnings("unchecked")
		AbstractJPADao<T> d = (AbstractJPADao<T>) daos.get(t.getClass());
		return d.create(t);
	}

	@Transactional
	public <T extends AbstractDomainObject> T update(T t) {
		@SuppressWarnings("unchecked")
		AbstractJPADao<T> d = (AbstractJPADao<T>) daos.get(t.getClass());
		return d.update(t);
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public <T extends AbstractDomainObject> T update(T t, MinifyTemplate formattingTemplate) {
		AbstractJPADao<T> d = (AbstractJPADao<T>) daos.get(t.getClass());
		T domainObject = d.update(t);
		return (T) domainObject.minify(formattingTemplate);
	}

	@Transactional
	public <T extends AbstractDomainObject> T delete(T t) {
		@SuppressWarnings("unchecked")
		AbstractJPADao<T> d = (AbstractJPADao<T>) daos.get(t.getClass());
		return d.delete(em, t);
	}


}
