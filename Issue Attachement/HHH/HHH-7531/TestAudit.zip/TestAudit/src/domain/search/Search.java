package domain.search;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyJoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.MapKey;
import org.hibernate.annotations.MapKeyManyToMany;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.AuditMappedBy;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;
import org.hibernate.envers.SecondaryAuditTable;

import domain.AbstractDomainObject;


/**
 * @author 501988786
 * 
 */
@SuppressWarnings("serial")
@Entity
@BatchSize(size = 1000)
@Table(schema = ApplicationConstants.REPORT_SCHEMA, name = ApplicationConstants.SEARCH_TABLE)
@Audited
@AuditTable(schema = ApplicationConstants.REPORT_SCHEMA, value = ApplicationConstants.SEARCH_TABLE + ApplicationConstants.AUDIT_TABLE_SUFFIX)
@Cache(region = "Search", usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Search extends AbstractDomainObject {

	private String								description;
	private Timestamp							modifyDate;
	private Set<SearchParameter>				searchParams;
	private Timestamp							createdDate;




	/**
	 * @return the deletedFlag
	 */

	public Search() {
	}

	/*
	 * @Override public Search clone() { Search out = new Search();
	 * out.modifyDate = new Timestamp(new Date().getTime()); out.outputType =
	 * this.outputType; out.report = report.clone(); out.searchDate = new
	 * Timestamp(new Date().getTime()); out.searchParams = new
	 * HashSet<SearchParameter>(); for (SearchParameter searchParameter :
	 * searchParams) { out.searchParams.add(searchParameter.clone()); } return
	 * out; }
	 */

	/**
	 * @return the createdDate
	 */
	@Column(name = "CREATED_DATE", updatable = false)
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate
	 *            the createdDate to set
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public boolean equals(Object obj) {
		boolean flag = false;
		if (this.id == ((Search) obj).getId()) {
			flag = true;
		} else {
			flag = false;
		}
		return flag;
	}

	@Column(name = "DESCRIPTION")
	public String getDescription() {
		return description;
	}

	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	

	@Column(name = "MODIFY_DATE")
	public Timestamp getModifyDate() {
		return modifyDate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see domain.AbstractDomainObject#getName()
	 */
	@Override
	public String getName() {
		return this.name;
	}

	//@AuditMappedBy(mappedBy = "search")
	//@MapKeyJoinColumn(name="SEARCH_ID")
	
	@AuditJoinTable(name="search_param_auidit")
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "SEARCH_ID")
	@Cache(region = "Search.searchParams", usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
	public Set<SearchParameter> getSearchParams() {
		return searchParams;
	}



	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public void setId(Long id) {
		this.id = id;
	}

	
	public void setModifyDate(Timestamp modifyDate) {
		this.modifyDate = modifyDate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see domain.AbstractDomainObject#setName(java.lang.String)
	 */
	@Override
	public void setName(String name) {
		this.name = name;
	}

	public void setSearchParams(Set<SearchParameter> parameters) {
		this.searchParams = parameters;
	}

	
}