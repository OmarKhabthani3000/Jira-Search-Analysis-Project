package domain.search;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import domain.AbstractDomainObject;

/**
 * @author 501988786
 * 
 */
@SuppressWarnings("serial")
@Entity
@BatchSize(size = 1000)
@Table(name = ApplicationConstants.SEARCH_PARAM_TABLE, schema = ApplicationConstants.REPORT_SCHEMA)
@Audited
@AuditTable(schema = ApplicationConstants.REPORT_SCHEMA, value = ApplicationConstants.SEARCH_PARAM_TABLE + ApplicationConstants.AUDIT_TABLE_SUFFIX)
@Cache(region = "SearchParameter", usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class SearchParameter extends AbstractDomainObject {

	/**
	 * @return the id
	 */
	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	@Override
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	@Override
	@Column(name = "NAME")
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	@Override
	public void setName(String name) {
		this.name = name;
	}

}
