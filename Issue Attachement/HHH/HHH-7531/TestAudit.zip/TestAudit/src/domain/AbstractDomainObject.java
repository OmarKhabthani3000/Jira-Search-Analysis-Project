/**
 * 
 */
package domain;

import java.io.Serializable;

import controller.MinifyTemplate;

/**
 * @author 501566335
 * 
 */
@SuppressWarnings("serial")
public abstract class AbstractDomainObject implements Serializable {

	protected Long		id;
	protected String	name;

	public abstract Long getId();

	public abstract void setId(Long id);

	public abstract String getName();

	public abstract void setName(String name);
	

	/**
	 * 
	 * Meant to be overwritten or not called
	 * 
	 * @param minifyTemplate
	 */
	public AbstractDomainObject minify(MinifyTemplate minifyTemplate) {
		throw new IllegalArgumentException("Attempt to call non-overwritten minify");
	};

}
