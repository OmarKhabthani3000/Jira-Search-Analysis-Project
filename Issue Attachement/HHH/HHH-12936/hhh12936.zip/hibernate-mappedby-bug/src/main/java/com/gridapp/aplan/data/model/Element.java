package com.gridapp.aplan.data.model;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;

@Entity
public class Element extends IdentifiedEntity
{

    @ManyToMany
    private Set<List> lists = new HashSet<>();

    public Set<List> getLists()
    {
        return lists;
    }

    public void setLists(Set<List> lists)
    {
        this.lists = lists;
    }

}
