package com.gridapp.aplan.data.model;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;

@Entity
public class List extends IdentifiedEntity
{

    @ManyToMany(mappedBy = "lists")
    private Set<Element> elements = new HashSet<>(); // if renaming to e.g. "elts" bug disappears

    public Set<Element> getElements()
    {
        return elements;
    }

    public void setElements(Set<Element> elements)
    {
        this.elements = elements;
    }

}
