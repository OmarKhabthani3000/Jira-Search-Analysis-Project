package com.gridapp;

import com.gridapp.aplan.data.model.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JPAUnitTestCase
{

    private static EntityManagerFactory entityManagerFactory;

    @Before
    public void init()
    {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy()
    {
        entityManagerFactory.close();
    }

    @Test
    public void hhh12936Test()
    {
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        // set up test data
        entityManager.getTransaction().begin();

        List list = new List();
        entityManager.persist(list);

        entityManager.getTransaction().commit();

        // execute test
        entityManager.getTransaction().begin();

        Query query = entityManager.createQuery("SELECT e FROM Element e WHERE :list MEMBER OF e.lists");
        query.setParameter("list", list);
        query.getResultList();  //throws org.hibernate.exception.SQLGrammarException

        entityManager.getTransaction().commit();
    }

}
