package test;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Session;
import org.hibernate.Query;
import java.util.List;

public class Test
{
    public static void main(String[] args)
    {
        System.out.println(">>> Beginning test driver...");

        System.out.println(">>> Initializing Configuration...");
        Configuration configuration = new Configuration();
        configuration.addClass(Person.class);
        configuration.addClass(Name.class);
        configuration.addClass(NameType.class);

        System.out.println(">>> Creating Session Factory...");
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        System.out.println(">>> Opening Session...");
        Session session = sessionFactory.openSession();

        System.out.println(">>> Creating Query...");
        String queryString = "SELECT name.type " +
            "FROM Person p LEFT JOIN p.names name LEFT JOIN name.type types ";
        Query query = session.createQuery(queryString);
        System.out.println(">>> HQL Query String: " + queryString);

        System.out.println(">>> Executing Query...");
        List results = query.list();

        System.out.println(">>> Exiting test driver.");
    }
}
