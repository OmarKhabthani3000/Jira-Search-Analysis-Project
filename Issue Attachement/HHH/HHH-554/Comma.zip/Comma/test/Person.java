package test;

import java.util.Set;
import java.math.BigDecimal;

public class Person
{
    private Set names = null;
    private BigDecimal identifier = null;

    public Person()
    {
        super();
    }

    private Set getNames()
    {
        return this.names;
    }

    private void setNames(Set names)
    {
        this.names = names;
    }

    public BigDecimal getIdentifier()
    {
        return this.identifier;
    }

    private void setIdentifier(BigDecimal identifier)
    {
        this.identifier = identifier;
    }
}
