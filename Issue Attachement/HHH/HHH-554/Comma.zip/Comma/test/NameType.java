package test;

import java.math.BigDecimal;

public class NameType
{
    private BigDecimal identifier = null;

    NameType()
    {
        super();
    }

    public BigDecimal getIdentifier()
    {
        return this.identifier;
    }

    private void setIdentifier(BigDecimal identifier)
    {
        this.identifier = identifier;
    }

}
