package test;

import java.math.BigDecimal;

public class Name
{
    private BigDecimal identifier = null;
    private NameType type = null;

    public Name()
    {
        super();
    }

    public NameType getType()
    {
        return this.type;
    }

    public void setType(NameType type)
    {
        this.type = type;
    }

    public BigDecimal getIdentifier()
    {
        return this.identifier;
    }

    private void setIdentifier(BigDecimal identifier)
    {
        this.identifier = identifier;
    }
}


