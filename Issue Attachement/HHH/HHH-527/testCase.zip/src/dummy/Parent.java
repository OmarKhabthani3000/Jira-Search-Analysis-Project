package dummy;

import java.io.Serializable;
import java.util.TreeMap;

import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class Parent implements Serializable {
    /** nullable persistent field */
    private java.util.SortedMap children;

    /** nullable persistent field */
    private String name;

    /** nullable persistent field */
    private Integer orderNo;

    Long id;

    /** default constructor */
    public Parent() {
    }

    /** full constructor */
    public Parent(String name, Integer orderNo, java.util.SortedMap children) {
        this.name = name;
        this.orderNo = orderNo;
        this.children = children;
    }

    public void addChild(Child child) {
        // int key = 0;
        // Object lastKey = null;
        if (children == null) {
            children = new TreeMap();
        }
        // if (children.size() > 0) {
        // lastKey = children.lastKey();
        // }
        // if (lastKey != null) {
        // key = ((Integer) lastKey).intValue() + 1;
        // }
        child.setParent(this);
        children.put(child.getOrderNo(), child);
    }

    public java.util.SortedMap getChildren() {
        return this.children;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return this.name;
    }

    public Integer getOrderNo() {
        return this.orderNo;
    }

    public void setChildren(java.util.SortedMap children) {
        this.children = children;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }

    public String toString() {
        return new ToStringBuilder(this).toString();
    }
}
