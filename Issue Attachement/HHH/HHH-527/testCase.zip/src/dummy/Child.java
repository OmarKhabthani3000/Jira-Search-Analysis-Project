package dummy;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class Child implements Serializable {
    /** nullable persistent field */
    private String name;

    /** nullable persistent field */
    private Integer orderNo;

    /** nullable persistent field */
    private Parent parent;

    Long id;

    /** default constructor */
    public Child() {
    }

    /** full constructor */
    public Child(String name, Integer orderNo, Parent parent) {
        this.name = name;
        this.orderNo = orderNo;
        this.parent = parent;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return this.name;
    }

    public Integer getOrderNo() {
        return this.orderNo;
    }

    public Parent getParent() {
        return this.parent;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }

    public void setParent(Parent parent) {
        this.parent = parent;
    }

    public String toString() {
        return new ToStringBuilder(this).toString();
    }

}
