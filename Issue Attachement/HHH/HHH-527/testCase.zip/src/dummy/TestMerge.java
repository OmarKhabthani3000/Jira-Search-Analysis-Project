package dummy;

public class TestMerge extends TestBase {

    private static final int COUNT = 3;

    public void testMerge() throws Exception {
        Long id;
        {
            execHql("delete from Child");
            execHql("delete from Parent");

            Parent parent = new Parent();
            parent.setName("parent name");

            // add 3 children
            for (int i = 0; i < COUNT; i++) {
                Child child = new Child();
                child.setName("child name");
                child.setOrderNo(new Integer(i));
                parent.addChild(child);
            }

            id = (Long) save(parent);
            assertEquals(COUNT, count(Child.class));
        }
        restartSession();
        {
            Parent parent = (Parent) load(Parent.class, id);
            // clear all children
            parent.getChildren().clear();

            // add 3 new children
            for (int i = 0; i < COUNT; i++) {
                Child child = new Child();
                child.setName("child name");
                child.setOrderNo(new Integer(i));
                parent.addChild(child);
            }
            beginTrans();
            // session.flush(); //if flush before merge, test case run OK
            session.merge(parent);
            commit();
            assertEquals("there are 6 children!", COUNT * 2, count(Child.class));
        }
    }
}
