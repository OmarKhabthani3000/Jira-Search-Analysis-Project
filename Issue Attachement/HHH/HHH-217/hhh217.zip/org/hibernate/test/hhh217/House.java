package org.hibernate.test.hhh217;

import java.util.*;

public class House {

	private Integer _identity;
	private Person _owner;

	public House() {
	}

	public Integer getIdentity() {
		return _identity;
	}

	public void setIdentity(Integer id) {
		_identity = id;
	}

	public Person getOwner() {
		return _owner;
	}

	public void setOwner(Person p) {
		_owner = p;
	}
}

