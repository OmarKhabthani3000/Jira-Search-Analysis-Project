package org.hibernate.test.hhh217;

import java.util.*;

public class Room {

	private Integer _identity;
	private House _house;
	private Person _owner;

	public Room() {
	}

	public Integer getIdentity() {
		return _identity;
	}

	public void setIdentity(Integer id) {
		_identity = id;
	}

	public House getHouse() {
		return _house;
	}

	public void setHouse(House h) {
		_house = h;
	}

	public Person getOwner() {
		return _owner;
	}

	public void setOwner(Person p) {
		_owner = p;
	}
}

