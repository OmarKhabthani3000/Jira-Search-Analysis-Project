package org.hibernate.test.hhh217;

public class Person {

	private Integer _identity;
	private String _name;

	public Person() {
	}

	public Integer getIdentity() {
		return _identity;
	}

	public void setIdentity(Integer id) {
		_identity = id;
	}

	public String getName() {
		return _name;
	}

	public void setName(String s) {
		_name = s;
	}
}

