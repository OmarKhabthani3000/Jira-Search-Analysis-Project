package org.hibernate.test.hhh217;

import java.util.List;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.test.TestCase;

public class HHH217Test extends TestCase {

	public HHH217Test(String name) {
		super(name);
	}

	/**
	 * <a href="http://opensource.atlassian.com/projects/hibernate/browse/HHH-217">HHH-217</a>
	 */
	public void testHHH217() {
		Person p1 = new Person();
		p1.setName("first");

		Person p2 = new Person();
		p2.setName("second");

		House h1 = new House();
		h1.setOwner(p1);

		House h2 = new House();
		h2.setOwner(p2);

		Room r1 = new Room();
		r1.setHouse(h1);
		r1.setOwner(p1);

		Room r2 = new Room();
		r2.setHouse(h2);
		r2.setOwner(p2);

		Session s = openSession();
		Transaction t = s.beginTransaction();

		s.save(r1);
		s.save(r2);

		t.commit();
		s.close();

		s = openSession();
		t = s.beginTransaction();

		Query q = s.createQuery("select r from Room r left join fetch r.house order by r.identity");
		List result = q.list();

		Room r = (Room) result.get(0);
		House h = r.getHouse();

		t.commit();
		s.close();

		assertEquals("first", r.getOwner().getName());
		assertEquals("first", h.getOwner().getName());
	}

	protected String[] getMappings() {
		return new String[] {"hhh217/hhh217.hbm.xml"};
	}

	protected void configure(Configuration cfg) {
		cfg.setProperty(Environment.USE_QUERY_CACHE, "false");
		cfg.setProperty(Environment.USE_SECOND_LEVEL_CACHE, "false");
	}

	public static Test suite() {
		return new TestSuite(HHH217Test.class);
	}
}

