import static org.junit.Assert.assertEquals;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Before;
import org.junit.Test;

/**
 * Copyright © 2019 Lhasa Limited
 * File created: 05/07/2019 by davidb
 * Creator : davidb
 * Version : $$Id$$
 */
public class DefaultConditionsTest
{

	SessionFactory sessionFactory = new Configuration().configure()
			.buildSessionFactory();

	@Before
	public void setUp() {
		Service s1 = new Service("Service A");

		User u1 = new User("Mr. User");
		User u2 = new User("Mrs. User");

		ServiceUser su1 = new ServiceUser(s1, u1, true);
		ServiceUser su2 = new ServiceUser(s1, u2, false);

		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(s1);
		session.save(u1);
		session.save(u2);
		session.save(su1);
		session.save(su2);
		session.getTransaction().commit();
	}

	@Test
	public void defaultConditionsAppliedToFilterJoinTable(){
		Session session = sessionFactory.openSession();
		session.enableFilter("revFilter");
		@SuppressWarnings("unchecked")
		List<Service> services = session.createQuery("FROM Service").list();

		assertEquals(services.get(0).getUsers(), services.get(0).getUsersDefaultCondition());
		session.close();
	}

}