import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class ServiceUser
{
    @Id
    @GeneratedValue
    private int id;

    @Column(name = "HAS_ACCESS")
    private boolean hasAccess;

    @ManyToOne()
    @JoinColumn(name = "USER_ID")
    private User user;

    @ManyToOne()
    @JoinColumn(name = "SERVICE_ID")
    private Service service;

    public ServiceUser() {
    }

    public ServiceUser(Service service, User user, boolean hasAccess) {
        this.user = user;
        this.service = service;
        this.hasAccess = hasAccess;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getUser()
    {
        return user;
    }

    public void setUser(User user)
    {
        this.user = user;
    }

    public Service getService()
    {
        return service;
    }

    public void setService(Service service)
    {
        this.service = service;
    }

	public boolean isHasAccess()
	{
		return hasAccess;
	}

	public void setHasAccess(boolean hasAccess)
	{
		this.hasAccess = hasAccess;
	}

	@Override public String toString()
	{
		return "ServiceUser{" +
				"id=" + id +
				", hasAccess=" + hasAccess +
				", user=" + user +
				", service=" + service +
				'}';
	}
}