import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.FilterJoinTable;

@Entity
@FilterDef(name = "revFilter", defaultCondition = "(HAS_ACCESS = true)")
public class Service
{
    @Id
    @GeneratedValue
    private int id;

    @Column(name = "FULL_NAME")
    private String name;

    @ManyToMany
    @JoinTable(
            name = "ServiceUser",
            joinColumns = { @JoinColumn(name = "SERVICE_ID", referencedColumnName = "ID") },
            inverseJoinColumns = { @JoinColumn(name = "USER_ID", referencedColumnName = "ID") })
    @FilterJoinTable(name = "revFilter", condition = "(HAS_ACCESS = true)")
    private Set<User> users = new HashSet<>();

    @ManyToMany
    @JoinTable(
            name = "ServiceUser",
            joinColumns = { @JoinColumn(name = "SERVICE_ID", referencedColumnName = "ID") },
            inverseJoinColumns = { @JoinColumn(name = "USER_ID", referencedColumnName = "ID") })
    @FilterJoinTable(name = "revFilter")
    private Set<User> usersDefaultCondition = new HashSet<>();


    public Service() {
    }

    public Service(String name) {
        this.name = name;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<User> getUsers()
    {
        return users;
    }

    public void setUsers(Set<User> users)
    {
        this.users = users;
    }

    public Set<User> getUsersDefaultCondition()
    {
        return usersDefaultCondition;
    }

    public void setUserDefaultCondition(Set<User> authorsDefaultCondition)
    {
        this.usersDefaultCondition = authorsDefaultCondition;
    }

	@Override public String toString()
	{
		return "Service{" +
				"id=" + id +
				", name='" + name + '\'' +
				", users=" + users +
				", usersDefaultCondition=" + usersDefaultCondition +
				'}';
	}
}