package org.hibernate.bugs;

/**
 * @author  Vlad Mihalcea
 */
public class TopicSummary {

	private Long id;

	private String title;

	public TopicSummary(Long id, String title) {
		this.id = id;
		this.title = title;
	}

	public Long getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}
}
