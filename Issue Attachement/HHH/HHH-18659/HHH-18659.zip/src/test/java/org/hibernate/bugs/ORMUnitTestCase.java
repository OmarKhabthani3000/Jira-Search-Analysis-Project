/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.BootstrapServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.boot.registry.internal.StandardServiceRegistryImpl;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.dialect.Dialect;
import org.hibernate.dialect.H2Dialect;
import org.hibernate.internal.util.config.ConfigurationHelper;
import org.hibernate.resource.jdbc.spi.JdbcSessionOwner;

import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import net.ttddyy.dsproxy.QueryCountHolder;
import net.ttddyy.dsproxy.listener.ChainListener;
import net.ttddyy.dsproxy.listener.DataSourceQueryCountListener;
import net.ttddyy.dsproxy.listener.logging.SystemOutQueryLoggingListener;
import net.ttddyy.dsproxy.support.ProxyDataSourceBuilder;
import org.h2.jdbcx.JdbcDataSource;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 *
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class<?>[] {
				Post.class
		};
	}

	// If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
	@Override
	protected String[] getMappings() {
		return new String[] {
//				"Foo.hbm.xml",
//				"Bar.hbm.xml"
		};
	}

	// If those mappings reside somewhere other than resources/org/hibernate/test, change this.
	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/test/";
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );

		configuration.setProperty( AvailableSettings.DIALECT, getDialect().getClass().getName() );
		configuration.setProperty( AvailableSettings.STATEMENT_BATCH_SIZE, "10" );
		configuration.setProperty( AvailableSettings.ORDER_INSERTS, Boolean.TRUE.toString() );
		configuration.setProperty( AvailableSettings.ORDER_UPDATES, Boolean.TRUE.toString() );

		JdbcDataSource actualDataSource = new JdbcDataSource();
		actualDataSource.setURL( "jdbc:h2:mem:db1;DB_CLOSE_DELAY=-1" );
		actualDataSource.setUser( "sa" );
		actualDataSource.setPassword( "" );

		ChainListener listener = new ChainListener();
		listener.addListener( new SystemOutQueryLoggingListener() );
		listener.addListener( new DataSourceQueryCountListener() );

		configuration.getProperties().put(
				AvailableSettings.DATASOURCE,
				ProxyDataSourceBuilder
						.create( actualDataSource )
						.name( "DataSourceProxy" )
						.listener( listener )
						.build()
		);
		configuration.getProperties().remove( AvailableSettings.CONNECTION_PROVIDER );
		//configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, "true" );
	}

	@Override
	protected StandardServiceRegistryImpl buildServiceRegistry(
			BootstrapServiceRegistry bootRegistry,
			Configuration configuration) {
		try {
			Properties properties = new Properties();
			properties.putAll( configuration.getProperties() );
			ConfigurationHelper.resolvePlaceHolders( properties );

			StandardServiceRegistryBuilder cfgRegistryBuilder = configuration.getStandardServiceRegistryBuilder();

			StandardServiceRegistryBuilder registryBuilder = new StandardServiceRegistryBuilder( bootRegistry, cfgRegistryBuilder.getAggregatedCfgXml() )
					.applySettings( properties );

			prepareBasicRegistryBuilder( registryBuilder );
			return (StandardServiceRegistryImpl) registryBuilder.build();
		}
		catch (Throwable t) {
			if ( bootRegistry != null ) {
				bootRegistry.close();
			}
			throw t;
		}
	}

	protected static Dialect getDialect() {
		return new H2Dialect();
	}

	// Add your tests, using standard JUnit.
	@Test
	public void test() {
		// BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
		{
			final AtomicBoolean statelessSessionTransactionStatus = new AtomicBoolean();

			Session session = openSession();
			Transaction tx = session.getTransaction();
			tx.begin();

			final StatelessSession statelessSession = sessionFactory()
					.openStatelessSession(
							session.doReturningWork( connection -> connection )
					);
			try {
				statelessSession.setJdbcBatchSize( 20 );

				QueryCountHolder.clear();

				for ( int i = 0; i < 10; i++ ) {
					statelessSession.insert( new Post().setContent( "Hibernate" ) );
				}

				statelessSessionTransactionStatus.set( statelessSession.getTransaction().isActive() );

				int postCount = ( (Number) session.createQuery( "select count(p) from Post p" )
						.getSingleResult() ).intValue();
				assertEquals( 10, postCount );
				assertEquals( 1, QueryCountHolder.getGrandTotal().getInsert() );
			}
			catch (Exception e) {
				throw new HibernateException( e );
			}
			finally {
				JdbcSessionOwner jdbcSessionOwner = ( (JdbcSessionOwner) statelessSession );
				jdbcSessionOwner.flushBeforeTransactionCompletion();
				statelessSession.close();
			}

			tx.commit();
			session.close();

			assertTrue( statelessSessionTransactionStatus.get() );
		}
	}

	@Entity(name = "Post")
	@Table(name = "post")
	public static class Post {

		@Id
		@GeneratedValue
		private Long id;

		private String content;

		public String getContent() {
			return content;
		}

		public Post setContent(String content) {
			this.content = content;
			return this;
		}
	}
}
