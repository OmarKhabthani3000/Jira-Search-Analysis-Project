package vdo.test.hibernate;

import java.util.List;

import javax.naming.InitialContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class ActionDAO {

 private static final Log log = LogFactory.getLog(ActionDAO.class);

 private final SessionFactory sessionFactory = getSessionFactory();

 protected SessionFactory getSessionFactory() {
     try {
         return (SessionFactory) new InitialContext()
                 .lookup("SessionFactory");
     } catch (Exception e) {
         log.error("Could not locate SessionFactory in JNDI", e);
         throw new IllegalStateException(
                 "Could not locate SessionFactory in JNDI");
     }
 }

 public void saveOrUpdate(Action transientInstance) {
 log.debug("saving or updating Action instance");
 try {
     Transaction tx = sessionFactory.getCurrentSession().beginTransaction();
     sessionFactory.getCurrentSession().saveOrUpdate(transientInstance);
     sessionFactory.getCurrentSession().flush();
     log.debug("saveOrUpdate successful");
     tx.commit();
 } catch (HibernateException re) {
     log.error("saveOrUpdate failed", re);
     throw re;
 }
}

 public void attachDirty(Action instance) {
     log.debug("attaching dirty Action instance");
     try {
         sessionFactory.getCurrentSession().saveOrUpdate(instance);
         log.debug("attach successful");
     } catch (HibernateException re) {
         log.error("attach failed", re);
         throw re;
     }
 }

 public void attachClean(Action instance) {
     log.debug("attaching clean Action instance");
     try {
         sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
         log.debug("attach successful");
     } catch (HibernateException re) {
         log.error("attach failed", re);
         throw re;
     }
 }

 public void delete(Action action) {
     log.debug("deleting Action instance");
     try {
         Transaction tx = sessionFactory.getCurrentSession().beginTransaction();
         //Suppression de Action du Set Parcours
         //Parcours parcours = action.getParcours();
         //parcours.getActions().remove(action);
         //Suppression de action
         sessionFactory.getCurrentSession().delete(action);
         //Sauvegarde de Parcours
         //sessionFactory.getCurrentSession().saveOrUpdate(parcours);
         sessionFactory.getCurrentSession().flush();
         log.debug("delete successful");
         tx.commit();
     } catch (HibernateException re) {
         log.error("delete failed", re);
         throw re;
     }
 }

 public Action merge(Action detachedInstance) {
     log.debug("merging Action instance");
     try {
         Transaction tx = sessionFactory.getCurrentSession().beginTransaction();
         Action result = (Action) sessionFactory.getCurrentSession().merge(detachedInstance);
         log.debug("merge successful");
         tx.commit();
         return result;
     } catch (HibernateException re) {
         log.error("merge failed", re);
         throw re;
     }
 }

 public Action findById(Integer id) {
     try {
         Transaction tx = sessionFactory.getCurrentSession().beginTransaction();
         Action instance = (Action) sessionFactory.getCurrentSession().get("vdo.test.hibernate.Action", id);
         if (instance == null) {
             log.debug("get successful, no instance found");
         } else {
             log.debug("get successful, instance found");
         }
         tx.commit();
         return instance;
     } catch (HibernateException re) {
         log.error("findById Action failed", re);
         throw re;
     }
 }

 public List<Action> findByUtilisateur(String utilisateurIdent) {
     try {
         Transaction tx = sessionFactory.getCurrentSession().beginTransaction();
         List<Action> results = (List<Action>) sessionFactory
                 .getCurrentSession().createQuery("from vdo.test.hibernate.Action where utilisateur.identifiant = ?")
                 .setString(0,utilisateurIdent)
                 .list();
         log.debug("findByUtilisateur Action successful, result size: "+ results.size());
         tx.commit();
         return results;
     } catch (HibernateException re) {
         log.error("findByUtilisateur Action failed", re);
         throw re;
     }
 }

 public List<Action> findAll() {
     try {
         Transaction tx = sessionFactory.getCurrentSession().beginTransaction();
     List<Action> results = (List<Action>) sessionFactory
                 .getCurrentSession().createQuery("from vdo.test.hibernate.Action").list();
         log.debug("findAll Action successful, result size: "
                 + results.size());
         tx.commit();
         return results;
     } catch (HibernateException re) {
         log.error("findAll Action failed", re);
         throw re;
     }
 }
}