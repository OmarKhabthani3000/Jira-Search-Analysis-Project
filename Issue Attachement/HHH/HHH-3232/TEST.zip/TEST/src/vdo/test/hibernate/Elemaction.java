package vdo.test.hibernate;

import vdo.test.hibernate.Action;


public class Elemaction implements Comparable {

	private int id;
	private String libelle;
	private Action action;

	public Elemaction() {

	}

	public Elemaction(int id, String libelle, Action action) {
		this.id = id;
		this.libelle = libelle;
		this.action = action;
	}

	public Action getAction() {
		return action;
	}

	public void setAction(Action action) {
		this.action = action;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public int compareTo(Object o) {
        if (!(o instanceof Elemaction)) return 0;
        Elemaction el = (Elemaction)o;
        int resultat = this.libelle.compareTo(el.getLibelle());
        return resultat;
    }
}
