package vdo.test.hibernate;

import java.util.Set;
import java.util.TreeSet;

public class Action {

	private int id;
    private Set elemaction;

	public Action() {
		//elemaction = new HashSet<Elemaction>();
		elemaction = new TreeSet<Elemaction>();
	}

	public Action(int id) {
		this.id = id;

		elemaction = new TreeSet<Elemaction>();
	}

	public Set getElemaction() {
		return elemaction;
	}

	public void setElemaction(Set elemaction) {
		this.elemaction = elemaction;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


}
