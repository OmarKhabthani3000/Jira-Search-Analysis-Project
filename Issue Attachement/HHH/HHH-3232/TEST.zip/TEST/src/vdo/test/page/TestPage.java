package vdo.test.page;

import java.util.List;

import net.sf.click.control.ActionLink;
import net.sf.click.control.Column;
import net.sf.click.control.FieldSet;
import net.sf.click.control.Form;
import net.sf.click.control.HiddenField;
import net.sf.click.control.Submit;
import net.sf.click.control.Table;
import net.sf.click.control.TextField;
import net.sf.click.extras.control.LinkDecorator;
import vdo.test.hibernate.Action;
import vdo.test.hibernate.ActionDAO;
import vdo.test.hibernate.Elemaction;
import vdo.test.hibernate.ElemactionDAO;

public class TestPage extends BorderPage {

	public String titre = "Test Sort Hibernate";
	protected String dateFormat = "dd-MM-yyyy";

	//Appel pour mise � jour Action
	private Action action = new Action();

    public Table table = new Table();

    //Actions de gestion
    public ActionLink addLink = new ActionLink("add", "Ajouter une �tape", this,"onAddElem");
    public ActionLink editLink = new ActionLink("edit", "Modifier une �tape", this,"onEditElem");
    public ActionLink deleteLink = new ActionLink("delete", "Supprimer une �tape", this,"onDeleteElem");

    public Form formelt = new Form();
    FieldSet fieldSet   = new FieldSet("<strong>Formulaire</strong>");

    Submit closeButton  = new Submit("Fermer le Parcours", this, "onCloseParcours");

    //R�cup�ration de l'Action d'apr�s id
	public String actionId = "";

    //constructeur par d�faut
    public TestPage() {

        // Tableau d'affichage des formations
        table.setClass("cgvo");
        table.setSortable(true);
        table.setHoverRows(true);

        table.addColumn(new Column("libelle","Etape"));


        Column column = new Column("");

        //Ic�nes
        addLink.setImageSrc("img/add.png");
        editLink.setImageSrc("img/edit.png");
        deleteLink.setImageSrc("img/delete.png");

        ActionLink[] links = new ActionLink[] { addLink, editLink, deleteLink };
        column.setDecorator(new LinkDecorator(table, links, "id"));
        table.addColumn(column);

        //Formulaire de mise � jour d'une formation
    	formelt.setErrorsPosition("middle");
    	formelt.setButtonAlign("center");
    	formelt.setLabelAlign("right");

    	//Id - Champ cach� pour mise � jour
    	HiddenField idField = new HiddenField("id",Integer.class);
    	fieldSet.add(idField);

    	//Libelle
    	TextField libelle = new TextField("libelle");
    	fieldSet.add(libelle);

        formelt.add(fieldSet);

        //ajout d'un contr�le javascript � la suppression
        deleteLink.setAttribute("onclick","return window.confirm('Confirmez-vous la suppression de cette �tape ?');");
    }

//  Initialisation de la page
    public void onInit() {

    	actionId = "1";

    	//Si l'id de l'action est renseign� et que l'on n'est pas en Post (Bouton Enregistrer)
    	if (actionId != null && !getContext().isPost()) {
    		//On r�cup�re le parcours de l'identifiant action pass� en param�tre
    		action = new ActionDAO().findById(new Integer(actionId));
    		//Mise en session de l'action
    		getContext().setSessionAttribute("action",action);
    	} else {
    		//On r�cup�re l'action de la session
    		action = (Action)getContext().getSessionAttribute("action");
    	}

        //ajout des boutons actions au formulaire
        Submit saveElemButton = new Submit("Enregistrer", this, "onSaveElem");
        saveElemButton.setAttribute("class","button1");
        formelt.add(saveElemButton);
        Submit clearElemButton = new Submit("Initialiser", this, "onClearElem");
        clearElemButton.setAttribute("class","button1");
        formelt.add(clearElemButton);

        InitListe();
    }


    private void InitListe() {
        //on affecte la liste des �l�ments de l'action
    	List elementsAction = new ElemactionDAO().findByAction(action);
        table.setRowList(elementsAction);

        //D�sactivation Bouton Fermer si pas d'�tape saisie
        if (elementsAction.isEmpty()) closeButton.setDisabled(true);
        else closeButton.setDisabled(false);
    }

    // cette fonction est utilis�e � chaque POST
    public void onPost() {
        InitListe();
    }

    // cette fonction est utilis�e � chaque GET
    public void onGet() {
    	InitListe();
    }


    // Action si clique sur le lien Ajouter
    public boolean onAddElem() {
    	fieldSet.setName("<b>Ajouter une �tape</b>");
    	formelt.clearValues();
        return true;
    }

    // Action si clique sur le lien Modifier
    public boolean onEditElem() {
        //on r�cup�re l'id du lien
        String id = editLink.getValue();
        //on recherche l'�l�ment par la classe DAO
        Elemaction elemaction = new ElemactionDAO().findById(Integer.parseInt(id));
        fieldSet.setName("<b>Modifier une �tape</b>");
        // si on trouve, on affecte l'�l�ment au formulaire
        if (elemaction != null) {
        	//Copie des donn�es elemaction dans form
            formelt.copyFrom(elemaction);

            //Mise � jour des options s�lectionn�es de la CheckList
        	//resultatMulti.setValues(tokenizeCheckList(elemaction.getResultatMulti()));
        }
        return true;
    }

    //Action si clique sur le lien Supprimer
    public boolean onDeleteElem() {
        //on r�cup�re l'id du lien
    	//String id = deleteLink.getValue();
        //on recherche l'�l�ment par la classe DAO
    	//Elemaction elemaction = new ElemactionDAO().findById(Integer.parseInt(id));
        //on le supprime
        //ew ElemactionDAO().deleteAndFlag(elemaction);
        return true;
    }

    //Action si on sauvegarde un �l�ment
    public boolean onSaveElem() {
        // si le formulaire est correctement rempli
        if (formelt.isValid()) {
        	Elemaction elemaction = new Elemaction();
            //on r�cup�re l'�l�ment renvoy� par le formulaire
            formelt.copyTo(elemaction);

        }
        return true;
    }

    // efface tous les champs du formulaire
    public boolean onClearElem() {
        formelt.clearValues();
        return true;
    }
}