package vdo.test.hibernate;

import java.util.List;

import javax.naming.InitialContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class ElemactionDAO {

 private static final Log log = LogFactory.getLog(ElemactionDAO.class);

 private final SessionFactory sessionFactory = getSessionFactory();

 protected SessionFactory getSessionFactory() {
     try {
         return (SessionFactory) new InitialContext().lookup("SessionFactory");
     } catch (Exception e) {
         log.error("Could not locate SessionFactory in JNDI", e);
         throw new IllegalStateException(
                 "Could not locate SessionFactory in JNDI");
     }
 }

 public void saveOrUpdate(Elemaction elemaction) {
     log.debug("saveOrUpdating Elemaction instance");
     try {
         Transaction tx = sessionFactory.getCurrentSession().beginTransaction();
         sessionFactory.getCurrentSession().saveOrUpdate(elemaction);
         log.debug("saveOrUpdating successful");
         tx.commit();
     } catch (HibernateException re) {
         log.error("saveOrUpdating failed", re);
         throw re;
     }
 }

 public void attachClean(Elemaction instance) {
     log.debug("attaching clean Elemaction instance");
     try {
         sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
         log.debug("attach successful");
     } catch (HibernateException re) {
         log.error("attach failed", re);
         throw re;
     }
 }

 public Elemaction merge(Elemaction elemaction) {
     log.debug("merging Elemaction instance");
     try {
         Transaction tx = sessionFactory.getCurrentSession().beginTransaction();
         Elemaction result = (Elemaction) sessionFactory.getCurrentSession().merge(elemaction);
         log.debug("merging Elemaction successful");
         tx.commit();
         return result;
     } catch (HibernateException re) {
         log.error("merging Elemaction failed", re);
         throw re;
     }
 }


 public void delete(Elemaction elemaction) {
     log.debug("deleting Elemaction instance");
     try {
         Transaction tx = sessionFactory.getCurrentSession().beginTransaction();
         //Suppression de Elemaction du Set Action
         //Action action = elemaction.getAction();
         //action.getElemaction().remove(elemaction);
         //Suppression de elemaction
         sessionFactory.getCurrentSession().delete(elemaction);
         //Sauvegarde de Action
         //sessionFactory.getCurrentSession().saveOrUpdate(action);
         sessionFactory.getCurrentSession().flush();
         log.debug("deleting Elemaction successful");
         tx.commit();
     } catch (HibernateException re) {
         log.error("deleting Elemaction failed", re);
         throw re;
     }
 }



 public Elemaction findById(Integer id) {
     try {
         Transaction tx = sessionFactory.getCurrentSession().beginTransaction();
         Elemaction instance = (Elemaction) sessionFactory.getCurrentSession().get("vdo.test.hibernate.Elemaction", id);
         if (instance == null) {
             log.debug("get successful, no instance found");
         } else {
             log.debug("get successful, instance found");
         }
         tx.commit();
         return instance;
     } catch (HibernateException re) {
         log.error("findById Elemaction failed", re);
         throw re;
     }
 }

 public List<Elemaction> findByAction(Action action) {
     try {
         Transaction tx = sessionFactory.getCurrentSession().beginTransaction();
         List<Elemaction> results = (List<Elemaction>) sessionFactory
                 .getCurrentSession().createQuery("from vdo.test.hibernate.Elemaction where action = ? order by libelle")
                 .setEntity(0,action)
                 .list();
         log.debug("findByAction Elemaction successful, result size: "
                 + results.size());
         tx.commit();
         return results;
     } catch (HibernateException re) {
         log.error("findByAction Elemaction failed", re);
         throw re;
     }
 }

 public List<Elemaction> findAll() {
     try {
         Transaction tx = sessionFactory.getCurrentSession().beginTransaction();
     List<Elemaction> results = (List<Elemaction>) sessionFactory
                 .getCurrentSession().createQuery("from vdo.test.hibernate.Elemaction")
                 .list();
         log.debug("findAll Elemaction successful, result size: "
                 + results.size());
         tx.commit();
         return results;
     } catch (HibernateException re) {
         log.error("findAll Elemaction failed", re);
         throw re;
     }
 }
}