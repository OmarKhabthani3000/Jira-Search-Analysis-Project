/**
 *
 */
package org.martingilday.hibernate;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;


/**
 * @author martin.gilday
 *
 */
public class JodaLocalDateTimeUserType extends AbstractImmutableUserType {
	
	private static final DateTimeFormatter TIMESTAMP_FORMAT =
		DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
	
	/* (non-Javadoc)
	 * @see org.hibernate.usertype.UserType#sqlTypes()
	 */
	public int[] sqlTypes() {
		return new int[] { Hibernate.TIMESTAMP.sqlType() };
	}

	/* (non-Javadoc)
	 * @see org.hibernate.usertype.UserType#returnedClass()
	 */
	public Class returnedClass() {
		return LocalDateTime.class;
	}

	/* (non-Javadoc)
	 * @see org.hibernate.usertype.UserType#nullSafeGet(java.sql.ResultSet, java.lang.String[], java.lang.Object)
	 */
	public Object nullSafeGet(ResultSet rs, String[] names, Object owner)
			throws HibernateException, SQLException {
		
		String timestampString = (String) rs.getObject(names[0]);
		if (null == timestampString){
			return null;
		}

		DateTime dateTime = TIMESTAMP_FORMAT.parseDateTime(timestampString);
		return dateTime.toLocalDateTime();
	}

	/* (non-Javadoc)
	 * @see org.hibernate.usertype.UserType#nullSafeSet(java.sql.PreparedStatement, java.lang.Object, int)
	 */
	public void nullSafeSet(PreparedStatement st, Object value, int index)
			throws HibernateException, SQLException {
		
		if(null == value) {
			st.setNull(index, Hibernate.STRING.sqlType());
		} else {
			LocalDateTime localDateTime = (LocalDateTime)value;
			String timestampTimeString = localDateTime.toString(TIMESTAMP_FORMAT);
			st.setString(index, timestampTimeString);
		}
	}
}
