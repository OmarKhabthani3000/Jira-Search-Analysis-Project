/**
 *
 */
package org.martingilday.hibernate;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;


/**
 * @author martin.gilday
 *
 */
public class JodaLocalDateUserType extends AbstractImmutableUserType {
	
	private static final DateTimeFormatter DATE_FORMAT =
		DateTimeFormat.forPattern("yyyy-MM-dd");

	/* (non-Javadoc)
	 * @see org.hibernate.usertype.UserType#sqlTypes()
	 */
	public int[] sqlTypes() {
		return new int[] { Hibernate.DATE.sqlType() };
	}

	/* (non-Javadoc)
	 * @see org.hibernate.usertype.UserType#returnedClass()
	 */
	public Class returnedClass() {
		return LocalDate.class;
	}

	/* (non-Javadoc)
	 * @see org.hibernate.usertype.UserType#nullSafeGet(java.sql.ResultSet, java.lang.String[], java.lang.Object)
	 */
	public Object nullSafeGet(ResultSet rs, String[] names, Object owner)
			throws HibernateException, SQLException {

		String dateString = (String) rs.getObject(names[0]);
		if (null == dateString){
			return null;
		}

		DateTime dateTime = DATE_FORMAT.parseDateTime(dateString);
		return dateTime.toLocalDate();
	}

	/* (non-Javadoc)
	 * @see org.hibernate.usertype.UserType#nullSafeSet(java.sql.PreparedStatement, java.lang.Object, int)
	 */
	public void nullSafeSet(PreparedStatement st, Object value, int index)
			throws HibernateException, SQLException {

		if(null == value) {
			st.setNull(index, Hibernate.STRING.sqlType());
		} else {
			LocalDate localDate = (LocalDate)value;
			String dateString = localDate.toString(DATE_FORMAT);
			st.setString(index, dateString);
		}
	}
}