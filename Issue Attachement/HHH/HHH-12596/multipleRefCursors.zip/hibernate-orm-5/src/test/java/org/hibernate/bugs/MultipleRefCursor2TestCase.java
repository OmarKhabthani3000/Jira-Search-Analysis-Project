package org.hibernate.bugs;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.*;
import java.util.List;

/**
 * Attempts to read two cursors - with a hasMoreResults call between the first and second cursor.
 */
public class MultipleRefCursor2TestCase {
    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void multipleRefCursorTestCase() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        entityManager.createNativeQuery("CREATE OR REPLACE PACKAGE SCOTT.HR_DATA IS " +
                "  PROCEDURE GETCURSORS (" +
                "    EMP_ID IN NUMBER, " +
                "    EMP_C OUT SYS_REFCURSOR, " +
                "    DEPT_C OUT SYS_REFCURSOR);" +
                "END HR_DATA;").executeUpdate();

        entityManager.createNativeQuery("CREATE OR REPLACE PACKAGE BODY SCOTT.HR_DATA IS" +
                "   PROCEDURE GETCURSORS (" +
                "    EMP_ID IN NUMBER, " +
                "    EMP_C OUT SYS_REFCURSOR, " +
                "    DEPT_C OUT SYS_REFCURSOR) IS" +
                "     BEGIN " +
                "     OPEN EMP_C FOR" +
                "          SELECT * FROM SCOTT.EMP;" +
                "     OPEN DEPT_C FOR" +
                "          SELECT * FROM SCOTT.DEPT;" +
                "    END GETCURSORS;" +
                "END HR_DATA; ").executeUpdate();

        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("SCOTT.HR_DATA.GETCURSORS")
                .registerStoredProcedureParameter("EMP_ID", Integer.class, ParameterMode.IN).setParameter("EMP_ID", 4)
                .registerStoredProcedureParameter("EMP_C", Class.class, ParameterMode.REF_CURSOR)
                .registerStoredProcedureParameter("DEPT_C", Class.class, ParameterMode.REF_CURSOR);

        storedProcedureQuery.execute();

        List<Object[]> empCursor = storedProcedureQuery.getResultList();
        Assert.assertNotNull(empCursor);
        Assert.assertTrue(empCursor.size() > 0);

        storedProcedureQuery.hasMoreResults();

        List<Object[]> deptCursor = storedProcedureQuery.getResultList();
        Assert.assertNotNull(deptCursor);
        Assert.assertTrue(deptCursor.size() > 0);

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
