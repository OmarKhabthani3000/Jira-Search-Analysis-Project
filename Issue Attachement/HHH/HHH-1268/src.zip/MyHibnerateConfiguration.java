import org.hibernate.cfg.*;

/**
 * User: rex
 * Date: Dec 13, 2005
 * Time: 8:02:12 PM
 */
public class MyHibnerateConfiguration extends AnnotationConfiguration {
   public MyHibnerateConfiguration() {

      super.configure("hibernate.cfg.xml");
      super.addAnnotatedClass(Parent.class);
      super.addAnnotatedClass(Child.class);
   }
}
