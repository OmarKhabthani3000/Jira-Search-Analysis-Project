import org.hibernate.*;
import org.hibernate.cfg.*;

/**
 * User: rex
 * Date: Dec 13, 2005
 * Time: 7:35:50 PM
 */
public class UnidirectionalOneToManyRemoveFromListBug {


   public static void main(String[] args) {
      SessionFactory sessFactory = initSessionFactory();
      Session session = sessFactory.openSession();

      Parent parent = new Parent();
      parent.getChildren().add(new Child());
      parent.getChildren().add(new Child());
      parent.getChildren().add(new Child());

      session.saveOrUpdate(parent);
      session.flush();



      parent.getChildren().remove(0);
      session.flush();




   }

   private static SessionFactory initSessionFactory() {
      MyHibnerateConfiguration cfg = new MyHibnerateConfiguration();



      SessionFactory sessFactory = cfg.buildSessionFactory();

      return sessFactory;
   }

}
