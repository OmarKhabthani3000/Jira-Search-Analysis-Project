import org.hibernate.annotations.*;

import javax.persistence.*;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.*;

@Entity()
@Table(name="parent")
public class Parent {



   private List<Child> children = new ArrayList<Child>();
   private int id;

   @Id(generate = GeneratorType.AUTO)
   public int getId() {
      return id;
   }

   public void setId(int id) {
      this.id = id;
   }


   @OneToMany(targetEntity = Child.class, cascade=CascadeType.ALL)
   @IndexColumn(name = "pos")
   public List<Child> getChildren() {
      return children;
   }

   public void setChildren(List<Child> children) {
      this.children = children;
   }


}
