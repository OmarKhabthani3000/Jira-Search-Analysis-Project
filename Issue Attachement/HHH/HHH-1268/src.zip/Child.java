import javax.persistence.*;


@Entity()
@Table(name = "child")
public class Child {
   private int id;

   @Id(generate = GeneratorType.AUTO)
   public int getId() {
      return id;
   }

   public void setId(int id) {
      this.id = id;
   }
}
