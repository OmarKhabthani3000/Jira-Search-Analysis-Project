package com.synconia.bookstore.ddl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.EnumSet;
import java.util.Set;
import javax.transaction.Transactional;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.boot.spi.MetadataImplementor;
import org.hibernate.dialect.Dialect;
import org.hibernate.dialect.MySQL57Dialect;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.hibernate.tool.schema.TargetType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

@Rollback
@SpringBootTest
@Transactional
@RunWith(SpringRunner.class)
public class DDLGen {

  @Test
  public void test() throws Exception {
    // String dialectName = "org.hibernate.dialect.MySQL57Dialect";
    // generate((Class<? extends Dialect>)Class.forName(dialectName));
    generate(MySQL57Dialect.class);
  }

  public void generate(Class<? extends Dialect> dialectClass) throws Exception {
    // String url  	= "jdbc:mysql://localhost:3306/dbName";
    // String user 	= "dbUser";
    // String password = "dbPassword";
    String entityPackage = "com.synconia.bookstore.entity";
    String outputDirectory = "sql";
    Connection connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
    // Connection connection = DriverManager.getConnection(url, user, password);
    StandardServiceRegistry serviceRegistry =
        new StandardServiceRegistryBuilder()
            .applySetting("hibernate.dialect", dialectClass.getName())
            .applySetting("javax.persistence.schema-generation-connection", connection)
            .build();
    MetadataSources metadata = new MetadataSources(serviceRegistry);
    Reflections reflections = new Reflections(entityPackage, new SubTypesScanner(false));
    Set<Class<? extends Object>> allClasses = reflections.getSubTypesOf(Object.class);
    for (Class<?> clazz : allClasses) {
      metadata.addAnnotatedClass(clazz);
    }
    final String fileName =
        String.format("./%s/ddl_%s.sql", outputDirectory, dialectClass.getSimpleName());
    SchemaExport export = new SchemaExport();
    MetadataImplementor metadataImplementor = (MetadataImplementor) metadata.buildMetadata();
    export.setDelimiter(";");
    export.setOutputFile(fileName);
    export.setFormat(true);
    export.create(EnumSet.of(TargetType.SCRIPT), metadataImplementor);
    // export.create(EnumSet.of(TargetType.DATABASE), metadataImplementor);
  }
}
