package com.synconia.bookstore.entity;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyClass;
import javax.persistence.MapKeyColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "BOOK")
public class Book implements Identifiable<Long> {
	static final long serialVersionUID = 1L;

	public Book() {

	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;

	@Column(name = "ISBN", nullable = false, length = 255)
	@NotNull
	@Size(min = 3, max = 255)
	private String isbn;

	@Column(name = "PREIS", nullable = false)
	@NotNull
	private BigDecimal preis;

	@ElementCollection(targetClass = BookTranslation.class, fetch = FetchType.LAZY)
	@CollectionTable(name = "BOOK_TRANSLATION", joinColumns = @JoinColumn(name = "BOOK_ID"))
	@MapKeyClass(String.class)
	@MapKeyColumn(name = "LANGUAGE_KEY")
	private Map<String, BookTranslation> translations = new HashMap<>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public BigDecimal getPreis() {
		return preis;
	}

	public void setPreis(BigDecimal preis) {
		this.preis = preis;
	}

	public Map<String, BookTranslation> getTranslations() {
		return translations;
	}

	public void setTranslations(Map<String, BookTranslation> translations) {
		this.translations = translations;
	}

	public BookTranslation getOrCreateTranslation(String languageKey) {
		BookTranslation tr = getTranslations().get(languageKey);
		if (tr == null) {
			tr = new BookTranslation();
			translations.put(languageKey, tr);
		}
		return tr;
	}

	public BookTranslation removeTranslation(String languageKey) {
		return getTranslations().remove(languageKey);
	}

	public String getName(String languageKey) {
		return getOrCreateTranslation(languageKey).getName();
	}

	public void setName(String languageKey, String name) {
		getOrCreateTranslation(languageKey).setName(name);
	}

	public String getDescription(String languageKey) {
		return getOrCreateTranslation(languageKey).getDescription();
	}

	public void setDescription(String languageKey, String description) {
		getOrCreateTranslation(languageKey).setDescription(description);
	}

	public ImageObject getCover(String languageKey) {
		return getOrCreateTranslation(languageKey).getCover();
	}

	public void setCover(String languageKey, ImageObject cover) {
		getOrCreateTranslation(languageKey).setCover(cover);
	}

	@Override
	public String toString() {
		String NL = System.lineSeparator();
		StringBuilder sb = new StringBuilder();
		sb.append("[id]: ").append(getId()).append(NL);
		sb.append("[isbn]: ").append(getIsbn()).append(NL);
		sb.append("[preis]: ").append(getPreis()).append(NL);
		// sb.append("[translations]: ").append(getTranslations()).append(NL);
		return sb.toString();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || this.getClass() != obj.getClass()) {
			return false;
		}
		Book other = (Book) obj;
		return this.getId() != null && Objects.equals(this.getId(), other.getId());
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(this.getId());
	}

}
