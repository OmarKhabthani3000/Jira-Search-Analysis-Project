package com.synconia.bookstore.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Transient;

@Embeddable
public class ImageObject {

	@Column(name = "LOB_BUCKET_NAME", nullable = true, length = 63)
	private String bucketName;

	@Column(name = "LOB_OBJECT_NAME", nullable = true, length = 1024)
	private String objectName;

	@Column(name = "LOB_STATUS", nullable = false)
	private Status status = Status.NEW;

	@Transient
	private ReferenceType referenceType;

	public ImageObject() {
		this.referenceType = ReferenceType.IMAGE;
	}

	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}

	public String getBucketName() {
		return bucketName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(String enumValue) {
		status = enumValue != null ? Status.valueOf(enumValue) : null;
	}

	public ReferenceType getReferenceType() {
		return referenceType;
	}

//	public void setReferenceType(ReferenceType referenceType) {
//		this.referenceType = referenceType;
//	}

	public enum ReferenceType {
		IMAGE,

		VIDEO,

		AUDIO,

		BYTE,

		PDF
	}

	public enum Status {
		NEW,

		READY,

		UPLOADING,

		ERROR,

		DELETING,

		DELETED
	}
}
