package com.synconia.bookstore.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.FetchType;
import javax.persistence.Lob;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Embeddable
public class BookTranslation {
	@Column(name = "NAME", nullable = false, length = 255)
	@NotNull
	@Size(min = 3, max = 255)
	private String name;

	@Column(name = "DESCRIPTION", nullable = true)
	@Lob
	@Basic(fetch = FetchType.EAGER)
	private String description;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "bucketName", column = @Column(name = "COVER_BUCKET_NAME", nullable = true, length = 63)),
			@AttributeOverride(name = "objectName", column = @Column(name = "COVER_OBJECT_NAME", nullable = true, length = 1024)),
			@AttributeOverride(name = "status", column = @Column(name = "COVER_UPLOAD_STATUS", nullable = true)) })
	private ImageObject cover;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public ImageObject getCover() {
		return cover;
	}

	public void setCover(ImageObject cover) {
		this.cover = cover;
	}
}
