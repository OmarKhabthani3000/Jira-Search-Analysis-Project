package com.synconia.bookstore.entity;

public interface Identifiable<ID> {

	ID getId();
}
