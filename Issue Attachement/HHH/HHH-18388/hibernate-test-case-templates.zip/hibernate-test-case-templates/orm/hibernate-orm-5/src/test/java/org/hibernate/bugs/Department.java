package org.hibernate.bugs;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import java.util.*;

@Entity
class Department extends BazeEntity {
    @Column(nullable = false)
    private String code;

    @Column(name = "manager_entity_id", nullable = false)
    private UUID managerEntityId;

    @Column(name = "vice_manager_entity_id")
    private UUID viceManagerEntityId;

    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.REFRESH)
    @JoinTable(
        name = "department_employees",
        joinColumns = {
            @JoinColumn(name = "department_entity_id", referencedColumnName = "entityId"),
            @JoinColumn(name = "department_working_set_id", referencedColumnName = "workingSetId")
        },
        inverseJoinColumns = {
            @JoinColumn(name = "employee_entity_id", referencedColumnName = "entityId"),
            @JoinColumn(name = "employee_working_set_id", referencedColumnName = "workingSetId")
        }
    )
    private Set<Employee> employees = new HashSet<>();

    @JoinColumn(name = "workingSetId", referencedColumnName = "workingSetId", insertable = false, updatable = false)
    @JoinColumn(name = "manager_entity_id", referencedColumnName = "entityId", insertable = false, updatable = false)
    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REFRESH)
    private Manager manager;

    @JoinColumn(name = "workingSetId", referencedColumnName = "workingSetId", insertable = false, updatable = false)
    @JoinColumn(name = "vice_manager_entity_id", referencedColumnName = "entityId", insertable = false, updatable = false)
    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REFRESH)
    private Manager viceManager;

    public Department(UUID workingSetId, String code, UUID managerEntityId) {
        this(workingSetId, code, managerEntityId, null);
    }

    public Department(UUID workingSetId, String code, UUID managerEntityId, UUID viceManagerEntityId) {
        this(workingSetId, code, managerEntityId, viceManagerEntityId, new HashSet<>());
    }

    public Department(
            UUID workingSetId,
            String code,
            UUID managerEntityId,
            UUID viceManagerEntityId,
            Collection<Employee> employees
    ) {
        super(workingSetId);
        this.code = code;
        this.managerEntityId = managerEntityId;
        this.viceManagerEntityId = viceManagerEntityId;
        this.employees = new HashSet<>(employees);
    }

    public Department() {
    }

    // Constructors, getters, and setters
    public void setManager(Manager manager) {
        this.manager = manager;
        this.managerEntityId = manager != null ? manager.getId().getEntityId() : null;
    }

    public void setViceManager(Manager viceManager) {
        this.viceManager = viceManager;
        this.viceManagerEntityId = viceManager != null ? viceManager.getId().getEntityId() : null;
    }

    public void setManagerEntityId(UUID managerEntityId) {
        this.managerEntityId = managerEntityId;
    }

    public void setViceManagerEntityId(UUID viceManagerEntityId) {
        this.viceManagerEntityId = viceManagerEntityId;
    }

    public UUID getManagerEntityId() {
        return managerEntityId;
    }

    public UUID getViceManagerEntityId() {
        return viceManagerEntityId;
    }

    public Manager getManager() {
        return manager;
    }

    public Manager getViceManager() {
        return viceManager;
    }

    public Collection<Employee> getEmployees() {
        return employees;
    }
}