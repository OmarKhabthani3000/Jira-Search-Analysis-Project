package org.hibernate.bugs;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.UUID;

@Embeddable
class MyCompositeId implements Serializable {
    @Column(nullable = false)
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "pg-uuid")
    private UUID workingSetId;

    @Column(nullable = false)
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "pg-uuid")
    private UUID entityId;

    public MyCompositeId(UUID workingSetId, UUID entityId) {
        this.workingSetId = workingSetId;
        this.entityId = entityId;
    }

    public MyCompositeId() {
    }

    public UUID getWorkingSetId() {
        return workingSetId;
    }

    public UUID getEntityId() {
        return entityId;
    }

    public void setWorkingSetId(UUID workingSetId) {
        this.workingSetId = workingSetId;
    }

    public void setEntityId(UUID entityId) {
        this.entityId = entityId;
    }
}