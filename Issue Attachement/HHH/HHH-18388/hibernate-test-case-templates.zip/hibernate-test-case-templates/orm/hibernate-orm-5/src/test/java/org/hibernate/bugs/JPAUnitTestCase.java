package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.jupiter.api.*;

import java.util.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

@Tag("exploratory-test")
public class JPAUnitTestCase {
    private EntityManagerFactory entityManagerFactory;
    private EntityManager entityManager;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
        entityManager = entityManagerFactory.createEntityManager();
    }

    @After
    public void destroy() {
        if (entityManager != null) {
            entityManager.close();
        }
        if (entityManagerFactory != null) {
            entityManagerFactory.close();
        }
    }

    @Test
    public void classWithSharedWorkingSetIdColumnCanBeSaved() {
        entityManager.getTransaction().begin();

        UUID workingSetId = UUID.randomUUID();
        Employee manager = new Employee(workingSetId, "manager");
        Department department = new Department(workingSetId, "department", manager.getId().getEntityId());

        assertDoesNotThrow(() -> {
            entityManager.persist(manager);
            entityManager.persist(department);
        });

        entityManager.getTransaction().rollback();
    }

    // THIS TEST FAILS WITH:
    // java.lang.NullPointerException: Cannot invoke "org.hibernate.bugs.Manager.getId()" because the return value of
    // "org.hibernate.bugs.Department.getManager()" is null
    @Test
    public void classWithSharedWorkingSetIdUpdatesReferencedEntityWhenUpdatingReferencedEntityId() {
        entityManager.getTransaction().begin();

        UUID workingSetId = UUID.randomUUID();
        Manager manager1 = new Manager(workingSetId, "manager1");
        Manager manager2 = new Manager(workingSetId, "manager2");
        Department department = new Department(workingSetId, "department", manager1.getId().getEntityId());

        entityManager.persist(manager1);
        entityManager.persist(manager2);
        entityManager.persist(department);

        department.setManagerEntityId(manager2.getId().getEntityId());

        entityManager.merge(department);

        Department reFetchedDepartment = entityManager.find(Department.class, department.getId());

        Assertions.assertAll(
                () -> Assertions.assertEquals(manager2.getId().getEntityId(), reFetchedDepartment.getManagerEntityId()),
                () -> Assertions.assertEquals(manager2.getId(), reFetchedDepartment.getManager().getId())
        );

        entityManager.getTransaction().rollback();
    }

    @Test
    public void classWithSharedWorkingSetIdUpdatesReferencedEntityWhenUpdatingReferencedEntity() {
        entityManager.getTransaction().begin();

        UUID workingSetId = UUID.randomUUID();
        Manager manager1 = new Manager(workingSetId, "manager1");
        Manager manager2 = new Manager(workingSetId, "manager2");
        Department department = new Department(workingSetId, "department", manager1.getId().getEntityId());

        entityManager.persist(manager1);
        entityManager.persist(manager2);
        entityManager.persist(department);

        department.setManager(manager2);

        entityManager.merge(department);

        Department reFetchedDepartment = entityManager.find(Department.class, department.getId());

        Assertions.assertAll(
                () -> Assertions.assertEquals(manager2.getId().getEntityId(), reFetchedDepartment.getManagerEntityId()),
                () -> Assertions.assertEquals(manager2.getId(), reFetchedDepartment.getManager().getId())
        );

        entityManager.getTransaction().rollback();
    }

    @Test
    public void classWithSharedWorkingSetIdUnsetsReferencedEntityWhenUnsettingReferencedEntityId() {
        entityManager.getTransaction().begin();

        UUID workingSetId = UUID.randomUUID();
        Manager manager1 = new Manager(workingSetId, "manager1");
        Manager manager2 = new Manager(workingSetId, "manager2");
        Department department = new Department(
                workingSetId,
                "department",
                manager1.getId().getEntityId(),
                manager2.getId().getEntityId()
        );

        entityManager.persist(manager1);
        entityManager.persist(manager2);
        entityManager.persist(department);

        department.setViceManagerEntityId(null);

        entityManager.merge(department);

        Department reFetchedDepartment = entityManager.find(Department.class, department.getId());

        Assertions.assertAll(
                () -> Assertions.assertNull(reFetchedDepartment.getViceManagerEntityId()),
                () -> Assertions.assertNull(reFetchedDepartment.getViceManager())
        );

        entityManager.getTransaction().rollback();
    }

    @Test
    public void classWithSharedWorkingSetIdUnsetsReferencedEntityWhenUnsettingReferencedEntity() {
        entityManager.getTransaction().begin();

        UUID workingSetId = UUID.randomUUID();
        Manager manager1 = new Manager(workingSetId, "manager1");
        Manager manager2 = new Manager(workingSetId, "manager2");
        Department department = new Department(workingSetId, "department",
                manager1.getId().getEntityId(), manager2.getId().getEntityId());

        entityManager.persist(manager1);
        entityManager.persist(manager2);
        entityManager.persist(department);

        department.setViceManager(null);

        entityManager.merge(department);

        Department reFetchedDepartment = entityManager.find(Department.class, department.getId());

        Assertions.assertAll(
                () -> Assertions.assertNull(reFetchedDepartment.getViceManagerEntityId()),
                () -> Assertions.assertNull(reFetchedDepartment.getViceManager())
        );

        entityManager.getTransaction().rollback();
    }

    @Test
    public void classWithSharedWorkingSetIdHandlesManyToManyFields() {
        entityManager.getTransaction().begin();

        UUID workingSetId = UUID.randomUUID();
        Manager manager1 = new Manager(workingSetId, "manager1");
        Manager manager2 = new Manager(workingSetId, "manager2");
        Employee employee1 = new Employee(workingSetId, "employee1");
        Employee employee2 = new Employee(workingSetId, "employee2");
        Department department = new Department(
                workingSetId,
                "department",
                manager1.getId().getEntityId(),
                manager2.getId().getEntityId(),
                Collections.singletonList(employee1)
        );

        entityManager.persist(manager1);
        entityManager.persist(manager2);
        entityManager.persist(employee1);
        entityManager.persist(employee2);
        entityManager.persist(department);

        department.getEmployees().remove(employee1);
        department.getEmployees().add(employee2);

        entityManager.merge(department);

        Department reFetchedDepartment = entityManager.find(Department.class, department.getId());

        Assertions.assertEquals(
                new HashSet<>(reFetchedDepartment.getEmployees()),
                new HashSet<>(Set.of(employee2))
        );

        entityManager.getTransaction().rollback();
    }
}