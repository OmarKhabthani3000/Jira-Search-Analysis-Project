package org.hibernate.bugs;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;
import java.util.UUID;

import static java.util.UUID.randomUUID;

@MappedSuperclass
abstract class BazeEntity implements Serializable {
    @Id
    @Access(AccessType.PROPERTY)
    private MyCompositeId id;

    public BazeEntity(MyCompositeId id) {
        this.id = id;
    }

    public BazeEntity(UUID workingSetId, UUID entityId) {
        this(new MyCompositeId(workingSetId, entityId));
    }

    public BazeEntity(UUID workingSetId) {
        this(workingSetId, randomUUID());
    }

    public BazeEntity() {
    }

    public MyCompositeId getId() {
        return id;
    }

    public void setId(MyCompositeId id) {
        this.id = id;
    }
}