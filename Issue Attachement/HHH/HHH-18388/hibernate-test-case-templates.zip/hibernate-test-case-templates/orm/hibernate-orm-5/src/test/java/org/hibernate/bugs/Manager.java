package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.util.UUID;

@Entity
class Manager extends BazeEntity {
    @Column(nullable = false)
    private String code;

    public Manager(UUID workingSetId, String code) {
        super(workingSetId);
        this.code = code;
    }

    public Manager() {
        super();
    }
}