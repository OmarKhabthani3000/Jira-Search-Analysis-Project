# Content has moved

Refer instead:

* to [search/hibernate-search-6/orm-lucene](../hibernate-search-6/orm-lucene) for Hibernate Search 6 in Hibernate ORM backed by an embedded Lucene instance.
* to [search/hibernate-search-5/lucene](../hibernate-search-5/lucene) for Hibernate Search 5 in Hibernate ORM backed by an embedded Lucene instance.
