package test;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import junit.framework.Assert;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.collection.internal.AbstractPersistentCollection;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.hibernate.sql.JoinType;
import org.hibernate.tool.hbm2ddl.SchemaUpdate;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class AttributeTest {

	private static SessionFactory sessionFactory;
	private List<A> beans;
	
	@BeforeClass
	public static void initClass() {
		Configuration hiberConf=new Configuration();
		hiberConf
		.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect")
		.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver")
		.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:aname")
		.setProperty("hibernate.connection.username", "sa")
		.setProperty("hibernate.connection.password", "")
		.setProperty("hibernate.show_sql", "true")
		.setProperty("hibernate.format_sql", "true");
		
		hiberConf.
			addClass(A.class).
			addClass(B.class);

		
		SchemaUpdate schemaUpdate=new SchemaUpdate(hiberConf);
		schemaUpdate.execute(false, true);
		
		ServiceRegistryBuilder serviceRegistryBuilder=new ServiceRegistryBuilder();
		serviceRegistryBuilder.applySettings(hiberConf.getProperties());
		ServiceRegistry buildServiceRegistry = serviceRegistryBuilder.buildServiceRegistry();
		sessionFactory = hiberConf.buildSessionFactory(buildServiceRegistry);
	}
	
	
	@Before
	public void init() {
		beans = addBeans();
	}
	
	@After
	public void cleanup() {
		Session s=null;
		Transaction t=null;
		try {
			s=sessionFactory.openSession();
			t=s.beginTransaction();
			
			for (A a : beans) {
				for (B b : a.getBset()) {
					s.delete(b);
				}
				s.delete(a);
			}
			
			t.commit();
		}
		finally {
			if (s!=null) s.close();
		}
	}
	
	/**
	 * 
	 *   A    B
	 *  a1----b1
	 *     |--b2
	 * 
	 *  a2
	 * 
 	 * */
	private List<A> addBeans() {
		Session s=null;
		Transaction t=null;
		try {
			s=sessionFactory.openSession();
			t=s.beginTransaction();
			
			// Saving b1 and b2
			B b1=new B("b1");
			B b2=new B("b2");
			
			s.save(b1);
			s.save(b2);
			
			// Saving a1 with references to b1 and b2
			A a1=new A("a1");
			Set<B> bset = new HashSet<B>();
			bset.add(b1);
			bset.add(b2);
			a1.setBset(bset);
			s.save(a1);
			
			// Saving a2 without any reference
			A a2=new A("a2");
			s.save(a2);
			
			t.commit();
			
			return Arrays.asList(a1, a2);
		}
		finally {
			if (s!=null) s.close();
		}
	}
	
	/**
	 * Query a.name="a2" or bset.name="b1"
	 * */
	@SuppressWarnings("unchecked")
	private List<A> queryABean(Session s) {
		Criteria criteria = s.createCriteria(A.class);
		criteria.createCriteria("bset", "bset", JoinType.LEFT_OUTER_JOIN);
		criteria.add(Restrictions.or(
				Restrictions.eq("bset.name", "b1"),
				Restrictions.eq("name", "a2")
				));
		List<A> list = (List<A>)criteria.list();
		return list;
	}
	
	// FAILURE
	@Test
	public void testSimpleQuery() {
		Session s=null;
		try {
			s=sessionFactory.openSession();
			
			List<A> result=queryABean(s);
			// only the filtered item (b1) is in the list the other (b2) is not.
			Assert.assertEquals("simple criteria query failes to load bset of a1 correctly", beans, result);
		}
		finally {
			if (s!=null) s.close();
		}
	}
	
	// SUCCESS
	@Test
	public void testQueryWithSessionGet_beforeQuery() {
		Session s=null;
		try {
			s=sessionFactory.openSession();
			
			for (A a: beans) {
				A a_session = (A)s.get(A.class, a.getId());
				// initialize persistent Set by reading it
				a_session.toString();
			}
			List<A> result=queryABean(s);
			// now bset is initialized correctly
			Assert.assertEquals(beans, result);
		}
		finally {
			if (s!=null) s.close();
		}
	}
	
	// FAILURE
	@Test
	public void testQueryWithSessionGet_afterQuery() {
		Session s=null;
		try {
			s=sessionFactory.openSession();
			
			List<A> result=queryABean(s);
			
			// now bset returns bad (incomplete) value for a1
			A a1=beans.get(0);
			A a1_session = (A)s.get(A.class, a1.getId());
			Assert.assertEquals("bset Set of a1 is not correct, even if it is fetched with session.get()", a1, a1_session);
			
			Assert.assertEquals(beans, result);
		}
		finally {
			if (s!=null) s.close();
		}
	}

	// SUCCESS
	@Test
	public void testQueryWithReflectiveHack() throws Exception {
		Session s=null;
		try {
			s=sessionFactory.openSession();
			
			List<A> result=queryABean(s);
			
			// if initialized state of persistent Sets changed to false, 
			// then it is loaded again with an other query and everything is OK.
			// This is a naughty hack.
			for (A a : result) {
				Set<B> bset = a.getBset();
				if (bset instanceof AbstractPersistentCollection) {
					Field f = AbstractPersistentCollection.class.getDeclaredField("initialized");
					f.setAccessible(true);
					f.set(bset, false);
				}
			}
			
			Assert.assertEquals(beans, result);
		}
		finally {
			if (s!=null) s.close();
		}
	}
}
