package test;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.collection.internal.AbstractPersistentCollection;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class PeopleWithDogsTest {

	private static SessionFactory sessionFactory;
	private Person dogFriendly;
	private Person hasNoDogs;

	@BeforeClass
	public static void initSessionFactory() {
		final StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure().build();
		try {
			sessionFactory = new MetadataSources(registry).buildMetadata().buildSessionFactory();
		} catch (final RuntimeException e) {
			StandardServiceRegistryBuilder.destroy(registry);
			throw e;
		}
	}

	@Before
	public void addBeans() {
		try (Session s = sessionFactory.openSession()) {
			final Transaction t = s.beginTransaction();

			final Dog dog1 = new Dog("dog1");
			final Dog dog2 = new Dog("dog2");

			s.save(dog1);
			s.save(dog2);

			dogFriendly = new Person("dogFriendly");
			final Set<Dog> dogs = new HashSet<Dog>();
			dogs.add(dog1);
			dogs.add(dog2);
			dogFriendly.setDogs(dogs);
			s.save(dogFriendly);

			hasNoDogs = new Person("hasNoDogs");
			s.save(hasNoDogs);

			t.commit();
		}
	}

	@After
	public void cleanupDatabase() {
		dogFriendly=null;
		hasNoDogs=null;
		try (Session s = sessionFactory.openSession()) {
			final Transaction t = s.beginTransaction();

			@SuppressWarnings("unchecked")
			final List<Person> list = s.createCriteria(Person.class).list();
			for (final Person person : list) {
				for (final Dog dog : person.getDogs()) {
					s.delete(dog);
				}
				s.delete(person);
			}

			t.commit();
		}
	}

	@SuppressWarnings("unchecked")
	private List<Person> queryPeopleWithADogOrName(final Session s) {
		final Criteria criteria = s.createCriteria(Person.class);
		criteria.createCriteria("dogs", "dogs", JoinType.LEFT_OUTER_JOIN);
		criteria.add(Restrictions.or(Restrictions.eq("dogs.name", "dog1"), Restrictions.eq("name", "hasNoDogs")));
		return criteria.list();
	}

	private void assertAllPersonIsInTheList(final List<Person> dbPeople) {
		assertEquals(2, dbPeople.size());
		final List<Person> people = new ArrayList<>(dbPeople);
		people.sort((final Person p1, final Person p2) -> p1.getName().compareTo(p2.getName()));
		assertEquals(dogFriendly, people.get(0));
		assertEquals(hasNoDogs, people.get(1));
	}

	@Test
	public void queryWithoutFilterWorksAsExpected() {
		try (Session s = sessionFactory.openSession()) {
			@SuppressWarnings("unchecked")
			final List<Person> people = s.createCriteria(Person.class).list();

			assertAllPersonIsInTheList(people);
		}
	}

	@Test
	public void queryWithFilterHasPartialResult() {
		try (Session s = sessionFactory.openSession()) {
			final List<Person> result = queryPeopleWithADogOrName(s);
			// only the filtered item (dog1) is in the list the other (dog2) is
			// not. Criteria query fails to load all dogs of person correctly
			assertAllPersonIsInTheList(result);
		}
	}

	@Test
	public void queryWorksIfSessionGetIsCalledBeforeQuery() {
		try (Session s = sessionFactory.openSession()) {
			// initialize persistent Set by reading it
			System.out.println(s.get(Person.class, hasNoDogs.getId()).toString());
			System.out.println(s.get(Person.class, dogFriendly.getId()).toString());

			// now dogs set has been initialized correctly
			final List<Person> result = queryPeopleWithADogOrName(s);
			assertAllPersonIsInTheList(result);
		}
	}

	@Test
	public void sessionContainsIncompletePersistentSetIfGetIsCalledAfterQuery() {
		try (Session s = sessionFactory.openSession()) {
			// query put a wrong dogs set object to session
			final List<Person> ignored = queryPeopleWithADogOrName(s);
			System.out.println(ignored.toString());

			final Person dogFriendly_session = s.get(Person.class, dogFriendly.getId());
			Assert.assertEquals("dogs Set of person is not correct, even if it is fetched with session.get()!",
					dogFriendly, dogFriendly_session);
		}
	}

	@Test
	public void queryWorksWithReflectiveHack() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		try (Session s = sessionFactory.openSession()) {
			final List<Person> result = queryPeopleWithADogOrName(s);

			// if initialized state of persistent Sets changed to false,
			// then it is loaded again with an other query and everything is OK.
			// This is a naughty hack.
			for (final Person person : result) {
				final Set<Dog> dogs = person.getDogs();
				if (dogs instanceof AbstractPersistentCollection) {
					final Field f = AbstractPersistentCollection.class.getDeclaredField("initialized");
					f.setAccessible(true);
					f.set(dogs, false);
				}
			}

			assertAllPersonIsInTheList(result);
		}
	}
}
