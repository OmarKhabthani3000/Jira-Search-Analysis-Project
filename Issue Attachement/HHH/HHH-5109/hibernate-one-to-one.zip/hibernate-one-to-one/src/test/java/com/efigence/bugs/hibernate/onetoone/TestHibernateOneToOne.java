package com.efigence.bugs.hibernate.onetoone;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.persistence.Entity;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.annotations.Proxy;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.classic.Session;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.internal.verification.Times;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;


public class TestHibernateOneToOne {
  private static final Logger logger = Logger.getLogger(TestHibernateOneToOne.class);
  
  
  public static final Long ID_OWNER_ENTITY = 1111L;
  public static final String WRONG_STRING = 
        "select owner0_.ID as ID0_2_, owned1_.ID as ID1_0_, owner2_.ID as ID0_1_ " +
  		"from Owner owner0_ left outer " +
  		      "join Owned owned1_ on owner0_.ID=owned1_.ID " +
  		      "left outer join Owner owner2_ on owned1_.ID=owner2_.ID " +
  		"where owner0_.ID=?";
  
  
  @Test
  public void testOneToOneById() throws Exception {
    SessionFactory sessionFactory = new AnnotationConfiguration()
    .addAnnotatedClass(Owner.class)
    .addAnnotatedClass(Owned.class)
    .setProperty("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect")
    .buildSessionFactory();
    
    final PreparedStatement preparedStatement = Mockito.mock(PreparedStatement.class);
    final ResultSet resultSet = Mockito.mock(ResultSet.class);

    final Connection connection = Mockito.mock(Connection.class);
    Mockito.when(connection.prepareStatement(Mockito.anyString())).thenAnswer(new Answer<PreparedStatement>() {
      @Override
      public PreparedStatement answer(InvocationOnMock invocation) throws Throwable {
        if (WRONG_STRING.equals(invocation.getArguments()[0])) {
          throw new RuntimeException("Two joins with owner");
        } else {
          logger.info("OK: " + invocation.getArguments()[0]);
          return preparedStatement;
        }
      }
    });
    Mockito.when(preparedStatement.executeQuery()).thenReturn(resultSet);
    
    Session session = sessionFactory.openSession(connection);
    
    Owner owner = (Owner) session.load(Owner.class, ID_OWNER_ENTITY);
    
    owner.hashCode();
    owner.getOwned().hashCode();

    Mockito.verify(connection).prepareStatement(Mockito.anyString());
    Mockito.verify(preparedStatement).setLong(1, ID_OWNER_ENTITY.longValue());
    Mockito.verify(connection, new Times(2)).isClosed();
    Mockito.verify(connection, new Times(2)).getAutoCommit();
    Mockito.verifyZeroInteractions(connection);
  }
}



@Entity
@Proxy(lazy=false)
class Owner {
  @javax.persistence.Id
  @javax.persistence.Column(name = "ID", columnDefinition = "BIGINT")
  public java.lang.Long getId() {
    return this.id;
  }
  
  public void setId(java.lang.Long newValue) {
    this.id = newValue;
  }
  
  private java.lang.Long id;
  
  @javax.persistence.OneToOne(targetEntity = Owned.class)
  @org.hibernate.annotations.Cascade( { org.hibernate.annotations.CascadeType.ALL })
  @javax.persistence.PrimaryKeyJoinColumn
  public Owned getOwned() {
    return this.owned;
  }
  
  public void setOwned(Owned owned) {
    this.owned = owned;
    if (owned != null) {
      owned.setOwner(this);
    }
  }
  
  private Owned owned;
}


@Entity
@Proxy(lazy=false)
class Owned {
  private java.lang.Long id;
  
  @javax.persistence.Id
  @javax.persistence.GeneratedValue(generator = "foreign")
  @org.hibernate.annotations.GenericGenerator(
      name = "foreign", 
      strategy = "foreign", 
      parameters = { @org.hibernate.annotations.Parameter(name = "property", value = "owner") })
      @javax.persistence.Column(name = "ID", columnDefinition = "BIGINT")
      public java.lang.Long getId() {
    return this.id;
  }
  
  public void setId(java.lang.Long newValue) {
    this.id = newValue;
  }
  
  @javax.persistence.OneToOne(targetEntity = Owner.class, mappedBy = "owned")
  @javax.persistence.PrimaryKeyJoinColumn
  public Owner getOwner() {
    return this.owner;
  }
  
  public void setOwner(Owner owner) {
    this.owner = owner;
  }
  
  private Owner owner;
}


