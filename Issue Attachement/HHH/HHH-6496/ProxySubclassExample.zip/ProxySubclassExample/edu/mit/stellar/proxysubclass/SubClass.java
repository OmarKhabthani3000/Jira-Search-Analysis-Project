package edu.mit.stellar.proxysubclass;

import javax.persistence.Entity;

@Entity
public class SubClass extends BaseClass {

    @Override public SubClass toSubClass() {
        return this;
    }
}
