package edu.mit.stellar.proxysubclass;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.dialect.Dialect;
import org.hibernate.dialect.HSQLDialect;
import org.hibernate.junit.functional.FunctionalTestCase;
import edu.mit.stellar.proxysubclass.SubClass;
import edu.mit.stellar.proxysubclass.LazyReferenceToBaseClass;
import edu.mit.stellar.proxysubclass.BaseClass;

public class ProxySubclassTest extends FunctionalTestCase {
    
    public ProxySubclassTest(String string) {
        super(string);
    }

    public String[] getMappings() {
        return new String[] { "Mapping.hbm.xml" };
    }

    public String getBaseForMappings() {
        return "edu/mit/stellar/proxysubclass/";
    }

    public boolean createSchema() {
        return true;
    }
  

    public void testProxySubclass() throws Exception {
        
        Session s = null;
        Transaction tx = null;
        Integer lazyReferenceToBaseClassId = null;
        try {
            s = this.openSession();
            tx = s.beginTransaction();
        
            BaseClass baseClass = new SubClass();
            baseClass.setName("baseClass");
            s.save(baseClass);
             
            LazyReferenceToBaseClass lazyReferenceToBaseClass = new LazyReferenceToBaseClass();
            lazyReferenceToBaseClass.setBaseClass(baseClass);
            lazyReferenceToBaseClass.setName("lazyReferenceToBaseClass");  
            s.save(lazyReferenceToBaseClass);    
           
            lazyReferenceToBaseClassId = lazyReferenceToBaseClass.getId();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            throw e;
        } finally {
            if (s != null) {
                s.close();
            }
        }

        try {
            s = this.openSession();
            tx = s.beginTransaction();
            //Load back record 2
            LazyReferenceToBaseClass lazyReferenceToBaseClass = (LazyReferenceToBaseClass) s.load(LazyReferenceToBaseClass.class, lazyReferenceToBaseClassId);
            BaseClass baseClass = lazyReferenceToBaseClass.getBaseClass();
            SubClass subClass = baseClass.toSubClass();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            throw e;
        } finally {
            if (s != null) {
                s.close();
            }
        }
    }
}
