package edu.mit.stellar.proxysubclass;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
public class LazyReferenceToBaseClass implements Serializable
{
  private static final long serialVersionUID = 3805731902822385142L;
  private Integer id;
  private String name;
  private BaseClass baseClass;
 
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  public Integer getId()
  {
    return id;
  }

  protected void setId(Integer id)
  {
    this.id = id;
  }

  @ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE }, fetch=FetchType.LAZY)
  public BaseClass getBaseClass()
  {
    return baseClass;
  }

  public void setBaseClass(BaseClass baseClass)
  {
    this.baseClass = baseClass;
  }

 
  public String getName()
  {
    return name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  
  public boolean equals(Object obj)
  {
    return EqualsBuilder.reflectionEquals(this, obj);
  }

  public int hashCode()
  {
    return HashCodeBuilder.reflectionHashCode(this);
  }
  
  public String toString()
  {
    return ToStringBuilder.reflectionToString(this);
  }
}