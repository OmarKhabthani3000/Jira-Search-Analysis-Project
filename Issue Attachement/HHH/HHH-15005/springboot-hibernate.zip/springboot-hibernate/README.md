See the guide [here](https://guides.hazelcast.org/springboot-hibernate).
