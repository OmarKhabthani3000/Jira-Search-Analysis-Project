asciidoctor -a allow-uri-read *.adoc;
asciidoctor-pdf -a allow-uri-read *.adoc;
