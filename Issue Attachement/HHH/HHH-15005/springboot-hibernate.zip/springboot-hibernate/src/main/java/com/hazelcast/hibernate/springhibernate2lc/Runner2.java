package com.hazelcast.hibernate.springhibernate2lc;

import com.hazelcast.hibernate.springhibernate2lc.persistence.BookRepository;

import java.time.LocalTime;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
class Runner2 implements CommandLineRunner {

    private final BookRepository repository;

    public Runner2(BookRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) throws Exception {
       
    	Thread.sleep(10000);
    	System.out.println("START -- " + LocalTime.now());
    	for(int x = 0; x < 30000; x++) {
    		repository.findById(1L);
    		//repository.findAll().forEach(System.out::println);
    		//Thread.sleep(1000);
    	}
    	System.out.println("END -- " + LocalTime.now());
    }
}
