package com.hazelcast.hibernate.springhibernate2lc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHibernate2lcApplicationTests {

	@Test
	void contextLoads() {
	}

}
