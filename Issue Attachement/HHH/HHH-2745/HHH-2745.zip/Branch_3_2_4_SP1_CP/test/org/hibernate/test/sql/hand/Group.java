package org.hibernate.test.sql.hand;

import java.util.ArrayList;
import java.util.List;

public class Group {
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public List<Person> getPersons() {
		return persons;
	}
	public void setPersons(List<Person> persons) {
		this.persons = persons;
	}
	private Long id;
	private List<Person> persons = new ArrayList<Person>();
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Group(String name) {
		this.name = name;
	}
	
	public Group(){}
	
}
