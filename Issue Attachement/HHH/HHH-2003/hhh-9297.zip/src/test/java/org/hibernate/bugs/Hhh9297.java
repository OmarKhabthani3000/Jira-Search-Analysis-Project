package org.hibernate.bugs;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.hibernate.testing.junit4.BaseUnitTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class Hhh9297 extends BaseUnitTestCase {
	@Entity
	@Table(name = "Player")
	@Cache(region = "players", usage = CacheConcurrencyStrategy.READ_ONLY)
	public static class Player {
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private Long id;

		@Column
		private int goals;

		public Player() {
		}

		public Player(int goals) {
			this.goals = goals;
		}

		@ManyToOne(fetch = FetchType.LAZY)
		@JoinColumn(name = "team_id")
		private Team team;

		@Override
		public String toString() {
			return "Player " + id;
		}
	}

	@Entity
	@Table(name = "Team")
	@Cache(region = "teams", usage = CacheConcurrencyStrategy.READ_ONLY)
	public static class Team {
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private Long id;

		@OneToMany(mappedBy = "team", fetch = FetchType.LAZY)
		@Cache(region = "teams", usage = CacheConcurrencyStrategy.READ_ONLY)
		private List<Player> players = new LinkedList<Player>();

		public List<Player> getPlayers() {
			return players;
		}

		@Override
		public String toString() {
			return "Team " + id + " (" + players.size() + " players: "
					+ players.toString() + ")";
		}
	}

	@Entity
	@Table(name = "Fan")
	@Cache(region = "fans", usage = CacheConcurrencyStrategy.READ_WRITE)
	public static class Fan {
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private Long id;

		@ManyToOne(fetch = FetchType.LAZY)
		@JoinColumn(name = "team", nullable = true)
		private Team team;

		@Override
		public String toString() {
			return "Fan " + id + ": " + team.toString();
		}
	}

	private Configuration config;
	private SessionFactory sessionFactory;

	@SuppressWarnings("deprecation")
	@Before
	public void setup() {
		config = new Configuration();
		config.addAnnotatedClass(Player.class);
		config.addAnnotatedClass(Team.class);
		config.addAnnotatedClass(Fan.class);

		config.setProperty("hibernate.connection.driver_class",
				"org.hsqldb.jdbcDriver");
		config.setProperty("hibernate.connection.url",
				"jdbc:hsqldb:mem:myunittests");
		config.setProperty("hibernate.connection.username", "sa");
		config.setProperty("hibernate.connection.password", "");
		config.setProperty("hibernate.connection.pool_size", "1");
		config.setProperty("hibernate.current_session_context_class", "thread");
		config.setProperty("hibernate.hbm2ddl.auto", "update");
		config.setProperty("hibernate.dialect",
				"org.hibernate.dialect.HSQLDialect");
		config.setProperty("hibernate.cache.use_second_level_cache", "true");
		config.setProperty("hibernate.cache.region_prefix", "hibernate-");
		config.setProperty("hibernate.cache.region.factory_class",
				"org.hibernate.cache.ehcache.EhCacheRegionFactory");
		config.setProperty("hibernate.show_sql", "true");

		sessionFactory = config.buildSessionFactory();

		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		session.createSQLQuery("insert into Team (id) values (1)")
				.executeUpdate();
		session.createSQLQuery("insert into Team (id) values (2)")
				.executeUpdate();
		session.createSQLQuery(
				"insert into Player (id, goals, team_id) values (1, 3, 1)")
				.executeUpdate();
		session.createSQLQuery(
				"insert into Player (id, goals, team_id) values (2, 1, 2)")
				.executeUpdate();
		session.createSQLQuery(
				"insert into Player (id, goals, team_id) values (3, 2, 2)")
				.executeUpdate();
		session.createSQLQuery("insert into Fan (id, team) values (1, 1)")
				.executeUpdate();
		session.createSQLQuery("insert into Fan (id, team) values (2, 2)")
				.executeUpdate();
		transaction.commit();
	}

	@Test
	public void query() {
		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		@SuppressWarnings("unchecked")
		List<Team> teams = session.createCriteria(Team.class)
				.setCacheable(false).list();
		System.out.println("Teams:");
		for (Team team : teams) {
			System.out.println(team);
		}
		transaction.rollback();

		sessionFactory.getCache().evictEntityRegions();
		sessionFactory.getCache().evictCollectionRegions();

		session = sessionFactory.getCurrentSession();
		transaction = session.beginTransaction();

		Criteria criteria = session.createCriteria(Fan.class);
		criteria.createAlias("team", "team", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("team.players", "player", JoinType.LEFT_OUTER_JOIN);
		criteria.add(Restrictions.ge("player.goals", 2));

		@SuppressWarnings("unchecked")
		List<Fan> fans = criteria.list();
		System.out.println("Fans:");
		for (Fan fan : fans) {
			System.out.println(fan);
		}

		transaction.rollback();

		System.out.println("Using cache:");
		session = sessionFactory.getCurrentSession();
		transaction = session.beginTransaction();
		Team team2fromCache = (Team) session.load(Team.class, 2L);
		System.out.println(team2fromCache);

		Assert.assertEquals(2, team2fromCache.getPlayers().size());
	}
}
