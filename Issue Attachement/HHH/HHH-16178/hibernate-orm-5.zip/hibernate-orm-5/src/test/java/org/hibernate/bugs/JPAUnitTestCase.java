package org.hibernate.bugs;

import java.util.List;

import javax.persistence.*;

import org.junit.*;

import tst.oth.impl.NotGeneratedEntity;
import tst.oth.impl.ReadOnlyChildrenEntity;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

  private EntityManagerFactory entityManagerFactory;
  private NotGeneratedEntity notGeneratedEntity;
  private ReadOnlyChildrenEntity readOnlyChildrenEntity;

  @After
  public void destroy() {
    entityManagerFactory.close();
  }

  @Test
  public void hhh16178Test()
      throws Exception {
    loadTestData(entityManagerFactory);

    EntityManager em = entityManagerFactory.createEntityManager();
    try {
      em.createQuery("from NotGeneratedEntity where id = " + notGeneratedEntity.getId(),
          NotGeneratedEntity.class).getResultStream().forEach(e -> {
            System.out.println("VALUE: " + e.getReadOnlyChildren().get(0).getId());
          });
    }
    finally {
      em.close();
    }

  }

  @Before
  public void init() {
    entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
  }

  /**
   * Inserts a set of data to be used by generated unit test classes. This data is
   * populated into a unit test DB, and referenced by test code.
   *
   * @param argEmf the {@link EntityManagerFactory} to use when loading test data.
   */
  public void loadTestData(EntityManagerFactory argEmf) {
    EntityManager em = argEmf.createEntityManager();
    try {
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      populateTestData();
      em.persist(notGeneratedEntity);
      tx.commit();
      tx = em.getTransaction();
      tx.begin();
      populateTestDataSecondPass();
      em.persist(notGeneratedEntity);
      tx.commit();
    }
    finally {
      em.close();
    }
  }

  public void populateTestData() {
    readOnlyChildrenEntity = new ReadOnlyChildrenEntity();
    notGeneratedEntity = new NotGeneratedEntity();
    notGeneratedEntity.setChars(
        "1CharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCh");

  }

  public void populateTestDataSecondPass() {
    notGeneratedEntity.setReadOnlyChildren(List.of(readOnlyChildrenEntity));
  }
}
