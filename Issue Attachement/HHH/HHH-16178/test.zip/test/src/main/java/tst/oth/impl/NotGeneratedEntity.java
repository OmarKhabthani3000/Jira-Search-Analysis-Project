package tst.oth.impl;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "NOT_GENERATED")
public class NotGeneratedEntity {

  private String chars;
  private long id;
  private List<ReadOnlyChildrenEntity> readOnlyChildren;

  @Column(name = "CHARS", nullable = false)
  public String getChars() {
    return chars;
  }

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "ID", nullable = false)
  public long getId() {
    return id;
  }

  @OneToMany(cascade = CascadeType.ALL)
  @OrderBy("notGeneratedId")
  @JoinColumn(name = "NOT_GENERATED_ID", nullable = false, referencedColumnName = "ID", updatable = false)
  public List<ReadOnlyChildrenEntity> getReadOnlyChildren() {
    return readOnlyChildren;
  }

  public void setChars(String argChars) {
    chars = argChars;
  }

  public void setId(long argId) {
    id = argId;
  }

  public void setReadOnlyChildren(List<ReadOnlyChildrenEntity> argReadOnlyChildren) {
    readOnlyChildren = argReadOnlyChildren;
  }
}
