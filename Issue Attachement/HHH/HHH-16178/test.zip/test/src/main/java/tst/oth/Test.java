package tst.oth;

import java.util.List;

import javax.persistence.*;

import tst.oth.impl.NotGeneratedEntity;
import tst.oth.impl.ReadOnlyChildrenEntity;

public class Test {
  public static void main(String[] args) {
    EntityManagerFactory factory = Persistence.createEntityManagerFactory("primary");

    Test test = new Test();
    test.loadTestData(factory);

    EntityManager em = factory.createEntityManager();
    em.createQuery("from NotGeneratedEntity where id = " + test.notGeneratedEntity.getId(),
        NotGeneratedEntity.class).getResultStream().forEach(e -> {
          System.out.println("VALUE: " + e.getReadOnlyChildren().get(0).getId());
        });
  }

  private NotGeneratedEntity notGeneratedEntity;
  private ReadOnlyChildrenEntity readOnlyChildrenEntity;

  /**
   * Inserts a set of data to be used by generated unit test classes. This data is
   * populated into a unit test DB, and referenced by test code.
   *
   * @param argEmf the {@link EntityManagerFactory} to use when loading test data.
   */
  public void loadTestData(EntityManagerFactory argEmf) {
    EntityManager em = argEmf.createEntityManager();
    try {
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      populateTestData();
      em.persist(notGeneratedEntity);
      tx.commit();
      tx = em.getTransaction();
      tx.begin();
      populateTestDataSecondPass();
      em.persist(notGeneratedEntity);
      tx.commit();
    }
    finally {
      em.close();
    }
  }

  public void populateTestData() {
    readOnlyChildrenEntity = new ReadOnlyChildrenEntity();
    notGeneratedEntity = new NotGeneratedEntity();
    notGeneratedEntity.setChars(
        "1CharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCharsCh");

  }

  public void populateTestDataSecondPass() {
    notGeneratedEntity.setReadOnlyChildren(List.of(readOnlyChildrenEntity));
  }

}
