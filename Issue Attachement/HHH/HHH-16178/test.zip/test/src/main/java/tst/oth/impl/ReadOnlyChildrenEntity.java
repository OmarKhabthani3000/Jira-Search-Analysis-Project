package tst.oth.impl;

import javax.persistence.*;

@Entity
@Table(name = "READ_ONLY_CHILDREN", uniqueConstraints = @UniqueConstraint(columnNames = {"NOT_GENERATED_ID"}))
public class ReadOnlyChildrenEntity {

  private long id;
  private long notGeneratedId;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "ID", nullable = false)
  public long getId() {
    return id;
  }

  @Column(insertable = false, name = "NOT_GENERATED_ID", nullable = false, updatable = false)
  public long getNotGeneratedId() {
    return notGeneratedId;
  }

  public void setId(long argId) {
    id = argId;
  }

  public void setNotGeneratedId(long argNotGeneratedId) {
    notGeneratedId = argNotGeneratedId;
  }
}
