package com.senacor.hibernate.defect;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.apache.log4j.xml.DOMConfigurator;
import org.junit.After;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for showcasing the issues with the deletion of orphaned one-to-relationships
 * with inverse bidirectional mappings.
 */
public class HibernateOneToOneDefectTest {
    private EntityManagerFactory emf;

    private EntityManager em;

    private EntityA entityA;

    @Before
    public void setUp() throws Exception {
        //No TRACE logging
        DOMConfigurator.configure(getClass().getResource("/log4j.xml"));

        emf = Persistence.createEntityManagerFactory("one-to-one-defect");
        em = emf.createEntityManager();
        entityA = new EntityA();
        EntityB entityB = new EntityB();
        entityA.setEntityB(entityB);

        //Persist Entity A with One-to-One to Entity B as test fixture
        em.getTransaction().begin();
        em.persist(entityA);

        em.getTransaction().commit();
        em.close();

        //Create new session for test case
        em = emf.createEntityManager();

        //Test bidirectional relation
        entityA = em.find(EntityA.class, entityA.getId());
        assertNotNull(entityA.getEntityB());
        assertNotNull(entityA.getEntityB().getEntityA());
    }

    @After
    public void tearDown() throws Exception {
        em.close();
        emf.close();
    }

    @Test
    public void testThrowsNoExceptionOnDeleteOneToOneRelationshipWithoutManualFlushInTransaction() {
        //Delete Entity B in Entity A and persist
        entityA.setEntityB(null);
        em.getTransaction().begin();
        em.merge(entityA);
        em.getTransaction().commit();
    }

    @Test
    public void testThrowsExceptionOnDeleteOneToOneRelationshipWithManualFlushInTransaction() {
        //Delete Entity B in Entity A and persist
        entityA.setEntityB(null);
        em.getTransaction().begin();
        em.merge(entityA);
        //This manual flush causes the flush on commit to fail
        em.flush();
        em.getTransaction().commit();
    }

    @Test
    public void testThrowsExceptionOnDeleteOneToOneRelationshipWithManualFlushInTransactionEvenWhenBothSidesAreSetToNull() {
        //Delete Entity B in Entity A and persist
        EntityB entityB = entityA.getEntityB();
        entityA.setEntityB(null);
        entityB.setEntityA(null);
        em.getTransaction().begin();
        em.merge(entityA);
        //This manual flush causes the flush on commit to fail
        em.flush();
        em.getTransaction().commit();
    }

    @Test
    public void testEvenThrowsExceptionOnDeleteOneToOneRelationshipWithoutManualFlushInTransactionWithLogLevelTrace() {
        //When log level is set to TRACE: the operation fails even without manual flushing
        DOMConfigurator.configure(getClass().getResource("/log4j_trace.xml"));
        //Delete Entity B in Entity A and persist
        entityA.setEntityB(null);
        em.getTransaction().begin();
        em.merge(entityA);
        em.getTransaction().commit();
    }

}
