package com.senacor.hibernate.defect;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author Denis Pasek, Senacor Technologies AG
 */
@Entity
@Table(name="T_ENTITY_B")
public class EntityB implements Serializable {

    @Id
    @GeneratedValue
    @Column(name="ID")
    private Long id;

    /**
     * One-to-One bidirectional relation to entity A. Entity B table should contain Foreign key to Entity A.
     */
    @OneToOne
    @JoinColumn(name="ENTITY_AD_FK")
    private EntityA entityA;

    public Long getId() {
        return id;
    }

    public EntityA getEntityA() {
        return entityA;
    }

    public void setEntityA(EntityA entityA) {
        this.entityA = entityA;
    }
}
