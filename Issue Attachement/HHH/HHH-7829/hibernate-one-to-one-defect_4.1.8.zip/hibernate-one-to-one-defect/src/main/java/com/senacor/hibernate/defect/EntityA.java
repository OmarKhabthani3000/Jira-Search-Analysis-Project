package com.senacor.hibernate.defect;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * Root Entity
 * @author Denis Pasek, Senacor Technologies AG
 */
@Entity
@Table(name="T_ENTITY_A")
public class EntityA implements Serializable{

    @Id
    @GeneratedValue
    @Column(name="ID")
    private Long id;

    /**
     * One-to-One bidirectional relation to entity B. Optional for Entity A.
     */
    @OneToOne(mappedBy="entityA", cascade= CascadeType.ALL, fetch= FetchType.EAGER, orphanRemoval=true)
    private EntityB entityB;

    public Long getId() {
        return id;
    }

    public EntityB getEntityB() {
        return entityB;
    }

    public void setEntityB(EntityB entityB) {
        if (entityB != null)  {
            entityB.setEntityA(this);
        }
        this.entityB = entityB;
    }

}
