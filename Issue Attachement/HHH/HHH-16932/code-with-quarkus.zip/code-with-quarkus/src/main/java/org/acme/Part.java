package org.acme;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import java.time.OffsetDateTime;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.envers.Audited;
import org.hibernate.type.SqlTypes;

@Entity(name = "Part")
@Table(name = "PART", schema = "base")
@Audited(withModifiedFlag = true)
public class Part {

    @Id
    private Long id;
    private String name;
    @JdbcTypeCode(SqlTypes.JSON)
    private Translation description;
    private OffsetDateTime stamp;

    @PrePersist
    @PreUpdate
    void setStamp() {
        stamp = OffsetDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public Part setId(Long aId) {
        this.id = aId;
        return this;
    }

    public String getName() {
        return name;
    }

    public Part setName(String aName) {
        this.name = aName;
        return this;
    }

    public Translation getDescription() {
        return description;
    }

    public Part setDescription(Translation aDescription) {
        this.description = aDescription;
        return this;
    }

    public OffsetDateTime getStamp() {
        return stamp;
    }

    public Part setStamp(OffsetDateTime aStamp) {
        this.stamp = aStamp;
        return this;
    }

    @Override
    public String toString() {
        return "Part{" + "id=" + id + ", name=" + name + ", description=" + description + ", stamp=" + stamp + '}';
    }
}
