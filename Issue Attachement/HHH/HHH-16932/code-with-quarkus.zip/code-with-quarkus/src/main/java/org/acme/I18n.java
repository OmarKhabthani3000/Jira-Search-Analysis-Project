package org.acme;

import jakarta.persistence.Embeddable;
import jakarta.persistence.MappedSuperclass;
import java.util.Objects;

@Embeddable
@MappedSuperclass
public class I18n<T extends I18n> {

    private String de;
    private String en;

    public String getDe() {
        return de;
    }

    public T setDe(String aDe) {
        this.de = aDe;
        return (T) this;
    }

    public String getEn() {
        return en;
    }

    public T setEn(String aEn) {
        this.en = aEn;
        return (T) this;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 59 * hash + Objects.hashCode(this.de);
        hash = 59 * hash + Objects.hashCode(this.en);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final I18n other = (I18n) obj;
        if (!Objects.equals(this.de, other.de)) {
            return false;
        }
        return Objects.equals(this.en, other.en);
    }

    @Override
    public String toString() {
        return "I18n{" + "de=" + de + ", en=" + en + '}';
    }
}
