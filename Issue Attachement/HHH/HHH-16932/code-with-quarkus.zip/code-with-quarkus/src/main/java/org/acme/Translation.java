package org.acme;

import jakarta.persistence.Embeddable;
import java.util.Locale;
import java.util.Objects;

/**
 * @since 13.07.2023
 */
@Embeddable
public class Translation extends I18n<Translation> {

    String getInCurrentLanguage() {
        switch (Locale.getDefault().getLanguage()) {
            case "de":
                return getDe();
            case "en":
                return getEn();
            default:
                return getEn();
        }
    }

}
