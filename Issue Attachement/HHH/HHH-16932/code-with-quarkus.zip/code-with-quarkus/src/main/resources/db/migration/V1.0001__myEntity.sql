--create structures for envers in public schema
CREATE TABLE IF NOT EXISTS public.revinfo (
	rev             int8 NULL,
	revtstmp        bigint NULL
);
CREATE SEQUENCE IF NOT EXISTS public.revinfo_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;

--create our structures
CREATE SCHEMA IF NOT EXISTS base;
CREATE TABLE IF NOT EXISTS base.PART (
    id 				bigint,
    name            varchar,
    description     jsonb,
    stamp           timestamptz 
);
CREATE TABLE IF NOT EXISTS base.PART_AUD (
    rev             int4 NOT NULL,
	revtype         int4 NULL,
    id 				bigint,
    name            varchar,
    name_mod        bool,
    description     jsonb,
    description_mod bool,
    stamp           timestamptz,
    stamp_mod       bool
);