package org.acme;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

@QuarkusTest
@Transactional(Transactional.TxType.REQUIRES_NEW)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class PartTest {

    static final long ID = 100L;

    @Inject
    EntityManager em;

    @Test
    void shouldWriteEnversAuditTrail() throws Exception {
        //given
        createPart();
        updatePartDescriptioEN("Hi");
        updatePartDescriptionDE("Guten Abend");
        updatePartDescriptioEN("Good Afternoon");
        //when
        List<Object[]> auditTrail = em
                .createNativeQuery("SELECT description, description_mod FROM base.part_aud ORDER BY rev asc")
                .getResultList();
        //then
        assertEquals(4, auditTrail.size());
        for (Object[] row : auditTrail) {
            assertTrue((boolean) row[1], "description should modified");
            assertNotNull(row[0], "description should not be null");
        }
    }

    void createPart() {
        Part part = new Part()
                .setId(ID)
                .setName("test")
                .setDescription(new Translation()
                        .setDe("Hallo")
                        .setEn("Hello"));
        em.persist(part);
    }

    void updatePartDescriptionDE(String aGermanDescription) {
        Part part = em.find(Part.class, ID);
        part.getDescription().setDe(aGermanDescription);
    }

    void updatePartDescriptioEN(String aEnglishDescription) {
        Part part = em.find(Part.class, ID);
        part.getDescription().setEn(aEnglishDescription);
    }
}
