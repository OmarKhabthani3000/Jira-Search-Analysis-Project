package com.example;

import javax.persistence.*;


@Entity
public class Product {
    @Id @GeneratedValue
    int id;

    public long getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
