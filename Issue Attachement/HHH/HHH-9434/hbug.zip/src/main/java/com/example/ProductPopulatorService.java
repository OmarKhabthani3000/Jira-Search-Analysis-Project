package com.example;


import com.example.Product;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


@Stateless
public class ProductPopulatorService {
    @PersistenceContext
    private EntityManager em;

    public void setupTestData() {
        Product p = new Product();
        em.persist(p);
    }
}
