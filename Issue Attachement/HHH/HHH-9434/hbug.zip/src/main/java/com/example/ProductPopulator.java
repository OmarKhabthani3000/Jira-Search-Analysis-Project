package com.example;

import com.example.Product;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;


@RequestScoped
@Named
public class ProductPopulator {
    @Inject
    ProductPopulatorService pps;

    public void setup() {
        pps.setupTestData();
    }
}
