package com.fareis.sessionfactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.HibernateException;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.BeanUtils;
import org.springframework.core.io.Resource;
import org.springframework.orm.hibernate3.LocalSessionFactoryBean;

import com.fareis.las.common.sessionfactory.LasPatternResolver;

public class LasSessionFactoryBean extends LocalSessionFactoryBean
{
  public void setMappingResources(String[] mappingResources)
  {
    List resources = new ArrayList();
    if (!(ArrayUtils.isEmpty(mappingResources))) {
      try
      {
        LasPatternResolver patternResolver = new LasPatternResolver();
        if (mappingResources != null) {
          for (String mappingResource : mappingResources)
            resources.addAll(Arrays.asList(patternResolver.getResources(mappingResource.trim())));
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }

    super.setMappingLocations((Resource[])resources.toArray(new Resource[0]));
  }

  protected Configuration newConfiguration()
    throws HibernateException
  {
    String env = System.getProperty("weblogic.env");

    if (StringUtils.equals(env, "junit")) {
      return ((Configuration)BeanUtils.instantiateClass(LasConfiguration.class));
    }
    return ((Configuration)BeanUtils.instantiateClass(Configuration.class));
  }
}