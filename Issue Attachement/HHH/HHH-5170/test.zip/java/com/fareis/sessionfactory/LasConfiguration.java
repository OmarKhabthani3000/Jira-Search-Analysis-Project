package com.fareis.sessionfactory;

import java.util.Properties;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.cfg.Settings;
import org.hibernate.util.PropertiesHelper;

public class LasConfiguration extends Configuration
{
  private static final long serialVersionUID = 1L;

  public SessionFactory buildSessionFactory()
    throws HibernateException
  {
    Environment.verifyProperties(super.getProperties());
    Properties copy = new Properties();
    copy.putAll(super.getProperties());
    PropertiesHelper.resolvePlaceHolders(copy);
    Settings settings = buildSettings(copy);

    LasSchemaExport export = new LasSchemaExport(this, settings);
    export.createSchemas();

    SessionFactory factory = super.buildSessionFactory();
    return factory;
  }
}


