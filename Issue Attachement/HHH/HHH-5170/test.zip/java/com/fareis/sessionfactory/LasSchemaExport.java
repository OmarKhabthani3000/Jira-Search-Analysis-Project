package com.fareis.sessionfactory;

import java.sql.Connection;
import java.sql.Statement;

import org.hibernate.HibernateException;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Settings;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class LasSchemaExport extends SchemaExport
{
  private Settings settings;

  public LasSchemaExport(Configuration cfg, Settings settings)
    throws HibernateException
  {
    super(cfg, settings);
    this.settings = settings;
  }

  public void createSchemas()
  {
    Connection connection = null;
    Statement statement = null;
    String schemaSQL = null;

    String[] schemas = { "LAS_CMS", "LAS_COR", "LAS_CSS", "LAS_ENA", "LAS_ITE", "LAS_OSS", "LAS_PRC", "LAS_RPS" };
    try
    {
      connection = this.settings.getConnectionProvider().getConnection();
      statement = connection.createStatement();

      for (String schema : schemas) {
        schemaSQL = "CREATE SCHEMA " + schema + " AUTHORIZATION DBA";
        statement.execute(schemaSQL);
      }

    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    finally
    {
      try
      {
        if (statement != null) {
          statement.close();
        }
        if (connection != null)
          connection.close();
      }
      catch (Exception e)
      {
      }
    }
  }
}