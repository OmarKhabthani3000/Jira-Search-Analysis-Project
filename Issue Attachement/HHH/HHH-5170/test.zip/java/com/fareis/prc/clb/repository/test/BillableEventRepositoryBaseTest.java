package com.fareis.prc.clb.repository.test;

import java.sql.SQLException;

import org.apache.commons.dbcp.BasicDataSource;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.test.AbstractTransactionalDataSourceSpringContextTests;

/**
 * The Base test class BillingRepositoryBaseTest.
 * 
 * @author mnilesh
 */
public abstract class BillableEventRepositoryBaseTest extends
        AbstractTransactionalDataSourceSpringContextTests {

    /** SessionFactory. */
    private SessionFactory sessionFactory;

    /** Session. */
    private Session currentSession;

    /**
     * The onSetUp().
     * 
     * @throws Exception
     *             the Exception.
     */
    @Override
    protected void onSetUp() throws Exception {
        super.onSetUp();
        setDefaultRollback(true);
        testDataSourceName();
        sessionFactory = (SessionFactory) getApplicationContext().getBean(
                "sessionFactory");
        currentSession = sessionFactory.getCurrentSession();

    }

    /**
     * To return the locations of config files.
     * 
     * @return String[]
     */
    @Override
    protected String[] getConfigLocations() {
        setAutowireMode(AUTOWIRE_BY_NAME);
        return new String[] { "classpath*:/**/testRepositoryContext.xml" };
    }

    /**
     * This is to test if the created connection is pointing to HSQLDB if not
     * fail and exit running rest of the test cases.
     * 
     * @throws SQLException
     *             the SQLException
     */
    public void testDataSourceName() throws SQLException {
        BasicDataSource dataSource = (BasicDataSource) this.jdbcTemplate
                .getDataSource();
        // assertEquals("org.hsqldb.jdbcDriver",
        // dataSource.getDriverClassName());
    }

}
