/**
 * 
 */
package com.fareis.prc.clb.repository.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

/**
 * The Class DateUtil.
 * 
 * @author sdeepesh
 */
public final class DateUtil {

    /**
     * Instantiates a new date util.
     */
    private DateUtil() {

    }

    /**
     * Convert string to date.
     * 
     * @param _dateString
     *            the _date string
     * 
     * @return the date
     * 
     * @throws ParseException
     *             the parse exception
     */
    public static Date convertStringToDate(String _dateString)
            throws ParseException {

        return convertStringToDate(_dateString, "yyyy-MM-dd hh:mm:ss.SSS");
    }

    /**
     * Convert string to date.
     * 
     * @param _dateString
     *            the _date string
     * @param _dateFormat
     *            the _date format
     * 
     * @return the date
     * 
     * @throws ParseException
     *             the parse exception
     */
    public static Date convertStringToDate(String _dateString,
            String _dateFormat) throws ParseException {

        if (StringUtils.isBlank(_dateString)) {

            return new Date();
        }
        _dateString = formatDateString(_dateString);
        SimpleDateFormat formatter = new SimpleDateFormat(_dateFormat);
        Date theDate = formatter.parse(_dateString);
        return theDate;
    }

    /**
     * Format date string. Checks the format to be matching with MM-dd-yyyy
     * hh:mm:ss.SSS, else add default values to missing fields
     * 
     * @param _dateString
     *            the _date string
     * 
     * @return the string
     */
    private static String formatDateString(String _dateString) {

        if (_dateString == null) {

            return null;
        }
        if (_dateString
                .matches("[0-9]{2}-[0-9]{2}-[0-9]{4} [0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}")) {

            return _dateString;
        }
        final int noSecondLength = 16;
        final int noMillisecondLength = 19;
        if (_dateString.length() == noSecondLength) {
            _dateString += ":00.000";
        } else if (_dateString.length() == noMillisecondLength) {
            _dateString += ".000";
        }
        return _dateString;
    }
}
