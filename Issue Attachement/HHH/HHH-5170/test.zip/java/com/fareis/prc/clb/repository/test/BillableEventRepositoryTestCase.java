package com.fareis.prc.clb.repository.test;

import java.util.ArrayList;
import java.util.List;

import com.fareis.las.prc.clb.el.domain.Event;
import com.fareis.las.prc.clb.el.domain.EventType;
import com.fareis.las.prc.clb.el.domain.LoanSnap;
import com.fareis.prc.clb.repository.EventRepository;

/**
 * The Test Cases for BillableEventRepositoryTestCase class.
 * 
 * @author mnilesh
 * 
 */
public class BillableEventRepositoryTestCase extends
        BillableEventRepositoryBaseTest {

    /** The BillingRepository. */
    private EventRepository eventRepository = null;

    /** The Constant SKIP_TEST. */
    private static final boolean SKIP_TEST = false;

    /** The client Request Id. */
    private static final int CLIENT_REQUEST_ID = 889;

    /** The event key */
    private static final int EVENT_KEY = 1;

    /** The event type. */
    private static final String EVENT_TYPE = "TWC";

    // Constructor

    /** default Constructor. */
    public BillableEventRepositoryTestCase() {
        System.setProperty("weblogic.env", "junit");
    }

    /**
     * onSetUpBeforeTransaction method.
     * 
     * @throws Exception
     *             the exception
     */
    protected final void onSetUpBeforeTransaction() throws Exception {
        super.onSetUpBeforeTransaction();
        eventRepository = (EventRepository) getApplicationContext().getBean(
                "billingEventDataLibrary");

    }

    /**
     * To setup Delinqueny Data.
     * 
     * @throws Exception
     *             the Exception
     */
    private void setUpData() throws Exception {
        super.executeSqlScript("/BillableEventData.sql", true);

    }

    /**
     * Test AddEvent().
     * 
     * @throws Exception
     *             The Exception
     */

    public final void testAddEvent() throws Exception {

        setUpData();

        Event formedEvent = EventInstanceCreator.getEvent();
        Integer createdEventKey = eventRepository.storeOrUpdateEvent(formedEvent);

        assertEquals(new Integer(1), createdEventKey);

        List<Event> insertedLIst = eventRepository
                .findByClientBillingEventKey(createdEventKey);

        assertNotNull(insertedLIst);
    }

    /**
     * Test FindBillableEventsByCriteria() .
     * 
     * @throws Exception
     *             The Exception
     */
    public void testFindBillableEventsByCriteria() throws Exception {

        if (SKIP_TEST) {
            assertTrue(true);
            return;
        }

        // setUpData();

        // Event formedEvent = EventInstanceCreator.getEvent();
        // eventRepository. storeOrUpdateEvent(formedEvent);

        List<Event> list = eventRepository.findBillableEventsByCriteria(
                EventInstanceCreator.getEventCriteria(), 0, 100);

        /*
         * assertNotNull(list);
         * 
         * for (Event event : list) { assertEquals(new
         * Integer(CLIENT_REQUEST_ID), event .getClientRequestId()); }
         */
    }

    /**
     * Test FindBillableEventDetailsByCriteria().
     * 
     * @throws Exception
     *             The Exception
     */
    public void testFindBillableEventDetailsByCriteria() throws Exception {

        if (SKIP_TEST) {
            assertTrue(true);
            return;
        }

        setUpData();

        Event formedEvent = EventInstanceCreator.getEvent();
        eventRepository.storeOrUpdateEvent(formedEvent);

        List<Event> list = eventRepository.findBillableEventDetailsByCriteria(
                EventInstanceCreator.getEventDetailsCriteria(), 0, 100);

        assertNotNull(list);

        for (Event event : list) {
            assertEquals(new Integer(EVENT_KEY), event
                    .getClientBillingEventKey());
        }
    }

    /**
     * Test BillableEventTypesByCriteria().
     * 
     * @throws Exception
     *             The Exception
     */
    public void testFindBillableEventTypesByCriteria() throws Exception {

        if (SKIP_TEST) {
            assertTrue(true);
            return;
        }

        setUpData();

        List<EventType> list = eventRepository
                .findBillableEventTypesByCriteria(EventInstanceCreator
                        .getEventTypeDetailsCriteria(), 0, 100);

        assertNotNull(list);

        for (EventType eventType : list) {
            assertEquals(EVENT_TYPE, eventType.getEventType());
        }
    }

    /**
     * Test FindDomainValuesByCriteria().
     * 
     * @throws Exception
     *             The Exception
     */
    public void testFindDomainValuesByCriteria() throws Exception {

        if (SKIP_TEST) {
            assertTrue(true);
            return;
        }

        setUpData();

        Event formedEvent = EventInstanceCreator.getEvent();
        eventRepository. storeOrUpdateEvent(formedEvent);

        List<Object> list = eventRepository.findDomainValuesByCriteria(
                EventInstanceCreator.getDomainValuesByCriteria(), 0, 100);

        assertNotNull(list);

        for (Object objLoanSnap : list) {
            LoanSnap loanSnap = (LoanSnap) objLoanSnap;
            assertEquals("A", loanSnap.getHighLiabilityFlag());
        }
    }

    /**
     * Test FindDomainValuesByCriteria().
     * 
     * @throws Exception
     *             The Exception
     */
    public void testUpdateCorrelationDate() throws Exception {

        setUpData();

        Event formedEvent = EventInstanceCreator.getEvent();
        eventRepository. storeOrUpdateEvent(formedEvent);

        List<String> srcTransIds = new ArrayList<String>();
        srcTransIds.add("NIL0001");
        eventRepository.updateCorrelationDate(srcTransIds);
    }
}
