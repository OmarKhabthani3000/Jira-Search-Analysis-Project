/**
 * 
 */
package com.fareis.prc.clb.repository.test;

import java.sql.Date;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import org.hibernate.FetchMode;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.fareis.las.css.cln.cl.domain.Client;
import com.fareis.las.css.sys.rf.domain.Country;
import com.fareis.las.css.sys.rf.domain.State;
import com.fareis.las.css.sys.rf.domain.StateId;
import com.fareis.las.prc.clb.el.domain.Event;
import com.fareis.las.prc.clb.el.domain.EventService;
import com.fareis.las.prc.clb.el.domain.EventType;
import com.fareis.las.prc.clb.el.domain.LoanSnap;
import com.fareis.las.prc.clb.el.domain.LoanSnapId;
import com.fareis.las.prc.clb.el.domain.ParcelLegalSnap;
import com.fareis.las.prc.clb.el.domain.ParcelLegalSnapId;
import com.fareis.las.prc.clb.el.domain.ParcelSnap;
import com.fareis.las.prc.clb.el.domain.ParcelSnapId;

/**
 * The Class BillableEventClient.
 * 
 * @author sdeepesh
 */
public final class EventInstanceCreator {

    /**
     * Gets the event.
     * 
     * @return the event
     * 
     * @throws Exception
     *             the exception
     */
    public static Event getEvent() throws Exception {

        Random randomNumber = new Random();
        String eventType = "TWC";
        Integer clientId = 59307;

        String sourceId = "Republic Day Two Testing";
        Integer clientRequestId = 889;
        String clientRequestOriginalCode = "TAX";
        String clientUserId = "Homi Babha";
        String clientBillingEventSourceTransactionId = "L0001";

        String clientTransactionId = randomNumber.nextInt(178) + ""
                + randomNumber.nextInt(212) + "" + randomNumber.nextInt(20);

        String requestSentTimeStamp = "2010-01-18 04:07:25";

        String requestReceiveTimeStamp = "2010-01-18 04:07:25";
        String eventRetainTimeStamp = "2010-01-18 04:07:25";

        String clientRequestType = "ABC";
        String clientProvideTaxAuthorityId = "AMX_CARD";
        String extractTimeStamp = "2010-01-18 04:07:25";
        String extractStatusCode = "EOD";
        String extractUserId = "uxbdas";
        String eventDataType = "LOW";
        String statusCode = "A";
        String lastUpdateSourceId = "PLASTIC INSTANT";
        String lastUpdateUserId = "uxbdv1";
        String lastUpdateTimeStamp = "2010-01-18 05:07:25";
        String serviceId = "NO SERVICE ID";
        String serviceType = "REQ";
        String taxAuthorityId = "TAX_AUTH";

        Integer billingId = 22;
        String regionServiceCenterCode = "5432";

        String serviceStatusCode = "DS";
        Double paidFeeAmount = 112D;
        String serviceReInstDate = "2010-01-01 05:07:25";
        String serviceStartDate = "2010-01-02 05:07:25";
        String serviceEndDate = "2010-12-01 05:07:25";
        String lastPaidDate = "2010-01-01 05:07:25";
        String productId = "CCS";
        String countryCode = "US";
        String stateCode = "TX";
        String xmlText = "This is a blob xml";
        String taxId = "tax id text";
        String paidType = "1211";

        String eventCommentText = "Cheque";
        Integer loanKey = 668899;
        String loanId = "BOX9988";
        Long investmentId = 1122L;
        String highliabilityFlag = "A";
        String loanOriginalDate = "2009-02-01 05:07:25";
        Integer loanTermMonthNumber = 1;
        Integer loanStatusKey = 12;
        Integer loanTypeKey = 1;
        Double paymentAmount = 100.00;
        String loanLoadDate = "2009-01-30 05:07:25";
        String loanCancelDate = "2009-12-30 05:07:25";
        String loanRefinanceDate = "2010-01-02 05:07:25";
        String loanStatusChangeDate = "2009-01-30 05:07:25";
        String loanCloseDate = "2009-01-30 05:07:25";
        String firstMortgagePaymentDate = "2009-02-30 05:07:25";
        String loadDate = "2009-01-30 05:07:25";

        String previouLoanId = "1100";

        Integer parcelKey = 1001;
        Integer parcelLegalKey = 727;
        String lotId = "LLOT1";
        String blockId = "DDD";
        String platBookId = "PLID1";
        String platPageId = "PLPG1";

        String tractId = "TRCK1";
        String ownerRecordBookId = "OWNR1";
        String ownerRecordPageId = "OWRP1";
        String sectionId = "SECT1";
        String townShipId = "TOWN1";
        String subDivisionId = "SUBDI";
        String rangeId = "RANG1";
        String unitId = "UNIT1";
        String condominumId = "CNDM1";
        String statusChangeDate = "2009-09-30 05:07:25";
        Integer standardFormatControlKey = 123;
        String phaseId = "PHASE-A";
        String legalStatusCode = "LGL";

        String surveyId = "SURV1";

        String mapInformationText = "MAPIN";
        String censusTractCode = "TRAX";

        String subLotId = "QOP5";

        Long investorId = 82L;

        Integer parcelTypeKey = 1;
        String streetPreDirectionCode = "OF";
        String streetType = "MAIN";
        String streetNumberText = "AB";

        String streetNumberFractionText = "AB";

        String streetName = "Washington Street";

        String streetPostDirectionCode = "LF";
        String unitNumberText = "UNIT";

        String purchaseOrderBoxNumberText = "PURORD112";
        String railRoadCode = "DA";
        String railroadNumberText = "DAX";
        String cityName = "Dallas";
        String postalCode = "560093";
        String neighborhoodCode = "GEORGE BUSH";

        Event clientBillingEvent = new Event();

        System.out.println(clientId + "  " + clientTransactionId + " "
                + eventType);

        Client client = new Client();
        client.setClientId(clientId);

        clientBillingEvent.setClientId(client);

        clientBillingEvent.setClientTransactionId(clientTransactionId);

        EventType eventTypeObj = new EventType();
        eventTypeObj.setEventType(eventType);
        clientBillingEvent.setEventType(eventTypeObj);
        clientBillingEvent.setSourceId(sourceId);
        clientBillingEvent.setCorrDate(new java.sql.Date(System
                .currentTimeMillis()));
        clientBillingEvent.setClientRequestId(clientRequestId);
        clientBillingEvent.setRequestSentTimestamp(DateUtil
                .convertStringToDate(requestSentTimeStamp));
        clientBillingEvent.setRequestReceiveTimestamp(DateUtil
                .convertStringToDate(requestReceiveTimeStamp));
        clientBillingEvent.setEventRetainTimestamp(DateUtil
                .convertStringToDate(eventRetainTimeStamp));
        clientBillingEvent.setClientRequestType(clientRequestType);
        clientBillingEvent
                .setClientProvideTaxAuthorityId(clientProvideTaxAuthorityId);
        clientBillingEvent.setEventDataType(eventDataType);
        clientBillingEvent.setStatusCode(statusCode);
        clientBillingEvent.setLastUpdateSourceId(lastUpdateSourceId);
        clientBillingEvent.setLastUpdateTimestamp(DateUtil
                .convertStringToDate(lastUpdateTimeStamp));
        clientBillingEvent.setLastUpdateUserId(lastUpdateUserId);
        clientBillingEvent
                .setClientBillingEventSourceTransactionId(clientBillingEventSourceTransactionId);

        /* non-mandatory fields */
        clientBillingEvent
                .setClientRequestOriginalCode(clientRequestOriginalCode);
        clientBillingEvent.setExtractTimestamp(DateUtil
                .convertStringToDate(extractTimeStamp));
        clientBillingEvent.setExtractStatusCode(extractStatusCode);
        clientBillingEvent.setExtractUserId(extractUserId);
        clientBillingEvent.setClientUserId(clientUserId);
        
        EventService service = new EventService();
        State state = new State();
        StateId id = new StateId();
        id.setStateCode("DAS");
        Country country = new Country();
        country.setCountryCode("US");
        id.setCountryCode(country);
        state.setId(id);
        service.setBillingId(10);
        service.setStatusCode("A");
        service.setState(state);
        service.setClientBillingEventKey(clientBillingEvent);
        service.setLastUpdateSourceId("TEST");
        service.setLastUpdateTimestamp(new java.util.Date());
        service.setLastUpdateUserId("sdeepesh");
        service.setCorrDate(new Date(System.currentTimeMillis()));
        Set<EventService> eventServices = new HashSet<EventService>();
        eventServices.add(service);
        
        clientBillingEvent.setEventServices(eventServices);
        /* end of client billing event */

        /*
         * clientBillingEventCrossReferencesForCrossReferenceClientBillingEventKey
         * EventCrossReference oneRef = new EventCrossReference();
         * EventCrossReferenceType eType = new EventCrossReferenceType();
         * eType.setEventCrossReferenceType("DEL");
         * oneRef.setEventCrossReferenceType(eType);
         */

        /*
         * forming composite-id 1 EventCrossReferenceId oneId = new
         * EventCrossReferenceId();
         * oneId.setClientBillingEventKey(clientBillingEvent); Event crossKey1 =
         * new Event(); crossKey1.setClientBillingEventKey(684);
         * oneId.setCrossReferenceClientBillingEventKey(crossKey1);
         */
        /*
         * end of composite-id 1
         * 
         * oneRef.setId(oneId); oneRef.setStatusCode(statusCode);
         * oneRef.setLastUpdateSourceId(lastUpdateSourceId);
         * oneRef.setLastUpdateTimestamp(DateUtil
         * .convertStringToDate(lastUpdateTimeStamp));
         * oneRef.setLastUpdateUserId(lastUpdateUserId);
         * 
         * 
         * EventCrossReference twoRef = new EventCrossReference();
         * twoRef.setEventCrossReferenceType(eType);
         */

        /*
         * forming composite-id 2 EventCrossReferenceId twoId = new
         * EventCrossReferenceId();
         * twoId.setClientBillingEventKey(clientBillingEvent); Event crossKey2 =
         * new Event(); crossKey2.setClientBillingEventKey(550);
         * twoId.setCrossReferenceClientBillingEventKey(crossKey2); /* end of
         * composite-id 2
         * 
         * 
         * twoRef.setId(twoId); twoRef.setStatusCode(statusCode);
         * twoRef.setLastUpdateSourceId(lastUpdateSourceId);
         * twoRef.setLastUpdateTimestamp(DateUtil
         * .convertStringToDate(lastUpdateTimeStamp));
         * twoRef.setLastUpdateUserId(lastUpdateUserId);
         * 
         * Set<EventCrossReference> xRefSet = new HashSet<EventCrossReference>();
         * xRefSet.add(oneRef); xRefSet.add(twoRef); clientBillingEvent
         * .setEventCrossReferencesForCrossReferenceClientBillingEventKey(xRefSet);
         */
        /* end of cross reference */
        /* clientBillingLoanSnapshots : Set */
        LoanSnap loan = new LoanSnap();
        /* forming id */
        LoanSnapId loanCompId = new LoanSnapId();
        loanCompId.setClientBillingEventKey(clientBillingEvent);
        loanCompId.setLoanKey(loanKey);/* id formed */
        loan.setId(loanCompId);
        loan.setLoanId(loanId);
        loan.setStatusCode(statusCode);
        loan.setCorrDate(new java.sql.Date(System.currentTimeMillis()));
        loan.setLastUpdateSourceId(lastUpdateSourceId);
        loan.setLastUpdateUserId(lastUpdateUserId);
        loan.setLastUpdateTimestamp(DateUtil
                .convertStringToDate(lastUpdateTimeStamp));

        loan.setInvestmentId(investmentId);
        loan.setHighLiabilityFlag(highliabilityFlag);
        loan.setLoanOriginalDate(new Date(DateUtil.convertStringToDate(
                loanOriginalDate).getTime()));
        loan.setLoanCancelDate(new Date(DateUtil.convertStringToDate(
                loanCancelDate).getTime()));
        loan.setLoanCloseDate(new Date(DateUtil.convertStringToDate(
                loanCloseDate).getTime()));
        loan.setLoanRefinanceDate(new Date(DateUtil.convertStringToDate(
                loanRefinanceDate).getTime()));
        loan.setLoanStatusChangeDate(new Date(DateUtil.convertStringToDate(
                loanStatusChangeDate).getTime()));
        loan.setLoanLoadDate(new Date(DateUtil
                .convertStringToDate(loanLoadDate).getTime()));
        loan.setFirstMortgagePaymentDate(new Date(DateUtil.convertStringToDate(
                firstMortgagePaymentDate).getTime()));
        loan.setLoadDate(new Date(DateUtil.convertStringToDate(loadDate)
                .getTime()));

        loan.setPreviousLoanId(previouLoanId);
        loan.setLoanTermMonthNumber(loanTermMonthNumber);
        loan.setLoanStatusKey(loanStatusKey);
        loan.setLoanTypeKey(loanTypeKey);
        loan.setPaymentAmount(paymentAmount);
        Set<LoanSnap> loanSet = new HashSet<LoanSnap>();
        loanSet.add(loan);
        clientBillingEvent.setLoanSnaps(loanSet);
        /* end of loan */
        /*
         * clientBillingEventServices : Set EventService serv = new
         * EventService(); serv.setServiceId(serviceId);
         * serv.setBillingId(billingId); serv.setStatusCode(statusCode);
         * serv.setLastUpdateUserId(lastUpdateUserId);
         * serv.setLastUpdateTimestamp(DateUtil.convertStringToDate(lastUpdateTimeStamp));
         * serv.setProductId(productId); serv.setCountryCode(countryCode);
         * serv.setStateCode(stateCode); serv.setXmlText(xmlText);
         * serv.setPaidFeeAmount(paidFeeAmount); serv.setTaxId(taxId);
         * serv.setPaidType(paidType);
         * serv.setEventCommentText(eventCommentText);
         * serv.setServiceStatusCode(serviceStatusCode);
         */
        /*
         * all java.sql.Date s serv.setServiceEndDate(new
         * Date(DateUtil.convertStringToDate(serviceEndDate).getTime()));
         * serv.setServiceReinstDate(new
         * Date(DateUtil.convertStringToDate(serviceReInstDate).getTime()));
         * serv.setServiceStartDate(new
         * Date(DateUtil.convertStringToDate(serviceStartDate).getTime()));
         * serv.setLastPaidDate(new
         * Date(DateUtil.convertStringToDate(lastPaidDate).getTime()));
         * 
         * serv.setRegionServiceCenterCode(regionServiceCenterCode);
         * serv.setServiceType(serviceType);
         * serv.setTaxAuthorityId(taxAuthorityId);
         * serv.setClientBillingEventKey(clientBillingEvent); Set<EventService>
         * servSet = new HashSet<EventService>(); servSet.add(serv);
         */
        // Commented due to xml_text_rowid not-null property being auto
        // generated.
        // clientBillingEvent.setEventServices(servSet);
        /* clientBillingParcelSnapshots : Set */
        ParcelSnap parcel = new ParcelSnap();
        ParcelSnapId parcelId = new ParcelSnapId();
        parcelId.setClientBillingEventKey(clientBillingEvent);
        parcelId.setParcelKey(parcelKey);
        parcel.setId(parcelId);
        parcel.setCorrDate(new java.sql.Date(System.currentTimeMillis()));
        parcel.setStatusCode(statusCode);
        parcel.setLastUpdateSourceId(lastUpdateSourceId);
        parcel.setLastUpdateUserId(lastUpdateUserId);
        parcel.setLastUpdateTimestamp(DateUtil
                .convertStringToDate(lastUpdateTimeStamp));

        parcel.setSurveyId(surveyId);
        parcel.setStateCode(stateCode);
        parcel.setCensusTractCode(censusTractCode);
        parcel.setCountryCode(countryCode);
        parcel.setNeighborhoodCode(neighborhoodCode);
        parcel.setMapInformationText(mapInformationText);
        parcel.setRailroadCode(railRoadCode);
        parcel.setRailroadNumberText(railroadNumberText);
        parcel.setCityName(cityName);
        parcel.setPostalCode(postalCode);
        parcel.setPurchaseorderBoxNumberText(purchaseOrderBoxNumberText);
        parcel.setUnitNumberText(unitNumberText);
        parcel.setStreetPostDirectionCode(streetPostDirectionCode);
        parcel.setStreetName(streetName);
        parcel.setStreetNumberFractionText(streetNumberFractionText);
        parcel.setStreetNumberText(streetNumberText);
        parcel.setStreetPreDirectionCode(streetPreDirectionCode);
        parcel.setStreetType(streetType);
        parcel.setParcelTypeKey(parcelTypeKey);
        parcel.setInvestorId(investorId);
        parcel.setSubLotId(subLotId);
        Set<ParcelSnap> parcelSet = new HashSet<ParcelSnap>();
        parcelSet.add(parcel);
        clientBillingEvent.setParcelSnaps(parcelSet);

        /* clientBillingParcelLegalSnapshots : Set */
        ParcelLegalSnap legal = new ParcelLegalSnap();
        ParcelLegalSnapId plId = new ParcelLegalSnapId();
        plId.setClientBillingEventKey(clientBillingEvent);
        plId.setParcelLegalKey(parcelLegalKey);
        legal.setId(plId);
        legal.setParcelKey(parcelKey);
        legal.setStatusCode(statusCode);
        legal.setCorrDate(new java.sql.Date(System.currentTimeMillis()));
        legal.setLastUpdateSourceId(lastUpdateSourceId);
        legal.setLastUpdateUserId(lastUpdateUserId);
        legal.setLastUpdateTimestamp(DateUtil
                .convertStringToDate(lastUpdateTimeStamp));

        legal.setLotId(lotId);
        legal.setBlockId(blockId);
        legal.setPlatBookId(platBookId);
        legal.setPlatPageId(platPageId);
        legal.setOwnerRecordBookId(ownerRecordBookId);
        legal.setOwnerRecordPageId(ownerRecordPageId);
        legal.setRangeId(rangeId);
        legal.setUnitId(unitId);
        legal.setCondominumId(condominumId);
        legal.setStatusChangeDate(DateUtil
                .convertStringToDate(statusChangeDate));
        legal.setPhaseId(phaseId);
        legal.setSectionId(sectionId);
        legal.setTownshipId(townShipId);
        legal.setSubdivisionId(subDivisionId);
        legal.setTractId(tractId);

        legal.setStandardFormatControlKey(standardFormatControlKey);
        legal.setPhaseId(phaseId);
        legal.setLegalStatusCode(legalStatusCode);

        Set<ParcelLegalSnap> lgSet = new HashSet<ParcelLegalSnap>();
        lgSet.add(legal);

        clientBillingEvent.setParcelLegalSnaps(lgSet);

        return clientBillingEvent;
    }

    public static DetachedCriteria getEventCriteria() throws Exception {

        DetachedCriteria hibernateCriteria = DetachedCriteria
                .forClass(Event.class);

        hibernateCriteria.setFetchMode("loanSnaps", FetchMode.SELECT);

        ProjectionList allProjections = Projections.projectionList();
        allProjections.add(Projections.groupProperty("clientBillingEventKey"));
        allProjections.add(Projections.groupProperty("clientRequestId"));

        DetachedCriteria joinAlias = hibernateCriteria.createAlias("loanSnaps",
                "loanSnaps");
        // joinAlias.add(Expression.eq("loanSnaps.loanId", true));
        allProjections.add(Projections.groupProperty("loanSnaps.loanId"));

        hibernateCriteria.setProjection(allProjections);

        // hibernateCriteria.addOrder(Order.asc("clientRequestId"));
        hibernateCriteria.add(Restrictions.eq("clientRequestId", new Integer(
                889)));

        return hibernateCriteria;
    }

    public static DetachedCriteria getEventDetailsCriteria() throws Exception {

        DetachedCriteria hibernateCriteria = DetachedCriteria
                .forClass(Event.class);
        hibernateCriteria.addOrder(Order.asc("clientBillingEventKey"));
        hibernateCriteria.add(Restrictions.eq("clientBillingEventKey",
                new Integer(1)));
        return hibernateCriteria;
    }

    public static DetachedCriteria getEventTypeDetailsCriteria()
            throws Exception {

        DetachedCriteria hibernateCriteria = DetachedCriteria
                .forClass(EventType.class);
        hibernateCriteria.addOrder(Order.asc("eventType"));
        hibernateCriteria.add(Restrictions.eq("eventType", "TWC"));
        return hibernateCriteria;
    }

    public static DetachedCriteria getDomainValuesByCriteria() throws Exception {

        DetachedCriteria hibernateCriteria = DetachedCriteria
                .forClass(LoanSnap.class);
        hibernateCriteria.addOrder(Order.asc("highLiabilityFlag"));
        hibernateCriteria.add(Restrictions.eq("highLiabilityFlag", "A"));
        return hibernateCriteria;
    }
    
}
