/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * License: GNU Lesser General Public License (LGPL), version 2.1 or later.
 * See the lgpl.txt file in the root directory or <http://www.gnu.org/licenses/lgpl-2.1.html>.
 */
package org.hibernate.envers.bugs;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.criteria.CriteriaQuery;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RevisionNumber;
import org.junit.Test;

public class EnversUnitTestCase extends AbstractEnversTestCase {

	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
			SomeEntity.class,
			OtherEntity.class
		};
	}

	@Test
	public void test() throws Exception {
		/*
		 * Put new stuff in database
		 */
		Session session = openSession();

		session.getTransaction().begin();

		SomeEntity someEntity = new SomeEntity();
		session.save(someEntity);
		OtherEntity otherEntity = new OtherEntity();
		session.save(otherEntity);

		someEntity.getMap().put(otherEntity, SomeEntity.Status.A);

		session.getTransaction().commit();

		/*
		 * Attempt to update map
		 */
		session.getTransaction().begin();

		CriteriaQuery<SomeEntity> query1 = session.getCriteriaBuilder().createQuery(SomeEntity.class);
		query1.select(query1.from(SomeEntity.class));
		someEntity = session.createQuery(query1).getSingleResult();

		CriteriaQuery<OtherEntity> query2 = session.getCriteriaBuilder().createQuery(OtherEntity.class);
		query2.select(query2.from(OtherEntity.class));
		otherEntity = session.createQuery(query2).getSingleResult();

		someEntity.getMap().put(otherEntity, SomeEntity.Status.B);

		session.getTransaction().commit();

		session.close();
	}

	@Entity
	@Audited
	public static class SomeEntity
	{
		@Id
		@GeneratedValue
		@Column
		@RevisionNumber
		private Long id;

		// XXX: uncommenting the line below makes the error go away
//		@NotAudited
		@ElementCollection(fetch = FetchType.LAZY)
		private Map<OtherEntity, Status> map = new HashMap<>();

		public Long getId()
		{
			return id;
		}

		public void setId(Long id)
		{
			this.id = id;
		}

		public Map<OtherEntity, Status> getMap()
		{
			return map;
		}

		public void setMap(Map<OtherEntity, Status> map)
		{
			this.map = map;
		}

		public enum Status
		{
			A,
			B
		}
	}

	@Entity
	@Audited
	public static class OtherEntity
	{
		@Id
		@GeneratedValue
		@Column
		@RevisionNumber
		private Long id;

		public Long getId()
		{
			return id;
		}

		public void setId(Long id)
		{
			this.id = id;
		}
	}
}
