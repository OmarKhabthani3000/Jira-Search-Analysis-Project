package org.hibernate.bugs;

import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import acme.hibernatetest.entities.Node;
import acme.hibernatetest.entities.NodeRelation;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		// prepare data in separate transaction
		entityManager.getTransaction().begin();
		Node leafNode = new Node("Leaf", Collections.emptyList());
		entityManager.persist(leafNode);
		
		Node innerNode = new Node("Inner", Collections.singletonList(leafNode));
		entityManager.persist(innerNode);
		
		Node rootNode = new Node("Root", Collections.singletonList(innerNode));
		entityManager.persist(rootNode);
		
		entityManager.persist(new NodeRelation(rootNode, rootNode, 0));
		entityManager.persist(new NodeRelation(rootNode, innerNode, 1));		
		entityManager.persist(new NodeRelation(rootNode, leafNode, 2));
		entityManager.persist(new NodeRelation(innerNode, innerNode, 0));		
		entityManager.persist(new NodeRelation(innerNode, leafNode, 1));
		entityManager.persist(new NodeRelation(leafNode, leafNode, 0));
		
		entityManager.getTransaction().commit();
		
		// clear all cached entities
		entityManager.clear();		
		
		entityManager.getTransaction().begin();
		
		// we don't care here about the result here
		List<NodeRelation> relations = 
				entityManager.createQuery("SELECT nr FROM NodeRelation AS nr LEFT JOIN FETCH nr.descendant d LEFT JOIN FETCH d.children", NodeRelation.class).getResultList();

		// of interest is the Node with id "Inner" which has incorrectly 2 children (two times the same object)
		Node n = entityManager.find(Node.class, "Inner");		
		Assert.assertNotNull(n);
		Assert.assertEquals(1, n.getChildren().size());
		
		entityManager.getTransaction().rollback();
		entityManager.close();
	}
}
