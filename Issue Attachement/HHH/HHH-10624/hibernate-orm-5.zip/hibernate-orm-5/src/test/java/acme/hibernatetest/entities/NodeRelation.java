package acme.hibernatetest.entities;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class NodeRelation {
	
	@Id
	private String uuid;
	
	@ManyToOne
	private Node ancestor;
	
	@ManyToOne
	private Node descendant;
	
	private int distance;
	
	
	NodeRelation() {
		// required for JPA
	}
	
	public NodeRelation(Node ancestor, Node descendant, int distance) {
		uuid = UUID.randomUUID().toString();
		this.ancestor = ancestor;
		this.descendant = descendant;
		this.distance = distance;
	}

	public String getUuid() {
		return uuid;
	}

	public Node getAncestor() {
		return ancestor;
	}

	public Node getDescendant() {
		return descendant;
	}
	
	public int getDistance() {
		return distance;
	}
	
}
