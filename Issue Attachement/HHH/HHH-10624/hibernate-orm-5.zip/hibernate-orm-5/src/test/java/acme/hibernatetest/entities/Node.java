package acme.hibernatetest.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Node {

	@Id
	private String name;

	@OneToMany
	private List<Node> children;
	
	Node () {
		// required for JPA
	}
	
	public Node(String name, List<Node> children) {
		this.name = name;
		this.children = new ArrayList<>(children);
	}
		
	public String getName() {
		return name;
	}
	
	public List<Node> getChildren() {
		return children;
	}	
}
