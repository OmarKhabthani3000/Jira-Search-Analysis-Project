
package test.events;

import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * 
 */
public class TestCat_tc extends TestCase
{
    private final SessionFactory sessionFactory = buildSessionFactory();

    private SessionFactory buildSessionFactory()
    {
        try
        {
            // Create the SessionFactory from hibernate.cfg.xml
            return new Configuration().configure().buildSessionFactory();
        }
        catch (Throwable ex)
        {
            // Make sure you log the exception, as it might be swallowed
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public SessionFactory getSessionFactory()
    {
        return sessionFactory;
    }

    public void test1() 
    {
        Session session = getSessionFactory().openSession();
        long id = new Date().getTime();

        Cat cat1 = new Cat();
        cat1.setName("Garfield " + id);
        cat1.setSex("Male");
        cat1.setGeburtstag(new Date());

        session.beginTransaction();
        session.save(cat1);
        session.getTransaction().commit();
        session.close();
        
        // liest die row mit HQL
        session = getSessionFactory().openSession();
        Query query = session.createQuery("from Cat where name like :name");
        query.setParameter("name", "Garfield " + id);

        List result = query.list();
        assertEquals(1, result.size());
        Cat cat2 = (Cat) result.get(0);
        assertEquals(cat1.getName(), cat2.getName());
        assertEquals(cat1.getGeburtstag(), cat2.getGeburtstag());
        
        session.close();
    }
}
