package test.events;

import org.hibernate.event.PostInsertEvent;
import org.hibernate.event.PostInsertEventListener;

/**
 * PreInsertEventListener.
 */
public class MyPostInsertEventListener implements PostInsertEventListener
{
    private static final long serialVersionUID = 4872510836550023950L;

    @Override
    public void onPostInsert(PostInsertEvent event)
    {
        System.out.println(">>> PostInsert: " + event.getEntity());        
    }
}
