package test.events;

import org.hibernate.HibernateException;
import org.hibernate.event.FlushEvent;
import org.hibernate.event.FlushEventListener;

/**
 * FlushEventListener.
 */
public class MyFlushEventListener implements FlushEventListener
{
    private static final long serialVersionUID = 2742594238835389921L;

    @Override
    public void onFlush(FlushEvent event) throws HibernateException
    {
        System.out.println(">>> onFlush: " + event);
    }
}
