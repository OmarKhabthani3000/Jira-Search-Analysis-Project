package test.events;

import org.hibernate.event.PreInsertEvent;
import org.hibernate.event.PreInsertEventListener;

/**
 * PreInsertEventListener.
 */
public class MyPreInsertEventListener implements PreInsertEventListener
{
    private static final long serialVersionUID = -2091003263774798759L;

    @Override
    public boolean onPreInsert(PreInsertEvent event)
    {
        System.out.println(">>> PreInsert: " + event.getEntity());
        return false;
    }
}
