package test.events;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 */
public class Cat  implements Serializable
{
    private static final long serialVersionUID = 284312284203226850L;

    private long m_id;

    private String m_name;

    private String m_sex;

    private Date m_geburtstag;

    /**
     * Default Constructor.
     */
    public Cat()
    {
    }
    
    public long getId()
    {
        return m_id;
    }

    public void setId(long id)
    {
        m_id = id;
    }

    public String getName()
    {
        return m_name;
    }

    public void setName(String name)
    {
        m_name = name;
    }

    public String getSex()
    {
        return m_sex;
    }

    public void setSex(String sex)
    {
        m_sex = sex;
    }

    public Date getGeburtstag()
    {
        return m_geburtstag;
    }

    public void setGeburtstag(Date geburtstag)
    {
        m_geburtstag = geburtstag;
    }

    @Override
    public String toString()
    {
        return "Cat: id=" + getId() + " name=" + getName();
    }
}
