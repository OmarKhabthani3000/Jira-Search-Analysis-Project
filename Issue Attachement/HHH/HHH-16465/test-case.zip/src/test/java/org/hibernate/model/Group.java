package org.hibernate.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Objects;

@Entity
@Table(name = "GROUP_TABLE")
public class Group {

    @Id
    private Long id;

    @Column(name = "NAME", nullable = false)
    private String name;

    public Group() {
    }

    public Group(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;

        if (!(obj instanceof Group))
            return false;

        Group other = (Group) obj;

        return Objects.equals(getId(), other.getId());
    }

    @Override
    public String toString() {
        return "Group[id=" + id + ", name=" + name + "]";
    }
}
