package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Tuple;
import org.hibernate.model.Group;
import org.hibernate.model.GroupTree;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        // Create and persist Group entities
        Group group1 = new Group(1L, "Group 1");
        entityManager.persist(group1);

        Group group2 = new Group(2L, "Group 2");
        entityManager.persist(group2);

        Group group3 = new Group(3L, "Group 3");
        entityManager.persist(group3);

        Group group4 = new Group(4L, "Group 4");
        entityManager.persist(group4);

        // Create and persist GroupTree entities
        GroupTree groupTree1 = new GroupTree(1L, group3, group2);
        entityManager.persist(groupTree1);

        GroupTree groupTree2 = new GroupTree(2L, group4, group3);
        entityManager.persist(groupTree2);

        GroupTree groupTree11 = new GroupTree(11L, group2, group1);  // ID 11L intentional => 11 + char(0) + char(0)) LIKE ('%' + '1' + char(0) + char(0)) = TRUE
        entityManager.persist(groupTree11);

        entityManager.getTransaction().commit();
        entityManager.close();

        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        /* Group Tree *

            Group 4
                \    		(GroupTree id=2)
                Group 3
                   \ 		(GroupTree id=1)
                 Group 2
                     \ 	  	(GroupTree id=11)
                    Group 1
         */

        List<Tuple> allParentsResult = entityManager.createQuery(
                        "WITH AllParents AS(" +
                                "SELECT c child, p parent, gt.id groupTreeId" +
                                "   FROM GroupTree gt" +
                                " INNER JOIN gt.parent p" +
                                " INNER JOIN gt.child c " +
                                "  WHERE c = :start " +
                                "UNION ALL " +
                                " SELECT c2 child, p2 parent, gt2.id groupTreeId " +
                                "   FROM AllParents cte " +
                                " JOIN GroupTree gt2 ON cte.parent = gt2.child " +
                                " INNER JOIN gt2.parent p2" +
                                " INNER JOIN gt2.child c2" +
                                ") cycle groupTreeId set cycleMark " +
                                "SELECT ap.child, ap.parent, ap.groupTreeId, ap.cycleMark FROM AllParents ap", Tuple.class)
                .setParameter("start", group1)
                .getResultList();

        // Create a list of all parents
        List<Group> allParents =
                allParentsResult.stream()
                        .map(it -> (Group) it.get(1))
                        .collect(Collectors.toList());

        Assert.assertTrue(allParents.contains(group2));
        Assert.assertTrue(allParents.contains(group3));
        Assert.assertTrue(allParents.contains(group4));
        Assert.assertEquals(3, allParents.size());

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
