package org.hibernate.model;

import jakarta.persistence.*;

@Entity
@Table(name = "GROUP_TREE_TABLE")
public class GroupTree {

    @Id
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "PARENT_ID", nullable = false)
    private Group parent;

    @ManyToOne(optional = false)
    @JoinColumn(name = "CHILD_ID", nullable = false)
    private Group child;

    public GroupTree() {
    }

    public GroupTree(Long id, Group parent, Group child) {
        this.id = id;
        this.parent = parent;
        this.child = child;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Group getParent() {
        return parent;
    }

    public void setParent(Group parent) {
        this.parent = parent;
    }

    public Group getChild() {
        return child;
    }

    public void setChild(Group child) {
        this.child = child;
    }

    @Override
    public String toString() {
        return "GroupTree[id=" + id + ", parentId=" + parent.getId() + ", childId=" + child.getId() + "]";
    }
}
