package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import java.util.Set;

@Entity
public class Network {
    @Id
    private Long id;

    @ManyToMany(mappedBy = "networks")
    private Set<CategorySet> categorySets;
}
