package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import java.util.Set;

@Entity
public class CategorySet {
    @Id
    private Long id;

    @ManyToMany
    @JoinTable
    private Set<Network> networks;

    @OneToMany(mappedBy = "categorySet")
    private Set<Category> categories;
}
