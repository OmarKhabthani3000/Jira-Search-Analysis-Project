Hibernate Bug:

   Using formula-based property causes invalid SQL code for children "subselect" query

Requirements:

   The test project was written for use with Gradle 2.6.

Instructions for running test:

   - Run 'gradle cleanTest test', you'll get an exception.
   - Change fetch="subselect" to fetch="select" on <bag> tag in Name.hbm.xml
   - Test runs fine now
   - Change back to fetch="subselect" on <bag> tag in Name.hbm.xml
   - Running 'gradle cleanTest test' gives an exception
   - Comment out the <property> tag for nameLength in Name.hbm.xml
   - 'gradle cleanTest test' will run now (but nameLength will be zero)

Conclusion:

   The formula and the subselect both work independently, but Hibernate breaks
   if you use them together.

The test case uses an in-memory HSQLDB database populated from scratch on running the test.

The test case was run against versions 3.6.10.Final, 4.3.7.Final and 5.0.0.Final
