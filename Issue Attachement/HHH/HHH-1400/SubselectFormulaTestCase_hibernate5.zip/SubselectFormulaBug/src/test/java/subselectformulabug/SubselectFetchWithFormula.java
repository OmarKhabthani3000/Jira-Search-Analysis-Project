package subselectformulabug;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.BeforeClass;
import org.junit.Test;

public class SubselectFetchWithFormula {
	private static SessionFactory sessionFactory;

	@BeforeClass
	public static void setup() {
		sessionFactory = new Configuration().configure().buildSessionFactory();

		Session session = sessionFactory.openSession();
		try {
			Name chris = new Name();
			chris.setId(1);
			chris.setName("chris");
			Value cat = new Value();
			cat.setId(1);
			cat.setName(chris);
			cat.setValue("cat");
			Value canary = new Value();
			canary.setId(2);
			canary.setName(chris);
			canary.setValue("canary");

			session.persist(chris);
			session.persist(cat);
			session.persist(canary);

			Name sam = new Name();
			sam.setId(2);
			sam.setName("sam");
			Value seal = new Value();
			seal.setId(3);
			seal.setName(sam);
			seal.setValue("seal");
			Value snake = new Value();
			snake.setId(4);
			snake.setName(sam);
			snake.setValue("snake");

			session.persist(sam);
			session.persist(seal);
			session.persist(snake);

			session.flush();
		} finally {
			session.close();
		}
	}

	@Test
	public void checkSubselectWithFormula() throws Exception {
		Session session = sessionFactory.openSession();
		try {
			List results = session.createCriteria(Name.class).list();
			for (Object result : results) {
				Name name = (Name) result;
				System.out.println("name = " + name.getName() + ", nameLength = " + name.getNameLength());
				for (Object o : name.getValues()) {
					Value value = (Value) o;
					System.out.println("   value = " + value.getValue());
				}
			}
		} finally {
			session.close();
		}
	}
}
