Hibernate Bug:

   Using formula-based property causes invalid SQL code for children "subselect" query

Instructions for running test:

   - Run main method in test.Test, you'll get an exception.
   - Change fetch="subselect" to fetch="select" on <bag> tag in Name.hbm.xml
   - Test runs fine now
   - Change back to fetch="subselect" on <bag> tag in Name.hbm.xml
   - Running Test gives an exception
   - Comment out the <property> tag for nameLength in Name.hbm.xml
   - Test will run now (but nameLength will be zero)

Conclusion:

   The formula and the subselect both work indepedently, but Hibernate breaks
   if you use them together.

SQL to create the test tables:

create table name
(
   id number,
   name varchar2 (30),
   constraint name_pk primary key (id)
);
create table value
(
   id number,
   name_id number,
   value varchar2 (30),
   constraint value_pk primary key (id),
   constraint value_name_fk foreign key (name_id) references name (id)
);
insert into name(id, name) values (1, 'chris');
insert into name(id, name) values (2, 'sam');
insert into value(id, name_id, value) values (1, 1, 'cat');
insert into value(id, name_id, value) values (2, 1, 'canary');
insert into value(id, name_id, value) values (3, 2, 'seal');
insert into value(id, name_id, value) values (4, 2, 'snake');

The following jar files were placed in the classpath:

   Oracle JDBC Thin Driver version - 9.0.2.0.0
      classes12.jar

   From the Hibernate 3.1.1:
      hibernate3.jar
      antlr-2.7.6rc1.jar (2.7.6rc1)
      asm-attrs.jar (unknown)
      asm.jar (unknown)
      cglib-2.1.3.jar (2.1.3)
      commons-collections-2.1.1.jar (2.1.1)
      commons-logging-1.0.4.jar (1.0.4)
      dom4j-1.6.1.jar (1.6.1)
      ehcache-1.1.jar (1.1)
      jdbc2_0-stdext.jar (2.0)
      jta.jar (unknown)
      log4j-1.2.11.jar
