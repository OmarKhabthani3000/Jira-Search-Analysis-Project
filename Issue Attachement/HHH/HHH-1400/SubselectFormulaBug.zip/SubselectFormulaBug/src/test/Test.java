package test;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Session;
import org.hibernate.Criteria;
import java.util.List;
import java.util.Iterator;

public class Test {
   public static void main(String[] args) throws Exception {
      SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
      Session session = sessionFactory.openSession();
      List results = session.createCriteria(Name.class).list();
      for (Iterator nameIter = results.iterator(); nameIter.hasNext(); ) {
         Name name = (Name) nameIter.next();
         System.out.println("name = " + name.getName() + ", nameLength = " + name.getNameLength());
         for (Iterator valueIter = name.getValues().iterator(); valueIter.hasNext(); ) {
            Value value = (Value) valueIter.next();
            System.out.println("   value = " + value.getValue());
         }
      }
   }
}
