package org.hibernate.test.subselectformula;

import java.io.*;
import java.util.*;

public class Person implements Serializable {
   private int personId;
   private String name;
   private int nameLength;
   private List pets = new ArrayList();

   public Person() {}
   public Person(String name) { this.name = name; }

   public int getPersonId() { return personId; }
   public String getName() { return name; }
   public int getNameLength() { return nameLength; }
   public List getPets() { return pets; }

   public void setPersonId(int personId) { this.personId = personId; }
   public void setName(String name) { this.name = name; }
   public void setNameLength(int nameLength) { this.nameLength = nameLength; }
   public void setPets(List pets) { this.pets = pets; }

   public void addPet(Pet pet) {
      pets.add(pet);
      pet.setPerson(this);
   }

   public boolean equals(Object obj) {
      if (!(obj instanceof Person)) return false;
      Person other = (Person) obj;
      return other.personId == this.personId;
   }

   public int hashCode() { return personId; }
}
