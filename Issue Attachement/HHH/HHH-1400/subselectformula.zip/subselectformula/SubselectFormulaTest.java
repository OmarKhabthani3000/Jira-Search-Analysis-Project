package org.hibernate.test.subselectformula;

import java.util.List;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.TestCase;
import org.hibernate.Criteria;
import java.util.Iterator;

/**
 * @author Chris Rogers
 */
public class SubselectFormulaTest extends TestCase {

   public SubselectFormulaTest(String str) {
      super(str);
   }

   public void testSubselectFormula() {

      Session s;
      Transaction tx;

      Person person;
      s = openSession();
      tx = s.beginTransaction();
      s.save(person = new Person("chris"));
      s.save(new Pet(person, "cat"));
      s.save(new Pet(person, "canary"));
      s.save(person = new Person("sam"));
      s.save(new Pet(person, "snake"));
      s.save(new Pet(person, "snail"));
      tx.commit();
      s.close();

      List results;

      s = openSession();
      tx = s.beginTransaction();
      results = s.createQuery("from Person").list();
      assertEquals(2, results.size());
      print(results);
      tx.commit();
      s.close();

      s = openSession();
      tx = s.beginTransaction();
      results = s.createCriteria(Person.class)
         .setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
         .list();
      assertEquals(2, results.size());
      print(results);
      tx.commit();
      s.close();
   }

   protected String[] getMappings() {
      return new String[] { "subselectformula/Person.hbm.xml", "subselectformula/Pet.hbm.xml" };
   }

   public static Test suite() {
      return new TestSuite(SubselectFormulaTest.class);
   }

   static void print(List results) {
      for (Iterator personIter = results.iterator(); personIter.hasNext(); ) {
         Person person = (Person) personIter.next();
         System.out.println("person = " + person.getName() + ", nameLength = " + person.getNameLength());
         for (Iterator petIter = person.getPets().iterator(); petIter.hasNext(); ) {
            Pet pet = (Pet) petIter.next();
            System.out.println("   animal = " + pet.getAnimal());
         }
      }
   }
}
