package org.hibernate.test.subselectformula;

import java.io.*;

public class Pet implements Serializable {
   private int petId;
   private Person person;
   private String animal;

   public Pet() {}
   public Pet(Person person, String animal) {this.animal=animal; person.addPet(this); }

   public int getPetId() { return petId; }
   public Person getPerson() { return person; }
   public String getAnimal() { return animal; }

   public void setPetId(int petId) { this.petId = petId; }
   public void setPerson(Person person) { this.person = person; }
   public void setAnimal(String animal) { this.animal = animal; }

   public boolean equals(Object obj) {
      if (!(obj instanceof Pet)) return false;
      Pet other = (Pet) obj;
      return other.petId == this.petId;
   }

   public int hashCode() { return petId; }
}
