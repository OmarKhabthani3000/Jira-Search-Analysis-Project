package org.frchen.hibernate5.entities;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "DEPARTMENT")
@SequenceGenerator(
		name = "departmentSequence",
		sequenceName = "DEPARTMENT_ID_SEQ",
		initialValue = 1,
		allocationSize = 1
)
public class Department {

	@Id
	@Column(name = "DEPARTMENT_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "departmentSequence")
	private Long id;
	
	@Column(name = "NAME", length = 20)
	private String name;
	
	@OneToMany(mappedBy = "department", fetch = FetchType.LAZY)
	private Set<Employee> employees;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(Set<Employee> employees) {
		this.employees = employees;
	}
}
