package org.frchen.hibernate5;

import java.util.List;

import org.frchen.hibernate5.entities.Department;
import org.frchen.hibernate5.entities.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;

public class AssociationTest {
	
	private static SessionFactory sessionFactory;
	
	@BeforeClass
	public static void initDatabase() {
		sessionFactory = createSessionFactory();
		initData();
	}
	
	@AfterClass
	public static void disposeDatabase() {
		SessionFactory sf = sessionFactory;
		if (sf != null) {
			sessionFactory = null;
			sf.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCollection() {
		Session session = sessionFactory.openSession();
		try {
			List<Department> departments = 
					session
					.createQuery("from Department d left join fetch d.employees")
					.list();
			Assert.assertEquals(2, departments.size());
			Assert.assertSame(departments.get(0), departments.get(1));
			Department department = departments.get(0);
			Assert.assertNotNull(department.getEmployees());
			Assert.assertNotNull(department.getEmployees());
		} finally {
			session.close();
		}
	}
	
	private static SessionFactory createSessionFactory() {
		StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.configure()
				.build();
		try {
			return new MetadataSources(registry)
					.addAnnotatedClass(Department.class)
					.addAnnotatedClass(Employee.class)
					.buildMetadata()
					.buildSessionFactory();
		} catch (RuntimeException | Error ex) {
			StandardServiceRegistryBuilder.destroy(registry);
			throw ex;
		}
	}
	
	private static void initData() {
		Session session = sessionFactory.openSession();
		try {
			Transaction tx = session.beginTransaction();
			try {
				Department sales = new Department();
				Employee jim = new Employee();
				Employee kate = new Employee();
				sales.setName("Sales");
				jim.setName("jim");
				kate.setName("kate");
				jim.setDepartment(sales);
				kate.setDepartment(sales);
				session.save(sales);
				session.save(jim);
				session.save(kate);
			} catch (RuntimeException | Error ex) {
				tx.rollback();
				throw ex;
			}
			tx.commit();
		} finally {
			session.close();
		}
	}
}
