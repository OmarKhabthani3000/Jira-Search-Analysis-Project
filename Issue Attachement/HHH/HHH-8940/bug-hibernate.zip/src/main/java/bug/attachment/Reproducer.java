package bug.attachment;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Reproducer {

	public static void main(String[] args) throws Throwable {
		EntityManagerFactory entityManagerFactory = Persistence
				.createEntityManagerFactory("bug-attachment");
		EntityManager entityManager = entityManagerFactory
				.createEntityManager();
		try {

			EntityTransaction transaction = entityManager.getTransaction();

			transaction.begin();
			try {
				// persistDoesntWork(entityManager, transaction);
				main(entityManager, transaction);
				transaction.commit();
			} catch (Throwable e) {
				if (transaction.isActive()) {
					transaction.rollback();
				}
				e.printStackTrace();
			}

		} finally {
			entityManager.close();
		}

		System.exit(0);
	}

	private static void main(EntityManager entityManager,
			EntityTransaction transaction) {
		Level0 level0 = new Level0();
		Level2 level2 = new Level2();
		Level1 level1 = new Level1(level0, level2);
		level0.getLevel1s().add(level1);

		entityManager.persist(level0);

	}

}
