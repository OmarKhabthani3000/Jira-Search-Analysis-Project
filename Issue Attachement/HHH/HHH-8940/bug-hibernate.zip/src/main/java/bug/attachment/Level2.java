package bug.attachment;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the "PARAMETER" database table.
 * 
 */
@Entity
@Table(name = "LEVEL2")
public class Level2 implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "LEVEL2_ID_GENERATOR", sequenceName = "LEVEL2_LEVEL2_ID_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "LEVEL2_ID_GENERATOR")
	@Column(name = "LEVEL2_ID", unique = true, nullable = false, precision = 8)
	private Integer id;

	public Level2() {
	}

	public Integer getId() {
		return id;
	}
	
	
}