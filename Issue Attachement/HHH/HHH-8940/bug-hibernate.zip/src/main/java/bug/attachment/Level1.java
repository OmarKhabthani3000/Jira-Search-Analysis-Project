package bug.attachment;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;

@Entity
@Table(name = "LEVEL1")
public class Level1 {
	@EmbeddedId
	Level1PK id;
	
	@ManyToOne
	@JoinColumn (name="LEVEL0_ID", insertable=false, nullable=false, updatable=false)
	private Level0 level0;

	@ManyToOne (cascade=CascadeType.ALL)
	@JoinColumn (name="LEVEL2_ID", insertable=false, nullable=false, updatable=false)
	private Level2 level2;

	@Column
	private String attr;
	

	public Level1 () {
	}

	public Level1(Level0 level0, Level2 level2) {
		super();
		this.level0 = level0;
		this.level2 = level2;
	}

	public String getAttr() {
		return attr;
	}
	
	@PrePersist
	private void updateId () {
		this.id = new Level1PK(level0.getId (), level2.getId ());
	}
	
}