package bug.attachment;

import java.io.Serializable;

import javax.persistence.Column;

public class Level1PK implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Column(name="LEVEL0_ID")
	private Integer level0Id;

	@Column(name="LEVEL2_ID")
	private Integer level2Id;

	public Level1PK(Integer id, Integer id2) {
		this.level0Id = id;
		this.level2Id = id2;
	}

	public Integer getLevel0Id() {
		return level0Id;
	}

	public void setLevel0Id(Integer level0Id) {
		this.level0Id = level0Id;
	}

	public Integer getLevel2Id() {
		return level2Id;
	}

	public void setLevel2Id(Integer level2Id) {
		this.level2Id = level2Id;
	}

	@Override
	public int hashCode() {
		return (level0Id != null? (int) level0Id: 0) ^ (level2Id != null? (int) level2Id: 0);
	}
	
	@Override
	public boolean equals(Object obj) {
		Level1PK pk = (Level1PK) obj;
		return level0Id.equals(pk.level0Id) && level2Id.equals(pk.level2Id);
	}
}
