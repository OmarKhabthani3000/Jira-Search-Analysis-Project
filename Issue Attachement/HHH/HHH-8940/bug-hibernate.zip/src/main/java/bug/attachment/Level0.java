package bug.attachment;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the "PARAMETER" database table.
 * 
 */
@Entity
@Table(name = "LEVEL0")
public class Level0 implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "LEVEL0_ID_GENERATOR", sequenceName = "LEVEL0_LEVEL0_ID_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "LEVEL0_ID_GENERATOR")
	@Column(name = "LEVEL0_ID", unique = true, nullable = false, precision = 8)
	private Integer id;
	
	@OneToMany(mappedBy="level0", cascade=CascadeType.ALL)
	private List<Level1> level1s = new ArrayList<Level1>();

	public List<Level1> getLevel1s() {
		return level1s;
	}

	public Level0() {
		
	}

	public Integer getId() {
		return id;
	}

	
}