import javax.persistence.*;

@Entity
@DiscriminatorValue("child")
public class ChildItem extends Item {
}
