package org.fgaule;

import javax.persistence.*;
import java.util.Set;

/**
 * Created by Edward Nygma on 27/7/2015.
 */
@Entity
public class MyEntity {

    private Long id;
    private Set<Team> teams;

    public MyEntity() {
    }

    public MyEntity(Set<Team> teams) {
        this.teams = teams;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    public Set<Team> getTeams() {
        return teams;
    }

    public void setTeams(Set<Team> teams) {
        this.teams = teams;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("MyEntity{");
        sb.append("id=").append(id);
        sb.append(", teams=").append(teams);
        sb.append('}');
        return sb.toString();
    }
}
