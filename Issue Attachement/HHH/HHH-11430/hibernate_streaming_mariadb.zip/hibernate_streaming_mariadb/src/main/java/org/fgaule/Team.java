package org.fgaule;

import javax.persistence.*;

/**
 * @author fgaule
 * @since 26/01/2017
 */
@Entity
public class Team {

    private Long id;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
