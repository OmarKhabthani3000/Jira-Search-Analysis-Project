package org.fgaule;

import org.hibernate.query.Query;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.*;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;
import java.sql.SQLException;
import java.util.HashSet;

public class TestCase {

    private EntityManager entityManager;
    private EntityManagerFactory entityManagerFactory;
    private EntityTransaction transaction;

    @Before
    public void setup() {
        System.out.println("Creating entity manager and persistence unit.");
        this.entityManagerFactory = Persistence.createEntityManagerFactory("test-jpa-converters");
        this.entityManager = this.entityManagerFactory.createEntityManager();
        this.transaction = this.entityManager.getTransaction();
        System.out.println("Done creating entity manager and persistence unit.");

        persistEntity();
    }

    @Test
    public void criteria_isMember_fails() {

        this.transaction.begin();

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();

        CriteriaQuery<MyEntity> q = cb.createQuery(MyEntity.class);
        final Root<MyEntity> from = q.from(MyEntity.class);
        from.fetch("teams", JoinType.LEFT);

        entityManager.createQuery(q).unwrap(Query.class)
                .setFetchSize(1)
                .stream()
                .forEach(e -> System.out.println(e.toString()));

        this.transaction.commit();

    }

    private void persistEntity() {
        this.transaction.begin();

        for (int i = 0; i < 50; i++) {
            final HashSet<Team> objects = new HashSet<>();
            objects.add(new Team());
            MyEntity entity = new MyEntity(objects);
            this.entityManager.persist(entity);
        }
        this.entityManager.flush();
        this.transaction.commit();
    }

    @After
    public void shutDown() throws SQLException {
        System.out.println("Closing persistence unit.");
        this.transaction = null;

        if (this.entityManager != null && this.entityManager.isOpen()) {
            this.entityManager.close();
        }

        if (this.entityManagerFactory != null && this.entityManagerFactory.isOpen()) {
            this.entityManagerFactory.close();
        }
        System.out.println("Persistence unit closed.");

    }

}
