import java.util.HashSet;
import java.util.Set;

public class ObjetTest
{
    private static final long serialVersionUID = 1L;
    private Integer oid;
    private Integer code;
    private String label;
    private ObjetTest parent;
    private Set<ObjetTest> children;

    public Set<ObjetTest> getChildren()
    {
        return children;
    }

    public void setChildren(Set<ObjetTest> aChildren)
    {
        children = aChildren;
    }

    public void addChild(ObjetTest aChild)
    {
        if (children == null)
        {
            children = new HashSet<ObjetTest>();
        }
        children.add(aChild);
    }

    public Integer getCode()
    {
        return code;
    }

    public void setCode(Integer aCode)
    {
        code = aCode;
    }

    public String getLabel()
    {
        return label;
    }

    public void setLabel(String aLabel)
    {
        label = aLabel;
    }

    public Integer getOid()
    {
        return oid;
    }

    public void setOid(Integer aOid)
    {
        oid = aOid;
    }

    public ObjetTest getParent()
    {
        return parent;
    }

    public void setParent(ObjetTest aParent)
    {
        parent = aParent;
    }
}
