import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test
{
    public static void main(String[] args)
    {
        SessionFactory factory = new Configuration().configure().buildSessionFactory();
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        ObjetTest objetTest = new ObjetTest();
        objetTest.setCode(1);
        objetTest.setLabel("test");
        ObjetTest enfant = new ObjetTest();
        enfant.setCode(2);
        enfant.setLabel("child2");
        enfant.setParent(objetTest);
        objetTest.addChild(enfant);
        enfant = new ObjetTest();
        enfant.setCode(3);
        enfant.setLabel("child3");
        enfant.setParent(objetTest);
        objetTest.addChild(enfant);
        session.save(objetTest);
        Query query;
        query = session.createQuery("select obj from ObjetTest obj left outer join fetch obj.children as obj_0 order by obj.id asc");
        query.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        query.setCacheable(true);
        for (Object object : query.list())
        {
            System.out.println(object);
        }
        tx.commit();
        session.close();
    }
}
