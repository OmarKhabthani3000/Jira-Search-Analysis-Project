package org.hibernate.bugs.entity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.OneToMany;
import javax.persistence.UniqueConstraint;

@Entity
@NamedEntityGraph(name="defect.comments", attributeNodes= {@NamedAttributeNode(value="comments")})
public class Defect {
	
	@Id
	@GeneratedValue
	private Integer id;
	
	private String name;
	
	@OneToMany(cascade=CascadeType.REMOVE, mappedBy="defect", orphanRemoval=true)
	private List<TimelineComment> comments = new ArrayList<>();
	
	@ManyToMany
	@JoinTable(
		name="DEFECT_RESOVLERS",
		joinColumns=@JoinColumn(referencedColumnName="ID", name="DEFECT_ID"),
		inverseJoinColumns=@JoinColumn(referencedColumnName="ID", name="USER_ID"),
		uniqueConstraints={@UniqueConstraint(columnNames={"DEFECT_ID", "USER_ID"})}
	)
	private Set<User> resolvers = new HashSet<>();

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<TimelineComment> getComments() {
		return comments;
	}

	public void setComments(List<TimelineComment> comments) {
		this.comments = comments;
	}

	public Set<User> getResolvers() {
		return resolvers;
	}

	public void setResolvers(Set<User> resolvers) {
		this.resolvers = resolvers;
	}
}
