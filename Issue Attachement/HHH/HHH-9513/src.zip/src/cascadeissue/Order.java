package cascadeissue;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity(name="Order")
public class Order {
   @Id @GeneratedValue public Integer getOrderID() { return OrderID; }
   public void setOrderID(Integer id) { this.OrderID = id; }
   private Integer OrderID;

   @ManyToOne
   public Customer getCustomerID() { return CustomerID; }
   public void setCustomerID(Customer CustomerID) { this.CustomerID = CustomerID; }
   private Customer CustomerID;
}