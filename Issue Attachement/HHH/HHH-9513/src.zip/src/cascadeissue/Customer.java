package cascadeissue;

import java.util.List;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;

@Entity(name="Customer")
public class Customer {
   @Id public String getCustomerID() { return CustomerID; }
   public void setCustomerID(String id) { this.CustomerID = id; }
   private String CustomerID;

   @OneToMany(mappedBy="CustomerID")
   @OrderColumn(name="orders_index")
   public Map<Integer, Order> getOrders() { return orders; }
   public void setOrders(Map<Integer, Order> orders) { this.orders = orders; }
   private Map<Integer, Order> orders;
}