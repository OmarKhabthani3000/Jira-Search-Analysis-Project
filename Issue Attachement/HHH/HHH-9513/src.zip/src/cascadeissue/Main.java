package cascadeissue;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class Main {

	public static void main(String[] args) {
		Main obj = new Main();
		Customer customer = new Customer();
		customer.setCustomerID("Hima");
		
		Order order1 = new Order();
		order1.setCustomerID(customer);
		
		Order order2 = new Order();
		order1.setCustomerID(customer);
		
		Map<Integer, Order> orders = new HashMap<Integer, Order>();
		orders.put(order1.getOrderID(), order1);
		orders.put(order2.getOrderID(), order2);
		
		customer.setOrders(orders);

		obj.saveEntities(customer, order1, order2);
	}
	
	public void saveEntities(Customer customer, Order order1, Order order2){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			session.save(order1);
			session.save(order2);
			session.save(customer);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		
	}
	
	public void saveEntity(Object entity){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			session.save(entity);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		
	}
	
}
