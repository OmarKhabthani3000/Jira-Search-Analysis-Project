package com.example.demo;

import org.hibernate.context.spi.CurrentTenantIdentifierResolver;

public class CurrentTenantIdentifierResolverImpl implements CurrentTenantIdentifierResolver{

    private String currentTenant = "unknown";

    public void setCurrentTenant(String currentTenant) {
        this.currentTenant = currentTenant;
    }

    public String getCurrentTenant() {
        return currentTenant;
    }

    @Override
    public String resolveCurrentTenantIdentifier() {
        return currentTenant;
    }

    @Override
    public boolean validateExistingCurrentSessions() {
        return true;
    }

    @Override
    public boolean isRoot(String tenantId) {
        return "-1".equals(tenantId);
    }

}
