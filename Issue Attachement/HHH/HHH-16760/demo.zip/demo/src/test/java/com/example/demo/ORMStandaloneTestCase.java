package com.example.demo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class ORMStandaloneTestCase  {

    private EntityManagerFactory entityManagerFactory;

    @BeforeEach
    public void init() {

        Configuration configuration = new Configuration()
                .addAnnotatedClass(Person.class)
                .setProperty(AvailableSettings.SHOW_SQL, "true")
                .setProperty(AvailableSettings.HBM2DDL_AUTO, "update")
                .setProperty(AvailableSettings.FORMAT_SQL, "true")
                .setProperty(AvailableSettings.PASS, "ssss")
                .setProperty(AvailableSettings.USER, "ssss")
                .setProperty(AvailableSettings.DRIVER, "org.h2.Driver")
                .setProperty(AvailableSettings.URL, "jdbc:h2:mem:test;DB_CLOSE_DELAY=-1");

        configuration.setCurrentTenantIdentifierResolver(new CurrentTenantIdentifierResolverImpl());
        entityManagerFactory = configuration.buildSessionFactory();
    }

    @AfterEach
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    public void hhh123Test() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        //  In 6.1.7 version , the sql statement will print like this:
        //        select
        //                p1_0.id,
        //                p1_0.name,
        //                p1_0.tenantId
        //        from
        //        Person p1_0
        //        where
        //        p1_0.id=?
        //        and p1_0.tenantId = ?

        //  In 6.2.2 version (Or the 2.x version?), the sql statement will print like this:
        //        select
        //        p1_0.id,
        //                p1_0.name,
        //                p1_0.tenantId
        //        from
        //        Person p1_0
        //        where
        //        p1_0.id=?
        entityManager.find(Person.class,1L);

        entityManager.getTransaction().commit();
        entityManager.close();
    }


}
