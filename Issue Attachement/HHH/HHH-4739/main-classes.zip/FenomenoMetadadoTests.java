package tests;

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertNotNull;
import static org.testng.AssertJUnit.assertNull;
import static org.testng.AssertJUnit.fail;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import org.domain.geoinfra.entity.AtributoMetadado;
import org.domain.geoinfra.entity.FenomenoMetadado;
import org.domain.geoinfra.entity.PointMetaDado;
import org.domain.geoinfra.entity.StringMetaDado;
import org.jboss.seam.mock.SeamTest;
import org.testng.annotations.Test;


public class FenomenoMetadadoTests extends SeamTest { 	
	
	@Test
	public void testarAtributosRequeridos() throws Exception {
		new ComponentTest() {

			@Override
			protected void testComponents() throws Exception {
				EntityManager em = (EntityManager)getValue("#{entityManager}");			
				
				FenomenoMetadado instalacaoMetaDado = new FenomenoMetadado();				
				instalacaoMetaDado.setDescricao("Insta�a�es de Petr�leo e G�s");
				
				try {
					em.persist(instalacaoMetaDado);
					fail("Nome � obrigat�rio");
				} catch (PersistenceException e) {
					
				}
				
			}
			
		}.run();
	}
	
	@Test
	public void testarCriarRemover() throws Exception {
		final FenomenoMetadado instalacaoMetaDado = new FenomenoMetadado();
		instalacaoMetaDado.setNome("Instala��es");
		instalacaoMetaDado.setDescricao("Instala��es de Petr�leo e G�s");
		List<AtributoMetadado> atributos = new ArrayList<AtributoMetadado>();
		StringMetaDado att1 = new StringMetaDado();
		att1.setLabel("Nome");
		att1.setNome("nome");
		att1.setRequerido(true);
		att1.setFenomenoMetadado(instalacaoMetaDado);
		atributos.add(att1);
		PointMetaDado att2 = new PointMetaDado();
		att2.setLabel("Localiza��o");
		att2.setNome("geom");
		att2.setRequerido(true);
		att2.setFenomenoMetadado(instalacaoMetaDado);
		atributos.add(att2);
		instalacaoMetaDado.setAtributosMetadado(atributos);

        new FacesRequest() {
            protected void invokeApplication()
            {
                EntityManager em = (EntityManager) getValue("#{entityManager}");
                
                try {
                	em.persist(instalacaoMetaDado);
                } catch (Exception e) {
                	e.printStackTrace();
                	fail("p�ia");
                }
            }
            
           
         }.run();
         
         new FacesRequest() {
             protected void invokeApplication()
             { 
                 EntityManager em = (EntityManager) getValue("#{entityManager}");
                 FenomenoMetadado found = em.find(FenomenoMetadado.class ,instalacaoMetaDado.getId());
                 assertNotNull("encontrado", found);
                 assertEquals("id", instalacaoMetaDado.getId(), found.getId());
                 assertEquals("nome", "Instala��es", found.getNome());
                 assertEquals("descricao", "Instala��es de Petr�leo e G�s", found.getDescricao());
                 assertEquals("atributos", instalacaoMetaDado.getAtributosMetadado().size(), found.getAtributosMetadado().size());
         
                 em.remove(found);             
             }
          }.run();
         
          new FacesRequest() {
              protected void invokeApplication()
              { 
                  EntityManager em = (EntityManager) getValue("#{entityManager}");
                  FenomenoMetadado found = em.find(FenomenoMetadado.class ,instalacaoMetaDado.getId());

                  assertNull("instala��o removida", found);             
              }
           }.run();
		
	}
}
