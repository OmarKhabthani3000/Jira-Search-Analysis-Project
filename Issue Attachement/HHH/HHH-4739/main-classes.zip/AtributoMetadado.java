package org.domain.geoinfra.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.validator.NotNull;

@Entity
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
public abstract class AtributoMetadado implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	@NotNull
	private String nome;
	@NotNull
	private String label;
	@NotNull	
	private Boolean requerido;
	
	@ManyToOne
	@JoinColumn(name="fenomenometadado_id", nullable = false)
	private FenomenoMetadado fenomenoMetadado;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public Boolean getRequerido() {
		return requerido;
	}

	public void setRequerido(Boolean requerido) {
		this.requerido = requerido;
	}

	public void setFenomenoMetadado(FenomenoMetadado fenomenoMetadado) {
		this.fenomenoMetadado = fenomenoMetadado;
	}

	public FenomenoMetadado getFenomenoMetadado() {
		return fenomenoMetadado;
	}

}
