package org.domain.geoinfra.entity;

import javax.persistence.Entity;

@Entity
public class StringMetaDado extends AtributoMetadado {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
