
import java.util.ArrayList;
import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.dialect.H2Dialect;
import org.hibernate.query.Query;
import org.hibernate.service.ServiceRegistry;

public class HibernateTest {

    private static SessionFactory sessionFactory;

    private static Session session;

    public HibernateTest() {
    }

    public static void main(String[] args) {
        Configuration configuration = new Configuration().addAnnotatedClass(Cart.class).addAnnotatedClass(Items.class)
                .setProperty("hibernate.dialect", H2Dialect.class.getName())
                .setProperty("hibernate.connection.driver_class", org.h2.Driver.class.getName())
                .setProperty("hibernate.connection.url", "jdbc:h2:mem:test")
                .setProperty("hibernate.connection.username", "sa").setProperty("hibernate.connection.password", "")
                .setProperty("hibernate.hbm2ddl.auto", "update");
        ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
                .applySettings(configuration.getProperties()).build();
        sessionFactory = configuration.buildSessionFactory(serviceRegistry);
        session = sessionFactory.openSession();
        session.beginTransaction();

        Cart cart = new Cart();
        Items item1 = new Items();
        //item1.setId(1L);
        item1.setSize(1000);
        item1.setCart(cart);

        Items item2 = new Items();
        //item2.setId(2L);
        item2.setSize(2000);
        item2.setCart(cart);

        List<Items> itemsSet = new ArrayList<Items>();
        itemsSet.add(item1);
        itemsSet.add(item2);
        cart.setItems(itemsSet);
        session.persist(cart);
        //session.getTransaction().commit();
        
        cart = new Cart();
        item1 = new Items();
        //item1.setId(3L);
        item1.setSize(3000);
        item1.setCart(cart);

        item2 = new Items();
        //item2.setId(4L);
        item2.setSize(4000);
        item2.setCart(cart);

        itemsSet = new ArrayList<Items>();
        itemsSet.add(item1);
        itemsSet.add(item2);
        cart.setItems(itemsSet);
        session.persist(cart);
        session.getTransaction().commit();
       
        session.close();

        session = sessionFactory.openSession();
        session.beginTransaction();
        cart = (Cart) session.get(Cart.class, 1L);
        
        for (Items items : cart.getItems()) {
            System.out.println(cart.getId()+" item property size value = "+items.getSize());
		}

        cart = (Cart) session.get(Cart.class, 4L);
        for (Items items : cart.getItems()) {
            System.out.println(cart.getId()+" item property size value = "+items.getSize());
		}

        Query query = session.createQuery("select o, (o.items.size) as col from Cart o");
        List list = query.list();
        
        session.getTransaction().commit();
        session.close();
        sessionFactory.close();
    }

}
