package org.hibernate.bugs.entity;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

@Entity
public class LineItem {
    @Id
    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "item_seq_number", nullable = false)
    private Integer sequenceNumber;

    @ManyToOne
    @JoinColumn(name = "cart_id")
    private ShoppingCart cart;

    @PrePersist
    @PreUpdate
    protected void preUpdate() {
        // actual usage
        sequenceNumber = cart.getLineItems().indexOf(this);

        // anything that triggers initialization of collection causes the issue, e.g.:
        // cart.getLineItems().iterator();
        // Hibernate.initialize(cart.getLineItems());
    }

    private LineItem() {
    }

    public LineItem(String name, ShoppingCart cart) {
        this.name = name;
        this.cart = cart;
    }

    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LineItem lineItem = (LineItem) o;
        return Objects.equals(name, lineItem.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
