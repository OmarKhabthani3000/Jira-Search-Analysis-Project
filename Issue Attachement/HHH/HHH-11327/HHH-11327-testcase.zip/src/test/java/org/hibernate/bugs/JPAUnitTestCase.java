package org.hibernate.bugs;

import org.hibernate.bugs.entity.LineItem;
import org.hibernate.bugs.entity.ShoppingCart;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import static org.junit.Assert.assertEquals;

public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void hhh11327Test() throws Exception {
	    //GIVEN
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		entityManager.persist(new ShoppingCart("cart1"));

		entityManager.getTransaction().commit();
        entityManager.close();


        //WHEN
        EntityManager entityManager2 = entityManagerFactory.createEntityManager();
        entityManager2.getTransaction().begin();


        ShoppingCart cart = entityManager2.find(ShoppingCart.class, "cart1");

        cart.addLineItem(new LineItem("item2", cart));

        entityManager2.getTransaction().commit();
        entityManager2.close();


        //THEN
        assertEquals(1, cart.getLineItems().size());
        assertEquals(0, cart.getLineItems().get(0).getSequenceNumber().intValue());
	}
}
