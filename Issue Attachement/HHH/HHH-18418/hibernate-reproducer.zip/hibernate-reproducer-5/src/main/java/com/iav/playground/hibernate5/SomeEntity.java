package com.iav.playground.hibernate5;

import static javax.persistence.TemporalType.TIMESTAMP;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;

@Entity
public class SomeEntity {
    @Id @GeneratedValue
    private Long id;

    @Embedded
    @AttributeOverride(name = "value", column = @Column(name = "LAST_ACCESS", nullable = false))
    @Temporal(TIMESTAMP)
    private AccessDate lastAccess;

    public SomeEntity() {
    }

    public SomeEntity(final AccessDate lastAccess) {
        this.lastAccess = lastAccess;
    }

    public Long getId() {
        return id;
    }

    public AccessDate getLastAccess() {
        return lastAccess;
    }
}
