package com.iav.playground.hibernate5;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class AccessDate implements Comparable<AccessDate>, Serializable {

    @Column(name = "value")
    private Date value;

    public AccessDate() {
    }

    public AccessDate(final Date value) {
        this.value = value;
    }

    public Date getValue() {
        return value;
    }

    @Override
    public int compareTo(final AccessDate o) {
        return value.compareTo(o.getValue());
    }
}
