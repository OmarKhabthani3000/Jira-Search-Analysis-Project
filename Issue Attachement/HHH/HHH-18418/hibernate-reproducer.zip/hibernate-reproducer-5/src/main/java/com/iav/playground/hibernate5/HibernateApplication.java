package com.iav.playground.hibernate5;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;

@SpringBootApplication
public class HibernateApplication implements CommandLineRunner {

    @PersistenceContext
    private EntityManager entityManager;

    public static void main(String[] args) {
        SpringApplication.run(HibernateApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        final CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        final CriteriaQuery<AccessDate> cq = cb.createQuery(AccessDate.class);
        final Root<SomeEntity> root = cq.from(SomeEntity.class);
        // This worked in Hibernate 5 and fails due to AccessDateTwo implementing Serializable.
        // Seems to be fixed in Hibernate 6.6.0.
        final Expression<AccessDate> leastAccessDate = cb.least(root.get(SomeEntity_.lastAccess));
        cq.select(leastAccessDate);

        // This worked in Hibernate 5:
        entityManager.createQuery(cq).getResultList();
    }
}
