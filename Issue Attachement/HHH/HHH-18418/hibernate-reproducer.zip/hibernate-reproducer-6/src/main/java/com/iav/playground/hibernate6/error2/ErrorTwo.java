/*
 * This document contains trade secret data which is the property of
 * IAV GmbH. Information contained herein may not be used,
 * copied or disclosed in whole or part except as permitted by written
 * agreement from IAV GmbH.
 *
 * Copyright (C) IAV GmbH / Gifhorn / Germany
 */

package com.iav.playground.hibernate6.error2;

import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Root;

public class ErrorTwo {

    public void run(final EntityManager entityManager) throws Exception {
        final CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        final CriteriaQuery<AccessDateTwo> cq = cb.createQuery(AccessDateTwo.class);
        final Root<SomeEntityTwo> root = cq.from(SomeEntityTwo.class);
        // This worked in Hibernate 5 and fails due to AccessDateTwo implementing Serializable.
        // Seems to be fixed in Hibernate 6.6.0.
        final Expression<AccessDateTwo> leastAccessDate = cb.least(root.get(SomeEntityTwo_.lastAccess));
        cq.select(leastAccessDate);

        entityManager.createQuery(cq).getResultList();
    }
}
