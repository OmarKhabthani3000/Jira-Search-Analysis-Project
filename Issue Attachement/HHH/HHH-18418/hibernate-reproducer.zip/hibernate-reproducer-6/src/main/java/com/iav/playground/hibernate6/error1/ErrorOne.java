/*
 * This document contains trade secret data which is the property of
 * IAV GmbH. Information contained herein may not be used,
 * copied or disclosed in whole or part except as permitted by written
 * agreement from IAV GmbH.
 *
 * Copyright (C) IAV GmbH / Gifhorn / Germany
 */

package com.iav.playground.hibernate6.error1;

import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Root;

public class ErrorOne {

    public void run(final EntityManager entityManager) throws Exception {
        final CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        final CriteriaQuery<AccessDateOne> cq = cb.createQuery(AccessDateOne.class);
        final Root<SomeEntityOne> root = cq.from(SomeEntityOne.class);
        final Expression<AccessDateOne> leastAccessDate = cb.least(root.get(SomeEntityOne_.lastAccess));
        cq.select(leastAccessDate);

        // This worked in Hibernate 5:
        entityManager.createQuery(cq).getResultList();
    }
}
