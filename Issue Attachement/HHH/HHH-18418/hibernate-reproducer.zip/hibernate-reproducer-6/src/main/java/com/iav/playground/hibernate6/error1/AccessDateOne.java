/*
 * This document contains trade secret data which is the property of
 * IAV GmbH. Information contained herein may not be used,
 * copied or disclosed in whole or part except as permitted by written
 * agreement from IAV GmbH.
 *
 * Copyright (C) IAV GmbH / Gifhorn / Germany
 */

package com.iav.playground.hibernate6.error1;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class AccessDateOne implements Comparable<AccessDateOne> {

    @Column(name = "value")
    private Date value;

    public AccessDateOne() {
    }

    public AccessDateOne(final Date value) {
        this.value = value;
    }

    public Date getValue() {
        return value;
    }

    @Override
    public int compareTo(final AccessDateOne o) {
        return value.compareTo(o.getValue());
    }
}
