/*
 * This document contains trade secret data which is the property of
 * IAV GmbH. Information contained herein may not be used,
 * copied or disclosed in whole or part except as permitted by written
 * agreement from IAV GmbH.
 *
 * Copyright (C) IAV GmbH / Gifhorn / Germany
 */

package com.iav.playground.hibernate6.error1;


import static jakarta.persistence.TemporalType.TIMESTAMP;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;

@Entity
public class SomeEntityOne {
    @Id
    @GeneratedValue
    private Long id;

    @Embedded
    @AttributeOverride(name = "value", column = @Column(name = "LAST_ACCESS", nullable = false))
    @Temporal(TIMESTAMP)
    private AccessDateOne lastAccess;

    public SomeEntityOne() {
    }

    public SomeEntityOne(final AccessDateOne lastAccess) {
        this.lastAccess = lastAccess;
    }

    public Long getId() {
        return id;
    }

    public AccessDateOne getLastAccess() {
        return lastAccess;
    }
}
