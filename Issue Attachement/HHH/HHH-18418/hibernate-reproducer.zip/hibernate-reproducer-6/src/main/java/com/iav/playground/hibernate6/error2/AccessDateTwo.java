/*
 * This document contains trade secret data which is the property of
 * IAV GmbH. Information contained herein may not be used,
 * copied or disclosed in whole or part except as permitted by written
 * agreement from IAV GmbH.
 *
 * Copyright (C) IAV GmbH / Gifhorn / Germany
 */

package com.iav.playground.hibernate6.error2;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class AccessDateTwo implements Comparable<AccessDateTwo>, Serializable {

    @Column(name = "value")
    private Date value;

    public AccessDateTwo() {
    }

    public AccessDateTwo(final Date value) {
        this.value = value;
    }

    public Date getValue() {
        return value;
    }

    @Override
    public int compareTo(final AccessDateTwo o) {
        return value.compareTo(o.getValue());
    }
}
