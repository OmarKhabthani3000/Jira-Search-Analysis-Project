package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.bugs.entities.Skill;
import org.hibernate.bugs.entities.Student;
import org.hibernate.bugs.entities.Teacher;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
    public void hhh13944Test() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		entityManager.getTransaction().begin();

		Skill mathSkill = new Skill();
		Skill frenchSkill = new Skill();

		entityManager.persist(mathSkill);
		entityManager.persist(frenchSkill);

		Teacher t1 = new Teacher();

        Teacher t2 = new Teacher();
        t2.getSkills().add(mathSkill);

        Teacher t3 = new Teacher();
		t3.getSkills().add(mathSkill);
		t3.getSkills().add(frenchSkill);

        entityManager.persist(t1);
        entityManager.persist(t2);
        entityManager.persist(t3);

        entityManager.flush();
        entityManager.clear();
		List<Teacher> teachers = entityManager.createQuery("select teacher from Teacher teacher where size(teacher.skills) > 0", Teacher.class)
				.getResultList();

		assertEquals(2, teachers.size());

		Student student = new Student();
		student.setTeacher(t3); // Teacher with 2 skills

		entityManager.persist(student);
		entityManager.flush();
		entityManager.clear();

		List<Student> students = entityManager.createQuery("select student from Student student where size(student.teacher.skills) > 0", Student.class)
				.getResultList();

		assertEquals(1, students.size());

		// I expect 1 because the unique student in DB is linked to the teacher with 2 skills.
		//
		// size(student.teacher.skills) should be 2
		//
		// Unfortunately, the generated subquery is:
		//    select
		//        count(skills1_.teachers_id)
		//    from
		//        Teacher_Skill skills1_
		//    where
		//        student0_.id = skills1_.teachers_id
		//
		// (note the condition: student0_.id = skills1_.teachers_id)
		// (is checking student id instead of teacher id)
		//
		// In version 5.4.12 and below the subquery was correct:
		//    select
		//        count(skills2_.teachers_id)
		//    from
		//        Teacher_Skill skills2_
		//    where
		//        teacher1_.id=skills2_.teachers_id
		//
		// After a first investigation, I think that the size refactoring made in HHH-13619
		// could be the reason of this misbehavior. (CollectionSizeNode)

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
