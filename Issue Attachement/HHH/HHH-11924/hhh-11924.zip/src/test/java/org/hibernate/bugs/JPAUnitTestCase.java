package org.hibernate.bugs;

import org.hibernate.bugs.model.Book;
import org.hibernate.bugs.model.Comment;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.*;

import static org.junit.Assert.assertEquals;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {
	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Add your tests, using standard JUnit.
	@Test
	public void hhh11924Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Book book = insertTestData(entityManager);
		entityManager.getTransaction().commit();

		entityManager.clear();
		entityManager.getTransaction().begin();

		Book persistedBook = entityManager.find(Book.class, book.getId());
		assertEquals(book.getTitle(), persistedBook.getTitle());
		List<Comment> comments = persistedBook.getComments();
		assertEquals("It's a okay book. But *** is better", comments.get(0).getComment());
		assertEquals("It's the greatest  book ever!!!!", comments.get(1).getComment());

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	private Book insertTestData(EntityManager s) {
		List<Comment> comments = Arrays.asList(new Comment("It's a okay book. But NoSql is better")
				, new Comment("It's the greatest  book ever!!!!")
				, new Comment("It's a must read")
		);
		Book book = new Book();
		book.setId(UUID.randomUUID().toString());
		book.setTitle("High-Performance Java Persistence");
		book.setComments(comments);
		s.persist(book);
		return book;
	}
}
