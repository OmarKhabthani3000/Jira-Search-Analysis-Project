package org.hibernate.bugs.model;

import java.util.UUID;

public class BaseComment {
    String id;

    void BaseComment() {
        this.id = UUID.randomUUID().toString();
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
