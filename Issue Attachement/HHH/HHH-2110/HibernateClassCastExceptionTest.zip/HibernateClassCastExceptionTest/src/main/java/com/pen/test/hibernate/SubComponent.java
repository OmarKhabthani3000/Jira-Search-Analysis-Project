package com.pen.test.hibernate;

/**
 * Test subclass 2
 */
public class SubComponent
    extends AbstractComponent {
    //~ Instance fields --------------------------------------------------------

    private AbstractComponent parent;

    //~ Methods ----------------------------------------------------------------

    /**
     * DOCUMENT ME!
     *
     * @return Returns the parent.
     */
    public AbstractComponent getParent() {
        return parent;
    }

    /**
     * DOCUMENT ME!
     *
     * @param parent The parent to set.
     */
    public void setParent(final AbstractComponent parent) {
        this.parent = parent;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public RootComponent getRootComponent() {
        return getParent().getRootComponent();
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public AbstractComponent getRootComponentAsBaseType() {
        return getParent().getRootComponentAsBaseType();
    }

    /**
     * DOCUMENT ME!
     *
     * @param visitor DOCUMENT ME!
     */
    public void accept(final AbstractComponentVisitor visitor) {
        // Not interested
    }
}
