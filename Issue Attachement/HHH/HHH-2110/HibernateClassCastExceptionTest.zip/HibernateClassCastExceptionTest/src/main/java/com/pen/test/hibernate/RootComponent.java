package com.pen.test.hibernate;

/**
 * Test subclass 1
 */
public class RootComponent
    extends AbstractComponent {
    //~ Instance fields --------------------------------------------------------

    private String attrOne;

    //~ Methods ----------------------------------------------------------------

    /**
     * DOCUMENT ME!
     *
     * @return Returns the attrOne.
     */
    public String getAttrOne() {
        return attrOne;
    }

    /**
     * DOCUMENT ME!
     *
     * @param attrOne The attrOne to set.
     */
    public void setAttrOne(final String attrOne) {
        this.attrOne = attrOne;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public RootComponent getRootComponent() {
        return this;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public AbstractComponent getRootComponentAsBaseType() {
        return this;
    }

    /**
     * DOCUMENT ME!
     *
     * @param visitor DOCUMENT ME!
     */
    public void accept(final AbstractComponentVisitor visitor) {
        visitor.visitRootComponent(this);
    }
}
