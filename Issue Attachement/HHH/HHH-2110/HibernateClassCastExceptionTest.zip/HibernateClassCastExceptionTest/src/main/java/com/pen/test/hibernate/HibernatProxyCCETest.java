package com.pen.test.hibernate;

import junit.framework.TestCase;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.SessionFactory;

import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

import org.hibernate.classic.Session;

import org.hibernate.dialect.HSQLDialect;


/**
 * DOCUMENT ME!
 */
public class HibernatProxyCCETest
    extends TestCase {
    //~ Static fields/initializers ---------------------------------------------

    private static final String TEST_STRING = "Test";

    //~ Instance fields --------------------------------------------------------

    private SessionFactory sessionFactory;
    private Session session;
    private Long componentId;

    //~ Constructors -----------------------------------------------------------

    /**
     * Creates a new HibernatProxyCCETest object.
     */
    public HibernatProxyCCETest() {
        super();
        createSessionFactory();
    }

    /**
     * Creates a new HibernatProxyCCETest object.
     *
     * @param name DOCUMENT ME!
     */
    public HibernatProxyCCETest(final String name) {
        super(name);
        createSessionFactory();
    }

    //~ Methods ----------------------------------------------------------------

    private final void createSessionFactory()
        throws MappingException, HibernateException {
        Configuration configuration = new Configuration();
        configuration.setProperty(Environment.DRIVER, "org.hsqldb.jdbcDriver");
        configuration.setProperty(Environment.URL,
            "jdbc:hsqldb:mem:HibernateProxyCCETest");
        configuration.setProperty(Environment.USER, "sa");
        configuration.setProperty(Environment.DIALECT,
            HSQLDialect.class.getName());
        configuration.setProperty(Environment.SHOW_SQL, "true");
        configuration.setProperty(Environment.HBM2DDL_AUTO, "create-drop");

        configuration.addClass(AbstractComponent.class);

        sessionFactory = configuration.buildSessionFactory();
    }

    /**
     * DOCUMENT ME!
     *
     * @param args DOCUMENT ME!
     */
    public static void main(final String[] args) {
        junit.swingui.TestRunner.run(HibernatProxyCCETest.class);
    }

    /**
     * DOCUMENT ME!
     *
     * @throws Exception DOCUMENT ME!
     */
    protected void setUp()
        throws Exception {
        super.setUp();

        session = sessionFactory.openSession();

        // Set up AbstractComponent tree - one parent and one child
        RootComponent rootComponent = new RootComponent();
        rootComponent.setAttrOne(TEST_STRING);

        SubComponent subComponent = new SubComponent();
        rootComponent.getChildren().add(subComponent);
        subComponent.setParent(rootComponent);
        session.save(rootComponent);
        componentId = subComponent.getId();

        session.flush();
        // Need to clear the session otherwise the original
        // objects will be in it and the proxy settings will not
        // take effect
        session.clear();
    }

    /**
     * DOCUMENT ME!
     */
    public void testUsingProperType() {
        try {
            AbstractComponent component =
                (AbstractComponent) session.load(AbstractComponent.class,
                    componentId);
            RootComponent rootComponent = component.getRootComponent();
            String result = rootComponent.getAttrOne();

            assertEquals(TEST_STRING, result);
        } finally {
            session.close();
        }
    }

    /**
     * DOCUMENT ME!
     */
    public void testUsingBaseTypeAndVisitorWorkaround() {
        class RootAtrrGetter
            implements AbstractComponentVisitor {
            String attrVal = "";

            public void visitRootComponent(final RootComponent rootComponent) {
                attrVal = rootComponent.getAttrOne();
            }
        }

        RootAtrrGetter rootAtrrGetter = new RootAtrrGetter();

        try {
            AbstractComponent component =
                (AbstractComponent) session.load(AbstractComponent.class,
                    componentId);
            AbstractComponent rootComponent =
                component.getRootComponentAsBaseType();
            rootComponent.accept(rootAtrrGetter);

            assertEquals(TEST_STRING, rootAtrrGetter.attrVal);
        } finally {
            session.close();
        }
    }
}
