package com.pen.test.hibernate;

import java.util.Collection;
import java.util.HashSet;


/**
 * DOCUMENT ME!
 */
public abstract class AbstractComponent {
    //~ Instance fields --------------------------------------------------------

    private Long id;
    private Collection children = new HashSet();

    //~ Methods ----------------------------------------------------------------

    /**
     * DOCUMENT ME!
     *
     * @return Returns the id.
     */
    public Long getId() {
        return id;
    }

    /**
     * DOCUMENT ME!
     *
     * @param id The id to set.
     */
    public void setId(final Long id) {
        this.id = id;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public abstract RootComponent getRootComponent();

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public abstract AbstractComponent getRootComponentAsBaseType();

    /**
     * DOCUMENT ME!
     *
     * @return Returns the children.
     */
    public Collection getChildren() {
        return children;
    }

    /**
     * DOCUMENT ME!
     *
     * @param children The children to set.
     */
    public void setChildren(final Collection children) {
        this.children = children;
    }

    /**
     * DOCUMENT ME!
     *
     * @param visitor DOCUMENT ME!
     */
    public abstract void accept(final AbstractComponentVisitor visitor);
}
