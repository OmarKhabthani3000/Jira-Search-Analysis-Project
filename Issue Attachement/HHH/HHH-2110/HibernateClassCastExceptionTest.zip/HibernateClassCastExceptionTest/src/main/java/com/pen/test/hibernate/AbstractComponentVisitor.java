package com.pen.test.hibernate;

/**
 * DOCUMENT ME!
 */
public interface AbstractComponentVisitor {
    //~ Methods ----------------------------------------------------------------

    /**
     * DOCUMENT ME!
     *
     * @param rootComponent DOCUMENT ME!
     */
    void visitRootComponent(final RootComponent rootComponent);
}
