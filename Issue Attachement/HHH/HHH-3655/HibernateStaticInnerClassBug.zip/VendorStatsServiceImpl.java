package com.lf.service.stats;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.security.annotation.Secured;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lf.model.enumeration.UserOnboardingEvent;
import com.lf.model.enumeration.UserStatus;
import com.lf.vo.stats.vendor.GeneralVendorStatsVO;


/**
 * A service for extracting vendor specific stats.
 *
 * Created by: Caine
 * On: Dec 6, 2008 - 9:42:51 AM
 */ 
@Repository("vendorStatsService")
@Transactional
public class VendorStatsServiceImpl {
	
	private static final long serialVersionUID = 1L;
	final Logger log = Logger.getLogger(getClass());
	
	@PersistenceContext
	private EntityManager em;
			
	/* (non-Javadoc)
	 * @see com.lf.service.stats.VendorStatsService#getGeneralVendorStats()
	 */
	@Secured({"ROLE_INTERNAL"})
	@Transactional(readOnly = true)
	@SuppressWarnings("unchecked")
	public GeneralVendorStatsVO getGeneralVendorStats() {
		
		GeneralVendorStatsVO vo = new GeneralVendorStatsVO();
		
		// This doesn't work.
		String queryString = "SELECT new com.lf.vo.stats.vendor.GeneralVendorStatsVO.StatusCounts(user.status, count(user)) FROM User user GROUP BY user.status";
		Query query = this.em.createQuery(queryString);
		List<GeneralVendorStatsVO.StatusCounts> statusCounts = query.getResultList();
		vo.setStatusCounts(statusCounts);
		for (GeneralVendorStatsVO.StatusCounts entry : statusCounts) {
			log.debug("Status: " + entry.getStatus()+ "Count: " + entry.getCount());
		}
		
		return vo;
	}
}
