CREATE SCHEMA IF NOT EXISTS base;
comment on schema base is 'datamodel for service-base-service management';

CREATE TABLE IF NOT EXISTS base.myentity
(
    id 				bigint,
    bookDate        timestamptz,
    data            varchar
);