package org.acme;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.Objects;

/**
 * @since 13.06.2023
 */
public class MyEntityKey implements Serializable {

    private Long id;
    private OffsetDateTime bookDate;

    public MyEntityKey(Long aId, OffsetDateTime aBookDate) {
        this.id = aId;
        this.bookDate = aBookDate;
    }

    public MyEntityKey() {
        //defualt constructor
    }

    //<editor-fold defaultstate="collapsed" desc="getter & setter">
    public Long getId() {
        return id;
    }

    public void setId(Long aId) {
        this.id = aId;
    }

    public OffsetDateTime getBookDate() {
        return bookDate;
    }

    public void setBookDate(OffsetDateTime aBookDate) {
        this.bookDate = aBookDate;
    }
    //</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="hashCode & equals">
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.id);
        hash = 37 * hash + Objects.hashCode(this.bookDate);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final MyEntityKey other = (MyEntityKey) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return Objects.equals(this.bookDate, other.bookDate);
    }
    //</editor-fold>
}
