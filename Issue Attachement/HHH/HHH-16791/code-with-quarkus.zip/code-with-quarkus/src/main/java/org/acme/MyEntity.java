package org.acme;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import java.time.OffsetDateTime;

@Entity(name = "MyEntity")
@Table(name = "myentity", schema = "base")
@IdClass(MyEntityKey.class)
public class MyEntity {

    @Id
    private Long id;

    @Id
    private OffsetDateTime bookDate;
    
    private String data;

    //<editor-fold defaultstate="collapsed" desc="getter & setter">
    public Long getId() {
        return id;
    }
    
    public void setId(Long aId) {
        this.id = aId;
    }
    
    public OffsetDateTime getBookDate() {
        return bookDate;
    }
    
    public void setBookDate(OffsetDateTime aBookDate) {
        this.bookDate = aBookDate;
    }
    
    public String getData() {
        return data;
    }
    
    public void setData(String aData) {
        this.data = aData;
    }
    //</editor-fold>
    
    
}
