package org.acme;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

@QuarkusTest
@Transactional(Transactional.TxType.REQUIRES_NEW)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class MyEntityTest {

    static final long ID = 100L;
    static final OffsetDateTime BOOK_DATE = OffsetDateTime.now();//.truncatedTo(ChronoUnit.MILLIS);

    @Inject
    EntityManager em;

    @BeforeAll
    public void peristMyEntity() {
        MyEntity myEntity = new MyEntity();
        myEntity.setId(ID);
        myEntity.setBookDate(BOOK_DATE);
        myEntity.setData("some data");
        em.persist(myEntity);
    }

    @Test
    public void selectMyEntity() {
        List<MyEntity> resultList = em
                .createQuery("SELECT x FROM MyEntity x WHERE x.id = :id AND x.bookDate = :bookDate", MyEntity.class)
                .setParameter("id", ID)
                .setParameter("bookDate", BOOK_DATE)
                .getResultList();
        assertEquals(1, resultList.size());
        System.out.println("selected MyEntity " + resultList.get(0));
    }

    @Test
    public void findMyEntity() {
        MyEntity found = em.find(MyEntity.class, new MyEntityKey(ID, BOOK_DATE));
        assertNotNull(found);
        System.out.println("found MyEntity " + found);
    }

}
