package gss.hibernate.test;

import java.util.Collection;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Arrays;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.junit.Test;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;

import junit.framework.TestCase;

public class NamedQueryTest extends TestCase{
	
	private static final Logger logger = Logger.getLogger(NamedQueryTest.class);
	private SessionFactory sessionFactory;
	private static ServiceRegistry serviceRegistry;
	
	@SuppressWarnings("deprecation")
	@Override
	protected void setUp() throws Exception {
		try {
			Configuration configuration = new Configuration().configure();

            serviceRegistry = new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
            sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}
	
	private Session openSession() {
		//if(sessionFactory!=null) {
		return sessionFactory.openSession();
		//}
	}

	@Test
	public void testNoTest() {
		   
	    //no test needs to run
	}

	
}
