package gss.hibernate.test.entity.annotations;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;


@Entity
@Table(name="ENTITY_A")
@NamedQuery(name="getEntityBById",
query = "from EntityA s where s.entityB.entityBId = :entityBId")
public class EntityA implements Serializable{
	
	
	private Long entityAId;
	
        @SequenceGenerator( allocationSize=1, name="ENTITY_A", sequenceName="ENTITY_A_SEQ" )
	@GeneratedValue( strategy=GenerationType.SEQUENCE, generator="ENTITY_A")
        @Id @Column(name="ENTITY_A_ID")
	public Long getEntityAId() {
		return this.entityAId;
	}
	
	public void setEntityAId(Long entityAId) {
		this.entityAId = entityAId;
	}
	
	@ManyToOne @JoinColumn(name="ENTITY_B_ID")
	private EntityB entityB;
	
	public EntityB getEntityB() {
		return this.entityB;
	}

	public void setEntityB(EntityB entityB) {
		this.entityB = entityB;
	}
	
	
	 private String name;

	  /** persistent field */
	  private boolean isFloatingInd;

	  /** persistent field */
	  private int sequenceNum;

	  /** nullable persistent field */
	  private Integer fixedStartTime;

	  /** nullable persistent field */
	 // private DtNote logNote;

	  /** persistent field */
	 // private int estDuration;

	  /** nullable persistent field */
	  private Integer calcStartTime;

	  /** nullable persistent field */
	  private Integer calcDuration;
	 @Column(name="NAME",length=50)

	  public String getName() {
	    return name;
	  }

	  public void setName(String name) {
	    this.name = name;
	  }

	  /**
	   * @hibernate.property column="IS_FLOATING_IND" type="yes_no" length="1" not-null="true"
	   *
	   */
	  @Column(name="IS_FLOATING_IND")
	  @Type(type="yes_no")
	  public boolean getIsFloatingInd() {
	    return isFloatingInd;
	  }

	  public void setIsFloatingInd(boolean isFloatingInd) {
	    this.isFloatingInd = isFloatingInd;
	  }

	  /**
	   * @hibernate.property column="SEQUENCE_NUM" length="2" not-null="true"
	   *
	   */

	  @Column(name="SEQUENCE_NUM",length=2,nullable=false)

	  public int getSequenceNum() {
	    return sequenceNum;
	  }

	  public void setSequenceNum(int sequenceNum) {
	    this.sequenceNum = sequenceNum;
	  }

	  /**
	   * @hibernate.property column="FIXED_START_TIME" length="6"
	   *
	   */

	  @Column(name="FIXED_START_TIME",length=6)

	  public Integer getFixedStartTime() {
	    return fixedStartTime;
	  }

	  public void setFixedStartTime(Integer fixedStartTime) {
	    this.fixedStartTime = fixedStartTime;
	  }



	  /**
	   * @hibernate.property column="CALC_START_TIME" length="6"
	   *
	   */

	  @Column(name="CALC_START_TIME",length=6)

	  public Integer getCalcStartTime() {
	    return calcStartTime;
	  }

	  public void setCalcStartTime(Integer calcStartTime) {
	    this.calcStartTime = calcStartTime;
	  }

	  /**
	   * @hibernate.property column="CALC_DURATION" length="6"
	   *
	   */

	  @Column(name="CALC_DURATION",length=6)

	  public Integer getCalcDuration() {
	    return calcDuration;
	  }

	  public void setCalcDuration(Integer calcDuration) {
	    this.calcDuration = calcDuration;
	  }

}
