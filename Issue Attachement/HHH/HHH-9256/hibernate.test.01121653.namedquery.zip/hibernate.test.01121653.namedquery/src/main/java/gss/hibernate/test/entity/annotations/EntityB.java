package gss.hibernate.test.entity.annotations;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="ENTITY_B")
public class EntityB implements Serializable{
	
	@SequenceGenerator( allocationSize=1, name="ENTITY_B", sequenceName="ENTITY_B_SEQ" )
	@GeneratedValue( strategy=GenerationType.SEQUENCE, generator="ENTITY_B")
    @Id @Column(name="ENTITY_B_ID")
	private Long entityBId;
	
	public Long getEntityBId() {
		return this.entityBId;
	}
	
	public void setEntityBId(Long entityBId) {
		this.entityBId = entityBId;
	}
	
	@Column(name="ENTITY_NAME")
	private String entityName;
	public String getEntityName() {
		return this.entityName; 
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

}
