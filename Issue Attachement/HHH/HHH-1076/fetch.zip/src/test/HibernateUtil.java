package test;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class HibernateUtil {
	private static final SessionFactory sessionFactory;
	private static final ThreadLocal<Session> session = new ThreadLocal<Session>();
	private static Log log = LogFactory.getLog(HibernateUtil.class);

	// Initialisierung des statischen Attributs sessionFactory beim Laden der Klasse
	static {
		try {
			Configuration conf = new Configuration();
			// Einlesen von hibernate.cfg.xml
			conf.configure();

			// SessionFactory erzeugen
			sessionFactory = conf.buildSessionFactory();
		}
		catch (Throwable e) {
			log.fatal("Initiale SessionFactory kann nicht erzeugt werden", e);
			throw new ExceptionInInitializerError(e);
		}
	}

	/**
	 * Session-Objekt f&uuml;r DB-Operationen ermitteln: Transaktionen starten
	 * und beenden, CRUD-Operationen f&uuml;r persistente Objekte.
	 * @return Ein Objekt f&uuml;r eine Hibernate-Session.
	 * @throws HibernateException Falls beim DB-Zugriff Fehler auftreten.
	 */
	public static Session currentSession() throws HibernateException {
		Session s = (Session) session.get();

		// Session oeffnen, falls noch nicht geoeffnet
		if (s == null) {
			s = sessionFactory.openSession();
			// Zuweisung an ThreadLocal
			session.set(s);
		}
		return s;
	}

	/**
	 * Schlie&szlig;en der Hibernate-Session: Beim Herunterfahren des Appservers,
	 * z.B. mit JMX.
	 * @throws HibernateException Falls beim DB-Zugriff Fehler auftreten.
	 */
	public static void closeSession() throws HibernateException {
		Session s = (Session) session.get();
		session.set(null);
		if (s != null)
			s.close();
	}
}