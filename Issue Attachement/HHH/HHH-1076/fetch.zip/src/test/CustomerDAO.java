package test;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


final public class CustomerDAO {
	private static Log log = LogFactory.getLog(CustomerDAO.class);

	public static void main(String[] args) {
		if (args.length != 1)
			usage();
		
		final String name = args[0];
		
		System.out.println("Load HibernateUtil");
		try {
			Class.forName(HibernateUtil.class.getName());
		}
		catch (ClassNotFoundException e) {
			System.err.println("Hibernate utility class not found");
			System.exit(-1);
		}
		
		System.out.println("LEFT OUTER JOIN:");
		List<Long> ids = findCustomersByName(name);
		for (Long id: ids) {
			System.out.println("id: " + id);
		}

		System.out.println("FETCH JOIN:");
		ids = findCustomersByNameFetch(name);
		for (Long id: ids) {
			System.out.println("id: " + id);
		}
	}
	
	public static List<Long> findCustomersByName(String name) {
		if (log.isDebugEnabled()) log.debug("BEGIN findCustomersByName: " + name);

		final Session session = HibernateUtil.currentSession();
		final Transaction trans = session.beginTransaction();

		final String queryStr = "SELECT DISTINCT c.id FROM CustomerData c LEFT JOIN c.orders o WHERE c.name = '" + name + "' AND o.id > 0";;
		final Query query = session.createQuery(queryStr);

		@SuppressWarnings("unchecked")
		List<Long> ids = query.list();

		trans.commit();

		if (ids == null)
			ids = new ArrayList<Long>();

		if (log.isDebugEnabled()) log.debug("END findCustomersByName: " + ids.size() + " records");

		return ids;
	}


	public static List<Long> findCustomersByNameFetch(String name) {
		if (log.isDebugEnabled()) log.debug("BEGIN findCustomersByNameFetch: " + name);

		final Session session = HibernateUtil.currentSession();
		final Transaction trans = session.beginTransaction();

		final String queryStr = "SELECT DISTINCT c.id FROM CustomerData c LEFT JOIN FETCH c.orders o WHERE c.name = '" + name + "' AND o.id > 0";;
		final Query query = session.createQuery(queryStr);

		@SuppressWarnings("unchecked")
		List<Long> ids = query.list();

		trans.commit();

		if (ids == null)
			ids = new ArrayList<Long>();

		if (log.isDebugEnabled()) log.debug("END findCustomersByNameFetch: " + ids.size() + " records");

		return ids;
	}


	private static void usage() {
		System.err.println("Usage: java " + CustomerDAO.class.getName() + " <name>");
		System.exit(-1);
	}
}