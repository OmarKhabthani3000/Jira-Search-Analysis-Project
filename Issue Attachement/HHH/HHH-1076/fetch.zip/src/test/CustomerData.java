package test;

import java.util.ArrayList;
import java.util.Collection;


public class CustomerData implements java.io.Serializable {
	private long id = 0;
	private String name = "";
	private Collection<OrderData> orders = new ArrayList<OrderData>();
	private static final long serialVersionUID = -3803020503441169594L;

	public CustomerData() {
		super();
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String nachname) {
		this.name = nachname;
	}

	public Collection<OrderData> getOrders() {
		return orders;
	}
	public void setOrders(Collection<OrderData> bestellungen) {
		this.orders = bestellungen;
	}

	@Override
	public String toString() {
		return "{id=" + id + ", name=" + name + '}';
	}
	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other instanceof CustomerData == false) return false;

		final CustomerData k = (CustomerData) other;
		return id == k.id && name.equals(k.name);
	}
}