package test;


public class OrderData implements java.io.Serializable {
	private long id = 0;
	private String text = "";
	private CustomerData customer;
	private static final long serialVersionUID = 5284620563675585237L;

	public OrderData() {
		super();
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}

	public CustomerData getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerData customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "{id=" + id + ", text=" + text + '}';
	}

	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other instanceof OrderData == false) return false;

		final OrderData b = (OrderData) other;
		return id == b.id;
	}
}