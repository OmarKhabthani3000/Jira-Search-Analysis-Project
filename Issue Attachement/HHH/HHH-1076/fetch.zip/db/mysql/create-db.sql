/*
 *    Aufruf:   mysql -vvv -u root < create-db.sql
 */

DROP DATABASE IF EXISTS demodb;
CREATE DATABASE demodb;