/*
 *    Aufruf:   mysql -vvv -u demo < clean.sql
 */

use mysql;

drop database demodb;
drop user demo@localhost;
