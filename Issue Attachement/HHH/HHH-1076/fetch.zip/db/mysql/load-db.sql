USE demodb;

LOAD DATA LOCAL INFILE "db/mysql/customer.csv"
INTO TABLE customer
FIELDS TERMINATED BY ';' ENCLOSED BY '"';

LOAD DATA LOCAL INFILE "db/mysql/orders.csv"
INTO TABLE orders
FIELDS TERMINATED BY ';' ENCLOSED BY '"';
