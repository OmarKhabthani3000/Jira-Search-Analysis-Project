/*
 *    Aufruf:   mysql -vvv -u root < create-user.sql
 */

GRANT ALL PRIVILEGES ON demodb.* TO demo@localhost IDENTIFIED BY 'demopassword';