SET search_path TO demo;

CREATE SEQUENCE hibernate_sequence START WITH 1000;

CREATE TABLE customer(
	id BIGINT NOT NULL DEFAULT nextval('hibernate_sequence'),
	name VARCHAR(32) NOT NULL,
	CONSTRAINT customer_pk PRIMARY KEY(id)
);
	
CREATE TABLE orders(
	id BIGINT NOT NULL DEFAULT nextval('hibernate_sequence'),
	text VARCHAR(32) NOT NULL,
	customer_fk BIGINT NOT NULL,
    CONSTRAINT order_pk PRIMARY KEY(id),
    CONSTRAINT order_customer_fk FOREIGN KEY (customer_fk) REFERENCES customer(id)
);

CREATE INDEX order_customer_index ON orders(customer_fk);
