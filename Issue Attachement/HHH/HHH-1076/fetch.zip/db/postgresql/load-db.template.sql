SET search_path TO demo;

COPY customer
	FROM '@PATH@/customer.csv'
	DELIMITER ';' CSV;

COPY orders
	FROM '@PATH@/orders.csv'
	DELIMITER ';' CSV;
