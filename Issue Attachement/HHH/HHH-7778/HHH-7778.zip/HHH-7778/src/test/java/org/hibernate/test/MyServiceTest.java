package org.hibernate.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.Test;

/**
 * MyService tests.
 */
@ContextConfiguration(locations = "classpath:context.xml")
public class MyServiceTest extends AbstractTransactionalTestNGSpringContextTests
{
    /**
     * The service.
     */
    @Autowired
    private MyService service;

    /**
     * Tests the persist method.
     */
    @Test
    public void testPersist()
    {
        MyEntity entity = service.persist(new MyEntity(0, "string", "bytes".getBytes()));
        assert entity.getId() > 0;
    }
}
