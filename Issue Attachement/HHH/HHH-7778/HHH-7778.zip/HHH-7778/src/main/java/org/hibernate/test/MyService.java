package org.hibernate.test;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

/**
 * My service.
 */
@Repository
public class MyService
{
    /**
     * The entity manager.
     */
    @PersistenceContext
    private EntityManager entityManager;

    /**
     * Persists.
     * 
     * @param entity the entity.
     * 
     * @return the persisted entity.
     */
    public MyEntity persist(final MyEntity entity)
    {
        entityManager.persist(entity);
        return entity;
    }
}
