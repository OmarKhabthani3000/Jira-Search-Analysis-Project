package org.hibernate.test;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;

/**
 * My entity.
 */
@Entity
public class MyEntity implements Serializable
{
    /**
     * The id.
     */
    @Id
    @GeneratedValue
    private long id;

    /**
     * The string.
     */
    @Lob
    private String string;

    /**
     * The bytes.
     */
    @Lob
    private byte[] bytes;

    /**
     * Returns the id.
     * 
     * @return the id.
     */
    public long getId()
    {
        return id;
    }

    /**
     * Returns the string.
     * 
     * @return the string.
     */
    public String getString()
    {
        return string;
    }

    /**
     * Returns the bytes.
     * 
     * @return the bytes.
     */
    public byte[] getBytes()
    {
        return bytes;
    }

    /**
     * Constructor.
     */
    protected MyEntity()
    {
        super();
    }

    /**
     * Constructor.
     * 
     * @param id the id.
     * @param string the string.
     * @param bytes the bytes.
     */
    public MyEntity(final long id, final String string, final byte[] bytes)
    {
        this.id = id;
        this.string = string;
        this.bytes = bytes;
    }

    /**
     * The serialVersionUID.
     */
    private static final long serialVersionUID = 6723000485271954387L;
}
