package hibernate.bug.core;

import org.hibernate.CacheMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

import static org.junit.Assert.assertEquals;

public class TestCase {
    private static final String DRIVER_CLASS_NAME = "org.h2.Driver";
    private static final String JDBC_URL = "jdbc:h2:mem:test";

    private Connection conn;

    @Before
    public void setUp() throws Exception {
        conn = DriverManager.getConnection(JDBC_URL);

        runSql("create table SOME_TABLE(ID int not null primary key, A varchar(10), B varchar(10))");
        runSql("insert into SOME_TABLE(ID, A, B) values(1, 'val', 'old')");
    }

    @Test
    public void hibernateCoreHonorsCacheMode() throws Exception {
        Session session = createSession();
        String hql = "from SomeEntity where a = 'val'";

        Query firstQuery = session.createQuery(hql);
        firstQuery.uniqueResult();

        runSql("update SOME_TABLE set B = 'new'");

        Query cacheBypassBugQuery = session.createQuery(hql);
        cacheBypassBugQuery.setCacheMode(CacheMode.IGNORE);

        SomeEntity cacheNotBypassedBugEntity = (SomeEntity) cacheBypassBugQuery.uniqueResult();

        String incorrectB = cacheNotBypassedBugEntity.getB();
        String expectedB = runSql("select B from SOME_TABLE");

        assertEquals(expectedB, incorrectB);
    }

    private String runSql(String sql) throws Exception {
        String value = null;

        Statement stmt = conn.createStatement();

        if (stmt.execute(sql)) {
            ResultSet rs = stmt.getResultSet();

            if (rs.next()) {
                value = rs.getString(1);
            }
        }

        stmt.close();

        return value;
    }

    private static Session createSession() {
        Properties props = new Properties();
        props.setProperty("hibernate.connection.driver_class", DRIVER_CLASS_NAME);
        props.setProperty("hibernate.connection.url", JDBC_URL);
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.H2Dialect");

        Configuration config = new Configuration();
        config.setProperties(props);
        config.addAnnotatedClass(SomeEntity.class);

        SessionFactory sessionFactory = config.buildSessionFactory();

        return sessionFactory.openSession();
    }
}
