package hibernate.bug.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SOME_TABLE")
class SomeEntity {
    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "A")
    private String a;

    @Column(name = "B")
    private String b;

    public Long getId() {
        return id;
    }

    public String getA() {
        return a;
    }

    public String getB() {
        return b;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setA(String a) {
        this.a = a;
    }

    public void setB(String b) {
        this.b = b;
    }
}
