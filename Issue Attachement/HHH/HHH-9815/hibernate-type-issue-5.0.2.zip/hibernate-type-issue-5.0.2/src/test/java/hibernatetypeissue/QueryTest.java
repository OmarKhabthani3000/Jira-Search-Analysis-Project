package hibernatetypeissue;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

import org.junit.Test;

public class QueryTest {
	private static EntityManagerFactory emf;
	private EntityManager em;
	
	@BeforeClass
	public static void openEmf() {		
		emf = Persistence.createEntityManagerFactory("hibernatetypeissue");
	}
	
	@AfterClass
	public static void closeEmf() {
		emf.close();
	}
	
	@Before
	public void openEm() {
		em = emf.createEntityManager();
	}
	
	@After
	public void closeEm() {
		if (em != null) {
			em.close();
		}
	}
	
	@Test
	public void validQueryLeafsOfPineTreeWithJoin() {
		em.createQuery("select l from Leaf l join l.tree t where TYPE(t) = PineTree");
	}
	
	@Test
	public void validQueryLeafsOfPineTree() {
		em.createQuery("select l from Leaf l where TYPE(l.tree) = PineTree");		
	}
}
