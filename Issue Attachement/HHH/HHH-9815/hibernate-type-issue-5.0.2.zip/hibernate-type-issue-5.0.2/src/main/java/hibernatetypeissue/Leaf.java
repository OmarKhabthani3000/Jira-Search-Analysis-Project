package hibernatetypeissue;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;

@Entity
public class Leaf {
	@Id
	private int leafId;
	
	@ManyToOne
	private Tree tree;
	
	public int getLeafId() {
		return leafId;
	}
	
	public Tree getTree() {
		return tree;
	}
}
