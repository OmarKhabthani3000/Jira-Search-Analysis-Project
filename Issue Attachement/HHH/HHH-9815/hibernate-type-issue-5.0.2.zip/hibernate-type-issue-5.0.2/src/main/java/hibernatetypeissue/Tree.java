package hibernatetypeissue;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Tree {
	@Id	
	private int treeId;
	
	@OneToMany(mappedBy = "tree")
	private List<Leaf> leaves;
	
}
