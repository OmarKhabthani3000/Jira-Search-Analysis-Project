package hibernatetypeissue;

import javax.persistence.Entity;

@Entity
public class PineTree extends Tree {

}
