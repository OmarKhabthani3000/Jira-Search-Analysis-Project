package hibernatetypeissue;

import javax.persistence.Persistence;

import org.junit.Test;

public class QueryTest {
	@Test
	public void testQueryLeafsOfPineTree() {
		Persistence.createEntityManagerFactory("hibernatetypeissue");
	}
}
