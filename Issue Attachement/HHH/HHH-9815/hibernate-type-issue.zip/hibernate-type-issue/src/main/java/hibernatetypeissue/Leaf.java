package hibernatetypeissue;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name = "type-fails", query = "select l from Leaf l where TYPE(l.tree) = PineTree")
public class Leaf {
	@Id
	private int leafId;
	
	@ManyToOne
	private Tree tree;
	
	public int getLeafId() {
		return leafId;
	}
	
	public Tree getTree() {
		return tree;
	}
}
