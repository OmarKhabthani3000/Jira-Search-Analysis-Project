package org.hibernate.bugs;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Many many1 = new Many();
		Many many2 = new Many();

		One one = new One();
		many1.one = one;
		many2.one = one;
		List<Many> manys = new ArrayList<>();
		manys.add(many1);
		manys.add(many2);

		one.manyList = manys;

		entityManager.persist(one);

		entityManager.find(Many.class, 1);

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	@Entity
	public static class One{

		@Id
		@GeneratedValue
		public Integer id;

		@OneToMany(
				cascade = {CascadeType.ALL},
				targetEntity = Many.class
		)
		@JoinColumn(name = "one_id", insertable = false, nullable = false, updatable = false)
		public List<Many> manyList;
	}

	@Entity
	public static class Many {

		@Id
		@GeneratedValue
		public Integer id;

		@ManyToOne(cascade = {CascadeType.REFRESH},
				targetEntity = One.class
		)
		@JoinColumn(name = "one_id", nullable = false, insertable = false, updatable = false)
		public One one;
	}
}
