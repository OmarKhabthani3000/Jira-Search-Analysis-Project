package test;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Before;
import org.junit.Test;

public class TestFetchSelect {
    private SessionFactory sessionFactory;

    @Before
    public void setUp() {
        Configuration config = new Configuration();
        config.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        config.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        config.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:test");
        config.setProperty("hibernate.connection.username", "sa");
        config.setProperty("hibernate.connection.password", "");
        config.setProperty("hibernate.connection.pool_size", "1");
        config.setProperty("hibernate.connection.autocommit", "true");
        config.setProperty("hibernate.cache.provider_class", "org.hibernate.cache.HashtableCacheProvider");
        config.setProperty("hibernate.show_sql", "true");
        config.addFile("src/java/test/Test.hbm.xml");

        sessionFactory = config.buildSessionFactory();

        String tbl1 = " CREATE TABLE Parent ( " +
                            " id int not null, " +
                            " parentType varchar(20) not null, " +
                            " PRIMARY KEY (id) " +
                    ");";
        
        String tbl2 = " CREATE TABLE Car ( " +
                            " id int not null, " +
                            " PRIMARY KEY (id) " +
                     " );";
        
        String tbl3 = " CREATE TABLE Father ( " +
                            " id int not null, " +
                            " carId int not null, " +
                            " PRIMARY KEY (id), " +
                            " CONSTRAINT parentIdFK FOREIGN KEY (id) REFERENCES Parent (id), " +
                            " CONSTRAINT carIdFK FOREIGN KEY (carId) REFERENCES Car (id) " +
                    " );";

        Session session = sessionFactory.openSession();

        Query query1 = session.createSQLQuery(tbl1);
        Query query2 = session.createSQLQuery(tbl2);
        Query query3 = session.createSQLQuery(tbl3);

        query1.executeUpdate();
        query2.executeUpdate();
        query3.executeUpdate();
        session.close();
    }

    @Test
    public void testSelect() {
        Session session = sessionFactory.openSession();

        Car car = new Car();
        session.saveOrUpdate(car);

        Father newFather = new Father();
        newFather.setCar(car);
        session.saveOrUpdate(newFather);

        session.flush();
        session.evict(car);
        session.evict(newFather);

        Parent retrievedParent = (Parent) session.load(Parent.class, newFather.getId());
        session.close();

    }

}
