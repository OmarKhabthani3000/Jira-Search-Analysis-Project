package test;

public class Car {
    private long id = 0;

    public void setId(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }
}
