package test;

public class Parent {
    private long id = 0;

    public void setId(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }
}
