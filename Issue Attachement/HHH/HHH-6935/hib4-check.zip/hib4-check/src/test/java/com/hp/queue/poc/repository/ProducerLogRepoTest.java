package com.hp.queue.poc.repository;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.hp.queue.poc.entity.ProducerLog;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath*:*Context.xml")
public class ProducerLogRepoTest {
	
	@Autowired
	private ProducerLogRepository producerLogRepository;
	
	@Autowired
	private ConsumerLogRepository consumerLogRepository;
	
	@Test
	//@Transactional
	//@Rollback(false)
	public void testCreateLog() {
		Assert.assertNotNull(producerLogRepository);
		Assert.assertNotNull(consumerLogRepository);
		
		ProducerLog producerLog = new ProducerLog();
		producerLog.setMessage("Message");
		
		producerLogRepository.save(producerLog);
	}

}
