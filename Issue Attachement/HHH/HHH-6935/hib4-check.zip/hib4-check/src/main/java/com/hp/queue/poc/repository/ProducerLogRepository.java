package com.hp.queue.poc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hp.queue.poc.entity.ProducerLog;


/**
 * @author spielerl
 *
 */
public interface ProducerLogRepository extends JpaRepository<ProducerLog, Long> {
    @Query("select p from ProducerLog as p where p.message = ?1")
    List<ProducerLog> findByMessage(String message);
}
