package com.hp.queue.poc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hp.queue.poc.entity.ConsumerLog;


/**
 * @author spielerl
 *
 */
public interface ConsumerLogRepository extends JpaRepository<ConsumerLog, Long> {
	 @Query("select p from ConsumerLog as p where p.message = ?1")
	 List<ConsumerLog> findByMessage(String message);
}
