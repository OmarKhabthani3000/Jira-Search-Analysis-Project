package org.hibernate.issues.any;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;

public class Issue implements Container {
	
	@GeneratedValue
	@Id
	Long id;
	
	@OneToMany(mappedBy = "container", orphanRemoval = true, cascade = CascadeType.PERSIST)
	@MapKey(name = "name")
	private Map<String, Attachment> attachments = new HashMap<String, Attachment>();
	
	public void addAttachment(String name, String content) {
		this.attachments.put(name, new Attachment(this, name, content));
	}
	
	public Attachment getAttachment(String name) {
		return this.attachments.get(name);
	}
	
	public Iterable<Attachment> getAttachments() {
		return this.attachments.values();
	}
	
	public void removeAttachment(String name) {
		this.attachments.remove(name);
	}
}