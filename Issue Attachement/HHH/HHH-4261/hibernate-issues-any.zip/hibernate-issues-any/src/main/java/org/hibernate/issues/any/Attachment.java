package org.hibernate.issues.any;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

import org.hibernate.annotations.Any;
import org.hibernate.annotations.AnyMetaDef;
import org.hibernate.annotations.MetaValue;
import org.hibernate.annotations.NaturalId;

@Entity
public class Attachment {
	
	@Id
	@GeneratedValue
	Long id;

	@Any(optional = false, metaColumn = @Column(name = "container_type"))
	@AnyMetaDef(idType = "long", metaType = "string", metaValues = { //
			@MetaValue(targetEntity = Blog.class, value = "blog"), //
			@MetaValue(targetEntity = Issue.class, value = "issue") //
	})
	@JoinColumn(name = "container_id")
	@NaturalId
	private Container container;
	
	private String content;
	
	@NaturalId
	private String name;
	
	public Attachment(Container container, String name, String content) {
		this.container = container;
		this.name = name;
		this.content = content;
	}
	
	Attachment() {}
	
	public Container getContainer() {
		return this.container;
	}
	
	public String getContent() {
		return this.content;
	}
	
	public String getName() {
		return this.name;
	}
}
