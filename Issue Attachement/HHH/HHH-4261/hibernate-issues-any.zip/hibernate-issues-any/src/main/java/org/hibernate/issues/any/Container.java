package org.hibernate.issues.any;

public interface Container {
	
	void addAttachment(String name, String content);
	
	Attachment getAttachment(String name);
	
	Iterable<Attachment> getAttachments();
	
	void removeAttachment(String name);
}
