package org.hibernate.issues.any;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Running this test with META-INF/orm.xml on the classpath will trigger bug
 * https://hibernate.onjira.com/browse/HHH-4261.
 * 
 * If orm.xml is removed, then we got an error because of combining
 * bidirectionnal and any (discussed at
 * https://forum.hibernate.org/viewtopic.php?f=1&t=1002834).
 * 
 */
public class AnyTest {

	private static EntityManagerFactory ENTITY_MANAGER_FACTORY;

	private EntityManager entityManager;

	@BeforeClass
	public static void createEntityManagerFactory() {
		ENTITY_MANAGER_FACTORY = Persistence
				.createEntityManagerFactory("org.hibernate.issues");
	}

	@AfterClass
	public static void closeEntityManagerFactory() {
		ENTITY_MANAGER_FACTORY.close();
	}

	@Before
	public void createEntityManager() {
		this.entityManager = ENTITY_MANAGER_FACTORY.createEntityManager();
	}

	@After
	public void closeEntityManager() {
		this.entityManager.close();
	}

	@Test
	public void simpleTest() {

		Blog blog = new Blog();
		blog.addAttachment("image", "nice image here");
		blog.addAttachment("document", "some word document");

		this.entityManager.getTransaction().begin();
		this.entityManager.persist(blog);
		this.entityManager.getTransaction().commit();
	}
}
