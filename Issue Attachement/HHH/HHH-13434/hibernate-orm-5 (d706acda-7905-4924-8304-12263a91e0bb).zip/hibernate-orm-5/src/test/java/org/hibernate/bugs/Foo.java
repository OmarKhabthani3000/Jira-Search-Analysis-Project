package org.hibernate.bugs;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Foo {
    @Id
    private long id;
    @OneToMany
    private List<Bar> bars;
    @OneToOne
    private User user;

    /**
     * Gibt den Wert von {@link #id} zurück.
     *
     * @return id
     */
    public long getId() {
        return id;
    }

    /**
     * Gibt den Wert von {@link #bars} zurück.
     *
     * @return bars
     */
    public List<Bar> getBars() {
        return bars;
    }

    /**
     * Setzt den Wert von {@link #bars} auf bars.
     *
     * @param bars neuer Wert für bars
     */
    public void setBars(List<Bar> bars) {
        this.bars = bars;
    }

    /**
     * Gibt den Wert von {@link #user} zurück.
     *
     * @return use
     */
    public User getUser() {
        return user;
    }

    /**
     * Setzt den Wert von {@link #user} auf use.
     *
     * @param use neuer Wert für use
     */
    public void setUser(User use) {
        this.user = use;
    }

}
