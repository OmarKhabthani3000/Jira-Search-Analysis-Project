package org.hibernate.bugs;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    public void hhhTestFooWithDistinct() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Foo> query = cb.createQuery(Foo.class);
        query.distinct(true);
        Root<Foo> from = query.from(Foo.class);
        query.where(cb.equal(from.join("bars").get("value"), 42));
        query.orderBy(cb.asc(from.join("user").get("name")));
        List<Foo> resultList = entityManager.createQuery(query).getResultList();

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    @Test
    public void hhhTestFooWithoutDistinct() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Foo> query = cb.createQuery(Foo.class);
        Root<Foo> from = query.from(Foo.class);
        query.where(cb.equal(from.join("bars").get("value"), 42));
        query.orderBy(cb.asc(from.join("user").get("name")));
        List<Foo> resultList = entityManager.createQuery(query).getResultList();

        entityManager.getTransaction().commit();
        entityManager.close();
    }

}
