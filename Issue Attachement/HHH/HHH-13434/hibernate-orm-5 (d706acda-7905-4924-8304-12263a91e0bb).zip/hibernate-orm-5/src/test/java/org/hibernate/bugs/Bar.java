package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Bar {
    @Id
    private long id;
    private int value;

    /**
     * Gibt den Wert von {@link #id} zurück.
     *
     * @return id
     */
    public long getId() {
        return id;
    }

    /**
     * Gibt den Wert von {@link #value} zurück.
     *
     * @return value
     */
    public int getValue() {
        return value;
    }

}
