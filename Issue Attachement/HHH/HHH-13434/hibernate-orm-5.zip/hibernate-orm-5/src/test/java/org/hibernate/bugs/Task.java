package org.hibernate.bugs;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Task {
    @Id
    private long id;
    @OneToMany
    private List<User> user;

    /**
     * Gibt den Wert von {@link #id} zurück.
     *
     * @return id
     */
    public long getId() {
        return id;
    }

    /**
     * Setzt den Wert von {@link #id} auf id.
     *
     * @param id neuer Wert für id
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * Gibt den Wert von {@link #user} zurück.
     *
     * @return user
     */
    public List<User> getUser() {
        return user;
    }

    /**
     * Setzt den Wert von {@link #user} auf user.
     *
     * @param user neuer Wert für user
     */
    public void setUser(List<User> user) {
        this.user = user;
    }

}
