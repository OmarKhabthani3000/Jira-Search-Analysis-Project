rootProject.name = "hibernate_named_query"

