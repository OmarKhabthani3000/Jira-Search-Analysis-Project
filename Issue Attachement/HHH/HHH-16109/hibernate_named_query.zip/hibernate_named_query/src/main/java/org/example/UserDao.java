package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import org.example.entity.User;

public class UserDao {

    private final EntityManagerFactory emf;

    private boolean saved;

    public UserDao() {
        emf = Persistence.createEntityManagerFactory("default");
    }

    public long getCount() {
        try (EntityManager em = emf.createEntityManager()) {
            TypedQuery<Long> query;
            if (saved) {
                query = em.createNamedQuery("query", Long.class);
            } else {
                CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
                CriteriaQuery<Long> criteria = criteriaBuilder.createQuery(Long.class);
                Root<User> root = criteria.from(User.class);
                criteria.select(criteriaBuilder.count(root));
                query = em.createQuery(criteria);
                emf.addNamedQuery("query", query);
                saved = true;
            }
            return query.getSingleResult();
        }
    }
}