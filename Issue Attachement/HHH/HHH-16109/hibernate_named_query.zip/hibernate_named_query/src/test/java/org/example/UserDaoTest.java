package org.example;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class UserDaoTest {

    private UserDao userDao = new UserDao();

    @Test
    public void test() {
        Assertions.assertEquals(userDao.getCount(), 0);

        Assertions.assertEquals(userDao.getCount(), 0);
    }
}
