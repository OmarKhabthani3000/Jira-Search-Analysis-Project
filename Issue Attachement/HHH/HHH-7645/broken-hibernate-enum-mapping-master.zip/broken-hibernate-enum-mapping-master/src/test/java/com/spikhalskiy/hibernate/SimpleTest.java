package com.spikhalskiy.hibernate;

import com.spikhalskiy.hibernate.entity.SocialNetwork;
import com.spikhalskiy.hibernate.entity.User;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Test;

/**
 * @author Dmitry Spikhalskiy
 * @since 30.10.12
 */
public class SimpleTest {
    @Test
    public void test() {
        User user = new User(SocialNetwork.STUB_NETWORK_NAME, "facebookId");
        save(user);
        read();
    }

    private static User read() {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();

        Query query = session.createQuery("SELECT e FROM User e");
        User user = (User)query.list().get(0);
        System.out.println(user.getSocialNetworkProfile(SocialNetwork.STUB_NETWORK_NAME));

        session.close();

        return user;
    }

    private static void save(User user) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();

        session.beginTransaction();

        session.save(user);
        session.save(user.getSocialNetworkProfile(SocialNetwork.STUB_NETWORK_NAME));

        session.getTransaction().commit();

        session.close();
    }
}
