package com.spikhalskiy.hibernate;

import com.spikhalskiy.hibernate.entity.SocialNetwork;
import com.spikhalskiy.hibernate.entity.User;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;


public class Main {


}
