package com.spikhalskiy.hibernate.entity;

/**
 * @author Dmitry Spikhalskiy
 * @since 16.09.12
 */
public enum SocialNetwork {
    STUB_NETWORK_NAME
}
