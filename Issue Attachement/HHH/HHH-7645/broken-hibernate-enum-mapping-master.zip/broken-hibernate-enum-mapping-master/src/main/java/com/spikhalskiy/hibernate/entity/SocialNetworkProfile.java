package com.spikhalskiy.hibernate.entity;

import javax.persistence.*;

/**
 * @author Dmitry Spikhalskiy
 * @since 17.09.12
 */
@Entity
@Table(name = "social_network_profile", uniqueConstraints = {@UniqueConstraint(columnNames = {"social_network", "network_id"})})
public class SocialNetworkProfile {
    @javax.persistence.Id
    @javax.persistence.GeneratedValue(generator = "system-uuid")
    @org.hibernate.annotations.GenericGenerator(name = "system-uuid", strategy = "uuid2")
    @javax.persistence.Column(name = "id", unique = true)
    private java.lang.String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(value = EnumType.STRING) //if change type to ordinal - test will not failure
    @Column(name = "social_network", nullable = false)
    private SocialNetwork socialNetworkType;

    @Column(name = "network_id", nullable = false)
    private String networkId;

    protected SocialNetworkProfile() {
    }

    protected SocialNetworkProfile(User user, SocialNetwork socialNetworkType, String networkId) {
        this.user = user;
        this.socialNetworkType = socialNetworkType;
        this.networkId = networkId;
    }
}
