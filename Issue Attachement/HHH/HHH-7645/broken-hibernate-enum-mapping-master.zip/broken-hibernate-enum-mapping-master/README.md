broken-hibernate-enum-mapping
=============================

Repo contains example with problematic hibernate enum mapping