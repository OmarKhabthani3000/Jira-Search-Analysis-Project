package org.hibernate.envers.test.integration.entityNames.oneToManyAuditedSessionBug;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.MappingException;
import org.hibernate.envers.test.AbstractSessionTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * @author Sven Rienstra
 * 
 */

public class ReadEntityWithAuditedCollectionTest extends AbstractSessionTest{

	private long id_car1;
	private long id_car2;
	
	private long id_pers1;
	
	protected void initMappings() throws MappingException, URISyntaxException {
		URL url = Thread.currentThread().getContextClassLoader().getResource("mappings/entityNames/oneToManyAuditedSessionBug/mappings.hbm.xml");
        config.addFile(new File(url.toURI()));
	}
	
	
    @BeforeClass(dependsOnMethods = "init")
    public void initData() {
    	
    	newSessionFactory();

        Person pers1 = new Person("Hernan", 28);

        Car car1 = new Car(5, pers1);

        //REV 1 
        getSession().getTransaction().begin();
        getSession().persist(pers1);
        getSession().persist(car1);
        getSession().getTransaction().commit();
        id_pers1 = pers1.getId();
        id_car1 = car1.getId();

        Car car2 = new Car(27, pers1);
        //REV 2
        getSession().getTransaction().begin();
        Person person1 = (Person)getSession().get(Person.class, id_pers1);
        person1.setName("Hernan David");
        person1.setAge(40);
        getSession().persist(car1);
        getSession().persist(car2);
        getSession().getTransaction().commit();
        id_car2 = car2.getId();

    }
    
    @Test
    public void testObtainCollectionWithEntityName() 
    {
    	Person pers1 = (Person) getSession().load(Person.class, id_pers1);
    	
    	Car car3 = new Car(5, pers1);
    	getSession().getTransaction().begin();
    	getSession().saveOrUpdate(car3);
    	getSession().getTransaction().commit();
    	
    	pers1.getCars().size();
    }    

}
