/*
SQLyog Trial v8.61 
MySQL - 5.1.51-community : Database - FMSDB
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`FMSDB` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `FMSDB`;

/*Table structure for table `bankaccounts` */

DROP TABLE IF EXISTS `bankaccounts`;

CREATE TABLE `bankaccounts` (
  `account_num` varchar(20) NOT NULL,
  `bank_id` int(11) DEFAULT NULL COMMENT 'refers to bank_id from Banks table',
  `branch` varchar(50) NOT NULL,
  `account_type` varchar(20) NOT NULL,
  `operation_mode` varchar(10) NOT NULL,
  `bank_account_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`bank_account_id`),
  KEY `FK_bankaccounts` (`bank_id`),
  CONSTRAINT `FK_bankaccounts` FOREIGN KEY (`bank_id`) REFERENCES `banks` (`bank_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `bankaccounts` */

insert  into `bankaccounts`(`account_num`,`bank_id`,`branch`,`account_type`,`operation_mode`,`bank_account_id`) values ('1234567890',29,'Teen Hath Naka','Current','Joint',13);

/*Table structure for table `banks` */

DROP TABLE IF EXISTS `banks`;

CREATE TABLE `banks` (
  `bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(45) DEFAULT NULL,
  `addr_line1` varchar(60) NOT NULL,
  `bank_phone` varchar(25) DEFAULT NULL,
  `routing_num` varchar(45) DEFAULT NULL,
  `ifsc_num` varchar(45) DEFAULT NULL,
  `custcare_num` varchar(25) DEFAULT NULL,
  `website` varchar(45) DEFAULT NULL,
  `bank_details` varchar(300) DEFAULT NULL,
  `updatedBy` varchar(50) DEFAULT NULL,
  `updatedOn` timestamp NULL DEFAULT NULL,
  `addr_line2` varchar(60) DEFAULT NULL,
  `city` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL,
  `zipcode` varchar(45) NOT NULL,
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1 COMMENT='This is banks master table.';

/*Data for the table `banks` */

insert  into `banks`(`bank_id`,`bank_name`,`addr_line1`,`bank_phone`,`routing_num`,`ifsc_num`,`custcare_num`,`website`,`bank_details`,`updatedBy`,`updatedOn`,`addr_line2`,`city`,`state`,`country`,`zipcode`) values (29,'HDFC Bank','address line 1','888-111-8989','18237461873','1237476789','800-123-5423','www.hdfcbank.co.in','For testing',NULL,'2010-10-18 17:48:30','address line 2','Thane','Maharashtra','India','400602');

/*Table structure for table `cards` */

DROP TABLE IF EXISTS `cards`;

CREATE TABLE `cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_num` varchar(20) NOT NULL,
  `vendor` varchar(50) NOT NULL,
  `card_name` varchar(50) NOT NULL,
  `valid_till` varchar(15) NOT NULL,
  `cvv_num` varchar(3) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `pay_login` varchar(20) DEFAULT NULL,
  `pay_passwd` varchar(20) DEFAULT NULL,
  `stmt_dt` date DEFAULT NULL,
  `pay_date` date DEFAULT NULL,
  `details` varchar(300) DEFAULT NULL,
  `card_type` varchar(10) DEFAULT NULL,
  `pin` varchar(5) DEFAULT NULL,
  `addr_line1` varchar(30) DEFAULT NULL,
  `addr_line2` varchar(30) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `state` varchar(40) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `zipcode` varchar(20) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_cards` (`user_id`),
  CONSTRAINT `FK_cards` FOREIGN KEY (`user_id`) REFERENCES `users` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `cards` */

/*Table structure for table `fixed_deposits` */

DROP TABLE IF EXISTS `fixed_deposits`;

CREATE TABLE `fixed_deposits` (
  `deposit_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_num` varchar(25) NOT NULL,
  `interest` varchar(30) NOT NULL,
  `tenure` varchar(20) NOT NULL,
  `start_date` date NOT NULL,
  `amount` varchar(30) NOT NULL,
  `details` varchar(300) DEFAULT NULL,
  `bank_id` int(11) NOT NULL,
  PRIMARY KEY (`deposit_id`),
  KEY `FK_fixed_deposits_bank` (`bank_id`),
  CONSTRAINT `FK_fixed_deposits_bank` FOREIGN KEY (`bank_id`) REFERENCES `banks` (`bank_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `fixed_deposits` */

/*Table structure for table `user_bankaccount` */

DROP TABLE IF EXISTS `user_bankaccount`;

CREATE TABLE `user_bankaccount` (
  `bank_account_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`bank_account_id`,`user_id`),
  KEY `FK_user_id` (`user_id`),
  CONSTRAINT `FK_user_bankaccount` FOREIGN KEY (`bank_account_id`) REFERENCES `bankaccounts` (`bank_account_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_bankaccount` */

insert  into `user_bankaccount`(`bank_account_id`,`user_id`) values (13,24),(13,25);

/*Table structure for table `user_fixeddeposits` */

DROP TABLE IF EXISTS `user_fixeddeposits`;

CREATE TABLE `user_fixeddeposits` (
  `deposit_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`deposit_id`,`user_id`),
  KEY `FK_user_fixeddeposits` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_fixeddeposits` */

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `phone_num` varchar(20) DEFAULT NULL,
  `login` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`userid`,`first_name`,`last_name`,`middle_name`,`phone_num`,`login`,`password`) values (24,'Charanya','Kaulgud','Suyash','9967137770','admin','admin'),(25,'Suyash','Kaulgud','Kamlakar','9987647700','admin','admin');

/* Trigger structure for table `banks` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `user_insert` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `user_insert` BEFORE INSERT ON `banks` FOR EACH ROW SET NEW.updatedOn = NOW() */$$


DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
