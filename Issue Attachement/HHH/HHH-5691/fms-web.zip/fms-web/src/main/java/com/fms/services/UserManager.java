package com.fms.services;

import com.fms.bizobj.User;

public class UserManager {

	/**
	 * 
	 * @param loginId
	 * @param password
	 * @return
	 */
	public User login(String loginId, String password) {
		return null;
	}

	/**
	 * 
	 * @param loginId
	 */
	public void logout(String loginId) {
		// TODO
	}

	/**
	 * 
	 * @param user
	 * @return
	 */
	public boolean isAuthorized(User user) {
		return false;
	}

}
