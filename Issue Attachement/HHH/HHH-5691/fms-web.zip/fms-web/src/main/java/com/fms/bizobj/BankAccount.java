package com.fms.bizobj;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fms.framework.LogLevel;
import com.fms.framework.annotations.Loggable;

@Entity
@Table(name = "bankaccounts")
public class BankAccount implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5683572472735529855L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bank_account_id")
	private int accountId;

	@Column(name = "account_num")
	private String accountNumber;

	@ManyToOne
	@JoinColumn(name = "bank_id")
	private Bank bank;

	@Column(name = "branch")
	private String branch;

	@ManyToMany(fetch = FetchType.EAGER)
	 @JoinTable(name = "user_bankaccount", joinColumns = @JoinColumn(name =
	 "bank_account_id"), inverseJoinColumns = @JoinColumn(name = "user_id"))
	private List<User> user = new ArrayList<User>();

	/**
	 * Savings / Current / Recurring
	 */
	@Column(name = "account_type")
	private String accountType;

	public List<User> getUser() {
		return user;
	}

	public void setUser(List<User> user) {
		this.user = user;
	}

	/**
	 * Single / Joint
	 */
	@Column(name = "operation_mode")
	private String opMode;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getOpMode() {
		return opMode;
	}

	public void setOpMode(String opMode) {
		this.opMode = opMode;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	@Override
	@Loggable(value = LogLevel.DEBUG)
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountId;
		result = prime * result
				+ ((accountNumber == null) ? 0 : accountNumber.hashCode());
		return result;
	}

	@Override
	@Loggable(value = LogLevel.DEBUG)
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankAccount other = (BankAccount) obj;
		if (accountId != other.accountId)
			return false;
		if (accountNumber == null) {
			if (other.accountNumber != null)
				return false;
		} else if (!accountNumber.equals(other.accountNumber))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "BankAccount [accountId=" + accountId + ", accountNumber="
				+ accountNumber + ", bank=" + bank + ", branch=" + branch
				+ ", user=" + user + ", accountType=" + accountType
				+ ", opMode=" + opMode + "]";
	}

}
