package com.fms.bizobj;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fms.framework.LogLevel;
import com.fms.framework.annotations.Loggable;

@Entity
@Table(name = "Users")
public class User implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1743701415934308337L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;

	@Column(name = "first_name")
	private String firstName;
	@Column(name = "middle_name")
	private String middleName;
	@Column(name = "last_name")
	private String lastName;
	@Column(name = "phone_num")
	private String phoneNumber;
	@Column(name = "login")
	private String login;
	@Column(name = "password")
	private String password;

	// private Set<String> roles;

	@ManyToMany(fetch = FetchType.EAGER, mappedBy="user")	
	private Set<BankAccount> bankAccounts = new HashSet<BankAccount>();

	// @ManyToMany(fetch=FetchType.EAGER)
	// @IndexColumn(name="loan_id")
	// private Set<FixedDeposit> fixedDeposits = new HashSet<FixedDeposit>();

	public Set<BankAccount> getBankAccount() {
		return bankAccounts;
	}

	public void setBankAccount(Set<BankAccount> bankAccount) {
		this.bankAccounts = bankAccount;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<BankAccount> getBankAccounts() {
		return bankAccounts;
	}

	public void setBankAccounts(Set<BankAccount> bankAccounts) {
		this.bankAccounts = bankAccounts;
	}

	// public Set<FixedDeposit> getFixedDeposits() {
	// return fixedDeposits;
	// }
	//
	// public void setFixedDeposits(Set<FixedDeposit> fixedDeposits) {
	// this.fixedDeposits = fixedDeposits;
	// }

	@Override
	@Loggable(value = LogLevel.DEBUG)
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + userId;
		return result;
	}

	@Override
	@Loggable(value = LogLevel.DEBUG)
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;

		if (userId != other.userId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstName=" + firstName
				+ ", middleName=" + middleName + ", lastName=" + lastName
				+ ", phoneNumber=" + phoneNumber + ", login=" + login
				+ ", password=" + password + ", bankAccounts=" + bankAccounts
				+ "]";
	}

}
