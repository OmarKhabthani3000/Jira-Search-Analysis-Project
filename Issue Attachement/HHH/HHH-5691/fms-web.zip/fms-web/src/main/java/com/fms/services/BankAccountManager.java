package com.fms.services;

import java.util.List;

import com.fms.bizobj.BankAccount;

public class BankAccountManager {

	/**
	 * 
	 * @param userId
	 * @param account
	 */
	public void addAccount(int userId, BankAccount account) {

	}

	/**
	 * 
	 * @param account
	 */
	public void updateAccount(BankAccount account) {

	}

	/**
	 * 
	 * @param userId
	 * @param accountNumber
	 */
	public void deleteAccount(int userId, int accountNumber) {

	}

	/**
	 * 
	 * @param userId
	 * @return
	 */
	public List<BankAccount> getBankAccountsForUser(int userId) {
		return null;
	}

	/**
	 * 
	 * @param accountNumber
	 * @return
	 */
	public BankAccount getBankAccountDetails(int accountNumber) {
		return null;
	}

}
