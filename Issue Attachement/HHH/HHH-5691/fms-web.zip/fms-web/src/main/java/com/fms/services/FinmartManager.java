package com.fms.services;

import java.util.List;

public interface FinmartManager {
	
	public List<BaseManager> fetchAll();
	
	public BaseManager fetch(int id);
	
	public void save(BaseManager baseManager);
	
	public void saveAll(List<BaseManager> baseManager);
	
	public void delete(BaseManager baseManager);
	
	public void deletaAll(List<BaseManager> baseManager);
	
	public void update(BaseManager baseManager);
	
	public void updateAll(List<BaseManager> baseManager);
	
	

}
