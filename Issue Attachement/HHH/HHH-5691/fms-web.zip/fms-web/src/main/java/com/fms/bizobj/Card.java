package com.fms.bizobj;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

//@Entity
//@Table(name = "cards")
public class Card extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2468899076716853623L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "card_num")
	private String cardNumber;

	@Column(name = "vendor")
	private String vendor;

	@Column(name = "card_name")
	private String cardName;

	@Column(name = "valid_till")
	private String vaildTill;

	@Column(name = "cvv_num")
	private String cvv;

	@Embedded
	private Address address;

	@Column(name = "url")
	private String url;

	@Column(name = "pay_login")
	private String payLogin;

	@Column(name = "pay_passwd")
	private String payPassword;

	@Column(name = "stmt_date")
	private Date stmtDate;

	@Column(name = "pay_date")
	private Date paymentDate;

	@Column(name = "details")
	private String details;

	@Column(name = "card_type")
	private String cardType;

	@Column(name = "pin")
	private String pin;

//	@ManyToOne(fetch = FetchType.EAGER)
//	@JoinColumn(name = "user_id")
	private User user;

	/**
	 * @return the vendor
	 */
	public String getVendor() {
		return vendor;
	}

	/**
	 * @param vendor
	 *            the vendor to set
	 */
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getStmtDate() {
		return stmtDate;
	}

	public void setStmtDate(Date stmtDate) {
		this.stmtDate = stmtDate;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardName() {
		return cardName;
	}

	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

	public String getVaildTill() {
		return vaildTill;
	}

	public void setVaildTill(String vaildTill) {
		this.vaildTill = vaildTill;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getPayLogin() {
		return payLogin;
	}

	public void setPayLogin(String payLogin) {
		this.payLogin = payLogin;
	}

	public String getPayPassword() {
		return payPassword;
	}

	public void setPayPassword(String payPassword) {
		this.payPassword = payPassword;
	}

	/**
	 * @return the cardType
	 */
	public String getCardType() {
		return cardType;
	}

	/**
	 * @param cardType
	 *            the cardType to set
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * @return the pin
	 */
	public String getPin() {
		return pin;
	}

	/**
	 * @param pin
	 *            the pin to set
	 */
	public void setPin(String pin) {
		this.pin = pin;
	}

	@Override
	public String toString() {
		return "Card [id=" + id + ", cardNumber=" + cardNumber + ", vendor="
				+ vendor + ", cardName=" + cardName + ", vaildTill="
				+ vaildTill + ", cvv=" + cvv + ", address=" + address
				+ ", url=" + url + ", payLogin=" + payLogin + ", payPassword="
				+ payPassword + ", stmtDate=" + stmtDate + ", paymentDate="
				+ paymentDate + ", details=" + details + ", cardType="
				+ cardType + ", pin=" + pin + ", user=" + user + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result
				+ ((cardName == null) ? 0 : cardName.hashCode());
		result = prime * result
				+ ((cardNumber == null) ? 0 : cardNumber.hashCode());
		result = prime * result + ((cvv == null) ? 0 : cvv.hashCode());
		result = prime * result + ((details == null) ? 0 : details.hashCode());
		result = prime * result + id;
		result = prime * result
				+ ((payLogin == null) ? 0 : payLogin.hashCode());
		result = prime * result
				+ ((payPassword == null) ? 0 : payPassword.hashCode());
		result = prime * result
				+ ((paymentDate == null) ? 0 : paymentDate.hashCode());
		result = prime * result
				+ ((stmtDate == null) ? 0 : stmtDate.hashCode());
		result = prime * result
				+ ((cardType == null) ? 0 : cardType.hashCode());
		result = prime * result + ((url == null) ? 0 : url.hashCode());
		result = prime * result
				+ ((vaildTill == null) ? 0 : vaildTill.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Card)) {
			return false;
		}
		Card other = (Card) obj;
		if (address == null) {
			if (other.address != null) {
				return false;
			}
		} else if (!address.equals(other.address)) {
			return false;
		}
		if (cardName == null) {
			if (other.cardName != null) {
				return false;
			}
		} else if (!cardName.equals(other.cardName)) {
			return false;
		}
		if (cardNumber == null) {
			if (other.cardNumber != null) {
				return false;
			}
		} else if (!cardNumber.equals(other.cardNumber)) {
			return false;
		}
		if (cvv == null) {
			if (other.cvv != null) {
				return false;
			}
		} else if (!cvv.equals(other.cvv)) {
			return false;
		}
		if (details == null) {
			if (other.details != null) {
				return false;
			}
		} else if (!details.equals(other.details)) {
			return false;
		}
		if (id != other.id) {
			return false;
		}
		if (payLogin == null) {
			if (other.payLogin != null) {
				return false;
			}
		} else if (!payLogin.equals(other.payLogin)) {
			return false;
		}
		if (payPassword == null) {
			if (other.payPassword != null) {
				return false;
			}
		} else if (!payPassword.equals(other.payPassword)) {
			return false;
		}
		if (paymentDate == null) {
			if (other.paymentDate != null) {
				return false;
			}
		} else if (!paymentDate.equals(other.paymentDate)) {
			return false;
		}
		if (stmtDate == null) {
			if (other.stmtDate != null) {
				return false;
			}
		} else if (!stmtDate.equals(other.stmtDate)) {
			return false;
		}
		if (cardType == null) {
			if (other.cardType != null) {
				return false;
			}
		} else if (!cardType.equals(other.cardType)) {
			return false;
		}
		if (url == null) {
			if (other.url != null) {
				return false;
			}
		} else if (!url.equals(other.url)) {
			return false;
		}
		if (vaildTill == null) {
			if (other.vaildTill != null) {
				return false;
			}
		} else if (!vaildTill.equals(other.vaildTill)) {
			return false;
		}
		return true;
	}

}
