package com.fms.dataaccess;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fms.bizobj.Card;
import com.fms.framework.LogLevel;
import com.fms.framework.annotations.Loggable;

//@Repository
//@Transactional
public class CardsDAO {

	private EntityManager em;

	public EntityManager getEm() {
		return em;
	}

//	@PersistenceContext
	public void setEm(EntityManager em) {
		this.em = em;
	}

	/**
	 * This method adds a new card record in CARDS table.
	 * 
	 * @param cardObj
	 */
	@Loggable(value = LogLevel.TRACE)
	public void addCard(Card cardObj) {
		em.persist(cardObj);
	}

	/**
	 * @return List of all cards
	 */
	@SuppressWarnings("unchecked")
	@Loggable(value = LogLevel.TRACE)
	public List<Card> getAllCards() {
		return em.createQuery("Select c from Card c order by c.vendor asc")
				.getResultList();
	}

	/**
	 * @return List of cards of a user.
	 */
	@SuppressWarnings("unchecked")
	@Loggable(value = LogLevel.TRACE)
	public List<Card> getCardsByUser(String firstName, String lastName) {
		Query query = em
				.createQuery("From Card c where c.user.firstName=? and c.user.lastName=?");
		query.setParameter(1, firstName);
		query.setParameter(2, lastName);
		return query.getResultList();
	}

}
