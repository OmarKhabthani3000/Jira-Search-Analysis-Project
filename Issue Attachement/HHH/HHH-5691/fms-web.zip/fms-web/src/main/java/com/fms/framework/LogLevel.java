package com.fms.framework;

public enum LogLevel {
	DEBUG,
	ERROR,
	FATAL,
	INFO,
	TRACE,
	WARN
}
