package com.fms.bizobj;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.IndexColumn;

import com.fms.framework.LogLevel;
import com.fms.framework.annotations.Loggable;

//@Entity
//@Table(name = "fixed_deposits")
public class FixedDeposit  implements Serializable {

	private static final long serialVersionUID = -1418084044344762650L;

//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int loan_id;

//	@Column(name = "account_num")
	private String loan_acct_num;

//	@ManyToOne
//	@JoinColumn(name = "bank_id")
	private Bank bank;

//	@Column(name = "tenure")
	private String tenure;

//	@Column(name = "interest")
	private String interest;

//	@Column(name = "start_date")
	private Date startDate;

//	@Column(name = "amount")
	private String amount;

//	@Column(name = "details")
	private String details;

//	@ManyToMany(fetch=FetchType.EAGER)
//	@JoinTable(name = "user_fixeddeposits", joinColumns = @JoinColumn(name = "loan_id"), inverseJoinColumns = @JoinColumn(name = "user_id"))
//	//@IndexColumn(name="user_id")
	private List<User> user = new ArrayList<User>();

	@Override
	public String toString() {
		return "FixedDeposit [loan_id=" + loan_id + ", loan_acct_num="
				+ loan_acct_num + ", bank=" + bank + ", tenure=" + tenure
				+ ", interest=" + interest + ", startDate=" + startDate
				+ ", amount=" + amount + ", details=" + details + ", user="
				+ user + "]";
	}

	@Override
	@Loggable(value = LogLevel.DEBUG)
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((loan_acct_num == null) ? 0 : loan_acct_num.hashCode());
		result = prime * result + loan_id;
		return result;
	}

	@Override
	@Loggable(value = LogLevel.DEBUG)
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FixedDeposit other = (FixedDeposit) obj;
		if (loan_acct_num == null) {
			if (other.loan_acct_num != null)
				return false;
		} else if (!loan_acct_num.equals(other.loan_acct_num))
			return false;
		if (loan_id != other.loan_id)
			return false;
		return true;
	}

	public int getLoan_id() {
		return loan_id;
	}

	public void setLoan_id(int loan_id) {
		this.loan_id = loan_id;
	}

	public String getLoan_acct_num() {
		return loan_acct_num;
	}

	public void setLoan_acct_num(String loan_acct_num) {
		this.loan_acct_num = loan_acct_num;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public String getTenure() {
		return tenure;
	}

	public void setTenure(String tenure) {
		this.tenure = tenure;
	}

	public String getInterest() {
		return interest;
	}

	public void setInterest(String interest) {
		this.interest = interest;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public List<User> getUser() {
		return user;
	}

	public void setUser(List<User> user) {
		this.user = user;
	}

}
