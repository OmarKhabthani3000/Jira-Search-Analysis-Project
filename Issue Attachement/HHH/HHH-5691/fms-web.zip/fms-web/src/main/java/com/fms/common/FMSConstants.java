package com.fms.common;

/**
 * This class contains all the application constants.
 * All constants should be declared public static final
 * 
 * @author sukaulgud
 *
 */
public class FMSConstants {
	
	// to prevent instantiation
	private FMSConstants(){}
	
	public static final String ADMIN_ROLE = "ADMIN";
	

}
