package com.fms.dataaccess;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fms.bizobj.User;
import com.fms.framework.LogLevel;
import com.fms.framework.annotations.Loggable;

/**
 * This class contains all the methods for CRUD operations of User object.
 * 
 * @author sukaulgud
 * 
 */
@Repository
@Transactional
public class UserDAO {

	private EntityManager em;

	/**
	 * @return EntityManager object
	 */
	public EntityManager getEm() {
		return em;
	}

	/**
	 * 
	 * @param em
	 */
	@PersistenceContext
	public void setEm(EntityManager em) {
		this.em = em;
	}

	/**
	 * 
	 * @param userObj
	 */
	@Loggable(value = LogLevel.TRACE)
	public void addUser(User userObj) {
		em.persist(userObj);
	}

	/**
	 * 
	 * @return List of User objects
	 */
	@SuppressWarnings("unchecked")
	@Loggable(value = LogLevel.TRACE)
	public List<User> getAllUsers() {
		return em.createQuery(
				"Select u from User u order by u.firstName asc")
				.getResultList();

	}

	/**
	 * 
	 * @param firstName
	 * @param lastName
	 * @return List of User objects
	 */
	@SuppressWarnings("unchecked")
	//@Loggable(value = LogLevel.TRACE)
	public List<User> getUserByName(String firstName, String lastName) {
		Query query = em
				.createQuery("Select u From User u where u.firstName=? and u.lastName=?");
		query.setParameter(1, firstName);
		query.setParameter(2, lastName);
		return query.getResultList();

	}

}
