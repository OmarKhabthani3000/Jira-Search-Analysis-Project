package com.fms.bizobj;

import java.io.Serializable;
import java.util.Date;


public class Stock implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2207968501894940648L;


	private int id;
	private String stockName;
	private String symbol;
	private double buyPrice;
	private Date buyDate;
	private Date soldDate;
	private double soldPrice;
	private long quantity;
	private boolean sold;
	private String marketPrice;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the stockName
	 */
	public String getStockName() {
		return stockName;
	}

	/**
	 * @param stockName
	 *            the stockName to set
	 */
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}

	/**
	 * @return the symbol
	 */
	public String getSymbol() {
		return symbol;
	}

	/**
	 * @param symbol
	 *            the symbol to set
	 */
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	/**
	 * @return the buyPrice
	 */
	public double getBuyPrice() {
		return buyPrice;
	}

	/**
	 * @param buyPrice
	 *            the buyPrice to set
	 */
	public void setBuyPrice(double buyPrice) {
		this.buyPrice = buyPrice;
	}

	/**
	 * @return the buyDate
	 */
	public Date getBuyDate() {
		return buyDate;
	}

	/**
	 * @param buyDate
	 *            the buyDate to set
	 */
	public void setBuyDate(Date buyDate) {
		this.buyDate = buyDate;
	}

	/**
	 * @return the soldDate
	 */
	public Date getSoldDate() {
		return soldDate;
	}

	/**
	 * @param soldDate
	 *            the soldDate to set
	 */
	public void setSoldDate(Date soldDate) {
		this.soldDate = soldDate;
	}

	/**
	 * @return the soldPrice
	 */
	public double getSoldPrice() {
		return soldPrice;
	}

	/**
	 * @param soldPrice
	 *            the soldPrice to set
	 */
	public void setSoldPrice(double soldPrice) {
		this.soldPrice = soldPrice;
	}

	/**
	 * @return the quantity
	 */
	public long getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity
	 *            the quantity to set
	 */
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the sold
	 */
	public boolean isSold() {
		return sold;
	}

	/**
	 * @param sold
	 *            the sold to set
	 */
	public void setSold(boolean sold) {
		this.sold = sold;
	}

	/**
	 * @return the marketPrice
	 */
	public String getMarketPrice() {
		return marketPrice;
	}

	/**
	 * @param marketPrice
	 *            the marketPrice to set
	 */
	public void setMarketPrice(String marketPrice) {
		this.marketPrice = marketPrice;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((buyDate == null) ? 0 : buyDate.hashCode());
		long temp;
		temp = Double.doubleToLongBits(buyPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + id;
		result = prime * result
				+ ((marketPrice == null) ? 0 : marketPrice.hashCode());
		result = prime * result + (int) (quantity ^ (quantity >>> 32));
		result = prime * result + (sold ? 1231 : 1237);
		result = prime * result
				+ ((soldDate == null) ? 0 : soldDate.hashCode());
		temp = Double.doubleToLongBits(soldPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result
				+ ((stockName == null) ? 0 : stockName.hashCode());
		result = prime * result + ((symbol == null) ? 0 : symbol.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Stock)) {
			return false;
		}
		Stock other = (Stock) obj;
		if (buyDate == null) {
			if (other.buyDate != null) {
				return false;
			}
		} else if (!buyDate.equals(other.buyDate)) {
			return false;
		}
		if (Double.doubleToLongBits(buyPrice) != Double
				.doubleToLongBits(other.buyPrice)) {
			return false;
		}
		if (id != other.id) {
			return false;
		}
		if (marketPrice == null) {
			if (other.marketPrice != null) {
				return false;
			}
		} else if (!marketPrice.equals(other.marketPrice)) {
			return false;
		}
		if (quantity != other.quantity) {
			return false;
		}
		if (sold != other.sold) {
			return false;
		}
		if (soldDate == null) {
			if (other.soldDate != null) {
				return false;
			}
		} else if (!soldDate.equals(other.soldDate)) {
			return false;
		}
		if (Double.doubleToLongBits(soldPrice) != Double
				.doubleToLongBits(other.soldPrice)) {
			return false;
		}
		if (stockName == null) {
			if (other.stockName != null) {
				return false;
			}
		} else if (!stockName.equals(other.stockName)) {
			return false;
		}
		if (symbol == null) {
			if (other.symbol != null) {
				return false;
			}
		} else if (!symbol.equals(other.symbol)) {
			return false;
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Stock [buyDate=" + buyDate + ", buyPrice=" + buyPrice + ", id="
				+ id + ", marketPrice=" + marketPrice + ", quantity="
				+ quantity + ", sold=" + sold + ", soldDate=" + soldDate
				+ ", soldPrice=" + soldPrice + ", stockName=" + stockName
				+ ", symbol=" + symbol + "]";
	}

}
