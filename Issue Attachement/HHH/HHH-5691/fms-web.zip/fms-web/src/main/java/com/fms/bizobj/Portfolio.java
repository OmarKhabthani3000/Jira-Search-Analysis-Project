package com.fms.bizobj;

import java.util.List;


public class Portfolio {


	private int id;
	private List<FixedDeposit> fds;
	private List<Stock> stocks;
	private List<MutualFund> mutualFunds;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Portfolio [fds=" + fds + ", id=" + id + ", mutualFunds="
				+ mutualFunds + ", stocks=" + stocks + "]";
	}

	public List<FixedDeposit> getFds() {
		return fds;
	}

	public void setFds(List<FixedDeposit> fds) {
		this.fds = fds;
	}

	public List<Stock> getStocks() {
		return stocks;
	}

	public void setStocks(List<Stock> stocks) {
		this.stocks = stocks;
	}

	public List<MutualFund> getMutualFunds() {
		return mutualFunds;
	}

	public void setMutualFunds(List<MutualFund> mutualFunds) {
		this.mutualFunds = mutualFunds;
	}

}
