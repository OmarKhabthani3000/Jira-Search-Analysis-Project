package com.fms.gui;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringLauncher {
    public static void main(String[] args) {
        String[] contextPaths = new String[]{"springexample/app-context.xml"};
        new ClassPathXmlApplicationContext(contextPaths);
    }
} 