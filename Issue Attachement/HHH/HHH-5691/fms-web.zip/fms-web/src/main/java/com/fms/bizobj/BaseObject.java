package com.fms.bizobj;

import java.io.Serializable;
import java.util.Date;

/**
 * This class contains default audit information which is extended by all the
 * business objects.
 * 
 * @author sukaulgud
 * 
 */
public abstract class BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1603947052740407736L;

	private String updatedBy;
	private Date updatedOn;

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

}
