package com.fms.dataaccess;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fms.bizobj.FixedDeposit;
import com.fms.framework.LogLevel;
import com.fms.framework.annotations.Loggable;

@Repository
@Transactional
public class FixedDepositDAO {

	private EntityManager em;

	public EntityManager getEm() {
		return em;
	}

	@PersistenceContext
	public void setEm(EntityManager em) {
		this.em = em;
	}

	@Loggable(value = LogLevel.TRACE)
	public void addFixedDeposit(FixedDeposit fdObj) {
		em.persist(fdObj);
	}

	/**
	 * @return List of all banks
	 */
	@SuppressWarnings("unchecked")
	@Loggable(value = LogLevel.TRACE)
	public List<FixedDeposit> getAllFixedDeposits() {
		return em.createQuery("Select f from FixedDeposit f").getResultList();
	}

}
