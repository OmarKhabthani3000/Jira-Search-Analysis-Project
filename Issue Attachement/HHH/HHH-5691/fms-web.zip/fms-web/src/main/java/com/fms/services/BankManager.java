package com.fms.services;

import com.fms.dataaccess.BankDAO;

public class BankManager {
	
	BankDAO bankdao;

	public BankDAO getBankdao() {
		return bankdao;
	}

	public void setBankdao(BankDAO bankdao) {
		this.bankdao = bankdao;
	}
	

}
