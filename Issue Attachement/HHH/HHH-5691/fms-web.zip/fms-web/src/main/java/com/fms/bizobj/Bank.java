package com.fms.bizobj;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BANKS")
public class Bank {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="bank_id")
	private int bankId;

	@Column(name = "bank_name")
	private String bankName;

	@Embedded
	private Address bankAddress;

	@Column(name = "bank_phone")
	private String bankPhone;

	@Column(name = "bank_details")
	private String bankDetails;

	@Column(name = "custcare_num")
	private String bankCustcareNumber;

	@Column(name = "website")
	private String bankWebsite;

	@Column(name = "routing_num")
	private String bankRoutingNumber;

	@Column(name = "ifsc_num")
	private String bankIFSCNumber;

	public int getBankId() {
		return bankId;
	}

	public void setBankId(int bankId) {
		this.bankId = bankId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public Address getBankAddress() {
		return bankAddress;
	}

	public void setBankAddress(Address bankAddress) {
		this.bankAddress = bankAddress;
	}

	public String getBankPhone() {
		return bankPhone;
	}

	public void setBankPhone(String bankPhone) {
		this.bankPhone = bankPhone;
	}

	public String getBankDetails() {
		return bankDetails;
	}

	public void setBankDetails(String bankDetails) {
		this.bankDetails = bankDetails;
	}

	public String getBankCustcareNumber() {
		return bankCustcareNumber;
	}

	public void setBankCustcareNumber(String bankCustcareNumber) {
		this.bankCustcareNumber = bankCustcareNumber;
	}

	public String getBankWebsite() {
		return bankWebsite;
	}

	public void setBankWebsite(String bankWebsite) {
		this.bankWebsite = bankWebsite;
	}

	public String getBankRoutingNumber() {
		return bankRoutingNumber;
	}

	public void setBankRoutingNumber(String bankRoutingNumber) {
		this.bankRoutingNumber = bankRoutingNumber;
	}

	public String getBankIFSCNumber() {
		return bankIFSCNumber;
	}

	public void setBankIFSCNumber(String bankIFSCNumber) {
		this.bankIFSCNumber = bankIFSCNumber;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((bankIFSCNumber == null) ? 0 : bankIFSCNumber.hashCode());
		result = prime * result + bankId;
		result = prime * result
				+ ((bankName == null) ? 0 : bankName.hashCode());
		result = prime
				* result
				+ ((bankRoutingNumber == null) ? 0 : bankRoutingNumber
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bank other = (Bank) obj;
		if (bankIFSCNumber == null) {
			if (other.bankIFSCNumber != null)
				return false;
		} else if (!bankIFSCNumber.equals(other.bankIFSCNumber))
			return false;
		if (bankId != other.bankId)
			return false;
		if (bankName == null) {
			if (other.bankName != null)
				return false;
		} else if (!bankName.equals(other.bankName))
			return false;
		if (bankRoutingNumber == null) {
			if (other.bankRoutingNumber != null)
				return false;
		} else if (!bankRoutingNumber.equals(other.bankRoutingNumber))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Bank [bankId=" + bankId + ", bankName=" + bankName
				+ ", bankAddress=" + bankAddress + ", bankPhone=" + bankPhone
				+ ", bankDetails=" + bankDetails + ", bankCustcareNumber="
				+ bankCustcareNumber + ", bankWebsite=" + bankWebsite
				+ ", bankRoutingNumber=" + bankRoutingNumber
				+ ", bankIFSCNumber=" + bankIFSCNumber + "]";
	}

}
