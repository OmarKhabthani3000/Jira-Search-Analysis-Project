package com.fms.bizobj;

import javax.annotation.Generated;
import javax.persistence.Id;
import javax.persistence.Transient;

public class Loan extends BaseObject {

	/**
	 * 
	 */
	@Transient
	private static final long serialVersionUID = 902892400283163768L;
	
	@Id
	@Generated(value = "")
	private int accountNumber;
	private Bank bank;
	private double emi;
	private int duration;
	private int remianingInstallments;

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public double getEmi() {
		return emi;
	}

	public void setEmi(double emi) {
		this.emi = emi;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getRemianingInstallments() {
		return remianingInstallments;
	}

	public void setRemianingInstallments(int remianingInstallments) {
		this.remianingInstallments = remianingInstallments;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountNumber;
		result = prime * result + ((bank == null) ? 0 : bank.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Loan other = (Loan) obj;
		if (accountNumber != other.accountNumber)
			return false;
		if (bank == null) {
			if (other.bank != null)
				return false;
		} else if (!bank.equals(other.bank))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Loan [accountNumber=" + accountNumber + ", bank=" + bank
				+ ", emi=" + emi + ", duration=" + duration
				+ ", remianingInstallments=" + remianingInstallments + "]";
	}

}
