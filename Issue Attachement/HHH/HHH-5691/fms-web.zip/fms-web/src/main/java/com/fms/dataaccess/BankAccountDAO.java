package com.fms.dataaccess;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fms.bizobj.BankAccount;

@Repository
@Transactional
public class BankAccountDAO {
	
	private EntityManager em;

	public EntityManager getEm() {
		return em;
	}

	@PersistenceContext
	public void setEm(EntityManager em) {
		this.em = em;
	}
	
	/**
	 * @param bankAccountObj - Bank account object to be inserted.
	 */
	public void addBankAccount(BankAccount bankAccountObj) {
		em.persist(bankAccountObj);
	}
	
	/**
	 * @param bankId - bank id to be used for fetching bank accounts
	 * @return List of bank accounts
	 */
	@SuppressWarnings("unchecked")
	public List<BankAccount> getBankAccountsForBank(int bankId)
	{
		Query query = em.createQuery("From BankAccount b where b.bank.bankId=?");
		query.setParameter(1, bankId);
		return query.getResultList();
	}

}
