package com.fms.bizobj;

import java.io.Serializable;
import java.util.Date;


public class MutualFund extends BaseObject implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7072711537125657404L;

	private int id;
	private String folioNumber;
	private String amcName;
	private Date startDate;
	private Date endDate;
	// lumpsum or SIP
	private String fundType;
	private double amount;
	private String firstHolder;
	private String secondHolder;
	private String thirdHolder;
	private String nominee;
	private Address address;
	private String details;
	private String amcURL;
	private String onlineLogin;
	private String onlinePassword;
	private boolean kycCompliant;
	private String bankName;
	private String sipDate;
	private Date sipFrom;
	private Date sipTill;
	private int bankId;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the folioNumber
	 */
	public String getFolioNumber() {
		return folioNumber;
	}

	/**
	 * @param folioNumber
	 *            the folioNumber to set
	 */
	public void setFolioNumber(String folioNumber) {
		this.folioNumber = folioNumber;
	}

	/**
	 * @return the amcName
	 */
	public String getAmcName() {
		return amcName;
	}

	/**
	 * @param amcName
	 *            the amcName to set
	 */
	public void setAmcName(String amcName) {
		this.amcName = amcName;
	}

	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate
	 *            the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate
	 *            the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the fundType
	 */
	public String getFundType() {
		return fundType;
	}

	/**
	 * @param fundType
	 *            the fundType to set
	 */
	public void setFundType(String fundType) {
		this.fundType = fundType;
	}

	/**
	 * @return the amount
	 */
	public double getAmount() {
		return amount;
	}

	/**
	 * @param amount
	 *            the amount to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}

	/**
	 * @return the firstHolder
	 */
	public String getFirstHolder() {
		return firstHolder;
	}

	/**
	 * @param firstHolder
	 *            the firstHolder to set
	 */
	public void setFirstHolder(String firstHolder) {
		this.firstHolder = firstHolder;
	}

	/**
	 * @return the secondHolder
	 */
	public String getSecondHolder() {
		return secondHolder;
	}

	/**
	 * @param secondHolder
	 *            the secondHolder to set
	 */
	public void setSecondHolder(String secondHolder) {
		this.secondHolder = secondHolder;
	}

	/**
	 * @return the thirdHolder
	 */
	public String getThirdHolder() {
		return thirdHolder;
	}

	/**
	 * @param thirdHolder
	 *            the thirdHolder to set
	 */
	public void setThirdHolder(String thirdHolder) {
		this.thirdHolder = thirdHolder;
	}

	/**
	 * @return the nominee
	 */
	public String getNominee() {
		return nominee;
	}

	/**
	 * @param nominee
	 *            the nominee to set
	 */
	public void setNominee(String nominee) {
		this.nominee = nominee;
	}

	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * @param address
	 *            the address to set
	 */
	public void setAddress(Address address) {
		this.address = address;
	}

	/**
	 * @return the details
	 */
	public String getDetails() {
		return details;
	}

	/**
	 * @param details
	 *            the details to set
	 */
	public void setDetails(String details) {
		this.details = details;
	}

	/**
	 * @return the amcURL
	 */
	public String getAmcURL() {
		return amcURL;
	}

	/**
	 * @param amcURL
	 *            the amcURL to set
	 */
	public void setAmcURL(String amcURL) {
		this.amcURL = amcURL;
	}

	/**
	 * @return the onlineLogin
	 */
	public String getOnlineLogin() {
		return onlineLogin;
	}

	/**
	 * @param onlineLogin
	 *            the onlineLogin to set
	 */
	public void setOnlineLogin(String onlineLogin) {
		this.onlineLogin = onlineLogin;
	}

	/**
	 * @return the onlinePassword
	 */
	public String getOnlinePassword() {
		return onlinePassword;
	}

	/**
	 * @param onlinePassword
	 *            the onlinePassword to set
	 */
	public void setOnlinePassword(String onlinePassword) {
		this.onlinePassword = onlinePassword;
	}

	/**
	 * @return the kycCompliant
	 */
	public boolean isKycCompliant() {
		return kycCompliant;
	}

	/**
	 * @param kycCompliant
	 *            the kycCompliant to set
	 */
	public void setKycCompliant(boolean kycCompliant) {
		this.kycCompliant = kycCompliant;
	}

	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * @param bankName
	 *            the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * @return the sipDate
	 */
	public String getSipDate() {
		return sipDate;
	}

	/**
	 * @param sipDate
	 *            the sipDate to set
	 */
	public void setSipDate(String sipDate) {
		this.sipDate = sipDate;
	}

	/**
	 * @return the sipFrom
	 */
	public Date getSipFrom() {
		return sipFrom;
	}

	/**
	 * @param sipFrom
	 *            the sipFrom to set
	 */
	public void setSipFrom(Date sipFrom) {
		this.sipFrom = sipFrom;
	}

	/**
	 * @return the sipTill
	 */
	public Date getSipTill() {
		return sipTill;
	}

	/**
	 * @param sipTill
	 *            the sipTill to set
	 */
	public void setSipTill(Date sipTill) {
		this.sipTill = sipTill;
	}

	/**
	 * @return the bankId
	 */
	public int getBankId() {
		return bankId;
	}

	/**
	 * @param bankId
	 *            the bankId to set
	 */
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}

}
