package com.fms.dataaccess;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fms.bizobj.Bank;
import com.fms.framework.LogLevel;
import com.fms.framework.annotations.Loggable;

@Repository
@Transactional
public class BankDAO {

	private EntityManager em;

	public EntityManager getEm() {
		return em;
	}

	@PersistenceContext
	public void setEm(EntityManager em) {
		this.em = em;
	}

	/**
	 * This method adds a new bank record in BANKS table.
	 * 
	 * @param bankObj
	 */
	@Loggable(value = LogLevel.TRACE)
	public void addBank(Bank bankObj) {
		em.persist(bankObj);
	}

	/**
	 * @return List of all banks
	 */
	@SuppressWarnings("unchecked")
	@Loggable(value = LogLevel.TRACE)
	public List<Bank> getAllBanks() {
		return em.createQuery("Select b from Bank b order by b.bankName asc")
				.getResultList();
	}

	/**
	 * @param name bank name to be fetched
	 * @return List of Banks
	 */
	@SuppressWarnings("unchecked")
	@Loggable(value = LogLevel.TRACE)
	public List<Bank> getBankByName(String name) {
		Query query = em.createQuery("From Bank b where b.bankName=?");
		query.setParameter(1, name);
		return query.getResultList();

	}

}
