package com.fms.services;

import com.fms.bizobj.Portfolio;

public class PortfolioManager {
	
	/**
	 * 
	 * @param userId
	 * @return
	 */
	public Portfolio getPortfolio(int userId)
	{
		return null;
	}
	
	/**
	 * 
	 * @param portfolio
	 */
	public void setPortfolio(Portfolio portfolio)
	{
		//TODO
	}

}
