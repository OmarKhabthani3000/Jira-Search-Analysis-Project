package com.fms.dataaccess;

import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fms.bizobj.Address;
import com.fms.bizobj.Bank;
import com.fms.framework.LogLevel;
import com.fms.framework.annotations.Loggable;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/applicationContext.xml")
public class BankDAOTest {

	@Autowired
	private BankDAO bankdao;

	@Test
	@Loggable(value = LogLevel.TRACE)
	public void addBank() {

		Bank bank = new Bank();
		bank.setBankName("HDFC Bank");
		Address address = new Address();
		address.setAddLine1("address line 1");
		address.setAddLine2("address line 2");
		address.setCity("Thane");
		address.setState("Maharashtra");
		address.setCountry("India");
		address.setZipcode("400602");
		bank.setBankAddress(address);
		bank.setBankIFSCNumber("1237476789");
		bank.setBankPhone("888-111-8989");
		bank.setBankWebsite("www.hdfcbank.co.in");
		bank.setBankCustcareNumber("800-123-5423");
		bank.setBankDetails("For testing");
		bank.setBankRoutingNumber("18237461873");

		bankdao.addBank(bank);
	}

	@Loggable(value = LogLevel.INFO)
	@Test
	public void getAllBanks() {
		List banks = bankdao.getAllBanks();
		Logger.getLogger(this.getClass().getName()).debug(
				"List of banks : " + banks);

	}

	@Loggable(value = LogLevel.INFO)
	@Test
	public void getBankByName() {
		List banks = bankdao.getBankByName("HDFC Bank");
		Logger.getLogger(this.getClass().getName()).debug(
				"Count = " + banks.size() + " List of banks : " + banks);

	}

}
