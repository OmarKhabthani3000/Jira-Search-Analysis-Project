package com.fms.dataaccess;

import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fms.bizobj.User;
import com.fms.framework.LogLevel;
import com.fms.framework.annotations.Loggable;

/**
 * @author sukaulgud
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/applicationContext.xml")
public class UserDAOTest {

	@Autowired
	private UserDAO userdao;

	/**
	 * 
	 */
//	@Test
//	@Loggable(value = LogLevel.TRACE)
	public void addUser() {

		User user = new User();
		user.setFirstName("Suyash");
		user.setMiddleName("Kamlakar");
		user.setLastName("Kaulgud");
		user.setLogin("admin");
		user.setPassword("admin");
		user.setPhoneNumber("9987647700");

		userdao.addUser(user);
	}

	/**
	 * 
	 */
	@Loggable(value = LogLevel.INFO)
	@Test
	public void getAllUsers() {
		List<User> users = userdao.getAllUsers();
		System.out.println("users.size() = " + users.size());
		Logger.getLogger(this.getClass().getName()).debug(
				"List of users : " + users.size());

	}

	/**
	 * 
	 */
	@Loggable(value = LogLevel.DEBUG)
	@Test
	public void getUserByName() {
		List<User> users = userdao.getUserByName("Suyash", "Kaulgud");
		Logger.getLogger(this.getClass().getName()).debug(
				"Count = " + users.size() + " List of users : " + users);

	}

}
