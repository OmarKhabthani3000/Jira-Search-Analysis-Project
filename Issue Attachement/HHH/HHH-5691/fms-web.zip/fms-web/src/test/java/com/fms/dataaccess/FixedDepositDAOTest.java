package com.fms.dataaccess;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fms.bizobj.Bank;
import com.fms.bizobj.FixedDeposit;
import com.fms.bizobj.User;
import com.fms.framework.LogLevel;
import com.fms.framework.annotations.Loggable;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/applicationContext.xml")
public class FixedDepositDAOTest {

	@Autowired
	FixedDepositDAO fixedDepositDAO;

	@Autowired
	BankDAO bankdao;

	@Autowired
	UserDAO userdao;

	@Test
	@Loggable(value = LogLevel.TRACE)
	public void addFixedDeposit() {
		Bank bank = bankdao.getBankByName("Bank of maharashtra").get(0);
		User u1 = userdao.getUserByName("Charanya", "Kaulgud").get(0);
		User u2 = userdao.getUserByName("Suyash", "Kaulgud").get(0);
		List<User> users = new ArrayList<User>();
		users.add(u1);
		users.add(u2);
		
		FixedDeposit fd = new FixedDeposit();
		fd.setAmount("2000000");
		fd.setBank(bank);
		fd.setDetails("Car Loan");
		fd.setInterest("9.75");
		fd.setLoan_acct_num("1236545908");
		fd.setStartDate(new Date());
		fd.setTenure("26 months");
		fd.setUser(users);
		
		fixedDepositDAO.addFixedDeposit(fd);
	}

}
