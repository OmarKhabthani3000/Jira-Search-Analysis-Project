package com.fms.dataaccess;

import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fms.bizobj.Card;
import com.fms.bizobj.User;
import com.fms.framework.LogLevel;
import com.fms.framework.annotations.Loggable;

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration("/applicationContext.xml")
public class CardDAOTest {

	//@Autowired
	private CardsDAO cardDao;
	//@Autowired
	private UserDAO userdao;

	//@Test
	@Loggable(value = LogLevel.TRACE)
	public void addCard() {
		User u1 = userdao.getUserByName("Charanya", "Kaulgud").get(0);

		Card card = new Card();
		card.setCardName("Charanya Suyash Kaulgud");
		card.setCardNumber("1234-5678-0055");
		card.setCardType("Credit Card");
		card.setVendor("ICICI Bank");
		card.setVaildTill("11-2013");
		card.setUser(u1);
		cardDao.addCard(card);
	}

//	@Test
	@Loggable(value = LogLevel.TRACE)
	public void getAllCards() {
		List<Card> cards = cardDao.getAllCards();
		Logger.getLogger(getClass()).debug("List of cards = " + cards);
	}

//	@Test
	@Loggable(value = LogLevel.TRACE)
	public void getCardsByUser() {
		List<Card> cards = cardDao.getCardsByUser("Charanya", "Kaulgud");
		Logger.getLogger(getClass()).debug("List of cards = " + cards);
	}

}
