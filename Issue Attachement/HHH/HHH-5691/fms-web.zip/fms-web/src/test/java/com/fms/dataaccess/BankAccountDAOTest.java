package com.fms.dataaccess;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fms.bizobj.Bank;
import com.fms.bizobj.BankAccount;
import com.fms.bizobj.User;
import com.fms.framework.LogLevel;
import com.fms.framework.annotations.Loggable;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/applicationContext.xml")
public class BankAccountDAOTest {

	@Autowired
	BankAccountDAO bankAccountDAO;

	@Autowired
	BankDAO bankdao;

	@Autowired
	UserDAO userdao;

	@Test
	@Loggable(value = LogLevel.TRACE)
	public void addBankAccount() {

		Bank bank = bankdao.getBankByName("HDFC Bank").get(0);
		User u1 = userdao.getUserByName("Suyash", "Kaulgud").get(0);
		
		User u2 = userdao.getUserByName("Charanya", "Kaulgud").get(0);
		List<User> users = new ArrayList<User>();
		
		Logger.getLogger(this.getClass().getName()).debug(
				"Users to be added to HDFC account : " + users);
		
		
		
		BankAccount ba = new BankAccount();

		users.add(u1);
		users.add(u2);
		ba.setUser(users);
		Set<BankAccount> s1 = new HashSet<BankAccount>();
		Set<BankAccount> s2 = new HashSet<BankAccount>();
		s1.add(ba);
		s2.add(ba);
		u1.setBankAccount(s1);
		u2.setBankAccount(s2);
		ba.setAccountType("Current");
		ba.setBank(bank);
		ba.setBranch("Teen Hath Naka");
		ba.setAccountNumber("1234567890");
		ba.setOpMode("Joint");
		bankAccountDAO.addBankAccount(ba);
	}

}
