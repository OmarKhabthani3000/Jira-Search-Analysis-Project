package com.fms.dataaccess;

import junit.framework.TestCase;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.fms.bizobj.Address;
import com.fms.bizobj.Bank;

public class oldBankDAOTest extends TestCase {

	public void testAddBank() {
		// create and configure beans
		ApplicationContext context = new ClassPathXmlApplicationContext(
				new String[] { "applicationContext.xml" });

		BankDAO bankdao = (BankDAO) context.getBean("bankdao", BankDAO.class);

		Bank bank = new Bank();
		bank.setBankName("Citibank");
		Address address = new Address();
		address.setAddLine1("address line 1");
		address.setAddLine2("address line 2");
		address.setCity("Thane");
		address.setState("Maharashtra");
		address.setCountry("India");
		address.setZipcode("400602");
		bank.setBankAddress(address);
		bank.setBankIFSCNumber("411232334");
		bank.setBankPhone("888-456-1110");
		bank.setBankWebsite("www.citibank.co.in");
		bank.setBankCustcareNumber("888-777-5100");
		bank.setBankDetails("For testing");
		bank.setBankRoutingNumber("74002324000");

		bankdao.addBank(bank);
	}

}
