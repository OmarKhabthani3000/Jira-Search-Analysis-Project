package org.hibernate.antoniak;

import org.hibernate.envers.Audited;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

/**
 * @author Lukasz Antoniak (lukasz dot antoniak at gmail dot com)
 */
@Entity
@Audited
public class Orange implements Serializable {
    @Id
    @GeneratedValue
    private long id;

    @ManyToMany(cascade = {CascadeType.PERSIST})
    private Set<Apple> apples = new HashSet<Apple>();

    public Orange() {
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Orange)) return false;

        Orange orange = (Orange) o;

        if (id != orange.id) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return (int) (id ^ (id >>> 32));
    }

    @Override
    public String toString() {
        return "Orange(id = " + id + ")";
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Set<Apple> getApples() {
        return apples;
    }

    public void setApples(Set<Apple> apples) {
        this.apples = apples;
    }
}
