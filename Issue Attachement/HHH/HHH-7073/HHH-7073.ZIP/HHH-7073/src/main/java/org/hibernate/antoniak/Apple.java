package org.hibernate.antoniak;

import org.hibernate.envers.Audited;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

/**
 * @author Lukasz Antoniak (lukasz dot antoniak at gmail dot com)
 */
@Entity
@Audited
public class Apple implements Serializable {
    @Id
    @GeneratedValue
    private long id;

    @ManyToMany(cascade = {CascadeType.PERSIST})
    @JoinTable(name = "ApplesAndOranges",
               joinColumns = {@JoinColumn(name = "appleId", nullable = false)},
               inverseJoinColumns = {@JoinColumn(name = "orangeId", nullable = false)})
    private Set<Orange> oranges = new HashSet<Orange>();

    public Apple() {
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Apple)) return false;

        Apple apple = (Apple) o;

        if (id != apple.id) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return (int) (id ^ (id >>> 32));
    }

    @Override
    public String toString() {
        return "Apple(id = " + id + ")";
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Set<Orange> getOranges() {
        return oranges;
    }

    public void setOranges(Set<Orange> oranges) {
        this.oranges = oranges;
    }
}
