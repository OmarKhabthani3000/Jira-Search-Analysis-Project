import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import testcase.BaseEntity;
import testcase.SubclassOne;
import testcase.SubclassZero;
import testcase.SubclassTwo;
import testcase.UnrelatedEntity;

public class InsertOrderTest {

    private SessionFactory sessionFactory;

    private Session getSession() throws HibernateException {
        return sessionFactory.openSession();
    }

    @Before
    public void init() {
        Configuration configuration = new Configuration();

        configuration.setProperty(AvailableSettings.ORDER_INSERTS, "true");
        configuration.setProperty(AvailableSettings.USE_SECOND_LEVEL_CACHE, "false");

        configuration.setProperty(AvailableSettings.DIALECT, "org.hibernate.dialect.H2Dialect");
        configuration.setProperty(AvailableSettings.DRIVER, "org.h2.Driver");
        configuration.setProperty(AvailableSettings.URL, "jdbc:h2:mem:db1");
        configuration.setProperty(AvailableSettings.USER, "sa");
        configuration.setProperty(AvailableSettings.ORDER_INSERTS, "true");
        configuration.setProperty(AvailableSettings.HBM2DDL_AUTO, "create");
        configuration.setProperty(AvailableSettings.SHOW_SQL, "true");

        configuration.addAnnotatedClass(BaseEntity.class);
        configuration.addAnnotatedClass(SubclassZero.class);
        configuration.addAnnotatedClass(SubclassOne.class);
        configuration.addAnnotatedClass(SubclassTwo.class);
        configuration.addAnnotatedClass(UnrelatedEntity.class);

        sessionFactory = configuration.buildSessionFactory();
    }

    @After
    public void destroy() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }

    @Test
    public void testTwoSubclasses(){
        final Session session = getSession();

        try {
            Transaction transaction = session.beginTransaction();

            UnrelatedEntity unrelatedEntity1 = new UnrelatedEntity();
            session.save(unrelatedEntity1);

            SubclassZero subclassRoot = new SubclassZero();
            session.save(subclassRoot);

            SubclassOne subclassOne1 = new SubclassOne();
            subclassOne1.setParent(subclassRoot);
            SubclassTwo subclassTwo1 = new SubclassTwo();
            subclassTwo1.setParent(subclassOne1);

            session.save(subclassTwo1);
            session.save(subclassOne1);

            UnrelatedEntity unrelatedEntity2 = new UnrelatedEntity();
            session.save(unrelatedEntity2);

            SubclassOne subclassOne2 = new SubclassOne();
            SubclassTwo subclassD2 = new SubclassTwo();
            session.save(subclassOne2);
            session.save(subclassD2);

            transaction.commit();

       } finally {
            session.close();
        }
    }
}
