package testcase;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class UnrelatedEntity {
    @Id
    @GeneratedValue
    private Long id;

    private String unrelatedValue;

    public void setUnrelatedValue(String unrelatedValue) {
        this.unrelatedValue = unrelatedValue;
    }
}
