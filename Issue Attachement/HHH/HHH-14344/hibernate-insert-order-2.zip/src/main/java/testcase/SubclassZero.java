package testcase;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("ZERO")
public class SubclassZero extends BaseEntity{

}
