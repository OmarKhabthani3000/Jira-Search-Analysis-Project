package envers.test;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HibernateUtil {
	
	private static final SessionFactory sessionFactory;

	static {
		try {
			AnnotationConfiguration config = new AnnotationConfiguration();
			config.setProperty("hibernate.dialect",
					"org.hibernate.dialect.Oracle10gDialect");
			config.setProperty("hibernate.connection.driver_class",
					"oracle.jdbc.driver.OracleDriver");
			config.setProperty("hibernate.connection.url",
					"jdbc:oracle:thin:@win2k3-test.faw.at:1521:orcl");
			config.setProperty("hibernate.connection.username", "aplang_test");
			config.setProperty("hibernate.connection.password", "*admin!");

			config.setProperty("hibernate.hbm2ddl.auto", "create-drop");
			// config.setProperty("hibernate.hbm2ddl.auto", "update");
			config.setProperty("hibernate.show_sql", "true");
			config.setProperty("hibernate.transaction.factory_class",
					"org.hibernate.transaction.JDBCTransactionFactory");
			config.setProperty("hibernate.current_session_context_class",
					"thread");

			// IDENTIFIER ROLLBACK
			config.setProperty("hibernate.use_identifier_rollback", "true");

			config.setListener("post-insert",
					"org.hibernate.envers.event.AuditEventListener");
			config.setListener("post-update",
					"org.hibernate.envers.event.AuditEventListener");
			config.setListener("post-delete",
					"org.hibernate.envers.event.AuditEventListener");
			config.setListener("pre-collection-update",
					"org.hibernate.envers.event.AuditEventListener");
			config.setListener("pre-collection-remove",
					"org.hibernate.envers.event.AuditEventListener");
			config.setListener("post-collection-recreate",
					"org.hibernate.envers.event.AuditEventListener");

			config.addAnnotatedClass(SourceEntity.class);
			config.addAnnotatedClass(TargetEntity.class);

			sessionFactory = config.buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}
