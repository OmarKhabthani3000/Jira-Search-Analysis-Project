package envers.test;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Main {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {

		boolean deleteOrphan = false;

		// create
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction transaction = session.beginTransaction();
		SourceEntity source = new SourceEntity();
		source.getUnidirectionalTargetEntities().add(new TargetEntity());
		session.saveOrUpdate(source);
		transaction.commit();

		if (!deleteOrphan) {

			// delete
			session = HibernateUtil.getSessionFactory().getCurrentSession();
			transaction = session.beginTransaction();
			List<SourceEntity> sourceEntities = session.createQuery(
					"from SourceEntity").list();
			for (SourceEntity sourceEntity : sourceEntities) {
				session.delete(sourceEntity);
			}
			transaction.commit();

		} else {

			// delete orphan
			session = HibernateUtil.getSessionFactory().getCurrentSession();
			transaction = session.beginTransaction();
			List<SourceEntity> sourceEntities = session.createQuery(
					"from SourceEntity").list();
			for (SourceEntity sourceEntity : sourceEntities) {
				sourceEntity.getUnidirectionalTargetEntities().clear();
				session.saveOrUpdate(sourceEntity);
			}
			transaction.commit();
		}
	}
}
