package envers.test;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "TEST_TARGET_ENTITY")
@Audited
public class TargetEntity extends GenericEntity<Long> {

	private static final long serialVersionUID = 1L;

}
