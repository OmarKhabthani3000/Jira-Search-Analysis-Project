package envers.test;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;

@Entity
@Table(name = "TEST_SOURCE_ENTITY")
@Audited
public class SourceEntity extends GenericEntity<Long> {

	private static final long serialVersionUID = 1L;

	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "SOURCE_ENTITY_UNI_ID")
	@Cascade(value = { CascadeType.ALL, CascadeType.DELETE_ORPHAN })
	@org.hibernate.annotations.IndexColumn(name = "SOURCE_ENTITY_UNI_IDX")
	@AuditJoinTable(name = "TEST_SOURCE_TARGET_ENTITY_AUD", inverseJoinColumns = @JoinColumn(name = "TARGET_ENTITY_UNI_ID", referencedColumnName = "ID", nullable = true))
	private List<TargetEntity> unidirectionalTargetEntities = new ArrayList<TargetEntity>();

	public List<TargetEntity> getUnidirectionalTargetEntities() {
		return unidirectionalTargetEntities;
	}

	public void setUnidirectionalTargetEntities(
			List<TargetEntity> unidirectionalTargetEntities) {
		this.unidirectionalTargetEntities = unidirectionalTargetEntities;
	}

}
