package envers.test;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.hibernate.Hibernate;

/**
 * Generic entity.
 * 
 * @author djabornig
 * 
 * @param <T>
 */
@MappedSuperclass
public abstract class GenericEntity<T> extends AbstractPropertyChangePublisher
		implements Serializable, Comparable<GenericEntity<T>> {

	/** Properties */
	public static final String ID = "id";

	public static final String VERSION = "version";

	public static final String DOT_EXT = ".";

	public static final String ARRAY_EXT = "Array";

	/** Load all property */
	protected static final String LOAD_ALL = "loadAll";

	/** Generated serial version */
	private static final long serialVersionUID = 5929114243398085451L;

	/** Id */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	protected T id;

	/** Version */
	@Version
	@Column(name = "VERSION")
	protected Long version;

	// /** External Id */
	// @Column(name = "EXTERNAL_ID")
	// protected final String externalId = UUID.randomUUID().toString();

	/** Loaded */
	@Transient
	private Set<String> loaded = new HashSet<String>();

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	public T getId() {
		return id;
	}

	public void setId(T id) {
		T oldValue = this.id;
		this.id = id;
		firePropertyChange(ID, oldValue, id);
	}

	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		Long oldValue = this.version;
		this.version = version;
		firePropertyChange(VERSION, oldValue, version);
	}

	/**
	 * Return true if the other object is a newer version of this object.
	 * 
	 * @param other
	 * @return
	 */
	public final boolean isNewerThan(Object other) {
		if (this == other || other == null || getClass() != other.getClass()) {
			return false;
		}

		final GenericEntity<?> that = (GenericEntity<?>) other;
		if (this.id != null && this.id.equals(that.id)) {
			if (this.version != null) {
				return this.version.compareTo(that.getVersion()) == 1;
			}
		}
		return false;
	}

	/**
	 * Return true if the other object is an older version of this object.
	 * 
	 * @param other
	 * @return
	 */
	public final boolean isOlderThan(Object other) {
		if (this == other || other == null || getClass() != other.getClass()) {
			return false;
		}

		final GenericEntity<?> that = (GenericEntity<?>) other;
		if (this.id != null && this.id.equals(that.id)) {
			if (this.version != null) {
				return this.version.compareTo(that.getVersion()) == -1;
			}
		}
		return false;
	}

	/**
	 * Return true if the given object is equal by id.
	 * 
	 * @param o
	 * @return
	 */
	public final boolean isEqualById(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		final GenericEntity<?> that = (GenericEntity<?>) o;
		if (this.getId() != null) {
			return this.getId().equals(that.getId());
		}
		return false;
	}

	public int compareTo(GenericEntity<Long> o) {
		return 0;
	}

	@Override
	public String toString() {
		T id = getId();
		if (id != null) {
			return String.valueOf(id);
		}
		return super.toString();
	}

	private boolean isLoaded(String property) {
		if (loaded.contains(property)) {
			return true;
		}
		if (property != null && !property.equals(LOAD_ALL)) {
			return Hibernate.isPropertyInitialized(this, property);
		}
		return false;
	}

	private void setLoaded(String property) {
		this.loaded.add(property);
		this.firePropertyChange("loaded", property, property);
	}

	/**
	 * Call this method before every getter and setter where lazy loading
	 * exceptions must be avoided.
	 * 
	 * @param property
	 *            the property that has to be loaded
	 */
	protected void ensureLoaded(String property) {
		if (this.id == null || isLoaded(property)) {
			// nothing to do
		} else {
			load(property);
			setLoaded(property);
		}
	}

	/**
	 * Load the entity completely.
	 * 
	 * @param property
	 *            property to load or LOAD_ALL if everything should be loaded
	 */
	protected void load(String property) {
		// to implement if necessary
	}

	/**
	 * True if this entity is persistent but maybe in a detached state.
	 * 
	 * @return
	 */
	public boolean isPersistent() {
		return getId() != null;
	}

	/**
	 * Set this entity not persistent.
	 */
	public void setNotPersistent() {
		setId(null);
		setVersion(null);
	}

	/**
	 * Creates a copy of this object. Creates a new object and copies all
	 * attributes and references. Custom clone operation.
	 * 
	 * @param <K>
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public GenericEntity<T> createCopy() {
		try {
			return getClass().newInstance();
		} catch (InstantiationException e) {
			// don nothing
		} catch (IllegalAccessException e) {
			// do nothing
		}
		return null;
	}

}
