package com.example.demo.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table
@Entity(name = "LocalTermTitle")
@Getter
@Setter
@NoArgsConstructor
public class LocalTerm extends Term {

    @ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "IdLanguage", nullable = false)
    private Language language;

}
