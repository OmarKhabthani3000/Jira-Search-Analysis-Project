package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Language;
import com.example.demo.repo.LanguageRepo;
import com.example.demo.repo.LinkageRepo;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@SpringBootApplication
public class DemoApplication implements CommandLineRunner {

    private final LanguageRepo languageRepo;
    private final LinkageRepo linkageRepo;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

    @Override
    public void run(String... args) throws Exception {
        var english = new Language();
        english.setName("English");
        english = languageRepo.save(english);

        linkageRepo.findAll(LinkageRepo.Specifications.byTermLanguage(english));
    }

}
