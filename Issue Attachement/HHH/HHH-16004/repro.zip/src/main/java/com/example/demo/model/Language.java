package com.example.demo.model;

import java.util.Collection;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table
@Entity(name = "Language")
@Getter
@Setter
@NoArgsConstructor
public class Language extends BaseEntity {

    @Column(nullable = false)
    private String name;

    @OneToMany(mappedBy = "language")
	private Collection<LocalTerm> localTerms;

}
