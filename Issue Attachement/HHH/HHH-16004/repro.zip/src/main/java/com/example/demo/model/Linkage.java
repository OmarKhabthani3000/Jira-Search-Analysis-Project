package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Table
@Entity(name = "PublicationLinkageToTerm")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Linkage extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "IdTermTitleBase", nullable = false)
    private Term term;

}
