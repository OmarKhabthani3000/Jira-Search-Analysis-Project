package com.example.demo.repo;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.example.demo.model.Language;
import com.example.demo.model.Linkage;
import com.example.demo.model.LocalTerm;

public interface LinkageRepo extends JpaRepository<Linkage, Long>, JpaSpecificationExecutor<Linkage> {

    public static class Specifications {

        private Specifications() {}

        public static Specification<Linkage> byTermLanguage(final Language language) {
            return (root, query, cb) -> {
                final var asLocalTerm = cb.treat(root.get("term"), LocalTerm.class);
                return cb.equal(asLocalTerm.get("language"), language);
            };
        }

    }

}
