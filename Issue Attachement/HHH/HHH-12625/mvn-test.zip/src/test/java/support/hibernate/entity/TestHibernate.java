package support.hibernate.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import support.hibernate.util.AutoCloser;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import org.junit.Test;
import org.junit.BeforeClass;
import org.junit.AfterClass;

public class TestHibernate {
	private static Logger log = LogManager.getLogger(TestHibernate.class.getCanonicalName());

	private static EntityManager entityManager;

	private static final AutoCloser m_closer = new AutoCloser();

	@BeforeClass
	public static void setUp() throws Exception {
		log.info("Configuring Hibernate " + org.hibernate.Version.getVersionString());
		try {
			// Configures settings from annotations + persistence.xml
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("TEST");
			m_closer.push(emf);
			entityManager = emf.createEntityManager();
			m_closer.push(entityManager);
		} catch (Throwable t) {
			log.warn("Setup failure", t);
		}
	}

	@AfterClass
	public static void tearDown() throws Exception {
		if (entityManager != null) {
			try {
				m_closer.close();
			} finally {
				entityManager = null;
				m_closer.clear();
			}
		}
	}

	@Test
	public void test() {
		log.info("---> test started.");
		EntityTransaction transaction = entityManager.getTransaction();
		try {
			transaction.begin();
			{
				Employee e = new Employee("John Smith", "Engineer");
				e.setTask(new Task("Work Task"));
				log.info("------> Persisting entity('" + e.getName() + "', '" + e.getTitle() + "')");
				entityManager.persist(e);
			}
			transaction.commit();

			transaction.begin();
			{
				for (Employee e : entityManager.createNamedQuery("Employee.selectByTaskName", Employee.class).setParameter(
						"tname","Work Task"
					).getResultList()) {
					log.info("------> Found entity('" + e.getName() + "', '" + e.getTitle() + "')");
				}

				entityManager.createNamedQuery("Employee.deleteByTaskName").setParameter(
					"tname","Work Task"
				).executeUpdate();
			}
			transaction.commit();
		} catch (javax.persistence.PersistenceException e) {
			// Try to unpack the error
			Throwable cause = e;
			while (cause.getCause() != null) {
				cause = cause.getCause();
			}
			log.error("Query failure", cause);
		} finally {
			if (transaction.isActive()) {
				try {
					transaction.rollback();
				} catch (Throwable t) {
					log.warn("Rollback failure", t);
				}
			}
			log.info("---> test completed.");
		}
	}
}
