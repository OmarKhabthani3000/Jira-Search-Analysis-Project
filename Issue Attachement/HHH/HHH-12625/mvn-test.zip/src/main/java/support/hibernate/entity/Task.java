package support.hibernate.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.ForeignKey;

@Entity
public class Task {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ID_GENERATOR")
	@SequenceGenerator(name = "ID_GENERATOR", sequenceName = "TASK_SEQ", initialValue= 1, allocationSize = 1)
	private long id;

	private String name;

	@OneToOne(optional = true)
	@ForeignKey(name = "none")
	private Employee employee; // Mapped using an implicit foreign key property employee_name

	public Task(String name) {
		this();
		setName(name);
	}

	public long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public Employee getEmployee() {
		return employee;
	}

	protected Task() {
		// this form used by Hibernate
	}

	protected void setId(long id) {
		this.id = id;
	}

	protected void setName(String name) {
		this.name = name;
	}

	protected void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public int hashCode() {
		if (name != null) {
			return name.hashCode();
		} else {
			return 0;
		}
	}

	public boolean equals(Object o) {
		if (this == o) {
			return true;
		} else if (o instanceof Task) {
			Task other = Task.class.cast(o);
			if (name != null) {
				return getName().equals(other.getName()) /* && getId() == other.getId() */;
			} else {
				return other.getName() == null;
			}
		} else {
			return false;
		}
	}
}
