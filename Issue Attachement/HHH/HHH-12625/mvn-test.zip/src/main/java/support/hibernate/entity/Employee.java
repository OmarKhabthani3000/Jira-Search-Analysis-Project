package support.hibernate.entity;

import javax.persistence.CascadeType;
import javax.persistence.ConstraintMode;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Version;

@Entity
@NamedQueries({
	// This fails
	@NamedQuery(name = "Employee.deleteByTaskName", query = "DELETE FROM Employee e WHERE e.task.name=:tname"),
	// This works
	//@NamedQuery(name = "Employee.deleteByTaskName", query = "DELETE FROM Employee e WHERE e.id in ( select e.name from Task t inner join t.employee as e where t.name=:tname )"),
	// This works
	@NamedQuery(name = "Employee.selectByTaskName", query = "SELECT e FROM Employee e WHERE e.task.name=:tname")
})
public class Employee {
	@Id
	private String name;

	@Version
	private long oca;

	private String title;

	@OneToOne(mappedBy = "employee", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
	private Task task;

	public Employee(String name, String title) {
		this();
		setName(name);
		setTitle(title);
	}

	public String getName() {
		return name;
	}

	public long getOca() {
		return oca;
	}

	public String getTitle() {
		return title;
	}

	public Task getTask() {
		return task;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setTask(Task task) {
		this.task = task;
		this.task.setEmployee(this);
	}

	protected Employee() {
		// this form used by Hibernate
	}

	protected void setName(String name) {
		this.name = name;
	}

	protected void setOca(long oca) {
		this.oca = oca;
	}
}
