package eu.pinske.model;

import javax.persistence.Entity;

@Entity
public class SomeEntity extends AnotherMappedSuperclass {

    private String entityValue;

    public String getEntityValue() {
        return entityValue;
    }

    public void setEntityValue(String entityValue) {
        this.entityValue = entityValue;
    }

}
