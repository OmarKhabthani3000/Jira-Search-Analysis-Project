package eu.pinske.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.Assert;
import org.junit.Test;

import eu.pinske.model.SomeEntity;

public class TrackingTest {

    @Test
    public void test() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        SomeEntity e = new SomeEntity();
        e.setEntityValue("a");
        e.setParentValue("b");
        em.persist(e);
        em.getTransaction().commit();
        em.clear();
        em.close();

        em = emf.createEntityManager();
        em.getTransaction().begin();
        e = em.find(SomeEntity.class, e.getId());
        e.setEntityValue("x");
        em.flush();
        em.getTransaction().commit();
        em.clear();
        em.close();

        em = emf.createEntityManager();
        em.getTransaction().begin();
        e = em.find(SomeEntity.class, e.getId());
        Assert.assertEquals("entity change not persisted", "x", e.getEntityValue());
        e.setParentValue("y");
        em.flush();
        em.getTransaction().commit();
        em.clear();
        em.close();

        em = emf.createEntityManager();
        em.getTransaction().begin();
        e = em.find(SomeEntity.class, e.getId());
        Assert.assertEquals("superclass change not persisted", "y", e.getParentValue());
        em.flush();
        em.getTransaction().commit();
        em.clear();
        em.close();

        emf.close();
    }

}
