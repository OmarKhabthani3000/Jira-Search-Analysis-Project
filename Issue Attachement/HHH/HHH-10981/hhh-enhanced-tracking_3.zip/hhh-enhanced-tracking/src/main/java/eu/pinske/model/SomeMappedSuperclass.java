package eu.pinske.model;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class SomeMappedSuperclass extends AnotherMappedSuperclass {

    private String parentValue;

    public String getParentValue() {
        return parentValue;
    }

    public void setParentValue(String parentValue) {
        this.parentValue = parentValue;
    }

}
