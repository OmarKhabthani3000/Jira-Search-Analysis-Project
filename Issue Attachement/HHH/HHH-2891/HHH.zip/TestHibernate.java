package test;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.jndi.JndiTemplate;
import test.hibernate.Group;

import java.net.URL;
import java.util.List;
import java.util.Properties;


public class TestHibernate {
    public static void main(String[] args) throws Exception {
        JndiTemplate jndiTemplate = new JndiTemplate();
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL();
        dataSource.setUser();
        dataSource.setPassword();
        jndiTemplate.bind("java:comp/env/jdbc/test", dataSource);

        Configuration configuration = new Configuration();
        configuration.configure(new URL("file:///c:/testproject/src/test/hibernate/hibernate.cfg.xml"));

        Properties properties = new Properties();
        properties.put("hibernate.cache.provider_class", "org.hibernate.cache.EhCacheProvider");
        properties.put("hibernate.cache.use_query_cache", "true");
        properties.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
        configuration.addProperties(properties);

        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = null;

        try {
            session = sessionFactory.openSession();
            Query query = session.getNamedQuery("Group.select.by.login");
            List<Group> groups;

            groups = query.setParameter(0, "tadamm").list();
            System.out.println("-----------------------------------------------------------------------------------");
            for (Group group : groups) {
                System.out.println(group.getName());
            }
            System.out.println("-----------------------------------------------------------------------------------");

            groups = query.setParameter(0, "tadamm").list();
            System.out.println("-----------------------------------------------------------------------------------");
            for (Group group : groups) {
                System.out.println(group.getName());
            }
            System.out.println("-----------------------------------------------------------------------------------");
        } finally {
            if (session != null) {
                session.close();
            }
            sessionFactory.close();
        }
    }
}
