/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jpa.model;

import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import static org.junit.Assert.*;

/**
 *
 * @author harrodr
 */
public class LoginUnitTest extends TestCase {

    private EntityTransaction _tx;
    private EntityManager _em;
    private EntityManagerFactory _emf;

    public LoginUnitTest() {
    }

    @Before
    public void setUp() {
      // Start EntityManagerFactory
      _emf = Persistence.createEntityManagerFactory( "model" );

      // First unit of work
      _em = _emf.createEntityManager();
    }

    public void testAddAndQuery(){
      String nowMillis = String.valueOf( new Date().getTime() );
      LoginUser user = new LoginUser();
      user.setUserName(
        "User ".concat( nowMillis )
      );

      LoginUnit unit = new LoginUnit();
      unit.setUnitName(
        "Unit ".concat( nowMillis )
      );

      LoginUnitUser unitUserRelation = new LoginUnitUser();
      unitUserRelation.setLoginUnitId( unit );
      unitUserRelation.setLoginUserId( user );
      _tx = _em.getTransaction();
      _tx.begin();
      _em.persist( user );
      _em.persist( unit );
      _em.persist( unitUserRelation );
      _tx.commit();

      List<LoginUnitUser> unitUserRelations = _em.createQuery(
        "select t from " + LoginUnitUser.class.getName() + " t ORDER BY t.id"
      ).getResultList();

      LoginUser readUser = null;
      for( LoginUnitUser unitUser : unitUserRelations ){
          readUser = unitUser.getLoginUserId();
      }

      assertNotNull( unitUserRelations );
    }

    @After
    public void tearDown() {
      _em.close();
      _emf.close();
    }

}