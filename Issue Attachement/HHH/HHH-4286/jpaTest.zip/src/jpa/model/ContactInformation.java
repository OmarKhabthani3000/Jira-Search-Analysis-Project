/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jpa.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author harrodr
 */
@Entity
@Table(name = "contact_information")
@NamedQueries({@NamedQuery(name = "ContactInformation.findAll", query = "SELECT c FROM ContactInformation c"), @NamedQuery(name = "ContactInformation.findByPhoneNumber", query = "SELECT c FROM ContactInformation c WHERE c.phoneNumber = :phoneNumber"), @NamedQuery(name = "ContactInformation.findByEmailAddress", query = "SELECT c FROM ContactInformation c WHERE c.emailAddress = :emailAddress"), @NamedQuery(name = "ContactInformation.findByPointOfContactName", query = "SELECT c FROM ContactInformation c WHERE c.pointOfContactName = :pointOfContactName"), @NamedQuery(name = "ContactInformation.findById", query = "SELECT c FROM ContactInformation c WHERE c.id = :id"), @NamedQuery(name = "ContactInformation.findByCreated", query = "SELECT c FROM ContactInformation c WHERE c.created = :created"), @NamedQuery(name = "ContactInformation.findByUpdated", query = "SELECT c FROM ContactInformation c WHERE c.updated = :updated")})
public class ContactInformation extends DomainObject implements Serializable{
    private static final long serialVersionUID = 1L;
    @Column(name = "phone_number")
    private String phoneNumber;
    @Column(name = "email_address")
    private String emailAddress;
    @Column(name = "point_of_contact_name")
    private String pointOfContactName;
    @Id
    @Basic(optional = false)
    @Column(name = "id")
    @GeneratedValue(generator="SqContactInformation")
    @SequenceGenerator(name="SqContactInformation",sequenceName="sq_contact_information", allocationSize=1)
    private Integer id;
    @Column(name = "_created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;
    @Column(name = "_updated")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updated;
    @OneToMany(mappedBy = "contactInformationId")
    private Collection<LoginUnit> loginUnitCollection;

    public ContactInformation() {
    }

    public ContactInformation(Integer id) {
        this.id = id;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPointOfContactName() {
        return pointOfContactName;
    }

    public void setPointOfContactName(String pointOfContactName) {
        this.pointOfContactName = pointOfContactName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public Collection<LoginUnit> getLoginUnitCollection() {
        return loginUnitCollection;
    }

    public void setLoginUnitCollection(Collection<LoginUnit> loginUnitCollection) {
        this.loginUnitCollection = loginUnitCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ContactInformation)) {
            return false;
        }
        ContactInformation other = (ContactInformation) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jpa.model.ContactInformation[id=" + id + "]";
    }

}
