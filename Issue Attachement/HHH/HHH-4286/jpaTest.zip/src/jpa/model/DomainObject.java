/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jpa.model;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;

/**
 *
 * @author harrodr
 */
@MappedSuperclass
public abstract class DomainObject {
  @JoinColumn(name = "_audit_login_user_id", referencedColumnName = "id")
  @ManyToOne
  private LoginUser auditLoginUserId;

  public LoginUser getAuditLoginUserId() {
    return auditLoginUserId;
  }

  public void setAuditLoginUserId(LoginUser auditLoginUserId) {
    this.auditLoginUserId = auditLoginUserId;
  }
}
