package org.hibernate.bugs;

import jakarta.persistence.*;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "CS_FOO")
public class Foo {

	private Long id;
	private boolean flag;

	@Id
	@SequenceGenerator(name = "CS_SEQ", sequenceName = "CS_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CS_SEQ")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "flag", updatable = false)
	@Type(
			value = StringBooleanType.class,
			parameters = {
					@org.hibernate.annotations.Parameter(name = "true", value = "#"),
					@org.hibernate.annotations.Parameter(name = "false", value = "&"),
			}
	)
	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}
}
