package org.hibernate.bugs;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.usertype.EnhancedUserType;
import org.hibernate.usertype.ParameterizedType;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

public class StringBooleanType implements EnhancedUserType<Boolean>, ParameterizedType {

	private static final String T_VALUES = "true";
	private static final String F_VALUES = "false";
	private static final String NULLABLE = "nullable";
	private static final String CASE_SENSITIVE = "caseSensitive";

	private static final String[] DEFAULT_T_VALUES = {
			"TRUE",
			"T",
			"YES",
			"Y",
			"ON",
			"1"
	};

	private static final String[] DEFAULT_F_VALUES = {
			"FALSE",
			"F",
			"NO",
			"N",
			"OFF",
			"0"
	};
	public static final String NAME = "StringBoolean";

	private String[] tValues = DEFAULT_T_VALUES;
	private String[] fValues = DEFAULT_F_VALUES;
	private boolean caseSensitive;
	private boolean nullable;

	// ParameterizedType

	@Override
	public void setParameterValues(Properties parameters) {
		String tsProperty = parameters.getProperty(T_VALUES);
		if (tsProperty != null) {
			tValues = split(tsProperty);
			if (tValues.length == 0)
				tValues = DEFAULT_T_VALUES;
		}

		String fsProperty = parameters.getProperty(F_VALUES);
		if (fsProperty != null) {
			fValues = split(fsProperty);
		}

		caseSensitive = "true".equalsIgnoreCase(parameters.getProperty(CASE_SENSITIVE));
		nullable = "true".equalsIgnoreCase(parameters.getProperty(NULLABLE));
	}

	// UserType


	@Override
	public int getSqlType() {
		return Types.VARCHAR;
	}

	@Override
	public Class<Boolean> returnedClass() {
		return Boolean.class;
	}

	@Override
	public boolean equals(Boolean obj1, Boolean obj2) {
		if (obj1 == obj2)
			return true;
		if (nullable) {
			if (obj1 == null || obj2 == null)
				return false;
		} else {
			if (obj1 == null)
				return obj2.equals(Boolean.FALSE);
			if (obj2 == null)
				return obj1.equals(Boolean.FALSE);
		}
		return obj1.equals(obj2);
	}

	@Override
	public int hashCode(Boolean obj) throws HibernateException {
		return obj == null ? 0 : obj.hashCode();
	}

	@Override
	public Boolean nullSafeGet(ResultSet result, int pos, SharedSessionContractImplementor sessionImplementor, Object o) throws HibernateException, SQLException {
		String value = result.getString(pos);
		return valueOf(result.wasNull() ? null : value);
	}

	@Override
	public void nullSafeSet(PreparedStatement stmt, Boolean value, int index, SharedSessionContractImplementor sessionImplementor) throws HibernateException, SQLException {
		if (value == null) {
			stmt.setNull(index, Types.VARCHAR);
		} else {
			stmt.setString(index, toString(value));
		}
	}

	@Override
	public Boolean deepCopy(Boolean value) {
		return value;
	}

	@Override
	public boolean isMutable() {
		return false;
	}

	@Override
	public Serializable disassemble(Boolean value) {
		return value;
	}

	@Override
	public Boolean assemble(Serializable cached, Object owner) {
		return (Boolean) cached;
	}

	// EnhancedUserType
	@Override
	public String toSqlLiteral(Boolean value) {
		String text = toString(value);
		return text == null ? "NULL" : "'" + text + "'";
	}

	@Override
	public Boolean fromStringValue(CharSequence sequence) throws HibernateException {
		return valueOf(sequence);
	}

	// Privates

	private Boolean valueOf(CharSequence source) {
		if (source == null) {
			return nullable ? null : Boolean.FALSE;
		}
		String text = (String) source;

		if (caseSensitive) {
			for (String t : tValues) {
				if (t.equals(text)) {
					return Boolean.TRUE;
				}
			}

			if (nullable) {
				for (String f : fValues) {
					if (f.equals(text)) {
						return Boolean.FALSE;
					}
				}

				return null;
			}
		} else {
			for (String t : tValues) {
				if (t.equalsIgnoreCase(text)) {
					return Boolean.TRUE;
				}
			}

			if (nullable) {
				for (String f : fValues) {
					if (f.equalsIgnoreCase(text)) {
						return Boolean.FALSE;
					}
				}

				return null;
			}
		}

		return Boolean.FALSE;
	}

	@Override
	public String toString(Boolean value) {
		if (value == null) {
			return nullable ? null : fValues[0];
		}
		return value ? tValues[0] : fValues[0];
	}

	public static String[] split(String text) {
		StringTokenizer tokenizer = new StringTokenizer(text, " \t,;|");
		List<String> list = new ArrayList<>();
		while (tokenizer.hasMoreTokens()) {
			list.add(tokenizer.nextToken());
		}
		return list.toArray(new String[0]);
	}

}
