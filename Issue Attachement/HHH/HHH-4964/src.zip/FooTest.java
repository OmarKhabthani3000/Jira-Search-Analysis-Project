package example.bug1;

import org.hibernate.Session;

import util.HibernateUtil;

public class FooTest {
    public static void main(String[] args) {
        Foo foo = new Foo();
        foo.setName("name");

        // t1
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        
        session.save(foo);
        session.getTransaction().commit();
        
        // t2
        session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        
        session.delete(foo);
        session.getTransaction().commit();
        
        // t3
        session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        
        session.update(foo);
        session.getTransaction().commit();
    }
}
