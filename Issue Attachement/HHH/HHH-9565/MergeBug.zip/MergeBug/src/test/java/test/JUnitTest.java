package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import model.Graph;

import org.junit.Test;

import factory.GraphFactory;

public class JUnitTest {

	@Test
	public void testMergeProblem() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("TestPersistenceUnit");
		EntityManager em = emf.createEntityManager();

		// build a Graph structure with 3000 nodes: A -> B -> C -> ... XYZ -> A
		Graph graph = GraphFactory.createRingGraph(3000);
		System.out.println("Created Graph has " + graph.getNodes().size() + " nodes.");
		em.merge(graph);
	}
}
