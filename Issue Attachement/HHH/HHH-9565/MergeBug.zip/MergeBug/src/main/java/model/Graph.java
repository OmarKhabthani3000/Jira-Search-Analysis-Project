package model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;

@Entity
public class Graph extends PersistableObject {

	@OneToMany(fetch = FetchType.LAZY, cascade = { CascadeType.MERGE, CascadeType.PERSIST })
	private Set<Node> nodes = new HashSet<Node>();

	public Set<Node> getNodes() {
		return this.nodes;
	}

	public void setNodes(final Set<Node> nodes) {
		this.nodes = nodes;
	}

}
