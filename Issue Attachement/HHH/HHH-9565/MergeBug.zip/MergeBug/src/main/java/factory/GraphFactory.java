package factory;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import model.Graph;
import model.Node;

public class GraphFactory {

	public static Graph createRandomGraph(final int numberOfNodes, final int edgesPerNode) {
		Graph graph = new Graph();
		// we use this list for random index access
		List<Node> nodes = new ArrayList<Node>();
		for (int nodeIndex = 0; nodeIndex < numberOfNodes; nodeIndex++) {
			Node node = new Node();
			node.setGraph(graph);
			graph.getNodes().add(node);
			nodes.add(node);
		}
		Random random = new Random();
		for (Node node : nodes) {
			for (int edgeIndex = 0; edgeIndex < edgesPerNode; edgeIndex++) {
				int randomTargetNodeIndex = random.nextInt(nodes.size());
				Node targetNode = nodes.get(randomTargetNodeIndex);
				node.getNeighbors().add(targetNode);
			}
		}
		return graph;
	}

	public static Graph createBinaryTree(final int numberOfNodes) {
		Graph tree = new Graph();
		Node rootNode = new Node();
		tree.getNodes().add(rootNode);
		generateBinaryTree(tree, rootNode, numberOfNodes - 1);
		return tree;
	}

	private static void generateBinaryTree(final Graph tree, final Node rootNode, final int nodesInSubtree) {
		int leftSubtreeNodes = (int) Math.round(Math.floor(nodesInSubtree / 2.0));
		int rightSubtreeNodes = (int) Math.round(Math.ceil(nodesInSubtree / 2.0));
		if (leftSubtreeNodes > 0) {
			Node leftNode = new Node();
			tree.getNodes().add(leftNode);
			rootNode.getNeighbors().add(leftNode);
			if (leftSubtreeNodes > 1) {
				generateBinaryTree(tree, leftNode, leftSubtreeNodes - 1);
			}
		}
		if (rightSubtreeNodes > 0) {
			Node rightNode = new Node();
			rootNode.getNeighbors().add(rightNode);
			tree.getNodes().add(rightNode);
			if (rightSubtreeNodes > 1) {
				generateBinaryTree(tree, rightNode, rightSubtreeNodes - 1);
			}
		}
	}

	public static Graph createRingGraph(final int ringSize) {
		Graph graph = new Graph();
		Node rootNode = new Node();
		graph.getNodes().add(rootNode);
		Node previousNode = rootNode;
		for (int i = 1; i < ringSize; i++) {
			Node node = new Node();
			graph.getNodes().add(node);
			previousNode.getNeighbors().add(node);
			previousNode = node;
		}
		previousNode.getNeighbors().add(rootNode);
		return graph;
	}

}
