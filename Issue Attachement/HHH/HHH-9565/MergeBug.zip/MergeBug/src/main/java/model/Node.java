package model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;

@Entity
public class Node extends PersistableObject {

	@ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.MERGE })
	private Set<Node> neighbors = new HashSet<Node>();

	// @ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.MERGE })
	// private Graph graph;

	public Set<Node> getNeighbors() {
		return this.neighbors;
	}

	public void setNeighbors(final Set<Node> neighbors) {
		this.neighbors = neighbors;
	}

	// public Graph getGraph() {
	// return this.graph;
	// }

	public void setGraph(final Graph graph) {
		// this.graph = graph;
	}

}
