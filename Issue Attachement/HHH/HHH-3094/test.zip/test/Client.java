package test;

import java.util.*;

import javax.naming.*;

public class Client {
	public static void main(String[] args) throws NamingException {
		Hashtable<String, String> environment = new Hashtable<String, String>();
	       environment.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
	       environment.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
	       environment.put(Context.PROVIDER_URL, "jnp://localhost:1099"); 
	       
	       InitialContext ctx = new InitialContext(environment);
	       MySession s = (MySession) ctx.lookup("MySessionBean/remote");
	       
	       s.create();
	       s.remove();
	}
}
