package test;

import javax.ejb.*;

@Remote
public interface MySession {
	void create();
	void remove();
}
