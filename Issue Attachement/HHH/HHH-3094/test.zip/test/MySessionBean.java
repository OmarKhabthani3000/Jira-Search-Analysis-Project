package test;

import javax.ejb.*;
import javax.persistence.*;

import org.hibernate.collection.*;

@Stateless
public class MySessionBean implements MySession {
	
	@PersistenceContext
	EntityManager m;
	
	public void create() {
		EntityA a = new EntityA(1);
		EntityB b = new EntityB(1);
		a.eB = b;
		b.eA.add(a);
		m.persist(a);
		m.persist(b);
	}
	
	public void remove() {
		EntityA a = m.find(EntityA.class, 1);
		EntityB b = m.find(EntityB.class, 1);
		
		m.remove(b);
		m.remove(a);
	}
}
