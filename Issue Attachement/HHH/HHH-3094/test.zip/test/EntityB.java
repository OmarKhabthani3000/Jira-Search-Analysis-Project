package test;

import java.util.*;

import javax.persistence.*;

@Entity
@org.hibernate.annotations.Entity(optimisticLock = org.hibernate.annotations.OptimisticLockType.ALL, dynamicUpdate = true)
public class EntityB {

	@Id
	Integer key;

	@OneToMany(mappedBy = "eB")    
	public Collection<EntityA> eA; 
	
	public EntityB() {
	}
    public EntityB(Integer key) {
    	this.key = key;
    	eA = new ArrayList<EntityA>();
    }
    
	@Override
	public String toString() {
		return "EntityB(" + key + ")";
	}
}
