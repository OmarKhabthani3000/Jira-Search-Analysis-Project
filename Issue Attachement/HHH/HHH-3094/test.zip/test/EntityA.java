package test;

import javax.persistence.*;

import de.dataport.ejb.*;

@Entity
@org.hibernate.annotations.Entity(optimisticLock = org.hibernate.annotations.OptimisticLockType.ALL, dynamicUpdate = true)
public class EntityA {
	
	@Id
	Integer key;
	
    @ManyToOne
	@JoinColumn(name = "eB_id")
	public EntityB eB;
    
    public EntityA() {
    }
    public EntityA(Integer key) {
    	this.key = key;
    }
	@Override
	public String toString() {
		return "EntityA(" + key + ")";
	}
}
