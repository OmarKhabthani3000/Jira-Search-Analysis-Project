package utils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.FlushMode;
import org.hibernate.HibernateException;
import org.hibernate.Interceptor;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


/**
 * Basic Hibernate helper class, handles SessionFactory, Session and Transaction.
 * <p>
 * Uses a static initializer for the initial SessionFactory creation
 * and holds Session and Transactions in thread local variables. All
 * exceptions are wrapped in an unchecked InfrastructureException.
 *
 * @author christian@hibernate.org,anthony@hibernate.org
 */
public class HibernateUtil {

	private static Log log = LogFactory.getLog(HibernateUtil.class);

	private static Configuration configuration;
	private static SessionFactory sessionFactory;
	private static final ThreadLocal threadSession = new ThreadLocal();
	private static final ThreadLocal threadTransaction = new ThreadLocal();
	private static final ThreadLocal threadInterceptor = new ThreadLocal();
	
	// usefull to set if the transaction is an atomic one or a persistence context one
	private static final ThreadLocal threadLongContextName = new ThreadLocal();

	// Create the initial SessionFactory from the default configuration files
	static {
		try {
			configuration = new Configuration();
			sessionFactory = configuration.configure().buildSessionFactory();
			// We could also let Hibernate bind it to JNDI:
			// configuration.configure().buildSessionFactory()
		} catch (Throwable ex) {
			// We have to catch Throwable, otherwise we will miss
			// NoClassDefFoundError and other subclasses of Error
			log.error("Building SessionFactory failed.", ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	/**
	 * Returns the SessionFactory used for this static class.
	 *
	 * @return SessionFactory
	 */
	public static SessionFactory getSessionFactory() {
		/* Instead of a static variable, use JNDI:
		SessionFactory sessions = null;
		try {
			Context ctx = new InitialContext();
			String jndiName = "java:hibernate/HibernateFactory";
			sessions = (SessionFactory)ctx.lookup(jndiName);
		} catch (NamingException ex) {
			throw new InfrastructureException(ex);
		}
		return sessions;
		*/
		return sessionFactory;
	}

	/**
	 * Returns the original Hibernate configuration.
	 *
	 * @return Configuration
	 */
	public static Configuration getConfiguration() {
		return configuration;
	}

	/**
	 * Rebuild the SessionFactory with the static Configuration.
	 *
	 */
	 public static void rebuildSessionFactory()
		throws RuntimeException {
		synchronized(sessionFactory) {
			try {
				sessionFactory = getConfiguration().buildSessionFactory();
			} catch (Exception ex) {
				throw new RuntimeException(ex);
			}
		}
	 }

	/**
	 * Rebuild the SessionFactory with the given Hibernate Configuration.
	 *
	 * @param cfg
	 */
	 public static void rebuildSessionFactory(Configuration cfg)
		throws RuntimeException {
		synchronized(sessionFactory) {
			try {
				sessionFactory = cfg.buildSessionFactory();
				configuration = cfg;
			} catch (Exception ex) {
				throw new RuntimeException(ex);
			}
		}
	 }

	/**
	 * Retrieves the current Session local to the thread.
	 * <p/>
	 * If no Session is open, opens a new Session for the running thread.
	 *
	 * @return Session
	 */
	public static Session getSession()
		throws RuntimeException {
		Session s = (Session) threadSession.get();
		try {
			if (s == null) {
				log.debug("Opening new Session for this thread.");
				if (getInterceptor() != null) {
					log.debug("Using interceptor: " + getInterceptor().getClass());
					s = getSessionFactory().openSession(getInterceptor());
				} else {
					s = getSessionFactory().openSession();
				}
				threadSession.set(s);
				if (threadTransaction.get()==null){
					beginTransaction();
				}
			}
		}
		catch (Exception ex) {
			throw new RuntimeException(ex);
		}
		return s;
	}
	
	/**
	 * needed by interceptor (i.e servlet filter) to know if we are
	 * using a persistence context or not 
	 * @return Session
	 */
	public static String getLongContextName()
		throws RuntimeException {
		String s = null;
		if (threadLongContextName.get()!=null)
			s = (String)threadLongContextName.get();
		return s;
	}
	
	/**
	 * let the interceptor (servlet filter) set the threadlocal
	 * variable 
	 */
	public static void setLongContextName(String name){
		threadLongContextName.set(name);
	}

	/**
	 * Closes the Session local to the thread.
	 */
	public static void closeSession()
		throws RuntimeException {
		try {
			Session s = (Session) threadSession.get();
			threadSession.set(null);
			if (s != null && s.isOpen()) {
				log.debug("Closing Session of this thread.");
				s.close();
			}
		} catch (HibernateException ex) {
			throw new RuntimeException(ex);
		}
	}

	/**
	 * Start a new database transaction.
	 */
	public static void beginTransaction()
		throws RuntimeException {
		Transaction tx = (Transaction) threadTransaction.get();
		try {
			if (tx == null) {
				log.debug("Starting new database transaction in this thread.");
				tx = getSession().beginTransaction();
				threadTransaction.set(tx);
			}
		} catch (HibernateException ex) {
			throw new RuntimeException(ex);
		}
	}

	/**
	 * Start a new long application transaction (starting persistence context)
	 * @param: only usefull for logging, can be changed with a Boolean
	 */
	public static void beginLongContext(String longProcessName) throws RuntimeException{
		log.debug("Starting application transaction for process:." + longProcessName);
		if (longProcessName != null){
			Session session = getSession();
			// clearing current session, the user must have managed the _previous_ session
			// and underlying bd transaction
			session.clear();
			session.setFlushMode(FlushMode.NEVER);
			threadLongContextName.set(longProcessName);
		}
		else 
			throw new RuntimeException ("starting application transaction without process name");
	}


	/**
	 * Commit the database transaction.
	 */
	public static void commitTransaction()
		throws RuntimeException {
		Transaction tx = (Transaction) threadTransaction.get();
		try {
			if ( tx != null && !tx.wasCommitted()
							&& !tx.wasRolledBack() ) {
				log.debug("Committing database transaction of this thread.");
				tx.commit();
			}
			threadTransaction.set(null);
		} catch (HibernateException ex) {
			rollbackTransaction();
			throw new RuntimeException(ex);
		}
	}
	
	/**
	 * Commit the long application transaction.
	 */
	public static void commitLongContext(String longContextName)
		throws RuntimeException {
		Transaction tx = (Transaction) threadTransaction.get();
			if (tx == null) beginTransaction();
		Session session = getSession();
		String contextName = getLongContextName();
		try {
			if ( contextName != null ) {
				log.debug("Committing Application transaction for process: " + contextName);
				session.flush();
				commitTransaction();
			}
			threadLongContextName.set(null);
		} catch (HibernateException ex) {
			rollbackTransaction();
			throw new RuntimeException(ex);
		}
	}

	/**
	 * Commit the database transaction.
	 */
	public static void rollbackTransaction()
		throws RuntimeException {
		Transaction tx = (Transaction) threadTransaction.get();
		try {
			threadTransaction.set(null);
			if ( tx != null && !tx.wasCommitted() && !tx.wasRolledBack() ) {
				log.debug("Tyring to rollback database transaction of this thread.");
				tx.rollback();
			}
		} catch (HibernateException ex) {
			throw new RuntimeException(ex);
		} finally {
			closeSession();
		}
	}
	
	
	/**
	 * Rollback the long context, tx.rollback not usefull since nothing has been propagated 
	 * to db because of flushmode
	 */
	public static void rollbackTransaction(String longContextName)
		throws RuntimeException {
		Transaction tx = (Transaction) threadTransaction.get();
		Session session = getSession();
		String contextName = getLongContextName();
		try {
			if ( contextName != null ) {
				log.debug("Rollback Application transaction for process: " + contextName);
				session.clear();
			}
			threadLongContextName.set(null);
		}  finally {
			closeSession();
		}
	}

	/**
	 * Reconnects a Hibernate Session to the current Thread.
	 *
	 * @param session The Hibernate Session to be reconnected.
	 */
	public static void reconnect(Session session)
		throws RuntimeException {
		try {
			if (!session.isConnected())
				session.reconnect();
			threadSession.set(session);
		} catch (HibernateException ex) {
			throw new RuntimeException(ex);
		}
	}

	/**
	 * Disconnect and return Session from current Thread.
	 *
	 * @return Session the disconnected Session
	 */
	public static Session disconnectSession()
		throws RuntimeException {

		Session session = getSession();
		try {
			threadSession.set(null);
			if (session.isConnected() && session.isOpen())
				session.disconnect();
		} catch (HibernateException ex) {
			throw new RuntimeException(ex);
		}
		return session;
	}

	/**
	 * Register a Hibernate interceptor with the current thread.
	 * <p>
	 * Every Session opened is opened with this interceptor after
	 * registration. Has no effect if the current Session of the
	 * thread is already open, effective on next close()/getSession().
	 */
	public static void registerInterceptor(Interceptor interceptor) {
		threadInterceptor.set(interceptor);
	}

	private static Interceptor getInterceptor() {
		Interceptor interceptor =
			(Interceptor) threadInterceptor.get();
		return interceptor;
	}

}

