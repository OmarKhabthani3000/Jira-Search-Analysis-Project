package com.eyrolles.sportTracker.model;

import java.io.Serializable;


/**
 * Une instance de cette classe repr�sente un Player.
 * Un player est associ� � une team. Son cycle de vie
 * n'est pas li� � la Team. * 
 * @author Anthony Patricio <anthony@hibernate.org>  
 */

public class Player extends Person implements Serializable{
	
	private String specificPlayerProperty;

	public  Player(){}
	
	public Player(String name){
	    this.setName(name);
	}


    
    /**
     * @return Returns the specificPlayerProperty.
     */
    public String getSpecificPlayerProperty() {
        return specificPlayerProperty;
    }
    /**
     * @param specificPlayerProperty The specificPlayerProperty to set.
     */
    public void setSpecificPlayerProperty(String specificPlayerProperty) {
        this.specificPlayerProperty = specificPlayerProperty;
    }
}
