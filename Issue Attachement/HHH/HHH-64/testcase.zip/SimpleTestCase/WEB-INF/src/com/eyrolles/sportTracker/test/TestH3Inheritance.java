package com.eyrolles.sportTracker.test;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import utils.HibernateUtil;

import com.eyrolles.sportTracker.model.Player;
/**
 * No actual test, but only test data initialization.
 *
 * @author Christian Bauer <christian@hibernate.org>
 */
public class TestH3Inheritance extends TestCase {
	public void testMakePersistant() throws Exception  {
	    System.out.println("==========testMakePersistant========");
	    Session session  = HibernateUtil.getSession();
	    Transaction tx=null;
	    try {
	        tx = session.beginTransaction();	
	        Player player = new Player("Anthony");
	        session.create(player);
	        tx.commit();
	    }
	    catch (Exception e) {
	        if (tx!=null) tx.rollback();	
	        e.printStackTrace();
	        throw e;
	    }
	    finally {
	        session.close();
	        System.out.println("==========testMakePersistant========");
	    }
	}

	public TestH3Inheritance(String x) {
		super(x);
	}
	
	public void drop(){
	    try {
            this.tearDown();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }	    
	}
	
	public static Test suite() {
	    return new TestSuite(TestH3Inheritance.class);
	}

	public static void main(String[] args) throws Exception {
		TestRunner.run( suite() );
	}
}
