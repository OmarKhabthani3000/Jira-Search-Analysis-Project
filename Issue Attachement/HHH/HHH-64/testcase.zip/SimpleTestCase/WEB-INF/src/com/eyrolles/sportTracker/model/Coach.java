/*
 * Created on 23 oct. 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.eyrolles.sportTracker.model;

import java.io.Serializable;

/**
 * @author totoo
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class Coach extends Person implements Serializable{
	
	private String specificCoachProperty;
    
    public Coach(){}

	public Coach(String name){
	    this.setName(name);
	}


   
    
    
    /**
     * @return Returns the specificCoachProperty.
     */
    public String getSpecificCoachProperty() {
        return specificCoachProperty;
    }
    /**
     * @param specificCoachProperty The specificCoachProperty to set.
     */
    public void setSpecificCoachProperty(String specificCoachProperty) {
        this.specificCoachProperty = specificCoachProperty;
    }
}
