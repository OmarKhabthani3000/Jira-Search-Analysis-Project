/*
 * Created on 23 oct. 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.eyrolles.sportTracker.model;

import java.util.Date;

/**
 * @author totoo
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public abstract class Person {
	private Long id;
	private String name;
	private Date birthday;
	private float height;
	private float weight;


    /**
     * @return Returns the birthday.
     */
    public Date getBirthday() {
        return birthday;
    }
    /**
     * @param birthday The birthday to set.
     */
    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }
    /**
     * @return Returns the height.
     */
    public float getHeight() {
        return height;
    }
    /**
     * @param height The height to set.
     */
    public void setHeight(float height) {
        this.height = height;
    }
    /**
     * @return Returns the id.
     */
    public Long getId() {
        return id;
    }
    /**
     * @param id The id to set.
     */
    public void setId(Long id) {
        this.id = id;
    }
    /**
     * @return Returns the name.
     */
    public String getName() {
        return name;
    }
    /**
     * @param name The name to set.
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return Returns the weight.
     */
    public float getWeight() {
        return weight;
    }
    /**
     * @param weight The weight to set.
     */
    public void setWeight(float weight) {
        this.weight = weight;
    }
}
