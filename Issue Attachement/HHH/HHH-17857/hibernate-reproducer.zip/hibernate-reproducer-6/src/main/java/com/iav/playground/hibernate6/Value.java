package com.iav.playground.hibernate6;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Value {
    @Id @GeneratedValue
    private Long id;

    @ManyToOne
    private Parent parent;

    @ManyToOne
    private Key key;
}
