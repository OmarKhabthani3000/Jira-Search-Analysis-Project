package com.iav.playground.hibernate6;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Key {
    @Id @GeneratedValue
    private Long id;

}
