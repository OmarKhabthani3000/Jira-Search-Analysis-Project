package com.iav.playground.hibernate5;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.SetJoin;

@SpringBootApplication
public class HibernateApplication implements CommandLineRunner {

    @PersistenceContext EntityManager entityManager;

    public static void main(String[] args) {
        SpringApplication.run(HibernateApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        final CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        final CriteriaQuery<Parent> cq = cb.createQuery(Parent.class);
        final Root<Parent> root = cq.from(Parent.class);
        final SetJoin<Parent, Value> valuesJoin = root.join(Parent_.values);
        valuesJoin.join(Value_.key);

        // This worked in Hibernate 5:
        entityManager.createQuery(cq).getResultList();
    }
}
