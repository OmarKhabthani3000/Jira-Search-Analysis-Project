package com.iav.playground.hibernate5;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Value {
    @Id @GeneratedValue
    private Long id;

    @ManyToOne
    private Parent parent;

    @ManyToOne
    private Key key;
}
