package com.iav.playground.hibernate5;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Key {
    @Id @GeneratedValue
    private Long id;
}
