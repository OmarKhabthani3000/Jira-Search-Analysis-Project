package hibernate.bug;

import hibernate.bug.model.Person;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p1 = new Person.Worker();
        Person p2 = new Person.Player();
        
        em.persist(p1);
        em.persist(p2);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testIssue() {
        EntityManager em = emf.createEntityManager();

        List l = em.createQuery("SELECT p FROM Person p WHERE (:personType IS NULL OR TYPE(p) = :personType)")
                .setParameter("personType", null)
                .getResultList();
        Assert.assertEquals(0, l.size());
        
        em.close();
    }
}
