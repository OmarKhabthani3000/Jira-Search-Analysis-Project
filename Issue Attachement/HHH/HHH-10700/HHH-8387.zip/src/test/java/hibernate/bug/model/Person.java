
package hibernate.bug.model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type")
public class Person implements Serializable {
    
    private Integer id;

    public Person() {
    }

    @Id
    @GeneratedValue
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * Created by Andrii Mozharovskyi on 20.04.2016.
     */
    @Entity
    @DiscriminatorValue("worker")
    public static class Worker extends Person {
    }

    /**
     * Created by Andrii Mozharovskyi on 20.04.2016.
     */
    @Entity
    @DiscriminatorValue("player")
    public static class Player extends Person {
    }
}
