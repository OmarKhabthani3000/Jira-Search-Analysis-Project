package hibernate.bug.jpa;

import org.hibernate.ejb.Ejb3Configuration;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.CacheRetrieveMode;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

import static org.junit.Assert.assertEquals;

public class TestCase {
    private static final String DRIVER_CLASS_NAME = "org.h2.Driver";
    private static final String JDBC_URL = "jdbc:h2:mem:test";

    private Connection conn;

    @Before
    public void setUp() throws Exception {
        conn = DriverManager.getConnection(JDBC_URL);

        runSql("create table SOME_TABLE(ID int not null primary key, A varchar(10), B varchar(10))");
        runSql("insert into SOME_TABLE(ID, A, B) values(1, 'val', 'old')");
    }

    @Test
    public void hibernateJpaHonorsCacheBypassHint() throws Exception {
        EntityManager entityManager = createEntityManager();
        String jpql = "from SomeEntity where a = 'val'";

        TypedQuery <SomeEntity> firstQuery = entityManager.createQuery(jpql, SomeEntity.class);
        firstQuery.getSingleResult();

        runSql("update SOME_TABLE set B = 'new'");

        TypedQuery<SomeEntity> cacheBypassBugQuery = entityManager.createQuery(jpql, SomeEntity.class);
        cacheBypassBugQuery.setHint("javax.persistence.cache.retrieveMode", CacheRetrieveMode.BYPASS);

        SomeEntity cacheNotBypassedBugEntity = cacheBypassBugQuery.getSingleResult();

        String incorrectB = cacheNotBypassedBugEntity.getB();
        String expectedB = runSql("select B from SOME_TABLE");

        assertEquals(expectedB, incorrectB);
    }

    private String runSql(String sql) throws Exception {
        String value = null;

        Statement stmt = conn.createStatement();

        if (stmt.execute(sql)) {
            ResultSet rs = stmt.getResultSet();

            if (rs.next()) {
                value = rs.getString(1);
            }
        }

        stmt.close();

        return value;
    }

    private EntityManager createEntityManager() {
        Properties props = new Properties();
        props.setProperty("javax.persistence.provider", "org.hibernate.ejb.HibernatePersistence");
        props.setProperty("javax.persistence.transactionType", "RESOURCE_LOCAL");
        props.setProperty("hibernate.connection.driver_class", DRIVER_CLASS_NAME);
        props.setProperty("hibernate.connection.url", JDBC_URL);
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.H2Dialect");

        Ejb3Configuration config = new Ejb3Configuration();
        config.addProperties(props);
        config.addAnnotatedClass(SomeEntity.class);

        EntityManagerFactory entityManagerFactory = config.buildEntityManagerFactory();

        return entityManagerFactory.createEntityManager();
    }
}
