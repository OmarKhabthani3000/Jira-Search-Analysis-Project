package com.bols;

import java.util.Map;

import org.hibernate.event.MergeEvent;
import org.hibernate.event.def.DefaultMergeEventListener;
import org.hibernate.util.IdentitySet;

/**
 * Possible extension to the MergeEventListener that just shortcuts merging objects that have already been found earlier in the merge
 * traverse, and will be inserted later. The ThreadLocal map is just a simple way of allowing the context to flow down the traversal, a
 * proper implementation would send this in regular parameters. (Or can the copycache be used)
 * 
 * @author Trond Bols� Isaksen
 */

public class ModifiedMergeEventListener extends DefaultMergeEventListener {

    private static final long serialVersionUID = 1L;
    static ThreadLocal<IdentitySet> transientObjects = new ThreadLocal<IdentitySet>();

    protected void entityIsTransient(MergeEvent event, Map copyCache) {

        boolean topLevelInvocation = transientObjects.get() == null;
        try {
            if (topLevelInvocation) {
                transientObjects.set(new IdentitySet());
            }
            if (transientObjects.get().contains(event.getEntity()))
                return;
            transientObjects.get().add(event.getEntity());
            super.entityIsTransient(event, copyCache);

        } finally {
            if (topLevelInvocation) {
                transientObjects.get().clear();
                transientObjects.set(null);
            }
        }
    }

}
