package com.bols;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.annotations.Cascade;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Environment;
import org.hibernate.criterion.Projections;
import org.hibernate.dialect.HSQLDialect;
import org.hibernate.event.MergeEventListener;
import org.hsqldb.jdbcDriver;
import org.junit.Test;


public class Hibernate3332TestCase extends TestCase{

    @Test
    public void testMergingASingleChildObjectWithCascadeToParentAndBackShouldNotGenerateTwoChildInserts() {
        Session session = setupConfiguration().buildSessionFactory().openSession();            
        runChildMergingTest(session);        
    }
    
    @Test
    public void testSameButWithModifiedMergeEventListener(){       
        AnnotationConfiguration annotationConfig = setupConfiguration();
        annotationConfig.getEventListeners().setMergeEventListeners(new MergeEventListener[]{new ModifiedMergeEventListener()});
        Session session=annotationConfig.buildSessionFactory().openSession();
        runChildMergingTest(session);
    }
    
    private void runChildMergingTest(Session session) {
        //Sets up one parent with one child
        Parent p = new Parent();
        Child c = new Child();
        c.setValue("TestValue");
        c.setParent(p);
        p.setChildren(Arrays.asList(new Child[] { c }));
        
        //Calls merge on the child
        session.merge(c);
        session.flush();        
        assertEquals("Number of child inserts ", 1, countNumber(session, Child.class));
    }

    private AnnotationConfiguration setupConfiguration() {
        AnnotationConfiguration annotationConfig = new AnnotationConfiguration();
        annotationConfig.addAnnotatedClass(Parent.class).addAnnotatedClass(Child.class);
        annotationConfig.setProperty(Environment.URL, "jdbc:hsqldb:mem:testdb");
        annotationConfig.setProperty(Environment.DRIVER, jdbcDriver.class.getName());
        annotationConfig.setProperty(Environment.HBM2DDL_AUTO, "create");
        annotationConfig.setProperty(Environment.DIALECT, HSQLDialect.class.getName());        
        return annotationConfig;
    }

    @Entity
    static public class Parent {
        @Id
        @GeneratedValue
        private int parentId;

        @OneToMany(mappedBy = "parent")
        @Cascade( { org.hibernate.annotations.CascadeType.MERGE })
        @org.hibernate.annotations.Fetch(value = org.hibernate.annotations.FetchMode.SUBSELECT)
        private List<Child> children;

        public List<Child> getChildren() {
            return children;
        }

        public void setChildren(List<Child> children) {
            this.children = children;
        }

        public int getParentId() {
            return parentId;
        }

    }

    @Entity
    static public class Child {
        @Id
        @GeneratedValue
        private int childId;

        @ManyToOne(fetch = FetchType.LAZY)
        @Cascade( { org.hibernate.annotations.CascadeType.MERGE })
        @JoinColumn(name = "parent_id")
        private Parent parent;

        @Column(name = "value")
        private String value;

        public int getChildId() {
            return childId;
        }

        public Parent getParent() {
            return parent;
        }

        public void setParent(Parent parent) {
            this.parent = parent;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }
    int countNumber(Session session, Class domainClass) {
        return (Integer) session.createCriteria(domainClass).setProjection(Projections.rowCount()).list().get(0);
    }
}
