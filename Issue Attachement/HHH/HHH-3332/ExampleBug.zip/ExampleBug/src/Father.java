import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


@Entity @Table(name="father") @TableGenerator(name="SEQ_ID_FATHER",
											  table="SEQUENCING",
											  pkColumnName="S_SEQUENCE",
											  valueColumnName="N_VALUE",
											  pkColumnValue="SEQ_ID_FATHER",
											  allocationSize=1)
public class Father implements Serializable{

	@Id 
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.TABLE, generator="SEQ_ID_FATHER")
	private Long id;
	
	@Column(name="s_nome")
	private String nome;
	
	//change the FetchType to EAGER and everything will work fine
	@OneToMany(mappedBy="father", fetch=FetchType.LAZY) @Cascade({CascadeType.ALL, CascadeType.DELETE_ORPHAN})
	private List<Child> Child;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public List<Child> getChild() {
		return Child;
	}

	public void setChild(List<Child> child) {
		Child = child;
	}
}
