
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;


public class Test {

	//this method preparer the environment that I'm facing.
	//Insert one father with no child
	public static void preparingTheEnvironment(){
		
		System.out.println("Starting to prepare the environment...");
		
		EntityManager em = Persistence.createEntityManagerFactory("ExampleBug", new HashMap()).createEntityManager();
		em.setFlushMode(FlushModeType.COMMIT);
		em.getTransaction().begin();
		
		//cleaning tables for multiples runs of this example
		em.createQuery("delete from Child").executeUpdate();
		em.createQuery("delete from Father").executeUpdate();
		
		//inserting one Father with no Child
		Father f = new Father();
		f.setNome("FatherName");		
		em.persist(f);		
		em.flush();
		
		//persisting the data into database
		em.getTransaction().commit();
		em.close();
		
		System.out.println("Finished preparing the environment...");
	}
	
	//this is the method that really test the bug found.
	public static void testBugMethod(){
		
		System.out.println("Starting the bug method...");
		
		EntityManager em = Persistence.createEntityManagerFactory("ExampleBug", new HashMap()).createEntityManager();
		em.setFlushMode(FlushModeType.COMMIT);
		em.getTransaction().begin();
		
		//Retrieving one Father from the database.
		List<Father> l = em.createQuery("select f from Father f ").getResultList();
		
		//using the first one returned
		Father father = l.get(0);
		
		//adding a child to the father
		Child child = new Child();
		child.setSNome("ChildName");
		child.setFather(father);
		father.getChild().add(child);
		
		//merge the father
		//this suppose to insert only one child into the database
		//but, if the FetchType in the Father class is set to LAZY, this merge inserts two child 
		//in the database with only the id different, that is generated from the TableGenerator
		em.merge(father);
		em.flush();	
		em.getTransaction().commit();
		
		em.close();
		
		System.out.println("Finished the bug method...");		
	}
	
	public static void main(String[] args) {
		Test.preparingTheEnvironment();
		Test.testBugMethod();		
		
		System.exit(0);
	}

}
