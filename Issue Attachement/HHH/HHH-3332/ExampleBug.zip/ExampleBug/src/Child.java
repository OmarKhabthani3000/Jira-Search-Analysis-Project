import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;


@Entity @Table(name="child") @TableGenerator(name="SEQ_ID_CHILD",
											 table="SEQUENCING",
											 pkColumnName="S_SEQUENCE",
											 valueColumnName="N_VALUE",
											 pkColumnValue="SEQ_ID_CHILD",
											 allocationSize=1)
public class Child implements Serializable{

	@Id
	@Column(name="Id")
	@GeneratedValue(strategy=GenerationType.TABLE, generator="SEQ_ID_CHILD")
	private Long id;
	
	@Column(name="s_nome")
	private String sNome;
	
	@ManyToOne @JoinColumn(name="id_father")
	private Father father;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSNome() {
		return sNome;
	}

	public void setSNome(String sNome) {
		this.sNome = sNome;
	}

	public Father getFather() {
		return father;
	}

	public void setFather(Father father) {
		this.father = father;
	}
}
