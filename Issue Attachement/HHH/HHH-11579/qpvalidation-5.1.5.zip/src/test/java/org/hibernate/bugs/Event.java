package org.hibernate.bugs;

import org.hibernate.annotations.Type;

import javax.persistence.*;

@Entity
public class Event {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Version
	private Integer version;

	@Type(type = "org.hibernate.bugs.WrappedMessageUserType")
	private WrappedMessage message;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public WrappedMessage getMessage() {
		return message;
	}

	public void setMessage(WrappedMessage message) {
		this.message = message;
	}
}
