package org.hibernate.bugs;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.Persistence;

public class JPAUnitTestCase {

	private SessionFactory sessionFactory;

	@Before
	public void init() {
		sessionFactory = Persistence.createEntityManagerFactory( "templatePU" ).unwrap(SessionFactory.class);
	}

	@After
	public void destroy() {
		sessionFactory.close();
	}

	@Test
	public void validateTest() throws Exception {
		Session session = sessionFactory.openSession();
		session.getTransaction().begin();
		try {
			WrappedMessage message = new WrappedMessage("Hello");

			// create a record
			Event event = new Event();
			event.setMessage(message);
			session.persist(event);

			Query query = session.createQuery("SELECT e FROM Event e WHERE e.message = ?");
			query.setParameter(0, message); // works fine
			Event result = (Event) query.uniqueResult();
			Assert.assertNotNull(result);
			Assert.assertNotNull(result.getMessage());
			Assert.assertEquals("Hello", result.getMessage().getS());

			query = session.createQuery("SELECT e FROM Event e WHERE e.message = ?");
			query.setParameter(0, "Hello"); // java.lang.IllegalArgumentException: Parameter value [Hello] did not match expected type [org.hibernate.bugs.WrappedMessage (n/a)]
			result = (Event) query.uniqueResult();
			Assert.assertNotNull(result);
			Assert.assertNotNull(result.getMessage());
			Assert.assertEquals("Hello", result.getMessage().getS());
		} finally {
			session.getTransaction().commit();
			session.close();
		}
	}
}
