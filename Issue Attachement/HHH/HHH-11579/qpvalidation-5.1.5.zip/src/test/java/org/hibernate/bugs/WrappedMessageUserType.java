package org.hibernate.bugs;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.StandardBasicTypes;
import org.hibernate.usertype.UserType;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

public class WrappedMessageUserType implements UserType {

	@Override
	public int[] sqlTypes() {
		return new int[] { Types.VARCHAR };
	}

	@Override
	public Class returnedClass() {
		return WrappedMessage.class;
	}

	@Override
	public boolean equals(Object x, Object y) throws HibernateException {
		boolean result;
		if (x == y) {
			result = true;
		} else if ((x == null) || (y == null)) {
			result = false;
		} else {
			result = x.equals(y);
		}
		return result;
	}

	@Override
	public int hashCode(Object x) throws HibernateException {
		return x == null ? 0 : x.hashCode();
	}

	@Override
	public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object o) throws HibernateException, SQLException {
		WrappedMessage result;
		String s = StandardBasicTypes.STRING.nullSafeGet(rs, names[0], session);
		if (s == null) {
			result = null;
		} else {
			result = new WrappedMessage(s);
		}
		return result;
	}

	@Override
	public void nullSafeSet(PreparedStatement st, Object value, int index, SessionImplementor session) throws HibernateException, SQLException {
		if (value == null) {
			st.setNull(index, sqlTypes()[0]);
		} else if (value instanceof WrappedMessage) {
			st.setString(index, ((WrappedMessage) value).getS());
		} else if (value instanceof String) {
			st.setString(index, (String) value);
		} else {
			throw new IllegalArgumentException("Parameter value has to be an instance of MyClass or String");
		}
	}

	@Override
	public Object deepCopy(Object value) throws HibernateException {
		return value;
	}

	@Override
	public boolean isMutable() {
		return false;
	}

	@Override
	public Serializable disassemble(Object value) throws HibernateException {
		String s;
		if (value instanceof WrappedMessage) {
			s = ((WrappedMessage) value).getS();
		} else if (value instanceof String) {
			s = (String) value;
		} else if (value == null) {
			s = null;
		} else {
			throw new IllegalArgumentException("Unsupported class: " + value.getClass().getName());
		}
		return s;
	}

	@Override
	public Object assemble(Serializable serializable, Object cached) throws HibernateException {
		return cached == null ? null : new WrappedMessage((String) cached);
	}

	@Override
	public Object replace(Object original, Object target, Object owner) throws HibernateException {
		return original;
	}

}
