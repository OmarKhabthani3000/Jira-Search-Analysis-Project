package org.hibernate.bugs;

public class WrappedMessage {

	private String s;

	public WrappedMessage(String s) {
		this.s = s;
	}

	public String getS() {
		return s;
	}

}
