package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void validateTest() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		try {
			WrappedMessage message = new WrappedMessage("Hello");

			// create a record
			Event event = new Event();
			event.setMessage(message);
			entityManager.persist(event);

			Query query = entityManager.createQuery("SELECT e FROM Event e WHERE e.message = :message");
			query.setParameter("message", message); // works fine
			Event result = (Event) query.getSingleResult();
			Assert.assertNotNull(result);
			Assert.assertNotNull(result.getMessage());
			Assert.assertEquals("Hello", result.getMessage().getS());

			query = entityManager.createQuery("SELECT e FROM Event e WHERE e.message = :message");
			query.setParameter("message", "Hello"); // java.lang.IllegalArgumentException: Parameter value [Hello] did not match expected type [org.hibernate.bugs.WrappedMessage (n/a)]
			result = (Event) query.getSingleResult();
			Assert.assertNotNull(result);
			Assert.assertNotNull(result.getMessage());
			Assert.assertEquals("Hello", result.getMessage().getS());
		} finally {
			entityManager.getTransaction().commit();
			entityManager.close();
		}
	}
}
