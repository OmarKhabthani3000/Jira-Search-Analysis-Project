
CREATE TABLE PostAddresses
(
  contact_id INTEGER NOT NULL,
  ordinal_nbr SMALLINT NOT NULL,
  PRIMARY KEY (contact_id, ordinal_nbr)
);

CREATE TABLE Foos
(
  contact_id INTEGER NOT NULL,
  ordinal_nbr SMALLINT NOT NULL,
  PRIMARY KEY (contact_id, ordinal_nbr),
  FOREIGN KEY (contact_id, ordinal_nbr) REFERENCES PostAddresses (contact_id, ordinal_nbr)
);

CREATE TABLE Bars
(
  contact_id INTEGER NOT NULL,
  ordinal_nbr SMALLINT NOT NULL,
  numba INTEGER NOT NULL,
  PRIMARY KEY (contact_id, ordinal_nbr, numba),
  FOREIGN KEY (contact_id, ordinal_nbr) REFERENCES Foos (contact_id, ordinal_nbr)
);
