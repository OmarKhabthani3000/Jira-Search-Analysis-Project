package tld.transmuc.model;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "Bars")
public class Bar implements Serializable
{
	@EmbeddedId
	private BarId embeddedId;

	@MapsId(value = "fooId")
	@ManyToOne
	@JoinColumns(value = {@JoinColumn(name = "contact_id", referencedColumnName = "contact_id"), @JoinColumn(name = "ordinal_nbr", referencedColumnName = "ordinal_nbr")})
	private Foo foo = null;

	public Bar()
	{
	}

	public Bar(Integer contactId, Integer ordinalNbr, Integer numba)
	{
		this.embeddedId = new BarId(contactId, ordinalNbr, numba);

		if ( contactId != null && ordinalNbr != null )
		{
			this.foo = new Foo(contactId, ordinalNbr);
		}
	}

	public BarId getEmbeddedId()
	{
		return embeddedId;
	}

	public void setEmbeddedId(BarId embeddedId)
	{
		this.embeddedId = embeddedId;
	}

	public Integer getContactId()
	{
		return embeddedId.getFooId().getPostAddressId().getContactId();
	}

	public void setContactId(Integer contactId)
	{
		embeddedId.getFooId().getPostAddressId().setContactId(contactId);
	}

	public Integer getOrdinalNbr()
	{
		return embeddedId.getFooId().getPostAddressId().getOrdinalNbr();
	}

	public void setOrdinalNbr(Integer ordinalNbr)
	{
		embeddedId.getFooId().getPostAddressId().setOrdinalNbr(ordinalNbr);
	}

	public Integer getNumba()
	{
		return embeddedId.getNumba();
	}

	public void setNumba(Integer numba)
	{
		embeddedId.setNumba(numba);
	}

	public Foo getFoo()
	{
		return foo;
	}

	public void setFoo(Foo foo)
	{
		this.foo = foo;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		Bar rhs = (Bar)obj;

		return new EqualsBuilder().append(embeddedId, rhs.getEmbeddedId()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(1481061677, 92821).append(embeddedId).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("embeddedId", embeddedId).append("foo", foo).toString();
	}

}
