package tld.transmuc.model;

import java.io.Serializable;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Embeddable
public class FooId implements Serializable
{
	@Embedded
	private PostAddressId postAddressId;

	public FooId()
	{
	}

	public FooId(Integer contactId, Integer ordinalNbr)
	{
		if ( contactId != null && ordinalNbr != null )
		{
			this.postAddressId = new PostAddressId(contactId, ordinalNbr);
		}
	}

	public PostAddressId getPostAddressId()
	{
		return postAddressId;
	}

	public void setPostAddressId(PostAddressId postAddressId)
	{
		this.postAddressId = postAddressId;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		FooId rhs = (FooId)obj;

		return new EqualsBuilder().append(postAddressId, rhs.getPostAddressId()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(1554697027, 92821).append(postAddressId).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("postAddressId", postAddressId).toString();
	}

}
