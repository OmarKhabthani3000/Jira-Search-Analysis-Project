package tld.transmuc.model;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "PostAddresses")
public class PostAddress implements Serializable
{
	@EmbeddedId
	private PostAddressId embeddedId;

	@OneToOne(mappedBy = "postAddress")
	private Foo foo = null;

	public PostAddress()
	{
	}

	public PostAddress(Integer contactId, Integer ordinalNbr)
	{
		this.embeddedId = new PostAddressId(contactId, ordinalNbr);
	}

	public PostAddressId getEmbeddedId()
	{
		return embeddedId;
	}

	public void setEmbeddedId(PostAddressId embeddedId)
	{
		this.embeddedId = embeddedId;
	}

	public Integer getContactId()
	{
		return embeddedId.getContactId();
	}

	public void setContactId(Integer contactId)
	{
		embeddedId.setContactId(contactId);
	}

	public Integer getOrdinalNbr()
	{
		return embeddedId.getOrdinalNbr();
	}

	public void setOrdinalNbr(Integer ordinalNbr)
	{
		embeddedId.setOrdinalNbr(ordinalNbr);
	}

	public Foo getFoo()
	{
		return foo;
	}

	public void setFoo(Foo foo)
	{
		this.foo = foo;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		PostAddress rhs = (PostAddress)obj;

		return new EqualsBuilder().append(embeddedId, rhs.getEmbeddedId()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(2003614645, 92821).append(embeddedId).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("embeddedId", embeddedId).toString();
	}

}
