package tld.transmuc.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Embeddable
public class BarId implements Serializable
{
	@Embedded
	private FooId fooId;

	@Column(name = "numba")
	private Integer numba;

	public BarId()
	{
	}

	public BarId(Integer contactId, Integer ordinalNbr, Integer numba)
	{
		if ( contactId != null && ordinalNbr != null )
		{
			this.fooId = new FooId(contactId, ordinalNbr);
		}

		this.numba = numba;
	}

	public FooId getFooId()
	{
		return fooId;
	}

	public void setFooId(FooId fooId)
	{
		this.fooId = fooId;
	}

	public Integer getNumba()
	{
		return numba;
	}

	public void setNumba(Integer numba)
	{
		this.numba = numba;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		BarId rhs = (BarId)obj;

		return new EqualsBuilder().append(fooId, rhs.getFooId()).append(numba, rhs.getNumba()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(1320449715, 92821).append(fooId).append(numba).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("fooId", fooId).append("numba", numba).toString();
	}

}
