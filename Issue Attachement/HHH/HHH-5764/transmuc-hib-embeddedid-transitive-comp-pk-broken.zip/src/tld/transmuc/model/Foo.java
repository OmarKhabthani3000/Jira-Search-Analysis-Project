package tld.transmuc.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "Foos")
public class Foo implements Serializable
{
	@EmbeddedId
	private FooId embeddedId;

	@MapsId(value = "postAddressId")
	@OneToOne
	@JoinColumns(value = {@JoinColumn(name = "contact_id", referencedColumnName = "contact_id"), @JoinColumn(name = "ordinal_nbr", referencedColumnName = "ordinal_nbr")})
	private PostAddress postAddress = null;

	@OneToMany(targetEntity = Bar.class, mappedBy = "foo")
	private Set<Bar> bars = new HashSet<Bar>();

	public Foo()
	{
	}

	public Foo(Integer contactId, Integer ordinalNbr)
	{
		this.embeddedId = new FooId(contactId, ordinalNbr);

		if ( contactId != null && ordinalNbr != null )
		{
			this.postAddress = new PostAddress(contactId, ordinalNbr);
		}
	}

	public FooId getEmbeddedId()
	{
		return embeddedId;
	}

	public void setEmbeddedId(FooId embeddedId)
	{
		this.embeddedId = embeddedId;
	}

	public Integer getContactId()
	{
		return embeddedId.getPostAddressId().getContactId();
	}

	public void setContactId(Integer contactId)
	{
		embeddedId.getPostAddressId().setContactId(contactId);
	}

	public Integer getOrdinalNbr()
	{
		return embeddedId.getPostAddressId().getOrdinalNbr();
	}

	public void setOrdinalNbr(Integer ordinalNbr)
	{
		embeddedId.getPostAddressId().setOrdinalNbr(ordinalNbr);
	}

	public PostAddress getPostAddress()
	{
		return postAddress;
	}

	public void setPostAddress(PostAddress postAddress)
	{
		this.postAddress = postAddress;
	}

	public Set<Bar> getBars()
	{
		return bars;
	}

	public void setBars(Set<Bar> bars)
	{
		this.bars = bars;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		Foo rhs = (Foo)obj;

		return new EqualsBuilder().append(embeddedId, rhs.getEmbeddedId()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(1049641405, 92821).append(embeddedId).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("embeddedId", embeddedId).append("postAddress", postAddress).toString();
	}

}
