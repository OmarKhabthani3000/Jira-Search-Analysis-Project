
package tld.transmuc;

import java.io.*;
import java.util.*;
import java.util.logging.*;
import java.sql.*;
import java.text.*;

import javax.sql.*;
import javax.persistence.*;

import tld.transmuc.model.*;

public class Main
{
		
	public static void main(String... sArgs) throws Exception
	{
		String sDbName = "transmuc";
		createInMemoryDbViaJdbc(sDbName); // via JDBC statements
	
		System.out.println();
		System.out.println("Database created!");
		System.out.println();
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(sDbName);
		EntityManager em = emf.createEntityManager();
		
		System.out.println();
		System.out.println("Entity manager created!");
		System.out.println();
		
		// Michael Jordan: the person who's only a player

		// EclipseLink 2.1.1 (+1): correct Person instance
		// EclipseLink 2.2.0 (+1): correct Person instance
		// Hibernate 3.6     (-1): wrong Player instance
		/*Contact co1 = em.find(Contact.class, 1);
		System.out.println("Loaded contact = " + co1);

		// EclipseLink 2.1.1 (+1): correct Person instance
		// EclipseLink 2.2.0 (+1): correct Person instance
		// Hibernate 3.6     (-1): wrong Player instance
		Person pe1 = em.find(Person.class, 1);
		System.out.println("Loaded person = " + pe1);
		
		// EclipseLink 2.1.1 (-1): wrong Person instance => class cast exception Person -> Player (fatal)
		// EclipseLink 2.2.0 (-1): wrong null
		// Hibernate 3.6     (+1): correct Player instance
		Player pl1 = em.find(Player.class, 1);
		System.out.println("Loaded player = " + pl1);

		// EclipseLink 2.1.1 (-1): wrong Person instance => class cast exception Person -> Referee (fatal)
		// EclipseLink 2.2.0 (+1): correct null
		// Hibernate 3.6     (+1): correct null
		Referee re1 = em.find(Referee.class, 1);
		System.out.println("Loaded referee = " + re1);
		
		// EclipseLink 2.1.1 (-1): wrong Person instance => class cast exception Person -> Coach (fatal)
		// EclipseLink 2.2.0 (+1): correct null
		// Hibernate 3.6     (+1): correct null
		Coach ch1 = em.find(Coach.class, 1);
		System.out.println("Loaded coach = " + ch1);

		System.out.println();
		System.out.println();

		// Dirk Nowitzki: the person who's a player *and* a referee

		// EclipseLink 2.1.1 (+1): correct Person instance
		// EclipseLink 2.2.0 (+1): correct Person instance
		// Hibernate 3.6     (-1): wrong Referee instance
		Contact co2 = em.find(Contact.class, 2);
		System.out.println("Loaded contact = " + co2);

		// EclipseLink 2.1.1 (+1): correct Person instance
		// EclipseLink 2.2.0 (+1): correct Person instance
		// Hibernate 3.6     (-1): wrong Referee instance
		Person pe2 = em.find(Person.class, 2);
		System.out.println("Loaded person = " + pe2);
		
		// EclipseLink 2.1.1 (-1): wrong Person instance => class cast exception Person -> Player (fatal)
		// EclipseLink 2.2.0 (-1): wrong null
		// Hibernate 3.6     (-1): wrong null
		Player pl2 = em.find(Player.class, 2);
		System.out.println("Loaded player = " + pl2);

		// EclipseLink 2.1.1 (-1): wrong Person instance => class cast exception Person -> Referee (fatal)
		// EclipseLink 2.2.0 (-1): wrong null
		// Hibernate 3.6     (+1): correct Referee instance
		Referee re2 = em.find(Referee.class, 2);
		System.out.println("Loaded referee = " + re2);

		// EclipseLink 2.1.1 (-1): wrong Person instance => class cast exception Person -> Coach (fatal)
		// EclipseLink 2.2.0 (+1): correct null
		// Hibernate 3.6     (+1): correct null
		Coach ch2 = em.find(Coach.class, 2);
		System.out.println("Loaded coach = " + ch2);

		System.out.println();
		System.out.println();

		// Blake Griffin: the person who's a player, referee, *and* coach

		// EclipseLink 2.1.1 (+1): correct Person instance
		// EclipseLink 2.2.0 (+1): correct Person instance
		// Hibernate 3.6     (-1): wrong Referee instance
		Contact co3 = em.find(Contact.class, 3);
		System.out.println("Loaded contact = " + co3);

		// EclipseLink 2.1.1 (+1): correct Person instance
		// EclipseLink 2.2.0 (+1): correct Person instance
		// Hibernate 3.6     (-1): wrong Referee instance
		Person pe3 = em.find(Person.class, 3);
		System.out.println("Loaded person = " + pe3);
		
		// EclipseLink 2.1.1 (-1): wrong Person instance => class cast exception Person -> Player (fatal)
		// EclipseLink 2.2.0 (-1): wrong null
		// Hibernate 3.6     (-1): wrong null
		Player pl3 = em.find(Player.class, 3);
		System.out.println("Loaded player = " + pl3);

		// EclipseLink 2.1.1 (-1): wrong Person instance => class cast exception Person -> Referee (fatal)
		// EclipseLink 2.2.0 (-1): wrong null
		// Hibernate 3.6     (+1): correct Referee instance
		Referee re3 = em.find(Referee.class, 3);
		System.out.println("Loaded referee = " + re3);

		// EclipseLink 2.1.1 (-1): wrong Person instance => class cast exception Person -> Coach (fatal)
		// EclipseLink 2.2.0 (-1): wrong null
		// Hibernate 3.6     (-1): wrong null
		Coach ch3 = em.find(Coach.class, 3);
		System.out.println("Loaded coach = " + ch3);*/

		// Total of 15:
		// EclipseLink 2.1.1: 9 of 15 wrong, *never* concrete sub classes!
		//                    => this is useless in practice (showstopper)
		// EclipseLink 2.2.0: 6 of 15 wrong, *never* concrete sub classes!
		//                    => this is useless in practice (showstopper)
		// Hibernate 3.6    : 9 of 15 wrong, never Person instances, but at least the correct sub class instances!
		//                    => also relatively useless in practice, but can workaround, see below
		
		// Hibernate workaround: remove all Referee and Coach entities which let'S it return Player instances at all times!

		/*TeamMember tm1 = em.find(TeamMember.class, new TeamMemberId(1, 1));
		System.out.println("Loaded team member = " + tm1);
		
		TeamMember tm2 = em.find(TeamMember.class, new TeamMemberId(2, 1));
		System.out.println("Loaded team member = " + tm2);
		
		TeamMember tm3 = em.find(TeamMember.class, new TeamMemberId(3, 1));
		System.out.println("Loaded team member = " + tm3);*/
		
		/*PlayerStat ps = em.find(PlayerStat.class, new PlayerStatId(5, false, 2, 1));
		System.out.println("Loaded player stat = " + ps);
		
		Stat stat = em.find(Stat.class, new StatId(5, false, 2, 1, 1));
		System.out.println("Loaded stat = " + stat);*/
		
		
		//em.close();
		//emf.close();
	}
	
	private static void createInMemoryDbViaJdbc(String sDbName) throws Exception
	{
		String sBatchSqlScript = readFile(new File("db", sDbName + "-isoansi-ddl.sql"));
		
		//System.out.println(sBatchSqlScript);
		
		List<String> lsStatements = new ArrayList<String>();
		
		StringTokenizer sto = new StringTokenizer(sBatchSqlScript, ";");
	
		while ( sto.hasMoreTokens() )
		{
			String sStatement = sto.nextToken().trim();
			//System.out.println("---------------------------------------------------------------------------------------------------");
			//System.out.println(sStatement);
			
			if ( !sStatement.isEmpty() )
			{
				lsStatements.add(sStatement);
			}
		}
 
		// loads the JDBC driver (needed for HSQLDB pre 2.0.0)
		Class.forName("org.hsqldb.jdbcDriver");	
		
		PreparedStatement ps = null;
		Connection conn = null;
		
		String sCurrStatement = null;
		
		try
		{
			conn = DriverManager.getConnection("jdbc:hsqldb:mem:" + sDbName, "sa", "");
			
			for ( String sStatement : lsStatements )
			{
				sCurrStatement = sStatement;
				ps = conn.prepareStatement(sStatement);
				ps.executeUpdate();
			}
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			System.out.println(sCurrStatement);
			System.exit(1);
		}
		finally
		{
			try
			{
				conn.close();
			}
			catch ( SQLException e )
			{
				e.printStackTrace();
			}
		}
    }
	
	private static String readFile(File flRead)
	{
		String sContent = null;
		FileInputStream fis = null;
		
		try
		{
			fis = new FileInputStream(flRead);
			byte[] readBuffer = new byte[(int)flRead.length()];
			
			fis.read(readBuffer);
			sContent = new String(readBuffer);
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			return null;
		}
		finally
		{
			if ( fis != null )
			{
				try
				{
					fis.close();
				}
				catch ( Throwable t )
				{
					System.err.println("File input stream couldn't be closed!");
				}
			}
		}
	
		return sContent;
	}

}
