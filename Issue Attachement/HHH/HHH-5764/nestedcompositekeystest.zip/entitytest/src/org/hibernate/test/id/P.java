package org.hibernate.test.id;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class P {
	
	@Id
	@Column(nullable=false, precision=15, scale=0)
	private Long id;
	
	@OneToOne(mappedBy="hasP")
	private PA hasPA;
	
	@Column(length=16)
	private String payload;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public PA getHasPA() {
		return hasPA;
	}

	public void setHasPA(PA hasPA) {
		this.hasPA = hasPA;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

}
