package org.hibernate.test.embeddedid;

import java.io.Serializable;
import java.util.Arrays;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;

@Embeddable
public class PA_Key implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long hasP;
	
	@Embedded
	private TA_Key belongsToTA;

	public PA_Key() {}
	
	public Long getHasP() {
		return hasP;
	}

	public void setHasP(Long hasP) {
		this.hasP = hasP;
	}

	public TA_Key getBelongsToTA() {
		return belongsToTA;
	}

	public void setBelongsToTA(TA_Key belongsToTA) {
		this.belongsToTA = belongsToTA;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || !this.getClass().equals(obj.getClass())) {
			return false;
		}
		PA_Key other = (PA_Key) obj;
		return
			(hasP == other.hasP || hasP != null && hasP.equals(other.hasP)) &&
			(belongsToTA == other.belongsToTA || belongsToTA != null && belongsToTA.equals(other.belongsToTA));
	}

	@Override
	public int hashCode() {
		return Arrays.hashCode(new Object[] {hasP, belongsToTA});
	}

}
