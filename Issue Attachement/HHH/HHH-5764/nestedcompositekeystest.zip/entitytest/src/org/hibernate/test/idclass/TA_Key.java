package org.hibernate.test.idclass;

import java.io.Serializable;

public class TA_Key implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer belongsToA;

	private String belongsToT;

	public TA_Key() {}
	
	public Integer getBelongsToA() {
		return belongsToA;
	}

	public void setBelongsToA(Integer belongsToA) {
		this.belongsToA = belongsToA;
	}

	public String getBelongsToT() {
		return belongsToT;
	}

	public void setBelongsToT(String belongsToT) {
		this.belongsToT = belongsToT;
	}

}
