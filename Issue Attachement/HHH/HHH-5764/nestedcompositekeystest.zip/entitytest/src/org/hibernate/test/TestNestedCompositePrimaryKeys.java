package org.hibernate.test;

import org.hibernate.MappingException;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

public class TestNestedCompositePrimaryKeys {

	private static class ConfigurationForTest extends Configuration {
		private static final long serialVersionUID = 1L;

		@Override
		public void secondPassCompile() throws MappingException {
			// Make this operation available to the test.
			super.secondPassCompile();
		}
	}
	
	@Test
	public void testEmbeddIdFull() {
		ConfigurationForTest config = new ConfigurationForTest();
		config.setProperty("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		config.addAnnotatedClass(org.hibernate.test.embeddedid.A.class);
		config.addAnnotatedClass(org.hibernate.test.embeddedid.T.class);
		config.addAnnotatedClass(org.hibernate.test.embeddedid.P.class);
		config.addAnnotatedClass(org.hibernate.test.embeddedid.R.class);
		config.addAnnotatedClass(org.hibernate.test.embeddedid.U.class);
		config.addAnnotatedClass(org.hibernate.test.embeddedid.TA.class);
		config.addAnnotatedClass(org.hibernate.test.embeddedid.PA.class);
		config.addAnnotatedClass(org.hibernate.test.embeddedid.UR.class);
		config.addAnnotatedClass(org.hibernate.test.embeddedid.UTA.class);
		config.addAnnotatedClass(org.hibernate.test.embeddedid.RUTA.class);
		config.secondPassCompile();		
	}
	
	@Test
	public void testEmbeddIdSubset() {
		ConfigurationForTest config = new ConfigurationForTest();
		config.setProperty("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		config.addAnnotatedClass(org.hibernate.test.embeddedidsub.A.class);
		config.addAnnotatedClass(org.hibernate.test.embeddedidsub.T.class);
		config.addAnnotatedClass(org.hibernate.test.embeddedidsub.P.class);
		config.addAnnotatedClass(org.hibernate.test.embeddedidsub.TA.class);
		config.addAnnotatedClass(org.hibernate.test.embeddedidsub.PA.class);
		config.secondPassCompile();		
	}

	@Test
	public void testIdClassFull() {
		ConfigurationForTest config = new ConfigurationForTest();
		config.setProperty("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		config.addAnnotatedClass(org.hibernate.test.idclass.A.class);
		config.addAnnotatedClass(org.hibernate.test.idclass.T.class);
		config.addAnnotatedClass(org.hibernate.test.idclass.P.class);
		config.addAnnotatedClass(org.hibernate.test.idclass.R.class);
		config.addAnnotatedClass(org.hibernate.test.idclass.U.class);
		config.addAnnotatedClass(org.hibernate.test.idclass.TA.class);
		config.addAnnotatedClass(org.hibernate.test.idclass.PA.class);
		config.addAnnotatedClass(org.hibernate.test.idclass.UR.class);
		config.addAnnotatedClass(org.hibernate.test.idclass.UTA.class);
		config.addAnnotatedClass(org.hibernate.test.idclass.RUTA.class);
		config.secondPassCompile();		
	}

	@Test
	public void testIdClassSubset() {
		ConfigurationForTest config = new ConfigurationForTest();
		config.setProperty("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		config.addAnnotatedClass(org.hibernate.test.idclasssub.A.class);
		config.addAnnotatedClass(org.hibernate.test.idclasssub.T.class);
		config.addAnnotatedClass(org.hibernate.test.idclasssub.P.class);
		config.addAnnotatedClass(org.hibernate.test.idclasssub.TA.class);
		config.addAnnotatedClass(org.hibernate.test.idclasssub.PA.class);
		config.secondPassCompile();		
	}

	@Test
	public void testId() {
		ConfigurationForTest config = new ConfigurationForTest();
		config.setProperty("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		config.addAnnotatedClass(org.hibernate.test.id.A.class);
		config.addAnnotatedClass(org.hibernate.test.id.T.class);
		config.addAnnotatedClass(org.hibernate.test.id.P.class);
		config.addAnnotatedClass(org.hibernate.test.id.R.class);
		config.addAnnotatedClass(org.hibernate.test.id.U.class);
		config.addAnnotatedClass(org.hibernate.test.id.TA.class);
		config.addAnnotatedClass(org.hibernate.test.id.PA.class);
		config.addAnnotatedClass(org.hibernate.test.id.UR.class);
		config.addAnnotatedClass(org.hibernate.test.id.UTA.class);
		config.addAnnotatedClass(org.hibernate.test.id.RUTA.class);
		config.secondPassCompile();		
	}

}
