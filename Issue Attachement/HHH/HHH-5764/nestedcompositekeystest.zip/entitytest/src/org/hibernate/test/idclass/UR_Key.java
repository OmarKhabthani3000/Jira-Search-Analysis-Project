package org.hibernate.test.idclass;

import java.io.Serializable;

public class UR_Key implements Serializable {

	private static final long serialVersionUID = 1L;

	private String hasR;
	
	private String belongsToU;

	public String getHasR() {
		return hasR;
	}

	public void setHasR(String hasR) {
		this.hasR = hasR;
	}

	public String getBelongsToU() {
		return belongsToU;
	}

	public void setBelongsToU(String belongsToU) {
		this.belongsToU = belongsToU;
	}
	
}
