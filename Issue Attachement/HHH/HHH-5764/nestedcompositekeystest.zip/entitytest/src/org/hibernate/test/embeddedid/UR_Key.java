package org.hibernate.test.embeddedid;

import java.io.Serializable;
import java.util.Arrays;

import javax.persistence.Embeddable;

@Embeddable
public class UR_Key implements Serializable {

	private static final long serialVersionUID = 1L;

	private String hasR;
	
	private String belongsToU;

	public String getHasR() {
		return hasR;
	}

	public void setHasR(String hasR) {
		this.hasR = hasR;
	}

	public String getBelongsToU() {
		return belongsToU;
	}

	public void setBelongsToU(String belongsToU) {
		this.belongsToU = belongsToU;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || !this.getClass().equals(obj.getClass())) {
			return false;
		}
		UR_Key other = (UR_Key) obj;
		return
			(hasR == other.hasR || hasR != null && hasR.equals(other.hasR)) &&
			(belongsToU == other.belongsToU || belongsToU != null && belongsToU.equals(other.belongsToU));
	}

	@Override
	public int hashCode() {
		return Arrays.hashCode(new Object[] {hasR, belongsToU});
	}

}
