package org.hibernate.test.idclasssub;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
@IdClass(PA_Key.class)
public class PA {
		
	@Id
	@OneToOne(optional=false)
	@JoinColumn(nullable=false)
	private P hasP;
	
	@Id
	@ManyToOne(optional=false)
	@JoinColumns({
		@JoinColumn(nullable=false),
		@JoinColumn(nullable=false)
	})
	private TA belongsToTA;
	
	@Column(length=16)
	private String payload;

	public P getHasP() {
		return hasP;
	}

	public void setHasP(P hasP) {
		this.hasP = hasP;
	}

	public TA getBelongsToTA() {
		return belongsToTA;
	}

	public void setBelongsToTA(TA belongsToTA) {
		this.belongsToTA = belongsToTA;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

}
