package org.hibernate.test.idclass;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
@IdClass(UR_Key.class)
public class UR {
	
	@Id
	@OneToOne(optional=false)
	@JoinColumn(nullable=false)
	private R hasR;
	
	@Id
	@ManyToOne(optional=false)
	@JoinColumn(nullable=false)
	private U belongsToU;
	
	@Column(length=16)
	private String payload;

	public R getHasR() {
		return hasR;
	}

	public void setHasR(R hasR) {
		this.hasR = hasR;
	}

	public U getBelongsToU() {
		return belongsToU;
	}

	public void setBelongsToU(U belongsToU) {
		this.belongsToU = belongsToU;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}
	
}
