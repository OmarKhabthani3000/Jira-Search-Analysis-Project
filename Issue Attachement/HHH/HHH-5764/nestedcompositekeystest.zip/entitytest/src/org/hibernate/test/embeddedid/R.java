package org.hibernate.test.embeddedid;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class R {
	
	@Id
	@Column(length=8, nullable=false)
	private String id;
	
	@OneToMany(mappedBy="belongsToR")
	private Set<RUTA> hasRUTA;
	
	@OneToOne(mappedBy="hasR")
	private UR hasUR;

	@Column(length=16)
	private String payload;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Set<RUTA> getHasRUTA() {
		return hasRUTA;
	}

	public void setHasRUTA(Set<RUTA> hasRUTA) {
		this.hasRUTA = hasRUTA;
	}

	public UR getHasUR() {
		return hasUR;
	}

	public void setHasUR(UR hasUR) {
		this.hasUR = hasUR;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

}
