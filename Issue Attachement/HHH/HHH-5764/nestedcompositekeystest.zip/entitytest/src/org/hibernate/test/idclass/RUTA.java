package org.hibernate.test.idclass;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

@Entity
@IdClass(RUTA_Key.class)
public class RUTA {
	
	@Id
	@ManyToOne(optional=false)
	@JoinColumn(nullable=false)
	private R belongsToR;
	
	@Id
	@ManyToOne(optional=false)
	@JoinColumns({
		@JoinColumn(nullable=false),
		@JoinColumn(nullable=false),
		@JoinColumn(nullable=false),
		@JoinColumn(nullable=false)
	})
	private UTA belongsToUTA;
	
	@Column(length=16)
	private String payload;

	public R getBelongsToR() {
		return belongsToR;
	}

	public void setBelongsToR(R belongsToR) {
		this.belongsToR = belongsToR;
	}

	public UTA getBelongsToUTA() {
		return belongsToUTA;
	}

	public void setBelongsToUTA(UTA belongsToUTA) {
		this.belongsToUTA = belongsToUTA;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

}
