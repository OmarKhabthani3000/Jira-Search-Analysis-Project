package org.hibernate.test.idclass;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
@IdClass(TA_Key.class)
public class TA {
	
	@Id
	@ManyToOne(optional=false)
	@JoinColumn(nullable=false)
	private A belongsToA;
	
	@Id
	@ManyToOne(optional=false)
	@JoinColumn(nullable=false)
	private T belongsToT;
	
	@OneToMany(mappedBy="belongsToTA")
	private Set<PA> hasPA;
	
	@Column(length=16)
	private String payload;

	public A getBelongsToA() {
		return belongsToA;
	}

	public void setBelongsToA(A belongsToA) {
		this.belongsToA = belongsToA;
	}

	public T getBelongsToT() {
		return belongsToT;
	}

	public void setBelongsToT(T belongsToT) {
		this.belongsToT = belongsToT;
	}

	public Set<PA> getHasPA() {
		return hasPA;
	}

	public void setHasPA(Set<PA> hasPA) {
		this.hasPA = hasPA;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

}
