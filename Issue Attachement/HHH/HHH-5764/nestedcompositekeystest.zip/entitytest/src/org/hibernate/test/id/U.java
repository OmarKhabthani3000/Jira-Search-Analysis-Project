package org.hibernate.test.id;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class U {
	
	@Id
	@Column(length=8, nullable=false)
	private String id;
	
	@OneToMany(mappedBy="belongsToU")
	private Set<UR> hasUR;
	
	@OneToMany(mappedBy="belongsToU")
	private Set<UTA> hasUTA;
	
	@Column(length=16)
	private String payload;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Set<UR> getHasUR() {
		return hasUR;
	}

	public void setHasUR(Set<UR> hasUR) {
		this.hasUR = hasUR;
	}

	public Set<UTA> getHasUTA() {
		return hasUTA;
	}

	public void setHasUTA(Set<UTA> hasUTA) {
		this.hasUTA = hasUTA;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}
	
}
