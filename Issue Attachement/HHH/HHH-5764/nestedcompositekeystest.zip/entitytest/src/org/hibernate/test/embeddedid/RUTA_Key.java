package org.hibernate.test.embeddedid;

import java.io.Serializable;
import java.util.Arrays;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;

@Embeddable
public class RUTA_Key implements Serializable {

	private static final long serialVersionUID = 1L;

	private String belongsToR;
	
	@Embedded
	private UTA_Key belongsToUTA;

	public String getBelongsToR() {
		return belongsToR;
	}

	public void setBelongsToR(String belongsToR) {
		this.belongsToR = belongsToR;
	}

	public UTA_Key getBelongsToUTA() {
		return belongsToUTA;
	}

	public void setBelongsToUTA(UTA_Key belongsToUTA) {
		this.belongsToUTA = belongsToUTA;
	}
	
	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || !this.getClass().equals(obj.getClass())) {
			return false;
		}
		RUTA_Key other = (RUTA_Key) obj;
		return
			(belongsToR == other.belongsToR || belongsToR != null && belongsToR.equals(other.belongsToR)) &&
			(belongsToUTA == other.belongsToUTA || belongsToUTA != null && belongsToUTA.equals(other.belongsToUTA));
	}

	@Override
	public int hashCode() {
		return Arrays.hashCode(new Object[] {belongsToR, belongsToUTA});
	}

}
