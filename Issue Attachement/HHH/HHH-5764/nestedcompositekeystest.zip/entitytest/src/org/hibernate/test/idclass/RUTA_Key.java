package org.hibernate.test.idclass;

import java.io.Serializable;

public class RUTA_Key implements Serializable {

	private static final long serialVersionUID = 1L;

	private String belongsToR;
	
	private UTA_Key belongsToUTA;

	public String getBelongsToR() {
		return belongsToR;
	}

	public void setBelongsToR(String belongsToR) {
		this.belongsToR = belongsToR;
	}

	public UTA_Key getBelongsToUTA() {
		return belongsToUTA;
	}

	public void setBelongsToUTA(UTA_Key belongsToUTA) {
		this.belongsToUTA = belongsToUTA;
	}
}
