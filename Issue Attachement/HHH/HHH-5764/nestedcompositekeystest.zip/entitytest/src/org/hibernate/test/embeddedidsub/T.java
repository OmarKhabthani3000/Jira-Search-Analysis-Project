package org.hibernate.test.embeddedidsub;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class T {
	
	@Id
	@Column(length=8, nullable=false)
	private String id;
	
	@OneToMany(mappedBy="belongsToT")
	private Set<TA> hasTA;
	
	@Column(length=16)
	private String payload;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Set<TA> getHasTA() {
		return hasTA;
	}

	public void setHasTA(Set<TA> hasTA) {
		this.hasTA = hasTA;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

}
