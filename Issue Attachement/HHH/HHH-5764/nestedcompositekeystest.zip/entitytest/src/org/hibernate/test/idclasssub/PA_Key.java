package org.hibernate.test.idclasssub;

import java.io.Serializable;

public class PA_Key implements Serializable {

	private static final long serialVersionUID = 1L;

	private long hasP;
	
	private TA_Key belongsToTA;

	public PA_Key() {}
	
	public long getHasP() {
		return hasP;
	}

	public void setHasP(long hasP) {
		this.hasP = hasP;
	}

	public TA_Key getBelongsToTA() {
		return belongsToTA;
	}

	public void setBelongsToTA(TA_Key belongsToTA) {
		this.belongsToTA = belongsToTA;
	}
	
}
