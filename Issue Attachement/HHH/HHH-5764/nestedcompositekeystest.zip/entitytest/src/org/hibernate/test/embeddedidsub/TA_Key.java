package org.hibernate.test.embeddedidsub;

import java.io.Serializable;
import java.util.Arrays;

import javax.persistence.Embeddable;

@Embeddable
public class TA_Key implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer belongsToA;

	private String belongsToT;

	public TA_Key() {}
	
	public Integer getBelongsToA() {
		return belongsToA;
	}

	public void setBelongsToA(Integer belongsToA) {
		this.belongsToA = belongsToA;
	}

	public String getBelongsToT() {
		return belongsToT;
	}

	public void setBelongsToT(String belongsToT) {
		this.belongsToT = belongsToT;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || !this.getClass().equals(obj.getClass())) {
			return false;
		}
		TA_Key other = (TA_Key) obj;
		return
			(belongsToA == other.belongsToA || belongsToA != null && belongsToA.equals(other.belongsToA)) &&
			(belongsToT == other.belongsToT || belongsToT != null && belongsToT.equals(other.belongsToT));
	}

	@Override
	public int hashCode() {
		return Arrays.hashCode(new Object[] {belongsToA, belongsToT});
	}

}
