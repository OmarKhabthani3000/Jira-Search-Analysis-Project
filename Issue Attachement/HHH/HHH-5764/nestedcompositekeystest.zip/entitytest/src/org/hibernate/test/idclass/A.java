package org.hibernate.test.idclass;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class A {
	
	@Id
	@Column(nullable=false, precision=8, scale=0)
	private Integer id;
	
	@OneToMany(mappedBy="belongsToA")
	private Set<TA> hasTA;

	@Column(length=16)
	private String payload;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Set<TA> getHasTA() {
		return hasTA;
	}

	public void setHasTA(Set<TA> hasTA) {
		this.hasTA = hasTA;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

}
