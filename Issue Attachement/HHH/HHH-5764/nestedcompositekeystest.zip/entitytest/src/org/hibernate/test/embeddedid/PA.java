package org.hibernate.test.embeddedid;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;

@Entity
public class PA {
	
	@EmbeddedId
	private PA_Key key;
	
	public PA_Key getKey() {
		return key;
	}

	public void setKey(PA_Key key) {
		this.key = key;
	}

	@MapsId("hasP")
	@OneToOne(optional=false)
	@JoinColumn(nullable=false)
	private P hasP;
	
	@MapsId("belongsToTA")
	@ManyToOne(optional=false)
	@JoinColumns({
		@JoinColumn(nullable=false),
		@JoinColumn(nullable=false)
	})
	private TA belongsToTA;
	
	@OneToOne(mappedBy="hasPA")
	private UTA hasUTA;
	
	@Column(length=16)
	private String payload;

	public P getHasP() {
		return hasP;
	}

	public void setHasP(P hasP) {
		this.hasP = hasP;
	}

	public TA getBelongsToTA() {
		return belongsToTA;
	}

	public void setBelongsToTA(TA belongsToTA) {
		this.belongsToTA = belongsToTA;
	}

	public UTA getHasUTA() {
		return hasUTA;
	}

	public void setHasUTA(UTA hasUTA) {
		this.hasUTA = hasUTA;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

}
