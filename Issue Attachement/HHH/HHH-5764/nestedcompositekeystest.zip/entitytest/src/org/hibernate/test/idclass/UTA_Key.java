package org.hibernate.test.idclass;

import java.io.Serializable;

public class UTA_Key implements Serializable {

	private static final long serialVersionUID = 1L;

	private PA_Key hasPA;
	
	private String belongsToU;

	public PA_Key getHasPA() {
		return hasPA;
	}

	public void setHasPA(PA_Key hasPA) {
		this.hasPA = hasPA;
	}

	public String getBelongsToU() {
		return belongsToU;
	}

	public void setBelongsToU(String belongsToU) {
		this.belongsToU = belongsToU;
	}

}
