package org.hibernate.test.embeddedid;

import java.io.Serializable;
import java.util.Arrays;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;

@Embeddable
public class UTA_Key implements Serializable {

	private static final long serialVersionUID = 1L;

	@Embedded
	private PA_Key hasPA;
	
	private String belongsToU;

	public PA_Key getHasPA() {
		return hasPA;
	}

	public void setHasPA(PA_Key hasPA) {
		this.hasPA = hasPA;
	}

	public String getBelongsToU() {
		return belongsToU;
	}

	public void setBelongsToU(String belongsToU) {
		this.belongsToU = belongsToU;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || !this.getClass().equals(obj.getClass())) {
			return false;
		}
		UTA_Key other = (UTA_Key) obj;
		return
			(hasPA == other.hasPA || hasPA != null && hasPA.equals(other.hasPA)) &&
			(belongsToU == other.belongsToU || belongsToU != null && belongsToU.equals(other.belongsToU));
	}

	@Override
	public int hashCode() {
		return Arrays.hashCode(new Object[] {hasPA, belongsToU});
	}

}
