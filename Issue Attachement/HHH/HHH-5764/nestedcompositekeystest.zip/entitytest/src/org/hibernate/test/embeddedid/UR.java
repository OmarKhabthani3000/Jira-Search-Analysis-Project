package org.hibernate.test.embeddedid;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;

@Entity
public class UR {
	
	@EmbeddedId
	private UR_Key key;
	
	public UR_Key getKey() {
		return key;
	}

	public void setKey(UR_Key key) {
		this.key = key;
	}

	@MapsId("hasR")
	@OneToOne(optional=false)
	@JoinColumn(nullable=false)
	private R hasR;
	
	@MapsId("belongsToU")
	@ManyToOne(optional=false)
	@JoinColumn(nullable=false)
	private U belongsToU;
	
	@Column(length=16)
	private String payload;

	public R getHasR() {
		return hasR;
	}

	public void setHasR(R hasR) {
		this.hasR = hasR;
	}

	public U getBelongsToU() {
		return belongsToU;
	}

	public void setBelongsToU(U belongsToU) {
		this.belongsToU = belongsToU;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}
	
}
