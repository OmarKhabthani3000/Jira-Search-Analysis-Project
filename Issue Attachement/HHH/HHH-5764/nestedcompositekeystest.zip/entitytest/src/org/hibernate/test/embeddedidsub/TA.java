package org.hibernate.test.embeddedidsub;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;

@Entity
public class TA {
	
	@EmbeddedId
	private TA_Key key;
	
	public TA_Key getKey() {
		return key;
	}

	public void setKey(TA_Key key) {
		this.key = key;
	}

	@MapsId("belongsToA")
	@ManyToOne(optional=false)
	@JoinColumn(nullable=false)
	private A belongsToA;
	
	@MapsId("belongsToT")
	@ManyToOne(optional=false)
	@JoinColumn(nullable=false)
	private T belongsToT;
	
	@OneToMany(mappedBy="belongsToTA")
	private Set<PA> hasPA;
	
	@Column(length=16)
	private String payload;

	public A getBelongsToA() {
		return belongsToA;
	}

	public void setBelongsToA(A belongsToA) {
		this.belongsToA = belongsToA;
	}

	public T getBelongsToT() {
		return belongsToT;
	}

	public void setBelongsToT(T belongsToT) {
		this.belongsToT = belongsToT;
	}

	public Set<PA> getHasPA() {
		return hasPA;
	}

	public void setHasPA(Set<PA> hasPA) {
		this.hasPA = hasPA;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

}
