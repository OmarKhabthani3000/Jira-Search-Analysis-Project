package org.hibernate.test.idclass;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
@IdClass(UTA_Key.class)
public class UTA {
	
	@Id
	@OneToOne(optional=false)
	@JoinColumns({
		@JoinColumn(nullable=false),
		@JoinColumn(nullable=false),
		@JoinColumn(nullable=false)
	})
	private PA hasPA;
	
	@Id
	@ManyToOne(optional=false)
	@JoinColumn(nullable=false)
	private U belongsToU;
	
	@OneToMany(mappedBy="belongsToUTA")
	private Set<RUTA> hasRUTA;
	
	@Column(length=16)
	private String payload;

	public PA getHasPA() {
		return hasPA;
	}

	public void setHasPA(PA hasPA) {
		this.hasPA = hasPA;
	}

	public U getBelongsToU() {
		return belongsToU;
	}

	public void setBelongsToU(U belongsToU) {
		this.belongsToU = belongsToU;
	}

	public Set<RUTA> getHasRUTA() {
		return hasRUTA;
	}

	public void setHasRUTA(Set<RUTA> hasRUTA) {
		this.hasRUTA = hasRUTA;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}
	
}
