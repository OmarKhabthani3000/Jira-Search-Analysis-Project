package org.hibernate.test.embeddedid;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

@Entity
public class RUTA {
	
	@EmbeddedId
	private RUTA_Key key;
	
	public RUTA_Key getKey() {
		return key;
	}

	public void setKey(RUTA_Key key) {
		this.key = key;
	}

	@MapsId("belongsToR")
	@ManyToOne(optional=false)
	@JoinColumn(nullable=false)
	private R belongsToR;
	
	@MapsId("belongsToUTA")
	@ManyToOne(optional=false)
	@JoinColumns({
		@JoinColumn(nullable=false),
		@JoinColumn(nullable=false),
		@JoinColumn(nullable=false),
		@JoinColumn(nullable=false)
	})
	private UTA belongsToUTA;
	
	@Column(length=16)
	private String payload;

	public R getBelongsToR() {
		return belongsToR;
	}

	public void setBelongsToR(R belongsToR) {
		this.belongsToR = belongsToR;
	}

	public UTA getBelongsToUTA() {
		return belongsToUTA;
	}

	public void setBelongsToUTA(UTA belongsToUTA) {
		this.belongsToUTA = belongsToUTA;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

}
