package de.test;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.Before;
import org.junit.Test;

import de.test.entities.AlertWithBusinessPartnerSearchDO;
import de.test.entities.AlertWithResponsibleUserDO;
import de.test.entities.BusinessPartnerSearchDO;
import de.test.entities.TeamDO;
import de.test.entities.UserDO;
import de.test.enums.EnumAlertSeverity;

/**
 * Unit test for simple App.
 */
public class AppTest {

    private static final String ORGANISATIONAL_UNIT_1 = "organisationalUnit1";
    private static final Long   BUSINESS_PARTNER_ID   = 1234L;

    private App                 app;

    private long                team1Id;

    @Before
    public void setup() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("defaultPersistenceUnit");
        app = new App(emf);
        EntityManager em = null;
        try {
            em = emf.createEntityManager();
            em.getTransaction().begin();

            UserDO user1 = new UserDO();
            user1.setId(1l);
            user1.setName("user1");
            user1.setLocale(Locale.GERMANY.toString());
            em.persist(user1);

            TeamDO team1 = new TeamDO();
            team1.setName("teamName1");
            team1.setOrganisationalUnit(ORGANISATIONAL_UNIT_1);
            team1.setVirtual(false);
            Set<TeamDO> teamMemberSet = new HashSet<TeamDO>(Arrays.asList(team1));
            team1.setTeamMembers(teamMemberSet);
            em.persist(team1);
            team1Id = team1.getId();

            BusinessPartnerSearchDO businessPartner1 = new BusinessPartnerSearchDO();
            businessPartner1.setBusinessPartnerId(BUSINESS_PARTNER_ID);
            businessPartner1.setAnalyst(ORGANISATIONAL_UNIT_1);
            businessPartner1.setLocale(Locale.GERMANY.toString());
            businessPartner1.setLocaleBpType(Locale.GERMANY.toString());
            businessPartner1.setRatingObjectType("STANDARD");
            em.persist(businessPartner1);

            AlertWithResponsibleUserDO alert1 = new AlertWithResponsibleUserDO();
            alert1.setBusinessPartnerId(BUSINESS_PARTNER_ID);
            alert1.setAlertTime(new Date());
            alert1.setMessageKey("key1");
            // 
            // If you add a responsible user, the inner join returns results. But I dont't want to
            // have the inner join in my query. I just want to have an left outer join.
            // For testing purposes. Just uncomment the next line:
            //
            // alert1.setResponsibleAnalyst(user1);
            // end - test
            alert1.setSeverity(EnumAlertSeverity.RED);
            em.persist(alert1);

            em.getTransaction().commit();
        } finally {
            if (em != null)
                em.close();
        }
    }

    @Test
    public void testManyToOneInnerJoinIssue() {
        List<AlertWithBusinessPartnerSearchDO> list = app.loadAlerts(team1Id);

        // Can you make the test work without uncommenting the line above?
        assertEquals(1, list.size());
    }
}
