package de.test;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import de.test.entities.AlertWithBusinessPartnerSearchDO;
import de.test.entities.AlertWithResponsibleUserDO;
import de.test.enums.EnumAlertSeverity;

public class App {
    private EntityManagerFactory emf;

    public App(EntityManagerFactory emf) {
        this.emf = emf;
    }

    public List<AlertWithBusinessPartnerSearchDO> loadAlerts(long teamId) {
        EntityManager em = null;

        try {
            em = emf.createEntityManager();
            List<AlertWithBusinessPartnerSearchDO> list = em
                    .createNamedQuery(
                            AlertWithBusinessPartnerSearchDO.NAMEDQUERY_LOAD_ALERT_WITH_BUSINESS_PARTNER_SEARCH_BY_TEAM_ID_AND_ALERT_SEVERITY)
                    .setParameter(AlertWithBusinessPartnerSearchDO.PARAM_LOCALE, Locale.GERMANY.toString())
                    .setParameter(AlertWithBusinessPartnerSearchDO.PARAM_LOCALE_BP_TYPE,
                            Locale.GERMANY.toString()).setParameter(
                            AlertWithBusinessPartnerSearchDO.PARAM_ALERT_SEVERITY_LIST,
                            Arrays.asList(EnumAlertSeverity.RED, EnumAlertSeverity.YELLOW,
                                    EnumAlertSeverity.GREEN)).setParameter(
                            AlertWithBusinessPartnerSearchDO.PARAM_TEAM_ID, teamId).getResultList();
            return list;
        } finally {
            if (em != null)
                em.close();
        }
    }
}
