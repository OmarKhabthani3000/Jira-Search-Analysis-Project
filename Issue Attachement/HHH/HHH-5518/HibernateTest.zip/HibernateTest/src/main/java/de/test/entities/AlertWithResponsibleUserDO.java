package de.test.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import de.test.enums.EnumAlertSeverity;

@Entity
@Table(name = "V440_R_ALERTS_WITH_RESP_USER")
@SequenceGenerator(name = "sequenceAlert", sequenceName = "SEQ_T440_PK", allocationSize = 1)
@NamedQueries( { @NamedQuery(name = AlertWithBusinessPartnerSearchDO.NAMEDQUERY_LOAD_ALERT_WITH_BUSINESS_PARTNER_SEARCH_BY_TEAM_ID_AND_ALERT_SEVERITY, query = "select new de.test.entities.AlertWithBusinessPartnerSearchDO(rra.id, rra.messageKey, rra.messageParameters, rra.severity, rra.alertTime, rra.businessPartnerId, bps.businessPartnerName, bps.analyst, rra.responsibleAnalyst) from AlertWithResponsibleUserDO rra, TeamDO t, BusinessPartnerSearchDO bps left join rra.responsibleAnalyst join t.teamMembers tm where rra.businessPartnerId = bps.businessPartnerId and (bps.ratingObjectType = 'STANDARD' or bps.ratingObjectType is null) and bps.analyst = tm.organisationalUnit and t.id = :"
        + AlertWithBusinessPartnerSearchDO.PARAM_TEAM_ID
        + " and rra.severity in (:"
        + AlertWithBusinessPartnerSearchDO.PARAM_ALERT_SEVERITY_LIST
        + ") and bps.locale = :"
        + AlertWithBusinessPartnerSearchDO.PARAM_LOCALE
        + " and bps.localeBpType = :"
        + AlertWithBusinessPartnerSearchDO.PARAM_LOCALE_BP_TYPE) })
public class AlertWithResponsibleUserDO extends AlertBaseDO {

    private static final long  serialVersionUID                               = 7008664013561253781L;

    public static final String PARAM_RISK_ANALYST                             = "riskAnalyst";
    public static final String PARAM_BUSINESS_PARTNER_ID                      = "businessPartnerIdParam";
    public static final String PARAM_ALERT_SEVERITY_LIST                      = "alertSeverityListParam";

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "F440_F004_RESPONSIBLE_USER_ID")
    private UserDO             responsibleAnalyst;

    // Constructors

    /** default constructor */
    public AlertWithResponsibleUserDO() {
    }

    public AlertWithResponsibleUserDO(Long id, String messageKey, String messageParameters,
            EnumAlertSeverity severity, Date alertTime, Long businessPartnerId, UserDO responsibleAnalyst) {
        super();
        setId(id);
        setMessageKey(messageKey);
        setMessageParameters(messageParameters);
        setSeverity(severity);
        setAlertTime(alertTime);
        setBusinessPartnerId(businessPartnerId);
        this.responsibleAnalyst = responsibleAnalyst;
    }

    /**
     * @return the responsibleAnalyst
     */
    public UserDO getResponsibleAnalyst() {
        return responsibleAnalyst;
    }

    /**
     * @param responsibleAnalyst
     *            the responsibleAnalyst to set
     */
    public void setResponsibleAnalyst(UserDO responsibleAnalyst) {
        this.responsibleAnalyst = responsibleAnalyst;
    }
}