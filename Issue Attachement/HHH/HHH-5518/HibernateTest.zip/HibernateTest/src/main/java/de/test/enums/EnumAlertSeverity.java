/**
 * 
 */
package de.test.enums;

/**
 * The severity of a rerating alert. 
 * @author int1740
 *
 */
public enum EnumAlertSeverity {
    // do not change the order of severity
    // because the values are stored in ordinal format in database
    GREEN, YELLOW, RED, 
    /** green if the rating class is unchanged or yellow if it is changed. */
    RERATE_GREEN_OR_YELLOW
}
