package de.test.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "V004_USER")
public class UserDO {

    private static final long  serialVersionUID                                    = 650912506611132593L;

    @Id
    @Column(name = "F004_ID")
    private Long               id;

    @Column(name = "F004_USER")
    private String             userId;

    @Column(name = "F004_LASTNAME")
    private String             name;

    @Column(name = "F004_FIRSTNAME")
    private String             forename;

    @Column(name = "F004_ORGANISATIONAL_UNIT")
    private String             orga;

    @Column(name = "F004_LOCALE")
    private String             locale;



    /**
     * default constructor
     */
    public UserDO() {
        super();
    }



    /**
     * @return the forename
     */
    public String getForename() {
        return forename;
    }


    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }



    /**
     * @return the locale
     */
    public String getLocale() {
        return locale;
    }

  
 
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the orga
     */
    public String getOrga() {
        return orga;
    }


    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param forename
     *            the forename to set
     */
    public void setForename(final String forename) {
        this.forename = forename;
    }


    /**
     * @param id
     *            the id to set
     */
    public void setId(final Long id) {
        this.id = id;
    }

    /**
     * @param locale
     *            the locale to set
     */
    public void setLocale(final String locale) {
        this.locale = locale;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * @param orga
     *            the orga to set
     */
    public void setOrga(final String orga) {
        this.orga = orga;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }
}