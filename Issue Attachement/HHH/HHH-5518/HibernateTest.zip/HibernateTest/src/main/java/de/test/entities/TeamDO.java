package de.test.entities;

import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Cacheable
@Table(name = "V133_PORTFOLIO_TEAM")
@TableGenerator(name="TEAM_SEQ_GEN")
@NamedQuery(name = TeamDO.NAMED_QUERY_FIND_ALL, query = "select t from TeamDO t left join fetch t.teamMembers tm order by t.organisationalUnit asc")
public class TeamDO {

    private static final long  serialVersionUID     = -5160755440004012118L;
    public static final String NAMED_QUERY_FIND_ALL = "TeamDO.findAll";

    @Id
    @GeneratedValue(generator="TEAM_SEQ_GEN")
    @Column(name = "F133_ID", unique = true, nullable = false, precision = 11, scale = 0)
    private Long               id;

    @Column(name = "F133_NAME", nullable = false, length = 100)
    private String             name;

    @Column(name = "F133_RISK_ANALYST", nullable = false, length = 12)
    private String             organisationalUnit;

    @Column(name = "F133_VIRTUAL", nullable = false, precision = 1, scale = 0)
    private Boolean            virtual;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "V134_PORTFOLIO_TEAM_MEMBER", joinColumns = { @JoinColumn(name = "F134_F133_PARENT_TEAM_ID") }, inverseJoinColumns = { @JoinColumn(name = "F134_F133_MEMBER_TEAM_ID") })
    private Set<TeamDO>        teamMembers;

    public Long getId() {
        return id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the organisationalUnit
     */
    public String getOrganisationalUnit() {
        return organisationalUnit;
    }

    /**
     * @param organisationalUnit
     *            the organisationalUnit to set
     */
    public void setOrganisationalUnit(String organisationalUnit) {
        this.organisationalUnit = organisationalUnit;
    }

    /**
     * @return the virtual
     */
    public Boolean getVirtual() {
        return virtual;
    }

    /**
     * @param virtual
     *            the virtual to set
     */
    public void setVirtual(Boolean virtual) {
        this.virtual = virtual;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the teamMembers
     */
    public Set<TeamDO> getTeamMembers() {
        return teamMembers;
    }

    /**
     * @param teamMembers
     *            the teamMembers to set
     */
    public void setTeamMembers(Set<TeamDO> teamMembers) {
        this.teamMembers = teamMembers;
    }
    
    public String toString() {
        return String.format("%s (%s)", organisationalUnit, name); 
    }
}