package de.test.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import de.test.enums.EnumAlertSeverity;


@MappedSuperclass()
public class AlertBaseDO {
    private static final long serialVersionUID = 1L;

    public AlertBaseDO() {
        super();
    }

    public AlertBaseDO(Long id, String messageKey, String messageParameters,
            EnumAlertSeverity severity, Date alertTime, String checkUser, Date checkedDate,
            Date suppressedSince, Date fixedSince, String preRatingClass,
            Double preRatingRiskPoints, String postRatingClass, Double postRatingRiskPoints,
            Long businessPartnerId, Long ratingTemplateId, String jobType) {
        super();
        this.id = id;
        this.messageKey = messageKey;
        this.messageParameters = messageParameters;
        this.severity = severity;
        this.alertTime = alertTime;
        this.businessPartnerId = businessPartnerId;

    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    @Column(name = "F440_ID", unique = true, nullable = false, precision = 11, scale = 0)
    private Long               id;

    @Column(name = "F440_MESSAGE_KEY", nullable = false, length = 256)
    private String             messageKey;

    @Column(name = "F440_MESSAGE_PARAMETERS", length = 4000)
    private String             messageParameters;

    @Enumerated
    @Column(name = "F440_SEVERITY")
    private EnumAlertSeverity  severity;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "F440_ALERT_TIME")
    private Date               alertTime;



    @Column(name = "F440_BUSINESS_PARTNER_ID", nullable = false, precision = 11, scale = 0)
    private Long               businessPartnerId;


    // Property accessors
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMessageKey() {
        return this.messageKey;
    }

    public void setMessageKey(String messageKey) {
        this.messageKey = messageKey;
    }

    public String getMessageParameters() {
        return this.messageParameters;
    }

    public void setMessageParameters(String messageParameters) {
        this.messageParameters = messageParameters;
    }

    public EnumAlertSeverity getSeverity() {
        return this.severity;
    }

    public void setSeverity(EnumAlertSeverity state) {
        this.severity = state;
    }

    public Date getAlertTime() {
        return this.alertTime;
    }

    public void setAlertTime(Date timestamp) {
        this.alertTime = timestamp;
    }

    public Long getBusinessPartnerId() {
        return this.businessPartnerId;
    }

    public void setBusinessPartnerId(Long businessPartnerId) {
        this.businessPartnerId = businessPartnerId;
    }
}
