package de.test.entities;

import java.util.Date;

import de.test.enums.EnumAlertSeverity;

public class AlertWithBusinessPartnerSearchDO extends AlertWithResponsibleUserDO {

    private static final long  serialVersionUID                                                                 = -3473338172632002607L;
    public static final String NAMEDQUERY_LOAD_ALERT_WITH_BUSINESS_PARTNER_SEARCH_BY_TEAM_ID_AND_ALERT_SEVERITY = "AlertWithBusinessPartnerSearchDO.loadByTeamIdAndAlertSeverity";

    public static final String PARAM_TEAM_ID                                                                    = "teamIdParam";
    public static final String PARAM_TEAM_MEMBER_ID                                                             = "teamMemberIdParam";
    public static final String PARAM_LOCALE                                                                     = "localeParam";
    public static final String PARAM_LOCALE_BP_TYPE                                                             = "localeBpTypeParam";

    private String             ratingUnit;

    private String             businessPartnerName;

    private Date               ratingValidUntil;

    private Long               groupId;

    private String             riskAnalyst;

    // ---------------------------------------------------------------
    // Constructors
    // ---------------------------------------------------------------
    public AlertWithBusinessPartnerSearchDO() {
        super();
    }

    public AlertWithBusinessPartnerSearchDO(Long id, String messageKey, String messageParameters,
            EnumAlertSeverity severity, Date alertTime, Long businessPartnerId,
            UserDO responsibleAnalyst) {
        super(id, messageKey, messageParameters, severity, alertTime, businessPartnerId,
                responsibleAnalyst);
    }

    public AlertWithBusinessPartnerSearchDO(Long id, String messageKey, String messageParameters,
            EnumAlertSeverity severity, Date alertTime, Long businessPartnerId,
            String businessPartnerName, String riskAnalyst, UserDO responsibleAnalyst) {
        super(id, messageKey, messageParameters, severity, alertTime, businessPartnerId,
                responsibleAnalyst);
        this.businessPartnerName = businessPartnerName;
        this.riskAnalyst = riskAnalyst;
    }

    /**
     * @return the ratingUnit
     */
    public String getRatingUnit() {
        return ratingUnit;
    }

    /**
     * @param ratingUnit
     *            the ratingUnit to set
     */
    public void setRatingUnit(String ratingUnit) {
        this.ratingUnit = ratingUnit;
    }

    /**
     * @return the businessPartnerName
     */
    public String getBusinessPartnerName() {
        return businessPartnerName;
    }

    /**
     * @param businessPartnerName
     *            the businessPartnerName to set
     */
    public void setBusinessPartnerName(String businessPartnerName) {
        this.businessPartnerName = businessPartnerName;
    }

    /**
     * @return the ratingValidUntil
     */
    public Date getRatingValidUntil() {
        return ratingValidUntil;
    }

    /**
     * @param ratingValidUntil
     *            the ratingValidUntil to set
     */
    public void setRatingValidUntil(Date ratingValidUntil) {
        this.ratingValidUntil = ratingValidUntil;
    }

    /**
     * @return the groupNumber
     */
    public Long getGroupId() {
        return groupId;
    }

    /**
     * @param groupId
     *            the groupNumber to set
     */
    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    /**
     * @return the riskAnalyst
     */
    public String getRiskAnalyst() {
        return riskAnalyst;
    }

    /**
     * @param riskAnalyst
     *            the riskAnalyst to set
     */
    public void setRiskAnalyst(String riskAnalyst) {
        this.riskAnalyst = riskAnalyst;
    }
}
