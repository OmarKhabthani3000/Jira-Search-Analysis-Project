package de.test.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "V000_BUSINESS_PARTNER_SEARCH")
@TableGenerator(name="BUSINESS_PARTNER_SEARCH_SEQ")
public class BusinessPartnerSearchDO {

    private static final long  serialVersionUID                       = -3858431195254193033L;

    @Id
    @GeneratedValue(generator="BUSINESS_PARTNER_SEARCH_SEQ")
    @Column(name = "F000_ID")
    private Long               id;

    @Column(name = "F000_TYPE")
    private String             businessPartnerType;

    @Column(name = "F000_NAME")
    private String             businessPartnerTypeName;

    @Column(name = "F000_BUSINESS_PARTNER_ID")
    private Long               businessPartnerId;

    @Column(name = "F000_BUSINESS_PARTNER_NAME")
    private String             businessPartnerName;

    @Column(name = "F000_RISK_ANALYST")
    private String             analyst;

    @Column(name = "F006_LOCALE", length = 5, columnDefinition = "char(5)")
    private String             locale;

    @Column(name = "LOCALE_BP_TYPE")
    private String             localeBpType;

    @Column(name = "F401_F114_RATING_OBJECT_TYPE")
    private String             ratingObjectType;

    /**
     * default constructor
     */
    public BusinessPartnerSearchDO() {
        super();
    }

    /**
     * @see de.westlb.f4ja.persistence.entities.AbstractEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final Long id) {
        this.id = id;
    }

      /**
     * @return the businessPartnerTypeName
     */
    public String getBusinessPartnerTypeName() {
        return businessPartnerTypeName;
    }

    /**
     * @param businessPartnerTypeName
     *            the businessPartnerTypeName to set
     */
    public void setBusinessPartnerTypeName(final String businessPartnerTypeName) {
        this.businessPartnerTypeName = businessPartnerTypeName;
    }

    /**
     * @return the localeBpTypeOuter
     */
    public String getLocaleBpType() {
        return localeBpType;
    }

    /**
     * @param localeBpTypeOuter
     *            the localeBpTypeOuter to set
     */
    public void setLocaleBpType(final String localeBpType) {
        this.localeBpType = localeBpType;
    }

    /**
     * @return the businessPartnerId
     */
    public Long getBusinessPartnerId() {
        return businessPartnerId;
    }

    /**
     * @param businessPartnerId
     *            the businessPartnerId to set
     */
    public void setBusinessPartnerId(final Long businessPartnerId) {
        this.businessPartnerId = businessPartnerId;
    }

    /**
     * @return the businessPartnerName
     */
    public String getBusinessPartnerName() {
        return businessPartnerName;
    }

    /**
     * @param businessPartnerName
     *            the businessPartnerName to set
     */
    public void setBusinessPartnerName(final String businessPartnerName) {
        this.businessPartnerName = businessPartnerName;
    }

    /**
     * @return the businessPartnerType
     */
    public String getBusinessPartnerType() {
        return businessPartnerType;
    }

    /**
     * @param businessPartnerType
     *            the businessPartnerType to set
     */
    public void setBusinessPartnerType(final String businessPartnerType) {
        this.businessPartnerType = businessPartnerType;
    }

    /**
     * @return the riskAnalyst
     */
    public String getAnalyst() {
        return analyst;
    }

    /**
     * @param riskAnalyst
     *            the riskAnalyst to set
     */
    public void setAnalyst(final String riskAnalyst) {
        analyst = riskAnalyst;
    }

    /**
     * @return the locale
     */
    public String getLocale() {
        return locale;
    }

    /**
     * @param locale
     *            the locale to set
     */
    public void setLocale(final String locale) {
        this.locale = locale;
    }

    /**
     * @return the ratingObjectType
     */
    public String getRatingObjectType() {
        return ratingObjectType;
    }

    /**
     * @param ratingObjectType
     *            the ratingObjectType to set
     */
    public void setRatingObjectType(String ratingObjectType) {
        this.ratingObjectType = ratingObjectType;
    }
}