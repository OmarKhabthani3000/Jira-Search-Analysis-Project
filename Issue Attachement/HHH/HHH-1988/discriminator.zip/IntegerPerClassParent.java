package ru.arptek.arpsite.data.discriminator;

import javax.persistence.*;

import ru.arptek.arpsite.data.DefaultSealedObject;

@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.INTEGER)
public class IntegerPerClassParent extends DefaultSealedObject {
    private int type;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
