package ru.arptek.arpsite.data.discriminator;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("1")
public class IntegerSingleChild extends IntegerSingleParent {

}
