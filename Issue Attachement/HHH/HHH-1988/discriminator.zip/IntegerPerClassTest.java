package ru.arptek.arpsite.data.discriminator;

import org.hibernate.ejb.Ejb3Configuration;

import ru.arptek.arpsite.data.AbstractHibernateJUnitTest;

public class IntegerPerClassTest extends AbstractHibernateJUnitTest {

    @Override
    protected void entityConfiguration(Ejb3Configuration cfg) {
        cfg.addAnnotatedClass(IntegerPerClassParent.class);
        cfg.addAnnotatedClass(IntegerPerClassChild.class);
    }

    public void test() {
        // just test is it possible to load
    }
}
