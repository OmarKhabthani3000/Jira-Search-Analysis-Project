package ru.arptek.arpsite.data.discriminator;

import org.hibernate.ejb.Ejb3Configuration;

import ru.arptek.arpsite.data.AbstractHibernateJUnitTest;

public class IntegerSingleTest extends AbstractHibernateJUnitTest {

    @Override
    protected void entityConfiguration(Ejb3Configuration cfg) {
        cfg.addAnnotatedClass(IntegerSingleParent.class);
        cfg.addAnnotatedClass(IntegerSingleChild.class);
    }

    public void test() {
        // just test is it possible to load
    }
}
