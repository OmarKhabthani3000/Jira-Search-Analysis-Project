package com.cyclone.hibernate;

import org.hibernate.Session;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

public class EvictTest extends BaseCoreFunctionalTestCase
{
    @Override
    protected String[] getXmlFiles()
    {
        return new String[]
        {"mappings.xml"};
    }

    // @Override
    // protected Class< ? >[] getAnnotatedClasses()
    // {
    // return new Class[]
    // {A.class, B.class};
    // }

    @Test
    public void evictCascade_entityReferencedMoreThanOnce()
    {
        Session session = openSession();
        session.beginTransaction();

        B b = new B();
        A a = new A();

        a.setB1(b);
        a.setB2(b);

        session.save("A", a);
        session.flush();

        session.evict(a);

        session.getTransaction().commit();
        session.close();

        session = openSession();
        session.beginTransaction();
        session.delete("A", a);
        session.getTransaction().commit();
        session.close();
    }
}
