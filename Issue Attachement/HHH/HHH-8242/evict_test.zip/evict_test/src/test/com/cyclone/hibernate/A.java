package com.cyclone.hibernate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Cascade;

@Entity(name = "A")
public class A
{
    @Id
    private int id;

    @ManyToOne(cascade =
    {CascadeType.ALL})
    private B b1;

    @ManyToOne(cascade =
    {CascadeType.ALL})
    private B b2;

    /**
     * @return the b1
     */
    public B getB1()
    {
        return b1;
    }

    /**
     * @param a_b1 the b1 to set
     */
    public void setB1(B a_b1)
    {
        b1 = a_b1;
    }

    /**
     * @return the b2
     */
    public B getB2()
    {
        return b2;
    }

    /**
     * @param a_b2 the b2 to set
     */
    public void setB2(B a_b2)
    {
        b2 = a_b2;
    }

}
