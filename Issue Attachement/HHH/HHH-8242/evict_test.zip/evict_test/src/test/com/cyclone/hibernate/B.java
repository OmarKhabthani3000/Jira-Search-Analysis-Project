package com.cyclone.hibernate;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "B")
public class B
{
    @Id
    private int id;
}
