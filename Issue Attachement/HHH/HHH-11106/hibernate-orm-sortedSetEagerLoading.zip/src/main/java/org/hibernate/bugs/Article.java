package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Article implements Comparable<Article> {

    @Id
    @GeneratedValue
    private Long id;

    private Long pages;

    @ManyToOne(fetch = FetchType.EAGER, targetEntity = Book.class)
    private Book book;

    protected Article() {  //JPA only
    }

    public Article(Long pages) {
        this.pages = pages;
    }

    @Override
    public int compareTo(Article o) {
        if (o.getPages() > this.getPages()) {
            return -1;
        } else if (o.getPages() < this.getPages()) {
            return 1;
        } else {
            return 0;
        }
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public Long getId() {
        return id;
    }

    public Long getPages() {
        return pages;
    }

    public void setPages(Long pages) {
        this.pages = pages;
    }

}
