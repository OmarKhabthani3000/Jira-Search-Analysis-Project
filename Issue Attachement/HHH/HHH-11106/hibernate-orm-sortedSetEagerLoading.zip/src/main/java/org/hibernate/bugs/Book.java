package org.hibernate.bugs;

import java.util.Collection;
import java.util.SortedSet;
import java.util.TreeSet;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import org.hibernate.annotations.SortNatural;

@Entity
public class Book {

    @Id
    @GeneratedValue
    private Long id;

    private String title;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "book", targetEntity = Article.class)
    @SortNatural
    private SortedSet<Article> articles;

    protected Book() { //JPA only
    }

    public Book(String title) {
        this.articles = new TreeSet<>();
        this.title = title;
    }

    public Long getId() {
        return id;
    }

    public Collection<Article> getArticles() {
        return this.articles;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void addArticle(Article article) {
        article.setBook(this);
        this.articles.add(article);
    }

}
