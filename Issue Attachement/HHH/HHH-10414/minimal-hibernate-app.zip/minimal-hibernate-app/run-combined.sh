#!/bin/sh
java -Xmx1g -cp dist/lib/mini-hibernate-app-standalone.jar com.corefiling.example.RunHibernate
