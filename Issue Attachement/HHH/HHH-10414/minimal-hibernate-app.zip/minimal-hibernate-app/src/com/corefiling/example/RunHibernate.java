package com.corefiling.example;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.hibernate.cfg.AvailableSettings;
import org.hibernate.jpa.HibernatePersistenceProvider;

/** */
public class RunHibernate {

  private static final String DATABASE_NAME = "db";
  private static final String USER_NAME = "user";
  private static final String PASSWORD = "pass";

  public static void main(final String[] args) {
    int i = 0;
    while (true) {
      exerciseHibernate();
      System.out.println(++i);
    }
  }

  public static void exerciseHibernate() {
    Map<String, Object> configOverrides = new LinkedHashMap<>();
    configOverrides.put(AvailableSettings.HBM2DDL_AUTO, "none");
    configOverrides.put("javax.persistence.jdbc.driver", "org.postgresql.Driver");
    configOverrides.put("javax.persistence.jdbc.url", "jdbc:postgresql://localhost/" + DATABASE_NAME);
    configOverrides.put("javax.persistence.jdbc.user", USER_NAME);
    configOverrides.put("javax.persistence.jdbc.password", PASSWORD);

    final EntityManagerFactory emf = new HibernatePersistenceProvider().createEntityManagerFactory("com.corefiling.example", configOverrides);
    emf.close();
  }
}
