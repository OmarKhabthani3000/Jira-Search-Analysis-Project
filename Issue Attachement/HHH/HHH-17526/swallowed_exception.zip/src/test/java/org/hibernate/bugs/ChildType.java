package org.hibernate.bugs;

public enum ChildType {
    TYPE_ONE,
    TYPE_TWO
}
