package org.hibernate.bugs;

import jakarta.persistence.*;
import org.hibernate.annotations.BatchSize;

@Entity
@BatchSize(size = 500)
public class Child {
    @Id
    @GeneratedValue
    private Long id;

    @Enumerated(value = EnumType.STRING)
    private ChildType type;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ChildType getType() {
        return type;
    }

    public void setType(ChildType type) {
        this.type = type;
    }
}
