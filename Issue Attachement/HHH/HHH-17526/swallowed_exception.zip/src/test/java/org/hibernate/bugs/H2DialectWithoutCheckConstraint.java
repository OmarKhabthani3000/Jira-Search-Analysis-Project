package org.hibernate.bugs;

import org.hibernate.dialect.H2Dialect;

public class H2DialectWithoutCheckConstraint extends H2Dialect {
    @Override
    public String getCheckCondition(String columnName, Class<? extends Enum<?>> enumType) {
        return null;
    }
}
