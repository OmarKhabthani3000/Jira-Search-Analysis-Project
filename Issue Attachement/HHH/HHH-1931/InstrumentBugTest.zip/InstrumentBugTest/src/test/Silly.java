package test;

public class Silly {

    public String value;

}
