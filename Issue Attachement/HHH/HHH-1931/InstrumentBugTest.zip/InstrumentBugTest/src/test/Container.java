package test;

import java.util.Set;
import java.util.HashSet;

public class Container {
    public Long id;
    public String name;
    public Set items = new HashSet();

    public Container() {
    }

    public Container(String name) {
        this.name = name;
    }

    public void doSillyThing(Silly silly) {
        silly.value = "true";
    }

}
