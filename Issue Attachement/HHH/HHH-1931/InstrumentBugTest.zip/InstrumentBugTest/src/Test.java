import test.Container;
import test.Silly;
import test.Item;
import org.hibernate.Transaction;
import org.hibernate.Session;
import org.hibernate.Hibernate;
import org.hibernate.proxy.HibernateProxy;
import junit.framework.TestCase;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

public class Test extends TestCase {

    public static void main(String[] args) {
        Test test = new Test();
        test.testCreate();
        test.testManyToMany();
        HibernateUtil.sessionFactory.close();
    }

    public void testCreate() {
        Session session = HibernateUtil.currentSession();
        Transaction tx = session.beginTransaction();
        List containerIds = new ArrayList();
        for (int i = 0; i < 10; ++i) {
            Container container = new Container("#" + i);
            session.save(container);
            Silly silly = new Silly();
            container.doSillyThing(silly);
            // rely on using a pre-determinable id generation...
            containerIds.add( container.id );
        }
        tx.commit();
        HibernateUtil.closeSession();

        session = HibernateUtil.currentSession();
        tx = session.beginTransaction();
        // load a container...
        Container container = ( Container ) session.get( Container.class, ( Long ) containerIds.get(0) );
        assertFalse( Hibernate.isInitialized( container ) );
        Hibernate.initialize( container );
        assertTrue( Hibernate.isInitialized( container ) );
        assertNotNull( container.name );
        assertTrue( Hibernate.isPropertyInitialized( container, "name" ) );
        Iterator ids = containerIds.iterator();
        while ( ids.hasNext() ) {
            session.delete( session.load( Container.class, ( Long ) ids.next() ) );
        }
        tx.commit();
        HibernateUtil.closeSession();
    }


    public void testManyToMany() {
        Session session = HibernateUtil.currentSession();
        Transaction tx = session.beginTransaction();
        Container container = new Container( "many-to-many" );
        container.items.add( new Item( "item1" ) );
        container.items.add( new Item( "item2" ) );
        container.items.add( new Item( "item3" ) );
        Item item4 = new Item( "item4" );
        container.items.add( item4 );
        session.save( container );
        tx.commit();
        Long someItemId = item4.getId();
        HibernateUtil.closeSession();

        // first load all items via the collection
        session = HibernateUtil.currentSession();
        tx = session.beginTransaction();
        container = (Container) session.load( Container.class, container.id );
        Iterator itr = container.items.iterator();
        while ( itr.hasNext() ) {
            Item item = ( Item ) itr.next();
            assertTrue( Hibernate.isInitialized( item ) );
            assertFalse( item instanceof HibernateProxy );
        }
        tx.commit();
    }
}
