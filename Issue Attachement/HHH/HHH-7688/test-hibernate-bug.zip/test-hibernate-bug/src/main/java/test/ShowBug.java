package test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Assert;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate4.SessionHolder;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;

public class ShowBug
{
    public static void main(String[] args) throws Exception
    {
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("persistence.xml");

        final SessionFactory sf = ctx.getBean(SessionFactory.class);

        final TransactionTemplate tt = ctx.getBean(TransactionTemplate.class);

        Session session = sf.openSession();
        System.err.println(session.hashCode());

        TransactionSynchronizationManager.bindResource(sf, new SessionHolder(session));

        tt.execute(new TransactionCallback<Object>() {
            public Object doInTransaction(TransactionStatus status)
            {
                Session session = sf.getCurrentSession();
                System.err.println(session.hashCode());
                TestEntity1 te1 = new TestEntity1();
                te1.setId(1);

                session.save(te1);

                TestEntity2 te2 = new TestEntity2();
                te2.setId(1);
                te2.setTe1(te1);

                session.save(te2);

                session.flush();
                return null;
            }
        });

        try
        {
            tt.execute(new TransactionCallback<Object>() {
                public Object doInTransaction(TransactionStatus status)
                {
                    Session session = sf.getCurrentSession();
                    System.err.println(session.hashCode());
                    TestEntity1 toDelete = (TestEntity1) session.get(TestEntity1.class, 1);
                    session.delete(toDelete);
                    session.flush();
                    return null;
                }
            });

            Assert.fail("Delete must not succeed beause of constraints!");
        }
        catch (Exception ex)
        {

        }

        // This fails:
        tt.execute(new TransactionCallback<Object>() {
            public Object doInTransaction(TransactionStatus status)
            {
                Session session = sf.getCurrentSession();
                System.err.println(session.hashCode());
                System.err.println(session.get(TestEntity1.class, 1));
                TestEntity1 te1 = new TestEntity1();
                te1.setId(2);

                session.save(te1);
                session.flush();
                return null;
            }
        });

        /**
         * Description of the problem:
         * 
         * - we have a pre-bound session (as in OpenSessionInViewFilter) - there
         * are multiple transactions - one transaction fails - the transaction
         * manager disconnects the session (this is also true if the transaction
         * succeeds - so it should not be a problem) - according the docs
         * reconnecting should be done by transaction management - all following
         * transactions fail
         * 
         * In AbstractBatchImpl: try { doExecuteBatch(); } finally {
         * releaseStatements(); }
         * 
         * Statements are released within the same Transaction (ensured via
         * try...finally)
         * 
         * In NonBatchingBatch: try { [...] final int rowCount =
         * statement.executeUpdate(); [...] } catch ( SQLException e ) {
         * LOG.debug( "SQLException escaped proxy", e ); throw
         * sqlExceptionHelper().convert( e, "could not execute batch statement",
         * entry.getKey() ); } getStatements().clear();
         * 
         * Problems with this implementation: - Statements are not released here
         * - Statements are not closed if the query fails (resource leak!) -
         * statement.clearBatch() is never called (not sure if this matters. at
         * least in AbstractBatchImpl it is called) - Statements are not removed
         * from the list
         * 
         * In the next transaction (which succeeds), releaseStatements() is
         * called which fails because the proxy is not valid anymore.
         * 
         * Solution:
         * Fix the method NonBatchingBatch.addToBatch() as in attached NonBatchingBatch_fixed.java 
         * 
         * Details:
         * - move all the close/release stuff outside of the loop
         * - put the loop in a "try" block
         * - in the "finally" block call super.releaseStatements()
         * - in AbstractBatchImpl make releaseStatements() protected instead of private
         *   (this should really be done to avoid dupplicate code)
         * 
         * 
         */

    }

}
