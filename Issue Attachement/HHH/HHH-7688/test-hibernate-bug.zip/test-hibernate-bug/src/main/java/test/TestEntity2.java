package test;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="te2")
public class TestEntity2
{
    protected int id;
    
    @Id
    public int getId()
    {
        return id;
    }
    
    public void setId(int id)
    {
        this.id = id;
    }
    
    protected TestEntity1 te1;
    
    @ManyToOne
    public TestEntity1 getTe1()
    {
        return te1;
    }
    public void setTe1(TestEntity1 te1)
    {
        this.te1 = te1;
    }
}
