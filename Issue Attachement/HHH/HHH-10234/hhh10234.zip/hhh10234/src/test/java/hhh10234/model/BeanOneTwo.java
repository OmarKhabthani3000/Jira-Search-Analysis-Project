package hhh10234.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name = "primary_table")
@SecondaryTable(name = "secondary_table")
public class BeanOneTwo implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer id;
    
	private String one;
	private String two;

	@Id
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column
    public String getOne() {
        return one;
    }

    public void setOne(String one) {
        this.one = one;
    }

	@Column(table = "secondary_table")
    public String getTwo() {
        return two;
    }

    public void setTwo(String two) {
        this.two = two;
    }
}
