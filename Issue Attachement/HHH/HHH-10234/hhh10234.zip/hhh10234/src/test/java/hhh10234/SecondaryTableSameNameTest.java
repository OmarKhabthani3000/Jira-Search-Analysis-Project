/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package hhh10234;

import hhh10234.model.BeanOneTwoNamedX;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * @author Burkhard Graves
 */
public class SecondaryTableSameNameTest extends BaseCoreFunctionalTestCase {
    
    private final static Integer ID = 1;

    @Override
    protected Class<?>[] getAnnotatedClasses() {
        return new Class[] {
            BeanOneTwoNamedX.class
        };
    }

    @Before
    public void before() {
        try (Session s = openSession()) {
            Transaction tx = s.beginTransaction();
            
            BeanOneTwoNamedX b = new BeanOneTwoNamedX();
            b.setId(ID);
            b.setOne("one");
            b.setTwo("two");

            s.save(b);
            tx.commit();
        }
    }

    @After
    public void after() {

        try (Session s = openSession()) {
            Transaction tx = s.beginTransaction();

            s.delete(getBean(s));

            tx.commit();
        }
    }
    
    private BeanOneTwoNamedX getBean(Session s) {
        return s.load(BeanOneTwoNamedX.class, ID);
    }
    
    /*
     * Fails due to incorrect update statement:
     *
     * update
     *     primary_table 
     * set
     *     x=x 
     * where
     *     (
     *         id
     *     ) IN (
     *         select
     *             id 
     *         from
     *             HT_primary_table
     *     )
     */
    @Test
    public void testUpdateOne() throws Exception {

        try (Session s = openSession()) {
            Transaction tx = s.beginTransaction();

            int updatedEntities = s.createQuery("update BeanOneTwoNamedX b set b.one=b.two").executeUpdate();

            tx.commit();

            Assert.assertEquals(1, updatedEntities);
        }

        try (Session s = openSession()) {
            Transaction tx = s.beginTransaction();

            BeanOneTwoNamedX b = getBean(s);

            Assert.assertEquals("two", b.getTwo() );
            Assert.assertEquals("two", b.getOne());

            tx.commit();
        }
    }

    /*
     * Fails due to incorrect update statement:
     *
     * update
     *     secondary_table 
     * set
     *     x=x 
     * where
     *     (
     *         id
     *     ) IN (
     *         select
     *             id 
     *         from
     *             HT_primary_table
     *     )
     */
    @Test
    public void testUpdateTwo() throws Exception {

        try (Session s = openSession()) {
            Transaction tx = s.beginTransaction();
            
            int updatedEntities = s.createQuery("update BeanOneTwoNamedX b set b.two=b.one").executeUpdate();

            tx.commit();

            Assert.assertEquals(1, updatedEntities);
        }

        try (Session s = openSession()) {
            Transaction tx = s.beginTransaction();

            BeanOneTwoNamedX b = getBean(s);

            Assert.assertEquals("one", b.getOne());
            Assert.assertEquals("one", b.getTwo());

            tx.commit();
        }
    }
}
