/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.tenplanets.ejb3test.data;

import javax.ejb.Local;


/**
 *
 * @author vadim
 */
@Local
public interface EmailFacadeLocal {
    
             

    void create(Email email);

    void edit(Email email);

    void remove(Email email);

    void delete(Object id);

    Email find(Object id);

  
}
