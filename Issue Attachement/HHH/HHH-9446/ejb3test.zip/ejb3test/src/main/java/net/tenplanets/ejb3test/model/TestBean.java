/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.tenplanets.ejb3test.model;

import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import net.tenplanets.ejb3test.data.Email;
import net.tenplanets.ejb3test.data.EmailFacadeLocal;

/**
 *
 * @author Vadims Zemlanojs <vadim@tenplanets.net>
 */
@ManagedBean(name = "TestBean")
//@Named("TestBean")
@RequestScoped
public class TestBean {

    @EJB(beanName = "EmailFacade")
    private EmailFacadeLocal emailFacade;

    public void preRender() {

    }

    public void test(ActionEvent e) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
         
        try {
            Email em = emailFacade.find(23322);  
           
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO,em.toString(), " email ");
            
            facesContext.addMessage(null, msg);

        } catch (Exception ex) {

            
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO,ex.getMessage(), ex.getClass().getName());
           
            facesContext.addMessage(null, msg);
           
              Logger.getLogger("net.tenplanets.ejb3test.data").log(Level.SEVERE, null, ex);
          
        }

    }

}
