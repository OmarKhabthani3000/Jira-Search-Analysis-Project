/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.tenplanets.ejb3test.data;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;


/**
 *
 * @author vadim
 */
@Entity
//@Cacheable(true)
@Table(name = "EMAILS")
public class Email  implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final int ARCHIVE = 1;
    public static final int DELETED = 2;//Reserved
    public static final int DRAFT = 4;//Reserved
   
   

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + (this.emailId != null ? Objects.hashCode(this.emailId) : super.hashCode());
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Email other = (Email) obj;

        if (this.emailId == null) {
            return super.equals(obj);
        } else if (!Objects.equals(this.emailId, other.emailId)) {
            return false;
        }



        return true;
    }

    @Override
    public String toString() {
        return "net.tenplanets.webmailer.data.Email[ id=" + email + " ]";
    }
    
 
    @Id
    @Column(name = "EMAILID", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer emailId;

    public Integer getEmailId() {
        return emailId;
    }

    public void setEmailId(Integer id) {
        this.emailId = id;
    }
    
   
    
    @Column(name = "EMAIL")
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;

    }
    @Column(name = "MASK")
    private Long mask;

    public Long getMask() {
        return mask;
    }

    public void setMask(Long mask) {
        this.mask = mask;       
    }
    @Column(name = "CONTEXT") 
    private String content;
    
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = (content == null || (content = content.trim()).equals("")) ? null : content;
    }
    @Column(name = "SUBJECT")
    private String subject;

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
    @Column(name = "TM")
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date lastUpdated;

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
    @Column(name = "RECTYPE")
    private int options;

    public int getOptions() {
        return options;
    }

    public void setOptions(int options) {
        this.options = options;
    }
    @Column(name = "DT")
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date lastUsed;

    public Date getLastUsed() {
        return lastUsed;
    }

    public void setLastUsed(Date lastUsed) {
        this.lastUsed = lastUsed;
    }


   

   
}
