/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.tenplanets.ejb3test.data;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


/**
 *
 * @author vadim
 */

@Stateless
//@Transactional(propagation = Propagation.REQUIRES_NEW)
public class EmailFacade extends AbstractFacade<Email> implements EmailFacadeLocal {

    @PersistenceContext(unitName = "main")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {          
        return em; 
    }

    public EmailFacade() {
        super(Email.class);
        
    }
    
   
}
