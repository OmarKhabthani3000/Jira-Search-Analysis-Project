/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.tenplanets.ejb3test.data;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.criteria.Root;
import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.Metamodel;

/**
 *
 * @author vadim
 * @param <T>
 */
//@Transactional(propagation = Propagation.REQUIRES_NEW)
public abstract class AbstractFacade<T> {

    private final Class<T> entityClass;

    public AbstractFacade(Class<T> entityClass) {
        this.entityClass = entityClass;
    }

    protected abstract EntityManager getEntityManager();

    public void create(T entity) {
        getEntityManager().persist(entity);

    }

    public void edit(T entity) {
        getEntityManager().merge(entity);
    }

    public void remove(T entity) {
        getEntityManager().remove(getEntityManager().merge(entity));
    }

    public void delete(Object id) {
        T obj = find(id);
        if (obj != null) {
            getEntityManager().remove(obj);
        }
    }

    public T find(Object id) {
        T t = getEntityManager().find(entityClass, id);
     
         Logger.getLogger("net.tenplanets.ejb3test.data").log(Level.INFO, "Equality of class names: {0}", (t.getClass().getCanonicalName().equals(entityClass.getCanonicalName())));
         Logger.getLogger("net.tenplanets.ejb3test.data").log(Level.INFO, "Equality of class loaders: {0}", (t.getClass().getClassLoader()==entityClass.getClassLoader()));
         Logger.getLogger("net.tenplanets.ejb3test.data").log(Level.INFO, "Class loaders: {0}  {1}", new Object[]{t.getClass().getClassLoader().toString(), entityClass.getClassLoader().toString()});
        return t;
    }

}
