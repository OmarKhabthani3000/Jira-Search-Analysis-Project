package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import org.junit.Test;

public class TestBug {
    
    @Test
    public void test() {
    	
    	 EntityManager em = Persistence.createEntityManagerFactory("test").createEntityManager();

    }
    

    
    
    
    

}
