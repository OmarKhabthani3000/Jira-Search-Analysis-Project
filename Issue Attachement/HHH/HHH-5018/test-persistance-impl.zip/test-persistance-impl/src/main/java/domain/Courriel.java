package domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity Courriel
 * 
 * @author cmalosse
 */
@Entity
@Table(name = "COURRIEL")
public class Courriel implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

	private int oid;
	private String libelle;
	private String adresse;

    /**
     * Constructeur par d�faut
     */
    public Courriel() {
        super();
    }
    
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "OID", nullable = false)
	public int getOid() {
		return this.oid;
	}

	public void setOid(int oid) {
		this.oid = oid;
	}

	@Column(name = "LIBELLE")
	public String getLibelle() {
		return this.libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	@Column(name = "ADRESSE")
	public String getAdresse() {
		return this.adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
}
