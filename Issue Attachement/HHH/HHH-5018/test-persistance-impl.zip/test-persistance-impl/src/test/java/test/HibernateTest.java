package test;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.classic.Session;

/**
 * Classe de test Hibernate et JDBC
 * 
 * @author cmalosse
 * 
 */
public class HibernateTest extends HibernateUnitTest {

	private static final Logger LOGGER = Logger.getLogger(HibernateTest.class);

	/**
	 * Test Cast Function in select clause
	 * TEST NOK in ClassicQueryTranslatorFactory
	 * TEST NOK in ASTQueryTranslatorFactory
	 */
	@SuppressWarnings("unchecked")
	public void testHQLCast() {
		StringBuilder hqlQuery = new StringBuilder("select cast(c.oid as varchar(100)) from Courriel c");
		try {
			Session session = hibernateTemplate.getSessionFactory().getCurrentSession();
			Query query = session.createQuery(hqlQuery.toString());
			List<String> list = query.list();
			assertFalse(list.isEmpty());
		} catch (Exception e) {
			LOGGER.error("Hibernate Error : " + e);
			fail("Hibernate Error");
		}
	}

	/**
	 * Test Cast Function in where clause
	 * TEST NOK in Classic QueryTranslatorFactory
	 * TEST NOK in Classic ASTQueryTranslatorFactory
	 */
	@SuppressWarnings("unchecked")
	public void testHQLCastWhere() {
		StringBuilder hqlQuery = new StringBuilder("select c.libelle from Courriel c where c.adresse =  cast('test@test.com' as varchar(100))");
		try {
			Session session = hibernateTemplate.getSessionFactory().getCurrentSession();		
			Query query = session.createQuery(hqlQuery.toString());
			List<String> list = query.list();
			assertFalse(list.isEmpty());
		} catch (Exception e) {
			LOGGER.error("Hibernate Error : " + e);
			fail("Hibernate Error");
		}
	}
	
	/**
	 * Test Cast Function in where clause and param
	 * 
	 * TEST OK in Classic QueryTranslatorFactory
	 * TEST NOK in Classic ASTQueryTranslatorFactory
	 */
	@SuppressWarnings("unchecked")
	public void testHQLCastWhereParam() {
		StringBuilder hqlQuery = new StringBuilder("select c.libelle from Courriel c where c.adresse =  cast(? as varchar(100))");
		try {
			Session session = hibernateTemplate.getSessionFactory().getCurrentSession();		
			Query query = session.createQuery(hqlQuery.toString());
			query.setString(0, "test@test.com");
			List<String> list = query.list();
			assertFalse(list.isEmpty());
		} catch (Exception e) {
			LOGGER.error("Hibernate Error : " + e);
			fail("Hibernate Error");
		}
	}
}