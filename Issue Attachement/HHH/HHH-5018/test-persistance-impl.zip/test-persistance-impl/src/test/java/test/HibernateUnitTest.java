package test;

import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.test.AbstractDependencyInjectionSpringContextTests;
import org.springframework.transaction.interceptor.DefaultTransactionAttribute;

/**
 * Class: HibernateUnitTest
 */
public abstract class HibernateUnitTest extends AbstractDependencyInjectionSpringContextTests {

	protected HibernateTransactionManager transactionManager;
	public void setTransactionManager(HibernateTransactionManager transactionManager) { this.transactionManager = transactionManager;}
	
	protected HibernateTemplate hibernateTemplate;
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) { this.hibernateTemplate = hibernateTemplate; }	
	
	@Override
	protected void onSetUp() throws Exception {
		transactionManager.getTransaction(new DefaultTransactionAttribute());
	}
	
	@Override
	protected String[] getConfigLocations() {
		return new String[] { "classpath:persistanceContext.xml", "classpath:dataSourceContext.xml",};
	}	
}