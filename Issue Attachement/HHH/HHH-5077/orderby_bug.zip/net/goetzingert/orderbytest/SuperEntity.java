/**
 * 
 */
package net.goetzingert.orderbytest;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

/**
 * @author goetzingert
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class SuperEntity
{

  @Id
  protected int id;
  protected int position = 0;

}
