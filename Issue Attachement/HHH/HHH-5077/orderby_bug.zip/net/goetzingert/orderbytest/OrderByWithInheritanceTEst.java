package net.goetzingert.orderbytest;

/**
 * 
 */

import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author goetzingert
 */
public class OrderByWithInheritanceTEst
{

  private static EntityManager entityManager;
  private static ClientEntity  entity;

  /**
   * @throws java.lang.Exception
   */
  @BeforeClass
  public static void setUp() throws Exception
  {
    entityManager = Persistence.createEntityManagerFactory("testPU").createEntityManager();
    entityManager.getTransaction().begin();
    entity = new ClientEntity(1);
    entity.addChild(new ChildEntity(1));
    entityManager.persist(entity);
    entityManager.flush();
    entityManager.getTransaction().commit();
    entityManager.clear();
  }

  @Test
  public void testFind()
  {
    ClientEntity find = entityManager.find(ClientEntity.class, 1);
    assertEquals(1, find.childs.size());
  }

  @Test
  public void testQuery()
  {
    ClientEntity find = (ClientEntity) entityManager.createNamedQuery("test").getResultList().get(0);
    assertEquals(1, find.childs.size());
  }

  @AfterClass
  public static void after()
  {
    entityManager.getTransaction().begin();
    entityManager.remove(entity);
    entityManager.getTransaction().commit();
    entityManager.close();
  }
}
