/**
 * 
 */
package net.goetzingert.orderbytest;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;

import luft.progrzlw.gafccis.util.collections.ArrayList;

/**
 * @author goetzingert
 */
@NamedQuery(name = "test", query = "SELECT e from ClientEntity e LEFT JOIN FETCH e.childs")
@Entity
public class ClientEntity
    extends SuperEntity
{

  /**
   * @param string
   */
  public ClientEntity(int id)
  {
    this.id = id;
  }

  @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "parent_id")
  @OrderBy("position")
  List<ChildEntity> childs = new ArrayList<ChildEntity>();

  /**
   * @param childEntity
   */
  public void addChild(ChildEntity childEntity)
  {
    childEntity.position = this.childs.size();
    childs.add(childEntity);
  }

}
