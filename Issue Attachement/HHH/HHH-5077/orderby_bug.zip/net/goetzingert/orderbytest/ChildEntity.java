/**
 * 
 */
package net.goetzingert.orderbytest;

import javax.persistence.Entity;

/**
 * @author goetzingert
 */
@Entity
public class ChildEntity
    extends SuperEntity
{

  /**
   * @param i
   * @param j
   */
  public ChildEntity(int i)
  {
    super.id = id;
  }

}
