import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test
{
    public static void main(String[] args)
    {
        SessionFactory factory = new Configuration().configure().buildSessionFactory();
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        Slave slave = new Slave();
        slave.setOid(1);
        session.save(slave);
        Master master = new Master();
        master.setSlave(slave);
        session.save(master);
        Query query;
        query = session.createQuery("select master from Master master where master.slave2 is null");
        System.out.println("Requete avec is null");
        for (Object object : query.list())
        {
            System.out.println(object);
        }
        query = session.createQuery("select master from Master master where master.slave2.oid is null");
        System.out.println("Requete avec is null sur oid");
        for (Object object : query.list())
        {
            System.out.println(object);
        }
        tx.commit();
        session.close();
    }
}
