public class Master
{
    private Integer oid;
    private String libelle;
    private Slave slave;

    public String getLibelle()
    {
        return libelle;
    }

    public void setLibelle(String aLibelle)
    {
        libelle = aLibelle;
    }

    public Integer getOid()
    {
        return oid;
    }

    public void setOid(Integer aOid)
    {
        oid = aOid;
    }

    public Slave getSlave()
    {
        return slave;
    }

    public void setSlave(Slave aSlave)
    {
        slave = aSlave;
    }

    private Slave2 slave2;

    public Slave2 getSlave2()
    {
        return slave2;
    }

    public void setSlave2(Slave2 aSlave2)
    {
        slave2 = aSlave2;
    }
}
