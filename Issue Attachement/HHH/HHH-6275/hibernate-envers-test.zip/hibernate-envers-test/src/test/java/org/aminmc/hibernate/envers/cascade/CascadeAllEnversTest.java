package org.aminmc.hibernate.envers.cascade;


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.query.AuditEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static junit.framework.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:app-context.xml")
public class CascadeAllEnversTest {

    @Autowired
    private HibernateTemplate hibernateTemplate;

    @Autowired
    private TransactionTemplate transactionTemplate;

    @Test
    public void canOnlyGetAuditEntryForClassAUpdate() {

        final ClassA  classA = new ClassA();
        classA.setObjectId(UUID.randomUUID().toString());

        final ClassB classB = new ClassB();
        classB.setName("TEST");
        classB.setValue("VALUE");

        classA.add(classB);

        transactionTemplate.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus transactionStatus) {
                hibernateTemplate.save(classA);
            }
        });


        assertAuditCountFor(classB, 1);

         transactionTemplate.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus transactionStatus) {
                ClassA childOfClassA = new ClassA();
                childOfClassA.setObjectId(UUID.randomUUID().toString());
                classA.getChildren().add(childOfClassA);
                hibernateTemplate.update(classA);
            }
        });

        assertAuditCountFor(classB, 1);

    }

    private void assertAuditCountFor(final ClassB classB, final int count) {

        hibernateTemplate.execute(new HibernateCallback<Object>() {
            @Override
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
                AuditReader reader = AuditReaderFactory.get(session);
                List<Object> rawResults = reader.createQuery().forRevisionsOfEntity(ClassB.class, false, true)
                                            .add(AuditEntity.property("originalId.id").in(Collections.singleton(classB.getId()))).getResultList();

                assertEquals(count, rawResults.size());
                return null;
            }
        });

    }


}
