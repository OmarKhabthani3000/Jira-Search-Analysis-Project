package testdb;

import javax.ejb.Local;

@Local
public interface TestBean {

    public void doNothing();
}
