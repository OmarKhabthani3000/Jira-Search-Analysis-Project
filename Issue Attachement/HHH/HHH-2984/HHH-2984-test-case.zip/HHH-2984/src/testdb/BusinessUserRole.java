package testdb;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class BusinessUserRole {
    Long id;
    Business business;
    User user;
    String role;
    boolean removed;
    
    @GeneratedValue @Id
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    
    @ManyToOne(cascade=CascadeType.PERSIST, optional=false)
    public Business getBusiness() {
        return business;
    }
    public void setBusiness(Business business) {
        this.business = business;
    }
    @ManyToOne(cascade=CascadeType.PERSIST, optional=false)
    public User getUser() {
        return user;
    }
    public void setUser(User user) {
        this.user = user;
    }
    @Column(nullable=false)
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }
    public BusinessUserRole(Business business, User user, String role) {
        this.business = business;
        this.user = user;
        this.role = role;
    }
    
    public BusinessUserRole() {
    }
    public boolean isRemoved() {
        return removed;
    }
    public void setRemoved(boolean removed) {
        this.removed = removed;
    }
}
