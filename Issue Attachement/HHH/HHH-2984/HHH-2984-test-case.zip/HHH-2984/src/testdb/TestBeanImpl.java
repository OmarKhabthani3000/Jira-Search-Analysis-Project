package testdb;

import javax.ejb.Stateless;

@Stateless
public class TestBeanImpl implements TestBean {

    @Override
    public void doNothing() {
    }
}
