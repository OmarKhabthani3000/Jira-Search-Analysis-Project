package testdb;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Business {
    Long id;
    ContactInformation contactInformation;
    boolean removed;
    
    public Business() {
    }
    public Business(ContactInformation contactInformation) {
        this.contactInformation = contactInformation;
    }
    
    @GeneratedValue @Id
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    
    @OneToOne(cascade=CascadeType.PERSIST)
    public ContactInformation getContactInformation() {
        return contactInformation;
    }
    public void setContactInformation(ContactInformation contactInformaion) {
        this.contactInformation = contactInformaion;
    }
    public boolean isRemoved() {
        return removed;
    }
    public void setRemoved(boolean removed) {
        this.removed = removed;
    }
}
