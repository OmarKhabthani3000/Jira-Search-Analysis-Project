package testdb;

import javax.persistence.EntityManager;

import com.bm.testsuite.BaseSessionBeanFixture;


public class RunQuery extends BaseSessionBeanFixture<TestBeanImpl> {
    public RunQuery() {
        super(TestBeanImpl.class, new Class[] {
          User.class, Business.class, BusinessUserRole.class, ContactInformation.class 
        });
    }
    public void testRunQuery() {
        EntityManager em = getEntityManager();
        User u1 = new User();
        em.persist(u1);
        Business b1 = new Business(new ContactInformation("b1"));
        em.persist(b1);
        Business b2 = new Business(new ContactInformation("b2"));
        em.persist(b2);
        BusinessUserRole bur1 = new BusinessUserRole(b1, u1, "a");
        em.persist(bur1);
        BusinessUserRole bur2 = new BusinessUserRole(b2, u1, "a");
        em.persist(bur2);
        BusinessUserRole bur3 = new BusinessUserRole(b2, u1, "b");
        em.persist(bur3);
        em.createQuery("select distinct bur.business from BusinessUserRole bur " +
        		"where bur.user = :user and bur.removed = false and bur.business.removed = false " +
        		"order by bur.business.contactInformation.name ASC, bur.id ASC")
        .setParameter("user", u1)
        .getResultList();
    }
}
