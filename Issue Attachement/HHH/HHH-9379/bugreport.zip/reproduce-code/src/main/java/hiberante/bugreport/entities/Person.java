package hiberante.bugreport.entities;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "PERSON")
@SequenceGenerator(
		name = "personSequence",
		sequenceName = "PERSON_ID_SEQ",
		initialValue = 1,
		allocationSize = 1
)
public class Person {

	@Id
	@Column(name = "PERSON_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "personSequence")
	private Long id;
	
	@Column(name = "NAME")
	private String name;
	
	@Basic(fetch = FetchType.LAZY)
	@Lob
	@Column(name = "PHOTO")
	private byte[] photo;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}
}
