package hibernate.bugreport.test;

import hiberante.bugreport.entities.Person;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.hibernate.jpa.HibernatePersistenceProvider;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class BugReportTest {

	private static EntityManagerFactory entityManagerFactory;
	
	@BeforeClass
	public static void initClass() {
		entityManagerFactory = 
				new HibernatePersistenceProvider()
				.createEntityManagerFactory("main", null);
		EntityManager em = entityManagerFactory.createEntityManager();
		try {
			Person person = new Person();
			person.setName("Logan");
			em.getTransaction().begin();
			try {
				em.persist(person);
			} catch (RuntimeException | Error ex) {
				em.getTransaction().rollback();
				throw ex;
			}
			em.getTransaction().commit();
		} finally {
			em.close();
		}
	}
	
	@AfterClass
	public static void disposeClass() {
		EntityManagerFactory emf = entityManagerFactory;
		if (emf != null) {
			entityManagerFactory.close();
			emf = null;
		}
	}
	
	@Test
	public void testMergeDetach() {
		Person person = new Person();
		person.setId(1L);
		person.setName("Crazy Logan");
		person.setPhoto(new byte[] { 11, 22, 33, 44, 55, 66, 77, 88, 99 });
		
		EntityManager em = entityManagerFactory.createEntityManager();
		try {
			em.getTransaction().begin();
			try {
				em.merge(person);
			} catch (RuntimeException | Error ex) {
				em.getTransaction().rollback();
				throw ex;
			}
			em.getTransaction().commit();
		} finally {
			em.close();
		}
	}
}
