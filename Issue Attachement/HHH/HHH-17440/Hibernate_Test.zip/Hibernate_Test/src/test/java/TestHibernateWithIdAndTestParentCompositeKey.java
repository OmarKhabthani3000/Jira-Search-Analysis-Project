
import java.io.Serializable;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;

import org.hibernate.Session;

import junit.framework.TestCase;

public class TestHibernateWithIdAndTestParentCompositeKey extends TestCase {
	private EntityManager entityManager;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("persistence_provider",
				null);
		entityManager = entityManagerFactory.createEntityManager();
		entityManager.setFlushMode(FlushModeType.COMMIT);
		entityManager.getTransaction().begin();
	}

	/**
	 * 
	 */
	public void testSaveParentThenSaveChild() {
		TestParent testParent = new TestParent();
		testParent.setId(new Random().nextLong());
		entityManager.persist(testParent);
		entityManager.flush();

		TestChild testChild = new TestChild();
		testChild.setId(new Random().nextLong());
		testChild.setTestParent(testParent.clone()); // Note that we clone the parent because in complex situations we might not have the same exact instance
		entityManager.persist(testChild);
		entityManager.flush(); // This fails with 5.6.15.Final
		
		assertEquals("The composite id key should be able to find the element from cache", true,
				isCached(testChild.getClass(), testChild.getIdAndTestParentCompositeKey()));
	}
	
	/**
	 * @param id
	 * @return boolean
	 */
	public boolean isCached(Class<?> clazz, Serializable id) {
		return ((Session) entityManager.getDelegate()).getSessionFactory().getCache().containsEntity(clazz, id);
	}

	@Override
	protected void tearDown() throws Exception {
		if (entityManager.getTransaction().isActive()) {
			entityManager.getTransaction().rollback();
		}

		super.tearDown();
	}
}
