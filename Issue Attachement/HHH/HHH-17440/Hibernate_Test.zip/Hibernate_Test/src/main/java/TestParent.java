import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class TestParent implements Cloneable {
	@Id
	private Long id;

	public static class IdAndTestParentCompositeKey implements Serializable {
		private Long id;
		private TestParent testParent;
		
		/**
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {
			return Objects.hash(id, getTestParentIdSafely());
		}

		/**
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(final Object obj) {
			if (this == obj) {
				return true;
			}

			if (obj == null) {
				return false;
			}

			if (getClass() != obj.getClass()) {
				return false;
			}

			return Objects.equals(id, ((IdAndTestParentCompositeKey) obj).id)
					&& Objects.equals(getTestParentIdSafely(), ((IdAndTestParentCompositeKey) obj).getTestParentIdSafely());
		}

		/**
		 * @return Long
		 */
		public Long getTestParentIdSafely() {
			return (testParent != null) ? testParent.getId() : null;
		}

		/**
		 * @return the id
		 */
		public Long getId() {
			return id;
		}

		/**
		 * @param id the id to set
		 */
		public void setId(Long id) {
			this.id = id;
		}

		/**
		 * @return the testParent
		 */
		public TestParent getTestParent() {
			return testParent;
		}

		/**
		 * @param testParent the testParent to set
		 */
		public void setTestParent(TestParent testParent) {
			this.testParent = testParent;
		}
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	@Override
	protected TestParent clone() {
		try {
			return (TestParent) super.clone();
		} catch (CloneNotSupportedException e) {
			throw new IllegalStateException(e);
		}
	}
}
