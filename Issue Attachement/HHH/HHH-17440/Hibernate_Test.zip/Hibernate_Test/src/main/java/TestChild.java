import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@IdClass(TestParent.IdAndTestParentCompositeKey.class)
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class TestChild {
	@Id
	private Long id;
	@Id // @see IdAndTestParent
	@Fetch(FetchMode.SELECT)
	@ManyToOne(optional = false)
	private TestParent testParent;
	
	/**
	 * @return the testParent
	 */
	public TestParent getTestParent() {
		return testParent;
	}
	/**
	 * @param testParent the testParent to set
	 */
	public void setTestParent(TestParent testParent) {
		this.testParent = testParent;
	}
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return TestParent.IdAndTestParentCompositeKey
	 */
	public TestParent.IdAndTestParentCompositeKey getIdAndTestParentCompositeKey() {
		TestParent.IdAndTestParentCompositeKey idAndTestParentCompositeKey = new TestParent.IdAndTestParentCompositeKey();
		idAndTestParentCompositeKey.setId(getId());
		idAndTestParentCompositeKey.setTestParent(getTestParent());
		return idAndTestParentCompositeKey;
	}
}
