package issue.domain;

import javax.persistence.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Policy {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    protected long id = 0;

    @Column(unique = true)
    private String name;

    @ManyToMany(targetEntity = Role.class, cascade = {
            CascadeType.PERSIST, CascadeType.MERGE
    })
    @JoinTable(name = "POLICY_ROLE", joinColumns = @JoinColumn(name = "POLICY_ID"), inverseJoinColumns = @JoinColumn(name = "ROLE_ID"))
    @OrderBy("name")
    private Set<Role> roles = new HashSet<Role>();

    public Policy(String name) {
        this.name = name;
    }

    public Policy() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }

    public void addRoles(Collection<Role> newRoles) {
        for (Role role : newRoles) {
            addRole(role);
        }
    }

    public void addRole(Role role) {
        roles.add(role);
        role.getPolicies().add(this);
    }
}
