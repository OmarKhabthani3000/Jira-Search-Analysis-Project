package issue.domain;

import javax.persistence.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    protected long id = 0;

    @Column(unique = true)
    private String name;

    @ManyToMany(targetEntity = Policy.class, mappedBy = "roles")
    @OrderBy("name")
    private Set<Policy> policies = new HashSet<Policy>();

    public Role(String name) {
        this.name = name;
    }

    public Role() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Policy> getPolicies() {
        return policies;
    }

    public void setPolicies(Set<Policy> policies) {
        this.policies = policies;
    }

    public void addPolicies(Collection<Policy> newPolicies) {
        for (Policy policy : newPolicies) {
            addPolicy(policy);
        }
    }

    public void addPolicy(Policy policy) {
        policies.add(policy);
        policy.getRoles().add(this);
    }
}
