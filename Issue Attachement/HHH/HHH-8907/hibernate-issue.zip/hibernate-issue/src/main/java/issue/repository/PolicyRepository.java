package issue.repository;

import issue.domain.Policy;
import issue.domain.Role;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.Collection;

public class PolicyRepository {
    private EntityManager entityManager;

    public PolicyRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @SuppressWarnings("unchecked")
    public Collection<Policy> findNotLinked(Role role) {
        Query query =
                entityManager.createQuery("SELECT p FROM Policy p WHERE :role not in (p.roles) order by p.name")
                             .setParameter("role", role);

        return query.getResultList();
    }
}
