package issue.repository;

import issue.domain.Policy;
import issue.domain.Role;
import org.junit.After;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.sql.DriverManager;
import java.util.Collection;

import static org.fest.assertions.Assertions.assertThat;

public class PolicyRepositoryTest {

    private PolicyRepository repository;

    private Role role1;
    private Role role2;
    private Role role3;
    private EntityManager entityManager;
    private EntityManagerFactory factory;

    private void setUp(String persistenceUnitName) throws Exception {
        factory = Persistence.createEntityManagerFactory(persistenceUnitName);
        entityManager = factory.createEntityManager();

        repository = new PolicyRepository(entityManager);

        entityManager.getTransaction().begin();

        role1 = new Role("role_1");
        role2 = new Role("role_2");
        role3 = new Role("role_3");

        Policy policy1 = new Policy("policy_1");
        Policy policy2 = new Policy("policy_2");
        Policy policy3 = new Policy("policy_3");
        Policy policy4 = new Policy("policy_4");
        Policy policy5 = new Policy("policy_5");

        persistAndRefresh(role1, role2, role3, policy1, policy2, policy3, policy4, policy5);

        role1.addPolicy(policy1);
        role1.addPolicy(policy2);
        role2.addPolicy(policy3);
        role3.addPolicy(policy4);

        entityManager.getTransaction().commit();
    }

    private void persistAndRefresh(Object... entities) {
        for (Object entity : entities) {
            entityManager.persist(entity);
        }

        entityManager.flush();

        for (Object entity : entities) {
            entityManager.refresh(entity);
        }
    }

    @After
    public void tearDown() throws Exception {
        entityManager.close();
        factory.close();
    }

    @Test
    public void testFindNotLinked_hsqldb() throws Exception {
        setUp("persistence-unit-hsqldb");
        Collection<Policy> result = repository.findNotLinked(role1);
        assertThat(result).containsOnly(role2, role3);
    }

    @Test
    public void testFindNotLinked_derby() throws Exception {
        Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
        DriverManager.getConnection("jdbc:derby:memory:testdb;create=true").close();

        setUp("persistence-unit-derby");

        Collection<Policy> result = repository.findNotLinked(role1);
        assertThat(result).containsOnly(role2, role3);
    }

    @Test
    public void testFindNotLinked_h2() throws Exception {
        setUp("persistence-unit-h2");
        Collection<Policy> result = repository.findNotLinked(role1);
        assertThat(result).containsOnly(role2, role3);
    }

}
