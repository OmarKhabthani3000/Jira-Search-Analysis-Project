create table test_login_info (id int primary key, login varchar(30), pass varchar(30));
create table test_client (id int primary key, name varchar(30), info_id int);