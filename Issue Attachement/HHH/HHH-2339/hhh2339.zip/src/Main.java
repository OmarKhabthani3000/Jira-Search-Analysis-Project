import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class Main
{

  /**
   * @param args
   */
  public static void main( String[] args )
  {
    BasicConfigurator.configure();
    Logger.getRootLogger().setLevel( Level.WARN );
    Logger.getLogger( "org.hibernate" ).setLevel( Level.INFO );
    Logger.getLogger( "org.hibernate.cache" ).setLevel( Level.OFF );
    Logger.getLogger( "org.hibernate.pretty.Printer" ).setLevel( Level.INFO );
    Logger.getLogger( "net.sf.ehcache" ).setLevel( Level.OFF );
    Logger.getLogger( "org.hibernate.tuple" ).setLevel( Level.OFF );
    Logger.getLogger( "org.hibernate.connection" ).setLevel( Level.OFF );
    Logger.getLogger( "org.hibernate.cfg" ).setLevel( Level.INFO );
    Logger.getLogger( "org.hibernate.cache.EhCache" ).setLevel( Level.OFF );
    Logger.getLogger( "org.hibernate.SQL" ).setLevel( Level.DEBUG );
    Logger.getLogger( "org.hibernate.cache.EhCacheProvider" ).setLevel( Level.OFF );
    
    Configuration configuration = new Configuration();
    configuration.addURL( Main.class.getResource( "hibernate.cfg.xml" ) );
    configuration.configure();
    SessionFactory sf = configuration.buildSessionFactory();
    
//    Session s1 = sf.openSession();
//    s1.beginTransaction();
//    Client c = new Client();
//    c.setInfo( new LoginInfo() );
//    c.getInfo().setLogin( "login" );
//    c.getInfo().setPass( "pass" );
//    c.setName( "Alex Black" );
//    s1.persist( c.getInfo() );
//    s1.persist( c );
//    s1.flush();
//    s1.getTransaction().commit();
//    s1.close();
    Session s1 = sf.openSession();
    s1.beginTransaction();
    Client c = ( Client ) s1.get( Client.class, 2l );
    s1.flush();
    s1.getTransaction().commit();
    s1.close();
    
    Session s2 = sf.openSession();
    s2.beginTransaction();
    c =  ( Client ) s2.merge( c );
    s2.flush();
    s2.getTransaction().commit();
    s2.close();
    
    
  }

}
