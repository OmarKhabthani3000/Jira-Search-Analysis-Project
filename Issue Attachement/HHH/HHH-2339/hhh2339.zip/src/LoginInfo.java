
public class LoginInfo
{
  private long id;
  
  private String login;
  
  private String pass;

  public String getLogin()
  {
    return login;
  }

  public void setLogin( String login )
  {
    this.login = login;
  }

  public String getPass()
  {
    return pass;
  }

  public void setPass( String pass )
  {
    this.pass = pass;
  }

  public long getId()
  {
    return id;
  }

  public void setId( long id )
  {
    this.id = id;
  }
}
