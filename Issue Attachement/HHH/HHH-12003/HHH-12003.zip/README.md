# HHH-12003
HHH-12003: incoherent em.persist() behavior [validation vs statement generation]
