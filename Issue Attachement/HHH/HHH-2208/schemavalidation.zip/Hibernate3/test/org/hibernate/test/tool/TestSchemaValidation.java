package org.hibernate.test.tool;

import java.sql.Connection;
import java.sql.Statement;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.TestCase;
import org.hibernate.tool.hbm2ddl.SchemaValidator;

/**
 * @author Anthony
 * we assume that a default schema is defined in Hibernate global configuration
 *
 */
public class TestSchemaValidation extends TestCase{
	
	public void testSchemaValidator() {
		try{
			new SchemaValidator(getCfg()).validate();
			Session session = openSession();
			Connection conn = session.connection();
			Statement stmt = conn.createStatement();
			stmt.executeUpdate("drop TABLE TEAM ");
			stmt.close();
			session.close();
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}
	
	public TestSchemaValidation(String arg0) {
		super(arg0);
	}
	
	public String[] getMappings() {
		return new String[] {"tool/Team.hbm.xml"};
	}

	public static Test suite() {
		return new TestSuite(TestSchemaValidation.class);
	}
	
	public static void main(String[] args) throws Exception {
		TestRunner.run( suite() );
	}
	
	// we need the same table name in both schemas
	protected void setUp() throws Exception {
		super.setUp();
		Session session = openSession();
		Connection conn = session.connection();
		Statement stmt = conn.createStatement();
		stmt.executeUpdate("CREATE TABLE TEAM " +
	      "(test VARCHAR2(40))" );
		stmt.close();
		session.close();
	}
	
}
