package org.hibernate.bugs.model;

public enum ReferenceType {
  BAR_X,
  BAR_Y
}
