package org.hibernate.bugs.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Fee implements Reference {

  @Column
  @Id
  @GeneratedValue
  private Long id;
}
