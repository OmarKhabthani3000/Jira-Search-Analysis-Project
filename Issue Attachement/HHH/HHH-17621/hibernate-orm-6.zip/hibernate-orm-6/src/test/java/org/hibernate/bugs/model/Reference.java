package org.hibernate.bugs.model;

import java.io.Serializable;

public interface Reference extends Serializable {}
