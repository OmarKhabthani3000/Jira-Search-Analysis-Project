package org.hibernate.bugs.model;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import org.hibernate.annotations.Any;
import org.hibernate.annotations.AnyDiscriminator;
import org.hibernate.annotations.AnyDiscriminatorValue;
import org.hibernate.annotations.AnyKeyJavaClass;

@Entity
public class InvoicePosition {

  @Column
  @Id
  @GeneratedValue
  private Long id;

  public Invoice getInvoice() {
    return invoice;
  }

  public void setInvoice(Invoice invoice) {
    this.invoice = invoice;
  }

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "InvoiceId", nullable = false)
  private Invoice invoice;

  @Any
  @AnyDiscriminator(DiscriminatorType.STRING)
  @AnyDiscriminatorValue(discriminator = "BONUS", entity = Bonus.class)
  @AnyDiscriminatorValue(discriminator = "FEE", entity = Fee.class)
  @AnyKeyJavaClass(Long.class)
  @Column(name = "Type")
  @JoinColumn(name = "ReferenceId")
  private Reference reference;

  public Reference getReference() {
    return reference;
  }

  public void setReference(Reference reference) {
    this.reference = reference;
  }
}
