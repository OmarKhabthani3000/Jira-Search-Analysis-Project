package org.hibernate.bugs.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import java.util.ArrayList;
import java.util.List;

@Entity
public class InvoiceBatch {

  @Column
  @Id
  @GeneratedValue
  private Long id;

  public List<Invoice> getInvoices() {
    return invoices;
  }

  public void setInvoices(List<Invoice> invoices) {
    this.invoices = invoices;
  }

  @OneToMany(mappedBy = "invoiceBatch", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private List<Invoice> invoices = new ArrayList<>();

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void addInvoice(Invoice invoice) {
    invoices.add(invoice);
    invoice.setInvoiceBatch(this);
  }
}
