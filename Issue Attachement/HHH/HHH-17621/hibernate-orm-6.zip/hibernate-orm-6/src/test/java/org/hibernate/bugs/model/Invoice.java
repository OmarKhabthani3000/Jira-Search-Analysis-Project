package org.hibernate.bugs.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Invoice {

  @Column
  @Id
  @GeneratedValue
  private Long id;

  public InvoiceBatch getInvoiceBatch() {
    return invoiceBatch;
  }

  public void setInvoiceBatch(InvoiceBatch invoiceBatch) {
    this.invoiceBatch = invoiceBatch;
  }

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "InvoiceBatchId", nullable = false)
  private InvoiceBatch invoiceBatch;

  @OneToMany(mappedBy = "invoice", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private List<InvoicePosition> invoicePositions = new ArrayList<>();

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void addInvoicePosition(InvoicePosition invoicePosition) {
    invoicePositions.add(invoicePosition);
    invoicePosition.setInvoice(this);
  }
}
