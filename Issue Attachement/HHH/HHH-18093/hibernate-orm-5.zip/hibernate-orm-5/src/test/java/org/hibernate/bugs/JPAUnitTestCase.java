package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Persistence;


import org.hibernate.annotations.Type;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		// Do stuff...
		entityManager.getTransaction().commit();
		entityManager.close();
	}

	public class Recipient {
		private String type;

		public Recipient() {

		}

		public Recipient(String type) {
			this.type = type;
		}
	}

	public class GlassRecipient {
		private String type;

		public GlassRecipient() {
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}
	}

	public class GlassRecipientWrapper extends Recipient {
		private GlassRecipient recipient;

		public GlassRecipientWrapper() {
			super();
		}

		public GlassRecipientWrapper(GlassRecipient recipient, String type) {
			super(type);
			this.recipient = recipient;
		}

		public GlassRecipient getRecipient() {
			return recipient;
		}

		public void setRecipient(GlassRecipient recipient) {
			this.recipient = recipient;
		}
	}

	@MappedSuperclass
	public abstract class EntityDb<R extends Recipient> {
		@Id
		private long id;

		private int version;

		@Type(type="io.hypersistence.utils.hibernate.type.json.JsonBinaryType")
		@Column(columnDefinition = "jsonb")
		private R recipient;

		public EntityDb() {
		}

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public R getRecipient() {
			return recipient;
		}

		public void setRecipient(R recipient) {
			this.recipient = recipient;
		}

		public int getVersion() {
			return version;
		}

		public void setVersion(int version) {
			this.version = version;
		}
	}

	@Entity(name = "GlassRecipient")
	public class GlassRecipientDb extends EntityDb<GlassRecipientWrapper> {

		public GlassRecipientDb() {
		}
	}


}
