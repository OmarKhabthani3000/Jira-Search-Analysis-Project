package manytomany;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "B", schema = "ADMIN")
public class B implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private int id;
	private P p;
	private String data;

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID", nullable = false)
	public int getId() {
		return this.id;
	}
	public void setId(int id) {
		this.id = id;
	}

	@ManyToOne
    @JoinColumn(name = "P", referencedColumnName = "ID", nullable = false)
	public P getP() {
		return p;
	}
	public void setP(P p) {
		this.p = p;
	}

	@Column(name = "DATA", length = 20)
	public String getData() {
		return this.data;
	}

	public void setData(String data) {
		this.data = data;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final B other = (B) obj;
		if (id != other.id)
			return false;
		return true;
	}

}
