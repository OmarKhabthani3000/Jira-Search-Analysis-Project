package manytomany;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("1")
public class ATrue extends A {

	private static final long serialVersionUID = 1L;
	
	public ATrue() {
		setBoolProp(true);
	}

}
