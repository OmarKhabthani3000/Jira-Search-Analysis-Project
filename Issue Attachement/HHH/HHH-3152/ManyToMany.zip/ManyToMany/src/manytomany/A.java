package manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "BOOL_PROP", discriminatorType = DiscriminatorType.INTEGER)
@Table(name = "A", schema = "ADMIN")
public abstract class A implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private int id;

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID", nullable = false)
	public int getId() {
		return this.id;
	}
	public void setId(int id) {
		this.id = id;
	}

	private P p;

	@ManyToOne
    @JoinColumn(name = "P", referencedColumnName = "ID", nullable = false)
	public P getP() {
		return p;
	}
	public void setP(P p) {
		this.p = p;
	}

	private List<B> bList = new ArrayList<B>();

	@ManyToMany
	@JoinTable(
		name = "A_B",
		joinColumns = {@JoinColumn(name="A", referencedColumnName = "ID", 
				nullable = false, insertable=false, updatable=false)},
		inverseJoinColumns = {@JoinColumn(name="B", referencedColumnName = "ID", 
				nullable = false, insertable=false, updatable=false)}
	)
	public List<B> getBList() {
		return bList;
	}
	public void setBList(List<B> list) {
		bList = list;
	}

    private List<AB> abList = new ArrayList<AB>();

    @OneToMany(mappedBy = "a", cascade={CascadeType.REMOVE})
	public List<AB> getAbSet() {
		return abList;
	}
	public void setAbSet(List<AB> abList) {
		this.abList = abList;
	}

	private boolean boolProp;

	@Column(name = "BOOL_PROP", nullable = false, insertable=false, updatable=false)
	public boolean getBoolProp() {
		return this.boolProp;
	}
	public void setBoolProp(boolean boolProp) {
		this.boolProp = boolProp;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final A other = (A) obj;
		if (id != other.id)
			return false;
		return true;
	}

}
