package manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Where;

@Entity
@Table(name = "P", schema = "ADMIN")
public class P {
	private int id;
	
	private List<A> allA = new ArrayList<A>();
	private List<A> allTrueA = new ArrayList<A>();
	private List<A> allFalseA = new ArrayList<A>();
	
	private List<B> bList = new ArrayList<B>();

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID", nullable = false)
	public int getId() {
		return this.id;
	}
	public void setId(int id) {
		this.id = id;
	}

	@OneToMany(mappedBy = "p", cascade={CascadeType.REMOVE})
	public List<A> getAllA() {
		return allA;
	}
	public void setAllA(List<A> aSet) {
		this.allA = aSet;
	}

	@OneToMany(mappedBy = "p")
    @Where(clause="BOOL_PROP<>0")
	public List<A> getAllTrueA() {
		return allTrueA;
	}
	public void setAllTrueA(List<A> allTrueA) {
		this.allTrueA = allTrueA;
	}

	@OneToMany(mappedBy = "p")
    @Where(clause="BOOL_PROP=0")
	public List<A> getAllFalseA() {
		return allFalseA;
	}
	public void setAllFalseA(List<A> allFalseA) {
		this.allFalseA = allFalseA;
	}
	
	@OneToMany(mappedBy = "p", cascade={CascadeType.REMOVE})
	public List<B> getBList() {
		return bList;
	}
	public void setBList(List<B> bList) {
		this.bList = bList;
	}
	
	@Override
	public int hashCode() {
		return id;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final P other = (P) obj;
		if (id != other.id)
			return false;
		return true;
	}

}
