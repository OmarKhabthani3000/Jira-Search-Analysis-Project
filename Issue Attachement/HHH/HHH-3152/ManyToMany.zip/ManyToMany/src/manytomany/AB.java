package manytomany;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "A_B", schema = "ADMIN")
public class AB implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private int id;
	private A a;
	private B b;
	private String data;

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID", nullable = false)
	public int getId() {
		return this.id;
	}
	public void setId(int id) {
		this.id = id;
	}

	@ManyToOne
    @JoinColumn(name = "A", referencedColumnName = "ID")
	public A getA() {
		return this.a;
	}
	public void setA(A a) {
		this.a = a;
	}

	@ManyToOne
    @JoinColumn(name = "B", referencedColumnName = "ID")
	public B getB() {
		return this.b;
	}
	public void setB(B b) {
		this.b = b;
	}

	@Column(name = "DATA", length = 20)
	public String getData() {
		return this.data;
	}
	public void setData(String data) {
		this.data = data;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final AB other = (AB) obj;
		if (id != other.id)
			return false;
		return true;
	}

}
