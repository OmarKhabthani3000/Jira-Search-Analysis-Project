package manytomany;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	private EntityManagerFactory emf = Persistence.createEntityManagerFactory("ManyToManyPU");
	private EntityManager em = emf.createEntityManager();

	public static void main(String[] args) {
		new Main().run();
	}

	@SuppressWarnings("unchecked")
	public void run() {
		try {
			P p = setUp();
			if (p == null) {
				System.out.println("Done. Restart the program to demonstrate the problem.");
				return;
			}
			
			System.out.println("Deleting True A...");
			em.getTransaction().begin();
			em.remove(p.getAllTrueA().get(0));
			em.getTransaction().commit();
			
			System.out.println("Done.");
		} finally {
			em.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	public P setUp() {
		em.getTransaction().begin();

		try {
			P p;
			List<P> list = (List<P>)em.createQuery("select p from P p").getResultList();
			if (list.size() > 0) {
				p = list.get(0);
			} else {
				p = setUpP();
			}
			
			List<A> allTrueA = p.getAllTrueA();
			if (allTrueA.size() == 0) {
				setUpTrueA(p);
				p = null;
			}
			
			em.getTransaction().commit();

			return p;
		} catch (RuntimeException e) {
			em.getTransaction().rollback();
			throw e;
		}
	}
	
	public P setUpP() {
		System.out.println("Setting up the parent (P)...");
		
		P p = new P();
		em.persist(p);
		
		B b = new B();
		b.setData("Blah");
		b.setP(p);
		p.getBList().add(b);
		em.persist(b);

		for (int i = 0; i < 3; i++) {
			A a = new AFalse();
			a.setP(p);
			
			AB ab = new AB();
			ab.setA(a);
			a.getAbSet().add(ab);
			ab.setB(b);
			
			em.persist(a);
			em.persist(ab);
		}
		
		return p;
	}
	
	public void setUpTrueA(P p) {
		System.out.println("Setting up the only true A...");
		
		A a = new ATrue();
		a.setP(p);
		
		AB ab = new AB();
		ab.setA(a);
		a.getAbSet().add(ab);
		ab.setB(p.getBList().get(0));

		em.persist(a);
		em.persist(ab);
	}
	
}
