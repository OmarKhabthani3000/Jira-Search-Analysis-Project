package manytomany;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("0")
public class AFalse extends A {

	private static final long serialVersionUID = 1L;
	
	public AFalse() {
		setBoolProp(false);
	}

}
