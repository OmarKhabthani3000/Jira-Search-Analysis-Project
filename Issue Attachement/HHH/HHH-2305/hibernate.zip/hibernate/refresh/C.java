package hibernate.refresh;

public class C
{
  protected long id;
  protected int c;
}
