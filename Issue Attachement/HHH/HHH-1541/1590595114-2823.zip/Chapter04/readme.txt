The Chapter 4 source code requires the Hibernate 3 Annotations project, and its JAR files, in addition to the Hibernate 3 JAR files and the HSQL DB JAR file.

The dbschema.txt file contains the DDL to create the tables for HSQLDB.