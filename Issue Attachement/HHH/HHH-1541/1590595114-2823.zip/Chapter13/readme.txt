In this chapter the examples use FireBird. We're also positing the 
existence of a legacy database, so rather than running the 
schemaexport task as normal, you'll just need to  run the provided
legacy.sql script against your FireBird database.

You will need to update the hibernate.cfg.xml file with the 
connection details of your FireBird database.