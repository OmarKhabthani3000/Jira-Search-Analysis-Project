package com.hibernatebook.chapter3.dao;

import java.util.logging.Logger;


public class DAO {
   public DAO() {
   }
   
   public static final Logger log = Logger.getAnonymousLogger();
}
