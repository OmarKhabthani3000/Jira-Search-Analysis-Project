package org.hibernate.javassist;
import java.text.ParseException;

import javax.naming.Context;
import javax.naming.InitialContext;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

public class HibernateObjectTest extends TestCase {
    
    private SessionFactory sessionFactory;
    
    
    public void setUp() throws Exception{
        super.setUp();
        System.setProperty("hibernate.bytecode.provider", "javassist");
                
        Configuration conf = new Configuration().configure("/org/hibernate/javassist/hibernate3.cfg.xml")
        .setProperty(Environment.HBM2DDL_AUTO, "create")
        .setProperty(Environment.BYTECODE_PROVIDER, "javassist");
        sessionFactory = conf.buildSessionFactory();
        
        Session s = sessionFactory.openSession();
        Transaction tx = s.beginTransaction();

        A a1 = new A(1);
        HibernateObject child1 = new HibernateObject(1, a1);
        child1.setA(a1);
        
        
        s.save(a1);
        
        s.save(child1);
        
        tx.commit();
        s.close();
        
    }
    
    protected void tearDown() throws Exception {
        sessionFactory.close();
        super.tearDown();
    }

    
    public void test() {
        Session session = sessionFactory.openSession();
        
        Transaction transaction = session.beginTransaction();
        
        HibernateObject object = (HibernateObject) session.createQuery("from HibernateObject").uniqueResult();
        try {
            object.getA().testException();
            fail("exception should be thrown");
        } catch (ParseException e) {
            //ok
        } catch (Exception e) {
            fail("wrong exception is thrown");
        }
        
        transaction.commit();
        
        
        System.out.println("ok");
    }

}
