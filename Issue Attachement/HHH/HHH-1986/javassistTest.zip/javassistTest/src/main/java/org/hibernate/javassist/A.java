package org.hibernate.javassist;

import java.text.ParseException;


public class A {
    
    private int id;
    

    public A() {
        super();
    }
    
    public A(int id) {
        super();
     
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    

    public void testException() throws ParseException {
        throw new ParseException("", 0);
    }
    
    
    
    
}
