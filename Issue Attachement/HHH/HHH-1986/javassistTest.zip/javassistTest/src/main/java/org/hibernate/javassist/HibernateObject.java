package org.hibernate.javassist;

public class HibernateObject {
    
    private int id;
    private A a;
    
    public HibernateObject() {
        super();
    }
    
    public HibernateObject(int id, A a) {
        super();
        this.id = id; 
        this.a = a;
    }
    
    public A getA() {
        return a;
    }

    public void setA(A a) {
        this.a = a;
    }

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
