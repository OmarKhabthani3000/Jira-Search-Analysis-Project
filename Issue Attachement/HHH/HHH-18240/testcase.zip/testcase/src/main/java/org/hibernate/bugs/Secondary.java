/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import java.util.Objects;

@Entity
public class Secondary {

    @Id
    private int id;
    @ManyToOne
    private Primary primary;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Primary getPrimary() {
        return primary;
    }

    public void setPrimary(Primary primary) {
        this.primary = primary;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Secondary secondary = (Secondary) o;
        return id == secondary.id;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }
}
