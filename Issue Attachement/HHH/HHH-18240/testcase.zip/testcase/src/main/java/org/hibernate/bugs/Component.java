/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package org.hibernate.bugs;

import jakarta.persistence.Embeddable;
import jakarta.persistence.OneToMany;
import java.io.Serializable;
import java.util.List;

@Embeddable
public class Component implements Serializable {

    @OneToMany(mappedBy = "primary")
    private List<Secondary> secondaries;

    public List<Secondary> getSecondaries() {
        return secondaries;
    }

    public void setSecondaries(List<Secondary> secondaries) {
        this.secondaries = secondaries;
    }
}
