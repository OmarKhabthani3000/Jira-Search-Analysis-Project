import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Iterator;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.hibernate.EntityMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class TestDom4jVersionedObject {

	
	public static void main(String[] args) throws Exception {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Session dom4jSession = session.getSession(EntityMode.DOM4J);
		load(dom4jSession, "Role.xml", "Role", "Role");
		session.flush();
		load(dom4jSession, "User.xml", "User", "User");
		tx.commit();
		session.close();
	}
	
	private static void load (Session dom4jSession, String fileName, String nodeName, String entityName) throws Exception {
		SAXReader reader = new SAXReader();
		InputStream is = new FileInputStream(fileName);
		Document document = reader.read(is);
		Element root = document.getRootElement();

		for ( Iterator i = root.elementIterator(nodeName); i.hasNext(); ) {
			Element userElement = (Element) i.next();
			dom4jSession.save(entityName, userElement);
		} 
		
		
	}

}
