package hibernate;

import java.io.File;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestHibernate {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		Configuration config = new Configuration();
		File file = new File("hibernate.cfg.xml");
		System.out.println(file.exists());
		
		config.configure(file);
		SessionFactory sessionFactory = config.buildSessionFactory();
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		s.get(X.class, 1L);
		t.commit();
	}

}
