package hibernate;

public class B extends A {
	private X x;

	public X getX() {
		return x;
	}

	public void setX(X x) {
		this.x = x;
	}
}
