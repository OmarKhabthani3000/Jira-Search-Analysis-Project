package hibernate;

public class X {
	private long id;
	private String ind;
	private B b;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getInd() {
		return ind;
	}
	public void setInd(String ind) {
		this.ind = ind;
	}
	public B getB() {
		return b;
	}
	public void setB(B b) {
		this.b = b;
	}

}
