create table A (
  id number primary key,
  ind char(1)
);
create table X (
  id number primary key,
  ind char(1)
);
create table B(
  id number primary key,
  ind char(1),
  x_id number
);

ALTER TABLE B 
ADD CONSTRAINT B_A_FK1 FOREIGN KEY 
(
"ID"
) REFERENCES TEST.A 
(
"ID"
) ENABLE
;

ALTER TABLE B 
ADD CONSTRAINT B_X_FK1 FOREIGN KEY 
(
"X_ID"
) REFERENCES TEST.X 
(
"ID"
) ENABLE
;

