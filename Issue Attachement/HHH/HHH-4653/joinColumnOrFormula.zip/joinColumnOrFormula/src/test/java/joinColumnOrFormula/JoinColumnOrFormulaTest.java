package joinColumnOrFormula;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.classic.Session;

import joinColumnOrFormula.Contract;
import joinColumnOrFormula.ContractCancelOrder;
import joinColumnOrFormula.ContractId;
import joinColumnOrFormula.Manufacturer;
import joinColumnOrFormula.ManufacturerId;
import joinColumnOrFormula.Model;
import joinColumnOrFormula.ModelId;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class JoinColumnOrFormulaTest extends TestCase {
	/**
	 * Create the test case
	 * 
	 * @param testName
	 *            name of the test case
	 */
	public JoinColumnOrFormulaTest(String testName) {
		super(testName);
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite() {
		return new TestSuite(JoinColumnOrFormulaTest.class);
	}

	/**
	 * Rigourous Test :-)
	 */
	public void testApp() {
		SessionFactory sessionFactory = new AnnotationConfiguration()
				.configure().buildSessionFactory();

		Integer companyCode = 10;
		Integer mfgCode = 100;
		String contractNumber = "NSAR97841";
		ContractId contractId = new ContractId(companyCode, 12457l, 1);

		Session session = sessionFactory.openSession();

		Transaction trx = session.beginTransaction();

		Manufacturer manufacturer = new Manufacturer(new ManufacturerId(
				companyCode, mfgCode), "FORD");

		Model model = new Model(new ModelId(companyCode, mfgCode, "FOCUS"),
				"FORD FOCUS");

		session.save(manufacturer);
		session.save(model);

		Contract contract = new Contract();
		contract.setId(contractId);
		contract.setContractNumber(contractNumber);
		contract.setManufacturer(manufacturer);
		contract.setModel(model);

		ContractCancelOrder cancelOrder = new ContractCancelOrder();
		cancelOrder.setContract(contract);
		cancelOrder.setName("Cancellation order for " + contractNumber);

		session.save(contract);
		session.save(cancelOrder);

		trx.commit();

		session.close();

		session = sessionFactory.openSession();

		trx = session.beginTransaction();
		contract = (Contract) session.load(Contract.class, contractId);
		System.out.println("Contract: " + contract);
		System.out.println("Cancel-Order: " + contract.getCancelOrder());
		System.out.println("Contract from Cancel-Order: "
				+ contract.getCancelOrder().getContract());
		System.out.println("Manufacturer: " + contract.getManufacturer());
		System.out.println("Model: " + contract.getModel());

		trx.commit();
		session.close();
	}
}
