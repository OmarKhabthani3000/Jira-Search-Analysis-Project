package joinColumnOrFormula;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CONTRACT_CANCEL_ORDER")
public class ContractCancelOrder implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer id;

	private Contract contract;

	private String name;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CCO_ID")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns( {
			@JoinColumn(name = "CCO_COMPANY_CODE", referencedColumnName = "CDT_COMPANY_CODE"),
			@JoinColumn(name = "CCO_CDT_NBR", referencedColumnName = "CDT_NBR"),
			@JoinColumn(name = "CCO_CDT_SEQ_NBR", referencedColumnName = "CDT_SEQ_NBR") })
	public Contract getContract() {
		return contract;
	}
	
	public void setContract(Contract contract) {
		this.contract = contract;
	}

	public void setName(String string) {
		name = string;
	}

	@Column(name = "CCO_NAME")
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return name;
	}

}
