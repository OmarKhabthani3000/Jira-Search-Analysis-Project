package hibernate.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.MapKeyColumn;


@Entity
public class Item implements Serializable
{
    private static final long serialVersionUID = 1L;

    @Id
    @Column(nullable = false)
    private String name;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "STORED_INPUT_PARAMETER", joinColumns = @JoinColumn(name = "STORED_INPUT_ID"))
    @MapKeyColumn(name = "NAME")
    @Lob
    @Column(name = "VALUE", length = 65535)
    private Map<String, String> parameters = new HashMap<>();

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Map<String, String> getParameters()
    {
        return parameters;
    }

    public void setParameters(Map<String, String> parameters)
    {
        this.parameters = parameters;
    }
}
