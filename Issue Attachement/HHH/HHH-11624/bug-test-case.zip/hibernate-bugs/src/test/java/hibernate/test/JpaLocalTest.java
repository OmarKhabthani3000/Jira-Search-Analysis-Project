package hibernate.test;

import java.sql.DriverManager;
import java.util.function.Consumer;
import java.util.function.Function;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import hibernate.model.Item;


public class JpaLocalTest
{
    private EntityManagerFactory emf;

    @Test
    public void test1()
    {
        Item input = new Item();
        input.setName("X");
        input.getParameters().put("aaa", "AAA");
        input.getParameters().put("bbb", "BBB");

        consume(em -> em.persist(input));

        Item input2 = execute(em -> em.find(Item.class, "X"));

        Item input3 = execute(em -> em.merge(input2));

        System.out.println(input3.getParameters());
    }

    protected void consume(Consumer<EntityManager> consumer)
    {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try
        {
            tx.begin();
            consumer.accept(em);
            tx.commit();
        }
        catch(Exception e)
        {
            tx.rollback();
            throw e;
        }
        finally
        {
            if(em.isOpen())
            {
                em.close();
            }
        }
    }

    protected <T> T execute(Function<EntityManager, T> function)
    {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try
        {
            tx.begin();
            T result = function.apply(em);
            tx.commit();
            return result;
        }
        catch(Exception e)
        {
            tx.rollback();
            throw e;
        }
        finally
        {
            if(em.isOpen())
            {
                em.close();
            }
        }
    }

    @Before
    public void beforeClass()
    {
        emf = Persistence.createEntityManagerFactory("test");
    }

    @After
    public void afterClass()
    {
        if(emf != null && emf.isOpen())
        {
            emf.close();
        }

        try
        {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
            DriverManager.getConnection("jdbc:derby:memory:test;drop=true");
        }
        catch(Exception e)
        {
            //e.printStackTrace();
        }
    }
}
