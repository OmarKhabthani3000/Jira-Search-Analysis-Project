/*
 * Module A.java
 * Created on 13 Nov 2009
 */
package test;

public interface A
{
    String getFoo();

    void setFoo(String value);
}
