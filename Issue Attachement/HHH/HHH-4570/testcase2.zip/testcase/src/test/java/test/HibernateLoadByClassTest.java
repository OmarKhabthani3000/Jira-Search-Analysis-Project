package test;
import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import test.AImpl;

public class HibernateLoadByClassTest extends TestCase {
    private SessionFactory sessionFactory;

    /**
     * @see junit.framework.TestCase#setUp()
     */
    @Override
    protected void setUp() throws Exception {
        super.setUp();

        Configuration configuration = new Configuration();
        configuration.configure("test_hibernate.cfg.xml");
        StandardServiceRegistryBuilder serviceRegistryBuilder = new StandardServiceRegistryBuilder()
                .applySettings(configuration.getProperties());
        sessionFactory = configuration
                .buildSessionFactory(serviceRegistryBuilder.build());
    }

    public void test_load_by_mapped_EntityName() {
        Session session = sessionFactory.openSession();

        session.load("A", 1);
    }

    // Fails org.hibernate.MappingException: Unknown entity: test.AImpl
    public void test_load_by_mapped_Class() {
        Session session = sessionFactory.openSession();

        session.load(AImpl.class, 1);
    }
}
