package test;
public interface A
{
    String getFoo();

    void setFoo(String value);
}
