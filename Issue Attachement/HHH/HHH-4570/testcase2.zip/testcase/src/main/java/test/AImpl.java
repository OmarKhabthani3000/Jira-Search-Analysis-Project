package test;
public class AImpl implements A {
    private int id = -1;

    private String foo;

    public int getId() {
        return id;
    }

    public void setId(int a_id) {
        id = a_id;
    }

    public String getFoo() {
        return foo;
    }

    public void setFoo(String a_value) {
        this.foo = foo;
    }
}
