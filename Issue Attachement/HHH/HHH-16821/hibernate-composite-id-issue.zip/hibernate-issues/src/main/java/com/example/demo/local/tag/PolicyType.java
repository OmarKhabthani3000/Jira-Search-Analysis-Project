package com.example.demo.local.tag;

public enum PolicyType {
    ALL,
    NONE
}