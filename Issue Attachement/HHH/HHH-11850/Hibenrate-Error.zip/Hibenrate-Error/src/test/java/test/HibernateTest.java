package test;

import static org.hibernate.cfg.AvailableSettings.*;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.SharedCacheMode;
import javax.persistence.spi.ClassTransformer;
import javax.persistence.spi.PersistenceUnitInfo;
import javax.persistence.spi.PersistenceUnitTransactionType;
import javax.sql.DataSource;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.appender.ConsoleAppender;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.Configurator;
import org.apache.logging.log4j.core.config.builder.api.AppenderComponentBuilder;
import org.apache.logging.log4j.core.config.builder.api.ConfigurationBuilder;
import org.apache.logging.log4j.core.config.builder.api.ConfigurationBuilderFactory;
import org.apache.logging.log4j.core.config.builder.impl.BuiltConfiguration;
import org.hibernate.dialect.HSQLDialect;
import org.hibernate.jpa.HibernatePersistenceProvider;
import org.junit.Test;

public class HibernateTest {
    EntityManagerFactory entityManagerFactory;

    @Test
    public void test() throws Exception {
        setLog4j();
        setUp();
        
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        
        entityManager.getTransaction().begin();
        FirstEntity firstEntity = new FirstEntity();
        firstEntity.setValue("fsdfjsdkljfskdl");
        firstEntity.setValue2("fshjfdsjkfj");
        SecondEntity secondEntity = new SecondEntity();
        secondEntity.firstEntity = firstEntity;
        firstEntity.getSecondEntities().add(secondEntity);
        entityManager.persist(firstEntity);
        entityManager.getTransaction().commit();

        entityManager.getTransaction().begin();
        entityManager.clear();
        List<FirstEntity> firstEntities = entityManager.createQuery("select fe from FirstEntity fe where fe.id = " + firstEntity.getId()).getResultList();
        FirstEntity fe = firstEntities.get(0);
        fe.setValue2("dddd2");
        SecondEntity secondEntity1 = new SecondEntity();
        secondEntity1.firstEntity = fe;
        fe.getSecondEntities().add(secondEntity1);
        entityManager.getTransaction().commit();
        
        
    }

    private void setLog4j() {
        ConfigurationBuilder<BuiltConfiguration> builder = ConfigurationBuilderFactory.newConfigurationBuilder();

        builder.setStatusLevel( Level.ERROR);
        builder.setConfigurationName("RollingBuilder");
        AppenderComponentBuilder appenderBuilder = builder.newAppender("Stdout", "CONSOLE").addAttribute("target",
                ConsoleAppender.Target.SYSTEM_OUT);
        appenderBuilder.add(builder.newLayout("PatternLayout")
                .addAttribute("pattern", "%d [%t] %-5level: %msg%n%throwable"));
        builder.add( appenderBuilder );

        builder.add( builder.newRootLogger( Level.DEBUG )
                .add( builder.newAppenderRef( "Stdout" ) ) );
        LoggerContext ctx = Configurator.initialize((Configuration)builder.build());

    }

    private void setUp(){
        HashMap<String, Object> properties = new HashMap<>();
        properties.put(DRIVER, "org.hsqldb.jdbcDriver");
        properties.put(URL, "jdbc:hsqldb:mem:temp");
        properties.put(DIALECT, HSQLDialect.class);
        properties.put(HBM2DDL_AUTO, "create");
        properties.put(SHOW_SQL, true);
        properties.put(QUERY_STARTUP_CHECKING, false);
        properties.put(GENERATE_STATISTICS, false);
        properties.put(USE_REFLECTION_OPTIMIZER, false);
        properties.put(USE_SECOND_LEVEL_CACHE, false);
        properties.put(USE_QUERY_CACHE, false);
        properties.put(USE_STRUCTURED_CACHE, false);
        properties.put(STATEMENT_BATCH_SIZE, 20);
        entityManagerFactory = new HibernatePersistenceProvider().createContainerEntityManagerFactory(
                archiverPersistenceUnitInfo(),
                properties);
    }

    private static PersistenceUnitInfo archiverPersistenceUnitInfo() {
        return new PersistenceUnitInfo() {
            @Override
            public String getPersistenceUnitName() {
                return "ApplicationPersistenceUnit";
            }

            @Override
            public String getPersistenceProviderClassName() {
                return "org.hibernate.jpa.HibernatePersistenceProvider";
            }

            @Override
            public PersistenceUnitTransactionType getTransactionType() {
                return PersistenceUnitTransactionType.RESOURCE_LOCAL;
            }

            @Override
            public DataSource getJtaDataSource() {
                return null;
            }

            @Override
            public DataSource getNonJtaDataSource() {
                return null;
            }

            @Override
            public List<String> getMappingFileNames() {
                return Collections.emptyList();
            }

            @Override
            public List<java.net.URL> getJarFileUrls() {
                try {
                    return Collections.list(this.getClass()
                            .getClassLoader()
                            .getResources(""));
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            }

            @Override
            public URL getPersistenceUnitRootUrl() {
                return null;
            }

            @Override
            public List<String> getManagedClassNames() {
                return Collections.emptyList();
            }

            @Override
            public boolean excludeUnlistedClasses() {
                return false;
            }

            @Override
            public SharedCacheMode getSharedCacheMode() {
                return null;
            }

            @Override
            public javax.persistence.ValidationMode getValidationMode() {
                return null;
            }

            @Override
            public Properties getProperties() {
                return new Properties();
            }

            @Override
            public String getPersistenceXMLSchemaVersion() {
                return null;
            }

            @Override
            public ClassLoader getClassLoader() {
                return null;
            }

            @Override
            public void addTransformer(ClassTransformer classTransformer) {

            }


            @Override
            public ClassLoader getNewTempClassLoader() {
                return null;
            }
        };
    }
}
