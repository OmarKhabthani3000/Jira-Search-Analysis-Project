package test;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Table(name = "firstEntity")
@Audited
@Entity
public class FirstEntity implements Serializable {
    
    @Id
    @GeneratedValue
    private Long id;

    @Basic(fetch = FetchType.LAZY)
    private String value;

    private String value2;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "firstEntity")
    Set<SecondEntity> secondEntities = new HashSet<>();

    public String getValue2() {
        return value2;
    }

    public void setValue2(String value2) {
        this.value2 = value2;
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Set<SecondEntity> getSecondEntities() {
        return secondEntities;
    }

    public void setSecondEntities(Set<SecondEntity> secondEntities) {
        this.secondEntities = secondEntities;
    }
    
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
