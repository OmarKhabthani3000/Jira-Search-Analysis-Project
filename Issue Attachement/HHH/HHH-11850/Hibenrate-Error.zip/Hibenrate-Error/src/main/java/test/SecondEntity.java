package test;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;

@Entity
@Audited
public class SecondEntity implements Serializable {

    @Id
    @GeneratedValue
    @Column(name = "id")
    Long id;
    
    @ManyToOne
    @JoinColumn(name = "first_entity_id")
    public FirstEntity firstEntity;
    
}
