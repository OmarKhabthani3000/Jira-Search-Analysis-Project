
import java.util.Date;

import junit.framework.TestCase;

import org.hibernate.ReplicationMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import com.phi.dictionarymanager.beans.CodeSystem;
import com.phi.dictionarymanager.beans.CodeValue;

public class TestEnvers12 extends TestCase {

	private SessionFactory sessionFactoryMysql;
	private SessionFactory sessionFactoryHsql;
	private final String MYSQL_CFG_XML = "hibernate-mysql.cfg.xml";
	private final String HSQL_CFG_XML = "hibernate-hsql.cfg.xml";
	private Session sessionLocal = null;
	private Session sessionNetwork = null;

	protected void setUp() throws Exception {
		super.setUp();
		
		try {
            // Create the SessionFactory from hibernate-mysql.cfg.xml
            sessionFactoryMysql = new AnnotationConfiguration().configure(MYSQL_CFG_XML).buildSessionFactory();
        } catch (Exception ex) {
            // Make sure you log the exception, as it might be swallowed
        	System.out.println("Initial SessionFactoryMysql creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
        try {
            // Create the SessionFactory from hibernate-hsql.cfg.xml
        	sessionFactoryHsql = new AnnotationConfiguration().configure(HSQL_CFG_XML).buildSessionFactory();
        } catch (Throwable ex) {
            // Make sure you log the exception, as it might be swallowed
        	System.out.println("Initial SessionFactoryHsql creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }

	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	
	
	public void test1() throws Exception{
		
		System.out.println("\n ------  TEST 1 --------");
		
		String codeSystemId = "test001";
		
		try{
		
			CodeSystem codeSystem = new CodeSystem();
			codeSystem = new CodeSystem();
			codeSystem.setId( codeSystemId );
			codeSystem.setVersion("1");
			codeSystem.setName("test");
			codeSystem.setDisplayName("test");
			codeSystem.setDescription("test");
			codeSystem.setStatus("ACTIVE");
			codeSystem.setCreationDate(new Date());
			codeSystem.setIsoCodeLang("it");
			codeSystem.setAuthorityName("test");
			codeSystem.setAuthorityDescription("test");
			codeSystem.setContactInformation("test");
			
			getSessionLocal().beginTransaction();
			getSessionLocal().saveOrUpdate(codeSystem);
			getSessionLocal().getTransaction().commit();
			getSessionLocal().close();
			sessionLocal = null;
			
			getSessionNetwork().beginTransaction();
			getSessionNetwork().replicate(codeSystem, ReplicationMode.LATEST_VERSION);
			getSessionNetwork().getTransaction().commit();
			getSessionNetwork().close();
			sessionNetwork = null;
			
			System.out.println("\n ------  Saved New CodeSystem --------");
			
			getSessionLocal().update(codeSystem);
			System.out.println("\n ------  Updated CodeSystem --------");
			
			CodeValue codeValue = new CodeValue();
			codeValue.setId( codeSystemId + "." + "test" );
			codeValue.setCodeSystem(codeSystem);
			codeValue.setCode( "test" );
			//cv.setActive(true);
			codeValue.setDisplayName( "test" );
			codeValue.setType( "C" );
			//cv.setSequenceNumber(0);
			codeValue.setDefaultChild(false);
			codeValue.setStatus( "ACTIVE" );
			codeValue.setValidFrom( codeSystem.getCreationDate() );
			codeValue.setValidTo( null );
			codeValue.setDescription( "test" );
			codeValue.setKeywords( "test" );
			codeValue.setAuthorityName("test");
			codeValue.setAuthorityDescription("test");
			codeValue.setContactInformation("test");
			
			codeSystem.getCodeValues().add(codeValue);
			
			
			getSessionLocal().beginTransaction();
			getSessionLocal().saveOrUpdate(codeSystem);
			getSessionLocal().getTransaction().commit();
			getSessionLocal().close();
			sessionLocal = null;
			
			getSessionNetwork().beginTransaction();
			getSessionNetwork().replicate(codeSystem, ReplicationMode.LATEST_VERSION);
			getSessionNetwork().getTransaction().commit();
			getSessionNetwork().close();
			sessionNetwork = null;
			
			System.out.println("\n ------  Saved CodeSystem with new CodeValue --------");
			
			
		} catch(Exception e){
			e.printStackTrace();
			System.out.println("ERR: " + e.getMessage());
		}
		
	}
	
	
	public Session getSessionLocal(){
    	if ( sessionLocal == null ){
    		sessionLocal = sessionFactoryHsql.openSession();
    	}
    	return sessionLocal;
    }
	
	public Session getSessionNetwork(){
    	if ( sessionNetwork == null ){
    		sessionNetwork = sessionFactoryMysql.openSession();
    	}
    	return sessionNetwork;
    }

	
}
