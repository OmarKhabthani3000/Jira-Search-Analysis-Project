package com.phi.dictionarymanager.beans;

public class SearchAdvanced {
	
	private String codeSystem;
	private String code;
	private String search;
	private String[] status;
	//private String changeReason;
	private String validFromStart;
	private String validFromEnd;
	private String validToStart;
	private String validToEnd;
	
	/**
	 * Empties the bean setting all fields to null
	 */
	public void empty(){
		code = null;
		search = null;
		status = null;
		validFromEnd = null;
		validFromStart = null;
		validToEnd = null;
		validToStart = null;
	}

	public void setCodeSystem(String codeSystem) {
		this.codeSystem = codeSystem;
	}

	public String getCodeSystem() {
		return codeSystem;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public String getValidFromStart() {
		return validFromStart;
	}

	public void setValidFromStart(String validFromStart) {
		this.validFromStart = validFromStart;
	}

	public String getValidFromEnd() {
		return validFromEnd;
	}

	public void setValidFromEnd(String validFromEnd) {
		this.validFromEnd = validFromEnd;
	}

	public String getValidToStart() {
		return validToStart;
	}

	public void setValidToStart(String validToStart) {
		this.validToStart = validToStart;
	}

	public String getValidToEnd() {
		return validToEnd;
	}

	public void setValidToEnd(String validToEnd) {
		this.validToEnd = validToEnd;
	}

	public void setSearch(String search) {
		this.search = search;
	}

	public String getSearch() {
		return search;
	}

	public void setStatus(String[] status) {
		this.status = status;
	}

	public String[] getStatus() {
		return status;
	}
	
	
}
