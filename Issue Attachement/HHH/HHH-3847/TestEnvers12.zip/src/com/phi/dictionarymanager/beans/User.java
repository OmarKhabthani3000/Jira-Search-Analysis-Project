package com.phi.dictionarymanager.beans;

public class User {
	
	private String username;
	private String password;
	private String nameComplete;
	private String authorityName;
	private String authorityDescription;
	private String contactInformation;
	
	
	
	public void setContactInformation(String contactInformation) {
		this.contactInformation = contactInformation;
	}
	public String getContactInformation() {
		return contactInformation;
	}
	public void setAuthorityDescription(String authorityDescription) {
		this.authorityDescription = authorityDescription;
	}
	public String getAuthorityDescription() {
		return authorityDescription;
	}
	public void setAuthorityName(String authorityName) {
		this.authorityName = authorityName;
	}
	public String getAuthorityName() {
		return authorityName;
	}
	public void setNameComplete(String nameComplete) {
		this.nameComplete = nameComplete;
	}
	public String getNameComplete() {
		return nameComplete;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUsername() {
		return username;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword() {
		return password;
	}
	
}
