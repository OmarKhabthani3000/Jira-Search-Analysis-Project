create database if not exists `phidictionary`;

USE `phidictionary`;