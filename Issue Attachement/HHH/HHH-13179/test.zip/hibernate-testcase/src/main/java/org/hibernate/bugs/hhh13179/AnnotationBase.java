package org.hibernate.bugs.hhh13179;

import javax.persistence.*;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@MappedSuperclass
@Cache(usage  = CacheConcurrencyStrategy.READ_WRITE)
public class AnnotationBase
{
	@Id
	@Access(AccessType.FIELD)
	public Long id;

	@Basic
	@Access(AccessType.FIELD)
	public String name;

	public AnnotationBase()
	{
	}

	public AnnotationBase(Long id, String name)
	{
		this.id = id;
		this.name = name;
	}
}
