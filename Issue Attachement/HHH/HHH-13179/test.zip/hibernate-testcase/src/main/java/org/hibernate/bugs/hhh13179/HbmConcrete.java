package org.hibernate.bugs.hhh13179;


public class HbmConcrete extends HbmBase
{
	public String property;

	protected HbmConcrete()
	{
	}

	public HbmConcrete(Long id, String name, String property)
	{
		super(id, name);
		this.property = property;
	}
}
