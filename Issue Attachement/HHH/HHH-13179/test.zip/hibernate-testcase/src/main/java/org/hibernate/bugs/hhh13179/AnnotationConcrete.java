package org.hibernate.bugs.hhh13179;

import javax.persistence.*;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cache(usage  = CacheConcurrencyStrategy.READ_WRITE)
public class AnnotationConcrete extends AnnotationBase
{
	@Basic
	@Access(AccessType.FIELD)
	public String property;

	protected AnnotationConcrete()
	{
	}

	public AnnotationConcrete(long id, String name, String property)
	{
		super(id, name);
		this.property = property;
	}

}
