/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs.hhh13179;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 *
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class UnionSubClassTest extends BaseCoreFunctionalTestCase {

	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
				AnnotationBase.class,
				AnnotationConcrete.class
		};
	}

	// If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
	@Override
	protected String[] getMappings() {
		return new String[] {
				"base.hbm.xml",
				"concrete.hbm.xml"
		};
	}
	// If those mappings reside somewhere other than resources/org/hibernate/test, change this.
	@Override
	protected String getBaseForMappings() {
		return UnionSubClassTest.class.getPackage().getName().replace('.', '/')+"/";
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {

		super.configure( configuration );

		configuration.setProperty( AvailableSettings.SHOW_SQL, Boolean.TRUE.toString() );
		//configuration.setProperty( AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString() );
		configuration.setProperty( AvailableSettings.USE_SECOND_LEVEL_CACHE, Boolean.TRUE.toString() );

	}

	// Add your tests, using standard JUnit.
	@Test
	public void cacheUnionSubclassHbmTest()
	{
		Session s = openSession();
		Transaction tx = s.beginTransaction();

		s.save(new HbmConcrete(1L, "name", "property"));

		tx.commit();
		s.close();

		for(int i=0; i<3; ++i)
		{
			Session s1 = openSession();
			Transaction tx1 = s1.beginTransaction();

			HbmConcrete o = s1.get(HbmConcrete.class, 1L);
			assertNotNull(o);
			assertEquals("name", o.name);
			assertEquals("property", o.property);

			tx1.commit();
			s1.close();

		}
	}

	@Test
	public void cacheMappedSuperClassAnnotationTest()
	{
		Session s = openSession();
		Transaction tx = s.beginTransaction();

		s.save(new AnnotationConcrete(1L, "name", "property"));

		tx.commit();
		s.close();

		for(int i=0; i<3; ++i)
		{
			Session s1 = openSession();
			Transaction tx1 = s1.beginTransaction();

			AnnotationConcrete o = s1.get(AnnotationConcrete.class, 1L);
			assertNotNull(o);
			assertEquals("name", o.name);
			assertEquals("property", o.property);

			tx1.commit();
			s1.close();

		}
	}
}
