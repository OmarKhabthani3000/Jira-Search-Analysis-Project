package org.hibernate.bugs.hhh13179;


public class HbmBase
{
	public Long id;
	public String name;

	public HbmBase()
	{
	}

	public HbmBase(Long id, String name)
	{
		this.id = id;
		this.name = name;
	}
}
