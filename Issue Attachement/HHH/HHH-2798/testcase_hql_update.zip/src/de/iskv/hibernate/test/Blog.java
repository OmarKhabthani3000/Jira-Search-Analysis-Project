package de.iskv.hibernate.test;
/**
 * class to persist. 
 */
public class Blog {
	
	private Long oid;
	private String url;
	private Person owner;
	
	public Long getOid() {
		return oid;
	}
	public void setOid(Long oid) {
		this.oid = oid;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Person getOwner() {
		return owner;
	}
	public void setOwner(Person owner) {
		this.owner = owner;
	}
	
	
}
