package de.iskv.hibernate.test;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

/**
 * Testcase to reproduce hibernate problem with HQL update
 */
public class HibernateSelectUpdateTestCase extends TestCase {
	
	/**
	 * The critical subselect statement (with two "member of" expressions!).  
	 */
	private static final String SUB_SELECT = "(select p.oid from de.iskv.hibernate.test.Person p, " +
			"de.iskv.hibernate.test.Address a, de.iskv.hibernate.test.Blog b where " +
			"a.city='New York' and b.url='http://mydomain.com/blogs/al' and a member of p.addresses and b member of p.blogs)";
	/**
	 * The select statement with subselect (working!)
	 */
	private static final String SELECT = "from de.iskv.hibernate.test.Person person where person.oid in " + SUB_SELECT;
	/**
	 * The update statement with subselect (NOT working!)
	 */
	private static final String UPDATE = "update de.iskv.hibernate.test.Person person set name = ' ' where person.oid in " + SUB_SELECT;
	
	public SessionFactory sessionFactory = null;
	
	/**
	 * Calls the select statement (working!). 
	 */
	public void testSelect() {
		if (sessionFactory!=null) {
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query query = session.createQuery(SELECT);
			query.list();
			tx.commit();
			session.close();
		}
	}
	
	/**
	 * Calls the update statement (NOT working!).
	 */
	public void testUpdate() {
		if (sessionFactory!=null) {
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query query = session.createQuery(UPDATE);
			query.executeUpdate();
			tx.commit();
			session.close();
		}
	}
	

	/**
	 * JUnit's setup - creation of configuration and session factory.
	 */
	protected void setUp() throws Exception {
		super.setUp();
        Configuration configuration = new Configuration();
        configuration.setProperty(Environment.DIALECT, "org.hibernate.dialect.DB2Dialect");
        configuration.setProperty(Environment.DRIVER, "com.ibm.db2.jcc.DB2Driver");
        configuration.setProperty(Environment.URL, System.getProperty("dbUrl"));
        configuration.setProperty(Environment.USER, System.getProperty("dbUser"));
        configuration.setProperty(Environment.PASS, System.getProperty("dbPwd"));
        configuration.setProperty(Environment.DEFAULT_SCHEMA, System.getProperty("dbSchema"));
        configuration.setProperty(Environment.SHOW_SQL, "true");
        configuration.setProperty(Environment.FORMAT_SQL, "true");
        configuration.setProperty(Environment.HBM2DDL_AUTO, "create-drop");
        configuration.addResource("de/iskv/hibernate/test/mapping.hbm");
        sessionFactory = configuration.buildSessionFactory();
	}

	/**
	 * JUnit's tear down - closes the session factory.
	 */
	protected void tearDown() throws Exception {
		if (sessionFactory!=null) {
			sessionFactory.close();
			sessionFactory = null;
		}
		super.tearDown();
	}

	/**
	 * Start JUnit (no arguments required - but System properties for database configuration: <p/>
	 * <el>
	 *   <li><b>dbUrl</b>=URL to database like jdbc:db2://<it>host</it>:<it>port</it>/<it>db name</it></li>
	 *   <li><b>dbUser</b>=database user name</li>
	 *   <li><b>dbPwd</b>=database password</li>
	 *   <li><b>dbSchema</b>=database schema to use</li>
	 * </el>
	 */
	public static void main(String[] args) {
		TestRunner.run(HibernateSelectUpdateTestCase.class);

	}

}
