package de.iskv.hibernate.test;

import java.util.HashSet;
import java.util.Set;

/**
 * class to persist. 
 */
public class Person {
	
	private Long oid;
	private String name;
	private String firstname;
	private Set<Address> addresses = new HashSet<Address>();
	private Set<Blog> blogs = new HashSet<Blog>();
	
	public Long getOid() {
		return oid;
	}
	public void setOid(Long oid) {
		this.oid = oid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	
	public void addAddress(Address pAddress) {
		addresses.add(pAddress);
	}
	
	public void removeAddress(Address pAddress) {
		if (addresses.contains(pAddress)) {
			addresses.remove(pAddress);
		}
	}
	public Set<Address> getAddresses() {
		return addresses;
	}
	
	
	public void addBlog(Blog pBlog) {
		blogs.add(pBlog);
	}
	
	public void removeBlog(Blog pBlog) {
		if (blogs.contains(pBlog)) {
			blogs.remove(pBlog);
		}
	}
	public Set<Blog> getBlogs() {
		return blogs;
	}
	
	

}
