package de.iskv.hibernate.test;

/**
 * class to persist. 
 */
public class Address {

	private Long oid;
	private String street;
	private String zipcode;
	private String city;
	
	private Person habitant;
	
	public Long getOid() {
		return oid;
	}
	public void setOid(Long oid) {
		this.oid = oid;
	}

	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Person getHabitant() {
		return habitant;
	}
	public void setHabitant(Person habitant) {
		this.habitant = habitant;
	}
	
	
}
