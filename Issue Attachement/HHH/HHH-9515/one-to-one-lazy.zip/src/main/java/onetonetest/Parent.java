package onetonetest;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Parent {
	@Id
    private Long id;

	@OneToOne(mappedBy = "parent", optional = false, fetch = FetchType.LAZY)
    private ChildWithFk child;

    public Long getId() {
        return id;
    }

	public ChildWithFk getChild() {
		return child;
	}
}
