package onetonetest;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class ChildWithFk {
	@Id
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PARENT_ID", nullable=false)
    private Parent parent;

    public Long getId() {
        return id;
    }

	public Parent getParent() {
		return parent;
	}
}
