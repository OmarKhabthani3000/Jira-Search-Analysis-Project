package onetoonetest;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import onetonetest.ChildWithFk;
import onetonetest.Parent;

import org.hibernate.Session;
import org.hibernate.jdbc.Work;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class LazyOneToOneTest {

	private static final String SCHEMA = "drop table if exists parent;"
			+ "drop table if exists childwithfk;"
			+ "create table parent (id bigint not null, primary key (id));"
			+ "create table childwithfk (id bigint not null, parent_id bigint null, primary key (id));"
			+ "alter table childwithfk add constraint fk_parent_id foreign key (parent_id) references parent;"

			+ "insert into parent(id) values (1);"
			+ "insert into childwithfk(id, parent_id) values (2, 1);";

	private static EntityManagerFactory emf;
	private EntityManager em;
	private PrintStream originalOut;

	@BeforeClass
	public static void beforeClass() {
		Map<String, String> props = new HashMap<>();

		props.put("hibernate.show_sql", "true");

		emf = Persistence.createEntityManagerFactory("h2", props);
	}

	@Before
	public void before() {
		em = emf.createEntityManager();

		em.getTransaction().begin();
		em.unwrap(Session.class).doWork(new Work() {
			@Override
			public void execute(Connection conn) throws SQLException {
				for (String stmt : SCHEMA.split(";")) {
					exec(conn, stmt);
				}
			}

		});

		em.getTransaction().commit();

		em.getTransaction().begin();

		originalOut = System.out;
	}

	private void exec(Connection conn, String stmt) throws SQLException {
		try (PreparedStatement prepareStatement = conn.prepareStatement(stmt)) {
			prepareStatement.executeUpdate();
		}
	}

	@After
	public void after() {
		if (originalOut != null) {
			System.setOut(originalOut);
		}

		em.getTransaction().rollback();
	}

	@Test
	public void childNotEagerLoaded() {

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(bos));

		// load parent only
		Parent parent = em.find(Parent.class, 1L);

		assertThat(bos.toString(), containsString("from Parent "));

		// no second query on ChildWithFk was done, yet
		assertThat(bos.toString(), not(containsString(" ChildWithFk ")));

		bos.reset();

		// access the child
		parent.getChild().getId();

		// now there is a query for the child
		assertThat(bos.toString(), containsString("from ChildWithFk "));
	}
	

	@Test
	public void parentNotEagerLoaded() {

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(bos));

		// load child only
		ChildWithFk child = em.find(ChildWithFk.class, 2L);

		assertThat(bos.toString(), containsString(" ChildWithFk "));

		// no second query on Parent was done, yet
		assertThat(bos.toString(), not(containsString("from Parent ")));

		bos.reset();

		// access the child
		child.getParent().getId();

		// now there is a query for the child
		assertThat(bos.toString(), containsString("from Parent "));
	}
}
