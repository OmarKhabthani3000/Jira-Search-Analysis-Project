package org.hibernate.bugs;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;
import java.util.HashMap;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.hibernate.bugs.model.MyEntity;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestBug {

    private EntityManager em;

    @Before
    public void setup() {

        em = Persistence.createEntityManagerFactory("domain").createEntityManager();
    }

    @After
    public void teardown() {
        em.close();
    }
    
    /*
     * This test demonstrates that when a map entry with a 
     * null value is added, it is never added to the database
     * and thus is silently "lost".
     */
    @Test
    public void testNullMapValue() {
    	em.getTransaction().begin();
    	MyEntity myEntity = new MyEntity();
    	myEntity.getValues().add("foo");
        em.persist(myEntity); 
        em.getTransaction().commit();
        
        // Verify that a row was added to the ElementCollection table
        Query q = em.createNativeQuery("select count(*) from MyEntity_values;");
        long count = ((BigInteger) q.getSingleResult()).longValue();
        assertEquals(1, count);
   
        // Verify that a row was added to the audit table
        // ** THIS FAILS **
		q = em.createNativeQuery("select count(*) from MyEntity_values_AUD;");
		count = ((BigInteger) q.getSingleResult()).longValue();
		assertEquals(1, count);
		
    }

}
