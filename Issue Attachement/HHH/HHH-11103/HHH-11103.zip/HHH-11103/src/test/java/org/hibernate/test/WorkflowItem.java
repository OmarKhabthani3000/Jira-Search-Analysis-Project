package org.hibernate.test;

public final class WorkflowItem {
    private static final long serialVersionUID = 1L;
    private Long id;
    private String name;
    public WorkflowItem() {
    }
    public String getName() {
        return name;
    }
    public void setName(String newName) {
        name = newName;
    }
}
