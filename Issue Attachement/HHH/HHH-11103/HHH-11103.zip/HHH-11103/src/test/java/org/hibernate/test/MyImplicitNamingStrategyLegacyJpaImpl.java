package org.hibernate.test;

import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.naming.ImplicitNamingStrategyLegacyJpaImpl;
import org.hibernate.boot.model.naming.ImplicitUniqueKeyNameSource;

public class MyImplicitNamingStrategyLegacyJpaImpl extends ImplicitNamingStrategyLegacyJpaImpl {

    private static final long serialVersionUID = 1L;

    @Override
    public Identifier determineUniqueKeyName(ImplicitUniqueKeyNameSource source) {
        System.err.println("determineUniqueKeyName for" + source.getTableName() + ": " + source.getColumnNames());
        if (source.getColumnNames().size() == 1) {
            return toIdentifier(source.getTableName() + "_" + source.getColumnNames().get(0) + "_key", source.getBuildingContext());
        } else {
            return super.determineUniqueKeyName(source);
        }
    }
}
