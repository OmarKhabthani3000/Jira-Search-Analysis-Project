package hibernate.bug;

import hibernate.bug.model.Animal;
import hibernate.bug.model.Cat;
import hibernate.bug.model.Person;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p = new Person();
        Cat c = new Cat(1, "c", p);
        
        em.persist(p);
        em.persist(c);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        
        List<Animal> l = em.createQuery(
                "SELECT pet FROM Animal pet, Animal owner "
                + "WHERE pet MEMBER OF TREAT(owner AS Person).pets")
                .getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
}
