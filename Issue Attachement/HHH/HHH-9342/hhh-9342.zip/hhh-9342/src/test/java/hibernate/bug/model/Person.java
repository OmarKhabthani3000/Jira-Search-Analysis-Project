package hibernate.bug.model;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

@Entity
public class Person extends Animal {

    private List<Animal> pets = new ArrayList<Animal>();

    public Person() {
    }

    public Person(String name) {
        super(name, null);
    }

    @OneToMany(mappedBy = "owner")
    public List<Animal> getPets() {
        return pets;
    }

    public void setPets(List<Animal> pets) {
        this.pets = pets;
    }

}
