package hibernate.bug.model;

import javax.persistence.Entity;

@Entity
public class Cat extends Animal {

    private int cuteness;

    public Cat() {
    }

    public Cat(int cuteness, String name, Person owner) {
        super(name, owner);
        this.cuteness = cuteness;
    }

    public int getCuteness() {
        return cuteness;
    }

    public void setCuteness(int cuteness) {
        this.cuteness = cuteness;
    }
}
