package org.hibernate.bugs;

import javax.persistence.Entity;

@Entity
public class ChildAEntity extends BaseEntity {
	@Override
	public String toString() {
		return "ChildA";
	}
}