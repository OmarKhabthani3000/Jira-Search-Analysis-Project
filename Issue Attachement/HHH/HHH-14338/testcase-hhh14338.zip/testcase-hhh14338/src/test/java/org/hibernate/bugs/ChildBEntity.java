package org.hibernate.bugs;

import javax.persistence.Entity;

@Entity
public class ChildBEntity extends BaseEntity {
	@Override
	public String toString() {
		return "ChildB";
	}
}
