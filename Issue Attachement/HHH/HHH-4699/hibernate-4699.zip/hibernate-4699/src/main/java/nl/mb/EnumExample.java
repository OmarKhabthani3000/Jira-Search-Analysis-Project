package nl.mb;

/**
 */
public enum EnumExample {
    LARGEST, SMALL;
}
