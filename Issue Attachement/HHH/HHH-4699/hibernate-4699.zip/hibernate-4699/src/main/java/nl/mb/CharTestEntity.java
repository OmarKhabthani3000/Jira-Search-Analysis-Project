package nl.mb;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 */
@Entity
public class CharTestEntity {
    @Id
    @GeneratedValue
    private int id;

    private EnumExample example;

    public EnumExample getExample() {
        return example;
    }
}
