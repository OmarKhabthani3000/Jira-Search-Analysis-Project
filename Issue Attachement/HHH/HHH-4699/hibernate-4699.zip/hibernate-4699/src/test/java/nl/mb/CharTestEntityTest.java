package nl.mb;

import org.hibernate.Session;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/**
 */
public class CharTestEntityTest {
    private static final String CREATE_TABLE = "create table CharTestEntity( id int not null, example char(7) not null)";

    @Test
    public void test() throws SQLException {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("4699");
        EntityManager em = emf.createEntityManager();
        final Session session = em.unwrap(Session.class);
        final Connection connection = session.connection();
        final Statement statement = connection.createStatement();
        statement.execute(CREATE_TABLE);
        statement.execute("insert into CharTestEntity values(1, '" + EnumExample.LARGEST.name() + "')");
        statement.execute("insert into CharTestEntity values(2, '" + EnumExample.SMALL.name() + "')");
        

        final List<CharTestEntity> resultList = em.createQuery("select c from CharTestEntity c").getResultList();
        for (CharTestEntity charTestEntity : resultList) {
            System.out.println("Enum: " + charTestEntity.getExample());
        }

        em.close();
        emf.close();
    }

}
