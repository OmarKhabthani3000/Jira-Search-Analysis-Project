package onetomanytestcase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import onetomanytestcase.entity.Document;
import onetomanytestcase.entity.Person;

import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class App {

    private static final Logger LOG = LoggerFactory.getLogger(App.class);

    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("myUnit");

    public static void main(String[] args) {

        fill();
        change();
        getRevision();

        emf.close();

        LOG.info("Success");

    }

    private static void fill() {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        List<Document> documents = new ArrayList<>();
        documents.add(new Document("doc 1"));
        documents.add(new Document("doc 2"));
        documents.add(new Document("doc 3"));
        Person person = new Person();
        person.setName("Person");
        person.setDocuments(documents);
        for (Document d : documents) {
            d.setPerson(person);
        }
        em.persist(person);

        tx.commit();
        em.close();
    }

    // change documents 
    private static void change() {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        Person persistedPerson = em.find(Person.class, 1);
        LOG.info("Persisted person: \n{}", persistedPerson);

        List<Document> updatedDocs = new ArrayList<>(persistedPerson.getDocuments());
        Collections.reverse(updatedDocs);
        Document docToRemove = updatedDocs.get(1);
        updatedDocs.remove(docToRemove);
        persistedPerson.setDocuments(updatedDocs);
        em.remove(docToRemove);

        tx.commit();
        em.close();
    }

    private static void getRevision() {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        AuditReader reader = AuditReaderFactory.get(em);
        List<Number> revs = reader.getRevisions(Person.class, 1);
        int latestIndex = revs.size() - 1;
        final Person latestPerson = reader.find(Person.class, 1, revs.get(latestIndex));
        LOG.info("Latest person revision: \n{}", latestPerson);

        tx.commit();
        em.close();
    }

}
