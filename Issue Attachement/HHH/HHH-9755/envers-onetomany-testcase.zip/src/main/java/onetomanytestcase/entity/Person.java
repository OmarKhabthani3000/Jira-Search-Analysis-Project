package onetomanytestcase.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;

import org.hibernate.envers.Audited;

@Entity
public class Person {

    @Id
    @GeneratedValue
    private Integer id;

    @Audited
    private String name;

    @Audited
    @OneToMany(mappedBy = "person", cascade = CascadeType.ALL)
    @OrderColumn(name = "index")
    private List<Document> documents;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Document> getDocuments() {
        return documents;
    }

    public void setDocuments(List<Document> documents) {
        this.documents = documents;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("id: ").append(id).append(System.lineSeparator());
        sb.append("name: ").append(name).append(System.lineSeparator());
        sb.append("documents: ").append(System.lineSeparator());
        for (Document doc : documents) {
            sb.append("    id: ").append(doc.getId()).append(System.lineSeparator());
            sb.append("    contents: ").append(doc.getContents()).append(System.lineSeparator());
        }
        return sb.toString();
    }

}
