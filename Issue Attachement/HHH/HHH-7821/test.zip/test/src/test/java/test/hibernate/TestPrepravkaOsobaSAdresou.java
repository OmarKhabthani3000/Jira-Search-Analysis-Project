package test.hibernate;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.Session;
import org.hibernate.context.spi.CurrentSessionContext;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Hodac Jan
 */
@RunWith(SpringJUnit4ClassRunner.class)
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@ContextConfiguration(locations = { "classpath:test-context-core.xml", "TestPrepravkaOsobaSAdresou-context.xml" })
@Transactional
public class TestPrepravkaOsobaSAdresou {
  
  @Entity(name = "RegKal")
  @Table(name = "REGKAL")
  public static class RegKal {

    @Id
    Long regKalId;

    String jmeno;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "regKal", orphanRemoval = true)
    Set<Detail> details = new HashSet<Detail>(0);
    
  }
  
  @Entity(name = "Detail")
  @Table(name = "DETAIL")
  public static class Detail {
    
    @Id
    Long detailId;
    
    String jmeno;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "regKalId")
    RegKal regKal;
    
    @ManyToMany(cascade = { CascadeType.MERGE, CascadeType.PERSIST }, fetch = FetchType.LAZY, targetEntity = Svatek.class)
    @JoinTable(name = "DETAIL_SVATEK_VAZBA", joinColumns = @JoinColumn(name = "detailId"), inverseJoinColumns = @JoinColumn(name = "svatekId"))
    Set<Svatek> svateks = new HashSet<Svatek>();

  }
  
  @Entity(name = "Svatek")
  @Table(name = "SVATEK")
  public static class Svatek {
    
    @Id
    Long svatekId;
  }
    
  @Autowired
  private CurrentSessionContext sessionContext;
  @Autowired
  private JdbcTemplate jdbcTemplate;
  
  @Before
  public void init() {
    jdbcTemplate.execute("delete from REGKAL");
    jdbcTemplate.execute("insert into REGKAL values(30, 'o3')");
    
    jdbcTemplate.execute("delete from DETAIL");
    jdbcTemplate.execute("insert into DETAIL values(3010, 'neco', 30)");
    jdbcTemplate.execute("insert into DETAIL values(3011, 'neco', 30)");
    jdbcTemplate.execute("insert into DETAIL values(3012, 'neco', 30)");
    
    jdbcTemplate.execute("delete from SVATEK");
    jdbcTemplate.execute("delete from DETAIL_SVATEK_VAZBA");
  }

  @Test
  public void testSessionGet() {
    RegKal o = (RegKal) getSession().get(RegKal.class, 30l);

    for (Detail a : o.details) {
      a.svateks.size();
    }
    
    getSession().clear();
    
    getSession().get(RegKal.class, 30l);

    o.details.remove(o.details.iterator().next());
    getSession().merge(o);

    getSession().flush();
    getSession().clear();

    o = (RegKal) getSession().get(RegKal.class, 30l);
    for (Detail a : o.details) {
      a.svateks.size();
    }
    
  }
  
  private Session getSession() {
    return sessionContext.currentSession();
  }

}