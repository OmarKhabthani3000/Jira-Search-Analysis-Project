package com.iav.playground.hibernate5;


import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Parent {
    @Id
    @GeneratedValue
    private Long id;

    @Convert(converter = StateJpaConverter.class)
    private State state;

    public Parent() {
    }

    public Parent(final State state) {
        this.state = state;
    }

    public Long getId() {
        return id;
    }

    public State getState() {
        return state;
    }
}
