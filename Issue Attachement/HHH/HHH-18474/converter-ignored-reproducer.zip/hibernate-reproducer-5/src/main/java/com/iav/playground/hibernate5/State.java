/*
 * This document contains trade secret data which is the property of
 * IAV GmbH. Information contained herein may not be used,
 * copied or disclosed in whole or part except as permitted by written
 * agreement from IAV GmbH.
 *
 * Copyright (C) IAV GmbH / Gifhorn / Germany
 */

package com.iav.playground.hibernate5;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum State {
  SOMESTATE(2),
  OTHER(3),
  EVENMORE(1);

  private static final Map<Integer, State> LOOKUP = new HashMap<>();

  static {
    for (State type : EnumSet.allOf(State.class)) {
      LOOKUP.put(type.getValue(), type);
    }
  }
  private final Integer value;

  State(final Integer value) {
    this.value = value;
  }

  public Integer getValue() {
    return value;
  }

  public static State getEnum(final Integer value) {
    return LOOKUP.get(value);
  }
}
