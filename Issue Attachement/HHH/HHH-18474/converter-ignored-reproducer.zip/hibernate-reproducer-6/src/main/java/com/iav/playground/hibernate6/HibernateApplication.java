package com.iav.playground.hibernate6;

import static com.iav.playground.hibernate6.State.SOMESTATE;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Tuple;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Root;

@SpringBootApplication
public class HibernateApplication implements CommandLineRunner {

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private PlatformTransactionManager transactionManager;

    public static void main(String[] args) {
        SpringApplication.run(HibernateApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        TransactionTemplate transactionTemplate = new TransactionTemplate(transactionManager);
        transactionTemplate.execute(status -> {
            entityManager.persist(new Parent(SOMESTATE));
            return null;
        });
        entityManager.clear();

        final CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        final CriteriaQuery<Tuple> cq = cb.createTupleQuery();
        final Root<Parent> from = cq.from(Parent.class);

        final Path<State> state = from.get(Parent_.state);

        cq.multiselect(cb.function("max", State.class, state));

        final TypedQuery<Tuple> query = entityManager.createQuery(cq);
        final List<Tuple> results = query.getResultList();

        // The result should be SOMESTATE
        final State resultState = results.get(0).get(0, State.class);
        if (!SOMESTATE.equals(resultState)) {
            throw new IllegalStateException("Wrong result. Expected SOMESTATE but got " + resultState);
        }
    }
}
