/*
 * This document contains trade secret data which is the property of
 * IAV GmbH. Information contained herein may not be used,
 * copied or disclosed in whole or part except as permitted by written
 * agreement from IAV GmbH.
 *
 * Copyright (C) IAV GmbH / Gifhorn / Germany
 */

package com.iav.playground.hibernate6;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter
public class StateJpaConverter implements AttributeConverter<State, Integer> {

  @Override
  public Integer convertToDatabaseColumn(final State state) {
    return state == null ? null : state.getValue();
  }

  @Override
  public State convertToEntityAttribute(final Integer dbData) {
    return dbData == null ? null : State.getEnum(dbData);
  }
}
