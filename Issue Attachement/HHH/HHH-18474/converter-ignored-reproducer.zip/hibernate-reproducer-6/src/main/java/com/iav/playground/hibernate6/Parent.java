package com.iav.playground.hibernate6;

import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Parent {
    @Id @GeneratedValue
    private Long id;

    @Convert(converter = StateJpaConverter.class)
    private State state;

    public Parent() {
    }

    public Parent(final State state) {
        this.state = state;
    }

    public Long getId() {
        return id;
    }

    public State getState() {
        return state;
    }
}
