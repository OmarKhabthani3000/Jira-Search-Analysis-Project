package org.hibernate.bugs;

import java.io.Serializable;



public class Params implements Serializable{
	
	
	private static final long serialVersionUID = 1L;
	
	private Version ver = Version.STD;
	private Level lvl = Level.NONE;
	
	
	public Params() {
		super();
		
	}
	
	
	public Params( Version ver, Level lvl) {
		super();
		
		this.ver = ver;
		this.lvl = lvl;
	}

	
	public Version getVer() {
		return ver;
	}
	public void setVer(Version ver) {
		this.ver = ver;
	}
	public Level getLvl() {
		return lvl;
	}
	public void setLvl(Level lvl) {
		this.lvl = lvl;
	}


	@Override
	public String toString() {
		return "Phone [ver=" + ver + ", lvl=" + lvl + "]";
	}

	

}
