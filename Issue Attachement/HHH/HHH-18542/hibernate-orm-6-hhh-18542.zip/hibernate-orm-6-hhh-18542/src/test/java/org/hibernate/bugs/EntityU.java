package org.hibernate.bugs;

import java.util.EnumMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;

import io.hypersistence.utils.hibernate.type.json.JsonType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;


@Entity
@Table(name = "entity_u")
public class EntityU {
	
	@Id
	private Long id;
	
	@Column(name="name")
	private String name;
	
	
	@OneToMany(mappedBy = "entityU", fetch = FetchType.LAZY)
	private Set<EntityUp> UpEntitys = new HashSet<>();


	@OneToOne(optional = false)
	@Fetch(FetchMode.JOIN)
	@JoinColumn(name = "entity_ua_id")
	private EntityUa entityUa;
	
	
	@Type(JsonType.class)
	@Column(name = "u_config", nullable = false,columnDefinition = "json")
	private Map<Function, Params> config = new EnumMap<>(Function.class);

	
	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof EntityU))
			return false;
		return id != null && id.equals(((EntityU) o).id);
	}

	@Override
	public int hashCode() {
		return 31;
	}
	
	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Set<EntityUp> getUpEntitys() {
		return UpEntitys;
	}


	public void setUpEntitys(Set<EntityUp> upEntitys) {
		UpEntitys = upEntitys;
	}


	public EntityUa getEntityUa() {
		return entityUa;
	}


	public void setEntityUa(EntityUa entityUa) {
		this.entityUa = entityUa;
	}


	public Map<Function, Params> getConfig() {
		return config;
	}


	public void setConfig(Map<Function, Params> config) {
		this.config = config;
	}


	


	

}
