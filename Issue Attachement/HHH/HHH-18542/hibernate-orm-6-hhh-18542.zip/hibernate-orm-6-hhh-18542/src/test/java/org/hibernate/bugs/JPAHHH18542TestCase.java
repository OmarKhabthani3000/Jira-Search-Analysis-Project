package org.hibernate.bugs;

import java.util.EnumMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
class JPAHHH18542TestCase {
	
	private static final Logger LOG = LogManager.getLogger(JPAHHH18542TestCase.class);


	private EntityManagerFactory entityManagerFactory;

	@BeforeEach
	void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@AfterEach
	void destroy() {
		entityManagerFactory.close();
	}

	private void initDb(EntityManager  em) {
		
		
		EntityUa ua1 = new EntityUa();
		ua1.setId(1l);
		ua1.setName("EntityUa-1-for-U1");
		em.persist(ua1);
		
		EntityUa ua2 = new EntityUa();
		ua2.setId(2l);
		ua2.setName("EntityUa-2-for-UP1");
		em.persist(ua2);
		
		
		EntityU u = new EntityU();
		u.setId(1l);
		u.setName("EntityU-1");
		u.setEntityUa(ua1);
		
		
		Map<Function, Params> config = new EnumMap<>(Function.class);
		
		config.put(Function.DA, new Params(Version.STD, Level.STD));
		
		u.setConfig(config);
		
		
		em.persist(u);
		
		EntityUp up = new EntityUp();
		up.setId(1l);
		up.setName("EntityUp-1");
		up.setEntityU(u);
		up.setEntityUa(ua2);
		em.persist(up);
		
		em.flush();
		
		em.detach(ua1);
		em.detach(ua2);
		
		em.detach(up);
		em.detach(u);
		
	}
	
	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	void hhh18542Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		LOG.info("### INIT DATA");
		initDb(entityManager);
		
		LOG.info("### START");
		EntityUp up  = entityManager.find(EntityUp.class, 1l);
		
		entityManager.flush();
		LOG.info("### END");
		
		// Do stuff...
		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
