package org.hibernate.bugs;

public enum Level {

	NONE, 
	STD,
	HELP
}
