package org.hibernate.bugs;

import java.math.BigDecimal;

import org.hibernate.annotations.Formula;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "entity_o")
public class EntityO {
	
	@Id
	private Long id;
	

	
	@Column(name = "val", nullable = false)
	private BigDecimal amount = BigDecimal.ZERO;


	@Column(name = "nb", nullable = false)
	private int nb = 0;
	
	@ManyToOne
	//@Fetch(FetchMode.SELECT)
	@JoinColumn(name = "entity_o_parent_id", referencedColumnName = "id", nullable = true)
	private EntityO parent;


	@Formula("(val*nb)")
	private BigDecimal totalValue;
	
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	

	
	public int getNb() {
		return nb;
	}

	public void setNb(int nb) {
		this.nb = nb;
	}

	public BigDecimal getTotalValue() {
		return totalValue;
	}

	public void setTotalValue(BigDecimal totalValue) {
		this.totalValue = totalValue;
	}

	public EntityO getParent() {
		return parent;
	}

	public void setParent(EntityO parent) {
		this.parent = parent;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	
	

}
