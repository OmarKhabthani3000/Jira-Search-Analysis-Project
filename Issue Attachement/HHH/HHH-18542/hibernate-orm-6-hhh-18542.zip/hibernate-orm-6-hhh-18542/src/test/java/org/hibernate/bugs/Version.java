package org.hibernate.bugs;

public enum Version {
	
	STD, 
	VOUCHER 
	
}
