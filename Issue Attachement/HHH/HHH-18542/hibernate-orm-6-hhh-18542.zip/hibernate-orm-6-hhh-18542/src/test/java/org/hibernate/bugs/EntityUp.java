package org.hibernate.bugs;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "entity_up")
public class EntityUp {

	@Id
	private Long id;
	
	@ManyToOne
	@Fetch(FetchMode.SELECT)
	@JoinColumn(name = "entity_u_id", referencedColumnName = "id", nullable = false)
	private EntityU entityU;
	
	
	@Column(name="name")
	private String name;

	
	@OneToOne(optional = false)
	@Fetch(FetchMode.SELECT)
	@JoinColumn(name = "entity_ua_id")
	protected EntityUa entityUa;

	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public EntityU getEntityU() {
		return entityU;
	}


	public void setEntityU(EntityU entityU) {
		this.entityU = entityU;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public EntityUa getEntityUa() {
		return entityUa;
	}


	public void setEntityUa(EntityUa entityUa) {
		this.entityUa = entityUa;
	}


	


	
	
}
