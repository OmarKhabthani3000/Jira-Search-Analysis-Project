package org.hibernate.bugs;

public enum Function {
	
	 LUNCH, // Organisation de dej
	 DA, // Distribution auto
	 SEND_FRIEND, // Envoi ami
	 QUICK_QR, // Raccourci QR
	 QUICK_REST, // Raccourci recherche resto
	 BONUSES, // BON PLAN
	 DONATION // Dons associations

}