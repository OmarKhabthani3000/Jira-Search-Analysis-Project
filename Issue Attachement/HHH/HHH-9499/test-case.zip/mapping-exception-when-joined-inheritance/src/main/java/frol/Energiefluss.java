package frol;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToMany;
import java.util.ArrayList;
import java.util.List;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Energiefluss {
    @Id
    private Long id;

    @OneToMany(mappedBy = "energiefluss")
    private List<Buchung> buchungen = new ArrayList<>();
}
