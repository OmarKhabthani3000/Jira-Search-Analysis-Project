package frol;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.ManyToOne;

@Entity
@Inheritance(strategy = javax.persistence.InheritanceType.JOINED)
public abstract class Buchung {
    @Id
    private Long id;

    @ManyToOne
    private Energiefluss energiefluss;
}
