package frol;

import javax.persistence.Entity;
import javax.persistence.OneToOne;

@Entity
public class Erzeugungsanlage extends Energiefluss {
    @OneToOne(mappedBy = "energiefluss")
    private Portfoliowirkung portfoliowirkung;
}
