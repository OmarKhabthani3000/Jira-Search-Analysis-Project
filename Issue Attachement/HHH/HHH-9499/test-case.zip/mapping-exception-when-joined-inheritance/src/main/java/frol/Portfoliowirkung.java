package frol;

import javax.persistence.Entity;

@Entity
public class Portfoliowirkung extends Buchung {
}
