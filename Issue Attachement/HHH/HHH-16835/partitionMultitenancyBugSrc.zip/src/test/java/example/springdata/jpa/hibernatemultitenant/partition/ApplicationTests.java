package example.springdata.jpa.hibernatemultitenant.partition;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTests {

    private static final String ADAM = "ADAM";

    private static final String EVE = "EVE";

    @Autowired
    PersonRepository personRepository;

    @Autowired
    TenantIdentifierResolver tenantIdentifierResolver;

    @Test
    void givenCurrentTenantIsSet_shouldNotReturnOtherTenants() {
        Person personAdam = new Person();
        personAdam.setName(ADAM);
        tenantIdentifierResolver.setCurrentTenant(ADAM);
        Person adamFromDb = personRepository.save(personAdam);

        Person personEve = new Person();
        personEve.setName(EVE);
        tenantIdentifierResolver.setCurrentTenant(EVE);
        Person eveFromDb = personRepository.save(personEve);

        Assertions.assertEquals(1, personRepository.findAll().size());

        //THIS CONDITION FAILS WHEN USING HIBERNATE VERSION 6.2
        Assertions.assertFalse(personRepository.findById(adamFromDb.getId()).isPresent());
    }

}
