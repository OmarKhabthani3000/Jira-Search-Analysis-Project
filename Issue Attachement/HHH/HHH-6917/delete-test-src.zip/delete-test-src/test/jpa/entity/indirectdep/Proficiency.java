package test.jpa.entity.indirectdep;

import javax.persistence.Basic;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

import test.jpa.entity.Base;

@Entity
public class Proficiency extends Base<ProficiencyPK> {
	private static final long serialVersionUID = 1L;
	@EmbeddedId
	private ProficiencyPK id;
	
	@MapsId("skillId")
	@ManyToOne
	private Skill skill;
	
	@MapsId("apprenticeId")
	@ManyToOne
	private Apprentice app;
	
	@Basic
	private double score;

	@Override
	public ProficiencyPK getId() {
		if(id == null) {
			id = new ProficiencyPK();
			id.setApprenticeId(app.getId());
			id.setSkillId(skill.getId());
		}
		return id;
	}

	public Skill getSkill() {
		return skill;
	}

	public void setSkill(Skill skill) {
		this.skill = skill;
	}

	public Apprentice getApp() {
		return app;
	}

	public void setApp(Apprentice app) {
		this.app = app;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public void setId(ProficiencyPK id) {
		this.id = id;
	}

	@Override public String toString() {
		return "{base: " + super.toString() 
				+ ", apprentice: " + app
				+ ", skill: " + skill
				+ "}";
	}
}
