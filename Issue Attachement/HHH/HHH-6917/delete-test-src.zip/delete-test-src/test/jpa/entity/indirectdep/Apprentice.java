package test.jpa.entity.indirectdep;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import test.jpa.entity.Base;

@Entity
public class Apprentice extends Base<Integer> {
	private static final long serialVersionUID = 1L;
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	@ManyToOne
	private Master master;

	@Override
	public Integer getId() {
		return id;
	}

	public Master getMaster() {
		return master;
	}

	public void setMaster(Master master) {
		this.master = master;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override public String toString() {
		return "{base: " + super.toString() 
				+ ", master.id:" + (null==master? "null": master.getId()) + "}";
	}
}
