package test.jpa.entity.indirectdep;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class ProficiencyPK implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer skillId;
	private Integer apprenticeId;
	
	public Integer getSkillId() {
		return skillId;
	}
	public void setSkillId(Integer skillId) {
		this.skillId = skillId;
	}
	public Integer getApprenticeId() {
		return apprenticeId;
	}
	public void setApprenticeId(Integer apprenticeId) {
		this.apprenticeId = apprenticeId;
	}
	
	@Override public String toString() {
		return "{skill.id: " + skillId + ", apprentice.id:" + apprenticeId + "}";
	}
}
