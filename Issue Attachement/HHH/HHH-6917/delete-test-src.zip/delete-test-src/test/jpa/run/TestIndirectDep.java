package test.jpa.run;

import java.util.List;

import test.jpa.entity.indirectdep.Apprentice;
import test.jpa.entity.indirectdep.Master;
import test.jpa.entity.indirectdep.Proficiency;
import test.jpa.entity.indirectdep.Skill;

public class TestIndirectDep extends TestBase {
	void generateSkill() {
		getEm();
		
		em.getTransaction().begin();
		for(int i = 0; i < 3; i++) {
			Skill s = new Skill();
			s.setName("Skill " + i);
			em.persist(s);
		}

		em.getTransaction().commit();
	}
	
	void insertData() {
		getEm();
		
		List<Skill> skills = em.createQuery("select e from Skill e", Skill.class).getResultList();
		
		Master m = new Master();
		m.setName("Master 001");
		
		em.getTransaction().begin();
		em.persist(m);
		for(int i = 0; i < 3; i++) {
			Apprentice a = new Apprentice();
			a.setName("App " + i);
			a.setMaster(m);
			em.persist(a);
			m.add(a);
			
			for(Skill s: skills) {
				Proficiency p = new Proficiency();
				p.setApp(a);
				p.setSkill(s);
				p.setScore(i);
				p.getId();
				em.persist(p);
			}
		}
		em.getTransaction().commit();
	}
	
	void test() {
		Master m = em.createQuery("select e from Master e", Master.class).getSingleResult();
		List<Skill> lsts = em.createQuery("select e from Skill e", Skill.class).getResultList();
		e("Master: " + m);
		e("Skills: " + lsts);
		
		List<Apprentice> lsta = m.getApps();
		e("Master " + m.getName() + " has " + (lsta == null? "null" : lsta.size()) + " apprentices");
		for(Apprentice a: lsta) {
			em.getTransaction().begin();
			List<Proficiency> lstp = em.createQuery("select e from Proficiency e where e.app=:app"
					, Proficiency.class).setParameter("app", a)
					.getResultList();
			e("Proficiency.size=" + lstp.size() + ", Skill.size=" + lsts.size());
			for(Proficiency p: lstp) {
				e("EM status: contais(p)?" + em.contains(p) 
						+ ",contains(a)?" + em.contains(a)
						+ ",contains(p.a)?" + em.contains(p.getApp()));
				em.remove(p);
			}
			/* Use the Query to delete directly from database. 
			int delCount = em.createQuery("delete from Proficiency e where e.app=:app")
				.setParameter("app", a).executeUpdate();
			o("Deleted Proficiency: " + delCount);
			*/
			em.remove(a);
			em.getTransaction().commit();
		}
		em.remove(m);
	}
	
	public static void main(String[] args) {
		TestIndirectDep t = new TestIndirectDep();
		t.generateSkill();
		t.insertData();
		t.test();
	}
}
