package test.jpa.run;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

// Provide some util(only)
public abstract class TestBase {
	@PersistenceContext
	protected EntityManager em;

	public EntityManager getEm() {
		if(null == em) {
			em = Persistence.createEntityManagerFactory("JPATest")
					.createEntityManager();			
		}
		return em;
	}
	
	protected void o(Object o) { System.out.println(o); }
	protected void e(Object o) { System.err.println(o); }
}
