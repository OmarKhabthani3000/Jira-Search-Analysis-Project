package test.jpa2;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.Test;

import test.jpa2.entity.EmbElement;
import test.jpa2.entity.Entity;

public class EmbededMapTest{
	
	@Test
	public void dotest() throws Exception
	{
		
		Map configOverrides = new HashMap();
		configOverrides.put("hibernate.hbm2ddl.auto", "create-drop");
		configOverrides.put("hibernate.show_sql", "true");		
		EntityManagerFactory programmaticEmf = null;
		
		try {
			programmaticEmf = Persistence.createEntityManagerFactory("manager1", configOverrides);
			//PB is Here : Unable to configure javax.persistence.PersistenceException:EntityManagerFactory : java.util.ConcurrentModificationException
		} catch (Exception e1) {
			
			
			e1.printStackTrace();
			throw e1;
		}
		
		EntityManager em = programmaticEmf.createEntityManager();

		//init datas
		
		em.getTransaction().begin();
		
		Entity e = new Entity();
		e.setVal("toto");
		
		EmbElement ee = new EmbElement();
		ee.setSsvalue("value1");
		ee.getSstring().add("s1");
		ee.getSstring().add("s2");
		ee.getSstring().add("s3");
		ee.getSstring().add("s4");
		
		e.getEmbElements().put("ee", ee);
		
		test(e);
		
		em.persist(e);
		em.getTransaction().commit();
		em.close();

		
		//reload and test
		
		em = programmaticEmf.createEntityManager();

		em.getTransaction().begin();
		
		Query q = em.createQuery("select e from Entity e",Entity.class);
		List<Entity> l = q.getResultList();
		assertTrue(l.size() == 1);		
		Entity er = l.get(0);
		test(er);
		
		em.getTransaction().commit();
		em.close();
		
		
	}
	

	
	private void test(Entity er)
	{
		assertTrue(er.getEmbElements().size() == 1);
		assertNotNull(er.getEmbElements().get("ee"));
		assertNotNull(er.getEmbElements().get("ee").getSsvalue());
		assertTrue(er.getEmbElements().get("ee").getSstring().size() == 4);
	}
	
}
