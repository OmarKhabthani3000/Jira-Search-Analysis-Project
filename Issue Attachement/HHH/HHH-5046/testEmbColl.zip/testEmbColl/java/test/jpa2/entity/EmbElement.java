package test.jpa2.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;



@Embeddable
public class EmbElement implements Serializable {

	private String ssvalue;
	
	@ElementCollection
	private Set<String> sstring = new HashSet<String>();

	
	public EmbElement() {
		super();
	}
	
	public Set<String> getSstring() {
		return sstring;
	}

	public void setSstring(Set<String> sstring) {
		this.sstring = sstring;
	}

	public String getSsvalue() {
		return ssvalue;
	}

	public void setSsvalue(String ssvalue) {
		this.ssvalue = ssvalue;
	}
	
}
