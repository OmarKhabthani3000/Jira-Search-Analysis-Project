package test.jpa2.entity;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.ElementCollection;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@javax.persistence.Entity
public class Entity implements Serializable {

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	private String val;

	@ElementCollection
	private Map<String, EmbElement> embElements =new HashMap<String, EmbElement>();
	
	
	public Entity() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Map<String, EmbElement> getEmbElements() {
		return embElements;
	}

	public void setEmbElements(Map<String, EmbElement> embElements) {
		this.embElements = embElements;
	}
	
	public String getVal() {
		return val;
	}

	public void setVal(String val) {
		this.val = val;
	}
	
}
