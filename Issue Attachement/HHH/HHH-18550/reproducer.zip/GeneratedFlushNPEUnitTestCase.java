package org.hibernate.bugs;

import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;


/**
 * Reproduces a NullPointerException in Hibernate 6.5+ when flushing a previously merged entity using
 * {@link org.hibernate.annotations.Generated} and {@link jakarta.persistence.ElementCollection}.
 */
class GeneratedFlushNPEUnitTestCase {

    private EntityManagerFactory entityManagerFactory;


    @BeforeEach
    void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
    }


    @AfterEach
    void destroy() {
        entityManagerFactory.close();
    }


    @Test
    void hhh123Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        var product = new ProductEntity();
        product.setId( UUID.randomUUID() );
        product.setName( "T-Shirt" );
        product.setVariants( List.of( "black", "blue" ) );
        entityManager.merge( product );
        // causes NullPointerException in Hibernate 6.5+
        entityManager.flush();

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
