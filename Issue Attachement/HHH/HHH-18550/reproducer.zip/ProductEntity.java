package org.hibernate.bugs;

import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import org.hibernate.annotations.Generated;
import org.hibernate.generator.EventType;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;


@Entity
@Table( name = "products" )
public class ProductEntity {

    @Id
    private UUID id;

    private String name;

    @Generated( event = { EventType.INSERT, EventType.UPDATE } )
    @Column( insertable = false, updatable = false )
    private Instant modificationDate;

    @ElementCollection( fetch = FetchType.EAGER )
    @CollectionTable( name = "product_variants",
            joinColumns = { @JoinColumn( name = "product_id", referencedColumnName = "id" ) } )
    @Column( name = "variant" )
    private List<String> variants;


    public UUID getId() {
        return id;
    }


    public void setId( UUID id ) {
        this.id = id;
    }


    public String getName() {
        return name;
    }


    public void setName( String name ) {
        this.name = name;
    }


    public Instant getModificationDate() {
        return modificationDate;
    }


    public void setModificationDate( Instant creationDate ) {
        this.modificationDate = creationDate;
    }


    public List<String> getVariants() {
        return variants;
    }


    public void setVariants( List<String> visibility ) {
        this.variants = visibility;
    }


    @Override
    public boolean equals( Object o ) {
        if( this == o )
            return true;
        if( o == null || getClass() != o.getClass() )
            return false;
        ProductEntity that = (ProductEntity)o;
        return Objects.equals( id, that.id );
    }


    @Override
    public int hashCode() {
        return Objects.hashCode( id );
    }


    @Override
    public String toString() {
        return "ProductEntity{" + "id=" + id + ", name='" + name + '\'' + ", modificationDate=" + modificationDate + ", variants=" + variants + '}';
    }
}
