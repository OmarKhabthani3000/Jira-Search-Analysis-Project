package org.hibernate.bug;


import org.hibernate.bug.entity.TestEntity;
import org.hibernate.bug.repository.TestRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BugTest {

    @Autowired private TestRepository repository;

    @Test
    public void reproduceHhh11699() throws Throwable {
        TestEntity entity = TestEntity.builder().text("abc").build();
        repository.save(entity);
        /*
         * Line above will generate:
         * select test_table_seq.nextval from dual
         * instead of:
         * select main.test_table_seq.nextval from dual
         */
    }


}

