package org.hibernate.bug.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

@Entity
@Table(name = "test_table", schema = "main")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Builder
public class TestEntity {

    @Id
    @SequenceGenerator(name = "test_table_seq", schema = "main", sequenceName = "test_table_seq", allocationSize = 1)
    @GeneratedValue(strategy = SEQUENCE, generator = "test_table_seq")
    @Column(name = "tt_id")
    private Long id;

    @Column(name = "tt_text")
    private String text;

}
