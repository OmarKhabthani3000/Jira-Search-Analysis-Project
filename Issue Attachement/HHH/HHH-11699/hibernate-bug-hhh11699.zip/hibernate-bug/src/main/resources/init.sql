-- main user/schema, who owns the tables
CREATE USER main
IDENTIFIED BY pswd
DEFAULT TABLESPACE default_tbs
TEMPORARY TABLESPACE bg_temp
QUOTA UNLIMITED ON default_tbs;
 
GRANT CREATE SESSION, CREATE TRIGGER, CREATE SEQUENCE, CREATE TABLE TO main;

-- user who will access the schema/tables/sequences
CREATE USER app
IDENTIFIED BY pswd
TEMPORARY TABLESPACE bg_temp
DEFAULT TABLESPACE users;
 
GRANT CREATE SESSION TO app;



-- below is the more important part, table, sequence and grants to the app user
CREATE TABLE main.test_table (
  tt_id         NUMBER(10)      CONSTRAINT tt_id_pk PRIMARY KEY USING INDEX TABLESPACE default_tbs,
  tt_text       VARCHAR2(4)     NULL,
) TABLESPACE default_tbs;

CREATE SEQUENCE main.test_table_seq START WITH 1 CACHE 50 NOORDER;


GRANT SELECT, UPDATE, INSERT, DELETE ON main.test_table TO app;
GRANT SELECT ON main.test_table_seq TO app;