package com.forio.hhh;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class HHH123Test {

  private ClassPathXmlApplicationContext context;
  private EntityManagerFactory entityManagerFactory;

  @BeforeClass
  public void beforeClass ()
    throws Exception {

    context = new ClassPathXmlApplicationContext("com/forio/hhh/test.xml");
    entityManagerFactory = context.getBean("entityManagerFactory", EntityManagerFactory.class);
  }

  @Test
  public void hhhTest123 () {

    EntityManager entityManager = entityManagerFactory.createEntityManager();
    EntityTransaction transaction = entityManager.getTransaction();

    transaction.begin();

    // select assignment
    //from World world, Assignment assignment
    //where world.id = assignment.worldId and assignment.pseudonymId = ?1 and (world.orbitType = ?2 and world.orbitId = ?3 or world.orbitType = ?4 and world.orbitId in (select episode.id
    //from Episode episode
    //where episode.groupId = ?5))
    entityManager.createQuery("select g from ReferencingEntity g where g.referencedId in (select d.id from ReferencedEntity d where d.color = 'blue')").getResultList();

    entityManager.flush();
    transaction.commit();
    entityManager.close();
  }
}
