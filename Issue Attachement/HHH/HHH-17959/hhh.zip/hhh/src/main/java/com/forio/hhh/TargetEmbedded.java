package com.forio.hhh;

public class TargetEmbedded {

  private String encoded;

  public TargetEmbedded () {

  }

  public TargetEmbedded (String encoded) {

    this.encoded = encoded;
  }

  public String getEncoded () {

    return encoded;
  }

  public void setEncoded (String encoded) {

    this.encoded = encoded;
  }
}
