package com.forio.hhh;

import jakarta.persistence.Cacheable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name = "referencing_entity")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class ReferencingEntity extends JPADurable<Long> {

  private String name;
  private long referencedId;

  @Column(name = "name", length = 191, nullable = false)
  public String getName () {

    return name;
  }

  public void setName (String name) {

    this.name = name;
  }

  @Column(name = "referenced_id", nullable = false, updatable = false)
  public long getReferencedId () {

    return referencedId;
  }

  public void setReferencedId (long referencedId) {

    this.referencedId = referencedId;
  }
}
