package com.forio.hhh;

import jakarta.persistence.Cacheable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name = "referenced_entity")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class ReferencedEntity extends JPADurable<Long> {

  private String color;

  @Column(name = "color", length = 191, nullable = false)
  public String getColor () {

    return color;
  }

  public void setColor (String color) {

    this.color = color;
  }
}
