package com.forio.hhh;

import java.io.Serializable;
import java.util.Objects;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.metamodel.spi.ValueAccess;
import org.hibernate.usertype.CompositeUserType;

public class TargetEmbeddedCompositeUerType implements CompositeUserType<TargetEmbedded> {

  @Override
  public boolean isMutable () {

    return false;
  }

  @Override
  public Class<?> embeddable () {

    return TargetedEmbeddedMapper.class;
  }

  @Override
  public Class<TargetEmbedded> returnedClass () {

    return TargetEmbedded.class;
  }

  @Override
  public boolean equals (TargetEmbedded x, TargetEmbedded y) {

    return Objects.equals(x, y);
  }

  @Override
  public int hashCode (TargetEmbedded x) {

    return Objects.hashCode(x);
  }

  @Override
  public TargetEmbedded deepCopy (TargetEmbedded value) {

    return value;
  }

  @Override
  public Serializable disassemble (TargetEmbedded value) {

    return (Serializable)value;
  }

  @Override
  public TargetEmbedded assemble (Serializable cached, Object owner) {

    return (TargetEmbedded)cached;
  }

  @Override
  public TargetEmbedded replace (TargetEmbedded detached, TargetEmbedded managed, Object owner) {

    return detached;
  }

  @Override
  public Object getPropertyValue (TargetEmbedded component, int property)
    throws HibernateException {

    if (component == null) {

      return null;
    } else {

      String[] abc = component.getEncoded().split("-", -1);

      // alphabetical
      return switch (property) {
        case 0 -> Integer.valueOf(abc[0]);
        case 1 -> Integer.valueOf(abc[1]);
        case 2 -> Integer.valueOf(abc[2]);
        default -> null;
      };
    }
  }

  @Override
  public TargetEmbedded instantiate (ValueAccess valueAccess, SessionFactoryImplementor sessionFactory)
    throws HibernateException {

    Object[] values = valueAccess.getValues();

    if (values.length == 3) {

      Integer a = (Integer)values[0];
      Integer b = (Integer)values[0];
      Integer c = (Integer)values[0];

      return new TargetEmbedded(((a == null) ? "0" : a.toString()) + "-" + ((b == null) ? "0" : b.toString()) + "-" + ((c == null) ? "0" : c.toString()));
    }

    return null;
  }

  public static class TargetedEmbeddedMapper {

    private Integer a;
    private Integer b;
    private Integer c;
  }
}
