package com.forio.hhh;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Cacheable;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.CompositeType;

@Entity
@Table(name = "parent_entity")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class ParentEntity {

  private Long id;
  private String color;
  private TargetEmbedded child;

  public ParentEntity () {

  }

  public ParentEntity (String color, TargetEmbedded child) {

    this.color = color;
    this.child = child;
  }

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", unique = true, nullable = false, updatable = false)
  public synchronized Long getId () {

    return id;
  }

  public synchronized void setId (Long id) {

    this.id = id;
  }

  @Column(name = "color", length = 25, updatable = false, nullable = false)
  public String getColor () {

    return color;
  }

  public void setColor (String color) {

    this.color = color;
  }

  @Embedded
  @AttributeOverride(name = "a", column = @Column(name = "a", nullable = false))
  @AttributeOverride(name = "b", column = @Column(name = "b", nullable = false))
  @AttributeOverride(name = "c", column = @Column(name = "c", nullable = false))
  @CompositeType(TargetEmbeddedCompositeUerType.class)
  public TargetEmbedded getChild () {

    return child;
  }

  public void setChild (TargetEmbedded child) {

    this.child = child;
  }
}
