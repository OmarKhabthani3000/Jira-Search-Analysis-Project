package com.forio.hhh;

import javax.sql.DataSource;
import org.smallmind.persistence.sql.DriverManagerDataSource;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;

public class DriverManagerDataSourceFactoryBean implements InitializingBean, FactoryBean<DataSource> {

  private DataSource dataSource;
  private String driverClassName;
  private String jdbcUrl;
  private String user;
  private String password;

  public void setDriverClassName (String driverClassName) {

    this.driverClassName = driverClassName;
  }

  public void setJdbcUrl (String jdbcUrl) {

    this.jdbcUrl = jdbcUrl;
  }

  public void setUser (String user) {

    this.user = user;
  }

  public void setPassword (String password) {

    this.password = password;
  }

  @Override
  public boolean isSingleton () {

    return true;
  }

  @Override
  public Class<?> getObjectType () {

    return DataSource.class;
  }

  @Override
  public void afterPropertiesSet ()
    throws Exception {

    dataSource = new DriverManagerDataSource(driverClassName, jdbcUrl, user, password);
  }

  @Override
  public DataSource getObject () {

    return dataSource;
  }
}
