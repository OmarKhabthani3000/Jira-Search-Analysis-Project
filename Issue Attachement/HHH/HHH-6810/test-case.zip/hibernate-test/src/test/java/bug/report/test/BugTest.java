package bug.report.test;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.hibernate.event.PreInsertEventListener;
import org.junit.Before;
import org.junit.Test;

import bug.report.SomeOtherThingPreInsertEventListenerCausingStackOverflow;
import bug.report.SomeUserPreInsertEventListenerQueryingSomeOtherThings;
import bug.report.model.SomeItem;
import bug.report.model.SomeOtherThing;
import bug.report.model.SomeUser;

public class BugTest {
	private SessionFactory sessionFactory;

	@Before
	public void setUp() {
		Configuration cfg = new Configuration() //
				.addAnnotatedClass(SomeUser.class) //
				.addAnnotatedClass(SomeItem.class) //
				.addAnnotatedClass(SomeOtherThing.class);//
		cfg
				.getEventListeners()
				.setPreInsertEventListeners(
						new PreInsertEventListener[] {
								new SomeUserPreInsertEventListenerQueryingSomeOtherThings(),
								new SomeOtherThingPreInsertEventListenerCausingStackOverflow() });

		sessionFactory = cfg.buildSessionFactory();
	}

	@Test
	public void testTwoRepresentationsOfTheSameCollection() {
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		// we have a simple one-to-many relationship: a user has some items
		SomeUser user = new SomeUser();
		user.setName("Some name");
		session.save(user);

		SomeItem item = new SomeItem();
		item.setDescription("Some description");
		user.addItem(item);
		session.save(item);

		// for some reason w need to call a flush here which triggers the
		// SomeUserPreInsertEventListenerQueryingSomeOtherThings. It queries
		// SomeOtherThings which are related neither with SomeUser nor with
		// SomeItem
		session.flush(); // 1st flush
		// the above flush left the persistence context in some illegal state
		// so that this commit (which issues another flush) fails
		session.getTransaction().commit(); // 2nd flush

		// note: this test succeeds if we either comment out the 1st flush or
		// don't register event listeners at all
	}

	@Test
	public void testStackOverflow() {
		// by the way did know this behavior?
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		SomeOtherThing someOtherThing = new SomeOtherThing();
		someOtherThing.setName("SomeOtherThing");
		session.save(someOtherThing);

		session.getTransaction().commit();
	}
}
