package bug.report;

import org.hibernate.event.PreInsertEvent;
import org.hibernate.event.PreInsertEventListener;

import bug.report.model.SomeOtherThing;

public class SomeOtherThingPreInsertEventListenerCausingStackOverflow implements
		PreInsertEventListener {
	private static final long serialVersionUID = 1430962408909560850L;

	public boolean onPreInsert(PreInsertEvent event) {
		Class<? extends Object> currentClass = event.getEntity().getClass();
		if (SomeOtherThing.class.equals(currentClass)) {
			event.getSession().createCriteria(SomeOtherThing.class).list();
		}
		return false;
	}
}
