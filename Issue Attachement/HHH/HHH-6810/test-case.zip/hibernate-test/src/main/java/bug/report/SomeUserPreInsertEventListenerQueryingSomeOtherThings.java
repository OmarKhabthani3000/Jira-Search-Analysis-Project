package bug.report;

import org.hibernate.event.PreInsertEvent;
import org.hibernate.event.PreInsertEventListener;

import bug.report.model.SomeOtherThing;
import bug.report.model.SomeUser;

public class SomeUserPreInsertEventListenerQueryingSomeOtherThings implements PreInsertEventListener {
	private static final long serialVersionUID = 7457725085286340589L;

	public boolean onPreInsert(PreInsertEvent event) {
		Class<? extends Object> currentClass = event.getEntity().getClass();
		if (SomeUser.class.equals(currentClass)) {
			event.getSession().createCriteria(SomeOtherThing.class).list();
		}
		return false;
	}
}
