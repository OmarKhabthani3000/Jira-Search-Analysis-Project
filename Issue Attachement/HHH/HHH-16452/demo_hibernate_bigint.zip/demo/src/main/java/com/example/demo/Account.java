package com.example.demo;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name="ACCOUNT")
public class Account {
	@Id
	@Column
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	protected Long id;

	@Column(nullable = false)
	protected String name;
}
