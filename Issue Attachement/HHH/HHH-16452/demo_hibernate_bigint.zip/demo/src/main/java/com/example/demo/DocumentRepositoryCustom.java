package com.example.demo;

import java.util.List;

public interface DocumentRepositoryCustom {
	List<Document> findAllForAccountId(Long userId);
}