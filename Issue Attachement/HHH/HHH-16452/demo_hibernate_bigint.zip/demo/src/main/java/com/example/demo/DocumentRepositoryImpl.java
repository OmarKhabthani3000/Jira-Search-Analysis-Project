package com.example.demo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.*;

@Repository
@Transactional
public class DocumentRepositoryImpl implements DocumentRepositoryCustom {
	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	public List<Document> findAllForAccountId(Long accountId) {
		Map<String,Object> paramMap = new HashMap<>();
		paramMap.put("accountId", BigInteger.valueOf(accountId));
		Query query = entityManager.createQuery("select creator.id = :accountId as ownership from Document");
		paramMap.keySet().forEach(key -> query.setParameter(key, paramMap.get(key)));

		@SuppressWarnings("unchecked")
		List<Object[]> results = query.getResultList();
		List<Document> result = new ArrayList<>(0);
		for (Object[] object : results) {
			Document document = (Document)object[0];
			result.add(document);

		}
		return result;
	}

}
