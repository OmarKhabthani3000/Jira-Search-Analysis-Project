CREATE TABLE
    DOCUMENT
    (
        ID bigint  ,
        NAME VARCHAR(255),
        CREATOR_USER_ID bigint,
        PRIMARY KEY (ID)
    );
CREATE TABLE
    ACCOUNT
    (
        ID bigint  ,
        name VARCHAR(255),
        PRIMARY KEY (ID)
    );
