CREATE USER 'hibernate_test'@'localhost';

GRANT USAGE ON * . * TO 'hibernate_test'@'localhost' WITH MAX_QUERIES_PER_HOUR 0 MAX_CONNECTIONS_PER_HOUR 0 MAX_UPDATES_PER_HOUR 0 MAX_USER_CONNECTIONS 0 ;

CREATE DATABASE IF NOT EXISTS `hibernate_test` ;

GRANT ALL PRIVILEGES ON `hibernate_test` . * TO 'hibernate_test'@'localhost';
