package transactiontest;

import junit.framework.TestCase;
import org.hibernate.Session;

import java.util.List;
import java.util.Set;

import transactiontest.model.Account;
import transactiontest.model.Transaction;

/**
 * TransactionTest.
 */
public class TransactionTest extends TestCase {
	public void testTransactions() {
		Session session = HibernateUtils.getSession();

		// delete all sessions and accounts
		session.createQuery("delete from Transaction").executeUpdate();
		session.createQuery("delete from Account").executeUpdate();
		session.flush();

		// create 3 accounts and save them
		Account account1 = new Account("a1");
		session.save(account1);
		Account account2 = new Account("a2");
		session.save(account2);
		Account account3 = new Account("a3");
		session.save(account3);

		// add some transactions to the accounts
		Transaction transaction1 = new Transaction(account1, account2, 10, Transaction.State.fromCommitted, "t1");
		session.save(transaction1);
		Transaction transaction2 = new Transaction(account3, account1, 20, Transaction.State.toCommitted, "t2");
		session.save(transaction2);
		Transaction transaction3 = new Transaction(account2, account3, 30, Transaction.State.toCommitted, "t3");
		session.save(transaction3);

		// get ID of the last account
		int account3Id = account3.getId();

		// flush and close
		session.flush();
		session.close();

		// reset hibernate connection
		HibernateUtils.resetSessionFactory();
		session = HibernateUtils.getSession();

		// load last account (a3)
		List<Account> accounts = session.createQuery("from Account where id = ?").setParameter(0, account3Id).list();
		assertEquals(1, accounts.size());
		Account account = accounts.get(0);
		System.out.println(account.getId());

		// execute named query with account ID of a3 and check the transactions
		List<Transaction> acc = session.getNamedQuery("transactions").setParameter("id", account.getId()).list();
		assertEquals(2, acc.size());
		for (Transaction transaction : acc) {
			System.out.println(transaction.getComment());
		}

		// get transations of account a3 via "transactions" property
		Set<Transaction> set = account.getTransactions();
		// next assertion fails on my computer
		assertEquals(2, set.size());
		for (Transaction transaction : set) {
			System.out.println(transaction.getComment());
		}

		session.close();
	}
}
