package transactiontest.model;

import transactiontest.model.Transaction;

import java.util.Calendar;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;

/**
 * Account.
 */
public class Account {
	private Integer id;
	private String name;
	private Set<Transaction> transactions = new TreeSet<Transaction>();

	public Account() {
	}
	
	public Account(String name) {
		this.name = name;
	}


	// getters and setters
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(Set<Transaction> transactions) {
		this.transactions = transactions;
	}
}
