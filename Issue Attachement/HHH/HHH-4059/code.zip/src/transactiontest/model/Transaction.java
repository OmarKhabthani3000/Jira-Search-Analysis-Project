package transactiontest.model;

import transactiontest.model.Account;

import java.util.Calendar;
import java.util.Date;

/**
 * Transaction between 2 accounts.
 *
 * @author Stefan Endrullis &lt;stefan@endrullis.de&gt;
 */
public class Transaction implements Comparable {
	public enum State { fromCommitted, toCommitted, bothCommitted }

	private Long id;
	private Account from;
	private Account to;
	private int amount; // TODO: ammount or amount?
	private Date creationDate;
	private Date commitDate;
	private State state = null;
	private String comment;

	public Transaction() {
	}

	public Transaction(Account from, Account to, int amount, State state, String comment) {
		this.from = from;
		this.to = to;
		this.amount = amount;
		this.creationDate = Calendar.getInstance().getTime();
		this.state = state;
		this.comment = comment;

		from.getTransactions().add(this);
		to.getTransactions().add(this);
	}

	public int compareTo(Object o) {
		if (o instanceof Transaction) {
		  Transaction other = (Transaction) o;
		  return creationDate.compareTo(other.creationDate);
		}
		return 0;
	}

	
// getters and setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Account getFrom() {
		return from;
	}

	public void setFrom(Account from) {
		this.from = from;
	}

	public Account getTo() {
		return to;
	}

	public void setTo(Account to) {
		this.to = to;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getCommitDate() {
		return commitDate;
	}

	public void setCommitDate(Date commitDate) {
		this.commitDate = commitDate;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public String getStateString() {
		return state.toString();
	}

	public void setState(String state) {
		this.state = State.valueOf(state);
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
}
