package transactiontest;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HibernateUtils {
	/** Session factory. */
	private static SessionFactory ourSessionFactory;

	static {
		resetSessionFactory();
	}

	/**
	 * Resets the hibernate session factory.
	 */
	public static void resetSessionFactory() {
		try {
			ourSessionFactory = new AnnotationConfiguration().
					configure("hibernate.cfg.xml").
					buildSessionFactory();
		}
		catch (Throwable ex) {
			throw new ExceptionInInitializerError(ex);
		}
	}

	/**
	 * Returns a new hibernate session using the hibernate configuration
	 * <code>hibernate.cfg.xml</code>.
	 *
	 * @return new hibernate session
	 * @throws HibernateException thrown if session creation fails
	 */
	public static Session getSession() throws HibernateException {
		return ourSessionFactory.openSession();
	}
}
