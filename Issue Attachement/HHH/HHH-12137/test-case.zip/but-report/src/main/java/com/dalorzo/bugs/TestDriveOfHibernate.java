package com.dalorzo.bugs;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import java.util.List;

public class TestDriveOfHibernate {

    public static void main(String[] args) {

        try (ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("classpath:hibernate-context.xml")) {

            EntityManagerFactory emf = context.getBean(EntityManagerFactory.class);
            System.out.println(emf.getProperties());

            try {
                //before running this get a lock on the record by running the following on the pgslq console
                //>
                //pgsql> begin;
                //pgsql> select tote_id from totes where facility = 'SLCW' and tote_id = '70005' FOR UPDATE;
                //>
                //don't commit the transaction just yet
                //now proceed to the first method invocation to force the socket timeout
                processRequest(emf);
                //now end the transaction you started in the console before you run this second method invocation
                //>
                // end;
                //
                //at this point the record is free to be taken and I should have one connection in the pool.
                processRequest(emf);
                //however, you will notice that the connection we used in the first invocation never got back to the pool
                //and this second method reports the pool is full, and fails.
            }
            finally {
                emf.close();
            }
        }
    }

    private static void processRequest(EntityManagerFactory emf) {
        EntityManager em = emf.createEntityManager();
        try {
            EntityTransaction tx = em.getTransaction();
            tx.begin();
            try {
                Query query = em.createNativeQuery("select tote_id from totes where facility = 'SLCW' and tote_id = '70005' FOR UPDATE");
                List<Object> totes = query.getResultList();
                System.out.println(totes);
                tx.commit();
            }
            catch (Exception e) {
                try {
                    tx.rollback();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                e.printStackTrace();
            }
        }
        finally {
            em.close();
        }
    }
}
