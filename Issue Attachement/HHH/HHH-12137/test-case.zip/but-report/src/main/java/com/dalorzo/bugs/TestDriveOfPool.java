package com.dalorzo.bugs;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TestDriveOfPool {


    public static void main(String[] args) {

        try (ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("classpath:data-context.xml")) {
            DataSource dataSource = context.getBean(DataSource.class);

            //before running this get a lock on the record by running the following on the pgslq console
            //>
            //pgsql> begin;
            //pgsql> select tote_id from totes where facility = 'SLCW' and tote_id = '70005' FOR UPDATE;
            //>
            //don't commit the transaction just yet
            //now proceed to the first method invocation to force the socket timeout
            processCall(dataSource);
            //now end the transaction you started in the console before you run this second method invocation
            //>
            // end;
            //
            //at this point the record is free to be taken and I should have one connection in the pool.
            processCall(dataSource);
            //success!!
            //it means DBCP Pool is fine
        }
    }

    private static void processCall(DataSource dataSource) {
        try(Connection conn = dataSource.getConnection()) {
            try(PreparedStatement pStm = conn.prepareStatement("select * from totes where facility = 'SLCW' and tote_id = '70005' FOR UPDATE")) {
                try(ResultSet rs = pStm.executeQuery()) {
                    while(rs.next()) {
                        System.out.println(rs.getInt("tote_id"));
                    }
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
