package hibernate.bug.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("bro")
public class Bro extends Person {

    public Bro() {
    }

    public Bro(String name) {
        super(name);
    }

}
