package hibernate.bug.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("nonbro")
public class NonBro extends Person {

    public NonBro() {
    }

    public NonBro(String name) {
        super(name);
    }

}
