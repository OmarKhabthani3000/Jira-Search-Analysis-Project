package org.hibernate.engine.jdbc;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Cache of string method -> int method resolutions
 *
 * @author MSpiegel
 */
public final class IntMethodCache {
	private static final float LOAD_FACTOR = .75f;

	private final ConcurrentHashMap<Method, Method> stringMethodToIntMethodCache;

	public IntMethodCache(int columnCount) {
		// should *not* need to grow beyond the size of the total number of columns in the rs
		this.stringMethodToIntMethodCache = new ConcurrentHashMap<Method, Method>( columnCount + (int)( columnCount * LOAD_FACTOR ) + 1, LOAD_FACTOR );
	}

	/**
	 * Resolve the int method for the given string method
	 *
	 * @param stringMethod The string method
	 * @param actualParameterTypes The array containing the parameter classes
	 *
	 * @return The int method
	 *
	 * @throws NoSuchMethodException Indicates a problem finding the corresponding int method
	 */
	@SuppressWarnings("UnnecessaryBoxing")
	public Method getIntMethodForStringMethod(Method stringMethod, Class actualParameterTypes[]) throws NoSuchMethodException {
		final Method cached = stringMethodToIntMethodCache.get( stringMethod );
		if ( cached != null ) {
			return cached;
		}
		else {
			final Method intMethod = stringMethod.getDeclaringClass().getMethod( stringMethod.getName(), actualParameterTypes );
			stringMethodToIntMethodCache.put( stringMethod, intMethod);
			return intMethod;
		}
	}
}
