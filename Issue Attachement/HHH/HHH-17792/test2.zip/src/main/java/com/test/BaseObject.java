package com.test;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotNull;

@MappedSuperclass
public abstract class BaseObject<I extends Serializable>  {

  private I id;

  @NotNull
  @Id
  public I getId() {
    return id;
  }

  public void setId(I id) {
    this.id = id;
  }}
