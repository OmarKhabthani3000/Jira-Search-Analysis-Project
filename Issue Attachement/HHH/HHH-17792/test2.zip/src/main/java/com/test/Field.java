package com.test;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@javax.persistence.Entity
@Table(name = "FIELD")
@AttributeOverride(name = "id", column = @Column(name = "ID_FIELD"))
public class Field extends BaseObject<Long> {

  private Entity entity;
  private Integer index;

  @NotNull
  @ManyToOne(optional = false, fetch = FetchType.LAZY)
  @JoinColumn(name = "ID_ENTITY", nullable = false, updatable = false)
  public Entity getEntity() {
    return entity;
  }

  public void setEntity(final Entity entity) {
    this.entity = entity;
  }

  @NotNull
  @Min(value = 0)
  public Integer getIndex() {
    return index;
  }

  public void setIndex(final Integer index) {
    this.index = index;
  }
}
