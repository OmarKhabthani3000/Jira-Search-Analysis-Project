package com.test;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

@Entity
@Table(name = "FORMAT")
@AttributeOverride(name = "id", column = @Column(name = "ID_FORMAT"))
public class Format extends BaseObject<Long> {

  private List<Sequence> sequences = new ArrayList<>();

  @OneToMany(mappedBy = "format", cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.DETACH})
  @OrderBy("index, id")
  public List<Sequence> getSequences() {
    return sequences;
  }

  public void setSequences(List<Sequence> sequences) {
    this.sequences = sequences;
  }
}
