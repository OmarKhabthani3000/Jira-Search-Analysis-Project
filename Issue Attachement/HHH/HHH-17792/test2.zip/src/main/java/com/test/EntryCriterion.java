package com.test;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "ENTRY_CRITERION")
@AttributeOverride(name = "id", column = @Column(name = "ID_ENTRY_CRITERION"))
public class EntryCriterion extends BaseObject<Long> {

  private Entry entry;

  private Field field;

  @NotNull
  @ManyToOne(optional = false, fetch = FetchType.LAZY)
  @JoinColumn(name = "ID_ENTRY", nullable = false, updatable = false)
  public Entry getEntry() {
    return entry;
  }

  public void setEntry(final Entry entry) {
    this.entry = entry;
  }

  @NotNull
  @ManyToOne(optional = false, fetch = FetchType.LAZY)
  @JoinColumn(name = "ID_FIELD", nullable = false, updatable = false)
  public Field getField() {
    return field;
  }

  public void setField(final Field field) {
    this.field = field;
  }
}
