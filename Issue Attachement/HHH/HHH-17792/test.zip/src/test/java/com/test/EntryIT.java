package com.test;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

@DataJpaTest(showSql = true)
class EntryIT {

  @Autowired
  private EntityManager entityManager;

  @Test
  void test() {
    Format format = new Format();
    format.setId(15L);
    entityManager.merge(format);

    TypedQuery<Entry> namedQuery = entityManager.createNamedQuery("Entry.getEntryForFormat", Entry.class);
    namedQuery.setParameter("format", format);

    namedQuery.getResultList();
  }

}
