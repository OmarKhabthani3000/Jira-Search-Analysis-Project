package com.test;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;

@Entity
@Table(name = "FORMAT")
@AttributeOverride(name = "id", column = @Column(name = "ID_FORMAT"))
public class Format extends BaseObject<Long> {

  private List<Sequence> sequences = new ArrayList<>();

  @OneToMany(mappedBy = "format", cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.DETACH})
  @OrderBy("index, id")
  public List<Sequence> getSequences() {
    return sequences;
  }

  public void setSequences(List<Sequence> sequences) {
    this.sequences = sequences;
  }
}
