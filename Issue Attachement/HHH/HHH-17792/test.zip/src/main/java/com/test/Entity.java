package com.test;

import java.util.Set;
import java.util.TreeSet;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;

@jakarta.persistence.Entity
@Table(name = "ENTITY")
@AttributeOverride(name = "id", column = @Column(name = "ID_ENTITY"))
public class Entity extends BaseObject<Long> {

  private Set<Field> fields = new TreeSet<>();

  @OneToMany(mappedBy = "entity", cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.DETACH})
  @OrderBy("index")
  public Set<Field> getFields() {
    return fields;
  }

  public void setFields(final Set<Field> fields) {
    this.fields = fields;
  }
}
