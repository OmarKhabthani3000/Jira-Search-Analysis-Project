package com.test;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

@jakarta.persistence.Entity
@Table(name = "SEQUENCE")
@AttributeOverride(name = "id", column = @Column(name = "ID_SEQUENCE"))
public class Sequence extends BaseObject<Long> {

  private Format format;
  private Entity entity;
  private Integer index;

  @NotNull
  @ManyToOne(optional = false, fetch = FetchType.LAZY)
  @JoinColumn(name = "ID_FORMAT", nullable = false, updatable = false)
  public Format getFormat() {
    return format;
  }

  public void setFormat(final Format format) {
    this.format = format;
  }

  @NotNull
  @ManyToOne(optional = false)
  @JoinColumn(name = "ID_ENTITE", nullable = false, updatable = false)
  public Entity getEntity() {
    return entity;
  }

  public void setEntity(final Entity entity) {
    this.entity = entity;
  }

  @NotNull
  @Min(value = 0)
  public Integer getIndex() {
    return index;
  }

  public void setIndex(final Integer index) {
    this.index = index;
  }
}
