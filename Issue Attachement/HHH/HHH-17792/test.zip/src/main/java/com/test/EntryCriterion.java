package com.test;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "ENTRY_CRITERION")
@AttributeOverride(name = "id", column = @Column(name = "ID_ENTRY_CRITERION"))
public class EntryCriterion extends BaseObject<Long> {

  private Entry entry;

  private Field field;

  @NotNull
  @ManyToOne(optional = false, fetch = FetchType.LAZY)
  @JoinColumn(name = "ID_ENTRY", nullable = false, updatable = false)
  public Entry getEntry() {
    return entry;
  }

  public void setEntry(final Entry entry) {
    this.entry = entry;
  }

  @NotNull
  @ManyToOne(optional = false, fetch = FetchType.LAZY)
  @JoinColumn(name = "ID_FIELD", nullable = false, updatable = false)
  public Field getField() {
    return field;
  }

  public void setField(final Field field) {
    this.field = field;
  }
}
