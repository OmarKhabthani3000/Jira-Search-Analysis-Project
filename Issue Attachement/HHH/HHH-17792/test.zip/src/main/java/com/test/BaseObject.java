package com.test;

import java.io.Serializable;

import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import jakarta.validation.constraints.NotNull;

@MappedSuperclass
public abstract class BaseObject<I extends Serializable>  {

  private I id;

  @NotNull
  @Id
  public I getId() {
    return id;
  }

  public void setId(I id) {
    this.id = id;
  }}
