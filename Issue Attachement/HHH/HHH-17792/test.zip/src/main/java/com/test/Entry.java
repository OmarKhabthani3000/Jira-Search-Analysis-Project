package com.test;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "ENTRY")
@AttributeOverride(name = "id", column = @Column(name = "ID_ENTRY"))
@NamedQuery(name = "Entry.getEntryForFormat", query = "select distinct r from Entry r join fetch r.criteria p where p.field in (select f from Format m join m.sequences t join t.entity e join e.fields f where m = :format)")
public class Entry extends BaseObject<Long> {

  private Set<EntryCriterion> criteria = new HashSet<>();

  @NotNull
  @Size(min = 1)
  @OneToMany(mappedBy = "entry", cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.DETACH })
  public Set<EntryCriterion> getCriteria() {
    return criteria;
  }

  public void setCriteria(final Set<EntryCriterion> criteria) {
    this.criteria = criteria;
  }
}
