package org.hibernate.bugs.hhh18129.entities;

import jakarta.persistence.Cacheable;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Cacheable
@Getter
@Setter
@Entity
public class Param {

    @Id
    private Long id;

    private String name;

    private Double factor;

}
