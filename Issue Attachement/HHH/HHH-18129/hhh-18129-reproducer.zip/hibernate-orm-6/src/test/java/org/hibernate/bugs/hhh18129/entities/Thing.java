package org.hibernate.bugs.hhh18129.entities;

import java.util.HashSet;
import java.util.Set;
import jakarta.persistence.Cacheable;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Cacheable
@Getter
@Setter
@Entity
public class Thing {

    @Id
    private Long id;

    private String name;

    @OneToMany(mappedBy = "thing", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ThingParamAssoc> thingParamAssoc = new HashSet<>();

}
