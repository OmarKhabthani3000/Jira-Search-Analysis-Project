package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.hibernate.bugs.hhh18129.entities.Param;
import org.hibernate.bugs.hhh18129.entities.Thing;
import org.hibernate.bugs.hhh18129.entities.ThingParamAssoc;
import org.hibernate.bugs.hhh18129.entities.ThingParamAssocId;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;
    private Param param1;

    @Before
	public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");

        // create Param
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        param1 = new Param();
        param1.setId(1L);
        param1.setName("Param1");
        param1.setFactor(1.0);
        em.persist(param1);

        em.getTransaction().commit();
        em.close();
	}

	@After
	public void destroy() {
        entityManagerFactory.close();
	}

	@Test
    public void hhh18129Test() throws Exception {
        // create new Thing and associate it with the existing Param

        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        Thing thing1 = new Thing();
        thing1.setId(1L);
        thing1.setName("Thing1");

        ThingParamAssocId thingParamAssocId = new ThingParamAssocId();
        thingParamAssocId.setThingId(thing1.getId());
        thingParamAssocId.setParamId(param1.getId());

        ThingParamAssoc thingParamAssoc = new ThingParamAssoc();
        thingParamAssoc.setId(thingParamAssocId);
        thingParamAssoc.setThing(thing1);
        thingParamAssoc.setParam(param1);

        thing1.getThingParamAssoc().add(thingParamAssoc);

        em.persist(thing1); // [1] jakarta.persistence.EntityExistsException: detached entity passed to persist: org.hibernate.bugs.hhh18129.entities.Param
        em.getTransaction().commit(); // [2]
        em.close();
	}
}

// [1] with caching: exception at `em.persist(thing1)`

// jakarta.persistence.EntityExistsException: detached entity passed to persist: org.hibernate.bugs.hhh18129.entities.Param
// Caused by: org.hibernate.PersistentObjectException: detached entity passed to persist: org.hibernate.bugs.hhh18129.entities.Param

// [2] without caching: exception at `em.getTransaction().commit()`

// jakarta.persistence.RollbackException: Error while committing the transaction
// Caused by: org.hibernate.exception.ConstraintViolationException: could not execute statement [Unique index or primary key violation: "PRIMARY KEY ON PUBLIC.PARAM(ID) ( /* key:1 */ CAST(1.0 AS DOUBLE PRECISION), CAST(1 AS BIGINT), 'Param1')";
// SQL statement: insert into Param (factor,name,id) values (?,?,?) [23505-224]] [insert into Param (factor,name,id) values (?,?,?)]

