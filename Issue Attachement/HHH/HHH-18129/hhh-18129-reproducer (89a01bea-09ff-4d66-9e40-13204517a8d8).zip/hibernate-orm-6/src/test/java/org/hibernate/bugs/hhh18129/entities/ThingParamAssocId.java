package org.hibernate.bugs.hhh18129.entities;

import java.io.Serializable;
import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class ThingParamAssocId implements Serializable {

    private Long thingId;
    private Long paramId;

}
