package org.hibernate.bugs.hhh18129.entities;

import jakarta.persistence.Cacheable;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Cacheable
@Getter
@Setter
@Entity
public class ThingParamAssoc {

    @EmbeddedId
    private ThingParamAssocId id;

    @ManyToOne
    @MapsId("thingId")
    @JoinColumn(name = "thingId")
    private Thing thing;

    @ManyToOne // no cascading defined, but Hibernate does PERSIST cascading
    @MapsId("paramId")
    @JoinColumn(name = "paramId")
    private Param param;

}
