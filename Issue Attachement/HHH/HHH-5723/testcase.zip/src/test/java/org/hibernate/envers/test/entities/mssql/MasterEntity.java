package org.hibernate.envers.test.entities.mssql;

import org.hibernate.envers.Audited;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.HashSet;
import java.util.Set;

/**
 * @author Dmitry Fursevich
 */
@Entity
@Audited
public class MasterEntity {
    private Integer id;
    private String data;
    private Set<SlaveEntity> slaves = new HashSet<SlaveEntity>();

    public MasterEntity() {
    }

    public MasterEntity(Integer id, String data) {
        this.id = id;
        this.data = data;
    }

    @Id
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Audited
    @OneToMany(targetEntity = SlaveEntity.class, mappedBy = "master")
    public Set<SlaveEntity> getSlaves() {
        return slaves;
    }

    public void setSlaves(Set<SlaveEntity> slaves) {
        this.slaves = slaves;
    }
}
