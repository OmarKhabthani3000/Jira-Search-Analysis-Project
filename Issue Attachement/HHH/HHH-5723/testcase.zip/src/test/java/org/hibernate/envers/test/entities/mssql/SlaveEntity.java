package org.hibernate.envers.test.entities.mssql;

import org.hibernate.envers.Audited;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * @author Dmitry Fursevich
 */
@Entity
@Audited
public class SlaveEntity {
    private Integer id;
    private String data;
    private MasterEntity master;

    public SlaveEntity() {
    }

    public SlaveEntity(Integer id, String data, MasterEntity master) {
        this.id = id;
        this.data = data;
        this.master = master;
    }

    @Id
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @ManyToOne(targetEntity = MasterEntity.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "masterId", nullable = false)
    public MasterEntity getMaster() {
        return master;
    }

    public void setMaster(MasterEntity master) {
        this.master = master;
    }
}
