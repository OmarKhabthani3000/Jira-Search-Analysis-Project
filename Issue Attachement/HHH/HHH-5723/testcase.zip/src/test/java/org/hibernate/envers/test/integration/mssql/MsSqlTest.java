package org.hibernate.envers.test.integration.mssql;

import org.hibernate.ejb.Ejb3Configuration;
import org.hibernate.envers.test.AbstractEntityTest;
import org.hibernate.envers.test.entities.mssql.MasterEntity;
import org.hibernate.envers.test.entities.mssql.SlaveEntity;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import javax.persistence.EntityManager;

/**
 * @author Dmitry Fursevich
 */
public class MsSqlTest extends AbstractEntityTest {
    @Override
    public void configure(Ejb3Configuration cfg) {
        cfg.addAnnotatedClass(MasterEntity.class);
        cfg.addAnnotatedClass(SlaveEntity.class);
    }

    @BeforeClass(dependsOnMethods = "init")
    public void initData() {
        EntityManager em = getEntityManager();

        em.getTransaction().begin();

        MasterEntity master = new MasterEntity(1, null);
        SlaveEntity slave = new SlaveEntity(2, "slaveData", master);

        em.persist(master);
        em.persist(slave);

        em.getTransaction().commit();
    }

    @Test
    public void test1() {
        EntityManager em = getEntityManager();

        em.getTransaction().begin();

        MasterEntity master = em.find(MasterEntity.class, 1);
        master.setData("masterData");
        em.merge(master);
        em.flush();
        em.clear();

        SlaveEntity slave = (SlaveEntity) em.createQuery("select slave from SlaveEntity slave where slave.master.id=1").getSingleResult();
        //slave.getMaster().getData();

        SlaveEntity slaveCopy = new SlaveEntity(3, slave.getData(), slave.getMaster());
        em.persist(slaveCopy);

        em.getTransaction().commit();
    }

    @Test
    public void test2() {
        EntityManager em = getEntityManager();

        em.getTransaction().begin();

        em.createQuery("Update MasterEntity master SET master.data = 'masterData' WHERE master.id = 1").executeUpdate();

        SlaveEntity slave = (SlaveEntity) em.createQuery("select slave from SlaveEntity slave where slave.master.id=1").getSingleResult();

        SlaveEntity slaveCopy = new SlaveEntity(3, slave.getData(), slave.getMaster());
        em.persist(slaveCopy);

        em.getTransaction().commit();
    }
}
