import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;

import org.dbunit.database.DatabaseSequenceFilter;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.FilteredDataSet;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatDtdDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.ext.oracle.OracleConnection;

public class DatabaseExportSample
{
	public static void main(String[] args) throws Exception
	{
		// database connection
		Class.forName("oracle.jdbc.OracleDriver");
		Connection jdbcConnection = DriverManager.getConnection(
				"jdbc:oracle:thin:@//R6B5:1532/DVPATV6", "formationj2eedev", "commun");
		IDatabaseConnection conn = new OracleConnection(jdbcConnection, "FORMATIONJ2EEDEV");

		DatabaseSequenceFilter filter = new DatabaseSequenceFilter(conn);

		IDataSet dataset = new FilteredDataSet(filter, conn.createDataSet());

		FlatDtdDataSet.write(dataset, new FileOutputStream("data.dtd"));
		FlatXmlDataSet.write(dataset, new FileOutputStream("data.xml"));
	}
}
