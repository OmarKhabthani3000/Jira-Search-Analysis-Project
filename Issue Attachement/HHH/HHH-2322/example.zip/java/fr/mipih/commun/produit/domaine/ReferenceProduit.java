// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.domaine;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.model.Identifiable;

import fr.mipih.foundation.type.PrixUnitaire2;
import fr.mipih.foundation.type.Quantite;

import java.io.Serializable;

import java.util.Date;


/**
 * Objet ReferenceProduit.
 */
public class ReferenceProduit extends Identifiable implements Serializable
{
	/** Identifiant de l'objet. */
	private String id;

	protected PrixUnitaire2 prix;
	private Date delaiLivraison;
	private Quantite quantiteEnStock;
	// Association unaire obligatoire
	private Fournisseur fournisseur; 
	private Produit produit;


	/**
	 * Constructeur par d�faut.
	 */
	public ReferenceProduit()
	{
	}

	/**
	 * Constructeur avec initialisation de la r�f�rence vers produit.
	 * @param produit la r�f�rence vers l'objet parent
	 */
	public ReferenceProduit(Produit produit)
	{
		this.produit = produit;
	}


	public Serializable getId()
	{
		return id;
	}
	
	public void setId(Serializable id)
	{
		this.id = (String)id;
	}

	/**
	 * Retourne l'attribut prix.
	 * @return l'attribut prix.
	 */
	public PrixUnitaire2 getPrix()
	{
		return prix;
	}
	
	/**
	 * D�finit l'attribut prix.
	 * @param code L'attribut prix.
	 */
	public void setPrix(PrixUnitaire2 prix)
	{
		this.prix = prix;
	}

	/**
	 * Retourne l'attribut delaiLivraison.
	 * @return l'attribut delaiLivraison.
	 */
	public Date getDelaiLivraison()
	{
		return delaiLivraison;
	}
	
	/**
	 * D�finit l'attribut delaiLivraison.
	 * @param code L'attribut delaiLivraison.
	 */
	public void setDelaiLivraison(Date delaiLivraison)
	{
		this.delaiLivraison = delaiLivraison;
	}

	/**
	 * Retourne l'attribut quantiteEnStock.
	 * @return l'attribut quantiteEnStock.
	 */
	public Quantite getQuantiteEnStock()
	{
		return quantiteEnStock;
	}
	
	/**
	 * D�finit l'attribut quantiteEnStock.
	 * @param code L'attribut quantiteEnStock.
	 */
	public void setQuantiteEnStock(Quantite quantiteEnStock)
	{
		this.quantiteEnStock = quantiteEnStock;
	}


	/**
	 * Renvoie l'objet parent de l'objet courant (composition).
	 * @return l'objet parent de l'objet courant.
	 */
	public Fournisseur getFournisseur()
	{
		return fournisseur;
	}
	
	/**
	 * Positionne l'objet parent de l'objet courant (composition).
	 * @param fournisseur l'objet parent de l'objet courant.
	 */
	public void setFournisseur(Fournisseur fournisseur)
	{
		this.fournisseur = fournisseur;
	}

	/**
	 * Retourne la r�f�rence 'produit'.
	 * @return la r�f�rence 'produit'.
	 */
	public Produit getProduit()
	{
		return produit;
	}

	/**
	 * D�finit la r�f�rence 'produit'.
	 * @param categorie la r�f�rence 'produit'.
	 */
	public void setProduit(Produit produit)
	{
		this.produit = produit;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + prix + " " + delaiLivraison + " " + quantiteEnStock;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
