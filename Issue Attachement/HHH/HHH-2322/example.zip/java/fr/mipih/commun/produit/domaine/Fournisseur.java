// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.domaine;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.model.Identifiable;

import fr.mipih.foundation.type.Taux;

import java.io.Serializable;


/**
 * Objet Fournisseur.
 */
public class Fournisseur extends Identifiable implements Serializable
{
	/** Identifiant de l'objet. */
	private String id;


	/** 
	 * La raison sociale de l'entreprise.
	 */
	private String nom;

	/** 
	 * L'entreprise est-elle certifi�e ISO ?
	 */
	private Boolean certifieISO;

	/** 
	 * Gr�ce � l'anciennet�, il est possible d'obtenir des r�ductions 
	 * variables pour.
	 * <p>
	 * chacun des fournisseurs. Ce nombre est un pourcentage (allant de 0 � 
	 * 100%)
	 * </p>
	 * <p>
	 * qui indique la valeur de cette r�duction.
	 * </p>
	 */
	private Taux tauxReduction;




	/**
	 * Constructeur par d�faut.
	 */
	public Fournisseur()
	{
	}



	public Serializable getId()
	{
		return id;
	}
	
	public void setId(Serializable id)
	{
		this.id = (String)id;
	}

	/**
	 * Retourne l'attribut nom.
	 * @return l'attribut nom.
	 */
	public String getNom()
	{
		return nom;
	}
	
	/**
	 * D�finit l'attribut nom.
	 * @param code L'attribut nom.
	 */
	public void setNom(String nom)
	{
		this.nom = nom;
	}

	/**
	 * Retourne l'attribut certifieISO.
	 * @return l'attribut certifieISO.
	 */
	public Boolean getCertifieISO()
	{
		return certifieISO;
	}
	
	/**
	 * D�finit l'attribut certifieISO.
	 * @param code L'attribut certifieISO.
	 */
	public void setCertifieISO(Boolean certifieISO)
	{
		this.certifieISO = certifieISO;
	}

	/**
	 * Retourne l'attribut tauxReduction.
	 * @return l'attribut tauxReduction.
	 */
	public Taux getTauxReduction()
	{
		return tauxReduction;
	}
	
	/**
	 * D�finit l'attribut tauxReduction.
	 * @param code L'attribut tauxReduction.
	 */
	public void setTauxReduction(Taux tauxReduction)
	{
		this.tauxReduction = tauxReduction;
	}





	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + nom + " " + certifieISO + " " + tauxReduction;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
