// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.services.serviceregion;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.client.domaine.Region;
import fr.mipih.commun.client.domaine.Ville;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.CrudService;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.List;


/**
 * Element ServiceRegion.
 */
public interface IServiceRegion extends CrudService
{

	/**
	 * Valide un(e) <code>ville</code> pour la relation <code>villes</code>.
	 * @param ville
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>ville</code> n'est pas valide
	 */	
	public void validateVilles(Ville ville);

	//===============================================================
	// M�thodes CRUD de l'objet Region
	//===============================================================

	/**
	 * Retourne la liste de toutes les objets Region.
	 * @return la liste de tous les objets Region.
	 */
	public List<Region> findAllRegion();

	/**
	 * Retourne la liste des objets Region.
	 * @param criteria Les crit�res de recherche.
	 * @return les Region correspondant aux crit�res.
	 */
	public List<Region> findRegion(AbstractCriteria criteres);

	/**
	 * Charge un objet Region � partir de son id.
	 * @param id l'id de l'objet � charger.
	 * @return l'objet Region correspondant � l'id donn�.
	 */
	public Region loadRegionById(Serializable id);

	/**
	 * Enregistre un objet Region.
	 * @param obj l'objet Region � enregistrer.
	 * @return l'objet Region enregistr�.
	 */
	public Region storeRegion(Identifiable obj);

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}