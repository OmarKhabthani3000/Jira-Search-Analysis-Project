// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.domaine;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.entreprise.domaine.Entreprise;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.Date;


/**
 * Objet Client.
 */
public class Client extends Identifiable implements Serializable
{


	protected Integer identifiantClient;
	private String prenom;
	private String nom;
	private Date dateNaissance;

	/** 
	 * Le client est-il un particulier ou une entreprise ?
	 */
	private Boolean particulier;
	// Composition unaire optionnelle
	private Compte compte; 
	// Composition unaire obligatoire
	private Adresse adresseFacturation = new Adresse(this); 
	// Association unaire obligatoire
	private Entreprise entreprise; 



	/**
	 * Constructeur par d�faut.
	 */
	public Client()
	{
	}



	public Serializable getId()
	{
		return identifiantClient;
	}
	
	public void setId(Serializable id)
	{
		/*
		 * FIXME: on g�re les Integer et les String � cause de Struts uniquement
		 * � terme il faudra g�rer ici uniquement les objets Integer!
		 * getId() renvoyant un objet de type Serializable, Struts ne sait pas
		 * convertir l'objet saisi (de type String) en objet de type Integer car
		 * il ne peut pas deviner le type de l'ID !
		 */
		if (id == null || "".equals(id))
		{
			this.identifiantClient = null;
		}
		else
		{
			// si c'est une chaine, on la transforme en Integer
			this.identifiantClient = id instanceof String ? new Integer((String)id) : (Integer)id;
		}
		
	}
	

	/**
	 * Retourne l'attribut identifiantClient.
	 * @return l'attribut identifiantClient.
	 */
	public Integer getIdentifiantClient()
	{
		return identifiantClient;
	}
	
	/**
	 * D�finit l'attribut identifiantClient.
	 * @param code L'attribut identifiantClient.
	 */
	public void setIdentifiantClient(Integer identifiantClient)
	{
		this.identifiantClient = identifiantClient;
	}

	/**
	 * Retourne l'attribut prenom.
	 * @return l'attribut prenom.
	 */
	public String getPrenom()
	{
		return prenom;
	}
	
	/**
	 * D�finit l'attribut prenom.
	 * @param code L'attribut prenom.
	 */
	public void setPrenom(String prenom)
	{
		this.prenom = prenom;
	}

	/**
	 * Retourne l'attribut nom.
	 * @return l'attribut nom.
	 */
	public String getNom()
	{
		return nom;
	}
	
	/**
	 * D�finit l'attribut nom.
	 * @param code L'attribut nom.
	 */
	public void setNom(String nom)
	{
		this.nom = nom;
	}

	/**
	 * Retourne l'attribut dateNaissance.
	 * @return l'attribut dateNaissance.
	 */
	public Date getDateNaissance()
	{
		return dateNaissance;
	}
	
	/**
	 * D�finit l'attribut dateNaissance.
	 * @param code L'attribut dateNaissance.
	 */
	public void setDateNaissance(Date dateNaissance)
	{
		this.dateNaissance = dateNaissance;
	}

	/**
	 * Retourne l'attribut particulier.
	 * @return l'attribut particulier.
	 */
	public Boolean getParticulier()
	{
		return particulier;
	}
	
	/**
	 * D�finit l'attribut particulier.
	 * @param code L'attribut particulier.
	 */
	public void setParticulier(Boolean particulier)
	{
		this.particulier = particulier;
	}


	public Compte getCompte()
	{
		return compte;
	}
	
	public void setCompte(Compte compte)
	{
		if (this.compte != null)
		{
			this.compte.setClient(null);
		}
		this.compte = compte;
		if (compte != null)
		{
			compte.setClient(this);
		}
	}


	public Adresse getAdresseFacturation()
	{
		return adresseFacturation;
	}
	
	public void setAdresseFacturation(Adresse adresseFacturation)
	{
		if (this.adresseFacturation != null)
		{
			this.adresseFacturation.setClient(null);
		}
		this.adresseFacturation = adresseFacturation;
		if (adresseFacturation != null)
		{
			adresseFacturation.setClient(this);
		}
	}


	/**
	 * Renvoie l'objet parent de l'objet courant (composition).
	 * @return l'objet parent de l'objet courant.
	 */
	public Entreprise getEntreprise()
	{
		return entreprise;
	}
	
	/**
	 * Positionne l'objet parent de l'objet courant (composition).
	 * @param entreprise l'objet parent de l'objet courant.
	 */
	public void setEntreprise(Entreprise entreprise)
	{
		this.entreprise = entreprise;
	}




	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + identifiantClient + " " + prenom + " " + nom + " " + dateNaissance + " " + particulier;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
