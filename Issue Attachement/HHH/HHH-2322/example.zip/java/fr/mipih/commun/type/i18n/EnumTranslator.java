// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.type.i18n;

import org.apache.commons.lang.ClassUtils;

import fr.mipih.foundation.core.i18n.Translator;

public class EnumTranslator extends Translator
{
	private static final String BUNDLE_NAME = ClassUtils.getPackageName(EnumTranslator.class) + ".enum";
	private static EnumTranslator instance = new EnumTranslator();

	private EnumTranslator()
	{
		super(BUNDLE_NAME);
	}

	public static EnumTranslator getInstance()
	{
		return instance;
	}
}