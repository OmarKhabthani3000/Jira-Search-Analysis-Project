// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.services.serviceville.implementation;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.client.dao.IVilleDao;

import fr.mipih.commun.client.domaine.Ville;

import fr.mipih.commun.client.services.serviceregion.IServiceRegion;

import fr.mipih.commun.client.services.serviceville.IServiceVille;

import fr.mipih.foundation.core.BeanRegistry;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.AbstractCrudService;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.List;

import org.springframework.util.Assert;


/**
 * Element ServiceVille.
 */
public class ServiceVille extends AbstractCrudService implements IServiceVille 
{
	// [DEBUT:ATTRIBUT]
	// [FIN:ATTRIBUT]

	/**
	 * Cette m�thode doit �tre syst�matiquement utilis�e pour appeler une autre m�thode. Au lieu
	 * d'appeler methodeB() directement depuis methodeA(), il faut appeler
	 * <code>getCurService().methodeB()</code>.
	 * 
	 * @return le proxy transactionnel de ce service, � utiliser syst�matiquement.
	 */
	@SuppressWarnings("unused")
	private IServiceVille getCurService()
	{
		IServiceVille service = (IServiceVille)BeanRegistry.getService("serviceVille");
		Assert.notNull(service,"Impossible de r�cup�rer le service courant, " +
					"v�rifiez votre configuration.");
			return service;
	}

	/**
	 * Retourne le service ServiceRegion.
	 * @return
	 *		Le service ServiceRegion
	 */
	public IServiceRegion getServiceRegion()
	{
		return (IServiceRegion)BeanRegistry.getService("serviceRegion");
	}





	//===============================================================
	// M�thodes CRUD de l'objet Ville
	//===============================================================

	@SuppressWarnings("unchecked")
	public List<Ville> findAllVille()
	{
		return getVilleDao().findAll();
	}

	@SuppressWarnings("unchecked")
	public List<Ville> findVille(AbstractCriteria criteres)
	{
		return (List<Ville>)getVilleDao().find(criteres);
	}

	public Ville loadVilleById(Serializable id)
	{
		return (Ville)getVilleDao().loadById(id);
	}

	public Ville storeVille(Identifiable obj)
	{
		return (Ville)getVilleDao().store(obj);
	}

	/**
	 * Retourne le DAO Ville.
	 * @return le DAO Ville
	 */
	public IVilleDao getVilleDao()
	{
		return (IVilleDao)BeanRegistry.getDao("villeDao");
	}
	// [DEBUT:METHODES]
	// [FIN:METHODES]
}