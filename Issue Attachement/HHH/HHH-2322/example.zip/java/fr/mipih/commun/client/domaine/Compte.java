// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.domaine;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;


/**
 * Objet Compte.
 */
public class Compte extends Identifiable implements Serializable
{


	protected Integer id;
	private String numero;

	private Client client;


	/**
	 * Constructeur par d�faut.
	 */
	public Compte()
	{
	}

	/**
	 * Constructeur avec initialisation de la r�f�rence vers client.
	 * @param client la r�f�rence vers l'objet parent
	 */
	public Compte(Client client)
	{
		this.client = client;
	}


	public Serializable getId()
	{
		return id;
	}
	
	public void setId(Serializable id)
	{
		/*
		 * FIXME: on g�re les Integer et les String � cause de Struts uniquement
		 * � terme il faudra g�rer ici uniquement les objets Integer!
		 * getId() renvoyant un objet de type Serializable, Struts ne sait pas
		 * convertir l'objet saisi (de type String) en objet de type Integer car
		 * il ne peut pas deviner le type de l'ID !
		 */
		if (id == null || "".equals(id))
		{
			this.id = null;
		}
		else
		{
			// si c'est une chaine, on la transforme en Integer
			this.id = id instanceof String ? new Integer((String)id) : (Integer)id;
		}
		
	}
	

	/**
	 * Retourne l'attribut numero.
	 * @return l'attribut numero.
	 */
	public String getNumero()
	{
		return numero;
	}
	
	/**
	 * D�finit l'attribut numero.
	 * @param code L'attribut numero.
	 */
	public void setNumero(String numero)
	{
		this.numero = numero;
	}


	/**
	 * Retourne la r�f�rence 'client'.
	 * @return la r�f�rence 'client'.
	 */
	public Client getClient()
	{
		return client;
	}

	/**
	 * D�finit la r�f�rence 'client'.
	 * @param categorie la r�f�rence 'client'.
	 */
	public void setClient(Client client)
	{
		this.client = client;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + id + " " + numero;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
