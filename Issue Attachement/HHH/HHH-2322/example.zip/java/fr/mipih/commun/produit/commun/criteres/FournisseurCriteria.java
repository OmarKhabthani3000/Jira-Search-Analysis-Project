// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.commun.criteres;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import java.io.Serializable;


/**
 * Crit�res de recherche.
 */
public class FournisseurCriteria extends AbstractCriteria implements Serializable
{
	private String nom;
	private Boolean certifie;

	/** 
	 * Cet attribut bool�en permet de rechercher des fournisseurs qui 
	 * autorisent ou non des r�ductions.
	 */
	private Boolean reductionPossible;

	/**
	 * Retourne l'attribut nom.
	 * @return l'attribut nom.
	 */
	public String getNom()
	{
		return nom;
	}
	
	/**
	 * D�finit l'attribut nom.
	 * @param code L'attribut nom.
	 */
	public void setNom(String nom)
	{
		this.nom = nom;
	}

	/**
	 * Retourne l'attribut certifie.
	 * @return l'attribut certifie.
	 */
	public Boolean getCertifie()
	{
		return certifie;
	}
	
	/**
	 * D�finit l'attribut certifie.
	 * @param code L'attribut certifie.
	 */
	public void setCertifie(Boolean certifie)
	{
		this.certifie = certifie;
	}

	/**
	 * Retourne l'attribut reductionPossible.
	 * @return l'attribut reductionPossible.
	 */
	public Boolean getReductionPossible()
	{
		return reductionPossible;
	}
	
	/**
	 * D�finit l'attribut reductionPossible.
	 * @param code L'attribut reductionPossible.
	 */
	public void setReductionPossible(Boolean reductionPossible)
	{
		this.reductionPossible = reductionPossible;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + "" + nom + " " + certifie + " " + reductionPossible;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}
}
