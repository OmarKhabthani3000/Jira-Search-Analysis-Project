// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.services.serviceville;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.client.domaine.Ville;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.CrudService;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.List;


/**
 * Element ServiceVille.
 */
public interface IServiceVille extends CrudService
{


	//===============================================================
	// M�thodes CRUD de l'objet Ville
	//===============================================================

	/**
	 * Retourne la liste de toutes les objets Ville.
	 * @return la liste de tous les objets Ville.
	 */
	public List<Ville> findAllVille();

	/**
	 * Retourne la liste des objets Ville.
	 * @param criteria Les crit�res de recherche.
	 * @return les Ville correspondant aux crit�res.
	 */
	public List<Ville> findVille(AbstractCriteria criteres);

	/**
	 * Charge un objet Ville � partir de son id.
	 * @param id l'id de l'objet � charger.
	 * @return l'objet Ville correspondant � l'id donn�.
	 */
	public Ville loadVilleById(Serializable id);

	/**
	 * Enregistre un objet Ville.
	 * @param obj l'objet Ville � enregistrer.
	 * @return l'objet Ville enregistr�.
	 */
	public Ville storeVille(Identifiable obj);

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}