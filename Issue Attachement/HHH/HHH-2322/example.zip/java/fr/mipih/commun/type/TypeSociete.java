// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.type;

import fr.mipih.commun.type.i18n.EnumTranslator;

import fr.mipih.foundation.core.i18n.I18nPersistentStringEnum;
import fr.mipih.foundation.core.i18n.Translator;

import fr.mipih.foundation.persistence.PersistentEnum;

import java.util.List;


/**
 * Enum�ration TypeSociete.
 */
public final class TypeSociete extends I18nPersistentStringEnum
{
	/** Valeur EURL */
	public static final TypeSociete EURL = new TypeSociete("E");

	/** Valeur SARL */
	public static final TypeSociete SARL = new TypeSociete("S");

	/** Valeur SA */
	public static final TypeSociete SA = new TypeSociete("A");


	/**
	 * Constructeur par d�faut.
	 */
	public TypeSociete()
	{
		super();
	}

	/**
	 * Constructeur de l'�num�ration avec initialisation du code.
	 *
	 * @param code
	 *		Le code de l'�num�ration
	 */
	private TypeSociete(String code) {
		super(code);
	}

	/**
	 * Retourne la liste des �num�rations.
	 *
	 * @return
	 *		La liste des �num�rations
	 */
	public static List getEnumList()
	{
		return PersistentEnum.getEnumList(TypeSociete.class);
	}

	public String getLabel()
	{
		return getTranslator().getString(getRessourcePrefix() + "." + getEnumKey()); 
	}
	

	/**
	 * Retourne l'�num�ration correspondant au code donn�.
	 *
	 * @param code
			Le code de l'�num�ration � r�cup�rer
	 * @return
	 *		L'�num�ration correspondant au code donn�
	 */
	public static TypeSociete getEnum(String code)
	{
		return (TypeSociete) PersistentEnum.getEnum(TypeSociete.class, code);
	}

	/**
	 * R�cup�re l'instance du translator utilis� par l'�num�ration.
	 *
	 * <p>
	 * Le translator sera utilis� pour rechercher dans le paquetage du translator le fichier
	 * enum.properties contenant les libell�s de chacune des �num�ration
	 * </p>
	 *
	 * @return
	 *		Le translator associ� � cette �num�ration
	 */
	protected Translator getTranslator()
	{
		return EnumTranslator.getInstance();
	}
}