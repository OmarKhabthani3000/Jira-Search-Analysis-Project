// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.entreprise.commun.criteres;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.type.Montant;

import java.io.Serializable;

import java.util.Date;


/**
 * Crit�res de recherche.
 */
public class FactureDefautCriteria extends AbstractCriteria implements Serializable
{
	private Montant montant;
	private Date dateDebutEmission;
	private Date dateFinEmission;

	/**
	 * Retourne l'attribut montant.
	 * @return l'attribut montant.
	 */
	public Montant getMontant()
	{
		return montant;
	}
	
	/**
	 * D�finit l'attribut montant.
	 * @param code L'attribut montant.
	 */
	public void setMontant(Montant montant)
	{
		this.montant = montant;
	}

	/**
	 * Retourne l'attribut dateDebutEmission.
	 * @return l'attribut dateDebutEmission.
	 */
	public Date getDateDebutEmission()
	{
		return dateDebutEmission;
	}
	
	/**
	 * D�finit l'attribut dateDebutEmission.
	 * @param code L'attribut dateDebutEmission.
	 */
	public void setDateDebutEmission(Date dateDebutEmission)
	{
		this.dateDebutEmission = dateDebutEmission;
	}

	/**
	 * Retourne l'attribut dateFinEmission.
	 * @return l'attribut dateFinEmission.
	 */
	public Date getDateFinEmission()
	{
		return dateFinEmission;
	}
	
	/**
	 * D�finit l'attribut dateFinEmission.
	 * @param code L'attribut dateFinEmission.
	 */
	public void setDateFinEmission(Date dateFinEmission)
	{
		this.dateFinEmission = dateFinEmission;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + "" + montant + " " + dateDebutEmission + " " + dateFinEmission;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}
}
