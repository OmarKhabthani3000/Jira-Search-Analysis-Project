// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.services.servicecategorieproduit.implementation;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.produit.dao.ICategorieProduitDao;

import fr.mipih.commun.produit.domaine.CategorieProduit;
import fr.mipih.commun.produit.domaine.Produit;

import fr.mipih.commun.produit.services.servicecategorieproduit.IServiceCategorieProduit;

import fr.mipih.foundation.ValidationException;

import fr.mipih.foundation.core.BeanRegistry;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.AbstractCrudService;

import fr.mipih.foundation.model.Identifiable;

import fr.mipih.foundation.utils.ThreadContext;

import java.io.Serializable;

import java.util.List;

import org.springframework.util.Assert;


/**
 * Element ServiceCategorieProduit.
 */
public class ServiceCategorieProduit extends AbstractCrudService implements IServiceCategorieProduit 
{
	// [DEBUT:ATTRIBUT]
	// [FIN:ATTRIBUT]

	/**
	 * Cette m�thode doit �tre syst�matiquement utilis�e pour appeler une autre m�thode. Au lieu
	 * d'appeler methodeB() directement depuis methodeA(), il faut appeler
	 * <code>getCurService().methodeB()</code>.
	 * 
	 * @return le proxy transactionnel de ce service, � utiliser syst�matiquement.
	 */
	@SuppressWarnings("unused")
	private IServiceCategorieProduit getCurService()
	{
		IServiceCategorieProduit service = (IServiceCategorieProduit)BeanRegistry.getService("serviceCategorieProduit");
		Assert.notNull(service,"Impossible de r�cup�rer le service courant, " +
					"v�rifiez votre configuration.");
			return service;
	}





	/**
	 * Valide un(e) <code>produit</code> pour la relation <code>produits</code>.
	 * @param produit
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>produit</code> n'est pas valide
	 */	
	public void validateProduits(Produit produit)
	{
		ServiceCategorieProduitValidator validator = (ServiceCategorieProduitValidator)getValidator();
		ThreadContext.clearErrors();
		if (validator != null)
		{
			validator.validateProduit(produit, ThreadContext.getErrors());
			if (!ThreadContext.getErrors().isEmpty())
			{
				throw new ValidationException("Validation exception : "
						+ ThreadContext.getErrors());
			}
		}	
		else
		{
			logger.warn("Pas de validator trouv� pour valider un(e) produit.");
		}
	}

	//===============================================================
	// M�thodes CRUD de l'objet CategorieProduit
	//===============================================================

	@SuppressWarnings("unchecked")
	public List<CategorieProduit> findAllCategorieProduit()
	{
		return getCategorieProduitDao().findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CategorieProduit> findCategorieProduit(AbstractCriteria criteres)
	{
		return (List<CategorieProduit>)getCategorieProduitDao().find(criteres);
	}

	public CategorieProduit loadCategorieProduitById(Serializable id)
	{
		return (CategorieProduit)getCategorieProduitDao().loadById(id);
	}

	public CategorieProduit storeCategorieProduit(Identifiable obj)
	{
		return (CategorieProduit)getCategorieProduitDao().store(obj);
	}

	/**
	 * Retourne le DAO CategorieProduit.
	 * @return le DAO CategorieProduit
	 */
	public ICategorieProduitDao getCategorieProduitDao()
	{
		return (ICategorieProduitDao)BeanRegistry.getDao("categorieProduitDao");
	}
	// [DEBUT:METHODES]
	// [FIN:METHODES]
}