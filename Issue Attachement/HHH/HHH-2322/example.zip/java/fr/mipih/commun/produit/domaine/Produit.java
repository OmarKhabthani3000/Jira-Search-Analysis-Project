// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.domaine;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * Objet Produit.
 */
public class Produit extends Identifiable implements Serializable
{
	/** Identifiant de l'objet. */
	private String id;

	private Integer code;
	private String libelle;
	private Date dateDeCreation = new Date();
	// Composition naire
	private List<ReferenceProduit> references = new ArrayList<ReferenceProduit>();
	private CategorieProduit categorie;


	/**
	 * Constructeur par d�faut.
	 */
	public Produit()
	{
	}

	/**
	 * Constructeur avec initialisation de la r�f�rence vers categorie.
	 * @param categorie la r�f�rence vers l'objet parent
	 */
	public Produit(CategorieProduit categorie)
	{
		this.categorie = categorie;
	}


	public Serializable getId()
	{
		return id;
	}
	
	public void setId(Serializable id)
	{
		this.id = (String)id;
	}

	/**
	 * Retourne l'attribut code.
	 * @return l'attribut code.
	 */
	public Integer getCode()
	{
		return code;
	}
	
	/**
	 * D�finit l'attribut code.
	 * @param code L'attribut code.
	 */
	public void setCode(Integer code)
	{
		this.code = code;
	}

	/**
	 * Retourne l'attribut libelle.
	 * @return l'attribut libelle.
	 */
	public String getLibelle()
	{
		return libelle;
	}
	
	/**
	 * D�finit l'attribut libelle.
	 * @param code L'attribut libelle.
	 */
	public void setLibelle(String libelle)
	{
		this.libelle = libelle;
	}

	/**
	 * Retourne l'attribut dateDeCreation.
	 * @return l'attribut dateDeCreation.
	 */
	public Date getDateDeCreation()
	{
		return dateDeCreation;
	}
	
	/**
	 * D�finit l'attribut dateDeCreation.
	 * @param code L'attribut dateDeCreation.
	 */
	public void setDateDeCreation(Date dateDeCreation)
	{
		this.dateDeCreation = dateDeCreation;
	}

	/**
	 * Retourne la liste des objets ReferenceProduit.
	 * <p>
	 * <strong>Attention : </strong> si vous voulez ajouter ou supprimer des
	 * �l�ments, utilisez les m�thodes <code>{@link #addToReferences(ReferenceProduit)}</code>
	 * et <code>{@link #removeFromReferences(ReferenceProduit)}</code>.
	 * </p>
	 * @return la liste des objets ReferenceProduit.
	 */
	public List<ReferenceProduit> getReferences()
	{
		return references;
	}

	/**
	 * D�finit la liste des objets ReferenceProduit.
	 * @param references la liste des objets ReferenceProduit.
	 */
	protected void setReferences(List<ReferenceProduit> references)
	{
		this.references = references;
	}

	/**
	 * Ajoute l'objet ReferenceProduit fourni � la liste des referenceProduits contenu(e)s dans le Produit.
	 * <p>
	 * Cette m�thode s'occupe de maintenir la coh�rence des donn�es. Elle :
	 * </p>
	 * <ul>
	 * <li>v�rifie que l'objet ReferenceProduit fourni ne poss�de pas d�j� de parent. S'il en
	 * poss�de un, on supprime l'�l�ment de la liste de ce parent. On garantit ainsi que l'objet
	 * ReferenceProduit n'appartient pas � plusieurs listes de parents au m�me moment.</li>
	 * <li>Cette v�rification effectu�e, on appelle la m�thode setProduit(ReferenceProduit) sur l'objet ReferenceProduit afin de positionner
	 * son nouveau parent.</li>
	 * <li>Pour finir, on effectue le lien inverse en ajoutant l'objet ReferenceProduit � la
	 * liste des referenceProduits.</li>
	 * </ul>
	 */
	public void addToReferences(ReferenceProduit referenceProduit)
	{
		if (referenceProduit.getProduit() != null) {
			referenceProduit.getProduit().removeFromReferences(referenceProduit);
		}
		referenceProduit.setProduit(this);
		this.references.add(referenceProduit);
	}

	/**
	 * Supprime l'objet ReferenceProduit de la liste des referenceProduit et met � null le parent de cet objet.
	 * @param referenceProduit l'objet ReferenceProduit � supprimer de la liste.
	 */
	public void removeFromReferences(ReferenceProduit referenceProduit)
	{
		this.references.remove(referenceProduit);
		referenceProduit.setProduit(null);
	}

	/**
	 * Vide la liste de la liste des referenceProduit.
	 */
	public void removeAllReferences()
	{
		for (int i= references.size() - 1; i >= 0; i--)
		{
			ReferenceProduit referenceProduit = (ReferenceProduit)references.get(i);
			removeFromReferences(referenceProduit);
		}
	}

	/**
	 * Retourne la r�f�rence 'categorie'.
	 * @return la r�f�rence 'categorie'.
	 */
	public CategorieProduit getCategorie()
	{
		return categorie;
	}

	/**
	 * D�finit la r�f�rence 'categorie'.
	 * @param categorie la r�f�rence 'categorie'.
	 */
	public void setCategorie(CategorieProduit categorie)
	{
		this.categorie = categorie;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + code + " " + libelle + " " + dateDeCreation;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
