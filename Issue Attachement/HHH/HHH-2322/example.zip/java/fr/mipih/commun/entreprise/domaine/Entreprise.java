// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.entreprise.domaine;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.type.TypeSociete;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;


/**
 * Objet Entreprise.
 */
public class Entreprise extends Identifiable implements Serializable
{


	protected Integer id;
	private String raisonSociale;
	private TypeSociete formeJuridique = TypeSociete.EURL;




	/**
	 * Constructeur par d�faut.
	 */
	public Entreprise()
	{
	}



	public Serializable getId()
	{
		return id;
	}
	
	public void setId(Serializable id)
	{
		/*
		 * FIXME: on g�re les Integer et les String � cause de Struts uniquement
		 * � terme il faudra g�rer ici uniquement les objets Integer!
		 * getId() renvoyant un objet de type Serializable, Struts ne sait pas
		 * convertir l'objet saisi (de type String) en objet de type Integer car
		 * il ne peut pas deviner le type de l'ID !
		 */
		if (id == null || "".equals(id))
		{
			this.id = null;
		}
		else
		{
			// si c'est une chaine, on la transforme en Integer
			this.id = id instanceof String ? new Integer((String)id) : (Integer)id;
		}
		
	}
	

	/**
	 * Retourne l'attribut raisonSociale.
	 * @return l'attribut raisonSociale.
	 */
	public String getRaisonSociale()
	{
		return raisonSociale;
	}
	
	/**
	 * D�finit l'attribut raisonSociale.
	 * @param code L'attribut raisonSociale.
	 */
	public void setRaisonSociale(String raisonSociale)
	{
		this.raisonSociale = raisonSociale;
	}

	/**
	 * Retourne l'attribut formeJuridique.
	 * @return l'attribut formeJuridique.
	 */
	public TypeSociete getFormeJuridique()
	{
		return formeJuridique;
	}
	
	/**
	 * D�finit l'attribut formeJuridique.
	 * @param code L'attribut formeJuridique.
	 */
	public void setFormeJuridique(TypeSociete formeJuridique)
	{
		this.formeJuridique = formeJuridique;
	}





	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + id + " " + raisonSociale + " " + formeJuridique;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
