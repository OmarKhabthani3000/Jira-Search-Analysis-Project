// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.entreprise.services.servicefacture.implementation;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.entreprise.dao.IFactureDao;

import fr.mipih.commun.entreprise.domaine.Facture;
import fr.mipih.commun.entreprise.domaine.LigneDeFacture;

import fr.mipih.commun.entreprise.services.servicefacture.IServiceFacture;

import fr.mipih.commun.produit.services.serviceproduit.IServiceProduit;

import fr.mipih.foundation.ValidationException;

import fr.mipih.foundation.core.BeanRegistry;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.AbstractCrudService;

import fr.mipih.foundation.model.Identifiable;

import fr.mipih.foundation.utils.ThreadContext;

import java.io.Serializable;

import java.util.List;

import org.springframework.util.Assert;


/**
 * Element ServiceFacture.
 */
public class ServiceFacture extends AbstractCrudService implements IServiceFacture 
{
	// [DEBUT:ATTRIBUT]
	// [FIN:ATTRIBUT]

	/**
	 * Cette m�thode doit �tre syst�matiquement utilis�e pour appeler une autre m�thode. Au lieu
	 * d'appeler methodeB() directement depuis methodeA(), il faut appeler
	 * <code>getCurService().methodeB()</code>.
	 * 
	 * @return le proxy transactionnel de ce service, � utiliser syst�matiquement.
	 */
	@SuppressWarnings("unused")
	private IServiceFacture getCurService()
	{
		IServiceFacture service = (IServiceFacture)BeanRegistry.getService("serviceFacture");
		Assert.notNull(service,"Impossible de r�cup�rer le service courant, " +
					"v�rifiez votre configuration.");
			return service;
	}

	/**
	 * Retourne le service ServiceProduit.
	 * @return
	 *		Le service ServiceProduit
	 */
	public IServiceProduit getServiceProduit()
	{
		return (IServiceProduit)BeanRegistry.getService("serviceProduit");
	}




	/**
	 * Valide un(e) <code>ligneDeFacture</code> pour la relation <code>lignes de facture</code>.
	 * @param ligneDeFacture
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>ligneDeFacture</code> n'est pas valide
	 */	
	public void validateLignesDeFacture(LigneDeFacture ligneDeFacture)
	{
		ServiceFactureValidator validator = (ServiceFactureValidator)getValidator();
		ThreadContext.clearErrors();
		if (validator != null)
		{
			validator.validateLigneDeFacture(ligneDeFacture, ThreadContext.getErrors());
			if (!ThreadContext.getErrors().isEmpty())
			{
				throw new ValidationException("Validation exception : "
						+ ThreadContext.getErrors());
			}
		}	
		else
		{
			logger.warn("Pas de validator trouv� pour valider un(e) ligneDeFacture.");
		}
	}

	//===============================================================
	// M�thodes CRUD de l'objet Facture
	//===============================================================

	@SuppressWarnings("unchecked")
	public List<Facture> findAllFacture()
	{
		return getFactureDao().findAll();
	}

	@SuppressWarnings("unchecked")
	public List<Facture> findFacture(AbstractCriteria criteres)
	{
		return (List<Facture>)getFactureDao().find(criteres);
	}

	public Facture loadFactureById(Serializable id)
	{
		return (Facture)getFactureDao().loadById(id);
	}

	public Facture storeFacture(Identifiable obj)
	{
		return (Facture)getFactureDao().store(obj);
	}

	/**
	 * Retourne le DAO Facture.
	 * @return le DAO Facture
	 */
	public IFactureDao getFactureDao()
	{
		return (IFactureDao)BeanRegistry.getDao("factureDao");
	}
	// [DEBUT:METHODES]
	// [FIN:METHODES]
}