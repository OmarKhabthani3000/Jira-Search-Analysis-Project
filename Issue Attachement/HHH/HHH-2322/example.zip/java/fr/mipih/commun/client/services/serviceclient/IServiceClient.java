// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.services.serviceclient;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.client.commun.criteres.ClientParCodeCriteria;

import fr.mipih.commun.client.domaine.Client;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.CrudService;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.List;


/**
 * Element ServiceClient.
 */
public interface IServiceClient extends CrudService
{
	/**
	 * Cette m�thode permet de rechercher un client par son code.
	 * @param criteres
	 *		La classe portant les crit�res de recherche
	 * @return
	 *		La liste des �l�ments correspondants aux crit�res fournis
	 */
	public List rechercherParCode(ClientParCodeCriteria criteres);


	//===============================================================
	// M�thodes CRUD de l'objet Client
	//===============================================================

	/**
	 * Retourne la liste de toutes les objets Client.
	 * @return la liste de tous les objets Client.
	 */
	public List<Client> findAllClient();

	/**
	 * Retourne la liste des objets Client.
	 * @param criteria Les crit�res de recherche.
	 * @return les Client correspondant aux crit�res.
	 */
	public List<Client> findClient(AbstractCriteria criteres);

	/**
	 * Charge un objet Client � partir de son id.
	 * @param id l'id de l'objet � charger.
	 * @return l'objet Client correspondant � l'id donn�.
	 */
	public Client loadClientById(Serializable id);

	/**
	 * Enregistre un objet Client.
	 * @param obj l'objet Client � enregistrer.
	 * @return l'objet Client enregistr�.
	 */
	public Client storeClient(Identifiable obj);

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}