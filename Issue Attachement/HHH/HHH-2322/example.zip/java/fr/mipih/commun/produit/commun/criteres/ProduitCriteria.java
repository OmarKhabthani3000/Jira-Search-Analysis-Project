// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.commun.criteres;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import java.io.Serializable;

import java.util.Date;


/**
 * Crit�res de recherche.
 */
public class ProduitCriteria extends AbstractCriteria implements Serializable
{
	private Integer code;
	private String libelle;
	private Date dateCreation;

	/**
	 * Retourne l'attribut code.
	 * @return l'attribut code.
	 */
	public Integer getCode()
	{
		return code;
	}
	
	/**
	 * D�finit l'attribut code.
	 * @param code L'attribut code.
	 */
	public void setCode(Integer code)
	{
		this.code = code;
	}

	/**
	 * Retourne l'attribut libelle.
	 * @return l'attribut libelle.
	 */
	public String getLibelle()
	{
		return libelle;
	}
	
	/**
	 * D�finit l'attribut libelle.
	 * @param code L'attribut libelle.
	 */
	public void setLibelle(String libelle)
	{
		this.libelle = libelle;
	}

	/**
	 * Retourne l'attribut dateCreation.
	 * @return l'attribut dateCreation.
	 */
	public Date getDateCreation()
	{
		return dateCreation;
	}
	
	/**
	 * D�finit l'attribut dateCreation.
	 * @param code L'attribut dateCreation.
	 */
	public void setDateCreation(Date dateCreation)
	{
		this.dateCreation = dateCreation;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + "" + code + " " + libelle + " " + dateCreation;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}
}
