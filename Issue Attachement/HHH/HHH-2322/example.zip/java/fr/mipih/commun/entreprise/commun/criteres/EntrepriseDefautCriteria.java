// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.entreprise.commun.criteres;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import java.io.Serializable;


/**
 * Crit�res de recherche.
 */
public class EntrepriseDefautCriteria extends AbstractCriteria implements Serializable
{
	private String raisonSociale;

	/**
	 * Retourne l'attribut raisonSociale.
	 * @return l'attribut raisonSociale.
	 */
	public String getRaisonSociale()
	{
		return raisonSociale;
	}
	
	/**
	 * D�finit l'attribut raisonSociale.
	 * @param code L'attribut raisonSociale.
	 */
	public void setRaisonSociale(String raisonSociale)
	{
		this.raisonSociale = raisonSociale;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + "" + raisonSociale;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}
}
