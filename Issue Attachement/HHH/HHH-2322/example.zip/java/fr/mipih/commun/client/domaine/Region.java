// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.domaine;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.type.TypeRegion;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;


/**
 * Objet Region.
 */
public class Region extends Identifiable implements Serializable
{
	/** Identifiant de l'objet. */
	private String id;

	private String nom;
	private TypeRegion type;
	// Composition naire
	private List<Ville> villes = new ArrayList<Ville>();



	/**
	 * Constructeur par d�faut.
	 */
	public Region()
	{
	}



	public Serializable getId()
	{
		return id;
	}
	
	public void setId(Serializable id)
	{
		this.id = (String)id;
	}

	/**
	 * Retourne l'attribut nom.
	 * @return l'attribut nom.
	 */
	public String getNom()
	{
		return nom;
	}
	
	/**
	 * D�finit l'attribut nom.
	 * @param code L'attribut nom.
	 */
	public void setNom(String nom)
	{
		this.nom = nom;
	}

	/**
	 * Retourne l'attribut type.
	 * @return l'attribut type.
	 */
	public TypeRegion getType()
	{
		return type;
	}
	
	/**
	 * D�finit l'attribut type.
	 * @param code L'attribut type.
	 */
	public void setType(TypeRegion type)
	{
		this.type = type;
	}

	/**
	 * Retourne la liste des objets Ville.
	 * <p>
	 * <strong>Attention : </strong> si vous voulez ajouter ou supprimer des
	 * �l�ments, utilisez les m�thodes <code>{@link #addToVilles(Ville)}</code>
	 * et <code>{@link #removeFromVilles(Ville)}</code>.
	 * </p>
	 * @return la liste des objets Ville.
	 */
	public List<Ville> getVilles()
	{
		return villes;
	}

	/**
	 * D�finit la liste des objets Ville.
	 * @param references la liste des objets Ville.
	 */
	protected void setVilles(List<Ville> villes)
	{
		this.villes = villes;
	}

	/**
	 * Ajoute l'objet Ville fourni � la liste des villes contenu(e)s dans le Region.
	 * <p>
	 * Cette m�thode s'occupe de maintenir la coh�rence des donn�es. Elle :
	 * </p>
	 * <ul>
	 * <li>v�rifie que l'objet Ville fourni ne poss�de pas d�j� de parent. S'il en
	 * poss�de un, on supprime l'�l�ment de la liste de ce parent. On garantit ainsi que l'objet
	 * Ville n'appartient pas � plusieurs listes de parents au m�me moment.</li>
	 * <li>Cette v�rification effectu�e, on appelle la m�thode setRegion(Ville) sur l'objet Ville afin de positionner
	 * son nouveau parent.</li>
	 * <li>Pour finir, on effectue le lien inverse en ajoutant l'objet Ville � la
	 * liste des villes.</li>
	 * </ul>
	 */
	public void addToVilles(Ville ville)
	{
		if (ville.getRegion() != null) {
			ville.getRegion().removeFromVilles(ville);
		}
		ville.setRegion(this);
		this.villes.add(ville);
	}

	/**
	 * Supprime l'objet Ville de la liste des ville et met � null le parent de cet objet.
	 * @param ville l'objet Ville � supprimer de la liste.
	 */
	public void removeFromVilles(Ville ville)
	{
		this.villes.remove(ville);
		ville.setRegion(null);
	}

	/**
	 * Vide la liste de la liste des ville.
	 */
	public void removeAllVilles()
	{
		for (int i= villes.size() - 1; i >= 0; i--)
		{
			Ville ville = (Ville)villes.get(i);
			removeFromVilles(ville);
		}
	}




	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + nom + " " + type;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
