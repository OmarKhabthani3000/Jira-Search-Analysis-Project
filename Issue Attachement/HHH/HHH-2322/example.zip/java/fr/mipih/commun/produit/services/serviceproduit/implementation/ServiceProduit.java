// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.services.serviceproduit.implementation;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.produit.dao.ICategorieProduitDao;
import fr.mipih.commun.produit.dao.IProduitDao;

import fr.mipih.commun.produit.domaine.CategorieProduit;
import fr.mipih.commun.produit.domaine.Produit;
import fr.mipih.commun.produit.domaine.ReferenceProduit;

import fr.mipih.commun.produit.services.servicefournisseur.IServiceFournisseur;

import fr.mipih.commun.produit.services.serviceproduit.IServiceProduit;

import fr.mipih.foundation.ValidationException;

import fr.mipih.foundation.core.BeanRegistry;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.AbstractCrudService;

import fr.mipih.foundation.model.Identifiable;

import fr.mipih.foundation.utils.ThreadContext;

import java.io.Serializable;

import java.util.List;

import org.springframework.util.Assert;


/**
 * Element ServiceProduit.
 */
public class ServiceProduit extends AbstractCrudService implements IServiceProduit 
{
	// [DEBUT:ATTRIBUT]
	// [FIN:ATTRIBUT]

	/**
	 * Cette m�thode doit �tre syst�matiquement utilis�e pour appeler une autre m�thode. Au lieu
	 * d'appeler methodeB() directement depuis methodeA(), il faut appeler
	 * <code>getCurService().methodeB()</code>.
	 * 
	 * @return le proxy transactionnel de ce service, � utiliser syst�matiquement.
	 */
	@SuppressWarnings("unused")
	private IServiceProduit getCurService()
	{
		IServiceProduit service = (IServiceProduit)BeanRegistry.getService("serviceProduit");
		Assert.notNull(service,"Impossible de r�cup�rer le service courant, " +
					"v�rifiez votre configuration.");
			return service;
	}

	/**
	 * Retourne le service ServiceFournisseur.
	 * @return
	 *		Le service ServiceFournisseur
	 */
	public IServiceFournisseur getServiceFournisseur()
	{
		return (IServiceFournisseur)BeanRegistry.getService("serviceFournisseur");
	}




	/**
	 * Valide un(e) <code>referenceProduit</code> pour la relation <code>references</code>.
	 * @param referenceProduit
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>referenceProduit</code> n'est pas valide
	 */	
	public void validateReferences(ReferenceProduit referenceProduit)
	{
		ServiceProduitValidator validator = (ServiceProduitValidator)getValidator();
		ThreadContext.clearErrors();
		if (validator != null)
		{
			validator.validateReferenceProduit(referenceProduit, ThreadContext.getErrors());
			if (!ThreadContext.getErrors().isEmpty())
			{
				throw new ValidationException("Validation exception : "
						+ ThreadContext.getErrors());
			}
		}	
		else
		{
			logger.warn("Pas de validator trouv� pour valider un(e) referenceProduit.");
		}
	}

	/**
	 * Valide un(e) <code>produit</code> pour la relation <code>produits</code>.
	 * @param produit
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>produit</code> n'est pas valide
	 */	
	public void validateProduits(Produit produit)
	{
		ServiceProduitValidator validator = (ServiceProduitValidator)getValidator();
		ThreadContext.clearErrors();
		if (validator != null)
		{
			validator.validate(produit, ThreadContext.getErrors());
			if (!ThreadContext.getErrors().isEmpty())
			{
				throw new ValidationException("Validation exception : "
						+ ThreadContext.getErrors());
			}
		}	
		else
		{
			logger.warn("Pas de validator trouv� pour valider un(e) produit.");
		}
	}

	//===============================================================
	// M�thodes CRUD de l'objet Produit
	//===============================================================

	@SuppressWarnings("unchecked")
	public List<Produit> findAllProduit()
	{
		return getProduitDao().findAll();
	}

	@SuppressWarnings("unchecked")
	public List<Produit> findProduit(AbstractCriteria criteres)
	{
		return (List<Produit>)getProduitDao().find(criteres);
	}

	public Produit loadProduitById(Serializable id)
	{
		return (Produit)getProduitDao().loadById(id);
	}

	public Produit storeProduit(Identifiable obj)
	{
		return (Produit)getProduitDao().store(obj);
	}

	/**
	 * Retourne le DAO Produit.
	 * @return le DAO Produit
	 */
	public IProduitDao getProduitDao()
	{
		return (IProduitDao)BeanRegistry.getDao("produitDao");
	}
	//===============================================================
	// M�thodes CRUD de l'objet CategorieProduit
	//===============================================================

	@SuppressWarnings("unchecked")
	public List<CategorieProduit> findAllCategorieProduit()
	{
		return getCategorieProduitDao().findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CategorieProduit> findCategorieProduit(AbstractCriteria criteres)
	{
		return (List<CategorieProduit>)getCategorieProduitDao().find(criteres);
	}

	public CategorieProduit loadCategorieProduitById(Serializable id)
	{
		return (CategorieProduit)getCategorieProduitDao().loadById(id);
	}

	public CategorieProduit storeCategorieProduit(Identifiable obj)
	{
		return (CategorieProduit)getCategorieProduitDao().store(obj);
	}

	/**
	 * Retourne le DAO CategorieProduit.
	 * @return le DAO CategorieProduit
	 */
	public ICategorieProduitDao getCategorieProduitDao()
	{
		return (ICategorieProduitDao)BeanRegistry.getDao("categorieProduitDao");
	}
	// [DEBUT:METHODES]
	// [FIN:METHODES]
}