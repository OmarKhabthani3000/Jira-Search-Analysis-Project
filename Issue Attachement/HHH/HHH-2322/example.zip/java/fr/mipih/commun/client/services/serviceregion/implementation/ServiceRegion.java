// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.services.serviceregion.implementation;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.client.dao.IRegionDao;

import fr.mipih.commun.client.domaine.Region;
import fr.mipih.commun.client.domaine.Ville;

import fr.mipih.commun.client.services.serviceregion.IServiceRegion;

import fr.mipih.foundation.ValidationException;

import fr.mipih.foundation.core.BeanRegistry;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.AbstractCrudService;

import fr.mipih.foundation.model.Identifiable;

import fr.mipih.foundation.utils.ThreadContext;

import java.io.Serializable;

import java.util.List;

import org.springframework.util.Assert;


/**
 * Element ServiceRegion.
 */
public class ServiceRegion extends AbstractCrudService implements IServiceRegion 
{
	// [DEBUT:ATTRIBUT]
	// [FIN:ATTRIBUT]

	/**
	 * Cette m�thode doit �tre syst�matiquement utilis�e pour appeler une autre m�thode. Au lieu
	 * d'appeler methodeB() directement depuis methodeA(), il faut appeler
	 * <code>getCurService().methodeB()</code>.
	 * 
	 * @return le proxy transactionnel de ce service, � utiliser syst�matiquement.
	 */
	@SuppressWarnings("unused")
	private IServiceRegion getCurService()
	{
		IServiceRegion service = (IServiceRegion)BeanRegistry.getService("serviceRegion");
		Assert.notNull(service,"Impossible de r�cup�rer le service courant, " +
					"v�rifiez votre configuration.");
			return service;
	}





	/**
	 * Valide un(e) <code>ville</code> pour la relation <code>villes</code>.
	 * @param ville
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>ville</code> n'est pas valide
	 */	
	public void validateVilles(Ville ville)
	{
		ServiceRegionValidator validator = (ServiceRegionValidator)getValidator();
		ThreadContext.clearErrors();
		if (validator != null)
		{
			validator.validateVille(ville, ThreadContext.getErrors());
			if (!ThreadContext.getErrors().isEmpty())
			{
				throw new ValidationException("Validation exception : "
						+ ThreadContext.getErrors());
			}
		}	
		else
		{
			logger.warn("Pas de validator trouv� pour valider un(e) ville.");
		}
	}

	//===============================================================
	// M�thodes CRUD de l'objet Region
	//===============================================================

	@SuppressWarnings("unchecked")
	public List<Region> findAllRegion()
	{
		return getRegionDao().findAll();
	}

	@SuppressWarnings("unchecked")
	public List<Region> findRegion(AbstractCriteria criteres)
	{
		return (List<Region>)getRegionDao().find(criteres);
	}

	public Region loadRegionById(Serializable id)
	{
		return (Region)getRegionDao().loadById(id);
	}

	public Region storeRegion(Identifiable obj)
	{
		return (Region)getRegionDao().store(obj);
	}

	/**
	 * Retourne le DAO Region.
	 * @return le DAO Region
	 */
	public IRegionDao getRegionDao()
	{
		return (IRegionDao)BeanRegistry.getDao("regionDao");
	}
	// [DEBUT:METHODES]
	// [FIN:METHODES]
}