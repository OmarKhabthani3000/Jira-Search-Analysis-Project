// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.commun.criteres;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import java.io.Serializable;


/**
 * Crit�res de recherche.
 */
public class CategorieProduitCriteria extends AbstractCriteria implements Serializable
{
	private String code;
	private String libelle;

	/**
	 * Retourne l'attribut code.
	 * @return l'attribut code.
	 */
	public String getCode()
	{
		return code;
	}
	
	/**
	 * D�finit l'attribut code.
	 * @param code L'attribut code.
	 */
	public void setCode(String code)
	{
		this.code = code;
	}

	/**
	 * Retourne l'attribut libelle.
	 * @return l'attribut libelle.
	 */
	public String getLibelle()
	{
		return libelle;
	}
	
	/**
	 * D�finit l'attribut libelle.
	 * @param code L'attribut libelle.
	 */
	public void setLibelle(String libelle)
	{
		this.libelle = libelle;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + "" + code + " " + libelle;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}
}
