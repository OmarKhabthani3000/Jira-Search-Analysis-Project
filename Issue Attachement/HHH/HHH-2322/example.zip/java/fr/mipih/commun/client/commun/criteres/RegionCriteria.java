// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.commun.criteres;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.type.TypeRegion;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import java.io.Serializable;


/**
 * Crit�res de recherche.
 */
public class RegionCriteria extends AbstractCriteria implements Serializable
{
	private String nom;
	// attribut utilis� pour la recherche sur les valeurs possibles de l'attribut type
	private TypeRegion[] type;
	/**
	 * Retourne l'attribut nom.
	 * @return l'attribut nom.
	 */
	public String getNom()
	{
		return nom;
	}
	
	/**
	 * D�finit l'attribut nom.
	 * @param code L'attribut nom.
	 */
	public void setNom(String nom)
	{
		this.nom = nom;
	}

	/**
	 * R�cup�re les valeurs possibles pour l'�num�ration type lors de la recherche.
	 * 
	 * @return
	 *		Un tableau contenant toutes les valeurs possibles pour l'�num�ration type
	 */
	public TypeRegion[] getType()
	{
		return type;
	}
	
	/**
	 * D�finit les valeurs possibles pour l'�num�ration type lors de la recherche.
	 * 
	 * @param type
	 *		Le tableau contenant toutes les valeurs possibles pour l'�num�ration type
	 */
	public void setType(TypeRegion[] type)
	{
		this.type = type;
	}

	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + "" + nom + " " + type;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}
}
