// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.commun.criteres;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import java.io.Serializable;

import java.util.Date;


/**
 * Crit�res de recherche.
 */
public class ClientDefautCriteria extends AbstractCriteria implements Serializable
{
	private String nom;
	private String prenom;
	private Date dateNaissance;

	/**
	 * Retourne l'attribut nom.
	 * @return l'attribut nom.
	 */
	public String getNom()
	{
		return nom;
	}
	
	/**
	 * D�finit l'attribut nom.
	 * @param code L'attribut nom.
	 */
	public void setNom(String nom)
	{
		this.nom = nom;
	}

	/**
	 * Retourne l'attribut prenom.
	 * @return l'attribut prenom.
	 */
	public String getPrenom()
	{
		return prenom;
	}
	
	/**
	 * D�finit l'attribut prenom.
	 * @param code L'attribut prenom.
	 */
	public void setPrenom(String prenom)
	{
		this.prenom = prenom;
	}

	/**
	 * Retourne l'attribut dateNaissance.
	 * @return l'attribut dateNaissance.
	 */
	public Date getDateNaissance()
	{
		return dateNaissance;
	}
	
	/**
	 * D�finit l'attribut dateNaissance.
	 * @param code L'attribut dateNaissance.
	 */
	public void setDateNaissance(Date dateNaissance)
	{
		this.dateNaissance = dateNaissance;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + "" + nom + " " + prenom + " " + dateNaissance;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}
}
