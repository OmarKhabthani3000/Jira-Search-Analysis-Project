// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.entreprise.services.servicefacture;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.entreprise.domaine.Facture;
import fr.mipih.commun.entreprise.domaine.LigneDeFacture;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.CrudService;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.List;


/**
 * Element ServiceFacture.
 */
public interface IServiceFacture extends CrudService
{

	/**
	 * Valide un(e) <code>ligneDeFacture</code> pour la relation <code>lignes de facture</code>.
	 * @param ligneDeFacture
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>ligneDeFacture</code> n'est pas valide
	 */	
	public void validateLignesDeFacture(LigneDeFacture ligneDeFacture);

	//===============================================================
	// M�thodes CRUD de l'objet Facture
	//===============================================================

	/**
	 * Retourne la liste de toutes les objets Facture.
	 * @return la liste de tous les objets Facture.
	 */
	public List<Facture> findAllFacture();

	/**
	 * Retourne la liste des objets Facture.
	 * @param criteria Les crit�res de recherche.
	 * @return les Facture correspondant aux crit�res.
	 */
	public List<Facture> findFacture(AbstractCriteria criteres);

	/**
	 * Charge un objet Facture � partir de son id.
	 * @param id l'id de l'objet � charger.
	 * @return l'objet Facture correspondant � l'id donn�.
	 */
	public Facture loadFactureById(Serializable id);

	/**
	 * Enregistre un objet Facture.
	 * @param obj l'objet Facture � enregistrer.
	 * @return l'objet Facture enregistr�.
	 */
	public Facture storeFacture(Identifiable obj);

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}