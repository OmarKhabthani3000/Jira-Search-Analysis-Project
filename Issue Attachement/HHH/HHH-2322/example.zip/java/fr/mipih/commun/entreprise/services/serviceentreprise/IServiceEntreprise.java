// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.entreprise.services.serviceentreprise;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.entreprise.domaine.Entreprise;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.CrudService;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.List;


/**
 * Element ServiceEntreprise.
 */
public interface IServiceEntreprise extends CrudService
{
	/**
	 * M�thode getListeEntreprise.
	 */
	public void getListeEntreprise();


	//===============================================================
	// M�thodes CRUD de l'objet Entreprise
	//===============================================================

	/**
	 * Retourne la liste de toutes les objets Entreprise.
	 * @return la liste de tous les objets Entreprise.
	 */
	public List<Entreprise> findAllEntreprise();

	/**
	 * Retourne la liste des objets Entreprise.
	 * @param criteria Les crit�res de recherche.
	 * @return les Entreprise correspondant aux crit�res.
	 */
	public List<Entreprise> findEntreprise(AbstractCriteria criteres);

	/**
	 * Charge un objet Entreprise � partir de son id.
	 * @param id l'id de l'objet � charger.
	 * @return l'objet Entreprise correspondant � l'id donn�.
	 */
	public Entreprise loadEntrepriseById(Serializable id);

	/**
	 * Enregistre un objet Entreprise.
	 * @param obj l'objet Entreprise � enregistrer.
	 * @return l'objet Entreprise enregistr�.
	 */
	public Entreprise storeEntreprise(Identifiable obj);

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}