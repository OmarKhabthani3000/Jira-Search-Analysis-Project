// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.dao.implementation;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.client.commun.criteres.VilleCriteria;

import fr.mipih.commun.client.dao.IVilleDao;

import fr.mipih.commun.client.domaine.Ville;

import fr.mipih.foundation.FatalServiceException;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.persistence.AbstractHibernateDAO;

import org.hibernate.Criteria;


/**
 * Classe de DAO VilleDao.
 */
public class VilleDao extends AbstractHibernateDAO implements IVilleDao
{
	/**
	 * Construit la liste des crit�res permettant de filtrer les r�sultats d'une recherche avec les
	 * crit�res contenus dans le <em>VilleCriteria</em>.
	 * 
	 * @param criteres
	 *            Le bean de recherche sur lequel on se base pour g�n�rer les crit�res de filtrage.
	 * @param hbCriteria
	 *            L'objet <em>Hibernate</em> contenant tous les crit�res de recherche (clause WHERE)
	 */
	@SuppressWarnings("unused")
	private void buildCriteriaDefault(VilleCriteria criteres, Criteria hbCriteria)
	{
		// [DEBUT:METHODE�-�m�thode�buidCriteriaDefault]
		// TODO Ajouter vos crit�res ici
		// [FIN:METHODE�-�m�thode�buidCriteriaDefault]
	}

	/**
	 * S'occupe de transmettre l'instance d'AbstractCriteria � la m�thode buildCriteria<em>XXX</em>
	 * correspondante.
	 * 
	 * @param criteres
	 *            Le bean de recherche sur lequel on se base pour g�n�rer les crit�res de filtrage
	 * @param hbCriteria
	 *            L'objet contenant tous les crit�res de recherche (clause WHERE)
	 */
	public void buildCriteria(AbstractCriteria criteres, Criteria hbCriteria)
	{
		if (criteres instanceof VilleCriteria)
		{
			buildVilleCriteria((VilleCriteria) criteres, hbCriteria);
		}

		else
		{
			throw new FatalServiceException(
				"Erreur lors de la cr�ation des crit�res de recherche : classe Criteria "
				+ criteres == null ? "null" : criteres.getClass().getName() + " non g�r�e");
		}
	}
	/**
	 * 
	 */
	public void buildVilleCriteria(VilleCriteria criteres, Criteria hbCriteria)
	{
		// [DEBUT:METHODE�-�buildVilleCriteria]
		// [FIN:METHODE�-�buildVilleCriteria]
	}

	/**
	 * Renvoie la classe du DOM g�r�e par ce DAO.
	 *
	 * @return
	 *		La classe du DOM g�r�e par ce DAO
	 */
	public Class getBeanClass()
	{
		return Ville.class;
	}
	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
