// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.services.serviceregion.implementation;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.client.domaine.Region;
import fr.mipih.commun.client.domaine.Ville;

import fr.mipih.commun.client.services.serviceregion.IServiceRegion;

import fr.mipih.foundation.core.BeanRegistry;

import fr.mipih.foundation.validation.AbstractValidator;
import fr.mipih.foundation.validation.BasicValidatorRule;
import fr.mipih.foundation.validation.IErrors;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


/**
 * Validateur de la classe Region.
 */
public class ServiceRegionValidator extends AbstractValidator
{
	/** Map contenant les r�gles de validation basiques */
	private Map rules = new HashMap();

	/**
	 * Constructeur par d�faut du validateur.
	 */
	public ServiceRegionValidator()
	{
		buildBasicRules();
		afterBuildBasicRules();
	}

	/**
	 * Rajoute � la map rules les r�gles de validation de base.
	 */
	protected void buildBasicRules()
	{
		rules.put("nom", new BasicValidatorRule("nom", null, new Integer(35), true));
	
	}

	/**
	 * M�thode appel�e apr�s l'initialisation des r�gles de base.
	 */
	protected void afterBuildBasicRules()
	{
		// [DEBUT:METHODE�-�methode�afterBuildBasicRules]

		// supprimez ou rajoutez des r�gles de base ici

		// [FIN:METHODE�-�methode�afterBuildBasicRules]
	}

	/**
	 * La classe pass�e en param�tre peut-elle �tre valid�e par ce validator?
	 *
	 * @param clazz
	 *		La classe � tester
	 * @return
	 *		true si la classe <code>clazz</code> peut �tre valid�e par ce validator
	 */
	public boolean supports(Class clazz)
	{
		return clazz.isAssignableFrom(Region.class);
	}

	/**
	 * Valide l'objet pass� en param�tre.
	 *
	 * <p>
	 * Si l'objet <code>obj</code> contient des erreurs, celles-ci seront 
	 * rajout�es dans l'objet <code>errors</code> pass� en param�tre.
	 * </p>
	 *
	 * @param obj
	 *		L'objet � valider
	 * @param errors
	 *		L'objet qui recueille la liste de toutes les erreurs de validation
	 */
	public void validate(Object obj, IErrors errors)
	{
		beforeBasicRulesValidation(obj, errors);

		// validation de base
		BasicValidatorRule.validate(obj, rules.values(), errors);

		afterBasicRulesValidation(obj, errors);
	}

	/**
	 * M�thode appel�e avant la validation de base sur les attributs.
	 *
	 * @param obj
	 *		L'objet � valider
	 * @param errors
	 *		L'objet qui recueille la liste de toutes les erreurs de validation
	 */
	public void beforeBasicRulesValidation(Object obj, IErrors errors)
	{
		// [DEBUT:METHODE�-�methode�beforeBasicRulesValidation]

		// TODO: modifiez les r�gles de base ici, vous pouvez aussi rajouter
		// vos r�gles de validation m�tier ici

		// Region region = (Region)obj;

		// [FIN:METHODE�-�methode�beforeBasicRulesValidation]
	}

	/**
	 * M�thode appel�e apr�s la validation de base sur les attributs.
	 *
	 * @param obj
	 *		L'objet � valider
	 * @param errors
	 *		L'objet qui recueille la liste de toutes les erreurs de validation
	 */
	public void afterBasicRulesValidation(Object obj, IErrors errors)
	{
		Region region = (Region)obj;
		validateAllVilles(region, errors);

		// [DEBUT:METHODE�-�methode�afterBasicRulesValidation]

		// TODO: les r�gles de base ont �t� v�rifi�es avant l'appel de cette m�thode,
		// vous pouvez valider vos r�gles m�tier ici

		// Region region = (Region)obj;

		// [FIN:METHODE�-�methode�afterBasicRulesValidation]
	}


	/**
	 * Retourne le service parent ServiceRegion rattach� � l'assembleur RegionAssembler.
	 *
	 * @return Le service parent ServiceRegion
	 */
	public IServiceRegion getServiceRegion()
	{
		return (IServiceRegion)BeanRegistry.getService("serviceRegion");
	}
	/**
	 * Valide un(e) <code>ville.
	 * @param Ville
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>Ville</code> n'est pas valide
	 */	
	public void validateVille(Ville ville, IErrors errors)
	{

	}
	@SuppressWarnings("unused")
	private void validateAllVilles(Region region, IErrors errors)
	{
		Iterator itr = region.getVilles().iterator();
		while (itr.hasNext())
		{
			Ville currentville = (Ville)itr.next();
			validateVille(currentville, errors);
		}
	}



	// [DEBUT:METHODES]
	// [FIN:METHODES]
}