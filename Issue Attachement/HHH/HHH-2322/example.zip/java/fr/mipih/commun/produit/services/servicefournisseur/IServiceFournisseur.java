// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.services.servicefournisseur;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.produit.domaine.Fournisseur;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.CrudService;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.List;


/**
 * Element ServiceFournisseur.
 */
public interface IServiceFournisseur extends CrudService
{


	//===============================================================
	// M�thodes CRUD de l'objet Fournisseur
	//===============================================================

	/**
	 * Retourne la liste de toutes les objets Fournisseur.
	 * @return la liste de tous les objets Fournisseur.
	 */
	public List<Fournisseur> findAllFournisseur();

	/**
	 * Retourne la liste des objets Fournisseur.
	 * @param criteria Les crit�res de recherche.
	 * @return les Fournisseur correspondant aux crit�res.
	 */
	public List<Fournisseur> findFournisseur(AbstractCriteria criteres);

	/**
	 * Charge un objet Fournisseur � partir de son id.
	 * @param id l'id de l'objet � charger.
	 * @return l'objet Fournisseur correspondant � l'id donn�.
	 */
	public Fournisseur loadFournisseurById(Serializable id);

	/**
	 * Enregistre un objet Fournisseur.
	 * @param obj l'objet Fournisseur � enregistrer.
	 * @return l'objet Fournisseur enregistr�.
	 */
	public Fournisseur storeFournisseur(Identifiable obj);

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}