// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.services.serviceclient.implementation;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.client.commun.criteres.ClientParCodeCriteria;

import fr.mipih.commun.client.dao.IClientDao;

import fr.mipih.commun.client.domaine.Client;

import fr.mipih.commun.client.services.serviceclient.IServiceClient;

import fr.mipih.commun.client.services.serviceville.IServiceVille;

import fr.mipih.foundation.core.BeanRegistry;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.AbstractCrudService;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.List;

import org.springframework.util.Assert;


/**
 * Element ServiceClient.
 */
public class ServiceClient extends AbstractCrudService implements IServiceClient 
{
	// [DEBUT:ATTRIBUT]
	// [FIN:ATTRIBUT]

	/**
	 * Cette m�thode doit �tre syst�matiquement utilis�e pour appeler une autre m�thode. Au lieu
	 * d'appeler methodeB() directement depuis methodeA(), il faut appeler
	 * <code>getCurService().methodeB()</code>.
	 * 
	 * @return le proxy transactionnel de ce service, � utiliser syst�matiquement.
	 */
	@SuppressWarnings("unused")
	private IServiceClient getCurService()
	{
		IServiceClient service = (IServiceClient)BeanRegistry.getService("serviceClient");
		Assert.notNull(service,"Impossible de r�cup�rer le service courant, " +
					"v�rifiez votre configuration.");
			return service;
	}

	/**
	 * Retourne le service ServiceVille.
	 * @return
	 *		Le service ServiceVille
	 */
	public IServiceVille getServiceVille()
	{
		return (IServiceVille)BeanRegistry.getService("serviceVille");
	}


	/**
	 * Cette m�thode permet de rechercher un client par son code.
	 * @param criteres
	 *		La classe portant les crit�res de recherche
	 * @return
	 *		La liste des �l�ments correspondants aux crit�res fournis
	 */
	public List rechercherParCode(ClientParCodeCriteria criteres)
	{
		// [DEBUT:METHODE�-�3C3C0E23-15D4-B1A5-07F3-939AD0049263]
		return find(criteres);
		// [FIN:METHODE�-�3C3C0E23-15D4-B1A5-07F3-939AD0049263]
	}



	//===============================================================
	// M�thodes CRUD de l'objet Client
	//===============================================================

	@SuppressWarnings("unchecked")
	public List<Client> findAllClient()
	{
		return getClientDao().findAll();
	}

	@SuppressWarnings("unchecked")
	public List<Client> findClient(AbstractCriteria criteres)
	{
		return (List<Client>)getClientDao().find(criteres);
	}

	public Client loadClientById(Serializable id)
	{
		return (Client)getClientDao().loadById(id);
	}

	public Client storeClient(Identifiable obj)
	{
		return (Client)getClientDao().store(obj);
	}

	/**
	 * Retourne le DAO Client.
	 * @return le DAO Client
	 */
	public IClientDao getClientDao()
	{
		return (IClientDao)BeanRegistry.getDao("clientDao");
	}
	// [DEBUT:METHODES]
	// [FIN:METHODES]
}