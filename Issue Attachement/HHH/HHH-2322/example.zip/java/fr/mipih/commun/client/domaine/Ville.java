// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.domaine;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;


/**
 * Objet Ville.
 */
public class Ville extends Identifiable implements Serializable
{
	/** Identifiant de l'objet. */
	private String id;

	private String nom;
	private String codePostal;

	private Region region;


	/**
	 * Constructeur par d�faut.
	 */
	public Ville()
	{
	}

	/**
	 * Constructeur avec initialisation de la r�f�rence vers region.
	 * @param region la r�f�rence vers l'objet parent
	 */
	public Ville(Region region)
	{
		this.region = region;
	}


	public Serializable getId()
	{
		return id;
	}
	
	public void setId(Serializable id)
	{
		this.id = (String)id;
	}

	/**
	 * Retourne l'attribut nom.
	 * @return l'attribut nom.
	 */
	public String getNom()
	{
		return nom;
	}
	
	/**
	 * D�finit l'attribut nom.
	 * @param code L'attribut nom.
	 */
	public void setNom(String nom)
	{
		this.nom = nom;
	}

	/**
	 * Retourne l'attribut codePostal.
	 * @return l'attribut codePostal.
	 */
	public String getCodePostal()
	{
		return codePostal;
	}
	
	/**
	 * D�finit l'attribut codePostal.
	 * @param code L'attribut codePostal.
	 */
	public void setCodePostal(String codePostal)
	{
		this.codePostal = codePostal;
	}


	/**
	 * Retourne la r�f�rence 'region'.
	 * @return la r�f�rence 'region'.
	 */
	public Region getRegion()
	{
		return region;
	}

	/**
	 * D�finit la r�f�rence 'region'.
	 * @param categorie la r�f�rence 'region'.
	 */
	public void setRegion(Region region)
	{
		this.region = region;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + nom + " " + codePostal;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
