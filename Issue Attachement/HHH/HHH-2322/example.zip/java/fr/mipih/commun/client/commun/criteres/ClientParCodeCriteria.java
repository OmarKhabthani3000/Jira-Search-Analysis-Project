// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.commun.criteres;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import java.io.Serializable;


/**
 * Crit�res de recherche.
 */
public class ClientParCodeCriteria extends AbstractCriteria implements Serializable
{

	/** 
	 * le code du client � rechercher.
	 */
	protected Integer code;

	/**
	 * Retourne l'attribut code.
	 * @return l'attribut code.
	 */
	public Integer getCode()
	{
		return code;
	}
	
	/**
	 * D�finit l'attribut code.
	 * @param code L'attribut code.
	 */
	public void setCode(Integer code)
	{
		this.code = code;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + "" + code;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}
}
