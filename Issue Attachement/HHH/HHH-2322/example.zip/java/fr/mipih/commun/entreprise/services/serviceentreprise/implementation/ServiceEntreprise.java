// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.entreprise.services.serviceentreprise.implementation;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.entreprise.dao.IEntrepriseDao;

import fr.mipih.commun.entreprise.domaine.Entreprise;

import fr.mipih.commun.entreprise.services.serviceentreprise.IServiceEntreprise;

import fr.mipih.foundation.core.BeanRegistry;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.AbstractCrudService;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.List;

import org.springframework.util.Assert;


/**
 * Element ServiceEntreprise.
 */
public class ServiceEntreprise extends AbstractCrudService implements IServiceEntreprise 
{
	// [DEBUT:ATTRIBUT]
	// [FIN:ATTRIBUT]

	/**
	 * Cette m�thode doit �tre syst�matiquement utilis�e pour appeler une autre m�thode. Au lieu
	 * d'appeler methodeB() directement depuis methodeA(), il faut appeler
	 * <code>getCurService().methodeB()</code>.
	 * 
	 * @return le proxy transactionnel de ce service, � utiliser syst�matiquement.
	 */
	@SuppressWarnings("unused")
	private IServiceEntreprise getCurService()
	{
		IServiceEntreprise service = (IServiceEntreprise)BeanRegistry.getService("serviceEntreprise");
		Assert.notNull(service,"Impossible de r�cup�rer le service courant, " +
					"v�rifiez votre configuration.");
			return service;
	}



	/**
	 * M�thode getListeEntreprise.
	 */
	public void getListeEntreprise()
	{
		// [DEBUT:METHODE�-�C07FE643-613B-CEC5-EFE3-FE7AE752D691]
		
		// [FIN:METHODE�-�C07FE643-613B-CEC5-EFE3-FE7AE752D691]
	}



	//===============================================================
	// M�thodes CRUD de l'objet Entreprise
	//===============================================================

	@SuppressWarnings("unchecked")
	public List<Entreprise> findAllEntreprise()
	{
		return getEntrepriseDao().findAll();
	}

	@SuppressWarnings("unchecked")
	public List<Entreprise> findEntreprise(AbstractCriteria criteres)
	{
		return (List<Entreprise>)getEntrepriseDao().find(criteres);
	}

	public Entreprise loadEntrepriseById(Serializable id)
	{
		return (Entreprise)getEntrepriseDao().loadById(id);
	}

	public Entreprise storeEntreprise(Identifiable obj)
	{
		return (Entreprise)getEntrepriseDao().store(obj);
	}

	/**
	 * Retourne le DAO Entreprise.
	 * @return le DAO Entreprise
	 */
	public IEntrepriseDao getEntrepriseDao()
	{
		return (IEntrepriseDao)BeanRegistry.getDao("entrepriseDao");
	}
	// [DEBUT:METHODES]
	// [FIN:METHODES]
}