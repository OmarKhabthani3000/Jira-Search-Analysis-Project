// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.domaine;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;


/**
 * Objet Adresse.
 */
public class Adresse extends Identifiable implements Serializable
{
	/** Identifiant de l'objet. */
	private String id;

	private String voie;
	private String adresse;
	// Association unaire obligatoire
	private Ville ville; 
	private Client client;


	/**
	 * Constructeur par d�faut.
	 */
	public Adresse()
	{
	}

	/**
	 * Constructeur avec initialisation de la r�f�rence vers client.
	 * @param client la r�f�rence vers l'objet parent
	 */
	public Adresse(Client client)
	{
		this.client = client;
	}


	public Serializable getId()
	{
		return id;
	}
	
	public void setId(Serializable id)
	{
		this.id = (String)id;
	}

	/**
	 * Retourne l'attribut voie.
	 * @return l'attribut voie.
	 */
	public String getVoie()
	{
		return voie;
	}
	
	/**
	 * D�finit l'attribut voie.
	 * @param code L'attribut voie.
	 */
	public void setVoie(String voie)
	{
		this.voie = voie;
	}

	/**
	 * Retourne l'attribut adresse.
	 * @return l'attribut adresse.
	 */
	public String getAdresse()
	{
		return adresse;
	}
	
	/**
	 * D�finit l'attribut adresse.
	 * @param code L'attribut adresse.
	 */
	public void setAdresse(String adresse)
	{
		this.adresse = adresse;
	}


	/**
	 * Renvoie l'objet parent de l'objet courant (composition).
	 * @return l'objet parent de l'objet courant.
	 */
	public Ville getVille()
	{
		return ville;
	}
	
	/**
	 * Positionne l'objet parent de l'objet courant (composition).
	 * @param ville l'objet parent de l'objet courant.
	 */
	public void setVille(Ville ville)
	{
		this.ville = ville;
	}

	/**
	 * Retourne la r�f�rence 'client'.
	 * @return la r�f�rence 'client'.
	 */
	public Client getClient()
	{
		return client;
	}

	/**
	 * D�finit la r�f�rence 'client'.
	 * @param categorie la r�f�rence 'client'.
	 */
	public void setClient(Client client)
	{
		this.client = client;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + voie + " " + adresse;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
