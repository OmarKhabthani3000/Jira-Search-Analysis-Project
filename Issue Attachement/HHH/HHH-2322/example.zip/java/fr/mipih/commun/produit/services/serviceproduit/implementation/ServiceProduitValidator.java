// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.services.serviceproduit.implementation;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.entreprise.domaine.LigneDeFacture;

import fr.mipih.commun.produit.domaine.CategorieProduit;
import fr.mipih.commun.produit.domaine.Produit;
import fr.mipih.commun.produit.domaine.ReferenceProduit;

import fr.mipih.commun.produit.services.servicefournisseur.IServiceFournisseur;

import fr.mipih.commun.produit.services.serviceproduit.IServiceProduit;

import fr.mipih.foundation.core.BeanRegistry;

import fr.mipih.foundation.validation.AbstractValidator;
import fr.mipih.foundation.validation.BasicValidatorRule;
import fr.mipih.foundation.validation.IErrors;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


/**
 * Validateur de la classe Produit.
 */
public class ServiceProduitValidator extends AbstractValidator
{
	/** Map contenant les r�gles de validation basiques */
	private Map rules = new HashMap();

	/**
	 * Constructeur par d�faut du validateur.
	 */
	public ServiceProduitValidator()
	{
		buildBasicRules();
		afterBuildBasicRules();
	}

	/**
	 * Rajoute � la map rules les r�gles de validation de base.
	 */
	protected void buildBasicRules()
	{
		rules.put("code", new BasicValidatorRule("code", null, null, true));
		rules.put("libelle", new BasicValidatorRule("libelle", null, new Integer(50), true));
		rules.put("dateDeCreation", new BasicValidatorRule("dateDeCreation", null, null, true));
	}

	/**
	 * M�thode appel�e apr�s l'initialisation des r�gles de base.
	 */
	protected void afterBuildBasicRules()
	{
		// [DEBUT:METHODE�-�methode�afterBuildBasicRules]

		// supprimez ou rajoutez des r�gles de base ici

		// [FIN:METHODE�-�methode�afterBuildBasicRules]
	}

	/**
	 * La classe pass�e en param�tre peut-elle �tre valid�e par ce validator?
	 *
	 * @param clazz
	 *		La classe � tester
	 * @return
	 *		true si la classe <code>clazz</code> peut �tre valid�e par ce validator
	 */
	public boolean supports(Class clazz)
	{
		return clazz.isAssignableFrom(Produit.class);
	}

	/**
	 * Valide l'objet pass� en param�tre.
	 *
	 * <p>
	 * Si l'objet <code>obj</code> contient des erreurs, celles-ci seront 
	 * rajout�es dans l'objet <code>errors</code> pass� en param�tre.
	 * </p>
	 *
	 * @param obj
	 *		L'objet � valider
	 * @param errors
	 *		L'objet qui recueille la liste de toutes les erreurs de validation
	 */
	public void validate(Object obj, IErrors errors)
	{
		beforeBasicRulesValidation(obj, errors);

		// validation de base
		BasicValidatorRule.validate(obj, rules.values(), errors);

		afterBasicRulesValidation(obj, errors);
	}

	/**
	 * M�thode appel�e avant la validation de base sur les attributs.
	 *
	 * @param obj
	 *		L'objet � valider
	 * @param errors
	 *		L'objet qui recueille la liste de toutes les erreurs de validation
	 */
	public void beforeBasicRulesValidation(Object obj, IErrors errors)
	{
		// [DEBUT:METHODE�-�methode�beforeBasicRulesValidation]

		// TODO: modifiez les r�gles de base ici, vous pouvez aussi rajouter
		// vos r�gles de validation m�tier ici

		// Produit produit = (Produit)obj;

		// [FIN:METHODE�-�methode�beforeBasicRulesValidation]
	}

	/**
	 * M�thode appel�e apr�s la validation de base sur les attributs.
	 *
	 * @param obj
	 *		L'objet � valider
	 * @param errors
	 *		L'objet qui recueille la liste de toutes les erreurs de validation
	 */
	public void afterBasicRulesValidation(Object obj, IErrors errors)
	{
		Produit produit = (Produit)obj;
		validateAllReferences(produit, errors);

		// [DEBUT:METHODE�-�methode�afterBasicRulesValidation]

		// TODO: les r�gles de base ont �t� v�rifi�es avant l'appel de cette m�thode,
		// vous pouvez valider vos r�gles m�tier ici

		// Produit produit = (Produit)obj;

		// [FIN:METHODE�-�methode�afterBasicRulesValidation]
	}

	/**
	 * Retourne le service d�pendant ServiceFournisseur rattach� � l'assembleur ProduitAssembler.
	 *
	 * @return Le service d�pendant ServiceFournisseur
	 */
	public IServiceFournisseur getServiceFournisseur()
	{
		return (IServiceFournisseur)BeanRegistry.getService("serviceFournisseur");
	}
	/**
	 * Retourne le service parent ServiceProduit rattach� � l'assembleur ProduitAssembler.
	 *
	 * @return Le service parent ServiceProduit
	 */
	public IServiceProduit getServiceProduit()
	{
		return (IServiceProduit)BeanRegistry.getService("serviceProduit");
	}
	/**
	 * Valide un(e) <code>categorieProduit.
	 * @param CategorieProduit
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>CategorieProduit</code> n'est pas valide
	 */	
	public void validateCategorieProduit(CategorieProduit categorieProduit, IErrors errors)
	{
		// [DEBUT:METHODE�-�validateCategorieProduit]
		/*
		if (ligneDeFacture.getMontant() == null || ligneDeFacture.getMontant().getValue() == 0)
		{
			errors.addError("facture.lignesDeFacture.prixUnitaire", "errors.positive", "", new Object[] {"facture.lignesDeFacture.prixUnitaire"});
		}
		*/
		// [FIN:METHODE�-�validateCategorieProduit]
	}
	/**
	 * Valide un(e) <code>referenceProduit.
	 * @param ReferenceProduit
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>ReferenceProduit</code> n'est pas valide
	 */	
	public void validateReferenceProduit(ReferenceProduit referenceProduit, IErrors errors)
	{
		// [DEBUT:METHODE�-�validateReferenceProduit]
		/*
		if (ligneDeFacture.getMontant() == null || ligneDeFacture.getMontant().getValue() == 0)
		{
			errors.addError("facture.lignesDeFacture.prixUnitaire", "errors.positive", "", new Object[] {"facture.lignesDeFacture.prixUnitaire"});
		}
		*/
		// [FIN:METHODE�-�validateReferenceProduit]
	}
	/**
	 * Valide un(e) <code>ligneDeFacture.
	 * @param LigneDeFacture
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>LigneDeFacture</code> n'est pas valide
	 */	
	public void validateLigneDeFacture(LigneDeFacture ligneDeFacture, IErrors errors)
	{
		// [DEBUT:METHODE�-�validateLigneDeFacture]
		/*
		if (ligneDeFacture.getMontant() == null || ligneDeFacture.getMontant().getValue() == 0)
		{
			errors.addError("facture.lignesDeFacture.prixUnitaire", "errors.positive", "", new Object[] {"facture.lignesDeFacture.prixUnitaire"});
		}
		*/
		// [FIN:METHODE�-�validateLigneDeFacture]
	}
	/**
	 * Valide un(e) <code>produit.
	 * @param Produit
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>Produit</code> n'est pas valide
	 */	
	public void validateProduit(Produit produit, IErrors errors)
	{
		// [DEBUT:METHODE�-�validateProduit]
		/*
		if (ligneDeFacture.getMontant() == null || ligneDeFacture.getMontant().getValue() == 0)
		{
			errors.addError("facture.lignesDeFacture.prixUnitaire", "errors.positive", "", new Object[] {"facture.lignesDeFacture.prixUnitaire"});
		}
		*/
		// [FIN:METHODE�-�validateProduit]
	}
	@SuppressWarnings("unused")
	private void validateAllReferences(Produit produit, IErrors errors)
	{
		Iterator itr = produit.getReferences().iterator();
		while (itr.hasNext())
		{
			ReferenceProduit currentreferenceProduit = (ReferenceProduit)itr.next();
			validateReferenceProduit(currentreferenceProduit, errors);
		}
	}

	@SuppressWarnings("unused")
	private void validateAllProduits(CategorieProduit categorieProduit, IErrors errors)
	{
		Iterator itr = categorieProduit.getProduits().iterator();
		while (itr.hasNext())
		{
			Produit currentproduit = (Produit)itr.next();
			validate(currentproduit, errors);
		}
	}



	// [DEBUT:METHODES]
	// [FIN:METHODES]
}