// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.services.servicecategorieproduit;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.produit.domaine.CategorieProduit;
import fr.mipih.commun.produit.domaine.Produit;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.CrudService;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.List;


/**
 * Element ServiceCategorieProduit.
 */
public interface IServiceCategorieProduit extends CrudService
{

	/**
	 * Valide un(e) <code>produit</code> pour la relation <code>produits</code>.
	 * @param produit
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>produit</code> n'est pas valide
	 */	
	public void validateProduits(Produit produit);

	//===============================================================
	// M�thodes CRUD de l'objet CategorieProduit
	//===============================================================

	/**
	 * Retourne la liste de toutes les objets CategorieProduit.
	 * @return la liste de tous les objets CategorieProduit.
	 */
	public List<CategorieProduit> findAllCategorieProduit();

	/**
	 * Retourne la liste des objets CategorieProduit.
	 * @param criteria Les crit�res de recherche.
	 * @return les CategorieProduit correspondant aux crit�res.
	 */
	public List<CategorieProduit> findCategorieProduit(AbstractCriteria criteres);

	/**
	 * Charge un objet CategorieProduit � partir de son id.
	 * @param id l'id de l'objet � charger.
	 * @return l'objet CategorieProduit correspondant � l'id donn�.
	 */
	public CategorieProduit loadCategorieProduitById(Serializable id);

	/**
	 * Enregistre un objet CategorieProduit.
	 * @param obj l'objet CategorieProduit � enregistrer.
	 * @return l'objet CategorieProduit enregistr�.
	 */
	public CategorieProduit storeCategorieProduit(Identifiable obj);

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}