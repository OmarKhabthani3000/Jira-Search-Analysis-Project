// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.entreprise.domaine;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.produit.domaine.Produit;

import fr.mipih.foundation.model.Identifiable;

import fr.mipih.foundation.type.PrixUnitaire2;
import fr.mipih.foundation.type.Quantite;

import java.io.Serializable;


/**
 * Objet LigneDeFacture.
 */
public class LigneDeFacture extends Identifiable implements Serializable
{
	/** Identifiant de l'objet. */
	private String id;


	/** 
	 * Il s'agit du prix du produit au moment o� la ligne est cr��e, en 
	 * appliquant la r�duction courante du fournisseur r�f�renc�.
	 */
	private PrixUnitaire2 prixProduit = new PrixUnitaire2(0);

	/** 
	 * c'est un commentaire �ventuel lors de l'achat d'un produit.
	 */
	private String commentaire;
	protected Quantite quantite = new Quantite(0);
	// Association unaire obligatoire
	private Produit produit; 
	private Facture facture;


	/**
	 * Constructeur par d�faut.
	 */
	public LigneDeFacture()
	{
	}

	/**
	 * Constructeur avec initialisation de la r�f�rence vers facture.
	 * @param facture la r�f�rence vers l'objet parent
	 */
	public LigneDeFacture(Facture facture)
	{
		this.facture = facture;
	}


	public Serializable getId()
	{
		return id;
	}
	
	public void setId(Serializable id)
	{
		this.id = (String)id;
	}

	/**
	 * Retourne l'attribut prixProduit.
	 * @return l'attribut prixProduit.
	 */
	public PrixUnitaire2 getPrixProduit()
	{
		return prixProduit;
	}
	
	/**
	 * D�finit l'attribut prixProduit.
	 * @param code L'attribut prixProduit.
	 */
	public void setPrixProduit(PrixUnitaire2 prixProduit)
	{
		this.prixProduit = prixProduit;
	}

	/**
	 * Retourne l'attribut commentaire.
	 * @return l'attribut commentaire.
	 */
	public String getCommentaire()
	{
		return commentaire;
	}
	
	/**
	 * D�finit l'attribut commentaire.
	 * @param code L'attribut commentaire.
	 */
	public void setCommentaire(String commentaire)
	{
		this.commentaire = commentaire;
	}

	/**
	 * Retourne l'attribut quantite.
	 * @return l'attribut quantite.
	 */
	public Quantite getQuantite()
	{
		return quantite;
	}
	
	/**
	 * D�finit l'attribut quantite.
	 * @param code L'attribut quantite.
	 */
	public void setQuantite(Quantite quantite)
	{
		this.quantite = quantite;
	}


	/**
	 * Renvoie l'objet parent de l'objet courant (composition).
	 * @return l'objet parent de l'objet courant.
	 */
	public Produit getProduit()
	{
		return produit;
	}
	
	/**
	 * Positionne l'objet parent de l'objet courant (composition).
	 * @param produit l'objet parent de l'objet courant.
	 */
	public void setProduit(Produit produit)
	{
		this.produit = produit;
	}

	/**
	 * Retourne la r�f�rence 'facture'.
	 * @return la r�f�rence 'facture'.
	 */
	public Facture getFacture()
	{
		return facture;
	}

	/**
	 * D�finit la r�f�rence 'facture'.
	 * @param categorie la r�f�rence 'facture'.
	 */
	public void setFacture(Facture facture)
	{
		this.facture = facture;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + prixProduit + " " + commentaire + " " + quantite;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
