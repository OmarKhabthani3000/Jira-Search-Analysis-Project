// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.domaine;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;


/**
 * Objet CategorieProduit.
 */
public class CategorieProduit extends Identifiable implements Serializable
{
	/** Identifiant de l'objet. */
	private String id;

	private String code;
	protected String libelle;
	// Composition naire
	private List<Produit> produits = new ArrayList<Produit>();



	/**
	 * Constructeur par d�faut.
	 */
	public CategorieProduit()
	{
	}



	public Serializable getId()
	{
		return id;
	}
	
	public void setId(Serializable id)
	{
		this.id = (String)id;
	}

	/**
	 * Retourne l'attribut code.
	 * @return l'attribut code.
	 */
	public String getCode()
	{
		return code;
	}
	
	/**
	 * D�finit l'attribut code.
	 * @param code L'attribut code.
	 */
	public void setCode(String code)
	{
		this.code = code;
	}

	/**
	 * Retourne l'attribut libelle.
	 * @return l'attribut libelle.
	 */
	public String getLibelle()
	{
		return libelle;
	}
	
	/**
	 * D�finit l'attribut libelle.
	 * @param code L'attribut libelle.
	 */
	public void setLibelle(String libelle)
	{
		this.libelle = libelle;
	}

	/**
	 * Retourne la liste des objets Produit.
	 * <p>
	 * <strong>Attention : </strong> si vous voulez ajouter ou supprimer des
	 * �l�ments, utilisez les m�thodes <code>{@link #addToProduits(Produit)}</code>
	 * et <code>{@link #removeFromProduits(Produit)}</code>.
	 * </p>
	 * @return la liste des objets Produit.
	 */
	public List<Produit> getProduits()
	{
		return produits;
	}

	/**
	 * D�finit la liste des objets Produit.
	 * @param references la liste des objets Produit.
	 */
	protected void setProduits(List<Produit> produits)
	{
		this.produits = produits;
	}

	/**
	 * Ajoute l'objet Produit fourni � la liste des produits contenu(e)s dans le Categorie.
	 * <p>
	 * Cette m�thode s'occupe de maintenir la coh�rence des donn�es. Elle :
	 * </p>
	 * <ul>
	 * <li>v�rifie que l'objet Produit fourni ne poss�de pas d�j� de parent. S'il en
	 * poss�de un, on supprime l'�l�ment de la liste de ce parent. On garantit ainsi que l'objet
	 * Produit n'appartient pas � plusieurs listes de parents au m�me moment.</li>
	 * <li>Cette v�rification effectu�e, on appelle la m�thode setCategorie(Produit) sur l'objet Produit afin de positionner
	 * son nouveau parent.</li>
	 * <li>Pour finir, on effectue le lien inverse en ajoutant l'objet Produit � la
	 * liste des produits.</li>
	 * </ul>
	 */
	public void addToProduits(Produit produit)
	{
		if (produit.getCategorie() != null) {
			produit.getCategorie().removeFromProduits(produit);
		}
		produit.setCategorie(this);
		this.produits.add(produit);
	}

	/**
	 * Supprime l'objet Produit de la liste des produit et met � null le parent de cet objet.
	 * @param produit l'objet Produit � supprimer de la liste.
	 */
	public void removeFromProduits(Produit produit)
	{
		this.produits.remove(produit);
		produit.setCategorie(null);
	}

	/**
	 * Vide la liste de la liste des produit.
	 */
	public void removeAllProduits()
	{
		for (int i= produits.size() - 1; i >= 0; i--)
		{
			Produit produit = (Produit)produits.get(i);
			removeFromProduits(produit);
		}
	}




	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + code + " " + libelle;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
