// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.dao.implementation;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.produit.commun.criteres.CategorieProduitCriteria;

import fr.mipih.commun.produit.dao.ICategorieProduitDao;

import fr.mipih.commun.produit.domaine.CategorieProduit;

import fr.mipih.foundation.FatalServiceException;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.persistence.AbstractHibernateDAO;

import org.hibernate.Criteria;


/**
 * Classe de DAO CategorieProduitDao.
 */
public class CategorieProduitDao extends AbstractHibernateDAO implements ICategorieProduitDao
{
	/**
	 * Construit la liste des crit�res permettant de filtrer les r�sultats d'une recherche avec les
	 * crit�res contenus dans le <em>CategorieProduitCriteria</em>.
	 * 
	 * @param criteres
	 *            Le bean de recherche sur lequel on se base pour g�n�rer les crit�res de filtrage.
	 * @param hbCriteria
	 *            L'objet <em>Hibernate</em> contenant tous les crit�res de recherche (clause WHERE)
	 */
	@SuppressWarnings("unused")
	private void buildCriteriaDefault(CategorieProduitCriteria criteres, Criteria hbCriteria)
	{
		// [DEBUT:METHODE�-�m�thode�buidCriteriaDefault]
		// TODO Ajouter vos crit�res ici
		// [FIN:METHODE�-�m�thode�buidCriteriaDefault]
	}

	/**
	 * S'occupe de transmettre l'instance d'AbstractCriteria � la m�thode buildCriteria<em>XXX</em>
	 * correspondante.
	 * 
	 * @param criteres
	 *            Le bean de recherche sur lequel on se base pour g�n�rer les crit�res de filtrage
	 * @param hbCriteria
	 *            L'objet contenant tous les crit�res de recherche (clause WHERE)
	 */
	public void buildCriteria(AbstractCriteria criteres, Criteria hbCriteria)
	{
		if (criteres instanceof CategorieProduitCriteria)
		{
			buildCategorieProduitCriteria((CategorieProduitCriteria) criteres, hbCriteria);
		}

		else
		{
			throw new FatalServiceException(
				"Erreur lors de la cr�ation des crit�res de recherche : classe Criteria "
				+ criteres == null ? "null" : criteres.getClass().getName() + " non g�r�e");
		}
	}
	/**
	 * 
	 */
	public void buildCategorieProduitCriteria(CategorieProduitCriteria criteres, Criteria hbCriteria)
	{
		// [DEBUT:METHODE�-�buildCategorieProduitCriteria]
		// [FIN:METHODE�-�buildCategorieProduitCriteria]
	}

	/**
	 * Renvoie la classe du DOM g�r�e par ce DAO.
	 *
	 * @return
	 *		La classe du DOM g�r�e par ce DAO
	 */
	public Class getBeanClass()
	{
		return CategorieProduit.class;
	}
	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
