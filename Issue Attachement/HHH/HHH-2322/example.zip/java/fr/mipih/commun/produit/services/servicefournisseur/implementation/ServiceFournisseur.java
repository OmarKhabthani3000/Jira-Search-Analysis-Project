// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.produit.services.servicefournisseur.implementation;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.produit.dao.IFournisseurDao;

import fr.mipih.commun.produit.domaine.Fournisseur;

import fr.mipih.commun.produit.services.servicefournisseur.IServiceFournisseur;

import fr.mipih.foundation.core.BeanRegistry;

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import fr.mipih.foundation.core.crudservice.AbstractCrudService;

import fr.mipih.foundation.model.Identifiable;

import java.io.Serializable;

import java.util.List;

import org.springframework.util.Assert;


/**
 * Element ServiceFournisseur.
 */
public class ServiceFournisseur extends AbstractCrudService implements IServiceFournisseur 
{
	// [DEBUT:ATTRIBUT]
	// [FIN:ATTRIBUT]

	/**
	 * Cette m�thode doit �tre syst�matiquement utilis�e pour appeler une autre m�thode. Au lieu
	 * d'appeler methodeB() directement depuis methodeA(), il faut appeler
	 * <code>getCurService().methodeB()</code>.
	 * 
	 * @return le proxy transactionnel de ce service, � utiliser syst�matiquement.
	 */
	@SuppressWarnings("unused")
	private IServiceFournisseur getCurService()
	{
		IServiceFournisseur service = (IServiceFournisseur)BeanRegistry.getService("serviceFournisseur");
		Assert.notNull(service,"Impossible de r�cup�rer le service courant, " +
					"v�rifiez votre configuration.");
			return service;
	}






	//===============================================================
	// M�thodes CRUD de l'objet Fournisseur
	//===============================================================

	@SuppressWarnings("unchecked")
	public List<Fournisseur> findAllFournisseur()
	{
		return getFournisseurDao().findAll();
	}

	@SuppressWarnings("unchecked")
	public List<Fournisseur> findFournisseur(AbstractCriteria criteres)
	{
		return (List<Fournisseur>)getFournisseurDao().find(criteres);
	}

	public Fournisseur loadFournisseurById(Serializable id)
	{
		return (Fournisseur)getFournisseurDao().loadById(id);
	}

	public Fournisseur storeFournisseur(Identifiable obj)
	{
		return (Fournisseur)getFournisseurDao().store(obj);
	}

	/**
	 * Retourne le DAO Fournisseur.
	 * @return le DAO Fournisseur
	 */
	public IFournisseurDao getFournisseurDao()
	{
		return (IFournisseurDao)BeanRegistry.getDao("fournisseurDao");
	}
	// [DEBUT:METHODES]
	// [FIN:METHODES]
}