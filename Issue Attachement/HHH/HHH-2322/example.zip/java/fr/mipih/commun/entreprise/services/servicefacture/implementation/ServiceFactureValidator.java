// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.entreprise.services.servicefacture.implementation;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.entreprise.domaine.Facture;
import fr.mipih.commun.entreprise.domaine.LigneDeFacture;

import fr.mipih.commun.entreprise.services.servicefacture.IServiceFacture;

import fr.mipih.commun.produit.services.serviceproduit.IServiceProduit;

import fr.mipih.foundation.core.BeanRegistry;

import fr.mipih.foundation.validation.AbstractValidator;
import fr.mipih.foundation.validation.BasicValidatorRule;
import fr.mipih.foundation.validation.IErrors;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


/**
 * Validateur de la classe Facture.
 */
public class ServiceFactureValidator extends AbstractValidator
{
	/** Map contenant les r�gles de validation basiques */
	private Map rules = new HashMap();

	/**
	 * Constructeur par d�faut du validateur.
	 */
	public ServiceFactureValidator()
	{
		buildBasicRules();
		afterBuildBasicRules();
	}

	/**
	 * Rajoute � la map rules les r�gles de validation de base.
	 */
	protected void buildBasicRules()
	{
		rules.put("id", new BasicValidatorRule("id", null, new Integer(36), false));
		rules.put("montant", new BasicValidatorRule("montant", null, null, true));
		rules.put("dateEmission", new BasicValidatorRule("dateEmission", null, null, true));
	
	}

	/**
	 * M�thode appel�e apr�s l'initialisation des r�gles de base.
	 */
	protected void afterBuildBasicRules()
	{
		// [DEBUT:METHODE�-�methode�afterBuildBasicRules]

		// supprimez ou rajoutez des r�gles de base ici

		// [FIN:METHODE�-�methode�afterBuildBasicRules]
	}

	/**
	 * La classe pass�e en param�tre peut-elle �tre valid�e par ce validator?
	 *
	 * @param clazz
	 *		La classe � tester
	 * @return
	 *		true si la classe <code>clazz</code> peut �tre valid�e par ce validator
	 */
	public boolean supports(Class clazz)
	{
		return clazz.isAssignableFrom(Facture.class);
	}

	/**
	 * Valide l'objet pass� en param�tre.
	 *
	 * <p>
	 * Si l'objet <code>obj</code> contient des erreurs, celles-ci seront 
	 * rajout�es dans l'objet <code>errors</code> pass� en param�tre.
	 * </p>
	 *
	 * @param obj
	 *		L'objet � valider
	 * @param errors
	 *		L'objet qui recueille la liste de toutes les erreurs de validation
	 */
	public void validate(Object obj, IErrors errors)
	{
		beforeBasicRulesValidation(obj, errors);

		// validation de base
		BasicValidatorRule.validate(obj, rules.values(), errors);

		afterBasicRulesValidation(obj, errors);
	}

	/**
	 * M�thode appel�e avant la validation de base sur les attributs.
	 *
	 * @param obj
	 *		L'objet � valider
	 * @param errors
	 *		L'objet qui recueille la liste de toutes les erreurs de validation
	 */
	public void beforeBasicRulesValidation(Object obj, IErrors errors)
	{
		// [DEBUT:METHODE�-�methode�beforeBasicRulesValidation]

		// TODO: modifiez les r�gles de base ici, vous pouvez aussi rajouter
		// vos r�gles de validation m�tier ici

		// Facture facture = (Facture)obj;

		// [FIN:METHODE�-�methode�beforeBasicRulesValidation]
	}

	/**
	 * M�thode appel�e apr�s la validation de base sur les attributs.
	 *
	 * @param obj
	 *		L'objet � valider
	 * @param errors
	 *		L'objet qui recueille la liste de toutes les erreurs de validation
	 */
	public void afterBasicRulesValidation(Object obj, IErrors errors)
	{
		Facture facture = (Facture)obj;
		validateAllLignesDeFacture(facture, errors);

		// [DEBUT:METHODE�-�methode�afterBasicRulesValidation]

		// TODO: les r�gles de base ont �t� v�rifi�es avant l'appel de cette m�thode,
		// vous pouvez valider vos r�gles m�tier ici

		// Facture facture = (Facture)obj;

		// [FIN:METHODE�-�methode�afterBasicRulesValidation]
	}

	/**
	 * Retourne le service d�pendant ServiceProduit rattach� � l'assembleur FactureAssembler.
	 *
	 * @return Le service d�pendant ServiceProduit
	 */
	public IServiceProduit getServiceProduit()
	{
		return (IServiceProduit)BeanRegistry.getService("serviceProduit");
	}
	/**
	 * Retourne le service parent ServiceFacture rattach� � l'assembleur FactureAssembler.
	 *
	 * @return Le service parent ServiceFacture
	 */
	public IServiceFacture getServiceFacture()
	{
		return (IServiceFacture)BeanRegistry.getService("serviceFacture");
	}
	/**
	 * Valide un(e) <code>ligneDeFacture.
	 * @param LigneDeFacture
	 * 		L'objet � valider
	 * @param errors
	 * 		La liste d'erreurs
	 * @throws ValidationException
	 * 		Si l'objet <code>LigneDeFacture</code> n'est pas valide
	 */	
	public void validateLigneDeFacture(LigneDeFacture ligneDeFacture, IErrors errors)
	{
		// [DEBUT:METHODE�-�validateLigneDeFacture]
		/*
		if (ligneDeFacture.getMontant() == null || ligneDeFacture.getMontant().getValue() == 0)
		{
			errors.addError("facture.lignesDeFacture.prixUnitaire", "errors.positive", "", new Object[] {"facture.lignesDeFacture.prixUnitaire"});
		}
		*/
		// [FIN:METHODE�-�validateLigneDeFacture]
	}
	@SuppressWarnings("unused")
	private void validateAllLignesDeFacture(Facture facture, IErrors errors)
	{
		Iterator itr = facture.getLignesDeFacture().iterator();
		while (itr.hasNext())
		{
			LigneDeFacture currentligneDeFacture = (LigneDeFacture)itr.next();
			validateLigneDeFacture(currentligneDeFacture, errors);
		}
	}



	// [DEBUT:METHODES]
	// [FIN:METHODES]
}