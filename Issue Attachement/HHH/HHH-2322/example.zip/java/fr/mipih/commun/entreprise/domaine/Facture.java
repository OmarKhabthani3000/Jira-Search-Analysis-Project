// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.entreprise.domaine;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.commun.client.domaine.Client;

import fr.mipih.foundation.model.Identifiable;

import fr.mipih.foundation.type.Montant;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * Objet Facture.
 */
public class Facture extends Identifiable implements Serializable
{


	protected String id;

	/** 
	 * Le montant total de la facture est calcul� � partir de la somme des 
	 * montants des lignes de cette facture.
	 */
	private Montant montant = new Montant(0);
	private Date dateEmission;

	/** 
	 * Une facture dont l'�tat trait� vaut true ne peut plus �tre modifi�e.
	 */
	private Boolean traitee;
	// Composition naire
	private List<LigneDeFacture> lignesDeFacture = new ArrayList<LigneDeFacture>();
	// Association unaire obligatoire
	private Client client; 



	/**
	 * Constructeur par d�faut.
	 */
	public Facture()
	{
	}



	public Serializable getId()
	{
		return id;
	}
	
	public void setId(Serializable id)
	{
		this.id = (String)id;
	}


	/**
	 * Retourne l'attribut montant.
	 * @return l'attribut montant.
	 */
	public Montant getMontant()
	{
		return montant;
	}
	
	/**
	 * D�finit l'attribut montant.
	 * @param code L'attribut montant.
	 */
	public void setMontant(Montant montant)
	{
		this.montant = montant;
	}

	/**
	 * Retourne l'attribut dateEmission.
	 * @return l'attribut dateEmission.
	 */
	public Date getDateEmission()
	{
		return dateEmission;
	}
	
	/**
	 * D�finit l'attribut dateEmission.
	 * @param code L'attribut dateEmission.
	 */
	public void setDateEmission(Date dateEmission)
	{
		this.dateEmission = dateEmission;
	}

	/**
	 * Retourne l'attribut traitee.
	 * @return l'attribut traitee.
	 */
	public Boolean getTraitee()
	{
		return traitee;
	}
	
	/**
	 * D�finit l'attribut traitee.
	 * @param code L'attribut traitee.
	 */
	public void setTraitee(Boolean traitee)
	{
		this.traitee = traitee;
	}

	/**
	 * Retourne la liste des objets LigneDeFacture.
	 * <p>
	 * <strong>Attention : </strong> si vous voulez ajouter ou supprimer des
	 * �l�ments, utilisez les m�thodes <code>{@link #addToLignesDeFacture(LigneDeFacture)}</code>
	 * et <code>{@link #removeFromLignesDeFacture(LigneDeFacture)}</code>.
	 * </p>
	 * @return la liste des objets LigneDeFacture.
	 */
	public List<LigneDeFacture> getLignesDeFacture()
	{
		return lignesDeFacture;
	}

	/**
	 * D�finit la liste des objets LigneDeFacture.
	 * @param references la liste des objets LigneDeFacture.
	 */
	protected void setLignesDeFacture(List<LigneDeFacture> lignesDeFacture)
	{
		this.lignesDeFacture = lignesDeFacture;
	}

	/**
	 * Ajoute l'objet LigneDeFacture fourni � la liste des ligneDeFactures contenu(e)s dans le Facture.
	 * <p>
	 * Cette m�thode s'occupe de maintenir la coh�rence des donn�es. Elle :
	 * </p>
	 * <ul>
	 * <li>v�rifie que l'objet LigneDeFacture fourni ne poss�de pas d�j� de parent. S'il en
	 * poss�de un, on supprime l'�l�ment de la liste de ce parent. On garantit ainsi que l'objet
	 * LigneDeFacture n'appartient pas � plusieurs listes de parents au m�me moment.</li>
	 * <li>Cette v�rification effectu�e, on appelle la m�thode setFacture(LigneDeFacture) sur l'objet LigneDeFacture afin de positionner
	 * son nouveau parent.</li>
	 * <li>Pour finir, on effectue le lien inverse en ajoutant l'objet LigneDeFacture � la
	 * liste des ligneDeFactures.</li>
	 * </ul>
	 */
	public void addToLignesDeFacture(LigneDeFacture ligneDeFacture)
	{
		if (ligneDeFacture.getFacture() != null) {
			ligneDeFacture.getFacture().removeFromLignesDeFacture(ligneDeFacture);
		}
		ligneDeFacture.setFacture(this);
		this.lignesDeFacture.add(ligneDeFacture);
	}

	/**
	 * Supprime l'objet LigneDeFacture de la liste des ligneDeFacture et met � null le parent de cet objet.
	 * @param ligneDeFacture l'objet LigneDeFacture � supprimer de la liste.
	 */
	public void removeFromLignesDeFacture(LigneDeFacture ligneDeFacture)
	{
		this.lignesDeFacture.remove(ligneDeFacture);
		ligneDeFacture.setFacture(null);
	}

	/**
	 * Vide la liste de la liste des ligneDeFacture.
	 */
	public void removeAllLignesDeFacture()
	{
		for (int i= lignesDeFacture.size() - 1; i >= 0; i--)
		{
			LigneDeFacture ligneDeFacture = (LigneDeFacture)lignesDeFacture.get(i);
			removeFromLignesDeFacture(ligneDeFacture);
		}
	}


	/**
	 * Renvoie l'objet parent de l'objet courant (composition).
	 * @return l'objet parent de l'objet courant.
	 */
	public Client getClient()
	{
		return client;
	}
	
	/**
	 * Positionne l'objet parent de l'objet courant (composition).
	 * @param client l'objet parent de l'objet courant.
	 */
	public void setClient(Client client)
	{
		this.client = client;
	}




	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + id + " " + montant + " " + dateEmission + " " + traitee;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}

	// [DEBUT:METHODES]
	// [FIN:METHODES]
}
