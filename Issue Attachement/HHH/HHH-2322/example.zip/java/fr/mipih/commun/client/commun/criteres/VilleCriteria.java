// [GENERATED]
// G�n�rateur������: 1.9.6.2
// Socle�����������: 1.0.6
// Mipih Technique�: 1.0.3
package fr.mipih.commun.client.commun.criteres;

// [DEBUT:IMPORTS]

// [FIN:IMPORTS]

import fr.mipih.foundation.core.criteria.AbstractCriteria;

import java.io.Serializable;


/**
 * Crit�res de recherche.
 */
public class VilleCriteria extends AbstractCriteria implements Serializable
{
	protected String nom;
	protected String codePostal;

	/**
	 * Retourne l'attribut nom.
	 * @return l'attribut nom.
	 */
	public String getNom()
	{
		return nom;
	}
	
	/**
	 * D�finit l'attribut nom.
	 * @param code L'attribut nom.
	 */
	public void setNom(String nom)
	{
		this.nom = nom;
	}

	/**
	 * Retourne l'attribut codePostal.
	 * @return l'attribut codePostal.
	 */
	public String getCodePostal()
	{
		return codePostal;
	}
	
	/**
	 * D�finit l'attribut codePostal.
	 * @param code L'attribut codePostal.
	 */
	public void setCodePostal(String codePostal)
	{
		this.codePostal = codePostal;
	}



	/**
	 * Repr�sentation textuelle de cette classe.
	 * @return
	 *		La repr�sentation textuelle de cette classe
	 */
	public String toString()
	{
		String toString = "" + "" + nom + " " + codePostal;
		// [DEBUT:METHODE�-�M�thode�toString]
		// [FIN:METHODE�-�M�thode�toString]
		return toString;
	}
}
