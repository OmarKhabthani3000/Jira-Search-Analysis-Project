import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class GenerateSchema
{
	public static final String HB_FILE_NAME = "config/hibernate.xml";
	private static final String OUTPUT_FILE = "schema.sql";

	public static void main(String[] args)
	{
		Configuration cfg = new Configuration();
		cfg.configure(ClassLoader.getSystemResource(HB_FILE_NAME));
		new SchemaExport(cfg).setDelimiter(";").setFormat(true).setOutputFile(OUTPUT_FILE).create(true, false);
	}
}
