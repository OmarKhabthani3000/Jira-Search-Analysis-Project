package com.blogspot.hwellmann.hhh7374;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;

import com.blogspot.hwellmann.hhh7374.MultilingualString;


public class MultilingualStringTest {
    
    @Rule
    public DatabaseRule databaseRule = new DatabaseRule();

    private EntityManager em = databaseRule.getEntityManager();
    
    @Before
    public void setUp() {
        em = databaseRule.getEntityManager();
        MultilingualString ms = new MultilingualString("de", "Hallo!");
        
        em.getTransaction().begin();
        em.persist(ms);
        em.getTransaction().commit();        
    }

    @Test
    public void queryWithoutKey()
    {
        em.getTransaction().begin();
        TypedQuery<String> query2 = em.createQuery("select m.text from MultilingualString s join s.map m where m.language = 'de'", String.class);
        List<String> names = query2.getResultList();
        assertEquals(1, names.size());
        em.getTransaction().commit();                
    }
    
    @Test
    public void queryWithLowerCaseKeyAndAlias()
    {
        em.getTransaction().begin();
        //query2 = em.createQuery("select m.text from MultilingualString s join s.map m where KEY(m) = 'de'", String.class);
        TypedQuery<String> query2 = em.createQuery("select m.text from MultilingualString s join s.map m where key(m) = 'de'", String.class);
        List<String> names = query2.getResultList();
        assertEquals(1, names.size());
        em.getTransaction().commit();                

    }
    
    @Test
    @Ignore
    public void queryWithLowerCaseKeyAndNoAlias()
    {
        em.getTransaction().begin();
        TypedQuery<String> query2 = em.createQuery("select m.text from MultilingualString s join s.map m where key(s.map) = 'de'", String.class);
        List<String> names = query2.getResultList();
        assertEquals(1, names.size());
        em.getTransaction().commit();                
    }
    
    @Test
    public void queryWithUpperCaseKeyAndAlias()
    {
        em.getTransaction().begin();
        TypedQuery<String> query2 = em.createQuery("select m.text from MultilingualString s join s.map m where KEY(m) = 'de'", String.class);
        List<String> names = query2.getResultList();
        assertEquals(1, names.size());
        em.getTransaction().commit();                

    }
    
    @Test
    @Ignore
    public void queryWithUpperCaseKeyAndNoAlias()
    {
        em.getTransaction().begin();
        TypedQuery<String> query2 = em.createQuery("select m.text from MultilingualString s join s.map m where KEY(s.map) = 'de'", String.class);
        List<String> names = query2.getResultList();
        assertEquals(1, names.size());
        em.getTransaction().commit();                
    }
    
}
