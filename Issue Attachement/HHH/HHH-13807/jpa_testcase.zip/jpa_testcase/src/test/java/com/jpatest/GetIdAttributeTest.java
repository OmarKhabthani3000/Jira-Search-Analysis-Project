/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package com.jpatest;

import com.jpatest.db.EntityA;
import com.jpatest.db.EntityB;
import java.util.Collections;
import java.util.Objects;
import java.util.Set;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.Type;
import org.junit.Assert;
import org.junit.Test;

public class GetIdAttributeTest {

    @Test
    public void getIdAttributeOfEntityB() {
        //given
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate_pu");
        EntityType<EntityB> entityTypeB = emf.getMetamodel().entity(EntityB.class);
        //when
        boolean hasSingleIdAttribute = entityTypeB.hasSingleIdAttribute();
        Type<?> idType = entityTypeB.getIdType();
        SingularAttribute<? super EntityB, EntityA> entityTypeBId = entityTypeB.getId(EntityA.class);
        Set<SingularAttribute<? super EntityB, ?>> idClassAttributes = null;
        try {
            idClassAttributes = entityTypeB.getIdClassAttributes();
        } catch (IllegalArgumentException ex) {
            idClassAttributes = Collections.emptySet();
        }
        //then
        boolean isSingle = hasSingleIdAttribute && Objects.nonNull(entityTypeB) && Objects.nonNull(entityTypeBId);
        boolean isComposite =  !idClassAttributes.isEmpty();
        boolean check = isSingle || isComposite;
        Assert.assertTrue(check);
    }
}
