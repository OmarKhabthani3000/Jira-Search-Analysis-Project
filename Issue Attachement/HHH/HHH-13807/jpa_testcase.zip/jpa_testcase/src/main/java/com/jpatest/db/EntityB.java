/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package com.jpatest.db;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class EntityB implements Serializable {

    @Id
    @ManyToOne
    private EntityA entityA;

    public EntityA getEntityA() {
        return entityA;
    }

    public void setEntityA(EntityA entityA) {
        this.entityA = entityA;
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EntityB entityB = (EntityB) o;
        return Objects.equals(getEntityA(), entityB.getEntityA());
    }

    @Override public int hashCode() {
        return Objects.hash(getEntityA());
    }
}
