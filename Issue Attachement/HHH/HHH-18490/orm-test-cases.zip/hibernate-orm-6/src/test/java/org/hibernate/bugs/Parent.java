package org.hibernate.bugs;

import static org.hibernate.bugs.CreationDate.VALUE;

import static jakarta.persistence.TemporalType.TIMESTAMP;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;

@Entity
public class Parent {
    @Id @GeneratedValue
    private Long id;

    @Embedded
    @AttributeOverride(name = VALUE, column = @Column(name = "some_string"))
    private SomeString someString;

    @Embedded
    @AttributeOverride(name = VALUE, column = @Column(name = "some_date"))
    @Temporal(TIMESTAMP)
    private CreationDate date;

    @Embedded
    @AttributeOverride(name = VALUE, column = @Column(name = "some_number"))
    private SomeNumber someNumber;

    public Parent() {
    }

    public Parent(final SomeString someString, final CreationDate date, final SomeNumber someNumber) {
        this.someString = someString;
        this.date = date;
        this.someNumber = someNumber;
    }
}
