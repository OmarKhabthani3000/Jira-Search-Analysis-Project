package org.hibernate.bugs;

import jakarta.persistence.Embeddable;

@Embeddable
public class SomeNumber extends AbstractValueObject<Long> {
  protected SomeNumber() {
  }

  public SomeNumber(final Long value) {
    super(value);
  }
}
