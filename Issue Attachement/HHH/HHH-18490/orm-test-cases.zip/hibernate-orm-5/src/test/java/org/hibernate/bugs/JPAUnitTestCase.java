package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Tuple;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.Date;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		final EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		entityManager.persist(new Parent(
				new SomeString("something"),
				new CreationDate(new Date()),
				new SomeNumber(42L)
		));

		entityManager.getTransaction().commit();

		entityManager.clear();

		final CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		final CriteriaQuery<Tuple> cq = cb.createTupleQuery();
		final Root<Parent> from = cq.from(Parent.class);

		final Path<Comparable> someStringPath = from.get(Parent_.someString).get(SomeString_.value);
		final Path<Comparable> someNumberPath = from.get(Parent_.someNumber).get(SomeNumber_.value);
		final Path<Comparable> timestampPath = from.get(Parent_.date).get(CreationDate_.value);
		final Expression<Timestamp> maxDate = cb.function("max", Timestamp.class, timestampPath);
		final Expression<Long> maxNumber = cb.function("max", Long.class, someNumberPath);
		cq.multiselect(someStringPath, maxDate, maxNumber);
		cq.groupBy(someStringPath);

		final TypedQuery<Tuple> query = entityManager.createQuery(cq);

		// This fails in Hibernate 6.5.2 and 6.6.0 because the mapping of the
		// generic "value" attribute is taken from SomeString and not from
		// CreationDate and will cause a ClassCastException. This worked fine
		// in Hibernate 6.4.10 and lower.
		final Tuple resultDate = query.getSingleResult();
		System.out.println(resultDate.get(0, String.class));
		System.out.println(resultDate.get(1, Timestamp.class));
		System.out.println(resultDate.get(2, Number.class).longValue());

		entityManager.close();
	}
}
