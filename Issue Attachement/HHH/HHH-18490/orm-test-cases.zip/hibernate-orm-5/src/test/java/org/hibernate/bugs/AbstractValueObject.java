package org.hibernate.bugs;

import static javax.persistence.AccessType.FIELD;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;


@MappedSuperclass
@Access(FIELD)
public abstract class AbstractValueObject<V extends Comparable<V>> implements Serializable,
    Comparable<AbstractValueObject<V>> {

  public static final String VALUE = "value";

  @Column(name = VALUE)
  private V value;

  protected AbstractValueObject() {
    super();
  }

  protected AbstractValueObject(final V value) {
    this.value = value;
  }

  @Override
  public int compareTo(final AbstractValueObject<V> object) {
    return value.compareTo(object.value);
  }
}
