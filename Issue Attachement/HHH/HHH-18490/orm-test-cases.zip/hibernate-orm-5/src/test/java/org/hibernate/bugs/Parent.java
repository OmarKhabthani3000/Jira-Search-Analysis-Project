package org.hibernate.bugs;

import static org.hibernate.bugs.CreationDate.VALUE;

import static javax.persistence.TemporalType.TIMESTAMP;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;

@Entity
public class Parent {
    @Id @GeneratedValue
    private Long id;

    @Embedded
    @AttributeOverride(name = VALUE, column = @Column(name = "some_string"))
    private SomeString someString;

    @Embedded
    @AttributeOverride(name = VALUE, column = @Column(name = "some_date"))
    @Temporal(TIMESTAMP)
    private CreationDate date;

    @Embedded
    @AttributeOverride(name = VALUE, column = @Column(name = "some_number"))
    private SomeNumber someNumber;

    public Parent() {
    }

    public Parent(final SomeString someString, final CreationDate date, final SomeNumber someNumber) {
        this.someString = someString;
        this.date = date;
        this.someNumber = someNumber;
    }
}
