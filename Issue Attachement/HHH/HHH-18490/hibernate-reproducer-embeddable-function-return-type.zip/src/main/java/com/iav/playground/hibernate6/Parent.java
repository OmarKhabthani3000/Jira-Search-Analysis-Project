package com.iav.playground.hibernate6;

import static com.iav.playground.hibernate6.CreationDate.VALUE;

import static jakarta.persistence.TemporalType.TIMESTAMP;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.validation.constraints.NotNull;

@Entity
public class Parent {
    @Id @GeneratedValue
    private Long id;

    @Embedded
    @AttributeOverride(name = VALUE, column = @Column(name = "some_string"))
    private SomeString someString;

    @Embedded
    @AttributeOverride(name = VALUE, column = @Column(name = "some_date"))
    @Temporal(TIMESTAMP)
    private CreationDate date;

    public Parent() {
    }

    public Parent(final SomeString someString, final CreationDate date) {
        this.someString = someString;
        this.date = date;
    }
}
