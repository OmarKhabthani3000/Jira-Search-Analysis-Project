package com.iav.playground.hibernate6;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.sql.Timestamp;
import java.util.Date;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Tuple;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Root;

@SpringBootApplication
public class HibernateApplication implements CommandLineRunner {

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private PlatformTransactionManager transactionManager;

    public static void main(String[] args) {
        SpringApplication.run(HibernateApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        final TransactionTemplate transactionTemplate = new TransactionTemplate(transactionManager);
        transactionTemplate.execute(status -> {
            entityManager.persist(new Parent(new SomeString("something"), new CreationDate(new Date())));
            return null;
        });
        entityManager.clear();

        final CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        final CriteriaQuery<Tuple> cq = cb.createTupleQuery();
        final Root<Parent> from = cq.from(Parent.class);

        final Path<Comparable> someStringPath = from.get(Parent_.someString).get(SomeString_.value);
        final Expression<Timestamp> maxDate = cb.function("max", Timestamp.class,
            from.get(Parent_.date).get(CreationDate_.value));
        cq.multiselect(someStringPath, maxDate);
        cq.groupBy(someStringPath);

        final TypedQuery<Tuple> query = entityManager.createQuery(cq);

        // This fails in Hibernate 6.5.2 and 6.6.0 because the mapping of the
        // generic "value" attribute is taken from SomeString and not from
        // CreationDate and will cause a ClassCastException. This worked fine
        // in Hibernate 6.4.10 and lower.
        final Tuple resultDate = query.getSingleResult();
        System.out.println(resultDate.get(0, String.class));
        System.out.println(resultDate.get(1, Timestamp.class));
    }
}
