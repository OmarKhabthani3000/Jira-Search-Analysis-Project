package com.iav.playground.hibernate6;

import jakarta.persistence.Embeddable;

@Embeddable
public class SomeString extends AbstractValueObject<String> {
  protected SomeString() {
  }

  public SomeString(final String value) {
    super(value);
  }
}
