package org.ginger.hibermapstest.model;

public interface Product {
	int getEntid();
	
	String getInventoryCode();
}
