package org.ginger.hibermapstest.model;

public interface Book extends Product {
	String getIsbn();
	
	Library getLibrary();
	
	void setLibrary(Library arg);
}
