package org.ginger.hibermapstest;

import javax.persistence.InheritanceType;

import org.ginger.hibermapstest.model.Book;
import org.ginger.hibermapstest.model.Library;

public class EntityFactory {
	private final InheritanceType inheritanceType;
	
	public EntityFactory(InheritanceType inheritanceType) {
		this.inheritanceType = inheritanceType;
	}
	
	public String bookPredicate() {
		switch (inheritanceType) {
		case JOINED:
			return "FROM org.ginger.hibermapstest.model.joined.BookImpl";
		case SINGLE_TABLE:
			return "FROM org.ginger.hibermapstest.model.single.BookImpl";
		case TABLE_PER_CLASS:
			return "FROM org.ginger.hibermapstest.model.perclass.BookImpl";
		default:
			return null;
		}
	}
	
	public String libraryPredicate() {
		switch (inheritanceType) {
		case JOINED:
			return "FROM org.ginger.hibermapstest.model.joined.LibraryImpl";
		case SINGLE_TABLE:
			return "FROM org.ginger.hibermapstest.model.single.LibraryImpl";
		case TABLE_PER_CLASS:
			return "FROM org.ginger.hibermapstest.model.perclass.LibraryImpl";
		default:
			return null;
		}
	}

	public Book newBook(String inventoryCode, String isbn, Library inventory) {
		switch (inheritanceType) {
		case JOINED:
			return new org.ginger.hibermapstest.model.joined.BookImpl(inventoryCode, isbn, inventory);
		case SINGLE_TABLE:
			return new org.ginger.hibermapstest.model.single.BookImpl(inventoryCode, isbn, inventory);
		case TABLE_PER_CLASS:
			return new org.ginger.hibermapstest.model.perclass.BookImpl(inventoryCode, isbn, inventory);
		default:
			return null;
		}
	}

	public Library newLibrary() {
		switch (inheritanceType) {
		case JOINED:
			return new org.ginger.hibermapstest.model.joined.LibraryImpl();
		case SINGLE_TABLE:
			return new org.ginger.hibermapstest.model.single.LibraryImpl();
		case TABLE_PER_CLASS:
			return new org.ginger.hibermapstest.model.perclass.LibraryImpl();
		default:
			return null;
		}
	}
}
