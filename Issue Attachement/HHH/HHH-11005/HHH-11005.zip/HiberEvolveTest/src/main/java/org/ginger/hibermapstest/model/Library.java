package org.ginger.hibermapstest.model;

import java.util.Map;

public interface Library {
	int getEntid();
	
	Map<String,Book> getBooksOnInventory();
}
