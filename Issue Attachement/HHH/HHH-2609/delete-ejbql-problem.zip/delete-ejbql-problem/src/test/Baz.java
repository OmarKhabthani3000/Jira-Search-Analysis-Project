package test;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Baz {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Basic
	private long fooId;	

	public long getFooId() {
		return fooId;
	}

	public void setFooId(long fooId) {
		this.fooId = fooId;
	}

	public long getId() {
		return id;
	}
}
