package test;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import junit.framework.TestCase;

public class QueryTest extends TestCase {

    EntityManager em;	
    
    public void setUp() {
    	URL resource = Thread.currentThread().getContextClassLoader().getResource("META-INF/persistence.xml");
    	System.out.println(resource);
        Map<String,String> properties = new HashMap<String,String>();
        properties.put("hibernate.hbm2ddl.auto", "create-drop");
        properties.put("hibernate.show_sql", "true");
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("default", properties);
        em = emf.createEntityManager();
    }
	
    //String str = "DELETE Foo WHERE fooId NOT IN (SELECT fooId FROM Bar) AND fooId NOT IN (SELECT fooId FROM Baz)";
    String str = "DELETE Foo f WHERE f.fooId NOT IN (SELECT bar.fooId FROM Bar bar) AND f.fooId NOT IN (SELECT baz.fooId FROM Baz baz)";
    //String str = "DELETE Foo f WHERE f.fooId NOT IN (SELECT bar.fooId FROM Bar bar)";
    //String s = "DELETE FROM test.Foo f";
    
	public void testQuery() {
		EntityTransaction tx = em.getTransaction();
		boolean success = false;
		try {
			//em.
			tx.begin();
			Query q = em.createQuery(str);
			q.executeUpdate();
			success = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (success) {
				tx.commit();
			} else {
				tx.rollback();
			}
		}
	}
}
