package org.hibernate.test.annotations;

import java.util.Set;

import org.hibernate.EmptyInterceptor;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class RedundantJoinInGeneratedSQLTest extends TestCase {

		public RedundantJoinInGeneratedSQLTest(String x) {
			super( x );
		}

		public void testExpectedNumberOfJoins() throws Exception {
		
			Session s = openSession(new JoinCounter(2));
			Transaction tx = s.beginTransaction();			
			
			Client c1 = new Client();
			c1.setFirstName("Firstname1");
			c1.setName("Name1");
			c1.setCode("1234");
			c1.setStreet("Street1");
			c1.setCity("City1");
			
			Client c2 = new Client();
			c2.setFirstName("Firstname2");
			c2.setName("Name2");
			c2.setCode("4321");
			c2.setStreet("Street2");
			c2.setCity("City2");
						
			Account a1 = new Account();
			a1.setNumber("1000");
			a1.setBalance(5000);
			a1.addHolder(c1);
			a1.addHolder(c2);
			 
			s.persist(a1);
			s.persist(c1);
			s.persist(c2);
			
			s.flush();
			s.clear();
			
			a1 = (Account) s.load(Account.class, a1.getId());
			Set<Client> clients = a1.getHolders();	
			assertEquals(2, clients.size());
			
			tx.rollback();
			s.close();
			
		}

		@Override
		protected Class<?>[] getAnnotatedClasses() {
			
			return new Class[]{
					Client.class,
					Account.class,
			};
					
		}
	
	
	
}


/**
 * Verifies that generated 'select' statement has desired number of joins 
 * @author Sharath Reddy
 *
 */
class JoinCounter extends EmptyInterceptor {
	 
	private static final long serialVersionUID = -3689681272273261051L;
	
	private int expectedNumberOfJoins = 0;
			
	public JoinCounter(int val) {
		super();
		this.expectedNumberOfJoins = val;
	}

	public String onPrepareStatement(String sql) {
				
		int numberOfJoins = 0;
		if (sql.startsWith("select")) {
			 numberOfJoins = count(sql, "join");
			 TestCase.assertEquals(expectedNumberOfJoins, numberOfJoins);
		}
						
		return sql;
	 }
	
	 /**
	   * Count the number of instances of substring within a string.
	   *
	   * @param string     String to look for substring in.
	   * @param substring  Sub-string to look for.
	   * @return           Count of substrings in string.
	   */
	  private int count(final String string, final String substring)
	  {
	     int count = 0;
	     int idx = 0;

	     while ((idx = string.indexOf(substring, idx)) != -1)
	     {
	        idx++;
	        count++;
	     }

	     return count;
	  }
	
}


