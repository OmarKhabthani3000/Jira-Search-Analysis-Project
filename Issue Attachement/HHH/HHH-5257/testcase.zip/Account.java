package org.hibernate.test.annotations;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "ACCOUNT")
public class Account implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String number;
	
	private double balance;

	@OneToMany (fetch = FetchType.EAGER, mappedBy="account")
	private Set<Client> holders;

	public Account() {
	}

	public int getId() {
		return this.id;
	}

	@SuppressWarnings("unused")
	private void setId(int id) {
		this.id = id;
	}

	public String getNumber() {
		return this.number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Set<Client> getHolders() {
		if (holders == null)
			holders = new HashSet<Client>();
		return holders;
	}


	public void addHolder(Client c)
	{
		if(holders == null)
		{
			holders = new HashSet<Client>();
		}
		holders.add(c);
		c.setAccount(this);
	}

}