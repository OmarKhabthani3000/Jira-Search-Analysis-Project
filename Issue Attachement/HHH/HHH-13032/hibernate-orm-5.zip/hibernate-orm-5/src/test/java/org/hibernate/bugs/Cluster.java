package org.hibernate.bugs;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.OptimisticLockType;
import org.hibernate.annotations.OptimisticLocking;

@Table(name = "cluster", schema = "schema1")
@SecondaryTable(name = "Cluster", schema = "schema2", pkJoinColumns = @PrimaryKeyJoinColumn(name = "clusterId", referencedColumnName = "objid"))
@org.hibernate.annotations.Table(appliesTo = "Cluster", optional = false)
@Entity
@OptimisticLocking(type = OptimisticLockType.DIRTY)
@DynamicUpdate
public class Cluster implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3965099001305947412L;

	@Id
	@Column(name = "objid")
	private Long id;

	@Basic
	private String uuid;
	
	@Basic
	private String resourceKey;
	
	@Basic
	private String name;
	
	@Column(name = "lastSync", table = "Cluster")
	private Long lastSync;
	
	@Column(name = "healthStatus", table = "Cluster")
	private Integer healthStatus;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getResourceKey() {
		return resourceKey;
	}

	public void setResourceKey(String resourceKey) {
		this.resourceKey = resourceKey;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public Long getLastSync() {
		return lastSync;
	}

	public void setLastSync(Long lastSync) {
		this.lastSync = lastSync;
	}

	public Integer getHealthStatus() {
		return healthStatus;
	}

	public void setHealthStatus(Integer healthStatus) {
		this.healthStatus = healthStatus;
	}

}
