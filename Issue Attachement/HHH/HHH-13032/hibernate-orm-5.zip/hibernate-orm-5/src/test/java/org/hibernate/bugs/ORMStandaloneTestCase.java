package org.hibernate.bugs;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Environment;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a standalone test case for
 * Hibernate ORM. Although this is perfectly acceptable as a reproducer, usage
 * of ORMUnitTestCase is preferred!
 */
public class ORMStandaloneTestCase {

	private SessionFactory sf;
	
	@Before
	public void setup() {
		StandardServiceRegistryBuilder registryBuilder = new StandardServiceRegistryBuilder();

        
        // Programatically configuring hibernate settings
        Map<String, String> settings = new HashMap<>();
        settings.put(Environment.DRIVER, "org.mariadb.jdbc.Driver");
        settings.put(Environment.URL, "jdbc:mysql://localhost:3306/schema1");
        settings.put(Environment.USER, "root");
        settings.put(Environment.DIALECT, "org.hibernate.dialect.MySQLDialect");
        settings.put(Environment.DEFAULT_SCHEMA, "schema1");
        // Apply settings
        registryBuilder.applySettings(settings);
        registryBuilder.applySetting("packagesToScan", "org.hibernate.bugs");
        // Create MetadataSources
        MetadataSources sources = new MetadataSources(registryBuilder.build());
        Metadata metadata = sources.getMetadataBuilder().build();
        sf =  metadata.getSessionFactoryBuilder().build();
        
	}

	
	


	// Add your tests, using standard JUnit.

	@SuppressWarnings("unchecked")
	@Test
	public void fetchClusterTest() throws Exception {

		Transaction transaction = null;
		try (Session session = sf.openSession()) {
			transaction = session.beginTransaction();

			System.out.println("*********************************************");
			System.out.println(" # # # # # # # # # # # # # # # # # # # # # # ");
			System.out.println("*********************************************");
			
			List<Cluster> clusters = session.createCriteria(Cluster.class).list();
			Iterator<Cluster> itr = clusters.iterator();
			while (itr.hasNext()) {
				Cluster cluster = itr.next();
				System.out.println(cluster.getName());
				System.out.println(cluster.getResourceKey());
				System.out.println(cluster.getUuid());
				System.out.println(cluster.getId());
			}

			transaction.commit();
			System.out.println("*********************************************");
			System.out.println(" # # # # # # # # # # # # # # # # # # # # # # ");
			System.out.println("*********************************************");
			

		} catch (Exception e) {
			e.printStackTrace();
			if (transaction != null) {
				transaction.rollback();
			}
		} finally {
			if(sf != null && !sf.isClosed()) {
				sf.close();
			}
			
		}

	}
	
	
	
//	@Test
//	public void hhh12Test() throws Exception {
//		Session session = sf.openSession();
//		CriteriaBuilder builder = session.getCriteriaBuilder();
//		CriteriaQuery<Cluster> query = builder.createQuery(Cluster.class);
//		Root<Cluster> root = query.from(Cluster.class);
//		query.select(root);
//		Query q = session.createQuery(query);
//		@SuppressWarnings("unchecked")
//		List<Cluster> clusters = q.getResultList();
//		for (Cluster cluster : clusters) {
//			System.out.println(cluster.getName());
//		}	
//	}
	
	
	
	
//	@Before
//	public void setup() {
//		System.out.println("Starting test setup");
//		try {
//			StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
//					// Add in any settings that are specific to your test. See
//					// resources/hibernate.properties for the defaults.
//					.applySetting("hibernate.show_sql", "true")
//					.applySetting("hibernate.format_sql", "true")
//					.applySetting("hibernate.default_schema", "schema1")
//					.applySetting("packagesToScan","org.hibernate.bugs");
//					//.applySetting("hibernate.hbm2ddl.auto", "update");
//
//			Metadata metadata = new MetadataSources(srb.build()).buildMetadata();
//					// Add your entities here.
//					//.addAnnotatedClass(Cluster.class).buildMetadata();
//
//			sf = metadata.buildSessionFactory();
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.out.println("ORMStandaloneTestCase setup done properly");
//	}
}
