package org.test.hibmetadatasourcestest.entities;

public abstract class TestA {

    protected long id;

    protected String name;

    public void setId(long id) {
        this.id = id;
    }
    
    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
