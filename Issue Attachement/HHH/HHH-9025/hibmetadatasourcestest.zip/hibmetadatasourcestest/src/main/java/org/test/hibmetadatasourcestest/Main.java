package org.test.hibmetadatasourcestest;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.dialect.PostgreSQL9Dialect;
import org.hibernate.metamodel.MetadataSources;
import org.test.hibmetadatasourcestest.entities.TestA;
import org.test.hibmetadatasourcestest.entities.TestB;
import org.test.hibmetadatasourcestest.entities.TestC;


public class Main {

    public static void main( String... args ) {

        Map<String, String> props = new HashMap<String, String>();
        props.put(AvailableSettings.DIALECT, PostgreSQL9Dialect.class.getName());

        StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder();
        builder.applySettings(props);
        StandardServiceRegistry standardServiceRegistry = builder.build();

        MetadataSources metaSource = new MetadataSources(standardServiceRegistry);

        metaSource.addClass(TestA.class);
        metaSource.addClass(TestB.class);
        metaSource.addClass(TestC.class);
        
        metaSource.buildMetadata();
    }
}
