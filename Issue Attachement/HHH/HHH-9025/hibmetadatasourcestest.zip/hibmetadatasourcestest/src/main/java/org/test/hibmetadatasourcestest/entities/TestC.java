package org.test.hibmetadatasourcestest.entities;

public class TestC extends TestB {

    protected String address;
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getAddress() {
        return address;
    }
}
