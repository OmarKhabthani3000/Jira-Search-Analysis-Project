package org.test.hibmetadatasourcestest.entities;

public abstract class TestB {

    protected int age;
    
    public void setAge(int age) {
        this.age = age;
    }
    
    public int getAge() {
        return age;
    }
}
