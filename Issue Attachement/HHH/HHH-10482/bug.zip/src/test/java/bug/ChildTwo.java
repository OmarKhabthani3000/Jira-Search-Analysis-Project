package bug;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 *
 **/
@Entity
@DiscriminatorValue("2")
public class ChildTwo extends AbstractParent {

}
