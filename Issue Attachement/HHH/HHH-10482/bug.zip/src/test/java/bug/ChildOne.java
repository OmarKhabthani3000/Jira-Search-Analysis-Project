package bug;

import javax.persistence.*;

/**
 *
 **/
@Entity
@DiscriminatorValue("1")
public class ChildOne extends AbstractParent {

}
