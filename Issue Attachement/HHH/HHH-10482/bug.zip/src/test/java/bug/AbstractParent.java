package bug;

import javax.persistence.*;

/**
 *
 **/
@Entity
@DiscriminatorColumn(name = "DISCRIMINATOR", discriminatorType = DiscriminatorType.INTEGER)
@Table(name = "SINGLE_TABLE")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public abstract class AbstractParent extends AbstractEntity<Integer> {

    @Id
    @Column(name = "CHILD_ID")
    @Override
    public Integer getId() {
        return super.getId();
    }

}
