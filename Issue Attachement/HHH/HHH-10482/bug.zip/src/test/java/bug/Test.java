package bug;

import org.junit.Assert;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Table;

/**
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath*:test.xml")
public class Test {

    private static final String CREATE =
            "CREATE TABLE single_table (surrogate_id NUMBER, discriminator NUMBER, child_id NUMBER)";
    private static final String INSERT =
            "INSERT INTO single_table (surrogate_id, discriminator, child_id) VALUES (%d, %d, %d)";


    @PersistenceContext
    private EntityManager entityManager;


    @Before
    public void before() {
        entityManager.createNativeQuery(CREATE).executeUpdate();
        entityManager.createNativeQuery(String.format(INSERT, 1, 1, 1)).executeUpdate();
        entityManager.createNativeQuery(String.format(INSERT, 2, 2, 1)).executeUpdate();
    }


    @org.junit.Test
    @Transactional
    public void test() {
        entityManager.createQuery("FROM ChildOne").getResultList();
        entityManager.createQuery("FROM ChildTwo").getResultList();
    }
}
