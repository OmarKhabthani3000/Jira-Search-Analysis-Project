package bug;

import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import java.io.Serializable;

/**
 *
 */
@MappedSuperclass
public abstract class AbstractEntity<ID extends Serializable> {

    private static final long serialVersionUID = -6829139895354409353L;


    private ID id;

    @Transient
    public ID getId() {
        return id;
    }

    protected void setId(ID id) {
        this.id = id;
    }

    @Transient
    public boolean isNew() {
        return null == getId();
    }

}
