# Reproducer Hibernate 6.1.4.Final Named Parameter Issue

## What is contained?

There are two reproducers in this project.

1. A vanilla reproducer that uses a limited set of dependencies (no CDI)
2. A reproducer that uses Helidon MP 3.0.2

### Vanilla Reproducer

This reproducer uses a limited set of dependencies:

- H2 database 2.1.212
- Hibernate 6.1.4.Final

Additionally, it uses a simple database init script.
This creates some database tables, and seeds some data.


### Helidon MP 3.0.2 Reproducer

This reproducer is based on [Helidon MP Project Starter](https://helidon.io/starter/3.0.2).
It uses the following components:

- Helidon MP 3.0.2
- H2 database 2.1.212
- Hibernate 6.1.4.Final

Additionally, it uses a simple database init script.
This creates some database tables, and seeds some data.

### What are we testing?

The `HibernateNamedNativeQuery` CDI bean has a `@PostConstruct` method that creates a named native query and registers that with the EMF.
The named native query, uses a named parameter (`:name`).
The goal of the test is to show the behavior of `setParameter`, named versus positional.
For this we expose two methods:

- executeNamed
- executePositional

These are tested in the respective `HibernateNamedNativeQueryTest`.

A similar approach is there for `HibernateNamedNativeQueryVanilla`.

**NOTE**

Even though we create a single named native query, with named parameters, it is the _executePositional_ that is succeeding.
The _executeNamed_ is failing with this stack trace:

```
java.lang.NullPointerException
	at java.base/java.util.Objects.requireNonNull(Objects.java:233)
	at java.base/java.lang.String.join(String.java:3331)
	at org.hibernate.query.internal.ParameterMetadataImpl.getQueryParameter(ParameterMetadataImpl.java:261)
	at org.hibernate.query.spi.AbstractCommonQueryContract.setParameter(AbstractCommonQueryContract.java:844)
	at org.hibernate.query.spi.AbstractSelectionQuery.setParameter(AbstractSelectionQuery.java:708)
	at org.hibernate.query.spi.AbstractQuery.setParameter(AbstractQuery.java:369)
	at org.hibernate.query.sql.internal.NativeQueryImpl.setParameter(NativeQueryImpl.java:1217)
	at org.hibernate.query.sql.internal.NativeQueryImpl.setParameter(NativeQueryImpl.java:108)
	at io.helidon.integrations.cdi.jpa.DelegatingQuery.setParameter(DelegatingQuery.java:193)
	at com.example.myproject.HibernateNamedNativeQuery.executeNamed(HibernateNamedNativeQuery.java:34)
	at com.example.myproject.HibernateNamedNativeQuery$Proxy$_$$_WeldClientProxy.executeNamed(Unknown Source)
	at com.example.myproject.HibernateNamedNativeQueryTest.namedNativeQueryWithNamedParameters(HibernateNamedNativeQueryTest.java:26)
	at java.base/jdk.internal.reflect.DirectMethodHandleAccessor.invoke(DirectMethodHandleAccessor.java:104)
	at java.base/java.lang.reflect.Method.invoke(Method.java:578)
	at org.jboss.weld.bean.proxy.AbstractBeanInstance.invoke(AbstractBeanInstance.java:38)
	at org.jboss.weld.bean.proxy.ProxyMethodHandler.invoke(ProxyMethodHandler.java:106)
	at com.example.myproject.HibernateNamedNativeQueryTest$Proxy$_$$_WeldClientProxy.namedNativeQueryWithNamedParameters(Unknown Source)
	at java.base/jdk.internal.reflect.DirectMethodHandleAccessor.invoke(DirectMethodHandleAccessor.java:104)
	at java.base/java.lang.reflect.Method.invoke(Method.java:578)
	at org.junit.platform.commons.util.ReflectionUtils.invokeMethod(ReflectionUtils.java:688)
```

### Running the tests

- Invoke `mvn test` from the command line, or
- Run the `HibernateNamedNativeQueryTest` or `HibernateNamedNativeQueryVanillaTest` from your favorite IDE (after importing the project)
