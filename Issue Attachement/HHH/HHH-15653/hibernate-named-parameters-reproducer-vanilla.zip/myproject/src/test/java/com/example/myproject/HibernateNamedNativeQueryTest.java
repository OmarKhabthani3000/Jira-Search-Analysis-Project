package com.example.myproject;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.helidon.microprofile.tests.junit5.HelidonTest;
import jakarta.inject.Inject;

@HelidonTest
class HibernateNamedNativeQueryTest {

    private final HibernateNamedNativeQuery hibernateNamedNativeQuery;

    @Inject
    HibernateNamedNativeQueryTest(HibernateNamedNativeQuery hibernateNamedNativeQuery) {
        this.hibernateNamedNativeQuery = hibernateNamedNativeQuery;
    }

    @Test
    @DisplayName("should be able to perform named native query with named parameters")
    void namedNativeQueryWithNamedParameters() {

        assertThat(hibernateNamedNativeQuery.executeNamed("Bulbasaur"), equalTo(1));
    }

    @Test
    @DisplayName("weird case that positional parameter mapping works")
    void namedNativeQueryWithPositionalParameters() {

        assertThat(hibernateNamedNativeQuery.executePositional("Bulbasaur"), equalTo(1));
    }
}