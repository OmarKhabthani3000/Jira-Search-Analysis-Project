package com.example.myproject;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class HibernateNamedNativeQueryVanillaTest {

    private static final HibernateNamedNativeQueryVanilla vanilla = new HibernateNamedNativeQueryVanilla();

    @BeforeAll
    static void initialize() {
        vanilla.initialize();
    }

    @AfterAll
    static void close() {
        vanilla.close();
    }

    @Test
    @DisplayName("should be able to perform named native query with named parameters")
    void namedNativeQueryWithNamedParameters() {

        assertThat(vanilla.executeNamed("Bulbasaur"), equalTo(1));
    }

    @Test
    @DisplayName("weird case that positional parameter mapping works")
    void namedNativeQueryWithPositionalParameters() {

        assertThat(vanilla.executePositional("Bulbasaur"), equalTo(1));
    }
}