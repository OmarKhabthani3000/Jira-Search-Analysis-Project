package com.example.myproject;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class HibernateNamedNativeQueryVanilla implements AutoCloseable {

    private static final String QUERY = "select %s from %s where name = :name";
    private static final String QUERY_NAME = "MY_QUERY";

    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu2");

    private final EntityManager em;

    public HibernateNamedNativeQueryVanilla() {
        this.em = emf.createEntityManager();
    }

    void initialize() {
        var actualQuery = QUERY.formatted("id", "pokemon");
        var query = em.createNativeQuery(actualQuery);
        emf.addNamedQuery(QUERY_NAME, query);
    }

    public Integer executeNamed(String name) {

        var matchingRecords = em
                .createNamedQuery(QUERY_NAME)
                .setParameter("name", name)
                .getResultList();

        return (Integer)matchingRecords.get(0);
    }

    public Integer executePositional(String name) {

        var matchingRecords = em
                .createNamedQuery(QUERY_NAME)
                .setParameter(1, name)
                .getResultList();

        return (Integer)matchingRecords.get(0);
    }

    @Override
    public void close() {
        em.close();
    }
}
