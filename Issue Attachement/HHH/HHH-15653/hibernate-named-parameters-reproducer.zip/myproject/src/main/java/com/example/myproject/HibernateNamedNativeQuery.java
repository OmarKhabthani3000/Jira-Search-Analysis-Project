package com.example.myproject;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@ApplicationScoped
public class HibernateNamedNativeQuery {

    private static final String QUERY = "select %s from %s where name = :name";
    private static final String QUERY_NAME = "MY_QUERY";

    @PersistenceContext(unitName = "pu1")
    private EntityManager entityManager;

    @PostConstruct
    void initialize() {

        var actualQuery = QUERY.formatted("id", "pokemon");
        Query query = entityManager.createNativeQuery(actualQuery);
        entityManager.getEntityManagerFactory().addNamedQuery(QUERY_NAME, query);
    }

    public Integer executeNamed(String name) {

        var matchingRecords = entityManager
                .createNamedQuery(QUERY_NAME)
                .setParameter("name", name)
                .getResultList();

        return (Integer)matchingRecords.get(0);
    }

    public Integer executePositional(String name) {

        var matchingRecords = entityManager
                .createNamedQuery(QUERY_NAME)
                .setParameter(1, name)
                .getResultList();

        return (Integer)matchingRecords.get(0);
    }
}
