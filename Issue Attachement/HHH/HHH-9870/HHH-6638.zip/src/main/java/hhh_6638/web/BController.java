package hhh_6638.web;
import hhh_6638.B;
import org.springframework.roo.addon.web.mvc.controller.scaffold.RooWebScaffold;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/bs")
@Controller
@RooWebScaffold(path = "bs", formBackingObject = B.class)
public class BController {
}
