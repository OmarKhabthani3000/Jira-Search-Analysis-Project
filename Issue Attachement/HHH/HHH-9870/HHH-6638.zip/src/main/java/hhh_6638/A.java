package hhh_6638;
import org.springframework.roo.addon.dbre.RooDbManaged;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.jpa.activerecord.RooJpaActiveRecord;
import org.springframework.roo.addon.tostring.RooToString;

@RooJavaBean
@RooJpaActiveRecord(identifierType = APK.class, versionField = "", table = "a")
@RooDbManaged(automaticallyDelete = true)
@RooToString(excludeFields = { "b" })
public class A {
}
