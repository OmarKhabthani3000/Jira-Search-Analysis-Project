package hhh_6638;
import org.springframework.roo.addon.jpa.identifier.RooIdentifier;

@RooIdentifier(dbManaged = true)
public final class APK {
}
