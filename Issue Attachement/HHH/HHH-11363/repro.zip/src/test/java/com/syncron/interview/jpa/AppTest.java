package com.syncron.interview.jpa;

import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void setUp() {
		entityManagerFactory = Persistence.createEntityManagerFactory("com.syncron.interview.jpa");
	}

	@After
	public void tearDown() {
		entityManagerFactory.close();
	}

	@Test
	public void test() throws Exception {
		EntityManager em = entityManagerFactory.createEntityManager();
		try {
			Query query = em.createQuery(""
					+ "select b.title as bookTitle"
					+ "  , b.author.workAddress.text as authorAddress "
					+ "from Book b "
					+ "  inner join b.author a "
					+ "  inner join b.shelve s "
					+ "");

			List<?> resultList = query.getResultList();

			Assert.assertEquals("resultList", Collections.emptyList(), resultList);

		} finally {
			em.close();
		}
	}
}
