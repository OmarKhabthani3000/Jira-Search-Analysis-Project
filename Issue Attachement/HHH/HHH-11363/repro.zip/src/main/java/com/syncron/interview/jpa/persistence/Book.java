package com.syncron.interview.jpa.persistence;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Book {

	private Long id;
	private String title;

	private Person author;
	private Shelve shelve;

	@Id
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String name) {
		this.title = name;
	}

	@ManyToOne
	public Person getAuthor() {
		return author;
	}

	public void setAuthor(Person warehouse) {
		this.author = warehouse;
	}

	@ManyToOne
	public Shelve getShelve() {
		return shelve;
	}

	public void setShelve(Shelve masterItem) {
		this.shelve = masterItem;
	}
}
