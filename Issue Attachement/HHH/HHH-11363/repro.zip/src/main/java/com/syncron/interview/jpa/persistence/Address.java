package com.syncron.interview.jpa.persistence;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Address {
	private Long id;

	private String text;

	@Id
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String name) {
		this.text = name;
	}

}
