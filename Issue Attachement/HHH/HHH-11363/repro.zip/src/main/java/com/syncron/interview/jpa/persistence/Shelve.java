package com.syncron.interview.jpa.persistence;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Shelve {
	private Long id;

	@Id
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
