package com.syncron.interview.jpa.persistence;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Person {
	private Long id;
	private String name;

	private Address workAddress;

	@Id
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@ManyToOne
	public Address getWorkAddress() {
		return workAddress;
	}

	public void setWorkAddress(Address defaultConfig) {
		this.workAddress = defaultConfig;
	}
}
