package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author ziems
 */
@Entity
@Table(name = "parent")
public class Parent {
    @Id
    @Column(name = "id", nullable = false)
    private long id;
}
