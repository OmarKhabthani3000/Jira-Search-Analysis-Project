/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

/**
 * This unit test tests, if the schema migrator recognizes foreign key definitions
 * by comparing constraint columns case-insensitivly.
 * H2 by default uses upper-case column names. Thus, the schema migrator should
 * use case-insensitive comparison, in case entity column definitions use
 * lower-case column names.
 */
public class ForeignKeyMigratorUnitTestCase extends BaseCoreFunctionalTestCase {

    @Override
    protected Class[] getAnnotatedClasses() {
        return new Class[] {Parent.class, Example.class};
    }

    @Override
    protected void configure(Configuration configuration) {
        super.configure(configuration);

        configuration.setProperty(AvailableSettings.HBM2DDL_AUTO, "update");
        configuration.setProperty(AvailableSettings.HBM2DDL_HALT_ON_ERROR, Boolean.TRUE.toString());
    }

    @Override
    protected void prepareBasicRegistryBuilder(StandardServiceRegistryBuilder serviceRegistryBuilder) {
        super.prepareBasicRegistryBuilder(serviceRegistryBuilder);

        // set the following configuration property directly on the builder,
        // because otherwise it will not be recognized (HHH-13230)
        // serviceRegistryBuilder.applySetting(AvailableSettings.HBM2DDL_HALT_ON_ERROR, Boolean.TRUE);
    }

    @Test
    public void testExample() throws Exception {
        final Session s = openSession();
        final Transaction tx = s.beginTransaction();

        // drop foreign key from example table and recreate it using a different name
        s.createSQLQuery("alter table example drop constraint FK_exampleParent")
                .executeUpdate();
        s.createSQLQuery("alter table example"
                    + " add constraint FK_exampleParentRenamed"
                        + " foreign key (parent_id) references parent")
                .executeUpdate();

        // create another table using the orginal name of the foreign key to
        // force an error in case the migrator should try to create the foreign
        // key on example table using the original name
        // Note: required, because H2 allows two identical foreign keys
        s.createSQLQuery("create table example2(id bigint not null, parent_id bigint, primary key(id))")
                .executeUpdate();
        s.createSQLQuery("alter table example2 add constraint FK_exampleParent"
                    + " foreign key (parent_id) references parent")
                .executeUpdate();

        tx.commit();
        s.close();

        // run schema migration which should detect that the foreign key of
        // example table exists (but has a different name)
        buildSessionFactory(null);
    }

    @Override
    public void onFailure() {
    }
}
