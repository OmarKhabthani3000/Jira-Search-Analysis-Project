package org.hibernate.bugs;

import org.hibernate.EntityNameResolver;

import java.util.Map;

public class HibernateEntityNameResolver implements EntityNameResolver {
    @Override
    public String resolveEntityName(Object entity) {
        if(entity instanceof Map)
            return "artist";
        return null;
    }

    public boolean equals(Object obj) {
        return getClass().equals( obj.getClass() );
    }

    public int hashCode() {
        return getClass().hashCode();
    }
}
