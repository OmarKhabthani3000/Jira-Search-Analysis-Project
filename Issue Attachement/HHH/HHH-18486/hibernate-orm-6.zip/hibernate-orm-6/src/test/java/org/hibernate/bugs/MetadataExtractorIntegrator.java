package org.hibernate.bugs;

import org.hibernate.boot.Metadata;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.integrator.spi.Integrator;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.spi.SessionFactoryServiceRegistry;

public class MetadataExtractorIntegrator implements Integrator {
    private Metadata metadata;
    private ServiceRegistry serviceRegistry;

    public MetadataExtractorIntegrator() {
        this.metadata = null;
        this.serviceRegistry = null;
    }

    public Metadata getMetadata() {
        return this.metadata;
    }

    public ServiceRegistry getServiceRegistry() {
        return this.serviceRegistry;
    }

    @Override
    public void integrate(
            Metadata metadata,
            SessionFactoryImplementor sessionFactory,
            SessionFactoryServiceRegistry serviceRegistry) {
        this.metadata = metadata;
        this.serviceRegistry = serviceRegistry;
    }

    @Override
    public void disintegrate(
            SessionFactoryImplementor sessionFactory,
            SessionFactoryServiceRegistry serviceRegistry) {
        this.metadata = null;
        this.serviceRegistry = null;

    }
}
