package jpa.test;

import java.util.Properties;
import javax.persistence.EntityManager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import jpa.test.entities.Document;
import org.junit.Test;

public class BugTest {
    
    @Test
    public void testRun() {
        /*
         * NOTE: To use JPA schemageneration, use true. Use false for hbm2ddl
         */
        test(true);
    }
    
    private void test(boolean jpaSchemagen) {
        Properties properties;
        EntityManagerFactory emf;
        EntityManager em;
        
        // Cleanup
        properties = getBaseProperties();
        if (jpaSchemagen) {
            properties.put("javax.persistence.schema-generation.database.action", "drop");
        } else {
            properties.put("hibernate.hbm2ddl.auto", "drop");
        }
        emf = Persistence.createEntityManagerFactory("TestPU", properties);
        emf.close();
        
        // Create
        properties = getBaseProperties();
        if (jpaSchemagen) {
            properties.put("javax.persistence.schema-generation.database.action", "create");
        } else {
            properties.put("hibernate.hbm2ddl.auto", "create");
        }
        emf = Persistence.createEntityManagerFactory("TestPU", properties);
        emf.close();
        
        // Query the table to ensure it exists
        properties = getBaseProperties();
        emf = Persistence.createEntityManagerFactory("TestPU", properties);
        em = emf.createEntityManager();
        em.find(Document.class, 1L);
        em.close();
        emf.close();
        
        // Check if drop works properly
        properties = getBaseProperties();
        if (jpaSchemagen) {
            properties.put("javax.persistence.schema-generation.database.action", "drop-and-create");
        } else {
            properties.put("hibernate.hbm2ddl.auto", "create-drop");
        }
        emf = Persistence.createEntityManagerFactory("TestPU", properties);
        emf.close();
        
        // Query the table to ensure it exists
        properties = getBaseProperties();
        emf = Persistence.createEntityManagerFactory("TestPU", properties);
        em = emf.createEntityManager();
        em.find(Document.class, 1L);
        em.close();
        emf.close();
    }
    
    private Properties getBaseProperties() {
        Properties properties = new Properties();
        properties.put("javax.persistence.jdbc.url", System.getProperty("jdbc.url"));
        properties.put("javax.persistence.jdbc.user", System.getProperty("jdbc.user", ""));
        properties.put("javax.persistence.jdbc.password", System.getProperty("jdbc.password", ""));
        properties.put("javax.persistence.jdbc.driver", System.getProperty("jdbc.driver"));
        properties.put("javax.persistence.sharedCache.mode", "NONE");
        properties.put("hibernate.dialect", SaneMySQLDialect.class.getName());
        return properties;
    }
}
