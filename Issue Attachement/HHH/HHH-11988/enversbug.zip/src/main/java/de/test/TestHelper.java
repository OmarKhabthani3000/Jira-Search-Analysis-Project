package de.test;

import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.util.List;
import java.util.logging.Logger;

import static java.lang.String.format;
import static javax.ejb.TransactionAttributeType.REQUIRES_NEW;

@Stateless
public class TestHelper {

  private static final Logger LOG = Logger.getLogger(TestHelper.class.getName());

  @PersistenceContext
  private EntityManager em;

  @TransactionAttribute(REQUIRES_NEW)
  public TestEntity createTestEntity() {
    TestEntity entity = new TestEntity();
    entity.setNumber(BigDecimal.valueOf(1));
    entity.setText("First");
    return em.merge(entity);
  }

  @TransactionAttribute(REQUIRES_NEW)
  public void updateTestEntity(Long id) {
    TestEntity entity = em.find(TestEntity.class, id);
    entity.setNumber(BigDecimal.valueOf(1));
    entity.setText("Second");
  }

  @TransactionAttribute(REQUIRES_NEW)
  public void checkRevisions(Long id) {
    AuditReader reader = AuditReaderFactory.get(em);
    List<Number> revisions = reader.getRevisions(TestEntity.class, id);

    if (revisions.size() != 1) {
      LOG.severe(format("There should be exactly one revision but there are %s revisions!", revisions.size()));
    } else {
      LOG.info(format("There is %s revision :-o", revisions.size()));
    }
  }
}
