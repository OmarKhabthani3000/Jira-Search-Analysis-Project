package de.test;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionAttribute;
import java.util.logging.Logger;

import static javax.ejb.TransactionAttributeType.NOT_SUPPORTED;

@Singleton
@Startup
public class TestBean {

  private static final Logger LOG = Logger.getLogger(TestBean.class.getName());

  @EJB
  private TestHelper helper;

  @PostConstruct
  @TransactionAttribute(NOT_SUPPORTED)
  public void testEnvers() {
    TestEntity test = helper.createTestEntity();
    helper.updateTestEntity(test.getId());
    helper.checkRevisions(test.getId());
  }



}
