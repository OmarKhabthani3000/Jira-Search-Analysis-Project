package de.test;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.math.BigDecimal;

import static javax.persistence.GenerationType.SEQUENCE;

@Entity
@Audited
public class TestEntity {

  @Id
  @GeneratedValue(strategy = SEQUENCE)
  private Long id;

  @Column(precision = 23, scale = 6)
  private BigDecimal number;

  @NotAudited
  private String text;

  public Long getId() {
    return id;
  }

  public TestEntity setId(Long id) {
    this.id = id;
    return this;
  }

  public BigDecimal getNumber() {
    return number;
  }

  public TestEntity setNumber(BigDecimal number) {
    this.number = number;
    return this;
  }

  public String getText() {
    return text;
  }

  public TestEntity setText(String text) {
    this.text = text;
    return this;
  }
}
