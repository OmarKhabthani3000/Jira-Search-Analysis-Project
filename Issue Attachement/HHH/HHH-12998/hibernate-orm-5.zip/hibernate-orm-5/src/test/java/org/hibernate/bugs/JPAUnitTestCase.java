package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.bugs.entity.Automobile;
import org.hibernate.bugs.entity.Slot;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		init(entityManager);
		flushAndClear(entityManager);

		//1 it doesn't work, but it's supposed to
		entityManager.remove(entityManager.find(Slot.class, 1L));

		//2 it works, but we are not supposed to delete Automobile manually.
		//This is because, it's done by database via on delete cascade FK
		//entityManager.remove(entityManager.find(Automobile.class, 1L));
		//entityManager.remove(entityManager.find(Slot.class, 1L));

		//3 it works, because no one lifecycle callbacks can be invoked
		//entityManager.createQuery("delete from Slot s where s.id =:id")
		//		.setParameter("id", 1L)
		//		.executeUpdate();

		flushAndClear(entityManager);

		assertNull(entityManager.find(Slot.class, 1L));
		assertNull(entityManager.find(Automobile.class, 1L));
		assertNotNull(entityManager.find(Slot.class, 2L));
		assertNotNull(entityManager.find(Automobile.class, 2L));

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	private void init(EntityManager em) {

		Slot slot1 = new Slot();
		slot1.setId(1L);
		em.persist(slot1);

		Automobile automobile1 = new Automobile();
		automobile1.setSlot(em.find(Slot.class, 1L));
		em.persist(automobile1);
		//----------
		Slot slot2 = new Slot();
		slot2.setId(2L);
		em.persist(slot2);

		Automobile automobile2 = new Automobile();
		automobile2.setSlot(em.find(Slot.class, 2L));
		em.persist(automobile2);
	}

	void flushAndClear(EntityManager em) {
		em.flush();
		em.clear();
	}
}
