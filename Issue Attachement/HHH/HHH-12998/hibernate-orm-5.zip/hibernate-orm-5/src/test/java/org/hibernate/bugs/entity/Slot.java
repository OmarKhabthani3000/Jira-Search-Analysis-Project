package org.hibernate.bugs.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *             //cascade = CascadeType.ALL
 *             // Removal cascading is redundant here,
 *             // because all heavy lifting is supposed be done via FK on delete cascade.
 *             // To make sure that it exists see in logs:
 * //            alter table Automobile
 * //            add constraint FK1aygv7kn78x4itcpgf3nh3wvf
 * //            foreign key (id)
 * //            references Slot
 * //            on delete cascade
 */
@Entity
@Table
public class Slot {
    @Id
    private Long id;

    @OneToOne(
            mappedBy = "slot",
            fetch = FetchType.LAZY,
            cascade = {CascadeType.PERSIST, CascadeType.MERGE}
    )
    private Automobile automobile;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Automobile getAutomobile() {
        return automobile;
    }

    public void setAutomobile(Automobile automobile) {
        this.automobile = automobile;
    }
}