package org.hibernate.test;

import org.hibernate.EmptyInterceptor;
import org.hibernate.Session;
import org.hibernate.type.Type;

import java.io.Serializable;
import java.util.List;

/**
 * Created by zhou on 2018/1/17.
 */
public class Interceptor extends EmptyInterceptor {

    public static ThreadLocal<Session> threadLocal = new ThreadLocal<>();

    @Override
    public boolean onLoad(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
        List<User> users = threadLocal.get().createQuery("select u from User u", User.class)
                .getResultList();
        return false;
    }

}
