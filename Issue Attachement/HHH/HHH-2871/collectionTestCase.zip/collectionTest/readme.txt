resources folder contains hibernate.cfg.xml

src/my/Test.java is a test case that contains 4 test methods. Two of these methods throw exception

fix contains SQLQueryParser.java, that resolve problems
