package my;

import junit.framework.TestCase;
import org.hibernate.SessionFactory;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.impl.SessionFactoryImpl;
import org.hibernate.cfg.Configuration;
import my.model.Program;

public class Test extends TestCase
{
    private SessionFactory _factory;

    /**
     * It is tests for one-to-many collection using star syntax.
     * Work properly.
     *
     * Query is "select p, p.documents from Program"
     */
    public void testOneToManyCollectionStar()
    {
        String nsql =
                "select " +
                        "{p.*}, " +
                        "{c.*} " +
                "from TBL_PROGRAM p " +
                "inner join TBL_DOCUMENT c on c.parent_id=p.id";

        executeCollectionQuery(nsql, "documents");
    }

    /**
     * It is tests for one-to-many collection using properties syntax.
     * Throws exception!
     *
     * Query is "select p, p.documents from Program"
     */
    public void testOneToManyCollectionProperties()
    {
        String nsql =
                "select " +
                        "{p.*}, " +
                        "c.parent_id as {c.key}, " +
                        "c.id as {c.element}, " +
                        "c.id as {c.element.id}, " +
                        "c.title as {c.element.title} " +
                "from TBL_PROGRAM p " +
                "inner join TBL_DOCUMENT c on c.parent_id=p.id";

        executeCollectionQuery(nsql, "documents");
    }

    /**
     * It is tests for element collection using star syntax.
     * Work properly.
     *
     * Query is "select p, p.elements from Program"
     */
    public void testElementCollectionStar()
    {
        String nsql =
                "select " +
                        "{p.*}, " +
                        "{c.*} " +
                "from TBL_PROGRAM p " +
                "inner join TBL_ELEMENT c on c.parent_id=p.id";

        executeCollectionQuery(nsql, "elements");
    }

    /**
     * It is tests for element collection using properties syntax.
     * Throws exception!
     *
     * Query is "select p, p.elements from Program"
     */
    public void testElementCollectionProperties()
    {
        String nsql =
                "select " +
                        "{p.*}, " +
                        "c.parent_id as {c.key}, " +
                        "c.number as {c.element} " +
                "from TBL_PROGRAM p " +
                "inner join TBL_ELEMENT c on c.parent_id=p.id";

        executeCollectionQuery(nsql, "elements");
    }

    private void executeCollectionQuery(String nsql, String join)
    {
        Session sess = _factory.openSession();
        Transaction tx = sess.beginTransaction();

        try
        {
            SQLQuery query = sess.createSQLQuery(nsql);
            query.addEntity("p", Program.class);
            query.addJoin("c", "p." + join);
            query.list();
        }
        finally
        {
            tx.rollback();
            sess.close();
        }
    }

    @Override
    protected void setUp() throws Exception
    {
        super.setUp();
        buildFactory();
    }

    private void buildFactory()
    {
        if( _factory==null )
        {
            try {
                // Create the SessionFactory from hibernate.cfg.xml
                Configuration config = new Configuration().configure();
                _factory = (SessionFactoryImpl) config.buildSessionFactory();
            } catch (Throwable ex) {
                // Make sure you log the exception, as it might be swallowed
                System.err.println("Initial SessionFactory creation failed." + ex);
                throw new ExceptionInInitializerError(ex);
            }
        }
    }
}
