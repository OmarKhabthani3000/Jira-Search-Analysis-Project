package my.model;

public class Document
{
    private String _id;
    private Program _parent;
    private String _title;

    public String getId()
    {
        return _id;
    }

    public void setId(String id)
    {
        _id = id;
    }

    public Program getParent()
    {
        return _parent;
    }

    public void setParent(Program parent)
    {
        _parent = parent;
    }

    public String getTitle()
    {
        return _title;
    }

    public void setTitle(String title)
    {
        _title = title;
    }
}
