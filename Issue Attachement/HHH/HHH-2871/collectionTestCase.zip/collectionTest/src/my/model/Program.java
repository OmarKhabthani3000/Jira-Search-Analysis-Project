package my.model;

import java.util.List;

public class Program
{
    private String _id;
    private String _title;
    private List<Document> _documents;
    private List<Integer> _elements;

    public String getId()
    {
        return _id;
    }

    public void setId(String id)
    {
        _id = id;
    }

    public String getTitle()
    {
        return _title;
    }

    public void setTitle(String title)
    {
        _title = title;
    }

    public List<Document> getDocuments()
    {
        return _documents;
    }

    public void setDocuments(List<Document> documents)
    {
        _documents = documents;
    }

    public List<Integer> getElements()
    {
        return _elements;
    }

    public void setElements(List<Integer> elements)
    {
        _elements = elements;
    }
}
