/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package db;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(schema = "test", name = "t_primary")
public class Primary extends BasePrimary {

}
