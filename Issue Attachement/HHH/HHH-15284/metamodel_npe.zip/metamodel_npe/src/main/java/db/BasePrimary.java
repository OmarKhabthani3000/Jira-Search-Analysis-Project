/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package db;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.OneToOne;
import java.io.Serializable;
import java.util.Objects;

@MappedSuperclass
public class BasePrimary implements Serializable {


    @Id
    @OneToOne
    @JoinColumn(name = "t_secondary_id")
    private Secondary secondary;


    @Column(name = "t_secondary_id", insertable = false, updatable = false)
    private Integer secondaryFk;

    public Secondary getSecondary() {
        return secondary;
    }

    public void setSecondary(Secondary secondary) {
        this.secondary = secondary;
    }

    public Integer getSecondaryFk() {
        return secondaryFk;
    }

    public void setSecondaryFk(Integer secondaryFk) {
        this.secondaryFk = secondaryFk;
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BasePrimary that = (BasePrimary) o;
        return Objects.equals(secondary, that.secondary) && Objects.equals(secondaryFk, that.secondaryFk);
    }

    @Override public int hashCode() {
        return Objects.hash(secondary, secondaryFk);
    }
}
