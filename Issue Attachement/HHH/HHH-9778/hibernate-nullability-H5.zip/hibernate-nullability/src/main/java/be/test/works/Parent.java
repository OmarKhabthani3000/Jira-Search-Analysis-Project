package be.test.works;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by koen on 28/04/15.
 */
public class Parent {

	private Long id;
	private Collection<Child> children = new ArrayList<>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Collection<Child> getChildren() {
		return children;
	}

	public void setChildren(Collection<Child> children) {
		this.children = children;
	}
}
