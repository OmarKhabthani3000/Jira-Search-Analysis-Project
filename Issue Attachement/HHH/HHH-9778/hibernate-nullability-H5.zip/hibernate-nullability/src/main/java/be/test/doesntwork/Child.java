package be.test.doesntwork;

/**
 * Created by koen on 28/04/15.
 */
public class Child {

	private Long id;

	private Parent parent;
	private Parent nextParent;

	private SomeComponent component;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public SomeComponent getComponent() {
		return component;
	}

	public void setComponent(SomeComponent component) {
		this.component = component;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public Parent getNextParent() {
		return nextParent;
	}

	public void setNextParent(Parent nextParent) {
		this.nextParent = nextParent;
	}
}
