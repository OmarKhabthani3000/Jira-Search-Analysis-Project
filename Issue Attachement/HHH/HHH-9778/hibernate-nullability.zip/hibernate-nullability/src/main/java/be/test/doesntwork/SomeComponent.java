package be.test.doesntwork;

import be.test.doesntwork.Parent;

/**
 * Created by koen on 28/04/15.
 */
public class SomeComponent {

	private Parent parent;
	private Parent nextParent;

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public Parent getNextParent() {
		return nextParent;
	}

	public void setNextParent(Parent nextParent) {
		this.nextParent = nextParent;
	}
}
