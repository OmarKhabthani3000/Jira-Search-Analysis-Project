package be.test;

/**
 * Created by koen on 28/04/15.
 */

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.Test;

import be.test.doesntwork.SomeComponent;
import be.test.works.Child;
import be.test.works.Parent;

@Test
@ContextConfiguration(locations = { "classpath:/config.xml" })
public class HibernateTest extends AbstractTransactionalTestNGSpringContextTests {

	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * This works
	 */
	public void testAssociationsPlacedDirectlyInsideChildEntity() {
		Session session = sessionFactory.getCurrentSession();

		Parent parentOne = new Parent();
		Parent parentTwo = new Parent();

		session.save("parent_wrks",parentOne);
		session.save("parent_wrks",parentTwo);

		session.flush();
		session.clear();

		parentOne = (Parent) session.get("parent_wrks", parentOne.getId());
		parentTwo = (Parent) session.get("parent_wrks", parentTwo.getId());

		Child child = new Child();
		child.setNextParent(parentTwo);

		parentOne.getChildren().add(child);

		session.flush();
		session.clear();
	}

	/**
	 * This doesn't work
	 */
	public void testAssociationsPlacedInsideComponentInsideChildEntity() {
		Session session = sessionFactory.getCurrentSession();

		be.test.doesntwork.Parent parentOne = new be.test.doesntwork.Parent();
		be.test.doesntwork.Parent parentTwo = new be.test.doesntwork.Parent();

		session.save("parent_dsntwrk",parentOne);
		session.save("parent_dsntwrk",parentTwo);

		session.flush();
		session.clear();

		parentOne = (be.test.doesntwork.Parent) session.get("parent_dsntwrk", parentOne.getId());
		parentTwo = (be.test.doesntwork.Parent) session.get("parent_dsntwrk", parentTwo.getId());

		be.test.doesntwork.Child child = new be.test.doesntwork.Child();
		SomeComponent someComponent = new SomeComponent();
		someComponent.setNextParent(parentTwo);
		child.setComponent(someComponent);

		parentOne.getChildren().add(child);

		session.flush();
		session.clear();
	}
}