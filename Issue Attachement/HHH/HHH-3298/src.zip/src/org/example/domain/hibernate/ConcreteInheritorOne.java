package org.example.domain.hibernate;

public class ConcreteInheritorOne extends Entity
{
	
	public ConcreteInheritorOne()
    {
    }
		
}
