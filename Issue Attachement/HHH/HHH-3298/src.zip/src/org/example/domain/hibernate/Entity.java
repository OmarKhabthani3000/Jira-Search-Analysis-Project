package org.example.domain.hibernate;

public class Entity
{
	private String m_id;
	private Integer m_versionNumber = -1;

	
	public Entity()
    {
    }

	
	public String getId()
    {
    	return m_id;
    }

	public void setId(String id)
    {
    	m_id = id;
    }

	public Integer getVersionNumber()
    {
    	return m_versionNumber;
    }

	public void setVersionNumber(Integer versionNumber)
    {
    	m_versionNumber = versionNumber;
    }
	
	
	
}
