package org.example.domain.hibernate;

public class ConcreteInheritorTwo extends ConcreteInheritorOne
{

	public ConcreteInheritorTwo()
    {
    }
	
}
