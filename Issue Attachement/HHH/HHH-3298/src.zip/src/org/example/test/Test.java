package org.example.test;

import org.example.domain.hibernate.ConcreteInheritorOne;
import org.example.domain.hibernate.ConcreteInheritorTwo;
import org.example.domain.hibernate.Entity;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.persister.entity.UnionSubclassEntityPersister;

import java.util.Date;

public class Test
{
	private static SessionFactory m_sessionFactory;
	private String inheritorOneId = Long.toString( (new Date()).getTime() - 100 );
	private String inheritorTwoId = Long.toString( (new Date()).getTime() + 100 );
	
	public Test()
    {
    }
	
	public static void main(String[] args)
	{
		m_sessionFactory = 	new Configuration().configure().buildSessionFactory();
		
		Test tester = new Test();
		tester.doTest1();
		
		m_sessionFactory = null;
		m_sessionFactory = 	new Configuration().configure().buildSessionFactory();
		
		tester.doTest2();
	}
	
	// Create persistent test objects
	public void doTest1()
	{
		String inheritorOneId = Long.toString( (new Date()).getTime() - 100 );
		String inheritorTwoId = Long.toString( (new Date()).getTime() + 100 );
		
		
		Session session = getSession();
		session.beginTransaction();
		
		ConcreteInheritorOne inheritorOne = new ConcreteInheritorOne();		
		ConcreteInheritorTwo inheritorTwo = new ConcreteInheritorTwo();
		
		inheritorOne.setId(inheritorOneId);
		inheritorTwo.setId(inheritorTwoId);
		
		session.saveOrUpdate(inheritorOne);
		session.saveOrUpdate(inheritorTwo);		
	
		session.getTransaction().commit();
	}
	
	// Retrieve subclass object using superclass, with LockMode.UPGRADE
	public void doTest2() 
	{		
		
		Session session = getSession();
		session.beginTransaction();
		
		// These lookups will cause an error
		Entity e = (Entity) session.get(Entity.class, inheritorTwoId, LockMode.UPGRADE);
		//Entity e = (Entity) session.get(ConcreteInheritorOne.class, inheritorTwoId, LockMode.UPGRADE);

		// These will not cause an error
		//Entity e = (Entity) getEntityForUpdate(ConcreteInheritorOne.class, inheritorTwoId);
		//Entity e = (Entity) session.get(ConcreteInheritorTwo.class, inheritorTwoId, LockMode.UPGRADE);
		
		session.getTransaction().commit();
		
	}	

	public Object getEntityForUpdate(Class entityClass, String entityId)
	{
		Session s = getSession();
		ClassMetadata meta = s.getSessionFactory().getClassMetadata(entityClass);
		
		Boolean doTwoPhaseLock = false;
		
		if(meta instanceof UnionSubclassEntityPersister)
		{
			if(((UnionSubclassEntityPersister)meta).getEntityMetamodel().getSubclassEntityNames().size() > 1)
				doTwoPhaseLock = true;
		}
		
		if(doTwoPhaseLock)
		{
			Entity e = (Entity)s.get(entityClass, entityId);
			System.out.println("Using Two-Phase Lock on: EntityId[" + entityId + "] EntityClass[" + entityClass.getName() + "]");
			s.lock(e, LockMode.UPGRADE);
			return e;
		}
		else
		{
			System.out.println("Using One-Phase Lock on: EntityId[" + entityId + "] EntityClass[" + entityClass.getName() + "]");
			return s.get(entityClass, entityId, LockMode.UPGRADE);
		}
	}
	
	private Session getSession()
	{
		return m_sessionFactory.getCurrentSession();
	}
	
}

