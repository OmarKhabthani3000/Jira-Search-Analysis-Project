package examples;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Access(AccessType.FIELD)
@Table(name="CHILD_1")
public class Child1 extends AbstractBase {

	@Column(name="VALUE_2",length=2000)
	private String value2;
	
	public String getValue2() {
		return value2;
	}
	
	public void setValue2(String __value) {
		this.value2 = __value;
	}
}
