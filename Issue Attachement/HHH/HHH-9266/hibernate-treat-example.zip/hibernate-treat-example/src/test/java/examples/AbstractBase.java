package examples;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;


@Entity
@Access(AccessType.FIELD)
@Table(name="ABSTRACT_BASE")
@Inheritance(strategy=InheritanceType.JOINED)
@DiscriminatorColumn(name="IN__TYPE", discriminatorType=DiscriminatorType.STRING,length=128)
@DiscriminatorValue("AbstractBase")
public class AbstractBase implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private Long id;
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long __value) {
		this.id = __value;
	}
	
	@Column(name="IN__TYPE",insertable=true,updatable=true)
	private String type__;
	
	public String _getType() {
		return type__;
	}

	@Column(name="VALUE_0",length=2000)
	private String value0;
	
	public String getValue0() {
		return value0;
	}
	
	public void setValue0(String __value) {
		this.value0 = __value;
	}
}
