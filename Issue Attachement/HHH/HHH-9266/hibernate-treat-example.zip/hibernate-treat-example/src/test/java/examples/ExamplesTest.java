package examples;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import junit.framework.TestCase;

public class ExamplesTest extends TestCase {
	private EntityManagerFactory emf;

	@Override
	protected void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory( "examples.hibernate" );
	}

	@Override
	protected void tearDown() throws Exception {
		emf.close();
	}

	public void testBasicUsage() {
		setupEntities();
		
		EntityManager em = createEntityManager();
		try {
			Query q = em.createQuery("select e.id, e.value0, treat(e as Child0).value1 from AbstractBase e");
			
			@SuppressWarnings("rawtypes")
			List result = q.getResultList();
			assertEquals(2, result.size());
		}
		finally {
			closeEntityManager(em);
		}
	}
	
	private void setupEntities() {
		EntityManager em = createEntityManager();
		try {
			Child0 c0 = new Child0();
			c0.setValue0("child0.value0");
			c0.setValue1("child0.value1");
			em.persist(c0);

			Child1 c1 = new Child1();
			c1.setValue0("child1.value0");
			c1.setValue2("child1.value2");
			em.persist(c1);
		}
		finally {
			closeEntityManager(em);
		}
	}
	
	private EntityManager createEntityManager() {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		return em;
	}
	
	private void closeEntityManager(EntityManager em) {
		em.getTransaction().commit();
        em.close();
	}
}
