package examples;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Access(AccessType.FIELD)
@Table(name="CHILD_0")
public class Child0 extends AbstractBase  {

	@Column(name="VALUE_1",length=2000)
	private String value1;
	
	public String getValue1() {
		return value1;
	}
	
	public void setValue1(String __value) {
		this.value1 = __value;
	}
}
