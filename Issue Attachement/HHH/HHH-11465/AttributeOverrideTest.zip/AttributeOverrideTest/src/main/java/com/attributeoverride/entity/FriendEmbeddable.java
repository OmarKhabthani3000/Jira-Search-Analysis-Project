package com.attributeoverride.entity;

import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.time.YearMonth;

@Embeddable
public class FriendEmbeddable {
    private String friendName;

    @Type(type = "org.hibernate.type.YearMonthUserType")
    @Columns(columns = {
            @Column(name = "known_year", nullable = true),
            @Column(name = "known_month", nullable = true)
    })
    private YearMonth knownSince;

    public FriendEmbeddable() {
    }

    public FriendEmbeddable(String friendName, YearMonth knownSince) {
        this.friendName = friendName;
        this.knownSince = knownSince;
    }

    public String getFriendName() {
        return friendName;
    }

    public void setFriendName(String friendName) {
        this.friendName = friendName;
    }

    public YearMonth getKnownSince() {
        return knownSince;
    }

    public void setKnownSince(YearMonth knownSince) {
        this.knownSince = knownSince;
    }
}
