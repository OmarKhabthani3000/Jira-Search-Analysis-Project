package com.attributeoverride.controller;

import com.attributeoverride.dao.PersonService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;

@RestController
public class PersonController {
    private final PersonService personDao;

    @Inject
    public PersonController(PersonService personDao) {
        this.personDao = personDao;
    }

    @RequestMapping("/person")
    public String person() {
        personDao.savePerson();
        return "Done";
    }
}
