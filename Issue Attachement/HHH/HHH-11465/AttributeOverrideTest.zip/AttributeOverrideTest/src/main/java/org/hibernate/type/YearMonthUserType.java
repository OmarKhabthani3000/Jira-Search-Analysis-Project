package org.hibernate.type;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.usertype.EnhancedUserType;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.YearMonth;

public class YearMonthUserType implements EnhancedUserType, Serializable {

    @Override
    public int[] sqlTypes() {
        return new int[]{
                IntegerType.INSTANCE.sqlType(),
                IntegerType.INSTANCE.sqlType(),
        };
    }

    @Override
    public Class returnedClass() {
        return YearMonth.class;
    }

    @Override
    @SuppressWarnings("PMD.SuspiciousEqualsMethodName")
    public boolean equals(final Object x, final Object y) throws HibernateException {
        if (x == y) {
            return true;
        }
        if (x == null || y == null) {
            return false;
        }
        final YearMonth mtx = (YearMonth) x;
        final YearMonth mty = (YearMonth) y;
        return mtx.equals(mty);
    }

    @Override
    public int hashCode(final Object x) throws HibernateException {
        return x.hashCode();
    }

    //https://docs.jboss.org/hibernate/orm/3.6/reference/en-US/html/types.html
    //http://learningviacode.blogspot.hu/2011/09/creating-hibernate-custom-type-4.html
    //http://java.dzone.com/articles/looking-java-9-YearMonth-and
    //http://www.infoq.com/articles/JSR-354-Java-YearMonth-Currency-API
    @Override
    public Object nullSafeGet(final ResultSet rs, final String[] names, final SessionImplementor session, final Object owner) throws HibernateException, SQLException {
        assert names.length == 2;
        final Integer year = IntegerType.INSTANCE.nullSafeGet(rs, names[0], session);
        final Integer month = IntegerType.INSTANCE.nullSafeGet(rs, names[1], session);
        return year == null || month == null ? null : YearMonth.of(year, month);
    }

    @Override
    public void nullSafeSet(final PreparedStatement st, final Object value, final int index, final SessionImplementor session) throws HibernateException, SQLException {
        if (value == null) {
            IntegerType.INSTANCE.set(st, null, index, session);
            IntegerType.INSTANCE.set(st, null, index + 1, session);
        } else {
            final YearMonth YearMonth = (YearMonth) value;

            IntegerType.INSTANCE.set(st, YearMonth.getYear(), index, session);
            IntegerType.INSTANCE.set(st, YearMonth.getMonthValue(), index + 1, session);
        }
    }

    @Override
    public Object deepCopy(final Object value) throws HibernateException {
        return value;
    }

    @Override
    public boolean isMutable() {
        return false;
    }

    @Override
    public Serializable disassemble(final Object value) throws HibernateException {
        return (Serializable) value;
    }

    @Override
    public Object assemble(final Serializable cached, final Object value) throws HibernateException {
        return cached;
    }

    @Override
    public Object replace(final Object original, final Object target, final Object owner) throws HibernateException {
        return original;
    }

    @Override
    public String objectToSQLString(final Object object) {
        throw new UnsupportedOperationException();
    }

    @Override
    @Deprecated
    public String toXMLString(final Object object) {
        return object.toString();
    }

    @Override
    @Deprecated
    public Object fromXMLString(final String string) {
        return YearMonth.parse(string);
    }
}