package com.attributeoverride.dao;

public interface PersonService {
    void savePerson();
}
