package com.attributeoverride.dao;

import com.attributeoverride.entity.FriendEmbeddable;
import com.attributeoverride.entity.Person;
import com.attributeoverride.repositories.PersonRepository;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import javax.transaction.Transactional;
import java.time.YearMonth;

@Transactional
@Service
public class PersonServiceImpl implements PersonService {
    private final PersonRepository repository;

    @Inject
    public PersonServiceImpl(PersonRepository repository) {
        this.repository = repository;
    }

    public void savePerson() {
        Person person = new Person();
        person.setName("Ram");
        person.setBestFriend(new FriendEmbeddable("Foo", YearMonth.of(2017, 04)));
        person.setOtherFriend(new FriendEmbeddable("Bar", YearMonth.of(2017, 05)));
        repository.save(person);
    }

}
