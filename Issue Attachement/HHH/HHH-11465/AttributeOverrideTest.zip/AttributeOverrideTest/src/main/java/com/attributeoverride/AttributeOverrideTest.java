package com.attributeoverride;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AttributeOverrideTest {
    public static void main(final String[] args) {
        SpringApplication.run(AttributeOverrideTest.class, args);
    }
}
