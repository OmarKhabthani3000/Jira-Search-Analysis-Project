package com.attributeoverride.entity;

import javax.persistence.*;

@Entity
@Table(name = "person")
public class Person {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;

    private FriendEmbeddable bestFriend;

    // This doesn't work now, but will with my patch
    @AttributeOverrides({
            @AttributeOverride(name = "friendName",
                    column = @Column(name = "other_friend_name")),
            @AttributeOverride(name = "knownSince",
                    column = @Column(name = "other_known_year")),
            @AttributeOverride(name = "knownSince",
                    column = @Column(name = "other_known_month"))
    })
    private FriendEmbeddable otherFriend;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public FriendEmbeddable getBestFriend() {
        return bestFriend;
    }

    public void setBestFriend(FriendEmbeddable bestFriend) {
        this.bestFriend = bestFriend;
    }

    public FriendEmbeddable getOtherFriend() {
        return otherFriend;
    }

    public void setOtherFriend(FriendEmbeddable otherFriend) {
        this.otherFriend = otherFriend;
    }
}
