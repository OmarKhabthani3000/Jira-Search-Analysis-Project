package com.example.demo;

import jakarta.inject.Inject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class HelloServlet extends HttpServlet {

    @Inject
    EJBService ejbService;

    private String message;

    public void destroy() {
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        EJBEntity ejbEntity = new EJBEntity();
        ejbService.save(ejbEntity);

        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>" + message + "</h1>");
        out.println("<br/>");
        out.println("<h3>" + ejbEntity + "</h3>");
        out.println("<h3>" + ejbEntity.getClass() + "</h3>");
        out.println("<h3>" + ejbEntity.getId() + "</h3>");
        out.println("</body></html>");
    }

    public void init() {
        message = "Hello World!";
    }
}