/*
    Copyright (C) 2022 Can Türker. All Rights Reserved.
    
    The content of this file is subject to expressly agreed licensing terms between the
    recipient and the copyright holders. Should you have received this file without having
    agreed to such licensing terms, please be aware that any interception, copying,
    distribution, disclosure, or business use of the content of this file is not allowed.
 */
package com.example.demo;

import jakarta.ejb.Stateless;
import jakarta.inject.Named;
import jakarta.persistence.EntityManager;
import jakarta.persistence.FlushModeType;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import java.io.Serializable;
import java.util.List;

@Named
@Stateless
public class EJBService implements Serializable {

    private static final long serialVersionUID = 1;

    @PersistenceContext(unitName = "default")
    private EntityManager entityManager;

    public EJBService() {
    }

    public void clear() {
        getEntityManager().clear();
    }

    public boolean contains(Object entity) {
        return getEntityManager().contains(entity);
    }

    public int count(Class<?> clazz) {
        return ((Long) createQuery("select count(1) from " + clazz.getSimpleName()).getSingleResult()).intValue();
    }

    public Query createNamedQuery(String queryString) {
        return getEntityManager().createNamedQuery(queryString).setFlushMode(FlushModeType.COMMIT);
    }

    public Query createNativeQuery(String queryString) {
        return getEntityManager().createNativeQuery(queryString).setFlushMode(FlushModeType.COMMIT);
    }

    public Query createNativeQuery(String queryString, Class<?> clazz) {
        return getEntityManager().createNativeQuery(queryString, clazz).setFlushMode(FlushModeType.COMMIT);
    }

    public Query createQuery(String queryString) {
        return getEntityManager().createQuery(queryString).setFlushMode(FlushModeType.COMMIT);
    }

    public <T> T find(Class<T> clazz, Object id) {
        return getEntityManager().find(clazz, id);
    }

    public <T> List<T> findAll(Class<T> clazz) {
        return createQuery("from " + clazz.getSimpleName()).getResultList();
    }

    public <T> List<T> findRange(Class<T> clazz, int[] range) {
        return createQuery("from " + clazz.getSimpleName()).setMaxResults(range[1] - range[0] + 1).setFirstResult(range[0]).getResultList();
    }

    public void flush() {
        getEntityManager().flush();
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

    public Object merge(Object entity) {
        getEntityManager().merge(entity);
        return entity;
    }

    public void persist(Object entity) {
        getEntityManager().persist(entity);
    }

    public void refresh(Object entity) {
        getEntityManager().refresh(entity);
    }

    public void remove(Class<?> clazz, Long id) {
        getEntityManager().remove(find(clazz, id));
    }

    public void remove(Object entity) {
        getEntityManager().remove(merge(entity));
    }

    public void save(EJBEntity EJBEntity) {
        if (EJBEntity != null) {
            if (EJBEntity.getId() > 0) {
                merge(EJBEntity);
            } else {
                persist(EJBEntity);
            }
        }
    }

    public void update(EJBEntity EJBEntity) {
        find(EJBEntity.getClass(), EJBEntity.getId());
        merge(EJBEntity);
    }
}
