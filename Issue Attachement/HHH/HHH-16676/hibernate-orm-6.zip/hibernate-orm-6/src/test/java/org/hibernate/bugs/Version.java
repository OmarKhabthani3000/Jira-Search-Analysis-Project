package org.hibernate.bugs;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "version")
public class Version {

    @Id
    @SequenceGenerator(name = "CS_SEQ", sequenceName = "CS_SEQ")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CS_SEQ")
    @Column(name = "ID")
    private Long id;

    @Column(name = "name")
    private String name;

    @JoinColumn(name = "root_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private VersionedRoot owner;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "version", cascade = CascadeType.PERSIST)
    private List<Node> nodes;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public VersionedRoot getOwner() {
        return owner;
    }

    public void setOwner(VersionedRoot owner) {
        this.owner = owner;
    }
}
