package org.hibernate.bugs;

import jakarta.persistence.*;

import java.util.List;

@Entity
@DiscriminatorValue(value = "2")
public class VersionedRoot extends BaseRoot {

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "owner", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Version> versions;

    public List<Version> getVersions() {
        return versions;
    }

    public void setVersions(List<Version> versions) {
        this.versions = versions;
    }
}
