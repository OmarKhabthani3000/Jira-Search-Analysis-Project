package org.hibernate.bugs;

import jakarta.persistence.*;

@Entity
@Table(name = "NODE")
public class Node {

    @Id
    @SequenceGenerator(name = "CS_SEQ", sequenceName = "CS_SEQ")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CS_SEQ")
    @Column(name = "ID")
    private Long id;

    @JoinColumn(name = "VERSION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Version version;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Version getVersion() {
        return version;
    }

    public void setVersion(Version version) {
        this.version = version;
    }
}
