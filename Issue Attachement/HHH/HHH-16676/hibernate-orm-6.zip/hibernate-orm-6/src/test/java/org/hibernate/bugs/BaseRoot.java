package org.hibernate.bugs;

import jakarta.persistence.*;

@Entity
@Table(name = "roots")
@DiscriminatorColumn(name = "TYPE")
public class BaseRoot {

    @Id
    @SequenceGenerator(name = "CS_SEQ", sequenceName = "CS_SEQ")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CS_SEQ")
    @Column(name = "ID")
    private Long id;

    @Column(name = "NAME")
    private String name;

    @Column(name = "TYPE", updatable = false, insertable = false)
    private String type;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
