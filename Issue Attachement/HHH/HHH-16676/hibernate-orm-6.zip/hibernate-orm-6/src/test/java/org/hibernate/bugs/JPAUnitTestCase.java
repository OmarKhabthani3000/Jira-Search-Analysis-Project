package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import jakarta.persistence.Query;
import jakarta.persistence.criteria.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh_16676_Test() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<BaseRoot> query = cb.createQuery(BaseRoot.class);

		Root<BaseRoot> root = query.from(BaseRoot.class);

		Subquery<Long> nodesQuery = query.subquery(Long.class);
		Root<BaseRoot> subQueryRoot = nodesQuery.from(BaseRoot.class);
		nodesQuery.select(subQueryRoot.get("id"));
		Root<VersionedRoot> treatedRoot = cb.treat(subQueryRoot, VersionedRoot.class);
		Join<VersionedRoot, Version> joinTrees = treatedRoot.join("versions");
		Join<Version, Node> joinNodes = joinTrees.join("nodes");
		nodesQuery.where(
				cb.equal(joinNodes.get("version").get("owner").get("id"), root.get("id"))
		);

		query.where(
				cb.and(
						cb.equal(root.get("type"), "Dog"),
						cb.exists(nodesQuery)
				)
		);

		query.select(root);

		List<BaseRoot> result = entityManager.createQuery(query).getResultList();

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
