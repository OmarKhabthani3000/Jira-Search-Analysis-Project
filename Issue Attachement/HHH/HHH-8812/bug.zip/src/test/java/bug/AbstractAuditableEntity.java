package bug;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.io.Serializable;
import java.util.Date;

/**
 *
 */
@MappedSuperclass
@SuppressWarnings("unused")
public abstract class AbstractAuditableEntity<ID extends Serializable> extends AbstractEntity<ID> implements Auditable {

    private static final long serialVersionUID = 4807081723478547074L;


    private String lastModifiedBy;

    private Date lastModifiedDate;


    @Column(name = "lastmod_by")
    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    @Override
    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    @Column(name = "lastmod_date")
    @Temporal(TemporalType.TIMESTAMP)
    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    @Override
    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
}
