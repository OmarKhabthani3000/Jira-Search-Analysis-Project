package bug;

import org.junit.Assert;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath*:test.xml")
public class Test {

    @PersistenceContext
    private EntityManager entityManager;

    @org.junit.Test
    @Transactional
    public void test() {

        final TestEntity e = new TestEntity();
        e.setId(1);
        e.setProperty(true);

        entityManager.persist(e);
        entityManager.flush();

        Assert.assertEquals(true, TestEntity.TestConverter.CONVERTED);
    }
}
