package bug;

import javax.persistence.*;

/**
 *
 */
@Entity
@Table(name = "test")
@Convert(converter = TestEntity.TestConverter.class, attributeName = "property")
public class TestEntity extends AbstractAuditableEntity<Integer> {

    private Boolean property;

    @Id
    public Integer getId() {
        return 1;
    }

    @Column(name = "property", columnDefinition = "int")
    public Boolean getProperty() {
        return property;
    }

    public void setProperty(Boolean property) {
        this.property = property;
    }


    @Converter
    public static class TestConverter implements AttributeConverter<Boolean, Integer> {

        public static volatile boolean CONVERTED = false;


        @Override
        public Integer convertToDatabaseColumn(Boolean attribute) {
            System.out.println("convertToDatabaseColumn()");
            CONVERTED = true;
            return attribute != null && attribute ? 1 : 0;
        }

        @Override
        public Boolean convertToEntityAttribute(Integer dbData) {
            System.out.println("convertToEntityAttribute()");
            CONVERTED = true;
            return null != dbData && dbData == 1;
        }

    }
}
