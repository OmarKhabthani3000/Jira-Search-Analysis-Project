package bug;

import java.util.Date;

/**
 *
 */
public interface Auditable {

    void setLastModifiedBy(String lastModifiedBy);

    void setLastModifiedDate(Date lastModifiedDate);
}
