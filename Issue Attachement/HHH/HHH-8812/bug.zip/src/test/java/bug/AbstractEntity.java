package bug;

import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import java.io.Serializable;

/**
 *
 */
@MappedSuperclass
public abstract class AbstractEntity<ID extends Serializable> {

    private static final long serialVersionUID = -6829139895354409353L;


    private ID id;


    protected void setId(ID id) {
        this.id = id;
    }

    @Transient
    public ID getId() {
        return id;
    }

    @Transient
    public boolean isNew() {
        return null == getId();
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[" + getId() + "]";
    }

    @Override
    @SuppressWarnings("all")
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AbstractEntity that = (AbstractEntity) o;

        if (isNew())
            return super.equals(o);

        if (id != null ? !id.equals(that.id) : that.id != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        if (isNew())
            return super.hashCode();
        return id.hashCode();
    }
}
