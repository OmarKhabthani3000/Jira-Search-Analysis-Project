package bug;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

/**
 *
 */
public class TestEntityListener {

    @PrePersist
    @PreUpdate
    private void listen(Object entity) {
        System.out.println("@PrePersist @PreUpdate listener event fired");
    }
}
