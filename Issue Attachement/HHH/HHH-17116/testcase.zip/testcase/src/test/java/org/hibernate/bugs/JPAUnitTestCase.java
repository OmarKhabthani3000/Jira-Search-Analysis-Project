package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import jakarta.persistence.Tuple;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.setExtractBareNamePropertyMethods;
import org.hibernate.Session;
import org.hibernate.query.criteria.JpaDerivedJoin;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private static final Logger LOGGER = LogManager.getLogger();
	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh17116Test() throws Exception {
		try(EntityManager entityManager = entityManagerFactory.createEntityManager()) {
			entityManager.getTransaction().begin();
			//given
			persistData(entityManager);
			var cb = entityManager.unwrap(Session.class).getCriteriaBuilder();
			var query = cb.createTupleQuery();
			var root = query.from(Primary.class);

			var subquery = query.subquery(Tuple.class);
			Root<Primary> correlatedRoot = subquery.correlate(root);
			Join<Primary, Secondary> secondaryJoin = correlatedRoot.join("secondary");
			subquery.multiselect(secondaryJoin.get("entityName").alias("name"));
			//when
			JpaDerivedJoin<Tuple> joinLateral = root.joinLateral(subquery);
			query.multiselect(
					root.get("id").alias("id"),
					joinLateral.get("name").alias("name")
			).orderBy(
					cb.asc(root.get("id"))
			);
			var list = entityManager.createQuery(query).getResultList();
			//then
			assertThat(list).hasSize(2);
			var tupleIt = list.iterator();
			var tuple = tupleIt.next();
			assertThat(tuple.get("id", Integer.class)).isEqualTo(1);
			assertThat(tuple.get("name", String.class)).isEqualTo("a");
			tuple = tupleIt.next();
			assertThat(tuple.get("id", Integer.class)).isEqualTo(2);
			assertThat(tuple.get("name", String.class)).isEqualTo("b");
		} catch (Throwable t) {
			LOGGER.error(t.getMessage(), t);
			throw t;
		}
	}

	private void persistData(EntityManager em) {
		var secondaryA = createSecondary(1, "a");
		var secondaryB = createSecondary(2, "b");

		var entities = new ArrayList<Object>(List.of(
				createPrimary(1, secondaryA),
				createPrimary(2, secondaryB)
		));
		entities.addAll(List.of(
				secondaryA, secondaryB
		));
		entities.forEach(em::persist);
		em.flush();
		em.clear();
	}

	private Primary createPrimary(int id, Secondary secondary) {
		var entity = new Primary();
		entity.setId(id);
		entity.setSecondary(secondary);
		return entity;
	}

	private Secondary createSecondary(int id, String entityName) {
		var entity = new Secondary();
		entity.setId(id);
		entity.setEntityName(entityName);
		return entity;
	}
}
