package com.netappsid.security.bo;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.netappsid.annotations.DAO;
import com.netappsid.bo.Entity;
import com.netappsid.ejb3.annotation.EntityManager;
import com.netappsid.security.bo.dao.PermissionDAO;


/**
 * @author xjodoin
 * @author NetAppsID inc.
 * 
 * @version $Revision: 1.1 $
 */
@javax.persistence.Entity
@Table(schema="naid_security")
@DAO(dao=PermissionDAO.class)
public class Permission extends Entity<Permission>
{
	private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(Permission.class);

	// attributes
	private Long id;
	private SecureAccess<?> owner;
	private SecureItem secureItem;

	// properties true -> allow , false -> deny , null -> none
	private Boolean propertyReadOnly;
	private Boolean propertyEdit;
	private Boolean propertyCreate;
	private Boolean propertyDelete;

	public static final String PROPERTYNAME_PROPERTYREADONLY = "propertyReadOnly";
	public static final String PROPERTYNAME_PROPERTYEDIT = "propertyEdit";
	public static final String PROPERTYNAME_PROPERTYCREATE = "propertyCreate";
	public static final String PROPERTYNAME_PROPERTYDELETE = "propertyDelete";

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	/**
	 * @return Returns the owner.
	 */
	@ManyToOne
	public SecureAccess<?> getOwner()
	{
		return owner;
	}

	/**
	 * @param owner
	 *            The owner to set.
	 */
	public void setOwner(SecureAccess<?> owner)
	{
		this.owner = owner;
	}

	/**
	 * @return Returns the secureItem.
	 */
	@ManyToOne
	public SecureItem getSecureItem()
	{
		return secureItem;
	}

	/**
	 * @param secureItem
	 *            The secureItem to set.
	 */
	public void setSecureItem(SecureItem secureItem)
	{
		this.secureItem = secureItem;
	}

	/**
	 * if user is member more than one group you want to merge the permission Deny win on Allow
	 * 
	 * @param permission
	 * @return
	 */
	public Permission merge(Permission permission)
	{
		if (permission != null)
		{
			if (permission.getPropertyReadOnly() != null)
			{
				if (getPropertyReadOnly() == null)
				{
					setPropertyReadOnly(permission.getPropertyReadOnly());
				}
				else
				{
					if (!permission.getPropertyReadOnly())
					{
						setPropertyReadOnly(permission.getPropertyReadOnly());
					}
				}
			}

			if (permission.getPropertyEdit() != null)
			{
				if (getPropertyEdit() == null)
				{
					setPropertyEdit(permission.getPropertyEdit());
				}
				else
				{
					if (!permission.getPropertyEdit())
					{
						setPropertyEdit(permission.getPropertyEdit());
					}
				}
			}

			if (permission.getPropertyCreate() != null)
			{
				if (getPropertyCreate() == null)
				{
					setPropertyCreate(permission.getPropertyCreate());
				}
				else
				{
					if (!permission.getPropertyCreate())
					{
						setPropertyCreate(permission.getPropertyCreate());
					}
				}
			}

			if (permission.getPropertyDelete() != null)
			{
				if (getPropertyDelete() == null)
				{
					setPropertyDelete(permission.getPropertyDelete());
				}
				else
				{
					if (!permission.getPropertyDelete())
					{
						setPropertyDelete(permission.getPropertyDelete());
					}
				}
			}
		}

		return this;
	}

	/**
	 * @return Returns the propertyReadOnly.
	 */
	public Boolean getPropertyReadOnly()
	{
		return propertyReadOnly;
	}

	/**
	 * @param propertyReadOnly
	 *            The propertyReadOnly to set.
	 */
	public void setPropertyReadOnly(Boolean propertyReadOnly)
	{
		// other must be set null if read only
		if (propertyReadOnly != null && propertyReadOnly)
		{
			propertyCreate = null;
			propertyDelete = null;
			propertyEdit = null;
		}

		this.propertyReadOnly = propertyReadOnly;
		firePropertyChange(PROPERTYNAME_PROPERTYREADONLY, null, propertyReadOnly); 
	}

	/**
	 * @return Returns the propertyEdit.
	 */
	public Boolean getPropertyEdit()
	{
		return propertyEdit;
	}

	/**
	 * @param propertyEdit
	 *            The propertyEdit to set.
	 */
	public void setPropertyEdit(Boolean propertyEdit)
	{
		this.propertyEdit = propertyEdit;
		firePropertyChange(PROPERTYNAME_PROPERTYEDIT, null, propertyEdit); 
	}

	/**
	 * @return Returns the propertyCreate.
	 */
	public Boolean getPropertyCreate()
	{
		return propertyCreate;
	}

	/**
	 * @param propertyCreate
	 *            The propertyCreate to set.
	 */
	public void setPropertyCreate(Boolean propertyCreate)
	{
		this.propertyCreate = propertyCreate;
		firePropertyChange(PROPERTYNAME_PROPERTYCREATE, null, propertyCreate); 
	}

	/**
	 * @return Returns the propertyDelete.
	 */
	public Boolean getPropertyDelete()
	{
		return propertyDelete;
	}

	/**
	 * @param propertyDelete
	 *            The propertyDelete to set.
	 */
	public void setPropertyDelete(Boolean propertyDelete)
	{
		this.propertyDelete = propertyDelete;
		firePropertyChange(PROPERTYNAME_PROPERTYDELETE, null, propertyDelete); 
	}

}
