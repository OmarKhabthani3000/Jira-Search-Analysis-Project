package com.netappsid.security.bo;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Cascade;
import org.hibernate.validator.NotNull;

import com.netappsid.annotations.DAO;
import com.netappsid.security.bo.dao.UserDAO;

/**
 * @author xjodoin
 * @author NetAppsID inc.
 * 
 * @version $Revision: 1.1 $
 */
@Entity
@DAO(dao = UserDAO.class)
@NamedQueries(@NamedQuery(name = "userByCode", query = "from SecurityUser user where user.code = :code"))
@Table(schema = "naid_security")
@Inheritance(strategy=InheritanceType.JOINED)
public class SecurityUser extends SecureAccess<SecurityUser> implements Principal
{
	private static final long serialVersionUID = 6817405045244210910L;

	private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SecurityUser.class);

	public static final String PROPERTY_GROUPS = "groups";

	private String password;

	private List<SecurityUserGroup> userGroups = new ArrayList<SecurityUserGroup>();
	private List<SecurityGroup> groups;

	private List<Permission> personnalPermissions;

	public boolean isMember(SecurityGroup group)
	{
		return getGroups().contains(group);
	}

	/**
	 * @return Returns the groups.
	 */
	@Transient
	public List<SecurityGroup> getGroups()
	{
		if (groups == null)
		{
			groups = new ArrayList<SecurityGroup>();

			for (SecurityUserGroup userGroup : userGroups)
			{
				groups.add(userGroup.getGroup());
			}
		}

		return groups;
	}

	/**
	 * @param groups
	 *            The groups to set.
	 */
	public void setGroups(List<SecurityGroup> groups)
	{
		List<SecurityGroup> old = this.groups;
		this.groups = groups;
		firePropertyChange(PROPERTY_GROUPS, old, groups);
	}

	public void removeFromGroups(SecurityGroup group)
	{
		Iterator<SecurityUserGroup> iterator = userGroups.iterator();

		while (iterator.hasNext())
		{
			SecurityUserGroup userGroup = (SecurityUserGroup) iterator.next();

			if (userGroup.getGroup().getId().equals(group.getId()))
			{
				iterator.remove();
				break;
			}
		}

		groups.remove(group);
		firePropertyChange(PROPERTY_GROUPS, null, groups);
	}

	@Transient
	public List<SecureAccess<?>> getSecureAccessList()
	{
		List<SecureAccess<?>> list = new ArrayList<SecureAccess<?>>();
		list.add(this);
		list.addAll(getGroups());

		return list;
	}

	/**
	 * @return Returns the userGroup.
	 */
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "user")
	public List<SecurityUserGroup> getUserGroups()
	{
		return userGroups;
	}

	/**
	 * @param userGroup
	 *            The userGroup to set.
	 */
	public void setUserGroups(List<SecurityUserGroup> userGroup)
	{
		this.userGroups = userGroup;
	}

	/**
	 * only permission is assign directly
	 * 
	 * @return
	 */
	@Transient
	public List<Permission> getPersonnalPermissions()
	{
		if (personnalPermissions == null)
		{
			personnalPermissions = new ArrayList<Permission>();

			for (SecureItem item : getPermissions().values())
			{
				if (item.getPermission(this) != null)
				{
					Permission permission = item.getPermission(this);

					if (permission.getOwner().getId().equals(getId()))
					{
						personnalPermissions.add(permission);
					}
				}

			}
		}

		return personnalPermissions;
	}

	public void removeFromPersonnalPermissions(Permission permission)
	{
		personnalPermissions.remove(permission);
		removeFromPermissionList(permission);
		firePropertyChange("personnalPermissions", null, personnalPermissions);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.security.Principal#getName()
	 */
	@Override
	@Transient
	public String getName()
	{
		return getCode();
	}

	public String getPassword()
	{
		return password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

}
