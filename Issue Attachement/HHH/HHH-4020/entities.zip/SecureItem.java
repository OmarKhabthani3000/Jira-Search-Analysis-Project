/**
 * 
 */
package com.netappsid.security.bo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CollectionTypeInfo;
import org.hibernate.annotations.Index;

import com.netappsid.annotations.DAO;
import com.netappsid.bo.Entity;
import com.netappsid.observable.list.DefaultObservableList;
import com.netappsid.security.SecurityException;
import com.netappsid.security.bo.dao.SecureItemDAO;

/**
 * @author xjodoin
 * @author NetAppsID inc.
 * 
 * @version $Revision: 1.1 $
 */
@javax.persistence.Entity
@Table(schema="naid_security")
@DAO(dao = SecureItemDAO.class)
public class SecureItem extends Entity<SecureItem>
{
	private static final long serialVersionUID = -8820180364949970307L;

	private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SecureItem.class);

	// attributes
	private Long id;
	private String name;

	private String securityKey;

	// the permission are inherited from the parent but doesn't if override
	private boolean securityOverride = false;

	private SecureItem parent;
	private List<SecureItem> childs = new ArrayList<SecureItem>();

	private Map<SecureAccess<?>, Permission> permissions = new HashMap<SecureAccess<?>, Permission>();

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	/**
	 * @return Returns the name.
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * @param name
	 *            The name to set.
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * @return Returns the parent.
	 */
	@ManyToOne
	public SecureItem getParent()
	{
		return parent;
	}

	/**
	 * @param parent
	 *            The parent to set.
	 */
	public void setParent(SecureItem parent)
	{
		this.parent = parent;
	}

	public void addChild(SecureItem child)
	{
		child.setParent(this);
		childs.add(child);
	}

	/**
	 * @return Returns the childs.
	 */
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(schema="naid_security")
	public List<SecureItem> getChilds()
	{
		return childs;
	}

	/**
	 * @param childs
	 *            The childs to set.
	 */
	public void setChilds(List<SecureItem> childs)
	{
		this.childs = childs;
	}

	/**
	 * @return the key is use for the security evaluation
	 */
	@Index(name = "securityKeyIndex")
	public String getSecurityKey()
	{
		if (securityKey == null)
		{
			StringBuffer key = new StringBuffer();

			if (parent != null)
			{
				key.append(parent.getSecurityKey()).append(":");
			}

			key.append(name);

			securityKey = key.toString();
		}

		return securityKey;
	}

	/**
	 * this key must be generated
	 * 
	 * @param securityKey
	 */
	public void setSecurityKey(String securityKey)
	{
		this.securityKey = securityKey;
	}

	/**
	 * @return Returns the permissions.
	 */
	@CollectionTypeInfo(name="com.netappsid.hibernate.LazyLoadMapType")
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinTable(schema="naid_security")
	@MapKey(name = "owner")
	public Map<SecureAccess<?>, Permission> getPermissions()
	{
		return permissions;
	}

	@Transient
	public List<Permission> getPermissionList()
	{
		return new DefaultObservableList<Permission>(new ArrayList<Permission>(permissions.values()));
	}

	public void setPermissionList(Collection<Permission> collection)
	{
		for (Permission permission : collection)
		{
			permissions.put(permission.getOwner(), permission);
		}
	}

	/**
	 * @param permissions
	 *            The permissions to set.
	 */
	public void setPermissions(Map<SecureAccess<?>, Permission> permissions)
	{
		this.permissions = permissions;
	}

	public void addPermission(Permission permission) throws SecurityException
	{
		if (permission.getOwner() == null)
		{
			throw new SecurityException("your permission must have an owner");
		}

		permission.setSecureItem(this);
		permissions.put(permission.getOwner(), permission);
	}

	public boolean hasPermission(SecureAccess<?> secureAccess)
	{
		if (permissions.containsKey(secureAccess))
		{
			return true;
		}
		else if (getParent() != null && !securityOverride)
		{
			return getParent().hasPermission(secureAccess);
		}
		else
		{
			return false;
		}
	}

	/**
	 * get permission for the associate SecureAcces if an user it get the user's group
	 * 
	 * @param secureAccess
	 * @return
	 */
	public Permission getPermission(SecureAccess<?> secureAccess)
	{
		if (securityOverride)
		{
			if (permissions.containsKey(secureAccess))
			{
				return permissions.get(secureAccess);
			}
			else if (secureAccess instanceof SecurityUser)
			{
				SecurityUser user = (SecurityUser) secureAccess;

				for (SecurityGroup group : user.getGroups())
				{
					if (permissions.containsKey(group))
					{
						return permissions.get(group);
					}
				}
			}

			return null;
		}
		else
		{
			Permission permission = null;

			if (permissions.containsKey(secureAccess))
			{
				permission = permissions.get(secureAccess);
			}
			else if (secureAccess instanceof SecurityUser)
			{
				SecurityUser user = (SecurityUser) secureAccess;

				for (SecurityGroup group : user.getGroups())
				{
					if (permissions.containsKey(group))
					{
						if (permission != null)
						{
							// if more than one group merge the permission
							permission = permission.merge(permissions.get(group));
						}
						else
						{
							permission = permissions.get(group);
						}
					}
				}
			}

			// get from parent
			if (permission == null && getParent() != null)
			{
				permission = getParent().getPermission(secureAccess);
			}

			return permission;
		}

	}

	public boolean hasChild()
	{
		return (childs != null && !childs.isEmpty());
	}

	/**
	 * @return Returns the securityOverride.
	 */
	public boolean isSecurityOverride()
	{
		return securityOverride;
	}

	/**
	 * @param securityOverride
	 *            The securityOverride to set.
	 */
	public void setSecurityOverride(boolean securityOverride)
	{
		this.securityOverride = securityOverride;
	}
	
	public void removeFromPermissionList(Permission permission)
	{
		permissions.remove(permission.getOwner());
		firePropertyChange("permissions", null, permissions);
		
	}

}
