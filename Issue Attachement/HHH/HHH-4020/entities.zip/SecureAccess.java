package com.netappsid.security.bo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.hibernate.annotations.Index;

import com.netappsid.annotations.UpperCase;
import com.netappsid.bo.Entity;
import com.netappsid.ejb3.annotation.EntityManager;

/**
 * 
 * @author xjodoin
 * @author NetAppsID inc.
 * 
 * @version $Revision: 1.1 $
 */
@javax.persistence.Entity
@Table(schema="naid_security")
@Inheritance(strategy=InheritanceType.JOINED)
public abstract class SecureAccess<T extends SecureAccess<?>> extends Entity<T>
{
	private static final long serialVersionUID = -7589578732584071717L;

	private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SecureAccess.class);

	// attributes
	private Long id;
	private String code;
	private String upperCode;
	private Long version;
	
	public static final String PROPERTYNAME_CODE = "code";
	
	//key -> securityKey of the secureItem
	private Map<String, SecureItem> permissions = new HashMap<String, SecureItem>();
	
	private List<Permission> permissionsToDeletes = new ArrayList<Permission>();

	private List<Permission> permissionList;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	/**
	 * @return Returns the name.
	 */
	@Index(name="codeIndex")
	@UpperCase(upperField="upperCode")
	public String getCode()
	{
		return code;
	}

	/**
	 * @param name
	 *            The name to set.
	 */
	public void setCode(String name)
	{
		this.code = name;
		firePropertyChange(PROPERTYNAME_CODE, null, name);
	}
	
	public boolean hasPermission(String securityKey)
	{
		if(permissions.containsKey(securityKey))
		{
			return true;
		}
		else if(securityKey.lastIndexOf(':') > 0)
		{
			return hasPermission(securityKey.substring(0,securityKey.lastIndexOf(':')));
		}
		else
		{
			return false;
		}
	}
	
	public boolean hasChildPermission(String securityKey)
	{
		Set<String> keySet = permissions.keySet();
		for (String key : keySet)
		{
			if(key.startsWith(securityKey))
			{
				return true;
			}
		}
		
		return false;
	}
	
	public SecureItem getSecureItem(String securityKey)
	{
		if(permissions.containsKey(securityKey))
		{
			return permissions.get(securityKey);
		}
		else if(securityKey.lastIndexOf(':') > 0)
		{
			return getSecureItem(securityKey.substring(0,securityKey.lastIndexOf(':')));
		}
		else
		{
			return null;
		}
	}
	
	/**
	 * @return Returns the permissions.
	 */
	@Transient
	public Map<String, SecureItem> getPermissions()
	{
		return permissions;
	}
	
	@Transient
	public List<Permission> getPermissionList()
	{
		if(permissionList==null)
		{
			permissionList = new ArrayList<Permission>();
			
			for (SecureItem item : permissions.values())
			{
				if(item.getPermission(this)!=null)
				{
					permissionList.add(item.getPermission(this));	
				}
				
			}
		}
		
		return permissionList;
	}

	/**
	 * @param permissions The permissions to set.
	 */
	public void setPermissions(Map<String, SecureItem> permissions)
	{
		this.permissions = permissions;
	}

	/**
	 * @return Returns the version.
	 */
	@Version
	public Long getVersion()
	{
		return version;
	}

	/**
	 * @param version The version to set.
	 */
	public void setVersion(Long version)
	{
		this.version = version;
	}
	
	public void removeFromPermissionList(Permission permission)
	{
		permissionsToDeletes.add(permission);
		permissions.remove(permission.getSecureItem().getSecurityKey());
		if(permissionList==null)
		{
			permissionList = getPermissionList();
		}
		permissionList.remove(permission);
		firePropertyChange("permissionList", null, permissionList);
	}
	
	@Transient
	public List<Permission> getPermissionsToDeletes()
	{
		return permissionsToDeletes;
	}

	public void setUpperCode(String upperCode)
	{
		this.upperCode = upperCode;
	}

	public String getUpperCode()
	{
		return upperCode;
	}
}
