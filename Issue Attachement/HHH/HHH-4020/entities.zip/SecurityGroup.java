package com.netappsid.security.bo;

import java.security.Principal;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;

import com.netappsid.annotations.DAO;
import com.netappsid.security.bo.dao.GroupDAO;

/**
 * @author xjodoin
 * @author NetAppsID inc.
 * 
 * @version $Revision: 1.1 $
 */
@Entity
@DAO(dao = GroupDAO.class)
@Table(schema="naid_security")
public class SecurityGroup extends SecureAccess<SecurityGroup> implements java.security.acl.Group
{
	private static final long serialVersionUID = -5025164960433296093L;

	private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SecurityGroup.class);

	public static final String PROPERTY_USERS = "users";

	private Set<SecurityUser> users;

	private Set<SecurityUserGroup> userGroups = new HashSet<SecurityUserGroup>();

	@Override
	public boolean addMember(Principal user)
	{
		throw new RuntimeException("create association with an UserGroup");
	}

	@Override
	public boolean isMember(Principal member)
	{
		return getUsers().contains((SecurityUser) member);
	}

	@Override
	public Enumeration<? extends Principal> members()
	{
		return Collections.enumeration(getUsers());
	}

	@Override
	public boolean removeMember(Principal user)
	{
		removeFromUsers((SecurityUser)user);
		return true;
	}

	/**
	 * @return Returns the users.
	 */
	@Transient
	public Set<SecurityUser> getUsers()
	{
		if(users==null)
		{
			users = new HashSet<SecurityUser>();
			
			for (SecurityUserGroup userGroup : userGroups)
			{
				users.add(userGroup.getUser());
			}
		}
		return users;
	}

	/**
	 * @param users
	 *            The users to set.
	 */
	public void setUsers(Set<SecurityUser> users)
	{
		Set<SecurityUser> old = this.users;
		this.users = users;
		firePropertyChange(PROPERTY_USERS, old, users);
	}

	public void removeFromUsers(SecurityUser user)
	{
		Iterator<SecurityUserGroup>iterator = userGroups.iterator();

		while (iterator.hasNext())
		{
			SecurityUserGroup userGroup = (SecurityUserGroup) iterator.next();
			
			if(userGroup.getUser().getId().equals(user.getId()))
			{
				iterator.remove();
				break;
			}
		}
		
		users.remove(user);
		firePropertyChange(PROPERTY_USERS, null, users);
	}

	/**
	 * @return Returns the userGroup.
	 */
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	@OneToMany(cascade=CascadeType.ALL , mappedBy = "group")
	public Set<SecurityUserGroup> getUserGroups()
	{
		return userGroups;
	}

	/**
	 * @param userGroup The userGroup to set.
	 */
	public void setUserGroups(Set<SecurityUserGroup> userGroup)
	{
		this.userGroups = userGroup;
	}

	/* (non-Javadoc)
	 * @see java.security.Principal#getName()
	 */
	@Override
	@Transient
	public String getName()
	{
		return getCode();
	}
}
