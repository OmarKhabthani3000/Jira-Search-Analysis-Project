package com.netappsid.security.bo;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.netappsid.ejb3.annotation.EntityManager;

@javax.persistence.Entity
@Table(schema="naid_security")
public class SecurityUserGroup implements Serializable
{
	private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SecurityUserGroup.class);

	@Embeddable
	public static class Id implements Serializable
	{
		@Column(name = "USERS_ID")
		private Long usersId;
		@Column(name = "GROUPS_ID")
		private Long groupsId;

		public Id()
		{}

		public Id(Long categoryId, Long itemId)
		{
			this.usersId = categoryId;
			this.groupsId = itemId;
		}

		public boolean equals(Object o)
		{
			if (o != null && o instanceof Id)
			{
				Id that = (Id) o;
				return this.usersId.equals(that.usersId) && this.groupsId.equals(that.groupsId);
			}
			else
			{
				return false;
			}
		}

		public int hashCode()
		{
			return usersId.hashCode() + groupsId.hashCode();
		}
	}

	@EmbeddedId
	private Id id = new Id();

	@ManyToOne
	private SecurityUser createBy;

	@Column(name = "ADDED_ON")
	private Date dateAdded = new Date();

	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name = "GROUPS_ID", insertable = false, updatable = false)
	private SecurityGroup group;

	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name = "USERS_ID", insertable = false, updatable = false)
	private SecurityUser user;

	public SecurityUserGroup()
	{}

	public SecurityUserGroup(SecurityUser createBy, SecurityUser user, SecurityGroup group)
	{
		// Set fields
		this.createBy = createBy;
		this.user = user;
		this.group = group;
		// Set identifier values
		this.id.usersId = user.getId();
		this.id.groupsId = group.getId();
		// Guarantee referential integrity
		user.getUserGroups().add(this);
		group.getUserGroups().add(this);
	}

	/**
	 * @return Returns the id.
	 */
	public Id getId()
	{
		return id;
	}

	/**
	 * @param id
	 *            The id to set.
	 */
	public void setId(Id id)
	{
		this.id = id;
	}

	/**
	 * @return Returns the dateAdded.
	 */
	public Date getDateAdded()
	{
		return dateAdded;
	}

	/**
	 * @param dateAdded
	 *            The dateAdded to set.
	 */
	public void setDateAdded(Date dateAdded)
	{
		this.dateAdded = dateAdded;
	}

	/**
	 * @return Returns the group.
	 */
	public SecurityGroup getGroup()
	{
		return group;
	}

	/**
	 * @param group
	 *            The group to set.
	 */
	public void setGroup(SecurityGroup group)
	{
		this.group = group;
	}

	/**
	 * @return Returns the user.
	 */
	public SecurityUser getUser()
	{
		return user;
	}

	/**
	 * @param user
	 *            The user to set.
	 */
	public void setUser(SecurityUser user)
	{
		this.user = user;
	}

	/**
	 * @return Returns the createBy.
	 */
	public SecurityUser getCreateBy()
	{
		return createBy;
	}

	/**
	 * @param createBy The createBy to set.
	 */
	public void setCreateBy(SecurityUser createBy)
	{
		this.createBy = createBy;
	}

}
