package org.hibernate.envers.bugs;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import org.hibernate.envers.Audited;

@Entity
@Audited
public class EntityA
{
  @GeneratedValue
  @Id
  private Integer id;

  private String data;

  @ManyToMany(targetEntity = EntityB.class)
  @JoinTable(name = "EntityA_mtmEntityBEntities_EntityB",
             joinColumns = @JoinColumn(name = "entityA"),
             inverseJoinColumns = @JoinColumn(name = "entityB"))
  private final Set<EntityB> mtmEntityBEntities = new HashSet<>();

  public EntityA()
  {
  }

  public EntityA(final String data)
  {
    this.data = data;
  }

  public Integer getId()
  {
    return id;
  }

  public void setId(Integer id)
  {
    this.id = id;
  }

  public String getData()
  {
    return data;
  }

  public void setData(String data)
  {
    this.data = data;
  }

  public Set<EntityB> getMtmEntityBEntities()
  {
    return mtmEntityBEntities;
  }

  public void setMtmEntityBEntities(Set<EntityB> mtmEntityBEntities)
  {
    if (mtmEntityBEntities == null)
    {
      throw new IllegalArgumentException("mtmEntityBEntities must be non-null");
    }

    if (this.mtmEntityBEntities.equals(mtmEntityBEntities))
    {
      return;
    }

    if (!this.mtmEntityBEntities.isEmpty())
    {
      final Set<EntityB> removed = new HashSet<>();

      for (Iterator<EntityB> it = this.mtmEntityBEntities.iterator(); it.hasNext();)
      {
        final EntityB value = it.next();

        if (!mtmEntityBEntities.contains(value))
        {
          it.remove();
          removed.add(value);
        }
      }

      for (final EntityB remove : removed)
      {
        remove.getMtmEntityAEntities().remove(this);
      }
    }

    for (final EntityB value : mtmEntityBEntities)
    {
      if (!this.mtmEntityBEntities.contains(value))
      {
        this.mtmEntityBEntities.add(value);
        value.getMtmEntityAEntities().add(this);
      }
    }
  }

  @Override
  public String toString()
  {
    return "EntityA(id = " + this.id + ", data = " + this.data + ")";
  }
}
