package org.hibernate.envers.bugs;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import org.hibernate.envers.Audited;

@Entity
@Audited
public class EntityB
{
  @GeneratedValue
  @Id
  private Integer id;

  private String data;

  @ManyToMany(targetEntity = EntityA.class, mappedBy = "mtmEntityBEntities")
  private final Set<EntityA> mtmEntityAEntities = new HashSet<>();

  public EntityB()
  {
  }

  public EntityB(final String data)
  {
    this.data = data;
  }

  public Integer getId()
  {
    return id;
  }

  public void setId(Integer id)
  {
    this.id = id;
  }

  public String getData()
  {
    return data;
  }

  public void setData(String data)
  {
    this.data = data;
  }

  public Set<EntityA> getMtmEntityAEntities()
  {
    return mtmEntityAEntities;
  }

  public void setMtmEntityAEntities(Set<EntityA> mtmEntityAEntities)
  {
    if (mtmEntityAEntities == null)
    {
      throw new IllegalArgumentException("mtmEntityAEntities must be non-null");
    }

    if (this.mtmEntityAEntities.equals(mtmEntityAEntities))
    {
      return;
    }

    if (!this.mtmEntityAEntities.isEmpty())
    {
      final Set<EntityA> removed = new HashSet<>();

      for (Iterator<EntityA> it = this.mtmEntityAEntities.iterator(); it.hasNext();)
      {
        final EntityA value = it.next();

        if (!mtmEntityAEntities.contains(value))
        {
          it.remove();
          removed.add(value);
        }
      }

      for (final EntityA remove : removed)
      {
        remove.getMtmEntityBEntities().remove(this);
      }
    }

    for (final EntityA value : mtmEntityAEntities)
    {
      if (!this.mtmEntityAEntities.contains(value))
      {
        this.mtmEntityAEntities.add(value);
        value.getMtmEntityBEntities().add(this);
      }
    }
  }

  @Override
  public String toString()
  {
    return "EntityB(id = " + this.id + ", data = " + this.data + ")";
  }
}
