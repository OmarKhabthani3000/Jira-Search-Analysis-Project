package org.hibernate.envers.bugs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Before;
import org.junit.Test;

public class MappedManyToManyEnversTestCase extends BaseCoreFunctionalTestCase
{
  @Override
  protected Class<?>[] getAnnotatedClasses()
  {
    return new Class<?>[] { EntityA.class, EntityB.class };
  }

  @Before
  public void beforeMethodOpenSession()
  {
    this.openSession();
  }

  @Test
  public void testASetsRelation()
  {
    final AuditReader reader = AuditReaderFactory.get(this.session);
    Integer aId;
    Integer bId;

    {
      final EntityA entityA = new EntityA("entityA");
      final EntityB entityB = new EntityB("entityB");

      this.session.beginTransaction();

      this.session.persist(entityA);
      this.session.persist(entityB);

      this.session.getTransaction().commit();

      aId = entityA.getId();
      bId = entityB.getId();
    }

    // Clear the session to ensure that loading occurs using hibernate proxies.
    // Without clear the objects would be fetched directly from the session, which is the original objects.
    this.session.clear();

    {
      this.session.beginTransaction();

      final EntityA entityA = this.session.load(EntityA.class, aId);
      final EntityB entityB = this.session.load(EntityB.class, bId);

      final Set<EntityB> entityBList = new HashSet<>();
      entityBList.add(entityB);

      // Use the A entity to set the relation.
      entityA.setMtmEntityBEntities(entityBList);

      this.session.getTransaction().commit();
    }

    {
      final List<Number> revisionsA = reader.getRevisions(EntityA.class, aId);
      final List<Number> revisionsB = reader.getRevisions(EntityB.class, bId);
      assertEquals(2, revisionsA.size());
      assertEquals(2, revisionsB.size());

      final EntityA revisionA = reader.find(EntityA.class, aId, revisionsA.get(1));
      assertEquals("entityA", revisionA.getData());
      assertEquals(1, revisionA.getMtmEntityBEntities().size());

      final EntityB revisionB = reader.find(EntityB.class, bId, revisionsB.get(1));
      //assertEquals("entityB", revisionB.getData());
      assertNull(revisionB.getData()); // TODO this should not be null!
      assertEquals(1, revisionB.getMtmEntityAEntities().size());
    }
  }

  @Test
  public void testBSetsRelation()
  {
    final AuditReader reader = AuditReaderFactory.get(this.session);
    Integer aId;
    Integer bId;

    {
      EntityA entityA = new EntityA("entityA2");
      EntityB entityB = new EntityB("entityB2");

      this.session.beginTransaction();

      this.session.persist(entityA);
      this.session.persist(entityB);

      this.session.getTransaction().commit();

      aId = entityA.getId();
      bId = entityB.getId();
    }

    this.session.clear();

    {
      this.session.beginTransaction();

      final EntityA entityA = this.session.load(EntityA.class, aId);
      final EntityB entityB = this.session.load(EntityB.class, bId);

      final Set<EntityA> entityASet = new HashSet<>();
      entityASet.add(entityA);

      // Use the B entity to set the relation.
      entityB.setMtmEntityAEntities(entityASet);

      this.session.getTransaction().commit();
    }

    {
      final List<Number> revisionsA = reader.getRevisions(EntityA.class, aId);
      final List<Number> revisionsB = reader.getRevisions(EntityB.class, bId);
      assertEquals(2, revisionsA.size());
      assertEquals(2, revisionsB.size());

      final EntityA revisionA = reader.find(EntityA.class, aId, revisionsA.get(1));
      assertEquals("entityA2", revisionA.getData());
      assertEquals(1, revisionA.getMtmEntityBEntities().size());

      final EntityB revisionB = reader.find(EntityB.class, bId, revisionsB.get(1));
      assertEquals("entityB2", revisionB.getData()); // This is not null, as expected!
      assertEquals(1, revisionB.getMtmEntityAEntities().size());
    }
  }
}
