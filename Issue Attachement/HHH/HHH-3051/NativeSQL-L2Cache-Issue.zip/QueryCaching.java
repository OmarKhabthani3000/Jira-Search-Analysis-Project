import java.util.List;
import java.util.Random;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

public class QueryCaching {

    public static void main(String[] args) throws Exception{
        int times = 30;
        long sleepTime = 3000;
        Session thisSession = getSession();
        boolean flushCache = false;
        
        fireNativeSql(session, flushCache);
        closeSession();
    }
    

    private static Session session;
    public static Session getSession(){
        if(session == null){
            System.out.println("Initializing session factory & getting session");
            HibernateSessionFactory.setConfigFile("caching.hibernate.cfg.xml");
            session = HibernateSessionFactory.getSession();
        }
        return session;
    }
    
    public static void closeSession(){
        if(session != null){
            System.out.println("Closing session.");
            session.close();
        }
    }


    private static void fireNativeSql(Session session, boolean flushCache){
        String sqlQuery = "select emp_id, emp_first_name from employee_mt";
        SQLQuery query = session.createSQLQuery(sqlQuery);
        query.setCacheable(true).setCacheRegion("TEST_REGION");
        query.addScalar("emp_id");
        query.addScalar("emp_first_name");
        List list = query.list();
        String counts = String.valueOf(list.size());
        System.out.println("NATIVE QUERY: Counts=" + counts);
    }

}
