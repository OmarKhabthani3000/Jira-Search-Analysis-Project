package com.example.hhh10905;

import com.example.hhh10905.model.Parent;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataBuilder;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.SessionFactoryBuilder;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Main implements AutoCloseable
{

    public static void main(final String[] arguments)
    {
        try (final Main main = new Main())
        {
            main.test();
        }
    }

    public Main()
    {
        final StandardServiceRegistryBuilder registryBuilder = new StandardServiceRegistryBuilder();
        registryBuilder.configure();
        final StandardServiceRegistry registry = registryBuilder.build();
        final MetadataSources metadataSources = new MetadataSources(registry);
        final MetadataBuilder metadataBuilder = metadataSources.getMetadataBuilder();
        final Metadata metadata = metadataBuilder.build();
        final SessionFactoryBuilder sessionFactoryBuilder = metadata.getSessionFactoryBuilder();
        this.sessionFactory = sessionFactoryBuilder.build();
    }

    private final SessionFactory sessionFactory;

    public void test()
    {
        final LockMode lockMode = null;
        try
        {
            try (final Session session = sessionFactory.openSession())
            {
                session.beginTransaction();
                session.get(Parent.class, 1L, lockMode);
            }
            try (final StatelessSession session = sessionFactory.openStatelessSession())
            {
                session.beginTransaction();
                session.get(Parent.class, 1L, lockMode);
            }
        } catch (final NullPointerException exception)
        {
            exception.printStackTrace(System.err);
        }
    }

    @Override
    public void close()
    {
        sessionFactory.close();
    }

}
