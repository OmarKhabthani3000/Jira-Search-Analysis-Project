package org.hibernate.bugs.domain;

public enum BottleSize {

	SMALL,
	LARGE;
}
