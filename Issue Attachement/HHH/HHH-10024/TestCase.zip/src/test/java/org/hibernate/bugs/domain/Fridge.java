package org.hibernate.bugs.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;

@Entity
public class Fridge {

	@OneToMany(cascade={CascadeType.ALL}) 
	private List<Bottle> bottles;
	@Id @GeneratedValue
	private Long id;


	public List<Bottle> getBottles() {
		return bottles;
	}

	public void setBottles(List<Bottle> bottles) {
		this.bottles = bottles;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
