package org.hibernate.bugs.domain;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class Bottle {

	@Enumerated(EnumType.STRING)
	private BottleSize size;
	
	@Enumerated(EnumType.STRING)
	private BottleSize otherNameThanSize;

	@Id @GeneratedValue
	private Long id;

	public BottleSize getSize() {
		return size;
	}
	
	public Bottle() {
		
	}
	
	public Bottle(BottleSize size) {
		setSize(size);
	}

	public void setSize(BottleSize size) {
		this.size = size;
		this.otherNameThanSize = size;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
