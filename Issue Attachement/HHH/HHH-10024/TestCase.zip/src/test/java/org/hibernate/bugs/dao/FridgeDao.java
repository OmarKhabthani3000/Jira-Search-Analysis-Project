package org.hibernate.bugs.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

import org.hibernate.bugs.domain.Bottle;
import org.hibernate.bugs.domain.BottleSize;
import org.hibernate.bugs.domain.Fridge;

public class FridgeDao {

	private EntityManager entityManager;

	public void saveFridge(Fridge fridge) {
		entityManager.persist(fridge);
	}

	/**
	 * Tries to join Fridge and Bottle and adds 
	 * where-criteria on Enum named "size".
	 * 
	 * Will fail in test.
	 */
	public List<Fridge> findBySize(BottleSize size) {
		//JPA
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Fridge> query =
				criteriaBuilder.createQuery(Fridge.class);
		Root<Fridge> fridgeRoot = query.from(Fridge.class);

		Path<BottleSize> path = 
				fridgeRoot.<Fridge,	Bottle>join("bottles")
				.<BottleSize>get("size"); 
		query.where(criteriaBuilder.equal(path, size));
		
		return entityManager.createQuery(query).getResultList();
	}

	/**
	 * Tries to join Fridge and Bottle and adds 
	 * where-criteria on Enum not named "size"
	 * 
	 * Will finish successfully.
	 */
	public List<Fridge> findByOtherNameThanSize(BottleSize size) {
		//JPA
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Fridge> query =
				criteriaBuilder.createQuery(Fridge.class);
		Root<Fridge> fridgeRoot = query.from(Fridge.class);

		Path<BottleSize> path = 
				fridgeRoot.<Fridge,	Bottle>join("bottles")
				.<BottleSize>get("otherNameThanSize"); 
		query.where(criteriaBuilder.equal(path, size));
		
		return entityManager.createQuery(query).getResultList();
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

}
