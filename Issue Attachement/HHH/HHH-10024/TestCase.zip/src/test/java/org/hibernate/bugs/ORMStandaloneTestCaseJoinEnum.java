package org.hibernate.bugs;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import org.hibernate.bugs.dao.FridgeDao;
import org.hibernate.bugs.domain.Bottle;
import org.hibernate.bugs.domain.BottleSize;
import org.hibernate.bugs.domain.Fridge;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a standalone test case for Hibernate ORM.  Although this is perfectly
 * acceptable as a reproducer, usage of ORMUnitTestCase is preferred!
 */
public class ORMStandaloneTestCaseJoinEnum {

	protected EntityManager entityManager = Persistence.createEntityManagerFactory("DefaultPersistenceUnit")
			.createEntityManager();

	protected FridgeDao fridgeDao = new FridgeDao();

	@Before
	public void setUp() {
		fridgeDao.setEntityManager(entityManager);

		entityManager.getTransaction().begin();
		
		Fridge fridge = new Fridge();
		Bottle bottle = new Bottle(BottleSize.LARGE);
		fridge.setBottles(Arrays.asList(bottle));

		fridgeDao.saveFridge(fridge);
	}
	
	@After
	public void tearDown() {
		if (entityManager.getTransaction().isActive())
			entityManager.getTransaction().rollback();
		entityManager.close();
	}

	@Test
	public void testFindBySize() {
		List<Fridge> fridge = fridgeDao.findBySize(BottleSize.LARGE);
		assertThat(fridge.size(), is(1));
	}
	
	@Test
	public void testFindByOtherNameThanSize() {
		List<Fridge> fridge = fridgeDao.findByOtherNameThanSize(BottleSize.LARGE);
		assertThat(fridge.size(), is(1));
	}
}
