/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * License: GNU Lesser General Public License (LGPL), version 2.1 or later.
 * See the lgpl.txt file in the root directory or <http://www.gnu.org/licenses/lgpl-2.1.html>.
 */
package org.hibernate.orm.test.annotations.inheritance;

import jakarta.persistence.*;
import org.hibernate.Hibernate;
import org.hibernate.testing.orm.junit.DomainModel;
import org.hibernate.testing.orm.junit.SessionFactory;
import org.hibernate.testing.orm.junit.SessionFactoryScope;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

@DomainModel(
        annotatedClasses = {
                ManyToOneWithInheritanceTest.SiteImpl.class,
                ManyToOneWithInheritanceTest.UserSiteImpl.class,
                ManyToOneWithInheritanceTest.BarImpl.class,
                ManyToOneWithInheritanceTest.BarBarImpl.class,
        }
)
@SessionFactory
public class ManyToOneWithInheritanceTest {

    private Site site;

    @Test
    public void testQuery(SessionFactoryScope scope) {
        scope.inTransaction(session -> {
            List<Bar> bars = session.createQuery("SELECT b FROM Bar b inner join b.site as site WHERE site = ?1")
                    .setParameter(1, site)
                    .list();
            BarImpl newBar = (BarImpl) bars.get(0);
            assertNotNull(newBar);
            assertNotNull(newBar.getSite());
            assertTrue(Hibernate.isInitialized(newBar.getSite()));
            assertEquals(site.getId(), newBar.getSite().getId());
        });
    }

    @BeforeEach
    public void setupData(SessionFactoryScope scope) {
        this.site = scope.fromTransaction(session -> {
            UserSiteImpl foo = new UserSiteImpl();
            foo.id = 1L;
            session.persist(foo);

            BarImpl bar = new BarImpl();
            bar.id = 1L;
            bar.setSite(foo);
            bar.setDetails("Some details");

            session.persist(bar);

            session.flush();

            assertNotNull(foo.getId());
            assertEquals(foo.getId(), bar.getSite().getId());

            return foo;
        });
    }

    @AfterEach
    public void cleanupData(SessionFactoryScope scope) {
        scope.inTransaction(session -> {
            session.delete(session.find(Site.class, site.getId()));
        });
        this.site = null;
    }

    public interface EntityWithId {

        Long getId();
    }

    public interface Site extends EntityWithId {

    }

    public interface UserSite extends Site {

    }

    @Entity
    @Access(AccessType.FIELD)
    @Inheritance(strategy = InheritanceType.SINGLE_TABLE)
    @DiscriminatorColumn(name = "TYPE", length = 20, discriminatorType = DiscriminatorType.STRING)
    public static abstract class SiteImpl implements Site {

        @Id
        protected Long id;

        private String name;

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            Site foo = (Site) o;
            return id.equals(foo.getId());
        }

        @Override
        public int hashCode() {
            return Objects.hash(id);
        }
    }

    @Entity
    @Access(AccessType.FIELD)
    @DiscriminatorValue("USER_SITE")
    public static class UserSiteImpl extends SiteImpl implements UserSite {
    }

    public interface Bar extends EntityWithId {

    }

    public interface SitedBar<S extends Site> extends Bar {

        S getSite();
    }

    @MappedSuperclass
    @Access(AccessType.FIELD)
    public static abstract class BarBarImpl<T extends Site> implements SitedBar<T> {

        @ManyToOne(fetch = FetchType.LAZY, targetEntity = SiteImpl.class)
        @JoinColumn(name = "BAR_ID")
        private T site;

        @Override
        public T getSite() {
            return site;
        }

        public void setSite(T site) {
            this.site = site;
        }

    }

    @Entity(name = "Bar")
    @Access(AccessType.FIELD)
    public static class BarImpl extends BarBarImpl<UserSite> implements Bar {

        @Id
        private Long id;

        private String details;

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getDetails() {
            return details;
        }

        public void setDetails(String details) {
            this.details = details;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            BarImpl bar = (BarImpl) o;
            return id.equals(bar.getId());
        }

        @Override
        public int hashCode() {
            return Objects.hash(id);
        }
    }
}
