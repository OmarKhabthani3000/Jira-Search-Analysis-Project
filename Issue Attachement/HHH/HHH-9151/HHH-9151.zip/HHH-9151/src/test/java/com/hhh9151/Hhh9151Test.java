package com.hhh9151;

import static org.junit.Assert.fail;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.RollbackException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class Hhh9151Test {

	private EntityManagerFactory emf;
	private EntityManager em;

	@Before
	public void setup() {
		emf = Persistence.createEntityManagerFactory("pu");
		em = emf.createEntityManager();
	}

	@After
	public void tearDown() {
		em.close();
		emf.close();
	}

	@Test(expected=RollbackException.class)
	public void shouldNotAllowToAssignTwoSourcesToOneTargetEntityInOneToOneRelationship() {
		
		// given
		EntityA firstSourceEntity = new EntityA();
		EntityA secondSourceEntity = new EntityA();
		EntityB targetEntity = new EntityB();
		
		firstSourceEntity.setEntityB(targetEntity);
		secondSourceEntity.setEntityB(targetEntity);
		
		// when
		em.getTransaction().begin();
		em.persist(targetEntity);
		em.persist(firstSourceEntity);
		em.persist(secondSourceEntity);
		em.getTransaction().commit();
		fail();
	}
}
