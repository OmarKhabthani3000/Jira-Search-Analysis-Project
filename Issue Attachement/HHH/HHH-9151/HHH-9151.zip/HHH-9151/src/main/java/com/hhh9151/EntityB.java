package com.hhh9151;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class EntityB {

	@Id
	@GeneratedValue(strategy=GenerationType.TABLE)
	private long id;
	
}
