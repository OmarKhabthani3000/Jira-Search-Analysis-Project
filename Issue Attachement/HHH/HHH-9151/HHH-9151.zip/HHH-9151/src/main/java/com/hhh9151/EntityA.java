package com.hhh9151;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class EntityA {
	
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE)
	private long id;
	
	@OneToOne
	private EntityB entityB;
	
	public void setEntityB(EntityB entityB) {
		this.entityB = entityB;
	}

}
