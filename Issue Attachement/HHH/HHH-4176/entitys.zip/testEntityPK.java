package entidades;

import java.io.Serializable;

public class testEntityPK implements Serializable {
	private Short a;
	
	private Short b;
	
	private Integer c;
}

