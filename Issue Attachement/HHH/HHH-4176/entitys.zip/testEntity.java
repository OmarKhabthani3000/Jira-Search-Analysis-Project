package entidades;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "test")
@IdClass(testEntityPK.class)
@SequenceGenerator(name = "test_seq", sequenceName = "test_seq", allocationSize = 1)		
public class testEntity implements Serializable {
	@Id
	private Short a;
	
	@Id
	private Short b;
	
	@Id@GeneratedValue(generator = "test_seq", strategy = GenerationType.SEQUENCE)
	private Integer c;

	private String d;

}

