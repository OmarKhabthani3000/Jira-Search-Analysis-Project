package com.myapp.entities;

import org.hibernate.envers.Audited;

@Audited
public class MyOtherEntity extends MyAbstractOtherEntity {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
