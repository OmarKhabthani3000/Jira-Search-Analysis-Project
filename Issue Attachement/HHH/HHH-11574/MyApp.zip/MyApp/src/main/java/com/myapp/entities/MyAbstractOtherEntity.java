package com.myapp.entities;

import org.hibernate.envers.Audited;

@Audited
public abstract class MyAbstractOtherEntity {

	private Integer id;
	private Integer type;
	private MyEntity myEntity;

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public MyEntity getMyEntity() {
		return myEntity;
	}

	public void setMyEntity(MyEntity myEntity) {
		this.myEntity = myEntity;
	}

}
