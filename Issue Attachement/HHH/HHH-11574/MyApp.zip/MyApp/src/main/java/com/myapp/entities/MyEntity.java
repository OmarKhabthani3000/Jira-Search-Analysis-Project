package com.myapp.entities;

import java.util.List;

import org.hibernate.envers.AuditMappedBy;
import org.hibernate.envers.Audited;

@Audited
public class MyEntity {

	private Integer id;
	private String name;

	@AuditMappedBy(mappedBy = "myEntity")
	private List<MyOtherEntity> myOtherEntities;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<MyOtherEntity> getMyOtherEntities() {
		return myOtherEntities;
	}

	public void setMyOtherEntities(List<MyOtherEntity> myOtherEntities) {
		this.myOtherEntities = myOtherEntities;
	}

}
