package com.myapp.services;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.myapp.entities.MyEntity;
import com.myapp.entities.MyOtherEntity;

@Service
public class MyService {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private PlatformTransactionManager transactionManager;

	public void reproduceIssue() {
		MyEntity entity = new MyEntity();
		entity.setId(1);
		entity.setName("my entity");

		MyOtherEntity otherEntity = new MyOtherEntity();
		otherEntity.setId(2);
		otherEntity.setName("my other entity");
		otherEntity.setMyEntity(entity);

		TransactionStatus txStatus = transactionManager
				.getTransaction(new DefaultTransactionDefinition(TransactionDefinition.PROPAGATION_REQUIRES_NEW));

		entityManager.persist(entity);
		entityManager.persist(otherEntity);
		transactionManager.commit(txStatus);

		System.out.println(entity);
	}

}
