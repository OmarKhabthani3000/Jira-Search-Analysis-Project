package org.hibernate.test.noid;

import junit.framework.Test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;
import org.hibernate.test.deletetransientmn.DeleteTransientEntityMNTest;

public class NoIdTest  extends FunctionalTestCase {

    public NoIdTest(String string) {
        super(string);
    }

    public String[] getMappings() {
        return new String[] { "noid/Thing.hbm.xml" };
    }

    public static Test suite() {
        return new FunctionalTestClassTestSuite( DeleteTransientEntityMNTest.class );
    }

    /**
     * Test case for http://opensource.atlassian.com/projects/hibernate/browse/HHH-2605
     *
     */
    public void testBug2605() {
        Session s = openSession();
        Transaction t = s.beginTransaction();

        
        Thing thing = new Thing();

        s.save( thing );


        t.rollback();
        
        s.close();
    }

}
