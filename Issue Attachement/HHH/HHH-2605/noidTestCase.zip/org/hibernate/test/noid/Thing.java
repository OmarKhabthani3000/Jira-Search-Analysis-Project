package org.hibernate.test.noid;

public class Thing {

    private Long id;

    public Long getId() {
    	return id;
    }

    public void setId(Long id) {
    	this.id = id;
    }

}
