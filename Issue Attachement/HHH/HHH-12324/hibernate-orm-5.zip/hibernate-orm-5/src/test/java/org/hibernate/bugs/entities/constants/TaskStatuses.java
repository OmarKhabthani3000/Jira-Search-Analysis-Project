package org.hibernate.bugs.entities.constants;

public enum TaskStatuses {
    CREATED(1),
    APPROVED(2),
    IN_PROGRESS(3),
    COMPLETED(4),

    REJECTED(100),
    ;

    private Integer id;

    TaskStatuses(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public static TaskStatuses valueOf(Integer id) {
        for (TaskStatuses value : values())
            if (value.getId().equals(id))
                return value;
        return null;
    }
}