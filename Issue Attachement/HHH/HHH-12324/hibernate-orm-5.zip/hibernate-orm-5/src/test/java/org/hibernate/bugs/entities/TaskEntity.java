package org.hibernate.bugs.entities;

import org.hibernate.bugs.entities.constants.TaskStatuses;
import org.hibernate.bugs.entities.converters.TaskStatusesConverter;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "tasks")
public class TaskEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String title;

    private String description;

    @Convert(converter = TaskStatusesConverter.class)
    private TaskStatuses status;

    @ManyToMany
    @JoinTable(
        name = "tasks_users",
        joinColumns = @JoinColumn(name = "task_id", referencedColumnName = "id"),
        inverseJoinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"),
        foreignKey = @ForeignKey(name = "none", value = ConstraintMode.NO_CONSTRAINT),
        inverseForeignKey = @ForeignKey(name = "none", value = ConstraintMode.NO_CONSTRAINT))
    private Set<UserEntity> involvedUsers;
}