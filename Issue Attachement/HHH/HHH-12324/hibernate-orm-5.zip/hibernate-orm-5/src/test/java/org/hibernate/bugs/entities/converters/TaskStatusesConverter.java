package org.hibernate.bugs.entities.converters;

import org.hibernate.bugs.entities.constants.TaskStatuses;

import javax.persistence.AttributeConverter;

public class TaskStatusesConverter implements AttributeConverter<TaskStatuses, Integer> {

    @Override
    public Integer convertToDatabaseColumn(TaskStatuses status) {
        return status.getId();
    }

    @Override
    public TaskStatuses convertToEntityAttribute(Integer status) {
        return TaskStatuses.valueOf(status);
    }
}