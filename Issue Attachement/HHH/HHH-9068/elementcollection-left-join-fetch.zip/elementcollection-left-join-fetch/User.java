import java.util.HashSet;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;

/**
 * <br>@author bingo
 * <br>2013-4-25
 * <br>@version
 */
@Entity
@Table(name = "T_SEC_User")
@SecondaryTable(name = "T_SEC_UserAccount", pkJoinColumns = { @PrimaryKeyJoinColumn(name = "userId") })
public class User {

	private static final long serialVersionUID = 1346363505539059955L;

	@Column(name = "userSecurityStrategyId")
	private String userSecurityStrategyId;

	@Column(name = "withPersonId")
	private String withPersonId;

	@Column(name = "masterPartyId")
	private String masterPartyId;

	@ElementCollection(fetch = FetchType.LAZY)
	@CollectionTable(name = "T_SEC_User_Party_Role",joinColumns={@JoinColumn(name = "userId")})
	private Set<UserPartyRole> userPartyRoles = new HashSet<UserPartyRole>();

	@Column(name = "timeZoneId")
	private String timeZoneId;

	@Column(name = "localeSign")
	private String localeSign;

	@Column(name = "secMailAddress")
	private String secMailAddress;

	@Column(name = "secMobileNumber")
	private String secMobileNumber;

	@Column(name = "systemDefault")
	private boolean systemDefault = false;

	/**
	 * @return the withPersonId
	 */
	public String getWithPersonId() {
		return withPersonId;
	}

	/**
	 * @return the masterPartyId
	 */
	public String getMasterPartyId() {
		return masterPartyId;
	}

	/**
	 * @return the userSecurityStrategy
	 */
	public UserSecurityStrategy obtainUserSecurityStrategy() {
		return null;
	}

	/**
	 * @return the userSecurityStrategy
	 */
	public String getUserSecurityStrategyId() {
		return userSecurityStrategyId;
	}

	/**
	 * @return the timeZoneId
	 */
	public String getTimeZoneId() {
		return timeZoneId;
	}

	/**
	 * @return the localeSign
	 */
	public String getLocaleSign() {
		return localeSign;
	}

	/**
	 * @return the userPartyRoles
	 */
	public Set<UserPartyRole> getUserPartyRoles() {
		return userPartyRoles;
	}

	/**
	 * @return the secMailAccount
	 */
	public String getSecMailAddress() {
		return secMailAddress;
	}

	/**
	 * @return the secMobileNumber
	 */
	public String getSecMobileNumber() {
		return secMobileNumber;
	}

	public boolean isSystemDefault() {
		return systemDefault;
	}

	public void setSystemDefault(boolean systemDefault) {
		this.systemDefault = systemDefault;
	}

	/**
	 * @param userPartyRoles the userPartyRoles to set
	 */
	protected void setUserPartyRoles(Set<UserPartyRole> userPartyRoles) {
		if (this.userPartyRoles != null)
			this.userPartyRoles.clear();
		else
			this.userPartyRoles = new HashSet<UserPartyRole>();
		if (!CollectionUtils.isEmpty(userPartyRoles))
			this.userPartyRoles.addAll(userPartyRoles);
	}

	/**
	 * @param withPersonId the withPersonId to set
	 */
	protected void setWithPersonId(String withPersonId) {
		this.withPersonId = withPersonId;
	}

	/**
	 * @param masterPartyId the masterPartyId to set
	 */
	protected void setMasterPartyId(String masterPartyId) {
		this.masterPartyId = masterPartyId;
	}


	/**
	 * @param userSecurityStrategyId the userSecurityStrategyId to set
	 */
	protected void setUserSecurityStrategyId(String userSecurityStrategyId) {
		this.userSecurityStrategyId = userSecurityStrategyId;
	}

	/**
	 * @param timeZoneId the timeZoneId to set
	 */
	protected void setTimeZoneId(String timeZoneId) {
		this.timeZoneId = timeZoneId;
	}

	/**
	 * @param localeSign the localeSign to set
	 */
	protected void setLocaleSign(String localeSign) {
		this.localeSign = localeSign;
	}

	/**
	 * @param secMailAccount the secMailAccount to set
	 */
	protected void setSecMailAddress(String secMailAddress) {
		this.secMailAddress = secMailAddress;
	}

	/**
	 * @param secMobileNumber the secMobileNumber to set
	 */
	protected void setSecMobileNumber(String secMobileNumber) {
		this.secMobileNumber = secMobileNumber;
	}

}
