
/**
 * 
 * @author bingo <br>
 * 2013-6-17 <br>
 * @version
 */
@Embeddable
public class UserPartyRole {

	/**
	 * ���ƣ�serialVersionUID ���ͣ�long ��ע��
	 */
	private static final long serialVersionUID = 1502825051129774164L;

	@Column(name = "partyId", length = 32)
	private String partyId;

	@ManyToOne(cascade = CascadeType.DETACH,fetch=FetchType.EAGER)
	@JoinColumn(name = "roleId")
	private Role role;

	public UserPartyRole() {

	}

	/**
	 * @param partyId
	 * @param role
	 */
	public UserPartyRole(String partyId, Role role) {
		super();
		this.setPartyId(partyId);
		this.setRole(role);
	}

	/**
	 * @return the partyId
	 */
	public String getPartyId() {
		return partyId;
	}

	public Role getRole() {
		return role;
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getPartyId() == null) ? 0 : getPartyId().hashCode());
		result = prime * result + ((getRole() == null) ? 0 : getRole().hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof UserPartyRole))
			return false;
		UserPartyRole other = (UserPartyRole) obj;
		if (getPartyId() == null) {
			if (other.getPartyId() != null)
				return false;
		} else if (!getPartyId().equals(other.getPartyId()))
			return false;
		if (getRole() == null) {
			if (other.getRole() != null)
				return false;
		} else if (!getRole().equals(other.getRole()))
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UserPartyRole [partyId=" + getPartyId() + ", role=" + getRole() + "]";
	}

	/**
	 * @param partyId
	 *            the partyId to set
	 */
	protected void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	protected void setRole(Role role) {
		this.role = role;
	}
}
