
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.springframework.util.CollectionUtils;

/**
 * 
 * <br>@author bingo
 * <br>2013-6-27
 * <br>@version
 */
@Entity
@Table(name = "T_SEC_Role")
public class Role {

	/**
	 */
	private static final long serialVersionUID = 1L;

	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name = "T_SEC_RolePermission", joinColumns = { @JoinColumn(name = "roleId") })
	private Set<RolePermission> permissions = new HashSet<RolePermission>();

	/**
	 */
	@Column(name = "systemDefault")
	private boolean systemDefault = false;

	@Override
	public String getName() {
		return super.getName();
	}

	public void setName(String name) {
		super.setName(name);
	}

	public Set<RolePermission> getPermissions() {
		return permissions == null ? new HashSet<RolePermission>() : Collections.unmodifiableSet(permissions);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 */
	@Override
	public void setRemark(String remark) {
		super.setRemark(remark);
	}

	public void setPermissions(Set<RolePermission> permissions) {
		if (this.getId() != null) {
			Set<String> oldPermissionKeys = new HashSet<String>();
			Set<String> newPermissionKeys = new HashSet<String>();
			for (RolePermission rp : permissions)
				newPermissionKeys.add(rp.getPermissionKey());
			for (RolePermission rp : this.getPermissions())
				oldPermissionKeys.add(rp.getPermissionKey());
		}
		if (this.permissions != null)
			this.permissions.clear();
		else
			this.permissions = new HashSet<RolePermission>();
		if (!CollectionUtils.isEmpty(permissions))
			this.permissions.addAll(permissions);
	}

	public void removePermission(RolePermission permission) {
		if (permission != null)
			if (permissions != null && permissions.contains(permission))
				permissions.remove(permission);
	}

	public void disable() {
		super.disable();
		if (this.getId() != null)
			occurDomainEvent(new RoleDisabledEvent());
	}


	public boolean isSystemDefault() {
		return systemDefault;
	}

	public void setSystemDefault(boolean systemDefault) {
		this.systemDefault = systemDefault;
	}
}
