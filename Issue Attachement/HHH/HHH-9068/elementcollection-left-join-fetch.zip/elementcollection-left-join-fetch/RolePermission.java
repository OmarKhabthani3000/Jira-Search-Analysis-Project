
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Embeddable;


/**
 * <br>@author luyangbin
 * <br>2013-6-18
 * <br>@version
 */
@Embeddable
public class RolePermission{

	private static final long serialVersionUID = 1616865746541549333L;

	@Column(name = "permissionKey", length = 512)
	private String permissionKey;

	@Column(name = "permissionStrategies")
	private String permissionStrategies;

	public RolePermission() {
		super();
	}

	/**
	 * @param permissionKey
	 * @param permissionStrategies
	 */
	protected RolePermission(String permissionKey, String permissionStrategies) {
		super();
		this.setPermissionKey(permissionKey);
		this.setPermissionStrategies(permissionStrategies);
	}

	/**
	 * @return the permissionKey
	 */
	public String getPermissionKey() {
		return permissionKey;
	}

	/**
	 * @return the permissionStrategies
	 */
	public String getPermissionStrategies() {
		return permissionStrategies;
	}

	public Set<RolePermissionStrategy> getPermissionStrategiesSet() {
		return Collections.unmodifiableSet(getInnerPermissionStrategiesSet());
	}

	/**
	 * @param permissionKey the permissionKey to set
	 */
	public void setPermissionKey(String permissionKey) {
		this.permissionKey = permissionKey;
	}

	/**
	 * @param permissionStrategies the permissionStrategies to set
	 */
	public void setPermissionStrategies(String permissionStrategies) {
		this.permissionStrategies = permissionStrategies;
	}

	public void setPermissionStrategiesSet(Set<RolePermissionStrategy> rps) {
		if (!CollectionUtils.isEmpty(rps)) {
			this.setPermissionStrategies(SerializerUtils.serializeObj2JsonStr(rps));
		} else {
			this.setPermissionStrategies(null);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getPermissionKey() == null) ? 0 : getPermissionKey().hashCode());
		result = prime * result + ((getPermissionStrategies() == null) ? 0 : getPermissionStrategies().hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof RolePermission))
			return false;
		RolePermission other = (RolePermission) obj;
		if (getPermissionKey() == null) {
			if (other.getPermissionKey() != null)
				return false;
		} else if (!getPermissionKey().equals(other.getPermissionKey()))
			return false;
		if (getPermissionStrategies() == null) {
			if (other.getPermissionStrategies() != null)
				return false;
		} else if (!getPermissionStrategies().equals(other.getPermissionStrategies()))
			return false;
		return true;
	}

}
