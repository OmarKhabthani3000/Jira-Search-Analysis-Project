package org.hibernate.test;

public enum ContactTypeEnum {
    INDIVIDU,
    ETAB,
    TIERS;

}
