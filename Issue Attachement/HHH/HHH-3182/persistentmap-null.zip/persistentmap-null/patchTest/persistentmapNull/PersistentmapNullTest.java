// $Id: RefreshTest.java 10976 2006-12-12 23:22:26Z steve.ebersole@jboss.com $
package patchTest.persistentmapNull;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import junit.framework.Test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;


/**
 * Implementation of test for patch not-found-keep.
 * 
 * @author Heinz Huber
 */
public class PersistentmapNullTest extends FunctionalTestCase {
    
    public PersistentmapNullTest( String name ) {
        super( name );
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see FunctionalTestCase#getBaseForMappings()
     */
    public String getBaseForMappings() {
        return "patchTest/";
    }
    
    public String[] getMappings() {
        return new String[] { "persistentmapNull/mapping.hbm.xml" };
    }
    
    public static Test suite() {
        return new FunctionalTestClassTestSuite( PersistentmapNullTest.class );
    }
    
    public void testPersistentmapNull() throws Throwable {
        Session session = openSession();
        Transaction txn = session.beginTransaction();
        
        Map map = new HashMap();
        map.put( "filled", "value" );
        map.put( "empty", null );
        PersistentmapNull obj = new PersistentmapNull( map );
        session.persist( obj );
        session.flush();
        check( "inserted", map, obj.getData() );
        
        session.clear();
        check( "loaded", map, ( (PersistentmapNull) session.get( PersistentmapNull.class, obj.getId() ) ).getData() );
        
        txn.rollback();
        session.close();
    }
    
    public void check( String id, Map test, Map check ) {
        assertTrue( id, test.keySet().containsAll( check.keySet() ) );
        for ( Iterator it = test.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry entry = (Map.Entry) it.next();
            assertEquals( id + " " + entry.getKey(), entry.getValue(), check.get( entry.getKey() ) );
        }
    }
}
