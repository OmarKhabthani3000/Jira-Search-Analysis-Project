package patchTest.persistentmapNull;

import java.util.Map;


public class PersistentmapNull {
    private Long id;
    
    private Map  data;
    
    public PersistentmapNull() {
        super();
    }
    
    public PersistentmapNull( Map data ) {
        super();
        this.data = data;
    }
    
    public Map getData() {
        return data;
    }
    
    public void setData( Map data ) {
        this.data = data;
    }
    
    public Long getId() {
        return id;
    }
    
    public void setId( Long id ) {
        this.id = id;
    }
    
}
