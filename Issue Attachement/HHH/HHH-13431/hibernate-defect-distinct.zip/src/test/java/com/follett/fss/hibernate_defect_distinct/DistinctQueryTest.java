package com.follett.fss.hibernate_defect_distinct;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLNonTransientConnectionException;
import java.sql.Statement;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.commons.io.FileUtils;
import org.apache.derby.jdbc.EmbeddedDriver;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.jpa.QueryHints;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class DistinctQueryTest {
	
	private static File dbDir;
	private static String dbUrl;
	
	private EntityManagerFactory entityManagerFactory;
	private EntityManager entityManager;
	
	@BeforeClass
	public static void beforeClass() throws Exception {

		BasicConfigurator.configure();
		Logger.getRootLogger().setLevel(Level.ERROR);
		
		dbDir = new File(System.getProperty("java.io.tmpdir"), DistinctQueryTest.class.getSimpleName());
		dbUrl = "jdbc:derby:" + dbDir.getAbsolutePath();

		try (Connection connection = DriverManager.getConnection(dbUrl + ";create=true")) {
			createTable(connection);
		}
	}
	
	@AfterClass
	public static void afterClass() throws Exception {

		try (Connection connection = DriverManager.getConnection(dbUrl + ";shutdown=true")) {
		}
		catch (SQLNonTransientConnectionException e) {
			// somehow this is expected
		}
		finally {
			FileUtils.deleteDirectory(dbDir);
		}
	}
	
	private static void createTable(Connection connection) throws SQLException {
		
		StringBuilder sql = new StringBuilder();
		sql.append("CREATE TABLE " + TestEntity.TABLE_NAME + " (");
		sql.append("	" + TestEntity.FIELD_NAME_ID + " BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),");
		sql.append("	" + TestEntity.FIELD_NAME_STRING_FIELD + " VARCHAR(64),");
		sql.append("	" + TestEntity.FIELD_NAME_BINARY_FIELD + " BLOB(1024)");
		sql.append(")");
		
		try (Statement statement = connection.createStatement()) {
			statement.executeUpdate(sql.toString());
		}
	}
	
	private static EntityManagerFactory createEntityManagerFactory(String persistenceUnitName) {
		
		Properties properties = new Properties();
		properties.setProperty("javax.persistence.jdbc.driver", EmbeddedDriver.class.getName());
		properties.setProperty("javax.persistence.jdbc.url", dbUrl);
		
		return Persistence.createEntityManagerFactory(persistenceUnitName, properties);
	}
	
	@After
	public void after() throws Exception {
		if (entityManager != null) {
			entityManager.close();
		}
		if (entityManagerFactory != null) {
			entityManagerFactory.close();
		}
	}
		
	@Test
	public void testWithoutComments() {
		// sets hibernate.use_sql_comments=false in persistence.xml
		// will pass
		this.test("without-comments");
	}
	
	@Test
	public void testWithComments() {
		// sets hibernate.use_sql_comments=true in persistence.xml
		// will fail
		this.test("with-comments");
	}

	private void test(String persistenceUnitName) {

		entityManagerFactory = createEntityManagerFactory(persistenceUnitName);
		entityManager = entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();

		try {
			this.insertEntity();
	
			try {

				// If 'distinct' is passed to the DB, it will error out because we're including a blob field
				TypedQuery<TestEntity> query = entityManager.createQuery("select distinct te from TestEntity te", TestEntity.class);
				
				// This *should* generate SQL without 'distinct'
				query.setHint(QueryHints.HINT_PASS_DISTINCT_THROUGH, false);
				
				// This will fail if the DB query has 'distinct' in it
				Assert.assertEquals(1, query.getResultList().size());
			}
			finally {
				this.cleanupEntities();
			}
			
			entityManager.getTransaction().commit();
		}
		catch (RuntimeException e) {
			entityManager.getTransaction().rollback();
			throw e;
		}
	}
	
	private void insertEntity() {
		
		final String value = String.valueOf(System.currentTimeMillis());
		
		TestEntity entity = new TestEntity();
		entity.setStringField(value);
		entity.setBinaryField(value.getBytes());

		
		entityManager.persist(entity);
		entityManager.flush();
	}
	
	private void cleanupEntities() {
		Query query = entityManager.createQuery("delete from TestEntity");
		query.executeUpdate();
		entityManager.flush();
	}
}
