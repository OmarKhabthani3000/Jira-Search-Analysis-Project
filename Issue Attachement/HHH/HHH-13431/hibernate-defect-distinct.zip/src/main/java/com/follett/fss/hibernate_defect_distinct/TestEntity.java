package com.follett.fss.hibernate_defect_distinct;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name=TestEntity.TABLE_NAME)
public class TestEntity {
	
	public static final String TABLE_NAME = "TEST";
	public static final String FIELD_NAME_ID = "ID";
	public static final String FIELD_NAME_STRING_FIELD = "STRING_FIELD";
	public static final String FIELD_NAME_BINARY_FIELD = "BINARY_FIELD";
	

	@Id
	@Column(name=FIELD_NAME_ID)
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(name=FIELD_NAME_STRING_FIELD)
	private String stringField;
	
	@Column(name=FIELD_NAME_BINARY_FIELD)
	@Lob
	private byte[] binaryField;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStringField() {
		return stringField;
	}

	public void setStringField(String stringField) {
		this.stringField = stringField;
	}

	public byte[] getBinaryField() {
		return binaryField;
	}

	public void setBinaryField(byte[] binaryField) {
		this.binaryField = binaryField;
	}
}
