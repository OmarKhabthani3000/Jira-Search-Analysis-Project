package org.hibernate.issue.hhh3538;

import java.util.List;
import org.hibernate.*;
import org.hibernate.cfg.AnnotationConfiguration;
import org.junit.*;
import static org.hibernate.criterion.Restrictions.*;
import static org.junit.Assert.*;
/**
 *
 */
public class HHH3538Test {

    @Test
    public void testIssue() throws Exception {
        SessionFactory sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
        // Create data set
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        Country country1 = new Country("France");
        session.save(country1);
        Country country2 = new Country("Espana");
        session.save(country2);
        Customer customer1 = new Customer("Dupont", country1);
        session.save(customer1);
        Customer customer2 = new Customer("Gonzalez", country2);
        session.save(customer2);
        Customer customer3 = new Customer("Durand", country1);
        session.save(customer3);
        tx.commit();
        session.close();
        // Execute QL query: OK
        session = sessionFactory.openSession();
        Query query=session.createQuery("select c from Customer c where c.country.name= :countryName");
        query.setString("countryName", "France");
        List<Customer> customers=query.list();
        session.close();
        // Check result
        assertCountryNotInitialized(customers);
        // Execute Critery query: KO
        session = sessionFactory.openSession();
        Criteria customerCrit=session.createCriteria(Customer.class);
        customerCrit.createCriteria("country").add(eq("name", "France"));
        customers=customerCrit.list();
        session.close();
        // Check result
        assertCountryNotInitialized(customers);
    }
    private void assertCountryNotInitialized(List<Customer> customers) {
        assertFalse(customers.isEmpty());
        try {
            for(Customer customer:customers) {
                customer.getCountry().getName();
            }
            fail("Expected lazy initialization exception");
        } catch(Exception exc) {
            // It's OK
        }
    }
}
