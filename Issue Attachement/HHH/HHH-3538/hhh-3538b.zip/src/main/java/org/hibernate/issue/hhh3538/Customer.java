package org.hibernate.issue.hhh3538;

import java.io.Serializable;
import javax.persistence.*;

/**
 *
 */
@Entity
public class Customer implements Serializable {
    @Id @GeneratedValue
    private Integer id;
    private String name;
    @ManyToOne(fetch=FetchType.LAZY)
    private Country country;

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }
    
    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Customer() {
    }

    public Customer(String name, Country country) {
        this.name = name;
        this.country = country;
    }

}
