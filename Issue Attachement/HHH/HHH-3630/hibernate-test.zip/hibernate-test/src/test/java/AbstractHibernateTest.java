import junit.framework.TestCase;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

/**
 * @author Daniel Wiell
 * @author Gino Miceli
 */
public abstract class AbstractHibernateTest extends TestCase {
    protected Session session;
    protected SessionFactory sessionFactory;

    @Override
    protected void setUp() throws Exception {
        sessionFactory = new Configuration().configure().buildSessionFactory();
        setupTables();
        fillTables();
        this.session = sessionFactory.openSession();
        this.session.beginTransaction();
    }

    @Override
    protected void tearDown() throws Exception {
        dropTables();
        this.session.getTransaction().rollback();
        if (session != null) session.close();
        sessionFactory.close();
    }

    private void setupTables() {
        Session session = sessionFactory.openSession();
        try {
            session.createSQLQuery("\n" +
                    "create table car (\n" +
                    "   id          bigint          not null identity,\n" +
                    "   make        varchar(200)    not null,\n" +
                    "   model       varchar(200)    not null,\n" +
                    "   engine_make  varchar(200)    not null,\n" +
                    "   engine_model varchar(200)    not null,\n" +
                    "   constraint pk_car primary key (id)\n" +
                    ");\n").executeUpdate();
            session.createSQLQuery("\n" +
                    "create table engine_mount (\n" +
                    "   car_id      bigint          not null,\n" +
                    "   part_name   varchar(200)    not null,\n" +
                    "   part        varchar(200)    not null,\n" +
                    "   constraint pk_part primary key (car_id, part_name, part)\n" +
                    ");\n").executeUpdate();
        } finally {
            session.close();
        }
    }

    private void dropTables() {
        Session session = sessionFactory.openSession();
        try {
            session.createSQLQuery("drop table engine_mount;").executeUpdate();
            session.createSQLQuery("drop table car;").executeUpdate();
        } finally {
            session.close();
        }
    }

    private void fillTables() {
        Session session = sessionFactory.openSession();
        try {
            session.createSQLQuery("insert into car values (1, 'Mazda', 'MX-6', 'Mazda', 'KL-DE 2.5');").executeUpdate();
            session.createSQLQuery("insert into car values (2, 'Ford', 'Probe GT', 'Mazda', 'KL-DE 2.5');").executeUpdate();
            session.createSQLQuery("insert into engine_mount values (1, 'Frame bracket', 'jp-2324-987');").executeUpdate();
            session.createSQLQuery("insert into engine_mount values (1, 'Mount bolt', 'jp-123-x');").executeUpdate();
            session.createSQLQuery("insert into engine_mount values (2, 'Frame bracket', 'us-2324-987');").executeUpdate();
            session.createSQLQuery("insert into engine_mount values (2, 'Mount bolt', 'jp-123-x');").executeUpdate();
        } finally {
            session.close();
        }
    }
}
