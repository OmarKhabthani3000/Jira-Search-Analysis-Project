/**
 * @author Gino Miceli
 */
@SuppressWarnings("unchecked")
public class HibernateTest extends AbstractHibernateTest {

	public void testNormalQuery() {
		Car car = (Car) session.createQuery("select car from Car car where car.id=1").uniqueResult();
		assertNotNull(car.getEngine().getMountParts());
	}

	public void testComponentQuery() {
		Engine engine = (Engine) session.createQuery("select car.engine from Car car where car.id=1").uniqueResult();
		assertNotNull(engine.getMountParts());
	}

}
