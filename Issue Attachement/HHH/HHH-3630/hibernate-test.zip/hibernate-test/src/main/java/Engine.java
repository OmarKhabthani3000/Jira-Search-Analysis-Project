import java.util.Map;

/**
 * @author Gino Miceli
 */
public class Engine {
	private String make;
	private String model;
	private Map<String, String> mountParts;

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Map<String, String> getMountParts() {
		return mountParts;
	}

	public void setMountParts(Map<String, String> parts) {
		this.mountParts = parts;
	}
}
