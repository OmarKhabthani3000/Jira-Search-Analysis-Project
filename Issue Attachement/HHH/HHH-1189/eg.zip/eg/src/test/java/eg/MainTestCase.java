package eg;

import junit.framework.TestCase;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class MainTestCase extends TestCase
{
    public void test()
    {
        final Configuration cfg = new Configuration();
        cfg.configure();
        final SessionFactory sessionFactory = cfg.buildSessionFactory();
        // this throws the following:
        // org.hibernate.MappingException: proxy must be either an interface, or the class itself: eg.DoctorImpl
        // if code is patched, all works well
        Session session = null;
        Transaction transaction = null;
        try {
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();
            final DoctorImpl doctor = new DoctorImpl("Doctor");
            session.persist(doctor);
            transaction.commit();
            transaction = null;
            session.close();
            session = null;
            session = sessionFactory.openSession();
            final Person doctorLoaded = (Person)session.get(Person.class,
                                                            new Integer(doctor.getId()));
            assertNotNull(doctorLoaded);
            assertTrue(doctorLoaded instanceof Doctor);
            final Doctor doctorLoadedCasted = (Doctor)doctorLoaded;
            assertEquals("Dr. " + doctor.getName() + " is in", 
                         doctorLoadedCasted.operate());
        } finally {
            if(session != null) session.close();
            sessionFactory.close();
        }
    }
}
