package eg;

public class DoctorImpl extends Person implements Doctor
{
    DoctorImpl() {}
    public DoctorImpl(String name) { super(name); }

    public String operate() {
        return "Dr. " + getName() + " is in";
    }
}
