package eg;

import java.io.Serializable;

public interface Doctor extends Serializable
{
    String operate();
}
