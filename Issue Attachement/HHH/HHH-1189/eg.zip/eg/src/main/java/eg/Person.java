package eg;

import java.io.Serializable;

public class Person implements Serializable
{
    private int id;
    private String name;
    
    protected Person() {}
    public Person(String name) { this.name = name; }
    
    public int getId() { return id; }
    public String getName() { return name; }
}
