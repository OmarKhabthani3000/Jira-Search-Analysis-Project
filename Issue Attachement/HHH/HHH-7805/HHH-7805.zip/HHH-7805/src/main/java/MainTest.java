

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainTest {
	public static void main(String[] args) {
		Configuration ac = new Configuration()
		.setProperty(Environment.SHOW_SQL,"true")
		.setProperty(Environment.FORMAT_SQL,"true")
		.setProperty("hibernate.connection.driver_class", "org.postgresql.Driver")
		.setProperty("hibernate.cache.use_second_level_cache", "false")
		.setProperty(Environment.C3P0_MAX_SIZE,"20")
		.setProperty(Environment.C3P0_MIN_SIZE,"5")
		.setProperty(Environment.C3P0_TIMEOUT,"300")
		.setProperty(Environment.C3P0_MAX_STATEMENTS,"50")
		.setProperty(Environment.C3P0_IDLE_TEST_PERIOD,"3000")
		.setProperty(Environment.C3P0_MAX_SIZE,"50")
		.setProperty(Environment.C3P0_ACQUIRE_INCREMENT,"1")
		.setProperty("hibernate.connection.url" ,"jdbc:postgresql:test")
		.setProperty("hibernate.connection.username" ,"postgres" )
		.setProperty("hibernate.connection.password" ,"velvet")
		.setProperty("hibernate.dialect" ,"org.hibernate.dialect.PostgreSQLDialect" )
		//.setProperty("hibernate.hbm2ddl.auto" ,"create")
		//.setProperty("hibernate.hbm2ddl.auto" ,"validate")
		.setProperty("hibernate.hbm2ddl.auto" ,"create-drop")
		.setProperty("hibernate.current_session_context_class","thread")
		.addAnnotatedClass(Person.class)
		.addAnnotatedClass(Project.class);
		SessionFactory sf =  ac.buildSessionFactory(new ServiceRegistryBuilder().applySettings(ac.getProperties()).buildServiceRegistry());


		Session ss= sf.openSession();
		ss.getTransaction().begin();

		Person joe = new Person();
        joe.setName("Joe");

        Project manhattan = new Project();
        manhattan.setName("Manhattan");
        manhattan.setLeader(joe);

        Project toronto = new Project();
        toronto.setName("Toronto");
        toronto.setLeader(joe);

        ss.persist(joe);
        ss.persist(manhattan);
        ss.persist(toronto);

		ss.getTransaction().commit();
		ss.close();

		//second transaction
		ss = sf.openSession();
		ss.getTransaction().begin();
		Project m = (Project)ss.merge(manhattan);
		m.setLeader(null);
		ss.update(m);

		Project t = (Project)ss.merge(toronto);
		t.setLeader(null);
		ss.update(t);

		Person joe2 = (Person)ss.get(Person.class, joe.getId());
		ss.delete(joe2);
		ss.getTransaction().commit();
		ss.close();

		//third transaction
		ss = sf.openSession();
		ss.getTransaction().begin();
		Project manhattan2 = (Project)ss.get(Project.class, manhattan.getId());
		Project toronto2 = (Project)ss.get(Project.class, toronto.getId());
		ss.getTransaction().commit();
		ss.close();
	}

}
