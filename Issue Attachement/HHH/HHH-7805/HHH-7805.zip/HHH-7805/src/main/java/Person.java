

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "PERSON")
public class Person {

    @Id
    @SequenceGenerator(name = "personIdSeqGenerator", sequenceName = "SEQ_PERSON")
    @GeneratedValue(generator = "personIdSeqGenerator", strategy = GenerationType.SEQUENCE)
    @Column(name = "ID", nullable = false, length = 20, precision = 0)
    private Long id;

    @Column(name = "NAME", length = 255)
    private String name;

    @OneToMany(mappedBy="leader")
    private Set<Project> projects;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Person{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}