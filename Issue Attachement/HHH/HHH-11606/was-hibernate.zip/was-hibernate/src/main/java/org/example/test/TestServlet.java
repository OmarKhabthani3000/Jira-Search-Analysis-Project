package org.example.test;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TestServlet extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("org.example");
        entityManagerFactory.createEntityManager();
    }
}
