package com.hibernate.examples.testcase;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hibernate.examples.main.Main;

public class MappingTestCase {
	
	private static Logger LOGGER = LoggerFactory.getLogger(Main.class);
	
	private Main main;

	@Before
	public void setUp() throws Exception {
		main = new Main();
	}

	@Test
	public void testMain() {
		try {
			main.method1();
		} catch(Exception e) {
			LOGGER.error("Exception", e);
			fail("Exception");
		}
	}

}
