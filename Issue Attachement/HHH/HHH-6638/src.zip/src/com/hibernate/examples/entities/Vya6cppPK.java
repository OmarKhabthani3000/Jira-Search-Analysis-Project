package com.hibernate.examples.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Vya6cppPK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name = "A6VN9K")
	private String a6vn9k;

	@Column(name = "A6VN8K")
	private String a6vn8k;

	public String getA6vn9k() {
		return a6vn9k;
	}

	public void setA6vn9k(String a6vn9k) {
		this.a6vn9k = a6vn9k;
	}

	public String getA6vn8k() {
		return a6vn8k;
	}

	public void setA6vn8k(String a6vn8k) {
		this.a6vn8k = a6vn8k;
	}
}
