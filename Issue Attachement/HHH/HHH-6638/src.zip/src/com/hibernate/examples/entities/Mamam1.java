package com.hibernate.examples.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "MAMAM1")
public class Mamam1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private Mamam1PK id;

	@Column(name = "M1SHPR")
	private String m1shpr;

	// bi-directional one-to-one association to Vya6cpp
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumns( {
			@JoinColumn(name = "M1VIN1", referencedColumnName = "A6VN9K"),
			@JoinColumn(name = "M1VIN2", referencedColumnName = "A6VN8K"), })
	private Vya6cpp vya6cpp;

	public Mamam1PK getId() {
		return id;
	}

	public void setId(Mamam1PK id) {
		this.id = id;
	}

	public String getM1shpr() {
		return m1shpr;
	}

	public void setM1shpr(String m1shpr) {
		this.m1shpr = m1shpr;
	}

	public Vya6cpp getVya6cpp() {
		return vya6cpp;
	}

	public void setVya6cpp(Vya6cpp vya6cpp) {
		this.vya6cpp = vya6cpp;
	}
}
