package com.hibernate.examples.main;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hibernate.examples.entities.Mamam1;



public class Main {

	private static Logger LOGGER = LoggerFactory.getLogger(Main.class);
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			new Main().method1();
		} catch (Exception e) {
			LOGGER.error("Exception", e);
		}
	}

	@SuppressWarnings("unchecked")
	public void method1() throws Exception {
		EntityManager em;
		EntityManagerFactory emf;
		try {
			emf = Persistence
					.createEntityManagerFactory("JPAService");
			em = emf.createEntityManager();
			
			Query query = em.createQuery("Select c from Mamam1 c");
			query.setMaxResults(10);
			List<Mamam1> list = query.getResultList();
			LOGGER.info("result data " + list);
		} catch(Exception e) {
			throw e;
		}
	}

}
