package com.hibernate.examples.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Mamam1PK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name = "M1VIN1")
	private String m1vin1;

	@Column(name = "M1VIN2")
	private String m1vin2;

	public String getM1vin1() {
		return m1vin1;
	}

	public void setM1vin1(String m1vin1) {
		this.m1vin1 = m1vin1;
	}

	public String getM1vin2() {
		return m1vin2;
	}

	public void setM1vin2(String m1vin2) {
		this.m1vin2 = m1vin2;
	}

}
