package com.hibernate.examples.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "VYA6CPP")
public class Vya6cpp implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private Vya6cppPK id;

	@Column(name = "A6J2CD")
	private String a6j2cd;

	// bi-directional one-to-one association to Mamam1
	@OneToOne(mappedBy = "vya6cpp", fetch = FetchType.EAGER)
	private Mamam1 mamam1;

	public Vya6cppPK getId() {
		return id;
	}

	public void setId(Vya6cppPK id) {
		this.id = id;
	}

	public String getA6j2cd() {
		return a6j2cd;
	}

	public void setA6j2cd(String a6j2cd) {
		this.a6j2cd = a6j2cd;
	}

	public Mamam1 getMamam1() {
		return mamam1;
	}

	public void setMamam1(Mamam1 mamam1) {
		this.mamam1 = mamam1;
	}
}