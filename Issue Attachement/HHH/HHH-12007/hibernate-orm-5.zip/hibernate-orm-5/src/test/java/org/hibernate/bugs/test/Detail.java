package org.hibernate.bugs.test;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@IdClass(DetailId.class)
@Table(name = "HHHDETAIL")
public class Detail implements Serializable {

    @Id
    @ManyToOne(optional = false)
    @JoinColumn(name = "MASTER_ID", nullable = false)
    private Master master;

    @Id
    @Column(name = "DETAIL_ID", nullable = false)
    private Integer detailId;

    @Column(name = "DESCR")
    private String description;

    public Detail() {
    }

    public Detail(Master master, Integer detailId) {
        this.master = master;
        this.detailId = detailId;
    }

    public Master getMaster() {
        return master;
    }

    public Integer getDetailId() {
        return detailId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.master) + Objects.hashCode(this.detailId);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || !getClass().isAssignableFrom(obj.getClass())) return false;
        Detail other = (Detail) obj;
        return Objects.equals(this.master, other.master) && Objects.equals(this.detailId, other.detailId);
    }

    @Override
    public String toString() {
        return "Detail=" + master+"/"+detailId;
    }
}
