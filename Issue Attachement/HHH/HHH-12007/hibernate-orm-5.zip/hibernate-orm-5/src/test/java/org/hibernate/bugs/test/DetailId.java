package org.hibernate.bugs.test;

import java.io.Serializable;
import java.util.Objects;

public class DetailId implements Serializable {

    private String master;
    private Integer detailId;

    public DetailId() {
    }

    public DetailId(Master master, Integer detailId) {
        this.master = master == null ? null : master.getMasterId();
        this.detailId = detailId;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.master) + Objects.hashCode(this.detailId);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || !getClass().isAssignableFrom(obj.getClass())) return false;
        DetailId other = (DetailId) obj;
        return Objects.equals(this.master, other.master) && Objects.equals(this.detailId, other.detailId);
    }

    @Override
    public String toString() {
        return master + "::" + detailId;
    }
}
