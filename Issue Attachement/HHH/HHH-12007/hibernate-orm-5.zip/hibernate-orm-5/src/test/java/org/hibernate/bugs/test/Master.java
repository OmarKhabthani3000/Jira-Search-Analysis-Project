/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.hibernate.bugs.test;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

@Entity @Table(name = "HHHMASTER")
public class Master implements Serializable {

    @Id
    @Column(name = "MASTER_ID")
    private String masterId;
    @Basic
    @Column(name = "DESCR")
    private String description;

    @OneToMany(mappedBy = "master")
    @OrderBy("masterId")
    private Set<Detail> details;

    public Master() {
    }

    public Master(String masterId) {
        this.masterId = masterId;
    }

    public String getMasterId() {
        return masterId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<Detail> getDetails() {
        if (details == null)
            details = new LinkedHashSet<>();
        return details;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.masterId);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || !getClass().isAssignableFrom(obj.getClass())) return false;
        Master other = (Master) obj;
        return Objects.equals(this.masterId, other.masterId);
    }

    @Override
    public String toString() {
        return "Master=" + masterId;
    }
}
