package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.Query;
import org.hibernate.bugs.test.Detail;
import org.hibernate.bugs.test.Master;
import static org.junit.Assert.*;

/**
 * This template demonstrates how to develop a org.hibernate.bugs.test case for Hibernate ORM, using the Java
 * Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    /**
     * Querying entity with a cascaded IdClass which does not exist in DB nor does master entity.
     *
     * @throws Exception
     */
    @Test
    public void queryCascadedIdClassTest() throws Exception {

        // Create new non-managed entities
        Master m = new Master("master");
        Detail d = new Detail(m, 0);

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        // executing this query leads to managed master entity which will be inserted in DB at flush/commit time
        Query q = entityManager
                .createQuery("select count(d) from Detail d where d=:d")
                .setParameter("d", d);

        assertFalse("before query pc should not contain master", entityManager.contains(m));
        assertFalse("before query pc should not contain detail", entityManager.contains(d));
        long cnt = (Long) q.getSingleResult();
        assertEquals(0L, cnt);
        assertFalse("after query pc should not contain detail", entityManager.contains(d));
        assertFalse("after query pc should not contain master", entityManager.contains(m));

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    /**
     * Querying entity with a cascaded IdClass which does not exist in DB nor does master entity.
     * a variation of test above
     * @throws Exception
     */
    @Test
    public void queryCascadedIdClassTest1() throws Exception {

        // Create new non-managed entities
        Master m = new Master("master");
        Detail d = new Detail(m, 0);

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        // executing this query leads to managed master entity which will be inserted in DB at flush/commit time
        Query q = entityManager
                .createQuery("select count(d) from Detail d where d=:d")
                .setParameter("d", d);

        long cnt = (Long) q.getSingleResult();
        assertEquals(0L, cnt);

        entityManager.getTransaction().commit();
        entityManager.close();

        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        m = entityManager.find(Master.class, m.getMasterId());
        assertNull("master should not be inserted in DB", m);

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    /**
     * Querying entity with a cascaded IdClass which does not exist in DB nor does master entity. This test throws
     * EntityExistsException: "A different object with the same identifier value was already associated with the
     * session" with Hibernate 5.0.11 but passes with Hibernate 5.1.10
     *
     * @throws Exception
     */
    @Test
    public void query2TimesCascadedIdClassTest() throws Exception {

        // Create new non-managed entities
        Master m = new Master("master");
        Detail d = new Detail(m, 0);

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        // first query
        Query q = entityManager
                .createQuery("select count(d) from Detail d where d=:d")
                .setParameter("d", d);

        long cnt = (Long) q.getSingleResult();
        assertEquals(0L, cnt);

        m = new Master("master");
        d = new Detail(m, 0);

        // query again using fresh objects
        // This leads to EntityExistsException at flush/commit time in older Hibernate versions
        q = entityManager
                .createQuery("select count(d) from Detail d where d=:d")
                .setParameter("d", d);

        cnt = (Long) q.getSingleResult();
        assertEquals(0L, cnt);

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    /**
     * Querying entity with a cascaded IdClass which does not exit in DB but master entity does exist. This test throws
     * SQL Error "duplicate key" with Hibernate 5.0.11 but passes with Hibernate 5.1.10
     *
     * @throws Exception
     */
    @Test
    public void queryCascadedIdClassExistingMasterTest() throws Exception {

        // setup fixture
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        Master master = new Master("master");
        master.setDescription("-");
        entityManager.persist(master);

        entityManager.getTransaction().commit();
        entityManager.close();

        // Create new non-managed entities
        Master m = new Master("master");
        Detail d = new Detail(m, 0);

        // This query leads to SQL Error "duplicate key" at flush/commit time in older Hibernate versions
        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        Query q = entityManager
                .createQuery("select count(d) from Detail d where d=:d")
                .setParameter("d", d);

        long cnt = (Long) q.getSingleResult();
        assertEquals(0L, cnt);

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
