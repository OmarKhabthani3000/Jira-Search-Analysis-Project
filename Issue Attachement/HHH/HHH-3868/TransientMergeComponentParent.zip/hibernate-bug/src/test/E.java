package test;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class E {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Embedded
	private C c;
	
	public Long getId() { return id; }
	public C getC() { return c; }
	public void setId(Long id) { this.id = id; }
	public void setC(C c) { this.c = c; }
}
