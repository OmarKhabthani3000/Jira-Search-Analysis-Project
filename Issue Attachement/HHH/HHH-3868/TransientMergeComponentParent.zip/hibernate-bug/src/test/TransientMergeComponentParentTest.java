package test;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.junit.BeforeClass;
import org.junit.Test;

public class TransientMergeComponentParentTest {

	static SessionFactory sessionFactory;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		AnnotationConfiguration config = new AnnotationConfiguration();
		config.addAnnotatedClass(E.class);
		config.addAnnotatedClass(C.class);
		sessionFactory = config.configure().buildSessionFactory();
	}

	@Test
	public void testTransientMergeComponentParent() {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			E e = new E();
			e.setC(new C());
			e = (E)session.merge(e);
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null) tx.rollback();
			throw e;
		} finally {
			session.close();
		}
	}
}
