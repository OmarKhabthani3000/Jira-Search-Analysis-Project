package test;

import javax.persistence.Embeddable;

import org.hibernate.annotations.Parent;

@Embeddable
public class C {
	@Parent
	private E parent;
	private String name;
	
	public E getParent() { return parent; }
	public String getName() { return name; }
	public void setParent(E parent) { this.parent = parent; }
	public void setName(String name) { this.name = name; }
}
