package envers.other;

public enum EnrollmentStatus {
    UNKNOWN,
    ACTIVE,
    DEACTIVATED
}
