package envers.other;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.envers.AuditReader;

public interface UniversalDao {

    SessionFactory getSessionFactory();

    <T> T get(Class<T> entityClass, Long id);

    <T> long getCount(Class<T> entityClass);

    <T> List<T> findAll(Class<T> entityClass);

    <T> void save(T entity);

    <T> void update(T entity);

    <T> void saveOrUpdate(T entity);

    <T> void remove(T entity);

    <T> int removeAll(Class<T> entityClass);

    <T> Object merge(T entity);

    <T> void refresh(T entity);

    AuditReader getAuditReader();

    long getRevisionNumber(Class<?> clazz);

    <T> T getPreviousVersion(Class<T> clazz, long currentRevision, long entityId);

    <T> List<T> getHistoricalVersions(Class<T> clazz, long entityId, Integer limit);

    List<Object> getAllChangedEntitiesForRevision(Class<?> clazz, long revision);
}
