package envers.other;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.query.AuditEntity;
import org.hibernate.envers.query.AuditQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class UniversalDaoImpl implements UniversalDao {

    private final SessionFactory sessionFactory;

    private final HibernateTemplate hibernateTemplate;

    @Autowired
    public UniversalDaoImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        this.hibernateTemplate = new HibernateTemplate(sessionFactory);
    }

    @Override
    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public AuditReader getAuditReader() {
        return AuditReaderFactory.get(sessionFactory.getCurrentSession());
    }

    @Override
    @Transactional
    public <T> long getCount(Class<T> entityClass) {
        return (Long) getSessionFactory().getCurrentSession()
                .createQuery("SELECT COUNT(*) FROM " + entityClass.getName()).uniqueResult();
    }

    @Override
    @Transactional
    @SuppressWarnings(value = "unchecked")
    public <T> T get(Class<T> entityClass, Long id) {
        return (T) getSessionFactory().getCurrentSession().get(entityClass, id);
    }

    @Override
    @SuppressWarnings(value = "unchecked")
    @Transactional(readOnly = true)
    public <T> List<T> findAll(Class<T> entityClass) {
        return (List<T>) getSessionFactory().getCurrentSession().createCriteria(entityClass)
                .setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
    }

    @Override
    @Transactional
    public <T> void save(T entity) {
        getSessionFactory().getCurrentSession().save(entity);
    }

    @Override
    @Transactional
    public <T> void update(T entity) {
        getSessionFactory().getCurrentSession().update(entity);
    }

    @Override
    @Transactional
    public <T> void saveOrUpdate(T entity) {
        getSessionFactory().getCurrentSession().saveOrUpdate(entity);
    }

    @Override
    @Transactional
    public <T> void remove(T entity) {
        getSessionFactory().getCurrentSession().delete(entity);
    }

    @Override
    @Transactional
    public <T> int removeAll(Class<T> entityClass) {
        return getSessionFactory().getCurrentSession().createQuery("DELETE " + entityClass.getName()).executeUpdate();
    }

    @Override
    @Transactional
    public <T> Object merge(T entity) {
        return getSessionFactory().getCurrentSession().merge(entity);
    }

    @Override
    @Transactional
    public <T> void refresh(T entity) {
        getSessionFactory().getCurrentSession().refresh(entity);
    }

    protected HibernateTemplate getHibernateTemplate() {
        return hibernateTemplate;
    }

    @Override
    public long getRevisionNumber(Class<?> clazz) {
        AuditReader reader = getAuditReader();
        if (!reader.isEntityClassAudited(clazz)) {
            throw new IllegalStateException("Entity is not audited");
        }
        Number previousRevision = (Number) reader.createQuery().forRevisionsOfEntity(clazz, false, true)
                .addProjection(AuditEntity.revisionNumber().max()).addOrder(AuditEntity.revisionNumber().desc())
                .getSingleResult();
        return previousRevision.longValue();
    }

    @Override
    public <T> T getPreviousVersion(Class<T> clazz, long currentRevision, long entityId) {
        T result = null;
        AuditReader reader = getAuditReader();

        if (!reader.isEntityClassAudited(clazz)) {
            throw new IllegalStateException("Entity is not audited");
        }

        Number previousRevision = (Number) reader.createQuery().forRevisionsOfEntity(clazz, false, true)
                .addProjection(AuditEntity.revisionNumber().max()).add(AuditEntity.id().eq(entityId))
                .add(AuditEntity.revisionNumber().lt(currentRevision)).getSingleResult();

        if (previousRevision != null) {
            result = (T) reader.find(clazz, entityId, previousRevision);
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> List<T> getHistoricalVersions(Class<T> clazz, long entityId, Integer limit) {
        AuditReader reader = getAuditReader();

        if (!reader.isEntityClassAudited(clazz)) {
            throw new IllegalStateException("Entity is not audited");
        }

        long currentRev = getRevisionNumber(clazz);
        AuditQuery query = reader.createQuery().forRevisionsOfEntity(clazz, true, true)
                .add(AuditEntity.id().eq(entityId)).add(AuditEntity.revisionNumber().lt(currentRev));
        if (limit != null) {
            query.setMaxResults(limit);
        }
        return query.getResultList();
    }

    @Override
    public List<Object> getAllChangedEntitiesForRevision(Class<?> clazz, long revision) {
        AuditReader reader = getAuditReader();
        return reader.getCrossTypeRevisionChangesReader().findEntities(revision);
    }

}
