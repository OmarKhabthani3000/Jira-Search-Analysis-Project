package envers.other;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    @Autowired
    DAO dao;

    @Autowired
    ApplicationContext applicationContext;

    private static EnrollmentStatus lastStatus = null;

    private void create() {
        Enrollment e = new Enrollment();
        e.setStatus(lastStatus);
        dao.save(e);
    }

    private void update() {
        Enrollment e = dao.findAll().get(0);
        if (EnrollmentStatus.ACTIVE.equals(lastStatus)) {
            e.setStatus(EnrollmentStatus.DEACTIVATED);
        } else {
            e.setStatus(EnrollmentStatus.ACTIVE);
        }
        dao.update(e);
        lastStatus = e.getStatus();
    }

    @RequestMapping("/test")
    public void request() {
        if (lastStatus == null) {
            List<Enrollment> es = dao.findAll();
            if (es.isEmpty()) {
                lastStatus = EnrollmentStatus.UNKNOWN;
            } else {
                lastStatus = es.get(0).getStatus();
            }

        }
        // create();
        update();
    }
}
