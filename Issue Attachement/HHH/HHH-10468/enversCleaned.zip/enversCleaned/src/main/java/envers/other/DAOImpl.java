package envers.other;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class DAOImpl extends GenericDaoImpl<Enrollment> implements DAO {

    // public AuditReader getAuditReader() {
    // return AuditReaderFactory.get(sessionFactory.getCurrentSession());
    // }

    @Autowired
    public DAOImpl(UniversalDao universalDao) {
        super(Enrollment.class, universalDao);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Enrollment> getEnrollmentsWhereStatusIsChanged(long userId) {
        // AuditReader reader = getAuditReader();
        //
        // List<Enrollment> specificChanges =
//        @formatter:off
//                reader
//                .createQuery()
//                .forRevisionsOfEntity(Enrollment.class, true, true)
//                    .add(AuditEntity.id().eq(userId))
//                    .add(AuditEntity.property("status").hasChanged())
//                .getResultList();
//        @formatter:on
        //
        // return specificChanges;
        return null;
    }

}
