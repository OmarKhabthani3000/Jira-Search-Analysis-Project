package envers.other;

import java.util.List;

public interface DAO extends GenericDao<Enrollment> {

    List<Enrollment> getEnrollmentsWhereStatusIsChanged(long userId);
}
