package envers.other;

import java.lang.annotation.Annotation;
import java.util.List;

import javax.persistence.Entity;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.envers.AuditReader;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class GenericDaoImpl<T> implements GenericDao<T> {

    private final Class<T> entityClass;

    private final UniversalDao universalDao;

    private final HibernateTemplate hibernateTemplate;

    // Use the method createQueryBuffer() to access this private variable.
    private static final int DEFAULT_QUERY_BUFFER_SIZE = 4096;

    public GenericDaoImpl(Class<T> entityClass, UniversalDao universalDao) {
        checkEntityClass(entityClass);
        this.entityClass = entityClass;
        this.universalDao = universalDao;
        this.hibernateTemplate = new HibernateTemplate(universalDao.getSessionFactory());
    }

    @Override
    public Class<T> getEntityClass() {
        return entityClass;
    }

    @Override
    public SessionFactory getSessionFactory() {
        return universalDao.getSessionFactory();
    }

    @Override
    public AuditReader getAuditReader() {
        return universalDao.getAuditReader();
    }

    @Override
    public Session getCurrentSession() {
        return getSessionFactory().getCurrentSession();
    }

    @Override
    public long getCount() {
        return universalDao.getCount(getEntityClass());
    }

    @Override
    public T get(Long id) {
        return universalDao.get(getEntityClass(), id);
    }

    @Override
    public List<T> findAll() {
        return universalDao.findAll(getEntityClass());
    }

    @Override
    public void save(T entity) {
        universalDao.save(entity);
    }

    @Override
    public void update(T entity) {
        universalDao.update(entity);
    }

    @Override
    public void saveOrUpdate(T entity) {
        universalDao.saveOrUpdate(entity);
    }

    @Override
    public void remove(T entity) {
        universalDao.remove(entity);
    }

    @Override
    public int removeAll() {
        return universalDao.removeAll(getEntityClass());
    }

    @Override
    public Object merge(T entity) {
        return universalDao.merge(entity);
    }

    protected HibernateTemplate getHibernateTemplate() {
        return hibernateTemplate;
    }

    private final void checkEntityClass(Class<?> entityClass) {
        if (entityClass == null) {
            throw new IllegalArgumentException("Entity class is null");
        }
        boolean hasEntityAnnotation = false;
        for (Annotation annotation : entityClass.getDeclaredAnnotations()) {
            if (annotation instanceof Entity) {
                hasEntityAnnotation = true;
                break;
            }
        }
        if (!hasEntityAnnotation) {
            throw new IllegalArgumentException(
                    "Entity class " + entityClass + " for this instance is not annotated with the @Entity annotation.");
        }
    }

    @Override
    public void refresh(T entity) {
        universalDao.refresh(entity);
    }

    @Override
    public void sessionClear() {
        universalDao.getSessionFactory().getCurrentSession().clear();
    }

    @Override
    public void flushSession() {
        universalDao.getSessionFactory().getCurrentSession().flush();
    }

    @Override
    public void evict(T entity) {
        universalDao.getSessionFactory().getCurrentSession().evict(entity);
    }

    public long getRevisionNumber() {
        return universalDao.getRevisionNumber(entityClass);
    }

    public T getPreviousVersion(long currentRevision, long entityId) {
        return universalDao.getPreviousVersion(entityClass, currentRevision, entityId);
    }

    public List<T> getHistoricalVersions(long entityId, Integer limit) {
        return universalDao.getHistoricalVersions(entityClass, entityId, limit);
    }

    protected Query createQuery(String query) {
        return universalDao.getSessionFactory().getCurrentSession().createQuery(query);
    }

    protected SQLQuery createSQLQuery(String query) {
        return universalDao.getSessionFactory().getCurrentSession().createSQLQuery(query);
    }

    protected Criteria createCriteria() {
        return universalDao.getSessionFactory().getCurrentSession().createCriteria(this.entityClass);
    }

    protected StringBuilder createQueryBuffer() {
        return new StringBuilder(DEFAULT_QUERY_BUFFER_SIZE);
    }

    @Override
    public List<Object> getAllChangedEntitiesForRevision(long revision) {
        return universalDao.getAllChangedEntitiesForRevision(entityClass, revision);
    }

}
