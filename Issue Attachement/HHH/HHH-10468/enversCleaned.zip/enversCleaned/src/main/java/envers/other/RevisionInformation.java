package envers.other;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;

import org.hibernate.envers.ModifiedEntityNames;
import org.hibernate.envers.RevisionEntity;
import org.hibernate.envers.RevisionNumber;
import org.hibernate.envers.RevisionTimestamp;

@Entity
@Table(name = "revision_info")
@RevisionEntity
public class RevisionInformation {

    @Id
    @GeneratedValue
    @RevisionNumber
    @Column(name = "revision_info_id")
    private long revisionInfoId;

    @RevisionTimestamp
    @Column(name = "revision_timestamp")
    private Date revisionDateTime;

    @ElementCollection
    @JoinTable(name = "revision_change", joinColumns = @JoinColumn(name = "revision") )
    @Column(name = "entity_name")
    @ModifiedEntityNames
    private Set<String> modifiedEntityNames;

    public long getRevisionInfoId() {
        return revisionInfoId;
    }

    public void setRevisionInfoId(long revisionInfoId) {
        this.revisionInfoId = revisionInfoId;
    }

    public Date getRevisionDateTime() {
        return revisionDateTime;
    }

    public void setRevisionDateTime(Date revisionDateTime) {
        this.revisionDateTime = revisionDateTime;
    }

}
