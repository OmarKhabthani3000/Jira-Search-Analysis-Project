package envers.framework;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;

@Configuration
@ComponentScan("envers.other")
public class Config {

    @Autowired
    private Environment env;

    @Autowired
    DataSource datasource;

    @Autowired
    Properties properties;

    @Bean
    public LocalSessionFactoryBean sessionFactory() {
        Properties enversProperties = new Properties(properties);
        enversProperties.put("org.hibernate.envers.revision_field_name", "revision");
        enversProperties.put("org.hibernate.envers.revision_type_field_name", "revision_type");
        enversProperties.put("org.hibernate.envers.audit_table_suffix", "_history");
        enversProperties.put("org.hibernate.envers.global_with_modified_flag", "false");
        enversProperties.put("org.hibernate.envers.modified_flag_suffix", "_modified");

        LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
        sessionFactory.setDataSource(datasource);
        sessionFactory.setPackagesToScan(new String[] { "envers.other" });
        sessionFactory.setHibernateProperties(enversProperties);

        return sessionFactory;
    }

    @Bean
    @Autowired
    public HibernateTransactionManager transactionManager(SessionFactory sessionFactory) {
        HibernateTransactionManager txManager = new HibernateTransactionManager();
        txManager.setSessionFactory(sessionFactory);

        return txManager;
    }

    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
        return new PersistenceExceptionTranslationPostProcessor();
    }

}