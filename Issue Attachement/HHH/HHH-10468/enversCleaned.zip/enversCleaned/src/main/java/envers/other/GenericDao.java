package envers.other;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.envers.AuditReader;

public interface GenericDao<T> {

    Class<T> getEntityClass();

    SessionFactory getSessionFactory();

    Session getCurrentSession();

    long getCount();

    T get(Long id);

    List<T> findAll();

    void save(T entity);

    void update(T entity);

    void saveOrUpdate(T entity);

    void remove(T entity);

    int removeAll();

    Object merge(T entity);

    void sessionClear();

    void evict(T entity);

    void refresh(T entity);

    void flushSession();

    AuditReader getAuditReader();

    long getRevisionNumber();

    T getPreviousVersion(long currentRevision, long entityId);

    List<T> getHistoricalVersions(long entityId, Integer limit);

    List<Object> getAllChangedEntitiesForRevision(long revision);
}
