package com.example.service;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.domain.Log;

@Service
public class Worker
{
    //~ Instance attributes ----------------------------------------------------------------------
    @Autowired DomainService service;

    //~ Methods ----------------------------------------------------------------------------------
    public void doStuff()
    {
        for (int n = 0; n < 10; n++)
        {
            //Thread t = new Thread(new Logmaker(service), "Logmaker #" + n);
            //t.start();
            new Logmaker(service).run();
        }
    }
    
    //~ Utilities --------------------------------------------------------------------------------
    /**
     * Thread runnable
     */
    static class Logmaker implements Runnable
    {
        /** Logger */
        private static final Logger LOG = Logger.getLogger(Worker.class);
        protected DomainService service;
        
        public Logmaker(DomainService theService)
        {
            this.service = theService;
        }
        
        @Override
        public void run()
        {
            //int wait = RandomUtils.nextInt(250, 10000);
            //LOG.info(String.format("Waiting %d ms...", wait));
            //wait(wait);
            
            for (int k = 0; k < 3; k++)
            {
                Log log = new Log();
                log.setLog(RandomStringUtils.randomAlphanumeric(256));
                service.persist(log);
                LOG.info(String.format("Log object %d with message [%s] has been persisted", log.getId(), log.getLog()));
                
                //wait(wait);
            }
        }
        
        static void wait(int ms)
        {
            try
            {
                Thread.sleep(ms);
            }
            catch (InterruptedException e)
            {
                LOG.error("Error waiting " + ms + " ms", e);
            }

        }
    }

}
