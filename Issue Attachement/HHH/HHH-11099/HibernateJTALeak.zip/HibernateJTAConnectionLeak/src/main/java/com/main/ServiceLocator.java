package com.main;

import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.core.env.MutablePropertySources;

import com.example.service.Worker;

/**
 * Service Locator - kickstarts Spring framework
 */
public class ServiceLocator
{
    //~ Static attributes/initializers -----------------------------------------------------------
    private static ServiceLocator singleton = new ServiceLocator();
    private static final String APP_CONTEXT = "classpath:/META-INF/spring/applicationContext.xml";
    private static final Logger LOG = Logger.getLogger(ServiceLocator.class);
    

    //~ Instance attributes ----------------------------------------------------------------------
    private ApplicationContext applicationContext;

    //~ Methods ----------------------------------------------------------------------------------
    /**
     * Returns the singleton ServiceLocator
     * @return the singleton ServiceLocator
     */
    public static ServiceLocator getInstance()
    {
        return singleton;
    }

    /**
     * Convenience wrapper for returning single bean from
     * getApplicationContext().getBeansOfType(type). If multiple beans exist in application context
     * of type, then an exception will be thrown.
     * 
     * @param type Class<T>
     * @param <T> - class type of the bean
     * @return the bean of type requested; an exception is thrown if no bean is found or more than one exist
     * @see ApplicationContext#getBean(Class)
     */
    public <T> T getBean(Class<T> type)
    {
        return this.applicationContext.getBean(type);
    }
    
    /**
     * Convenience to find a bean with given criteria - and return null if none found (rather than an exception)
     * @param <T> the type of the bean to return
     * @param name name of the bean to find
     * @param type the type of the bean to find
     * @return the bean of type and name requested; null if none found; if no name is given and multiple beans of the requested type exist, return 
     * the first one as returned by the underlying spring context
     * @see #getBean(String, Class) 
     * @see ApplicationContext#getBeansOfType(Class)
     */
    public <T> T findBean(String name, Class<T> type)
    {
        Map<String, T> beans = this.applicationContext.getBeansOfType(type);
        if (MapUtils.isEmpty(beans))
        {
            return null;
        }
        if (StringUtils.isEmpty(name))
        {
            //returns the first entry in the map
            return beans.entrySet().iterator().next().getValue();
        }
        //returns the bean with the given name - this could be null
        return beans.get(name);
    }

    //~ Utilities --------------------------------------------------------------------------------

    /**
     * loads spring context
     */
    private void init()
    {
        if (this.applicationContext == null)
        {
            String ctxPath = APP_CONTEXT;
            //start spring
            GenericXmlApplicationContext appCtx = new GenericXmlApplicationContext();
            
            appCtx.load(ctxPath);
            appCtx.refresh();
            
            this.applicationContext = appCtx;
            
            LOG.info("Spring context loaded from " + ctxPath);
        }
    }
    
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        ServiceLocator.getInstance().init();
        
        ServiceLocator.getInstance().getBean(Worker.class).doStuff();
        
    }
}
