package com.example.config;

import java.util.Properties;

import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import javax.sql.XADataSource;
import javax.transaction.SystemException;

import org.apache.commons.dbcp.BasicDataSourceFactory;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.orm.jpa.DefaultJpaDialect;
import org.springframework.orm.jpa.JpaDialect;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.jta.JtaTransactionManager;

import com.atomikos.icatch.config.UserTransactionService;
import com.atomikos.icatch.config.UserTransactionServiceImp;
import com.atomikos.icatch.jta.J2eeTransactionManager;
import com.atomikos.icatch.jta.J2eeUserTransaction;


@Configuration
@PropertySource("classpath:/jdbc.properties")
public class DataConfig
{
    public static final Logger LOGGER = Logger.getLogger(DataConfig.class);
    
    public static final String TXN_JTA = "jta";
    
    @Autowired Environment env;
    
    //~ Methods -----------------------------------------------------------------------------------
    @Bean
    public JpaDialect hibernateJpaDialect()
    {
        return new DefaultJpaDialect();
    }
    
    /**
     * The JTA {@link EntityManagerFactory}
     * @param dialect
     * @param xaDataSource
     * @return
     */
    @Bean
    @Autowired	
    public LocalContainerEntityManagerFactoryBean jtaEntityManagerFactory(JpaDialect dialect, @Qualifier("atomikosDataSource") DataSource xaDataSource)
    {
         LocalContainerEntityManagerFactoryBean emf = baseEntityManagerFactory(TXN_JTA, xaDataSource);
         emf.setJpaDialect(dialect);
         emf.setJtaDataSource(xaDataSource);
         emf.getJpaPropertyMap().put("hibernate.hbm2ddl.auto", "none");

         return emf;
    }
    
    /**
     * The JPA (default) {@link EntityManagerFactory} - we're only needing this one to create the DDL in H2 database. Letting the JTA factory do that 
     * fails with errors related to atomikos transaction manager.
     * @param dialect
     * @param dataSource
     * @return
     */
    @Bean @Qualifier("jpa")
    @Autowired  
    public LocalContainerEntityManagerFactoryBean localEntityManagerFactory(JpaDialect dialect, @Qualifier("dataSource") DataSource dataSource)
    {
         LocalContainerEntityManagerFactoryBean emf = baseEntityManagerFactory("local", dataSource);
         emf.setJpaDialect(dialect);
         return emf;
    }
    
    @Bean(destroyMethod="close")
    public DataSource dataSource() throws Exception
    {
        Properties dsProps = new Properties();
        dsProps.setProperty("driverClassName", env.getProperty("jdbc.driverClassName"));
        dsProps.setProperty("url", env.getProperty("jdbc.url"));
        dsProps.setProperty("username", env.getProperty("jdbc.username"));
        dsProps.setProperty("password", env.getProperty("jdbc.password"));
        dsProps.setProperty("defaultAutoCommit", "false");
        dsProps.setProperty("initialSize", env.getProperty("jdbc.pool.initialSize"));
        dsProps.setProperty("maxActive", env.getProperty("jdbc.pool.maxActive"));
        dsProps.setProperty("maxWait", env.getProperty("jdbc.pool.maxWait"));
        
        DataSource ds = BasicDataSourceFactory.createDataSource(dsProps);
        return ds;
    }
    
    @Bean
    public FactoryBean<XADataSource> dataSourceXa()
    {
        XaDataSourceFactoryBean fbXA = new XaDataSourceFactoryBean();
        fbXA.setXaDataSourceClass(env.getProperty("jdbc.datasource.class"));
        
        Properties xaProps = new Properties();
        xaProps.setProperty("URL", env.getProperty("jdbc.url"));
        xaProps.setProperty("user", env.getProperty("jdbc.username"));
        xaProps.setProperty("password", env.getProperty("jdbc.password"));
        
        fbXA.setXaProperties(xaProps);
        return fbXA;
    }
    
    @Bean(initMethod="init")
    @Autowired
    public DataSource atomikosDataSource(FactoryBean<XADataSource> dataSourceXa) throws Exception
    {
        CustomAtomikosDataSourceBean xaDs = new CustomAtomikosDataSourceBean();
        xaDs.setUniqueResourceName("xaDataSource");
        xaDs.setXaDataSource(dataSourceXa.getObject());
        xaDs.setPoolSize(5);
        xaDs.setTestQuery("SELECT sysdate FROM DUAL");
        return xaDs;
    }
    
    @Bean @Qualifier("main")
    @Autowired
    public PlatformTransactionManager transactionManager(@Qualifier("jpa") EntityManagerFactory emf, JpaDialect jpaDialect)
    {
        JpaTransactionManager tm = new JpaTransactionManager(emf);
        tm.setJpaDialect(jpaDialect);
        return tm;
    }
    
    @Bean @Qualifier("jta") @Autowired
    public PlatformTransactionManager jtaTransactionManager(J2eeTransactionManager j2eeTm, J2eeUserTransaction jusrTx)
    {
        JtaTransactionManager tm = new JtaTransactionManager(jusrTx, j2eeTm);
        return tm;
        
    }
    
    @Bean(initMethod="init", destroyMethod="shutdownForce")
    public UserTransactionService userTransactionService()
    {
        return new UserTransactionServiceImp();
    }
    
    @Bean @DependsOn("userTransactionService")
    public J2eeTransactionManager atomikosTransactionManager()
    {
        return new J2eeTransactionManager();
    }
    
    @Bean @DependsOn("userTransactionService")
    public J2eeUserTransaction atomikosUserTransaction() throws SystemException
    {
        J2eeUserTransaction jut = new J2eeUserTransaction();
        jut.setTransactionTimeout(300);
        return jut;
    }
    
    //~ Utilities ---------------------------------------------------------------------------------
    /**
     */
    protected LocalContainerEntityManagerFactoryBean baseEntityManagerFactory(String anAggregatedPersistentUnitName, DataSource aDataSource)
    {
        LOGGER.info("localEntityManagerFactory start " + anAggregatedPersistentUnitName);
        
        Properties persistenceProperties = basePersistenceProperties();
        h2Properties(persistenceProperties);

        specificFactoryProperties(persistenceProperties);

        LocalContainerEntityManagerFactoryBean emf = new LocalContainerEntityManagerFactoryBean();
        emf.setJpaProperties(persistenceProperties);
        emf.setDataSource(aDataSource);
        emf.setPersistenceUnitName(anAggregatedPersistentUnitName);  
        emf.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        emf.setPackagesToScan("com.example.domain");
        return emf;
    }
    
    /**
     * Returns a common set of persistence unit property settings
     * @return a common set of persistence unit property settings
     */
    protected Properties basePersistenceProperties()
    {
        Properties persistenceProperties = new Properties();
        persistenceProperties.put("hibernate.implicit_naming_strategy", "org.hibernate.boot.model.naming.ImplicitNamingStrategyJpaCompliantImpl");
        persistenceProperties.put("hibernate.use_sql_comments", "true");
        return persistenceProperties;
    }
    
    /**
     * Add H2 specific properties to the input Properties object
     * @param persistenceProperties the input Properties object
     */
    protected void h2Properties(Properties persistenceProperties)
    {
        persistenceProperties.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
        persistenceProperties.put("hibernate.hbm2ddl.auto", "create");
    }
    
    /**
     * @param persistenceProperties the input Properties object
     */
    protected void specificFactoryProperties(Properties persistenceProperties)
    {
        persistenceProperties.put("hibernate.transaction.jta.platform", "com.example.config.CustomJtaPlatform");
    }

}
