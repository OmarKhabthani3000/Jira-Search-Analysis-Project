package com.example.config;

import java.sql.Connection;
import java.sql.SQLException;

import org.springframework.util.Assert;

import com.atomikos.jdbc.AtomikosDataSourceBean;

/**
 * Custom data source that logs calls to {@link #getConnection()}
 */
public class CustomAtomikosDataSourceBean extends AtomikosDataSourceBean
{
    //~ Static attributes/initializers -----------------------------------------------------------
    private static final long serialVersionUID = 1L;

    //~ Methods ----------------------------------------------------------------------------------
    @Override
    public Connection getConnection() throws SQLException
    {
        Connection con = super.getConnection();
        
        System.out.println(String.format(">>> Atomikos Connection borrowed; remaining pool size: %d", poolAvailableSize()));
        
        Assert.isTrue(poolAvailableSize() > 0, "POOL EXHAUSTED");
        
        return con;
    }
    
}
