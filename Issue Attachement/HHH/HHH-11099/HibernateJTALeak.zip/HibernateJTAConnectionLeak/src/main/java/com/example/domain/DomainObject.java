package com.example.domain;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class DomainObject
{
    //~ Instance attributes ----------------------------------------------------------------------
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "domainSequencer")
    @Id
    @Column(name = "id")
    @Basic
    protected Long id;

    //~ Methods ----------------------------------------------------------------------------------
    
    public Long getId()
    {
        return this.id;
    }

    public void setId(Long anId)
    {
        this.id = anId;
    }


}
