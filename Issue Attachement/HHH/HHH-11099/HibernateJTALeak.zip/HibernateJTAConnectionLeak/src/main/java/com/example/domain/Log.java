package com.example.domain;


import javax.persistence.AttributeOverride;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "APP_LOG")
@AttributeOverride(name = "id", column = @Column(name = "APP_LOG_ID"))
@SequenceGenerator(name = "domainSequencer", sequenceName = "APP_LOG_SEQ", allocationSize = 1)
public class Log extends DomainObject
{
    protected static final int MAX_LOG_LENGTH = 4000;

    @Basic
    @Column(name = "TARGET_ID")
    private Long targetId;

    @Basic
    @Column(name = "LOG", length = MAX_LOG_LENGTH)
    private String log;

    /**
     * Returns the targetId.
     * @return the targetId.
     */
    public Long getTargetId()
    {
        return this.targetId;
    }

    /**
     * Sets the targetId.
     * @param aTargetId The targetId to set.
     */
    public void setTargetId(Long aTargetId)
    {
        this.targetId = aTargetId;
    }


    /**
     * Returns the log.
     * @return the log.
     */
    public String getLog()
    {
        return this.log;
    }

    /**
     * Sets the log.
     * @param aLog The log to set.
     */
    public void setLog(String aLog)
    {
        this.log = aLog;
    }


    /**
     * Returns the string representing this object.
     * @return the string representing this object.
     */
    @Override
    public String toString()
    {

        return super.toString()
            + " targetId["  + this.targetId + "]"
            + " log["  + this.log + "]";
    }
}
