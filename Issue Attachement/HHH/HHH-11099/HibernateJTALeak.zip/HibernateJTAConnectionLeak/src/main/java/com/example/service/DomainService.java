package com.example.service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.RandomUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.domain.DomainObject;

/**
 */
@Service
public class DomainService
{
    //~ Instance attributes ----------------------------------------------------------------------
    /** jta entity manager */
    @PersistenceContext(unitName = "jta")
    protected EntityManager jtaEntityManager;

    //~ Methods ----------------------------------------------------------------------------------
    
    public EntityManager getJtaEntityManager()
    {
        return jtaEntityManager;
    }
    
    @Transactional("jta")
    public void persist(DomainObject obj)
    {
        int txLength = RandomUtils.nextInt(100, 500);
        try
        {
            Thread.sleep(txLength);
        }
        catch (InterruptedException e)
        {
            //don't care
        }
        this.jtaEntityManager.persist(obj);
    }

}
