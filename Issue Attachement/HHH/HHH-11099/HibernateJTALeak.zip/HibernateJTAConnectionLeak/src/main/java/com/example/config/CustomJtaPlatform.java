package com.example.config;

import javax.transaction.TransactionManager;
import javax.transaction.UserTransaction;

import org.hibernate.engine.transaction.jta.platform.internal.AbstractJtaPlatform;

import com.atomikos.icatch.jta.J2eeTransactionManager;

/**
 * 
 * This is an implementation of {@link AbstractJtaPlatform} for Atomikos' {@link J2eeTransactionManager}.
 * 
 */
public class CustomJtaPlatform extends AbstractJtaPlatform
{
    private static final long serialVersionUID = 1L;
    
    /** Manager that will be looked up */
    private J2eeTransactionManager manager;
    
    /**
     * Constructor
     */
    public CustomJtaPlatform()
    {
        this.manager = new J2eeTransactionManager();
    }

    @Override
    protected TransactionManager locateTransactionManager() 
    {
        return this.manager;
    }
    
    @Override
    protected UserTransaction locateUserTransaction()
    {
        throw new UnsupportedOperationException("locateUserTransaction is not supported. Use the locateTransactionManager instead.");
    }
}
