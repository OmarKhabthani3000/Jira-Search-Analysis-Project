package com.example.config;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Properties;

import javax.sql.XADataSource;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.util.ReflectionUtils;

public class XaDataSourceFactoryBean implements FactoryBean<XADataSource>
{
    /** The properties to set in the instance. */
    private Properties xaProperties;
    /** The fully-qualified class name of the XADataSource implementation. */
    private String xaDataSourceClass;
    
    /**
     * Sets the class name of the XADataSource implementation.
     * @param classname The fully-qualified class name.
     */
    public void setXaDataSourceClass(String classname)
    {
        this.xaDataSourceClass = classname;
    }

    /**
     * Sets the properties that should be set in the XADataSource instance.
     * @param properties The properties
     */
    public void setXaProperties(Properties properties)
    {
        this.xaProperties = properties;
    }

    @Override
    public XADataSource getObject() throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException
    {
        Class<?> xaDataSourceClazz = Class.forName(this.xaDataSourceClass);
        XADataSource xaDataSource = (XADataSource) xaDataSourceClazz.newInstance();
        
        Enumeration<?> propertyNames = this.xaProperties.propertyNames();
        
        while (propertyNames.hasMoreElements())
        {
            String name = (String) propertyNames.nextElement();
            String methodName = "set" + Character.toUpperCase(name.charAt(0)) + name.substring(1);
            Method m = ReflectionUtils.findMethod(xaDataSourceClazz, methodName, String.class);
            String value = this.xaProperties.getProperty(name);
            ReflectionUtils.invokeMethod(m, xaDataSource, value);
        }
        
        return xaDataSource;
    }

    /**
     * {@inheritdoc}
     * @return Always returns <code>XADataSource.class</code>
     */
    @Override
    public Class<XADataSource> getObjectType()
    {
        return XADataSource.class;
    }

    /**
     * {@inheritdoc}
     * @return Always returns false since each usage of this factory returns a new instance.
     */
    @Override
    public boolean isSingleton()
    {
        return false;
    }
}
