package com.acme.persistence;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Invoice entity.
 */
@Entity
@Table(name = "inv_invoice")
public class Invoice
{
	/** Primary key. */
	private Long id;

	/** Attribute. */
	private BigDecimal amount;
	

	/**
	 * @return The primary key.
	 */
	@Id
	@SequenceGenerator(name = "seq_inv", sequenceName = "seq_inv", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_inv")
	public Long getId()
	{
		return id;
	}


	/**
	 * Set the primary key.
	 * @param id Value of the key.
	 */
	public void setId(final Long id) {
		this.id = id;
	}


	/**
	 * @return The amount.
	 */
	public BigDecimal getAmount() {
		return amount;
	}


	/**
	 * Sets the amount.
	 * @param amount Amount.
	 */
	public void setAmount(final BigDecimal amount) {
		this.amount = amount;
	}
}
