package hibernate.lazy_ignore;

import java.util.Map;

public class B
{
  public int getB () { return b; }
  protected long id;
  protected int b;
  protected Map map;
}
