package hibernate.lazy_ignore;

import java.util.List;

public class A
{
  public int getA () { return a; }
  public List getBag () { return bag; }
  protected long id;
  protected int a;
  protected List bag;
}
