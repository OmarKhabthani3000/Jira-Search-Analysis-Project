package hibernate.lazy_ignore;

import java.util.ArrayList;
import java.util.HashMap;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class Test
{
  public static void main (String[] args)
  {
    try
    {
      Configuration config = new Configuration();
      config.configure("hibernate/lazy_ignore/hibernate.cfg.xml");
      SessionFactory factory = config.buildSessionFactory();
      Session session = factory.openSession();
      Transaction tx = session.beginTransaction();
      
      A a = new A();
      a.a = -1;
      a.bag = new ArrayList();
      for (int i = 0; i < 2; i++)
      {
        B b = new B();
        b.b = i;
        b.map = new HashMap();
        for (int j = 0; j < 2; j++)
        {
          C c = new C();
          c.c = j * 1000000;
          b.map.put(new Integer(j), c);
        }
        a.bag.add(b);
      }
      session.save(a);
      tx.commit();
      session.close();

      session = factory.openSession();
      tx = session.beginTransaction();
      
      Criteria criteria = session.createCriteria(A.class);
      criteria.add(Restrictions.eq("a", new Integer(-1)));
      // BTW: when using criteria.setFetchMode("bag", FetchMode.JOIN) here,
      // this will produce a correct "from A outer join B outer join C".
      a = (A) criteria.uniqueResult();

      a.getA(); // force fetch
      System.out.println(">>>> failed lazy get:");
      // watch console output: this will result in two selects (one for B and 
      // one for C) though fetch="join" has been specified for the map in B.
      // I expect one statement "from B outer join C" here.
      a.getBag().get(0);

      // when directly getting a B all is fine
      System.out.println(">>>> correct direct get:");
      Criteria criteriaB = session.createCriteria(B.class);
      criteriaB.add(Restrictions.eq("b", new Integer(0)));
      B b = (B) criteriaB.uniqueResult();
      b.getB(); // force fetch

      tx.commit();
      session.close();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}
