package hibernate.lazy_ignore;

public class C
{
  protected long id;
  protected int c;
}
