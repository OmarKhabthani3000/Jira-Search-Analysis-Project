package eu.pinske.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.engine.spi.SelfDirtinessTracker;
import org.junit.Test;

import eu.pinske.model.Thing;

public class ThingTest {

    @Test
    public void testFail() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        Thing thing = new Thing();
        em.persist(thing);

        em.createQuery("update Thing set special = :s, version = version + 1").setParameter("s", "new").executeUpdate();
        thing.setSpecial("new");

        em.flush();
        em.getTransaction().commit();
        em.clear();
        em.close();

        emf.close();
    }

    //@Test
    public void testWorkaround() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        Thing thing = new Thing();
        em.persist(thing);

        em.createQuery("update Thing set special = :s, version = version + 1").setParameter("s", "new").executeUpdate();
        ((SelfDirtinessTracker) thing).$$_hibernate_suspendDirtyTracking(true);
        thing.setSpecial("new");
        ((SelfDirtinessTracker) thing).$$_hibernate_suspendDirtyTracking(false);

        em.flush();
        em.getTransaction().commit();
        em.clear();
        em.close();

        emf.close();
    }

}
