package tld.zips.model;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "Zips")
public class Zip implements Serializable
{
	@EmbeddedId
	private ZipId embeddedId;

	@ManyToOne
	@JoinColumn(name = "country_code", referencedColumnName = "iso_code")
	private Country country = null;

	public Zip()
	{
	}

	public Zip(String countryCode, String code)
	{
		this.embeddedId = new ZipId(countryCode, code);

		if ( countryCode != null )
		{
			this.country = new Country(countryCode);
		}
	}

	public ZipId getEmbeddedId()
	{
		return embeddedId;
	}

	public void setEmbeddedId(ZipId embeddedId)
	{
		this.embeddedId = embeddedId;
	}

	public String getCountryCode()
	{
		return embeddedId.getCountryCode();
	}

	public void setCountryCode(String countryCode)
	{
		embeddedId.setCountryCode(countryCode);
	}

	public String getCode()
	{
		return embeddedId.getCode();
	}

	public void setCode(String code)
	{
		embeddedId.setCode(code);
	}

	public Country getCountry()
	{
		return country;
	}

	public void setCountry(Country country)
	{
		this.country = country;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		Zip rhs = (Zip)obj;

		return new EqualsBuilder().append(embeddedId, rhs.getEmbeddedId()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(565479955, 92821).append(embeddedId).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("embeddedId", embeddedId).append("country", country).toString();
	}

}
