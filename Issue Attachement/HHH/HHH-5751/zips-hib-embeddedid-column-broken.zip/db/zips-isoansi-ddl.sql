CREATE TABLE Countries
(
  iso_code CHAR(2) NOT NULL,
  name VARCHAR(50) NOT NULL,
  PRIMARY KEY (iso_code)
);

CREATE TABLE Zips
(
  country_code CHAR(2) NOT NULL,
  code VARCHAR(10) NOT NULL,
  PRIMARY KEY (country_code, code),
  FOREIGN KEY (country_code) REFERENCES Countries (iso_code)
);
