package org.acme;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/**
 *
 * @since 09.05.2023
 */
@QuarkusTest
@Transactional(Transactional.TxType.REQUIRES_NEW)
class MyEntityTest {

    @Inject
    EntityManager em;
    static final long PK = 123L;
    static final String CHANGED = "CHANGED";

    @Test
    void shouldCreateUpdateAndSelectMyEntity() throws Exception {
        insert();
        findAndUpdate();
        selectFiltered();
    }

    void insert() {
        MyEntity myEntity = new MyEntity();
        myEntity.setId(PK);
        MyJson myJson = new MyJson();
        myJson.setLongProp(100L);
        myJson.setStringProp("Hello");
        myEntity.setJsonProperty(myJson);
        em.persist(myEntity);
    }

    void findAndUpdate() {
        MyEntity found = em.find(MyEntity.class, PK);
        found.getJsonProperty().setStringProp(CHANGED);
//        found.setInfo(CHANGED); // by changing any other property of the entity, it will be marked as dirty and EVERY change will be written to the DB
    }

    void selectFiltered() {
        List<MyEntity> result = em
                .createQuery("SELECT e FROM MyEntity e WHERE e.jsonProperty.longProp = :x", MyEntity.class)
                .setParameter("x", 100L)
                .getResultList();
        assertEquals(1, result.size());
        assertEquals(CHANGED, result.get(0).getJsonProperty().getStringProp(), "json property not changed");
        assertEquals(CHANGED, result.get(0).getInfo(), "plain property not changed");
    }
}
