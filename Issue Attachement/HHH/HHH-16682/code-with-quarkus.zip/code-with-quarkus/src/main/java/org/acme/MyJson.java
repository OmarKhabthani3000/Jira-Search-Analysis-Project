
package org.acme;

import jakarta.persistence.Embeddable;
import java.util.Objects;

/**
 * @since 09.05.2023
 */
@Embeddable
public class MyJson {

    private String stringProp;
    private Long longProp;

    public String getStringProp() {
        return stringProp;
    }

    public void setStringProp(String aStringProp) {
        this.stringProp = aStringProp;
    }

    public Long getLongProp() {
        return longProp;
    }

    public void setLongProp(Long aLongProp) {
        this.longProp = aLongProp;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.stringProp);
        hash = 97 * hash + Objects.hashCode(this.longProp);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final MyJson other = (MyJson) obj;
        if (!Objects.equals(this.stringProp, other.stringProp)) {
            return false;
        }
        return Objects.equals(this.longProp, other.longProp);
    }
    
    
}
