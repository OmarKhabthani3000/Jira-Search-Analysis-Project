package org.acme;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.util.Objects;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
//@Table(name = "MY_ENTITY", schema = "base") //with explict table-name & schema it won't work
public class MyEntity {

    @Id
    private Long id;

    @JdbcTypeCode(SqlTypes.JSON)
    private MyJson jsonProperty;
    
    private String info;

    //<editor-fold defaultstate="collapsed" desc="getter & setter">
    public Long getId() {
        return id;
    }
    
    public void setId(Long aId) {
        this.id = aId;
    }
    
    public MyJson getJsonProperty() {
        return jsonProperty;
    }
    
    public void setJsonProperty(MyJson aJsonProperty) {
        this.jsonProperty = aJsonProperty;
    }
    
    public String getInfo() {
        return info;
    }
    
    public void setInfo(String aInfo) {
        this.info = aInfo;
    }
    //</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="hashCode & equals">
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.id);
        hash = 89 * hash + Objects.hashCode(this.jsonProperty);
        hash = 89 * hash + Objects.hashCode(this.info);
        return hash;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final MyEntity other = (MyEntity) obj;
        if (!Objects.equals(this.info, other.info)) {
            return false;
        }
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return Objects.equals(this.jsonProperty, other.jsonProperty);
    }
    //</editor-fold>
}
