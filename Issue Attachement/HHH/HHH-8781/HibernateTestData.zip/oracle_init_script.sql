
Insert into PARENTT (PUID) values ('1');
Insert into PARENTT (PUID) values ('2');

Insert into CHILDONE (CHILD_UID,PUID) values ('1','1');
Insert into CHILDONE (CHILD_UID,PUID) values ('2','1');
Insert into CHILDONE (CHILD_UID,PUID) values ('3','1');
Insert into CHILDONE (CHILD_UID,PUID) values ('4','1');
Insert into CHILDONE (CHILD_UID,PUID) values ('5','1');
Insert into CHILDONE (CHILD_UID,PUID) values ('6','2');
Insert into CHILDONE (CHILD_UID,PUID) values ('7','2');
Insert into CHILDONE (CHILD_UID,PUID) values ('8','2');
Insert into CHILDONE (CHILD_UID,PUID) values ('9','2');

Insert into CHILDTWO (CHILD_UID,PUID) values ('1','1');
Insert into CHILDTWO (CHILD_UID,PUID) values ('2','1');
Insert into CHILDTWO (CHILD_UID,PUID) values ('3','1');
Insert into CHILDTWO (CHILD_UID,PUID) values ('4','2');
Insert into CHILDTWO (CHILD_UID,PUID) values ('5','2');
