import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import java.util.List;
import java.util.UUID;

import static org.hibernate.annotations.CascadeType.REMOVE;

@Entity
@Table(schema = "test", name = "vod__tag")
public class VodTagEntity {

    @Id
    @Column(name = "id", columnDefinition = "uuid")
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(
            name = "UUID",
            strategy = "org.hibernate.id.UUIDGenerator"
    )
    private UUID id;

    @Column(name = "name")
    private String name;

    @Column(name = "attribute_id", columnDefinition = "uuid")
    private UUID attributeId;

    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(
            schema = "test",
            name = "vod__link_video_tag",
            joinColumns = {@JoinColumn(name = "tag_id")}
    )
    @Cascade(REMOVE)
    @Column(name = "video_id")
    private List<UUID> videoIds;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getAttributeId() {
        return attributeId;
    }

    public void setAttributeId(UUID attributeId) {
        this.attributeId = attributeId;
    }

    public List<UUID> getVideoIds() {
        return videoIds;
    }

    public void setVideoIds(List<UUID> videoIds) {
        this.videoIds = videoIds;
    }
}