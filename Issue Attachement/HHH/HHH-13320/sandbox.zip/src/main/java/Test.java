import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
    private static EntityManagerFactory entityManagerFactory =
            Persistence.createEntityManagerFactory("sandbox");

    public static void main(String... args) {
        EntityManager manager = entityManagerFactory.createEntityManager();
    }
}
