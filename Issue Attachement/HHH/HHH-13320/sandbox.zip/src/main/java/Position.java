import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import java.util.UUID;

@MappedSuperclass
public class Position<T> {
    @Id
    @Column(name = "id", columnDefinition = "uuid")
    private UUID id;

    @Column(name = "value")
    private Long value;

    @OneToOne(optional = false, fetch = FetchType.LAZY)
    @PrimaryKeyJoinColumn
    private T entity;

    public Position() {}

    public UUID getId() {return this.id;}

    public Long getValue() {return this.value;}

    public T getEntity() {return this.entity;}

    public void setId(UUID id) {this.id = id; }

    public void setValue(Long value) {this.value = value; }

    public void setEntity(T entity) {this.entity = entity; }
}
