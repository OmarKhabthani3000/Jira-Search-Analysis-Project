import javax.persistence.Entity;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedSubgraph;
import javax.persistence.Table;

@Entity
@Table(schema = "test", name = "category_position")
@NamedEntityGraph(
        name = CategoryPositionEntity.CATEGORY_POSITION__FETCH_ENTITY_WITH_FEATURED,
        attributeNodes = @NamedAttributeNode(value = "entity", subgraph = "entity.featured"),
        subgraphs = @NamedSubgraph(name = "entity.featured", attributeNodes = @NamedAttributeNode("featured"))
)
public class CategoryPositionEntity extends Position<CategoryEntity> {
    public static final String CATEGORY_POSITION__FETCH_ENTITY_WITH_FEATURED = "CategoryPosition" +
            ".fetchEntityWithFeatured";
}


