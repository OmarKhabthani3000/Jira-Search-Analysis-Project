import javax.persistence.Entity;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedSubgraph;
import javax.persistence.Table;

@Entity
@Table(schema = "test", name = "vod__attribute_position")
@NamedEntityGraph(
        name = VodAttributePositionEntity.VOD_ATTRIBUTE_POSITION__FETCH_ENTITY_WITH_TAGS,
        attributeNodes = @NamedAttributeNode(value = "entity", subgraph = "entity.tags"),
        subgraphs = @NamedSubgraph(
                name = "entity.tags",
                attributeNodes = @NamedAttributeNode(value = "tags")
        )
)
public class VodAttributePositionEntity extends Position<VodAttributeEntity> {
    public static final String VOD_ATTRIBUTE_POSITION__FETCH_ENTITY_WITH_TAGS = "VodAttributePosition" +
            ".fetchEntityWithTags";
}
