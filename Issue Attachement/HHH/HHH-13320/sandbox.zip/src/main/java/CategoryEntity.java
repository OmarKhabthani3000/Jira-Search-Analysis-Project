import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@Entity
@Table(schema = "test", name = "category")
public class CategoryEntity {

    @Id
    @Column(name = "id", columnDefinition = "uuid")
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(
            name = "UUID",
            strategy = "org.hibernate.id.UUIDGenerator"
    )
    private UUID id;

    @Column(name = "name")
    private String name;

    @Column(name = "video_block_title")
    private String videoBlockTitle;

    @Column(name = "featured")
    private Boolean featured;

    public UUID getId() {return this.id;}

    public String getName() {return this.name;}

    public String getVideoBlockTitle() {return this.videoBlockTitle;}

    public Boolean getFeatured() {return this.featured;}

    public void setId(UUID id) {this.id = id; }

    public void setName(String name) {this.name = name; }

    public void setVideoBlockTitle(String videoBlockTitle) {this.videoBlockTitle = videoBlockTitle; }

    public void setFeatured(Boolean featured) {this.featured = featured; }
}
