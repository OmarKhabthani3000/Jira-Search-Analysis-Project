package hibtest;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.testng.annotations.Test;


public class TestUpdateWithListAsParam extends AbstractTest {
	
	@Test
	public void testParamListAsNamed() {
		Query q = super.entityManager.createNamedQuery( "update_with_named_list" );
		q.setParameter( "ids", ids() );
		q.executeUpdate();
	}

	@Test
	public void testParamListAsIndexed() {
		Query q = super.entityManager.createNamedQuery( "update_with_indexed_list" );
		q.setParameter( 1, ids() );
		q.executeUpdate();
	}

	private List<Long> ids() {
		List<Long> ids = new ArrayList<Long>(2);
		ids.add( 1l );
		ids.add( 2l );
		return ids;
	}

}
