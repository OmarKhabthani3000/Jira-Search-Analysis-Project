package hibtest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public class AbstractTest {
	
	protected EntityManagerFactory entityManagerFactory;
	
	protected EntityManager entityManager;
	
	protected EntityTransaction tx;
	
	@BeforeClass
	public void createEntityManagerFactory() {
		this.entityManagerFactory = Persistence.createEntityManagerFactory( "hibtest" );
	}
	
	@BeforeMethod
	public void createEntityManager() {
		this.entityManager = this.entityManagerFactory.createEntityManager();
		this.entityManager.setFlushMode( FlushModeType.AUTO );
		this.tx = this.entityManager.getTransaction();
		this.tx.begin();
	}
	
	@AfterMethod
	public void closeEntityManager() {
		if ( this.tx.getRollbackOnly() )
			this.tx.rollback();
		else 
			this.tx.commit();
		this.entityManager.close();
		this.entityManager = null;
	}

}
