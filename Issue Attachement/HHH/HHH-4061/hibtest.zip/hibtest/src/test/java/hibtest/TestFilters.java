package hibtest;


import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.hibernate.Session;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestFilters extends AbstractTest {
	
	@Test
	public void create10() {
		EntityCls cls = new EntityCls();
		this.entityManager.persist( cls );
		this.entityManager.flush();
	}
	
	@Test
	public void testFindAll() {
		Query q = this.entityManager.createQuery( "from EntityCls");
		q.getResultList();
	}
	
	@Test
	public void testFindAllWithFilter() {
		Query q = this.entityManager.createQuery( "from EntityCls");
		Session session = (Session) this.entityManager.getDelegate();
		session.enableFilter( EntityCls.FILTER );
		q.getResultList();
	}
	
	@Test
	public void testUpdate() {
		Query q = this.entityManager.createQuery( "update EntityCls set removed = ?");
		q.setParameter( 1, new Date() );
		q.executeUpdate();
	}
	
	@Test
	public void testUpdateWithFilter() {
		Query q = this.entityManager.createQuery( "update EntityCls set removed = ?");
		q.setParameter( 1, new Date() );
		Session session = (Session) this.entityManager.getDelegate();
		session.enableFilter( EntityCls.FILTER );
		q.executeUpdate();
	}

}
