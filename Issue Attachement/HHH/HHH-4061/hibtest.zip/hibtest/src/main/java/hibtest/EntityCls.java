package hibtest;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;

@Entity
@NamedQueries(
		{
			@NamedQuery(name="update_with_indexed_list", query="UPDATE EntityCls SET removed = current_date WHERE id in (?)"),
			@NamedQuery(name="update_with_named_list", query="UPDATE EntityCls SET removed = current_date WHERE id in (:ids)")
		}
)
@FilterDef(name=EntityCls.FILTER, defaultCondition="is_removed is null")
@Filter(name=EntityCls.FILTER)
public class EntityCls {
	
	public static final String FILTER ="not-removed";
	
	@Id
	@GeneratedValue( strategy=GenerationType.AUTO )
	private Long id;
	
	@Column(name="is_removed")
	private Date removed;

}
