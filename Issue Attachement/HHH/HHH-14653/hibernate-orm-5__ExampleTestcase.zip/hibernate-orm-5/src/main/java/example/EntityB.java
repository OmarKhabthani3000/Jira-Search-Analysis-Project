package example;

public class EntityB {
    private int id;
    private int value_b1;
    private int value_b2;
    private EntityA entityA;

    public EntityB() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getValue_b1() {
        return value_b1;
    }

    public void setValue_b1(int value_b1) {
        this.value_b1 = value_b1;
    }

    public int getValue_b2() {
        return value_b2;
    }

    public void setValue_b2(int value_b2) {
        this.value_b2 = value_b2;
    }

    public EntityA getEntityA() {
        return entityA;
    }

    public void setEntityA(EntityA entityA) {
        this.entityA = entityA;
    }

}