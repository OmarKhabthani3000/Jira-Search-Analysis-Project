package example;

import java.util.Set;

public class EntityA {
    private int id;
    private int value_a1;
    private Set EntityBs;

    public EntityA() {
    }

    public EntityA(int copies, Set EntityBs) {
        this.value_a1 = copies;
        this.EntityBs = EntityBs;
    }

    public int getValue_a1() {
        return value_a1;
    }

    public void setValue_a1(int value_a1) {
        this.value_a1 = value_a1;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Set getEntityBs() {
        return EntityBs;
    }

    public void setEntityBs(Set books) {
        this.EntityBs = books;
    }
}