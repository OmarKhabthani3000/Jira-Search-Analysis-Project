package org.hibernate.bugs;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

/**
 * This template demonstrates how to develop a standalone test case for Hibernate ORM.  Although this is perfectly
 * acceptable as a reproducer, usage of ORMUnitTestCase is preferred!
 */
public class ORMStandaloneTestCase {

	private SessionFactory sf;

	@Before
	public void setup() {
		StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
			// Add in any settings that are specific to your test. See resources/hibernate.properties for the defaults.
			.applySetting( "hibernate.show_sql", "true" )
			.applySetting( "hibernate.format_sql", "true" )
			.applySetting( "hibernate.hbm2ddl.auto", "update" );

		Metadata metadata = new MetadataSources( srb.build() )
		// Add your entities here.
		//	.addAnnotatedClass( Foo.class )
				.addResource("EntityB.hbm.xml")
				.addResource("EntityA.hbm.xml")
				.addResource("myFilter.hbm.xml")

			.buildMetadata();

		sf = metadata.buildSessionFactory();
	}


	@Test
	public void hhh123Test() throws Exception {
		Session session = sf.openSession();
		// Filter is causing the Problem
		session.enableFilter("myFilter").setParameter("myFilterParam", 999);
		session.beginTransaction();

		// Query with subselect
		// The parameters get mixed up. See logs.
		String hql = "SELECT a.id, b.id, b.value_b1, b.value_b2 " + "FROM EntityA a " + "LEFT OUTER JOIN a.entityBs b WITH "
				+ "b.value_b1 = :x1 AND b.value_b2 NOT IN (SELECT value_b2 FROM EntityB WHERE value_b1 = :x2) "
				+ "WHERE a.id>:x3 and b.id>:x4";

		Query query1 = session.createQuery(hql);
		query1.setParameter("x1", 1);
		query1.setParameter("x2", 2);
		query1.setParameter("x3", 3);
		query1.setParameter("x4", 4);
		List results1 = query1.getResultList();



		session.getTransaction().commit();
		session.close();
	}
}
