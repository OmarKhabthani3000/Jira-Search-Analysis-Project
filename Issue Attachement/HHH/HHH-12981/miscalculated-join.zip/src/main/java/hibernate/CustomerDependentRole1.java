package hibernate;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
@DiscriminatorValue("CUSTOMERROLE1")
public class CustomerDependentRole1 extends Role {
    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false, updatable = false)
    private Customer customer;

    @Column
    private String specificField1;

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getSpecificField1() {
        return specificField1;
    }

    public void setSpecificField1(String specificField1) {
        this.specificField1 = specificField1;
    }
}
