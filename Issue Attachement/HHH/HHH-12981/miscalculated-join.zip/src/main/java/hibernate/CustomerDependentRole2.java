package hibernate;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
@DiscriminatorValue("CUSTOMERROLE2")
public class CustomerDependentRole2 extends Role {
    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false, updatable = false)
    private Customer customer;

    @Column
    private String specificField2;

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getSpecificField2() {
        return specificField2;
    }

    public void setSpecificField2(String specificField2) {
        this.specificField2 = specificField2;
    }
}
