package hibernate;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author etamfra
 */
@Configuration
@EntityScan("hibernate")
public class TestConfiguration {
}
