package hibernate;

import static org.hamcrest.MatcherAssert.assertThat;

import java.util.List;
import javax.persistence.EntityManager;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author etamfra
 *
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = { TestConfiguration.class })
@EnableAutoConfiguration
@DataJpaTest
@ActiveProfiles("TEST")
public class HibernateTest {
    @Autowired
    private TestEntityManager entityManager;

    @Before
    public void initRecords() {
        assertThat(entityManager, Matchers.notNullValue());

        getEntityManager().createNativeQuery("TRUNCATE SCHEMA AND COMMIT");

        Customer customer1 = new Customer();
        customer1.setName("Customer10");
        customer1 = entityManager.persistAndFlush(customer1);

        Customer customer2 = new Customer();
        customer2.setName("Customer20");
        customer2 = entityManager.persistAndFlush(customer2);

        CustomerDependentRole1 customerRole1 = new CustomerDependentRole1();
        customerRole1.setName("Customer10_role");
        customerRole1.setCustomer(customer1);
        customerRole1 = entityManager.persistAndFlush(customerRole1);

        CustomerDependentRole2 customerRole2 = new CustomerDependentRole2();
        customerRole2.setName("Customer20_role");
        customerRole2.setCustomer(customer2);
        customerRole2 = entityManager.persistAndFlush(customerRole2);

        UserRole userRole = new UserRole();
        userRole.setRole(customerRole1);
        userRole.setUserName("etamfra");
        userRole = entityManager.persistAndFlush(userRole);

        userRole = new UserRole();
        userRole.setRole(customerRole2);
        userRole.setUserName("etamfra");
        userRole = entityManager.persistAndFlush(userRole);
    }

    @Test
    public void testTreat() {
        List<Customer> resultList1 = getEntityManager().createQuery( //
            "SELECT c FROM UserRole ur JOIN treat (ur.role AS CustomerDependentRole1) cr JOIN Customer c ON c.id = cr.customer WHERE ur.userName = 'etamfra' AND upper(cr.name) = 'CUSTOMER10_ROLE' AND c.name = 'Customer10'"
        ).getResultList();

        List<Customer> resultList2 = getEntityManager().createQuery( //
            "SELECT c FROM UserRole ur JOIN TREAT (ur.role AS CustomerDependentRole2) cr JOIN Customer c ON c.id = cr.customer WHERE ur.userName = 'etamfra' AND upper(cr.name) = 'CUSTOMER20_ROLE' AND c.name = 'Customer20'"
        ).getResultList();

        // UNFORTUNATELY size of resultList1 or resultList2 will be empty because of bug (depending on which entity was scanned first)
        assertThat(resultList1.size() + resultList2.size(), Matchers.equalTo(1));
    }

    private EntityManager getEntityManager() {
        return entityManager.getEntityManager();
    }
}
