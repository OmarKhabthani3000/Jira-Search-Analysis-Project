package error.query.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "qwerty")
public class Qwerty {

	@Id
	private Integer id;

	protected Integer getId() {

		return id;
	}

	protected void setId(Integer id) {

		this.id = id;
	}

}
