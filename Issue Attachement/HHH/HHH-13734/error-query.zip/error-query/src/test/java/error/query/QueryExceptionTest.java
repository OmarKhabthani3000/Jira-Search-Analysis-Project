package error.query;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.stream.IntStream;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.junit.jupiter.api.Test;

import error.query.entities.Qwerty;

public class QueryExceptionTest {

	@Test
	public void testStackOverflowError() {

		List<Integer> intList = new ArrayList<>();
		IntStream.range(0, 200000).forEach(intList::add);

		Properties properties = new Properties();
		properties.put("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
		properties.put("hibernate.hbm2ddl.auto", "update");
		properties.put("hibernate.show_sql", "true");
		properties.put("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
		properties.put("hibernate.connection.url", "jdbc:hsqldb:mem:test");
		properties.put("hibernate.connection.username", "sa");
		properties.put("hibernate.connection.password", "");

		EntityManager entityManager = new Configuration().addProperties(properties).addAnnotatedClass(Qwerty.class)
				.buildSessionFactory(new StandardServiceRegistryBuilder().applySettings(properties).build()).createEntityManager();

		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Qwerty> query = cb.createQuery(Qwerty.class);
		Root<Qwerty> root = query.from(Qwerty.class);
		query.select(root).where(root.get("id").in(intList));

		assertNotNull(entityManager.createQuery(query));

	}

}
