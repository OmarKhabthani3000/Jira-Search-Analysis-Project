package org.hibernate.bugs;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.ManyToOne;

import lombok.Data;


@SuppressWarnings("serial")
@Data
@Embeddable
public class BookPK implements Serializable {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

	
	@ManyToOne(fetch = FetchType.LAZY)
	private Author author;

}
