package org.hibernate.bugs;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

import org.hibernate.envers.Audited;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Data
@RequiredArgsConstructor(staticName = "of")
@NoArgsConstructor
@ToString
@Entity
@Audited
public class Book {


	@EmbeddedId
	private final BookPK pk  = new BookPK();
	    
    @NonNull private String isbn;
    @NonNull private String title;

   
   
}
