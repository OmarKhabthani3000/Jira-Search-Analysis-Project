import static org.junit.Assert.assertThat;

import java.util.HashMap;
import java.util.Map;

import org.hamcrest.CoreMatchers;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Environment;
import org.junit.Test;

public class TestHibernate {

    @Test
    public void testGet() {
        StandardServiceRegistry registry = buildRegistry();
        try (SessionFactory sessionFactory = buildMetadata(registry).buildSessionFactory();
                Session session = sessionFactory.openSession();) {

            buildTables(session);

            session.beginTransaction();
            session.createSQLQuery("INSERT INTO ChildEntity (id) VALUES (11)").executeUpdate();
            session.createSQLQuery("INSERT INTO MainEntity (id, child_id) VALUES (1, 11)").executeUpdate();
            session.getTransaction().commit();

            MainEntity entity = session.get(MainEntity.class, 1);
            assertThat(entity, CoreMatchers.notNullValue());
        } finally {
            StandardServiceRegistryBuilder.destroy(registry);
        }
    }

    @Test
    public void testGetWithErrors() {
        StandardServiceRegistry registry = buildRegistry();
        try (SessionFactory sessionFactory = buildMetadata(registry).buildSessionFactory();
                Session session = sessionFactory.openSession();) {

            buildTables(session);

            session.beginTransaction();
            session.createSQLQuery("INSERT INTO MainEntity (id, child_id) VALUES (1, 11)").executeUpdate();
            session.getTransaction().commit();

            MainEntity entity = session.get(MainEntity.class, 1);
            assertThat(entity, CoreMatchers.notNullValue());
        } finally {
            StandardServiceRegistryBuilder.destroy(registry);
        }
    }

    private Session buildTables(Session session) {
        session.beginTransaction();
        session.createSQLQuery("CREATE TABLE MainEntity (id INT, child_id INT)").executeUpdate();
        session.createSQLQuery("CREATE TABLE ChildEntity (id INT)").executeUpdate();
        session.getTransaction().commit();
        return session;
    }

    private Metadata buildMetadata(StandardServiceRegistry registry) {
        return new MetadataSources(registry)
                .addAnnotatedClass(ChildEntity.class)
                .addAnnotatedClass(MainEntity.class)
                .buildMetadata();
    }

    private StandardServiceRegistry buildRegistry() {
        return new StandardServiceRegistryBuilder()
                .applySettings(buildSettings())
                .build();
    }

    private Map<String, String> buildSettings() {
        Map<String, String> settings = new HashMap<>();
        settings.put(Environment.DRIVER, "org.h2.Driver");
        settings.put(Environment.URL, "jdbc:h2:mem:test");
        settings.put(Environment.USER, "sa");
        settings.put(Environment.PASS, "");
        settings.put(Environment.DIALECT, "org.hibernate.dialect.H2Dialect");
        return settings;
    }
}
