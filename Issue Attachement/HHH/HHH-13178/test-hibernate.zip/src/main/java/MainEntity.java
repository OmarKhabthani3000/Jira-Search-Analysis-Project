import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class MainEntity {

	@Id
	private Integer id;

	@OneToOne
	private ChildEntity child;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public ChildEntity getChild() {
		return child;
	}

	public void setChild(ChildEntity child) {
		this.child = child;
	}

}
