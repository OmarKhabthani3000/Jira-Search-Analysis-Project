package org.hibernate.test.querycache.bag;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@EntityListeners(value={EpgEntityListener.class})
@Entity
public class Company {
	@Id
	long id;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "company")
    @Cache(usage=CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
	Set<User> users = new HashSet<User>();
	
	public void addUser(User user) {
		if (users==null) users=new HashSet<User>();
		users.add(user);
		user.setCompany(this);
	}
	
	public void removeUser(User user) {
		if (users==null) return;
		users.remove(user);
		user.setCompany(null);
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Set<User> getUsers() {
		return users;
	}

	public void setUsers(Set<User> users) {
		this.users = users;
	}
}
