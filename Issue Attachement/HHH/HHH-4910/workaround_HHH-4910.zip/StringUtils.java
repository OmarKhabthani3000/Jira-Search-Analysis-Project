package org.hibernate.test.querycache.bag;

import java.util.List;

/**
 * M�thodes statiques utilitaires pour des cha�nes de caract�res Implementation
 * note: cette classe est plac�e dans le r�pertoire src/main car certaines de
 * ses m�thodes sont utilis�es par des entit�s JPA qui sont charg�es par le
 * classloader par d�faut et non par le classloader "hot deploy" de Seam.
 * 
 * @author jkronegg
 * 
 */
public class StringUtils {
	/**
	 * Retourne true si la chaine de caract�re est null ou est vide
	 * 
	 * @param s
	 * @return
	 */
	public static boolean isNullOrEmpty(String s) {
		return s == null || s.length() == 0;
	}

	/**
	 * Retourne true si la cha�ne de caract�re est non nulle et n'est pas vide.
	 * 
	 * @param s
	 * @return
	 */
	public static boolean isNotNullOrEmpty(String s) {
		return s != null && s.length() > 0;
	}

	/**
	 * Suppression des accents tout en gardant le format de la string de d�part
	 * 
	 * @param nomRue
	 * @return nomRue sans accent
	 */
	public static String supAccent(String nomRue) {
		String nomFormatte = nomRue;
		
		String[][][] regCarSansAccent= new String[2][23][4];
		
		// d�finition de tout ce qui sera transform� en A
		String[] regexA = { "�", "�", "�", "�" };
		regCarSansAccent[1][0]=(regexA);
		regCarSansAccent[0][0][0]="A";
		
		String[] regexa = { "�", "�", "�", "�" };
		regCarSansAccent[1][1]=regexa;
		regCarSansAccent[0][1][0]="a";
		
		// d�finition de ce qui sera transformer en C
		String[] regexC = { "�" };
		regCarSansAccent[1][2]=regexC;
		regCarSansAccent[0][2][0]="C";
		
		// d�finition de ce qui sera transformer en c
		String[] regexc = { "�" };
		regCarSansAccent[1][3]=regexc;
		regCarSansAccent[0][3][0]="c";
		
		// d�finition de ce qui sera transformer en E
		String[] regexE = { "�", "�", "�", "�" };
		regCarSansAccent[1][4]=regexE;
		regCarSansAccent[0][4][0]="E";
		
		// d�finition de ce qui sera transformer en e
		String[] regexe = { "�", "�", "�", "�" };
		regCarSansAccent[1][5]=regexe;
		regCarSansAccent[0][5][0]="e";
		
		// d�finition de ce qui sera transformer en I
		String[] regexI = { "�", "�", "�", "�" };
		regCarSansAccent[1][6]=regexI;
		regCarSansAccent[0][6][0]="I";
		
		// d�finition de ce qui sera transformer en i
		String[] regexi = { "�", "�", "�", "�" };
		regCarSansAccent[1][7]=regexi;
		regCarSansAccent[0][7][0]="i";

		// d�finition de ce qui sera transformer en N
		String[] regexN = { "�" };
		regCarSansAccent[1][8]=regexN;
		regCarSansAccent[0][8][0]="N";
		
		// d�finition de ce qui sera transformer en n
		String[] regexn = { "�" };
		regCarSansAccent[1][9]=regexn;
		regCarSansAccent[0][9][0]="n";

		// d�finition de ce qui sera transformer en O
		String[] regexO = { "�", "�", "�", "�" };
		regCarSansAccent[1][10]=regexO;
		regCarSansAccent[0][10][0]="O";
		
		// d�finition de ce qui sera transformer en o
		String[] regexo = { "�", "�", "�" };
		regCarSansAccent[1][11]=regexo;
		regCarSansAccent[0][11][0]="o";
		

		// d�finition de ce qui sera transformer en U
		String[] regexU = { "�", "�", "�" };
		regCarSansAccent[1][12]=regexU; 
		regCarSansAccent[0][12][0]="U";
		
		// d�finition de ce qui sera transformer en u
		String[] regexu = { "�", "�", "�" };
		regCarSansAccent[1][13]=regexu;
		regCarSansAccent[0][13][0]="u";

		// d�finition de ce qui sera transformer en Y
		String[] regexY = { "ݟ" };
		regCarSansAccent[1][14]=regexY;
		regCarSansAccent[0][14][0]="Y";
		
		// d�finition de ce qui sera transformer en y
		String[] regexy = { "�", "�" };
		regCarSansAccent[1][15]=regexy;
		regCarSansAccent[0][15][0]="y";
		

		// d�finition de ce qui sera transformer en AE
		String[] regexAE = { "�" };
		regCarSansAccent[1][16]=regexAE;
		regCarSansAccent[0][16][0]="AE";
		
		// d�finition de ce qui sera transformer en ae
		String[] regexae = { "�" };
		regCarSansAccent[1][17]=regexae;
		regCarSansAccent[0][17][0]="ae";

		// d�finition de ce qui sera transformer en OE
		String[] regexOE = { "�" };
		regCarSansAccent[1][18]= regexOE;
		regCarSansAccent[0][18][0]="OE";
		
		// d�finition de ce qui sera transformer en oe
		String[] regexoe = { "�" };
		regCarSansAccent[1][19] = regexoe; 
		regCarSansAccent[0][19][0]="oe";
		

		// d�finition de ce qui sera transformer en UE
		String[] regexUE = { "�" };
		regCarSansAccent[1][20] = regexUE; 
		regCarSansAccent[0][20][0]="UE";
		
		// d�finition de ce qui sera transformer en ue
		String[] regexue = { "�" };
		regCarSansAccent[1][21] = regexue;
		regCarSansAccent[0][21][0]="ue";
		
		// d�finition de ce qui sera transformer en SS
		String[] regexB = { "�" }; 
		regCarSansAccent[1][22] = regexB;
		regCarSansAccent[0][22][0]="SS";
		
		
		//parcours du tableau pour supprimer tous les accents par le caract�re correspondant
		for (int j = 0; j < 23; j++) {	
			for(int i = 0;i<regCarSansAccent[1][j].length;i++){
				nomFormatte=nomFormatte.replaceAll(regCarSansAccent[1][j][i], regCarSansAccent[0][j][0]);
			}
		}	
		return nomFormatte;
	}

	public static String implode(List<? extends String> labels, String delimiter) {
		String concat = "";
		for (int i = 0 ; i < labels.size() ; i++) {
			concat += (i == 0 ? "" : delimiter) + labels.get(i).trim();
		}
		return concat;
	}

	
	/**
	 * Capitalizes the given string, i.e. makes the first letter as upper case. 
	 * @param s
	 * @return
	 */
	public static String capitalize(String s) {
		if (s==null || s.length()==0) return s;
		return s.substring(0,1).toUpperCase()+s.substring(1);
	}

	/**
	 * Uncapitalizes the given string, i.e. makes the first letter as lower case. 
	 * @param s
	 * @return
	 */
	public static String uncapitalize(String s) {
		if (s==null || s.length()==0) return s;
		return s.substring(0,1).toLowerCase()+s.substring(1);
	}
	
}
