package org.hibernate.test.querycache.bag;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.persistence.Query;


/**
 * Useful static methods to access JPA properties.
 * Uses introspection.
 * 
 * Implementation note: cette classe est plac�e dans le r�pertoire src/main car
 * certaines de ses m�thodes sont utilis�es par des entit�s JPA qui sont
 * charg�es par le classloader par d�faut et non par le classloader "hot deploy"
 * de Seam.
 * 
 * @author jkronegg
 *
 */
public class JpaUtils {
    private static Logger log = Logger.getLogger(PersistenceUnitTest.class.getName());

    
	/**
	 * Cache for getKeyGetter method.
	 */
	private static HashMap<Class<?>,Method> hm_key_getters = new HashMap<Class<?>,Method>(); 
	/**
	 * Cache for the getGetter method.
	 */
	private static Map<Class<?>,Map<String,Method>> cacheGetGetter = new HashMap<Class<?>,Map<String,Method>>();
	

	
	/**
	 * Append the "where" or "and" keyword depending on the parameter numbers.
	 * @param query
	 * @param nbrParams
	 */
	public static void appendWhereOrAnd(StringBuilder query, int nbrParams) {
		query.append(nbrParams>0?" and ":" where ");
	}

	/**
	 * Append the "where" or "or" keyword depending on the parameter numbers.
	 * @param query
	 * @param nbrParams
	 */
	public static void appendWhereOrOr(StringBuilder query, int nbrParams) {
		query.append(nbrParams>0?" and ":" where ");
	}
	




	/**
	 * Sauve l'�l�ment dans la base de donn�es. Selon que l'objet soit manag� ou non, un persist ou un merge est effectu�.
	 * @param obj
	 * @param em
	 * @return true if persisted, false if updated
	 */
	public static boolean persistOrUpdate(Object obj, EntityManager em) {
		if (em.contains(obj)) {
			em.merge(obj);
			return false;
		} else {
			em.persist(obj);
			return true;
		}
	}
	
	
	
	
	/**
	 * Supprime l'ancienne instance de l'entity si la nouvelle instance de l'entity est null.
	 * @param oldInstance
	 * @param newInstance
	 * @param em
	 */
	public static void removeOldInstanceIfNewInstanceIsNull(Object oldInstance, Object newInstance, EntityManager em) {
		if (oldInstance!=null && newInstance==null) {
			// l'ancien entity est non null et la nouvelle l'est => on supprime l'ancienne
			em.remove(oldInstance);
		}
	}
	
	
	/**
	 * Enable the query cache on the given query
	 * @param q
	 */
	public static Query enableQueryCache(Query q) {
		return enableQueryCache(q, true);
	}
	
	/**
	 * Enable or disable the query cache for the given query
	 * @param q
	 * @param enable
	 */
	public static Query enableQueryCache(Query q, boolean enable) {
		q.setHint("org.hibernate.cacheable", Boolean.valueOf(enable));
		return q;
	}




	
	/**
	 * Return the key getter for the specified class. This getter is
	 * annotated with the javax.persistence.Id annotation.
	 * 
	 * Implementation note:
	 * The key getter is cached for the given class so that
	 * further calls for the same class are much faster.
	 * The method performance has been tested on 200'000 calls:
	 *   - uncached version: 77'420 ns/call
	 *   -   cached version:     75 ns/call
	 * So the improvement is about 1000 times faster!
	 * 
	 * @param c
	 * @return the key getter method, or null if not found
	 */
	public static Method getKeyGetter(Class<?> c) {
			log.info("getKeyGetter.BEGIN(c:"+c+")");
		Method m = hm_key_getters.get(c);
		if (m==null) {
				log.info("not in cache");
			// cached key getter not found => look for it
			Field f = null;
			Field[] fields = c.getDeclaredFields();
			for (int i=0; i<fields.length; i++) {
				if (fields[i].getAnnotation(Id.class)!=null) {
					f = fields[i];
					break;
				}//end if
			}//end for
				log.info("javax.persistence.Id.class annoted field:"+f);
			if (f!=null) {
				// build the getter name
				String getterName = "get"+StringUtils.capitalize(f.getName());
					log.info("javax.persistence.Id.class annoted field:"+f);
				try {
					m = c.getDeclaredMethod(getterName);
				} catch (SecurityException e) {
						log.info("Could not getDeclaredMethod for method name :"+getterName+" in class :"+c+"; SecurityException msg:"+e.getMessage());
				} catch (NoSuchMethodException e) {
						log.info("Could not getDeclaredMethod for method name :"+getterName+" in class :"+c+"; NoSuchMethodException msg:"+e.getMessage());
				}
			}
			if (m == null) {
				Method[] methods = c.getDeclaredMethods();
				for (int i=0; i<methods.length; i++) {
					if (methods[i].getAnnotation(Id.class)!=null) {
						m = methods[i];
						break;
					}//end if
				}//end for
					log.info("javax.persistence.Id.class annoted method:"+m);
			}
			if (m!=null) {
				// found the key getter => return it
				hm_key_getters.put(c, m);
			}
		}//end if
			log.info("getKeyGetter.END; return "+m);
		return m;
	}//end getKeyGetter


	/**
	 * Return the identifier property name for the given class.
	 * Returns null if the key property name could not be found. 
	 * @param c
	 * @return
	 */
	public static String getKeyPropertyName(Class<?> c) {
		Method keyGetter = getKeyGetter(c);
		if (keyGetter==null) return null;
		return getPropertyName(keyGetter);
	}
	
	/**
	 * Return the property name for a given getter or setter.
	 * @param getterOrSetter
	 * @return
	 */
	public static String getPropertyName(Method getterOrSetter) {
		return StringUtils.uncapitalize(getterOrSetter.getName().replaceFirst("^[gs]et", ""));
	}


	/**
	 * Returns the given Entity key.
	 * @param entity
	 * @return
	 */
	public static Serializable getKey(Object entity) {
		try {
			return (Serializable)getKeyGetter(entity.getClass()).invoke(entity, (Object[])null);
		} catch (Exception e) {
			throw new RuntimeException("could not get the Entity id", e);
		}
	}	
	
	
	
	/**
	 * Return the getter for the given field.
	 * @param c
	 * @param fieldName
	 * @param fieldClass
	 * @return
	 */
	public static Method getGetter(Class<?> c, String fieldName) {
			log.info("getGetter.BEGIN(c:"+c.getSimpleName()+", fieldName:"+fieldName+")");
		// Implementation note: 
		//    cached      :  310 ns/call (current version, two hashmaps)
		//    cached (old):  940 ns/call (old version, one hashmap with concatenated string key)
		//    uncached    : 1560 ns/call (old version)
		 
		Method m = null;
		
		// find class Method cache in first cache
		Map<String,Method> m_class = cacheGetGetter.get(c);
		if (m_class==null) {
			// Class method cache not yet initialized for this class => create a new one
			m_class=new HashMap<String,Method>();
			cacheGetGetter.put(c, m_class);
				log.info("init cache for the class");
		}//end if
		
		// find Method in second cache
		m = m_class.get(fieldName);
		if (m!=null) {
			// found a cached Method getter => return it
				log.info("found in cache");
		} else {
			// uncached result => get the method and cache it for future usage
			try {
				String capitalizedFieldName = StringUtils.capitalize(fieldName);
				try {
					m = c.getMethod("get"+capitalizedFieldName, (Class[])null);
				} catch (NoSuchMethodException ee) {
					// not getXXX method found (this may be a boolean) => try isXXX 
					try {
						m = c.getMethod("is"+capitalizedFieldName, (Class[])null);
					} catch (NoSuchMethodException ee2) {
						// no isXXX method found => try to get as method name
						m = c.getMethod(fieldName, (Class[])null);
					}
				}//end try
				if (m!=null) {
					// found a getter => cache it
					if (m.getReturnType()==null) throw new RuntimeException("the getter is not supposed to return void: "+m);
					m_class.put(fieldName, m);
				}//end if
			} catch (Exception e) {
				throw new RuntimeException("could not find a getter for field '"+fieldName+"' in class "+c.getName(), e);
			}//end try		
		}//end if

			log.info("getGetter.END; return "+m);
		return m;
	}//end getGetter
	
	
	
	
	
	
	
	/**
	 * Return the setter for the given field.
	 * TODO: 4. cache the method (see getGetter(Class<?>,String) for implementation and performance details). Performance could be optimized by 5x.
	 * @param c
	 * @param fieldName
	 * @param fieldClass
	 * @return
	 */
	public static Method getSetter(Class<?> c, String fieldName, Class<?> fieldClass) {
		String methodName = "set"+StringUtils.capitalize(fieldName);
		try {
			return c.getDeclaredMethod(methodName, fieldClass);
		} catch (Exception e) {
			throw new RuntimeException("could not find a setter '"+methodName+"("+fieldClass.getName()+")' for field '"+fieldName+"' in class "+c.getName(), e);
		}
	}//end getSetter
	
	/**
	 * Gets a JDBC <code>java.sql.Connection</code> from a JPA <code>javax.persistence.EntityManager</code>.
	 * @param em
	 * @return a <code>java.sql.Connection</code>
	 */
	public static Connection getJDBCConnection(EntityManager em) {
    	Connection myConnection = null;
    	Object o = em.getDelegate();
    	if (o.getClass().getName().startsWith("org.hibernate")) {
    		// hibernate implementation
    		try {
				myConnection = (java.sql.Connection)o.getClass().getMethod("connection").invoke(o);
			} catch (Exception e) {
	            throw new RuntimeException("Could not obtain a JDBC connection!", e);
			}
    	} else {
    		//TODO other implementation ...
    	}
    	return myConnection;
	}



	/**
	 * Return a String representation for the given JPA entity.
	 * Robust to LazyInitializationException
	 * @param utModuleT
	 * @return
	 */
	public static String toString(Object obj) {
		try {
			return obj.toString();
		} catch (Throwable e) {
			// probably a LazyInitializationException
			// TODO in case of LazyInitializationException, return a generic String description based on the entity class name and id
			return e.getClass().getSimpleName()+"/"+e.getMessage();
		}		
	}
	
}
