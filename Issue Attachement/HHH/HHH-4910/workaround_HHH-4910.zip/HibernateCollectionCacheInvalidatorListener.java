package org.hibernate.test.querycache.bag;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javassist.Modifier;

import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PostPersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

import org.hibernate.SessionFactory;
import org.hibernate.annotations.Cache;
import org.hibernate.proxy.HibernateProxy;

/**
 * EntityListener for the L2 collection cache. When an entity is added or
 * removed, all corresponding cached collections are evicted from L2 cache.
 * 
 * Usage:
 *   1) add @EntityListeners(value={HibernateCollectionCacheInvalidatorListener.class}) on every entity class
 *   2) call HibernateCollectionCacheInvalidatorListener.setSessionFactory(SessionFactory) to initialize the session factory
 *  
 * Note : this works only if there is only one persistence unit. If there are more than one persistence unit, the static session factory cannot be used anymore and must be given at each call. 
 *  
 * @author inf27
 *
 */
public class HibernateCollectionCacheInvalidatorListener {
	static Logger log = Logger.getLogger(HibernateCollectionCacheInvalidatorListener.class.getName());

	static Map<String,Field> collectionFields = new HashMap<String,Field>();

	static Map<String,FieldCollectionPair[]> manyToOneFieldCollections = new HashMap<String,FieldCollectionPair[]>();

	

	
	

	
	
	/**
	 * Evicts all entities where the given entity is included.
	 * Performances:
	 *  - First call for one entity class:         800 us/call
	 *  - Further calls for the same entity class:   3 us/call
	 * @param entity the entity persisted or removed
	 */
	@PostPersist
	@PreRemove
	public static void evictCollectionsWhereIAmIn(Object entity) {
		evictCollectionsWhereIAmIn(entity, HibernateUtils.getCurrentSessionFactory());
	}

	@PreUpdate
	public static void evictCollectionsWhereIAmInForUpdate(Object entity) {
		evictCollectionsWhereIAmInForUpdate(entity, HibernateUtils.getCurrentSessionFactory());
	}
	
	
	
	
	/**
	 * Evicts all entities where the given entity is included.
	 * Performances:
	 *  - First call for one entity class:         800 us/call
	 *  - Further calls for the same entity class:   3 us/call
	 * @param entity the entity persisted or removed
	 * @param sf the session factory which holds the entity collections cache.
	 */
	public static void evictCollectionsWhereIAmIn(Object entity, SessionFactory sf) {
		log.finest("evictCollectionsWhereIAmIn: class="+entity.getClass().getName());
		if (entity instanceof HibernateProxy) {
			// found a proxy => get its value
			entity = ((HibernateProxy)entity).getHibernateLazyInitializer().getImplementation();
			// Implementation note: this case occurs most probably when the
			// entity is removed from the database. This, this is not the
			// optimal approach, since we load the object using the
			// LazyInitializer, then it will be removed later. A better 
			// implementation would be to traverse the proxy and for each
			// field, determine if the original entity field with the same 
			// name is annotated. But since this is mostly for removing, 
			// the performance impact is not so high.
		}
//		long t0 = System.currentTimeMillis();
//		int n=100000;
//		for (int j=0; j<n;j++) {
		
		// get the list of ManyToOne fields for the given entity
		FieldCollectionPair[] listFields = getFieldCollectionPairList(entity.getClass());
		
		// evicts the collection for ManyToOne fields from L2 cache
		for (FieldCollectionPair fcp : listFields) {

			// get the field value identifier 
			Serializable id = null;
			try {
				Object value = fcp.getField().get(entity);
				if (value instanceof HibernateProxy) {
					// found a proxy => get the value identifier from the proxy
					id = ((HibernateProxy)value).getHibernateLazyInitializer().getIdentifier();
				} else {
					// found a true object
					id = (value!=null?(Serializable)fcp.getKeyGetter().invoke(value, (Object[])null):null);
				}
			} catch (Exception e) {
				throw new RuntimeException("could not get the value for field "+fcp.getField().getName(), e);
			}
			
			if (id!=null) {
				// foreign key provided => look for the collection class and evict it
				String collectionRegionName = fcp.getCollectionRole();
				
				// evict the collection for the current
				log.info("evicting collection "+collectionRegionName+" for entity id="+id);
				sf.evictCollection(collectionRegionName, id);
			}
		}
		
//		}
//		long t1 = System.currentTimeMillis();
//		log.info("evictCollectionsIAmIn: duration="+(t1-t0)*1000*1000/n+" ns");
	}


	/**
	 * Evicts the collections where the entity previous was involved and
	 * where the entity current state is newly involved.
	 * @param entity
	 * @param sf
	 */
	public static void evictCollectionsWhereIAmInForUpdate(Object entity, SessionFactory sf) {
		Object previousEntity = HibernateUtils.getPreviousEntity(entity);
		
		// get the @ManyToOne fields
		FieldCollectionPair[] listFields = getFieldCollectionPairList(entity.getClass());
		
		for (FieldCollectionPair fcp : listFields) {
			Field f = fcp.getField();
			Method kg = fcp.getKeyGetter();
			
			// get the current field value identifier
			Serializable id = null;
			try {
				Object value = f.get(entity);
				if (value instanceof HibernateProxy) {
					// found a proxy => get the value identifier from the proxy
					id = ((HibernateProxy)value).getHibernateLazyInitializer().getIdentifier();
				} else {
					// found a true object
					if (!sf.getCurrentSession().contains(value)) {
						// value not yet managed => manage it
						sf.getCurrentSession().update(value);
					}
					id = (value!=null?(Serializable)kg.invoke(value, (Object[])null):null);
				}
			} catch (Exception e) {
				throw new RuntimeException("could not get the value for field "+fcp.getField().getName(), e);
			}
			
			// get the previous value identifier
			Serializable previousId = null;
			try {
				Object value = f.get(previousEntity);
				if (value instanceof HibernateProxy) {
					// found a proxy => get the value identifier from the proxy
					previousId = ((HibernateProxy)value).getHibernateLazyInitializer().getIdentifier();
				} else {
					// found a true object
					if (!sf.getCurrentSession().contains(value)) {
						// value not yet managed => manage it
						sf.getCurrentSession().update(value);
					}
					previousId = (value!=null?(Serializable)kg.invoke(value, (Object[])null):null);
				}
			} catch (Exception e) {
				throw new RuntimeException("could not get the previous value for field "+fcp.getField().getName(), e);
			}
			
			// evict when needed
			// Implementation note:
			//  previousId	currentId	--> action
			//  -----------------------------------
			//  null		null		--> nothing
			//  null		val			--> evict(val)
			//  val			null		--> evict(val)
			//	val1		val2		--> evict(val1), evict(val2)
			//  val			val			--> nothing
			if ((id!=null || previousId!=null) && !id.equals(previousId)) {
				// value changed => look for the collection class and evict it
				String collectionRegionName = fcp.getCollectionRole();
				
				// evict the collection with the current key
				if (id!=null) {
					log.info("evicting collection "+collectionRegionName+" for entity id="+id);
					sf.evictCollection(collectionRegionName, id);
				}

				// evict the collection with the previous key
				if (previousId!=null) {
					log.info("evicting collection "+collectionRegionName+" for entity id="+previousId);
					sf.evictCollection(collectionRegionName, previousId);
				}
			}
			
		}//end for
		
	}


	private static FieldCollectionPair[] getFieldCollectionPairList(Class<? extends Object> entityClass) {
		String key = entityClass.getName();
		FieldCollectionPair[] result = manyToOneFieldCollections.get(key);
		if (result==null) {
			// no list of ManyToOne fields for this class => build the list
			List<FieldCollectionPair> listFields = new ArrayList<FieldCollectionPair>();
			Field[] fields = entityClass.getDeclaredFields();
			for (Field f : fields) {
				ManyToOne manyToOne = f.getAnnotation(ManyToOne.class);
				if (manyToOne!=null) {
					// got a @ManyToOne field => collect it
					f.setAccessible(true);
					String crn = getCollectionRegionName(entityClass, f);
					if (crn!=null) {
						// collection is cached => keep the field
						Method keyGetter = JpaUtils.getKeyGetter(f.getType());
						listFields.add(new FieldCollectionPair(f,crn, keyGetter));
					}
					//log.info("entityClass="+entity.getClass().getName()+", field="+f.getName()+", collectionRegionName="+crn);
				}
			}
			
			// add the newly created collections to the map
			result = listFields.toArray(new FieldCollectionPair[listFields.size()]);
			manyToOneFieldCollections.put(key, result);
		}
		return result;
	}

	private static String getCollectionRegionName(Class<?> entityClass, Field f) {
		Class<?> collectionClass = f.getType();
		Field collectionField = findCollectionField(collectionClass, f.getName(), entityClass);
		if (collectionField==null) {
			// unmapped field (i.e. the entity does not define a collection for that field) => no collection to evict
			return null;
		}
		Cache cache = collectionField.getAnnotation(Cache.class);
		if (cache!=null) {
			// cached collection => return the collection role name
			String collectionRegionName = collectionClass.getName()+"."+collectionField.getName();
			// Implementation note: the cache region name is independent of the collection name
			return collectionRegionName;
		} else {
			// uncached collection => nothing to evict
			return null;
		}
	}






	/**
	 * Return the Field corresponding to the given foreign property name
	 * @param collectionClass
	 * @param foreignPropertyName
	 * @param classOfElement 
	 * @return
	 */
	private static Field findCollectionField(Class<?> collectionClass, String foreignPropertyName, Class<?> classOfElement) {
		String key = collectionClass.getName()+"/"+foreignPropertyName+"/"+classOfElement.getName();
		Field field = collectionFields.get(key);
		if (field==null) {
			for (Field f : collectionClass.getDeclaredFields()) {
				OneToMany oneToMany = f.getAnnotation(OneToMany.class);
				if (oneToMany==null &&
					!Modifier.isStatic(f.getModifiers()) &&
					!Modifier.isFinal(f.getModifiers())) {
					// no OneToMany annotation on the field => look on the getter (maybe getter annotation instead of field annotation)
					try {
						oneToMany = JpaUtils.getGetter(collectionClass, f.getName()).getAnnotation(OneToMany.class);
					} catch (Throwable e) {
						// probably no getter for the given field => do nothing
					}
				}
				if (oneToMany!=null &&
					oneToMany.mappedBy().equals(foreignPropertyName)) {
					// oneToMany property mapped by the required property name => determine if the class of object is correct
					ParameterizedType t = (ParameterizedType)f.getGenericType();
					//log.info(t.getActualTypeArguments()[0].toString()+" "+classOfElement.getName());
					if (t.getActualTypeArguments()[0].equals(classOfElement)) {
						// found the corresponding collection field => return it
						field=f;
						collectionFields.put(key,f);
						break;
					}
				}
			}
			if (field==null && log.isLoggable(Level.FINEST)) {
				// field not found in the parent class => raise a warning
				// Implementation note: if the field is null, this means that the @ManyToOne mapping in the child is not mapped in the parent. So this warning may be used to improve the entity definition
				log.finest("Missing @OneToMany mapping to "+classOfElement.getName()+"/"+foreignPropertyName+" in entity "+collectionClass.getName());
			}
		}
		return field;
	}




	public static class FieldCollectionPair {
		private Field f;
		private String collectionRole;
		private Method keyGetter;
		public FieldCollectionPair(Field f, String collectionRole, Method keyGetter) {
			super();
			this.f = f;
			this.collectionRole = collectionRole;
			this.keyGetter = keyGetter;
		}
		public Field getField() {
			return f;
		}
		public String getCollectionRole() {
			return collectionRole;
		}
		public Method getKeyGetter() {
			return keyGetter;
		}
		
	}

}
