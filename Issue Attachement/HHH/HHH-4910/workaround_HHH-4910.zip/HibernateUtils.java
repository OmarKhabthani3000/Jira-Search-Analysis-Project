package org.hibernate.test.querycache.bag;

import org.hibernate.SessionFactory;

public class HibernateUtils {
	static SessionFactory sf;
	
	/**
	 * Returns the current session factory
	 * @return
	 */
	public static SessionFactory getCurrentSessionFactory() {
		return sf;
	}

	/**
	 * Returns the entity previous state from its current state.
	 * Returns null when the entity has no previous state
	 * @param entity
	 * @return
	 */
	public static Object getPreviousEntity(Object entity) {
		// TODO 1. implement the previous entity method
		return null; 
	}

	public static void setSessionFactory(SessionFactory sf) {
		HibernateUtils.sf = sf;
	}

}
