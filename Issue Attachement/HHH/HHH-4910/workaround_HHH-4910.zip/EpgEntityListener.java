package org.hibernate.test.querycache.bag;

import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

/**
 * Do some specific processing when an entity is persisted/updated/removed.
 * To activate, add in every class:
 * 		@EntityListeners(value={EpgEntityListener.class})
 * 
 * @author jkronegg
 *
 */
public class EpgEntityListener {
	private static final boolean enableCollectionCacheInvalidation = true;

	@PrePersist
	public static void prePersist(Object entity) {
		
	}

	@PostPersist
	public static void postPersist(Object entity) {
		// evict collections where that given entity is involved
		if (enableCollectionCacheInvalidation) HibernateCollectionCacheInvalidatorListener.evictCollectionsWhereIAmIn(entity);
	}

	@PreRemove
	public static void preRemove(Object entity) {
		// evict collections where that given entity is involved
		if (enableCollectionCacheInvalidation) HibernateCollectionCacheInvalidatorListener.evictCollectionsWhereIAmIn(entity);
	}

	@PostRemove
	public static void postRemove(Object entity) {
	}

	@PreUpdate
	public static void preUpdate(Object entity) {
		// evict collections where that given entity is involved
		if (enableCollectionCacheInvalidation) HibernateCollectionCacheInvalidatorListener.evictCollectionsWhereIAmInForUpdate(entity);
	}
	
	@PostUpdate
	public static void postUpdate(Object entity) {
	}
}
