package org.hibernate.test.dialect.namespace;

import java.sql.Connection;
import java.sql.SQLException;

import org.hibernate.engine.jdbc.connections.internal.UserSuppliedConnectionProviderImpl;

public class InformixMockConnectionProvider extends UserSuppliedConnectionProviderImpl {
	private static final long serialVersionUID = 1L;
	private Connection connection;

	@Override
	public Connection getConnection() throws SQLException {
		if (connection == null) {
			connection = Mocks.createConnection("db1", 0);
		}
		return connection;
	}

	@Override
	public void closeConnection(Connection conn) throws SQLException {
	}


}
