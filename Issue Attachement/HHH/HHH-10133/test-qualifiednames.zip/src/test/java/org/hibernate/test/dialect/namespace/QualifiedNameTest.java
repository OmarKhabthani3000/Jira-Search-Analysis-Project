package org.hibernate.test.dialect.namespace;

import static org.junit.Assert.assertEquals;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.relational.Namespace;
import org.hibernate.dialect.InformixCatalogDialect;
import org.hibernate.mapping.Table;
import org.hibernate.testing.RequiresDialect;
import org.hibernate.testing.junit4.BaseNonConfigCoreFunctionalTestCase;
import org.junit.Test;

@RequiresDialect(value = { InformixCatalogDialect.class })
public class QualifiedNameTest extends BaseNonConfigCoreFunctionalTestCase {

	@Override
	protected Class<?>[] getAnnotatedClasses() {
		return new Class[] { Box.class };
	}

	@Entity(name = "Box")
	@javax.persistence.Table(name = "Box", schema = "PUBLIC", catalog = "DB1")
	public static class Box {
		@Id
		public Integer id;
		public String value;
	}

	@Override
	protected boolean createSchema() {
		return false;
	}

	@Test
	public void testQualifiedNameSeparator() throws Exception {
		for (Namespace namespace : metadata().getDatabase().getNamespaces()) {
			Identifier catalogIdentifier = namespace.getName().getCatalog();
			Identifier schemaIdentifier = namespace.getName().getSchema();
			String catalog = catalogIdentifier == null ? null : catalogIdentifier.render(getDialect());
			String schema = schemaIdentifier == null ? null : schemaIdentifier.render(getDialect());

			for (Table table : namespace.getTables()) {
				String formatedNameString = metadata().getDatabase().getJdbcEnvironment().getQualifiedObjectNameFormatter().format(
						table.getQualifiedTableName(), getDialect());
				assertEquals(formatedNameString, table.getQualifiedTableName().render() );
				assertEquals(formatedNameString, table.getQualifiedName(getDialect(), catalog, schema));
			}
		}
	}

}
