package org.hibernate.envers.test.integration.onetoone.bidirectional;

import org.hibernate.envers.Audited;

@Audited
public class BidirectionalRefIngPK {
    private long id;
    private String data;
    private BidirectionalRefEdPK reference;

    public BidirectionalRefIngPK() {}

    public BidirectionalRefIngPK(long id, String data) {
        this.data = data;
    }

    public BidirectionalRefIngPK(long id, String data, BidirectionalRefEdPK reference) {
        this.data = data;
        this.reference = reference;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public BidirectionalRefEdPK getReference() {
        return reference;
    }

    public void setReference(BidirectionalRefEdPK reference) {
        this.reference = reference;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BidirectionalRefIngPK)) return false;

        BidirectionalRefIngPK that = (BidirectionalRefIngPK) o;

        if (data != null ? !data.equals(that.data) : that.data != null) return false;
        Long id = new Long(this.id);
        Long thatId = new Long(that.id);
        if (id != null ? !id.equals(that.id) : thatId != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        Long id = new Long(this.id);
        result = (id != null ? id.hashCode() : 0);
        result = 31 * result + (data != null ? data.hashCode() : 0);
        return result;
    }
}
