package org.hibernate.envers.test.integration.onetoone.bidirectional;

import java.net.URL;

import javax.persistence.EntityManager;

import org.hibernate.ejb.Ejb3Configuration;
import org.hibernate.envers.test.AbstractEntityTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class GreedyLoading extends AbstractEntityTest {
	private Long ed1_id;
	
	@Override
	public void configure(Ejb3Configuration cfg) {
    	URL path = Thread.currentThread().getContextClassLoader().getResource("greedyloading.hbm.xml");
    	cfg.addFile(path.getFile());
    }
	
	@BeforeClass(dependsOnMethods = "init")
    public void initData() {
        BidirectionalRefEdPK ed1 = new BidirectionalRefEdPK(1, "data_ed_1");
        BidirectionalRefIngPK ing1 = new BidirectionalRefIngPK(3, "data_ing_1");

        // Revision 1
        EntityManager em = getEntityManager();
        em.getTransaction().begin();

        ing1.setReference(ed1);
        
        em.persist(ed1);
        em.persist(ing1);
        em.getTransaction().commit();

        // Revision 2
        em.getTransaction().begin();

        ing1 = em.find(BidirectionalRefIngPK.class, ing1.getId());
        em.getTransaction().commit();

        ed1_id = ed1.getLongId();
    }

    @Test
    public void testRevisionsCounts() {
    	BidirectionalRefIngPK referencing = getAuditReader().find(BidirectionalRefIngPK.class, ed1_id, 1);
    	assert referencing.getReference().getData()!=null;
    }

}
