package org.hibernate.envers.test.integration.onetoone.bidirectional;

import org.hibernate.envers.Audited;

/**
 * <b>BidirectionalRefEdPK</b>
 * <p>
 *
 * @author Quartet Financial Systems
 * @see
 */
@Audited
public class BidirectionalRefEdPK {
    private long longId;
    private String data;
    private BidirectionalRefIngPK referencing;

    public BidirectionalRefEdPK() {}

    public BidirectionalRefEdPK(long id, String data) {
        this.data = data;
    }

    public BidirectionalRefEdPK(long id, String data, BidirectionalRefIngPK referencing) {
        this.data = data;
        this.referencing = referencing;
    }

    public long getLongId() {
        return longId;
    }

    public void setLongId(Long id) {
        this.longId = id;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public BidirectionalRefIngPK getReferencing() {
        return referencing;
    }

    public void setReferencing(BidirectionalRefIngPK referencing) {
        this.referencing = referencing;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BidirectionalRefEdPK)) return false;

        BidirectionalRefEdPK that = (BidirectionalRefEdPK) o;

        if (data != null ? !data.equals(that.data) : that.data != null) return false;
        Long longId = new Long(this.longId);
        Long thatLongId = new Long(that.longId);
        if (longId != null ? !longId.equals(that.longId) : thatLongId != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        Long longId = new Long(this.longId);
        result = (longId != null ? longId.hashCode() : 0);
        result = 31 * result + (data != null ? data.hashCode() : 0);
        return result;
    }
}
