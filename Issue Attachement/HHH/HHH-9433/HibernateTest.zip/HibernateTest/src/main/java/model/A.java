package model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


@Entity
public class A implements Serializable {

    @Id
    @GeneratedValue
    public long id;

    public String string;

    @ManyToMany
    @JoinTable(joinColumns = {
            @JoinColumn(name="string", referencedColumnName = "string")
    })
    public List<B> bs;

    @Override
    public String toString() {
        return "A{" +
                "bs=" + bs +
                '}';
    }
}
