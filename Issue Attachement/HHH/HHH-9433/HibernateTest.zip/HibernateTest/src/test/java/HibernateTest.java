import hibernate.HibernateUtil;
import model.A;
import model.B;
import org.hibernate.Query;
import org.hibernate.Session;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by agimission on 08/10/14.
 */
public class HibernateTest {

    @Test
    public void basicTest() {
        Session session = HibernateUtil.getSessionFactory().openSession();

        session.beginTransaction();
        B b = new B();
        session.save(b);
        A a = new A();
        a.string = "string";
        a.bs = new ArrayList<B>();
        a.bs.add(b);
        session.save(a);
        session.getTransaction().commit();
        session.clear();

        Query q =session.createQuery("From A");
        List<A> as = q.list();
        System.out.println("number of a : " + as.size());
        System.out.println(as.get(0));
    }
}
