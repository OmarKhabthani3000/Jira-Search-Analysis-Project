package com.myapp.entities;

import java.util.concurrent.ThreadLocalRandom;
import javax.persistence.Entity;
import javax.persistence.Id;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

@Entity
public class Details {

	@Id
	int id;
	
	@Type(type = "com.myapp.entities.SecuredStringType",parameters = {@Parameter(name = "key",value = "698")})
	private String secString;
	
	@Type(type = "com.myapp.entities.SecuredStringType",parameters = {@Parameter(name = "key",value = "456")})
	private String secName;
	
	@Type(type = "com.myapp.entities.SecuredStringType",parameters = {@Parameter(name = "key",value = "222")})
	private String secLocation;
	
	@Type(type = "com.myapp.entities.SecuredStringType",parameters = {@Parameter(name = "key",value = "698")})
	private String secString2;
	
	@Type(type = "com.myapp.entities.SecuredStringType",parameters = {@Parameter(name = "key",value = "456")})
	private String secName2;
	
	@Type(type = "com.myapp.entities.SecuredStringType",parameters = {@Parameter(name = "key",value = "222")})
	private String secLocation2;
	
	public String getSecName() {
		return secName;
	}

	public void setSecName(String secName) {
		this.secName = secName;
	}

	public String getSecLocation() {
		return secLocation;
	}

	public void setSecLocation(String secLocation) {
		this.secLocation = secLocation;
	}

	public String getSecString2() {
		return secString2;
	}

	public void setSecString2(String secString2) {
		this.secString2 = secString2;
	}

	public String getSecName2() {
		return secName2;
	}

	public void setSecName2(String secName2) {
		this.secName2 = secName2;
	}

	public String getSecLocation2() {
		return secLocation2;
	}

	public void setSecLocation2(String secLocation2) {
		this.secLocation2 = secLocation2;
	}

	public Details()
	{
		
	}
	
	public Details(int id)
	{
		this.id = id;
		secString = "Codename "+id;
		secName = "Realname "+id;
		secLocation = "Location "+id;
		secString2 = "Codename "+id;
		secName2 = "Realname "+id;
		secLocation2 = "Location "+id;
	}
	
	public String toString()
	{
		return id+" :: "+secString+" of "+secName+" at "+secLocation+" :: "+secString2+" of "+secName2+" at "+secLocation2;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSecString() {
		return secString;
	}

	public void setSecString(String secString) {
		this.secString = secString;
	}

	public void reassign() {
		reassign(ThreadLocalRandom.current().nextInt(0, 10000),ThreadLocalRandom.current().nextInt(0, 10000));
	}
	
	public void reassign(int codeId, int locId)
	{
		secString = "Codename "+codeId;
		secLocation = "Location "+locId;
	}
	
}
