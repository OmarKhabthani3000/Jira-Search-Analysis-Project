package com.myapp.entities;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Properties;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.type.ConcurrentHashMapBackedProperties;
import org.hibernate.usertype.ParameterizedType;
import org.hibernate.usertype.UserType;


public class SecuredStringType implements ParameterizedType, UserType{
	
	private Properties parameters;
	
	private static final String APPENDER = "---";
	
	
	@Override
	public void setParameterValues(Properties parameters) {
		this.parameters = parameters;
	}

	public int[] sqlTypes() {
		return new int[]{Types.LONGVARCHAR};
	}

	public Class returnedClass() {
		return String.class;
	}

	public boolean equals(Object x, Object y) throws HibernateException {
		if(x == null || y == null) return false;
		return x.equals(y);
	}

	public int hashCode(Object x) throws HibernateException {
		return x.hashCode();
	}

	public Object nullSafeGet(ResultSet rs, String[] names, SharedSessionContractImplementor session, Object owner)
			throws HibernateException, SQLException {
		String encryptedEntity = rs.getString(names[0]);
		String decryptedEntity = null;
		if (encryptedEntity != null) {
			if (encryptedEntity.startsWith(parameters.getProperty("key") + APPENDER)) {
				String key = parameters.getProperty("key");
				decryptedEntity = encryptedEntity.replaceFirst("^" + key + APPENDER, "");
			}
			else
			{
				decryptedEntity = encryptedEntity;
			}
		}
		return decryptedEntity;
	}

	public void nullSafeSet(PreparedStatement st, Object value, int index, SharedSessionContractImplementor session)
			throws HibernateException, SQLException {
		if (value != null) {
			String encryptedEntity = parameters.getProperty("key") + APPENDER + (String) value;
			st.setString(index, encryptedEntity);
		}
	}

	public Object deepCopy(Object value) throws HibernateException {
		return new String((String) value);
	}

	public boolean isMutable() {
		return false;
	}

	public Serializable disassemble(Object value) throws HibernateException {
		return (Serializable) value;
	}

	public Object assemble(Serializable cached, Object owner) throws HibernateException {
		return cached;
	}

	public Object replace(Object original, Object target, Object owner) throws HibernateException {
		return original;
	}

}
