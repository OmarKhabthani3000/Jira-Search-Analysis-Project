package com.myapp.services;

import java.util.Collection;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.myapp.entities.Details;

@Service
public class MyService {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@SuppressWarnings({ "unchecked", "unused" })
	public void reproduceIssue() {

		// Uncomment to persist entities for fresh DB
		//persistMany(10000);

		ExecutorService executor = Executors.newFixedThreadPool(100);
		@SuppressWarnings("rawtypes")
		CompletionService cs = new ExecutorCompletionService(executor);
		
		int THREADCOUNT = 2000;
		
		for (int i = 0; i < THREADCOUNT; i++) {
					cs.submit(() -> {
				Collection<Details> fetchedEntites = reassignAll();
				return null;
			});

		}

		Details fetchedDetails = entityManager.find(Details.class, 10);
		System.out.println(fetchedDetails);

	}
	
	public void persistMany(int num) {
		TransactionStatus txStatus = transactionManager
				.getTransaction(new DefaultTransactionDefinition(TransactionDefinition.PROPAGATION_REQUIRES_NEW));

		for (int i = 0; i < num; i++) {
			Details details = new Details(10 + i * 100);
			entityManager.persist(details);
		}
		transactionManager.commit(txStatus);
	}

	@SuppressWarnings("unchecked")
	public Collection<Details> reassignAll() {
		TransactionStatus txStatus = transactionManager
				.getTransaction(new DefaultTransactionDefinition(TransactionDefinition.PROPAGATION_REQUIRES_NEW));
		Query query = entityManager.createQuery("SELECT e FROM Details e");
		Collection<Details> fetchedDetails = (Collection<Details>) query.getResultList();
		transactionManager.commit(txStatus);
		return fetchedDetails;
	}

}

class MyWorker implements Runnable {

	public void run() {

	}

}
