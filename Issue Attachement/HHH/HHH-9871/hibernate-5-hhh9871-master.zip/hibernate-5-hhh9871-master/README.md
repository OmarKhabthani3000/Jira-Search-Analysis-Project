# hibernate-5-hhh9871
https://hibernate.atlassian.net/browse/HHH-9871 Issue reproduce with Hibernate 5

Hibernate 4 test case - https://github.com/kwon37xi/hibernate-customtype-same-value-binding-bug