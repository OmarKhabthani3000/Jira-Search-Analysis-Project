package fr.into.tests;

public class ArchiveEntryTest extends ArchiveEntry {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
