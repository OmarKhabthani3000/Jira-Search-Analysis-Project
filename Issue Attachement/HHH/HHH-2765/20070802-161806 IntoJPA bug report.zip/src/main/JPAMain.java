package main;

import java.util.Date;

import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import fr.into.tests.ArchiveId;
import fr.into.tests.Person;

public class JPAMain {
	public static ThreadLocal<EntityManager>	EM	= new ThreadLocal<EntityManager>();

	public static void main(String[] args) throws NamingException {
		save( false );
		save( true );
	}

	private static void save(boolean update) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory( "IntoJPA" );
		EntityManager em = emf.createEntityManager();

		try {
			EntityTransaction transaction = em.getTransaction();
			transaction.begin();
			Person zied;
			if( update )
				zied = em.find( Person.class, new ArchiveId( 1, 1 ) );
			else
				zied = new Person( new ArchiveId( 1, 1 ) );

			zied.getEntry().setNote( update ? "second" : "first" );
			zied.getEntry().setStartDate( new Date() );
			JPAMain.EM.set( em );
			
			if( update ) {
				System.out.println( "Updating person: " + zied );
				em.merge( zied );
			} else {
				System.out.println( "Inserting person: " + zied );
				em.persist( zied );
			}
			transaction.commit();
		} catch( Exception ex ) {
			ex.printStackTrace();
		} finally {
			em.close();
			emf.close();
		}
	}
}
