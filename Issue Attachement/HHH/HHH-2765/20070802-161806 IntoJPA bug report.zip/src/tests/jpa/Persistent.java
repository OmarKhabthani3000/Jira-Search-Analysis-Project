package tests.jpa;

import static javax.persistence.GenerationType.TABLE;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.TableGenerator;

@Entity
public class Persistent {
	private long		id;
	private String	name;

	public Persistent() {
	}

	public Persistent(String name) {
		this.name = name;
	}

	@Id
	@GeneratedValue(strategy = TABLE, generator = "persistent_gen")
	@TableGenerator(name = "persistent_gen", table = "persistent_key_gen", pkColumnName = "seq_name", 
			valueColumnName = "seq_value", pkColumnValue = "Persistence_seq", initialValue = 1, allocationSize = 1)
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Basic
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
