package fr.into.tests;

import javax.persistence.Entity;

@Entity
public class Person extends Archivable {

	public Person() {
	}

	public Person(ArchiveId archiveId) {
		super(archiveId);
	}

	@Override
	public long nextRevision() {
		return getRevision() + 1;
	}

	@Override
	public String toString() {
		return "Person "+ getArchiveId();
	}
	
}
