package fr.into.tests;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import javax.persistence.*;

import fr.into.tests.listeners.persistence.ArchivableListener;

@MappedSuperclass
@EntityListeners(ArchivableListener.class)
public abstract class Archivable {
	private static final org.apache.commons.logging.Log	LOG	= org.apache.commons.logging.LogFactory.getLog( Archivable.class );
	protected ArchiveEntry															entry;
	protected ArchiveId																	archiveId;

	public Archivable() {
		this( new ArchiveId() );
	}

	public Archivable(ArchiveId archiveId) {
		entry = new ArchiveEntry();
		this.archiveId = archiveId;
	}

	@Embedded
	public ArchiveEntry getEntry() {
		return entry;
	}

	public void setEntry(ArchiveEntry entry) {
		this.entry = entry;
	}

	@EmbeddedId
	public ArchiveId getArchiveId() {
		return archiveId;
	}

	public void setArchiveId(ArchiveId archiveId) {
		this.archiveId = archiveId;
	}

	public abstract long nextRevision();

	/**
	 * Constructs a copy this instance on all non relational fields (for
	 * archiving)
	 * 
	 * @author Zied Hamdi for Omondo � corporation on 2 ao�t 07
	 * @return
	 */
	public void removeRelationships() {
		try {
			Class<? extends Archivable> clazz = getClass();
			Field[] fields = clazz.getFields();
			for( Field current : fields ) {
				Object value = current.get( this );
// check field annotations
				if( containsRelationalAnnotation( current.getAnnotations() ) )
					current.set( this, null );
// check property annotations
			}
			Method[] methods = clazz.getMethods();

			for( Method method : methods ) {
				String name = method.getName();
				if( name.startsWith( "get" ) || (name.startsWith( "is" ) && method.getReturnType() == Boolean.class) ) {
					if( containsRelationalAnnotation( method.getAnnotations() ) ) {
						try {
							Method setter = clazz.getMethod( "s" + name.substring( 1 ), method.getReturnType() );
							setter.invoke( this, (Object[]) null );
						} catch( Exception e ) {
							LOG
									.trace( "There's no corrsponding setter for the getter method : " + method +
											". This method is a JPA relationship, its must have a setter in order to archive it properly. Remove the relationship or add a setter." );
							continue;
						}
					}
				}
			}

		} catch( Exception ex ) {
			throw new UnsupportedOperationException( "You must override " + getClass().getName() + ".constructCopy()", ex );
		}
	}

	protected boolean containsRelationalAnnotation(Annotation[] annotations) {
		for( int i = 0; i < annotations.length; i++ ) {
			Class<? extends Annotation> annotation = annotations[i].annotationType();
			if( annotation == OneToOne.class || annotation == OneToMany.class || annotation == ManyToOne.class || annotation == ManyToMany.class )
				return true;
		}
		return false;
	}

	// ---------------------- delegate -----------------
	@Column(insertable = false, updatable = false)
	public long getId() {
		return archiveId.getId();
	}

	@Column(insertable = false, updatable = false)
	public long getRevision() {
		return archiveId.getRevision();
	}

	public void setId(long id) {
		archiveId.setId( id );
	}

	public void setRevision(long revision) {
		archiveId.setRevision( revision );
	}

}
