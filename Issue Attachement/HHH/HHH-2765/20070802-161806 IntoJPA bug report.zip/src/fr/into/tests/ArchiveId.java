package fr.into.tests;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class ArchiveId implements Serializable{
	/** @author Zied Hamdi for Into � corporation on 5 juin 07 */
	private static final long	serialVersionUID	= 1L;
	
	protected long	id;
	protected long	revision;

	public ArchiveId() {
	}

	public ArchiveId(long id, long revision) {
		this.id = id;
		this.revision = revision;
	}

	/**
	 * Gets the id of this Client.
	 * 
	 * @return the id
	 */
	public long getId() {
		return this.id;
	}

	/**
	 * Sets the id of this Client to the specified value.
	 * 
	 * @param id
	 *          the new id
	 */
	public void setId(long id) {
		this.id = id;
	}

	public long getRevision() {
		return revision;
	}

	public void setRevision(long revision) {
		this.revision = revision;
	}

	/**
	 * Returns a hash code value for the object. This implementation computes a
	 * hash code value based on the id fields in this object.
	 * 
	 * @return a hash code value for this object.
	 */
	@Override
	public int hashCode() {
		int hash = 0;
		hash += this.id ^ revision;
		return hash;
	}

	/**
	 * Determines whether another object is equal to this WorkTask. The result is
	 * <code>true</code> if and only if the argument is not null and is a
	 * WorkTask object that has the same id field values as this object.
	 * 
	 * @param object
	 *          the reference object with which to compare
	 * @return <code>true</code> if this object is the same as the argument;
	 *         <code>false</code> otherwise.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean equals(Object object) {
		if( !(object instanceof ArchiveId) ) {
			return false;
		}
		ArchiveId other = (ArchiveId) object;
		if( this.id != other.id )
			return false;
		if( this.revision != other.revision )
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Archive Id: "+ id +" revision: "+ revision;
	}
	
}
