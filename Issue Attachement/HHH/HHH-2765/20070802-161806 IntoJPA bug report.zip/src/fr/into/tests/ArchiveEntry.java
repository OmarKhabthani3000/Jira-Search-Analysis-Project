package fr.into.tests;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Embeddable
public class ArchiveEntry implements Serializable {

	/** @author Zied Hamdi for Into � corporation on 5 juin 07 */
	private static final long serialVersionUID = 1;

	protected Date startDate, endDate;
	protected String note;
	protected ArchiveEntry originalEntry;
	/**
	 * true ifaoif this element is the last in all revisions (optimizes reading
	 * from db)
	 */
	protected boolean lastOccurence;


	@Temporal(TemporalType.TIMESTAMP)
	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	@Temporal(TemporalType.TIMESTAMP)
	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public boolean isLastOccurence() {
		return lastOccurence;
	}

	public void setLastOccurence(boolean lastOccurence) {
		this.lastOccurence = lastOccurence;
	}

	@Override
	public String toString() {
		return note;
	}

}