package fr.into.tests.listeners.persistence;

import javax.persistence.EntityManager;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import main.JPAMain;
import fr.into.tests.Archivable;

public class ArchivableListener {

	@PrePersist
	public void persisting(Archivable archivable) {
		System.out.println( "persisting "+ archivable.getEntry().getNote() );
//		archivable.getEntry().setStartDate( new Date() );
	}
	@PreUpdate
	public void updating(Archivable archivable) {
		EntityManager em = getEntityManager();
		//must clear to avoid getting the same instance as archivable (from cache)
		em.clear();
		Archivable old = em.find( archivable.getClass(), archivable.getArchiveId() );
		//must clear to oblige hibernate to insert a new row (elwhere even calling persist attempts an update)
		em.clear();
		old.removeRelationships();
		old.setRevision( archivable.nextRevision() );
		System.out.println( "persisting old archive with new revision number: "+ old );
		em.persist( old );
		//no more clear needed: archivable and old are distinct instances. 
	}
	
	protected EntityManager getEntityManager() {
		//FIXME must replace with injection after test validation
		return JPAMain.EM.get();
	}
	
	
}
