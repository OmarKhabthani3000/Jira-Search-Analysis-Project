package test.nocommit;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;

@Entity
public class MyEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long id;
	@Column(length = 50)
	private String name;
	@ManyToOne
	private MyEntity myEntity;
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "myEnt", fetch = FetchType.EAGER)
	@MapKey(name = "typeName")
	private Map<String, ContainedEntity> secConfigs;

	public MyEntity() {
	}

	public MyEntity(String name, MyEntity myEntity) {
		this.name = name;
		this.myEntity = myEntity;
	}

	public MyEntity(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Map<String, ContainedEntity> getSecConfigs() {
		return secConfigs;
	}

	public void setSecConfigs(Map<String, ContainedEntity> secConfigs) {
		this.secConfigs = secConfigs;
	}

	public MyEntity getMyEntity() {
		return myEntity;
	}

	public void setMyEntity(MyEntity myEntity) {
		this.myEntity = myEntity;
	}

	public String toString() {
		return name + " -- " + myEntity;
	}
}
