package test.nocommit;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.ManyToOne;

public class ContainedEntityPK implements Serializable {
	private static final long serialVersionUID = -1714218588564578557L;
	@Column(length = 255)
	private String typeName;
	@ManyToOne
	private MyEntity myEnt;

	public ContainedEntityPK() {
	}

	public ContainedEntityPK(String typeName, MyEntity myEnt) {
		super();
		this.typeName = typeName;
		this.myEnt = myEnt;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String name) {
		this.typeName = name;
	}

	public MyEntity getMyEnt() {
		return myEnt;
	}

	public void setMyEnt(MyEntity myEnt) {
		this.myEnt = myEnt;
	}

	public int hashCode() {
		return (int) (typeName.hashCode() + myEnt.hashCode());
	}

	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (obj == this)
			return true;
		if (!(obj instanceof ContainedEntityPK))
			return false;
		ContainedEntityPK pk = (ContainedEntityPK) obj;
		return pk.getMyEnt().equals(myEnt) && pk.typeName.equals(typeName);
	}
}
