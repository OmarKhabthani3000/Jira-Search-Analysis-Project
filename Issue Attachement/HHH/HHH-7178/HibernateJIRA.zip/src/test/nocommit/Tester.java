package test.nocommit;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Tester {
	static EntityManagerFactory emf = Persistence.createEntityManagerFactory("testPersistenceUnit");

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		addEntities();
		findEntity("aEntity");
		findEntity("bEntity");
	}

	public static void addEntities() {
		EntityManager em = emf.createEntityManager();

		MyEntity aEntity = new MyEntity("aEntity");
		MyEntity bEntity = new MyEntity("bEntity", aEntity);

		em.getTransaction().begin();
		em.persist(aEntity);
		em.persist(bEntity);
		em.getTransaction().commit();
		em.close();
	}

	public static void findEntity(String name) {
		EntityManager em = emf.createEntityManager();

		TypedQuery<MyEntity> q = em.createQuery("SELECT M FROM MyEntity M WHERE M.name=:name", MyEntity.class);
		q.setParameter("name", name);
		System.out.println(q.getSingleResult());
	}
}
