package test.nocommit;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;

@IdClass(ContainedEntityPK.class)
@Entity
public class ContainedEntity {

	@Id
	private String typeName;
	@Id
	private MyEntity myEnt;
	@Column(length = 255)
	private String ceName;

	public ContainedEntity() {
	}

	public ContainedEntity(String typeName, String ceName) {
		super();
		this.typeName = typeName;
		this.ceName = ceName;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public MyEntity getMyEnt() {
		return myEnt;
	}

	public void setMyEnt(MyEntity myEnt) {
		this.myEnt = myEnt;
	}

	public String getCeName() {
		return ceName;
	}

	public void setCeName(String ceName) {
		this.ceName = ceName;
	}

}