package hibernate;

import junit.framework.TestCase;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

public class TestBase extends TestCase {
	protected SessionFactory sessionFactory;

	protected Session session;

	protected void setUp() throws Exception {
		super.setUp();
		sessionFactory = new Configuration().configure().buildSessionFactory();
		session = sessionFactory.openSession();
	}

	protected void tearDown() throws Exception {
		session.close();
		super.tearDown();
	}
}
