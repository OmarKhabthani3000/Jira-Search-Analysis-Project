package hibernate;

public class Detail {
	private Long id;

	private Long dispNo;

	private Master master;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Master getMaster() {
		return master;
	}

	public void setMaster(Master master) {
		this.master = master;
	}

	public Long getDispNo() {
		return dispNo;
	}

	public void setDispNo(Long dispNo) {
		this.dispNo = dispNo;
	}
}
