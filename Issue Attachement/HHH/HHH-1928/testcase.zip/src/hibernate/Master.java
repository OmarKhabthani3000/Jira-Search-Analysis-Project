package hibernate;

import java.util.Set;

public class Master {
	private Long id;

	private Set details;

	public Set getDetails() {
		return details;
	}

	public void setDetails(Set details) {
		this.details = details;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
