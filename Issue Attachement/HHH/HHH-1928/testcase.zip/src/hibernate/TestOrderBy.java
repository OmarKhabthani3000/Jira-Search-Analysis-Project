package hibernate;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.Order;

public class TestOrderBy extends TestBase {
	/*
	 * generated SQL: order by details2_.DISP_NO, this_.id asc
	 */
	public void testJoinFetchByCriteria() throws Exception {
		session.createCriteria(Master.class)//
				.setFetchMode("details", FetchMode.JOIN)//
				.addOrder(Order.asc("id"))//
				.list();
	}

	/*
	 * generated SQL: order by master0_.id, details1_.DISP_NO
	 */
	public void testJoinFetchByHql() throws Exception {
		session.createQuery("from Master M left join fetch M.details " //
				+ "order by M.id")//
				.list();
	}

	/*
	 * generated SQL: order by d1_.DISP_NO, this_.id asc
	 */
	public void testLeftJoinByCriteria() throws Exception {
		session.createCriteria(Master.class)//
				.createAlias("details", "D", Criteria.LEFT_JOIN)//
				.addOrder(Order.asc("id"))//
				.list();
	}

	/*
	 * generated SQL: order by master0_.id
	 */
	public void testLeftJoinByHql() throws Exception {
		session.createQuery("from Master M left join M.details " //
				+ "order by M.id")//
				.list();
	}
}
