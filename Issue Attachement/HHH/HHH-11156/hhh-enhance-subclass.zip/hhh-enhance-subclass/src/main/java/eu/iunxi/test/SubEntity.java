package eu.iunxi.test;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 *
 * @author fred
 */
@Entity
public class SubEntity extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @LazyToOne(LazyToOneOption.NO_PROXY)
    private BaseEntity otherEntity;

    public BaseEntity getOtherEntity() {
        return otherEntity;
    }

    public void setOtherEntity(BaseEntity otherEntity) {
        this.otherEntity = otherEntity;
    }
}
