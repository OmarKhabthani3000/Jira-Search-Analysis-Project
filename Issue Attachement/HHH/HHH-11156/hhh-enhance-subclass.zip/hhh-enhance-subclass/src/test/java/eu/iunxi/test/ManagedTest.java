package eu.iunxi.test;

import org.hibernate.engine.spi.Managed;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author fred
 */
public class ManagedTest {
    
    public ManagedTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testManaged() {
        BaseEntity baseEntity = new BaseEntity();
        SubEntity subEntity = new SubEntity();

        assertTrue("BaseEntity NOT managed", isEnhanced(baseEntity));
        assertTrue("SubEntity NOT managed", isEnhanced(subEntity));
    }

    private boolean isEnhanced(Object object) {
        for (Class localInterface: object.getClass().getInterfaces()) {
            if (Managed.class.isAssignableFrom(localInterface)) {
                return true;
            }
        }
        return false;
    }
}
