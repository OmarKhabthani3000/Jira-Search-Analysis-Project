package org.hibernate.cache.test.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE, region="test")
public class Child {

	private long id;

	@Id
	@GeneratedValue
	public long getId() {
		return id;
	}

	protected void setId(long id) {
		this.id = id;
	}

}
