package org.hibernate.cache.test.util;

import java.io.Serializable;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.cache.spi.CacheKey;
import org.hibernate.cache.spi.access.CollectionRegionAccessStrategy;
import org.hibernate.cache.spi.entry.CollectionCacheEntry;
import org.hibernate.collection.spi.PersistentCollection;
import org.hibernate.engine.spi.CollectionEntry;
import org.hibernate.engine.spi.PersistenceContext;
import org.hibernate.internal.SessionImpl;
import org.hibernate.internal.util.collections.IdentityMap;
import org.hibernate.persister.collection.CollectionPersister;
import org.hibernate.stat.Statistics;

public class HibernateUtils {

	public static void displayCacheStat(Statistics statistics) {
		System.out.println(String.format("Cache stats: 1st fetch: %1$d, 2nd put: %2$d, 2nd hit: %3$d, 2nd miss: %4$d, 2nd query hit: %5$d",
				statistics.getEntityFetchCount(),
				statistics.getSecondLevelCachePutCount(),
				statistics.getSecondLevelCacheHitCount(),
				statistics.getSecondLevelCacheMissCount(),
				statistics.getQueryCacheHitCount()));
	}

	/**
	 * This little helper method is a way out I found, grabbing part of code I found
	 * within Hibernate cache management. Seems to me a workaround not so bad, but
	 * sure I would prefer Hibernate did its job completely :) 
	 *  
	 * @param session
	 */
	@SuppressWarnings("unchecked")
	public static void unlockCollections(Session session) {
		if (SessionImpl.class.isAssignableFrom(session.getClass())) {
			SessionImpl sessionImpl = (SessionImpl) session;
			PersistenceContext persistenceContext = sessionImpl.getPersistenceContext();
			for (Map.Entry<PersistentCollection, CollectionEntry> me : IdentityMap.concurrentEntries((Map<PersistentCollection, CollectionEntry>) persistenceContext.getCollectionEntries())) {
				CollectionEntry ce = me.getValue();
				CollectionPersister persister = ce.getCurrentPersister();

				if (persister != null && persister.getCacheAccessStrategy() != null) {
					CollectionRegionAccessStrategy cacheStrategy = persister.getCacheAccessStrategy();
					long timestamp = cacheStrategy.getRegion().nextTimestamp();

					PersistentCollection pe = me.getKey();
					Serializable key = ce.getCurrentKey();
					CollectionCacheEntry collectionCacheEntry = new CollectionCacheEntry(pe, persister);

					CacheKey ck = sessionImpl.generateCacheKey(
							key,
							persister.getKeyType(),
							persister.getRole());

					// only non versioned entities are supported for now in this helper...
					if (!persister.isVersioned()) {
						cacheStrategy.putFromLoad(ck, collectionCacheEntry, timestamp, null, true);
					}
					else {
						System.out.println("collection not unlocked: " + ce);
					}

				}
				else {
					System.out.println("collection not unlocked: " + ce);
				}
			}
		}
	}	

}
