package com.example.demo;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@SpringBootTest
class DemoApplicationTests {

	@Autowired
	ChildRepository repository;

	@Test
	void fetchSomeEntityIds() {
		// given
		Executable execution = () -> repository.findAllIds();

		// when/then
		assertDoesNotThrow(execution);
	}

}
