package com.example.demo;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "child1")
@AllArgsConstructor
@NoArgsConstructor
class Child {

    @EmbeddedId
    private ChildId childId;
}
