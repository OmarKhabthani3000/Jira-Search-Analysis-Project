package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

interface ChildRepository extends JpaRepository<Child, ChildId> {

    @Query("SELECT childId FROM Child")
    List<ChildId> findAllIds();
}
