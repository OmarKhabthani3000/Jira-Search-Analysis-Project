CREATE TABLE public.parent(
    id VARCHAR(255) PRIMARY KEY
);

CREATE TABLE public.child1(
    id VARCHAR(255),
    version integer,

    PRIMARY KEY(id, version),
    FOREIGN KEY(id) REFERENCES public.parent(id)
);