INSERT INTO public.parent VALUES ('parentId');
INSERT INTO public.child1 VALUES ('parentId', 1);