package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.hibernate.bugs.entity.RiskScenario;
import org.hibernate.bugs.entity.SecurityMeasure;
import org.hibernate.bugs.entity.Treatment;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.stream.Collectors;

public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;
    private EntityManager entityManager;

    private ForkJoinPool forkJoinPool;

    private SecurityMeasure firstMeasure;
    private SecurityMeasure secondMeasure;

    @Before
    public void init() {
        forkJoinPool = new ForkJoinPool(10);

        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
        entityManager = entityManagerFactory.createEntityManager();

        entityManager.getTransaction().begin();

        initDataset();

        // to avoid fetching entities cached at session level
        entityManager.flush();
        entityManager.clear();

        entityManager.getTransaction().commit();
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
        forkJoinPool.shutdown();
    }

    @Test
    public void test() {
        entityManager.getTransaction().begin();

        SecurityMeasure firstMeasureRefreshed = entityManager.find(SecurityMeasure.class, this.firstMeasure.getId());
        SecurityMeasure secondMeasureRefreshed = entityManager.find(SecurityMeasure.class, this.secondMeasure.getId());

        forkJoinPool
                .submit(() ->
                        List.of(firstMeasureRefreshed, secondMeasureRefreshed)
                                .parallelStream()
                                .map(SecurityMeasure::getTreatments)
                                .flatMap(Collection::stream)
                                .map(Treatment::getRiskScenario)
                                .collect(Collectors.toList()))
                .join();

        entityManager.getTransaction().commit();
    }

    private void initDataset() {
        RiskScenario riskScenario = new RiskScenario();

        this.firstMeasure = createMeasureForRisk(riskScenario);
        this.secondMeasure = createMeasureForRisk(riskScenario);
    }

    private SecurityMeasure createMeasureForRisk(RiskScenario riskScenario) {
        SecurityMeasure securityMeasure = new SecurityMeasure();

        Treatment treatment = new Treatment();
        treatment.setRiskScenario(riskScenario);
        treatment.setSecurityMeasure(securityMeasure);

        riskScenario.addTreatment(treatment);
        securityMeasure.addTreatment(treatment);

        entityManager.persist(riskScenario);

        return securityMeasure;
    }
}
