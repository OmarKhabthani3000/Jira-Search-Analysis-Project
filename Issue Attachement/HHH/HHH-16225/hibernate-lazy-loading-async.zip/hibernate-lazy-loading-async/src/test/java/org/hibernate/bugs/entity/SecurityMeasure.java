package org.hibernate.bugs.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static jakarta.persistence.CascadeType.ALL;
import static jakarta.persistence.FetchType.LAZY;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
public class SecurityMeasure {

    @Id
    @GeneratedValue
    @ToString.Include
    private Long id;

    @EqualsAndHashCode.Include
    @Setter(AccessLevel.PRIVATE)
    private UUID uuid = UUID.randomUUID();

    @ToString.Include
    private String name;

    @OneToMany(cascade = ALL, fetch = FetchType.LAZY, mappedBy = "securityMeasure", orphanRemoval = true)
    private Set<Treatment> treatments = new HashSet<>();

    public void addTreatment(Treatment treatment) {
        if (treatments == null) {
            treatments = new HashSet<>();
        }
        treatments.add(treatment);
        treatment.setSecurityMeasure(this);
    }

}
