package org.hibernate.bugs.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

import static jakarta.persistence.CascadeType.MERGE;
import static jakarta.persistence.CascadeType.PERSIST;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
public class Treatment {

    @Id
    @GeneratedValue
    @ToString.Include
    private Long id;

    @EqualsAndHashCode.Include
    @Setter(AccessLevel.PRIVATE)
    private UUID uuid = UUID.randomUUID();

    @ToString.Include
    private String name;

    @ManyToOne(cascade = {PERSIST, MERGE}, optional = false)
    @JoinColumn(name = "risk_scenario_id")
    @ToString.Include
    private RiskScenario riskScenario;

    @ManyToOne(cascade = {PERSIST, MERGE}, optional = false)
    @JoinColumn(name = "security_measure_id")
    @ToString.Include
    private SecurityMeasure securityMeasure;

}
