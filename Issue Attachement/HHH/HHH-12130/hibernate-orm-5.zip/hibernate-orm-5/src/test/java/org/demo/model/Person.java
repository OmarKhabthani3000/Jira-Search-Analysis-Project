package org.demo.model;

import org.hibernate.annotations.DiscriminatorFormula;
import org.hibernate.annotations.DiscriminatorOptions;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Person entity.
 */
@Entity
@Table(name = "PERSON")
@SequenceGenerator(name = "SEQ", sequenceName = "SEQ_PK_PERSON", allocationSize = 1)
@DiscriminatorFormula("CASE WHEN " +
        "valid_from <= TRUNC(SYSDATE) and (valid_to >= TRUNC(SYSDATE) or valid_to is null) " +
        "THEN 'ACTUAL' ELSE 'HISTORICAL' END")
@DiscriminatorValue("HISTORICAL")
@DiscriminatorOptions(force = true)
public class Person extends AbstractPerson {

    private static final long serialVersionUID = -963958275732062407L;

}
