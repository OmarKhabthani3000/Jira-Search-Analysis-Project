package org.demo.model;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Active person.
 */
@Entity
@DiscriminatorValue("ACTUAL")
public class ActualPerson extends Person {

    @Column(name = "PERSON_ID", insertable = false, updatable = false)
    private Long personId;

    @Override
    public Long getPersonId() {
        return personId;
    }

    @Override
    public void setPersonId(Long personId) {
        this.personId = personId;
    }

}
