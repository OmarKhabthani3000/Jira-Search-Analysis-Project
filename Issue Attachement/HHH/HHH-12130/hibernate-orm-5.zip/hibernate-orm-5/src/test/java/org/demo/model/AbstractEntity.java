package org.demo.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

/**
 * Abstract entity.
 */
@XmlAccessorType(XmlAccessType.NONE)
@MappedSuperclass
//@EntityListeners(AuditingEntityListener.class)
public abstract class AbstractEntity implements Cloneable {

    @Id
    @GeneratedValue(generator = "SEQ", strategy = GenerationType.SEQUENCE)
    @Column(name = "ID")
    protected Long id;

    /**
     * @return the id of the Entity
     */
    public Long getId() {
        return this.id;
    }


    public void setId(final Long id) {
        this.id = id;
    }

}
