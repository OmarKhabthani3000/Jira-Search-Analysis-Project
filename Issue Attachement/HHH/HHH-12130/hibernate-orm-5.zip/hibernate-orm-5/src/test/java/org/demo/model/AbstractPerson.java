package org.demo.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;

/**
 * Person entity interface.
 */
@MappedSuperclass
public class AbstractPerson extends AbstractEntity implements Serializable {

    private static final long serialVersionUID = -963958275732062407L;

    @Column(name = "PERSON_ID")
    private Long personId;

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

}
