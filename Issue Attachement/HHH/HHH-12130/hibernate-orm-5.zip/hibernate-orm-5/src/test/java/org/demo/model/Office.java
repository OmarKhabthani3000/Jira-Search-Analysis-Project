package org.demo.model;

import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Office entity.
 */
@Entity
@Table(name = "OFFICE")
@SequenceGenerator(name = "SEQ", sequenceName = "SEQ_PK_OFFICE", allocationSize = 1)
public class Office extends AbstractOffice {
    private Boolean signedCurrent;

    public Boolean getSignedCurrent() {
        return signedCurrent;
    }

    public void setSignedCurrent(Boolean signedCurrent) {
        this.signedCurrent = signedCurrent;
    }
}
