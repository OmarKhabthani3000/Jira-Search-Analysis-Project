package org.demo.model;

import org.hibernate.annotations.Formula;

import javax.persistence.Column;
import javax.persistence.Lob;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import java.util.List;

/**
 * Abstract notary entity.
 */
@MappedSuperclass
public abstract class AbstractNotary<P extends AbstractPerson, O extends AbstractOffice> extends AbstractEntity {

    @Column(name = "PERSON_ID")
    private Long personId;

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(final Long personId) {
        this.personId = personId;
    }

    public abstract P getPerson();

    public abstract void setPerson(P person);

}
