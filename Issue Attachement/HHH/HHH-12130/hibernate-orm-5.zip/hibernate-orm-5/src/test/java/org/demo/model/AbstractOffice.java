package org.demo.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import java.math.BigDecimal;

/**
 * Abstract office entity.
 */
@MappedSuperclass
public class AbstractOffice extends AbstractEntity {

    private String type;

    private String postalCode;

    private String city;

    private Long cityId;

    private String street;

    private String additionalAddress;

    private String district;

    private String officeHours;

    private String phone;

    private String fax;

    private String countryCode;

    private String lastModifiedBy;

    private boolean currentOffice;

    @Column(name = "NOTARY_ID")
    private Long notaryId;

    private BigDecimal latitude;

    private BigDecimal longitude;

    private BigDecimal searchLatitude;

    private BigDecimal searchLongitude;

    public String getType() {
        return type;
    }

    public void setType(final String type) {
        this.type = type;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(final String phone) {
        this.phone = phone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(final String fax) {
        this.fax = fax;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(final String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(final String city) {
        this.city = city;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(final String street) {
        this.street = street;
    }

    public String getAdditionalAddress() {
        return additionalAddress;
    }

    public void setAdditionalAddress(final String additionalAddress) {
        this.additionalAddress = additionalAddress;
    }

    public String getOfficeHours() {
        return officeHours;
    }

    public void setOfficeHours(final String officeHours) {
        this.officeHours = officeHours;
    }

    public Long getNotaryId() {
        return notaryId;
    }

    public void setNotaryId(final Long notaryId) {
        this.notaryId = notaryId;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(final String district) {
        this.district = district;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(final String countryCode) {
        this.countryCode = countryCode;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(final String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public boolean isCurrentOffice() {
        return currentOffice;
    }

    public void setCurrentOffice(final boolean current) {
        this.currentOffice = current;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(final BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(final BigDecimal longitude) {
        this.longitude = longitude;
    }

    public BigDecimal getSearchLatitude() {
        return searchLatitude;
    }

    public void setSearchLatitude(final BigDecimal searchLatitude) {
        this.searchLatitude = searchLatitude;
    }

    public BigDecimal getSearchLongitude() {
        return searchLongitude;
    }

    public void setSearchLongitude(final BigDecimal searchLongitude) {
        this.searchLongitude = searchLongitude;
    }

    public Long getCityId() {
        return cityId;
    }

    public void setCityId(Long cityId) {
        this.cityId = cityId;
    }
}
