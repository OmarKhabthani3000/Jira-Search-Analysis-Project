package org.demo.model;

import org.hibernate.annotations.DiscriminatorFormula;
import org.hibernate.annotations.DiscriminatorOptions;

import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Notary for external systems.
 */
@Entity
@DiscriminatorFormula("CASE " +
        "WHEN valid_to < sysdate " +
        "THEN 'HISTORICAL' " +
        "WHEN signed_title is not null " +
        "THEN 'SIGNED' END")
@DiscriminatorOptions(force = true)
@Table(name = "NOTARY")
@SequenceGenerator(name = "SEQ", sequenceName = "SEQ_PK_NOTARY", allocationSize = 1)
public abstract class ExternalNotary<P extends AbstractPerson, O extends AbstractOffice> extends AbstractNotary<P, O> {
}
