package org.demo.model;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import java.util.ArrayList;
import java.util.List;

/**
 * Historical notary entity.
 */
@Entity
@DiscriminatorValue("HISTORICAL")
public class HistoricalNotary extends ExternalNotary<ActualPerson, Office> {

    @OneToOne(cascade = CascadeType.DETACH, fetch = FetchType.EAGER)
    @JoinColumn(name = "PERSON_ID", referencedColumnName = "PERSON_ID", insertable = false, updatable = false)
    private ActualPerson person;

    @Override
    public ActualPerson getPerson() {
        return person;
    }

    @Override
    public void setPerson(ActualPerson person) {
        this.person = person;
    }
}
