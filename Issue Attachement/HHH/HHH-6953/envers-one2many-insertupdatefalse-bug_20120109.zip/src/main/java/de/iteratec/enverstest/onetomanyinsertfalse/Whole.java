package de.iteratec.enverstest.onetomanyinsertfalse;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;

import org.hibernate.envers.Audited;

/**
 * Entity implementation class for Entity: Whole
 *
 */
@Entity
@Audited
public class Whole implements Serializable {


	private Integer id;
	private String name;
	private List<Piece> pieces;
	private static final long serialVersionUID = 1L;

	public Whole() {
		super();
	}
	@Id @GeneratedValue
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@OneToMany
	@OrderColumn(name="position")
	@JoinColumn(name="whole_id")
	public List<Piece> getPieces() {
		return this.pieces;
	}

	public void setPieces(List<Piece> pieces) {
		this.pieces = pieces;
	}

}
