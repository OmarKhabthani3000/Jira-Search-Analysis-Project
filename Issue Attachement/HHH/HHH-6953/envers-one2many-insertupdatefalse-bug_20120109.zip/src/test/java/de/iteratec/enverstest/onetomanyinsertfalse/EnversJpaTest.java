package de.iteratec.enverstest.onetomanyinsertfalse;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import junit.framework.Assert;

import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.query.AuditEntity;
import org.hibernate.envers.query.AuditQuery;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class EnversJpaTest {

	private EntityManagerFactory emf = Persistence.createEntityManagerFactory("envers_many2many");
	private EntityManager em;
	private EntityTransaction tx;

	public EntityManager createEntityManager() {
		return emf.createEntityManager();
	}

	public void closeEntityManager() {
		emf.close();
	}

	@Before
	public void setUp() {
		em = createEntityManager();
		tx = em.getTransaction();
		tx.begin();
	}

	@After
	public void tearDown() {
		tx.commit();
		em.close();
		closeEntityManager();
	}

	@Test
	public void testAuditOne2Many() throws Exception {
		// create one Whole object and link it with three pieces
		Whole whole = new Whole();
		whole.setName("Default group");
		whole.setPieces(new ArrayList<Piece>());
		em.persist(whole);

		Piece little = createPiece("Size", whole);
		createPiece("Area", whole);
		createPiece("Volume", whole);


		tx.commit();

		tx = em.getTransaction();
		tx.begin();

		// load one Piece again and verify its whole attribute is non -null
		Piece loadedLittle = em.find(Piece.class, little.getId());
		Assert.assertNotNull(loadedLittle);
		Whole LoadedAt = loadedLittle.getWhole();
		Assert.assertNotNull(LoadedAt);

		// now get the same Piece through the AuditReader and check for Whole again.
		AuditReader historyReader = AuditReaderFactory.get(em);
		AuditQuery q = historyReader.createQuery().forRevisionsOfEntity(Piece.class, false, false);
		q.add(AuditEntity.id().eq(little.getId()));
		Object[] res = (Object[]) q.getSingleResult();

		Piece v = (Piece) res[0];
		Assert.assertNotNull(v);
		Whole nullWhole = v.getWhole();
		Assert.assertNotNull("expected to get a Whole object", nullWhole); // fails!
	}

	private Piece createPiece(String value, Whole whole) {
		Piece piece = new Piece();
		piece.setName("Size");
		piece.setWhole(whole);
		whole.getPieces().add(piece);
		em.persist(piece);

		return piece;
	}

}
