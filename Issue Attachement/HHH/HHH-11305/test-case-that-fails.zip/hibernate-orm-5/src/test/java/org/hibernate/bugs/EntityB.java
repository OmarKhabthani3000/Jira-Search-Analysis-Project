// ____________________________________________________________________________
//
// (c) 2016, ORTHOsoft Inc. All Rights Reserved
//
// The contents of this file may not be disclosed, copied or duplicated in
// any form, in whole or part, without the prior written permission of
// ORTHOsoft Inc.
// ____________________________________________________________________________

package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "b")
public class EntityB {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column()
  private Long primaryKey;

  @OneToOne
  @JoinTable(name = "join_table", joinColumns = @JoinColumn(name = "lock_pk"),
      inverseJoinColumns = @JoinColumn(name = "case_pk"))
  private EntityA a;

  public Long getPrimaryKey() {
    return primaryKey;
  }

  public void setPrimaryKey(Long primaryKey) {
    this.primaryKey = primaryKey;
  }

  public EntityA getA() {
    return a;
  }

  public void setA(EntityA a) {
    this.a = a;
  }
}
