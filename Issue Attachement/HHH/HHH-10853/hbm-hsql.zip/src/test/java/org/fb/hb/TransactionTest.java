/*
 * ----------------------------------------------------------------------------
 * Copyright 2009 - 2016 by PostFinance AG - all rights reserved
 * ----------------------------------------------------------------------------
 */
package org.fb.hb;

import org.junit.Test;

public class TransactionTest {
    @Test
    public void testDdl() {
        TransactionHelper helper = new TransactionHelper();
        Person user = new Person();
        user.setMyName("my name");
        helper.persist(user);
    }
}
