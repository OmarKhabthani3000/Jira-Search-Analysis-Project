/*
 * ----------------------------------------------------------------------------
 * Copyright 2009 - 2016 by PostFinance AG - all rights reserved
 * ----------------------------------------------------------------------------
 */
package org.fb.hb;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TransactionHelper {

    private final EntityManager entityManager;

    public TransactionHelper() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("Hsql");
        entityManager = factory.createEntityManager();
    }

    public void persist(Object user) {
        entityManager.persist(user);
    }
}
