package com.example;

import com.example.model.Author;
import com.example.model.Book;
import com.example.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.query.AuditEntity;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class AuditOnCascadeTest {
    public static final String JACOB_GRIMM = "Jacob Grimm";
    public static final String WILHELM_GRIMM = "Wilhelm Grimm";
    public static final String FAIRY_TALES = "Fairy tales";

    @BeforeClass
    public static void prepare() {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        Book book = new Book();
        book.setName(FAIRY_TALES);
        session.save(book);
        transaction.commit();
    }

    private static Session getSession() {
        return HibernateUtil.getSessionFactory().getCurrentSession();
    }

    @Test
    public void addAuthor() {
        Session session = getSession();
        Transaction tx = session.beginTransaction();
        Book book = findBookByName(session, FAIRY_TALES);
        List bookRevisions = getRevisionList(session, Book.class, book.getId());
        int before = bookRevisions.size();
        Author secondAuthor = new Author();
        secondAuthor.setName(WILHELM_GRIMM);
        secondAuthor.setAuthorOf(book);
        session.save(secondAuthor);
        tx.commit();
        session = getSession();
        tx = session.beginTransaction();
        bookRevisions = getRevisionList(session, Book.class, book.getId());
        int after = bookRevisions.size();
        tx.commit();
        Assert.assertEquals(after, before);
    }

    @Test
    public void addAuthorToBook() {
        Session session = getSession();
        Transaction tx = session.beginTransaction();
        Book book = findBookByName(session, FAIRY_TALES);
        List bookRevisions = getRevisionList(session, Book.class, book.getId());
        int before = bookRevisions.size();
        Author secondAuthor = new Author();
        secondAuthor.setName(JACOB_GRIMM);
        book.getAuthors().add(secondAuthor);
        session.update(book);
        tx.commit();
        session = getSession();
        tx = session.beginTransaction();
        Author a = findAuthor(session, JACOB_GRIMM);
        Assert.assertNotNull(a);
        bookRevisions = getRevisionList(session, Book.class, book.getId());
        int after = bookRevisions.size();
        tx.commit();
        Assert.assertEquals("Adding item to collection should not create a new revision. Or it should?", before, after);
    }

    private Book findBookByName(Session session, String name) {
        return (Book) session.createQuery("From Book where name = :name")
                    .setParameter("name", name).uniqueResult();
    }

    private Author findAuthor(Session session, String name) {
        return (Author) session.createQuery("From Author where name = :name")
                    .setParameter("name", name).uniqueResult();
    }

    private List getRevisionList(Session session, Class<? extends Serializable> aClass, Serializable pk) {
        AuditReader auditReader = AuditReaderFactory.get(session);
        return auditReader.createQuery().forRevisionsOfEntity(aClass, true, false)
                .add(AuditEntity.id().eq(pk)).getResultList();
    }
}
