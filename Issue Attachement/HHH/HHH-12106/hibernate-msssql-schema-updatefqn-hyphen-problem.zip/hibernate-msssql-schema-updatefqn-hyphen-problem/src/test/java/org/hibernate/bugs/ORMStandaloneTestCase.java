package org.hibernate.bugs;

import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.Before;
import org.junit.Test;

/** Provides a test method to reproduce the problem that at schema update the "ALTER TABLE" DDL statement
 * executed in a MicroSoft SQL-Server 2008 and probably other versions and database types
 * fails if the database name contains a hyphen.
 */
public class ORMStandaloneTestCase {

	@Before
	public void setup() {
		StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
			.applySetting( "hibernate.show_sql", "true" )
			.applySetting( "hibernate.format_sql", "true" )
			.applySetting( "hibernate.hbm2ddl.auto", "update" )
			.applySetting("javax.persistence.schema-generation.database.action", "create-drop");
		Metadata metadata = new MetadataSources( srb.build() )
			.addFile("./src/test/resources/MappingCreate.hbm.xml")
			.buildMetadata();

		metadata.buildSessionFactory();
	}

	/** Test to reproduce the problem that at schema update the "ALTER TABLE" DDL statement
	 * executed in a MicroSoft SQL-Server 2008 and probably other versions and database types
	 * fails if the database name contains a hyphen.
	 * <p>
	 * The root exception which has (not) to occur is <br>
	 * Caused by: com.microsoft.sqlserver.jdbc.SQLServerException: Falsche Syntax in der N�he von '-'.
	 */
	@Test
	public void testMsSqlDatabaseNameQuotedAtSchemaUpdate() throws Exception {
		
		StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
				.applySetting( "hibernate.show_sql", "true" )
				.applySetting( "hibernate.format_sql", "true" )
				.applySetting( "hibernate.hbm2ddl.auto", "update" )
				.applySetting( "javax.persistence.schema-generation.database.action", "update")
				.applySetting( "hibernate.globally_quoted_identifiers", "true");
		Metadata metadata = new MetadataSources( srb.build() )
			.addFile("./src/test/resources/MappingAlter.hbm.xml")
			.buildMetadata();

		metadata.buildSessionFactory();
	}
}
