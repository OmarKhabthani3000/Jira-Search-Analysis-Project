package org.hibernate.bugs;

/** The mapped class.
 * 
 */
public class Test {

	private int id;
	private int c1;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getC1() {
		return c1;
	}

	public void setC1(int c1) {
		this.c1 = c1;
	}
	
	
}
