package test;

import org.hibernate.Hibernate;
import org.junit.Test;
import test.domain.*;

import java.util.List;

import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class JPAHibernateJoinTest extends JPAHibernateTest {

    @Test
    public void testPersist_success() {
        em.getTransaction().begin();
        long id = 0;

        User user = new User();
        user.setId(id++);
        em.persist(user);

        Role role = new Role();
        role.setId(id++);
        em.persist(role);

        Resource resource = new Resource();
        resource.setId(id++);
        em.persist(resource);

        RoleResource roleResource = new RoleResource();
        roleResource.setId(id++);
        roleResource.setRole(role);
        roleResource.setResource(resource);
        em.persist(roleResource);

        UserRole userRole = new UserRole();
        userRole.setId(id++);
        userRole.setRole(role);
        userRole.setUser(user);
        em.persist(userRole);

        em.getTransaction().commit();
        em.clear();

        StringBuilder hql = new StringBuilder();
        hql.append("FROM User u ");
        hql.append(" LEFT JOIN FETCH u.userRole ur ");
        hql.append(" LEFT JOIN FETCH ur.role r ");
        hql.append(" LEFT JOIN FETCH r.roleResource rr ");
        hql.append(" LEFT JOIN FETCH rr.resource  ");

        List<User> users = em.createQuery(hql.toString(), User.class).getResultList();

        em.close();

        assertNotNull(users);
        assertEquals(1, users.size());

        user = users.get(0);
        assertTrue(Hibernate.isInitialized(user));
        assertTrue(Hibernate.isInitialized(user.getUserRole()));
        assertTrue(Hibernate.isInitialized(user.getUserRole().iterator().next()));
        assertTrue(Hibernate.isInitialized(user.getUserRole().iterator().next().getRole()));
        assertTrue(Hibernate.isInitialized(user.getUserRole().iterator().next().getRole().getRoleResource()));
        assertTrue(Hibernate.isInitialized(user.getUserRole().iterator().next().getRole().getRoleResource().iterator().next()));
        assertTrue(Hibernate.isInitialized(user.getUserRole().iterator().next().getRole().getRoleResource().iterator().next().getResource()));
    }

}
