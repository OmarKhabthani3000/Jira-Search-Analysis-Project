package com.cfpwood.hibernate;

public class DatabaseIDSingleton {

	private static DatabaseIDSingleton databaseID = null;

	private Short identification = null;

	private DatabaseIDSingleton() {
		super();
	}

	public static DatabaseIDSingleton getInstance() {
		if (databaseID == null) {
			databaseID = new DatabaseIDSingleton();
		}//End if (databaseID == null)
		return databaseID;
	}// End getInstance method

	/**
	 * Don't make any methods static other than getInstance in order to force
	 * instantion of singleton before use
	 */

	/**
	 * Return the database identification in a Short. Using this vs
	 * <Integer>.shortValue().
	 * 
	 * @return Short identification
	 */
	public Short getIdentification() {
		return identification;
	}

	/**
	 * Return the database identification in a Byte. Using this vs
	 * getIdentification.byteValue() ensures that if the identification is null
	 * there is no null pointer exceptions thrown by the byteValue() method.
	 * 
	 * @return Byte identification
	 */
	public Byte getByteIdentification() {
		return (identification == null) ? null : new Byte(identification
				.byteValue());
	}

	public void setIdentification(Integer identification) {
		// Allow ID to be only set once
		if (this.identification == null) {
			this.identification = new Short(identification.shortValue());
		} // if (this.identification == null)
	}

	public void setIdentification(Short identification) {
		// Allow ID to be only set once
		if (this.identification == null) {
			this.identification = identification;
		} // if (this.identification == null)
	}

}
