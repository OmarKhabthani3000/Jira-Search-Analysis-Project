//$Id: DatabaseIDSequenceGenerator.java,v 1.4 2005/12/19 21:43:44 yblouin Exp $
package com.cfpwood.hibernate;

import java.io.Serializable;
import java.util.Properties;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.dialect.Dialect;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.Configurable;
import org.hibernate.id.IdentifierGenerationException;
import org.hibernate.id.PersistentIdentifierGenerator;
import org.hibernate.id.SequenceGenerator;
import org.hibernate.id.SequenceHiLoGenerator;
import org.hibernate.id.TableHiLoGenerator;
import org.hibernate.type.Type;

/**
 * <b>DatabaseIDSequenceGenerator</b><br>
 * <br>
 * Generates <tt>long</tt> values using an oracle-style sequence with an
 * embedded database ID. This is intended for distributed (replicated) database
 * environment in order to ensure that the primary key is unique across
 * databases. There is a dependency with the DatabaseIDSingleton class where the
 * fixed database ID to be used is stored.<br>
 * <br>
 * Mapping parameters supported: sequence, parameters, databaseID, multiplier.
 * 
 * @see SequenceGenerator
 * @see SequenceHiLoGenerator
 * @see TableHiLoGenerator
 * @author Yves Blouin
 */

public class DatabaseIDSequenceGenerator implements
		PersistentIdentifierGenerator, Configurable {

	/**
	 * The sequence parameter
	 */
	public static final String SEQUENCE = "sequence";

	/**
	 * The parameters parameter, appended to the create sequence DDL. For
	 * example (Oracle):
	 * <tt>INCREMENT BY 1 START WITH 1 MAXVALUE 100 NOCACHE</tt>.
	 */
	public static final String PARAMETERS = "parameters";

	public static final String DATABASEID = "databaseID";

	public static final String MULTIPLIER = "multiplier";

	// private String sequenceName;

	// private String parameters;

	private Type identifierType;

	// private String sql;

	private String str_databaseID;

	private String str_multiplier;

	private TableHiLoGenerator tableHiLoGenerator = null;

	private SequenceHiLoGenerator sequenceHiLoGenerator = null;

	private boolean tableHiLoGeneratorUsed = true;

	private static DatabaseIDSingleton dbID = DatabaseIDSingleton.getInstance();

	/*
	 * private static final Log log = LogFactory
	 * .getLog(DatabaseIDSequenceGenerator.class);
	 */

public void configure(Type type, Properties params, Dialect dialect)
			throws MappingException {
		Class clazz = dialect.getNativeIdentifierGeneratorClass();
		this.identifierType = type;
		this.str_multiplier = params.getProperty(MULTIPLIER);
		this.str_databaseID = params.getProperty(DATABASEID);

		if (clazz == SequenceGenerator.class) {
			setTableHiLoGeneratorUsed(false);
			if (this.sequenceHiLoGenerator == null) {
				this.sequenceHiLoGenerator = new SequenceHiLoGenerator();
				this.sequenceHiLoGenerator.configure(type, params, dialect);
			}
		} else {
			setTableHiLoGeneratorUsed(true);
			if (this.tableHiLoGenerator == null) {
				this.tableHiLoGenerator = new TableHiLoGenerator();
				this.tableHiLoGenerator.configure(type, params, dialect);
			}
		}
	}	public Serializable generate(SessionImplementor session, Object obj)
			throws HibernateException {

		final Serializable result;
		Serializable baseID;
		if (isTableHiLoGeneratorUsed()) {
			baseID = this.tableHiLoGenerator.generate(session, obj);
		} else {
			baseID = this.sequenceHiLoGenerator.generate(session, obj);
		}
		result = AddDBIdentification(baseID);
		return result;
	} // End generate method

	public String[] sqlCreateStrings(Dialect dialect) throws HibernateException {
		String[] a_str_ddl;
		if (isTableHiLoGeneratorUsed()) {
			a_str_ddl = this.tableHiLoGenerator.sqlCreateStrings(dialect);
		} else {
			a_str_ddl = this.sequenceHiLoGenerator.sqlCreateStrings(dialect);
		}
		return a_str_ddl;
	} // End sqlCreateStrings method

	public String[] sqlDropStrings(Dialect dialect) throws HibernateException {
		String[] a_str_ddl;
		if (isTableHiLoGeneratorUsed()) {
			a_str_ddl = this.tableHiLoGenerator.sqlDropStrings(dialect);
		} else {
			a_str_ddl = this.sequenceHiLoGenerator.sqlDropStrings(dialect);
		}
		return a_str_ddl;
	} // End sqlDropStrings method

	public Object generatorKey() {
		Object genKey;
		if (isTableHiLoGeneratorUsed()) {
			genKey = this.tableHiLoGenerator.generatorKey();
		} else {
			genKey = this.sequenceHiLoGenerator.generatorKey();
		}
		return genKey;
	} // End generatorKey method

	private Serializable AddDBIdentification(Serializable baseID)
			throws IdentifierGenerationException {
		short multiplier = 1;
		short databaseID = 0;
		// String str_dbID = "";
		Serializable result;

		Class idClass = identifierType.getReturnedClass();
		if (this.str_multiplier == null) {
			multiplier = 1;
			databaseID = 0;
		} else {
			try {
				multiplier = Short.parseShort(this.str_multiplier);
			} catch (NumberFormatException excNumFmt) {
				multiplier = 1;
			}
			if (dbID.getIdentification() != null) {
				databaseID = dbID.getIdentification().shortValue();
			} else {
				try {
					databaseID = Short.parseShort(this.str_databaseID);
				} catch (NumberFormatException excNumFmt) {
					databaseID = 0;
				}
			} // if (dbID.getIdentification() != null)
		} // if (this.str_multiplier == null)

		if (idClass == Long.class) {
			result = new Long(((Long) baseID).longValue() * multiplier
					+ databaseID);
		} else if (idClass == Integer.class) {
			result = new Integer(((Integer) baseID).intValue() * multiplier
					+ databaseID);
		} else if (idClass == Short.class) {
			result = new Short((short) (((Short) baseID).shortValue()
					* multiplier + databaseID));
		} else if (idClass == String.class) {
			if (this.str_databaseID != null) {
				result = ((String) baseID) + this.str_databaseID;
			} else {
				result = ((String) baseID);
			} // if (this.str_databaseID != null)
		} else {
			throw new IdentifierGenerationException(
					"this id generator generates long, integer, short or string");
		} // if (idClass == Long.class)
		return result;
	}

	private boolean isTableHiLoGeneratorUsed() {
		return tableHiLoGeneratorUsed;
	}

	private void setTableHiLoGeneratorUsed(boolean tableHiLoGeneratorUsed) {
		this.tableHiLoGeneratorUsed = tableHiLoGeneratorUsed;
	}

}
