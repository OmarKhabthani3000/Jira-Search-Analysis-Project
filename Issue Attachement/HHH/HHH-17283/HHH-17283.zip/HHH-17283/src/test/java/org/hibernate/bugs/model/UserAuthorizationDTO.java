package org.hibernate.bugs.model;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "User_Authorizations")
public class UserAuthorizationDTO
    implements Serializable
{
    /** */
    private static final long serialVersionUID = 3455048387718432594L;

    /** */
    @EmbeddedId
    private final UserAuthorizationID pk = new UserAuthorizationID();

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        final UserAuthorizationDTO other = (UserAuthorizationDTO)obj;
        if (!Objects.equals(pk.getAce(), other.pk.getAce()) || !Objects.equals(pk.getRole(), other.pk.getRole()) || !Objects.equals(pk.getUser(), other.pk.getUser()))
        {
            return false;
        }
        return true;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode()
    {
        return Objects.hash(pk);
    }

    public UserAuthorizationID getPk()
    {
        return pk;
    }
}
