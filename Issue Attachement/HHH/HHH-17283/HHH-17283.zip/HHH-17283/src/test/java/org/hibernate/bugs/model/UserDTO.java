package org.hibernate.bugs.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "User_Accounts")
public class UserDTO
    implements Serializable
{
    /** */
    private static final long serialVersionUID = 9158507006143579213L;

    /** */
    @Id
    @GeneratedValue
    @SequenceGenerator(name = "user_sequence_gen", sequenceName = "User_Account_Seq", allocationSize = 1)
    @Column(name = "id")
    private Integer pk = null;

    /** */
    @Column(name = "email", length = 255, nullable = false)
    private String email;

    /** */
    @Column(name = "first_name", length = 255, nullable = false)
    private String firstName;

    /** */
    @Column(name = "last_name", length = 255, nullable = false)
    private String lastName;

    public Integer getPk()
    {
        return pk;
    }

    public void setPk(final Integer pk)
    {
        this.pk = pk;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(final String email)
    {
        this.email = email;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(final String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(final String lastName)
    {
        this.lastName = lastName;
    }
}
