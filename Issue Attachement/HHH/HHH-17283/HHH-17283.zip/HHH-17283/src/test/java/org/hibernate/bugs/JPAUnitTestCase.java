package org.hibernate.bugs;

import org.hibernate.bugs.model.UserAuthorizationDTO;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh17283Test() throws Exception {
		final EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

        final TypedQuery<UserAuthorizationDTO> query = entityManager.createQuery("" +
                "SELECT outer_UserAuthorizationDTO " +
                "FROM " + UserAuthorizationDTO.class.getName() + " AS outer_UserAuthorizationDTO " +
                "WHERE outer_UserAuthorizationDTO.pk IN ( " +
                "  SELECT inner_UserAuthorizationDTO.pk " +
                "  FROM " + UserAuthorizationDTO.class.getName() + " AS inner_UserAuthorizationDTO " +
                "    INNER JOIN inner_UserAuthorizationDTO.pk AS inner_UserAuthorizationDTO_pk " +
                "  WHERE (inner_UserAuthorizationDTO_pk.user = :user) " +
                "  AND (inner_UserAuthorizationDTO_pk.role = :role) " +
                "  AND (inner_UserAuthorizationDTO_pk.ace = :ace) " +
                "  GROUP BY inner_UserAuthorizationDTO.pk " +
                ") " +
                "ORDER BY outer_UserAuthorizationDTO.pk ASC",
                UserAuthorizationDTO.class
        );

        query.getResultList();

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
