package org.hibernate.bugs.model;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Embeddable
public class UserAuthorizationID
    implements Serializable
{
    /** */
    private static final long serialVersionUID = 5217847812017549983L;

    /** */
    @JoinColumn(name = "ac_entry_id", nullable = false, insertable = false)
    @ManyToOne(optional = false)
    private AccessControlEntryDTO ace;

    /** */
    @ManyToOne(optional = false)
    @JoinColumn(name = "role_id", nullable = false, insertable = false)
    private RoleDTO role;

    /** */
    @JoinColumn(name = "user_id", nullable = false, insertable = false)
    @ManyToOne(optional = false)
    private UserDTO user;

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (getClass() != obj.getClass()))
        {
            return false;
        }

        final UserAuthorizationID other = (UserAuthorizationID)obj;

        if (!Objects.equals(ace, other.ace) || !Objects.equals(role, other.role) || !Objects.equals(user, other.user))
        {
            return false;
        }

        return true;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode()
    {
        return Objects.hash(ace, role, user);
    }

    public AccessControlEntryDTO getAce()
    {
        return ace;
    }

    public void setAce(final AccessControlEntryDTO ace)
    {
        this.ace = ace;
    }

    public RoleDTO getRole()
    {
        return role;
    }

    public void setRole(final RoleDTO role)
    {
        this.role = role;
    }

    public UserDTO getUser()
    {
        return user;
    }

    public void setUser(final UserDTO user)
    {
        this.user = user;
    }
}
