package org.hibernate.bugs.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Roles")
public class RoleDTO
    implements Serializable
{
    /** */
    private static final long serialVersionUID = -982059724219078303L;

    /** */
    @Id
    @GeneratedValue
    @Column(name = "id")
    private Integer pk = null;

    /** */
    @Column(name = "name", length = 256, nullable = false)
    private String name = null;

    public Integer getPk()
    {
        return pk;
    }

    public void setPk(final Integer pk)
    {
        this.pk = pk;
    }

    public String getName()
    {
        return name;
    }

    public void setName(final String name)
    {
        this.name = name;
    }
}
