/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2008, Red Hat Middleware LLC or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Middleware LLC.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.envers.test.entities.collection;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.hibernate.envers.test.entities.collection.entity.CascadeAllCollectionEntity;
import org.hibernate.envers.test.entities.collection.entity.CascadedEntity;
import org.junit.Test;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.jta.JtaTransactionManager;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * @author Erik-Berndt Scheper
 */
public class CascadeCollectionEntityTest extends AbstractIntegrationTest {

	@Resource(name = "transactionManager")
	private JtaTransactionManager transactionManager = null;

	private final Logger logger = Logger.getLogger(this.getClass());

	private Integer can1_id;
	private Integer ccd1_id;
	private Integer ccd2_id;

	@Test
	public void testRevisionsCounts() {
		// Revision 1
		final TransactionTemplate transactionTemplate = new TransactionTemplate(
				transactionManager);

		// Setup: create CascadeAllCollectionEntity + CascadedEntity
		final CascadeAllCollectionEntity can = (CascadeAllCollectionEntity) transactionTemplate
				.execute(new TransactionCallback<CascadeAllCollectionEntity>() {
					// this method executes in a transactional context
					public CascadeAllCollectionEntity doInTransaction(
							TransactionStatus status) {

						EntityManager entityManager = getEntityManager();

						CascadedEntity ccd1 = new CascadedEntity();
						ccd1.setData("CascadedEntity1_data1");

						CascadedEntity ccd2 = new CascadedEntity();
						ccd2.setData("CascadedEntity2_data1");

						CascadeAllCollectionEntity can1 = new CascadeAllCollectionEntity();
						can1.setData("CascadeAllCollectionEntity1_data1");
						can1.addCascadedEntity(ccd1);
						can1.addCascadedEntity(ccd2);
						entityManager.persist(can1);

						// add flush() here to make the test succeed
						// entityManager.flush();

						return can1;

					}
				});

		// log info
		logger.error("created entity: " + can);

		// verify results after transaction completion
		transactionTemplate
				.execute(new TransactionCallback<CascadeAllCollectionEntity>() {
					// the code in this method executes in a transactional
					// context
					public CascadeAllCollectionEntity doInTransaction(
							TransactionStatus status) {

						can1_id = can.getId();
						ccd1_id = can.getCascadedEntities().get(0).getId();
						ccd2_id = can.getCascadedEntities().get(1).getId();

						assertEquals(Arrays.asList(1), getAuditReader()
								.getRevisions(CascadeAllCollectionEntity.class,
										can1_id));
						assertEquals(Arrays.asList(1), getAuditReader()
								.getRevisions(CascadedEntity.class, ccd1_id));

						CascadeAllCollectionEntity can1Rev1 = getAuditReader()
								.find(CascadeAllCollectionEntity.class,
										can1_id, 1);
						CascadedEntity ccd1Rev1 = getAuditReader().find(
								CascadedEntity.class, ccd1_id, 1);

						CascadedEntity ccd2Rev1 = getAuditReader().find(
								CascadedEntity.class, ccd2_id, 1);

						assertEquals(2, can1Rev1.getCascadedEntities().size());
						assertTrue(can1Rev1.getCascadedEntities().contains(
								ccd1Rev1));
						assertTrue(can1Rev1.getCascadedEntities().contains(
								ccd2Rev1));

						assertEquals("CascadeAllCollectionEntity1_data1",
								can1Rev1.getData());
						assertEquals("CascadedEntity1_data1", ccd1Rev1
								.getData());
						assertEquals("CascadedEntity2_data1", ccd2Rev1
								.getData());

						checkAuditJoinTable(can1_id, ccd1_id, ccd2_id);

						return null;

					}
				});

	}

	private void checkAuditJoinTable(Integer canId, Integer ccd1Id,
			Integer ccd2Id) {
		// Verify that the entity was correctly persisted
		EntityManager em = getEntityManager();

		Long canEntCount = (Long) em.createQuery(
				"select count(can) from CAN can where can.id = "
						+ canId.toString()).getSingleResult();

		Integer canAuditCount = (Integer) em.createNativeQuery(
				"select count(1) from CAN_AUD  where id = " + canId.toString())
				.getSingleResult();

		Long ccdEntCount = (Long) em.createQuery(
				"select count(ccd) from CCD ccd where ccd.id = "
						+ ccd1Id.toString()).getSingleResult();
		Integer ccdAuditCount = (Integer) em.createNativeQuery(
				"select count(1) from CCD_AUD where id = " + ccd1Id.toString())
				.getSingleResult();

		Integer auditJoinCount_canId1 = (Integer) em.createNativeQuery(
				"select count(1) from CAN_CCD_AUD where CAN_ID = "
						+ canId.toString()).getSingleResult();
		Integer auditJoinCount_ccdId1 = (Integer) em.createNativeQuery(
				"select count(1) from CAN_CCD_AUD where CCD_ID = "
						+ ccd1Id.toString()).getSingleResult();
		Integer auditJoinCount_ccdId2 = (Integer) em.createNativeQuery(
				"select count(1) from CAN_CCD_AUD where CCD_ID = "
						+ ccd2Id.toString()).getSingleResult();

		@SuppressWarnings("unchecked")
		List<Integer> auditJoin_canIdList = em.createNativeQuery(
				"SELECT DISTINCT CAN_ID from CAN_CCD_AUD where CAN_ID = ? ")
				.setParameter(1, canId).getResultList();

		@SuppressWarnings("unchecked")
		List<Integer> auditJoin_ccdIdList = em.createNativeQuery(
				"SELECT DISTINCT CCD_ID from CAN_CCD_AUD where CAN_ID = ? ")
				.setParameter(1, canId).getResultList();

		// verify
		assertEquals(Long.valueOf(1L), canEntCount);
		assertEquals(Long.valueOf(1L), ccdEntCount);
		assertEquals(Integer.valueOf(1), canAuditCount);
		assertEquals(Integer.valueOf(1), ccdAuditCount);

		assertEquals(Integer.valueOf(2), auditJoinCount_canId1);
		assertEquals(Integer.valueOf(1), auditJoinCount_ccdId1);
		assertEquals(Integer.valueOf(1), auditJoinCount_ccdId2);

		assertEquals(1, auditJoin_canIdList.size());
		assertTrue(auditJoin_canIdList.contains(canId));

		assertEquals(2, auditJoin_ccdIdList.size());
		assertTrue(auditJoin_ccdIdList.contains(ccd1Id));
		assertTrue(auditJoin_ccdIdList.contains(ccd2Id));

	}
}