package org.hibernate.envers.support;

import java.util.Enumeration;
import java.util.Properties;

/**
 * Set the System Properties used by the <a
 * href="http://www.atomikos.com/Main/TransactionsEssentials">Atomikos Transactions Essentials</a>
 * JTA implementation.
 * 
 * @author Erik-Berndt Scheper
 * 
 */
public class AtomikosSystemPropertiesInitializingBean {

	/**
	 * Constructor for setting properties used by the <a
	 * href="http://www.atomikos.com/Main/TransactionsEssentials">Atomikos Transactions
	 * Essentials</a> JTA implementation.
	 * 
	 * @param props
	 *            the {@link Properties} to be set as System Properties.
	 * 
	 */
	public AtomikosSystemPropertiesInitializingBean(Properties props) {
		if (props == null) {
			// No properties to initialize
			return;
		}
		Enumeration<?> names = props.propertyNames();
		while (names.hasMoreElements()) {
			String name = (String) names.nextElement();
			String value = props.getProperty(name);
			System.setProperty(name, value);
		}
	}

}
