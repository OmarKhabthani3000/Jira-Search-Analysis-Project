package org.hibernate.envers.test.entities.collection;

import static org.junit.Assert.assertNotNull;

import java.lang.reflect.Field;
import java.net.URL;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.LogManager;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.reader.AuditReaderImpl;
import org.junit.BeforeClass;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

/**
 * Base testclass voor BAP integration tests.
 * <p>
 * N.B. Gebruikt <strong>test versie</strong> van HQI-client
 * </p>
 * 
 * @author Erik-Berndt Scheper, Erik Horlings
 * 
 */
@ContextConfiguration(locations = { "classpath:integrationTestContext.xml",
		"classpath:integrationTestDatasources.xml" })
public abstract class AbstractIntegrationTest extends
		AbstractJUnit4SpringContextTests {

	private static final String DEFAULT_LOG4J_CONFIG_URL = "/log4jTest.xml";

	@PersistenceContext(unitName = "bap")
	private EntityManager entityManager;

	/**
	 * Configuratie log4j.
	 * 
	 * @throws Exception
	 */
	@BeforeClass
	public static void setUpLogging() throws Exception {

		URL log4jConfigURL = getLog4jConfigURL(null);
		LogManager.resetConfiguration();
		if (log4jConfigURL == null) {
			System.out.println("Could not load logging configuration");
		} else {
			DOMConfigurator.configure(log4jConfigURL);
		}
	}

	/**
	 * @return de waarde van entityManagerBap
	 */
	protected EntityManager getEntityManager() {
		return this.entityManager;
	}

	protected AuditReader getAuditReader() {
		return AuditReaderFactory.get(getEntityManager());
	}

	/**
	 * Override this method to change the default location of log4j.xml for a
	 * specific testcase.
	 * 
	 * @param location
	 *            the new location of log4j.xml. Defaults to
	 *            &quot;/log4j.xml&quot; if null.
	 * @return the log4j config url
	 */
	protected static URL getLog4jConfigURL(String location) {
		if (location == null) {
			location = DEFAULT_LOG4J_CONFIG_URL;
		}
		URL result = AbstractIntegrationTest.class.getResource(location);
		return result;
	}

	/**
	 * Retrieve the current Hibernate {@link Transaction}.
	 * 
	 * @param em
	 *            the Hibernate {@link EntityManager}.
	 * @return the current Hibernate {@link Transaction}.
	 */
	protected static final Transaction getCurrentTransaction(EntityManager em) {
		AuditReaderImpl auditReader = (AuditReaderImpl) AuditReaderFactory
				.get(em);
		Session session = auditReader.getSession();
		Transaction transaction = session.getTransaction();

		assertNotNull(transaction);

		return transaction;
	}

	/**
	 * Zet een private / protected field van de instance uit de meegegeven
	 * class.
	 * 
	 * @param <T>
	 * @param aClass
	 *            de class die het field heeft
	 * @param fieldName
	 *            naam van het field uit de class
	 * @param instance
	 *            instance de instance waarvan het field gezet moet worden
	 * @param value
	 *            de waarde van het field
	 * @return de gewijzigde instance
	 */
	protected static final <T> T setProperty(Class<?> aClass, String fieldName,
			T instance, Object value) {
		try {
			Field field = aClass.getDeclaredField(fieldName);
			field.setAccessible(true);
			field.set(instance, value);

		} catch (Exception ex) {
			throw new IllegalStateException("Kon field '" + fieldName
					+ "' niet setten", ex);
		}
		return instance;
	}

}
