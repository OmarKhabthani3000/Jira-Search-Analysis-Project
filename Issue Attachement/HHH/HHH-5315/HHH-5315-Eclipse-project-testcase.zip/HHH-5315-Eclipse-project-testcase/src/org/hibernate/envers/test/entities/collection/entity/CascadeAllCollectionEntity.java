package org.hibernate.envers.test.entities.collection.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.hibernate.envers.Audited;

@Entity(name = "CAN")
@Audited
public class CascadeAllCollectionEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", length = 10)
	private Integer id;

	private String data;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "CAN_ID", nullable = false)
	@org.hibernate.envers.AuditJoinTable(name = "CAN_CCD_AUD", inverseJoinColumns = @JoinColumn(name = "CCD_ID"))
	private List<CascadedEntity> cascadedEntities = new ArrayList<CascadedEntity>();

	public Integer getId() {
		return id;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public List<CascadedEntity> getCascadedEntities() {
		return Collections.unmodifiableList(this.cascadedEntities);
	}

	public void addCascadedEntity(CascadedEntity cascadedEntity) {
		this.cascadedEntities.add(cascadedEntity);
		cascadedEntity.setCascadeAllCollectionEntity(this);
	}

	// ********************** Common Methods ********************** //

	@Override
	public String toString() {
		StringBuilder output = new StringBuilder();
		output.append(this.getClass().getSimpleName()).append(" {");
		output.append(" id = \"").append(this.id).append("\", ");
		output.append(" data = \"").append(this.data).append("\", ");
		output.append(" cascadedEntities = \"").append(this.cascadedEntities)
				.append("\"}");
		return output.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((data == null) ? 0 : data.hashCode());
		result = prime
				* result
				+ ((cascadedEntities == null) ? 0 : cascadedEntities.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CascadeAllCollectionEntity other = (CascadeAllCollectionEntity) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (data == null) {
			if (other.data != null)
				return false;
		} else if (!data.equals(other.data))
			return false;
		if (cascadedEntities == null) {
			if (other.cascadedEntities != null)
				return false;
		} else if (!cascadedEntities.equals(other.cascadedEntities))
			return false;
		return true;
	}

}
