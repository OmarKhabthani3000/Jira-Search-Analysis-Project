package org.hibernate.envers.test.entities.collection.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

@Entity(name = "CCD")
@Audited
public class CascadedEntity {
	@Id
	@GeneratedValue
	@Column(name = "ID")
	private Integer id;

	private String data;

	@ManyToOne
	@JoinColumn(name = "CAN_ID", nullable = false, insertable = false, updatable = false)
	@NotAudited
	private CascadeAllCollectionEntity cascadeAllCollectionEntity;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public CascadeAllCollectionEntity getCascadeAllCollectionEntity() {
		return cascadeAllCollectionEntity;
	}

	public void setCascadeAllCollectionEntity(
			CascadeAllCollectionEntity cascadeAllCollectionEntity) {
		this.cascadeAllCollectionEntity = cascadeAllCollectionEntity;
	}

	// ********************** Common Methods ********************** //

	@Override
	public String toString() {
		StringBuilder output = new StringBuilder();
		output.append(this.getClass().getSimpleName()).append(" {");
		output.append(" id = \"").append(this.id).append("\", ");
		output.append(" data = \"").append(this.data).append("\"}");
		return output.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((data == null) ? 0 : data.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CascadedEntity other = (CascadedEntity) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (data == null) {
			if (other.data != null)
				return false;
		} else if (!data.equals(other.data))
			return false;
		return true;
	}

}
