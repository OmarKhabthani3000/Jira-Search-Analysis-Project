package org.hibernate.bugs.HHH10236;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Version;

import org.hibernate.annotations.SelectBeforeUpdate;

@Entity
@SelectBeforeUpdate
public class Author implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private Long authorId;
	private String authorName;
	@Version
	private Long version;

	public Author() {
	}

	public Author(Long authorId, String authorName) {
		this.authorId = authorId;
		this.authorName = authorName;
	}

	public Long getAuthorId() {
		return authorId;
	}

	public void setAuthorId(Long authorId) {
		this.authorId = authorId;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}

}
