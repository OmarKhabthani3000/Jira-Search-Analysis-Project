/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs.HHH10236;

import static org.junit.Assert.assertEquals;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	// Add your entities here.
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
			Author.class,
			Book.class
		};
	}

	// If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
	@Override
	protected String[] getMappings() {
		return new String[] {
			// "Author.hbm.xml",
			// "Book.hbm.xml"
		};
	}
	// If those mappings reside somewhere other than resources/org/hibernate/test, change this.
	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/test/";
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );
		// configuration.setProperty(AvailableSettings.USE_SECOND_LEVEL_CACHE, "true");
	}

	// Add your tests, using standard JUnit.
	@Test
	public void hhh10236Test() throws Exception {
		// Test if unnecessary update occurs when using select-before-update for an entity which has immutable many-to-one property.
		Session s;
		Transaction t;
		
		// ----------------------------------------------------------------------------------------------
		// insert
		s = openSession();
		t = s.beginTransaction();
		
		Author author = new Author(1L, "author1");
		Book book = new Book(1L, "book1", author);
		s.save(author);
		s.save(book);

		t.commit();
		s.close();

		// ----------------------------------------------------------------------------------------------
		// update
        OnFlushDirtyInterceptor i = new OnFlushDirtyInterceptor();
		s = openSession(i);
		t = s.beginTransaction();

		s.update(book); // update unchanged object, but actual update should not happen because Book has SelectBeforeUpdate annotation.

		t.commit();
		s.close();

        assertEquals(0L, i.getCallCount());
	}
}
