package test.dom4j.duptype;

import java.util.Collection;
import java.util.Iterator;

import junit.framework.TestCase;

import org.apache.log4j.Logger;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.hibernate.EntityMode;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * <p>Title: XMLDupTypeTest.java</p>
 * 
 * <p>Description: This test case identifies a situation where if two <many-to-one> 
 *                 relationships point to the same object, their names are corrupted 
 *                 when generating XML. 
 * 
 *   The results of this test, using 3.0.5 and 3.1 Beta 1.
 * <code>
 *   <TestObject>
 *     <id>1</id>
 *     <data>Test Data</data>
 *     <currentStatus> <-- This element should be named <initialStatus>
 *       <id>1</id>
 *       <value>Open</value>
 *     </currentStatus>
 *     <currentStatus>
 *       <id>1</id>
 *       <value>Open</value>
 *     </currentStatus>
 *   </TestObject> 
 * </code>
 * </p>
 * 
 * @author psheldon
 * @version 1.0 
 * 
 * Created on Jul 25, 2005
 */
public class XMLDupTypeTest extends TestCase {

	private static final Logger logger = Logger.getLogger(XMLDupTypeTest.class);
	
	private Session session = null;
	private XMLWriter writer;
	
	public void testDupTypes() {

		logger.info("###################### Begin Test");
		Session dom4JSession = null;
    	try {
    		dom4JSession = getSession().getSession(EntityMode.DOM4J);    		
    		Collection result = dom4JSession.createCriteria(TestObject.class).list();
    		for (Iterator i = result.iterator(); i.hasNext();) {
				Element element = (Element) i.next();
				writer.write(element);
			}
    		writer.flush();
    		writer.close();
		} catch (Exception e) {
			logger.fatal("Exception",e);
			fail(e.getLocalizedMessage());
		} catch (Throwable e) {
			logger.fatal("Throwable",e);
			fail(e.getLocalizedMessage());
		} finally {
			dom4JSession.close();
			getSession().close();
		}
		logger.info("###################### End Test");
	}

	protected void setUp() throws Exception {
		super.setUp();

		Session session = getSession();
		Transaction t1 = session.beginTransaction();

		Status stat1 = new Status("Open");
		session.save(stat1);
		Status stat2 = new Status("Closed");
		session.save(stat2);
		t1.commit();
		
		Transaction t2 = session.beginTransaction();
		TestObject testObj = new TestObject();
		testObj.setData("Test Data");
		testObj.setInitialStatus(stat1);
		testObj.setCurrentStatus(stat1);
		session.save(testObj);
		t2.commit();
		
		writer = new XMLWriter(System.out, OutputFormat.createPrettyPrint());
	}
	
	private Session getSession() {

		if (session == null) {
		    Configuration cfg = new Configuration()
             .addClass(TestObject.class)
		     .addClass(Status.class)
		     .setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver")
		     .setProperty("hibernate.connection.url","jdbc:hsqldb:C:\\hsql\\xmltest")
		     .setProperty("hibernate.dialect","org.hibernate.dialect.HSQLDialect")
		     .setProperty("hibernate.jdbc.batch_size", "0")
		     .setProperty("hibernate.connection.username", "sa")
		     .setProperty("hibernate.connection.password", "")
		     .setProperty("hibernate.connection.autocommit", "false")
		     .setProperty("hibernate.show_sql", "true")
		     .setProperty("hibernate.hbm2ddl.auto", "create-drop");
		    session = cfg.buildSessionFactory().openSession();
		}
		return session;
	}
}
