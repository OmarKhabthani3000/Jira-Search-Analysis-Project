package test.dom4j.duptype;

import java.io.Serializable;

/**
 * <p>Title: AggObj.java</p>
 * <p>Description: </p>
 * <p>Copyright: Deloitte (c) 2004</p>
 * <p>Company: Deloitte</p>
 * @author psheldon
 * @version 1.0 
 * 
 * Created on Jul 25, 2005
 */
public class TestObject implements Serializable {
	
	private Long id;
	private String data;
	private Status initialStatus;
	private Status currentStatus;
	
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Status getInitialStatus() {
		return initialStatus;
	}
	public void setInitialStatus(Status status) {
		this.initialStatus = status;
	}
	public Status getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(Status status) {
		this.currentStatus = status;
	}

}
