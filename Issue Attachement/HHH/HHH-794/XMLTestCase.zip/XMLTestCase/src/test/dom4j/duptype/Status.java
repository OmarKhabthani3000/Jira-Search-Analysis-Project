package test.dom4j.duptype;

import java.io.Serializable;

public class Status implements Serializable {

	private Long id;
	private String value;
	
	public Status() {
		
	}
	public Status(String value) {
		this.value=value;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
}
