package blog.jpa.domain;


import javax.persistence.Embeddable;
import javax.persistence.Id;
import javax.persistence.Column;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@Embeddable
public class RestaurantPK implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    private long regionId;
    private long restaurantId;


    public Long getRestaurantId(){
        return restaurantId;
    }

    public void setRestaurantId(Long personId) {
        this.restaurantId = restaurantId;
    }

    public Long getRegionId(){
        return regionId;
    }

    public void setRegionId(Long regionId) {
        this.regionId = regionId;
    }

    public boolean equals(Object other) {
        if ( !(other instanceof RestaurantPK) ) return false;
        RestaurantPK castOther = (RestaurantPK) other;
        return new EqualsBuilder()
            .append(this.getRegionId(), castOther.getRegionId())
            .append(this.getRestaurantId(), castOther.getRestaurantId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getRegionId())
            .append(getRestaurantId())
            .toHashCode();
    }


}
