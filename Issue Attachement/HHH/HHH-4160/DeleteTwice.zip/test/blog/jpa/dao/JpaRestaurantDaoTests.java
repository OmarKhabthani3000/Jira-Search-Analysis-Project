package blog.jpa.dao;

import java.util.List;
import org.springframework.test.jpa.AbstractJpaTests;
import blog.jpa.dao.RestaurantDao;
import blog.jpa.domain.Restaurant;

public class JpaRestaurantDaoTests extends AbstractJpaTests {


  private RestaurantDao restaurantDao;

  public void setRestaurantDao(RestaurantDao restaurantDao) {
    this.restaurantDao = restaurantDao;
  }

  protected String[] getConfigLocations() {
    return new String[] {"classpath:/blog/jpa/dao/applicationContext.xml"};
  }

  protected void onSetUpInTransaction() throws Exception {
    jdbcTemplate.execute("insert into restaurant (regionid, restaurantid, name) values (9, 1, 'Burger Barn')");
    jdbcTemplate.execute("insert into restaurant (regionid, restaurantid, name) values (9, 2, 'Veggie Village')");
    jdbcTemplate.execute("insert into restaurant (regionid, restaurantid, name) values (9, 3, 'Dover Diner')");
  }


  public void testDeleteRestaurant() {
    logger.debug("Beginning of " + getName());
    String restaurantName = "Dover Diner";
    Restaurant restaurant = restaurantDao.findByName(restaurantName).get(0);
    logger.debug("restaurant is " + restaurant);
    Restaurant rest2  = restaurantDao.findByName(restaurantName).get(0);
    logger.debug("rest2 is " + rest2);

    logger.debug("delete restaurant");
    restaurantDao.delete(restaurant);

    List<Restaurant> results = restaurantDao.findByName(restaurantName);
    assertEquals(0, results.size());

    logger.debug("delete rest2");
    restaurantDao.delete(rest2);
    logger.debug("End of " + getName());
  }

}