Test case for bug on Hibernate union-subclass
HOWTO
-----

Run with
$ mvn clean package

example model:

      Building
          | 1
          |
          |
          v 0..*
    Flat <<abstract>>
          ^
          |
      ----------
      |        |
    Loft     Suite


The unit test will throw an exception:

ERROR: Table "FLAT" not found; SQL statement:
update Flat set building=?, building_idx=? where flatId=? [42102-177]

This is due to used of union-subclass, in that case indexes have to be created on concrete entities tables as Loft and Suite
and not Flat for this example.
