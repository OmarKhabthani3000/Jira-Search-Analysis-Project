package org.nuiton.entities;

/*
 * #%L
 * Test case for HHH-8109
 * %%
 * Copyright (C) 2013 Code Lutin
 * %%
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as 
 * published by the Free Software Foundation, either version 3 of the 
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Lesser Public License for more details.
 *
 * You should have received a copy of the GNU General Lesser Public 
 * License along with this program.  If not, see
 * <http://www.gnu.org/licenses/lgpl-3.0.html>.
 * #L%
 */

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class AppTest {

    protected Session session;

    @Before
    public void beforeTest() {

        // Create a session
        Configuration configuration = new Configuration();
        configuration.configure();
        StandardServiceRegistryBuilder serviceRegistryBuilder = new StandardServiceRegistryBuilder();
        ServiceRegistry serviceRegistry = serviceRegistryBuilder.applySettings(
                configuration.getProperties()).build();
        SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
        session = sessionFactory.openSession();

    }

    @After
    public void afterTest() {
        session.close();
    }

    @Test
    public void test() {

        // Start transaction
        Transaction tx = session.beginTransaction();

        // Create and persist a loft
        Loft loft = new Loft();
        loft.setName("Some loft");
        Long loftKey = (Long) session.save(loft);
        System.out.println("Created loft with id:" + loftKey);

        // Create and persist a suite
        Suite suite = new Suite();
        suite.setName("Some suite");
        Long suiteKey = (Long) session.save(suite);
        System.out.println("Created suite with id:" + suiteKey);

        // Commit transaction and start a new one
        tx.commit();
        tx = session.beginTransaction();

        // Create a building and add both flat and suite
        Building building = new Building();
        building.setName("Building");
        List<Flat> flats = new ArrayList<Flat>();
        building.setFlats(flats);
        flats.add(loft);
        flats.add(suite);

        Long buildingKey = (Long) session.save(building);
        System.out.println("Created bulding with id:" + buildingKey);

        // Persisting the building's flat list will fail
        tx.commit();

        // The test fails during commit with an incoherent SQL query : "update Flat set building=?, building_idx=? where flatId=?"
        // The query is not correct because according to inheritance strategy, table Flat does not exist
        // Exception is :org.h2.jdbc.JdbcSQLException: Table "FLAT" not found; SQL statement:

    }

}
