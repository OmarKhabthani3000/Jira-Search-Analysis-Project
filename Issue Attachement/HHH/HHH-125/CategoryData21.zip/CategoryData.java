
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.StandardToStringStyle;
import org.apache.commons.lang.builder.ToStringBuilder;
//import org.hibernate.*;
import net.sf.hibernate.*;
import net.sf.hibernate.cfg.*;


/**
 * This class represents the category of a locale.
 * 
 * @version 1.0 (Jan 24, 2005)
 * @author cramirez
 * 
 * @hibernate.class table = "category"
 */
public class CategoryData {

	/**
	 * The category's child list
	 */
	private Set<CategoryData> childs;

	/**
	 * The category code
	 */
	private int code;

	/**
	 * The category level
	 */
	private int level;

	/**
	 * The category name
	 */
	private String name;

	/**
	 * The category's parent list
	 */
	private Set<CategoryData> parents;

	/**
	 * Getter of <code>childs</code> property.
	 * 
	 * @return <code>childs</code> property value.
	 * @see #childs
	 * 
	 * @hibernate.set table = "category_parent" inverse = "true"
	 * @hibernate.collection-key column = "category_parent_code"
	 * @hibernate.collection-many-to-many class =
	 *                                    "saes.election.demographics.CategoryData"
	 *                                    column = "category_child_code"
	 * 
	 */

	public Set<CategoryData> getChilds() {
		return childs;
	}

	/**
	 * Getter of <code>code</code> property.
	 * 
	 * @return <code>code</code> property value.
	 * @see #code
	 * 
	 * @hibernate.id column = "category_code" generator-class = "native"
	 *               unsaved-value = "0"
	 * @hibernate.generator-param name = "sequence" value = "s_category"
	 */

	public int getCode() {
		return code;
	}

	/**
	 * Getter of <code>level</code> property.
	 * 
	 * @return <code>level</code> property value.
	 * @see #level
	 * 
	 * @hibernate.property column = "category_level" not-null = "true"
	 */

	public int getLevel() {
		return level;
	}

	/**
	 * Getter of <code>name</code> property.
	 * 
	 * @return <code>name</code> property value.
	 * @see #name
	 * 
	 * @hibernate.property column = "category_name" length = "32" not-null =
	 *                     "true"
	 */

	public String getName() {
		return name;
	}

	/**
	 * Getter of <code>parents</code> property.
	 * 
	 * @return <code>parents</code> property value.
	 * @see #parents
	 * 
	 * @hibernate.set table = "category_parent"
	 * @hibernate.collection-key column = "category_child_code"
	 * @hibernate.collection-many-to-many class =
	 *                                    "saes.election.demographics.CategoryData"
	 *                                    column = "category_parent_code"
	 * 
	 */

	public Set<CategoryData> getParents() {
		return parents;
	}

	/**
	 * Setter of <code>childs</code> property.
	 * 
	 * @param childs
	 *            The <code>childs</code> to set.
	 * @see #childs
	 */
	public void setChilds(Set<CategoryData> childs) {
		this.childs = childs;
	}

	/**
	 * Setter of <code>code</code> property.
	 * 
	 * @param code
	 *            The <code>code</code> to set.
	 * @see #code
	 */
	public void setCode(int code) {
		this.code = code;
	}

	/**
	 * Setter of <code>level</code> property.
	 * 
	 * @param level
	 *            The <code>level</code> to set.
	 * @see #level
	 */
	public void setLevel(int level) {
		this.level = level;
	}

	/**
	 * Setter of <code>name</code> property.
	 * 
	 * @param name
	 *            The <code>name</code> to set.
	 * @see #name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Setter of <code>parents</code> property.
	 * 
	 * @param parents
	 *            The <code>parents</code> to set.
	 * @see #parents
	 */
	public void setParents(Set<CategoryData> parents) {
		this.parents = parents;
	}

	/**
	 * @inheritDoc
	 */
	public int hashCode() {
		return new HashCodeBuilder().append(code).toHashCode();
	}

	/**
	 * @inheritDoc
	 */
	public String toString() {
		return new ToStringBuilder(this).append("code", code).append("name",
				name).toString();
	}

	/**
	 * @inheritDoc
	 */
	public boolean equals(Object obj) {
		return new EqualsBuilder().append(code, ((CategoryData) obj).code)
				.isEquals();
	}

	static public void main( String[] args) {
        try {
			StandardToStringStyle std = new StandardToStringStyle();
			std.setUseIdentityHashCode(false);
			std.setArrayContentDetail(true);
			std.setDefaultFullDetail(true);
			std.setFieldNameValueSeparator(": ");
			std.setContentStart("[ ");
			std.setFieldSeparator(", ");
			std.setContentEnd(" ]");
			ToStringBuilder.setDefaultStyle(std);
			
			
			Configuration cfg = new Configuration();
			/*
			cfg.setProperty( "hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
			cfg.setProperty( "hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
			cfg.setProperty( "hibernate.connection.username", "sa");
			cfg.setProperty( "hibernate.connection.password", "");
			cfg.setProperty( "hibernate.connection.url", "jdbc:hsqldb:.");
			*/

			/*//Hibernate 3.0
			cfg.setProperty( "hibernate.dialect", "org.hibernate.dialect.Oracle9Dialect");
			*/
			//Hibernate 2.0
			cfg.setProperty( "hibernate.dialect", "net.sf.hibernate.dialect.Oracle9Dialect");
			
			cfg.setProperty( "hibernate.connection.driver_class", "oracle.jdbc.driver.OracleDriver");
			cfg.setProperty( "hibernate.connection.username", "hibernate");
			cfg.setProperty( "hibernate.connection.password", "hibernate");
			cfg.setProperty( "hibernate.connection.url", "jdbc:oracle:thin:@data:1521:AESDES");
			
			cfg.setProperty( "hibernate.show_sql", "true");
			cfg.setProperty( "hibernate.use_sql_comments", "true");
			cfg.setProperty( "hibernate.hbm2ddl.auto", "create-drop");

			cfg.addClass(CategoryData.class);
			
			SessionFactory sessionFactory = cfg.buildSessionFactory();
			try {
				
				addData(sessionFactory);
				getData(sessionFactory);

			} finally {
			    sessionFactory.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
        
        
	}

	/**
	 * @param sessionFactory
	 * @throws HibernateException 
	 */
	private static void addData(SessionFactory sessionFactory) throws HibernateException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			try {
				CategoryData cat1 = new CategoryData();
				cat1.setLevel(4);
				cat1.setName("Country");

				session.save(cat1);

				CategoryData cat2 = new CategoryData();
				cat2.setLevel(3);
				cat2.setName("State");
				cat2.setParents(Collections.singleton(cat1));

				session.save(cat2);

				CategoryData cat22 = new CategoryData();
				cat22.setLevel(3);
				cat22.setName("Metropolitan Area");
				cat22.setParents(Collections.singleton(cat1));

				session.save(cat22);

				CategoryData cat3 = new CategoryData();
				cat3.setLevel(2);
				cat3.setName("Municipality");

				Set<CategoryData> s = new HashSet<CategoryData>();
				s.add(cat2);
				s.add(cat22);
				cat3.setParents(s);

				session.save(cat3);

				CategoryData cat4 = new CategoryData();
				cat4.setLevel(1);
				cat4.setName("Locality");
				cat4.setParents(Collections.singleton(cat3));

				session.save(cat4);


			} finally {
				tx.commit();
			}

		} catch (HibernateException he) {
			if (tx != null) {
				tx.rollback();
			}
			throw he;
		} finally {
			session.close();
		}
	}
	
	private static void getData(SessionFactory sessionFactory) throws HibernateException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			try {
				System.out.println( session.load( CategoryData.class, 5));

			} finally {
				tx.commit();
			}

		} catch (HibernateException he) {
			if (tx != null) {
				tx.rollback();
			}
			throw he;
		} finally {
			session.close();
		}
	}
	
}
