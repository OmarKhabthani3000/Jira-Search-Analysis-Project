package com.demo.hibernate;

import io.hypersistence.utils.hibernate.type.basic.YearMonthDateType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;

import java.io.Serializable;
import java.time.YearMonth;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "demo_table_hp")
public class DemoEntityHypersistence implements Serializable {
    @Id
    @Column(name = "year_month_key")
    @Type(YearMonthDateType.class)
    private YearMonth yearMonthKey;

    @Column(name = "year_month_value")
    @Type(YearMonthDateType.class)
    private YearMonth yearMonthValue;

    public DemoEntityHypersistence(YearMonth value) {
        this(value, value);
    }
}
