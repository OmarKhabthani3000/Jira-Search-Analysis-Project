package com.demo.hibernate;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.time.YearMonth;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "demo_table")
public class DemoEntity implements Serializable {
    @Id
    @Column(name = "year_month_key")
    @Convert(converter = YearMonthIntegerConverter.class)
    private YearMonth yearMonthKey;

    @Column(name = "year_month_value")
    @Convert(converter = YearMonthIntegerConverter.class)
    private YearMonth yearMonthValue;

    public DemoEntity(YearMonth value) {
        this(value, value);
    }
}
