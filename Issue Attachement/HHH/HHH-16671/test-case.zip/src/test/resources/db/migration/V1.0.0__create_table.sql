CREATE TABLE `demo_table`
(
    `year_month_key`   INT NOT NULL,
    `year_month_value` INT NOT NULL,
    PRIMARY KEY (`year_month_key`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci;

CREATE TABLE `demo_table_hp`
(
    `year_month_key`   MEDIUMINT NOT NULL,
    `year_month_value` MEDIUMINT NOT NULL,
    PRIMARY KEY (`year_month_key`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci;
