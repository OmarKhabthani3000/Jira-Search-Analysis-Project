package com.demo.hibernate;

import jakarta.persistence.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.*;
import org.testcontainers.containers.MariaDBContainer;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.time.YearMonth;

@SpringBootTest
@ActiveProfiles("test")
@TestPropertySource(locations = "classpath:application.yml")
@Testcontainers
class DemoApplicationTests {

	private static final MariaDBContainer<?> dbContainer = new MariaDBContainer<>("mariadb:10.4.26")
			.withDatabaseName("demodb")
			.withUsername("demouser")
			.withPassword("demopwd")
			.withCommand("--character-set-server=utf8mb4", "--collation-server=utf8mb4_unicode_ci");

	@DynamicPropertySource
	static void properties(DynamicPropertyRegistry registry) {
		dbContainer.start();
		registry.add("spring.datasource.url", dbContainer::getJdbcUrl);
		registry.add("spring.datasource.username", dbContainer::getUsername);
		registry.add("spring.datasource.password", dbContainer::getPassword);
	}

	@Autowired
	private EntityManagerFactory entityManagerFactory;

	@Test
	void test_max_id_int(@Autowired EntityManager entityManager) {
		entityManager.createQuery("SELECT MAX(de.yearMonthKey) FROM DemoEntity de");
	}

	@Test
	void test_max_value_int(@Autowired EntityManager entityManager) {
		entityManager.createQuery("SELECT MAX(de.yearMonthValue) FROM DemoEntity de");
	}

	@Test
	void test_max_id_date(@Autowired EntityManager entityManager) {
		entityManager.createQuery("SELECT MAX(de.yearMonthKey) FROM DemoEntityHypersistence de");
	}

	@Test
	void test_max_value_date(@Autowired EntityManager entityManager) {
		entityManager.createQuery("SELECT MAX(de.yearMonthValue) FROM DemoEntityHypersistence de");
	}
}
