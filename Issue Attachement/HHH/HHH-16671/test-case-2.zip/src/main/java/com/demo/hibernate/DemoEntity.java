package com.demo.hibernate;

import io.hypersistence.utils.hibernate.type.basic.YearMonthDateType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.JdbcType;
import org.hibernate.annotations.Type;
import org.hibernate.type.descriptor.jdbc.DateJdbcType;

import java.io.Serializable;
import java.time.YearMonth;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "demo_table_hp")
public class DemoEntity implements Serializable {
    @Id
    @Column(name = "year_month_key")
//    @Type(YearMonthDateType.class)
    private YearMonth yearMonthKey;

    @Column(name = "year_month_value")
    @Type(YearMonthDateType.class)
    private YearMonth yearMonthValue;

    public DemoEntity(YearMonth value) {
        this(value, value);
    }
}
