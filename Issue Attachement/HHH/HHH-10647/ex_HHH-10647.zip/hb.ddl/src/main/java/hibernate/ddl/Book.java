package hibernate.ddl;

import javax.persistence.*;

@Entity
@Table(name = "books")
public class Book {
    private Integer id;
    private Author author;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @JoinColumn(name = "author", nullable = true)
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    public Author getAuthor() {
        return author;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }
}
