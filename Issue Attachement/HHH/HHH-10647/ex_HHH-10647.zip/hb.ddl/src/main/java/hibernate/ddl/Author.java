package hibernate.ddl;


import javax.persistence.*;

@Entity
@Table(name = "authors")
public class Author {
    private Integer id;

    @Id
    @Column(columnDefinition = "serial")
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
