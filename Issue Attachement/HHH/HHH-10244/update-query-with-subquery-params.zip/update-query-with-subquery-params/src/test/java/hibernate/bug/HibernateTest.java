package hibernate.bug;

import hibernate.bug.model.Document;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        em.persist(new Document("a"));
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test() throws Throwable {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        int updated;
        
        try {
            updated = em.createQuery(
                    "UPDATE Document d SET name = :param_0 WHERE d.id IN ABS((SELECT d2.id FROM Document d2 WHERE d2.name = :param_1))")
                    .setParameter("param_0", "b")
                    .setParameter("param_1", "a")
                    .executeUpdate();
            em.flush();
            tx.commit();
        } catch (Throwable t) {
            tx.rollback();
            throw t;
        } finally {
            em.close();
        }
    
        Assert.assertEquals(1, updated);
    }
}
