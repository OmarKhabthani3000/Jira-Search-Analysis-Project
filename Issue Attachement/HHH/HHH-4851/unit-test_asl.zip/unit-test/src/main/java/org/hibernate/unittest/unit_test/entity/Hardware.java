/**
  *        Licensed to the Apache Software Foundation (ASF) under one
  *        or more contributor license agreements.  See the NOTICE file
  *        distributed with this work for additional information
  *        regarding copyright ownership.  The ASF licenses this file
  *        to you under the Apache License, Version 2.0 (the
  *        "License"); you may not use this file except in compliance
  *        with the License.  You may obtain a copy of the License at
  *
  *        http://www.apache.org/licenses/LICENSE-2.0
  *
  *        Unless required by applicable law or agreed to in writing,
  *        software distributed under the License is distributed on an
  *        "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  *        KIND, either express or implied.  See the License for the
  *        specific language governing permissions and limitations
  *        under the License.    
  *
  */
package org.hibernate.unittest.unit_test.entity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table
@Inheritance( strategy = InheritanceType.SINGLE_TABLE )
@DiscriminatorColumn( discriminatorType = DiscriminatorType.STRING, name = "DeviceType", length = 1 )
@DiscriminatorValue( value = "C" )
public class Hardware extends BaseEntity {
	
	public static final String		ATTRIBUTE_ATTRIBUTES	= "attributes";
	public static final String		ATTRIBUTE_PARENT		= "parent";
	public static final String		ATTRIBUTE_SUBDEVICES	= "subdevices";
	
	private Hardware				parent					= null;
	private List<Hardware>			subdevices				= new ArrayList<Hardware>();
	private Set<HardwareAttribute>	attributes				= new HashSet<HardwareAttribute>();
	
	public static final String		CLASS_SHORT_NAME		= "Device";
	
	protected Hardware() {

	}
	
	public Hardware( Hardware parent ) {
		this.parent = parent;
		
	}

	public void addChild( Hardware device ) {
		subdevices.add( device );
	}
	
	@OneToMany( fetch = FetchType.LAZY )
	@Cascade( value = { CascadeType.ALL, CascadeType.DELETE_ORPHAN } )
	@JoinColumn( name = "attributes_id" )
	public Set<HardwareAttribute> getAttributes() {
		return this.attributes;
	}
	
	@OneToOne( fetch = FetchType.LAZY )
	@JoinColumn( name = "parent_id" )
	public Hardware getParent() {
		return this.parent;
	}
	
	@OneToMany( fetch = FetchType.LAZY )
	@Cascade( value = { CascadeType.DELETE_ORPHAN, CascadeType.ALL } )
	@JoinTable( name = "Hardware_Device", joinColumns = { @JoinColumn( name = "Device_id" ) }, inverseJoinColumns = { @JoinColumn( name = "subdevices_id", updatable = true ) } )
	public List<Hardware> getSubdevices() {
		return this.subdevices;
	}
	
	public void setAttributes( Set<HardwareAttribute> attributes ) {
		this.attributes = attributes;
	}
	
	public void setParent( Hardware parent ) {
		this.parent = parent;
	}
	
	public void setSubdevices( List<Hardware> subdevices ) {
		this.subdevices = subdevices;
	}
	
}
