/**
  *        Licensed to the Apache Software Foundation (ASF) under one
  *        or more contributor license agreements.  See the NOTICE file
  *        distributed with this work for additional information
  *        regarding copyright ownership.  The ASF licenses this file
  *        to you under the Apache License, Version 2.0 (the
  *        "License"); you may not use this file except in compliance
  *        with the License.  You may obtain a copy of the License at
  *
  *        http://www.apache.org/licenses/LICENSE-2.0
  *
  *        Unless required by applicable law or agreed to in writing,
  *        software distributed under the License is distributed on an
  *        "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  *        KIND, either express or implied.  See the License for the
  *        specific language governing permissions and limitations
  *        under the License.    
  *
  */
package org.hibernate.unittest.unit_test.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table( uniqueConstraints = { @UniqueConstraint( columnNames = { DeviceGroup.ATTRIBUTE_NAME } ) } )
public class DeviceGroup extends BaseEntity {
	
	public static final String	ATTRIBUTE_MANAGED_DEVICES	= "managedDevices";
	public static final String	ATTRIBUTE_NAME				= "name";
	public static final String	ENTITY						= "DeviceGroup";
	
	private Set<ManagedDevice>	managedDevices;
	private String				name						= null;

	public DeviceGroup() {

	}
	
	@ManyToMany( fetch = FetchType.LAZY )
	public Set<ManagedDevice> getManagedDevices() {
		if ( managedDevices == null ) {
			managedDevices = new HashSet<ManagedDevice>();
		}
		return managedDevices;
	}
	
	@Column( nullable = false )
	public String getName() {
		return name;
	}
	
	public void setManagedDevices( Set<ManagedDevice> logicalTerminals ) {
		this.managedDevices = logicalTerminals;
	}

	public void setName( String name ) {
		this.name = name;
	}
	
}