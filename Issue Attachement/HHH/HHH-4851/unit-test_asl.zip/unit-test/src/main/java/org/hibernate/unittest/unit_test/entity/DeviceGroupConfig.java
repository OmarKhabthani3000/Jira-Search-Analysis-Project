/**
  *        Licensed to the Apache Software Foundation (ASF) under one
  *        or more contributor license agreements.  See the NOTICE file
  *        distributed with this work for additional information
  *        regarding copyright ownership.  The ASF licenses this file
  *        to you under the Apache License, Version 2.0 (the
  *        "License"); you may not use this file except in compliance
  *        with the License.  You may obtain a copy of the License at
  *
  *        http://www.apache.org/licenses/LICENSE-2.0
  *
  *        Unless required by applicable law or agreed to in writing,
  *        software distributed under the License is distributed on an
  *        "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  *        KIND, either express or implied.  See the License for the
  *        specific language governing permissions and limitations
  *        under the License.    
  *
  */
package org.hibernate.unittest.unit_test.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.hibernate.annotations.ForeignKey;

/**
 * A group of {@link LogicalTerminal logical terminals}. Used to group them for Configuration purpose. That's why a
 * LogicalTerminal can only have one TerminalGroup.
 */
@Entity
@Table
public class DeviceGroupConfig extends BaseEntity {
	
	public static final String	ENTITY						= "DeviceGroupConfig";
	
	public static final String	ATTRIBUTE_NAME				= "name";
	public static final String	ATTRIBUTE_MANAGED_DEVICES	= "managedDevices";
	
	private static final String	CLASS_SHORT_NAME			= "DeviceGroupConfig_";
	
	private String				name						= null;
	private Set<ManagedDevice>	managedDevices;

	public DeviceGroupConfig() {

	}

	/**
	 * Not unique, because we could use the same name in two different organizations.
	 * 
	 * @return
	 */
	@Column( nullable = false )
	public String getName() {
		return name;
	}
	
	public void setName( String name ) {
		this.name = name;
	}

	@OneToMany
	@JoinTable( name = DeviceGroupConfig.ENTITY + "_" + ManagedDevice.ENTITY, joinColumns = { @JoinColumn( name = ManagedDevice.ATTRIBUTE_DEVICE_GROUP_CONFIG + "_" + DeviceGroupConfig.ATTRIBUTE_ID ) }, inverseJoinColumns = { @JoinColumn( name = DeviceGroupConfig.ATTRIBUTE_MANAGED_DEVICES
			+ "_" + ManagedDevice.ATTRIBUTE_ID, unique = true ) } )
	@ForeignKey( name = FK_PREFIX + CLASS_SHORT_NAME + ATTRIBUTE_MANAGED_DEVICES )
	public Set<ManagedDevice> getManagedDevices() {
		if ( managedDevices == null ) {
			managedDevices = new HashSet<ManagedDevice>();
		}
		return managedDevices;
	}

	public void setManagedDevices( Set<ManagedDevice> logicalTerminals ) {
		this.managedDevices = logicalTerminals;
	}

}