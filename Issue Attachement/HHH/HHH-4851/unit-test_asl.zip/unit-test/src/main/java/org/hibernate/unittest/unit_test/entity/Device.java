/**
  *        Licensed to the Apache Software Foundation (ASF) under one
  *        or more contributor license agreements.  See the NOTICE file
  *        distributed with this work for additional information
  *        regarding copyright ownership.  The ASF licenses this file
  *        to you under the Apache License, Version 2.0 (the
  *        "License"); you may not use this file except in compliance
  *        with the License.  You may obtain a copy of the License at
  *
  *        http://www.apache.org/licenses/LICENSE-2.0
  *
  *        Unless required by applicable law or agreed to in writing,
  *        software distributed under the License is distributed on an
  *        "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  *        KIND, either express or implied.  See the License for the
  *        specific language governing permissions and limitations
  *        under the License.    
  *
  */
package org.hibernate.unittest.unit_test.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.ForeignKey;

@Entity
@DiscriminatorValue( value = "T" )
public class Device extends Hardware {
	
	public static final String	ATTRIBUTE_LOGICAL_TERMINAL			= "managedDevice";
	public static final String	ATTRIBUTE_TAG						= "tag";
	public static final String	ATTRIBUTE_TERMINAL_EFFECTIVEDEVICES	= "activeHardware";
	
	private Set<Hardware>		activeHardware						= new HashSet<Hardware>();
	private ManagedDevice		managedDevice;
	private String				tag;
	
	public Device() {
	}
	
	@OneToMany( fetch = FetchType.LAZY )
	@Cascade( value = { CascadeType.ALL, CascadeType.DELETE_ORPHAN } )
	@ForeignKey( name = FK_PREFIX + "Terminal" + NAME_SEPARATOR + Device.ATTRIBUTE_TERMINAL_EFFECTIVEDEVICES )
	@JoinTable( name = "Terminal" + NAME_SEPARATOR + Hardware.CLASS_SHORT_NAME, joinColumns = { @JoinColumn( name = "Terminal" + NAME_SEPARATOR + Device.ATTRIBUTE_ID ) }, inverseJoinColumns = { @JoinColumn( name = Device.ATTRIBUTE_TERMINAL_EFFECTIVEDEVICES
			+ "_" + Hardware.ATTRIBUTE_ID ) } )
	public Set<Hardware> getActiveHardware() {
		return activeHardware;
	}
	
	@OneToOne( fetch = FetchType.LAZY, mappedBy = ManagedDevice.ATTRIBUTE_DEVICE )
	public ManagedDevice getManagedDevice() {
		return managedDevice;
	}
	
	@Column( unique = true, nullable = true )
	public String getTag() {
		return tag;
	}
	
	public void setActiveHardware( Set<Hardware> effectiveDevices ) {
		this.activeHardware = effectiveDevices;
	}
	
	public void setManagedDevice( ManagedDevice logicalterminal ) {
		this.managedDevice = logicalterminal;
	}
	
	public void setTag( String tag ) {
		this.tag = tag;
	}
	
}
