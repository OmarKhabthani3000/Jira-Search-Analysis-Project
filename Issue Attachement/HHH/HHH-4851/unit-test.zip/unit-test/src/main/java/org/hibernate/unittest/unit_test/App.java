package org.hibernate.unittest.unit_test;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.util.logging.Handler;
import java.util.logging.LogManager;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cache.NoCacheProvider;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Environment;
import org.hibernate.classic.Session;
import org.hibernate.connection.C3P0ConnectionProvider;
import org.hibernate.dialect.DerbyDialect;
import org.hibernate.unittest.unit_test.entity.Device;
import org.hibernate.unittest.unit_test.entity.DeviceGroup;
import org.hibernate.unittest.unit_test.entity.DeviceGroupConfig;
import org.hibernate.unittest.unit_test.entity.Hardware;
import org.hibernate.unittest.unit_test.entity.HardwareAttribute;
import org.hibernate.unittest.unit_test.entity.ManagedDevice;
import org.hibernate.unittest.unit_test.entity.Owner;
import org.slf4j.bridge.SLF4JBridgeHandler;

/**
 * Hello world!
 *
 */
public class App {
	
	private static void unconfigureJavaUtilLogging() {
		java.util.logging.Logger rootLogger = LogManager.getLogManager().getLogger( "" );
		Handler[] handlers = rootLogger.getHandlers();
		for ( int i = 0; i < handlers.length; i++ ) {
			rootLogger.removeHandler( handlers[i] );
		}
	}
	
	public static void main( String[] args ) throws IOException {
		FileUtils.deleteDirectory( new File( "db" ) );
		FileUtils.deleteDirectory( new File( "log" ) );
		FileUtils.deleteQuietly( new File( "derby.log" ) );

		DOMConfigurator.configure( Thread.currentThread().getContextClassLoader().getResource( "log4j.xml" ) );
		unconfigureJavaUtilLogging();
		SLF4JBridgeHandler.install();

		AnnotationConfiguration configuration = createHibernateConfiguration();
		
		SessionFactory factory = null;
		Session session = null;
		Transaction trx = null;
		
		try {
			factory = configuration.buildSessionFactory();
			session = factory.getCurrentSession();
			trx = session.beginTransaction();
			
			Owner org = new Owner();
			org.setName( "root" );
			session.saveOrUpdate( org );

			ManagedDevice lTerminal = new ManagedDevice();
			lTerminal.setName( "test" );
			lTerminal.setOwner( org );
			session.saveOrUpdate( lTerminal );

			Device terminal = new Device();
			terminal.setTag( "test" );
			terminal.setOwner( org );
			session.saveOrUpdate( terminal );
			trx.commit();
		} catch ( Exception e ) {
			System.err.println( e.getMessage() );
			e.printStackTrace();
			if ( trx != null ) {
				trx.rollback();
			}
		} finally {
			if ( session != null ) {
				if ( session.isOpen() ) {
					session.close();
				}
			}
			
			if ( factory != null ) {
				factory.close();
			}
		}
	}

	/**
	 * @return
	 */
	private static AnnotationConfiguration createHibernateConfiguration() {
		AnnotationConfiguration configuration = new AnnotationConfiguration();
		
		// Mysql-specific parameters
		configuration.setProperty( Environment.DRIVER, org.apache.derby.jdbc.EmbeddedDriver.class.getName() );
		configuration.setProperty( Environment.URL, "jdbc:derby:db/current;create=true" );
		configuration.setProperty( Environment.USER, "sa" );
		configuration.setProperty( Environment.PASS, "" );
		configuration.setProperty( Environment.DIALECT, DerbyDialect.class.getName() );
		
		// General parameters
		configuration.setProperty( Environment.CURRENT_SESSION_CONTEXT_CLASS, "thread" );
		configuration.setProperty( Environment.CACHE_PROVIDER, NoCacheProvider.class.getName() );
		configuration.setProperty( Environment.USE_QUERY_CACHE, String.valueOf( false ) );
		configuration.setProperty( Environment.USE_SECOND_LEVEL_CACHE, String.valueOf( false ) );
		configuration.setProperty( Environment.SHOW_SQL, String.valueOf( true ) );
		configuration.setProperty( Environment.FORMAT_SQL, String.valueOf( true ) );
		configuration.setProperty( Environment.USE_SQL_COMMENTS, String.valueOf( false ) );
		configuration.setProperty( Environment.ISOLATION, String.valueOf( Connection.TRANSACTION_READ_COMMITTED ) );
		configuration.setProperty( Environment.HBM2DDL_AUTO, "create-drop" );
		
		// connection provider
		configuration.setProperty( Environment.CONNECTION_PROVIDER, C3P0ConnectionProvider.class.getCanonicalName() );
		
		// connection pool parameters
		configuration.setProperty( Environment.C3P0_MIN_SIZE, String.valueOf( 5 ) );
		configuration.setProperty( Environment.C3P0_MAX_SIZE, String.valueOf( 15 ) );
		configuration.setProperty( Environment.C3P0_ACQUIRE_INCREMENT, String.valueOf( 1 ) );
		configuration.setProperty( Environment.C3P0_MAX_STATEMENTS, String.valueOf( 100 ) );
		configuration.setProperty( Environment.C3P0_TIMEOUT, String.valueOf( 1800 ) );
		configuration.setProperty( Environment.C3P0_IDLE_TEST_PERIOD, String.valueOf( 3600 ) );
		
		configuration.addAnnotatedClass( Hardware.class );
		configuration.addAnnotatedClass( DeviceGroupConfig.class );
		configuration.addAnnotatedClass( Hardware.class );
		configuration.addAnnotatedClass( ManagedDevice.class );
		configuration.addAnnotatedClass( Device.class );
		configuration.addAnnotatedClass( DeviceGroup.class );
		configuration.addAnnotatedClass( HardwareAttribute.class );
		configuration.addAnnotatedClass( Owner.class );
		return configuration;
	}
}
