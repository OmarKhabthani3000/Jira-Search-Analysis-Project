package org.hibernate.unittest.unit_test.entity;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table
public class HardwareAttribute extends BaseEntity {
	
	public static final String	ATTRIBUTE_RESOURCE_ID	= "resourceId";
	public static final String	ATTRIBUTE_VALUE			= "value";
	
	private String				resourceId				= null;
	private String				value;
	
	public HardwareAttribute() {
	}
	
	public String getResourceId() {
		return resourceId;
	}
	
	@Transient
	public String getValue() {
		return value;
	}
	
	public void setResourceId( String resourceId ) {
		this.resourceId = resourceId;
	}
	
	public void setValue( String value ) {
		this.value = value;
	}

}
