/*
 * Copyright 2008 8D Technologies, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of 8D Technologies, Inc.
 * Use is subject to license terms.
 */

package org.hibernate.unittest.unit_test.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import org.hibernate.annotations.ForeignKey;

/**
 * this class represents a logical representation of a terminal it could be linked to a terminal or not it contains the
 * alias of the terminal and is virtualizable
 */
@Entity
@Table( uniqueConstraints = { @UniqueConstraint( columnNames = { ManagedDevice.ATTRIBUTE_NAME } ) } )
public class ManagedDevice extends BaseEntity {
	
	public static final String	ENTITY							= "ManagedDevice";
	
	private static final String	TABLE_SHORT_NAME				= "ManagedDevice";
	private static final String	TABLE_SHORT_NAME_PREFIX			= TABLE_SHORT_NAME + NAME_SEPARATOR;
	
	public static final String	ATTRIBUTE_DEVICE				= "device";
	public static final String	ATTRIBUTE_DEVICE_GROUP_CONFIG	= "deviceGroupConfig";
	public static final String	ATTRIBUTE_NAME					= "name";
	public static final String	ATTRIBUTE_DEVICE_GROUPS			= "deviceGroups";
	
	private String				name;
	private Device				device;
	private DeviceGroupConfig	deviceGroupConfig				= null;
	private Set<DeviceGroup>	deviceGroups					= null;
	
	public ManagedDevice() {
	}
	
	public ManagedDevice( String alias ) {
		this.name = alias;
	}
	
	public String getName() {
		return name;
	}
	
	@OneToOne( fetch = FetchType.LAZY )
	@ForeignKey( name = FK_PREFIX + TABLE_SHORT_NAME_PREFIX + ATTRIBUTE_DEVICE )
	@JoinColumn( name = "terminal_id" )
	public Device getDevice() {
		return device;
	}
	
	@ManyToOne( optional = true, fetch = FetchType.LAZY )
	@ForeignKey( name = FK_PREFIX + TABLE_SHORT_NAME_PREFIX + ManagedDevice.ATTRIBUTE_DEVICE_GROUP_CONFIG )
	@JoinTable( name = DeviceGroupConfig.ENTITY + "_" + ManagedDevice.ENTITY, joinColumns = { @JoinColumn( name = DeviceGroupConfig.ATTRIBUTE_MANAGED_DEVICES + "_" + ManagedDevice.ATTRIBUTE_ID, unique = true ) }, inverseJoinColumns = { @JoinColumn( name = ManagedDevice.ATTRIBUTE_DEVICE_GROUP_CONFIG
			+ "_" + DeviceGroupConfig.ATTRIBUTE_ID ) } )
	public DeviceGroupConfig getDeviceGroupConfig() {
		return deviceGroupConfig;
	}
	
	@ManyToMany( mappedBy = DeviceGroup.ATTRIBUTE_MANAGED_DEVICES, fetch = FetchType.LAZY )
	public Set<DeviceGroup> getDeviceGroups() {
		if ( deviceGroups == null ) {
			deviceGroups = new HashSet<DeviceGroup>();
		}
		return deviceGroups;
	}
	
	public void setName( String alias ) {
		this.name = alias;
	}
	
	public void setDevice( Device terminal ) {
		this.device = terminal;
	}
	
	public void setDeviceGroupConfig( DeviceGroupConfig terminalGroup ) {
		this.deviceGroupConfig = terminalGroup;
	}
	
	public void setDeviceGroups( Set<DeviceGroup> userTerminalGroups ) {
		this.deviceGroups = userTerminalGroups;
	}
	
}
