package org.hibernate.unittest.unit_test.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.ForeignKey;

@Entity
@DiscriminatorValue( value = "T" )
public class Device extends Hardware {
	
	public static final String	ATTRIBUTE_LOGICAL_TERMINAL			= "managedDevice";
	public static final String	ATTRIBUTE_TAG						= "tag";
	public static final String	ATTRIBUTE_TERMINAL_EFFECTIVEDEVICES	= "activeHardware";
	
	private Set<Hardware>		activeHardware						= new HashSet<Hardware>();
	private ManagedDevice		managedDevice;
	private String				tag;
	
	public Device() {
	}
	
	@OneToMany( fetch = FetchType.LAZY )
	@Cascade( value = { CascadeType.ALL, CascadeType.DELETE_ORPHAN } )
	@ForeignKey( name = FK_PREFIX + "Terminal" + NAME_SEPARATOR + Device.ATTRIBUTE_TERMINAL_EFFECTIVEDEVICES )
	@JoinTable( name = "Terminal" + NAME_SEPARATOR + Hardware.CLASS_SHORT_NAME, joinColumns = { @JoinColumn( name = "Terminal" + NAME_SEPARATOR + Device.ATTRIBUTE_ID ) }, inverseJoinColumns = { @JoinColumn( name = Device.ATTRIBUTE_TERMINAL_EFFECTIVEDEVICES
			+ "_" + Hardware.ATTRIBUTE_ID ) } )
	public Set<Hardware> getActiveHardware() {
		return activeHardware;
	}
	
	@OneToOne( fetch = FetchType.LAZY, mappedBy = ManagedDevice.ATTRIBUTE_DEVICE )
	public ManagedDevice getManagedDevice() {
		return managedDevice;
	}
	
	@Column( unique = true, nullable = true )
	public String getTag() {
		return tag;
	}
	
	public void setActiveHardware( Set<Hardware> effectiveDevices ) {
		this.activeHardware = effectiveDevices;
	}
	
	public void setManagedDevice( ManagedDevice logicalterminal ) {
		this.managedDevice = logicalterminal;
	}
	
	public void setTag( String tag ) {
		this.tag = tag;
	}
	
}
