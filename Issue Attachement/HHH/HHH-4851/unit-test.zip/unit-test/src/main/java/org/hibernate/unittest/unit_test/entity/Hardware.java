package org.hibernate.unittest.unit_test.entity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table
@Inheritance( strategy = InheritanceType.SINGLE_TABLE )
@DiscriminatorColumn( discriminatorType = DiscriminatorType.STRING, name = "DeviceType", length = 1 )
@DiscriminatorValue( value = "C" )
public class Hardware extends BaseEntity {
	
	public static final String		ATTRIBUTE_ATTRIBUTES	= "attributes";
	public static final String		ATTRIBUTE_PARENT		= "parent";
	public static final String		ATTRIBUTE_SUBDEVICES	= "subdevices";
	
	private Hardware				parent					= null;
	private List<Hardware>			subdevices				= new ArrayList<Hardware>();
	private Set<HardwareAttribute>	attributes				= new HashSet<HardwareAttribute>();
	
	public static final String		CLASS_SHORT_NAME		= "Device";
	
	protected Hardware() {

	}
	
	public Hardware( Hardware parent ) {
		this.parent = parent;
		
	}

	public void addChild( Hardware device ) {
		subdevices.add( device );
	}
	
	@SuppressWarnings( "unchecked" )
	@OneToMany( fetch = FetchType.LAZY )
	@Cascade( value = { CascadeType.ALL, CascadeType.DELETE_ORPHAN } )
	@JoinColumn( name = "attributes_id" )
	public Set<HardwareAttribute> getAttributes() {
		return this.attributes;
	}
	
	@OneToOne( fetch = FetchType.LAZY )
	@JoinColumn( name = "parent_id" )
	public Hardware getParent() {
		return this.parent;
	}
	
	@OneToMany( fetch = FetchType.LAZY )
	@Cascade( value = { CascadeType.DELETE_ORPHAN, CascadeType.ALL } )
	@JoinTable( name = "Device_Device", joinColumns = { @JoinColumn( name = "Device_id" ) }, inverseJoinColumns = { @JoinColumn( name = "subdevices_id", updatable = true ) } )
	public List<Hardware> getSubdevices() {
		return this.subdevices;
	}
	
	public void setAttributes( Set<HardwareAttribute> attributes ) {
		this.attributes = attributes;
	}
	
	public void setParent( Hardware parent ) {
		this.parent = parent;
	}
	
	public void setSubdevices( List<Hardware> subdevices ) {
		this.subdevices = subdevices;
	}
	
}
