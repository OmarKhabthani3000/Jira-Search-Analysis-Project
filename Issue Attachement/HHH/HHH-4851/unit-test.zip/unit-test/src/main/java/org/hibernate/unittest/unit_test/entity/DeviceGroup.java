/*
 * Copyright 2009 8D Technologies, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of 8D Technologie, Inc.
 * Use is subject to license terms.
 *
 */
package org.hibernate.unittest.unit_test.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table( uniqueConstraints = { @UniqueConstraint( columnNames = { DeviceGroup.ATTRIBUTE_NAME } ) } )
public class DeviceGroup extends BaseEntity {
	
	public static final String	ATTRIBUTE_MANAGED_DEVICES	= "managedDevices";
	public static final String	ATTRIBUTE_NAME				= "name";
	public static final String	ENTITY						= "DeviceGroup";
	
	private Set<ManagedDevice>	managedDevices;
	private String				name						= null;

	public DeviceGroup() {

	}
	
	@ManyToMany( fetch = FetchType.LAZY )
	public Set<ManagedDevice> getManagedDevices() {
		if ( managedDevices == null ) {
			managedDevices = new HashSet<ManagedDevice>();
		}
		return managedDevices;
	}
	
	@Column( nullable = false )
	public String getName() {
		return name;
	}
	
	public void setManagedDevices( Set<ManagedDevice> logicalTerminals ) {
		this.managedDevices = logicalTerminals;
	}

	public void setName( String name ) {
		this.name = name;
	}
	
}