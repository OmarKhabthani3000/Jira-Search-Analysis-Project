package org.hibernate.bugs;

import java.sql.Timestamp;
import java.util.List;
import java.util.stream.LongStream;

import org.jboss.logging.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private static Long queryTimeWithoutExtraQuery;
	private static Long queryTimeWithExtraQuery;

	static final int NUMBER_OF_ENTITIES = 10000;
	static final boolean PRINT_ENTITES = false;

	private EntityManagerFactory entityManagerFactory;
	private static Logger logger = Logger.getLogger(JPAUnitTestCase.class);

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
		setupData();
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	
	@AfterClass
	public static void summary() {
		
		logger.info("--------------------------------------------------------------------------------------------------");
		logger.info(String.format("hibernate 6 : number of enties    : %6d",  NUMBER_OF_ENTITIES));
		logger.info(String.format("hibernate 6 : without extra query : %6d ms", queryTimeWithoutExtraQuery));
		logger.info(String.format("hibernate 6 : with extra query    : %6d ms", queryTimeWithExtraQuery));
		logger.info("--------------------------------------------------------------------------------------------------");

	}
	
	
	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh999_1Test() {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		// Do stuff...
		long start = System.currentTimeMillis();
		queryEmployees(entityManager, false);
		queryTimeWithoutExtraQuery = System.currentTimeMillis() - start;

		
		entityManager.getTransaction().commit();
		entityManager.close();

	}

	@Test
	public void hhh999_2Test() {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		// Do stuff...
		long start = System.currentTimeMillis();
		queryEmployees(entityManager, true);
		queryTimeWithExtraQuery = System.currentTimeMillis() - start;

		
		entityManager.getTransaction().commit();
		entityManager.close();
		
	}

	private void queryEmployees(EntityManager entityManager, boolean includeQueryAccess) {

		TypedQuery<Employee> query = entityManager.createQuery("select e From Employee e", Employee.class);
		List<Employee> employeeList = query.getResultList();
		for (Employee employee : employeeList) {

			consumeEntity(employee);

			if (includeQueryAccess) {
				queryAccessForEmployee(entityManager, employee);
			}

		}

	}

	private void queryAccessForEmployee(EntityManager entityManager, Employee employee) {

		TypedQuery<ProjectAccess> accessQuery = entityManager
				.createQuery("select pa From ProjectAccess pa where pa.employee = :employee", ProjectAccess.class)
				.setParameter("employee", employee);

		List<ProjectAccess> accessList = accessQuery.getResultList();

		accessList.forEach(p -> consumeEntity(p));

	}

	private void consumeEntity(Object entity) {

		String line = "" + entity;
		if (PRINT_ENTITES) {
			System.out.println(line);
		}

	}

	private void setupData() {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		LongStream.range(1, NUMBER_OF_ENTITIES).forEach(id -> {
			Employee employee = new Employee();
			employee.setFirstName("FNAME_" + id);
			employee.setLastName("LNAME_" + id);
			employee.setEmail("NAME_" + id + "@email.com");

			entityManager.persist(employee);
		});

		LongStream.range(1, NUMBER_OF_ENTITIES).forEach(id -> {
			Project project = new Project();
			project.setTitle("TITLE_" + id);
			project.setBegin(new Timestamp(System.currentTimeMillis()));
			entityManager.persist(project);
		});

		LongStream.range(1, NUMBER_OF_ENTITIES).forEach(id -> {

			ProjectAccess projectAccess = new ProjectAccess();
			projectAccess.setEmployee(entityManager.find(Employee.class, id));
			projectAccess.setProject(entityManager.find(Project.class, id));
			projectAccess.setBegin(new Timestamp(System.currentTimeMillis()));
			entityManager.persist(projectAccess);

		});

		entityManager.getTransaction().commit();

	}
}
