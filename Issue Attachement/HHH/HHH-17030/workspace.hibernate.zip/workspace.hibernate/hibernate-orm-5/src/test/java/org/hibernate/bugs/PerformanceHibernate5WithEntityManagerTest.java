package org.hibernate.bugs;

import java.sql.Timestamp;
import java.util.List;
import java.util.stream.LongStream;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.hibernate.Version;
import org.jboss.logging.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM,
 * using the Java Persistence API.
 */
public class PerformanceHibernate5WithEntityManagerTest {

	private static Long queryTimeWithoutExtraQuery;
	private static Long queryTimeWithExtraQuery;

	static final int NUMBER_OF_ENTITIES = 1000;
	static final boolean PRINT_ENTITES = false;

	private EntityManagerFactory entityManagerFactory;
	private static Logger logger = Logger.getLogger(PerformanceHibernate5WithEntityManagerTest.class);

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
		setupData();
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@AfterClass
	public static void summary() {
		
		String version = Version.getVersionString();
		
		logger.info("----------------------------------------------------------------------------");
		logger.info(String.format("hibernate %s with entity manager : number of enties    : %6d",  version, NUMBER_OF_ENTITIES));
		logger.info(String.format("hibernate %s with entity manager : without extra query : %6d ms", version, queryTimeWithoutExtraQuery));
		logger.info(String.format("hibernate %s with entity manager : with extra query    : %6d ms", version, queryTimeWithExtraQuery));
		logger.info("----------------------------------------------------------------------------");

	}
	
	
	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh_17030_1_Test() {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		// Do stuff...
		long start = System.currentTimeMillis();
		queryEmployees(entityManager, false);
		queryTimeWithoutExtraQuery = System.currentTimeMillis() - start;

		
		entityManager.getTransaction().commit();
		entityManager.close();

	}

	@Test
	public void hhh_17030_2_Test() {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		// Do stuff...
		long start = System.currentTimeMillis();
		queryEmployees(entityManager, true);
		queryTimeWithExtraQuery = System.currentTimeMillis() - start;

		
		entityManager.getTransaction().commit();
		entityManager.close();
		
	}

	private void queryEmployees(EntityManager entityManager, boolean includeQueryAccess) {

		TypedQuery<Employee> query = entityManager.createQuery("select e From Employee e", Employee.class);
		List<Employee> employeeList = query.getResultList();
		for (Employee employee : employeeList) {

			consumeEntity(employee);

			if (includeQueryAccess) {
				queryAccessForEmployee(entityManager, employee);
			}

		}

	}

	private void queryAccessForEmployee(EntityManager entityManager, Employee employee) {

		TypedQuery<ProjectAccess> accessQuery = entityManager
				.createQuery("select pa From ProjectAccess pa where pa.employee = :employee", ProjectAccess.class)
				.setParameter("employee", employee);

		List<ProjectAccess> accessList = accessQuery.getResultList();

		accessList.forEach(p -> consumeEntity(p));

	}

	private void consumeEntity(Object entity) {

		String line = "" + entity;
		if (PRINT_ENTITES) {
			System.out.println(line);
		}

	}

	private void setupData() {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		LongStream.range(1, NUMBER_OF_ENTITIES).forEach(id -> {
			Employee employee = new Employee();
			employee.setFirstName("FNAME_" + id);
			employee.setLastName("LNAME_" + id);
			employee.setEmail("NAME_" + id + "@email.com");

			entityManager.persist(employee);
		});

		LongStream.range(1, NUMBER_OF_ENTITIES).forEach(id -> {
			Project project = new Project();
			project.setTitle("TITLE_" + id);
			project.setBegin(new Timestamp(System.currentTimeMillis()));
			entityManager.persist(project);
		});

		LongStream.range(1, NUMBER_OF_ENTITIES).forEach(id -> {

			ProjectAccess projectAccess = new ProjectAccess();
			projectAccess.setEmployee(entityManager.find(Employee.class, id));
			projectAccess.setProject(entityManager.find(Project.class, id));
			projectAccess.setBegin(new Timestamp(System.currentTimeMillis()));
			entityManager.persist(projectAccess);

		});

		entityManager.getTransaction().commit();

	}
}
