package org.hibernate.bugs;

import java.sql.Timestamp;
import java.util.List;
import java.util.stream.LongStream;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Version;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.jboss.logging.Logger;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class PerformanceHibernate5WithSessionFactoryTest {
	
  private static SessionFactory sessionFactory = null;
  
  private static Long queryTimeWithoutExtraQuery;
  private static Long queryTimeWithExtraQuery;
  
  static final int NUMBER_OF_ENTITIES = 1000;
  static final boolean PRINT_ENTITES = false;
  
  private static Logger logger = Logger.getLogger(PerformanceHibernate5WithSessionFactoryTest.class);
  
  @BeforeClass
  public static void setup() {
    try {
      StandardServiceRegistry standardRegistry
          = new StandardServiceRegistryBuilder()
          .configure("hibernate-test.cfg.xml")
          .build();

      Metadata metadata = new MetadataSources(standardRegistry)
          .addAnnotatedClass(Employee.class)
          .addAnnotatedClass(Project.class)
          .addAnnotatedClass(ProjectAccess.class)
          
          .getMetadataBuilder()
          .build();

      sessionFactory = metadata
          .getSessionFactoryBuilder().build();

      setupData();

    } catch (Throwable ex) {
      throw new ExceptionInInitializerError(ex);
    }
  }
  
  @AfterClass
  public static void summary() {
		
	  String version = Version.getVersionString();
	  
	  logger.info("---------------------------------------------------------------------------");
	  logger.info(String.format("hibernate %s with session factory : number of enties    : %6d", version, NUMBER_OF_ENTITIES));
	  logger.info(String.format("hibernate %s with session factory : without extra query : %6d ms", version, queryTimeWithoutExtraQuery));
	  logger.info(String.format("hibernate %s with session factory : with extra query    : %6d ms", version, queryTimeWithExtraQuery));
	  logger.info("---------------------------------------------------------------------------");
	  
  }

  
  @Test
  public void testWithoutExtraQuery() {
	  try (Session session = sessionFactory.openSession()) {
      
		  session.getTransaction().begin();
	
		 
		  long start = System.currentTimeMillis();	  
		  queryEmployees( session, false);
		  queryTimeWithoutExtraQuery = System.currentTimeMillis() - start;
		  
		  
	      session.getTransaction().commit();
	  }
  }
  
  @Test
  public void testWithExtraQuery() {
	  try (Session session = sessionFactory.openSession()) {
      
		  session.getTransaction().begin();
	
		 
		  long start = System.currentTimeMillis();	  
		  queryEmployees( session, true);
		  queryTimeWithExtraQuery = System.currentTimeMillis() - start;

	      
		  
	      session.getTransaction().commit();
	  }
  }
    
  
  private void queryEmployees(Session session, boolean includeQueryAccess) {
	  
      TypedQuery<Employee> query = session.createQuery("select e From Employee e", Employee.class);
      List<Employee> employeeList = query.getResultList();
      for ( Employee employee : employeeList) {

    	  consumeEntity(employee);
    	  
    	  if (includeQueryAccess) {
    		  queryAccessForEmployee(session, employee);
    	  }

      }
	  
  }
  
  private void queryAccessForEmployee(Session session, Employee employee) {
	  
	  TypedQuery<ProjectAccess> accessQuery = session
			  .createQuery("select pa From ProjectAccess pa where pa.employee = :employee", ProjectAccess.class)
			  .setParameter("employee", employee);

	  List<ProjectAccess> accessList = accessQuery.getResultList();

	  accessList.forEach(p -> consumeEntity(p) );
	  
  }
  
  private void consumeEntity(Object entity) {
	  
	  String line = ""+entity;
	  if (PRINT_ENTITES) {
		  System.out.println(line);
	  }

  }
  
  
  
  private static void setupData() {
    try (Session session = sessionFactory.openSession()) {
      session.getTransaction().begin();


      
      LongStream.range(1, NUMBER_OF_ENTITIES).forEach(id -> {
        Employee employee = new Employee();
        employee.setFirstName("FNAME_" + id);
        employee.setLastName("LNAME_" + id);
        employee.setEmail("NAME_" + id + "@email.com");

        session.persist(employee);
      });

      LongStream.range(1, NUMBER_OF_ENTITIES).forEach(id -> {
          Project project = new Project();
          project.setTitle("TITLE_" + id );
          project.setBegin(new Timestamp(System.currentTimeMillis()));
          session.persist(project);
        });
      
      LongStream.range(1, NUMBER_OF_ENTITIES).forEach(id -> {
    	  
    	  ProjectAccess projectAccess = new ProjectAccess();
    	  projectAccess.setEmployee(session.find(Employee.class, id));
    	  projectAccess.setProject(session.find(Project.class,id));
    	  projectAccess.setBegin(new Timestamp(System.currentTimeMillis()));
    	  session.persist(projectAccess);
    	  
      });


      
      session.getTransaction().commit();
    }
  }

 

}

