package cz.fekete.hibernate.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TABLE_B database table.
 * 
 */
@Entity
@Table(name="table_b")
public class TableB implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="table_b_id")
	private Long tableBId;

	@Column(name="table_a_id", insertable=false, updatable=false)
	private Long tableAId;


    @Temporal( TemporalType.DATE)
	@Column(name="table_b_date")
	private Date tableBDate;
	
	@ManyToOne
    @JoinColumn(name="table_a_id")
	private TableA tableA;
	
	@OneToMany(mappedBy="tableB")	
	private Set<TableC> tableCs;

	
    public TableB() {
    }

	public Long getTableBId() {
		return this.tableBId;
	}

	public void setTableBId(Long _tableBId_) {
		this.tableBId = _tableBId_;
	}

	public Long getTableAId() {
		return this.tableAId;
	}

	public void setTableAId(Long _tableAId_) {
		this.tableAId = _tableAId_;
	}

	public Date getTableBDate() {
		return this.tableBDate;
	}

	public void setTableBDate(Date _tableBDate_) {
		this.tableBDate = _tableBDate_;
	}

	public TableA getTableA() {
		return tableA;
	}

	public void setTableA(TableA tableA) {
		this.tableA = tableA;
	}

	public Set<TableC> getTableCs() {
		return tableCs;
	}

	public void setTableCs(Set<TableC> tableCs) {
		this.tableCs = tableCs;
	}
	
}