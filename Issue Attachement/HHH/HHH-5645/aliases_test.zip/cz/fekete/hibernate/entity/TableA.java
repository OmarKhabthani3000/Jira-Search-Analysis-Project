package cz.fekete.hibernate.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TABLE_A database table.
 * 
 */
@Entity
@Table(name="table_a")
public class TableA implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="table_a_id")
	private Long tableAId;

	@Column(name="table_a_character")
	private String tableACharacter;
	
	@OneToMany(mappedBy="tableA")	
	private Set<TableB> tableBs;

    public TableA() {
    }

	public Long getTableAId() {
		return this.tableAId;
	}

	public void setTableAId_(Long _tableAId_) {
		this.tableAId = _tableAId_;
	}

	public String getTableACharacter() {
		return this.tableACharacter;
	}

	public void setTableACharacter(String _tableACharacter_) {
		this.tableACharacter = _tableACharacter_;
	}

	public Set<TableB> getTableBs() {
		return this.tableBs;
	}

	public void setTableBs(Set<TableB> tableBs) {
		this.tableBs = tableBs;
	}
	
}