package cz.fekete.hibernate.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;


/**
 * The persistent class for the table_c database table.
 * 
 */
@Entity
@Table(name="table_c")
public class TableC implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="table_c_id")
	private Long tableCId;

	@Column(name="table_b_id", insertable=false, updatable=false)
	private Long tableBId;

	@Column(name="table_c_boolean")
	private Boolean tableCBoolean;
	
	@ManyToOne
    @JoinColumn(name="table_b_id")
	private TableB tableB;

    public TableC() {
    }

	public Long getTableCId() {
		return this.tableCId;
	}

	public void setTableCId(Long tableCId) {
		this.tableCId = tableCId;
	}

	public Long getTableBId() {
		return this.tableBId;
	}

	public void setTableBId(Long tableBId) {
		this.tableBId = tableBId;
	}

	public Boolean getTableCBoolean() {
		return this.tableCBoolean;
	}

	public void setTableCBoolean(Boolean tableCBoolean) {
		this.tableCBoolean = tableCBoolean;
	}

	public TableB getTableB() {
		return tableB;
	}

	public void setTableB(TableB tableB) {
		this.tableB = tableB;
	}		
}