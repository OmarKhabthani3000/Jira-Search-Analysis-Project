/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cascadetest.entities;

import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Snowbird
 */
public class CascadeTest {
    private EntityManagerFactory emf = Persistence.createEntityManagerFactory("CascadeTestPU");

    @Before
    public void setUp() {
        Master master = new Master();
        Detail detail = new Detail();

        master.setId(1L);
        master.setDetails(new ArrayList<Detail>());
        master.getDetails().add(detail);
        detail.setId(1L);
        detail.setSomeValue(1000L);
        detail.setMaster(master);

        persist(master);
        System.out.println("0");
    }

    @After
    public void tearDown() {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        System.out.println("4");
        em.remove(em.find(Detail.class, 1L));
        System.out.println("5");
        em.remove(em.find(Master.class, 1L));

        em.getTransaction().commit();
    }

//    @Test
//    public void testAttached() {
//        System.err.println("testAttached");
//        //Changing a property of the detail object
//        EntityManager em = emf.createEntityManager();
//        Master master;
//        long myDetailValue = System.currentTimeMillis();
//
//        em.getTransaction().begin();
//
//        master = em.find(Master.class, 1L);
//        System.err.println("master loaded");
//        master.getDetails().get(0).setSomeValue(myDetailValue);
//        System.err.println("detail changed");
//
//        //Works even without merge or anything...
//        em.getTransaction().commit();
//        System.err.println("commit");
//
//        em.close();
//
////        assertDetailValue(myDetailValue);
//    }

//    @Test
//    public void testDetached() {
//        System.err.println("testDetached");
//        //Changing a property of the detail object
//        EntityManager em = emf.createEntityManager();
//        Master master;
//        long myDetailValue = System.currentTimeMillis();
//
//        master = em.find(Master.class, 1L);
//        System.err.println("master loaded");
//        System.err.println("get Detail 0");
//        master.getDetails().get(0);
//        em.close();
//        System.err.println("detatched. change detail..");
//        master.getDetails().get(0).setSomeValue(myDetailValue);
//
//        em = emf.createEntityManager();
//        em.getTransaction().begin();
//        System.err.println("merge");
//        em.merge(master);
//        em.getTransaction().commit();

//        assertDetailValue(myDetailValue);
//    }

//    @Test
//    public void testAttachedWithNoDetailChanges() {
//        System.err.println("testAttachedWithNoDetailChanges");
//        //Merge with no changes, hibernate should not load the detail object
//        EntityManager em = emf.createEntityManager();
//        Master master;
//
//        Detail.instancesCreated = 0;
//
//        em.getTransaction().begin();
//        master = em.find(Master.class, 1L);
//        System.err.println("master loaded");
////        assertTrue("master has details.", master.getDetails().isEmpty());
//        System.err.println("sou");
//        ((Session)em.getDelegate()).saveOrUpdate(master);
//        em.merge(master);
//        em.getTransaction().commit();
//
//        assertEquals(0, Detail.instancesCreated);
//    }


    @Test
    public void testDetachedWithNoDetailChanges() throws Exception {
        System.out.println("******** testDetachedWithNoDetailChanges");
        //Merge with no changes, hibernate should not load the detail object
        EntityManager em = emf.createEntityManager();
        Master master;

        Detail.instancesCreated = 0;

        master = em.find(Master.class, 1L);
        System.out.println("1");
        em.close();
        
        em = emf.createEntityManager();
        em.getTransaction().begin();
        System.out.println("2");
//        ((Session)em.getDelegate()).saveOrUpdate(master);
        em.merge(master);
        System.out.println("3");
        em.getTransaction().commit();

        assertEquals(0, Detail.instancesCreated);
    }

    public void persist(Object object) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        try {
            em.persist(object);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
        } finally {
            em.close();
        }
    }

    private void assertDetailValue(long myDetailValue) {
        EntityManager em = emf.createEntityManager();

        Master master = em.find(Master.class, 1L);

        assertEquals(myDetailValue, master.getDetails().get(0).getSomeValue());

        em.close();
    }
}