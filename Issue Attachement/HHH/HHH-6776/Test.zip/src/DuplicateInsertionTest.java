import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DuplicateInsertionTest
{
	private EntityManagerFactory emf;
	private EntityManager em;

	@Before
	public void setUp()
	{
		// set up JPA
		emf = Persistence.createEntityManagerFactory("TestPersistenceUnit");
	}

	@Test
	public void testDuplicateInsertion()
	{
		// persist parent entity in a transaction

		em = emf.createEntityManager();
		em.getTransaction().begin();

		Parent parent = new Parent();
		em.persist(parent);
		int id = parent.getId();

		em.getTransaction().commit();
		em.close();

		// relate and persist child entity in another transaction

		em = emf.createEntityManager();
		em.getTransaction().begin();

		parent = em.find(Parent.class, id);
		Child child = new Child();
		child.setParent(parent);
		parent.getChildren().add(child);
		em.persist(child);

		// verify the number of children
		assertEquals(1, parent.getChildren().size());

		em.getTransaction().commit();
		em.close();
	}

	@After
	public void tearDown()
	{
		emf.close();
	}
}
