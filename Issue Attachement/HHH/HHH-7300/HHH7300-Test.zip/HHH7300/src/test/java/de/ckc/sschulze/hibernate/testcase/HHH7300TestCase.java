package de.ckc.sschulze.hibernate.testcase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.dialect.HSQLDialect;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class HHH7300TestCase{
	private Configuration cfg;
	
	@Before
	public void setup(){
		cfg=new Configuration()
			.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect")
			.setProperty("connection.url", "jdbc:hsqldb:mem:testdb")
			.setProperty("connection.driver_class", "org.hsqldb.jdbcDriver");
	}
	
	@Test
	public void testFirstTypeThenEntity(){
		cfg.addResource("TestEnumType.hbm.xml")
		   .addResource("TestEntity.hbm.xml");
		
		SessionFactory sessions=cfg.buildSessionFactory();
	}
	
	@Test
	public void testFirstEntityThenType(){
		cfg.addResource("TestEntity.hbm.xml")
		   .addResource("TestEnumType.hbm.xml");
		
		SessionFactory sessions=cfg.buildSessionFactory();
	}
}
