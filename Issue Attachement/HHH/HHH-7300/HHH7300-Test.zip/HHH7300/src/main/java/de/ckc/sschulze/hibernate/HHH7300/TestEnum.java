package de.ckc.sschulze.hibernate.HHH7300;

public enum TestEnum {
	FOO,
	BAR;
}
