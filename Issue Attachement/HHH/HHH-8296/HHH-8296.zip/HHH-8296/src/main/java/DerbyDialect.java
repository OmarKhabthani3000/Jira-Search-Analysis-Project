import org.hibernate.dialect.DerbyTenSevenDialect;

import java.sql.Types;

/**
 * User: Andy Gumbrecht (c) ORPRO Vision
 * Date: 21.09.2009
 * Time: 16:08:33
 * <p/>
 * com.orprovision.spectrum.storage.dialect
 */
public class DerbyDialect extends DerbyTenSevenDialect {

    public DerbyDialect() {
        super();

        this.registerHibernateType(Types.LONGVARCHAR, Long.MAX_VALUE, org.hibernate.type.StandardBasicTypes.CLOB.getName());
        this.registerHibernateType(Types.LONGVARBINARY, Long.MAX_VALUE, org.hibernate.type.StandardBasicTypes.BLOB.getName());
        this.registerHibernateType(Types.VARBINARY, Long.MAX_VALUE, org.hibernate.type.StandardBasicTypes.BLOB.getName());
        //registerHibernateType(Types.BOOLEAN, , StandardBasicTypes.BOOLEAN.getName());

        this.registerColumnType(Types.BINARY, Long.MAX_VALUE, "blob");
        this.registerColumnType(Types.LONGVARCHAR, Long.MAX_VALUE, "clob");
        this.registerColumnType(Types.LONGVARBINARY, Long.MAX_VALUE, "blob");
        this.registerColumnType(Types.VARBINARY, "blob");

        this.registerColumnType(Types.BLOB, "blob");
        this.registerColumnType(Types.CLOB, "clob");
    }
}
