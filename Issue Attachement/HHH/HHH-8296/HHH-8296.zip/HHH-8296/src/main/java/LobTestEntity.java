import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import java.sql.Blob;

@Entity
@Table( name = "lob_test" )
public class LobTestEntity {

	@Id
	private Long id;
	
	@Lob
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "lobValue", nullable = false)
	private Blob lobValue;
	
	@Column( name = "qwerty", length = 4000 )
	private String qwerty;

	public void setId(final Long id) {
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setLobValue(final Blob lobValue) {
		this.lobValue = lobValue;
	}

	public Blob getLobValue() {
		return lobValue;
	}

	public void setQwerty(final String qwerty) {
		this.qwerty = qwerty;
	}

	public String getQwerty() {
		return qwerty;
	}
	
}
