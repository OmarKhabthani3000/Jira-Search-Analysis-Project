

import org.hibernate.Session;
import org.hibernate.testing.RequiresDialect;
import org.hibernate.testing.TestForIssue;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.jboss.logging.Logger;
import org.junit.Test;

/**
 * Test for HHH-8296
 *
 * @author Andy Gumbrecht
 */
@RequiresDialect(DerbyDialect.class)
@TestForIssue(jiraKey = "HHH-8296")
public class DerbyLobTest extends BaseCoreFunctionalTestCase {

    private static final Logger LOG = Logger.getLogger(DerbyLobTest.class);

    @Test
    public void hibernateTest() {

        final Session session = this.openSession();
        session.beginTransaction();

        //Create
        for (long i = 1; i < 5; i++) {
            final LobTestEntity entity = new LobTestEntity();
            define(session, i, entity);
        }

        //Update
        for (long i = 1; i < 5; i++) {
            final LobTestEntity entity = (LobTestEntity) session.get(LobTestEntity.class, i);
            entity.setQwerty("Updated " + i);
        }

        session.getTransaction().commit();
        LOG.info("Done");
    }

    @Override
    protected Class[] getAnnotatedClasses() {
        return new Class[]{LobTestEntity.class};
    }

    private static void define(final Session session, final long i, final LobTestEntity entity) {
        entity.setId(i);
        entity.setQwerty(randomString(4000));
        entity.setLobValue(session.getLobHelper().createBlob(new byte[]{0}));
        session.save(entity);
        session.flush();
    }

    private static String randomString(final int count) {
        final StringBuilder buffer = new StringBuilder(count);
        for (int i = 0; i < count; i++) {
            buffer.append('a');
        }
        return buffer.toString();
    }
}
