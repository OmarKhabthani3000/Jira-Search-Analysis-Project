package hibernate.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.junit.Assert;
import org.junit.Test;

/**
 * Demonstrates a problem in with eagerly retrieved persistset. When eagerly retrieved indirectly
 * the persistent set calls hashcode on items before they are populated and thus retrieves and
 * stores them under an incorrect hashcode making them inaccessible by collection operations that
 * rely on hashcode.
 * 
 * @author igor.vaynberg
 */
public class HibernateEagerPersistentSetTest
{


    @Test
    public void test()
    {
        final Long containerId;
        final SessionFactory sf = buildSessionFactory();

        { // populate database with a container
            Session session = sf.openSession();
            Transaction txn = session.beginTransaction();

            Container container = new Container();
            container.items.add(new Item(container, "item1"));
            container.items.add(new Item(container, "item2"));

            session.persist(container);
            txn.commit();
            session.close();

            Assert.assertNotNull(container.id);
            containerId = container.id;
        }


        { // this passes, when the container is loaded directly
            Session session = sf.openSession();
            Transaction txn = session.beginTransaction();

            Container container = (Container)session.get(Container.class, containerId);
            assertNotNull(container);

            assertEquals(2, container.items.size());
            assertTrue(container.items.contains(new Item("item1")));
            assertTrue(container.items.contains(new Item("item2")));

            txn.rollback();
            session.close();
        }

        { // this fails, when the container is loaded from query
            Session session = sf.openSession();
            Transaction txn = session.beginTransaction();

            Item item1 = (Item)session.createQuery("FROM Item WHERE name=:name").setParameter(
                    "name", "item1").uniqueResult();

            assertNotNull(item1);

            assertEquals(2, item1.container.items.size());

            /*
             * below line fails because persistentset stores the items under incorrect hashcode
             * which it obtained by calling item#hashcode before item's fields were populated . this
             * happens during the execution of the above query.
             */
            assertTrue(item1.container.items.contains(item1));

            txn.rollback();
            session.close();
        }

    }

    private SessionFactory buildSessionFactory()
    {
        Properties props = new Properties();
        props.put("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.put("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        props.put("hibernate.connection.url", "jdbc:hsqldb:mem:test");
        props.put("hibernate.connection.username", "sa");
        props.put("hibernate.connection.password", "");
        props.put("hibernate.hbm2ddl.auto", "create");
        props.put("hibernate.show_sql", "true");

        AnnotationConfiguration cfg = new AnnotationConfiguration();
        cfg.setProperties(props);
        cfg.addAnnotatedClass(Item.class);
        cfg.addAnnotatedClass(Container.class);

        return cfg.buildSessionFactory();
    }

    /** simple container for items */
    @Entity(name = "Container")
    private static class Container
    {
        @Id
        @GeneratedValue
        Long id;

        @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST, mappedBy = "container")
        Set<Item> items = new HashSet<Item>();
    }

    /** simple item that implements a custom equals/hashcode */
    @Entity(name = "Item")
    private static class Item
    {
        @Id
        @GeneratedValue
        Long id;

        @ManyToOne
        Container container;

        String name;

        Item()
        {

        }

        Item(String name)
        {
            this.name = name;
        }

        Item(Container container, String name)
        {
            this.container = container;
            this.name = name;
        }

        @Override
        public int hashCode()
        {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((name == null) ? 0 : name.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj)
        {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            Item other = (Item)obj;
            if (name == null)
            {
                if (other.name != null)
                    return false;
            }
            else if (!name.equals(other.name))
                return false;
            return true;
        }
    }

}
