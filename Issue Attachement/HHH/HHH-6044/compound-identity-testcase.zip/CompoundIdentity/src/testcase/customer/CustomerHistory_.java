package testcase.customer;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(CustomerHistory.class)
public class CustomerHistory_ {

    public static volatile SingularAttribute<CustomerHistory, Integer> logId;
    
    public static volatile SingularAttribute<CustomerHistory, Integer> customerId;

    public static volatile SingularAttribute<CustomerHistory, String> EMail;

    public static volatile SingularAttribute<CustomerHistory, String> name;
    
}


