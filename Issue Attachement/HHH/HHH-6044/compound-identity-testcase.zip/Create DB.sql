-- Uses SQL2005
-- Persistence.xml has the login set to 'sa' with no password.

CREATE DATABASE [CompoundIdentity]
GO

USE [CompoundIdentity]
GO

CREATE TABLE [dbo].[customer_history](
	[customer_id] [int]                       NOT NULL,
	[log_id]      [int]         IDENTITY(1,1) NOT NULL,
	[e_mail]      [varchar](50)               NOT NULL,
	[name]        [varchar](50)               NOT NULL,
    CONSTRAINT [PK_customer_history_1] PRIMARY KEY CLUSTERED 
    (
	    [customer_id] ASC,
	    [log_id]      ASC
    )
)
GO