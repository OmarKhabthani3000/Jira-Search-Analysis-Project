package testcase;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import testcase.customer.CustomerHistory;


public class Main {

    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("compoundIdentity.persistence"); 
        EntityManager em = factory.createEntityManager();
        
        em.getTransaction().begin();
        
        CustomerHistory history = new CustomerHistory();
        history.setCustomerId(100);
        history.setEMail("test@noreply.com");
        history.setName("Test");
        
        em.persist(history);
        
        em.getTransaction().commit();
        // java.lang.IllegalArgumentException: Can not set java.lang.Integer field testcase.customer.CustomerHistory.logId to org.hibernate.id.IdentifierGeneratorHelper$2
    }

}
