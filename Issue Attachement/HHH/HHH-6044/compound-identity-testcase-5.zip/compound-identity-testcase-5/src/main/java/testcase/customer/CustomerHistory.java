package testcase.customer;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

@Entity(name = "customer_history")
public class CustomerHistory implements Serializable {

    private static final long serialVersionUID = 154181689966783L;

    @Id
    @Column(name = "customer_id", nullable = false)
    protected Integer customerId;

    public Integer getCustomerId() {
        return customerId;    
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId; 
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Generated(value = GenerationTime.INSERT)
    @Column(name = "log_id", nullable = false)
    protected Integer logId;

    public Integer getLogId() {
        return logId;    
    }

    public void setLogId(Integer customerId) {
        this.logId = customerId; 
    }

    @Column(name = "e_mail", nullable = false)
    protected String EMail;

    public String getEMail() {
        return EMail;    
    }

    public void setEMail(String EMail) {
        this.EMail = EMail; 
    }

    @Column(name = "name", nullable = false)
    protected String name;

    public String getName() {
        return name;    
    }

    public void setName(String name) {
        this.name = name; 
    }
}


