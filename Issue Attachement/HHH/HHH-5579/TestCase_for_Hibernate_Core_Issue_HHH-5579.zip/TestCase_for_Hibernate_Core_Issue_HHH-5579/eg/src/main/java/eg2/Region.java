package eg2;

/**
 * @date 20 Oct 2010
 * @time 16:48:41
 */
public class Region {
    
    private Integer id;
    private String name;
    
    /**
     * Class constructor
     */
    Region() {
	
    }

    
    /**
     * Class constructor
     * @param id
     * @param name
     */
    public Region(Integer id, String name) {
	this.id = id;
	this.name = name;
    }


    /**
     * Getter for <code>this.id</code>
     * @return the id
     */
    public Integer getId() {
        return id;
    }


    /**
     * Setter for <code>this.id</code>
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }


    /**
     * Getter for <code>this.name</code>
     * @return the name
     */
    public String getName() {
        return name;
    }


    /**
     * Setter for <code>this.name</code>
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
   
}
