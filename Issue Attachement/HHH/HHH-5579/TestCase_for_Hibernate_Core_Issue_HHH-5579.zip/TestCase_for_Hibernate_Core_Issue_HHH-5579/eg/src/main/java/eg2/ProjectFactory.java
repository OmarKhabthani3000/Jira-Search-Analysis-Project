package eg2;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

/**
 * @date 20 Oct 2010
 * @time 15:45:16
 */
public class ProjectFactory {

    /**
     * Gets all projects for defined criteria
     * 
     * @param name
     *            project name
     * @param region
     *            project region
     * @param sector
     *            project sector
     * @return list of projects
     */
    @SuppressWarnings("unchecked")
    public List<Project> getProjects(Session session, String name,
	    Region region, Sector sector) {

	Transaction transaction = null;
	List<Project> result = null;
	transaction = session.beginTransaction();

	Criteria crit = session.createCriteria(Project.class, "project");

	if (name != null && name.length() > 0) {
	    crit.add(Restrictions.ilike("name", name));
	}

	crit.createCriteria("regions").add(
		Restrictions.eq("id", region.getId()));
	crit.createCriteria("sectors").add(
		Restrictions.eq("id", region.getId()));
	crit.setFetchSize(10);
	crit.setMaxResults(10);

	result = crit.list();

	transaction.commit();
	transaction = null;

	return result;
    }

}
