package eg2;

import java.util.Set;


public class Project {

    private Integer id;
    private String name;
    private Set<Region> regions;
    private Set<Sector> sectors;
    
    /**
     * Class constructor
     */
    Project() {
	
    }
    
    /**
     * Class constructor
     * @param id
     */
    Project(Integer id) {
	this.id = id;
    }
    
    
    /**
     * Getter for <code>this.id</code>
     * @return the id
     */
    public Integer getId() {
        return id;
    }
    /**
     * Setter for <code>this.id</code>
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }
    /**
     * Getter for <code>this.name</code>
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * Setter for <code>this.name</code>
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * Getter for <code>this.regions</code>
     * @return the regions
     */
    public Set<Region> getRegions() {
        return regions;
    }
    /**
     * Setter for <code>this.regions</code>
     * @param regions the regions to set
     */
    public void setRegions(Set<Region> regions) {
        this.regions = regions;
    }
    /**
     * Getter for <code>this.sectors</code>
     * @return the sectors
     */
    public Set<Sector> getSectors() {
        return sectors;
    }
    /**
     * Setter for <code>this.sectors</code>
     * @param sectors the sectors to set
     */
    public void setSectors(Set<Sector> sectors) {
        this.sectors = sectors;
    }
    
    
    
    
}
