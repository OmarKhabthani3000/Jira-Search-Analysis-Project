package eg2;

import java.util.List;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @date 20 Oct 2010
 * @time 16:53:32
 */
public class ProjectFactoryTest extends TestCase {

    private ProjectFactory testInstance;
    private String testName;
    private Sector testSector;
    private Region testRegion;
    private SessionFactory sessionFactory;
    private Session testSession;

    /*
     * (non-Jsdoc)
     * 
     * @see junit.framework.TestCase#setUp()
     */
    @Before
    protected void setUp() throws Exception {
	super.setUp();
	this.testInstance = new ProjectFactory();
	
	final Configuration cfg = new Configuration();
	cfg.configure();
	sessionFactory = cfg.buildSessionFactory();
	this.testSession = sessionFactory.openSession();
    }

    /*
     * (non-Jsdoc)
     * 
     * @see junit.framework.TestCase#tearDown()
     */
    @After
    protected void tearDown() throws Exception {
	super.tearDown();
	if (this.testSession != null)
	    this.testSession.close();
	sessionFactory.close();
    }

    // Helper method
    private void setUp_fixture1() {
	this.testName = "test";
	this.testRegion = new Region(1, "region");
	this.testSector = new Sector(1, "sector");
    }

    /**
     * Test method for
     * {@link eg2.ProjectFactory#getProjects(java.lang.String, eg2.Region, eg2.Sector)}
     * .
     */
    @Test
    public final void testGetProjects() {
	setUp_fixture1();
	List<Project> result = this.testInstance.getProjects(this.testSession,
		this.testName, this.testRegion, this.testSector);

	assertNotNull(result);
	assertTrue(result.isEmpty());
    }

}
