package nl.orangebits.ordertest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

public class OrderTest {

	private static final Logger log = LoggerFactory.getLogger(OrderTest.class);
	
	EntityManagerFactory entityManagerFactory;
	EntityManager entityManager;
	
	@Before
	public void setup(){
		entityManagerFactory = Persistence
				.createEntityManagerFactory("OrderColumnTestJPA");
		entityManager = entityManagerFactory
				.createEntityManager();

	}
	
	@After
	public void teardown(){
		entityManager.close();
		entityManagerFactory.close();	
	}
	
	@Test
	public void cascadeSaveTest() {
		EntityTransaction tx = entityManager.getTransaction();
		
		try{
			
			tx.begin();
			
			Forum forum = new Forum();
			forum.setName("forum1");
			forum = entityManager.merge(forum);
	
			//Create a post
			Post post = new Post();
			post.setName("post1");
			post.setForum(forum);
			forum.getPosts().add(post);
			
			forum = entityManager.merge(forum);
			
			entityManager.flush();
			entityManager.clear();
			entityManagerFactory.getCache().evictAll();
			
			forum = (Forum) entityManager.find(Forum.class, forum.getId());
			
			assertEquals(1, forum.getPosts().size());
			
		}catch(Exception e){
			log.error("problem",e); 
		}finally{
			if(tx.isActive())
				tx.commit();
		}
	}
	
	@Test
	public void loadAndSaveTest() {
		
		EntityTransaction tx = entityManager.getTransaction();

		try {

			tx.begin();
			
			Forum forum = new Forum();
			forum.setName("forum2");
			forum = entityManager.merge(forum);
			
			entityManager.flush();
			entityManager.clear();
			entityManagerFactory.getCache().evictAll();
			
			forum = entityManager.find(Forum.class, forum.getId());

			User user = new User();
			user.setName("john");
			user.setForum(forum);
			forum.getUsers().add(user);
			
			forum = entityManager.merge(forum);
			
			entityManager.flush();
			entityManager.clear();
			entityManagerFactory.getCache().evictAll();
			
			forum = entityManager.find(Forum.class, forum.getId());
			
			assertEquals(1, forum.getUsers().size());
			assertEquals("john", forum.getUsers().get(0).getName());
			
		}catch(Exception e){
			log.error("problem",e); 
		}finally{
			if(tx.isActive())
				tx.commit();
		}
		
	}
	
	@Test
	public void owningSaveTest(){

		EntityTransaction tx = entityManager.getTransaction();
		
		try{
			
			tx.begin();
			
			Forum forum = new Forum();
			forum.setName("forum3");
			forum = entityManager.merge(forum);
	
			//Create a post
			Post post = new Post();
			post.setName("post2");
			post.setForum(forum);
			
			post = entityManager.merge(post);
		
			entityManager.flush();
			entityManager.clear();
			entityManagerFactory.getCache().evictAll();
			
			forum = entityManager.find(Forum.class, forum.getId());
			
			assertEquals(1, forum.getPosts().size());
		
		}catch(Exception e){
			log.error("problem",e); 
		}finally{
			if(tx.isActive())
				tx.commit();
		}

	}
	
}
