package foo;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.Test;

import foo.a.Customer;
import foo.a.Order;

public class OrderColumnTest {

    @Test
    public void flushTest() {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("OrderColumnTestJPA");
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        EntityTransaction tx = entityManager.getTransaction();

        tx.begin();
        try {

            Customer c = new Customer();
            c.setOrders(new ArrayList<Order>());

            entityManager.persist(c);

            Order o1 = new Order();
            o1.setNumber("o1");
            o1.setCustomer(c);
            c.getOrders().add(o1);
            entityManager.persist(o1);

            Order o2 = new Order();
            o2.setNumber("o2");
            o2.setCustomer(c);
            c.getOrders().add(o2);
            entityManager.persist(o2); 
            
            entityManager.flush();

            int customerId = c.getId();

            entityManager.clear();

            entityManagerFactory.getCache().evictAll();

            c = entityManager.find(Customer.class, customerId);

            assertNotNull(c);

            assertNotNull(c.getOrders());
            assertEquals(2, c.getOrders().size());
            assertEquals("o1", c.getOrders().get(0).getNumber());
            assertEquals("o2", c.getOrders().get(1).getNumber());
        } finally {
            tx.rollback();
        }
        entityManager.close();
        entityManagerFactory.close();
    }
}
