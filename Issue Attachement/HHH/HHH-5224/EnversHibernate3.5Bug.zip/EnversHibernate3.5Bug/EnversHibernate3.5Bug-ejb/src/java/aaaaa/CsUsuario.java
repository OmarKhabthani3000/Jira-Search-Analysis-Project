/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package aaaaa;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.envers.Audited;

/**
 *
 * @author dyego
 */
@Entity
@Table( name = "CS_USUARIO2")
    @Audited
    public class CsUsuario implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Basic(optional = false)
    @Column(name = "usu_id", nullable = false)
    private Integer usuId;
    @Basic(optional = false)
    @Column(name = "usu_cpf", nullable = false, length = 14)
    private String usuCpf;
    @Basic(optional = false)
    @Column(name = "usu_nome", nullable = false, length = 255)
    private String usuNome;
    @Basic(optional = false)
    @Column(name = "usu_ativo", nullable = false)
    private boolean usuAtivo;
    @Column(name = "usu_login", length = 255)
    private String usuLogin;
    @Column(name = "usu_senha", length = 255)
    private String usuSenha;
    @Basic(optional = false)
    @Column(name = "usu_trocarsenha", nullable = false)
    private boolean usuTrocarsenha;
    @Column(name = "usu_telefones", length = 100)
    private String usuTelefones;
    @Column(name = "usu_instituicaocadastro", length = 255)
    private String usuInstituicaocadastro;
    @Column(name = "usu_grupo")
    private int usuGrupo;

    public CsUsuario() {
    }

    public CsUsuario(Integer usuId) {
        this.usuId = usuId;
    }

    public CsUsuario(Integer usuId, String usuCpf, String usuNome, boolean usuAtivo, boolean usuTrocarsenha) {
        this.usuId = usuId;
        this.usuCpf = usuCpf;
        this.usuNome = usuNome;
        this.usuAtivo = usuAtivo;
        this.usuTrocarsenha = usuTrocarsenha;
    }

    public Integer getUsuId() {
        return usuId;
    }

    public void setUsuId(Integer usuId) {
        this.usuId = usuId;
    }

    public String getUsuCpf() {
        return usuCpf;
    }

    public void setUsuCpf(String usuCpf) {
        this.usuCpf = usuCpf;
    }

    public String getUsuNome() {
        return usuNome;
    }

    public void setUsuNome(String usuNome) {
        this.usuNome = usuNome;
    }

    public boolean getUsuAtivo() {
        return usuAtivo;
    }

    public void setUsuAtivo(boolean usuAtivo) {
        this.usuAtivo = usuAtivo;
    }

    public String getUsuLogin() {
        return usuLogin;
    }

    public void setUsuLogin(String usuLogin) {
        this.usuLogin = usuLogin;
    }

    public String getUsuSenha() {
        return usuSenha;
    }

    public void setUsuSenha(String usuSenha) {
        this.usuSenha = usuSenha;
    }

    public boolean getUsuTrocarsenha() {
        return usuTrocarsenha;
    }

    public void setUsuTrocarsenha(boolean usuTrocarsenha) {
        this.usuTrocarsenha = usuTrocarsenha;
    }

    public String getUsuTelefones() {
        return usuTelefones;
    }

    public void setUsuTelefones(String usuTelefones) {
        this.usuTelefones = usuTelefones;
    }

    public String getUsuInstituicaocadastro() {
        return usuInstituicaocadastro;
    }

    public void setUsuInstituicaocadastro(String usuInstituicaocadastro) {
        this.usuInstituicaocadastro = usuInstituicaocadastro;
    }


    @Override
    public int hashCode() {
        int hash = 0;
        hash += (usuId != null ? usuId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CsUsuario)) {
            return false;
        }
        CsUsuario other = (CsUsuario) object;
        if ((this.usuId == null && other.usuId != null) || (this.usuId != null && !this.usuId.equals(other.usuId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "aaaaa.CsUsuario[usuId=" + usuId + "]";
    }

    public int getUsuGrupo() {
        return usuGrupo;
    }

    public void setUsuGrupo(int usuGrupo) {
        this.usuGrupo = usuGrupo;
    }

}
