/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package aaaaa.ent;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author dyego
 */
@Named
@RequestScoped
public class NewClass {

    @Inject
    private NewSessionBean bean;



    public String test1() {
        bean.doCadastrar();
        return "/index.faces";
    }

    public String test2() {
        bean.doAlterar();
        return "/index.faces";
    }

}
