/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package aaaaa.ent;

import aaaaa.CsUsuario;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author dyego
 */
@Stateless
@LocalBean
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class NewSessionBean {
    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @PersistenceContext
    private EntityManager em;

    public void doCadastrar() {
        CsUsuario csu = new CsUsuario();
        csu.setUsuNome("Dyego");
        csu.setUsuCpf("111");
        csu.setUsuTelefones("aaaa");
        csu.setUsuGrupo(1);
        csu.setUsuLogin("login");
        em.persist(csu);
    }

    public void doAlterar() {
        CsUsuario csu = em.find(CsUsuario.class, 1);
        csu.setUsuSenha("Senha");
        em.merge(csu);
    }


 
}
