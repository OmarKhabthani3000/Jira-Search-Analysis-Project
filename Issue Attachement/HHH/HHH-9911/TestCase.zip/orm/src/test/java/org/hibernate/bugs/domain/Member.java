package org.hibernate.bugs.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Member implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "username")
	private Credential credential;

	public Credential getCredential() {
		return credential;
	}

	public void setCredential(Credential credential) {
		this.credential = credential;
	}
}