package org.hibernate.bugs.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Friendship implements Serializable {

	private static final long serialVersionUID = 1;
	
//	Uncomment the @JoinColumn declarations to make the test pass
	
	@Id
	@ManyToOne
//	@JoinColumn(referencedColumnName = "username")
	private Member requester;
	
	@Id
	@ManyToOne
//	@JoinColumn(referencedColumnName = "username")
	private Member friend;

	public Member getRequester() {
		return requester;
	}

	public void setRequester(Member requester) {
		this.requester = requester;
	}

	public Member getFriend() {
		return friend;
	}

	public void setFriend(Member friend) {
		this.friend = friend;
	}
}