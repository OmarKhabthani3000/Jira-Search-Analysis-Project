package org.acme;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ExampleServiceTest {
    @Spy
    private final EntityManager entityManager = Persistence.createEntityManagerFactory("persistenceUnitExample").createEntityManager();

    @InjectMocks
    private ExampleService service = new ExampleService();


    @Test
    void create() {
        entityManager.getTransaction().begin();

        service.create();

        entityManager.getTransaction().commit();
    }
}
