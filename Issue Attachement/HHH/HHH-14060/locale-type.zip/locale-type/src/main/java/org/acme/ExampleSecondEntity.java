package org.acme;

import org.hibernate.annotations.BatchSize;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
public class ExampleSecondEntity {
    @Id
    @GeneratedValue
    private Long id;

    private String name;



    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "exampleSecondEntity")
    @BatchSize(size = 30)
    private Set<PositionEntity> positions = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<PositionEntity> getPositions() {
        return positions;
    }

    public void setPositions(Set<PositionEntity> positions) {
        this.positions = positions;
    }
}
