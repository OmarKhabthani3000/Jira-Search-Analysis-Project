package org.acme;

import org.hibernate.annotations.BatchSize;

import javax.persistence.*;

@Entity
public class PositionEntity {
    @Id
    @GeneratedValue
    private Long id;

    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn
    private ExampleSecondEntity exampleSecondEntity;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ExampleSecondEntity getExampleSecondEntity() {
        return exampleSecondEntity;
    }

    public void setExampleSecondEntity(ExampleSecondEntity exampleSecondEntity) {
        this.exampleSecondEntity = exampleSecondEntity;
    }
}
