package org.acme;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.UUID;

@ApplicationScoped
@Transactional
public class ExampleService {
    @Inject
    EntityManager em;

    public ExampleSecondEntity create() {
        ExampleSecondEntity exampleSecondEntity = new ExampleSecondEntity();
        exampleSecondEntity.setName(UUID.randomUUID().toString());

        for (int i = 0; i < 10; i++) {
            PositionEntity positionEntity = new PositionEntity();
            positionEntity.setName(UUID.randomUUID().toString());

            positionEntity.setExampleSecondEntity(exampleSecondEntity);

            exampleSecondEntity.getPositions().add(positionEntity);
        }

        em.persist(exampleSecondEntity);

        return exampleSecondEntity;
    }


    public ExampleSecondEntity find(Long id) {
        ExampleSecondEntity exampleSecondEntity = em.find(ExampleSecondEntity.class, id);

        return exampleSecondEntity;
    }
}
