public class Cat {
	private boolean abc;

	public Cat() {
	}

	public boolean isAbc() {
		return abc;
	}

	public void setAbc(boolean abc) {
		this.abc = abc;
	}
}




