import org.hibernate.tool.hbm2ddl.SchemaValidator;
import org.hibernate.cfg.Configuration;

public class HsqlHibernateBit {
	public static void main(String[] args) {
		Configuration cfg= new Configuration().configure("hibernate-HSQL.cfg.xml");
		cfg.addClass(Cat.class);
		cfg.buildSessionFactory();
		SchemaValidator schemaValidator = new SchemaValidator(cfg);
		schemaValidator.validate();
	}
}


