package test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import junit.framework.Assert;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class KeyJoinTest {

	private static final String OBJ_EMPTY = "OBJ_4";
	private static final String OBJ_FOOBAR = "OBJ_3";
	private static final String OBJ_BAR = "OBJ_2";
	private static final String OBJ_FOO = "OBJ_1";
	private static EntityManagerFactory emf;
	private static EntityManager em;

	private static final String KEY_FOO = "foo";
	private static final String KEY_BAR = "bar";
	
	@BeforeClass
	public static void setUpClass() throws Exception {
		emf = Persistence.createEntityManagerFactory("test");
		em = emf.createEntityManager();
	}

	@AfterClass
	public static void tearDownClass() throws Exception {
		em.close();
		emf.close(); 
		
	}

	@Test
	public void keyJoinTest() {
	
		EntityTransaction et = buildData();

		em.flush();	
		et.commit();
		
		TypedQuery<IdValue> q = em.createQuery("SELECT NEW test.IdValue(a.name, m.value) FROM A AS a LEFT JOIN a.keyValue AS m WITH KEY(m)=?1 ORDER BY a.name", IdValue.class);
		q.setParameter(1, KEY_FOO);
		List<IdValue> results = q.getResultList();
		
		// The query should report all 4 entities - including those with no KEY_FOO
		Assert.assertEquals(4, results.size());

		// OBJ_FOO has KEY_FOO with content KEY_FOO
		IdValue idv1 = results.get(0);
		Assert.assertEquals(OBJ_FOO, idv1.getId());
		Assert.assertEquals(KEY_FOO, idv1.getValue());

		// OBJ_BAR has no KEY_FOO, but only KEY_BAR - expect null
		IdValue idv2 = results.get(1);
		Assert.assertEquals(OBJ_BAR, idv2.getId());
		Assert.assertNull(idv2.getValue());
		
		// OBJ_FOOBAR has KEY_FOO and KEY_BAR - expect only the content of KEY_BAR
		IdValue idv3 = results.get(2);
		Assert.assertEquals(OBJ_FOOBAR, idv3.getId());
		Assert.assertEquals(KEY_FOO, idv3.getValue());

		// OBJ_EMPTY has no content in Map, expect null
		IdValue idv4 = results.get(3);
		Assert.assertEquals(OBJ_EMPTY, idv4.getId());
		Assert.assertNull(idv4.getValue());
	}

	private EntityTransaction buildData() {
		EntityTransaction et = em.getTransaction();
		et.begin();
		A a1 = new A();
		a1.setName(OBJ_FOO);
		B b11 = new B();
		b11.setValue(KEY_FOO);
		a1.getKeyValue().put(KEY_FOO, b11);
		em.persist(a1);

		A a2 = new A();
		a2.setName(OBJ_BAR);
		B b21 = new B();
		b21.setValue(KEY_BAR);
		a2.getKeyValue().put(KEY_BAR, b21);
		em.persist(a2);
		
		A a3 = new A();
		a3.setName(OBJ_FOOBAR);
		B b31 = new B();
		b31.setValue(KEY_FOO);
		B b32 = new B();
		b32.setValue(KEY_BAR);
		a3.getKeyValue().put(KEY_FOO, b31);
		a3.getKeyValue().put(KEY_BAR, b32);
		em.persist(a3);

		A a4 = new A();
		a4.setName(OBJ_EMPTY);
		em.persist(a4);
		return et;
	}
}
