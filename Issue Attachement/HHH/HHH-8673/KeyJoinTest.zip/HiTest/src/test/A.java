package test;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;

@Entity
public class A {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	private String name;
	
	@OneToMany(cascade=CascadeType.ALL)
	@MapKeyColumn(name="key")
	private final Map<String, B> keyValue = new HashMap<>();

	public long getId() {
		return id;
	}
	
	public void setId(long id) {
		this.id =id;
	}
	
	public Map<String, B> getKeyValue() {
		return keyValue;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
