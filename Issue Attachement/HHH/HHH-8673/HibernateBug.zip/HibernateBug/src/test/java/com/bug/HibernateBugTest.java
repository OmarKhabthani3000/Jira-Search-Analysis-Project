package com.bug;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import org.hibernate.ejb.Ejb3Configuration;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Christian
 */
public class HibernateBugTest {

    @Test
    public void setUpClass() throws Exception {
        Properties properties = new Properties();
        properties.put("javax.persistence.provider", "org.hibernate.ejb.HibernatePersistence");
        properties.put("javax.persistence.transactionType", "RESOURCE_LOCAL");
        properties.put("hibernate.connection.url", "jdbc:h2:mem:test");
        properties.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
        properties.put("hibernate.connection.driver_class", "org.h2.Driver");
        properties.put("hibernate.connection.password", "admin");
        properties.put("hibernate.connection.username", "admin");
        properties.put("hibernate.hbm2ddl.auto", "create-drop");
        properties.put("hibernate.show_sql", "true");
        properties.put("hibernate.format_sql", "true");
        
        Ejb3Configuration config = new Ejb3Configuration();
        config.addProperties(properties);
        config.addAnnotatedClass(Document.class);
        config.addAnnotatedClass(Person.class);
        EntityManagerFactory emf = config.buildEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        
        em.getTransaction().begin();
        Person p1 = new Person();
        Person p2 = new Person();
        Person p3 = new Person();
        
        em.persist(p1);
        em.persist(p2);
        em.persist(p3);
        
        Document doc1 = new Document();
        doc1.getContacts().put(1, p1);
        em.persist(doc1);
        
        Document doc2 = new Document();
        em.persist(doc2);
        
        Document doc3 = new Document();
        doc3.getContacts().put(1, p2);
        doc3.getContacts().put(2, p3);
        em.persist(doc3);
        em.getTransaction().commit();
        
        String query = "SELECT contacts.name FROM Document d LEFT JOIN d.contacts contacts WITH KEY(contacts) = :contactNr ORDER BY d.id, contacts.id";
        List<String> result = em.createQuery(query, String.class).setParameter("contactNr", 1).getResultList();
        
        assertEquals(result.get(0), p1.getName());
        assertNull(result.get(1));
        assertEquals(result.get(2), p2.getName());
        
        emf.close();
    }
    
}
