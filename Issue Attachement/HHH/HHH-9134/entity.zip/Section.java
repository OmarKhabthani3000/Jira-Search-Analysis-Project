package test;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Section implements Serializable {

	private static final long serialVersionUID = 9197604206574697276L;

	@Column(length = 50)
	private String name;

	@Column(length = 50)
	private String content;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
