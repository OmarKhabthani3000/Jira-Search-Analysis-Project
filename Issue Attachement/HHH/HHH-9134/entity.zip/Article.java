package test;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OrderColumn;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NaturalId;

@Entity
public class Article implements Serializable {

	private static final long serialVersionUID = -6685568143708412797L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "article_seq")
	@SequenceGenerator(name = "article_seq", sequenceName = "article_seq", allocationSize = 1)
	protected Long id;

	@NaturalId(mutable = true)
	@Column(length = 10)
	private String name;

	@ElementCollection(fetch = FetchType.LAZY, targetClass = Section.class)
	@CollectionTable(name = "Section", joinColumns = @JoinColumn(name = "article"))
	@OrderColumn(name = "lineNumber", nullable = false)
	@Fetch(FetchMode.SUBSELECT)
	private List<Section> sections = new ArrayList<Section>(0);

	public String toString() {
		return this.name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Section> getSections() {
		return sections;
	}

	public void setSections(List<Section> sections) {
		this.sections = sections;
	}

}
