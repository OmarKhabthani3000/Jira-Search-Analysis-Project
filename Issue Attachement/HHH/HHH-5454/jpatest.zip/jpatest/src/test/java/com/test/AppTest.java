package com.test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class AppTest extends TestCase {
	public AppTest(String testName) {
		super(testName);
	}

	public static Test suite() {
		return new TestSuite(AppTest.class);
	}

    public void testJPA() throws Exception {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("manager1");
		EntityManager em = emf.createEntityManager();
		// create a person with no associations
		Long personId = null;
		{
		    EntityTransaction tx = em.getTransaction();
		    tx.begin();
    		Person p1 = createPerson("Firstname", "Lastname");
    		em.persist(p1);
    		tx.commit();
    		personId = p1.getId();
		}
		// update created person, add
		// 1) single phone association
		// 2) single relation assiciation, referring to another related Person object with another single phone
		{
		    EntityTransaction tx = em.getTransaction();
            tx.begin();
		    Person p1 = em.find(Person.class, personId);
		    
            // add single phone to main entity
            {
                Phone ph1 = createPhone(p1, "1234567", 1L);
                if (p1.getPhones() == null) {
                    p1.setPhones(new HashMap<Long, Phone>());
                }
                p1.getPhones().put(ph1.getTypeId(), ph1);
            }
            // add related person with a single phone to main entity
            {
                Person p2 = createPerson("Relatedfirstname", "Relatedlastname");
                Phone ph2 = createPhone(p2, "88888888888", 1L);
                Map<Long, Phone> phones = new HashMap<Long, Phone>();
                phones.put(ph2.getTypeId(), ph2);
                p2.setPhones(phones);

                Relation r1 = new Relation();
                r1.setPersonId(p1.getId());
                r1.setRelatedPerson(p2);

                if (p1.getRelations() == null) {
                    p1.setRelations(new HashSet<Relation>());
                }
                p1.getRelations().add(r1);
            }
		    
            em.persist(p1);
            tx.commit();
		}
		em.close();
		emf.close();

	}

    private Person createPerson(String firstname, String lastname) {
        Person person = new Person();
        person.setFirstname(firstname);
        person.setLastname(lastname);
        return person;
    }

    private Phone createPhone(Person person, String phoneNo, Long typeId) {
        Phone phone = new Phone();
        phone.setPerson(person);
        phone.setPhoneNo(phoneNo);
        phone.setTypeId(typeId);
        return phone;
    }
}
