package com.test;

import java.io.Serializable;

public class Relation implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;
    private Long personId;
    private Person relatedPerson;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getPersonId() {
        return personId;
    }
    public void setPersonId(Long personId) {
        this.personId = personId;
    }
    public Person getRelatedPerson() {
        return relatedPerson;
    }
    public void setRelatedPerson(Person relatedPerson) {
        this.relatedPerson = relatedPerson;
    }
}
