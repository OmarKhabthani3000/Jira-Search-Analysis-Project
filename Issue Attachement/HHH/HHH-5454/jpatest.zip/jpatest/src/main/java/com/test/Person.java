package com.test;

import java.util.Map;
import java.util.Set;

public class Person {
    private Long id;
    private String firstname;
    private String lastname;
    private Map<Long, Phone> phones;
    private Set<Relation> relations;
    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getFirstname() {
        return firstname;
    }
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }
    public String getLastname() {
        return lastname;
    }
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    public Map<Long, Phone> getPhones() {
        return phones;
    }
    public void setPhones(Map<Long, Phone> phones) {
        this.phones = phones;
    }
    public Set<Relation> getRelations() {
        return relations;
    }
    public void setRelations(Set<Relation> relations) {
        this.relations = relations;
    }
    
}
