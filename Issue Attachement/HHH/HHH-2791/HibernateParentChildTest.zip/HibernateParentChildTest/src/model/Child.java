package model;


public class Child {
    public String id;
    public String parent;

    /**
     * @return Returns the id.
     */
    public String getId() {
        return id;
    }

    /**
     * @param id The id to set.
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return Returns the parent.
     */
    public String getParent() {
        return parent;
    }

    /**
     * @param parent The parent to set.
     */
    public void setParent(String parent) {
        this.parent = parent;
    }
}
