package model;

import java.util.Set;

public class Parent {

    public String id;
    public Set children;
    /**
     * @return Returns the children.
     */
    public Set getChildren() {
        return children;
    }
    /**
     * @param children The children to set.
     */
    public void setChildren(Set children) {
        this.children = children;
    }
    /**
     * @return Returns the id.
     */
    public String getId() {
        return id;
    }
    /**
     * @param id The id to set.
     */
    public void setId(String id) {
        this.id = id;
    }
}
