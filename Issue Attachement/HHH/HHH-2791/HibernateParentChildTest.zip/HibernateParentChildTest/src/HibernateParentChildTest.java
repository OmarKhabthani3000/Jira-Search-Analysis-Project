import java.util.HashSet;
import java.util.Set;

import model.Child;
import model.Parent;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateParentChildTest {

    /**
     * @param args
     */
    public static void main(String[] args) {
        SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        Session session = factory.getCurrentSession();
        
        /* create parent */
        Parent parent = new Parent();
        parent.id="1";
        
        /* create children*/
        Child child1 = new Child();
        child1.id = "1C";
        child1.setParent(parent.id);
        
        Set set = new HashSet();
        set.add(child1);
        
        parent.children = set;
        
        session.beginTransaction();
        session.save(parent);
        session.getTransaction().commit();
        System.out.println("first commit");
        
        session = factory.openSession();
        session.beginTransaction();
        
        String query = "delete Parent p where p.id = :parentId";
        session.createQuery(query).setParameter("parentId","1").executeUpdate();
        session.getTransaction().commit();
        
        System.out.println("HQL delete!");

        session = factory.openSession();
        session.beginTransaction();
        
        /* re-save parent for session based delete */
        session.save(parent);
        session.delete(parent);
        
        session.getTransaction().commit();
        System.out.println("Session based Delete!");
        
    }

}
