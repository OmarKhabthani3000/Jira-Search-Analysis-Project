package org.hibernate.bugs;

import org.hibernate.bugs.entity.Child;
import org.hibernate.bugs.entity.Parent;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import static java.util.Collections.singletonMap;
import static javax.persistence.Persistence.createEntityManagerFactory;
import static org.junit.Assert.assertEquals;
import static org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class OneToOneCascadeTestCase {

    private EntityManagerFactory entityManagerFactory;

    public OneToOneCascadeTestCase(boolean enableOrderInserts) {
        entityManagerFactory =
                createEntityManagerFactory("templatePU", singletonMap("hibernate.order_inserts", String.valueOf(enableOrderInserts)));
    }

    @Parameters(name = "hibernate.order_inserts = {0}")
    public static Object[] data() {
        return new Object[] {true, false};
    }

    @After
    public void tearDown() throws Exception {
        entityManagerFactory.close();
    }

    @Test
    public void hhh11609Test() throws Exception {
        //GIVEN
        Parent parent = new Parent();
        parent.id = "parentId";

        Child child = new Child();
        child.id = "childId";
        child.parent = parent;

        parent.child = child;

        //WHEN
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        entityManager.persist(parent);

        entityManager.getTransaction().commit();
        entityManager.close();

        //THEN
        EntityManager entityManager2 = entityManagerFactory.createEntityManager();
        entityManager2.getTransaction().begin();

        Parent savedParent = entityManager2.find(Parent.class, "parentId");
        assertEquals("parentId", savedParent.id);
        assertEquals("childId", savedParent.child.id);
        assertEquals(savedParent, savedParent.child.parent);
    }
}
