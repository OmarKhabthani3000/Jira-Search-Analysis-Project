package org.hibernate.bugs.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Parent {
    @Id
    public String id;

    @OneToOne(mappedBy = "parent", cascade = CascadeType.ALL, orphanRemoval = true)
    public Child child;
}
