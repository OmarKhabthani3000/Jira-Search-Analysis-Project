package org.hibernate.bugs.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Child {

    @Id
    public String id;

    @OneToOne
    public Parent parent;
}
