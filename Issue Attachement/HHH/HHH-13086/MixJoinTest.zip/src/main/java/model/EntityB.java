package model;

import java.util.Collection;
import java.util.HashSet;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;


@Entity
public class EntityB extends AbstractEntity {

	/**
	 * SUID
	 */
	private static final long serialVersionUID = -4316768421714123901L;
	
	public EntityB(int i) {
		super(i);
	}
	
	@OneToMany(cascade={CascadeType.ALL},mappedBy="b")
	private Collection<EntityC> cEntities = new HashSet<EntityC>();

	public Collection<EntityC> getcEntities() {
		return cEntities;
	}

	public void setcEntities(Collection<EntityC> cEntities) {
		this.cEntities = cEntities;
	}
	
	@ManyToOne
	private EntityA a;

	public EntityA getA() {
		return a;
	}

	public void setA(EntityA a) {
		this.a = a;
	}
	
	
}
