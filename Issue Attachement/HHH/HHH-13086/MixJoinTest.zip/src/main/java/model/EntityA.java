package model;

import java.util.Collection;
import java.util.HashSet;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;


@Entity
public class EntityA extends AbstractEntity {

	public EntityA(int i) {
		super(i);
	}

	/**
	 * SUID.
	 */
	private static final long serialVersionUID = -4914129457137311120L;

	@OneToMany(cascade={CascadeType.ALL},mappedBy="a")
	private Collection<EntityB> bEntities = new HashSet<EntityB>();

	public Collection<EntityB> getbEntities() {
		return bEntities;
	}

	public void setbEntities(Collection<EntityB> bEntities) {
		this.bEntities = bEntities;
	}
}
