package model;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class AbstractEntity implements Serializable {
	
	/**
	 * SUID.
	 */
	private static final long serialVersionUID = 2560924346752615482L;
	
	
	protected AbstractEntity(int i) {
		id = UUID.randomUUID().toString();
		name = this.getClass().getSimpleName().substring(this.getClass().getSimpleName().length()-1)+String.valueOf(i);
	}

	@Id
	private String id;

	private String name;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName()+" [id=" + id + ", name=" + name + "]";
	}
	
}
