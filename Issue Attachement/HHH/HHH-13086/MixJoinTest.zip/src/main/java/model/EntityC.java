package model;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;


@Entity
public class EntityC extends AbstractEntity {

	/**
	 * SUID.
	 */
	private static final long serialVersionUID = -1181121691198011976L;
	
	public EntityC(int i) {
		super(i);
	}
	
	@ManyToOne
	private EntityB b;

	public EntityB getB() {
		return b;
	}

	public void setB(EntityB b) {
		this.b = b;
	}
	
	
}