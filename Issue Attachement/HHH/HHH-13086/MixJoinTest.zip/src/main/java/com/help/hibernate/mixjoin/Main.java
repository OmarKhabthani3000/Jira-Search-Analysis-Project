package com.help.hibernate.mixjoin;

import static javax.persistence.criteria.JoinType.INNER;
import static javax.persistence.criteria.JoinType.LEFT;

import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import model.AbstractEntity;
import model.EntityA;
import model.EntityB;
import model.EntityC;

public class Main {
    // Create an EntityManagerFactory when you start the application.
    private static final EntityManagerFactory ENTITY_MANAGER_FACTORY = Persistence
            .createEntityManagerFactory("JavaHelps");

    public static void main(String[] args) {

        // Create an EntityManager
        EntityManager manager = ENTITY_MANAGER_FACTORY.createEntityManager();
        EntityTransaction transaction = null;

        try {
            // Get a transaction
            transaction = manager.getTransaction();
            // Begin the transaction
            transaction.begin();

            //Build data to test
            buildData(manager);
            
            //Do Test
            doTest(manager);

            // Commit the transaction
            transaction.commit();
        } catch (Exception ex) {
            // If there are any exceptions, roll back the changes
            if (transaction != null) {
                transaction.rollback();
            }
            // Print the Exception
            ex.printStackTrace();
        } finally {
            // Close the EntityManager
            manager.close();
        }
        
        // NEVER FORGET TO CLOSE THE ENTITY_MANAGER_FACTORY
        ENTITY_MANAGER_FACTORY.close();
    }

	private static void buildData(EntityManager manager) {
		
		//A1
		EntityA entityA1 = new EntityA(1);

		EntityB entityB1 = new EntityB(1);
		
		EntityC entityC1 = new EntityC(1);
		EntityC entityC2 = new EntityC(2);
		
		entityA1.getbEntities().add(entityB1);
		entityB1.setA(entityA1);
		entityB1.getcEntities().add(entityC1);
		entityC1.setB(entityB1);
		entityB1.getcEntities().add(entityC2);
		entityC2.setB(entityB1);

		manager.persist(entityA1);

		
		//A2
		EntityA entityA2 = new EntityA(2);

		EntityB entityB2 = new EntityB(2);
		
		EntityC entityC3 = new EntityC(3);
		
		entityA2.getbEntities().add(entityB2);
		entityB2.setA(entityA2);
		entityB2.getcEntities().add(entityC3);
		entityC3.setB(entityB2);

		manager.persist(entityA2);
		
		
		list(manager, EntityA.class);
		list(manager, EntityB.class);
		list(manager, EntityC.class);
		
		String qlString = "Select a.name,b.name,c.name \n\tfrom EntityA a \n\tleft outer join a.bEntities as \n\tb left outer join b.cEntities as c order by a.name,b.name,c.name";
		List<Object[]> resultList = manager.createQuery(qlString).getResultList();
		
		System.out.println("\nEntities was build as \n  '"+qlString+"'\nreturns:"+"\n------------------");
		printJoinResult(resultList);
	}

	private static void printJoinResult(List<Object[]> resultList) {
		System.out.println("A\tB\tC");
		System.out.println("------------------");
		for(Object[] o : resultList){
			for(Object oe : o){
				System.out.print(oe+"\t");
			}
			System.out.println("\n------------------");
		}
	}
	
	
	private static void doTest(EntityManager manager){
		
		/*
		 * I want all EntityA, 
		 * having "eventually" an EntityB (in bEntities),
		 * only if this EntityB has an EntityC named "C1"
		 * 
		 * ==> should A1( + B1 + C1 ) + A2 ( + null  + null )
		 */
		
		CriteriaBuilder cb = manager.getCriteriaBuilder();
		
		CriteriaQuery<Object[]> query = cb.createQuery(Object[].class);
		
		//I want all EntityA
		Root<EntityA> root = query.from(EntityA.class);
		
		//having "eventually" an EntityB (in bEntities)
		Join<EntityA, EntityB> aJoinB_LEFT = root.join("bEntities",LEFT);
		
		//only if this EntityB has an EntityC ...
		Join<EntityB, EntityC> bJoinC_INNER = aJoinB_LEFT.join("cEntities",INNER);
		
		//... named "C1"
		bJoinC_INNER.on(
				cb.equal(
						bJoinC_INNER.get("name"),
						"C1"));
			
		
		// select a.name,b.name,c.name
		query.multiselect(
				root.get("name"),
				aJoinB_LEFT.get("name"),
				bJoinC_INNER.get("name")
		);
		
		/**
		 * Produces this request:
		 * 
		 *     select
			        entitya0_.name as col_0_0_,
			        bentities1_.name as col_1_0_,
			        centities2_.name as col_2_0_ 
			    from
			        EntityA entitya0_ 
			    left outer join
			        EntityB bentities1_ 
						--
						-- next inner join should be "nested" here : before this on
						--
			            on entitya0_.id=bentities1_.a_id 
			    inner join
			        EntityC centities2_ 
			            on bentities1_.id=centities2_.b_id 
			            and (
			                centities2_.name=?
			            )
		 *
		 * But the inner join should be "nested" to the left join
		 * 
		 * before the "on" of the left outer join
		 * 
		 * As this, it aborts the "optional effect" of the LEFT OUTER
		 *
		 */
		
		
		System.out.println("\nselect a.name, b.name, c.name \n\tfrom EntityA as a \n\tLEFT OUTER JOIN a.bEntities as b \n\tINNER JOIN b.cEntities as c ON c.name = 'C1'\n\n=>should return should A1( + B1 + C1 ) & A2 ( + null  + null )\n==>but returns:");
		printJoinResult(manager.createQuery(query).getResultList());
	}


	private static <T extends AbstractEntity> Collection<T> list(
			final EntityManager manager, 
			final Class<T> resultClass) {
		
		final CriteriaBuilder cb = manager.getCriteriaBuilder();
		
		CriteriaQuery<T> qQuery = cb.createQuery(resultClass);
		
		qQuery.from(resultClass);
		
		List<T> resultList = manager.createQuery(qQuery).getResultList();
		
		System.out.println("\nAll "+resultClass.getName()+" :");
		for(T o : resultList){
			System.out.println(o);
		}
		
		return resultList;
	}

}