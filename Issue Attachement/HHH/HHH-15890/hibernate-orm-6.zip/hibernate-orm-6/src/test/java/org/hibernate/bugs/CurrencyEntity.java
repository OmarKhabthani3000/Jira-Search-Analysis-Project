package org.hibernate.bugs;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "MDCULP")
public class CurrencyEntity implements Serializable{

	private static final long serialVersionUID = -1611164827876000264L;
	
	@Id
	@Column(name = "MCCUR", length = 3, nullable = false)
	private String isoCurrencyAlphaCode;
	

	public String getIsoCurrencyAlphaCode() {
		return isoCurrencyAlphaCode;
	}

	public void setIsoCurrencyAlphaCode(String isoCurrencyAlphaCode) {
		this.isoCurrencyAlphaCode = isoCurrencyAlphaCode;
	}

	
	
	
}