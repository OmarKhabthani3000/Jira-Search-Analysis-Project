# Prerequisites
 - docker to setup a DB2 database
 - git to switch between spring boot 2.7.0 and 3.0.0
 - JDK 17
 - maven (3.8+) to compile and run the tests

# Steps to reproduce
## Setup the sample DB2 database
    $ docker run -itd --name db2 --privileged=true -p 50000:50000 -e LICENSE=accept -e DB2INST1_PASSWORD=aaaaaaa -e SAMPLEDB=true ibmcom/db2
    $ docker logs -f db2
Wait for the DB2 sample database to be ready then CTRL+C.

## Test with springboot 2.7.0
    $ git checkout springboot-2.7.0
    $ mvn test
    [...]
    Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
    [...]

## Test with springboot 3.0.0
    $ git checkout springboot-3.0.0
    $ mvn test
    [ERROR] testFindAll  Time elapsed: 0.204 s  <<< FAILURE!
    org.opentest4j.AssertionFailedError: Unexpected exception thrown: org.springframework.dao.InvalidDataAccessResourceUsageException: JDBC exception executing SQL [select * from (select e1_0.empno c0,row_number() over() rn from employee e1_0) r_0_ where  order by r_0_.rn]; SQL [n/a]
    at nc.bci.SpringbootDb2ApplicationTests.testFindAll(SpringbootDb2ApplicationTests.java:16)
    Caused by: org.springframework.dao.InvalidDataAccessResourceUsageException: JDBC exception executing SQL [select * from (select e1_0.empno c0,row_number() over() rn from employee e1_0) r_0_ where  order by r_0_.rn]; SQL [n/a]
    at nc.bci.SpringbootDb2ApplicationTests.lambda$testFindAll$0(SpringbootDb2ApplicationTests.java:16)
    at nc.bci.SpringbootDb2ApplicationTests.testFindAll(SpringbootDb2ApplicationTests.java:16)
    Caused by: org.hibernate.exception.SQLGrammarException: JDBC exception executing SQL [select * from (select e1_0.empno c0,row_number() over() rn from employee e1_0) r_0_ where  order by r_0_.rn]
    at nc.bci.SpringbootDb2ApplicationTests.lambda$testFindAll$0(SpringbootDb2ApplicationTests.java:16)
    at nc.bci.SpringbootDb2ApplicationTests.testFindAll(SpringbootDb2ApplicationTests.java:16)
    Caused by: com.ibm.db2.jcc.am.SqlSyntaxErrorException: DB2 SQL Error: SQLCODE=-104, SQLSTATE=42601, SQLERRMC=by;0) r_0_ where  order;ORDER, DRIVER=4.32.28
    at nc.bci.SpringbootDb2ApplicationTests.lambda$testFindAll$0(SpringbootDb2ApplicationTests.java:16)
    at nc.bci.SpringbootDb2ApplicationTests.testFindAll(SpringbootDb2ApplicationTests.java:16)
    