package nc.bci;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDb2Application {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootDb2Application.class, args);
    }

}
