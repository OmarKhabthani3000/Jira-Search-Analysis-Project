package hibernate.bug.model;

public enum Permission {

    READ,
    WRITE,
    EXECUTE;
}
