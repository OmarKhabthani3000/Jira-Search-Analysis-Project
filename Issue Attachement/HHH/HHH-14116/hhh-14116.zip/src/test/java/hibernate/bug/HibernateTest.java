package hibernate.bug;

import hibernate.bug.model.Group;
import hibernate.bug.model.User;
import java.util.List;
import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Subgraph;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test1() {
        EntityManager em = emf.createEntityManager();
        EntityGraph<User> userGraph = em.createEntityGraph(User.class);
        Subgraph<Object> groupGraph = userGraph.addSubgraph("groups");
        groupGraph.addAttributeNodes("permissions", "tenant");
        
        List<User> l = em.createQuery(
                "SELECT u FROM User u where u.id = ?1")
                .setHint("javax.persistence.loadgraph", userGraph)
                .setParameter(1, 1L)
                .getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
    
    @Test
    public void test2() {
        EntityManager em = emf.createEntityManager();
        
        List<Group> l = em.createQuery(
                "SELECT g FROM User u JOIN u.groups g JOIN FETCH g.permissions JOIN FETCH g.tenant where u.id = ?1")
                .setParameter(1, 1L)
                .getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
    
    @Test
    public void test3() {
        EntityManager em = emf.createEntityManager();
        
        List<User> l = em.createQuery(
                "SELECT u FROM User u JOIN u.groups g JOIN FETCH g.permissions JOIN FETCH g.tenant where u.id = ?1")
                .setParameter(1, 1L)
                .getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
}
