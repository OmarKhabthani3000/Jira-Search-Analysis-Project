package hibernate.bug.model;


import java.util.Set;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "usr_tbl")
public class User {

    @Id
    @GeneratedValue
    private Long id;
    private String name;
    @ManyToMany
    private Set<Group> groups;
    
    @Enumerated(value = EnumType.STRING)
    @ElementCollection
    private Set<Permission> permissions;
    
}
