package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.bugs.entities.AnEntity;
import org.hibernate.bugs.entities.ChildEntity;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * This template demonstrates how to develop a standalone test case for
 * Hibernate ORM. Although this is perfectly acceptable as a reproducer, usage
 * of ORMUnitTestCase is preferred!
 */
public class HHH9789StandaloneTestCase {

	private static SessionFactory sf;

	private static long id;

	@BeforeClass
	public static void setup() {
		StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
				// Add in any settings that are specific to your test. See
				// resources/hibernate.properties for the defaults.
				.applySetting("hibernate.show_sql", "false").applySetting("hibernate.format_sql", "true")
				.applySetting("hibernate.hbm2ddl.auto", "create-drop");

		Metadata metadata = new MetadataSources(srb.build())
				// Add your entities here.
				.addAnnotatedClass(AnEntity.class).addAnnotatedClass(ChildEntity.class).buildMetadata();

		sf = metadata.buildSessionFactory();

		//
		createEntity();
	}

	/**
	 * Creates the entities for the test
	 * 
	 * @return the id for AnEntity created
	 */
	private static long createEntity() {

		Session session = sf.openSession();
		session.beginTransaction();

		AnEntity ent = new AnEntity();
		ent.getChildren2().add(new ChildEntity(50));
		ent.getChildren2().add(new ChildEntity(500));
		ent.getChildren2().add(new ChildEntity(50));
		ent.getChildren2().add(new ChildEntity(500));

		session.persist(ent);
		id = ent.getId();

		session.getTransaction().commit();
		session.close();

		return id;
	}

	// Add your tests, using standard JUnit.

	  @Test
	  public void getCollectionSizeWihNotInitialatedProxy() {
	    Session session = sf.openSession();
	    session.beginTransaction();

	    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

	    int size = ent.getChildren2().size();

	    System.out.println("Collection size without previous proxy initialization: " + size + " -> must be 4");

	    session.getTransaction().commit();
	    session.close();
	    Assert.assertEquals(size, 4);
	  }
	  
	  @Test
	  public void getCollectionIsEmptyWihNotInitialatedProxy() {
	    Session session = sf.openSession();
	    session.beginTransaction();

	    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

	    boolean empty = ent.getChildren2().isEmpty();

	    System.out.println("Collection isEmpty with previous proxy initialization: " + empty
	        + " -> must be false");

	    session.getTransaction().commit();
	    session.close();
	    Assert.assertEquals(empty, false);
	  }	  

	  @Test
	  public void getCollectionSizeWihNotInitialatedProxyEnablingFilter() {
	    Session session = sf.openSession();
	    session.beginTransaction();
	    session.enableFilter("cantOver100");

	    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

	    int size = ent.getChildren2().size();

	    System.out.println("Collection size without previous proxy initialization enabling filter: " + size
	        + " -> must be 2");

	    session.getTransaction().commit();
	    session.close();
	    Assert.assertEquals(size, 2);
	  }
	  
	  @Test
	  public void getCollectionIsEmptyWihNotInitialatedProxyEnablingFilter() {
	    Session session = sf.openSession();
	    session.beginTransaction();
	    session.enableFilter("cantOver1000");

	    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

	    boolean empty = ent.getChildren2().isEmpty();

	    System.out.println("Collection isEmpty with previous proxy initialization enabling filter: " + empty
	        + " -> must be true");

	    session.getTransaction().commit();
	    session.close();
	    Assert.assertEquals(empty, true);
	  }
	  

	  @Test
	  public void getCollectionSizeWihInitialatedProxy() {
	    Session session = sf.openSession();
	    session.beginTransaction();

	    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

	    // forcing collection initialization
	    ent.getChildren2().get(0);

	    int size = ent.getChildren2().size();

	    System.out.println("Collection size with previous proxy initialization: " + size + " -> must be 4");

	    session.getTransaction().commit();
	    session.close();
	    Assert.assertEquals(size, 4);
	  }

	  @Test
	  public void getCollectionIsEmptyWihInitialatedProxy() {
	    Session session = sf.openSession();
	    session.beginTransaction();

	    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

	    // forcing collection initialization
	    ent.getChildren2().get(0);

	    boolean empty = ent.getChildren2().isEmpty();

	    System.out.println("Collection isEmpty with previous proxy initialization: " + empty
	        + " -> must be false");

	    session.getTransaction().commit();
	    session.close();
	    Assert.assertEquals(empty, false);
	  }
	  

	  @Test
	  public void getCollectionSizeWihInitialatedProxyEnablingFilter() {
	    Session session = sf.openSession();
	    session.beginTransaction();
	    session.enableFilter("cantOver100");

	    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

	    // forcing collection initialization
	    ent.getChildren2().get(0);

	    int size = ent.getChildren2().size();

	    System.out.println("Collection size with previous proxy initialization enabling filter: " + size
	        + " -> must be 2");

	    session.getTransaction().commit();
	    session.close();
	    Assert.assertEquals(size, 2);
	  }
	  
	  @Test
	  public void getCollectionIsEmptyWihInitialatedProxyEnablingFilter() {
	    Session session = sf.openSession();
	    session.beginTransaction();
	    session.enableFilter("cantOver100");

	    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

	    // forcing collection initialization
	    boolean empty = ent.getChildren2().isEmpty();

	    System.out.println("Collection isEmpry with previous proxy initialization enabling filter: " + empty + " -> must be false");

	    session.getTransaction().commit();
	    session.close();
	    Assert.assertEquals(empty, false);
	  }
	  


}
