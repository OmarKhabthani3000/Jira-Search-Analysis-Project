/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.bugs.entities.AnEntity;
import org.hibernate.bugs.entities.ChildEntity;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Assert;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM,
 * using its built-in unit test framework. Although ORMStandaloneTestCase is
 * perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing
 * your reproducer using this method simplifies the process.
 *
 * What's even better? Fork hibernate-orm itself, add your test case directly to
 * a module's unit tests, then submit it as a PR!
 */
public class HHH9789UnitTestCase extends BaseCoreFunctionalTestCase {

	private static long id;

	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] { AnEntity.class, ChildEntity.class };
	}

	// Add in any settings that are specific to your test. See
	// resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure(configuration);

		configuration.setProperty(AvailableSettings.SHOW_SQL, "false");
		configuration.setProperty(AvailableSettings.HBM2DDL_AUTO, "create-drop");

	}

	@Override
	protected void afterSessionFactoryBuilt() {
		// TODO Auto-generated method stub
		super.afterSessionFactoryBuilt();
		id = this.createEntity();
	}

	/**
	 * Creates the entities for the test
	 * 
	 * @return the id for AnEntity created
	 */
	private long createEntity() {

		Session session = openSession();
		session.beginTransaction();

		AnEntity ent = new AnEntity();
		ent.getChildren2().add(new ChildEntity(50));
		ent.getChildren2().add(new ChildEntity(500));
		ent.getChildren2().add(new ChildEntity(50));
		ent.getChildren2().add(new ChildEntity(500));

		session.persist(ent);
		id = ent.getId();

		session.getTransaction().commit();
		session.close();

		return id;
	}

	// Add your tests, using standard JUnit.
	@Test
	public void getCollectionSizeWihNotInitialatedProxy() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();

		AnEntity ent = (AnEntity) s.get(AnEntity.class, id);

		int size = ent.getChildren2().size();

		System.out.println("Collection size without previous proxy initialization: " + size + " -> must be 4");

		tx.commit();
		s.close();
		Assert.assertEquals(size, 4);
	}

	@Test
	public void getCollectionIsEmptyWihNotInitialatedProxy() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();

		AnEntity ent = (AnEntity) s.get(AnEntity.class, id);

		boolean empty = ent.getChildren2().isEmpty();

		System.out.println("Collection isEmpty with previous proxy initialization: " + empty + " -> must be false");

		tx.commit();
		s.close();
		Assert.assertEquals(empty, false);
	}

	@Test
	public void getCollectionSizeWihNotInitialatedProxyEnablingFilter() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		s.enableFilter("cantOver100");

		AnEntity ent = (AnEntity) s.get(AnEntity.class, id);

		int size = ent.getChildren2().size();

		System.out.println(
				"Collection size without previous proxy initialization enabling filter: " + size + " -> must be 2");

		tx.commit();
		s.close();

		Assert.assertEquals(size, 2);
	}

	@Test
	public void getCollectionIsEmptyWihNotInitialatedProxyEnablingFilter() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		s.enableFilter("cantOver1000");

		AnEntity ent = (AnEntity) s.get(AnEntity.class, id);

		boolean empty = ent.getChildren2().isEmpty();

		System.out.println(
				"Collection isEmpty with previous proxy initialization enabling filter: " + empty + " -> must be true");

		tx.commit();
		s.close();

		Assert.assertEquals(empty, true);
	}

	@Test
	public void getCollectionSizeWihInitialatedProxy() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();

		AnEntity ent = (AnEntity) s.get(AnEntity.class, id);

		// forcing collection initialization
		ent.getChildren2().get(0);

		int size = ent.getChildren2().size();

		System.out.println("Collection size with previous proxy initialization: " + size + " -> must be 4");

		tx.commit();
		s.close();

		Assert.assertEquals(size, 4);
	}

	@Test
	public void getCollectionIsEmptyWihInitialatedProxy() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();

		AnEntity ent = (AnEntity) s.get(AnEntity.class, id);

		// forcing collection initialization
		ent.getChildren2().get(0);

		boolean empty = ent.getChildren2().isEmpty();

		System.out.println("Collection isEmpty with previous proxy initialization: " + empty + " -> must be false");

		tx.commit();
		s.close();

		Assert.assertEquals(empty, false);
	}

	@Test
	public void getCollectionSizeWihInitialatedProxyEnablingFilter() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		s.enableFilter("cantOver100");

		AnEntity ent = (AnEntity) s.get(AnEntity.class, id);

		// forcing collection initialization
		ent.getChildren2().get(0);

		int size = ent.getChildren2().size();

		System.out.println(
				"Collection size with previous proxy initialization enabling filter: " + size + " -> must be 2");

		tx.commit();
		s.close();

		Assert.assertEquals(size, 2);
	}

	@Test
	public void getCollectionIsEmptyWihInitialatedProxyEnablingFilter() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		s.enableFilter("cantOver100");

		AnEntity ent = (AnEntity) s.get(AnEntity.class, id);

		// forcing collection initialization
		boolean empty = ent.getChildren2().isEmpty();

		System.out.println("Collection isEmpry with previous proxy initialization enabling filter: " + empty
				+ " -> must be false");

		tx.commit();
		s.close();

		Assert.assertEquals(empty, false);
	}

}
