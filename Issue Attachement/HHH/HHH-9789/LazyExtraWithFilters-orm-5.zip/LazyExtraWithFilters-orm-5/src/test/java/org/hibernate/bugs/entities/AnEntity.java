package org.hibernate.bugs.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.Filters;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

@Entity
public class AnEntity {

  @Id
  private long id;

  @OneToMany(cascade = CascadeType.ALL)
  @JoinColumn(name = "AN_ENTITY_ID")
  @LazyCollection(LazyCollectionOption.EXTRA)
  @Filters(value = {
      @Filter(name = "cantOver100"), @Filter(name = "cantOver1000")
  })
  private List<ChildEntity> children = new ArrayList<ChildEntity>();

  public AnEntity() {

  }

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public List<ChildEntity> getChildren2() {
    return children;
  }

  public void setChildren2(List<ChildEntity> children2) {
    this.children = children2;
  }

}
