package org.hibernate.test;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class HibernateCore43LazyExtraAndFilterTest {

  private static EntityManagerFactory emf;

  private static long id;

  @BeforeClass
  public static void setUp() {
    emf = Persistence.createEntityManagerFactory("LazyExtraWithFilters");
    id = createEntity();
  }

  @AfterClass
  public static void tearDown() {
    emf.close();
  }

  private static long createEntity() {

    Session session = emf.createEntityManager().unwrap(Session.class);
    session.beginTransaction();

    AnEntity ent = new AnEntity();
    ent.getChildren2().add(new ChildEntity(50));
    ent.getChildren2().add(new ChildEntity(500));
    ent.getChildren2().add(new ChildEntity(50));
    ent.getChildren2().add(new ChildEntity(500));

    session.persist(ent);
    id = ent.getId();

    session.getTransaction().commit();
    session.close();

    return id;
  }

  @Test
  public void getCollectionSizeWihNotInitialatedProxy() {
    Session session = emf.createEntityManager().unwrap(Session.class);
    session.beginTransaction();

    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

    int size = ent.getChildren2().size();

    System.out.println("Collection size without previous proxy initialization: " + size + " -> must be 4");

    session.getTransaction().commit();
    session.close();
    Assert.assertEquals(size, 4);
  }

  @Test
  public void getCollectionSizeWihNotInitialatedProxyEnablingFilter() {
    Session session = emf.createEntityManager().unwrap(Session.class);
    session.beginTransaction();
    session.enableFilter("cantOver100");

    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

    int size = ent.getChildren2().size();

    System.out.println("Collection size without previous proxy initialization enabling filter: " + size
        + " -> must be 2");

    session.getTransaction().commit();
    session.close();
    Assert.assertEquals(size, 2);
  }

  @Test
  public void getCollectionSizeWihInitialatedProxy() {
    Session session = emf.createEntityManager().unwrap(Session.class);
    session.beginTransaction();

    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

    // forcing collection initialization
    ent.getChildren2().get(0);

    int size = ent.getChildren2().size();

    System.out.println("Collection size with previous proxy initialization: " + size + " -> must be 4");

    session.getTransaction().commit();
    session.close();
    Assert.assertEquals(size, 4);
  }

  @Test
  public void getCollectionSizeWihInitialatedProxyEnablingFilter() {
    Session session = emf.createEntityManager().unwrap(Session.class);
    session.beginTransaction();
    session.enableFilter("cantOver100");

    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

    // forcing collection initialization
    ent.getChildren2().get(0);

    int size = ent.getChildren2().size();

    System.out.println("Collection size with previous proxy initialization enabling filter: " + size
        + " -> must be 2");

    session.getTransaction().commit();
    session.close();
    Assert.assertEquals(size, 2);
  }

  @Test
  public void getCollectionIsEmptyWihInitialatedProxy() {
    Session session = emf.createEntityManager().unwrap(Session.class);
    session.beginTransaction();

    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

    // forcing collection initialization
    ent.getChildren2().get(0);

    boolean empty = ent.getChildren2().isEmpty();

    System.out.println("Collection isEmpty with previous proxy initialization: " + empty
        + " -> must be false");

    session.getTransaction().commit();
    session.close();
    Assert.assertEquals(empty, false);
  }

  @Test
  public void getCollectionIsEmptyWihNotInitialatedProxy() {
    Session session = emf.createEntityManager().unwrap(Session.class);
    session.beginTransaction();

    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

    boolean empty = ent.getChildren2().isEmpty();

    System.out.println("Collection isEmpty with previous proxy initialization: " + empty
        + " -> must be false");

    session.getTransaction().commit();
    session.close();
    Assert.assertEquals(empty, false);
  }

  @Test
  public void getCollectionIsEmptyWihNotInitialatedProxyEnablingFilter() {
    Session session = emf.createEntityManager().unwrap(Session.class);
    session.beginTransaction();
    session.enableFilter("cantOver1000");

    AnEntity ent = (AnEntity) session.get(AnEntity.class, id);

    boolean empty = ent.getChildren2().isEmpty();

    System.out.println("Collection isEmpty with previous proxy initialization enabling filter: " + empty
        + " -> must be true");

    session.getTransaction().commit();
    session.close();
    Assert.assertEquals(empty, true);
  }
}
