package org.hibernate.test;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.FilterDefs;

@FilterDefs(value = {
    @FilterDef(name = "cantOver100", defaultCondition = "cant > 100"),
    @FilterDef(name = "cantOver1000", defaultCondition = "cant > 1000")
})
@Entity
@Table(name = "CHILD2")
public class ChildEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private long id;

  private int cant;

  public ChildEntity() {

  }

  public ChildEntity(int cant) {
    this.cant = cant;
  }

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public int getCant() {
    return cant;
  }

  public void setCant(int cant) {
    this.cant = cant;
  }

}
