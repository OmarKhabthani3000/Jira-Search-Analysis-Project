package org.hibernate.HHH4109;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestHHH4109 {

	private static SessionFactory factory;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Session session = getSession();
		Transaction transaction = session.beginTransaction();
		session.enableFilter("softDeletedFilter").setParameter("deleted", false);

		try {
			initData(session);
			String hql = "select u, b.state as buddyState from User as u left join u.buddiesForUserB as b with b.userByUserA.id = :p_userAid where u.anotherField = :p_anotherField";
			Query query = session.createQuery(hql);
			query.setParameter("p_userAid", new Integer(1));
			query.setParameter("p_anotherField", "anotherField");
			List result = query.list();
			transaction.commit();
		} finally {
			session.close();
		}
	}

	private static void initData(Session session) {
		User fry = new User(new Integer(1), "fry", false, "anotherField");
		User bender = new User(new Integer(2), "bender", false, "anotherField");
		User me = new User(new Integer(3), "me", false, "notreallyanotherField");
		session.persist(fry);
		session.persist(bender);
		session.persist(me);
		Buddy buddyFryBender = new Buddy(new Integer(4), fry, bender, false, "active");
		Buddy buddyFryMe = new Buddy(new Integer(5), fry, me, false, "active");
		session.persist(buddyFryBender);
		session.persist(buddyFryMe);
	}

	public static synchronized Session getSession() {

		if (factory == null) {
			factory = new Configuration().configure("hibernate.cfg.xml")
					.buildSessionFactory();
		}

		return factory.openSession();
	}

}
