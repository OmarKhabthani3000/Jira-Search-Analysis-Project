
package ejemplo08;

public enum TipoFuncionario {
    Carrera,
    Practicas,
    Interino
}
