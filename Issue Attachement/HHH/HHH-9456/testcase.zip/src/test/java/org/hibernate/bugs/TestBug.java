package org.hibernate.bugs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.HashMap;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import org.hibernate.bugs.model.MyAuditedEntity;
import org.hibernate.bugs.model.MyEntity;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestBug {

    private EntityManager em;

    @Before
    public void setup() {

        em = Persistence.createEntityManagerFactory("domain").createEntityManager();
    }

    @After
    public void teardown() {
        em.close();
    }
    
    /*
     * This test demonstrates that when a map entry with a 
     * null value is added, it is never added to the database
     * and thus is silently "lost".
     */
    @Test
    public void testNullMapValue() {
    	em.getTransaction().begin();
    	MyEntity myEntity = new MyEntity();
    	myEntity.setEmbeddedMap(new HashMap<String, String>());
    	myEntity.getEmbeddedMap().put("key1", "value1");
    	myEntity.getEmbeddedMap().put("key2", null);
    	
        em.persist(myEntity);
        
        em.flush();
        // this succeeds, the map has 2 elements
        assertEquals("after flush", 2, myEntity.getEmbeddedMap().size());
   
        em.refresh(myEntity);
        // after re-querying from the DB, we have silently lost 1 element
		assertEquals("after refresh", 2, myEntity.getEmbeddedMap().size());
		
		em.getTransaction().commit();
		
    }
    
    /*
     * This test demonstrates that the "lost" row
     * re-appears when the transaction is committed, for updating the audit table.  Note that
     * if the underlying issue were fixed, this test would
     * still fail because of the constraint violation.  In a more
     * realistic use case, if we need auditing, we would probably want to put a constraint
     * on the map column itself to ensure that it is not null.
     */
    @Test
    public void testAuditedEntity() {
    	em.getTransaction().begin();
    	MyAuditedEntity myEntity = new MyAuditedEntity();
    	myEntity.setEmbeddedMap(new HashMap<String, String>());
    	myEntity.getEmbeddedMap().put("key1", "value1");
    	myEntity.getEmbeddedMap().put("key2", null);
    	
        em.persist(myEntity);  
        
        try {
        	// on commit the audit tables are updated
        	// at this point we find the "lost" null value
        	// row suddenly re-appears and causes an error!
        	em.getTransaction().commit();
        }
        catch (PersistenceException e) {
        	fail("Persistence Exception : " + e.getCause().getCause().getCause().getMessage());
        }
		
    }
    

}
