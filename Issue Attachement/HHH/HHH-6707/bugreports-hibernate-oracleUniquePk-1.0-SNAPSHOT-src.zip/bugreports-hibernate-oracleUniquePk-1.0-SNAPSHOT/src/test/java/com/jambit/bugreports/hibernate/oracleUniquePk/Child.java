package com.jambit.bugreports.hibernate.oracleUniquePk;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Child implements Serializable {
	
	@Id
	// A @OneToOne here results in the following DDL: create table child ([...] primary key
	// (parent), unique (parent)).
	// Oracle does not like a unique constraint and a PK on the same column (results in ORA-02261)
	@OneToOne(optional = false)
	private Parent parent;

	public void setParent(Parent parent) {
		this.parent = parent;
	}

}
