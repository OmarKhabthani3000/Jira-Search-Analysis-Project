package com.jambit.bugreports.hibernate.oracleUniquePk;

import static org.junit.Assert.assertTrue;

import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.junit.Test;

public class OracleUniquePkTest {

	@Test
	public void testSchemaCreation() throws Exception {
		Configuration cfg = new Configuration()
			.addAnnotatedClass(Parent.class)
			.addAnnotatedClass(Child.class)
			.setProperty("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect")
			.setProperty("hibernate.connection.driver_class", "oracle.jdbc.driver.OracleDriver");
		// .setProperty("hibernate.connection.url", "jdbc:oracle:thin:@<SERVER>:<DB>")
		// .setProperty("hibernate.connection.username", "<USERNAM>");
		// .setProperty("hibernate.connection.password", "<PASSWORD>");

		SchemaExport schemaExport = new SchemaExport(cfg).setHaltOnError(true).setFormat(true);
		schemaExport.execute(true, true, false, true);

		assertTrue("Exceptions " + schemaExport.getExceptions() + " occurred", schemaExport.getExceptions().isEmpty());
	}

}
