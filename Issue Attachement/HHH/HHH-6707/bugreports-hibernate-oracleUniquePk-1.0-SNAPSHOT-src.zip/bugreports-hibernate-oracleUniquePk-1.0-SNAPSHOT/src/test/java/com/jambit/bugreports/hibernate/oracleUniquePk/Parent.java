package com.jambit.bugreports.hibernate.oracleUniquePk;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Parent {

	@Id
	Long id;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "parent")
	Child child;

	void setChild(Child child) {
		this.child = child;
		child.setParent(this);
	}

}
