package testapp;

import junit.framework.Test;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.classic.Session;
import org.hibernate.dialect.Dialect;
import org.hibernate.dialect.H2Dialect;
import org.hibernate.jdbc.Work;
import org.hibernate.testing.junit.functional.DatabaseSpecificFunctionalTestCase;
import org.hibernate.testing.junit.functional.FunctionalTestClassTestSuite;
import org.hibernate.tool.hbm2ddl.DatabaseMetadata;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.hibernate.tool.hbm2ddl.SchemaUpdate;
import org.hibernate.tool.hbm2ddl.TableMetadata;

import java.sql.Connection;
import java.sql.SQLException;

public class SchemaUpdateTest extends DatabaseSpecificFunctionalTestCase
{
    public SchemaUpdateTest( String testName )
    {
        super( testName );
    }

    public static Test suite()
    {
		return new FunctionalTestClassTestSuite( SchemaUpdateTest.class );
    }

    public boolean appliesTo(Dialect dialect) {
        return dialect instanceof H2Dialect;
    }



    public void testSchemaUpdateCreatesForeignKeysInNonDefaultSchema()
    {
        Session session = openSession();
        session.createSQLQuery("create schema test_schema authorization sa").executeUpdate();

		Configuration cfg1 = new Configuration();
        cfg1.setProperty(Environment.DEFAULT_SCHEMA, "test_schema");
        cfg1.addResource("testapp/Version1.hbm.xml");


        SchemaExport se = new SchemaExport(cfg1);
        se.create(true, true);

        Configuration cfg2 = new Configuration();
        cfg2.setProperty(Environment.DEFAULT_SCHEMA, "test_schema");
        cfg2.addResource("testapp/Version2.hbm.xml");
        
        SchemaUpdate su = new SchemaUpdate(cfg2);
        su.execute(true, true);

        session.doWork(new Work() {
            public void execute(Connection connection) throws SQLException {
                DatabaseMetadata databaseMetadata = new DatabaseMetadata(connection, getDialect());
                TableMetadata metadata = databaseMetadata.getTableMetadata("version1", "test_schema", null, false);
                assertNotNull("Foreign key is not created by SchemaUpdate",
                        metadata.getForeignKeyMetadata("fk_parent"));
            }
        });

        session.close();
    }

    public String[] getMappings() {
        return new String[] {"Version2.hbm.xml"};
    }

    @Override
    public String getBaseForMappings() {
        return "testapp/";
    }
}
