package testapp;

/**
 * @author vklyushnikov
 * @since 18.08.2010 18:13:41
 */
public class Parent {
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
