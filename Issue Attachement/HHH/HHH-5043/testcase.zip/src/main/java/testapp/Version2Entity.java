package testapp;

/**
 * @author vklyushnikov
 * @since 13.08.2010 19:17:22
 */
public class Version2Entity {
    private int id;
    private Parent parent;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Parent getParent() {
        return parent;
    }

    public void setParent(Parent parent) {
        this.parent = parent;
    }
}
