package testapp;

/**
 * @author vklyushnikov
 * @since 13.08.2010 19:17:22
 */
public class Version1Entity {
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
