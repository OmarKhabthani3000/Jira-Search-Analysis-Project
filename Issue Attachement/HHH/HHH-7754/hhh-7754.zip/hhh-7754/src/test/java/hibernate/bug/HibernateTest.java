package hibernate.bug;

import hibernate.bug.model.EntitySubclass;
import hibernate.bug.model.EntitySuperClass;
import hibernate.bug.model.EntityWithNoInheritance;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {

    private EntityManagerFactory emf;

    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");

        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        // Create one of each entity type
        EntityWithNoInheritance entityNoInheritance = new EntityWithNoInheritance();
        em.persist(entityNoInheritance);

        EntitySuperClass entitySuper = new EntitySuperClass();
        em.persist(entitySuper);

        EntitySubclass entitySub = new EntitySubclass();
        em.persist(entitySub);

        em.flush();
        tx.commit();
        em.close();
    }

    @Test
    public void testTypeForNoInheritance() {
        EntityManager em = emf.createEntityManager();

        List<EntityWithNoInheritance> results = em.createQuery("FROM EntityWithNoInheritance e WHERE TYPE(e) = EntityWithNoInheritance", EntityWithNoInheritance.class).getResultList();

        assertTrue("Expected EntityWithNoInheritance only", results.size() == 1);
    }

    @Test
    public void testTypeForSubAndSuper() {
        EntityManager em = emf.createEntityManager();
        
        List<EntitySuperClass> results = em.createQuery("FROM EntitySuperClass e where TYPE(e) = EntitySuperClass", EntitySuperClass.class).getResultList();

        assertTrue("Expected EntitySubclass only", results.size() == 1);
    }

    @Test
    public void testTypeInSelect() {
        EntityManager em = emf.createEntityManager();

        List<Class> results = em.createQuery("SELECT TYPE(e) FROM EntityWithNoInheritance e", Class.class).getResultList();

        assertTrue("Expected class type for EntityWithNoInheritance", results.size() == 1);
    }
}
