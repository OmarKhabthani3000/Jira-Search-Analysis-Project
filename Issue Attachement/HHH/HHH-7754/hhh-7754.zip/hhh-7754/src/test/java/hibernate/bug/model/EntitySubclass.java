package hibernate.bug.model;

import javax.persistence.Entity;

@Entity
public class EntitySubclass extends EntitySuperClass {

}
