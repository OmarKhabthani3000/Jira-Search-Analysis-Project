package org.example.jpatypetest.entities;

import javax.persistence.Entity;

@Entity
public class EntitySubclass extends EntitySuperClass {

}
