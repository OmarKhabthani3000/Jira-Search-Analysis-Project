package org.example.jpatypetest.tests;

import java.util.List;

import org.example.jpatypetest.entities.EntitySubclass;
import org.example.jpatypetest.entities.EntitySuperClass;
import org.example.jpatypetest.entities.EntityWithNoInheritance;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.*;

import static org.junit.Assert.*;

public class JpaTypeTestCase {

	private static EntityManagerFactory emf = null;
	
	@BeforeClass
	public static void setup() {
		
		emf = Persistence.createEntityManagerFactory("pu");
		
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		// Create one of each entity type
		EntityWithNoInheritance entityNoInheritance = new EntityWithNoInheritance();
		em.persist(entityNoInheritance);
		
		EntitySuperClass entitySuper = new EntitySuperClass();
		em.persist(entitySuper);
		
		EntitySubclass entitySub = new EntitySubclass();
		em.persist(entitySub);
		em.getTransaction().commit();
	}
	
	@Test
	public void testTypeForNoInheritance() {
		
		EntityManager em = emf.createEntityManager();
		
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<EntityWithNoInheritance> query = builder.createQuery(EntityWithNoInheritance.class);
		Root<EntityWithNoInheritance> from = query.from(EntityWithNoInheritance.class);
		query.where(builder.equal(from.type(), EntityWithNoInheritance.class));
		
		List<EntityWithNoInheritance> results = em.createQuery(query).getResultList();
		
		assertTrue("Expected EntityWithNoInheritance only", results.size() == 1);
	}
	
	@Test
	public void testTypeForSubAndSuper() {
		
		EntityManager em = emf.createEntityManager();
		
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<EntitySuperClass> query = builder.createQuery(EntitySuperClass.class);
		Root<EntitySuperClass> from = query.from(EntitySuperClass.class);
		query.where(builder.equal(from.type(), EntitySubclass.class));
		
		List<EntitySuperClass> results = em.createQuery(query).getResultList();
		
		assertTrue("Expected EntitySubclass only", results.size() == 1);
	}

	@Test
	public void testTypeInSelect() {
		
		EntityManager em = emf.createEntityManager();
		
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Class> query = builder.createQuery(Class.class);
		Root<EntityWithNoInheritance> from = query.from(EntityWithNoInheritance.class);
		query.select(from.type());
		
		List<Class> results = em.createQuery(query).getResultList();
		
		assertTrue("Expected class type for EntityWithNoInheritance", results.size() == 1);
	}
}
