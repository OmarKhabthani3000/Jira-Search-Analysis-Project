package org.hibernate.bugs;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Child {

    @Id
    @GeneratedValue
    private Long id;
    
    /** Uni-directional. Only mapped child side. */
    @ManyToOne(optional = false)
    @JoinColumn(name = "parent_id", nullable = false, updatable = false)
    private Parent parent;

    @OneToMany(cascade = { CascadeType.ALL }, orphanRemoval = true)
    @JoinColumn(name = "item_id", nullable = false)
    private Set<Item> items = new HashSet<>();
    
    @Column(name="some_enum")
    private TimeUnit someEnum = TimeUnit.DAYS;
    
    public Child() {
    }
    
    public Child(Parent parent) {
		this.parent = parent;
	}
    
    public Child(Parent parent, List<Item> items) {
		this.parent = parent;
		this.items.addAll(items);
	}
    
    public Parent getParent() {
		return parent;
	}
    
    public Set<Item> getItems() {
		return items;
	}
    
    public Long getId() {
		return id;
	}
}
