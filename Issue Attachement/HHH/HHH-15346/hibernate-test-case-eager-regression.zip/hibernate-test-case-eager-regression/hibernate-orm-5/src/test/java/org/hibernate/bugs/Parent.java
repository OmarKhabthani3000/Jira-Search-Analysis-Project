package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Parent {

	@Id
	@GeneratedValue
	private Long id;
	
	@Column(name="field1")
	private String someField;

	public Parent() {
	}

	public Parent(String someField) {
		this.someField = someField;
	}

	public String getSomeField() {
		return someField;
	}

	public Long getId() {
		return id;
	}
	
}
