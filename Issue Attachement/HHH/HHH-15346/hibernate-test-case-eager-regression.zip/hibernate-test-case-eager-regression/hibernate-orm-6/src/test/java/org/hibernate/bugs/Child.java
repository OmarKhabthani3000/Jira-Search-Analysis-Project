package org.hibernate.bugs;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Child {

    @Id
    @GeneratedValue
    private Long id;
    
    /** Uni-directional. Only mapped child side. */
    @ManyToOne(optional = false)
    @JoinColumn(name = "parent_id", nullable = false, updatable = false)
    private Parent parent;

    @OneToMany(cascade = { CascadeType.ALL }, orphanRemoval = true)
    @JoinColumn(name = "item_id", nullable = false)
    private Set<Item> items = new HashSet<>();
    
    public Child() {
    }
    
    public Child(Parent parent) {
		this.parent = parent;
	}
    
    public Child(Parent parent, List<Item> items) {
		this.parent = parent;
		this.items.addAll(items);
	}
    
    public Parent getParent() {
		return parent;
	}
    
    public Set<Item> getItems() {
		return items;
	}
    
    public Long getId() {
		return id;
	}
}
