package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Parent {
	@Id
	@GeneratedValue
	private Long id;

	private String someField;

	public Parent() {
	}

	public Parent(String someField) {
		this.someField = someField;
	}

	public String getSomeField() {
		return someField;
	}

	public Long getId() {
		return id;
	}
	
}
