package org.hibernate.bugs;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM,
 * using the Java Persistence API.
 */
public class JPAUnitTestCase {


	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		Parent parent = new Parent("a");
		entityManager.persist(parent);
		Item it1 = new Item();
		Item it2 = new Item();
		entityManager.persist(new Child(parent, List.of(it1, it2)));
		entityManager.persist(new Child(parent, List.of(it1, it2)));

		entityManager.flush();
		entityManager.clear();
		
		List<Child> children = entityManager
				.createQuery("select c from Child as c where c.parent.someField=:someField", Child.class)
				.setParameter("someField", "a")
				.getResultList()
			;
		
		assertEquals(2, children.size());
		
		assertNotNull(children.get(1).getParent()); // nb reverse order since last entry (this one) will not be null
		assertEquals(children.get(1).getItems().size(), 2);

		assertNotNull("this should not be null when idx=1 above is mapped ok", children.get(0).getParent());
		assertEquals(children.get(0).getItems().size(), 2);
		
		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
