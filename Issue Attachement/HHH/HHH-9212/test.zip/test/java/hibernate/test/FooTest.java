package hibernate.test;

import java.util.List;

import junit.framework.Assert;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/hsqlContext.xml")
public class FooTest
{

    @Autowired
    private SessionFactory sessionFactory;

    @Test
    public void testDefaultBatchFetchSize() throws Exception
    {
        Child child = new Child();
        Child child2 = new Child();
        Parent parent = new Parent();
        Parent parent2 = new Parent();
        Session currentSession = sessionFactory.openSession();
        currentSession.save(parent2);
        currentSession.save(parent);
        child.setParent(parent);
        currentSession.save(child);
        child2.setParent(parent2);
        currentSession.save(child2);
        currentSession.flush();
        StatelessSession session = null;
        try
        {
            session = sessionFactory.openStatelessSession();
            Query query = session.createQuery("select a from Child a   where a.id in (1,2) ");
            @SuppressWarnings("unchecked")
            List<Child> children = query.list();
            for (Child qChild : children)
            {
                Assert.assertNotNull(qChild.getParent());
            }
        }
        finally
        {
            currentSession.close();
            session.close();
        }
    }
}