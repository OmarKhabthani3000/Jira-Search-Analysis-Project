package org.hibernate.bugs;

import jakarta.persistence.Entity;

@Entity
public class BatchData extends Data {
    private String baz;

    public String getBaz() {
        return baz;
    }

    public void setBaz(String baz) {
        this.baz = baz;
    }
}
