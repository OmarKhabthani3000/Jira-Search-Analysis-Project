package org.hibernate.bugs;

import jakarta.persistence.Entity;

@Entity
public abstract class ContinuousData extends Data {
    private String bar;

    public String getBar() {
        return bar;
    }

    public void setBar(String bar) {
        this.bar = bar;
    }
}
