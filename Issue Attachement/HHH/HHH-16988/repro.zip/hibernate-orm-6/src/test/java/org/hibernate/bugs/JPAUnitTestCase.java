package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

    /**
     * This test fails. The specific query used here could be much simpler of course, but I simplified the real one
     * to reproduce the issue.
     * Stack trace:
     * java.lang.AssertionError
     * 	at org.hibernate.query.sqm.tree.domain.AbstractSqmPath.copyTo(AbstractSqmPath.java:61)
     * 	at org.hibernate.query.sqm.tree.domain.SqmBasicValuedSimplePath.copy(SqmBasicValuedSimplePath.java:63)
     * 	at org.hibernate.query.sqm.tree.domain.SqmBasicValuedSimplePath.copy(SqmBasicValuedSimplePath.java:25)
     * 	at org.hibernate.query.sqm.tree.domain.AbstractSqmPath.copyTo(AbstractSqmPath.java:67)
     * 	at org.hibernate.query.sqm.tree.domain.AbstractSqmFrom.copyTo(AbstractSqmFrom.java:130)
     * 	at org.hibernate.query.sqm.tree.domain.AbstractSqmQualifiedJoin.copyTo(AbstractSqmQualifiedJoin.java:39)
     * 	at org.hibernate.query.sqm.tree.domain.SqmSetJoin.copy(SqmSetJoin.java:74)
     * 	at org.hibernate.query.sqm.tree.domain.SqmSetJoin.copy(SqmSetJoin.java:32)
     * 	at org.hibernate.query.sqm.tree.domain.AbstractSqmFrom.copyTo(AbstractSqmFrom.java:134)
     * 	at org.hibernate.query.sqm.tree.from.SqmRoot.copyTo(SqmRoot.java:93)
     * 	at org.hibernate.query.sqm.tree.domain.SqmCorrelatedRoot.copy(SqmCorrelatedRoot.java:41)
     * 	at org.hibernate.query.sqm.tree.domain.SqmCorrelatedRoot.copy(SqmCorrelatedRoot.java:17)
     * 	at org.hibernate.query.sqm.tree.from.SqmFromClause.<init>(SqmFromClause.java:40)
     * 	at org.hibernate.query.sqm.tree.from.SqmFromClause.copy(SqmFromClause.java:46)
     * 	at org.hibernate.query.sqm.tree.select.SqmQuerySpec.copy(SqmQuerySpec.java:101)
     * 	at org.hibernate.query.sqm.tree.select.SqmQuerySpec.copy(SqmQuerySpec.java:56)
     * 	at org.hibernate.query.sqm.tree.select.SqmSubQuery.copy(SqmSubQuery.java:149)
     * 	at org.hibernate.query.sqm.tree.select.SqmSubQuery.copy(SqmSubQuery.java:75)
     * 	at org.hibernate.query.sqm.tree.predicate.SqmExistsPredicate.copy(SqmExistsPredicate.java:45)
     * 	at org.hibernate.query.sqm.tree.predicate.SqmExistsPredicate.copy(SqmExistsPredicate.java:17)
     * 	at org.hibernate.query.sqm.tree.predicate.SqmWhereClause.copy(SqmWhereClause.java:33)
     * 	at org.hibernate.query.sqm.tree.select.SqmQuerySpec.copy(SqmQuerySpec.java:107)
     * 	at org.hibernate.query.sqm.tree.select.SqmQuerySpec.copy(SqmQuerySpec.java:56)
     * 	at org.hibernate.query.sqm.tree.select.SqmSelectStatement.copy(SqmSelectStatement.java:131)
     * 	at org.hibernate.query.sqm.tree.select.SqmSelectStatement.copy(SqmSelectStatement.java:42)
     * 	at org.hibernate.query.sqm.internal.QuerySqmImpl.<init>(QuerySqmImpl.java:226)
     * 	at org.hibernate.internal.AbstractSharedSessionContract.createCriteriaQuery(AbstractSharedSessionContract.java:1343)
     * 	at org.hibernate.internal.AbstractSharedSessionContract.createQuery(AbstractSharedSessionContract.java:1304)
     * 	at org.hibernate.internal.SessionImpl.createQuery(SessionImpl.java:190)
     * 	at org.hibernate.bugs.JPAUnitTestCase.shouldQueryWhenTwoLevelsInHierarchy(JPAUnitTestCase.java:46)
     */
	@Test
	public void shouldQueryWhenTwoLevelsInHierarchy() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<StoredContinuousData> criteriaQuery = cb.createQuery(StoredContinuousData.class);
        Root<StoredContinuousData> root = criteriaQuery.from(StoredContinuousData.class);
        criteriaQuery.where(createPredicate(root, criteriaQuery, cb));
        entityManager.createQuery(criteriaQuery).getResultList();

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    /**
     * This test passes although it does basically the same thing as the one with the two levels in the hierarchy.
     */
    @Test
    public void shouldQueryWhenOneLevelInHierarchy() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<BatchData> criteriaQuery = cb.createQuery(BatchData.class);
        Root<BatchData> root = criteriaQuery.from(BatchData.class);
        criteriaQuery.where(createPredicate(root, criteriaQuery, cb));
        entityManager.createQuery(criteriaQuery).getResultList();

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    public <D> Predicate createPredicate(
        Root<D> root,
        CriteriaQuery<?> criteriaQuery,
        CriteriaBuilder cb
    ) {
        Subquery<String> subquery = criteriaQuery.subquery(String.class);
        Root<D> root2 = subquery.correlate(root);
        subquery.select(root2.get("id"))
                .where(root2.join("tags")
                            .get("id")
                            .in("a", "b"));
        return cb.exists(subquery);
    }
}
