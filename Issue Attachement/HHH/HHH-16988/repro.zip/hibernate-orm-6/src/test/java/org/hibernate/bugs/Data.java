package org.hibernate.bugs;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;

/**
 * @author JB Nizet
 */
@Entity
public abstract class Data {
    @Id
    private String id;

    @ManyToMany
    @JoinTable(
        name = "data_tags",
        joinColumns = @JoinColumn(name = "data_id"),
        inverseJoinColumns = @JoinColumn(name = "tag_value_id")
    )
    private Set<Tag> tags = new HashSet<>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Set<Tag> getTags() {
        return tags;
    }

    public void setTags(Set<Tag> tags) {
        this.tags = tags;
    }
}
