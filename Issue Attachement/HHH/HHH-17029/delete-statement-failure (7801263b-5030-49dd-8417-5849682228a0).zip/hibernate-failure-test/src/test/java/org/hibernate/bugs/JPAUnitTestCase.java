package org.hibernate.bugs;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.hibernate.bugs.entities.Car;
import org.hibernate.bugs.entities.Person;
import org.hibernate.bugs.entities.PersonGroup;
import org.hibernate.bugs.entities.Relationship;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;


/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@BeforeEach
	public void init() {
		this.entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
	}

	@AfterEach
	public void destroy() {
		this.entityManagerFactory.close();
	}

	
	private static String getSelectCountQueryString(Class<?> clazz) {
	    String name = clazz.getSimpleName();
	    String id = name.codePoints().filter(Character::isUpperCase).map(Character::toLowerCase).collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).toString();
	    return "SELECT COUNT(%s) FROM %s AS %s".formatted(id, name, id);
	}
	
	private static int getSelectionResult(Class<?> clazz, EntityManager entityManager) {
	    Query query = entityManager.createQuery(getSelectCountQueryString(clazz));
	    EntityTransaction transaction = entityManager.getTransaction();
	    transaction.begin();
	    @SuppressWarnings("unchecked")
        List<Long> result = query.getResultList();
	    transaction.commit();
	    return result.get(0).intValue();
	}
	
	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void deleteTest() throws Exception {
		try(EntityManager entityManager = this.entityManagerFactory.createEntityManager()) {
	        EntityTransaction transaction = entityManager.getTransaction();
	        transaction.begin();
		    Person unboundedPerson = new Person("Not Bounded");
		    Car car = new Car("1");
	        car.setOwner(unboundedPerson);
	        entityManager.persist(unboundedPerson);
	        entityManager.persist(car);
	        
	        PersonGroup personGroup = new PersonGroup("My Group");
	        Person boundedPerson = new Person("Bounded");
	        Relationship relationship = new Relationship(boundedPerson, personGroup, true);
	        entityManager.persist(personGroup);
	        entityManager.persist(boundedPerson);
	        entityManager.persist(relationship);
	        
	        transaction.commit();
	        
	        assertEquals(2, getSelectionResult(Person.class, entityManager));
	        assertEquals(1, getSelectionResult(PersonGroup.class, entityManager));
            assertEquals(1, getSelectionResult(Relationship.class, entityManager));
            assertEquals(1, getSelectionResult(Car.class, entityManager));

            transaction = entityManager.getTransaction();
            transaction.begin();
		    String queryString = "DELETE FROM Car AS car WHERE car.owner.relationships IS EMPTY";
		    Query query = entityManager.createQuery(queryString);
		    // Next statement fails
		    int deletedCarCount = query.executeUpdate();
		    
		    assertEquals(1, deletedCarCount);
            assertEquals(0, getSelectionResult(Car.class, entityManager));
		    transaction.commit();
		}
	}
}
