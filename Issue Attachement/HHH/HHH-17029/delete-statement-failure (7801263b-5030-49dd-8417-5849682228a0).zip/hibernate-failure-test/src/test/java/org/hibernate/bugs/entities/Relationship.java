package org.hibernate.bugs.entities;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.ManyToOne;

@Entity
@Access(AccessType.PROPERTY)
@IdClass(RelationshipId.class)
public class Relationship {

    private boolean leader;
    
    private Person person;
    
    private PersonGroup personGroup;
    
    public Relationship() {}
    
    public Relationship(Person person, PersonGroup personGroup, boolean leader) {
        this.person = person;
        this.personGroup = personGroup;
        this.leader = leader;
    }

    public boolean isLeader() {
        return this.leader;
    }

    public void setLeader(boolean leader) {
        this.leader = leader;
    }

    @Id
    @ManyToOne
    public Person getPerson() {
        return this.person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    @Id
    @ManyToOne
    public PersonGroup getPersonGroup() {
        return this.personGroup;
    }

    public void setPersonGroup(PersonGroup personGroup) {
        this.personGroup = personGroup;
    }
}
