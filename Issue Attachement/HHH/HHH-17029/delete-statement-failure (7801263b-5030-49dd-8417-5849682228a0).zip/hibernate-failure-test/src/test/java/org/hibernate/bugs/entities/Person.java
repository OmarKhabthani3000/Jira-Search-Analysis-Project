package org.hibernate.bugs.entities;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
@Access(AccessType.PROPERTY)
public class Person {
    
    private String name;

    private List<Relationship> relationships = new ArrayList<>();
    
    private List<Car> cars = new ArrayList<>();
    
    public Person() {}
    
    public Person(String name) {
        setName(name);
    }
    
    @Id
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    @OneToMany(mappedBy = "person")
    public List<Relationship> getRelationships() {
        return this.relationships;
    }

    public void setRelationships(List<Relationship> relationships) {
        this.relationships = relationships;
    }

    @OneToMany(mappedBy = "owner")
    public List<Car> getCars() {
        return this.cars;
    }

    public void setCars(List<Car> cars) {
        this.cars = cars;
    }
}
