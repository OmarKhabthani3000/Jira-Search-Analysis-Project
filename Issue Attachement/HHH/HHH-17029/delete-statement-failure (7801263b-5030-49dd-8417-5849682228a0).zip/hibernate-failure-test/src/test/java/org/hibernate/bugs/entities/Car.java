package org.hibernate.bugs.entities;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
@Access(AccessType.PROPERTY)
public class Car {

    private String number;
    
    private Person owner;
    
    public Car() {}
    
    public Car(String number) {
        setNumber(number);
    }

    @Id
    public String getNumber() {
        return this.number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    @ManyToOne
    public Person getOwner() {
        return this.owner;
    }

    public void setOwner(Person owner) {
        this.owner = owner;
    }
}
