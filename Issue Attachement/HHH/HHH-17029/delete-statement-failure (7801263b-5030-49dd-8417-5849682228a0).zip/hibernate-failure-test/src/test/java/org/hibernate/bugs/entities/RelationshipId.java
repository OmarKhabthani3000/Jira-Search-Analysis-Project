package org.hibernate.bugs.entities;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;

@Access(AccessType.PROPERTY)
public class RelationshipId implements Serializable {

    @Serial
    private static final long serialVersionUID = -4117332648932943040L;

    private String person;
    
    private String personGroup;

    public String getPerson() {
        return this.person;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    public String getPersonGroup() {
        return this.personGroup;
    }

    public void setPersonGroup(String personGroup) {
        this.personGroup = personGroup;
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.personGroup, this.person);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        } else if (obj instanceof RelationshipId relationshipId) {
            return Objects.equals(this.personGroup, relationshipId.personGroup) && Objects.equals(this.person, relationshipId.person);
        } else {
            return false;
        }
    }

}
