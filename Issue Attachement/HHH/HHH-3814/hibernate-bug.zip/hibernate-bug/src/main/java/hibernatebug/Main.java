package hibernatebug;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

/**
 * Demonstrates a Hibernate bug.
 */
public class Main {
  public static void main(String[] args) {
    new Main();
  }
  
  private Main() {
    SessionFactory sessionFactory;
    try {
      // set up Hibernate
      sessionFactory = new AnnotationConfiguration()
        .setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect")
        .setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver")
        .setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:test")
        .setProperty("hibernate.connection.username", "sa")
        .setProperty("hibernate.connection.password", "")
        .setProperty("hibernate.hbm2ddl.auto", "create")
        .addAnnotatedClass(Entity1.class)
        .addAnnotatedClass(Entity2.class)
        .buildSessionFactory();
      
      // start transaction
      StatelessSession session = sessionFactory.openStatelessSession();
      Transaction trx = session.beginTransaction();
      
      // try to insert entity objects
      session.insert(new Entity1(1));
      session.insert(new Entity1(1));   // should cause an exception: same ID/primary key as before
      session.insert(new Entity2(99));  // ...but instead the exception occurs here, leading to
                                        //    confusion on why adding new Entity2(99) has failed
      
      trx.commit();
      session.close();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }
  
  /**
   * First entity class.
   */
  @Entity
  @Table(name="ENTITY_1")
  class Entity1 {
    @Id
    int id;
    
    public Entity1(int id) {
      this.id = id;
    }
  }
  
  /**
   * Seconds entity class.
   */
  @Entity
  @Table(name="ENTITY_2")
  class Entity2 {
    @Id
    int id;
    
    public Entity2(int id) {
      this.id = id;
    }
  }
}
