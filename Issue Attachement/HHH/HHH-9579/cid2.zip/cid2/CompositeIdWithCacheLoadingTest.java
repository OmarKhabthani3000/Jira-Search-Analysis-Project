/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2008, Red Hat Middleware LLC or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Middleware LLC.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.test.cid2;

import org.hibernate.Cache;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.cid.PurchaseDetail;
import org.hibernate.test.cid.PurchaseRecord;
import org.hibernate.testing.TestForIssue;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.jboss.logging.Logger;
import org.junit.Test;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Tests the use of composite-id with EAGER and then LAZY load dereference
 * The LAZY loading fails to perform the select, instead it appears to use the original
 * concrete class as the value.
 * 
 * For HHH-9528.
 * 
 * @author Darryl L. Miles
 */
@TestForIssue( jiraKey = "HHH-9528" )
public class CompositeIdWithCacheLoadingTest extends BaseCoreFunctionalTestCase {

	private static final Logger log = Logger.getLogger( CompositeIdWithCacheLoadingTest.class );

	@Override
	public String[] getMappings() {
		return new String[] { "cid2/Customer.hbm.xml", "cid2/Order.hbm.xml", "cid2/LineItem.hbm.xml" };
	}

	@Test
	public void testCompositeIdSimple() {
		final String customerName = "customerName";
		final String product = "The Special Box";
		final String orderRef = "orderRef1234";
		final int quantity = 42;
		LineItem.Id pkid = null;
		{
			Session s = openSession();
			Transaction t = s.beginTransaction();

			// Persist some data
			Customer customer = new Customer();
			customer.setName(customerName);
			s.persist(customer);

			Order order = new Order();
			order.setCustomer(customer);
			order.setOrderRef(orderRef);
			order.setTotal(BigDecimal.ONE);
			s.persist(order);

			LineItem.Id lineItemId = new LineItem.Id(order, 0);
			LineItem lineItem = new LineItem(lineItemId);
			lineItem.setLineItemIndex(0);
			lineItem.setProduct(product);
			lineItem.setQuantity(quantity);
			s.persist(lineItem);

			pkid = (LineItem.Id) lineItem.getId().clone();      // save PKID

			t.commit();
			s.clear();      // needed?
			s.close();
		}

		Cache cache = sessionFactory().getCache();
		if(cache != null) {
			log.debug("cache.evictAllRegions() FOUND");
			cache.evictAllRegions();
		} else {
			log.debug("cache.evictAllRegions() NOT-FOUND");
		}

		{
			Session s = openSession();
			Transaction t = s.beginTransaction();

			LineItem lineItem = (LineItem) s.get(LineItem.class, pkid);
			assertNotNull(lineItem);
			assertEquals("LineItem#product", product, lineItem.getProduct());
			assertEquals("LineItem#quantity", quantity, lineItem.getQuantity());
			assertTrue(s.contains(lineItem));

			LineItem.Id id = lineItem.getId();
			assertNotNull(id);
			Order order = id.getOrder();      // EAGER loaded via JOIN from Session#get above
			assertNotNull(order);
			assertEquals("Order#orderRef", orderRef, order.getOrderRef());
			assertTrue(s.contains(order));

			Customer customer = order.getCustomer();    // expect LAZY load via SELECT, but not SELECT happens
			assertNotNull(customer);    // this is non-null, it is our exact concrete instance we persisted
			assertEquals("Customer#name", customerName, customer.getName());
			assertTrue(s.contains(customer));   // OPPS this is the bug

			t.commit();
			s.close();
		}
	}

}

