package org.hibernate.test.cid2;

import java.io.Serializable;

/**
 *
 */
public class LineItem {
	public static class Id implements Serializable, Cloneable {
		private Order order;
//		private long orderId;
		private int orderLineId;

		public Id(Order order, int orderLineId) {
			setOrder(order);
			setOrderLineId(orderLineId);
		}
//		public Id(long orderId, int orderLineId) {
//			setOrderId(orderId);
//			setOrderLineId(orderLineId);
//		}
		public Id() {}

		/**
		 * @return Returns the order.
		 */
		public Order getOrder() {
			return order;
		}
		/**
		 * @param order The orderId to set.
		 */
		public void setOrder(Order order) {
			this.order = order;
		}
//		/**
//		 * @return Returns the orderId.
//		 */
//		public long getOrderId() {
//			return orderId;
//		}
//		/**
//		 * @param orderId The orderId to set.
//		 */
//		public void setOrderId(long orderId) {
//			this.orderId = orderId;
//		}
		/**
		 * @return Returns the orderLineId.
		 */
		public int getOrderLineId() {
			return orderLineId;
		}
		/**
		 * @param orderLineId The orderId to set.
		 */
		public void setOrderLineId(int orderLineId) {
			this.orderLineId = orderLineId;
		}

		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + (int) (order.getOrderId() ^ (order.getOrderId() >>> 32));
			result = prime * result + getOrderLineId();
			return result;
			//return (int) orderId + orderLineId;
		}

		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (!(obj instanceof Id))
				return false;
			Id other = (Id) obj;
			if (!Order.safeEquals(getOrder(), other.getOrder()))
				return false;
			if (getOrderLineId() != other.getOrderLineId())
				return false;
			return true;
		}

		public Object clone() {
			return new Id(getOrder(), getOrderLineId());
		}
	}

	private Id id = new Id();
	private int lineItemIndex;
	private int quantity;
//	private Order order;
	private String product;

	public LineItem(Id id) {
		setId(id);
	}

	public LineItem() {}

	/**
	 * @return Returns the lineItemIndex.
	 */
	public int getLineItemIndex() {
		return lineItemIndex;
	}
	/**
	 * @param lineItemIndex The order to set.
	 */
	public void setLineItemIndex(int lineItemIndex) {
		this.lineItemIndex = lineItemIndex;
	}

//	/**
//	 * @return Returns the order.
//	 */
//	public Order getOrder() {
//		return order;
//	}
//	/**
//	 * @param order The order to set.
//	 */
//	public void setOrder(Order order) {
//		this.order = order;
//	}
	/**
	 * @return Returns the product.
	 */
	public String getProduct() {
		return product;
	}
	/**
	 * @param product The product to set.
	 */
	public void setProduct(String product) {
		this.product = product;
	}
	/**
	 * @return Returns the quantity.
	 */
	public int getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity The quantity to set.
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return Returns the id.
	 */
	public Id getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(Id id) {
		this.id = id;
	}
}
