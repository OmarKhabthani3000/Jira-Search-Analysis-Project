
package org.hibernate.test.cid2;

import java.math.BigDecimal;


/**
 *
 */
public class Order {

	private long orderId;
	private Customer customer;
	private BigDecimal total;
	private String orderRef;

	public Order() {}

	/**
	 * @return Returns the orderId.
	 */
	public long getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId The orderId to set.
	 */
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return Returns the customer.
	 */
	public Customer getCustomer() {
		return customer;
	}
	/**
	 * @param customer The customer to set.
	 */
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	/**
	 * @return Returns the total.
	 */
	public BigDecimal getTotal() {
		return total;
	}
	/**
	 * @param total The total to set.
	 */
	public void setTotal(BigDecimal total) {
		this.total = total;
	}
	/**
	 * @return Returns the orderRef.
	 */
	public String getOrderRef() {
		return orderRef;
	}
	/**
	 * @param orderRef The total to set.
	 */
	public void setOrderRef(String orderRef) {
		this.orderRef = orderRef;
	}

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (getOrderId() ^ (getOrderId() >>> 32));
		return result;
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Order))
			return false;
		Order other = (Order) obj;
		if (getOrderId() != other.getOrderId())
			return false;
		return true;
	}

	public static boolean safeEquals(Order a, Order b) {
		if(a == null || b == null)
			return false;
		return a.equals(b);
	}
}
