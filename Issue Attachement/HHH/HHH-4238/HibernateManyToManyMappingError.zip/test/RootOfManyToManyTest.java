

import java.util.ArrayList;

import junit.framework.TestCase;

import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class RootOfManyToManyTest extends TestCase
{
    protected HibernateTemplate             hibernateTemplate;

    protected void setUp() throws Exception
    {
        FileSystemXmlApplicationContext appContext = new FileSystemXmlApplicationContext( "spring.xml" );
        
        hibernateTemplate = (HibernateTemplate)appContext.getBean( "hibernateTemplate" );
    }
    
    public void test_manyToManyRelationship() throws Exception 
    {
        RootOfManyToMany rootOfManyToMany = new RootOfManyToMany();
        rootOfManyToMany.values = new ArrayList<ValueOfManyToMany>();
        rootOfManyToMany.values.add( new ValueOfManyToMany() );
        
        assertEquals( 0, hibernateTemplate.find( "from RootOfManyToMany" ).size() );
        
        Long id = (Long)hibernateTemplate.save( rootOfManyToMany );
        hibernateTemplate.flush();
        
        assertEquals( 1, hibernateTemplate.find( "from RootOfManyToMany" ).size() );
        
        RootOfManyToMany root = (RootOfManyToMany)hibernateTemplate.get( RootOfManyToMany.class, id );
        ValueOfManyToMany value = root.values.get( 0 );
        
        hibernateTemplate.delete( root );
        hibernateTemplate.flush();
        
        hibernateTemplate.delete( value ); //Exception thrown here
    }
}
