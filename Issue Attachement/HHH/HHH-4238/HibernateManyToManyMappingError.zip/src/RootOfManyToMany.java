

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class RootOfManyToMany
{
    @Id
    @GeneratedValue( generator = "hibseq" )
    @GenericGenerator( name = "hibseq", strategy = "hilo" )
    public Long                            id;

    @ManyToMany( fetch = FetchType.EAGER, cascade = javax.persistence.CascadeType.ALL )
    @JoinTable(
         name = "MAPPING_TABLE",
         joinColumns = {@JoinColumn(name = "ROOT_ID")},
         inverseJoinColumns = {@JoinColumn(name = "VALUE_ID")}
    )
    public List< ValueOfManyToMany > values;
}