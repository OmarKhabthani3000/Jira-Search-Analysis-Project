//$Id: ManyToManyTest.java 11282 2007-03-14 22:05:59Z epbernard $
package org.hibernate.test.annotations.manytomany;


import java.util.ArrayList;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.annotations.TestCase;

public class ManyToManyTest extends TestCase {

	public ManyToManyTest(String x) {
		super( x );
	}
    
    public void testMen() throws Exception
    {
        Session s;
        Transaction tx;
        s = openSession();
        tx = s.beginTransaction();
        
        RootOfManyToMany rootOfManyToMany = new RootOfManyToMany();
        ValueOfManyToMany valueOfManyToMany = new ValueOfManyToMany();
        rootOfManyToMany.values = new ArrayList<ValueOfManyToMany>();
        rootOfManyToMany.values.add( valueOfManyToMany );

        Criteria rootCriteria = s.createCriteria( RootOfManyToMany.class );
        Criteria valueCriteria = s.createCriteria( ValueOfManyToMany.class );
        
        assertEquals( 0, rootCriteria.list().size() );
        assertEquals( 0, valueCriteria.list().size() );
        
        s.save( rootOfManyToMany );
        s.flush();

        assertEquals( 1, rootCriteria.list().size() );
        assertEquals( 1, valueCriteria.list().size() );
        
        Long rootId = rootOfManyToMany.id;
        Long valueId = valueOfManyToMany.id;
        
        RootOfManyToMany persistedRoot = (RootOfManyToMany)s.get( RootOfManyToMany.class, rootId );
        ValueOfManyToMany persistedValue = (ValueOfManyToMany)s.get( ValueOfManyToMany.class, valueId );
        
        s.delete( persistedRoot );
        s.flush();

        assertEquals( 0, rootCriteria.list().size() );
        assertEquals( 0, valueCriteria.list().size() );
        
        s.delete( persistedValue ); //Exception thrown here
        
        tx.commit();
        s.close();
    }

	/**
	 * @see org.hibernate.test.annotations.TestCase#getMappings()
	 */
	protected Class[] getMappings() {
		return new Class[]{
		           RootOfManyToMany.class,
		           ValueOfManyToMany.class
		};
	}

}