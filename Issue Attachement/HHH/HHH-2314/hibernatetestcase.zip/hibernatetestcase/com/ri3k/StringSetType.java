/**
 *
 * -----------------------------------------------------------------------
 *
 * RI3K  LIMITED
 *
 * -----------------------------------------------------------------------
 *
 * (C) Copyright 2005 RI3K Limited. All rights reserved.
 *
 * NOTICE:  All information contained herein or attendant hereto is,
 *          and remains, the property of RI3K Limited.  Many of the
 *          intellectual and technical concepts contained herein are
 *          proprietary to RI3K Limited. Any dissemination of this
 *          information or reproduction of this material is strictly
 *          forbidden unless prior written permission is obtained
 *          from RI3K Limited.
 *
 * -----------------------------------------------------------------------
 *
 */
package com.ri3k;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import org.hibernate.HibernateException;
import org.hibernate.usertype.ParameterizedType;
import org.hibernate.usertype.UserType;

public class StringSetType implements UserType, ParameterizedType {

    private static final int[] SQL_TYPES = new int[] {Types.VARCHAR};
    private String delim = "|";

    public int[] sqlTypes() {
        return SQL_TYPES;
    }

    public Class returnedClass() {
        return Set.class;
    }

    public boolean equals(Object x, Object y) throws HibernateException {
        if (x == y) return true;
        if (x == null || y == null) return false;
        return x.equals(y);
    }

    public int hashCode(Object x) throws HibernateException {
        return x.hashCode();
    }

    public Object nullSafeGet(ResultSet rs, String[] names, Object owner) throws HibernateException, SQLException {
        String setStrings = rs.getString(names[0]);
        Set<String> set = new HashSet<String>();
        if (setStrings != null) {
            StringTokenizer tokenizer = new StringTokenizer(setStrings, delim);
            while(tokenizer.hasMoreTokens()) {
                set.add(tokenizer.nextToken());
            }
        }
        return set;
    }

    public void nullSafeSet(PreparedStatement st, Object value, int index) throws HibernateException, SQLException {
        Set set = (Set) value;
        if (set == null) {
            st.setNull(index, Types.VARCHAR);
        } else {
            st.setString(index, getString(set));
        }
    }

    private String getString(Set set) {
        StringBuffer buffer = new StringBuffer();
        for (Iterator iter = set.iterator(); iter.hasNext();) {
            String element = (String) iter.next();
            buffer.append(element);
            buffer.append(delim);
        }
        return buffer.toString();
    }

    public Object deepCopy(Object value) throws HibernateException {
        return new HashSet<String>((Set<? extends String>) value);
    }

    public boolean isMutable() {
        return true;
    }

    public Serializable disassemble(Object value) throws HibernateException {
        return (Serializable) value;
    }

    public Object assemble(Serializable cached, Object owner) throws HibernateException {
        return cached;
    }

    public Object replace(Object original, Object target, Object owner) throws HibernateException {
        return original;
    }

    public void setParameterValues(Properties parameters) {
        setDelim(parameters.getProperty("delim"));
    }

    private void setDelim(String delim) {
        if (delim != null && delim.length() == 1) {
            this.delim = delim;
        }
    }

}
