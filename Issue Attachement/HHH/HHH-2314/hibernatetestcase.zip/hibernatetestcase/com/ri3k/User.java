package com.ri3k;


import java.util.HashSet;
import java.util.Set;

public class User {

    private Set<String> roles = new HashSet<String>();
    private String id;

    public User() {
        roles.add("default role");
    }

    

    public String getId() {
        return id;
    }



    public void setId(String id) {
        this.id = id;
    }



    public Set getRoles() {
        return roles;
    }
    
    public void addRole(String role) {
        roles.add(role);
    }

}
