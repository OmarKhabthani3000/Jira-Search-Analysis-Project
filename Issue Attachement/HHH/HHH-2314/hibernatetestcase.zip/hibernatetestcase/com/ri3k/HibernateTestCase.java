package com.ri3k;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.Status;
import javax.transaction.SystemException;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateTestCase extends TestCase {

    private static final String ROLE3 = "role3";
    private static final String ROLE2 = "role2";
    private static final String USER_ID = "test";
    SessionFactory sessionFactory = null;

    public void setUp() {
        Configuration config = new Configuration().setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect").setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver").setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:baseball").setProperty("hibernate.connection.username", "sa").setProperty("hibernate.connection.password", "").setProperty("hibernate.connection.pool_size", "1").setProperty("hibernate.connection.autocommit", "true").setProperty(
                "hibernate.cache.provider_class", "org.hibernate.cache.HashtableCacheProvider").setProperty("hibernate.hbm2ddl.auto", "create-drop").setProperty("hibernate.show_sql", "true").addClass(User.class);

        sessionFactory = config.buildSessionFactory();
    }

    public void testCreateUser() throws SecurityException, IllegalStateException, RollbackException, HeuristicMixedException, HeuristicRollbackException, SystemException {

        final User user = new User();
        user.setId(USER_ID);

        executeInTransaction(new HibernateCallback() {
            public Object execute(Session session) {
                return session.save(user);
            }
        });

        User u2 = selectUser();

        assertEquals(user.getId(), u2.getId());
        assertEquals(user.getRoles(), u2.getRoles());

    }

    private User selectUser() throws SecurityException, IllegalStateException, RollbackException, HeuristicMixedException, HeuristicRollbackException, SystemException {
        User u2 = (User) executeInTransaction(new HibernateCallback() {

            public Object execute(Session session) {
                return session.get(User.class, USER_ID);
            }
        });
        return u2;
    }

    public void testCreateUserUpdateRolesBetweenFlushes() throws SecurityException, IllegalStateException, RollbackException, HeuristicMixedException, HeuristicRollbackException, SystemException {

        final User user = new User();
        user.setId(USER_ID);

        executeInTransaction(new HibernateCallback() {
            public Object execute(Session session) {

                session.save(user);
                session.flush();

                user.addRole(ROLE2);
                session.flush();

                user.addRole(ROLE3);

                return null;
            }
        });

        sessionFactory.evict(User.class);

        User u2 = selectUser();
        assertTrue(u2.getRoles().contains(ROLE3));

    }

    @Override
    protected void tearDown() throws Exception {
        sessionFactory.close();
    }

    public Object executeInTransaction(HibernateCallback callback) throws SecurityException, IllegalStateException, RollbackException, HeuristicMixedException, HeuristicRollbackException, SystemException {

        Session session = null;
        Transaction transaction = null;

        Object result = null;

        try {
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();  

            result = callback.execute(session);

            transaction.commit();
            
            return result;
        } finally {
            try {
                if (transaction != null && transaction.isActive()) {
                    transaction.rollback();
                }
            } catch (Exception e) {
            }

            if (session != null) {
                session.close();
            }

        }
    }

    static interface HibernateCallback {
        Object execute(Session session);
    }
}
