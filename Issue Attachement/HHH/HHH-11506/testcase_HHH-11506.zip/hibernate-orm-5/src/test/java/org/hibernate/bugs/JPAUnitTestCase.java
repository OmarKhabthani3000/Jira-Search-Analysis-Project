package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.bugs.model.Entity1;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void testUpdateLazyProperty() throws Exception {
		EntityManager em;
		Entity1 entity1;
		
		// step 1: insert entity1
		em = begin();
		entity1 = new Entity1();
		entity1.setId(1L);
		em.persist(entity1);
		commitAndClear(em);

		// step 2: read entity1 and update
		em = begin();
		entity1 = em.find(Entity1.class, 1L);
		Assert.assertNull(entity1.getLongText());
		entity1.setLongText("xxx");
		// IMPORTANT: uncommenting the next line makes the test pass under hibernate 5.2.2
		// entity1.getChildren().size();
		commitAndClear(em);
	
		// step 3: verify entity1
		em = begin();
		entity1 = em.find(Entity1.class, 1L);
		Assert.assertNotNull("field longText should have been updated", entity1.getLongText());
		commitAndClear(em);
	}
	
	private EntityManager begin() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		return entityManager;
	}
	
	private void commitAndClear(EntityManager em) {
		em.getTransaction().commit();
		em.clear();
	}
}
