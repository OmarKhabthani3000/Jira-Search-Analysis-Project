package org.hibernate.bugs.model;

import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;

@Entity
public class Entity1 {
	
	@Id
	private Long id;

	@Lob
	@Basic(fetch = FetchType.LAZY)
	private String longText;
	
	@OneToMany(mappedBy="parent")
	private List<Entity2> children;
	
	//////////////////////
	// Getters and Setters
	public String getLongText() {
		return longText;
	}

	public void setLongText(String longText) {
		this.longText = longText;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<Entity2> getChildren() {
		return children;
	}
}
