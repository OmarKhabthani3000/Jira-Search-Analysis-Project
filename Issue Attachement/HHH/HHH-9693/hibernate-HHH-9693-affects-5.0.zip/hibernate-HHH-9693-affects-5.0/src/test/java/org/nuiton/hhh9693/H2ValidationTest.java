package org.nuiton.hhh9693;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

/**
 * @author Arnaud Thimel (Code Lutin)
 */
public class H2ValidationTest {

    protected Configuration createConfiguration(String dbUrl, String hbm2ddl, Class<?> dialectClass) {

        Configuration configuration = new Configuration();
        configuration.addClass(SomeEntity.class);
        configuration.setProperty("hibernate.connection.driver_class", org.h2.Driver.class.getName());
        configuration.setProperty("hibernate.connection.username", "sa");
        configuration.setProperty("hibernate.connection.password", "");

        configuration.setProperty("hibernate.dialect", dialectClass.getName());
        configuration.setProperty("hibernate.connection.url", dbUrl);
        configuration.setProperty("hibernate.hbm2ddl.auto", hbm2ddl);

        return configuration;
    }

    @Test
    public void testValidateHibernateH2Dialect() {

        String dbUrl = "jdbc:h2:file:/tmp/db-" + System.currentTimeMillis();

        { // Use hibernate.hbm2ddl.auto=update to create the database
            Configuration configuration = createConfiguration(dbUrl, "update", org.hibernate.dialect.H2Dialect.class);
            configuration.buildMappings();
            SessionFactory sessionFactory = configuration.buildSessionFactory();
            sessionFactory.close();
        }

        { // Use hibernate.hbm2ddl.auto=validate to validate the database
            Configuration configuration = createConfiguration(dbUrl, "validate", org.hibernate.dialect.H2Dialect.class);
            configuration.buildMappings();
            SessionFactory sessionFactory = configuration.buildSessionFactory();
            sessionFactory.close();
        }

    }

    @Test
    public void testValidateFixedH2Dialect() {

        String dbUrl = "jdbc:h2:file:/tmp/db-" + System.currentTimeMillis();

        { // Use hibernate.hbm2ddl.auto=update to create the database
            Configuration configuration = createConfiguration(dbUrl, "update", FixedH2Dialect.class);
            configuration.buildMappings();
            SessionFactory sessionFactory = configuration.buildSessionFactory();
            sessionFactory.close();
        }

        { // Use hibernate.hbm2ddl.auto=validate to validate the database
            Configuration configuration = createConfiguration(dbUrl, "validate", FixedH2Dialect.class);
            configuration.buildMappings();
            SessionFactory sessionFactory = configuration.buildSessionFactory();
            sessionFactory.close();
        }

    }

}
