package org.nuiton.hhh9693;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
/**
 * @author Arnaud Thimel (Code Lutin)
 */
public class SomeEntity implements Serializable {

    @Id
    protected long id;

    @Column()
    protected String name;

    public SomeEntity() {
    }

    public SomeEntity(long id, String name) {
        this.id = id;
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
