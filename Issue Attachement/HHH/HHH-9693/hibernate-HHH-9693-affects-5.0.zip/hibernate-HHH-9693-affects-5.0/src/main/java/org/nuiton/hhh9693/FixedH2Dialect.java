package org.nuiton.hhh9693;

import java.sql.Types;

/**
 * @author Arnaud Thimel (Code Lutin)
 */
public class FixedH2Dialect extends org.hibernate.dialect.H2Dialect {

    public FixedH2Dialect() {
        super();

        // Override definition from org.hibernate.dialect.H2Dialect's constructor
        registerColumnType( Types.LONGVARCHAR, String.format("varchar(%d)", Integer.MAX_VALUE) );
    }

}
