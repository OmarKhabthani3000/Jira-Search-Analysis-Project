Test case for https://hibernate.atlassian.net/browse/HHH-9693

HOWTO
-----

Run with
$ mvn clean package

The unit test will create a H2 database using hbm2ddl=update then try to validate the created schema.

In the mapping of SomeEntity, name's attribute type is "text". This is considered as SqlType=LONGVARCHAR.

Currently, Hibernate cannot validate the schema it just created.
