package model.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PerfilIndicador extends COADFPersistent {
	//br.com.cvrd.coadf.model.vo.PerfilIndicador
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private Integer indicador;
	private List cenarios = new ArrayList();
	
	public PerfilIndicador() {
		
	}
	
	public Serializable getId() {
		return id;
	}

	public void setId(Serializable id) {
		this.id = (Integer) id;
	}

	public String toString() {
		return indicador.toString();
	}

	public Integer getIndicador() {
		return indicador;
	}

	public void setIndicador(Integer indicador) {
		this.indicador = indicador;
	}

	public List getCenarios() {
		return cenarios;
	}

	public void setCenarios(List cenarios) {
		this.cenarios = cenarios;
	}

	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((cenarios == null) ? 0 : cenarios.hashCode());
		result = prime * result
				+ ((indicador == null) ? 0 : indicador.hashCode());
		return result;
	}

	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (getClass() != obj.getClass())
			return false;
		final PerfilIndicador other = (PerfilIndicador) obj;
		if (cenarios == null) {
			if (other.cenarios != null)
				return false;
		} else if (!cenarios.equals(other.cenarios))
			return false;
		if (indicador == null) {
			if (other.indicador != null)
				return false;
		} else if (!indicador.equals(other.indicador))
			return false;
		return true;
	}
	
//	public PerfilExtracao getPerfilExtracao() {
//		return perfilExtracao;
//	}
//
//	public void setPerfilExtracao(PerfilExtracao perfilExtracao) {
//		this.perfilExtracao = perfilExtracao;
//	}

	
}
