package model.vo;

import java.io.Serializable;


public class ValorIndicador extends COADFPersistent {
	
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private Integer indicador;
	private Integer tipoValor;
	private Double valor;
		
	public ValorIndicador() {
	}
	
	

	public Serializable getId() {
		return id;
	}



	public void setId(Serializable id) {
		this.id = (Integer) id;
	}

	public Integer getTipoValor() {
		return tipoValor;
	}



	public void setTipoValor(Integer tipoValor) {
		this.tipoValor = tipoValor;
	}
	
	

	
	public Integer getIndicador() {
		return indicador;
	}



	public void setIndicador(Integer indicador) {
		this.indicador = indicador;
	}



	public Double getValor() {
		return valor;
	}



	public void setValor(Double valor) {
		this.valor = valor;
	}



	public String toString() {
		return "" + indicador + " " + tipoValor + " " + valor;
	}



	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((indicador == null) ? 0 : indicador.hashCode());
		result = prime * result
				+ ((tipoValor == null) ? 0 : tipoValor.hashCode());
		result = prime * result + ((valor == null) ? 0 : valor.hashCode());
		return result;
	}




	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		
		if (getClass() != obj.getClass())
			return false;
		final ValorIndicador other = (ValorIndicador) obj;
		if (indicador == null) {
			if (other.indicador != null)
				return false;
		} else if (!indicador.equals(other.indicador))
			return false;
		if (tipoValor == null) {
			if (other.tipoValor != null)
				return false;
		} else if (!tipoValor.equals(other.tipoValor))
			return false;
		if (valor == null) {
			if (other.valor != null)
				return false;
		} else if (!valor.equals(other.valor))
			return false;
		return true;
	}

	
	
}
