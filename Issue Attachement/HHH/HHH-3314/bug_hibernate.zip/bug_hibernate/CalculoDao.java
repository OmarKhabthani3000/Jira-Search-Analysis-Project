package model.dao;

import org.hibernate.Query;

import control.Main;

public class CalculoDao {

	public void getError() {
		StringBuffer sb = new StringBuffer();
		
		sb.append(		" insert into ValorIndicador ( indicador," );
		sb.append(		" 							   tipoValor ) " );
		sb.append(		" select vi.indicador, " );
		sb.append(		" 		 vi.tipoValor ");
		sb.append(		" from ValorIndicador vi, PerfilIndicador pi " );
		sb.append(		" where 1 = 1 " );
		sb.append(		" 	and vi.indicador = pi.indicador " );
		sb.append(		" 	and vi.tipoValor in elements( pi.cenarios ) " );

				
		Query query = Main.session.createQuery(sb.toString());
		
		query.executeUpdate();
//		query.list();

	}
}
