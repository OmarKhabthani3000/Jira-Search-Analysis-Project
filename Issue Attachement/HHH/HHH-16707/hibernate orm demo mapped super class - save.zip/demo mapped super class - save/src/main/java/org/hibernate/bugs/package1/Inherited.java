package org.hibernate.bugs.package1;

import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class Inherited {
    @Id
    protected String id;
    protected String name;

    protected Inherited(String id, String name) {
        this.id = id;
        this.name = name;
    }

    protected Inherited() {
    }

    protected String getId() {
        return id;
    }

    protected String getName() {
        return name;
    }
}
