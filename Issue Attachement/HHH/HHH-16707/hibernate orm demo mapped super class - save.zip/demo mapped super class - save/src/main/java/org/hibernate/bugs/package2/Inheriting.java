package org.hibernate.bugs.package2;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.hibernate.bugs.package1.Inherited;

@Entity
@Table(name = "inheriting")
class Inheriting extends Inherited {

    Inheriting(String id, String name) {
        super(id, name);
    }

    Inheriting() {
    }
}
