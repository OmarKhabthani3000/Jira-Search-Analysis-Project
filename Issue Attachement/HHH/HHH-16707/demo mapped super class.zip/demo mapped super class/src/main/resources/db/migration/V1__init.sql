CREATE TABLE public.inheriting(
    id VARCHAR(255) PRIMARY KEY,
    name VARCHAR(255)
);