package com.example.demo.package2;

import com.example.demo.package1.Inherited;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "inheriting")
@NoArgsConstructor
@Getter
class Inheriting extends Inherited {

    Inheriting(String id, String name) {
        super(id, name);
    }
}
