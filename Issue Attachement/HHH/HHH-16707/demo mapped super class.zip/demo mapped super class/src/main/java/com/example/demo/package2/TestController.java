package com.example.demo.package2;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/test")
@RestController
@CrossOrigin
@AllArgsConstructor
class TestController {
    private final InheritingRepository repository;

    @PostMapping
    public Inheriting createEntity() {
        return repository.save(
                new Inheriting("id", "name")
        );
    }
}
