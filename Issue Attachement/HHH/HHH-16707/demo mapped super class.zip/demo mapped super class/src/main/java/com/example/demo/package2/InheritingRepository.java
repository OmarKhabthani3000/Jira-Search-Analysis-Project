package com.example.demo.package2;

import org.springframework.data.jpa.repository.JpaRepository;

interface InheritingRepository extends JpaRepository<Inheriting, String> {
}
