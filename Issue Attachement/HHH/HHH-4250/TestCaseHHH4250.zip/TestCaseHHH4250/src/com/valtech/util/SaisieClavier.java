package com.valtech.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class SaisieClavier {
	
	public static Long getLong() {
		Long result = null;
		result = Long.parseLong(lecture());
		return result;
	}
	public static Integer getInteger() {
		Integer result = null;
		result = Integer.parseInt(lecture());
		return result;
	}

	public static String getString() {
		return lecture();
	}

	
	public static void attente() {
		lecture();
	}

	private static String lecture() {
		String result = "";
		try {
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			result = br.readLine();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
