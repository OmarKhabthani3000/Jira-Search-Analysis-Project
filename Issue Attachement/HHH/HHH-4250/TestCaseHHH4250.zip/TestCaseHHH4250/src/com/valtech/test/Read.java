package com.valtech.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.valtech.domaine.Account;
import com.valtech.domaine.Client;
import com.valtech.util.SaisieClavier;
public class Read {

	private EntityManagerFactory emf;
	private EntityManager em;
	private EntityTransaction tx;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("bankPU");
		em = emf.createEntityManager();
		System.out.println("Entity Manager Initialised");
	}

	@Test
	public void readClient() {
		tx = em.getTransaction();
		tx.begin();
		System.out.println("Input Account Number to extract Holders:");

		Account a = (Account)em.createQuery("SELECT a FROM Account a WHERE a.number=:number").setParameter("number", SaisieClavier.getString()).getSingleResult();
		for (Client c : a.getHolders())
		{
			System.out.println(c.getName() + " " + c.getFirstname());
		}
		
		tx.commit();

	}

	@After
	public void tearDown() throws Exception {
		em.close();
		emf.close();
		System.out.println("ressources closed");
	}

}
