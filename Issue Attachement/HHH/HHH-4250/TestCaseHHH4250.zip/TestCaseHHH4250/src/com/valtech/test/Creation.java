package com.valtech.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.valtech.domaine.Account;
import com.valtech.domaine.Client;

public class Creation {

	private EntityManagerFactory emf;
	private EntityManager em;
	private EntityTransaction tx;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("bankPU");
		em = emf.createEntityManager();
		System.out.println("Entity Manager Initialised");
	}

	@Test
	public void createAccount() {

		tx = em.getTransaction();
		tx.begin();
		
		/*
		 * Clients
		 */
		Client c1 = new Client();
		c1.setFirstname("Firstname1");
		c1.setName("Name1");
		c1.setCode("1234");
		c1.setStreet("Street1");
		c1.setCity("City1");
		
		Client c2 = new Client();
		c2.setFirstname("Firstname2");
		c2.setName("Name2");
		c2.setCode("4321");
		c2.setStreet("Street2");
		c2.setCity("City2");
		
		Client c3 = new Client();
		c3.setFirstname("Firstname3");
		c3.setName("Name3");
		c3.setCode("9999");
		c3.setStreet("Street3");
		c3.setCity("City3");
		
		em.persist(c1);
		em.persist(c2);
		em.persist(c3);
		
		/*
		 * Accounts
		 */
		Account a1 = new Account();
		a1.setNumber("1000");
		a1.setBalance(5000);
		a1.addHolder(c1);
		a1.addHolder(c2);
		
		Account a2 = new Account();
		a2.setNumber("1001");
		a2.setBalance(100);
		a2.addHolder(c3);
		
	    em.persist(a1);
	    em.persist(a2);
	    
		tx.commit();
	}

	@After
	public void tearDown() throws Exception {
		em.close();
		emf.close();
		System.out.println("ressources closed");
	}

}
