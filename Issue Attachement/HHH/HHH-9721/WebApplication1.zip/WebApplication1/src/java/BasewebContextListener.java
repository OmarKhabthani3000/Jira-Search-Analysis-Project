
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public final class BasewebContextListener
	implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		HibernateHelper.init();
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		HibernateHelper.shutdown();
	}

	private void setStaticAttributeToNull(Class<?> clazz, String fieldName) {
		try {
			Field field = clazz.getDeclaredField(fieldName);
			if (field != null) {
				field.setAccessible(true);

				Field modifiersField = Field.class.getDeclaredField("modifiers");
				modifiersField.setAccessible(true);
				modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);

				field.set(null, null);
			}
		} catch (IllegalAccessException | NoSuchFieldException | SecurityException ex) {
			// ignorado
		}
	}
}
