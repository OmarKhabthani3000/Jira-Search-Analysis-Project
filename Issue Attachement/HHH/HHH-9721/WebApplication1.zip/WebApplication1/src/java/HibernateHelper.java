
import java.util.logging.Level;
import java.util.logging.Logger;
import org.hibernate.*;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public final class HibernateHelper {
	private static SessionFactory sessionFactory;

	public static SessionFactory init() {
		if (sessionFactory == null) {
			Logger.getLogger(HibernateHelper.class.getName()).log(Level.INFO, "Hibernate init...");

			Configuration hibernateConfig = new Configuration().configure();

			ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
				.applySettings(hibernateConfig.getProperties())
				.build();

			sessionFactory = hibernateConfig.buildSessionFactory(serviceRegistry);

			Logger.getLogger(HibernateHelper.class.getName()).log(Level.INFO, "Hibernate init...OK");
		}

		return sessionFactory;
	}

	public static void shutdown() {
		Logger.getLogger(HibernateHelper.class.getName()).log(Level.INFO, "Hibernate shutdown...");

		if (sessionFactory != null) {
			sessionFactory.close();
			sessionFactory = null;
		}

		Logger.getLogger(HibernateHelper.class.getName()).log(Level.INFO, "Hibernate shutdown...OK");
	}
}
