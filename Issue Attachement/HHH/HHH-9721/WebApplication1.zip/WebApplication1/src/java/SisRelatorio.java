

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;

@Entity
@Table(name = "SIS_RELATORIO")
public class SisRelatorio
	implements Serializable {
	//<editor-fold defaultstate="collapsed" desc="ATRIBUTOS">
	private static final long serialVersionUID = 1L;
	@Id
	@Basic(optional = false)
	@Column(name = "seq_relatorio")
	private Integer seqRelatorio;
	@Column(name = "des_caminho")
	private String desCaminho;
//</editor-fold>

	//<editor-fold defaultstate="collapsed" desc="GETTER/SETTER">
	public Integer getSeqRelatorio() {
		return seqRelatorio;
	}

	public void setSeqRelatorio(Integer seqRelatorio) {
		this.seqRelatorio = seqRelatorio;
	}

	public String getDesCaminho() {
		return desCaminho;
	}

	public void setDesCaminho(String desCaminho) {
		this.desCaminho = desCaminho;
	}
//</editor-fold>

	//<editor-fold defaultstate="collapsed" desc="MÉTODOS PÚBLICOS">
	@Override
	public int hashCode() {
		int hash = 5;
		hash = 29 * hash + Objects.hashCode(getSeqRelatorio());
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are not set
		if (!(object instanceof SisRelatorio)) {
			return false;
		}
		SisRelatorio other = (SisRelatorio) object;
		return Objects.equals(getSeqRelatorio(), other.getSeqRelatorio());
	}

	@Override
	public String toString() {
		return "strategos.baseweb.entities.SisRelatorio[seqRelatorio=" + seqRelatorio + "]";
	}
//</editor-fold>

}
