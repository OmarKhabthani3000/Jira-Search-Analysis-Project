package test;

import static org.junit.Assert.assertEquals;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.exception.GenericJDBCException;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.resource.jdbc.spi.StatementInspector;
import org.hibernate.testing.TestForIssue;
import org.hibernate.testing.junit4.BaseNonConfigCoreFunctionalTestCase;
import org.junit.Test;

import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Test that Oracle dialect generates nationalized string values in CASE statements
 */
public class NStringCaseOracleTest extends BaseNonConfigCoreFunctionalTestCase {

  private final SqlStatementRecorder ssr = new SqlStatementRecorder();

  @Override
  protected Class<?>[] getAnnotatedClasses() {
    return new Class[] { Person.class };
  }

  @SuppressWarnings({ "rawtypes", "unchecked" })
  @Override
  protected void addSettings(Map settings) {
    settings.put(AvailableSettings.USE_NATIONALIZED_CHARACTER_DATA, true);
    settings.put(AvailableSettings.STATEMENT_INSPECTOR, ssr);
    // FIXME explicit connection settings are used for local testing
    settings.put(AvailableSettings.HBM2DDL_AUTO, "create");
    settings.put(AvailableSettings.DRIVER, "oracle.jdbc.driver.OracleDriver");
    settings.put(AvailableSettings.URL, "jdbc:oracle:thin:@localhost:1521:xe");
    settings.put(AvailableSettings.USER, "blueriq10");
    settings.put(AvailableSettings.PASS, "Welcome");
  }

  @Test
  @TestForIssue(jiraKey = "HHH-11622")
  public void testCaseStatementWithNationalizedStringColumn() {
    Session session = openSession();
    ClassMetadata personMetadata = session.getSessionFactory().getClassMetadata(Person.class);
    Query query = session.createQuery(
        "select case p.fName when 'John' then 'x' else 'y' end from " + personMetadata.getEntityName() + " p");
    try {
      query.list();
    } catch (GenericJDBCException gjex) {
      // Locally prints 'Caused by: java.sql.SQLException: ORA-12704: character set mismatch'
      gjex.printStackTrace();
    }
    assertEquals("select case nstringcas0_.fName when n'John' then 'x' else 'y' end as col_0_0_ "
        + "from NStringCaseOracleTest$Person nstringcas0_", ssr.getLastExecutedSql());
  }

  @SuppressWarnings("unused")
  @Entity
  public static class Person {
    @Id
    private Integer id;
    private String fName;
    private String lName;
  }

  private class SqlStatementRecorder implements StatementInspector {
    private static final long serialVersionUID = 1L;

    private String lastExecutedSql = "";

    public String inspect(String sql) {
      lastExecutedSql = sql;

      return sql;
    }

    public String getLastExecutedSql() {
      return lastExecutedSql;
    }
  }
}
