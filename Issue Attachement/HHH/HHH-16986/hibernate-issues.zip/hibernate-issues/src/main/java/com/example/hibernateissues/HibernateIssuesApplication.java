package com.example.hibernateissues;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernateIssuesApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibernateIssuesApplication.class, args);
	}

}
