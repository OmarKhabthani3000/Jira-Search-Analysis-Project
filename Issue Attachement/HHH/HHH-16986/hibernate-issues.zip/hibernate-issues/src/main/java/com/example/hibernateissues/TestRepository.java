package com.example.hibernateissues;

import java.math.BigDecimal;
import java.util.UUID;

import org.springframework.data.jpa.repository.*;

public interface TestRepository extends JpaRepository<TestEntity, UUID> {

	@Query("""
		SELECT test.intField * ?1
		FROM TestEntity test
		""")
	BigDecimal calculateFromEntityField(BigDecimal value);

	@Query("""
		SELECT test.intField * ?1
		FROM TestEntity test
		""")
	Double calculateFromEntityField(double value);

	@Modifying
	@Query("""
		UPDATE TestEntity test
		SET test.bigDecimalField = test.intField * ?1
		""")
	void calculateNewValueForEntityField(BigDecimal value);

	@Modifying
	@Query("""
		UPDATE TestEntity test
		SET test.bigDecimalField = test.intField * ?1
		""")
	void calculateNewValueForEntityField(Double value);

}
