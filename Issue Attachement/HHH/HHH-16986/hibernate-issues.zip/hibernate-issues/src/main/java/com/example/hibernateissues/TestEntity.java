package com.example.hibernateissues;

import java.math.BigDecimal;
import java.util.UUID;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class TestEntity {

	@Id
	@UuidGenerator
	private UUID id;

	private BigDecimal bigDecimalField;
	private Integer intField;

	public TestEntity() {
	}

	public TestEntity(Integer intField) {
		this.intField = intField;
	}

}
