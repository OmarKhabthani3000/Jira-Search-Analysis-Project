package com.example.hibernateissues;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateIssuesApplicationTests {

	private static final BigDecimal BIG_DECIMAL = BigDecimal.valueOf(2.5d);
	private static final double DOUBLE = 2.5d;

	@Autowired
	private TestRepository repository;

	@Test
	void multiplyingIntegerFieldWithBigDecimalParameterThrowsException_ModifyingVersion() {
		repository.save(new TestEntity(2));

		repository.calculateNewValueForEntityField(BIG_DECIMAL);
	}

	@Test
	void multiplyingIntegerFieldWithBigDecimalParameterThrowsException_ReadingVersion() {
		repository.save(new TestEntity(2));

		repository.calculateFromEntityField(BIG_DECIMAL);
	}

	@Test
	void multiplyingIntegerFieldWithDoubleParameterThrowsException_ModifyingVersion() {
		repository.save(new TestEntity(2));

		repository.calculateNewValueForEntityField(DOUBLE);
	}

	@Test
	void multiplyingIntegerFieldWithDoubleParameterThrowsException_ReadingVersion() {
		repository.save(new TestEntity(2));

		repository.calculateFromEntityField(DOUBLE);
	}

}
