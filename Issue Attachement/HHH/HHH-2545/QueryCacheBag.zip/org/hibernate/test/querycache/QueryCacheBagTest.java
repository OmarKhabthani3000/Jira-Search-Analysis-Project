package org.hibernate.test.querycache.bag;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;
import org.hibernate.test.querycache.bag.Item;
import org.hibernate.test.querycache.bag.SubItem;

/**
 * @author Jacek Halat
 */
public class QueryCacheBagTest extends FunctionalTestCase {

	public QueryCacheBagTest(String str) {
		super(str);
	}

	public String[] getMappings() {
		return new String[] { "querycache/bag/SubItem.hbm.xml" };
	}

	public void configure(Configuration cfg) {
		super.configure(cfg);
		cfg.setProperty(Environment.USE_QUERY_CACHE, "true");
		cfg.setProperty(Environment.CACHE_REGION_PREFIX, "foo");
		cfg.setProperty(Environment.USE_SECOND_LEVEL_CACHE, "true");
		cfg.setProperty(Environment.GENERATE_STATISTICS, "true");
	}

	public static Test suite() {
		return new FunctionalTestClassTestSuite(QueryCacheBagTest.class);
	}

	public void testQueryCacheInvalidation() throws Exception {
		getSessions().evictQueries();
		getSessions().getStatistics().clear();

		final String queryString = "select i.subItems from Item i";

		Session s = openSession();
		Transaction t = s.beginTransaction();
		Item i = new Item();
		i.setName("ItemName");

		SubItem subItem = new SubItem();
		subItem.setName("SubItemName");
		subItem.setItem(i);
		i.setSubItems(new ArrayList<SubItem>());
		i.getSubItems().add(subItem);
		s.save(i);
		t.commit();
		s.close();

		Thread.sleep(200);

		s = openSession();
		t = s.beginTransaction();
		List result = s.createQuery(queryString).setCacheable(true).list();
		assertEquals(result.size(), 1);
		SubItem nonCachedSubItem = (SubItem) result.get(0);
		assertNotNull(nonCachedSubItem);

		Item loadedItem = (Item) s.load(Item.class, i.getId());
		assertNotNull(loadedItem);
		assertNotNull(loadedItem.getSubItems());
		assertNotNull(loadedItem.getSubItems().get(0));
		t.commit();
		s.close();

		s = openSession();
		t = s.beginTransaction();
		result = s.createQuery(queryString).setCacheable(true).list();
		assertEquals(result.size(), 1);
		SubItem cachedSubItem = (SubItem) result.get(0);
		assertNotNull(cachedSubItem);
		t.commit();
		s.close();
	}

}
