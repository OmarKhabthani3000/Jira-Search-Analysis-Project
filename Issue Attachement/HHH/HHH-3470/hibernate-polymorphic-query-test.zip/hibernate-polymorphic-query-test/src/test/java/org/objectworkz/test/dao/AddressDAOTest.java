package org.objectworkz.test.dao;

import java.util.List;
import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hsqldb.jdbcDriver;
import org.objectworkz.test.domain.Address;
import org.objectworkz.test.domain.FaxNumber;
import org.objectworkz.test.domain.PhoneNumber;
import org.objectworkz.test.domain.PostalAddress;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.orm.hibernate3.LocalSessionFactoryBean;

import junit.framework.TestCase;

public class AddressDAOTest extends TestCase {
	private AddressDAO addressDAO;
	
	@SuppressWarnings("unchecked")
	public void testFindAddress() throws Exception{
		PhoneNumber phoneNumber = new PhoneNumber();
		phoneNumber.setNumber("0911");
		addressDAO.getHibernateTemplate().save(phoneNumber);

		FaxNumber faxNumber = new FaxNumber();
		faxNumber.setNumber("0911");
		addressDAO.getHibernateTemplate().save(faxNumber);
		
		PostalAddress postalAddress = new PostalAddress();
		postalAddress.setAddressLine("line");
		postalAddress.setName("Jens Laufer");
		postalAddress.setCity("F�rth");
		postalAddress.setPostalCode("0911");
		addressDAO.getHibernateTemplate().save(postalAddress);
		
		List<Address> addresses = addressDAO.getHibernateTemplate().loadAll(Address.class);
		assertEquals(3, addresses.size());
		
		//Now we test the findbyQuery
		//We search for 0911, because it is the number in the number objects and postalCode in the postalAddresst
		addresses = addressDAO.findAddress("0911%");
		assertEquals(3, addresses.size());
		
		
	}
	

	@Override
	protected void setUp() throws Exception {
		addressDAO = new AddressDAO();
		
		LocalSessionFactoryBean localSessionFactoryBean = new LocalSessionFactoryBean();
		SimpleDriverDataSource simpleDriverDataSource = new SimpleDriverDataSource();
		simpleDriverDataSource.setDriverClass(jdbcDriver.class);
		simpleDriverDataSource.setUsername("sa");
		simpleDriverDataSource.setPassword("");
		simpleDriverDataSource.setUrl("jdbc:hsqldb:mem:initial");
		
		localSessionFactoryBean.setDataSource(simpleDriverDataSource);
		localSessionFactoryBean.setMappingLocations(new Resource[]{new FileSystemResource("src/main/resources/Address.hbm.xml")});
		Properties hibernateProperties = new Properties();
		hibernateProperties.put("hibernate.hbm2ddl.auto", "update");
		hibernateProperties.put("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
		localSessionFactoryBean.setHibernateProperties(hibernateProperties);
		localSessionFactoryBean.afterPropertiesSet();
		
		addressDAO.setSessionFactory((SessionFactory)localSessionFactoryBean.getObject());
	}
	
	
	
}
