package org.objectworkz.test.domain;

public class PhoneNumber extends Address {
	private static final long serialVersionUID = 760465574560228755L;
	private String number;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

}
