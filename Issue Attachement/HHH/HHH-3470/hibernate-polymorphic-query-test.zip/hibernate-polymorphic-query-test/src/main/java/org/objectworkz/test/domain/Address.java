package org.objectworkz.test.domain;
import java.io.Serializable;

public abstract class Address implements Serializable {
	private static final long serialVersionUID = -525633382701002922L;
	private long id;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
}
