package org.objectworkz.test.dao;

import java.util.List;

import org.objectworkz.test.domain.Address;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;


public class AddressDAO extends HibernateDaoSupport {

	@SuppressWarnings("unchecked")
	public List<Address> findAddress(String queryStr) {
		String query = "FROM Address WHERE number LIKE :query OR postalCode LIKE :query OR name LIKE :query OR city LIKE :query OR addressLine LIKE :query";
		//String query = "FROM Address address WHERE address.number LIKE :query";

		return getHibernateTemplate().findByNamedParam(query, new String[]{"query"}, new Object[]{queryStr});
	}

}
