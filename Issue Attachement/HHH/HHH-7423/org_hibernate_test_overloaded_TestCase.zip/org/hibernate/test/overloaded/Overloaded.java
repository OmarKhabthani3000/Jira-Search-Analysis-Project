package org.hibernate.test.overloaded;

public class Overloaded extends AbstractOverloaded {

	public void setName(Integer name) {
		super.setName(name.toString());
	}
}
