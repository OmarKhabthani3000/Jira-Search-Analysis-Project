package org.hibernate.test.overloaded;

/**
 * {@inheritDoc}
 *
 * @author Steve Ebersole
 */
public class AbstractOverloaded {
	private Long id;
	private String name;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null || !AbstractOverloaded.class.isAssignableFrom(obj.getClass()))
			return false;
		AbstractOverloaded other = (AbstractOverloaded) obj;
		if(id != null) {
			if(other.getId() == null)
				return false;
			if(!id.equals(other.getId()))
				return false;
		}
		else{
			if(other.getId() != null)
				return false;
		}
		if(name != null) {
			if(other.getName() == null)
				return false;
			if(!name.equals(other.getName()))
				return false;
		}
		else{
			if(other.getName() != null)
				return false;
		}
		return true;
	}
	
	@Override
	public int hashCode() {
		String hstr= new String();
		if(id != null)
			hstr = hstr.concat(id.toString());
		if(name != null)
			hstr = hstr.concat(name);
		return hstr.hashCode();
	}
}
