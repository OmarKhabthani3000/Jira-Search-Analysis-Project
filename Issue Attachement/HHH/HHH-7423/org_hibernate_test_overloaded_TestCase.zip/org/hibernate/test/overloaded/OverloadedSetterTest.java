package org.hibernate.test.overloaded;

import java.lang.reflect.Method;
import java.util.Iterator;

import javassist.util.proxy.MethodFilter;
import javassist.util.proxy.MethodHandler;
import javassist.util.proxy.ProxyFactory;
import junit.framework.Test;

import org.hibernate.Hibernate;
import org.hibernate.PropertyAccessException;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;
import org.hibernate.proxy.HibernateProxy;
import org.hibernate.proxy.pojo.javassist.JavassistLazyInitializer;

/**
 * This test case demos a situation where session.load() throws a PropertyAccessException because 
 * the lazy initialization proxy (when using Javassist) is not able to find a method signature defined in a super class.<p>
 * The object is a domain composed by an abstract class and a concrete class - <b>AbstractOverloaded</b> and <b>Overloaded</b>, respectively.<br>
 * <b>AbstractOverloaded</b> defines the setter method <code>public void setName(String name)</code> which receives a parameter of type String
 * as defined in the <b>Overloaded.hbm.xml</b> mapping.<br><b>Overloaded</b> extends AbstractOverloaded and defines the method 
 * <code>public void setName(<b>Integer</b> name)</code> which overloads the previous method.<p>
 * When the <code>JavassistLazyInitializer</code> loads an instance of Overloaded, the proxy returned throws an exception if you try to execute
 * <code>overloadedProxy.setName("Manuel")</code> because it cannot find the method defined in the AbstractOverloaded (super class) class.<p>
 * When you create a proxy of the Overloaded class by using javassist directly then <code>overloadedProxy.setName("Manuel")</code> works
 * well.<p>
 * @author cemartins (Carlos Martins)
 */
public class OverloadedSetterTest extends FunctionalTestCase {

	public OverloadedSetterTest(String str) {
		super(str);
	}
	
	public String[] getMappings() {
		return new String[] { "overloaded/Overloaded.hbm.xml" };
	}
	
	public void configure(Configuration cfg) {
		cfg.setProperty(Environment.GENERATE_STATISTICS, "true");
	}

	public static Test suite() {
		return new FunctionalTestClassTestSuite( OverloadedSetterTest.class );
	}

	/**
	 * This test builds a javassist proxy of the Overloaded class upon execution of session.load()
	 */
	public void testOverloadedSetter_HibernateLoad() {
		Session session = openSession();
		try {
			session.beginTransaction();
			Overloaded overloadedProxy = new Overloaded();
			overloadedProxy.setName( "whatever" );
			session.save(overloadedProxy);
			session.flush();
			session.clear();
			
			// this automatically creates a javassist proxy through JavassistLazyInitializer
			overloadedProxy = (Overloaded) session.load(Overloaded.class, new Long( overloadedProxy.getId() ) );
			// "o" is now an uninitialized javassist proxy
			assertFalse( Hibernate.isInitialized(overloadedProxy) );

			// fails here (throws PropertyAccessException) because the proxy cannot find the method setName(String) defined in the AbstractOverloaded class.
			overloadedProxy.setName( "Manuel" );

			session.save( overloadedProxy );
			
		}
		catch(PropertyAccessException e) {
			session.getTransaction().rollback();
			fail("proxy did not find the method setName(String) defined in the AbstractOverloaded class");
		}
		catch(IllegalArgumentException e) {
			session.getTransaction().rollback();
			fail();
		}
		catch (Exception e) {
			session.getTransaction().rollback();
		} finally {
			session.close();
		}
	}


	
	/**
	 * This test builds a javassist proxy of the Overloaded class through hibernate's JavassistLazyInitializer
	 */
	public void testOverloadedSetter_Hibernate() {
		Session session = openSession();
		try {
			session.beginTransaction();
			Overloaded o = new Overloaded();
			o.setName( "whatever" );
			session.save(o);
			session.flush();
			session.clear();
			
			Method getIdentifierMethod = Overloaded.class.getMethod("getId", null);
			Method setIdentifierMethod = Overloaded.class.getMethod("setId", new Class[] {Long.class});
			
			Overloaded overloadedProxy = (Overloaded) JavassistLazyInitializer.getProxy(
					Overloaded.class.getName(),
					Overloaded.class,
					new Class[] {HibernateProxy.class},
			        getIdentifierMethod,
					setIdentifierMethod,
			        null,
			        new Long(1),
			        (SessionImplementor) session);

			// fails here (throws PropertyAccessException) because the proxy cannot find the method setName(String) defined in the AbstractOverloaded class.
			overloadedProxy.setName("Manuel");
			System.out.println(overloadedProxy.getClass() + " Name(String) = " + overloadedProxy.getName());

		}
		catch(PropertyAccessException e) {
			session.getTransaction().rollback();
			fail("proxy did not find the method setName(String) defined in the AbstractOverloaded class");
		}
		catch(IllegalArgumentException e) {
			session.getTransaction().rollback();
			fail();
		}
		catch (Exception e) {
			session.getTransaction().rollback();
		} finally {
			session.close();
		}
	}

	
	/**
	 * This test builds a javassist proxy of the Overloaded class with no hibernate intermediaries.<p>
	 * Javassist alone does not present the same problem.
	 */
	public void testOverloadedSetter_Javassist() {
		ProxyFactory factory = new ProxyFactory();
		factory.setSuperclass( Overloaded.class );
		factory.setFilter( new MethodFilter() {
			public boolean isHandled(Method m) {
				// skip finalize methods
				return !( m.getParameterTypes().length == 0 && m.getName().equals( "finalize" ) );
			}
		} );
		Class c = factory.createClass();
		
		MethodHandler mi = new MethodHandler() {

			public Object invoke(Object self, Method thisMethod,
					Method proceed, Object[] args) throws Throwable {
				return proceed.invoke(self, args);
			}
		};
		
		Overloaded overloadedProxy = null;
		try {
			overloadedProxy = (Overloaded) c.newInstance();
			
			((javassist.util.proxy.ProxyObject)overloadedProxy).setHandler(mi);
			
			// This works. The proxy is able to find the method setName(String) defined in the AbstractOverloaded class.
			overloadedProxy.setName("Manuel");
			System.out.println(overloadedProxy.getClass() + " Name(String) = " + overloadedProxy.getName());
			
		} catch (InstantiationException e) {
			fail();
		} catch (IllegalAccessException e) {
			fail();
		}
	}

	protected void cleanup() {
		Session s = openSession();
		s.beginTransaction();
		Iterator itr = s.createQuery( "from Overloaded" ).list().iterator();
		while ( itr.hasNext() ) {
			Overloaded p = (Overloaded) itr.next();
			s.delete( p );
		}
		s.getTransaction().commit();
		s.close();
	}
}