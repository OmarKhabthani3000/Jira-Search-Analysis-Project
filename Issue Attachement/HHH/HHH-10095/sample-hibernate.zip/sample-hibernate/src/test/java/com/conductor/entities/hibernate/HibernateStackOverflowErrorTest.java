package com.conductor.entities.hibernate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import org.hibernate.dialect.Dialect;
import org.hibernate.engine.query.spi.NamedParameterDescriptor;
import org.hibernate.engine.query.spi.ParameterMetadata;
import org.hibernate.engine.spi.QueryParameters;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.internal.AbstractQueryImpl;
import org.hibernate.type.StringType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class HibernateStackOverflowErrorTest {
    @Mock private SessionImplementor session;
    @Mock private ParameterMetadata metadata;
    @Mock private NamedParameterDescriptor namedParameterDescriptor;
    @Mock private SessionFactoryImplementor sessionFactory;

    private MockQueryImpl tested;
    
    @Before
    public void setUp() throws Exception {
        tested = new MockQueryImpl("select from o where o.f in ( :name ) or o.f in ( :name_0 )", session, metadata);

        // Need to change namedParameterLists map to the one which returns parameters in the same order each time to simplify bug reproduction
        Field namedParameterListsField = AbstractQueryImpl.class.getDeclaredField("namedParameterLists");
        namedParameterListsField.setAccessible(true);
        namedParameterListsField.set(tested, new TreeMap(Collections.reverseOrder()));
        
        when(metadata.getNamedParameterNames()).thenReturn(new HashSet(Arrays.asList("name", "name_0")));
        when(metadata.getNamedParameterDescriptor(anyString())).thenReturn(namedParameterDescriptor);
        when(namedParameterDescriptor.isJpaStyle()).thenReturn(false);
        when(session.getFactory()).thenReturn(sessionFactory);
        when(sessionFactory.getDialect()).thenReturn(new Dialect() { });
    }

    @Test
    public void expandParameterListsTriggeresStackOverflowError() {
        StringType type = new StringType();
        tested.setParameterList("name", generateValues(2, "name"), type);
        tested.setParameterList("name_0", generateValues(1024 * 15, "name_0"), type);

        // need to be sure that 'name_0' (long list) will be expanded first
        Iterator<Entry<?, ?>> iterator = ((Set<Map.Entry<?, ?>>)tested.getNamedParameterLists().entrySet()).iterator();
        assertEquals("name_0", iterator.next().getKey());
        assertEquals("name", iterator.next().getKey());

        // actually list method fails with StackOverflowError which happens within AbstractQueryImpl.expandParameterLists(Map) method
        assertNotNull(tested.list());

        ArgumentCaptor<String> queryCapturer = ArgumentCaptor.forClass(String.class);
        verify(session).list(queryCapturer.capture(), any(QueryParameters.class));

        assertNotNull(queryCapturer.getValue());
    }

    private List<String> generateValues(int num, String prefix) {
        List<String> result = new ArrayList<String>(num);
        for (int i = 0; i < num; i++) {
            result.add(prefix + "-" + Integer.toHexString(i));
        }
        return result;
    }

    private static class MockQueryImpl extends org.hibernate.internal.QueryImpl {

        public MockQueryImpl(String queryString, SessionImplementor session, ParameterMetadata parameterMetadata) {
            super(queryString, session, parameterMetadata);
            // TODO Auto-generated constructor stub
        }

        @Override public Map getNamedParameterLists() { return super.getNamedParameterLists(); }
        @Override protected void verifyParameters() { }
        @Override protected void before() { }
        @Override protected void after() { }
        @Override public boolean isReadOnly() { return true; }
    }
}
