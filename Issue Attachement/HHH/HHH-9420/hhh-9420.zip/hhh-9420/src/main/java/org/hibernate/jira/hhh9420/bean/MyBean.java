/**
 * Copyright (C) 2014 by Genigraph
 * All rights reserved.
 *
 * All usage rights are governed by the applicable Genigraph agreement.
 */
package org.hibernate.jira.hhh9420.bean;

public class MyBean
{
   private String value;

   private Integer id;

   public MyBean()
   {
   }

   public String getValue()
   {
      return value;
   }

   public void setValue(final String value)
   {
      this.value = value;
   }

   public Integer getId()
   {
      return id;
   }

   public void setId(final Integer id)
   {
      this.id = id;
   }
}
