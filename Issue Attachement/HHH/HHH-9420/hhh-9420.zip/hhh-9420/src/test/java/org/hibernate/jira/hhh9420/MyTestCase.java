package org.hibernate.jira.hhh9420;

import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.jira.hhh9420.bean.MyBean;

import junit.framework.TestCase;

public class MyTestCase extends TestCase
{
   private EntityManagerFactory emf;

   @Override
   protected void setUp() throws Exception
   {
      emf = Persistence.createEntityManagerFactory("my-pu");
   }

   @Override
   protected void tearDown() throws Exception
   {
      emf.close();
   }

   public void testHHH9420() throws Exception
   {
      final EntityManager em = emf.createEntityManager();
      em.getTransaction().begin();
      final MyBean o = new MyBean();
      o.setValue(UUID.randomUUID().toString());
      em.persist(o);
      em.getTransaction().commit();
      em.close();
   }
}
