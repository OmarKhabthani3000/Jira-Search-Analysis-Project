package org.permacode;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BugCompositeKeyTest
{
    private static final String JDBC_PASSWORD = "";

    private static final String JDBC_USERNAME = "";

    private static final String JDBC_DRIVER =
        "org.apache.derby.jdbc.EmbeddedDriver";

    private static final String JDBC_ATOMIC_TEST =
        "jdbc:derby:derby_db;create=true;derby.system.durability=test";

    private EntityManagerFactory entityManagerFactory;

    private Connection connection;

    private Statement statement;

    @Before
    public void start() throws Exception
    {
        startDatabase();
        //toplink("TestToplink", "Derby");
        hibernate("TestHibernate", "org.hibernate.dialect.DerbyDialect");
        // openJpa("TestOpenJPA",
        // "org.apache.openjpa.jdbc.sql.DerbyDictionary");
    }

    @After
    public void tearDown() throws SQLException
    {
        if (statement != null)
            statement.close();
        if (connection != null)
            connection.close();
    }

    public void startDatabase() throws Exception
    {
        Class.forName(JDBC_DRIVER);
        connection =
            DriverManager.getConnection(JDBC_ATOMIC_TEST, JDBC_USERNAME,
                JDBC_PASSWORD);
        statement = connection.createStatement();
        if (isSchemaSetup(connection, "DEV"))
        {
            killSchema(connection, "DEV");
        }
        statement.execute("create schema DEV");
        statement.execute("set schema DEV");
        statement
            .execute("create table HABITAT_SPECIES_LINK ("
                + "HABITAT_ID integer not null,"
                + "SPECIES_ID integer not null,"
                + "constraint HABITAT_SPECIES_LINK_PK primary key (HABITAT_ID, SPECIES_ID)"
                + ") ");
        statement.execute("insert into HABITAT_SPECIES_LINK "
            + "(HABITAT_ID, SPECIES_ID) values (123, 234)");
    }

    @SuppressWarnings("unused")
    private void openJpa(String persistenceUnit, String dialect)
    {
        Map map = new HashMap();
        map.put("openjpa.jdbc.DBDictionary", dialect);
        map.put("openjpa.jdbc.SchemaFactory", "native(ForeignKeys=true)");
        map.put("openjpa.ConnectionURL", JDBC_ATOMIC_TEST);
        map.put("openjpa.ConnectionDriverName", JDBC_DRIVER);
        map.put("openjpa.ConnectionUserName", JDBC_USERNAME);
        map.put("openjpa.ConnectionPassword", JDBC_PASSWORD);
        entityManagerFactory =
            Persistence.createEntityManagerFactory(persistenceUnit, map);
    }

    @SuppressWarnings("unused")
    private void toplink(String persistenceUnit, String dialect)
    {
        Map map = new HashMap();
        map.put("toplink.logging.level", "FINEST");
        map.put("toplink.target-database", dialect);
        map.put("toplink.jdbc.url", JDBC_ATOMIC_TEST);
        map.put("toplink.jdbc.driver", JDBC_DRIVER);
        map.put("toplink.jdbc.user", JDBC_USERNAME);
        map.put("toplink.jdbc.password", JDBC_PASSWORD);
        entityManagerFactory =
            Persistence.createEntityManagerFactory(persistenceUnit, map);
    }

    @SuppressWarnings("unused")
    private void hibernate(String persistenceUnit, String dialect)
    {
        Map map = new HashMap();
        map.put("hibernate.dialect", dialect);
        map.put("hibernate.show_sql", "true");
        map.put("hibernate.connection.url", JDBC_ATOMIC_TEST);
        map.put("hibernate.connection.driver_class", JDBC_DRIVER);
        map.put("hibernate.connection.username", JDBC_USERNAME);
        map.put("hibernate.connection.password", JDBC_PASSWORD);
        entityManagerFactory =
            Persistence.createEntityManagerFactory(persistenceUnit, map);
    }

    public boolean isSchemaSetup(Connection connection, String schema)
        throws SQLException
    {
        DatabaseMetaData metaData = connection.getMetaData();
        ResultSet rs = metaData.getSchemas();
        while (rs.next())
        {
            System.out.println("Schema " + rs.getString("TABLE_SCHEM"));
        }
        rs.close();
        rs = metaData.getTables(null, schema, null, new String[] { "TABLE" });
        boolean hasTables = false;
        while (rs.next())
        {
            System.out.println("Schema " + schema + " has table '"
                + rs.getString("TABLE_NAME") + "'");
            hasTables = true;
        }
        rs.close();
        return hasTables;
    }

    public void killSchema(Connection connection, String schema)
        throws SQLException
    {
        DatabaseMetaData metaData = connection.getMetaData();
        ResultSet rs =
            metaData.getTables(null, schema, null, new String[] { "TABLE" });
        if (schema == null)
            schema = "";
        if (schema != null && schema.length() > 0)
            schema += ".";
        while (rs.next())
        {
            statement.executeUpdate("drop table " + schema
                + rs.getString("TABLE_NAME"));
        }
        rs.close();
        statement.executeUpdate("drop schema DEV restrict");
    }

    @Test
    public void testCompositeKey() throws Exception
    {
        EntityManager entityManager =
            entityManagerFactory.createEntityManager();
        Query query =
            entityManager
                .createNativeQuery("select * from DEV.HABITAT_SPECIES_LINK");
        List result = query.getResultList();
        Assert.assertNotNull("should have a list", result);
        Assert.assertTrue("should have one item", result.size() == 1);
        HabitatSpeciesLink.HabitatSpeciesLinkId id =
            new HabitatSpeciesLink.HabitatSpeciesLinkId();
        id.setHabitatId(new Long(123));
        id.setSpeciesId(new Long(234));
        HabitatSpeciesLink entity =
            entityManager.find(HabitatSpeciesLink.class, id);
        Assert.assertNotNull("should have entity with composite key", entity);
    }
}
