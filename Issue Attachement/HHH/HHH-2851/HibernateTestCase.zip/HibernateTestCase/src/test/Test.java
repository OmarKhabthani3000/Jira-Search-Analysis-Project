package test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
	@SuppressWarnings ("unchecked")
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("testDatabase");
		EntityManager em = emf.createEntityManager();
		List<A> l = em.createNamedQuery("A.test")
				.setParameter("param", null)
				.getResultList();
		for (A a : l) {
			System.out.println(a.getParam());
		}
	}
}
