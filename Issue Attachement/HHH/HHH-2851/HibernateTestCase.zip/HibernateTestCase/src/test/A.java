package test;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery (name = "A.test", query = "FROM A a WHERE :param IS NULL OR a.param = :param")
public class A implements Serializable {
	@Id
	private Long id;
	private Long param;

	public Long getId() {
		return id;
	}
	public Long getParam() {
		return param;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setParam(Long param) {
		this.param = param;
	}
}
