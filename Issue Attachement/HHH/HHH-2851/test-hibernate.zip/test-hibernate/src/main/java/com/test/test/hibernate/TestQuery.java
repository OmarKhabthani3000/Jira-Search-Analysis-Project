/**
 * Copyright (c) 2015 Impact Mobile Inc.
 */
package com.test.test.hibernate;

import java.sql.Date;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Singleton
@Startup
public class TestQuery
{
    @PersistenceContext( name = "testDatabase" )
    EntityManager entityManager;

    @PostConstruct
    public void test()
    {

        // this will work
        Query query = entityManager
            .createQuery( "SELECT f FROM TestEntity f WHERE (:namedParam = f.val OR :namedParam IS NULL)" )
            .setParameter( "namedParam", null );

        query.getResultList();

        // this will not
        query = entityManager
            .createQuery( "SELECT f FROM TestEntity f WHERE (:namedParam IS NULL OR :namedParam = f.val)" )
            .setParameter( "namedParam", null );

        query.getResultList();
    }

}
