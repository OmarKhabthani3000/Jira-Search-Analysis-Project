/**
 * Copyright (c) 2015 Impact Mobile Inc.
 */
package com.test.test.hibernate;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table( name = "TEST" )
public class TestEntity
{
    @Column
    @Id
    private Date val;

    /**
     * @return the val
     */
    public Date getVal()
    {
        return val;
    }

    /**
     * @param val the val to set
     */
    public void setVal( Date val )
    {
        this.val = val;
    }

}
