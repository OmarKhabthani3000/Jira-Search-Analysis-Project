


public class Partner extends Person {}
