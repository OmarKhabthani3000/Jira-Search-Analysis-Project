

import junit.framework.TestCase;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class TestSubclassRetrieval extends TestCase {
	
	Logger log = Logger.getLogger(TestSubclassRetrieval.class);
	
	private static SessionFactory sessionFactory;
	private static Session session;
	
    protected void setUp() throws Exception {
        super.setUp();
        sessionFactory = null;
        Session session = getSession();
        
        session.connection().prepareStatement("drop table if exists people").execute();
        session.connection().prepareStatement("create table people (id int identity primary key, type_id int not null, name varchar(64))").execute();
        
        Client client = new Client();
        client.setName("Test Case - " + System.currentTimeMillis());
        session.save(client);
        log.info("Client created: " + client.getId() + " - " + client.getName());
        session.flush();
        session.close();
        
    }
    
    protected void tearDown() throws Exception {
        super.tearDown();
        getSession().close();
    }

	
	public void testCachedGet() throws Exception {
        Client client = (Client) getSession().get(Client.class, 0);
        assertNotNull(client);
        
        // this should be null, not return a Client object (resulting in a ClassCastException)
		Partner partner = (Partner) getSession().get(Partner.class, 0);
		assertNull(partner);
	}
    
    public void testUncachedGet() throws Exception {
        Partner partner = (Partner) getSession().get(Partner.class, 0);
        assertNull(partner);
    }
	
	private Session getSession() {
		if (session == null || !session.isOpen() ) {
			if (sessionFactory == null) {
				Configuration cfg = new Configuration()
						.addClass(Person.class)
						.setProperty("hibernate.connection.driver_class","org.hsqldb.jdbcDriver")
						.setProperty("hibernate.connection.url","jdbc:hsqldb:/tmp/test")
						.setProperty("hibernate.connection.username", "sa").setProperty("hibernate.connection.password", "")
						.setProperty("hibernate.dialect","org.hibernate.dialect.HSQLDialect")
						.setProperty("hibernate.connection.autocommit", "false")
						.setProperty("show_sql", "true");
				sessionFactory = cfg.buildSessionFactory();
			}
			session = sessionFactory.openSession();
		}
		return session;
	}
}
