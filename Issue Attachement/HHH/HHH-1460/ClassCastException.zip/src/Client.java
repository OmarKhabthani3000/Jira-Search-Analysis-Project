


public class Client extends Person {}
