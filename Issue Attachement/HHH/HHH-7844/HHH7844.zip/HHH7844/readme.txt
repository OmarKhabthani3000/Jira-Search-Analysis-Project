1. Open as a project in Eclipse
2. Add stardard Hibernate and H2 jars to the classpath
3. Execute hhh7844.HHH7844Test with a JUnit runner