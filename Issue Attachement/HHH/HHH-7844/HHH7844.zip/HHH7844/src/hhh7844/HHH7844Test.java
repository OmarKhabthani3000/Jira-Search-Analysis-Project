package hhh7844;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.Test;

/**
 * @author karol.bienkowski@syncron.com, 2012-12-03
 */
public class HHH7844Test {

	@Test
	public void batchedUpdateShouldNotProduceTheHHH000381Warning() {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("test");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();

		tx.begin();

		SampleEntity ent1 = new SampleEntity(1);
		SampleEntity ent2 = new SampleEntity(2);

		em.persist(ent1);
		em.persist(ent2);

		/*
		 * These two updates cause: WARN: HHH000381: JDBC driver did not return the expected number of row counts
		 */
		ent1.field1 = "ee";
		ent2.field2 = "ef";

		tx.commit();

	}

}
