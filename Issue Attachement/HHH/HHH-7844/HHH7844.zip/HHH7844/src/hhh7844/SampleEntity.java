package hhh7844;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@org.hibernate.annotations.Entity(dynamicUpdate = true)
public class SampleEntity {

	@Id
	public int id;
	public String field1;
	public String field2;

	public SampleEntity() {
	}

	public SampleEntity(int id) {
		this.id = id;
	}

}
