//$Id: DynamicMapOneToOneTest.java 10977 2006-12-12 23:28:04Z steve.ebersole@jboss.com $
package org.hibernate.test.onetoone;

import java.math.BigDecimal;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

/**
 * @author Gavin King
 */
public class OneToOneTest
{
    
    @Test
    public void testOneToOnePropertyRef()
    {
        Person person = new Person();
        person.setId(new BigDecimal(1));
        person.setName("hyj");
        
        Address address = new Address();
        address.setId(new BigDecimal(1));
        address.setName("mars");
        person.setAddress(address);
        
        Session s = openSession();
        s.beginTransaction();
        s.save("Person", person);
        s.getTransaction().commit();
        s.close();
        
        s = openSession();
        s.beginTransaction();
        person = (Person)s.load("Person", new BigDecimal(1)); //$NON-NLS-1$
        address = person.getAddress();
        person.setAddress(null);
        s.delete(address);
        s.delete(person);
        s.getTransaction().commit();
        s.close();
    }
    
    /**
     * TODO 添加方法注释
     * @return
     */
    private Session openSession()
    {
        Configuration configuration = new Configuration();
        configuration.configure("/hibernate.cfg.xml");
        
        org.hibernate.SessionFactory sessionFactory = configuration.buildSessionFactory();
        return sessionFactory.openSession();
    }
    
}
