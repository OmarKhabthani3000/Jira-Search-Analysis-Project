package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
public class Foo
{
   @Id
   private Long id;

   @OneToOne(optional = true)
   @PrimaryKeyJoinColumn()
   private Bar bar;

}
