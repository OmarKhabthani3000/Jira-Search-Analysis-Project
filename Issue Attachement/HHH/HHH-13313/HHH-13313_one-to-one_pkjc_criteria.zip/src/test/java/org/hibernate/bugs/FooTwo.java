package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
public class FooTwo
{
   @Id
   private Long id;

   @OneToOne(optional = false)
   @PrimaryKeyJoinColumn()
   private Bar bar;

}
