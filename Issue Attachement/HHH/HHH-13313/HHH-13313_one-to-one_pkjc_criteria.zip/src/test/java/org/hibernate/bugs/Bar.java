package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Bar
{
   @Id
   private Long id;
}
