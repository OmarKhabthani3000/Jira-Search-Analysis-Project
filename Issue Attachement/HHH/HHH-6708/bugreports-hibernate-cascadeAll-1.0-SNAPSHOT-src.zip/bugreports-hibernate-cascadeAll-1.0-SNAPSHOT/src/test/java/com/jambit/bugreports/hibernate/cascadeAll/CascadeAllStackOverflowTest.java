package com.jambit.bugreports.hibernate.cascadeAll;

import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.junit.Test;

public class CascadeAllStackOverflowTest {

	@Test
	public void testStoreAndLoad() throws Exception {
		Configuration cfg = new Configuration().addAnnotatedClass(Parent.class).addAnnotatedClass(Child.class)
				.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect")
				.setProperty("hibernate.hbm2ddl.auto", "create")
				.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver")
				.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:aname")
				.setProperty("hibernate.connection.username", "sa")
				.setProperty("hibernate.connection.password", "");

		Session session = cfg.buildSessionFactory().openSession();

		Parent parent = new Parent();
		parent.id = 1l;
		parent.setChild(new Child());

		session.save(parent);
		session.flush();
		
		// this forces the following load to access the DB
		session.evict(parent);

		Parent loadedParent = (Parent) session.load(Parent.class, 1l);
		System.out.println(loadedParent);
	}
	
}
