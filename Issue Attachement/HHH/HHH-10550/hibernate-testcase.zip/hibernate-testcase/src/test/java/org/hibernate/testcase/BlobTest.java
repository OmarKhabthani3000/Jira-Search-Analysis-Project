package org.hibernate.testcase;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;

import org.hibernate.engine.jdbc.NonContextualLobCreator;
import org.junit.Test;

import junit.framework.TestCase;

public class BlobTest extends TestCase {

	@Test
	public void testBlob() throws SQLException {
		InputStream dummy = new ByteArrayInputStream("asd".getBytes());

		// Works as expected
		Blob blob = NonContextualLobCreator.INSTANCE.createBlob(dummy, Integer.MAX_VALUE - 100);
		assertTrue("Length of a blob should be a positive number. Found: " + blob.length(), blob.length() > 0);

		// Now the length becomes a negative number
		blob = NonContextualLobCreator.INSTANCE.createBlob(dummy, Integer.MAX_VALUE + 100);
		assertTrue("Length of a blob should be a positive number. Found: " + blob.length(), blob.length() > 0);
	}

}
