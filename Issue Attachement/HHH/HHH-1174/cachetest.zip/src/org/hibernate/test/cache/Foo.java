package org.hibernate.test.cache;
/**
 * 
 */

/**
 * @author kjozsa
 */
public class Foo {
    private long id;
    private Bar bar;
    
    /**
     * Getter of the field bar.
     * @return Returns the bar.
     */
    public Bar getBar() {
        return bar;
    }
    /**
     * Setter of the field bar.
     * @param bar The bar to set.
     */
    public void setBar(Bar bar) {
        this.bar = bar;
    }
    /**
     * Getter of the field id.
     * @return Returns the id.
     */
    public long getId() {
        return id;
    }
    /**
     * Setter of the field id.
     * @param id The id to set.
     */
    public void setId(long id) {
        this.id = id;
    }
    
}
