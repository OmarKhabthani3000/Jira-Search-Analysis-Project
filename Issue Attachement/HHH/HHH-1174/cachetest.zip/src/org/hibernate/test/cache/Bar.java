/**
 * 
 */
package org.hibernate.test.cache;

/**
 * @author kjozsa
 */
public class Bar {
    private long id;
    private Foo foo;
    
    
    /**
     * Getter of the field foo.
     * @return Returns the foo.
     */
    public Foo getFoo() {
        return foo;
    }
    /**
     * Setter of the field foo.
     * @param foo The foo to set.
     */
    public void setFoo(Foo foo) {
        this.foo = foo;
    }
    /**
     * Getter of the field id.
     * @return Returns the id.
     */
    public long getId() {
        return id;
    }
    /**
     * Setter of the field id.
     * @param id The id to set.
     */
    public void setId(long id) {
        this.id = id;
    }
    
    
    
}
