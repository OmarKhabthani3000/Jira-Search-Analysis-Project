/**
 * 
 */
package org.hibernate.test.cache;

import java.util.List;

import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

/**
 * @author kjozsa
 */
public class CacheTest extends TestCase {
    
    private Configuration configuration;
    private SessionFactory sessionFactory;

    public void testCache() throws Exception {
        for (int i = 0; i < 5; i++) {
            Session session = sessionFactory.openSession();
            Query query = session.createQuery("from Foo foo");
            query.setCacheable(true);
            List results = query.list();
            
            assertEquals(1, results.size());
            // Foo foo = (Foo) results.get(0);
            // assertNotNull(foo.getBar().getFoo());
            
            session.close();
            System.out.println("-----");
            Thread.sleep(1000);
        }
        
    }
    
    /**
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        configuration = new Configuration()
            .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQLInnoDBDialect")
            .setProperty("hibernate.connection.driver_class", "com.mysql.jdbc.Driver")
            .setProperty("hibernate.connection.url", "jdbc:mysql://localhost/test")
            .setProperty("hibernate.connection.username", "root")
            .setProperty("hibernate.show_sql", "true")
            .setProperty("hibernate.use_sql_comments", "true")
            
            .setProperty("hibernate.cache.provider_class", "org.hibernate.cache.EhCacheProvider")
            .setProperty("hibernate.cache.use_query_cache", "true")
            
            .addClass(Foo.class)
            .addClass(Bar.class)
        ;
        
        sessionFactory = configuration.buildSessionFactory();
        new SchemaExport(configuration).create(true, true);
        
        // save test data
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        
        Foo foo = new Foo();
        Bar bar = new Bar();
        foo.setBar(bar);
        bar.setFoo(foo);
        session.save(foo);
        session.save(bar);
        
        tx.commit();
        session.close();
        
    }
    
    /**
     * @see junit.framework.TestCase#tearDown()
     */
    protected void tearDown() throws Exception {
        new SchemaExport(configuration).drop(true, true);
    }
    
}
