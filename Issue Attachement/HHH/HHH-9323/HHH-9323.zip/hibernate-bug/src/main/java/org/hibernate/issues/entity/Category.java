package org.hibernate.issues.entity;

import java.io.Serializable;
import javax.persistence.*;

@Entity(name = Category.ENTITY_NAME)
@Table(name = Category.ENTITY_NAME + "S")
public class Category implements Serializable {

    public static final String ENTITY_NAME = "CATEGORY";
    private static final long serialVersionUID = 0;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private boolean visible = true;

    public long getId() {
        return id;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }
}
