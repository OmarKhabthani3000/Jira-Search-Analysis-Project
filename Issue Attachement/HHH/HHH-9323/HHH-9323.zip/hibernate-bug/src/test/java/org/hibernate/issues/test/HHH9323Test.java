package org.hibernate.issues.test;

import org.junit.Test;

import javax.persistence.Persistence;

public class HHH9323Test {

    private void builder() {
        Persistence.createEntityManagerFactory("HHH-9323").close();
    }
    
    @Test
    public void testPass1() {
        builder();
    }

    @Test
    public void testPass2() {
        builder();
    }

}
