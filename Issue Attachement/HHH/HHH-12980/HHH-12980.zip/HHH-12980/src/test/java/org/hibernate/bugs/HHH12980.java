/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import static org.junit.Assert.assertEquals;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OptimisticLockException;
import javax.persistence.Version;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

public class HHH12980 extends BaseCoreFunctionalTestCase {

	@Override
	protected Class<?>[] getAnnotatedClasses() {
		return new Class[] { Company.class };
	}

	@Override
	protected void configure(Configuration configuration) {
		super.configure(configuration);
		configuration.setProperty(AvailableSettings.SHOW_SQL, Boolean.TRUE.toString());
		configuration.setProperty(AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString());
	}

	@Test(expected = OptimisticLockException.class)
	public void testManagedEntity() throws Exception {
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		Company company = new Company();
		assertEquals(-1, company.getVersion());
		company.setName("a");
		s.save(company);
		tx.commit();
		tx = s.beginTransaction();
		assertEquals(0, company.getVersion());
		company.setName("b");
		s.update(company);
		tx.commit();
		tx = s.beginTransaction();
		assertEquals(1, company.getVersion());
		company.setName("c");
		company.setVersion(company.getVersion() - 1); // simulate pass version from UI form
		s.update(company);
		tx.commit();
		tx = s.beginTransaction();
		assertEquals(2, company.getVersion());
		s.close();
	}

	@Test(expected = OptimisticLockException.class)
	public void testDetachedEntity() throws Exception {
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		Company company = new Company();
		assertEquals(-1, company.getVersion());
		company.setName("a");
		s.save(company);
		tx.commit();
		s.close();
		s = openSession();
		tx = s.beginTransaction();
		assertEquals(0, company.getVersion());
		company.setName("b");
		s.update(company);
		tx.commit();
		s.close();
		s = openSession();
		tx = s.beginTransaction();
		assertEquals(1, company.getVersion());
		company.setName("c");
		company.setVersion(company.getVersion() - 1); // simulate pass version from UI form
		s.update(company);
		tx.commit();
		assertEquals(2, company.getVersion());
		s.close();
	}

	@Entity
	public static class Company {

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private Long id;

		private String name;

		@Version
		private int version = -1;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public int getVersion() {
			return version;
		}

		public void setVersion(int version) {
			this.version = version;
		}

	}

}
