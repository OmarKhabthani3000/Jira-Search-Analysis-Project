package simplecase;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class EntityManagerProvider {

    private static final String PERSISTENCE_UNIT = "simplecase.persistence";
    private static final String USER_PROPERTY = "javax.persistence.jdbc.user";
    private static final String PASSWORD_PROPERTY = "javax.persistence.jdbc.password";

    private static final Map<String, EntityManagerFactory> managerFactories = new HashMap<String, EntityManagerFactory>();

    private static String user;
    private static String password;
    
    //Since this class provides only static methods, do not allow this class to be instantiated.
    private EntityManagerProvider() {
        super();
    }

    private static ThreadLocal<EntityManager> localMgr = new ThreadLocal<EntityManager>() {

        protected EntityManager initialValue() {

            EntityManagerFactory f = managerFactories.get(user);

            if (f == null) {
                //A factory with the provided username does not yet exist, create a factory.
                Properties p = new Properties();
                p.setProperty(USER_PROPERTY, user);
                p.setProperty(PASSWORD_PROPERTY, password);

                f = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT, p);
                EntityManager em = f.createEntityManager();

                //A connection has been established with the provided credentials, save the factory.
                managerFactories.put(user, f);
                return em;
            }
            
            return null;
        }
    };

    public static EntityManager getEntityManager(String usr, String pass)
    {
        user = usr;
        password = pass;
        return localMgr.get();
    }
}


