package simplecase;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.SimpleCase;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import simplecase.customer.Customer;
import simplecase.customer.Customer_;


public class Main {

    /**
     * @param args
     */
    public static void main(String[] args) {
        EntityManager em = EntityManagerProvider.getEntityManager("user", "passw0rd");
        CriteriaBuilder builder = em.getCriteriaBuilder();
        
        CriteriaQuery<Customer> query = builder.createQuery(Customer.class);
        Root<Customer> root = query.from(Customer.class);
        query.select(root);

        SimpleCase<String, Integer> orderCase = builder.selectCase(root.get(Customer_.EMail));
        orderCase = orderCase.when("test@test.com", 1);
        orderCase = orderCase.when("test2@test.com", 2);
        
        query.orderBy(builder.asc(orderCase.otherwise(0)));
        
        em.createQuery(query);
                
    }

}
