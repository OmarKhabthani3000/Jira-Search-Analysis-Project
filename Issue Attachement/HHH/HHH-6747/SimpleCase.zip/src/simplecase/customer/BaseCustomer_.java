package simplecase.customer;

import java.util.Date;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(BaseCustomer.class)
public class BaseCustomer_ {

    public static volatile SingularAttribute<BaseCustomer, Integer> customerId;

    public static volatile SingularAttribute<BaseCustomer, String> EMail;

    public static volatile SingularAttribute<BaseCustomer, String> name;

    public static volatile SingularAttribute<BaseCustomer, String> webSite;

    public static volatile SingularAttribute<BaseCustomer, String> insertUser;

    public static volatile SingularAttribute<BaseCustomer, Date> insertDateTime;

    public static volatile SingularAttribute<BaseCustomer, String> updateUser;

    public static volatile SingularAttribute<BaseCustomer, Date> updateDateTime;

}


