package simplecase.customer;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "customer")
public class Customer extends BaseCustomer {

    private static final long serialVersionUID = 446363938565782L;

    @Override
    public int hashCode() {
        int hash = 0;
        hash = hash + (31 * (customerId != null ? customerId.hashCode() : 0))^1;
        return hash;
    }

    @Override
    public boolean equals(Object other) {
        if (other == null) 
            return false;
        if (!(other instanceof Customer)) 
            return false;

        Customer otherN = (Customer)other;
        if (otherN.customerId == null && customerId != null) return false;
        if (otherN.customerId != null && customerId == null) return false;
        if (otherN.customerId != null && !otherN.customerId.equals(customerId)) return false;

        return true;
    }

}


