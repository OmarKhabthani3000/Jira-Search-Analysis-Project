package simplecase.customer;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

@MappedSuperclass
public abstract class BaseCustomer implements Serializable {

    private static final long serialVersionUID = 154181689966783L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Generated(value = GenerationTime.INSERT)
    @Column(name = "customer_id", nullable = false)
    protected Integer customerId;

    public Integer getCustomerId() {
        return customerId;    
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId; 
    }

    @Column(name = "e_mail", nullable = false)
    protected String EMail;

    public String getEMail() {
        return EMail;    
    }

    public void setEMail(String EMail) {
        this.EMail = EMail; 
    }

    @Column(name = "name", nullable = false)
    protected String name;

    public String getName() {
        return name;    
    }

    public void setName(String name) {
        this.name = name; 
    }

    @Column(name = "web_site", nullable = true)
    protected String webSite;

    public String getWebSite() {
        return webSite;    
    }

    public void setWebSite(String webSite) {
        this.webSite = webSite; 
    }

    @Column(name = "insert_user", nullable = true)
    protected String insertUser;

    public String getInsertUser() {
        return insertUser;    
    }

    public void setInsertUser(String insertUser) {
        this.insertUser = insertUser; 
    }

    @Column(name = "insert_date_time", nullable = true)
    protected Date insertDateTime;

    public Date getInsertDateTime() {
        return insertDateTime;    
    }

    public void setInsertDateTime(Date insertDateTime) {
        this.insertDateTime = insertDateTime; 
    }

    @Column(name = "update_user", nullable = true)
    protected String updateUser;

    public String getUpdateUser() {
        return updateUser;    
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser; 
    }

    @Column(name = "update_date_time", nullable = true)
    protected Date updateDateTime;

    public Date getUpdateDateTime() {
        return updateDateTime;    
    }

    public void setUpdateDateTime(Date updateDateTime) {
        this.updateDateTime = updateDateTime; 
    }
}


