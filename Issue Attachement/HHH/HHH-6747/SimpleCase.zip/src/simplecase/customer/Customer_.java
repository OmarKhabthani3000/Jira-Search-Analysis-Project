package simplecase.customer;

import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(Customer.class)
public class Customer_ extends BaseCustomer_ {

}


