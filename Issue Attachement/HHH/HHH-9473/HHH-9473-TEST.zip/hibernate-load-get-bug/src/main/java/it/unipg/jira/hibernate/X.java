package it.unipg.jira.hibernate;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

/**
 * @author Giulio Quaresima (giulio.quaresima@gmail.com)
 *
 */
@Entity
@Table (name = "X", schema = "PUBLIC")
public class X implements Serializable
{
	private static final long serialVersionUID = -7750404757345343565L;

	private Integer id;
	private String name;
	private String description;
	private Set<Y> yyy = new HashSet<Y>();
	
	public X()
	{
		super();
	}
	
	@Id
	@Column (name = "ID")
	public Integer getId()
	{
		return id;
	}
	public void setId(Integer id)
	{
		this.id = id;
	}
	
	@Column (name = "NAME")
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	
	@Column (name = "DESCRIPTION")
	public String getDescription()
	{
		return description;
	}
	public void setDescription(String description)
	{
		this.description = description;
	}
	
	@ManyToMany
	@JoinTable (
		name = "X_Y",
		schema = "PUBLIC",
		joinColumns = @JoinColumn (name = "X_ID", referencedColumnName = "ID"),
		inverseJoinColumns = @JoinColumn (name = "Y_ID", referencedColumnName = "ID")
	)
	public Set<Y> getYyy()
	{
		return yyy;
	}
	public void setYyy(Set<Y> yyy)
	{
		this.yyy = yyy;
	}
	
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (!(obj instanceof X))
		{
			return false;
		}
		
		Integer thisId = getId();
		X other = (X) obj;
		Integer otherId = other.getId();
		
		if (thisId != null)
		{
			return thisId.equals(otherId);
		}
		// else entities with null id are never equals each other
		return false;
	}
	
}
