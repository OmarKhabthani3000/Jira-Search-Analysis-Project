package it.unipg.jira.hibernate;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Giulio Quaresima (giulio.quaresima@gmail.com)
 *
 */
@Entity
@Table (name = "Y", schema = "PUBLIC")
public class Y implements Serializable, Comparable<Y>
{
	private static final long serialVersionUID = -5864886490891418860L;

	private Integer id;
	private String name;
	
	public Y()
	{
		super();
	}
	
	@Id
	@Column (name = "ID")
	public Integer getId()
	{
		return id;
	}
	public void setId(Integer id)
	{
		this.id = id;
	}
	
	@Column (name = "NAME")
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (!(obj instanceof Y))
		{
			return false;
		}
		
		Integer thisId = getId();
		Y other = (Y) obj;
		Integer otherId = other.getId();
		
		if (thisId != null)
		{
			return thisId.equals(otherId);
		}
		// else entities with null id are never equals each other
		return false;
	}
	
	@Override
	public int compareTo(Y other)
	{
		if (other != null)
		{
			int compare = 0;
			
			String thisName = getName();
			String otherName = other.getName();
			if (thisName != null && otherName != null)
			{
				compare = thisName.compareTo(otherName);
			}
			
			if (compare == 0)
			{
				Integer thisId = getId();
				Integer otherId = other.getId();
				if (thisId != null && otherId != null)
				{
					compare = thisId - otherId;
				}
			}
			
			if (compare == 0)
			{
				compare = System.identityHashCode(this) - System.identityHashCode(other);
			}
			
			return compare;
		}
		return Integer.MAX_VALUE;
	}
	
}
