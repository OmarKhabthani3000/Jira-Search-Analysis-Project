package it.unipg.jira.hibernate;

import java.util.Collection;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public class YDAO extends AbstractHibernateDAO
{

	@Transactional (propagation = Propagation.SUPPORTS, readOnly = true)
	public Y get(int id)
	{
		return (Y) getCurrentSession().get(Y.class, id);
	}
	
	@Transactional (propagation = Propagation.SUPPORTS, readOnly = true)
	public Y load(int id)
	{
		return (Y) getCurrentSession().load(Y.class, id);
	}
	
	@SuppressWarnings("unchecked")
	@Transactional (propagation = Propagation.SUPPORTS, readOnly = true)
	public Collection<Y> list()
	{
		return getCurrentSession().createCriteria(Y.class).list();
	}
	
}
