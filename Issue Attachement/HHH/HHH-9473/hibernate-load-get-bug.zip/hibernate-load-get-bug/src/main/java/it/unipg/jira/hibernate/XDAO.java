package it.unipg.jira.hibernate;

import java.util.Collection;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public class XDAO extends AbstractHibernateDAO
{

	@Transactional (propagation = Propagation.SUPPORTS, readOnly = true)
	public X get(int id)
	{
		return (X) getCurrentSession().get(X.class, id);
	}
	
	@Transactional (propagation = Propagation.SUPPORTS, readOnly = true)
	public X load(int id)
	{
		return (X) getCurrentSession().load(X.class, id);
	}
	
	@SuppressWarnings("unchecked")
	@Transactional (propagation = Propagation.SUPPORTS, readOnly = true)
	public Collection<X> list()
	{
		return getCurrentSession().createCriteria(X.class).list();
	}
	
}
