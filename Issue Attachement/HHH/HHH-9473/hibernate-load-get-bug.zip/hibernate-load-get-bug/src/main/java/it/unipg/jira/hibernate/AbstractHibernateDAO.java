package it.unipg.jira.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public class AbstractHibernateDAO
{
	@Autowired
	private SessionFactory sessionFactory;

	protected Session getCurrentSession()
	{
		return sessionFactory.getCurrentSession();
	}
	
	@Transactional (propagation = Propagation.REQUIRED, readOnly = false)
	public void save(Object entity)
	{
		getCurrentSession().save(entity);
	}
	
	@Transactional (propagation = Propagation.REQUIRED, readOnly = false)
	public void saveOrUpdate(Object entity)
	{
		getCurrentSession().saveOrUpdate(entity);
	}
	
}
