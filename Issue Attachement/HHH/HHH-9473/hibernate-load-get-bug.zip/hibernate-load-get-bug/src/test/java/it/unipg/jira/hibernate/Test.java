package it.unipg.jira.hibernate;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import org.hibernate.Session;
import org.junit.Assert;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"/applicationContext.xml"})
public class Test
{
	@Autowired
	private XDAO xdao;
	
	@Autowired
	private YDAO ydao;
	
	@org.junit.Test
	@Transactional
	public void testGet() throws SecurityException, NoSuchMethodException
	{
		testCommon(xdao.get(2));
	}
	
	/**
	 * Test that
	 * {@link Session#load(Class, java.io.Serializable)} generate
	 * a javassist proxy which delete some informations about
	 * generics declarations of persistent collections. 
	 * 
	 * @throws SecurityException
	 * @throws NoSuchMethodException
	 */
	@org.junit.Test (expected = ClassCastException.class)
	@Transactional
	public void testLoad() throws SecurityException, NoSuchMethodException
	{
		testCommon(xdao.load(2));
	}
	
	void testCommon(X x) throws SecurityException, NoSuchMethodException
	{
		Assert.assertNotNull(x);
		Assert.assertEquals("X002", x.getName());
		Assert.assertNull(x.getDescription());
		Assert.assertTrue(4 == x.getYyy().size());
		
		Class<?> clax = x.getClass();
		Method method = clax.getMethod("getYyy");
		Type type = method.getGenericReturnType();
		
		// THE CAST BELOW THROWS A ClassCastException WHEN x IS LOADED
		ParameterizedType parameterizedType = (ParameterizedType) type;
		
		Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
		
		Assert.assertTrue(1 == actualTypeArguments.length);
		Assert.assertEquals(Y.class, actualTypeArguments[0]);
	}
	
}
