package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Phone {

	@Id
	private int id;

	@Column(nullable=false)
	private String number;

	@ManyToOne(fetch=FetchType.LAZY, optional=false)
	@JoinColumn(name="person_id", foreignKey=@ForeignKey(name="Phone_Person_FK"))
	private Person owner;

	public Phone() {}

	public Phone(int id, String number, Person owner) {
		this.id = id;
		this.number = number;
		this.owner = owner;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}

	public Person getOwner() {
		return owner;
	}
	public void setOwner(Person owner) {
		this.owner = owner;
	}

}
