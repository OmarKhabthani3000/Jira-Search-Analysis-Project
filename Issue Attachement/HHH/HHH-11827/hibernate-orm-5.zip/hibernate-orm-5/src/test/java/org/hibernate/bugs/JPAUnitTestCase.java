package org.hibernate.bugs;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void entityNativeQueryEagerJoinTest() throws Exception {
		EntityManager em = entityManagerFactory.createEntityManager();
		em.getTransaction().begin();

		for( int i = 1; i <= 5; i++ ) {
			Person p = new Person(i, "Name " + i);
			Phone ph = new Phone(i, "Phone " + i, p);
			em.persist(p);
			em.persist(ph);
		}

		em.getTransaction().commit();

		em.clear();
		/*
		 * The query below follows the "Example 475. JPA native query selecting entities with joined many-to-one association"
		 * from Hibernate user guide http://docs.jboss.org/hibernate/orm/5.2/userguide/html_single/Hibernate_User_Guide.html#sql-entity-associations-query
		 *
		 * It should "...eagerly join the Phone and the Person entities to avoid the possible extra roundtrip for initializing the many-to-one association..."
		 */
		List<Phone> phones = em.createNativeQuery(
				"select * "
				+ "from Phone ph "
				+ "join Person p "
				+ "on ph.person_id = p.id "
				+ "where ph.id > 2", Phone.class).getResultList();

		for(Phone ph : phones) {
			/*
			 * When I try to access the Person, another query is sent to the database.
			 * So the eager fetch of entity native query does not initialize the many-to-one association as expected.
			 */
		    System.out.println(ph.getOwner().getName());
		}

		em.close();
	}
}
