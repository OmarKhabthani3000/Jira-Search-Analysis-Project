package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Person {

    @Id
    private Long id;

    @OneToMany(mappedBy = "person")
    private Set<Dog> dogs = new HashSet<>(0);

    public Person() {
    }

    public Person(Long id, Set<Dog> dogs) {
        this.id = id;
        this.dogs = dogs;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Set<Dog> getDogs() {
        return dogs;
    }

    public void setDogs(Set<Dog> dogs) {
        this.dogs = dogs;
    }
}
