package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import jakarta.persistence.EntityManager;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
class DemoApplicationTests {

	@Autowired
	private EntityManager entityManager;

	@Test
	@Transactional
	void contextLoads() {
		Dog dog1 = new Dog(1L, "harry", "jack-russel-terrier");
		Dog dog2 = new Dog(2L, "dumbledore", "shepherd");
		entityManager.persist(dog1);
		entityManager.persist(dog2);
		Person person = new Person(1L, Set.of(dog1, dog2));
		person.setId(1L);
		entityManager.persist(person);
		dog1.setPerson(person);
		dog2.setPerson(person);
		entityManager.flush();
		entityManager.clear();

		List<Person> loadedPersons = entityManager.createNativeQuery("""
  			SELECT * FROM person p LEFT JOIN dog d on d.person_id = p.id
		""", Person.class).getResultList();
		assertEquals(loadedPersons.size(), 1);
	}

}
