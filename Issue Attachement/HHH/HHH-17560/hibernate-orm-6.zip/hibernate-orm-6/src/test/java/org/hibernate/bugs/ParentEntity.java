package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import org.hibernate.annotations.Cascade;

import static org.hibernate.annotations.CascadeType.PERSIST;
import static org.hibernate.annotations.CascadeType.SAVE_UPDATE;

@Entity
public class ParentEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne
  @Cascade(SAVE_UPDATE)
  @JoinColumn(name = "child_entity_id")
  private ChildEntity childEntity;

  public void setId(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public ChildEntity getChildEntity() {
    return childEntity;
  }

  public void setChildEntity(ChildEntity childEntity) {
    this.childEntity = childEntity;
  }
}
