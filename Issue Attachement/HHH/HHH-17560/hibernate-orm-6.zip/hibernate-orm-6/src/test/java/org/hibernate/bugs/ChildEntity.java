package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.SelectBeforeUpdate;

import static org.hibernate.annotations.CascadeType.SAVE_UPDATE;

@Entity
@SelectBeforeUpdate
public class ChildEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String property;
  @OneToOne(mappedBy = "childEntity")
  @Cascade(SAVE_UPDATE)
  private MappedEntity mappedEntity;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getProperty() {
    return property;
  }

  public void setProperty(String property) {
    this.property = property;
  }

  public MappedEntity getMappedEntity() {
    return mappedEntity;
  }

  public void setMappedEntity(MappedEntity mappedEntity) {
    this.mappedEntity = mappedEntity;
  }
}
