package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import org.hibernate.engine.spi.SessionImplementor;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		ChildEntity childEntity = new ChildEntity();
		childEntity.setProperty("property");

		entityManager.unwrap(SessionImplementor.class).save(childEntity);

		entityManager.getTransaction().commit();

		entityManager.clear();
		entityManager.close();

		EntityManager secondEntityManager = entityManagerFactory.createEntityManager();
		secondEntityManager.getTransaction().begin();

		ParentEntity parent1 = new ParentEntity();
		parent1.setChildEntity(childEntity);

		secondEntityManager.unwrap(SessionImplementor.class).save(parent1);

		secondEntityManager.getTransaction().commit();
		secondEntityManager.clear();
		secondEntityManager.close();

		EntityManager thirdEntityManager = entityManagerFactory.createEntityManager();
		thirdEntityManager.getTransaction().begin();

		ParentEntity parent2 = new ParentEntity();
		parent2.setChildEntity(childEntity);

		thirdEntityManager.unwrap(SessionImplementor.class).save(parent2);

		thirdEntityManager.getTransaction().commit();
		thirdEntityManager.close();
	}
}
