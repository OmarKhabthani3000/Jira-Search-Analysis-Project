Test package contains one test which demonstrates the bug.
Hibernate will try to force version increment on non-versioned entity.
This is because StationPlanRepository query uses
@Lock(LockModeType.OPTIMISTIC_FORCE_INCREMENT)
AND
@EntityGraph(attributePaths = {"station", "station.stationTracks"})

Hibernate will propagate OPTIMISTIC_FORCE_INCREMENT for everything in EntityGraph's attributePaths.
1) Should it propagate OPTIMISTIC_FORCE_INCREMENT
2) Should it propagate it to entity even if entity is not versioned

How to replicate:
1) set your jdbc driver as dependency in build.gradle (default: Oracle).
2) Run content of data.sql migration to database (default dialect: Oracle)
3) Run test
4) Hibernate will throw assertion trying to increment non-versioned entity