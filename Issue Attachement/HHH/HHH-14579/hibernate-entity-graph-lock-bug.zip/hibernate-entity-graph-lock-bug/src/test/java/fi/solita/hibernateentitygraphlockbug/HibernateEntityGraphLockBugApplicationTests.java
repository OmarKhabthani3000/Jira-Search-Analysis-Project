package fi.solita.hibernateentitygraphlockbug;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import fi.solita.hibernateentitygraphlockbug.domain.StationPlan;
import fi.solita.hibernateentitygraphlockbug.repository.StationPlanRepository;
import fi.solita.hibernateentitygraphlockbug.service.SimpleTransactionManager;

@SpringBootTest
class HibernateEntityGraphLockBugApplicationTests {

	@Autowired
	private StationPlanRepository stationPlanRepository;
	@Autowired
	private SimpleTransactionManager simpleTransactionManager;

	/**
	 * Test will fail when trying to commit optimistic version increment
	 * "cannot force version increment on non-versioned entity"
	 */
	@Test
	void testBug() {
		simpleTransactionManager.executeInNewTransaction(() -> {
			final Optional<StationPlan> stationPlan = stationPlanRepository.findByStationPlanId(1L);
		});
	}

}
