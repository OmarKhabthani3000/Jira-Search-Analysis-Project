CREATE TABLE STATION
(
    station_id number(10) NOT NULL,
    version    number(10) NOT NULL,
    CONSTRAINT STATION_PK PRIMARY KEY (station_id)
);

CREATE TABLE STATION_TRACK
(
    track_id number(10) NOT NULL,
    station_id    number(10) NOT NULL,
    CONSTRAINT TRACK_PK PRIMARY KEY (track_id),
    CONSTRAINT STATION_FK FOREIGN KEY (station_id) REFERENCES STATION (station_id)
);

CREATE TABLE STATION_PLAN
(
    plan_id         number(10) NOT NULL,
    version    number(10) NOT NULL,
    station_id number(10) NOT NULL,
    CONSTRAINT STATION_PLAN_PK PRIMARY KEY (plan_id),
    CONSTRAINT STATION_FK FOREIGN KEY (station_id) REFERENCES STATION (station_id)
);

INSERT INTO STATION (station_id, version) values (1, 1);

INSERT INTO STATION_TRACK (track_id, station_id) values (1, 1);
INSERT INTO STATION_TRACK (track_id, station_id) values (2, 1);
INSERT INTO STATION_TRACK (track_id, station_id) values (3, 1);
INSERT INTO STATION_TRACK (track_id, station_id) values (4, 1);
INSERT INTO STATION_TRACK (track_id, station_id) values (5, 1);

INSERT INTO STATION_PLAN (plan_id, version, station_id) values (1, 1, 1);