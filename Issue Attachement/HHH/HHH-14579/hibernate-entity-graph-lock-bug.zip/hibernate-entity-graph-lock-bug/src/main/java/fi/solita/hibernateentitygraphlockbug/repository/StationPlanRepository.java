package fi.solita.hibernateentitygraphlockbug.repository;

import javax.persistence.LockModeType;
import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import fi.solita.hibernateentitygraphlockbug.domain.StationPlan;

@Repository
public interface StationPlanRepository extends JpaRepository<StationPlan, Long> {

    @Lock(LockModeType.OPTIMISTIC_FORCE_INCREMENT)
    @Query("SELECT plan FROM StationPlan plan WHERE plan.planId = :planId")
    @EntityGraph(attributePaths = {"station", "station.stationTracks"})
    Optional<StationPlan> findByStationPlanId(@Param("planId") final long planId);

}
