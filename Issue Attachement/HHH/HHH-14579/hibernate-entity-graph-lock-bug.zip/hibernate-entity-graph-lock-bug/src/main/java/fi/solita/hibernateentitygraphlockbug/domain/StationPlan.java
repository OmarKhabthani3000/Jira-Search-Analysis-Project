package fi.solita.hibernateentitygraphlockbug.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "STATION_PLAN")
public class StationPlan {

    @Id
    private long planId;

    @Version
    private int version;

    @ManyToOne
    @JoinColumn(name = "station_id")
    private Station station;

    public StationPlan() {
    }

    public long getPlanId() {
        return planId;
    }

    public int getVersion() {
        return version;
    }

    public Station getStation() {
        return station;
    }
}
