package fi.solita.hibernateentitygraphlockbug.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "STATION_TRACK")
public class StationTrack {

    @Id
    private long trackId;

    public StationTrack() {
    }

    public long getTrackId() {
        return trackId;
    }

}
