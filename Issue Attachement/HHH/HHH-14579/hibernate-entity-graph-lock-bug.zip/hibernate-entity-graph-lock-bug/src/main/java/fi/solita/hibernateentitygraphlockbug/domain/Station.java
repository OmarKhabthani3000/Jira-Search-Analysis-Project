package fi.solita.hibernateentitygraphlockbug.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;
import java.util.Set;

@Entity
@Table(name = "STATION")
public class Station {

    @Id
    private long stationId;

    @Version
    private long version;

    @OneToMany
    @JoinColumn(name = "STATION_ID")
    private Set<StationTrack> stationTracks;

    public Station() {
    }

    public long getStationId() {
        return stationId;
    }

    public long getVersion() {
        return version;
    }

    public Set<StationTrack> getStationTracks() {
        return stationTracks;
    }
}
