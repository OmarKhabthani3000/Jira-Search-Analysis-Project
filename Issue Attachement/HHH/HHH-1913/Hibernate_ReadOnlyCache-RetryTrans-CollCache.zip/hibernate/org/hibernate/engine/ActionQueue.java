// $Id: ActionQueue.java 9194 2006-02-01 19:59:07Z steveebersole $
package org.hibernate.engine;

import org.hibernate.action.*;
import org.hibernate.HibernateException;
import org.hibernate.AssertionFailure;
import org.hibernate.persister.collection.CollectionPersister;
import org.hibernate.cache.CacheException;
import org.hibernate.cache.CacheKey;
import org.hibernate.cache.CacheConcurrencyStrategy.SoftLock;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.*;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.io.ObjectOutputStream;

/**
 * Responsible for maintaining the queue of actions related to events.
 * </p>
 * The ActionQueue holds the DML operations queued as part of a session's
 * transactional-write-behind semantics.  DML operations are queued here
 * until a flush forces them to be executed against the database.
 *
 * @author Steve Ebersole
 */
public class ActionQueue {

	private static final Log log = LogFactory.getLog( ActionQueue.class );
	private static final int INIT_QUEUE_LIST_SIZE = 5;
	private static final int INIT_LISTS_LIST_SIZE = 6;

	private SessionImplementor session;

	// Object insertions, updates, and deletions have list semantics because
	// they must happen in the right order so as to respect referential
	// integrity
	private ArrayList insertions;
	private ArrayList deletions;
	private ArrayList updates;
	// Actually the semantics of the next three are really "Bag"
	// Note that, unlike objects, collection insertions, updates,
	// deletions are not really remembered between flushes. We
	// just re-use the same Lists for convenience.
	private ArrayList collectionCreations;
	private ArrayList collectionUpdates;
	private ArrayList collectionRemovals;

	private transient ArrayList lists;

	private ArrayList executions;

	/**
	 * This map contains information about locks held and evictions
	 * on L2 Collection cache entries.  It maps CacheKey keys to
	 * Lists of { CollectionPersister, lockCount, softLock, wasEvicted }
	 */
	private transient Map collectionCacheState = new HashMap();

	/**
	 * Constructs an action queue bound to the given session.
	 *
	 * @param session The session "owning" this queue.
	 */
	public ActionQueue(SessionImplementor session) {
		this.session = session;
		init();
	}

	private void init() {
		insertions = new ArrayList( INIT_QUEUE_LIST_SIZE );
		deletions = new ArrayList( INIT_QUEUE_LIST_SIZE );
		updates = new ArrayList( INIT_QUEUE_LIST_SIZE );

		collectionCreations = new ArrayList( INIT_QUEUE_LIST_SIZE );
		collectionRemovals = new ArrayList( INIT_QUEUE_LIST_SIZE );
		collectionUpdates = new ArrayList( INIT_QUEUE_LIST_SIZE );

		executions = new ArrayList( INIT_QUEUE_LIST_SIZE * 3 );

		lists = new ArrayList( INIT_LISTS_LIST_SIZE );

		buildListsList();
	}

	private void buildListsList() {
		// The order matters here.  It determines their order of processing
		lists.add( insertions );
		lists.add( updates );
		lists.add( collectionRemovals );
		lists.add( collectionUpdates );
		lists.add( collectionCreations );
		lists.add( deletions );
	}

	public void clear() {
		int size = lists.size();
		for ( int i = 0; i < size; i++ ) {
			( (List) lists.get(i) ).clear();
		}
	}

	public void addAction(EntityInsertAction action) {
		insertions.add( action );
	}

	public void addAction(EntityDeleteAction action) {
		deletions.add( action );
	}

	public void addAction(EntityUpdateAction action) {
		updates.add( action );
	}

	public void addAction(CollectionRecreateAction action) {
		collectionCreations.add( action );
	}

	public void addAction(CollectionRemoveAction action) {
		collectionRemovals.add( action );
	}

	public void addAction(CollectionUpdateAction action) {
		collectionUpdates.add( action );
	}

	public void addAction(EntityIdentityInsertAction insert) {
		insertions.add( insert );
	}

	public void addAction(BulkOperationCleanupAction cleanupAction) {
		// Add these directly to the executions queue
		executions.add( cleanupAction );
	}

	/**
	 * Perform all currently queued entity-insertion actions.
	 *
	 * @throws HibernateException error executing queued insertion actions.
	 */
	public void executeInserts() throws HibernateException {
		List lists = java.util.Collections.singletonList(insertions);
		prepareActions(lists);
		executeActions(lists);
	}

  	/**
	 * Perform all currently queued actions.
	 *
	 * @throws HibernateException error executing queued actions.
	 */
	public void executeActions() throws HibernateException {
		prepareActions(lists);
		executeActions(lists);
	}

	/**
	 * Perform all currently queued actions contained in the lists contained in the provided list
	 *
	 * @param lists list of lists which contain queued actions
	 * @throws HibernateException
	 */
	private void executeActions(List lists) throws HibernateException {

		final int size = lists.size();

		for ( int i = 0; i < size; i++ ) {
			prepareForExecution( (List) lists.get(i) );
		}


		// Only support this retry feature if no other activity has yet been pushed through the
		// Batcher.  This is because we would have to either use JDBC Connection SavePoints, or
		// keep a log of all of the PreparedStatements that have been executed within this
		// Transaction so that they too can be retried, along with the actions presently in this
		// ActionQueue, after the rollback is done.
		final boolean supportRetries = this.session.getBatcher().getExecutedStatementCount() == 0
			&& !this.session.getBatcher().hasBatchedStatement();

		for ( int j = 0; j < Integer.MAX_VALUE; j++ ) {
			try {
				for ( int i = 0; i < size; i++ ) {
					executeActionsDatastorePhase( (List) lists.get(i) );
				}

				break;
			}
			catch (HibernateException e) {
				if (!supportRetries
					|| !this.session.getInterceptor().onDatastoreWriteException(e, j))
					throw e;
				log.warn("Exception making datastore changes, rolling back now for retry", e);
				try {
					// todo - Use the relevant Transaction object, not the Connection directly
					session.connection().rollback();
				}
				catch (Exception ee) {
					// todo - translator for SQLExceptions
					throw new HibernateException(ee);
				}
			}
		}


		for ( int i = 0; i < size; i++ ) {
			executeActionsCachePhase( (List) lists.get(i) );
		}

		for ( int i = 0; i < size; i++ ) {
			( (List) lists.get(i) ).clear();
		}
	}

	/**
	 * Performs cleanup of any held cache softlocks.
	 *
	 * @param success Was the transaction successful.
	 */
	public void afterTransactionCompletion(boolean success) {
		int size = executions.size();
		final boolean invalidateQueryCache = session.getFactory().getSettings().isQueryCacheEnabled();
		for ( int i = 0; i < size; i++ ) {
			try {
				Executable exec = ( Executable ) executions.get(i);
				try {
					exec.afterTransactionCompletion( success, this );
				}
				finally {
					if ( invalidateQueryCache ) {
						session.getFactory().getUpdateTimestampsCache().invalidate( exec.getPropertySpaces() );
					}
				}
			}
			catch (CacheException ce) {
				log.error( "could not release a cache lock", ce );
				// continue loop
			}
			catch (Exception e) {
				throw new AssertionFailure( "Exception releasing cache locks", e );
			}
		}
		executions.clear();

		if (this.collectionCacheState.size() > 0)
			throw new AssertionFailure( "Not all cache locks were released" );
	}

	/**
	 * Lock the cache entry corresponding to the provided key.  If the
	 * entry has already been locked by this ActionQueue, then the only
	 * action taken is an increment of the lockCount for this key<->entry.
	 *
	 * @param cacheKey the key for the cache entry we want to lock
	 * @param collPersister the persister associated with the CacheKey space
	 */
	public void lock(CacheKey cacheKey, CollectionPersister collPersister) {
		List entry = (List) collectionCacheState.get(cacheKey);

		if (entry == null) {
			SoftLock lock = collPersister.getCache().lock(cacheKey, null);
			entry = new ArrayList(4);
			entry.add(collPersister);
			entry.add(new Integer(1));
			entry.add(lock);
			entry.add(Boolean.FALSE);
			collectionCacheState.put(cacheKey, entry);
		}
		else {
			Integer currLockCount = (Integer) entry.get(1);
			Integer newLockCount = new Integer(currLockCount.intValue() + 1);
			entry.set(1, newLockCount);
		}
	}

	/**
	 * Unlock the cache entry corresponding to the provided key.  If the
	 * lockCount is currently greater than one, then the only action taken
	 * is a decrement of the lockCount.  Otherwise, the entry is unlocked
	 * and any information held about the provided CacheKey by this ActionQueue
	 * is purged.
	 *
	 * @param cacheKey the key for the cache entry we want to unlock
	 */
	public void unlock(CacheKey cacheKey) {
		List entry = (List) collectionCacheState.get(cacheKey);
		Integer currLockCount = (Integer) entry.get(1);

		if (currLockCount.intValue() > 1) {
			Integer newLockCount = new Integer(currLockCount.intValue() - 1);
			entry.set(1, newLockCount);
		}
		else if (currLockCount.intValue() == 1) {
			CollectionPersister collPersister = (CollectionPersister) entry.get(0);
			SoftLock lock = (SoftLock) entry.get(2);
			// Even if there's an error, we consider the

			// lock invalid, so just remove it first
			collectionCacheState.remove(cacheKey);
			collPersister.getCache().release(cacheKey, lock);
		}
	}

	/**
	 * Evict the cache entry corresponding to the provided key.  If the
	 * entry has not yet been evicted, then it is evicted and marked as
	 * having been so.  If it was already evicted by this ActionQueue,
	 * then no action is taken.
	 *
	 * @param cacheKey the key for the cache entry we want to evict
	 */
	public void evict(CacheKey cacheKey, SessionImplementor session) {
		List entry = (List) collectionCacheState.get(cacheKey);
		Boolean alreadyEvicted = (Boolean) entry.get(3);

		if (!alreadyEvicted.booleanValue()) {
			CollectionPersister collPersister = (CollectionPersister) entry.get(0);
			collPersister.getCache().evict(cacheKey);
			entry.set(3, Boolean.TRUE);

			if ( session.getFactory().getStatistics().isStatisticsEnabled() ) {
				session.getFactory().getStatisticsImplementor()
						.removeCollection( collPersister.getRole() );
			}
		}
	}

	/**
	 * Check whether the given tables/query-spaces are to be executed against
	 * given the currently queued actions.
	 *
	 * @param tables The table/query-spaces to check.
	 * @return True if we contain pending actions against any of the given
	 * tables; false otherwise.
	 */
	public boolean areTablesToBeUpdated(Set tables) {
		int size = lists.size();
		for ( int i = 0; i < size; i++ ) {
			if (areTablesToUpdated( (List) lists.get(i), tables))
				return true;
		}
		return false;
	}

	/**
	 * Check whether any insertion or deletion actions are currently queued.
	 *
	 * @return True if insertions or deletions are currently queued; false otherwise.
	 */
	public boolean areInsertionsOrDeletionsQueued() {
		return ( insertions.size() > 0 || deletions.size() > 0 );
	}

	private static boolean areTablesToUpdated(List executables, Set tablespaces) {
		int size = executables.size();
		for ( int j = 0; j < size; j++ ) {
			Serializable[] spaces = ( (Executable) executables.get(j) ).getPropertySpaces();
			for ( int i = 0; i < spaces.length; i++ ) {
				if ( tablespaces.contains( spaces[i] ) ) {
					if ( log.isDebugEnabled() ) log.debug( "changes must be flushed to space: " + spaces[i] );
					return true;
				}
			}
		}
		return false;
	}

	private void executeActionsDatastorePhase(List list) throws HibernateException {
		int size = list.size();
		for ( int i = 0; i < size; i++ ) {
			( (Executable) list.get(i) ).executeDatastorePhase();
		}
		session.getBatcher().executeBatch();
	}

	private void executeActionsCachePhase(List list) throws HibernateException {
		int size = list.size();
		for ( int i = 0; i < size; i++ ) {
			( (Executable) list.get(i) ).executeCachePhase(this);
		}
	}

	public void execute(Executable executable) throws HibernateException {
		executable.beforeExecutions(this);
		prepareForExecution(executable);
		executable.executeDatastorePhase();
		session.getBatcher().executeBatch();
		executable.executeCachePhase(this);
	}

	private void prepareForExecution(List list) throws HibernateException {
		int size = list.size();
		for ( int i = 0; i < size; i++ ) {
			prepareForExecution( (Executable) list.get( i ) );
		}
	}

	private void prepareForExecution(Executable executable) throws HibernateException {
		final boolean lockQueryCache = session.getFactory().getSettings().isQueryCacheEnabled();
		if ( executable.hasAfterTransactionCompletion() || lockQueryCache ) {
			executions.add( executable );
		}
		if (lockQueryCache) {
			session.getFactory()
				.getUpdateTimestampsCache()
				.preinvalidate( executable.getPropertySpaces() );
		}
	}

	private void prepareActions(List lists) throws HibernateException {
		int listsSize = lists.size();
		for ( int i=0; i<listsSize; i++ ) {
			List queue = (List) lists.get(i);
			int size = queue.size();
			for ( int j=0; j<size; ++j ) {
				Executable executable = ( Executable ) queue.get(j);
				executable.beforeExecutions(this);
			}
		}
	}

	/**
	 * Returns a string representation of the object.
	 *
	 * @return a string representation of the object.
	 */
	public String toString() {
		return new StringBuffer()
				.append("ActionQueue[insertions=").append(insertions)
				.append(" updates=").append(updates)
		        .append(" deletions=").append(deletions)
				.append(" collectionCreations=").append(collectionCreations)
				.append(" collectionRemovals=").append(collectionRemovals)
				.append(" collectionUpdates=").append(collectionUpdates)
		        .append("]")
				.toString();
	}

	public int numberOfCollectionRemovals() {
		return collectionRemovals.size();
	}

	public int numberOfCollectionUpdates() {
		return collectionUpdates.size();
	}

	public int numberOfCollectionCreations() {
		return collectionCreations.size();
	}

	public int numberOfDeletions() {
		return deletions.size();
	}

	public int numberOfUpdates() {
		return updates.size();
	}

	public int numberOfInsertions() {
		return insertions.size();
	}

	public void sortCollectionActions() {
		if ( session.getFactory().getSettings().isOrderUpdatesEnabled() ) {
			//sort the updates by fk
			java.util.Collections.sort( collectionCreations );
			java.util.Collections.sort( collectionUpdates );
			java.util.Collections.sort( collectionRemovals );
		}
	}

	public void sortUpdateActions() {
		if ( session.getFactory().getSettings().isOrderUpdatesEnabled() ) {
			//sort the updates by pk
			java.util.Collections.sort( updates );
		}
	}

	public ArrayList cloneDeletions() {
		return (ArrayList) deletions.clone();
	}

	public void clearFromFlushNeededCheck(int previousCollectionRemovalSize) {
		collectionCreations.clear();
		collectionUpdates.clear();
		updates.clear();
		// collection deletions are a special case since update() can add
		// deletions of collections not loaded by the session.
		for ( int i = collectionRemovals.size()-1; i >= previousCollectionRemovalSize; i-- ) {
			collectionRemovals.remove(i);
		}
	}

	public boolean hasAnyQueuedActions() {
		int size = lists.size();
		for ( int i = 0; i < size; i++ ) {
			if ( ( (List) lists.get(i) ).size() > 0 )
				return true;
		}
		return false;
	}

	/**
	 * Used by the owning session to explicitly control serialization of the
	 * action queue
	 *
	 * @param oos The stream to which the action queue should get written
	 * @throws IOException
	 */
	public void serialize(ObjectOutputStream oos) throws IOException {
		log.trace( "serializing action-queue" );

		int queueSize = insertions.size();
		log.trace( "starting serialization of [" + queueSize + "] insertions entries" );
		oos.writeInt( queueSize );
		for ( int i = 0; i < queueSize; i++ ) {
			oos.writeObject( insertions.get( i ) );
		}

		queueSize = deletions.size();
		log.trace( "starting serialization of [" + queueSize + "] deletions entries" );
		oos.writeInt( queueSize );
		for ( int i = 0; i < queueSize; i++ ) {
			oos.writeObject( deletions.get( i ) );
		}

		queueSize = updates.size();
		log.trace( "starting serialization of [" + queueSize + "] updates entries" );
		oos.writeInt( queueSize );
		for ( int i = 0; i < queueSize; i++ ) {
			oos.writeObject( updates.get( i ) );
		}

		queueSize = collectionUpdates.size();
		log.trace( "starting serialization of [" + queueSize + "] collectionUpdates entries" );
		oos.writeInt( queueSize );
		for ( int i = 0; i < queueSize; i++ ) {
			oos.writeObject( collectionUpdates.get( i ) );
		}

		queueSize = collectionRemovals.size();
		log.trace( "starting serialization of [" + queueSize + "] collectionRemovals entries" );
		oos.writeInt( queueSize );
		for ( int i = 0; i < queueSize; i++ ) {
			oos.writeObject( collectionRemovals.get( i ) );
		}

		queueSize = collectionCreations.size();
		log.trace( "starting serialization of [" + queueSize + "] collectionCreations entries" );
		oos.writeInt( queueSize );
		for ( int i = 0; i < queueSize; i++ ) {
			oos.writeObject( collectionCreations.get( i ) );
		}
	}

	/**
	 * Used by the owning session to explicitly control deserialization of the
	 * action queue
	 *
	 * @param ois The stream from which to read the action queue
	 * @throws IOException
	 */
	public static ActionQueue deserialize(
			ObjectInputStream ois,
	        SessionImplementor session) throws IOException, ClassNotFoundException {
		log.trace( "deserializing action-queue" );
		ActionQueue rtn = new ActionQueue( session );

		int queueSize = ois.readInt();
		log.trace( "starting deserialization of [" + queueSize + "] insertions entries" );
		rtn.insertions = new ArrayList( queueSize );
		for ( int i = 0; i < queueSize; i++ ) {
			rtn.insertions.add( ois.readObject() );
		}

		queueSize = ois.readInt();
		log.trace( "starting deserialization of [" + queueSize + "] deletions entries" );
		rtn.deletions = new ArrayList( queueSize );
		for ( int i = 0; i < queueSize; i++ ) {
			rtn.deletions.add( ois.readObject() );
		}

		queueSize = ois.readInt();
		log.trace( "starting deserialization of [" + queueSize + "] updates entries" );
		rtn.updates = new ArrayList( queueSize );
		for ( int i = 0; i < queueSize; i++ ) {
			rtn.updates.add( ois.readObject() );
		}

		queueSize = ois.readInt();
		log.trace( "starting deserialization of [" + queueSize + "] collectionUpdates entries" );
		rtn.collectionUpdates = new ArrayList( queueSize );
		for ( int i = 0; i < queueSize; i++ ) {
			rtn.collectionUpdates.add( ois.readObject() );
		}

		queueSize = ois.readInt();
		log.trace( "starting deserialization of [" + queueSize + "] collectionRemovals entries" );
		rtn.collectionRemovals = new ArrayList( queueSize );
		for ( int i = 0; i < queueSize; i++ ) {
			rtn.collectionRemovals.add( ois.readObject() );
		}

		queueSize = ois.readInt();
		log.trace( "starting deserialization of [" + queueSize + "] collectionCreations entries" );
		rtn.collectionCreations = new ArrayList( queueSize );
		for ( int i = 0; i < queueSize; i++ ) {
			rtn.collectionCreations.add( ois.readObject() );
		}
		return rtn;
	}

}
