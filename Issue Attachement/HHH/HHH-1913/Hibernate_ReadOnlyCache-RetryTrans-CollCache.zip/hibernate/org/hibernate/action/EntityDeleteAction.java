//$Id: EntityDeleteAction.java 9575 2006-03-08 05:17:04Z steve.ebersole@jboss.com $
package org.hibernate.action;

import java.io.Serializable;

import org.hibernate.AssertionFailure;
import org.hibernate.HibernateException;
import org.hibernate.cache.CacheKey;
import org.hibernate.cache.CacheConcurrencyStrategy.SoftLock;
import org.hibernate.engine.*;
import org.hibernate.event.PostDeleteEvent;
import org.hibernate.event.PostDeleteEventListener;
import org.hibernate.event.PreDeleteEvent;
import org.hibernate.event.PreDeleteEventListener;
import org.hibernate.persister.entity.EntityPersister;

public final class EntityDeleteAction extends EntityExistenceAction {

	private final Object version;
	private SoftLock lock;
	private final boolean isCascadeDeleteEnabled;
	private final Object[] state;

	public EntityDeleteAction(
			final Serializable id,
	        final Object[] state,
	        final Object version,
	        final Object instance,
	        final EntityPersister persister,
	        final boolean isCascadeDeleteEnabled,
	        final SessionImplementor session) {
		super( session, id, instance, persister );
		this.version = version;
		this.isCascadeDeleteEnabled = isCascadeDeleteEnabled;
		this.state = state;
	}

	public void beforeExecutions(ActionQueue actionQueue) throws HibernateException {
		veto = Boolean.valueOf( preDelete() );
		if ( getPersister().hasCache() ) {
			Object version = this.version;
			EntityPersister persister = getPersister();
			SessionImplementor session = getSession();
			Object instance = getInstance();
			if ( persister.isVersionPropertyGenerated() ) {
				// we need to grab the version value from the entity, otherwise
				// we have issues with generated-version entities that may have
				// multiple actions queued during the same flush
				version = persister.getVersion( instance, session.getEntityMode() );
			}
			final CacheKey ck = new CacheKey(
					getId(),
					persister.getIdentifierType(),
					persister.getRootEntityName(),
					session.getEntityMode(),
					session.getFactory()
				);
			lock = getPersister().getCache().lock(ck, version);
		}
		super.beforeExecutions(actionQueue);
	}

	public void executeDatastorePhase() throws HibernateException {
		if ( !isCascadeDeleteEnabled && !veto.booleanValue() )
			getPersister().delete( getId(), version, getInstance(), getSession() );
	}

	public void executeCachePhase(ActionQueue actionQueue) throws HibernateException {

		Serializable id = getId();
		EntityPersister persister = getPersister();
		SessionImplementor session = getSession();
		Object instance = getInstance();

		final CacheKey ck;
		if ( persister.hasCache() ) {
			ck = new CacheKey(
					id,
					persister.getIdentifierType(),
					persister.getRootEntityName(),
					session.getEntityMode(),
					session.getFactory()
				);
		}
		else {
			ck = null;
		}

		//postDelete:
		// After actually deleting a row, record the fact that the instance no longer
		// exists on the database (needed for identity-column key generation), and
		// remove it from the session cache
		final PersistenceContext persistenceContext = session.getPersistenceContext();
		EntityEntry entry = persistenceContext.removeEntry( instance );
		if ( entry == null ) {
			throw new AssertionFailure( "possible nonthreadsafe access to session" );
		}
		entry.postDelete();

		EntityKey key = new EntityKey( entry.getId(), entry.getPersister(), session.getEntityMode() );
		persistenceContext.removeEntity(key);
		persistenceContext.removeProxy(key);

		if ( persister.hasCache() ) persister.getCache().evict(ck);

		evictOwningCollectionsFromCache(actionQueue);

		postDelete();

		if ( getSession().getFactory().getStatistics().isStatisticsEnabled() && !veto.booleanValue() ) {
			getSession().getFactory().getStatisticsImplementor()
					.deleteEntity( getPersister().getEntityName() );
		}
	}

	private boolean preDelete() {
		PreDeleteEventListener[] preListeners = getSession().getListeners()
				.getPreDeleteEventListeners();
		boolean veto = false;
		if (preListeners.length>0) {
			PreDeleteEvent preEvent = new PreDeleteEvent( getInstance(), getId(), state, getPersister() );
			for ( int i = 0; i < preListeners.length; i++ ) {
				veto = preListeners[i].onPreDelete(preEvent) || veto;
			}
		}
		return veto;
	}

	private void postDelete() {
		PostDeleteEventListener[] postListeners = getSession().getListeners()
				.getPostDeleteEventListeners();
		if (postListeners.length>0) {
			PostDeleteEvent postEvent = new PostDeleteEvent( getInstance(), getId(), state, getPersister() );
			for ( int i = 0; i < postListeners.length; i++ ) {
				postListeners[i].onPostDelete(postEvent);
			}
		}
	}

	private void postCommitDelete() {
		PostDeleteEventListener[] postListeners = getSession().getListeners()
				.getPostCommitDeleteEventListeners();
		if (postListeners.length>0) {
			PostDeleteEvent postEvent = new PostDeleteEvent( getInstance(), getId(), state, getPersister() );
			for ( int i = 0; i < postListeners.length; i++ ) {
				postListeners[i].onPostDelete(postEvent);
			}
		}
	}

	public void afterTransactionCompletion(boolean success, ActionQueue actionQueue) throws HibernateException {
		super.afterTransactionCompletion(success, actionQueue);
		if ( getPersister().hasCache() ) {
			try {
				final CacheKey ck = new CacheKey(
						getId(),
						getPersister().getIdentifierType(),
						getPersister().getRootEntityName(),
						getSession().getEntityMode(),
						getSession().getFactory()
					);
				getPersister().getCache().release(ck, lock);
			}
			finally {
				lock = null;
			}
		}
   		postCommitDelete();
	}

	protected boolean hasPostCommitEventListeners() {
		return getSession().getListeners().getPostCommitDeleteEventListeners().length>0;
	}

}







