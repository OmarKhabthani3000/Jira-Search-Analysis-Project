//$Id: CollectionRecreateAction.java 7147 2005-06-15 13:20:13Z oneovthafew $
package org.hibernate.action;

import org.hibernate.HibernateException;
import org.hibernate.cache.CacheException;
import org.hibernate.collection.PersistentCollection;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.engine.ActionQueue;
import org.hibernate.persister.collection.CollectionPersister;

import java.io.Serializable;

public final class CollectionRecreateAction extends CollectionAction {

	public CollectionRecreateAction(
				final PersistentCollection collection, 
				final CollectionPersister persister, 
				final Serializable id, 
				final SessionImplementor session)
			throws CacheException {
		super( persister, collection, id, session );
	}

	public void executeDatastorePhase() throws HibernateException {
		getPersister().recreate( getCollection(), getKey() , getSession() );
	}

	public void executeCachePhase(ActionQueue actionQueue) throws HibernateException {

		final PersistentCollection collection = getCollection();

		getSession().getPersistenceContext()
				.getCollectionEntry(collection)
				.afterAction(collection);

		evict(actionQueue);

		if ( getSession().getFactory().getStatistics().isStatisticsEnabled() ) {
			getSession().getFactory().getStatisticsImplementor()
					.recreateCollection( getPersister().getRole() );
		}
	}

}
