package org.hibernate.action;

import org.hibernate.persister.entity.EntityPersister;
import org.hibernate.persister.collection.CollectionPersister;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.engine.ActionQueue;
import org.hibernate.type.Type;
import org.hibernate.type.ManyToOneType;
import org.hibernate.type.CollectionType;
import org.hibernate.cache.CacheKey;
import org.hibernate.HibernateException;
import org.hibernate.EntityMode;
import org.hibernate.proxy.HibernateProxy;
import org.hibernate.proxy.LazyInitializer;
import org.hibernate.collection.PersistentCollection;

import java.util.*;
import java.io.Serializable;

/**
 * When an Entity is inserted or deleted, collections where it appears as an element
 * need to be evicted from the L2 cache.  This class provides that functionality,
 * intentionally to be used as a superclass for EntityInsertAction and EntityDeleteAction.
 *
 * @author Nathan Morse
 */
public abstract class EntityExistenceAction extends EntityAction {

	private static final Map entityRolesToEvict = new HashMap();

	/**
	 * Contains CacheKey objects for all Collections that contain
	 * the this.getInstance() entity.
	 */
	private Set collectionsToEvict = new TreeSet(new Comparator(){
		public int compare(Object o1, Object o2) {
			CacheKey ck1 = (CacheKey) o1;
			CacheKey ck2 = (CacheKey) o2;
			int cmp = ck1.getEntityOrRoleName().compareTo(ck2.getEntityOrRoleName());
			return cmp != 0 ? cmp
				: ck1.getKey().toString().compareTo(ck2.getKey().toString());
		}
	});


	public EntityExistenceAction(final SessionImplementor session,
                                 final Serializable id,
                                 final Object instance,
                                 final EntityPersister persister) {
		super( session, id, instance, persister );
	}


	/**
	 * Generate information about all of the collections where the getInstance() entity
	 * appears as a collection element and lock the L2 cache entries of all of these collections.
	 *
	 * @param actionQueue the action queue that is executing this action
	 * @throws HibernateException if something goes wrong
	 */
	public void beforeExecutions(ActionQueue actionQueue) throws HibernateException {

		Map rolesToEvict = getRolesToEvict();

		for ( Iterator itrPropertyIndex = rolesToEvict.keySet().iterator(); itrPropertyIndex.hasNext(); ) {

			Integer propertyIndex = (Integer) itrPropertyIndex.next();
			Set inboundPersisters = (Set) rolesToEvict.get(propertyIndex);

			// All inbound persisters on the other end are on the same owning object, so just
			// grab it off of the first one.
			EntityPersister ownerPersister = ((CollectionPersister) inboundPersisters.iterator().next())
				.getOwnerEntityPersister();

			Object property = getPersister().getPropertyValue(getInstance(), propertyIndex.intValue(), getSession().getEntityMode());

			if ( property != null ) {
				if ( property instanceof Collection ) {

					// We DON'T want to instantiate the collection here, because it also instantiates
					// all of the entities it contains, which then creates CollectionEntries for those
					// entitys' collection mappings, and on and on.  We must avoid that at this point
					// in this flush cycle.

					if ( !(property instanceof PersistentCollection) || ((PersistentCollection) property).wasInitialized() ) {
						for ( Iterator itrOwner = ((Collection) property).iterator(); itrOwner.hasNext(); ) {
							Object ownerEntity = itrOwner.next();
							Serializable ownerId = getIdentifier(ownerEntity, ownerPersister, getSession().getEntityMode());
							for ( Iterator itrInbound = inboundPersisters.iterator(); itrInbound.hasNext(); ) {
								CollectionPersister inboundPersister = (CollectionPersister) itrInbound.next();
								generateEvictInfo(ownerId, inboundPersister, actionQueue);
							}
						}
					}
					else {
						// Query only the owner identifiers from the outboundPersister
						CollectionType outboundType = (CollectionType) getPersister().getPropertyTypes()[propertyIndex.intValue()];
						CollectionPersister outboundPersister = getPersister().getFactory()
							.getCollectionPersister(outboundType.getRole());
						Serializable instanceId = getPersister().getIdentifier(getInstance(), getSession().getEntityMode());
						Serializable[] elementIDs = outboundPersister.getElementIdentifiers(instanceId, getSession());
						for ( int i = 0; i < elementIDs.length; i++ ) {
							for ( Iterator itrInbound = inboundPersisters.iterator(); itrInbound.hasNext(); ) {
								CollectionPersister inboundPersister = (CollectionPersister) itrInbound.next();
								generateEvictInfo(elementIDs[i], inboundPersister, actionQueue);
							}
						}
					}
				}
				else {
					Serializable ownerId = getIdentifier(property, ownerPersister, getSession().getEntityMode());
					for ( Iterator itrInbound = inboundPersisters.iterator(); itrInbound.hasNext(); ) {
						CollectionPersister inboundPersister = (CollectionPersister) itrInbound.next();
						generateEvictInfo(ownerId, inboundPersister, actionQueue);
					}
				}
			}
		}
	}


	/**
	 * Evict from the L2 cache entries for any collection where the getInstance() entity
	 * appears as a collection element.
	 *
	 * @param actionQueue the action queue that is executing this action
	 */
	protected void evictOwningCollectionsFromCache(ActionQueue actionQueue) {

		for ( Iterator itrCacheKey = collectionsToEvict.iterator(); itrCacheKey.hasNext(); ) {
			actionQueue.evict((CacheKey) itrCacheKey.next(), getSession());
		}
	}


	/**
	 * Unlock the L2 cache entries for any collection where the getInstance() entity
	 * appears as a collection element.
	 *
	 * @param success tells us whether or not the transaction succeeded
	 * @param actionQueue the action queue that is executing this action
	 * @throws HibernateException if something goes wrong
	 */
	public void afterTransactionCompletion(boolean success, ActionQueue actionQueue) throws HibernateException {

		HibernateException error = null;

		for ( Iterator itrCacheKey = collectionsToEvict.iterator(); itrCacheKey.hasNext(); ) {
			try {
				actionQueue.unlock((CacheKey) itrCacheKey.next());
			}
			catch (HibernateException e) {
				if (error == null) error = e;
			}
		}

		collectionsToEvict.clear();

		if ( error != null )
			throw error;
	}

	public boolean hasAfterTransactionCompletion()
	{
		return collectionsToEvict.size() > 0 || super.hasAfterTransactionCompletion();
	}


	private Serializable getIdentifier(Object entity, EntityPersister persister, EntityMode entityMode)
	{
		if (entity == null) return null;

		Serializable identifier;

		if (entity instanceof HibernateProxy)
		{
			LazyInitializer li = ((HibernateProxy) entity).getHibernateLazyInitializer();
			identifier = li.getIdentifier();
		}
		else
		{
			identifier = persister.getIdentifier(entity, entityMode);
		}

		return identifier;
	}


	/**
	 * Store info for this PersistentCollection that owns the getInstance() object and lock
	 * its L2 cache entry.  The info is stored so the L2 cache entry can later be evicted,
	 * then unlocked.
	 *
	 * @param ownerId the ID of the owner of the collection that contains the getInstance() entity
	 * @param inboundPersister the persister of the collection that contains the getInstance() entity
	 * @param actionQueue the action queue that is executing this action
	 */
	private void generateEvictInfo(Serializable ownerId, CollectionPersister inboundPersister, ActionQueue actionQueue) {

		// might be a nulled or unsaved entity reference
		if ( ownerId != null ) {

			final CacheKey ck = new CacheKey(
				ownerId,
				inboundPersister.getKeyType(),
				inboundPersister.getRole(),
				getSession().getEntityMode(),
				getSession().getFactory()
			);

			if ( !collectionsToEvict.contains(ck) ) {
				actionQueue.lock(ck, inboundPersister);
				collectionsToEvict.add(ck);
			}
		}
	}


	/**
	 * @return a map of propertyIndex-->inboundPersister specific to the getPersister()
	 * persister.
	 */
	private Map getRolesToEvict() {

		synchronized (entityRolesToEvict) {

			Map rolesToEvict = (Map) entityRolesToEvict.get(getPersister());

			if (rolesToEvict == null) {
				rolesToEvict = generateRolesToEvict(getPersister(), getSession().getFactory());

				// @todo - If many SessionFactories are created during the course of program execution
				// this map would continue to grow.  Does this really need a solution?

				entityRolesToEvict.put(getPersister(), rolesToEvict);
			}

			return rolesToEvict;
		}
	}

	/**
	 * Since it appears to not be possible to match CollectionPersisters to property names on
	 * both sides of the mapping, I conservatively match types instead.
	 *
	 * @return a map of propertyIndex-->inboundPersister specific to the getPersister()
	 * persister.
	 */
	private static Map generateRolesToEvict(EntityPersister persister, SessionFactoryImplementor factory) {

		Map rolesToEvict = new TreeMap();

		Set roles = new TreeSet();

		Set rootEntityRoles = factory.getCollectionRolesByEntityParticipant(persister.getRootEntityName());
		if ( rootEntityRoles != null )
			roles.addAll(rootEntityRoles);

		Set entityRoles = factory.getCollectionRolesByEntityParticipant(persister.getEntityName());
		if ( entityRoles != null )
			roles.addAll(entityRoles);

		for (Iterator itrRoleName = roles.iterator(); itrRoleName.hasNext();) {

			String roleName = (String) itrRoleName.next();
			CollectionPersister inboundPersister = factory.getCollectionPersister(roleName);

			if (!inboundPersister.hasCache())
				continue;

			EntityPersister ownerPersister = inboundPersister.getOwnerEntityPersister();
			String ownerEntityName = ownerPersister.getEntityName();

			final String[] elementPropertyNames = persister.getPropertyNames();

			for (int propertyIndex = 0; propertyIndex < elementPropertyNames.length; propertyIndex++) {

				final Integer iPropertyIndex = new Integer(propertyIndex);
				if (rolesToEvict.containsKey(iPropertyIndex)
					&& ((Set) rolesToEvict.get(iPropertyIndex)).contains(inboundPersister))
					continue;

				String elementPropertyName = elementPropertyNames[propertyIndex];
				Type elementPropertyType = persister.getPropertyType(elementPropertyName);

				boolean evictThisProperty = false;

				if (elementPropertyType instanceof ManyToOneType)
				{
					evictThisProperty =
						((ManyToOneType) elementPropertyType).getAssociatedEntityName().equals(ownerEntityName);
				}
				else if (elementPropertyType instanceof CollectionType)
				{
					CollectionType elPropCollType = (CollectionType) elementPropertyType;
					CollectionPersister elPropCollPersister = factory.getCollectionPersister(elPropCollType.getRole());

					if (elPropCollPersister.getElementType().isEntityType()
						&& elPropCollType.getAssociatedEntityName(factory).equals(ownerEntityName))
						evictThisProperty = true;
				}

				if (evictThisProperty) {
					Set inboundPersisters = (Set) rolesToEvict.get(iPropertyIndex);
					if (inboundPersisters == null) {
						inboundPersisters = new TreeSet(new Comparator(){
							public int compare(Object o1, Object o2) {
								return ((CollectionPersister) o1).getRole().compareTo(((CollectionPersister) o2).getRole());
							}
						});
						rolesToEvict.put(iPropertyIndex, inboundPersisters);
					}
					inboundPersisters.add(inboundPersister);
				}
			}
		}

		return rolesToEvict;
	}

}
