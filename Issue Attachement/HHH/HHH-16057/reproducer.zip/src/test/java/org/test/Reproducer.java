package org.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;
import javax.inject.Inject;

@QuarkusTest
class Reproducer {

    @Inject
    MyService myService;

    @Test
    void test() {
        myService.createEntity(); // creates entity with value "a"
        myService.updateEntity("a");
        assertEquals("a", myService.getEntityValue());
    }
}
