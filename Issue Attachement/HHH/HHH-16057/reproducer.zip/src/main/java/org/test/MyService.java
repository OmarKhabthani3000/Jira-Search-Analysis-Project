package org.test;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;

@ApplicationScoped
public class MyService {

    @Inject
    EntityManager entityManager;

    @Transactional
    public void createEntity() {
        MyEntity myEntity = new MyEntity();
        myEntity.setMyVar("a");
        entityManager.persist(myEntity);

        entityManager.createQuery(
                "select e " +
                        "from MyEntity e", MyEntity.class);
    }

    @Transactional
    public void updateEntity(String value) {
        MyEntity myEntity = entityManager.createQuery(
                "select e " +
                        "from MyEntity e", MyEntity.class).getSingleResult();
        myEntity.setMyVar(value);
    }

    @Transactional
    public String getEntityValue() {
        return entityManager.createQuery(
                "select e " +
                        "from MyEntity e", MyEntity.class).getSingleResult().getMyVar();
    }
}
