package org.test;

import javax.persistence.PreUpdate;

public class MyEntityListener {

    @PreUpdate
    public void onPreUpdate(MyEntity entity) {
        entity.setMyVar("c");
    }
}
