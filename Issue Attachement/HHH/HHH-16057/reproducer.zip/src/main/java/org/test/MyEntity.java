package org.test;

import javax.persistence.*;

@Entity
@EntityListeners(MyEntityListener.class)
public class MyEntity {

    @Id
    @GeneratedValue
    private Long id;

    @Column
    private String myVar;

    public String getMyVar() {
        return myVar;
    }

    public void setMyVar(String myVar) {
        this.myVar = myVar;
    }
}
