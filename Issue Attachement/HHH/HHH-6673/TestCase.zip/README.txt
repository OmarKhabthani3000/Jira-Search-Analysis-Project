Test case does not build as zipped under maven, 
add ojdbc jar to classpath or maven dependencies 
and update the JDBC connection info in the unit-test-context.xml