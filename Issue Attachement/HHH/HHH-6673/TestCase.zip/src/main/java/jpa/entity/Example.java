package jpa.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@org.hibernate.annotations.Entity(dynamicUpdate = true)
@Table(name = "EXAMPLE_TBL")
public class Example {

    Integer id;
    String description;
    int version;
    AuditInfo auditInfo;

    @PreUpdate
    public void beforeUpdate() {
        auditInfo.setUpdateBy("unit-test");
        auditInfo.setUpdateDate(new Date());
    }

    @Id
    @Column(name = "EXAMPLE_ID")
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Column(name = "DESCRIPTION")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Version
    @Column(name = "VERSION")
    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    @Embedded
    public AuditInfo getAuditInfo() {
        return auditInfo;
    }

    public void setAuditInfo(AuditInfo auditInfo) {
        this.auditInfo = auditInfo;
    }

}
