package jpa.test;

import jpa.dao.ExampleDao;
import jpa.entity.Example;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:/unit-test-context.xml")
public class MergePreUpdateTest {

    @Autowired
    ExampleDao dao;

    @Transactional
    @Test
    public void doUpdate() {

        Example example = dao.getEntityManager().find(Example.class,
                new Integer(99));

        dao.getEntityManager().detach(example);

        example.setDescription("updated by unit test");

        dao.getEntityManager().merge(example);
        dao.getEntityManager().flush();
    }
}
