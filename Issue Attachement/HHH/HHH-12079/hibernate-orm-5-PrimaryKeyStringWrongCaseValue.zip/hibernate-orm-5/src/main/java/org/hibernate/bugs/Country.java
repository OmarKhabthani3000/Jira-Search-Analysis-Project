package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 *
 * @author oussama
 */
@Entity
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
@ToString
public class Country {
    
    @Id
    @Column(name = "code", columnDefinition = "VARCHAR_IGNORECASE")
    private String mCode;
    

    public String getCode() {
        return this.mCode;
    }
  
}
