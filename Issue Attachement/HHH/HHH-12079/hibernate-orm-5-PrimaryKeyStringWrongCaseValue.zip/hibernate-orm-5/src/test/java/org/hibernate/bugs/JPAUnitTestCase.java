package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import static org.assertj.core.api.Assertions.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM,
 * using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private static final String EXPECTED_COUNTRY_ID = "USA";    
    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {        
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");        
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    
    @Test
    public void hhh123Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        
        // Persist Country "USA"        
        entityManager.getTransaction().begin();
        entityManager.persist(new Country(EXPECTED_COUNTRY_ID));
        entityManager.getTransaction().commit();
        
        // Find for "USA"
        entityManager.clear();
        entityManager.getTransaction().begin();
        Country countryUSA = entityManager.find(Country.class, "USA");
        entityManager.getTransaction().commit();
        
        assertThat(countryUSA.getCode()).asString().isEqualTo(EXPECTED_COUNTRY_ID);
        
        // Find for "Usa"
        entityManager.clear();
        entityManager.getTransaction().begin();        
        Country countryUsa = entityManager.find(Country.class, "Usa");
        entityManager.getTransaction().commit();
        assertThat(countryUsa.getCode()).asString().isEqualTo(EXPECTED_COUNTRY_ID);
        
        // Find for "uSA"
        entityManager.clear();
        entityManager.getTransaction().begin();
        Country countryuSA = entityManager.find(Country.class, "uSA");
        entityManager.getTransaction().commit();

        assertThat(countryuSA.getCode()).asString().isEqualTo(EXPECTED_COUNTRY_ID);
    }
    
}
