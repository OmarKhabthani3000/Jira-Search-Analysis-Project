package com.example.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Post;
import com.example.demo.repo.PostRepository;

@Service
@Transactional
public class PostService {

	@Autowired
	private PostRepository postRepository;

	public List<Post> list() {
		return postRepository.findAll();
	}

	public Post save(Post post) {
		return postRepository.save(post);
	}

	public Post findById(Long id) {
		return postRepository.findById(id).get();
	}

	public Post updateTitle(Long id, String title) {
		Post post = postRepository.findById(id).get();
		post.setTitle(title);
		return postRepository.saveAndFlush(post);
	}
}
