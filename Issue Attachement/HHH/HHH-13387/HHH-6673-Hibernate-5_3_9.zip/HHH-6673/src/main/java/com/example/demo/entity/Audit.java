package com.example.demo.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

@Embeddable
public class Audit {

	@Column(name = "updated_on")
	private LocalDateTime updatedOn;

	@PrePersist
	@PreUpdate
	public void preUpdate() {
		updatedOn = LocalDateTime.now();
	}

	public LocalDateTime getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(LocalDateTime updatedOn) {
		this.updatedOn = updatedOn;
	}

}
