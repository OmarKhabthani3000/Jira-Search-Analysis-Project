package com.example.demo;

import java.time.LocalDateTime;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.entity.Post;
import com.example.demo.service.PostService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PostServiceTest {

	@Autowired
	private PostService postService;

	@Test
	public void shouldHaveUpdatedAuditDate() {
		Post post = new Post();
		post.setTitle("Old Title");
		Post savedPost = postService.save(post);
		LocalDateTime prevDate = savedPost.getAudit().getUpdatedOn();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		postService.updateTitle(savedPost.getId(), "Updated Title");
		Post updatedPost = postService.findById(savedPost.getId());
		Assert.assertEquals("Updated Title", updatedPost.getTitle());
		LocalDateTime newDate = updatedPost.getAudit().getUpdatedOn();
		Assert.assertTrue(newDate.isAfter(prevDate));
	}

}
