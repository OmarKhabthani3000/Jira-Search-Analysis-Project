package org.hibernate;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.junit.Test;

public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void userTypeTest() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}
}