package money;

public interface CurrencyUnit extends Comparable<CurrencyUnit> {
	String getCurrencyCode();

	int getNumericCode();

	int getDefaultFractionDigits();
}