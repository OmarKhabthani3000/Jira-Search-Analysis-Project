package entities;

import java.util.function.BiConsumer;
import money.CurrencyUnit;
import org.hibernate.type.descriptor.java.BasicJavaType;
import org.hibernate.type.descriptor.jdbc.JdbcType;
import org.hibernate.type.descriptor.jdbc.VarcharJdbcType;
import org.hibernate.usertype.BaseUserTypeSupport;

public class CurrencyUnitUserType extends BaseUserTypeSupport<CurrencyUnit> {

	@Override
	protected void resolve(BiConsumer<BasicJavaType<CurrencyUnit>,JdbcType> resolutionConsumer) {
		resolutionConsumer.accept(
				CurrencyUnitTypeDescriptor.INSTANCE,
				VarcharJdbcType.INSTANCE );
	}
}