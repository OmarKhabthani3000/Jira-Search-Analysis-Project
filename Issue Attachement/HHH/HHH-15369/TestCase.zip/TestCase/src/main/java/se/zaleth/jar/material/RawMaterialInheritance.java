/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import java.util.Date;

/**
 *
 * @author krister
 */
public class RawMaterialInheritance {
    
    private long id;
    private boolean inheritComposition;
    private boolean inheritPrice;
    private boolean inheritCO2Info;
    private double priceDeviationPercentage;
    private double priceDeviationValue;
    private AbstractMaterial ancestor;
    private Date started;
    private Date ended;
    private Date updated;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isInheritComposition() {
        return inheritComposition;
    }

    public void setInheritComposition(boolean inheritComposition) {
        this.inheritComposition = inheritComposition;
    }

    public boolean isInheritPrice() {
        return inheritPrice;
    }

    public void setInheritPrice(boolean inheritPrice) {
        this.inheritPrice = inheritPrice;
    }

    public boolean isInheritCO2Info() {
        return inheritCO2Info;
    }

    public void setInheritCO2Info(boolean inheritCO2Info) {
        this.inheritCO2Info = inheritCO2Info;
    }

    public double getPriceDeviationPercentage() {
        return priceDeviationPercentage;
    }

    public void setPriceDeviationPercentage(double priceDeviationPercentage) {
        this.priceDeviationPercentage = priceDeviationPercentage;
    }

    public double getPriceDeviationValue() {
        return priceDeviationValue;
    }

    public void setPriceDeviationValue(double priceDeviationValue) {
        this.priceDeviationValue = priceDeviationValue;
    }

    public AbstractMaterial getAncestor() {
        return ancestor;
    }

    public void setAncestor(AbstractMaterial ancestor) {
        this.ancestor = ancestor;
    }

    public Date getStarted() {
        return started;
    }

    public void setStarted(Date started) {
        this.started = started;
    }

    public Date getEnded() {
        return ended;
    }

    public void setEnded(Date ended) {
        this.ended = ended;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

}
