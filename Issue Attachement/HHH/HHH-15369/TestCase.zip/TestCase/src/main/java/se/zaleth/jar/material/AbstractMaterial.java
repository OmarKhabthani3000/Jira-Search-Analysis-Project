/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

/**
 *
 * @author krister
 */
public class AbstractMaterial {
    
    private long id;
    private RawMaterialInheritance inheritance;
    
    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }

    public RawMaterialInheritance getInheritance() {
        return inheritance;
    }

    public void setInheritance(RawMaterialInheritance inheritance) {
        this.inheritance = inheritance;
    }

}
