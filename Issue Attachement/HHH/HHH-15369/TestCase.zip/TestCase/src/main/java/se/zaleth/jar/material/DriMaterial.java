/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import se.zaleth.jar.plant.ReductionShaftFurnace;

/**
 *
 * @author krister
 */
public class DriMaterial extends RawMaterial {
    
    private ReductionShaftFurnace furnace;

    public ReductionShaftFurnace getFurnace() {
        return furnace;
    }

    public void setFurnace(ReductionShaftFurnace furnace) {
        this.furnace = furnace;
    }

}
