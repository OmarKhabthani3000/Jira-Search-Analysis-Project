/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import se.zaleth.jar.plant.BlastFurnace;

/**
 *
 * @author krister
 */
public class HotMetalMaterial extends RawMaterial {
    
    private BlastFurnace furnace;
    
    public BlastFurnace getFurnace() {
        return furnace;
    }

    public void setFurnace(BlastFurnace furnace) {
        this.furnace = furnace;
    }

}
