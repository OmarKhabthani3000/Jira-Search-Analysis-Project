/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.hibernate.bugs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.appender.OutputStreamAppender;
import org.apache.logging.log4j.core.config.Configurator;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.Session;
//import org.slf4j.Logger;

import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private SessionFactory sf;
        
	@Before
	public void setup() {
            
		StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
			// Add in any settings that are specific to your test. See resources/hibernate.properties for the defaults.
                        .configure("hibernate.cfg.xml")
			.applySetting( "hibernate.show_sql", "true" )
			.applySetting( "hibernate.format_sql", "true" )
			/*.applySetting( "hibernate.hbm2ddl.auto", "update" )*/;

                try {
		MetadataSources metadataSources = new MetadataSources( srb.build() );
		// Add your entities here.
                metadataSources
		//	.addAnnotatedClass( Foo.class )
                        .addResource("META-INF/Material.hbm.xml")
                        .addResource("META-INF/ProductionUnit.hbm.xml")
                        .addResource("META-INF/RawMaterialInheritance.hbm.xml")
                        ;
                Metadata metadata = metadataSources.buildMetadata();
		sf = metadata.buildSessionFactory();
                } catch(NullPointerException e) {
                    e.printStackTrace();
                    throw e;
                }
	}

	// Add your tests, using standard JUnit.
	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
            // No actual tests to be run, crash happens when creating the Session Factory
            Session session = sf.openSession();
	}
}
