--  Test case for MySQL
create database TEST;
use TEST;

create table WIDGET ( 
 CODE varchar( 3 ) not null, 
 DIVISION varchar( 4 ) not null, 
 COST double not null, 
 constraint PK_WIDGET primary key( CODE, DIVISION ) 
 );
 
 insert into WIDGET( CODE, DIVISION, COST ) values( 'AAA', 'NA', 10.00 );
 insert into WIDGET( CODE, DIVISION, COST ) values( 'AAA', 'EU', 12.50 );
 insert into WIDGET( CODE, DIVISION, COST ) values( 'AAA', 'ASIA', 110.00 );
 insert into WIDGET( CODE, DIVISION, COST ) values( 'BBB', 'NA', 14.00 );
 insert into WIDGET( CODE, DIVISION, COST ) values( 'BBB', 'EU', 8.75 );
 insert into WIDGET( CODE, DIVISION, COST ) values( 'BBB', 'ASIA', 86.22 );
 
 commit;