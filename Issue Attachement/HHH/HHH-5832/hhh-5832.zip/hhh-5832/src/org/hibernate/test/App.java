package org.hibernate.test;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;
import javax.persistence.criteria.*;

public class App {
	private static EntityManager em;
	private static EntityManagerFactory factory;
	
	public static void main( String[ ] args ) {
		try {
			System.out.println( "Packaging arguments for use in query." );
			List<String> divisions = new ArrayList<String>( );
			for( String arg : args ) divisions.add( arg );
			System.out.println( "Arguments are " + divisions.toString( ) );
			
			System.out.println( "Building the query." );
			CriteriaBuilder criteria = em.getCriteriaBuilder( );
			CriteriaQuery<Widget> query = criteria.createQuery( Widget.class );
			Root<Widget> root = query.from( Widget.class );
			
			System.out.println( "This call should result in a NullPointerException if the original code is used." );
			Predicate predicate = root.get( "division" ).in( divisions );  //  The call to get( "division" ) should return null and cause an error.
			query.where( predicate );
			
			System.out.println( "Retrieving query." );
			List<Widget> widgets = em.createQuery( query ).getResultList( );
			for( Widget widget : widgets ) System.out.println( widget.toString( ) );
		} catch( Exception e ) {
			e.printStackTrace( );
		}
	}
	
	static {
		factory = Persistence.createEntityManagerFactory( "test" );
		em = factory.createEntityManager( );
	}
}
