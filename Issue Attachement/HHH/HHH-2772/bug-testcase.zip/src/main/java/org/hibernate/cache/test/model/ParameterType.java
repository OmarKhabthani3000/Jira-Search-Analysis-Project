package org.hibernate.cache.test.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class ParameterType {

	private long id;
	private TypeInterface interfaceType;	

	@Id
	@GeneratedValue
	public long getId() {
		return id;
	}

	protected void setId(long id) {
		this.id = id;
	}

	@ManyToOne()
	public TypeInterface getInterfaceType() {
		return interfaceType;
	}

	public void setInterfaceType(TypeInterface interfaceType) {
		this.interfaceType = interfaceType;
	}
}
