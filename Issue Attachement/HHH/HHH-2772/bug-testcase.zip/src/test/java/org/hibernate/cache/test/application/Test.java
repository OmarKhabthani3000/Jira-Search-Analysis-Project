package org.hibernate.cache.test.application;

import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Test extends TestCase{

	public static void testLeftJoinWith() throws Exception{
		try{
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("org.hibernate.test");
			SessionFactory factory = entityManagerFactory.unwrap(SessionFactory.class);		
			Session session = factory.openSession();
			session.beginTransaction();

			Query query = session.createQuery("SELECT interInst, typeInter, paramType, paramValue "
					+ "FROM InterfaceInstance interInst "
					+ "JOIN interInst.type AS typeInter "
					+ "JOIN typeInter.parameterTypes AS paramType "
					+ "LEFT JOIN interInst.parameterValues AS paramValue  WITH paramValue.type=paramType");

			List list = query.list();
			session.close();
			factory.close();
		}
		catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
}
