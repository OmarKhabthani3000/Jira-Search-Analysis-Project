package hibernate.bug;

import hibernate.bug.model.InterfaceInstance;
import hibernate.bug.model.ParameterType;
import hibernate.bug.model.ParameterValue;
import hibernate.bug.model.TypeInterface;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        TypeInterface ti = new TypeInterface("ti1");
        InterfaceInstance ii = new InterfaceInstance(ti);
        ParameterType pt = new ParameterType(ti);
        ParameterValue pv = new ParameterValue(pt, ii);
        
        em.persist(ti);
        em.persist(ii);
        em.persist(pt);
        em.persist(pv);
        
        ii.getParameterValues().add(pv);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        
        ParameterType type = em.createQuery("FROM ParameterType pt WHERE pt.interfaceType.code = :code", ParameterType.class)
                .setParameter("code", "ti1")
                .getSingleResult();
        List<Object[]> l = em.createQuery(
                "SELECT interInst, typeInter, paramType, paramValue "
                + "FROM InterfaceInstance interInst "
                + "JOIN interInst.type AS typeInter "
                + "JOIN typeInter.parameterTypes AS paramType "
                + "LEFT JOIN interInst.parameterValues AS paramValue WITH paramValue.type = :paramType")
                .setParameter("paramType", type)
                .getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
}
