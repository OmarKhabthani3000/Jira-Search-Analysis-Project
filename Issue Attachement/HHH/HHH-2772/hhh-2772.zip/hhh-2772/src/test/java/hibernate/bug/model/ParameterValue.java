package hibernate.bug.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class ParameterValue {

    private long id;
    private ParameterType type;
    private InterfaceInstance interfaceInstance;

    public ParameterValue() {
    }

    public ParameterValue(ParameterType type, InterfaceInstance interfaceInstance) {
        this.type = type;
        this.interfaceInstance = interfaceInstance;
    }

    @Id
    @GeneratedValue
    public long getId() {
        return id;
    }

    protected void setId(long id) {
        this.id = id;
    }

    @ManyToOne
    public ParameterType getType() {
        return type;
    }

    public void setType(ParameterType type) {
        this.type = type;
    }

    @ManyToOne
    public InterfaceInstance getInterfaceInstance() {
        return interfaceInstance;
    }

    public void setInterfaceInstance(InterfaceInstance interfaceInstance) {
        this.interfaceInstance = interfaceInstance;
    }

}
