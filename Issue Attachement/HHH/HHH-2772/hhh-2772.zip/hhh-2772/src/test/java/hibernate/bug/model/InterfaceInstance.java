package hibernate.bug.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class InterfaceInstance {

    private long id;
    private TypeInterface type;
    private List<ParameterValue> parameterValues = new ArrayList<ParameterValue>();

    public InterfaceInstance() {
    }

    public InterfaceInstance(TypeInterface type) {
        this.type = type;
    }

    @Id
    @GeneratedValue
    public long getId() {
        return id;
    }

    protected void setId(long id) {
        this.id = id;
    }

    @ManyToOne
    public TypeInterface getType() {
        return type;
    }

    public void setType(TypeInterface type) {
        this.type = type;
    }

    @OneToMany(mappedBy = "interfaceInstance")
    public List<ParameterValue> getParameterValues() {
        return parameterValues;
    }

    public void setParameterValues(List<ParameterValue> parameterValues) {
        this.parameterValues = parameterValues;
    }
}
