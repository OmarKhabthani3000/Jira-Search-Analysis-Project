package org.dseas.base.model;

import java.util.ArrayList;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.dseas.base.constants.IDomainConstants.CodeTypeAddress;
import org.dseas.base.constants.IDomainConstants.CodeTypeAddressRelation;
import org.dseas.base.constants.IDomainConstants.CodeTypeNoYes;
import org.dseas.base.constants.IDomainConstants.CodeTypeOrganisation;
import org.dseas.base.entities.PatientEntity;

/**
 * @author Christoph Mayerhofer
 *
 */
@Entity
@Table(name = "PATIENT")
public class Patient extends PatientEntity {

	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor which adds a main address to the patient.
	 */
	public Patient() {
		// set default values
		setCodeTypeAddInsurance(CodeTypeNoYes.NO);
		setCodeTypePrescChargeFree(CodeTypeNoYes.NO);
	}

	/**
	 * Get all contacts sorted.
	 * 
	 * @return
	 */
	@Transient
	public Set<Contact> getSortedContacts() {
		return Contact.sortBySeqNo(super.getContacts());
	}

	/**
	 * Get the main address of the patient.
	 */
	@Transient
	public Address getMainAddress() {
		Address mainAddress = Address.getMainAddress(getAddresses());

		if (mainAddress == null) {
			mainAddress = new Address();
			mainAddress.setPatient(this);
			mainAddress.setCodeTypeAddress(CodeTypeAddress.MAIN);
			mainAddress
					.setCodeTypeAddressRelation(CodeTypeAddressRelation.PATIENT);

			getAddresses().add(mainAddress);
		}

		return mainAddress;
	}

	/**
	 * Get the additional addresses of the patient.
	 */
	@Transient
	public Set<Address> getAdditionalAddresses() {
		return Address.getAdditionalAddresses(getAddresses());
	}

	/**
	 * Get the full name of the patient.
	 */
	@Transient
	public String getTxtLastFirstName() {
		StringBuffer s = new StringBuffer();
		if (txtLastName != null) {
			s.append(txtLastName);
		}

		if (txtFirstName != null) {
			s.append(" " + txtFirstName);
		}

		return s.toString();
	}

	/**
	 * Get the patient organisation for the patient's employer.
	 * 
	 * @return PatientOrganisation
	 */
	@Transient
	public PatientOrganisation getPatientOrganisationEmployer() {
		for (PatientOrganisation org : getPatientOrganisations()) {
			if (org.getOrganisation().getCodeType().equals(
					CodeTypeOrganisation.EMPLOYER)) {
				return org;
			}
		}

		return null;
	}

	/**
	 * Get the organisation for the patient's employer.
	 */
	@Transient
	public Organisation getOrganisationEmployer() {
		PatientOrganisation po = getPatientOrganisationEmployer();
		if (po != null) {
			return po.getOrganisation();
		}

		return null;
	}

	/**
	 * Get the patient organisation for the patient's doctor.
	 * 
	 * @return PatientOrganisation
	 */
	@Transient
	public PatientOrganisation getPatientOrganisationDoctor() {
		for (PatientOrganisation org : getPatientOrganisations()) {
			if (org.getOrganisation().getCodeType().equals(
					CodeTypeOrganisation.DOCTOR)) {
				return org;
			}
		}

		return null;
	}

	/**
	 * Get the organisation for the patient's doctor.
	 */
	@Transient
	public Organisation getOrganisationDoctor() {
		PatientOrganisation po = getPatientOrganisationDoctor();
		if (po != null) {
			return po.getOrganisation();
		}

		return null;
	}

	/**
	 * Get the PatientSocialInsurance for a SocialInsurance.
	 * 
	 * @param s
	 * @return
	 */
	@Transient
	public PatientSocialInsurance getPatientSocialInsurance(SocialInsurance s) {
		for (PatientSocialInsurance ps : getPatientSocialInsurances()) {
			if (ps.getSocialInsurance().equals(s)) {
				return ps;
			}
		}
		return null;
	}

	/**
	 * Get the default social insurance of the patient.
	 * 
	 * @return The default social insurance, or null if no one exists.
	 */
	@Transient
	public SocialInsurance getDefaultSocialInsurance() {
		for (PatientSocialInsurance ps : getPatientSocialInsurances()) {
			if (ps.getCodeTypeDefault().equals(CodeTypeNoYes.YES)) {
				return ps.getSocialInsurance();
			}
		}
		return null;
	}

	/**
	 * Get all social insurances of the patient.
	 * 
	 * @return
	 */
	@Transient
	public ArrayList<SocialInsurance> getSocialInsurances() {
		ArrayList<SocialInsurance> insurances = new ArrayList<SocialInsurance>();
		for (PatientSocialInsurance ps : getPatientSocialInsurances()) {
			insurances.add(ps.getSocialInsurance());
		}
		return insurances;
	}

	/**
	 * Checks if some insurant data is set.
	 * 
	 * @param patient
	 * @return
	 */
	@Transient
	public boolean hasInsurantData() {
		if (getTxtLastNameInsurant() != null
				&& getTxtLastNameInsurant().length() > 0) {
			return Boolean.TRUE;
		}

		if (getTxtFirstNameInsurant() != null
				&& getTxtFirstNameInsurant().length() > 0) {
			return Boolean.TRUE;
		}

		if (getTxtTitleInsurant() != null && getTxtTitleInsurant().length() > 0) {
			return Boolean.TRUE;
		}

		if (getCodeTypeSexInsurant() != null) {
			return Boolean.TRUE;
		}

		if (getDateBirthInsurant() != null) {
			return Boolean.TRUE;
		}

		if (getValSinoInsurant() != null) {
			return Boolean.TRUE;
		}

		return Boolean.FALSE;
	}

	/**
	 * Checks if the patient has an insurant set.
	 * 
	 * @return
	 */
	@Transient
	public boolean hasInsurant() {
		return hasInsurantData() || (getPatientInsurant() != null);
	}
}