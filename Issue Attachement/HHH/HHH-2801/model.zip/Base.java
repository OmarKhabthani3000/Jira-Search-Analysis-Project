package org.dseas.base.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.GenericGenerator;

/**
 * The base class for all POJOs. This class is defined as MappedSuperclass. All
 * mapping information is applied to the entities that inherit from it. A mapped
 * superclass has no separate table defined for it.
 * 
 * @author Christoph Mayerhofer
 */

@MappedSuperclass
public class Base {

	protected String id;

	protected AppUser userCre;

	protected AppUser userUpd;

	protected Date timeCre;

	protected Date timeUpd;

	@GenericGenerator(name = "generator", strategy = "guid", parameters = {})
	@Id
	@Column(name = "ID", unique = true, nullable = false, insertable = true, updatable = true, length = 38)
	@GeneratedValue(generator = "generator")
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "USER_CRE", unique = false, nullable = false, insertable = true, updatable = true)
	public AppUser getUserCre() {
		return this.userCre;
	}

	public void setUserCre(AppUser userCre) {
		this.userCre = userCre;
	}

	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "USER_UPD", unique = false, nullable = true, insertable = true, updatable = true)
	public AppUser getUserUpd() {
		return this.userUpd;
	}

	public void setUserUpd(AppUser userUpd) {
		this.userUpd = userUpd;
	}

	@Column(name = "TIME_CRE", unique = false, nullable = false, insertable = true, updatable = true, length = 11)
	public Date getTimeCre() {
		return this.timeCre;
	}

	public void setTimeCre(Date timeCre) {
		this.timeCre = timeCre;
	}

	@Column(name = "TIME_UPD", unique = false, nullable = true, insertable = true, updatable = true, length = 11)
	public Date getTimeUpd() {
		return this.timeUpd;
	}

	public void setTimeUpd(Date timeUpd) {
		this.timeUpd = timeUpd;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Base) {
			Base base = (Base) obj;
			if (base.getId() != null && id != null) {
				return base.getId().equals(id);
			} else {
				return super.equals(obj);
			}
		} else {
			return false;
		}
	}
}
