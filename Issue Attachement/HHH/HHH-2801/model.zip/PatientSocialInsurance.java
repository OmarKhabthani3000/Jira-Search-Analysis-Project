package org.dseas.base.model;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.dseas.base.entities.PatientSocialInsuranceEntity;

/**
 * @author Christoph Mayerhofer
 *
 */
@Entity
@Table(name = "PATIENT_SOCIAL_INSURANCE", uniqueConstraints = @UniqueConstraint(columnNames = {
	"PATIENT_ID", "SOC_INS_ID" }))
public class PatientSocialInsurance extends PatientSocialInsuranceEntity {

	private static final long serialVersionUID = 1L;
}