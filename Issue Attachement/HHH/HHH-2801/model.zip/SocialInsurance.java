package org.dseas.base.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import org.dseas.base.constants.IDomainConstants.CodeTypeAddress;
import org.dseas.base.constants.IDomainConstants.CodeTypeAddressRelation;
import org.dseas.base.entities.SocialInsuranceEntity;

/**
 * @author Christoph Mayerhofer
 *
 */
@Entity
@Table(name = "SOCIAL_INSURANCE", uniqueConstraints = @UniqueConstraint(columnNames = {
	"SOC_INS_GRP_ID", "CODE_ID" }))
public class SocialInsurance extends SocialInsuranceEntity {

	private static final long serialVersionUID = 1L;

	/**
	 * Get all contacts sorted.
	 * 
	 * @return
	 */
	@Transient
	public Set<Contact> getSortedContacts() {
		return Contact.sortBySeqNo(super.getContacts());
	}

	/**
	 * Get the main address of the social insurance.
	 */
	@Transient
	public Address getMainAddress() {
		Address mainAddress = Address.getMainAddress(getAddresses());

		if (mainAddress == null) {
			mainAddress = new Address();
			mainAddress.setSocialInsurance(this);
			mainAddress.setCodeTypeAddress(CodeTypeAddress.MAIN);
			mainAddress
				.setCodeTypeAddressRelation(CodeTypeAddressRelation.SOCINS);

			getAddresses().add(mainAddress);
		}

		return mainAddress;
	}

	/**
	 * Get the additional addresses of the social insurance.
	 */
	@Transient
	public Set<Address> getAdditionalAddresses() {
		return Address.getAdditionalAddresses(getAddresses());
	}

	/**
	 * Get the codeId and the name of the social insurance.
	 * 
	 * @return
	 */
	@Transient
	public String getCodeIdTxtName() {
		if (txtName != null) {
			return codeId + ", " + txtName;
		} else {
			return codeId;
		}
	}

	/**
	 * Get the codeId or the name of the social insurance.
	 * 
	 * @return
	 */
	@Transient
	public String getCodeIdOrTxtName() {
		if (txtName != null) {
			return txtName;
		} else {
			return codeId;
		}
	}
}