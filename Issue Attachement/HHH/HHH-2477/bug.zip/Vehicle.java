package test.hibernate;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name="tab_vehicle",schema="test")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="type",discriminatorType=DiscriminatorType.CHAR)
/* note that without DiscriminatorValue hibernate raise error,
 * but with DiscriminatorValue netbeans complains that can be only specified for
 * concrete entity */
@DiscriminatorValue("V")
public abstract class Vehicle implements Serializable
{
  private Integer idVehicle;
  
  public Vehicle()
  {
  }

  public boolean equals(Object o)
  {
    if (o==null)
      return false;
    if (!(o instanceof Vehicle))
      return false;
    if (this.getIdVehicle()==null)
      return false;
    Vehicle v = (Vehicle)o;
    return this.getIdVehicle().equals(v.getIdVehicle());
  }
  
  public int hashCode()
  {
    return this.getIdVehicle()!=null ? this.getIdVehicle() : 0;
  }
  
  @Id
  @Column(name="id_vehicle",nullable=false)
  public Integer getIdVehicle()
  {
    return idVehicle;
  }
  public void setIdVehicle(Integer idBase)
  {
    this.idVehicle = idBase;
  }
}
