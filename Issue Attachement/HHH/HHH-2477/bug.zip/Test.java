package test.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Test
{
  public static void main(String args[])
  {
    AnnotationConfiguration cfg = new AnnotationConfiguration();
    cfg.addAnnotatedClass(test.hibernate.User.class);
    cfg.addAnnotatedClass(test.hibernate.Vehicle.class);
    cfg.addAnnotatedClass(test.hibernate.Car.class);
    cfg.setProperty("hibernate.dialect","org.hibernate.dialect.PostgreSQLDialect");
    cfg.setProperty("hibernate.max_fetch_depth","8");
    cfg.setProperty("show_sql","false");
    cfg.setProperty("hibernate.connection.driver_class","org.postgresql.Driver");
    cfg.setProperty("hibernate.connection.url","jdbc:postgresql://127.0.0.1/test");
    cfg.setProperty("hibernate.connection.username","test");
    cfg.setProperty("hibernate.connection.password","test");
    
    SessionFactory sf = null;
    Session s = null;
    Transaction tx = null;
    try
    {
      sf = cfg.buildSessionFactory();
      s = sf.openSession();
      tx = s.beginTransaction();
      
      //create car
      Car car = new Car();
      car.setIdVehicle(1);
      car.setAge(5);
      s.save(car);
      
      //create user of car
      User user = new User();
      user.setIdUser(1);
      user.setVehicle(car);
      s.save(user);
      
      //make sure it is actually added
      s.flush();

      // test 1 - works ok, because we loaded vehicle before user
      s.clear(); //clear cache
      Vehicle vv = (Vehicle)s.get(Vehicle.class, 1);
      User uu = (User)s.get(User.class, 1);
      //we know that user vehicle is actually a Car
      Car cc = (Car)uu.getVehicle();
      
      // test 2 - fails, when using lazy fetching
      s.clear(); //clear cache
      User u = (User)s.get(User.class, 1);
      Vehicle v = u.getVehicle();
      //we know that user vehicle is actually a Car
      //so we cast to Car but ClassCastException is raised!!!
      Car c = (Car)v;
      //let's check what's the class of v
      System.out.println(v.getClass().getName());
      System.out.println(v.getClass().getSuperclass().getName());
      //result:
      //  test.hibernate.Vehicle$$EnhancerByCGLIB$$12ce1883
      //  test.hibernate.Vehicle
      //but I expected:
      //  test.hibernate.Car$$EnhancerByCGLIB$$xxxxx
      //  test.hibernate.Car
    }
    finally
    {
      if (tx!=null)
        tx.rollback();
      if (s!=null)
        s.close();
      if (sf!=null)
        sf.close();
    }
  }
}
