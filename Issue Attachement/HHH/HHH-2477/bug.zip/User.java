package test.hibernate;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="tab_user",schema="test")
public class User implements Serializable
{
  private Integer idUser;
  private Vehicle vehicle;
  
  public User()
  {
  }

  public boolean equals(Object o)
  {
    if (o==null)
      return false;
    if (!(o instanceof User))
      return false;
    if (this.getIdUser()==null)
      return false;
    User p = (User)o;
    return this.getIdUser().equals(p.getIdUser());
  }
  
  public int hashCode()
  {
    return this.getIdUser()!=null ? this.getIdUser() : 0;
  }
  
  @Id
  @Column(name="id_user",nullable=false)
  public Integer getIdUser()
  {
    return idUser;
  }
  public void setIdUser(Integer idUser)
  {
    this.idUser = idUser;
  }

  @ManyToOne(fetch=FetchType.LAZY)
  @JoinColumn(name="fk_vehicle",nullable=false)
  public Vehicle getVehicle()
  {
    return vehicle;
  }
  public void setVehicle(Vehicle vehicle)
  {
    this.vehicle = vehicle;
  }

}
