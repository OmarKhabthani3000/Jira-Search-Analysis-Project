package test.hibernate;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("C")
public class Car extends Vehicle
{
  private int age;
  
  public Car()
  {
  }

  @Basic
  @Column(name="age",nullable=true)
  public int getAge()
  {
    return age;
  }
  public void setAge(int age)
  {
    this.age = age;
  }

  
}
