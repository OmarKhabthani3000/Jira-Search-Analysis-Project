package com.domain;

import java.io.Serializable;

/**
 * @hibernate.class table = "EMPLOYEE" schema = "COMPANY"
 */
public class Employee implements Serializable {

	private Long _id;

	private String _name;

	/**
	 * @hibernate.id generator-class = "assigned" column="EMPLOYEE_ID"
	 *               type = "long"
	 * @return
	 */
	public Long getId() {
		return _id;
	}

	public void setId(Long id) {
		_id = id;
	}

	/**
	 * @hibernate.property type = "string" column = "EMPLOYEE_NAME"
	 * @return
	 */
	public String getName() {
		return _name;
	}

	public void setName(String name) {
		_name = name;
	}



}
