package com.domain;

import java.io.Serializable;
import java.util.Set;

/**
 * @hibernate.class table = "DEPARTMENT" schema = "COMPANY"
 */
public class Department implements Serializable {

	private Long _id;

	private String _name;

	private Set _employees;

	/**
	 * @hibernate.set inverse = "true" cascade="all-delete-orphan"
	 * @hibernate.one-to-many class="com.domain.Employee"
	 * @hibernate.key column = "DEPARTMENT_ID"
	 * @return
	 */
	public Set getEmployees() {
		return _employees;
	}

	public void setEmployees(Set employees) {
		_employees = employees;
	}

	/**
	 * @hibernate.id generator-class = "assigned" column="DEPARTMENT_ID"
	 *               type = "long"
	 * @return
	 */
	public Long getId() {
		return _id;
	}

	public void setId(Long id) {
		_id = id;
	}

	/**
	 * @hibernate.property type = "string" column = "DEPARTMENT_NAME"
	 * @return
	 */
	public String getName() {
		return _name;
	}

	public void setName(String name) {
		_name = name;
	}

}
