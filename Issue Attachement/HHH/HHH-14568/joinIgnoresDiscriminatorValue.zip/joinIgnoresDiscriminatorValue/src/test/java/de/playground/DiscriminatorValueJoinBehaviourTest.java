package de.playground;

import de.playground.entity.Animal;
import de.playground.entity.Cat;
import de.playground.entity.Dog;
import de.playground.entity.Zoo;
import de.playground.util.EMUtils;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import static org.junit.Assert.assertEquals;

public class DiscriminatorValueJoinBehaviourTest {
    private static EntityManagerFactory emf;
    private EntityManager em;

    @BeforeClass
    public static void beforeClass() {
        emf = EMUtils.createEntityManagerFactory(Animal.class.getPackage().getName());
    }

    @Before
    public void setUp() {
        em = emf.createEntityManager();
        em.getTransaction().begin();
    }

    @After
    public void tearDown() {
        EMUtils.rollbackAndClose(em);
    }

    @AfterClass
    public static void afterClass() {
        if (emf != null) {
            emf.close();
        }
    }

    @Test
    public void entityJoin_discriminatorValueIsFiltered() {
        var zoo = new Zoo();
        zoo.addDog(new Dog());
        zoo.addCat(new Cat());
        em.persist(zoo);
        em.flush();
        long count = ((Long) em.createQuery("select count(zoo)\n" +
                "from Zoo zoo\n" +
                "  inner join Dog dog with dog.zoo = zoo").getResultList().get(0));
        // this fails !!
        assertEquals(1, count);

    }

    @Test
    public void implicitJoinPath_discriminatorValueIsFiltered() {
        var zoo = new Zoo();
        zoo.addDog(new Dog());
        zoo.addCat(new Cat());
        em.persist(zoo);
        em.flush();
        long count = ((Long) em.createQuery("select count(zoo)\n" +
                "from Zoo zoo\n" +
                "  inner join zoo.dogs as dog").getResultList().get(0));
        assertEquals(1, count);
    }
}
