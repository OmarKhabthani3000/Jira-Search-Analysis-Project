package de.playground.util;

import org.hibernate.cfg.AvailableSettings;
import org.hibernate.dialect.H2Dialect;
import org.hibernate.jpa.HibernatePersistenceProvider;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

public final class EMUtils {

    private EMUtils() {
    }

    public static EntityManagerFactory createEntityManagerFactory(String... entityPackages) {
        LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
        factoryBean.setPersistenceProviderClass(HibernatePersistenceProvider.class);
        factoryBean.setJpaPropertyMap(createDefaultJpaProperties());
        factoryBean.setPersistenceUnitName("default");
        factoryBean.setPackagesToScan(entityPackages);
        factoryBean.setDataSource(createInMemoryDataSource());
        factoryBean.afterPropertiesSet();
        return factoryBean.getNativeEntityManagerFactory();
    }

    private static Map<String, String> createDefaultJpaProperties() {
        Map<String, String> jpaProperties = new HashMap<>();
        jpaProperties.put(AvailableSettings.HBM2DDL_AUTO, "update");
        jpaProperties.put(AvailableSettings.DIALECT, H2Dialect.class.getName());
        return jpaProperties;
    }

    private static DataSource createInMemoryDataSource() {
        return new SingleConnectionDataSource("jdbc:h2:mem:;", true);
    }

    public static void rollbackAndClose(EntityManager em) {
        try {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
        } finally {
            if (em.isOpen()) {
                em.close();
            }
        }
    }
}
