package de.playground.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Zoo {
    @Id
    @GeneratedValue
    private Long id;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "zoo", targetEntity = Cat.class, fetch = FetchType.LAZY, orphanRemoval = true)
    private final List<Cat> cats = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "zoo", targetEntity = Dog.class, fetch = FetchType.LAZY, orphanRemoval = true)
    private final List<Dog> dogs = new ArrayList<>();

    public List<Cat> getCats() {
        return cats;
    }

    public void addCat(Cat cat) {
        cat.setZoo(this);
        cats.add(cat);
    }

    public List<Dog> getDogs() {
        return dogs;
    }

    public void addDog(Dog dog) {
        dog.setZoo(this);
        dogs.add(dog);
    }
}
