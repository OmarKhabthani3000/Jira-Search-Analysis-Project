package de.mc;

import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.jboss.logging.Logger;

@Singleton
@Startup
public class Reproducer
{
    private static final Logger LOGGER = Logger.getLogger(Reproducer.class);
    
    @PersistenceContext
    private EntityManager em;
    
    @Schedule(second="*/5", minute="*",hour="*", persistent=false)
    public void doWork()
    {
        LOGGER.info(System.currentTimeMillis());
        em.persist(new ReproducerEntity());
    }
}
