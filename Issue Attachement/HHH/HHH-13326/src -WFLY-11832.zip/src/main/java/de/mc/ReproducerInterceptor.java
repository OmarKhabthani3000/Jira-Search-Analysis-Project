package de.mc;

import org.hibernate.EmptyInterceptor;
import org.hibernate.Transaction;
import org.jboss.logging.Logger;

public class ReproducerInterceptor extends EmptyInterceptor
{
    private static final long serialVersionUID = -3835545677430831921L;
    private static final Logger LOGGER = Logger.getLogger(ReproducerInterceptor.class);
    
    @Override
    public void afterTransactionCompletion(Transaction tx)
    {
        LOGGER.info(tx.getTimeout());
    }
}
