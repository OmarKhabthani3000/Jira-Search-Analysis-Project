package com.adsoul.hbnbug.a;

import java.io.IOException;

public interface A {
    void a(IOException e);
}
