package com.adsoul.hbnbug.b;

import com.adsoul.hbnbug.a.A;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class B extends FileOutputStream implements A {
    public B(String name) throws FileNotFoundException {
        super(name);
    }

    @Override
    public void a(IOException e) {
    }
}
