//$Id: EntityTest.java 14203 2007-11-19 17:12:16Z epbernard $

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import test.EntityWithEnum;

/**
 * @author Emmanuel Bernard
 */
public class EntityTest extends TestCase {

    public EntityTest(String x) {
	super(x);
    }

    public void testBasic() throws Exception {
	Session s = openSession();
	Transaction tx = s.beginTransaction();
	EntityWithEnum e1 = new EntityWithEnum();
	try {
	    Query q = s
		    .createQuery("select e.name from EntityWithEnum e ,EntityWithEnum where  e.id = id AND  scope = :dd");
	    q.setParameter("dd", EntityWithEnum.Role.SCOPE1);
	    List l = q.list();
	    tx.commit();
	} catch (Exception e) {
	    // success
	    if (tx != null)
		tx.rollback();
	} finally {
	    s.close();
	}
    }

    /**
     * @see org.hibernate.test.annotations.TestCase#getMappings()
     */
    protected Class[] getMappings() {
	return new Class[] { EntityWithEnum.class };
    }

}
