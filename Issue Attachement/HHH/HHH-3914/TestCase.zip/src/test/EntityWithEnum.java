/**
 * Copyright (c) 2008 Toyota Manufacturing Europe. All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are not permitted.
 */
package test;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

/**
 * 
 * 
 * 
 * @revision $Revision$
 * @author $Author$
 * 
 * 
 */
@Entity
public class EntityWithEnum {

    /**
     * 
     * 
     * 
     * @revision $Revision$
     * @author $Author$
     * 
     * 
     */
    public enum Role {
	SCOPE1, SCOPE2, SCOPE3

    }

    private int id;
    private String name;
    private Role scope;

    @Id
    public int getId() {
	return id;
    }

    public void setId(int id) {
	this.id = id;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    @Enumerated(EnumType.STRING)
    public Role getScope() {
	return scope;
    }

    public void setScope(Role scope) {
	this.scope = scope;
    }

}
