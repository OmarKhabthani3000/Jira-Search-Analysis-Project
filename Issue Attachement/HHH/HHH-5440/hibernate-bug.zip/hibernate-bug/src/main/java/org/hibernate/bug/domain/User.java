package org.hibernate.bug.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Configurable;

@Entity
@Table(name = "USERS")
@Access(AccessType.FIELD)
@Configurable
public class User implements Serializable {

	@SuppressWarnings("unused")
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;

	@Column(name = "USERNAME", unique = true, nullable = false, length = 128)
	private String username;

	@ElementCollection
	@Enumerated(EnumType.STRING)
	@Column(name = "ROLE")
	@CollectionTable(name = "USER_ROLES", joinColumns = @JoinColumn(name = "USER_ID"))
	private Set<Role> roles = new HashSet<Role>();

	@SuppressWarnings("unused")
	private User() {
	}

	public User(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public User addRole(Role role) {
		roles.add(role);
		return this;
	}

	public User removeRole(Role role) {
		roles.remove(role);
		return this;
	}

	public boolean hasRole(Role role) {
		return roles.contains(role);
	}

	public List<Role> getRoles() {
		return Collections.unmodifiableList(new ArrayList<Role>(roles));
	}

}
