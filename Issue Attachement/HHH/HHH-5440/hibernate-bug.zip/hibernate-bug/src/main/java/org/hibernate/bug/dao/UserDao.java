package org.hibernate.bug.dao;

import java.util.List;
import java.util.Set;

import org.hibernate.bug.domain.Role;
import org.hibernate.bug.domain.User;

public interface UserDao {

	void persist(User user);

	List<User> findByRoles(Set<Role> roles);

}
