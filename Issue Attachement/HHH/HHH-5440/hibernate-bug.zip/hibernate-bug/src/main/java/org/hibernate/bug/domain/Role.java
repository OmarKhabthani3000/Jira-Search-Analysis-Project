package org.hibernate.bug.domain;

public enum Role {

	ROLE_1, ROLE_2, ROLE_3;

}
