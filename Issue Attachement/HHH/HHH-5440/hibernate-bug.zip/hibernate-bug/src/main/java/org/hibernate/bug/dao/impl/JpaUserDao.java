package org.hibernate.bug.dao.impl;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.bug.dao.UserDao;
import org.hibernate.bug.domain.Role;
import org.hibernate.bug.domain.User;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository(value = "userDao")
public class JpaUserDao implements UserDao {

	@PersistenceContext(unitName = "DefaultPersistenceUnit")
	private EntityManager entityManager;

	@Override
	@Transactional
	public void persist(User user) {
		entityManager.persist(user);
	}

	@Override
	public List<User> findByRoles(Set<Role> roles) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<User> criteriaQuery = criteriaBuilder.createQuery(User.class);
		criteriaQuery.distinct(true);

		Root<User> root = criteriaQuery.from(User.class);

		criteriaQuery.where(root.join("roles").in(roles));

		TypedQuery<User> query = entityManager.createQuery(criteriaQuery);
		return query.getResultList();
	}

}
