package org.hibernate.bug;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.bug.dao.UserDao;
import org.hibernate.bug.domain.Role;
import org.hibernate.bug.domain.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration( { "classpath*:context.xml" })
public class BugTest {

	@Autowired
	private UserDao userDao;

	@Test
	@Transactional
	public void testBug() {
		userDao.persist(new User("user1").addRole(Role.ROLE_1).addRole(Role.ROLE_2));
		userDao.persist(new User("user2").addRole(Role.ROLE_3));

		Set<Role> roles = new HashSet<Role>();
		roles.add(Role.ROLE_3);

		List<User> users = userDao.findByRoles(roles);
		for (User user : users) {
			System.out.println(user.getUsername());
		}
	}

}
