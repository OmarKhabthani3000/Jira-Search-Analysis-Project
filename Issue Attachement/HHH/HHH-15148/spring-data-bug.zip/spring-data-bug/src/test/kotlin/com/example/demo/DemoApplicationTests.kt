package com.example.demo

import org.assertj.core.api.Assertions
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class DemoApplicationTests {

  @Autowired
  lateinit var repository: AssessmentRepository

  val entity1 = AssessmentProjection("assessmentId1", "assessment-1", "customerId")
  val entity2 = AssessmentProjection("assessmentId2", "assessment-2", "customerId")

  @BeforeEach
  fun `given an empty DB`() {
    repository.deleteAll()
    repository.save(entity1)
    repository.save(entity2)
  }

  @Test
  fun `AssessmentCountByStartsWithNameQuery should return amount of assessments starting with Name`() {

    var result = repository.countByAssessmentNameStartsWithAndCustomerId("assessment", "customerId")
    Assertions.assertThat(result).isEqualTo(2)

    // second invocation fails since Sping Boot 2.6.5 (or hibernate-core:
    result = repository.countByAssessmentNameStartsWithAndCustomerId("assessment", "customerId")
    Assertions.assertThat(result).isEqualTo(2)
  }

}
