package com.example.demo

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository
import javax.persistence.Entity
import javax.persistence.Id


@Entity
data class AssessmentProjection(
  @Id var assessmentId: String,
  var assessmentName: String,
  var customerId: String,
)

@Repository
interface AssessmentRepository : JpaRepository<AssessmentProjection, String>, JpaSpecificationExecutor<AssessmentProjection> {
  fun countByAssessmentNameStartsWithAndCustomerId(assessmentName: String, customerId: String): Long
}

@SpringBootApplication
class DemoApplication

fun main(args: Array<String>) {
  runApplication<DemoApplication>(*args)
}
