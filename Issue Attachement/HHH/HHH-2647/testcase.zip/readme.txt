Load up java file and XML hibernate mapping in your favorite test environment.

Run the following HQL query and check out the output SQL. It is semantically invalid and will never return any results.


from SymbolMappingImpl e 
where (e.businessKey.subBusinessDivisionCdId = 5412 and e.businessKey.productFamilyCdId = 4540 and e.businessKey.symbolCdId = 5969 
and e.businessKey.companyCdId = 3802 and e.businessKey.stateCdId = 3744) or 
(e.businessKey.subBusinessDivisionCdId = 5411 and e.businessKey.productFamilyCdId = 4540 and e.businessKey.symbolCdId = 5969 
and e.businessKey.companyCdId = 3802 and e.businessKey.stateCdId = 3744) 


it will output the following SQL:

select symbolmapp0_.SymbolMappingId as SymbolMa1_217_, symbolmapp0_.SubBusinessDivisionCdId as SubBusin2_217_, 
symbolmapp0_.ProductFamilyCdId as ProductF3_217_, symbolmapp0_.SymbolCdId as SymbolCdId217_, 
symbolmapp0_.CompanyCdId as CompanyC5_217_, symbolmapp0_.StateCdId as StateCdId217_, symbolmapp0_.EffectiveDt as Effectiv7_217_, 
symbolmapp0_.ExpirationDt as Expirati8_217_ 
from SymbolMapping symbolmapp0_ 
where symbolmapp0_.SubBusinessDivisionCdId=5412 and symbolmapp0_.ProductFamilyCdId=4540 and symbolmapp0_.SymbolCdId=5969 and
symbolmapp0_.CompanyCdId=3802 and symbolmapp0_.StateCdId=3744 or 
symbolmapp0_.SubBusinessDivisionCdId=5411 and symbolmapp0_.ProductFamilyCdId=4540 and symbolmapp0_.SymbolCdId=5969 and 
symbolmapp0_.CompanyCdId=3802 and symbolmapp0_.StateCdId=3744 