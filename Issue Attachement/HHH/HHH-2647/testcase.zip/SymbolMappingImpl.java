import org.apache.commons.lang.ObjectUtils;

import com.archinsurance.rdm.entity.archlink.SymbolMapping;
import com.archinsurance.rdm.entity.archlink.SymbolMappingKey;

public class SymbolMappingImpl {

	private Integer symbolMappingId;
	
	private SymbolMappingKey businessKey;

	public SymbolMappingKey getBusinessKey() {
		return this.businessKey;
	}

	@SuppressWarnings("unused")
	private void setBusinessKey(SymbolMappingKey key) {
		this.businessKey = key;
	}
	

	/* (non-Javadoc)
	 * @see com.archinsurance.rdm.entity.archlink.impl.SymbolMapping#getSymbolMappingId()
	 */
	public Integer getId() {
		return symbolMappingId;
	}

	public void setId(Integer symbolMappingId) {
		this.symbolMappingId = symbolMappingId;
	}

	
	@Override
	public boolean equals(Object arg0) {
		if (!(arg0 instanceof SymbolMappingImpl)) {
			return false;
		}
		SymbolMappingImpl symbolMappingImpl = (SymbolMappingImpl)arg0;
	
		return ObjectUtils.equals(getBusinessKey(), symbolMappingImpl.getBusinessKey());
	}

	@Override
	public int hashCode() {
		return getBusinessKey().hashCode();
	}
	
	@Override
	public String toString() {
		return new StringBuilder().append(getBusinessKey()).toString();
	}
}
