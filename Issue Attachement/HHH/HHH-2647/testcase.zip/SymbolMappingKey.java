

import org.apache.commons.lang.ObjectUtils;

public class SymbolMappingKey  {
	
	private Long subBusinessDivisionCdId;
	private Long productFamilyCdId;
	private Long symbolCdId;
	private Long companyCdId;
	private Long stateCdId;
	
	@Override
	public boolean equals(Object arg0) {
		if (!(arg0 instanceof SymbolMappingKey)) {
			return false;
		}
		SymbolMappingKey key = (SymbolMappingKey)arg0;
		boolean equals = ObjectUtils.equals(getCompanyCdId(), key.getCompanyCdId());
		equals &= ObjectUtils.equals(getProductFamilyCdId(), key.getProductFamilyCdId());
		equals &= ObjectUtils.equals(getStateCdId(), key.getStateCdId());
		equals &= ObjectUtils.equals(getSubBusinessDivisionCdId(), key.getSubBusinessDivisionCdId());
		equals &= ObjectUtils.equals(getSymbolCdId(), key.getSymbolCdId());
			
		return equals;
	}

	@Override
	public int hashCode() {
		int hashCode = 7;
		hashCode = hashCode * 31 + (this.getSubBusinessDivisionCdId() != null ? this.getSubBusinessDivisionCdId().hashCode() : 0);
		hashCode = hashCode * 31 + (this.getProductFamilyCdId() != null ? this.getProductFamilyCdId().hashCode() : 0);
		hashCode = hashCode * 31 + (this.getSymbolCdId() != null ? this.getSymbolCdId().hashCode() : 0);
		hashCode = hashCode * 31 + (this.getCompanyCdId() != null ? this.getCompanyCdId().hashCode() : 0);
		hashCode = hashCode * 31 + (this.getStateCdId() != null ? this.getStateCdId().hashCode() : 0);
		return hashCode;
	}
	
	public Long getSubBusinessDivisionCdId() {
		return subBusinessDivisionCdId;
	}
	public void setSubBusinessDivisionCdId(Long subBusinessDivisionCdId) {
		this.subBusinessDivisionCdId = subBusinessDivisionCdId;
	}
	public Long getProductFamilyCdId() {
		return productFamilyCdId;
	}
	public void setProductFamilyCdId(Long productFamilyCdId) {
		this.productFamilyCdId = productFamilyCdId;
	}
	public Long getSymbolCdId() {
		return symbolCdId;
	}
	public void setSymbolCdId(Long symbolCdId) {
		this.symbolCdId = symbolCdId;
	}
	public Long getCompanyCdId() {
		return companyCdId;
	}
	public void setCompanyCdId(Long companyCdId) {
		this.companyCdId = companyCdId;
	}
	public Long getStateCdId() {
		return stateCdId;
	}
	public void setStateCdId(Long stateCdId) {
		this.stateCdId = stateCdId;
	}
	
	@Override
	public String toString() {
		return new StringBuilder().append("SubBusinessDivisionCdId:").append(getSubBusinessDivisionCdId()).append("@ProductFamilyCdId:").append(getProductFamilyCdId())
			.append("@SymbolCdId:").append(getSymbolCdId()).append("@CompanyCdId:").append(getCompanyCdId()).append("@StateCdId:").append(getStateCdId()).toString();
	}
}
