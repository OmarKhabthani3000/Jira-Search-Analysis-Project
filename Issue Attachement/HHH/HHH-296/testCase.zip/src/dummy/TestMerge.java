package dummy;

/**
 * @author giangnh
 *  
 */
public class TestMerge extends TestBase {

    public void testMerge() {
        Parent parent = new Parent("parent name", null);
        Long id = (Long) save(parent);
        parent = (Parent) load(Parent.class, id);

        restartSession();

        Child child = new Child("child name", null, null, null);
        GrandChild grandChild = new GrandChild("grand child name", null, null);
        child.addGrandChild(grandChild);
        parent.addChild(child);

        Parent parent1 = (Parent) hibSess.get(Parent.class, id);
        beginTrans();
        //cannot call hibSess.update(parent) because instance with the same id
        // parent1 was loaded already
        hibSess.merge(parent);//error
        commit();
    }
}