package dummy;

import java.io.Serializable;

import junit.framework.TestCase;

import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

/**
 * @author giangnh
 */
public class TestBase extends TestCase {

    protected org.hibernate.Session hibSess;

    private Transaction transaction;

    protected void setUp() throws Exception {
        super.setUp();
        openSession(true);
    }

    private void openSession(boolean createSchema) {
        Configuration configuration = new Configuration();
        if (createSchema) {
            configuration.setProperty(Environment.HBM2DDL_AUTO, "create-drop");
        }
        hibSess = configuration.configure().buildSessionFactory().openSession();
    }

    protected void commit() {
        transaction.commit();
    }

    protected void beginTrans() {
        transaction = hibSess.beginTransaction();
    }

    protected void restartSession() {
        hibSess.close();
        openSession(false);
    }

    protected Object load(Class aClass, Long aId) {
        return hibSess.get(aClass, aId);
    }

    protected Serializable save(Parent aParent) {
        beginTrans();
        Serializable save = hibSess.save(aParent);
        commit();
        return save;
    }

}