package dummy;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;


/** @author Hibernate CodeGenerator */
public class GrandChild implements Serializable {

    /** identifier field */
    private Long id;

    /** nullable persistent field */
    private String name;

    /** nullable persistent field */
    private Integer order;

    /** nullable persistent field */
    private Child parent;

    /** full constructor */
    public GrandChild(String name, Integer order, Child parent) {
        this.name = name;
        this.order = order;
        this.parent = parent;
    }

    /** default constructor */
    public GrandChild() {
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getOrder() {
        return this.order;
    }

    public void setOrder(Integer order) {
        this.order = order;
    }

    public Child getParent() {
        return this.parent;
    }

    public void setParent(Child parent) {
        this.parent = parent;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

}
