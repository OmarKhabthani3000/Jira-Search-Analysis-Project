package dummy;

import java.io.Serializable;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class Child implements Serializable {

    /** identifier field */
    private Long id;

    /** nullable persistent field */
    private String name;

    /** nullable persistent field */
    private Integer order;

    /** nullable persistent field */
    private Parent parent;

    /** persistent field */
    private SortedMap children;

    /** full constructor */
    public Child(String name, Integer order, Parent parent, SortedMap children) {
        this.name = name;
        this.order = order;
        this.parent = parent;
        this.children = children;
    }

    /** default constructor */
    public Child() {
    }

    /** minimal constructor */
    public Child(SortedMap children) {
        this.children = children;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getOrder() {
        return this.order;
    }

    public void setOrder(Integer order) {
        this.order = order;
    }

    public Parent getParent() {
        return this.parent;
    }

    public void setParent(Parent parent) {
        this.parent = parent;
    }

    public SortedMap getChildren() {
        return this.children;
    }

    public void setChildren(SortedMap children) {
        this.children = children;
    }

    public String toString() {
        return new ToStringBuilder(this).append("id", getId()).toString();
    }

    /**
     * @param aGrandChild
     */
    public void addGrandChild(GrandChild aGrandChild) {
        aGrandChild.setParent(this);
        
        if (children == null) {
            children = new TreeMap();
        }
        Integer order1 = null;
        try {
            order1 = (Integer) children.lastKey();
        } catch (RuntimeException e) {
        }
        if (order1 == null) {
            order1 = new Integer(0);
        } else {
            order1 = new Integer(order1.intValue() + 1);
        }
        aGrandChild.setOrder(order1);
        children.put(order1, aGrandChild);
    }

}