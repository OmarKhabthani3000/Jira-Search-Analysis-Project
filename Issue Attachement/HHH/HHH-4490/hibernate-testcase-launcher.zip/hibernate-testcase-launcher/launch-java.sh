#!/bin/bash

basedir=`dirname $0`

classpath=$basedir/conf
for jar in `ls $basedir/lib`; do
    classpath=$classpath:$basedir/lib/$jar
done;

command="java -cp "$classpath
command=$command" "
command=$command" hibernate.testcase.HibernateLoader"
command=$command" "
command=$command" $@"

echo "Running:"
echo $command
exec $command

rt=$?
if [ "$rt" != "0" ]; then
    echo "ERROR: $0 failed : $rt"
    exit $rt
fi
