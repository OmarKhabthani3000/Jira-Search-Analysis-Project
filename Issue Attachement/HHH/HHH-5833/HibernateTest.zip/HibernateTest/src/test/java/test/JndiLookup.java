package test;

import javax.naming.Context;
import javax.naming.NamingException;

public final class JndiLookup<INTERFACE> {

	private Context context = null;
	
	public JndiLookup(Context ctx) {
		context = ctx;
	}
	
	@SuppressWarnings("unchecked")
	public INTERFACE getLocalBean(final Class<? extends INTERFACE> beanClass) throws NamingException {
    	String jndiName = beanClass.getSimpleName() + "Local";
    	return (INTERFACE)context.lookup(jndiName);
    }
	
	@SuppressWarnings("unchecked")
	public INTERFACE getResource(final String jndiName) throws NamingException {
		return (INTERFACE)context.lookup(jndiName);
    }
}
