package test;

import java.io.IOException;
import java.lang.Thread.UncaughtExceptionHandler;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Random;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import test.Family;
import test.FamilyManager;

public class Runner {
	
	private static class MyUncaughtExceptionHandler implements UncaughtExceptionHandler {

		private Runner runner = null;
		
		public MyUncaughtExceptionHandler(Runner runner) {
			this.runner = runner;
		}
		
		@Override
		public void uncaughtException(Thread t, Throwable e) {
			runner.handleThreadException(t, e);
		}
		
	};
	
	private UncaughtExceptionHandler ueh = null;
	private boolean threadException = false;
	
	
	private static final Logger log = LoggerFactory.getLogger(Runner.class);
	
//	public static final int nbThread = 32;
	public static final int nbThread = 1;
//	public static final int nbRequest = 1000;
	public static final int nbRequest = 1;
	
	protected static Properties                props = null;
	protected static int                       nodeNb = 2;
	protected static int                       nodeId = 0;
	protected static int                       nbPersonPerFamily = 3;
	
	protected static InitialContext            context = null;
	protected static JndiLookup<FamilyManager> looker = null;
	
	protected FamilyManager                    manager = null;
	protected int                              threadId = 0;
	
	protected static int                       familyNbInsert = 0;
	protected static int                       familyNbUpdate = 0;
	protected static int                       familyNbRead = 0;
	protected static int                       familyNbRead2 = 0;
	protected static int                       familyNbRemove = 0;
	protected static int                       collectionNbInsert = 0;
	protected static int                       collectionNbRemove = 0;
	
	protected static synchronized void razContext() {
		context = null;
		looker = null;
	}
	protected static synchronized int getFamilyNbInsert() {
		return familyNbInsert;
	}
	protected static synchronized int getFamilyNbUpdate() {
		return familyNbUpdate;
	}
	protected static synchronized int getFamilyNbRead() {
		return familyNbRead;
	}
	protected static synchronized int getFamilyNbRead2() {
		return familyNbRead2;
	}
	protected static synchronized int getFamilyNbRemove() {
		return familyNbRemove;
	}
	protected static synchronized int getCollectionNbInsert() {
		return collectionNbInsert;
	}
	protected static synchronized int getCollectionNbRemove() {
		return collectionNbRemove;
	}
	protected static synchronized int nextFamilyNbInsert() {
		int i = familyNbInsert;
		familyNbInsert++;
		return i;
	}
	protected static synchronized int nextFamilyNbUpdate() {
		int i = familyNbUpdate;
		familyNbUpdate++;
		return i;
	}
	protected static synchronized int nextFamilyNbRead() {
		int i = familyNbRead;
		familyNbRead++;
		return i;
	}
	protected static synchronized int nextFamilyNbRead2() {
		int i = familyNbRead2;
		familyNbRead2++;
		return i;
	}
	protected static synchronized int nextFamilyNbRemove() {
		int i = familyNbRemove;
		familyNbRemove++;
		return i;
	}
	protected static synchronized int nextCollectionNbInsert() {
		int i = collectionNbInsert;
		collectionNbInsert++;
		return i;
	}
	protected static synchronized int nextCollectionNbRemove() {
		int i = collectionNbRemove;
		collectionNbRemove++;
		return i;
	}
	
	public Runner() throws NamingException {
		ueh = new MyUncaughtExceptionHandler(this);
		setManager();
	}

	protected Runner(int threadId) throws NamingException {
		ueh = new MyUncaughtExceptionHandler(this);
		setManager();
		this.threadId = threadId;
	}
	
	private void setManager() throws NamingException {
		synchronized(looker) {
			manager = looker.getResource("FamilyManagerBeanLocal");
			if (manager == null) {
				throw new IllegalStateException("Lookup for FamilyManagerBeanLocal failed");
			}
		}
	}
	
	public void handleThreadException(Thread t, Throwable e) {
		System.err.println("Exception in thread " + t.getName());
		e.printStackTrace();
		threadException = true;
	}
	
	public static void razCounters() {
		familyNbInsert = 0;
		familyNbUpdate = 0;
		familyNbRead = 0;
		familyNbRead2 = 0;
		familyNbRemove = 0;
		collectionNbInsert = 0;
		collectionNbRemove = 0;
	}
	
	@BeforeClass
	public static void init() {
		props = System.getProperties();;
		if (!props.containsKey("test.nodeNb")) {
			throw new IllegalStateException("Property 'test.nodeNb' is REQUIRED and MUST be the same for each JVM.");
		}
		if (!props.containsKey("test.nodeId")) {
			throw new IllegalStateException("Property 'test.nodeId' is REQUIRED and MUST be different for each JVM.");
		}
		nodeNb = Integer.parseInt(props.getProperty("test.nodeNb", "2"));
		nodeId = Integer.parseInt(props.getProperty("test.nodeId", "0"));

		props.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.openejb.client.LocalInitialContextFactory");
		props.setProperty("openejb.embedded.initialcontext.close", "destroy");

		if (log.isInfoEnabled()) log.info("Starting node " + nodeId + "/" + nodeNb);
		// Start OpenEjb
		try {
			context = new InitialContext(props);
			looker = new JndiLookup<FamilyManager>(context);
		} catch (NamingException e) {
			throw new IllegalStateException("Creation of an InitialContext or Looker failed", e);
		}
		if (log.isDebugEnabled()) log.debug(new JndiTree(context).toString());
	}

	@AfterClass
	public static void exit() {
		if (log.isInfoEnabled()) log.info("Stopping node " + nodeId + "/" + nodeNb);
		if (context != null) {
			// Stop OpenEjb
			try {
				context.close();
			} catch (Exception e) {
				SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss,SSS");
				System.err.println(sdf.format(new Date()) + " Closing InitialContext failed: " + e.getMessage());
			} finally {
				razContext();
			}
		}
	}
	
	/**
	 * Insert Families using only em.persist().
	 * @throws NamingException 
	 */
	public void testEntityInsert() throws InterruptedException, NamingException {
		if (log.isInfoEnabled()) log.info("Test " + nbThread*nbRequest + " Family inserts with "
				+ nbThread + " threads");
		Thread threads[] = new Thread[nbThread];
		threadException = false;
		for(int i=0; i<nbThread; i++) {
			threads[i] = new Thread(new EntityInsertRunner(i+1));
		}
		long startMs = System.currentTimeMillis();
		for(int i=0; i<nbThread; i++) {
			threads[i].setUncaughtExceptionHandler(ueh);
			threads[i].start();
		}
		for(int i=0; i<nbThread; i++) {
			threads[i].join();
		}
		long stopMs = System.currentTimeMillis();
		if (log.isInfoEnabled()) log.info(nbThread*nbRequest + " Family inserts done in " 
				+ (stopMs - startMs)/1000 + " seconds (" 
				+ (((stopMs - startMs) > 0) ? nbThread*nbRequest*1000/(stopMs - startMs) : 0) + " TPS)");
	}
	private static class EntityInsertRunner extends Runner implements Runnable {
		public EntityInsertRunner(int threadId) throws NamingException {
			super(threadId);
		}
		
		@Override
		public void run() {
			for (int n=0; n < nbRequest; n++) {
				int i = nextFamilyNbInsert();
				
				int familyId = (i*nodeNb + nodeId);
				String familyName = "Durand-" + nodeId + "-" + i;
				manager.createFamily(familyId, familyName);

//				int addressId = (i*nodeNb + nodeId);
//				manager.createAddress(addressId, i, "rue " + nodeId, "Paris", "France");

//				int personBaseId = (i*nodeNb*nbPersonPerFamily + nodeId*nbPersonPerFamily);
//				for (int j = 0; j < nbPersonPerFamily; j++) {
//					manager.createPerson(personBaseId + j, "Pierre-" + j, familyId);
//				}

//				manager.setAddressForPersonsByFamilyName(familyName, addressId);
			}
		}
	};
	
	/**
	 * Update Families using only em.find() without using queries.
	 * @throws NamingException 
	 */
	public void testEntityUpdate() throws InterruptedException, NamingException {
		if (log.isInfoEnabled()) log.info("Test " + nbThread*nbRequest + " Family updates with "
				+ nbThread + " threads");
		Thread threads[] = new Thread[nbThread];
		threadException = false;
		for(int i=0; i<nbThread; i++) {
			threads[i] = new Thread(new EntityUpdateRunner(i+1));
		}
		long startMs = System.currentTimeMillis();
		for(int i=0; i<nbThread; i++) {
			threads[i].setUncaughtExceptionHandler(ueh);
			threads[i].start();
		}
		for(int i=0; i<nbThread; i++) {
			threads[i].join();
		}
		long stopMs = System.currentTimeMillis();
		if (log.isInfoEnabled()) log.info(nbThread*nbRequest + " Family updates done in " 
				+ (stopMs - startMs)/1000 + " seconds (" 
				+ (((stopMs - startMs) > 0) ? nbThread*nbRequest*1000/(stopMs - startMs): 0) + " TPS)");
	}
	private static class EntityUpdateRunner extends Runner implements Runnable {
		public EntityUpdateRunner(int threadId) throws NamingException {
			super(threadId);
		}
		
		@Override
		public void run() {
			for (int n=0; n < nbRequest; n++) {
				int i = nextFamilyNbUpdate();
				
				int familyId = (i*nodeNb + nodeId);
				Family family = manager.findFamily(familyId);
				if (family == null) {
					if (log.isWarnEnabled()) log.warn("Family '" + familyId + "' does not exist");
				} else {
					String secondName = family.getSecondName() + "-";
					manager.updateFamily(familyId, secondName);
				}
			}
		}
	};
	
	/**
	 * Read Families using only em.find() without using queries.
	 * Id is THE SAME ONE => cache would be very useful
	 * @throws NamingException 
	 */
	public void testEntityReadSame() throws InterruptedException, NamingException {
		if (log.isInfoEnabled()) log.info("Test " + nbThread*nbRequest + " Family reads on same Entity with "
				+ nbThread + " threads");
		Thread threads[] = new Thread[nbThread];
		threadException = false;
		for(int i=0; i<nbThread; i++) {
			threads[i] = new Thread(new EntityReadSameRunner(i+1));
		}
		long startMs = System.currentTimeMillis();
		for(int i=0; i<nbThread; i++) {
			threads[i].setUncaughtExceptionHandler(ueh);
			threads[i].start();
		}
		for(int i=0; i<nbThread; i++) {
			threads[i].join();
		}
		long stopMs = System.currentTimeMillis();
		if (log.isInfoEnabled()) log.info(nbThread*nbRequest + " Family reads on same Entity done in " 
				+ (stopMs - startMs)/1000 + " seconds (" 
				+ (((stopMs - startMs) > 0) ? nbThread*nbRequest*1000/(stopMs - startMs) : 0) + " TPS)");
	}
	private static class EntityReadSameRunner extends Runner implements Runnable {
		public EntityReadSameRunner(int threadId) throws NamingException {
			super(threadId);
		}
		
		@Override
		public void run() {
			for (int n=0; n < nbRequest; n++) {
				int i = 0;
				int familyId = (i*nodeNb + nodeId);
				Family family = manager.findFamily(familyId);
				if (family == null) {
					if (log.isWarnEnabled()) log.warn("Family '" + familyId + "' does not exist");
				}
			}
		}
	};
	
	/**
	 * Read Families using only em.find() without using queries.
	 * Id is chosen IN INCREASING ORDER => cache would be useful if big
	 * @throws NamingException 
	 */
	public void testEntityReadInOrder() throws InterruptedException, NamingException {
		if (log.isInfoEnabled()) log.info("Test " + nbThread*nbRequest + " Family reads on ordered Entity with "
				+ nbThread + " threads");
		Thread threads[] = new Thread[nbThread];
		threadException = false;
		for(int i=0; i<nbThread; i++) {
			threads[i] = new Thread(new EntityReadInOrderRunner(i+1));
		}
		long startMs = System.currentTimeMillis();
		for(int i=0; i<nbThread; i++) {
			threads[i].setUncaughtExceptionHandler(ueh);
			threads[i].start();
		}
		for(int i=0; i<nbThread; i++) {
			threads[i].join();
		}
		long stopMs = System.currentTimeMillis();
		if (log.isInfoEnabled()) log.info(nbThread*nbRequest + " Family reads on ordered Entity done in " 
				+ (stopMs - startMs)/1000 + " seconds (" 
				+ (((stopMs - startMs) > 0) ? nbThread*nbRequest*1000/(stopMs - startMs) : 0) + " TPS)");
	}
	private static class EntityReadInOrderRunner extends Runner implements Runnable {
		public EntityReadInOrderRunner(int threadId) throws NamingException {
			super(threadId);
		}
		
		@Override
		public void run() {
			for (int n=0; n < nbRequest; n++) {
				int i = nextFamilyNbRead();
				int familyId = (i*nodeNb + nodeId);
				Family family = manager.findFamily(familyId);
				if (family == null) {
					if (log.isWarnEnabled()) log.warn("Family '" + familyId + "' does not exist");
				}
			}
		}
	};
	
	/**
	 * Read Families using only em.find() without using queries.
	 * Id is chosen RANDOMLY => cache would be useless
	 * @throws NamingException 
	 */
	public void testEntityReadRandomly() throws InterruptedException, NamingException {
		if (log.isInfoEnabled()) log.info("Test " + nbThread*nbRequest + " Family reads on random Entity with "
				+ nbThread + " threads");
		Thread threads[] = new Thread[nbThread];
		threadException = false;
		for(int i=0; i<nbThread; i++) {
			threads[i] = new Thread(new EntityReadRandomlyRunner(i+1));
		}
		long startMs = System.currentTimeMillis();
		for(int i=0; i<nbThread; i++) {
			threads[i].setUncaughtExceptionHandler(ueh);
			threads[i].start();
		}
		for(int i=0; i<nbThread; i++) {
			threads[i].join();
		}
		long stopMs = System.currentTimeMillis();
		if (log.isInfoEnabled()) log.info(nbThread*nbRequest + " Family reads on random Entity done in " 
				+ (stopMs - startMs)/1000 + " seconds (" 
				+ (((stopMs - startMs) > 0) ? nbThread*nbRequest*1000/(stopMs - startMs) : 0) + " TPS)");
	}
	private static class EntityReadRandomlyRunner extends Runner implements Runnable {
		private Random rnd = new Random();
		
		public EntityReadRandomlyRunner(int threadId) throws NamingException {
			super(threadId);
		}
		
		@Override
		public void run() {
			int nbInsert = getFamilyNbInsert();
			for (int n=0; n < nbRequest; n++) {
				int i = rnd.nextInt(nbInsert);
				int familyId = (i*nodeNb + nodeId);
				Family family = manager.findFamily(familyId);
				if (family == null) {
					if (log.isWarnEnabled()) log.warn("Family '" + familyId + "' does not exist");
				}
			}
		}
	};
	
	/**
	 * Remove Families using only em.find() without using queries.
	 * @throws NamingException 
	 */
	public void testEntityRemove() throws InterruptedException, NamingException {
		//Logger.getLogger("org.hibernate.SQL").setLevel(Level.TRACE);
		//Logger.getLogger("org.hibernate.type").setLevel(Level.TRACE);

		if (log.isInfoEnabled()) log.info("Test " + nbThread*nbRequest + " Family removes on Entity with "
				+ nbThread + " threads");
		Thread threads[] = new Thread[nbThread];
		threadException = false;
		for(int i=0; i<nbThread; i++) {
			threads[i] = new Thread(new EntityRemoveRunner(i+1));
		}
		long startMs = System.currentTimeMillis();
		for(int i=0; i<nbThread; i++) {
			threads[i].setUncaughtExceptionHandler(ueh);
			threads[i].start();
		}
		for(int i=0; i<nbThread; i++) {
			threads[i].join();
		}
		long stopMs = System.currentTimeMillis();
		if (log.isInfoEnabled()) log.info(nbThread*nbRequest + " Family removes on Entity done in " 
				+ (stopMs - startMs)/1000 + " seconds (" 
				+ (((stopMs - startMs) > 0) ? nbThread*nbRequest*1000/(stopMs - startMs) : 0) + " TPS)");
		//Logger.getLogger("org.hibernate.SQL").setLevel(Level.WARN);
		//Logger.getLogger("org.hibernate.type").setLevel(Level.WARN);
	}
	private static class EntityRemoveRunner extends Runner implements Runnable {
		public EntityRemoveRunner(int threadId) throws NamingException {
			super(threadId);
		}
		
		@Override
		public void run() {
			for (int n=0; n < nbRequest; n++) {
				int i = nextFamilyNbRemove();
				int familyId = (i*nodeNb + nodeId);
				manager.removeFamily(familyId);
			}
		}
	};
	
	@Test
	public void testEntity() throws InterruptedException, NamingException {
		Assert.assertNotNull(manager);
		long nb = manager.countAllAddresses();
		if (log.isInfoEnabled()) log.info("Found " + nb + " addresses already imported in database.");
		Assert.assertEquals(0, nb);
		nb = manager.countAllFamilies();
		if (log.isInfoEnabled()) log.info("Found " + nb + " families already imported in database.");
		Assert.assertEquals(0, nb);
		nb = manager.countAllPersons();
		if (log.isInfoEnabled()) log.info("Found " + nb + " persons already imported in database.");
		Assert.assertEquals(0, nb);
		testEntityInsert();
		Assert.assertFalse(threadException);
		Assert.assertEquals(nbThread*nbRequest, getFamilyNbInsert());
		testEntityUpdate();
		Assert.assertFalse(threadException);
		Assert.assertEquals(nbThread*nbRequest, getFamilyNbUpdate());
		testEntityReadSame();
		Assert.assertFalse(threadException);
		testEntityReadInOrder();
		Assert.assertFalse(threadException);
		Assert.assertEquals(nbThread*nbRequest, getFamilyNbRead());
		testEntityReadRandomly();
		Assert.assertFalse(threadException);
		testEntityRemove();
		Assert.assertFalse(threadException);
		Assert.assertEquals(nbThread*nbRequest, getFamilyNbRemove());
		razCounters();
	}
	
	/**
	 * Create Family & Address & Persons.
	 * @throws NamingException 
	 */
	public void runCollectionInit() throws InterruptedException, NamingException {
		if (log.isInfoEnabled()) log.info("Init by creating "+nbThread*nbRequest+" Family + Address + "
				+ nbPersonPerFamily + "*Persons with " + nbThread + " threads");
		Thread threads[] = new Thread[nbThread];
		threadException = false;
		for(int i=0; i<nbThread; i++) { 
			threads[i] = new Thread(new CollectionInitRunner(i+1));
		}
		long startMs = System.currentTimeMillis();
		for(int i=0; i<nbThread; i++) {
			threads[i].setUncaughtExceptionHandler(ueh);
			threads[i].start();
		}
		for(int i=0; i<nbThread; i++) {
			threads[i].join();
		}
		long stopMs = System.currentTimeMillis();
		if (log.isInfoEnabled()) log.info(nbThread*nbRequest + " Family + Address + "
				+ nbPersonPerFamily + "*Persons created in " 
				+ (stopMs - startMs)/1000 + " seconds (" 
				+ (((stopMs - startMs) > 0) ? nbThread*nbRequest*1000/(stopMs - startMs) : 0) + " TPS)");
	}
	private static class CollectionInitRunner extends Runner implements Runnable {
		public CollectionInitRunner(int threadId) throws NamingException {
			super(threadId);
		}
		
		@Override
		public void run() {
			for (int n=0; n < nbRequest; n++) {
				int i = nextFamilyNbInsert();
				
				int familyId = (i*nodeNb + nodeId);
				String familyName = "Durand-" + nodeId + "-" + i;
				manager.createFamily(familyId, familyName);

				int addressId = (i*nodeNb + nodeId);
				manager.createAddress(addressId, i, "rue " + nodeId, "Paris", "France");

				int personBaseId = (i*nodeNb*nbPersonPerFamily + nodeId*nbPersonPerFamily);
				for (int j = 0; j < nbPersonPerFamily; j++) {
					manager.createPerson(personBaseId + j, "Pierre-" + j, familyId);
				}

//				manager.setAddressForPersonsByFamilyName(familyName, addressId);
			}
		}
	};
	
	/**
	 * Collection Address.inhabitants insert.
	 * We need to measure previously the query person.findPersonsByFamily.
	 * @throws NamingException 
	 */
	public void testCollectionInsert() throws InterruptedException, NamingException {
		if (log.isInfoEnabled()) log.info("Test "+nbThread*nbRequest*nbPersonPerFamily 
				+" Address.inhabitants inserts with " + nbThread + " threads");
		Thread threads[] = new Thread[nbThread];
		threadException = false;
		for(int i=0; i<nbThread; i++) { 
			threads[i] = new Thread(new CollectionInsertRunner(i+1));
		}
		long startMs = System.currentTimeMillis();
		for(int i=0; i<nbThread; i++) { 
			threads[i].setUncaughtExceptionHandler(ueh);
			threads[i].start();
		}
		for(int i=0; i<nbThread; i++) { 
			threads[i].join();
		}
		long stopMs = System.currentTimeMillis();
		if (log.isInfoEnabled()) log.info(nbThread*nbRequest*nbPersonPerFamily 
				+ " Address.inhabitants inserts done in " 
				+ (stopMs - startMs)/1000 + " seconds (" 
				+ (((stopMs - startMs) > 0) 
						? nbThread*nbRequest*nbPersonPerFamily*1000/(stopMs - startMs) : 0) + " TPS)");
	}
	private static class CollectionInsertRunner extends Runner implements Runnable {
		public CollectionInsertRunner(int threadId) throws NamingException {
			super(threadId);
		}
		
		@Override
		public void run() {
			for (int n=0; n < nbRequest; n++) {
				int i = nextCollectionNbInsert();
				
				int addressId = (i*nodeNb + nodeId);
				int personBaseId = (i*nodeNb*nbPersonPerFamily + nodeId*nbPersonPerFamily);
				for (int j = 0; j < nbPersonPerFamily; j++) {
					manager.setAddressForPerson(personBaseId + j, addressId);
				}
			}
		}
	};
	
	/**
	 * Collection Address.inhabitants remove.
	 * We need to measure previously the query person.findPersonsByFamily.
	 * @throws NamingException 
	 */
	public void testCollectionRemove() throws InterruptedException, NamingException {
		if (log.isInfoEnabled()) log.info("Test "+nbThread*nbRequest*nbPersonPerFamily 
				+" Address.inhabitants removes with " + nbThread + " threads");
		Thread threads[] = new Thread[nbThread];
		threadException = false;
		for(int i=0; i<nbThread; i++) { 
			threads[i] = new Thread(new CollectionRemoveRunner(i+1));
		}
		long startMs = System.currentTimeMillis();
		for(int i=0; i<nbThread; i++) { 
			threads[i].setUncaughtExceptionHandler(ueh);
			threads[i].start();
		}
		for(int i=0; i<nbThread; i++) { 
			threads[i].join();
		}
		long stopMs = System.currentTimeMillis();
		if (log.isInfoEnabled()) log.info(nbThread*nbRequest*nbPersonPerFamily 
				+ " Address.inhabitants removes done in " 
				+ (stopMs - startMs)/1000 + " seconds (" 
				+ (((stopMs - startMs) > 0) 
						? nbThread*nbRequest*nbPersonPerFamily*1000/(stopMs - startMs) : 0) + " TPS)");
	}
	private static class CollectionRemoveRunner extends Runner implements Runnable {
		public CollectionRemoveRunner(int threadId) throws NamingException {
			super(threadId);
		}
		
		@Override
		public void run() {
			for (int n=0; n < nbRequest; n++) {
				int i = nextCollectionNbRemove();
				
				int addressId = (i*nodeNb + nodeId);
				int personBaseId = (i*nodeNb*nbPersonPerFamily + nodeId*nbPersonPerFamily);
				for (int j = 0; j < nbPersonPerFamily; j++) {
					manager.removeAddressForPerson(personBaseId + j, addressId);
				}
			}
		}
	};
	
	/**
	 * Create Family & Address & Persons.
	 * @throws NamingException 
	 */
	public void runCollectionExit() throws InterruptedException, NamingException {
		if (log.isInfoEnabled()) log.info("Init by creating "+nbThread*nbRequest+" Family + Address + "
				+ nbPersonPerFamily + "*Persons with " + nbThread + " threads");
		Thread threads[] = new Thread[nbThread];
		threadException = false;
		for(int i=0; i<nbThread; i++) { 
			threads[i] = new Thread(new CollectionExitRunner(i+1));
		}
		long startMs = System.currentTimeMillis();
		for(int i=0; i<nbThread; i++) { 
			threads[i].setUncaughtExceptionHandler(ueh);
			threads[i].start();
		}
		for(int i=0; i<nbThread; i++) { 
			threads[i].join();
		}
		long stopMs = System.currentTimeMillis();
		if (log.isInfoEnabled()) log.info(nbThread*nbRequest + " Family + Address + "
				+ nbPersonPerFamily + "*Persons created in " 
				+ (stopMs - startMs)/1000 + " seconds (" 
				+ (((stopMs - startMs) > 0) ? nbThread*nbRequest*1000/(stopMs - startMs) : 0) + " TPS)");
	}
	private static class CollectionExitRunner extends Runner implements Runnable {
		public CollectionExitRunner(int threadId) throws NamingException {
			super(threadId);
		}
		
		@Override
		public void run() {
			for (int n=0; n < nbRequest; n++) {
				int i = nextFamilyNbRemove();
				
				int familyId = (i*nodeNb + nodeId);
				int addressId = (i*nodeNb + nodeId);
				int personBaseId = (i*nodeNb*nbPersonPerFamily + nodeId*nbPersonPerFamily);
				for (int j = 0; j < nbPersonPerFamily; j++) {
					manager.removePerson(personBaseId + j);
				}
				manager.removeAddress(addressId);
				manager.removeFamily(familyId);
			}
		}
	};
	
	@Test
	public void testCollection() throws InterruptedException, NamingException {
		Assert.assertNotNull(manager);
		long nb = manager.countAllAddresses();
		if (log.isInfoEnabled()) log.info("Found " + nb + " addresses already imported in database.");
		Assert.assertEquals(0, nb);
		nb = manager.countAllFamilies();
		if (log.isInfoEnabled()) log.info("Found " + nb + " families already imported in database.");
		Assert.assertEquals(0, nb);
		nb = manager.countAllPersons();
		if (log.isInfoEnabled()) log.info("Found " + nb + " persons already imported in database.");
		Assert.assertEquals(0, nb);
		runCollectionInit();
		Assert.assertFalse(threadException);
		Assert.assertEquals(nbThread*nbRequest, getFamilyNbInsert());
		testCollectionInsert();
		Assert.assertFalse(threadException);
		Assert.assertEquals(nbThread*nbRequest, getCollectionNbInsert());
		testCollectionRemove();
		Assert.assertFalse(threadException);
		Assert.assertEquals(nbThread*nbRequest, getCollectionNbRemove());
		runCollectionExit();
		Assert.assertFalse(threadException);
		Assert.assertEquals(nbThread*nbRequest, getFamilyNbRemove());
		razCounters();
	}
	
	public static void main(String[] args) {
//		System.setProperty("test.nodeNb", "1");
//		System.setProperty("test.nodeId", "0");
		Runner.init();
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss,SSS");

//			System.out.println(sdf.format(new Date()) + " Test of node " + nodeId + "/" + nodeNb + " will begin in 30 seconds");
//			long stopMs = System.currentTimeMillis() + 30000;
//			while (System.currentTimeMillis() < stopMs) {
//				Thread.sleep(100);
//			}
			System.out.println(sdf.format(new Date()) + " Test of node " + nodeId + "/" + nodeNb + " will begin now");
			Runner runner = new Runner();
			Assert.assertNotNull(runner.manager);

			System.out.println("----------");
			System.out.println(sdf.format(new Date()) + " Strike any key to start Entity-INSERT test");
			while (System.in.available() > 0) System.in.skip(System.in.available());
			System.in.read();
			
			runner.testEntityInsert();
			Assert.assertFalse(runner.threadException);
			Assert.assertEquals(nbThread*nbRequest, getFamilyNbInsert());
			
			System.out.println("----------");
			System.out.println(sdf.format(new Date()) + " Strike any key to start Entity-UPDATE test");
			while (System.in.available() > 0) System.in.skip(System.in.available());
			System.in.read();
			
			runner.testEntityUpdate();
			Assert.assertFalse(runner.threadException);
			Assert.assertEquals(nbThread*nbRequest, getFamilyNbUpdate());
			
			System.out.println("----------");
			System.out.println(sdf.format(new Date()) + " Strike any key to start Entity-READ-SAME test");
			while (System.in.available() > 0) System.in.skip(System.in.available());
			System.in.read();
			
			runner.testEntityReadSame();
			Assert.assertFalse(runner.threadException);
			
			System.out.println("----------");
			System.out.println(sdf.format(new Date()) + " Strike any key to start Entity-READ-IN-ORDER test");
			while (System.in.available() > 0) System.in.skip(System.in.available());
			System.in.read();
			
			runner.testEntityReadInOrder();
			Assert.assertFalse(runner.threadException);
			Assert.assertEquals(nbThread*nbRequest, getFamilyNbRead());
			
			System.out.println("----------");
			System.out.println(sdf.format(new Date()) + " Strike any key to start Entity-READ-RANDOMLY test");
			while (System.in.available() > 0) System.in.skip(System.in.available());
			System.in.read();
			
			runner.testEntityReadRandomly();
			Assert.assertFalse(runner.threadException);
			
			System.out.println("----------");
			System.out.println(sdf.format(new Date()) + " Strike any key to start Entity-REMOVE test");
			while (System.in.available() > 0) System.in.skip(System.in.available());
			System.in.read();
			
			runner.testEntityRemove();
			Assert.assertFalse(runner.threadException);
			Assert.assertEquals(nbThread*nbRequest, getFamilyNbRemove());
			razCounters();
			
			
			
			System.out.println("----------");
			System.out.println(sdf.format(new Date()) + " Strike any key to init Collection tests");
			while (System.in.available() > 0) System.in.skip(System.in.available());
			System.in.read();
			
			runner.runCollectionInit();
			Assert.assertFalse(runner.threadException);
			Assert.assertEquals(nbThread*nbRequest, getFamilyNbInsert());

			System.out.println("----------");
			System.out.println(sdf.format(new Date()) + " Strike any key to start Collection-INSERT test");
			while (System.in.available() > 0) System.in.skip(System.in.available());
			System.in.read();
			
			runner.testCollectionInsert();
			Assert.assertFalse(runner.threadException);
			Assert.assertEquals(nbThread*nbRequest, getCollectionNbInsert());
			
			System.out.println("----------");
			System.out.println(sdf.format(new Date()) + " Strike any key to start Collection-REMOVE test");
			while (System.in.available() > 0) System.in.skip(System.in.available());
			System.in.read();
			
			runner.testCollectionRemove();
			Assert.assertFalse(runner.threadException);
			Assert.assertEquals(nbThread*nbRequest, getCollectionNbRemove());

			System.out.println("----------");
			System.out.println(sdf.format(new Date()) + " Strike any key to exit Collection tests");
			while (System.in.available() > 0) System.in.skip(System.in.available());
			System.in.read();
			
			runner.runCollectionExit();
			Assert.assertFalse(runner.threadException);
			Assert.assertEquals(nbThread*nbRequest, getFamilyNbRemove());
			razCounters();
			


			System.out.println("----------");
			System.out.println(sdf.format(new Date()) + " Strike any key to stop");
			while (System.in.available() > 0) System.in.skip(System.in.available());
			System.in.read();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			Runner.exit();
		}
	}
}
