package test;

import javax.ejb.EJBException;
import javax.naming.Context;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;

public final class JndiTree {

	private Context context = null;
	
	private StringBuilder sb = null;
	
	public JndiTree(Context ctx) {
		context = ctx;
	}

	public String toString() {
		sb = new StringBuilder();
		sb.append("JNDI Tree from root context \"\"\n");
		printJNDITree("", "");
		sb.append("-----\n");
		sb.append("JNDI Tree from context \"java:\"\n");
		printJNDITree("", "java:");
		return sb.toString();
	}

	private void printJNDITree(String levelPrefix, String parentCtx)   {
		NamingEnumeration<NameClassPair> ne = null;
		try {
			ne = context.list(parentCtx);
		} catch (NamingException e) {
			// ignore leaf node exception
		} catch (EJBException e) {
			// ignore leaf node exception
		}
		if (ne != null) {
			String parentPrefix = (parentCtx.length() == 0) ? "" : parentCtx + "/";
			while (ne.hasMoreElements()) {
				NameClassPair next = ne.nextElement();
				sb.append(levelPrefix + parentPrefix + next.getName() + ": " + next.getClassName() + "\n");
				printJNDITree(levelPrefix + "  ", parentPrefix + next.getName());
			}
		}
	}
}

