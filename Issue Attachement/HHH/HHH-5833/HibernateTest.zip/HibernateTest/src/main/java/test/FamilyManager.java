package test;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

public interface FamilyManager {
	
	EntityManager getEm();
	
//	void          clearSecondLevelCache();
	
	String        hello();
	
	Map<String, Long> getCacheSize();
	
	void          createAddress(int id, int streetNumber, String streetName, String cityName, String countryName);
	
	boolean       removeAddress(int id);
	
	Address       findAddress(int id);
	
	Address       findAddressWithInhabitants(int id);
	
	int           coundAddressInhabitants(int id);
	
	Address       findAddressByNames(int streetNumber, String streetName, String cityName, String countryName);
	
	Address       findAddressByNamesWithoutCache(int streetNumber, String streetName, String cityName, String countryName);
	
	Address       findAddressWithInhabitantsByNames(int streetNumber, String streetName, String cityName, String countryName);
	
	Address       findAddressWithInhabitantsByNamesWithoutCache(int streetNumber, String streetName, String cityName, String countryName);
	
	List<Address> findAddressesByFamilyName(String familyName);
	
	List<Address> findAddressesByCity(String cityName, String countryName);
	
	List<Address> findAddressesWithInhabitantsByCity(String cityName, String countryName);
	
	long          countAllAddresses();
	
	
	
	void          createFamily(int id, String name);
	
	boolean       removeFamily(int id);
	
	Family        findFamily(int id);
	
	Family        findFamilyWithMembers(int id);
	
	int           coundFamilyMembers(int id);
	
	Family        findFamilyByName(String name);
	
	Family        findFamilyWithMembersByName(String name);
	
	List<Family>  findFamiliesByInhabitantFirstName(String firstName);
	
	List<Family>  findFamiliesWithMembersByInhabitantFirstName(String firstName);
	
	void          updateFamily(int id, String suffix);
	
	long          countAllFamilies();
	
	
	
	void          createPerson(int id, String firstName, int familyId);
	
	void          createFemale(int id, String firstName, int familyId);
	
	void          createMale(int id, String firstName, int familyId);
	
	boolean       removePerson(int id);
	
	Person        findPerson(int id);
	
	Person        findPersonByNames(String firstName, String familyName);
	
	Person        findPersonByNamesWithoutCache(String firstName, String familyName);
	
	List<Person>  findPersonsByFamily(int familyId);
	
	List<Person>  findPersonsByFamilyName(String familyName);
	
	List<Person>  findPersonsByAddress(int addressId);
	
	int           checkPersonsByFamilyName(String familyName);
	
	void          setAddressForPerson(int personId, int addressId);
	
	int           setAddressForPersonsByFamilyName(String familyName, int addressId);
	
	void          removeAddressForPerson(int personId, int addressId);
	
	void          setBirthDateForPerson(int personId, Date birthDate);
	
	void          setFormatedBirthDateForPerson(int personId, String formatedBirthDate);
	
	long          countAllPersons();
}