package test;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Stateless(name="FamilyManagerBean")
public class FamilyManagerBean implements FamilyManager {

	/*
	 * Logger should not be static, because we can have 
	 * different thread-context-classloaders in WEB apps or J2EE apps.
	 */
	private final Logger log = LoggerFactory.getLogger(FamilyManagerBean.class);

	//@PersistenceContext(unitName = "jpacache1")
	public EntityManager em;

	public EntityManager getEm() {
		return em;
	}
	
	// Does not work with JBossCache : Lock on fqn ENTITY for example
//	public void clearSecondLevelCache() {
//		org.hibernate.SessionFactory sf = ((org.hibernate.ejb.EntityManagerImpl)em.getDelegate()).getSession().getSessionFactory();
//		sf.evict(Address.class);
//		sf.evict(Family.class);
//		sf.evict(Person.class);
//		sf.evictCollection("net.atos.xa.jpacache.domain.Family.members");
//		sf.evictCollection("net.atos.xa.jpacache.domain.Address.inhabitants");
//	}

	public String hello() {
		return "hello";
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Map<String, Long> getCacheSize() {
		Map<String, Long> map = new HashMap<String, Long>();
		// Hibernate specific
//		org.hibernate.SessionFactory sf = ((org.hibernate.ejb.EntityManagerImpl)em.getDelegate()).getSession().getSessionFactory();
//		map.put("  Entity Insert Count = ", Long.valueOf(sf.getStatistics().getEntityInsertCount()));
//		map.put("  Entity Load Count = ", Long.valueOf(sf.getStatistics().getEntityLoadCount()));
//		map.put("  Entity Update Count = ", Long.valueOf(sf.getStatistics().getEntityUpdateCount()));
//		map.put("  Entity Delete Count = ", Long.valueOf(sf.getStatistics().getEntityDeleteCount()));
//		map.put("  Entity Fetch Count = ", Long.valueOf(sf.getStatistics().getEntityFetchCount()));
//		map.put("  Second Level Cache Hit Count = ", Long.valueOf(sf.getStatistics().getSecondLevelCacheHitCount()));
//		map.put("  Second Level Cache Miss Count = ", Long.valueOf(sf.getStatistics().getSecondLevelCacheMissCount()));
//		map.put("  Second Level Cache Put Count = ", Long.valueOf(sf.getStatistics().getSecondLevelCachePutCount()));
//		for (String region : sf.getStatistics().getSecondLevelCacheRegionNames()) {
//			map.put("  Region '" + region + "' : SizeInMemory = " , Long.valueOf(sf.getStatistics().getSecondLevelCacheStatistics(region).getSizeInMemory()));
//			map.put("  Region '" + region + "' : HitCount = ", Long.valueOf(sf.getStatistics().getSecondLevelCacheStatistics(region).getHitCount()));
//			map.put("  Region '" + region + "' : MissCount = ", Long.valueOf(sf.getStatistics().getSecondLevelCacheStatistics(region).getMissCount()));
//			map.put("  Region '" + region + "' : PutCount = ", Long.valueOf(sf.getStatistics().getSecondLevelCacheStatistics(region).getPutCount()));
//			map.put("  Region '" + region + "' : ElementCountInMemory = ", Long.valueOf(sf.getStatistics().getSecondLevelCacheStatistics(region).getElementCountInMemory()));
//			map.put("  Region '" + region + "' : ElementCountOnDisk = ", Long.valueOf(sf.getStatistics().getSecondLevelCacheStatistics(region).getElementCountOnDisk()));
//		}
		return map;
	}

	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void createAddress(int id, int streetNumber, String streetName, String cityName, String countryName) {
		if (log.isDebugEnabled()) {
			log.debug("persist new Address(id=" + id + ",streetNumber=" + streetNumber + ",streetName=" + streetName 
					+ ",cityName=" + cityName + ",countryName=" + countryName + ")");
		}
		Address address = new Address(streetNumber, streetName, cityName, countryName);
		address.setId(id);
		em.persist(address);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public boolean removeAddress(int id) {
		if (log.isDebugEnabled()) {
			log.debug("find and remove Address(id=" + id + ")");
		}
		Address a = em.find(Address.class, id);
		boolean done = false;
		if (a != null) {
			done = true;
			em.remove(a);
		}
		return done;
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Address findAddress(int id) {
		if (log.isDebugEnabled()) {
			log.debug("find Address(id=" + id + ")");
		}
		return em.find(Address.class, id);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Address findAddressWithInhabitants(int id) {
		if (log.isDebugEnabled()) {
			log.debug("find Address(id=" + id + ") and count Inhabitants");
		}
		Address a = em.find(Address.class, id);
		if (a != null) {
			// A method call such as size() is required on members in order to
			// trigger collection lazy loading
			a.getInhabitants().size();
		}
		return a;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public int coundAddressInhabitants(int id) {
		if (log.isDebugEnabled()) {
			log.debug("find Address(id=" + id + ") and count Inhabitants");
		}
		Address a = em.find(Address.class, id);
		int nb = 0;
		if (a != null) {
			nb = a.getInhabitants().size();
		}
		return nb;
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Address findAddressByNames(int streetNumber, String streetName, String cityName, String countryName) {
		if (log.isDebugEnabled()) {
			log.debug("query address.findAddressByNames(streetNumber=" + streetNumber 
					+ ",streetName=" + streetName + ",cityName=" + cityName + ",countryName=" + countryName + ")");
		}
		Query q = em.createNamedQuery("address.findAddressByNames");
		q.setParameter("streetNumber", streetNumber);
		q.setParameter("streetName", streetName);
		q.setParameter("cityName", cityName);
		q.setParameter("countryName", countryName);
		try {
			return (Address)q.getSingleResult();
		} catch (javax.persistence.NoResultException e) {
			return null;
		}
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Address findAddressByNamesWithoutCache(int streetNumber, String streetName, String cityName, String countryName) {
		if (log.isDebugEnabled()) {
			log.debug("query address.findAddressByNamesWithoutCache(streetNumber=" + streetNumber 
					+ ",streetName=" + streetName + ",cityName=" + cityName + ",countryName=" + countryName + ")");
		}
		Query q = em.createNamedQuery("address.findAddressByNamesWithoutCache");
		q.setParameter("streetNumber", streetNumber);
		q.setParameter("streetName", streetName);
		q.setParameter("cityName", cityName);
		q.setParameter("countryName", countryName);
		try {
			return (Address)q.getSingleResult();
		} catch (javax.persistence.NoResultException e) {
			return null;
		}
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Address findAddressWithInhabitantsByNames(int streetNumber, String streetName, String cityName, String countryName) {
		if (log.isDebugEnabled()) {
			log.debug("query address.findAddressByNames(streetNumber=" + streetNumber 
					+ ",streetName=" + streetName + ",cityName=" + cityName + ",countryName=" + countryName 
					+ ") and count Inhabitants");
		}
		Query q = em.createNamedQuery("address.findAddressByNames");
		q.setParameter("streetNumber", streetNumber);
		q.setParameter("streetName", streetName);
		q.setParameter("cityName", cityName);
		q.setParameter("countryName", countryName);
		try {
			Address a = (Address)q.getSingleResult();
			// A method call such as size() is required on members in order to
			// trigger collection lazy loading
			a.getInhabitants().size();
			return a;
		} catch (javax.persistence.NoResultException e) {
			return null;
		}
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Address findAddressWithInhabitantsByNamesWithoutCache(int streetNumber, String streetName, String cityName, String countryName) {
		if (log.isDebugEnabled()) {
			log.debug("query address.findAddressByNamesWithoutCache(streetNumber=" + streetNumber 
					+ ",streetName=" + streetName + ",cityName=" + cityName + ",countryName=" + countryName 
					+ ") and count Inhabitants");
		}
		Query q = em.createNamedQuery("address.findAddressByNamesWithoutCache");
		q.setParameter("streetNumber", streetNumber);
		q.setParameter("streetName", streetName);
		q.setParameter("cityName", cityName);
		q.setParameter("countryName", countryName);
		try {
			Address a = (Address)q.getSingleResult();
			// A method call such as size() is required on members in order to
			// trigger collection lazy loading
			a.getInhabitants().size();
			return a;
		} catch (javax.persistence.NoResultException e) {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Address> findAddressesByFamilyName(String familyName) {
		if (log.isDebugEnabled()) {
			log.debug("query address.findAddressesByFamilyName(familyName=" + familyName + ")");
		}
		Query q = em.createNamedQuery("address.findAddressesByFamilyName");
		q.setParameter("familyName", familyName);
		return (List<Address>)q.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Address> findAddressesByCity(String cityName, String countryName) {
		if (log.isDebugEnabled()) {
			log.debug("query address.findAddressesByCity(cityName=" + cityName + ",countryName=" + countryName + ")");
		}
		Query q = em.createNamedQuery("address.findAddressesByCity");
		q.setParameter("cityName", cityName);
		q.setParameter("countryName", countryName);
		return (List<Address>)q.getResultList();
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Address> findAddressesWithInhabitantsByCity(String cityName, String countryName) {
		if (log.isDebugEnabled()) {
			log.debug("query address.findAddressesByCity(cityName" + cityName + ",countryName=" + countryName 
					+ ") and count Inhabitants");
		}
		Query q = em.createNamedQuery("address.findAddressesByCity");
		q.setParameter("cityName", cityName);
		q.setParameter("countryName", countryName);
		List<Address> addresses = (List<Address>)q.getResultList();
		if (addresses != null) {
			// A method call such as size() is required on members in order to
			// trigger collection lazy loading
			for (Iterator<Address> iterator = addresses.iterator(); iterator.hasNext();) {
				Address a = iterator.next();
				a.getInhabitants().size();
			}
		}
		return addresses;
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public long countAllAddresses() {	
		if (log.isDebugEnabled()) {
			log.debug("query address.countAll");
		}
		Query q = em.createNamedQuery("address.countAll");
		return (Long)q.getSingleResult();
	}
	
	/**
	 * Since we are in a bench context, we want to control the ID value.
	 */
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void createFamily(int id, String name) {
		if (log.isDebugEnabled()) {
			log.debug("persist new Family(id=" + id + ",name=" + name + ")");
		}
		Family family = new Family(name);
		family.setId(id);
		em.persist(family);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public boolean removeFamily(int id) {
		if (log.isDebugEnabled()) {
			log.debug("find and remove Family(id=" + id + ")");
		}
		Family f = em.find(Family.class, id);
		boolean done = false;
		if (f != null) {
			done = true;
			em.remove(f);
		}
		return done;
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Family findFamily(int id) {
		if (log.isDebugEnabled()) {
			log.debug("find Family(id=" + id + ")");
		}
		return em.find(Family.class, id);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Family findFamilyWithMembers(int id) {
		if (log.isDebugEnabled()) {
			log.debug("find Family(id=" + id + ") and count Members");
		}
		Family f = em.find(Family.class, id);
		if (f != null) {
			// A method call such as size() is required on members in order to
			// trigger collection lazy loading
			f.getMembers().size();
		}
		return f;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public int coundFamilyMembers(int id) {
		if (log.isDebugEnabled()) {
			log.debug("find Family(id=" + id + ") and count Members");
		}
		Family f = em.find(Family.class, id);
		int nb = 0;
		if (f != null) {
			nb = f.getMembers().size();
		}
		return nb;
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Family findFamilyByName(String name) {
		if (log.isDebugEnabled()) {
			log.debug("query family.findFamilyByName(name=" + name + ")");
		}
		Query q = em.createNamedQuery("family.findFamilyByName");
		q.setParameter("name", name);
		try {
			return (Family)q.getSingleResult();
		} catch (javax.persistence.NoResultException e) {
			return null;
		}
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Family findFamilyWithMembersByName(String name) {
		if (log.isDebugEnabled()) {
			log.debug("query family.findFamilyByName(name=" + name + ") and count Members");
		}
		Query q = em.createNamedQuery("family.findFamilyByName");
		q.setParameter("name", name);
		try {
			Family f = (Family)q.getSingleResult();
			// A method call such as size() is required on members in order to
			// trigger collection lazy loading
			f.getMembers().size();
			return f;
		} catch (javax.persistence.NoResultException e) {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Family> findFamiliesByInhabitantFirstName(String firstName) {
		if (log.isDebugEnabled()) {
			log.debug("query family.findFamiliesByInhabitantFirstName(firstName=" + firstName + ")");
		}
		Query q = em.createNamedQuery("family.findFamiliesByInhabitantFirstName");
		q.setParameter("firstName", firstName);
		return (List<Family>)q.getResultList();
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Family> findFamiliesWithMembersByInhabitantFirstName(String firstName) {
		if (log.isDebugEnabled()) {
			log.debug("query family.findFamiliesByInhabitantFirstName(firstName=" + firstName 
					+ ") and count Members");
		}
		Query q = em.createNamedQuery("family.findFamiliesByInhabitantFirstName");
		q.setParameter("firstName", firstName);
		List<Family> families = (List<Family>)q.getResultList();
		if (families != null) {
			// A method call such as size() is required on members in order to
			// trigger collection lazy loading
			for (Iterator<Family> iterator = families.iterator(); iterator.hasNext();) {
				Family f = iterator.next();
				f.getMembers().size();
			}
		}
		return families;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void updateFamily(int id, String secondName) {
		if (log.isDebugEnabled()) {
			log.debug("find Family(id=" + id + ") and setSecondName(" + secondName + ")");
		}
		Family family = em.find(Family.class, id);
		family.setSecondName(secondName);
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public long countAllFamilies() {	
		if (log.isDebugEnabled()) {
			log.debug("query family.countAll");
		}
		Query q = em.createNamedQuery("family.countAll");
		return (Long)q.getSingleResult();
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void createPerson(int id, String firstName, int familyId) {
		if (log.isDebugEnabled()) {
			log.debug("find Family(id=" 
					+ familyId + ") and persist new Person(id=" + id + ",firstName=" + firstName + ")");
		}
		Family family = em.find(Family.class, familyId);
		if (family != null) {
			Person person = new Person(firstName, family);
			person.setId(id);
			em.persist(person);
		} else {
			throw new IllegalArgumentException("Family '" + familyId + "' does not currently exist."
					+" Person '" + firstName + "' cannot therefore be created.");
		}
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void createFemale(int id, String firstName, int familyId) {
		if (log.isDebugEnabled()) {
			log.debug("find Family(id=" + familyId 
					+ ") and persist new FemalePerson(id=" + id + ",firstName=" + firstName + ")");
		}
		Family family = em.find(Family.class, familyId);
		if (family != null) {
			Person person = new FemalePerson(firstName, family);
			person.setId(id);
			em.persist(person);
		} else {
			throw new IllegalArgumentException("Family '" + familyId + "' does not currently exist."
					+" Person '" + firstName + "' cannot therefore be created.");
		}
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void createMale(int id, String firstName, int familyId) {
		if (log.isDebugEnabled()) {
			log.debug("find Family(id=" + familyId 
					+ ") and persist new MalePerson(id=" + id + ",firstName=" + firstName + ")");
		}
		Family family = em.find(Family.class, familyId);
		if (family != null) {
			Person person = new MalePerson(firstName, family);
			person.setId(id);
			em.persist(person);
		} else {
			throw new IllegalArgumentException("Family '" + familyId + "' does not currently exist."
					+" Person '" + firstName + "' cannot therefore be created.");
		}
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public boolean removePerson(int id) {
		if (log.isDebugEnabled()) {
			log.debug("find and remove Person(id=" + id + ")");
		}
		Person p = em.find(Person.class, id);
		boolean done = false;
		if (p != null) {
			done = true;
			em.remove(p);
		}
		return done;
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Person findPerson(int id) {
		if (log.isDebugEnabled()) {
			log.debug("find Person(id=" + id + ")");
		}
		return em.find(Person.class, id);
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Person findPersonByNames(String firstName, String familyName) {
		if (log.isDebugEnabled()) {
			log.debug("query person.findPersonByNames(firstName=" + firstName + ",familyName=" + familyName + ")");
		}
		Query q = em.createNamedQuery("person.findPersonByNames");
		q.setParameter("firstName", firstName);
		q.setParameter("familyName", familyName);
		try {
			return (Person)q.getSingleResult();
		} catch (javax.persistence.NoResultException e) {
			return null;
		}
	}
	
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Person findPersonByNamesWithoutCache(String firstName, String familyName) {
		if (log.isDebugEnabled()) {
			log.debug("query person.findPersonByNamesWithoutCache(firstName=" + firstName + ",familyName=" + familyName + ")");
		}
		Query q = em.createNamedQuery("person.findPersonByNamesWithoutCache");
		q.setParameter("firstName", firstName);
		q.setParameter("familyName", familyName);
		try {
			return (Person)q.getSingleResult();
		} catch (javax.persistence.NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Person> findPersonsByFamily(int familyId) {
		if (log.isDebugEnabled()) {
			log.debug("query person.findPersonsByFamily(familyId=" + familyId + ")");
		}
		Query q = em.createNamedQuery("person.findPersonsByFamily");
		q.setParameter("familyId", familyId);
		return (List<Person>)q.getResultList();
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Person> findPersonsByFamilyName(String familyName) {
		if (log.isDebugEnabled()) {
			log.debug("query person.findPersonsByFamilyName(familyName=" + familyName + ")");
		}
		Query q = em.createNamedQuery("person.findPersonsByFamilyName");
		q.setParameter("familyName", familyName);
		return (List<Person>)q.getResultList();
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Person> findPersonsByAddress(int addressId) {
		if (log.isDebugEnabled()) {
			log.debug("query person.findPersonsByAddress(addressId=" + addressId + ")");
		}
		Query q = em.createNamedQuery("person.findPersonsByAddress");
		q.setParameter("addressId", addressId);
		return (List<Person>)q.getResultList();
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public int checkPersonsByFamilyName(String familyName) {
		if (log.isDebugEnabled()) {
			log.debug("query person.findPersonsByFamilyName(familyName=" + familyName + ") and setChecked(true)");
		}
		Query q = em.createNamedQuery("person.findPersonsByFamilyName");
		q.setParameter("familyName", familyName);
		List<Person> persons = (List<Person>)q.getResultList();
		for (Iterator<Person> iterator = persons.iterator(); iterator.hasNext();) {
			Person person = iterator.next();
			person.setChecked(true);
		}
		return persons.size();
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void setAddressForPerson(int personId, int addressId) {
		if (log.isDebugEnabled()) {
			log.debug("find Address(id=" + addressId + "), find Person(id=" + personId + ") and setAddress()");
		}
		Address address = findAddress(addressId);
		if (address == null) {
			throw new IllegalArgumentException("Address with id " + addressId + " does not currently exist.");
		}
		Person person = findPerson(personId);
		if (person == null) {
			throw new IllegalArgumentException("Person with id " + personId + " does not currently exist.");
		}
		// Due to Hibernate BUG
//		if (person.getAddress() != null) person.getAddress().remInhabitant(person);
//      if (address != null) address.addInhabitant(person);
        //
		person.setAddress(address);
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public int setAddressForPersonsByFamilyName(String familyName, int addressId) {
		if (log.isDebugEnabled()) {
			log.debug("find Address(id=" + addressId 
					+ "), query person.findPersonsByFamilyName(familyName=" + familyName 
					+ ") and setAddress()");
		}
		Address address = findAddress(addressId);
		if (address == null) {
			throw new IllegalArgumentException("Address with id " + addressId + " does not currently exist.");
		}
		Query q = em.createNamedQuery("person.findPersonsByFamilyName");
		q.setParameter("familyName", familyName);
		List<Person> persons = (List<Person>)q.getResultList();
		for (Iterator<Person> iterator = persons.iterator(); iterator.hasNext();) {
			Person person = iterator.next();
			// Due to Hibernate BUG
//			if (person.getAddress() != null) person.getAddress().remInhabitant(person);
//	        if (address != null) address.addInhabitant(person);
	        //
			person.setAddress(address);
		}
		return persons.size();
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	/*
	 * We add parameter addressId to have the same CPU consumption with setAddressForPerson()
	 */
	public void removeAddressForPerson(int personId, int addressId) {
		if (log.isDebugEnabled()) {
			log.debug("find Address(id=" + addressId 
					+ "), find Person(id=" + personId + ") and setAddress(null)");
		}
		Address address = findAddress(addressId);
		if (address == null) {
			throw new IllegalArgumentException("Address with id " + addressId + " does not currently exist.");
		}
		Person person = findPerson(personId);
		if (person == null) {
			throw new IllegalArgumentException("Person with id " + personId + " does not currently exist.");
		}
		// Due to Hibernate BUG
//		if (person.getAddress() != null) person.getAddress().remInhabitant(person);
		//
		person.setAddress(null);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void setBirthDateForPerson(int personId, Date birthDate) {
		if (log.isDebugEnabled()) {
			log.debug("find Person(id=" + personId + ") and setBirthDate(" + birthDate + ")");
		}
		Person person = findPerson(personId);
		if (person == null) {
			throw new IllegalArgumentException("Person with id " + personId + " does not currently exist.");
		}
		person.setBirthDate(birthDate);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void setFormatedBirthDateForPerson(int personId, String formatedBirthDate) {
		if (log.isDebugEnabled()) {
			log.debug("find Person(id=" + personId + ") and setBirthDate(" + formatedBirthDate + ")");
		}
		Person person = findPerson(personId);
		if (person == null) {
			throw new IllegalArgumentException("Person with id " + personId + " does not currently exist.");
		}
		try {
			person.setBirthDate(formatedBirthDate);
		} catch (ParseException e) {
			throw new IllegalArgumentException("BirthDate '" + formatedBirthDate 
					+ "' is not recognized.", e);
		}
	}
	
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public long countAllPersons() {	
		if (log.isDebugEnabled()) {
			log.debug("query person.countAll()");
		}
		Query q = em.createNamedQuery("person.countAll");
		return (Long)q.getSingleResult();
	}
	
}
