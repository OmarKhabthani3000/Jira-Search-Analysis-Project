package test;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * The Class Address.
 * 
 * The functional key is made from streetNumber, streetName, cityName and countryName. It must be unique.
 * Therefore, it is not possible to change these attributes after instanciation.
 * 
 * The attributes id and version are DB technical, and setted by JPA provider.
 * Therefore, it is not possible to change publicly these attributes.
 */
public final
class Address 
{

	//------------------------------------------------------------------------
	// public
	//------------------------------------------------------------------------
	
	public 
	Address(int streetNumber, String streetName, String cityName, String countryName) 
	{
		this.streetNumber = streetNumber;
		this.streetName = streetName;
		this.cityName = cityName;
		this.countryName = countryName;
		this.zipCode = null;
		this.inhabitants = new HashSet<Person>();
		this.id = 0;
		this.version = 0;
	}

	//------------------------------------------------------------------------
	
	public int 
	getStreetNumber() 
	{
		return streetNumber;
	}

	//------------------------------------------------------------------------
	
	public String 
	getStreetName() 
	{
		return streetName;
	}

	//------------------------------------------------------------------------
	
	public String 
	getCityName() 
	{
		return cityName;
	}

	//------------------------------------------------------------------------
	
	public String 
	getCountryName() 
	{
		return countryName;
	}

	//------------------------------------------------------------------------
	
	public String 
	getZipCode() 
	{
		return zipCode;
	}

	//------------------------------------------------------------------------
	
	public void 
	setZipCode(String zipCode) 
	{
		this.zipCode = zipCode;
	}

	//------------------------------------------------------------------------
	
	public Set<Person> 
	getInhabitants() 
	{
		return inhabitants;
	}

	//------------------------------------------------------------------------
	
	public boolean 
	addInhabitant(Person inhabitant) 
	{
		boolean done = false;
		if (inhabitants.add(inhabitant)) {
			inhabitant.setAddress(this);
			done = true;
		}
		return done;
	}

	//------------------------------------------------------------------------
	
	public boolean 
	remInhabitant(Person inhabitant) 
	{
		boolean done = false;
		if (inhabitants.remove(inhabitant)) {
			inhabitant.setAddress(null);
			done = true;
		}
		return done;
	}

	//------------------------------------------------------------------------
	
	public int 
	getId() 
	{
		return id;
	}

	//------------------------------------------------------------------------
	
	/**
	 * Since we are in a bench context, we want to control the ID value.
	 * In other context, this method should be protected 
	 * and the getter should use "@GeneratedValue(strategy = GenerationType.AUTO)". 
	 */
	public void 
	setId(int id) 
	{
		this.id = id;
	}

	//------------------------------------------------------------------------
	
	public int 
	getVersion() 
	{
		return version;
	}

	//------------------------------------------------------------------------
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */                
	@Override
    public boolean 
    equals(Object o) 
	{
    	if (this == o) {
    		return true;
    	}
		if (o == null) {
			return false;
		}
		if (getClass() != o.getClass()) {
			// equals must be symetric : 
			//   Address.equals(<Subclass extends Address> o) <=> <Subclass extends Address>.equals(Address o)
			// => we should not use instanceof
			return false;
		}
    	final Address toCompare = (Address) o;
        return new EqualsBuilder()
    	.append(getStreetNumber(), toCompare.getStreetNumber())
    	.append(getStreetName(), toCompare.getStreetName())
    	.append(getCityName(), toCompare.getCityName())
    	.append(getCountryName(), toCompare.getCountryName())
		.isEquals();
	}

	//------------------------------------------------------------------------
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
    @Override
    public int 
    hashCode() 
    {
        return new HashCodeBuilder()
		.append(getStreetNumber())
		.append(getStreetName())
		.append(getCityName())
		.append(getCountryName())
    	.toHashCode();
    }

	//------------------------------------------------------------------------
	
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String 
    toString() 
    {
        return new ToStringBuilder(this)
		.append("streetNumber", this.getStreetNumber())
		.append("streetName", this.getStreetName())
		.append("zipCode", this.getZipCode())
		.append("cityName", this.getCityName())
		.append("countryName", this.getCountryName())
        .append("id", this.getId())
    	.append("version", this.getVersion())
    	.toString();
    }
    
	//------------------------------------------------------------------------
	// protected
	//------------------------------------------------------------------------
	
	protected 
	Address() 
	{
		this.streetNumber = 0;
		this.streetName = null;
		this.cityName = null;
		this.countryName = null;
		this.zipCode = null;
		this.inhabitants = new HashSet<Person>();
		this.id = 0;
		this.version = 0;
	}
	
	//------------------------------------------------------------------------
	
	protected void 
	removeAllInhabitants() 
	{
		// inhabitants relation is not CASCADED, we must delete the relation on other side by ourselves
		for (Iterator<Person> iterator = inhabitants.iterator(); iterator.hasNext();) {
			Person p = iterator.next();
			p.setAddress(null);
		}
	}

	//------------------------------------------------------------------------
	
	protected void 
	setStreetNumber(int streetNumber) 
	{
		this.streetNumber = streetNumber;
	}

	//------------------------------------------------------------------------
	
	protected void 
	setStreetName(String streetName) 
	{
		this.streetName = streetName;
	}

	//------------------------------------------------------------------------
	
	protected void 
	setCityName(String cityName) 
	{
		this.cityName = cityName;
	}

	//------------------------------------------------------------------------
	
	protected void 
	setCountryName(String countryName) 
	{
		this.countryName = countryName;
	}

	//------------------------------------------------------------------------
	
	protected void 
	setInhabitants(Set<Person> inhabitants) 
	{
		if (inhabitants == null) {
			this.inhabitants = new HashSet<Person>();
		} else {
			this.inhabitants = inhabitants;
		}
	}

	//------------------------------------------------------------------------
	
	protected void 
	setVersion(Integer version) 
	{
		this.version = version;
	}
	
	//------------------------------------------------------------------------
	// members
	//------------------------------------------------------------------------
	
	private int streetNumber;
	private String streetName;
	private String cityName;
	private String countryName;
	private String zipCode;
	private Set<Person> inhabitants;
	private int id;
	private int version;
}
