package test;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * The Class Family.
 * 
 * The functional key is made from name. It must be unique.
 * Therefore, it is not possible to change this attribute after instanciation.
 * 
 * The attributes id and version are DB technical, and setted by JPA provider.
 * Therefore, it is not possible to change publicly these attributes.
 */
public final
class Family 
{

	//------------------------------------------------------------------------
	// public
	//------------------------------------------------------------------------
	
	public 
	Family(String name) 
	{
		this.name = name;
		this.secondName = null;
		this.members = new HashSet<Person>();
		this.id = 0;
		this.version = 0;
	}
	
	//------------------------------------------------------------------------
	
	public String 
	getName() 
	{
		return name;
	}

	//------------------------------------------------------------------------
	
	public Set<Person> 
	getMembers() 
	{
		return members;
	}

	//------------------------------------------------------------------------
	
	public String 
	getSecondName() 
	{
		return secondName;
	}

	//------------------------------------------------------------------------
	
	public void 
	setSecondName(String secondName) 
	{
		this.secondName = secondName;
	}

	//------------------------------------------------------------------------
	
	public int 
	getId() 
	{
		return id;
	}

	//------------------------------------------------------------------------
	
	/**
	 * Since we are in a bench context, we want to control the ID value.
	 * In other context, this method should be protected 
	 * and the getter should use "@GeneratedValue(strategy = GenerationType.AUTO)". 
	 */
	public void 
	setId(int id) 
	{
		this.id = id;
	}

	//------------------------------------------------------------------------
	
	public int 
	getVersion() 
	{
		return version;
	}

	//------------------------------------------------------------------------
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */                
	@Override
    public boolean 
    equals(Object o) 
	{
    	if (this == o) {
    		return true;
    	}
		if (o == null) {
			return false;
		}
		if (getClass() != o.getClass()) {
			// equals must be symetric : 
			//   Address.equals(<Subclass extends Address> o) <=> <Subclass extends Address>.equals(Address o)
			// => we should not use instanceof
			return false;
		}
    	final Family toCompare = (Family) o;
        return new EqualsBuilder()
    	.append(getName(), toCompare.getName())
		.isEquals();
	}

	//------------------------------------------------------------------------
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
    @Override
    public int 
    hashCode() 
    {
        return new HashCodeBuilder()
		.append(getName())
    	.toHashCode();
    }

	//------------------------------------------------------------------------
	
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String 
    toString() 
    {
        return new ToStringBuilder(this)
		.append("name", this.getName())
		.append("secondName", this.getSecondName())
        .append("id", this.getId())
    	.append("version", this.getVersion())
    	.toString();
    }
    
	//------------------------------------------------------------------------
	// package
	//------------------------------------------------------------------------
	
	/**
	 * Adds a member in the Collection members.
	 * But does not update this relation on Person side.
	 * This is used internally to update the Collection members in Person constructor 
	 * 
	 * @param member the member
	 * 
	 * @return true, if successful
	 */
	boolean 
	addMember(Person member) 
	{
		return members.add(member);
	}

	//------------------------------------------------------------------------
	// protected
	//------------------------------------------------------------------------
	
	protected 
	Family() 
	{
		this.name = null;
		this.secondName = null;
		this.members = new HashSet<Person>();
		this.id = 0;
		this.version = 0;
	}
	
	//------------------------------------------------------------------------
	
	protected void 
	setName(String name) 
	{
		this.name = name;
	}

	//------------------------------------------------------------------------
	
	protected void 
	setMembers(Set<Person> members) 
	{
		if (members == null) {
			this.members = new HashSet<Person>();
		} else {
			this.members = members;
		}
	}

	//------------------------------------------------------------------------
	
	protected void 
	setVersion(Integer version) 
	{
		this.version = version;
	}

	//------------------------------------------------------------------------
	// members
	//------------------------------------------------------------------------
	
	private String name;
	private String secondName;
	private Set<Person> members;
	private int id;
	private int version;
}
