package test;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.time.DateUtils;

/**
 * The Class Person.
 * 
 * The functional key is made from firstName and family. It must be unique.
 * Therefore, it is not possible to change these attributes after instanciation.
 * 
 * The attributes id and version are DB technical, and setted by JPA provider.
 * Therefore, it is not possible to change publicly these attributes.
 */
public 
class Person 
{
	
	//------------------------------------------------------------------------
	// public
	//------------------------------------------------------------------------
	
	public 
	Person(String firstName, Family family) 
	{
		this.firstName = firstName;
		this.family = family;
		this.birthDate = null;
		this.address = null;
		this.checked = false;
		this.id = 0;
		this.version = 0;
		this.family.addMember(this);
	}
	
	//------------------------------------------------------------------------
	
	public String 
	getFirstName() 
	{
		return firstName;
	}

	//------------------------------------------------------------------------
	
	public Family 
	getFamily() 
	{
		return family;
	}

	//------------------------------------------------------------------------
	
	public Date 
	getBirthDate() 
	{
		return birthDate;
	}

	//------------------------------------------------------------------------
	
	public void 
	setBirthDate(Date birthDate) 
	{
		this.birthDate = birthDate;
	}
	
	//------------------------------------------------------------------------
	
	public void 
	setBirthDate(String formatedDate) throws ParseException 
	{
		setBirthDate(DateUtils.parseDate(formatedDate, DATE_FORMAT));
	}

	//------------------------------------------------------------------------
	
	public Address 
	getAddress() 
	{
		return address;
	}

	//------------------------------------------------------------------------
	
	/**
	 * Sets the address.
	 * 
	 * @param address the address
	 * 
	 * @return true, if successfully changed
	 */
	public void 
	setAddress(Address address) 
	{
		// To skip Hibernate BUG with access.PROPERTY : the rest should be done in DAO
//		this.address = address;
		// Hibernate BUG : if we update the relation on 2 sides
		if (this.address != address) {
			if (this.address != null) this.address.remInhabitant(this);
			this.address = address;
			if (this.address != null) this.address.addInhabitant(this);
		}
	}

	//------------------------------------------------------------------------
	
	public boolean 
	isChecked() 
	{
		return checked;
	}

	//------------------------------------------------------------------------
	
	public void 
	setChecked(boolean checked) 
	{
		this.checked = checked;
	}

	//------------------------------------------------------------------------
	
	public int 
	getId() 
	{
		return id;
	}

	//------------------------------------------------------------------------
	
	/**
	 * Since we are in a bench context, we want to control the ID value.
	 * In other context, this method should be protected 
	 * and the getter should use "@GeneratedValue(strategy = GenerationType.AUTO)". 
	 */
	public void 
	setId(int id) 
	{
		this.id = id;
	}

	//------------------------------------------------------------------------
	
	public int 
	getVersion() 
	{
		return version;
	}

	
	//------------------------------------------------------------------------
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
    public boolean 
    equals(Object o) 
	{
		if (this == o) {
			return true;
		}
		if (o == null) {
			return false;
		}
		if (getClass() != o.getClass()) {
			// equals must be symetric : 
			//   Person.equals(<Subclass extends Person> o) <=> <Subclass extends Person>.equals(Person o)
			// => we cannot use instanceof
			return false;
		}
    	final Person toCompare = (Person) o;
        return new EqualsBuilder()
    	.append(getFirstName(), toCompare.getFirstName())
    	.append(getFamily(), toCompare.getFamily())
		.isEquals();
	}

	//------------------------------------------------------------------------
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
    @Override
    public int 
    hashCode() 
    {
        return new HashCodeBuilder()
		.append(getFirstName())
		.append(getFamily())
    	.toHashCode();
    }

	//------------------------------------------------------------------------
	
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String 
    toString() 
    {
        return new ToStringBuilder(this)
		.append("sexe", "U")
		.append("firstName", this.getFirstName())
		.append("family", this.getFamily())
		.append("birthDate", this.getBirthDate())
		.append("address", this.getAddress())
		.append("checked", this.isChecked())
        .append("id", this.getId())
    	.append("version", this.getVersion())
    	.toString();
    }

	//------------------------------------------------------------------------
	// protected
	//------------------------------------------------------------------------
	
    protected 
    Person() 
    {
		this.firstName = null;
		this.family = null;
		this.birthDate = null;
		this.address = null;
		this.checked = false;
		this.id = 0;
		this.version = 0;
	}
    
    protected void 
    setFirstName(String firstName) 
    {
		this.firstName = firstName;
	}

    protected void 
    setFamily(Family family) 
    {
		this.family = family;
	}

	protected void 
	setVersion(Integer version) 
	{
		this.version = version;
	}

	//------------------------------------------------------------------------
	// static members
	//------------------------------------------------------------------------
	
	private static final String[] DATE_FORMAT = {"dd/MM/yyyy"};
	
	//------------------------------------------------------------------------
	// members
	//------------------------------------------------------------------------
	
	private String firstName;
	private Family family;
	private Date birthDate;
	private Address address;
	private boolean checked;
	private int id;
	private int version;
}
