package test;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * The Class MalePerson.
 * 
 * The functional key is made from Person.firstName and Person.family.
 */
public 
class MalePerson 
extends Person 
{

	//------------------------------------------------------------------------
	// public
	//------------------------------------------------------------------------
	
	public 
	MalePerson(String firstName, Family family) 
	{
		super(firstName, family);
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */    
	@Override
    public boolean 
    equals(Object o) 
	{
		if (this == o) {
			return true;
		}
		if (o == null) {
			return false;
		}
		if (getClass() != o.getClass()) {
			// equals must be symetric : 
			//   Person.equals(MalePerson o) <=> MalePerson.equals(Person o)
			// => we cannot use instanceof
			return false;
		}
    	final MalePerson toCompare = (MalePerson) o;
        return new EqualsBuilder()
    	.append(getFirstName(), toCompare.getFirstName())
    	.append(getFamily(), toCompare.getFamily())
		.isEquals();
	}

	//------------------------------------------------------------------------
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
    @Override
    public int 
    hashCode() 
    {
        return new HashCodeBuilder()
		.append(getFirstName())
		.append(getFamily())
    	.toHashCode();
    }

	//------------------------------------------------------------------------
	
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String 
    toString() 
    {
        return new ToStringBuilder(this)
		.append("sexe", "M")
		.append("firstName", this.getFirstName())
		.append("family", this.getFamily())
		.append("birthDate", this.getBirthDate())
		.append("address", this.getAddress())
		.append("checked", this.isChecked())
        .append("id", this.getId())
    	.append("version", this.getVersion())
    	.toString();
    }

	//------------------------------------------------------------------------
	// protected
	//------------------------------------------------------------------------

    protected 
    MalePerson() 
    {
    	super();
	}
}
