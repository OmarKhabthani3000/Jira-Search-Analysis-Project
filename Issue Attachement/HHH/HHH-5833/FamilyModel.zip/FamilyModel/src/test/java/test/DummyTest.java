package test;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit tests.
 */
public
class DummyTest 
{
	@Test
    public void 
    testApp()
    {
        Assert.assertTrue( true );
    }
}
