package org.hibernate.bugs;

import java.io.Serializable;
import java.util.Locale;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "Description")
public class MasterdataDescriptionEntity implements Serializable{


	private static final long serialVersionUID = -2234107629248439062L;

	@Id
	@Column(name = "sequence", length = 11, updatable = false, nullable = false)
	private Long sequence;

	@Id
	@Column(name = "isoLanguageCode", length = 5, updatable = false, nullable = false)
	private Locale isoLanguageCode;

	@Column(name = "translatedText", length = 512, nullable = false, unique = false)
	private String translatedText;
	

	public Long getSequence() {
		return sequence;
	}

	public void setSequence(Long sequence) {
		this.sequence = sequence;
	}

	public String getTranslatedText() {
		return translatedText;
	}

	public void setTranslatedText(String translatedText) {
		this.translatedText = translatedText;
	}

	public Locale getIsoLanguageCode() {
		return isoLanguageCode;
	}

	public void setIsoLanguageCode(Locale isoLanguageCode) {
		this.isoLanguageCode = isoLanguageCode;
	}

	

	

}
