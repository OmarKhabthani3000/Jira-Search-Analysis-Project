package org.hibernate.bugs;

import java.io.Serializable;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.SecondaryTable;
import jakarta.persistence.Table;


@Entity
@Table(name = "Country")
@SecondaryTable(name = "CountryDescriptionMapping", pkJoinColumns = {@PrimaryKeyJoinColumn(name = "isoCode", referencedColumnName = "isoCode" )} )
public class CountryEntity implements Serializable{

	private static final long serialVersionUID = -8903799816266034621L;
	
	@Id
	@Column(name = "isoCode", length = 3, nullable = false, unique = false)
	private String isoCode;
    
	@Column(name = "sequence", length = 11, table = "CountryDescriptionMapping")
	private Long sequenceLanguageNumber;
	
	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "sequence", referencedColumnName = "sequence") 
	private List<MasterdataDescriptionEntity> descriptions;
	


	public Long getSequenceLanguageNumber() {
		return sequenceLanguageNumber;
	}

	public void setSequenceLanguageNumber(Long sequenceLanguageNumber) {
		this.sequenceLanguageNumber = sequenceLanguageNumber;
	}

	public List<MasterdataDescriptionEntity> getDescriptions() {
		return descriptions;
	}

	public void setDescriptions(List<MasterdataDescriptionEntity> descriptions) {
		this.descriptions = descriptions;
	}

	public String getIsoCode() {
		return isoCode;
	}

	public void setIsoCode(String isoCode) {
		this.isoCode = isoCode;
	}
	
	

}
