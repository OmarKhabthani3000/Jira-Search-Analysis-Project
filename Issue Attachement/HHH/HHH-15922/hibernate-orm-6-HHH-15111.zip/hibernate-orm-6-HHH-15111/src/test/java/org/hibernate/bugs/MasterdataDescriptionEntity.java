package org.hibernate.bugs;

import java.io.Serializable;
import java.util.Locale;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "MDUDSP")
public class MasterdataDescriptionEntity implements Serializable{


	private static final long serialVersionUID = -2234107629248439062L;

	@Id
	@Column(name = "MUSLN", length = 11, updatable = false, nullable = false)
	private Long sequenceLanguageNumber;

	@Id
	@Column(name = "MUTLO", length = 5, updatable = false, nullable = false)
	private Locale translationLocale;

	@Column(name = "MUVAL", length = 512, nullable = false, unique = false)
	private String value;
	

	public Long getSequenceLanguageNumber() {
		return sequenceLanguageNumber;
	}

	public void setSequenceLanguageNumber(Long sequenceLanguageNumber) {
		this.sequenceLanguageNumber = sequenceLanguageNumber;
	}

	public Locale getTranslationLocale() {
		return translationLocale;
	}

	public void setTranslationLocale(Locale translationLocale) {
		this.translationLocale = translationLocale;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	

	

}
