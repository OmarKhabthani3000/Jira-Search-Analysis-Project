package org.hibernate.bugs;

import java.io.Serializable;


public class CountryId implements Serializable {

	private static final long serialVersionUID = 8593639274258843233L;

	private Integer business;

	private String isoCountryAlpha2Code;

	public Integer getBusiness() {
		return business;
	}

	public void setBusiness(Integer business) {
		this.business = business;
	}

	public String getIsoCountryAlpha2Code() {
		return isoCountryAlpha2Code;
	}

	public void setIsoCountryAlpha2Code(String isoCountryAlpha2Code) {
		this.isoCountryAlpha2Code = isoCountryAlpha2Code;
	}

	
}
