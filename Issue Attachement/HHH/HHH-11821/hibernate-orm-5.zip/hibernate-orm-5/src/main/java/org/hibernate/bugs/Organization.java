package org.hibernate.bugs;

import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(schema = "ormenhance")
public class Organization {
    
    
    @SequenceGenerator(name = "org_seq_generator", sequenceName = "org_seq")
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO,
            generator = "org_seq_generator")
    @Access(AccessType.PROPERTY)
    private Integer id;

    @Column
    private String name;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "primary_user_id", referencedColumnName = "id")
    private User primaryUser;


    @Basic(fetch = FetchType.LAZY)
    @Column(length = 102400)
    private byte[] logo;

    @Column
    private boolean enabled;
    
    @OneToMany(mappedBy = "organization", fetch = FetchType.LAZY)
    private Set<User> users;

    public Organization() {
    }

    public Organization(int orgId) {
        this.id = orgId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<User> getUsers() {
        return users;
    }

    public void setUsers(Set<User> users) {
        this.users = users;
    }

    public User getPrimaryUser() {
        return primaryUser;
    }

    public void setPrimaryUser(User primaryUser) {
        this.primaryUser = primaryUser;
    }



    public byte[] getLogo() {
        return logo != null ? logo.clone() : null;
    }

    public void setLogo(byte[] logo) {
        this.logo = logo != null ? logo.clone() : null;
    }

    public boolean isEnabled() {
        return enabled;
    }

    /**
     * @param enabled
     *            the enabled to set
     */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

}
