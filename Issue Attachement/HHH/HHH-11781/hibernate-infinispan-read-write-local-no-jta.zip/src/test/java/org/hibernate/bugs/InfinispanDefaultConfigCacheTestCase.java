package org.hibernate.bugs;

import org.hibernate.cache.infinispan.InfinispanRegionFactory;
import org.hibernate.cfg.Configuration;

/**
 * @author aarkaev
 * @since 01.06.2017
 */
public class InfinispanDefaultConfigCacheTestCase extends InfinispanCacheBaseTestCase {

    @Override
    protected void configure(Configuration configuration) {
        super.configure(configuration);

        configuration.setProperty(InfinispanRegionFactory.INFINISPAN_CONFIG_RESOURCE_PROP, InfinispanRegionFactory.DEF_INFINISPAN_CONFIG_RESOURCE);
    }
}
