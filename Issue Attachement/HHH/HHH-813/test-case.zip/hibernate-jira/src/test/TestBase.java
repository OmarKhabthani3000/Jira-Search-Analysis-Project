package test;

import java.io.Serializable;

import junit.framework.TestCase;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.classic.Session;

/*
 * $Id: $
 * All rights reserved, Copyright (c) MITANI SANGYO Co.,Ltd. 2005-
 */

/**
 * 
 * TODO Describe the JavaDoc comment!
 * 
 */
public class TestBase extends TestCase {

	private Session session;

	private Transaction transaction;

	private boolean updateFlg;

	private void beginTrans() {
		transaction = session.beginTransaction();
	}

	private void commit() {
		transaction.commit();
	}

	protected Object get(Class class1, Serializable id) {
		return session.get(class1, id);
	}

	private void openSession(boolean flg) {
		Configuration configuration = new Configuration();
		if (flg) {
			configuration.setProperty(Environment.HBM2DDL_AUTO, "create-drop");
		}
		SessionFactory sessionFactory = configuration.configure()
				.buildSessionFactory();
		session = sessionFactory.openSession();
	}

	protected void restartSession() {
		session.close();
		openSession(false);
	}

	protected Serializable save(Object object) {
		beginTrans();
		Serializable id = session.save(object);
		commit();
		return id;
	}

	protected void setUp() throws Exception {
		super.setUp();
		openSession(true);
	}

}
