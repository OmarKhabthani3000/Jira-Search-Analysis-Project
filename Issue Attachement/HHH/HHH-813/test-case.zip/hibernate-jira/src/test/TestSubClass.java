/*
 * $Id: $
 * All rights reserved, Copyright (c) MITANI SANGYO Co.,Ltd. 2005-
 */
package test;

import java.io.Serializable;

/**
 * 
 * TODO Describe the JavaDoc comment!
 * 
 */
public class TestSubClass extends TestBase {
	public void testLoad() throws Exception {
		Serializable id;
		Serializable id1;
		Serializable id2;
		{
			// add 1 associate entity
			AssEntity assEntity = new AssEntity();
			assEntity.setId("1");
			id = save(assEntity);

			// add 1 sub entity1
			SubEntity1 entity1 = new SubEntity1();
			entity1.setName("entity 1 name");
			entity1.setSeq("1");
			id1 = save(entity1);

			// add 1 sub entity2
			SubEntity2 subEntity2 = new SubEntity2();
			subEntity2.setName("entity 2 name");
			subEntity2.setSeq("1");
			id2 = save(subEntity2);
		}
		restartSession();
		{
			assertTrue(get(Entity.class, id1) instanceof SubEntity1);
			assertTrue(get(Entity.class, id2) instanceof SubEntity2);
		}
		restartSession();
		{
			AssEntity assEntity = (AssEntity) get(AssEntity.class, id);

			assertFalse(assEntity.getEntities1().size() == 1);
			assertEquals(2, assEntity.getEntities1().size());

			Entity entity1 = (Entity) assEntity.getEntities1().toArray()[0];
			assertEquals(id1, entity1.getId());
			assertTrue(entity1 instanceof SubEntity1);

			Entity entity2 = (Entity) assEntity.getEntities1().toArray()[1];
			assertEquals(id2, entity2.getId());
			assertTrue(entity2 instanceof SubEntity1);// wrong result

			assertTrue(assEntity.getEntities2().size() > 0);// throw
															// WrongClassExceltion
			assertTrue(assEntity.getEntities2().toArray()[0] instanceof SubEntity2);
		}
	}
}
