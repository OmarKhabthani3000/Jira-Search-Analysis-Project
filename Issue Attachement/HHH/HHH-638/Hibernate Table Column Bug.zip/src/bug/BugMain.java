package bug;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class BugMain {
    public static void main(String[] args) {
        ApplicationContext context = new FileSystemXmlApplicationContext(
                "application.xml");
        DocumentDAO dao = (DocumentDAO)context.getBean("DocumentDAO");
        Document doc = new Document();
        doc.setTitle("A document");
        doc.setDocument("The document.");
        dao.save(doc);
        doc = null;
        doc = dao.findByTitle("A document");
        System.out.println(doc.getDocument());
        dao.delete(doc);
    }
}
