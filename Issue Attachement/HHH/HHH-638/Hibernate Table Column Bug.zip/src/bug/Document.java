package bug;

import java.io.UnsupportedEncodingException;

public class Document {
    
    private Long documentId;
    public Long getDocumentId() {
        return this.documentId;
    }
    public void setDocumentId(Long documentId) {
        this.documentId = documentId;
    }
    
    private String document;
    public String getDocument() {
        return this.document;
    }
    public void setDocument(String document) {
        this.document = document;
    }

    private String title;
    public String getTitle() {
        return this.title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    
    public byte[] getContent() {
        byte[] result = null;
        try {
            result = document.getBytes("UTF-8");
        } catch (UnsupportedEncodingException exc) {}
        return result;
    }
    public void setContent(byte[] content) {
        try{
            this.document = new String(content, "UTF-8");
        } catch (UnsupportedEncodingException exc) {}
    }
}
