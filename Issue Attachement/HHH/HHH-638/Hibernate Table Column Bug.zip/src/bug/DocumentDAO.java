package bug;

import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class DocumentDAO {
    
    private SessionFactory sessionFactory;
    private HibernateTemplate hibernateTemplate;
    
    public DocumentDAO() {
    }
    
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        hibernateTemplate = new HibernateTemplate(sessionFactory);
    }
    
    public void save(Document doc) {
        hibernateTemplate.save(doc);
    }
    
    public void delete(Document doc) {
        hibernateTemplate.delete(doc);
    }
    
    public Document findById(int id) {
        return (Document)hibernateTemplate.get(Document.class, new Long(id));
    }
    
    public Document findByTitle(String title) {
        List list = hibernateTemplate.find(
                "from Document a where a.title = ?",
                new Object[] { title });
        return (Document)list.get(0);
    }
}
