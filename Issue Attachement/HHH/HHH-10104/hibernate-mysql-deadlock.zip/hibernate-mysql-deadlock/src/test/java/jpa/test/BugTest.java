package jpa.test;

import java.util.List;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import jpa.test.entities.Document;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BugTest {
    
    private EntityManagerFactory emf;
    private EntityManager em;
    
    @Before
    public void setup() {
        Properties properties = new Properties();
        properties.put("javax.persistence.jdbc.url", System.getProperty("jdbc.url"));
        properties.put("javax.persistence.jdbc.user", System.getProperty("jdbc.user", ""));
        properties.put("javax.persistence.jdbc.password", System.getProperty("jdbc.password", ""));
        properties.put("javax.persistence.jdbc.driver", System.getProperty("jdbc.driver"));
        properties.put("javax.persistence.sharedCache.mode", "NONE");
        
        /* 
         * NOTE: When commenting out the following, everything seems to work
         */
        properties.put("hibernate.hbm2ddl.auto", "create-drop");
        
        emf = Persistence.createEntityManagerFactory("TestPU", properties);
        em = emf.createEntityManager();
        
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        em.persist(new Document("Aoc"));
        tx.commit();
    }
    
    @After
    public void destruct() {
    	EntityManagerFactory factory = em.getEntityManagerFactory();
    	// NOTE: We need to close the entity manager or else we could run into a deadlock on some dbms platforms
    	// I am looking at you MySQL..
    	em.close();
        factory.close();
    }
    
    @Test
    public void testRun() {
        TypedQuery<String> query = em.createQuery("SELECT d.name FROM Document d", String.class);
        List<String> results = query.getResultList();
        Assert.assertEquals(1, results.size());
    }
}
