package net.kemuri9.hibernate;

public enum EnumType {

	ONE(1),
	TWO(2),
	THREE(3);
	
	public final byte code;
	
	private EnumType(int code) {
		this.code = (byte) code;
	}
}
