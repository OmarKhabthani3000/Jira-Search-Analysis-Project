package net.kemuri9.hibernate;

import java.util.Arrays;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

/**
 * Short works, but Byte does not
 * @author Steven Walters
 *
 */
@Converter()
public class EnumTypeShortConverter implements AttributeConverter<EnumType, Short> {

	@Override
	public Short convertToDatabaseColumn(EnumType attribute) {
		return (attribute == null) ? null : (short) attribute.code;
	}

	@Override
	public EnumType convertToEntityAttribute(Short dbData) {
		return (dbData == null) ? null : Arrays.stream(EnumType.values())
				.filter((e)-> e.code == dbData.byteValue()).findFirst().orElse(null);
	}

}
