package net.kemuri9.hibernate;

import javax.persistence.*;

@Entity
public class EntityType {
	
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long id;
	
	/** short works without issue, but Byte throws unknown SQL type error */
//	@Convert(converter = EnumTypeShortConverter.class)
	@Convert(converter = EnumTypeByteConverter.class)
	@Column(nullable = true)
	public EnumType enumVal;
}
