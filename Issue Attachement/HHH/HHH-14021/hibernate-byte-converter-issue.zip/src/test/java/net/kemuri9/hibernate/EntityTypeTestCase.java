package net.kemuri9.hibernate;

import java.security.SecureRandom;
import java.util.function.Function;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class EntityTypeTestCase {

	private static EntityManagerFactory factory;
	private static final SecureRandom RANDOM = new SecureRandom();
	
	@BeforeAll
	public static void beforeAll() {
		factory = Persistence.createEntityManagerFactory("TestPersistence"); 
	}
	
	@AfterAll
	public static void afterAll() {
		if (factory != null) {
			factory.close();
		}
	}
	
	public static <T> T withManager(Function<EntityManager, T> process) {
		EntityManager manager = null;
		try {
			manager = factory.createEntityManager();
			return process.apply(manager);
		} finally {
			if (manager != null) {
				manager.close();
			}
		}
	}
	
	@Test
	public void testEntityTypePersist() {
		EntityType saved = withManager((mgr)-> {
			EntityType instance = new EntityType();
			instance.enumVal = EnumType.values()[RANDOM.nextInt(3)];
			mgr.getTransaction().begin();
			mgr.persist(instance);
			mgr.getTransaction().commit();
			return instance;
		});
		EntityType retrieved = withManager((mgr)-> mgr.find(EntityType.class, saved.id));
		Assertions.assertEquals(saved.enumVal, retrieved.enumVal);
		System.out.println(retrieved.enumVal);
	}
}
