package testapp;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import javax.persistence.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author vladimirkl
 * @since <pre>$today</pre>
 */
@Entity
@Audited
public class M2MIndexedListEntity {
    @Id
    @GeneratedValue
    private int id;

    @ManyToMany(cascade = CascadeType.ALL)
    @OrderColumn(name="sortOrder")
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private List<NotAuditedEntity> list = new ArrayList<NotAuditedEntity>();

    public M2MIndexedListEntity() {
    }

    public M2MIndexedListEntity(NotAuditedEntity... entities) {
        this.list.addAll(Arrays.asList(entities));
    }

    public int getId() {
        return id;
    }

    public List<NotAuditedEntity> getList() {
        return list;
    }
}
