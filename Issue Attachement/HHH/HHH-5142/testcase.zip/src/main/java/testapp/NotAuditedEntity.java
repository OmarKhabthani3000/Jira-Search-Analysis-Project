package testapp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;

/**
 * @author vladimirkl
 * @since <pre>$today</pre>
 */
@Entity
public class NotAuditedEntity {
    
    @Id
    @GeneratedValue
    private int id;

    private String name;

    public NotAuditedEntity() {
    }

    public NotAuditedEntity(String name) {
        this.name = name;
    }


    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
