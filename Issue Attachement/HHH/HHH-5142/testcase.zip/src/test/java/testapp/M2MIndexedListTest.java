package testapp;

import org.hibernate.ejb.Ejb3Configuration;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

/**
 * @author vladimirkl
 * @since <pre>$today</pre>
 */
public class M2MIndexedListTest {

    private EntityManager em;
    private static EntityManagerFactory emf;


    @BeforeClass
    public static void init() {
        Ejb3Configuration cfg = new Ejb3Configuration();
        cfg.configure("hibernate.test.cfg.xml");
        cfg.addAnnotatedClass(M2MIndexedListEntity.class);
        cfg.addAnnotatedClass(NotAuditedEntity.class);
        emf = cfg.buildEntityManagerFactory();
    }

    @Before
    public void newEntityManager() {
        em = emf.createEntityManager();
    }

    @After
    public void closeEntityManager() {
        em.close();
    }

    @Test
    public void shouldInitializeCollection() {

        EntityTransaction tx = em.getTransaction();

        tx.begin();

        em.persist(new M2MIndexedListEntity(new NotAuditedEntity("1"), new NotAuditedEntity("2")));

        tx.commit();

        tx.begin();

        AuditReader auditReader = AuditReaderFactory.get(em);
        M2MIndexedListEntity entity = (M2MIndexedListEntity) auditReader.createQuery()
                .forRevisionsOfEntity(M2MIndexedListEntity.class, true, false)
                .getSingleResult();

        assertEquals(1,entity.getList().size());
        tx.commit();
    }
}
