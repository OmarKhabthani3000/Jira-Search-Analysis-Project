/*
 * Klasifikace: CHRÁNĚNÉ
 */
package org.hibernate.test.annotations.filter.fetching;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


@Entity
public class CustomerOrder {
  
  @Id
  @GeneratedValue
  private Long orderId;
  
  private Long total;

  @ManyToOne
  private Customer customer;
  
  public Long getOrderId() {
    return orderId;
  }
  
  public void setOrderId(Long orderId) {
    this.orderId = orderId;
  }

  public Customer getCustomer() {
    return customer;
  }
  
  public void setCustomer(Customer customer) {
    this.customer = customer;
  }
  
  public Long getTotal() {
    return total;
  }
  
  public void setTotal(Long total) {
    this.total = total;
  }
  
}
