/*
 * Klasifikace: CHRÁNĚNÉ
 */
package org.hibernate.test.annotations.filter.fetching;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.ParamDef;

@Entity
@FilterDef(defaultCondition = "customerId >= :id", name = "ID",
        parameters = { @ParamDef(type = "long", name = "id") }
)
@Filter(name = "ID")
public class Customer {

  @Id
  @GeneratedValue
  private Long customerId;

  private String name;

  @OneToMany(mappedBy = "customer", fetch = FetchType.EAGER)
  @Fetch(FetchMode.SUBSELECT)
  private Set<CustomerOrder> orders = new HashSet<CustomerOrder>();
  
  public Long getCustomerId() {
    return customerId;
  }
  
  public void setCustomerId(Long customerId) {
    this.customerId = customerId;
  }
  
  public String getName() {
    return name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  
  public Set<CustomerOrder> getOrders() {
    return orders;
  }
  
  public void setOrders(Set<CustomerOrder> orders) {
    this.orders = orders;
  }
}
