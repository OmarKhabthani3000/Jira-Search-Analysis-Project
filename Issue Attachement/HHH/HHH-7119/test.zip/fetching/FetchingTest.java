/*
 * Klasifikace: CHRÁNĚNÉ
 */
package org.hibernate.test.annotations.filter.fetching;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;

import java.util.List;

import org.hibernate.annotations.FetchMode;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.stat.SessionStatistics;
import org.hibernate.stat.Statistics;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

/**
 * Test filter in conjunction with fetching.
 * 
 * @author Vit Novak
 * @version $Revision$
 */
public class FetchingTest extends BaseCoreFunctionalTestCase {
  
  @Override
  protected Class[] getAnnotatedClasses() {
    return new Class[] { Customer.class, CustomerOrder.class };
  }
  
  @Override
  protected void configure(Configuration configuration) {
    super.configure(configuration);
    configuration.setProperty(AvailableSettings.GENERATE_STATISTICS, "true");
    configuration.setProperty(AvailableSettings.HBM2DDL_IMPORT_FILES,
            "/org/hibernate/test/annotations/filter/fetching/import.sql");
  }

  /**
   * Tests fetching a collection using {@link FetchMode.SUBSELECT} when the parent uses parametrized
   * filter. Query that fetches the collection includes original query for parent(s) and this should
   * also contain the filter condition and the parameters should be set as per original query.
   */
  @Test
  public void testSubselect() {
    openSession();
    
    session.enableFilter("ID").setParameter("id", 3L);
    List result = session.createQuery("from Customer order by id").list();
    
    assertFalse(result.isEmpty());
    Customer customer = (Customer) result.get(0);
    assertSame(customer.getCustomerId(), 3L);
    
    assertSame(customer.getOrders().size(), 2);
    SessionStatistics statistics = session.getStatistics();
    assertSame(statistics.getEntityCount(), 9);
    
    Statistics sfStatistics = session.getSessionFactory().getStatistics();
    
    assertSame(sfStatistics.getCollectionFetchCount(), 1L);
    assertSame(sfStatistics.getQueries().length, 1);
  }
}
