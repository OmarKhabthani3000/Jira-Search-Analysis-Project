insert into customer(customerId, name) values(1, 'Atlasian');
insert into customer(customerId, name) values(2, 'IBM');
insert into customer(customerId, name) values(3, 'Dell');
insert into customer(customerId, name) values(4, 'HP');
insert into customer(customerId, name) values(5, 'VMware');

insert into CustomerOrder(orderId, customer_customerId, total) values(1, 1, 100);
insert into CustomerOrder(orderId, customer_customerId, total) values(2, 1, 200);
insert into CustomerOrder(orderId, customer_customerId, total) values(3, 2, 300);
insert into CustomerOrder(orderId, customer_customerId, total) values(4, 2, 400);
insert into CustomerOrder(orderId, customer_customerId, total) values(5, 3, 500);
insert into CustomerOrder(orderId, customer_customerId, total) values(6, 3, 600);
insert into CustomerOrder(orderId, customer_customerId, total) values(7, 4, 700);
insert into CustomerOrder(orderId, customer_customerId, total) values(8, 4, 800);
insert into CustomerOrder(orderId, customer_customerId, total) values(9, 5, 900);
insert into CustomerOrder(orderId, customer_customerId, total) values(10, 5, 1000);
