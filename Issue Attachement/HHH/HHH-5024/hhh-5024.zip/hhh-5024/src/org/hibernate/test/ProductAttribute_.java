package org.hibernate.test;

import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(ProductAttribute.class)
public abstract class ProductAttribute_ extends AbstractAttribute_
{


}

