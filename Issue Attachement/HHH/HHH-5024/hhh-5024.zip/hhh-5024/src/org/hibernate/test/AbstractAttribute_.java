package org.hibernate.test;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(AbstractAttribute.class)
public abstract class AbstractAttribute_ {

	public static volatile SingularAttribute<AbstractAttribute, Integer> owner;
	public static volatile SingularAttribute<AbstractAttribute, String> value;
    public static volatile SingularAttribute<AbstractAttribute, String> key;
    // Ne fonctionne pas bug hibernate : HHH-5024
    // public static volatile String key = "key";

}

