package org.hibernate.test;

import static org.junit.Assert.assertNotNull;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.Test;

public class UnitTest {
	private static EntityManager em;
	private static EntityManagerFactory factory;
	
	@Test
	public void testHhh5832( ) {
		
		try {
            assertNotNull( "This static attribute should be not null (or should not be null)", ProductAttribute_.key );
		} catch( Exception e ) {
			e.printStackTrace( );
		}
		
	}
	
	static {
		factory = Persistence.createEntityManagerFactory( "test" );
		em = factory.createEntityManager( );
	}
}
