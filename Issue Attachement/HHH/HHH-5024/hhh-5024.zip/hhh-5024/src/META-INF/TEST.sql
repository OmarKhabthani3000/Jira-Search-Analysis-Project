--  Test case for MySQL
create database TEST;
use TEST;

CREATE TABLE product_attribute (
attribute_key VARCHAR( 255 ) NOT NULL ,
owner VARCHAR( 255 ) NOT NULL ,
attribute_value VARCHAR( 255 ) NOT NULL
);
 commit;