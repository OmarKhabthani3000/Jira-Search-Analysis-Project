package org.foo.test.jpa2.hibernate;

import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import junit.framework.Assert;

import org.foo.test.jpa2.hibernate.customer.Customer;
import org.foo.test.jpa2.hibernate.customer.CustomerId;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class CustomerTest {
	
	private static EntityManagerFactory emf;
	private EntityManager em;
	
	@Test
	public void testCreateCustomer() {
		CustomerId id = new CustomerId(UUID.randomUUID().toString());
		Customer newCustomer = new Customer(id);
		
		em.getTransaction().begin();
		em.persist(newCustomer);
		em.getTransaction().commit();
		
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Customer> customerQuery = cb.createQuery(Customer.class);
		Root<Customer> customerRoot = customerQuery.from(Customer.class);
		
		Customer fetchedCustomer = em.createQuery(customerQuery.where(cb.equal(customerRoot.get("customerId"), id)))
			.getSingleResult();
		
		Assert.assertEquals(newCustomer, fetchedCustomer);		
	}
	
	
	@Before
	public void before() {
		em = emf.createEntityManager();
	}
	
	@After
	public void after() {
		if (em != null) {
			em.close();
			em = null;
		}
	}
	
	@BeforeClass
	public static void beforeClass() {
		emf = Persistence.createEntityManagerFactory("jpa2Pu");
	}
	
	@AfterClass
	public static void afterClass() {
		if (emf != null) {
			emf.close();
			emf = null;
		}
	}
}
