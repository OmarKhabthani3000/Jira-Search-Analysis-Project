/**
 * 
 */
package org.foo.test.jpa2.hibernate.common;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.MappedSuperclass;

import org.apache.commons.lang.Validate;

/**
 * <code>AbstractIdentity</code> provided an abstract implementation of an
 * entity (business) identifier.
 * 
 * @author had
 * @param <T> The type of the identity.
 */
@MappedSuperclass
@Access(AccessType.FIELD)
public abstract class AbstractIdentity<T extends Identity<T>> implements Identity<T> {
    
    private String id;

    /**
     * Constructs the <code>AbstractIdentity</code>.
     * @param id The string representation of the id, must not be null.
     * @throws IllegalArgumentException If <code>id</code> is null.
     */
    protected AbstractIdentity(final String id) {
        Validate.notNull(id);        
        this.id = id;
    }
    
    /**
     * <strong>Note:</strong> This constructor only exists to fulfill the JPA 
     * specification. Use {@link #AbstractIdentity(String)} constructor in order to
     * manually create an identity instance.
     */
    protected AbstractIdentity() {
        // Needed by JPA
    }

    /**
     * @see Identity#getId()
     */
    @Override
    public String getId() {
        return id;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        return id.hashCode();
    }
    
    /**
     * @see DDDValueObject#sameValueAs(java.lang.Object)
     */
    @Override
    public boolean sameValueAs(T other) {
        return other != null && this.getId().equals(other.getId());
    }
    
    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return id;
    }   
}
