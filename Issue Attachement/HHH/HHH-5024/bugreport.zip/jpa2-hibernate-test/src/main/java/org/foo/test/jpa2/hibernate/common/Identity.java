/**
 * 
 */
package org.foo.test.jpa2.hibernate.common;

/**
 * <code>Identity</code> defines the interface for an entity identity.
 *
 * @author  had
 * @param <T> The type of the identity.
 */
public interface Identity<T> extends DDDValueObject<T> {
    
    /**
     * Returns the string representation of this identity.
     * @return String representation of this identity, never null.
     */
    String getId();
}
