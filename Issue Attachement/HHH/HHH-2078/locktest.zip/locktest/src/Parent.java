import java.util.List;

public class Parent
{

  private Long id;
  private List<Child> children;

  public void setId( Long id ) { this.id = id; }
  public Long getId() { return this.id; }
  public void setChildren( List<Child> children ) { this.children = children; }
  public List<Child> getChildren() { return this.children; }
  
}
