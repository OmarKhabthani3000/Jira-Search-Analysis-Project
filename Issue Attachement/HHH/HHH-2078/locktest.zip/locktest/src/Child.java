public class Child
{

  private Long id;
  private Parent parent;
  private Integer sequence;

  public void setId( Long id ) { this.id = id; }
  public Long getId() { return this.id; }
  public void setParent( Parent parent ) { this.parent = parent; }
  public Parent getParent() { return this.parent; }
  public void setSequence( Integer sequence ) { this.sequence = sequence; }
  public Integer getSequence() { return this.sequence; }

}
