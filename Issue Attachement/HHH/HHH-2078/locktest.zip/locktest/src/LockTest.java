import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class LockTest
{

  public static void main( String[] args )
  {

    Log log = LogFactory.getLog( LockTest.class.getName() );
    SessionFactory sf = new Configuration().configure().buildSessionFactory();
    Session session = sf.openSession();
    try
    {
      ScrollableResults rs = session.createCriteria( Parent.class )
          .setLockMode( LockMode.UPGRADE )
          .scroll();
      while ( rs.next() )
      {
        Parent parent = (Parent)rs.get()[0];
        log.info( "Parent: " + parent.getId() );
        for ( Child child : parent.getChildren() )
        {
          log.info( "Child #" + child.getSequence() + ": " + child.getId() );
        }
      }
    }
    finally
    {
      session.close();
    }

  }

}
