package hello;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.Type;

@org.hibernate.annotations.TypeDefs({
        @org.hibernate.annotations.TypeDef(name = "jsonb", typeClass = TestUserType.class, defaultForType = java.util.List.class)
})
@Entity
public class Customer implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    private String name;

    @Type(type = "jsonb")
    private List<String> attr;

    protected Customer() {
    }

    public Customer(String name, List<String> attr) {
        this.name = name;
        this.attr = attr;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getAttr() {
        return attr;
    }

    public void setAttr(List<String> attr) {
        this.attr = attr;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", attr=" + attr +
                '}';
    }
}

