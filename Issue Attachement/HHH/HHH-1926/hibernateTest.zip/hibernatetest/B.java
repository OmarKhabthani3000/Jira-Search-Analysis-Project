/*
 * B.java
 * 
 * Created on Jul 20, 2006
 * 
 * This code is copyright (c) 2005 CareScience - A Quovadx Division
 * All Rights Reserved
 * 
 */

package hibernatetest;

import java.util.List;

// import statements

public class B
{
    private BPK compId;
    private String otherColumnB;
    
    // read-only columns needed so we can link to A
    private String column2;
    private int  column3;
    
    // many-to-many with A, should contain all A's that share column2 and 3 with this B
    private List relatedAs;
    
    public BPK getCompId()
    {
        return compId;
    }
    public void setCompId(BPK compId)
    {
        this.compId = compId;
    }
    public String getOtherColumnB()
    {
        return otherColumnB;
    }
    public void setOtherColumnB(String otherColumnB)
    {
        this.otherColumnB = otherColumnB;
    }
    public List getRelatedAs()
    {
        return relatedAs;
    }
    public void setRelatedAs(List relatedAs)
    {
        this.relatedAs = relatedAs;
    }
    public String getColumn2()
    {
        return column2;
    }
    public void setColumn2(String column2)
    {
        this.column2 = column2;
    }
    public int getColumn3()
    {
        return column3;
    }
    public void setColumn3(int column3)
    {
        this.column3 = column3;
    } 
}
