package hibernatetest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import junit.framework.TestCase;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Unit test for the conversion data layer pieces of the DM UI I go out of my
 * way to consolidate unit tests here (not typically a good practice) because
 * these are DB tests that have a 2-3 second startup time, so for speed, I
 * combine them wherever possible
 * 
 * @version
 * @author dhannum
 */
public class HibernateManyToManyPartialKeyTest extends TestCase
{
    private Connection conn;
    SessionFactory sessions;

    public void setUp() throws Exception
    {
        Class.forName("org.hsqldb.jdbcDriver" );
        conn = DriverManager.getConnection("jdbc:hsqldb:mem:dmTest", "sa", "");
        
        Statement s = conn.createStatement();
        s.execute("Create table A ( C1 VARCHAR(20) NOT NULL, C2 VARCHAR(20) NOT NULL, C3 INTEGER NOT NULL, OTHER_COLUMN_A VARCHAR(20) );");
        s.execute("ALTER TABLE A ADD CONSTRAINT A_PK PRIMARY KEY ( C1, C2, C3 );");
        s.execute("Create table B ( C2 VARCHAR(20) NOT NULL, C3 INTEGER NOT NULL, C4 VARCHAR(20) NOT NULL, C5 VARCHAR(20) NOT NULL, OTHER_COLUMN_B VARCHAR(20) );");
        s.execute("ALTER TABLE B ADD CONSTRAINT B_PK PRIMARY KEY ( C2, C3, C4, C5 );");
        
        Configuration config = new Configuration().
        setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect").
        setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver").
        setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:dmTest").
        setProperty("hibernate.connection.username", "sa").
        setProperty("hibernate.connection.password", "").
        setProperty("hibernate.connection.pool_size", "1").
        setProperty("hibernate.connection.autocommit", "true").
        setProperty("hibernate.cache.provider_class", "org.hibernate.cache.HashtableCacheProvider").
        setProperty("hibernate.show_sql", "true").
        addClass(A.class).
        addClass(B.class);
        
        sessions = config.buildSessionFactory();
    }

    public void tearDown() throws Exception
    {
        Statement st = conn.createStatement();
        st.execute("SHUTDOWN");
        conn.close();    // if there are no other open connection
    }
    
    public void testAnything() throws Exception
    {
        // we won't even get here. Test will fail in setUp
    }
}