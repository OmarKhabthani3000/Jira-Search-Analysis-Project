/*
 * APK.java
 * 
 * Created on Jul 20, 2006
 * 
 * This code is copyright (c) 2005 CareScience - A Quovadx Division
 * All Rights Reserved
 * 
 */

package hibernatetest;

import java.io.Serializable;

// import statements

/**
 * PK for A
 */
public class APK implements Serializable
{
    private String column1;
    private String column2;
    private int column3;
    
    public String getColumn1()
    {
        return column1;
    }
    public void setColumn1(String column1)
    {
        this.column1 = column1;
    }
    public String getColumn2()
    {
        return column2;
    }
    public void setColumn2(String column2)
    {
        this.column2 = column2;
    }
    public int getColumn3()
    {
        return column3;
    }
    public void setColumn3(int column3)
    {
        this.column3 = column3;
    }
}
