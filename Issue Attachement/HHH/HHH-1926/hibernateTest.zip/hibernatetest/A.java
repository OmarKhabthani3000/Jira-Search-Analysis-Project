/*
 * A.java
 * 
 * Created on Jul 20, 2006
 * 
 * This code is copyright (c) 2005 CareScience - A Quovadx Division
 * All Rights Reserved
 * 
 */

package hibernatetest;

import java.util.List;

// import statements

public class A
{
    // First 3 are PK, column 2 and column 3 are also present in B
    private APK compId;
    private String otherColumnA;
    
    // many-to-many with B, should contain all B's that share column2 and 3 with this A
    private List relatedBs;
    
    // read-only columns needed so we can link to B
    private String column2;
    private int  column3;
    
    public APK getCompId()
    {
        return compId;
    }
    public void setCompId(APK compId)
    {
        this.compId = compId;
    }
    public String getOtherColumnA()
    {
        return otherColumnA;
    }
    public void setOtherColumnA(String otherColumnA)
    {
        this.otherColumnA = otherColumnA;
    }
    public List getRelatedBs()
    {
        return relatedBs;
    }
    public void setRelatedBs(List relatedBs)
    {
        this.relatedBs = relatedBs;
    }
    public String getColumn2()
    {
        return column2;
    }
    public void setColumn2(String column2)
    {
        this.column2 = column2;
    }
    public int getColumn3()
    {
        return column3;
    }
    public void setColumn3(int column3)
    {
        this.column3 = column3;
    }
}