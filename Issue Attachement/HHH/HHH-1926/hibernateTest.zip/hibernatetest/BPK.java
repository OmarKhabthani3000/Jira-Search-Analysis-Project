/*
 * BPK.java
 * 
 * Created on Jul 20, 2006
 * 
 * This code is copyright (c) 2005 CareScience - A Quovadx Division
 * All Rights Reserved
 * 
 */

package hibernatetest;

import java.io.Serializable;

// import statements

/**
 * PK for B
 */
public class BPK implements Serializable
{
    private String column2;
    private int column3;
    private String column4;
    private String column5;
    
    public String getColumn2()
    {
        return column2;
    }
    public void setColumn2(String column2)
    {
        this.column2 = column2;
    }
    public int getColumn3()
    {
        return column3;
    }
    public void setColumn3(int column3)
    {
        this.column3 = column3;
    }
    public String getColumn4()
    {
        return column4;
    }
    public void setColumn4(String column4)
    {
        this.column4 = column4;
    }
    public String getColumn5()
    {
        return column5;
    }
    public void setColumn5(String column5)
    {
        this.column5 = column5;
    }
}
