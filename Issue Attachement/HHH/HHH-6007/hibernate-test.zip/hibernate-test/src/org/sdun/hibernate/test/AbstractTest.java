package org.sdun.hibernate.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;


/**
 * 
 */
public abstract class AbstractTest {
	
	/**
	 * our entity manager
	 */
	protected final EntityManager em;
	
	/**
	 * constructor
	 */
	public AbstractTest() {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("test"); 
		assert emf != null; 
		
		this.em = emf.createEntityManager();
		assert em != null;
		
		//
		// we want to query new entities inside 
		// a transaction without an _explicit_ 
		// flush or commit! 
		//
		// AUTO   flush mode serves this behaviour
		// COMMIT flushes only at a commit or explicit flush
		//
		
		em.setFlushMode(FlushModeType.AUTO);
	}

	
	
	
} // class

