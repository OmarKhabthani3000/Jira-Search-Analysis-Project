package org.sdun.hibernate.test.util;



/**
 * 
 */
public class Tuple<F,S> {

	public F first;
	public S second;
	
	public Tuple(F first,S second) {
		this.first = first;
		this.second = second;
	}

	public F getFirst() {
		return first;
	}

	public S getSecond() {
		return second;
	}
	
	@Override
	public final String toString() {
		final StringBuilder b = new StringBuilder();

		b.append("(");

		if( first != null ) {
			b.append(first.toString());
		}
		
		if( first != null && second != null ) {
			b.append(", ");
		}
		
		if( second != null ) {
			b.append(second.toString());
		}
		
		b.append(")");

		return b.toString();
	}
	
}

