package org.sdun.hibernate.test.util;



/**
 * 
 */
public final class Pointer<T> {

	public T pr = null;

	public Pointer() {
		this.pr = null;
	}

	public Pointer(T obj) {
		this.pr = obj;
	}

	public final T get() {
		return pr;
	}

	public final T set(T obj) {
		this.pr = obj;
		return obj;
	}

} // class



