package org.sdun.hibernate.test.tree;

import org.sdun.hibernate.test.AbstractTest;
import org.sdun.hibernate.test.util.Pointer;
import org.sdun.hibernate.test.util.Tuple;

/**
 * 
 */
public final class TreeTest 
extends AbstractTest {

	/**
	 * the root node of the tree
	 */
	private TreeNode root;

	/**
	 * build an initial tree
	 */
	private void build() {

		// the root

		em.getTransaction().begin();

		root = new TreeNode().setName("0");
		em.persist(root);
		
		em.getTransaction().commit();
		
		// 1 & 2 

		em.getTransaction().begin();

		TreeNode e1 = new TreeNode().setName("1");
		TreeNode e2 = new TreeNode().setName("2");
		TreeNode e3 = new TreeNode().setName("3");
	
		root.getChildren().add(e1);
		root.getChildren().add(e2);
		root.getChildren().add(e3);
		
		em.getTransaction().commit();
		
		// 1.x

		em.getTransaction().begin();

		TreeNode ea = new TreeNode().setName("1.1");
		TreeNode eb = new TreeNode().setName("1.2");
	
		e1.getChildren().add(ea);
		e1.getChildren().add(eb);
		
		em.getTransaction().commit();

		// 2.x

		em.getTransaction().begin();

		ea = new TreeNode().setName("2.1");
		eb = new TreeNode().setName("2.2");
	
		e2.getChildren().add(ea);
		e2.getChildren().add(eb);

		em.getTransaction().commit();
		
		//3.x

		em.getTransaction().begin();

		ea = new TreeNode().setName("3.1");
		eb = new TreeNode().setName("3.2");
	
		e3.getChildren().add(ea);
		e3.getChildren().add(eb);

		em.getTransaction().commit();
		
	}

	/**
	 * move a node to another 
	 * parent node (by name)
	 */
	private final void move(String name, String target) {

		em.getTransaction().begin();

		// find node, node parent and target
		
		Tuple<TreeNode,TreeNode> n = find(name);
		assert n != null : name;

		Tuple<TreeNode,TreeNode> t = find(target);
		assert t != null : target;
		
		// remove node from its current parent
		
		n.getFirst().getChildren().remove(n.getSecond());
		
		// add to target
		
		t.getSecond().getChildren().add(n.getSecond());
		
		// done

		em.getTransaction().commit();
	}

	
	/**
	 * run this test
	 */
	public static final void main( String...args ) {
		
		TreeTest t = new TreeTest();
		
		t.build();
		t.print();

		t.move("2","3");
		t.print();

		t.move("2","0"); // constraint violation!
		t.print();
	}


	/**
	 * find a node
	 * 
	 * @return a tuple with the found node as second 
	 * element and the parent node of the found node 
	 * as the first element or null if not found
	 */
	private final Tuple<TreeNode,TreeNode> find(String name) {

		assert name != null;
		assert name.length() > 0;

		// System.out.println("find! '"+name+"'");
		
		Pointer<TreeNode> p = new Pointer<TreeNode>(root); // parent
		TreeNode n = find(root,name,p);
		
		if( n == null ) {
			return null;
		}
		
		assert p.get() != null : n.getName();
		
		return new Tuple<TreeNode,TreeNode>(p.get(),n);
	}

	/**
	 * find a node
	 */
	private final TreeNode find(TreeNode n, 
			String name, Pointer<TreeNode> p ) {
	
		if( n == null ) {
			return null;
		}
		
		if( n.getName().equals(name) ) {
			return n;
		}

		// System.out.println("find? '"+n.getName()+"' != '"+name+"'");
		
		for( TreeNode f : n.getChildren() ) {
			
			p.set(n);
			TreeNode x = find(f,name,p);
			
			if( x != null ) {
				return x;
			}
		}
		
		return null;
	}
		
	
	/**
	 * print the tree 
	 */
	private final void print() {
		System.out.println("the tree: ");
		print(root,0);
	}

	/**
	 * print the tree 
	 */
	private final void print(TreeNode n, int d) {

		if( n == null ) {
			return;
		}
		
		for( int i = 0; i < d; i++  ) {
			System.out.print(" ");
		}
		
		System.out.println(n.getName());
		
		for( TreeNode p : n.getChildren() ) {
			print(p,d+1);
		}
	}

	
} // class

