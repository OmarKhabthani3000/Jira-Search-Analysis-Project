package org.sdun.hibernate.test.tree;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * 
 * 
 */
@Entity(name="TreeNode")
@Table(name="tn")
public final class TreeNode {

	/**
	 * primary key
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE)
	private long id;

	/**
	 * just a string
	 */
	@Basic
	private String name;

	/**
	 * the entries
	 */
	@OneToMany(cascade=CascadeType.ALL)		
	private List<TreeNode> entries = new ArrayList<TreeNode>();
	 
	/**
	 * constructor
	 */
	public TreeNode() {
	}

	/**
	 * returns the id
	 */
	public final long getId() {
		return id;
	}

	/**
	 * returns the name
	 */
	public final String getName() {
		return name;
	}
	
	/**
	 * set the name
	 */
	public final TreeNode setName(String n) {

		assert n != null;
		assert n.length() > 0;
		
		this.name = n;
		
		return this;
	}

	/**
	 * get the children
	 */
	public final List<TreeNode> getChildren() {
		return entries;
	}

	/**
	 * java
	 */
	@Override
	public final boolean equals( Object obj ) {
		
		if( obj == null ) {
			return false;
		}
		
		if( obj.getClass() != TreeNode.class ) {
			return false;
		}
		
		if( this.id == ((TreeNode)obj).getId() ) {
			return true;
		}
		
		return false;
	}

	

} // class




