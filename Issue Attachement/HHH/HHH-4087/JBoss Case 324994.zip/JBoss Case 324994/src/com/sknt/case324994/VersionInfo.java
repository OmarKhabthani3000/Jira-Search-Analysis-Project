package com.sknt.case324994;

import java.util.ArrayList;
import java.util.List;

public class VersionInfo {
	private long versionNumber;
	private List<Status> statusList = new ArrayList<Status>();
	private Long sequenceNumber;
	
	public long getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(long versionNumber) {
		this.versionNumber = versionNumber;
	}

	public List<Status> getStatusList() {
		return statusList;
	}

	public void setStatusList(List<Status> statusList) {
		this.statusList = statusList;
	}

	public Long getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Long sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	
	public int hashCode() {
		return sequenceNumber.intValue();
	}
	
	public boolean equals(Object obj) {
		VersionInfo that = (VersionInfo) obj;
		
		return this.versionNumber == that.versionNumber;
	}
}
