package com.sknt.case324994;

public class Portfolio {
	private long pk;
	private String name;
	private VersionInfo versionInfo;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public VersionInfo getVersionInfo() {
		return versionInfo;
	}
	
	public void setVersionInfo(VersionInfo versionInfo) {
		this.versionInfo = versionInfo;
	}

	public int hashCode() {
		return name == null ? 0 : name.hashCode();
	}
	
	public boolean equals(Object obj) {
		Portfolio that = (Portfolio) obj;

		return this.name.equals(that.name) 
			
		&& this.versionInfo.getVersionNumber() == that.versionInfo.getVersionNumber();
	}
}
