package com.sknt.case324994;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Case324994Test extends TestCase {
	private SessionFactory factory; 
	private Transaction transaction;
	private Session session;
	
	protected void setUp() throws Exception {
		super.setUp();
		factory = new Configuration().configure().buildSessionFactory();
		session = factory.openSession();
		transaction = session.beginTransaction();

	}

	protected void tearDown() throws Exception {
		super.tearDown();
		
		transaction.commit();
		session.close();
		factory.close();
	}
	
	public void testCase324994() throws Exception {
		Portfolio p = new Portfolio();
		p.setName("foo portfolio");
		VersionInfo vinfo = new VersionInfo();
		p.setVersionInfo(vinfo);
		Status s = new Status();
		s.setComment("bar");
		vinfo.getStatusList().add(s);
		
		session.save(p);
		session.flush();
		session.refresh(p);
	}
}
