package org.hibernate.test.joinedmapfilter;

public class Toplevel {
    private long toplevelId;

    private long longValueOne;
    private ProductDetail productDetail;
    private String description;
	
    public long getToplevelId() {
        return toplevelId;
    }
    public void setToplevelId(long id) {
        this.toplevelId = id;
    }
	
    public long getLongValueOne() {
        return longValueOne;
    }
    public void setLongValueOne(long longValueOne) {
        this.longValueOne = longValueOne;
    }

    public ProductDetail getProductDetail() {
    	return productDetail;
    }
    public void setProductDetail(ProductDetail productDetail) {
	this.productDetail = productDetail;
    }
    
    public String getDescription() {
      return description;
    }
    public void setDescription(String description) {
      this.description = description;
    }
}
