CREATE TABLE toplevel (
	toplevel_id BIGINT NOT NULL AUTO_INCREMENT,
	long_value_one BIGINT NOT NULL,
	product_detail_id BIGINT NOT NULL,
	description VARCHAR(64) NULL,

	PRIMARY KEY(toplevel_id)
);

CREATE TABLE product_detail (
	product_detail_id BIGINT NOT NULL AUTO_INCREMENT,
	long_value_again_one  BIGINT NOT NULL,

	PRIMARY KEY(product_detail_id)
);

CREATE TABLE product_detail_attrs (
	unique_id  BIGINT NOT NULL AUTO_INCREMENT,
	product_detail_id BIGINT NOT NULL,
	name VARCHAR(32),
	value VARCHAR(255),

	PRIMARY KEY(unique_id),
	KEY(product_detail_id, unique_id)
);
