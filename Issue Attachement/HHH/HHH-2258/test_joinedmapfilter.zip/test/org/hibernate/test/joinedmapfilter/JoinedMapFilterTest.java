//$Id$
package org.hibernate.test.joinedmapfilter;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.TestCase;

/**
 * @author Darryl Miles
 */
public class JoinedMapFilterTest extends TestCase {
	
	public JoinedMapFilterTest(String str) {
		super(str);
	}
	
	public void testJoinedMapFilter() {
		Session s = openSession();
		Transaction t = s.beginTransaction();

		Map attributes = new HashMap();
		attributes.put("nameOne", "valueOne");
		attributes.put("nameTwo", "valueTwo");
		attributes.put("nameThree", "valueThree");

		ProductDetail productDetail = new ProductDetail();
		productDetail.setLongValueAgainOne(987);
		productDetail.setAttributes(attributes);

		Toplevel toplevel = new Toplevel();
		toplevel.setLongValueOne(123);
		toplevel.setProductDetail(productDetail);
		
		s.save(productDetail);
		s.save(toplevel);
		long toplevelId = toplevel.getToplevelId();	// save the id to use again below
		t.commit();
		
		t = s.beginTransaction();

		assertEquals( s.createQuery("from ProductDetail").list().size(), 1 );
		assertEquals( s.createQuery("from Toplevel").list().size(), 1 );

		toplevel = (Toplevel) s.get(Toplevel.class, new Long(toplevelId));
		assertNotNull( toplevel );

		// Method 1, this has always worked ok.
		String nameOne = (String) toplevel.getProductDetail().getAttributes().get("nameOne");
		assertNotNull( nameOne );
		assertEquals( nameOne, "valueOne" );

		t.commit();
		
		t = s.beginTransaction();

		// Method 2, this is the problem
		// This is the statement which is not including the correct join table
		//  "no FROM clause for "product_detail productdet1_" which links the Java object graph"


// Well hello there; this causes an NPE with 3.1.3, due to the typo of "rec" should be "r"
//
// Testcase: testJoinedMapFilter took 0.513 sec
//         Caused an ERROR
// null
// java.lang.NullPointerException
//      at org.hibernate.hql.ast.tree.DotNode.dereferenceCollection(DotNode.java:229)
//         at org.hibernate.hql.ast.tree.DotNode.resolveIndex(DotNode.java:163)
//         at org.hibernate.hql.ast.tree.IndexNode.resolve(IndexNode.java:63)
//         at org.hibernate.hql.ast.tree.FromReferenceNode.resolve(FromReferenceNode.java:94)
//         at org.hibernate.hql.ast.tree.FromReferenceNode.resolve(FromReferenceNode.java:90)
//         at org.hibernate.hql.ast.HqlSqlWalker.processIndex(HqlSqlWalker.java:837)
//         at org.hibernate.hql.antlr.HqlSqlBaseWalker.addrExpr(HqlSqlBaseWalker.java:4359)
//         at org.hibernate.hql.antlr.HqlSqlBaseWalker.expr(HqlSqlBaseWalker.java:1212)
//         at org.hibernate.hql.antlr.HqlSqlBaseWalker.exprOrSubquery(HqlSqlBaseWalker.java:4041)
//         at org.hibernate.hql.antlr.HqlSqlBaseWalker.comparisonExpr(HqlSqlBaseWalker.java:3525)
//         at org.hibernate.hql.antlr.HqlSqlBaseWalker.logicalExpr(HqlSqlBaseWalker.java:1762)
//         at org.hibernate.hql.antlr.HqlSqlBaseWalker.logicalExpr(HqlSqlBaseWalker.java:1690)
//         at org.hibernate.hql.antlr.HqlSqlBaseWalker.whereClause(HqlSqlBaseWalker.java:776)
//         at org.hibernate.hql.antlr.HqlSqlBaseWalker.query(HqlSqlBaseWalker.java:577)
//         at org.hibernate.hql.antlr.HqlSqlBaseWalker.selectStatement(HqlSqlBaseWalker.java:281)
//         at org.hibernate.hql.antlr.HqlSqlBaseWalker.statement(HqlSqlBaseWalker.java:229)
//         at org.hibernate.hql.ast.QueryTranslatorImpl.analyze(QueryTranslatorImpl.java:228)
//         at org.hibernate.hql.ast.QueryTranslatorImpl.doCompile(QueryTranslatorImpl.java:160)
//         at org.hibernate.hql.ast.QueryTranslatorImpl.compile(QueryTranslatorImpl.java:111)
//         at org.hibernate.engine.query.HQLQueryPlan.<init>(HQLQueryPlan.java:77)
//         at org.hibernate.engine.query.HQLQueryPlan.<init>(HQLQueryPlan.java:56)
//         at org.hibernate.engine.query.QueryPlanCache.getHQLQueryPlan(QueryPlanCache.java:72)
//         at org.hibernate.impl.AbstractSessionImpl.getHQLQueryPlan(AbstractSessionImpl.java:133)
//         at org.hibernate.impl.AbstractSessionImpl.createQuery(AbstractSessionImpl.java:112)
//         at org.hibernate.impl.SessionImpl.createQuery(SessionImpl.java:1623)
//         at org.hibernate.test.joinedmapfilter.JoinedMapFilterTest.testJoinedMapFilter(JoinedMapFilterTest.java:69)
//         at org.hibernate.test.TestCase.runTest(TestCase.java:250)
//         at org.hibernate.test.TestCase.runBare(TestCase.java:316)
//
//Query q = s.createQuery("SELECT r FROM " + Toplevel.class.getName() + " AS r WHERE r.toplevelId=? AND rec.productDetail.attributes[?]=?");
//
//
//


		Query q = s.createQuery("SELECT r FROM " + Toplevel.class.getName() + " AS r WHERE r.toplevelId=? AND r.productDetail.attributes[?]=?");
		q.setLong(0, toplevelId);
		q.setParameter(1, "nameOne");
		q.setParameter(2, "valueOne");
		assertEquals( q.list().size(), 1 );

		// Cleanup
		s.delete(toplevel);
		s.delete(toplevel.getProductDetail());

		t.commit();
		s.close();
	}

	protected String[] getMappings() {
		return new String[] { "joinedmapfilter/class.hbm.xml" };
	}

	public static Test suite() {
		return new TestSuite(JoinedMapFilterTest.class);
	}

}

