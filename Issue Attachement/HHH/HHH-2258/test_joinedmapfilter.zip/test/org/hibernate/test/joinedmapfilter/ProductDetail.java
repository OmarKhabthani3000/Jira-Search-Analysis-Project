package org.hibernate.test.joinedmapfilter;

import java.util.Map;

public class ProductDetail {
    private long productDetailId;

    private long longValueAgainOne;
    private Map attributes;
	
    public long getProductDetailId() {
        return productDetailId;
    }
    public void setProductDetailId(long id) {
        this.productDetailId = id;
    }
	
    public long getLongValueAgainOne() {
        return longValueAgainOne;
    }
    public void setLongValueAgainOne(long longValueAgainOne) {
        this.longValueAgainOne = longValueAgainOne;
    }

    public Map getAttributes() {
    	return attributes;
    }
    public void setAttributes(Map attributes) {
	this.attributes = attributes;
    }
}
