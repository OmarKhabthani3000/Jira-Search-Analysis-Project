package org.hibernate.bugs;

import org.hibernate.dialect.H2Dialect;
import org.hibernate.hql.spi.id.MultiTableBulkIdStrategy;
import org.hibernate.hql.spi.id.persistent.PersistentTableBulkIdStrategy;

public class PersistentTableBulkIdH2Dialect extends H2Dialect {

  @Override
  public MultiTableBulkIdStrategy getDefaultMultiTableBulkIdStrategy() {
    return new PersistentTableBulkIdStrategy();
  }

}
