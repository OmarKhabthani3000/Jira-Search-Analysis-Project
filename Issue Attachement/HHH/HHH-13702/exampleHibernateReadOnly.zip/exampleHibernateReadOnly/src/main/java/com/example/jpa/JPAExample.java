package com.example.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.ArrayList;
import java.util.Collection;

public class JPAExample {
    private static final String PERSISTENCE_UNIT_NAME = "test";
    private static EntityManagerFactory factory;

    private static EntityManagerFactory getEntityManagerFactory() {
        if (factory == null) {
            factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        }
        return factory;
    }

    private static void shutdown() {
        if (factory != null) {
            factory.close();
        }
    }

    public static void main (String[] args) {
        EntityManager entityManager = getEntityManagerFactory().createEntityManager();
        entityManager.getTransaction().begin();

        EventStackFrame eventStackFrame = new EventStackFrame(1L, "EventStackFrame", 1L);

        Collection<EventStackFrame> eventStackFrames = new ArrayList<EventStackFrame>();
        eventStackFrames.add(eventStackFrame);
        Event event = new Event(1L, "Event", eventStackFrames);

        entityManager.persist(event);

        entityManager.getTransaction().commit();


        entityManager.getTransaction().begin();

        Event loadedEvent = entityManager.find(Event.class, 1L);
        System.out.println("Loaded event = " + loadedEvent);

        entityManager.getTransaction().commit();

        entityManager.close();

        shutdown();
    }
}