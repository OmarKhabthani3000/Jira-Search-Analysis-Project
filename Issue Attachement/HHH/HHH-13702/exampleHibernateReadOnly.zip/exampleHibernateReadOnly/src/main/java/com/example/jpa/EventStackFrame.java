package com.example.jpa;

import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "Child")
@Immutable
@Table(name = "EventStackFrames")
public class EventStackFrame {
    @Id
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "eventId")
    private Long eventId;

    public EventStackFrame(
            Long id,
            String name,
            Long eventId) {
        this.id = id;
        this.name = name;
        this.eventId = eventId;
    }

    //Needed when instantiating the entity from a JDBC ResultSet
    private EventStackFrame() {
    }

    @Override
    public String toString() {
        return "EventStackFrame{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", eventId=" + eventId +
                '}';
    }

//Getters omitted for brevity
}
