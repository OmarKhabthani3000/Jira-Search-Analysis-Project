package com.example.jpa;

import org.hibernate.annotations.Immutable;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;

@Entity(name = "Event")
@Immutable
@Table(name = "events")
public class Event {

    @Id
    private Long id;

    @Column(name = "name")
    private String name;

    @OneToMany(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "eventId")
    @Immutable
    private Collection<EventStackFrame> eventStackFrames = new ArrayList<EventStackFrame>();

    public Event(
            Long id,
            String name,
            Collection<EventStackFrame> eventStackFrames) {
        this.id = id;
        this.name = name;
        this.eventStackFrames = eventStackFrames;
    }

    //Needed when instantiating the entity from a JDBC ResultSet
    private Event() {
    }

    //Getters omitted for brevity

    @Override
    public String toString() {
        return "Event{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", eventStackFrames=" + eventStackFrames +
                '}';
    }
}
