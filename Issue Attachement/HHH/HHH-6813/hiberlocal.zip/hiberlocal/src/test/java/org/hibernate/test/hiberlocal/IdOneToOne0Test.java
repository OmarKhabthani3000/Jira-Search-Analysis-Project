package org.hibernate.test.hiberlocal;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class IdOneToOne0Test {
    private EntityManager em;

    private static EntityManagerFactory emf;

    @BeforeClass
    public static void init() {
        emf = Persistence.createEntityManagerFactory( "hibertestPU" );
    }

    @Before
    public void newEntityManager() {
        em = emf.createEntityManager();

        EntityTransaction tx = em.getTransaction();
        tx.begin();

        Person p = new Person();
        p.setName( "Alfio" );
        PersonInfo pi = new PersonInfo();
        pi.setId( p );
        pi.setInfo( "Some information" );
        em.persist( p );
        em.persist( pi );
        tx.commit();
    }

    @Test
    public void select() {
        Query q = em.createNamedQuery( "PersonQuery" );
        List<Person> people = q.getResultList();
    }
    
    //@Test
    public void find() {
        Person p = em.find( Person.class, 1);
    }
}
