package org.hibernate.test.hiberjta;

import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
@DataSourceDefinition( name = "java:app/jdbc/hiberjta",
                       className = "org.h2.jdbcx.JdbcDataSource",
                       url = "jdbc:h2:mem:hibertest",
                       user = "user",
                       password = "" )
public class PersonEJB {
    @PersistenceContext( name = "hibertestPU" )
    private EntityManager em;
    
    public void update() {
        Person p = new Person();
        p.setName( "Alfio" );
        PersonInfo pi = new PersonInfo();
        pi.setId( p );
        pi.setInfo( "Some information" );
        em.persist( p );
        em.persist( pi );
    }
    
    public void find() {
        Person p = em.find( Person.class, 1 );
    }
    
    public void select() {
        Query q = em.createNamedQuery( "PersonQuery" );
        q.getResultList();
    }
}
