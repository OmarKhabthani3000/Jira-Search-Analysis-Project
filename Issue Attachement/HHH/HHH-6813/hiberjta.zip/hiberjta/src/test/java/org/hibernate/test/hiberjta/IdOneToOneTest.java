package org.hibernate.test.hiberjta;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;
import org.junit.BeforeClass;
import org.junit.Test;

public class IdOneToOneTest {
    private static PersonEJB personEJB;

    @BeforeClass
    public static void init() {
        EJBContainer ejbContainer = EJBContainer.createEJBContainer();
        Context ctx = ejbContainer.getContext();

        try {
            personEJB = (PersonEJB)ctx.lookup( "java:global/classes/PersonEJB!org.hibernate.test.hiberjta.PersonEJB" );

        }
        catch ( NamingException ex ) {
            throw new AssertionError( ex );
        }
    }

    @Test
    public void select() {
        personEJB.update();
        personEJB.select();
    }

    @Test
    public void find() {
        personEJB.update();
        personEJB.find();
    }
}
