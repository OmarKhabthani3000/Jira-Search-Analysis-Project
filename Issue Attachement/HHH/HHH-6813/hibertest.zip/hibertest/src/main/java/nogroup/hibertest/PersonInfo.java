package nogroup.hibertest;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class PersonInfo implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @OneToOne
    private Person id;
    
    @Basic
    private String info;

    public Person getId() {
        return id;
    }

    public void setId( Person id ) {
        this.id = id;
    }
    
    public String getInfo() {
        return info;
    }

    public void setInfo( String info ) {
        this.info = info;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += ( id != null ? id.hashCode() : 0 );
        return hash;
    }

    @Override
    public boolean equals( Object object ) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if ( !( object instanceof PersonInfo ) ) {
            return false;
        }
        PersonInfo other = (PersonInfo)object;
        if ( ( this.id == null && other.id != null ) || ( this.id != null && !this.id.equals( other.id ) ) ) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "nogroup.hibertest.PersonInfo[ id=" + id + " ]";
    }
}
