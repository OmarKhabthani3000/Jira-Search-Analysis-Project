
package nogroup.hibertest;

import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;

@Named
@RequestScoped
public class Bean {
    @PersistenceContext
    private EntityManager em;

    @Resource
    private UserTransaction utx;

    public void execute() {
        Query q = em.createNamedQuery( "PersonQuery" );
        q.getResultList();
    }

    public void update() {
        try {
            utx.begin();
            Person p = new Person();
            p.setName( "Alfio" );
            PersonInfo pi = new PersonInfo();
            pi.setId( p );
            pi.setInfo( "Some information" );
            em.persist( p );
            em.persist( pi );
        }
        catch ( Exception e ) {

            return;
        }
        finally {
            try {
                utx.commit();
            }
            catch ( Exception e ) {
            }
        }
    }
}
