package nogroup.hibertest;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

@Entity
@NamedQuery( name = "PersonQuery", query = "SELECT p FROM Person p" )
public class Person implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.AUTO )
    private Integer id;

    @Basic
    private String name;

    @OneToOne( mappedBy = "id" )
    private PersonInfo personInfo;

    public Integer getId() {
        return id;
    }

    public void setId( Integer id ) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName( String name ) {
        this.name = name;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += ( id != null ? id.hashCode() : 0 );
        return hash;
    }

    @Override
    public boolean equals( Object object ) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if ( !( object instanceof Person ) ) {
            return false;
        }
        Person other = (Person)object;
        if ( ( this.id == null && other.id != null ) || ( this.id != null && !this.id.equals( other.id ) ) ) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "nogroup.hibertest.Person[ id=" + id + " ]";
    }

    /**
     * @return the personInfo
     */
    public PersonInfo getPersonInfo() {
        return personInfo;
    }

    /**
     * @param personInfo the personInfo to set
     */
    public void setPersonInfo( PersonInfo personInfo ) {
        this.personInfo = personInfo;
    }
}
