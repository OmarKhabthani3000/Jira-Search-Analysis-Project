package org.hibernate.bugs.fieldresult;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

@SqlResultSetMapping(
        name = "user_result",
        entities = @EntityResult(
                entityClass = User.class,
                fields = {
                    @FieldResult(name = "id", column = "id"),
                    @FieldResult(name = "name", column = "name"),
                    @FieldResult(name = "group.id", column = "group_id"),
                    @FieldResult(name = "group.name", column = "group_name")}))
@NamedNativeQuery(
        name = "Usuario.findAll",
        query = "SELECT u.id, u.name, u.group_id, g.name AS group_name FROM users u INNER JOIN groups g ON u.group_id = g.id",
        resultSetMapping = "user_result")
@Entity
@Table(name = "users")
public class User implements Serializable {

    @Id
    @GeneratedValue
    @Column(name = "id")
    private Long id;
    @Column(name = "name")
    private String name;
    @ManyToOne
    @JoinColumn(name = "group_id", referencedColumnName = "id")
    private Group group;

    public User() {
    }

    public User(String name, Group group) {
        this.name = name;
        this.group = group;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Group getGroup() {
        return group;
    }

    @Override
    public String toString() {
        return "User{" + "id=" + id + ", name=" + name + ", group=" + group + '}';
    }

}
