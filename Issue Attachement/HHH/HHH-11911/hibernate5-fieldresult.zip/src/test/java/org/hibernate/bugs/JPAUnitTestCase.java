package org.hibernate.bugs;

import org.hibernate.bugs.fieldresult.Group;
import org.hibernate.bugs.fieldresult.User;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Assert;
import static org.junit.Assert.assertNotNull;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM,
 * using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        Group grupo = new Group("developers");

        em.persist(grupo);
        em.persist(new User("Guillermo", grupo));
        em.persist(new User("Luis", grupo));

        em.getTransaction().commit();

        List<User> users = em.createNamedQuery("Usuario.findAll", User.class).getResultList();
        for (User user : users) {
            assertNotNull(user.getGroup().getId());
            assertNotNull(user.getGroup().getName());
        }

        em.close();
    }
}
