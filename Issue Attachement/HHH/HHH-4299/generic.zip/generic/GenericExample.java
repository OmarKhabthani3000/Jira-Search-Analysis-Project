package generic;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GenericExample {
	
	@Id
	private int id;
	
	private GenericRange<Integer> bounds;


}
