package generic;

import javax.persistence.Embeddable;

@Embeddable
public class GenericRange<T> {

	private T min;
	private T max;
	
	
}
