package generic;

import javax.persistence.Embeddable;

@Embeddable
public class IntegerRange extends Range<Integer> {

}
