package generic;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Example {

	@Id
	private int id;
	
	private IntegerRange bounds;
}
