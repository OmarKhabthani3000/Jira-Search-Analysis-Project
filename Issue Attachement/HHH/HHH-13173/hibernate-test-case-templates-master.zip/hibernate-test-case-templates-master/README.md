# Hibernate Test Case - Cache with joined subclass not working

Attempting ot cache a joined subclass inheritance method does not work.

First test shows it working for a regular mapped class.  2nd test follows the same format for a joined subclass inheritance and does not work.
