package entities;

public class NonUIPerson extends Person {
}
