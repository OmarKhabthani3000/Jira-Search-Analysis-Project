package entities;

public class UIPerson extends Person {
}
