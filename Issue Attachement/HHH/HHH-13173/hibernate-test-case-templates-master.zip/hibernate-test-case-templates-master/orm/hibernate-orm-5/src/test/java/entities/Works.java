package entities;

public class Works {

   private Long oid;

   public Long getOid() {
      return oid;
   }

   public void setOid(Long oid) {
      this.oid = oid;
   }
}
