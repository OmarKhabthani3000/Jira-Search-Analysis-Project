package de.m3y3r.hhh;

public class TestObject {

	public TestObject(String text, String type) {
	}
}
