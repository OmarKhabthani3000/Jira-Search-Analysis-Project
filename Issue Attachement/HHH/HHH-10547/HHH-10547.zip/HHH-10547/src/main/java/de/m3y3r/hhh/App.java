package de.m3y3r.hhh;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class App implements Runnable
{
	public static void main(String[] args )
	{
		new App().run();
	}

	@Override
	public void run() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("unit");
		try {
			EntityManager em = emf.createEntityManager();
			try {
				Query q = em.createQuery("select t, new de.m3y3r.hhh.TestObject(t, 'tags') from TestEntity e join e.tags t group by t");
				List resultList = q.getResultList();
			} finally {
				em.close();
			}
		} finally {
			emf.close();
		}
	}
}
