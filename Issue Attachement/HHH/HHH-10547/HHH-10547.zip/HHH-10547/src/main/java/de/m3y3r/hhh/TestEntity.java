package de.m3y3r.hhh;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="TEST_ENTITY")
public class TestEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private Integer id;

	@ElementCollection
	private List<String> tags;

}
