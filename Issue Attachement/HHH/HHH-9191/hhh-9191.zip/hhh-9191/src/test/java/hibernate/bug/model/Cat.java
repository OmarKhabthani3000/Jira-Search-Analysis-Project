package hibernate.bug.model;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Cat extends Animal {

    private Cat parent;
    private Set<Cat> kittens = new HashSet<Cat>();

    public Cat() {
    }

    public Cat(Cat parent, String name) {
        super(name);
        this.parent = parent;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Cat getParent() {
        return parent;
    }

    public void setParent(Cat parent) {
        this.parent = parent;
    }

    @OneToMany(mappedBy = "parent")
    public Set<Cat> getKittens() {
        return kittens;
    }

    public void setKittens(Set<Cat> kittens) {
        this.kittens = kittens;
    }
}
