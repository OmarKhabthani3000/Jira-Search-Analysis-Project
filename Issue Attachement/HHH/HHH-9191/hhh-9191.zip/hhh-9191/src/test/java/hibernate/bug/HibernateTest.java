package hibernate.bug;

import hibernate.bug.model.Animal;
import hibernate.bug.model.Cat;
import hibernate.bug.model.CuteCat;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    private Cat c;
    private CuteCat d;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        c = new Cat(null, "c");
        d = new CuteCat(1, null, "d");
        
        em.persist(c);
        em.persist(d);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        
        Assert.assertNotNull(em.find(Cat.class, c.getId()));
        
        em.close();
    }
}
