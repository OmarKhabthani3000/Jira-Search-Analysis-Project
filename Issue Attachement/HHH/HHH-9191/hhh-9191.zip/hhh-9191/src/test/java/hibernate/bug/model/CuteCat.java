package hibernate.bug.model;

import javax.persistence.Entity;

@Entity
public class CuteCat extends Cat {

    private int cuteness;

    public CuteCat() {
    }

    public CuteCat(int cuteness, Cat parent, String name) {
        super(parent, name);
        this.cuteness = cuteness;
    }

    public int getCuteness() {
        return cuteness;
    }

    public void setCuteness(int cuteness) {
        this.cuteness = cuteness;
    }
}
