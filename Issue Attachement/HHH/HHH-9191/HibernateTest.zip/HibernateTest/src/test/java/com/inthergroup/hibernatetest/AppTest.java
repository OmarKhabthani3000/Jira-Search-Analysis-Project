package com.inthergroup.hibernatetest;

import com.inthergroup.hibernatetest.invalid.Y;
import com.inthergroup.hibernatetest.invalid.Z;
import com.inthergroup.hibernatetest.valid.C;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App. I provided 2 hierarchies . One hierarchy has not in
 * superClass Discriminator Column , another has. The problem is that in
 * hierarchy with Discriminator Column i am trying to get all records from table
 * define in B Entity.. But it Dies.
 *
 * Below is my test
 */
public class AppTest
        extends TestCase
{

  EntityManagerFactory factory = Persistence.createEntityManagerFactory("persistenceUnit");

  /**
   * Create the test case
   *
   * @param testName name of the test case
   */
  public AppTest(String testName)
  {
    super(testName);

  }

  /**
   * @return the suite of tests being tested
   */
  public static Test suite()
  {
    return new TestSuite(AppTest.class);
  }

  public void testInsert()
  {
    insertRecords_C();
    insertRecordsIn_Z();
  }

  /**
   *  //Here am getting records from DB. EveryThing Works OK!! Method trying to
   * get all Object from Db using entity B. B Entity is a JoinedSubclass of A
   * entity. A does not have Discriminator Column defined.
   */
  public void testNoDiscriminatorColumnForJoinedInhertance()
  {

    EntityManager manager = factory.createEntityManager();
    Query q = manager.createQuery("SELECT b FROM " + "B" + " b ");
    System.out.println(q.getResultList());

  }

  /**
   * Select Records from Y using query. Test fails because of Discriminator
   * Column that is generate in Y. Y is JoinedSubclass of Class X , there
   * discriminator column is defined.
   */
  public void testQuerySelectFromInheritanceJoinedWithDiscriminatorColumn()
  {

    EntityManager manager = factory.createEntityManager();
    Query q = manager.createQuery("SELECT y FROM " + "Y" + " y ");
    System.out.println(q.getResultList());

  }

  /**
   * Test fails because of Discriminator Column that is generate in Y. Y is
   * JoinedSubclass of Class X , there discriminator column is defined.
   */
  public void testManagerFindFromInheritanceJoinedWithDiscriminatorColumn()
  {
    EntityManager manager = factory.createEntityManager();
    Y b = manager.find(Y.class, "1");

  }

  /**
   * Inserts records Type C in Db using manager. The Super Class is A . This
   * class does not have Discriminator Column
   *
   * @param factory
   */
  public void insertRecords_C()
  {
    try
    {
      EntityManager manager = factory.createEntityManager();
      EntityTransaction tx = manager.getTransaction();
      tx.begin();

      C c1 = new C();
      c1.setId("1");
      c1.setName("Test 1");
      c1.setStatus(1);

      manager.persist(c1);

      tx.commit();

      assertTrue(true);
    }
    catch (Exception e)
    {
      assertFalse(e.toString(), true);
    }
  }

  /**
   * This Method tries to insert a record in Z. X is super class where
   * Discriminator Column is defined
   *
   * @param factory
   */
  public void insertRecordsIn_Z()
  {
    try
    {
      EntityManager manager = factory.createEntityManager();
      EntityTransaction tx = manager.getTransaction();
      tx.begin();

      Z c1 = new Z();
      c1.setId("1");
      c1.setName("Test 1");
      c1.setStatus(1);

      manager.persist(c1);

      tx.commit();
      assertTrue(true);
    }
    catch (Exception e)
    {
      assertFalse(e.toString(), true);
    }
  }
}
