package com.inthergroup.hibernatetest;

import com.inthergroup.hibernatetest.invalid.Y;
import com.inthergroup.hibernatetest.invalid.Z;
import com.inthergroup.hibernatetest.valid.C;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 * Hello world!
 *
 */
public class App
{

  static EntityManagerFactory factory = Persistence.createEntityManagerFactory("persistenceUnit");

  public static void main(String[] args)
  {

    System.out.println("Hello");

    //This works
    insertRecordsValid();
    selectRecordsValid();

    //This doesnt work
    insertRecordsInValid();
    selectRecordsInValid();

    System.out.println("");
  }

  public static void insertRecordsValid()
  {

    EntityManager manager = factory.createEntityManager();
    EntityTransaction tx = manager.getTransaction();
    tx.begin();

    C c1 = new C();
    c1.setId("1");
    c1.setName("Test 1");
    c1.setStatus(1);

    manager.persist(c1);

    tx.commit();
  }

  public static void selectRecordsValid()
  {
    EntityManager manager = factory.createEntityManager();
    Query q = manager.createQuery("SELECT ol FROM " + "B" + " ol ");
    System.out.println(q.getResultList());
  }

  public static void insertRecordsInValid()
  {
    EntityManager manager = factory.createEntityManager();
    EntityTransaction tx = manager.getTransaction();
    tx.begin();

    Z z1 = new Z();
    z1.setId("1");
    z1.setName("Test 1");
    z1.setStatus(1);

    manager.persist(z1);
    tx.commit();
  }

  public static void selectRecordsInValid()
  {
    EntityManager manager = factory.createEntityManager();
    Y b = manager.find(Y.class, "1");
    System.out.println(b);
  }
}
