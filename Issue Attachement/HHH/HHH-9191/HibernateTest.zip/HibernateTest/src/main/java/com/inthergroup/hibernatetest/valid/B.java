//*************************************************//
//          INTHER LOGISTICS ENGINEERING           //
//*************************************************//
package com.inthergroup.hibernatetest.valid;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @since May 15, 2014
 * @author dcebotarenco
 */
@Entity
@Table(name = "Table_B")
public abstract class B extends A
{

}
