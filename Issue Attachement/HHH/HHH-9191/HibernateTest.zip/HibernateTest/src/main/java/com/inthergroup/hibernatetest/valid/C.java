//*************************************************//
//          INTHER LOGISTICS ENGINEERING           //
//*************************************************//
package com.inthergroup.hibernatetest.valid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @since May 15, 2014
 * @author dcebotarenco
 */
@Entity
@Table(name = "Table_C")
public class C extends B
{

  @Column
  private String name;

  public String getName()
  {
    return name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

}
