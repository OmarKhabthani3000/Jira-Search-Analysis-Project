//*************************************************//
//          INTHER LOGISTICS ENGINEERING           //
//*************************************************//
package com.inthergroup.hibernatetest.invalid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @since May 15, 2014
 * @author dcebotarenco
 */
@Entity
@Table(name = "Table_Z")
public class Z extends Y
{

  @Column
  private String name;

  public String getName()
  {
    return name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

}
