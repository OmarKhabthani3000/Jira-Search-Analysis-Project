//*************************************************//
//          INTHER LOGISTICS ENGINEERING           //
//*************************************************//
package com.inthergroup.hibernatetest.invalid;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

/**
 *
 * @since May 15, 2014
 * @author dcebotarenco
 */
@Entity
@Table(name = "Table_X")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "INTH_TYPE")
public abstract class X
{

  @Id
  private String id;
  @Column
  private int status;

  public String getId()
  {
    return id;
  }

  public void setId(String id)
  {
    this.id = id;
  }

  public int getStatus()
  {
    return status;
  }

  public void setStatus(int status)
  {
    this.status = status;
  }

}
