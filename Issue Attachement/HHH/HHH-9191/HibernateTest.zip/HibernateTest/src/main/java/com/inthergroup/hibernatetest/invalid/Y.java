//*************************************************//
//          INTHER LOGISTICS ENGINEERING           //
//*************************************************//
package com.inthergroup.hibernatetest.invalid;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @since May 15, 2014
 * @author dcebotarenco
 */
@Entity
@Table(name = "Table_Y")
public abstract class Y extends X
{

}
