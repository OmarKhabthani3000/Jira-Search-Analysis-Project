package org.hibernate.test.hhh9372;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.hibernate.testcase.Person;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author Fagner Granella
 */
public class TestHHH9372 {

    private static EntityManagerFactory entityManagerFactory;

    private static EntityManager entityManager;

    @Before
    public void initFactory() {
        entityManagerFactory = Persistence.createEntityManagerFactory("testPU");
    }

    @Test
    public void testConverterInsideClass() {
        entityManager = entityManagerFactory.createEntityManager();
        
        entityManager.getTransaction().begin();
        
        Person person = new Person();
        person.setName("John Doe");
        person.setGender(Person.Gender.MALE);
        
        entityManager.persist(person);
        Assert.assertTrue(entityManager.contains(person));
        
        entityManager.getTransaction().commit();
    }
}
