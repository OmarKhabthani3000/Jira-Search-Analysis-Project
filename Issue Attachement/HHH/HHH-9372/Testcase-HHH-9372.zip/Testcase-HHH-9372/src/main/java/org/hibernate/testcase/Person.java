package org.hibernate.testcase;

import java.io.Serializable;
import javax.persistence.AttributeConverter;
import javax.persistence.Convert;
import javax.persistence.Converter;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author Fagner Granella
 */
@Entity
public class Person implements Serializable {

    public enum Gender {

        MALE,
        FEMALE;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Convert(converter = GenderConverter.class)
    private Gender gender;

    public Person() {
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return "Person{" + "id=" + id + ", name=" + name + ", gender=" + gender + '}';
    }

    @Converter
    public class GenderConverter implements AttributeConverter<Person.Gender, Integer> {

        @Override
        public Integer convertToDatabaseColumn(Person.Gender attribute) {
            return attribute.ordinal();
        }

        @Override
        public Person.Gender convertToEntityAttribute(Integer dbValue) {
            return Person.Gender.values()[dbValue];
        }

    }
}
