package oracleTest;

import java.util.Date;

import junit.framework.TestCase;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class LeftJoinFragmentTest extends TestCase {
	private static Log log = LogFactory.getLog(LeftJoinFragmentTest.class);
	protected Configuration conf;
	protected SessionFactory sessionFactory;
	
    protected void setUp() {
		conf = new Configuration().configure("hibernate.cfg.xml");
		sessionFactory = conf.buildSessionFactory();
    	SchemaExport schemaExport = new SchemaExport(conf);
    	schemaExport.create(true, true);
    	
    	log.info("finished setting test.");
    }
    
	protected void tearDown() throws Exception {
		sessionFactory.close();
		sessionFactory = null;
		super.tearDown();
	}

	public void testLeftJoinFragment(){
		
		Session s = sessionFactory.openSession();
		Transaction t = s.beginTransaction();
		
		Company sourcelabs = new Company( "sourcelabs" );
		
		s.save(sourcelabs);
		s.flush();

		Employee yajun = new Employee( "yajun", new Date(1234567890L), sourcelabs.getId() );
		Employee gail = new Employee( "gail", new Date(1234567890L), sourcelabs.getId() );
		sourcelabs.getEmployees().add(yajun);
		sourcelabs.getEmployees().add(gail);
		
		s.save(yajun);
		s.save(gail);
		s.saveOrUpdate(sourcelabs);
		
		t.commit();
		
		sessionFactory.evict( Employee.class );
		sessionFactory.evict( Company.class );

		// open a new transaction to start the test
		Transaction t2 = s.beginTransaction();
		
		int sizeQueries = s.createQuery("from Company comp " +
										"left outer join comp.employees empl " +
										"with empl.birthday != :date")
							.setParameter("date", new Date())
							.list()
							.size();
		
		assertEquals(2, sizeQueries);

		s.createQuery("from Company comp " +
				"left outer join comp.employees empl " +
				"with empl.birthday >= :date")
		.setParameter("date", new Date())
		.list()
		.size();

		t2.commit();
		s.close();
	}
}

