package test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.Assert;
import org.junit.Test;

public class Tests {
	@Test
	public void testIsEmpty() {
		EntityManager entityManager = Persistence.createEntityManagerFactory( "unitH2" ).createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();

		entityTransaction.begin();

		Property property1 = new Property();
		entityManager.persist( property1 );
		Property property2 = new Property();
		entityManager.persist( property2 );

		Project projectWithProperties = new Project();
		projectWithProperties.getProperties().add( property1 );
		projectWithProperties.getSelectedProperties().add( property2 );
		entityManager.persist( projectWithProperties );

		Project orderWithoutProperties = new Project();
		entityManager.persist( orderWithoutProperties );

		entityTransaction.commit();

		entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();

		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Project> cq = cb.createQuery( Project.class );
		Root<Project> root = cq.from( Project.class );
		cq.select( root );

		cq.where( cb.isEmpty( root.get( Project_.selectedProperties ) ) );

		List<Project> ordersWithoutProducts = entityManager.createQuery( cq ).getResultList();

		Assert.assertEquals( 1, ordersWithoutProducts.size() ); // Works as we are using "selectedProperties"

		cb = entityManager.getCriteriaBuilder();
		cq = cb.createQuery( Project.class );
		root = cq.from( Project.class );
		cq.select( root );

		cq.where( cb.isEmpty( root.get( Project_.properties ) ) );

		ordersWithoutProducts = entityManager.createQuery( cq ).getResultList(); // FAILS HERE as we are using "properties"

		Assert.assertEquals( 1, ordersWithoutProducts.size() );

		EntityManagerFactory entityManagerFactory = entityManager.getEntityManagerFactory();
		entityTransaction.commit();
		entityManager.close();
		entityManagerFactory.close();

		entityManager = null;
	}
}
