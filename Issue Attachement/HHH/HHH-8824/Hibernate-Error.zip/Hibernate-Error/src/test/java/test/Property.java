package test;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
@Access( AccessType.PROPERTY )
public class Property {
	private Long id;
	private Set<Project> projectsByProperties;
	private Set<Project> projectsBySelectedProperties;

	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	@ManyToMany( cascade = CascadeType.ALL, mappedBy = "properties" )
	public Set<Project> getProjectsByProperties() {
		if( projectsByProperties == null ){
			projectsByProperties = new HashSet<>();
		}

		return projectsByProperties;
	}
	public void setProjectsBySelectedProperties(Set<Project> projectsBySelectedProperties) {
		this.projectsBySelectedProperties = projectsBySelectedProperties;
	}

	@ManyToMany( cascade = CascadeType.ALL, mappedBy = "selectedProperties" )
	public Set<Project> getProjectsBySelectedProperties() {
		if( projectsBySelectedProperties == null ){
			projectsBySelectedProperties = new HashSet<>();
		}

		return projectsBySelectedProperties;
	}
	public void setProjectsByProperties(Set<Project> projectsByProperties) {
		this.projectsByProperties = projectsByProperties;
	}
}
