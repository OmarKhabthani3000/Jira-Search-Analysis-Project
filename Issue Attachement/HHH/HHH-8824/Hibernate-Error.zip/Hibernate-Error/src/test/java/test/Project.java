package test;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
@Access( AccessType.PROPERTY )
public class Project {
	private Long id;
	private Set<Property> properties;
	private Set<Property> selectedProperties;

	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	@ManyToMany
	@JoinTable( name = "Project_Properties" )
	public Set<Property> getProperties() {
		if( properties == null ){
			properties = new HashSet<>();
		}

		return properties;
	}
	public void setProperties(Set<Property> properties) {
		this.properties = properties;
	}

	@ManyToMany
	@JoinTable( name = "Project_SelectedProperties" )
	public Set<Property> getSelectedProperties() {
		if( selectedProperties == null ){
			selectedProperties = new HashSet<>();
		}

		return selectedProperties;
	}
	public void setSelectedProperties(Set<Property> selectedProperties) {
		this.selectedProperties = selectedProperties;
	}
}
