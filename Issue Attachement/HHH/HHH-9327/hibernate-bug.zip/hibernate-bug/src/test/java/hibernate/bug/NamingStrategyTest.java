/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hibernate.bug;

import java.sql.Connection;
import java.sql.ResultSet;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import junit.framework.Assert;
import org.hibernate.Session;
import org.hibernate.internal.SessionImpl;
import org.junit.Test;

public class NamingStrategyTest {
    
    @Test
    public void test() throws Exception {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Test");
        Connection c = ((SessionImpl)emf.createEntityManager().unwrap(Session.class)).connection();
        ResultSet rs = c.createStatement().executeQuery("SHOW TABLES");
        boolean found = false;
        
        while (rs.next()) {
            if ("BUG_LOCALIZED_WORKFLOW".equals(rs.getString("TABLE_NAME").toUpperCase())) {
                found = true;
                break;
            }
        }
        
        if (!found) {
            Assert.fail("Couldn't find table!");
        }
    }
}
