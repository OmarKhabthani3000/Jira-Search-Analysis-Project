/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hibernate.bug;

import org.hibernate.cfg.EJB3NamingStrategy;

public class MyNamingStrategy extends EJB3NamingStrategy {

    private static final long serialVersionUID = -5713413771290957530L;

    @Override
    public String collectionTableName(String ownerEntity, String ownerEntityTable, String associatedEntity, String associatedEntityTable, String propertyName) {
        String name = null;

        if ("localized".equals(propertyName)) {
            // NOTE: The problem is that ownerEntity is not the fully qualified class name since 4.2.15 anymore
            final String[] qualifiedNameParts = ownerEntity.split("\\.");

            if (qualifiedNameParts.length > 3 && "model".equals(qualifiedNameParts[qualifiedNameParts.length - 2])) {
                final String moduleShortcut = qualifiedNameParts[qualifiedNameParts.length - 3];
                // Remove Module prefix of entity if equal to moduleShortcut
                ownerEntityTable = ownerEntityTable.toUpperCase().startsWith(moduleShortcut.toUpperCase()) ? ownerEntityTable.substring(moduleShortcut.length(), ownerEntityTable.length()) : ownerEntityTable;
                name = new StringBuilder(moduleShortcut).append("_LOCALIZED_").append(addUnderscores(ownerEntityTable)).toString().toUpperCase();
            }
        }

        if (name == null) {
            name = super.collectionTableName(ownerEntity, ownerEntityTable, associatedEntity, associatedEntityTable, propertyName);
        }

        return name;
    }

    private static StringBuilder addUnderscores(String name) {
        StringBuilder sb = new StringBuilder(name.replace('.', '_'));

        for (int i = 1; i < sb.length() - 1; i++) {
            if (Character.isLowerCase(sb.charAt(i - 1)) && Character.isUpperCase(sb.charAt(i)) && Character.isLowerCase(sb.charAt(i + 1))) {
                sb.insert(i++, '_');
            }
        }

        return sb;
    }
}
