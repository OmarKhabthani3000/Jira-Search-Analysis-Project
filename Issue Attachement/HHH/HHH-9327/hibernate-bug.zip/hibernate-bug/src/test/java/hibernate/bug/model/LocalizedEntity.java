package hibernate.bug.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class LocalizedEntity implements Serializable, Cloneable {
    
    private static final long serialVersionUID = -8539302606114365372L;

    private String name;
    private String description;

    /**
     * Empty Constructor
     */
    public LocalizedEntity() {
        super();
    }

    /**
     * @param name
     * @param description
     */
    public LocalizedEntity(String name, String description) {
        super();
        this.name = name;
        this.description = description;
    }

    @Column(
            name = "NAME",
            nullable = false,
            length = 255)
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(
            name = "DESCRIPTION",
            nullable = false,
            length = 2500)
    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public LocalizedEntity clone() {
        return new LocalizedEntity(this.name, this.description);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((description == null) ? 0 : description.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        LocalizedEntity other = (LocalizedEntity) obj;
        if (description == null) {
            if (other.description != null)
                return false;
        } else if (!description.equals(other.description))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        return true;
    }
}
