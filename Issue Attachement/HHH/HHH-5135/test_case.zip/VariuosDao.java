package somepackage.dao;

import somepackage.domain.*;

import java.util.List;

public interface VariuosDao {
    public List<Period> findAllPeriods();
}
