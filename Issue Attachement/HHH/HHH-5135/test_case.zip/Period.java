package somepackage.domain;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Period extends DomainObject {

	private Date fromDate;
	private Date toDate;
	private Date month;

	public Period() {

	}

	/**
	 * @return
	 */
	public Date getFromDate() {
		return fromDate;
	}

	/**
	 * @return
	 */
	public Date getMonth() {
		return month;
	}

	/**
	 * @return
	 */
	public Date getToDate() {
		return toDate;
	}

	/**
	 * @param date
	 */
	public void setFromDate(Date date) {
		fromDate = date;
	}

	/**
	 * @param date
	 */
	public void setMonth(Date date) {
		month = date;
	}

	/**
	 * @param date
	 */
	public void setToDate(Date date) {
		toDate = date;
	}

}
