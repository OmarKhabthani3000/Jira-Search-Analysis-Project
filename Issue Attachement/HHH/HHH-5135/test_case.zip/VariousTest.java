package somepackage.tests;

import somepackage.domain.*;
import somepackage.dao.VariuosDao;

import org.apache.log4j.Logger;

import java.util.List;

public class VariousTest extends BaseTestCase {

    Logger logger = Logger.getLogger(VariousTest.class);

    protected void setUp() throws Exception {
        super.setUp();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testFindAllPeriods() {
        VariuosDao dao = (VariuosDao) getContext().getBean("variousDao");
        List<Period> periods = dao.findAllPeriods();
        logger.debug("Periods size = " + periods.size());
        assertTrue(periods.size() > 0);
    }
}
