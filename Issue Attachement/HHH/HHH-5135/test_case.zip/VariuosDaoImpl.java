package somepackage.dao;

import somepackage.domain.*;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.hibernate.Session;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Criteria;
import org.apache.log4j.Logger;

import java.sql.SQLException;
import java.util.List;

public class VariuosDaoImpl implements VariuosDao {

    Logger logger = Logger.getLogger(VariuosDaoImpl.class);

    private HibernateTemplate hibernateTemplate;

    public List<Period> findAllPeriods() {
        return (List<Period>) getHibernateTemplate().execute(new HibernateCallback() {
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
                Query query = session.createQuery("from Period p");
                query.setFirstResult(0);
                query.setMaxResults(1);
                List<Period> periods = query.list();
                return periods;
            }
        });
    }

    public HibernateTemplate getHibernateTemplate() {
        return hibernateTemplate;
    }

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }
}
