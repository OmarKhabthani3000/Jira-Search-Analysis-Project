package org.hibernate.test;

public class Base {
    private Long objectId;
    private ChildA childA;

    public Long getObjectId() {
        return objectId;
    }

    public void setObjectId(Long objectId) {
        this.objectId = objectId;
    }

    public ChildA getChildA() {
        return childA;
    }

    public void setChildA(ChildA childA) {
        this.childA = childA;
    }
}
