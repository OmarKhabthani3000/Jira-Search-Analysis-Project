package org.hibernate.test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.bugs.ORMUnitTestCase;
import org.hibernate.query.Query;
import org.junit.Test;

public class WrongUpdateQueryTest extends ORMUnitTestCase {
    @Override
    protected String[] getMappings() {
        return new String[] { "Base.hbm.xml" };
    }


    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
        // BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
        Session s = openSession();
        Transaction tx = s.beginTransaction();

        Query query = s.createQuery("update Base b set b.childA.objectId = :newId where b.childA.objectId = :oldId");
        query.setParameter("newId", 5L);
        query.setParameter("oldId", 6L);
        query.executeUpdate();

        // Do stuff...
        tx.commit();
        s.close();
    }
}
