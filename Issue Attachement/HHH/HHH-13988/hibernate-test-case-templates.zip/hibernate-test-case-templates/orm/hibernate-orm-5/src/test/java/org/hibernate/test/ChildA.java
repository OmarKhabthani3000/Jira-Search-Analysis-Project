package org.hibernate.test;

public class ChildA extends Base {
}
