package org.hibernate.test;

public class ChildB extends Base {
}
