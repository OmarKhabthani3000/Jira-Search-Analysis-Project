package de.iteratec.enverstest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class EnversJpaTest {

	private EntityManagerFactory emf = Persistence.createEntityManagerFactory("envers_many2many");
	private EntityManager em;
	private EntityTransaction tx;

	public EntityManager createEntityManager() {
		return emf.createEntityManager();
	}

	public void closeEntityManager() {
		emf.close();
	}

	public void persistPerson(Person person) {
		em.persist(person);
	}

	public void mergePerson(Person person) {
		em.merge(person);
	}

	public void persistRole(Role role) {
		em.persist(role);
	}

	public void mergeRole(Role role) {
		em.merge(role);
	}

	@Before
	public void setUp() {
		em = createEntityManager();
		tx = em.getTransaction();
		tx.begin();
	}

	@After
	public void tearDown() {
		tx.commit();
		em.close();
		closeEntityManager();
	}

	@Test
	public void testAuditMany2Many() throws Exception {
		Person anton = new Person();
		anton.setName("Anton");
		persistPerson(anton);

		Role gruppe = new Role();
		gruppe.setName("Gruppe1");

		anton.getRoles().add(gruppe);
		gruppe.getMembers().add(anton);

		persistRole(gruppe);

	}

}
