package de.iteratec.enverstest;

import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2011-09-28T14:49:02.171+0200")
@StaticMetamodel(Role.class)
public class Role_ extends RightsSubject_ {
	public static volatile SingularAttribute<Role, String> name;
	public static volatile SetAttribute<Role, RightsSubject> members;
}
