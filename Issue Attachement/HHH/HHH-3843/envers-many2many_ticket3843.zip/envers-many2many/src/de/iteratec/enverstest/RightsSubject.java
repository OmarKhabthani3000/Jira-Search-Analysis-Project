package de.iteratec.enverstest;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.envers.Audited;

/**
 * Entity implementation class for Entity: RightsSubject
 *
 */
@Entity
@Table(catalog="PUBLIC")
@Inheritance(strategy=InheritanceType.JOINED)
@Audited
public abstract class RightsSubject implements Serializable {

	@Override
	public String toString() {
		return "RightsSubject [id=" + id + ", superRoles=" + superRoles + "]";
	}

	private static final long serialVersionUID = 1L;
	private String             lastModificationUser;
	private Date               lastModificationTime;

	private Integer version;
	private Integer id;
	private Set<Role> superRoles = new HashSet<Role>();

	@Id
	@GeneratedValue
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the version
	 */
	@Version
	public Integer getVersion() {
		return version;
	}
	/**
	 * @param version the version to set
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}

	public RightsSubject() {
		super();
	}

	/**
	 * @return the roles
	 */
	@ManyToMany(mappedBy="members")
	public Set<Role> getRoles() {
		return superRoles;
	}
	/**
	 * @param roles the roles to set
	 */
	public void setRoles(Set<Role> roles) {
		this.superRoles = roles;
	}

	/**
	 * @return the lastModificationUser
	 */
	public String getLastModificationUser() {
		return lastModificationUser;
	}

	/**
	 * @param lastModificationUser the lastModificationUser to set
	 */
	public void setLastModificationUser(String lastModificationUser) {
		this.lastModificationUser = lastModificationUser;
	}

	/**
	 * @return the lastModificationTime
	 */
	public Date getLastModificationTime() {
		return lastModificationTime;
	}

	/**
	 * @param lastModificationTime the lastModificationTime to set
	 */
	public void setLastModificationTime(Date lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}

}
