package de.iteratec.enverstest;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

/**
 * Entity implementation class for Entity: Role
 *
 */
@Entity
@Table(catalog = "PUBLIC")
@Audited
public class Role extends RightsSubject {


	private String name;
	private Set<RightsSubject> members = new HashSet<RightsSubject>();

	@Override
	public String toString() {
		return "Role [name=" + name + ", members=" + members + "]";
	}

	private static final long serialVersionUID = 1L;

	public Role() {
		super();
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the members
	 */
	@ManyToMany
	@JoinTable(catalog = "PUBLIC")
	public Set<RightsSubject> getMembers() {
		return members;
	}

	/**
	 * @param members the members to set
	 */
	public void setMembers(Set<RightsSubject> members) {
		this.members = members;
	}

}
