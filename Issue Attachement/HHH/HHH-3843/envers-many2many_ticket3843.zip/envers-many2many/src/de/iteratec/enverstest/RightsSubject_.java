package de.iteratec.enverstest;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2011-09-28T15:31:10.131+0200")
@StaticMetamodel(RightsSubject.class)
public class RightsSubject_ {
	public static volatile SingularAttribute<RightsSubject, Integer> id;
	public static volatile SingularAttribute<RightsSubject, Integer> version;
	public static volatile SingularAttribute<RightsSubject, String> lastModificationUser;
	public static volatile SingularAttribute<RightsSubject, Date> lastModificationTime;
	public static volatile SetAttribute<RightsSubject, Role> roles;
}
