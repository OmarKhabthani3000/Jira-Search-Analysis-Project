package de.iteratec.enverstest;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2011-09-28T14:43:25.497+0200")
@StaticMetamodel(Person.class)
public class Person_ extends RightsSubject_ {
	public static volatile SingularAttribute<Person, String> name;
}
