package de.iteratec.enverstest;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

/**
 * Entity implementation class for Entity: Person
 *
 */
@Entity
@Table(catalog = "PUBLIC")
@Audited
public class Person extends RightsSubject {


	private String name;

	@Override
	public String toString() {
		return "Person [name=" + name + "]";
	}

	private static final long serialVersionUID = 1L;

	public Person() {
		super();
	}
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
