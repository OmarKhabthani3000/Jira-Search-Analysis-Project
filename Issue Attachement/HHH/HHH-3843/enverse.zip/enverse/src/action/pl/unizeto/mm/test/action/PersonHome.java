package pl.unizeto.mm.test.action;

import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Begin;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.framework.EntityHome;

import pl.unizeto.mm.test.model.Person;

@Name("personHome")
public class PersonHome extends EntityHome<Person>
{

    @RequestParameter 
    Long personId;
    
    @Override
    public Object getId() 
    { 
        if (personId==null)
        {
            return super.getId();
        }
        else
        {
            return personId;
        }
    }
    
    @Override @Begin
    public void create() {
        super.create();
    }
 	
}
