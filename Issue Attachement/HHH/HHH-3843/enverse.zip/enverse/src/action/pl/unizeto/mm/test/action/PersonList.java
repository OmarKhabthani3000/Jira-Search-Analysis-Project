package pl.unizeto.mm.test.action;

import org.jboss.seam.annotations.Name;
import org.jboss.seam.framework.EntityQuery;

@Name("personList")
public class PersonList extends EntityQuery
{
    @Override
    public String getEjbql() 
    { 
        return "select person from Person person";
    }
}
