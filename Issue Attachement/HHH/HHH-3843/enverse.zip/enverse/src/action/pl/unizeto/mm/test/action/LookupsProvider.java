package pl.unizeto.mm.test.action;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Transactional;

import pl.unizeto.mm.test.model.Role;

@Name("lookups")
public class LookupsProvider {
	@In
	EntityManager entityManager;
	
	
	@SuppressWarnings("unchecked")
	@Factory("rolesLookup")
	@Transactional
	public List<Role> getRoles() {
		Query query = entityManager.createQuery("select r from Role r order by r.name");
		return query.getResultList();
	}
	
}
