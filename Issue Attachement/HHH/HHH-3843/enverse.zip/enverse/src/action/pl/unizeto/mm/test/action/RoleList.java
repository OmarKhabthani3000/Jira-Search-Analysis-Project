package pl.unizeto.mm.test.action;

import org.jboss.seam.annotations.Name;
import org.jboss.seam.framework.EntityQuery;

@Name("roleList")
public class RoleList extends EntityQuery
{
    @Override
    public String getEjbql() 
    { 
        return "select role from Role role";
    }
}
