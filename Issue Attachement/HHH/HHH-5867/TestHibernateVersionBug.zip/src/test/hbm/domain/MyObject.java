package test.hbm.domain;


public class MyObject {

	private Long _id; // for ORM

	private int _version; // for ORM;
	
	private String name;
	
	private MyComponent component;
	
	public MyObject(String name, MyComponent component) {
		this.name = name;
		this.component = component;
	}

	public Long get_id() {
		return _id;
	}

	public void set_id(Long _id) {
		this._id = _id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public MyComponent getComponent() {
		return component;
	}

	public void setComponent(MyComponent component) {
		this.component = component;
	}

	public int get_version() {
		return _version;
	}

}
