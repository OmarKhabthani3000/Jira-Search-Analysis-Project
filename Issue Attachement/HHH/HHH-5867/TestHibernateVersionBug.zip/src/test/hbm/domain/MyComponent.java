package test.hbm.domain;


public class MyComponent {

	private MyEnum type; 

	public MyComponent() { //for ORM
	}

	public MyComponent(final String tspType, final String instanceName, final String obuType) {
		this(tspType, instanceName, obuType, null, null);
	}

	public MyComponent(final String tspType, final String instanceName, final String obuType,
			final String obuNumber, final String trigger) {
	}

	public MyEnum getType() {
		return type;
	}

	public void setType(final MyEnum type) {
		this.type = type;
	}

}
