package test.hbm.domain;

public enum MyEnum {
	S1, S2, S3
}
