package test.hbm.util;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.usertype.EnhancedUserType;
import org.hibernate.usertype.ParameterizedType;
import org.hibernate.util.ReflectHelper;

public class ShortEnumUserType
	implements EnhancedUserType, ParameterizedType
{
    @SuppressWarnings("unchecked")
	private Class<Enum> enumClass = null;

    @SuppressWarnings("unchecked")
	public void setParameterValues(final Properties parameters) {
        final String enumClassName = parameters.getProperty("enumClassname");
        try {
            enumClass = ReflectHelper.classForName(enumClassName);
        }
        catch (final ClassNotFoundException cnfe) {
            throw new HibernateException("Enum class not found", cnfe);
        }
    }

    @SuppressWarnings("unchecked")
	public Class returnedClass() {
        return enumClass;
    }

    public int[] sqlTypes() {
        return new int[] { Hibernate.SHORT.sqlType() };
    }

    public boolean isMutable() {
        return false;
    }

    public Object deepCopy (final Object value) {
        return value;
    }

    @SuppressWarnings("unchecked")
	public Serializable disassemble (final Object value) {
        return (Enum) value;
    }

    public Object replace (final Object original, final Object target, final Object owner) {
        return original;
    }

    public Object assemble(final Serializable cached, final Object owner) {
        return cached;
    }

    public boolean equals (final Object x, final Object y) {
       if (x == null || y == null) {
		return false;
	}
       return x.equals(y);
    }

    public int hashCode (final Object x) {
        return x.hashCode();
    }

    public Object fromXMLString(final String xmlValue) {
    	return enumClass.getEnumConstants()[Integer.valueOf(xmlValue)];
    }

    @SuppressWarnings("unchecked")
	public String objectToSQLString (final Object value) {
        return "\'" + ((Enum) value).ordinal() + '\'';
    }

    @SuppressWarnings("unchecked")
	public String toXMLString (final Object value) {
        return Integer.toString(((Enum) value).ordinal());
    }

    public Object nullSafeGet(final ResultSet rs, final String[] names, final Object owner)
            throws SQLException {
        final int ordinal = rs.getShort( names[0] );
        return rs.wasNull() ? null : enumClass.getEnumConstants()[ordinal];
    }

	@SuppressWarnings("unchecked")
	public void nullSafeSet(final PreparedStatement st, final Object value,
			final int index) throws SQLException {
		if (value == null) {
			st.setNull(index, Hibernate.STRING.sqlType());
		} else {
			st.setShort(index, (short) ((Enum) value).ordinal());
		}
	}

    /*
    License
    ---------------------------------------------------------------------------

    This product includes software developed by
    the Apache Software Foundation (http://www.apache.org/).

    This software is distributed as open source.
    The following disclaimer applies to all files
    (not any included 3rd party libraries) distributed in
    this package:

    Copyright (c) 2005, Christian Bauer <christian@hibernate.org>
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:

    - Redistributions of source code must retain the above copyright notice, this
    list of conditions and the following disclaimer.

    - Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

    Neither the name of the original author nor the names of contributors may be
    used to endorse or promote products derived from this software without
    specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
    ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
    INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
    CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
    ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
    THE POSSIBILITY OF SUCH DAMAGE.
    */
}
