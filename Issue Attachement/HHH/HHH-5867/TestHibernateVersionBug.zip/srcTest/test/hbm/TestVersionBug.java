package test.hbm;

import java.util.List;

import junit.framework.Assert;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.junit.Test;

import test.hbm.domain.MyComponent;
import test.hbm.domain.MyObject;

public class TestVersionBug {

	@Test
	public void testIncreaseVersionOnReadBug() {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		//create myObject
		Transaction transaction = session.beginTransaction();
		MyComponent sourceInfo = new MyComponent();
		MyObject myObject = new MyObject("myObject", sourceInfo);
		session.save(myObject);
		transaction.commit();
		
		int initialVersion = myObject.get_version();
		
		System.out.println("MyObject Id:"+myObject.get_id());
		System.out.println("MyObject Version:"+myObject.get_version());
		
		//read myObject, version should not increase here
		Transaction tx = session.beginTransaction();
		Criteria crit = session.createCriteria(MyObject.class);
		crit.add(Restrictions.idEq(myObject.get_id()));
		List<MyObject> results = crit.list();
		MyObject myObj = (MyObject) results.get(0);
		tx.commit();
		
		System.out.println("MyObject Id:"+myObj.get_id());
		System.out.println("MyObject Version:"+myObj.get_version());

		//version has increased, because of read only operation
		Assert.assertEquals(initialVersion, myObj.get_version());
		
		
		session.close();
	}
}
