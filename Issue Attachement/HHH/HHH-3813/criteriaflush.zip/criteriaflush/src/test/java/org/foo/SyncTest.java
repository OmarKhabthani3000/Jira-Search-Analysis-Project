package org.foo;

import java.util.HashSet;

import junit.framework.TestCase;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class SyncTest extends TestCase {

	private SessionFactory sessionFactory;
	private Session session;

	@Override
	protected void setUp() throws Exception {
		Configuration cfg = new Configuration();
		cfg.configure();
		sessionFactory = cfg.buildSessionFactory();
		session = sessionFactory.openSession();
	}

	@Override
	protected void tearDown() throws Exception {
		session.close();
		sessionFactory.close();
	}

	public void test1() throws Exception {
		Transaction tx = session.beginTransaction();
		try {
			User user1 = createUser(1);

			Criteria criteria = session.createCriteria(User.class);
			criteria.createAlias("items", "items");
			criteria.add(Restrictions.eq("items.name", "item1"));
			User result = (User) criteria.uniqueResult();
			// User result = (User) session.createQuery("select u from User u join u.items i where i.name='item1'").uniqueResult();
			assertEquals(user1, result);
		} finally {
			tx.rollback();
		}
	}

	private User createUser(int index) {
		User user = new User();
		user.setName("user" + index);
		user.setItems(new HashSet<Item>());

		Item item = new Item();
		item.setName("item" + index);
		user.getItems().add(item);

		session.save(user);
		return user;
	}

}
