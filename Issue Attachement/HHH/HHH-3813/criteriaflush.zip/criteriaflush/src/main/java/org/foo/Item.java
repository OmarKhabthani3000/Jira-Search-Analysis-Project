package org.foo;

import java.util.List;

public class Item extends BaseEntity {
}
