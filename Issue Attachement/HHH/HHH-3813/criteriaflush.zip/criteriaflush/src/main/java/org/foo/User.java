package org.foo;

import java.util.Set;

public class User extends BaseEntity {
	private Set<Item> items;

	public Set<Item> getItems() {
		return items;
	}

	public void setItems(Set<Item> items) {
		this.items = items;
	}
}
