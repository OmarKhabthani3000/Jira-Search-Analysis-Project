package com.example.demo;

import com.example.demo.entity.DefinitionA;
import com.example.demo.entity.Organization;
import com.example.demo.entity.PhysicalAspect;
import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.transaction.annotation.Transactional;

@DataJpaTest
@Transactional(rollbackFor = Exception.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class EagerLoadingEntityGraphTest {

    @PersistenceContext
    private EntityManager entityManager;

    private Organization organization;

    @BeforeEach
    void setUp() {
        organization = new Organization("myOrg");
        entityManager.persist(organization);

        PhysicalAspect physicalAspect = new PhysicalAspect(organization);
        entityManager.persist(physicalAspect);

        DefinitionA definitionA = new DefinitionA(physicalAspect);
        definitionA.setModuleWidth(10);
        entityManager.persist(definitionA);

        physicalAspect.setDefinition(definitionA);

        entityManager.flush();
    }

    /**
     * Succeeds with Hibernate 5.6.11.Final, where it fails with Hibernate 6.0+
     */
    @Test
    void testEagerloadingByNamedEntityGraphAnnotationSucceeds() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<PhysicalAspect> query = cb.createQuery(PhysicalAspect.class);
        Root<PhysicalAspect> aspect = query.from(PhysicalAspect.class);
        Path<String> organizationPath = aspect.get("organization");

        EntityGraph<?> graph = this.entityManager.getEntityGraph("Item.characteristics");
        CriteriaQuery<PhysicalAspect> where = query
                .select(aspect)
                .where(cb.equal(organizationPath, organization));

        entityManager.createQuery(where).setHint("javax.persistence.fetchgraph", graph).getResultList();
    }

}