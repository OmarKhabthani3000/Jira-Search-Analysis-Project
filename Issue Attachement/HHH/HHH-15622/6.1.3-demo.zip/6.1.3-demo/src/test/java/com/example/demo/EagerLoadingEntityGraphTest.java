package com.example.demo;

import com.example.demo.entity.DefinitionA;
import com.example.demo.entity.Organization;
import com.example.demo.entity.PhysicalAspect;
import jakarta.persistence.EntityGraph;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Root;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.transaction.annotation.Transactional;

@DataJpaTest
@Transactional(rollbackFor = Exception.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class EagerLoadingEntityGraphTest {

    @PersistenceContext
    private EntityManager entityManager;

    private Organization organization;

    @BeforeEach
    void setUp() {
        organization = new Organization("myOrg");
        entityManager.persist(organization);

        PhysicalAspect physicalAspect = new PhysicalAspect(organization);
        entityManager.persist(physicalAspect);

        DefinitionA definitionA = new DefinitionA(physicalAspect);
        definitionA.setModuleWidth(10);
        entityManager.persist(definitionA);

        physicalAspect.setDefinition(definitionA);

        entityManager.flush();
    }

    /**
     * Fails with org.postgresql.util.PSQLException: ERROR: operator does not exist: uuid = character varying
     * Sql:
     * select p1_0.id,d1_0.parent_id,d1_0.dtype,d1_0.organization_id,d1_0.module_width,p1_0.organization_id from physical_aspect p1_0 left join physical_aspect_definition d1_0 on p1_0.id=d1_0.dtype where p1_0.organization_id=?
     * Sql error:
     * ... p1_0.id=d1_0.dtype <- discriminator column
     */
    @Test
    void testEagerloadingByNamedEntityGraphAnnotationFails() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<PhysicalAspect> query = cb.createQuery(PhysicalAspect.class);
        Root<PhysicalAspect> aspect = query.from(PhysicalAspect.class);
        Path<String> organizationPath = aspect.get("organization");

        EntityGraph<?> graph = this.entityManager.getEntityGraph("Item.characteristics");
        CriteriaQuery<PhysicalAspect> where = query
                .select(aspect)
                .where(cb.equal(organizationPath, organization));

        entityManager.createQuery(where).setHint("javax.persistence.fetchgraph", graph).getResultList();
    }

}