package test;

public class IdGen
{
    protected static volatile long id=2009219112005957001L;
    
    public static synchronized long next()
    {
        return id++;
    }

}
