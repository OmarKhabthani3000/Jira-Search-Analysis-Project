package test.model;

import java.util.Map;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import test.IdGen;

public class EntityA
{
    protected long id;
    protected String name;
    protected Map<EntityB,Integer> testMapEntityB;

    public EntityA()
    {
        id=IdGen.next();
    }
    public EntityA(String name)
    {
        this();
        setName(name);
    }
    
    
    public long getId()
    {
        return id;
    }
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public Map<EntityB, Integer> getTestMapEntityB()
    {
        return testMapEntityB;
    }
    public void setTestMapEntityB(Map<EntityB, Integer> testMapEntityB)
    {
        this.testMapEntityB = testMapEntityB;
    }
    @Override
    public String toString()
    {
        return ToStringBuilder.reflectionToString(this,ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
