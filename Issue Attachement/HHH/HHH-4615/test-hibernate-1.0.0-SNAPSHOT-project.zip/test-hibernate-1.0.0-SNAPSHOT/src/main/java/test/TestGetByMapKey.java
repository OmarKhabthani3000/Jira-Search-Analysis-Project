package test;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import test.model.EntityA;
import test.model.EntityB;

public class TestGetByMapKey
{
    public static void main(String[] args) throws Exception
    {
        Configuration cfg=new Configuration();
        cfg.addResource("mappings.hbm.xml");
        
        SessionFactory sf=cfg.buildSessionFactory();
        
        Session session=sf.openSession();
        
        EntityB b1=new EntityB("b1");
        session.save(b1);
        EntityB b2=new EntityB("b2");
        session.save(b2);
        EntityB b3=new EntityB("b3");
        session.save(b3);
        
        EntityA a1=new EntityA("a1");
        session.save(a1);
        
        EntityA a2=new EntityA("a2");
        a2.setTestMapEntityB(new HashMap<EntityB, Integer>());
        a2.getTestMapEntityB().put(b1, 1);
        a2.getTestMapEntityB().put(b3, 2);
        session.save(a2);
        
        session.flush();
        session.close();
        
        session=sf.openSession();
        
        System.err.flush(); System.out.flush();
        System.err.println("=== CASE 1 ==================================================================");
        try
        {
            List<?> result=session.createQuery("select distinct(a) from EntityA as a left join a.testMapEntityB as b where index(b).id=?")
                .setParameter(0, b1.getId())
                .list();
            System.err.println("Result: "+result);
        }
        catch (Exception ex)
        {
            System.err.flush(); System.out.flush();
            ex.printStackTrace();
        }
        
        System.err.flush(); System.out.flush();
        System.err.println("=== CASE 2 ==================================================================");
        try
        {
            List<?> result=session.createQuery("select distinct(a) from EntityA as a left join a.testMapEntityB as b where index(b)=?")
                .setParameter(0, b1.getId())
                .list();
            System.err.println("Result: "+result);
        }
        catch (Exception ex)
        {
            System.err.flush(); System.out.flush();
            ex.printStackTrace();
        }
        
        System.err.flush(); System.out.flush();
        System.err.println("=== CASE 3 ==================================================================");
        try
        {
            List<?> result=session.createQuery("select distinct(a) from EntityA as a left join a.testMapEntityB as b where index(b)=?")
                .setParameter(0, b1)
                .list();
            System.err.println("Result: "+result);
        }
        catch (Exception ex)
        {
            System.err.flush(); System.out.flush();
            ex.printStackTrace();
        }
    }
}
