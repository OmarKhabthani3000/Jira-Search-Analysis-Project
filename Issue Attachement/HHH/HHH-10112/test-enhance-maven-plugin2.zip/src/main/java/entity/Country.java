package entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.apache.commons.beanutils.PropertyUtils;

@Entity
public abstract class Country {
	private PropertyUtils utils;

	@Id
	@GeneratedValue
	private Long id;
}
