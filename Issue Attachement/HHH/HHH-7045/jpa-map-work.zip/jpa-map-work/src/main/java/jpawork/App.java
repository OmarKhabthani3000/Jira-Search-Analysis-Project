package jpawork;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import jpawork.model.ContainerEntity;
import jpawork.model.KeyEntity;
import jpawork.model.ValueEntity;

public class App
{
	public static void main(String[] args)
	{
		EntityManagerFactory emf = null;
		EntityManager em = null;

		try {
			emf = Persistence.createEntityManagerFactory("jpa-map-work");
			em = emf.createEntityManager();
			em.getTransaction().begin();

			ContainerEntity ce = new ContainerEntity();

			KeyEntity k1 = new KeyEntity();
			k1.handle = "k1";

			KeyEntity k2 = new KeyEntity();
			k2.handle = "k2";

			ValueEntity v1 = new ValueEntity();
			v1.key = k1;
			v1.value = "v1";
			v1.container = ce;
			ce.values.put(k1, v1);

			ValueEntity v2 = new ValueEntity();
			v2.key = k2;
			v2.value = "v2";
			v2.container = ce;
			ce.values.put(k2, v2);

			em.persist(ce);

			// display number of values
			System.out.println("Original number of entries in map: " + ce.values.size());

			// create new transaction
			em.getTransaction().commit();
			em.close();
			em = emf.createEntityManager();
			em.getTransaction().begin();

			// find our container and inspect the number of values
			ce = em.find(ContainerEntity.class, ce.id);
			System.out.println("Number of entries in map after reload: " + ce.values.size());

			// create new transaction
			em.getTransaction().commit();
			em.close();
			em = emf.createEntityManager();
			em.getTransaction().begin();

			// prime cache, load container, inspect
			em.createQuery("SELECT k FROM KeyEntity k", KeyEntity.class).getResultList();
			ce = em.find(ContainerEntity.class, ce.id);
			System.out.println("Number of entries in map after reload (primed cache): " + ce.values.size());
		} finally {
			if (em != null) em.close();
			if (emf != null) emf.close();
		}
	}
}
