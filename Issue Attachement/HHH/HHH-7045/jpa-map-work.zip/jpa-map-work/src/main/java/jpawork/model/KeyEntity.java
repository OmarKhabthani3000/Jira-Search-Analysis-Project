package jpawork.model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
public class KeyEntity implements Serializable
{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	public Long id;

	@Column(nullable = false, unique = true)
	public String handle;

	@Override
	public boolean equals(Object o) {
		KeyEntity oke = (KeyEntity) o;
		return handle != null ? handle.equals(oke.handle) : oke.handle == null;
	}

	@Override
	public int hashCode() {
		return handle != null ? handle.hashCode() : 0;
	}
}
