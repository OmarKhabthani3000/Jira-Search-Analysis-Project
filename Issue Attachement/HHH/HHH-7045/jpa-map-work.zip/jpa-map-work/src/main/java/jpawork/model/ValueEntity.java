package jpawork.model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
public class ValueEntity implements Serializable
{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	public Long id;

	@ManyToOne(cascade = CascadeType.ALL)
	public KeyEntity key;

	public String value;

	@ManyToOne(cascade = CascadeType.ALL)
	public ContainerEntity container;

	@Override
	public boolean equals(Object o) {
		ValueEntity ove = (ValueEntity) o;
		return key != null ? key.equals(ove.key) : ove.key == null;
	}

	@Override
	public int hashCode() {
		return key != null ? key.hashCode() : 0;
	}
}
