package jpawork.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.persistence.*;

@Entity
public class ContainerEntity implements Serializable
{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	public Long id;

	@OneToMany(mappedBy = "container", cascade = CascadeType.ALL)
	@MapKeyJoinColumn(name = "key_id")
	public Map<KeyEntity, ValueEntity> values = new HashMap<KeyEntity, ValueEntity>();
}
