package org.hibernate.bugs;

import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Parent {

    @Id
    private String id;
    @Embedded
    private Child child;
}
