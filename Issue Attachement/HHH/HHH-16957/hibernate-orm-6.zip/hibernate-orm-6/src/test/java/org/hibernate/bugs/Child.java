package org.hibernate.bugs;

import jakarta.persistence.Embeddable;
import org.hibernate.annotations.Generated;
import org.hibernate.generator.EventType;

@Embeddable
public class Child {
    private String prop1;
    @Generated(event = {EventType.INSERT, EventType.UPDATE})
//    @Generated(value = GenerationTime.ALWAYS)
    private String prop2;
}
