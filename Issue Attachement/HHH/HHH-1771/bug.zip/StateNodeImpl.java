package com.pvs.pmm.client.state;

import java.util.Map;

public class StateNodeImpl {
	
	public StateNodeImpl(ApplicationState state, String name, Long defaultState) {
		this.parentApplicationState = state;
		this.stateName = name;
		this.stateValue = defaultState;
	}

	private Long id;
	private String stateName;
	private Long stateValue;
	
	private StateNodeImpl parentState;
	private ApplicationState parentApplicationState;
	private StateNodeState parentStateState;
	
	private Map<String, StateNodeState> currentState;

	public Map<String, StateNodeState> getCurrentState() {
		return currentState;
	}

	public void setCurrentState(Map<String, StateNodeState> currentState) {
		this.currentState = currentState;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ApplicationState getParentApplicationState() {
		return parentApplicationState;
	}

	public void setParentApplicationState(ApplicationState parentApplicationState) {
		this.parentApplicationState = parentApplicationState;
	}

	public StateNodeImpl getParentState() {
		return parentState;
	}

	public void setParentState(StateNodeImpl parentState) {
		this.parentState = parentState;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public Long getStateValue() {
		return stateValue;
	}

	public void setStateValue(Long stateValue) {
		this.stateValue = stateValue;
	}

	public StateNodeState getParentStateState() {
		return parentStateState;
	}

	public void setParentStateState(StateNodeState parentStateState) {
		this.parentStateState = parentStateState;
	}

	

}
