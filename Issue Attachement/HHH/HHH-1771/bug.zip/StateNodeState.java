package com.pvs.pmm.client.state;

public class StateNodeState {
	
	private StateNodeStatePK id;
	private StateNodeImpl state;
	
	public StateNodeStatePK getId() {
		return id;
	}
	public void setId(StateNodeStatePK id) {
		this.id = id;
	}
	public StateNodeImpl getState() {
		return state;
	}
	public void setState(StateNodeImpl state) {
		this.state = state;
	}

}
