package com.pvs.pmm.client.state;

import java.io.Serializable;

public class StateNodeStatePK implements Serializable {
	
	private StateNodeImpl parentNode;
	private String stateName;
	
	public StateNodeImpl getParentNode() {
		return parentNode;
	}
	public void setParentNode(StateNodeImpl parentNode) {
		this.parentNode = parentNode;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	
	

}
