package dbtest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App {

    public static void main(String[] args) {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("testPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Long siteId=1L;
        for (int i = 0; i < 10; i++) {
            Job j = new Job();
            j.setName("job" + Math.random() * 10);
            j.setSiteId(siteId);
            em.persist(j);
        }
       
        em.getTransaction().commit();
        em.close();
        emf.close();

    }
}
