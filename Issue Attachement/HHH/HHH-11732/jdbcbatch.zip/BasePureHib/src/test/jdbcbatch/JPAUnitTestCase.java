package test.jdbcbatch;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Environment;
import org.junit.Before;
import org.junit.Test;

public class JPAUnitTestCase {
	private SessionFactory sf;

	@Before
	public void setup() {
		StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
				// Add in any settings that are specific to your test. See resources/hibernate.properties for the defaults.
				.applySetting("hibernate.show_sql", "true")
				.applySetting("hibernate.format_sql", "true")
				.applySetting(Environment.STATEMENT_BATCH_SIZE, "10")
				//				.applySetting("hibernate.hbm2ddl.auto", "update");
				.configure("test/jdbcbatch/hibernate.cfg.xml");

		Metadata metadata = new MetadataSources(srb.build())
				// Add your entities here.
				//	.addAnnotatedClass( Foo.class )
				.buildMetadata();

		sf = metadata.buildSessionFactory();
	}

	// Add your tests, using standard JUnit.

	@Test
	public void hhh123Test() throws Exception {
		StatelessSession session = sf.openStatelessSession();
		Transaction tx = session.beginTransaction();

		try {
			int id = 0;

			Employee employee = new Employee("1", "2", 1);
			employee.setId(id++);
			session.insert(employee);

			tx.rollback();
		}
		catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		}
		finally {
			session.close();
		}
	}
}
