package org.example.testcase;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.transaction.TestTransaction;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class TestcaseApplicationTests {

	@Autowired
	private EntityManager em;

	@Test
	public void failsOnPersist() {
		// create and persist one entity
		OtherEntity otherEntity = new OtherEntity();
		em.persist(otherEntity);

		// create a second entity referencing the first
		SomeEntity entity = new SomeEntity();
		entity.setOtherEntity(otherEntity);

		// fails on persist
		em.persist(entity);
	}
}
