
CREATE TABLE product (
    id INTEGER UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE `order` (
   id INTEGER UNSIGNED NOT NULL,
   total DECIMAL(13,2) NOT NULL,
   PRIMARY KEY (id)
);

CREATE TABLE orderItem (
   order_id INTEGER UNSIGNED NOT NULL,
   product_id INTEGER UNSIGNED NOT NULL,
   PRIMARY KEY (order_id, product_id),
   FOREIGN KEY (order_id) REFERENCES `order`(id),
   FOREIGN KEY (product_id) REFERENCES product(id)
);

INSERT INTO product VALUES (1, "Product1"),(2, "Product2");
INSERT INTO `order` VALUES (1, 100);
INSERT INTO orderItem VALUES (1, 1),(1, 2);
