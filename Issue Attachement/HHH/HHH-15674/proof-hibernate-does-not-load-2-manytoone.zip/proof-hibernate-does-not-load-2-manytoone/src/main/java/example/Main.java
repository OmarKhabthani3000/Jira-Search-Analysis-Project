package example;

import example.entities.Order;
import example.entities.Product;
import example.entities.OrderItem;
import org.hibernate.Hibernate;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.jpa.QueryHints;
import org.hibernate.jpa.SpecHints;

public class Main {

    public static OrderItem fetch(SessionFactory sessionFactory, long id, String graph) {
        try (var session = sessionFactory.openSession()) {
            return session.createQuery("SELECT e FROM OrderItem e WHERE e.order.id = :id AND e.product.id = 1", OrderItem.class)
                    .setParameter("id", id)
                    .setHint(QueryHints.JAKARTA_HINT_FETCHGRAPH, sessionFactory.createEntityManager().getEntityGraph(graph))
//                    .setHint(SpecHints.HINT_SPEC_FETCH_GRAPH, sessionFactory.createEntityManager().getEntityGraph(graph))
//                    .setHint(SpecHints.HINT_SPEC_LOAD_GRAPH, sessionFactory.createEntityManager().getEntityGraph(graph))
                    .getSingleResult();
        }
    }

    public static void main(String[] args) {
        var standardRegistry = new StandardServiceRegistryBuilder().build();
        var sources = new MetadataSources(standardRegistry);
        sources.addAnnotatedClass(Product.class);
        sources.addAnnotatedClass(Order.class);
        sources.addAnnotatedClass(OrderItem.class);

        var configuration = new Configuration(sources);
        configuration.setProperty("hibernate.connection.url", "jdbc:mariadb://localhost/test2");
        configuration.setProperty("hibernate.connection.username", "root");
        configuration.setProperty("hibernate.connection.password", "MySQ7Admin");
        configuration.setProperty("hibernate.show_sql", "true");
        //configuration.setProperty("hibernate.format_sql", "true");

        try(var sessionFactory = configuration.buildSessionFactory()) {
            var result = fetch(sessionFactory, 1L, "OrderItem.withAll");
            var product = Hibernate.isInitialized(result.getProduct());
            var order = Hibernate.isInitialized(result.getOrder());
            System.out.println("order: " + order);
            System.out.println("product: " + product);
            System.out.println("item: " + result.getProduct().getName() + " : " + result.getOrder().getTotal());
        }
    }
}
