package example.entities;

import jakarta.persistence.*;

import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "orderItem")
@IdClass(OrderItem.PK.class)
@NamedEntityGraph(
    name = "OrderItem.withAll",
    attributeNodes = {
        @NamedAttributeNode("product"),
        @NamedAttributeNode("order"),
    }
)
public class OrderItem {

    @Id
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "product_id")
    private Product product;

    @Id
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "order_id")
    private Order order;

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public static class PK implements Serializable {
        private Long product;
        private Long order;

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            PK pk = (PK) o;
            return Objects.equals(product, pk.product) && Objects.equals(order, pk.order);
        }

        @Override
        public int hashCode() {
            return Objects.hash(product, order);
        }
    }
}
