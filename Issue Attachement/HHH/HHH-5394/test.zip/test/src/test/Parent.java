package test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Parent {

	private String name = "parent";

	public String getName() {
		return name;
	}

	public void setName( String name ) {
		this.name = name;
	}

	private Long moid;

	public Long getMoid() {
		return this.moid;
	}

	private void setMoid( Long moid ) {
		this.moid = moid;
	}

	public String displayName = "";

	public void setDisplayName( String dName ) {

		this.displayName = dName;
	}

	public String getDisplayName() {

		return displayName;
	}

	Set members = new HashSet();

	public Set getMembers() {

		return this.members;
	}

	public void setMembers( Set<String> members1 ) {
		this.members = members1;
	}

	private List<Parent> children;

	public List<Parent> getChildren() {
		return children;
	}

	public void setChildren( List<Parent> keys ) {
		this.children = keys;
	}

	private Parent parentId;

	public Parent getParentId() {
		return parentId;
	}

	public void setParentId( Parent parentId ) {
		this.parentId = parentId;
	}

}
