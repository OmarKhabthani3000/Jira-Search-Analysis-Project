package test;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import org.hibernate.stat.Statistics;

import java.io.Serializable;
import java.util.*;
import test.HibernateUtil;
import org.hibernate.criterion.*;
import org.hibernate.type.*;

public class TestManager {

	public static void main( String[] args ) {
		try {
			TestManager mgr = new TestManager();
			String opr = "add";
			String name = "webnms";

			if ( opr.equals( "add" ) ) {
				mgr.createAndStoreEvent( name );
			}
			HibernateUtil.getSessionFactory().getStatistics().logSummary();
			HibernateUtil.getSessionFactory().close();
		} catch ( Exception e ) {
			System.err.println( "EXCEPTION : " + e );
			e.printStackTrace();
		}

	}

	private void createAndStoreEvent( String name ) {
		addObject( name );
		Parent p2 = (Parent) getObject( name );
		System.out.println( "object fetched at first time------------> " + p2.getName() );
		updateObject( p2 );
		System.out.println( "object updated ---------------- " );
		Parent p3 = (Parent) getObject( name );
		System.out.println( "Object fecthed at second time----------->" + p3.getName() );

	}

	private void addObject( String name ) {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();

		Parent p6 = new Parent();
		p6.setName( name );
		p6.setDisplayName( "testing" );
		session.save( p6 );
		session.getTransaction().commit();

	}

	private Object getObject( String key ) {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		Criteria criteria = session.createCriteria( test.Parent.class );
		criteria.add( Restrictions.naturalId().set( "name", key ) );// No I18N
		criteria.setCacheable( true );
		Object obj = criteria.uniqueResult();
		session.getTransaction().commit();
		return obj;
	}

	private void updateObject( Parent p ) {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		p.setDisplayName( "test" );
		session.merge( p );
		session.getTransaction().commit();
	}

}
