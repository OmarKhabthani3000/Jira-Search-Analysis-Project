package test;


import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.connection.ConnectionProvider;



import java.sql.Connection;
import java.sql.SQLException;
public class HibernateUtil {
	
	private static SessionFactory sessionFactory;
    private static Configuration cfg;

    private static ConnectionProvider cp;
 
    static {
        try
                {
                       
            //load configuration from hibernate.cfg.xml
             cfg = new Configuration().configure();
             sessionFactory = cfg.buildSessionFactory();
             cp = ((org.hibernate.engine.SessionFactoryImplementor)sessionFactory).getConnectionProvider();
        } catch (Throwable ex) {

        	  // Make sure you log the exception, as it might be swallowed
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    /**
     * for internal purpose.
     */

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    /**
     * Gets the Hibernate Configuration instance.
     * @return Configuration
     */
    public static Configuration getConfiguration()
    {
            return cfg;
    }


    public static Connection getConnection() throws SQLException
    {
                   return cp.getConnection();
    }

}
