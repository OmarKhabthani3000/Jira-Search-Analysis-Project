//$Id:$
package org.hibernate.test.join;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Expression;
import org.hibernate.test.TestCase;

/**
 * @author Emmanuel Bernard
 */
public class BiDirJoinTest extends TestCase {

	public BiDirJoinTest(String x) {
		super(x);
	}
	
	public void testBiDir() throws Exception {
		Session s;
		Transaction tx;
		s = openSession();
		tx = s.beginTransaction();
		A a = new A();
		B b = new B();
		a.setName("ah");
		Set bs = new HashSet();
		//does not update the collection, it should work since its inverse="true"
		//bs.add(b);
		//a.setBs(bs);
		b.setA(a);
		s.create(b);
		tx.commit();
		s.close();
		
		s = openSession();
		tx = s.beginTransaction();
		
		B bb = (B) s.createCriteria(B.class).add(Expression.eq("id", b.getId())).uniqueResult();
		assertNotNull(bb);
		assertNotNull( bb.getA() );
		assertEquals( 1, bb.getA().getBs().size() );
		tx.commit();
		s.close();
		
		s = openSession();
		tx = s.beginTransaction();
		A aa = (A) s.createCriteria(A.class).add(Expression.eq("id", a.getId())).uniqueResult();
		assertNotNull(aa);
		assertNotNull( aa.getBs() );
		assertEquals( 1, aa.getBs().size() );
		//A use B.A_Id instead of BPlus.A_ID
		tx.commit();
		s.close();
	}

	/**
	 * @see org.hibernate.test.TestCase#getMappings()
	 */
	protected String[] getMappings() {
		return new String[] {
			"join/A.hbm.xml",
			"join/B.hbm.xml"
		};
	}

}
