//$Id:$
package org.hibernate.test.join;

/**
 * @author Emmanuel Bernard
 */
public class B {

	private Integer id;
	private A a;
	/**
	 * @return
	 */
	public A getA() {
		return a;
	}

	/**
	 * @return
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param a
	 */
	public void setA(A a) {
		this.a = a;
	}

	/**
	 * @param integer
	 */
	public void setId(Integer integer) {
		id = integer;
	}

}
