//$Id:$
package org.hibernate.test.join;

import java.util.Set;

/**
 * @author Emmanuel Bernard
 */
public class A {

	private Integer id;
	private Set bs;
	private String name;
	/**
	 * @return
	 */
	public Set getBs() {
		return bs;
	}

	/**
	 * @return
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param set
	 */
	public void setBs(Set set) {
		bs = set;
	}

	/**
	 * @param integer
	 */
	public void setId(Integer integer) {
		id = integer;
	}

	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param string
	 */
	public void setName(String string) {
		name = string;
	}

}
