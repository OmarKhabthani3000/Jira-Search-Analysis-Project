package test.service;

import static org.junit.Assert.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import test.entity.A;
import test.entity.B;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"../localDbConfig.xml"})
public class TestService {
    @PersistenceUnit
    private EntityManagerFactory emf;
    
    protected final static Logger logger = Logger.getLogger(TestService.class);
    
    @Test
    public void service() {
	int id = createA();
	int bsBefore = countBs();
	bug(id);
	int bsAfter = countBs();
	assertEquals(1, bsAfter - bsBefore);
    }

    private int createA() {
	EntityManager em = null;
	int id = 0;
	try {
	    em = emf.createEntityManager();
	    em.getTransaction().begin();
	    A a = new A();
	    em.persist(a);
	    em.getTransaction().commit();
	    id = a.getId();
	} catch (Exception e) {
	    if (em.getTransaction().isActive())
		em.getTransaction().rollback();
	} finally {
	    if (em != null && em.isOpen())
		em.close();
	}
	return id;
    }

    private void bug(int id) {
	EntityManager em = null;
	try {
	    em = emf.createEntityManager();
	    em.getTransaction().begin();

	    A a = em.find(A.class, id);

	    B b = new B();
	    a.getBs().add(0, b);

	    // The following line triggers the bug:
	    em.merge(a);

	    em.getTransaction().commit();
	} catch (Exception e) {
	    if (em.getTransaction().isActive())
		em.getTransaction().rollback();
	} finally {
	    if (em != null && em.isOpen())
		em.close();
	}
    }

    private int countBs() {
	EntityManager em = null;
	try {
	    em = emf.createEntityManager();
	    return ((Number) em.createQuery("select count(*) from B")
		    .getSingleResult()).intValue();
	} finally {
	    if (em != null && em.isOpen())
		em.close();
	}
    }
}
