package test.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class B {
    private int id;
    private A a;
    /**
     * @return the id
     */
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public int getId() {
        return id;
    }
    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * @return the a
     */
    @ManyToOne
    public A getA() {
        return a;
    }
    /**
     * @param a the a to set
     */
    public void setA(A a) {
        this.a = a;
    }
    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((a == null) ? 0 : a.hashCode());
	result = prime * result + id;
	return result;
    }
    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (obj == null)
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	B other = (B) obj;
	if (a == null) {
	    if (other.a != null)
		return false;
	} else if (!a.equals(other.a))
	    return false;
	if (id != other.id)
	    return false;
	return true;
    }
}
