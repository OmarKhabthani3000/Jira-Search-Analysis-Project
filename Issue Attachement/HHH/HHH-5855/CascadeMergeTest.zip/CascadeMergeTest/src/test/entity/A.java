package test.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class A {
    private int id;
    
    private List<B> bs = new ArrayList<B>();

    /**
     * @return the id
     */
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the bs
     */
    @OneToMany(mappedBy="a", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
    public List<B> getBs() {
        return bs;
    }

    /**
     * @param bs the bs to set
     */
    public void setBs(List<B> bs) {
        this.bs = bs;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((bs == null) ? 0 : bs.hashCode());
	result = prime * result + id;
	return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (obj == null)
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	A other = (A) obj;
	if (bs == null) {
	    if (other.bs != null)
		return false;
	} else if (!bs.equals(other.bs))
	    return false;
	if (id != other.id)
	    return false;
	return true;
    }
}
