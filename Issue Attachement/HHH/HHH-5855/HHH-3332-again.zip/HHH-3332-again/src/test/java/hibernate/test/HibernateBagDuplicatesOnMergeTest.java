package hibernate.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.junit.Test;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertEquals;

/**
 * Test adapted from the test code submitted for from https://hibernate.atlassian.net/browse/HHH-3799
 * The purpose of this is to prove HHH-3332 still replicates.
 */
public class HibernateBagDuplicatesOnMergeTest {


    @Test
    public void test() {
        final Long containerId;
        final SessionFactory sf = buildSessionFactory();

        { // populate database with a container
            Session session = sf.openSession();
            Transaction txn = session.beginTransaction();

            Container container = new Container();
            session.persist(container);
            containerId = container.id;

            txn.commit();
            session.close();
        }

        {
            Session session = sf.openSession();
            Transaction txn = session.beginTransaction();

            Container loadContainer = (Container) session.createQuery("from Container where id = " + containerId).uniqueResult();

            loadContainer.addItem(new Item("item1"));
            loadContainer.addItem(new Item("item2"));

            session.merge(loadContainer);

            txn.commit();
            session.close();
        }


        { // this passes, when the container is loaded directly
            Session session = sf.openSession();
            Transaction txn = session.beginTransaction();

            Container loadContainer = (Container) session.createQuery("from Container where id = " + containerId).uniqueResult();

            assertEquals(2, loadContainer.items.size());

            txn.rollback();
            session.close();
        }

    }

    private SessionFactory buildSessionFactory() {
        Properties props = new Properties();
        props.put("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.put("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        props.put("hibernate.connection.url", "jdbc:hsqldb:mem:test");
        props.put("hibernate.connection.username", "sa");
        props.put("hibernate.connection.password", "");
        props.put("hibernate.hbm2ddl.auto", "create");
        props.put("hibernate.show_sql", "true");

        AnnotationConfiguration cfg = new AnnotationConfiguration();
        cfg.setProperties(props);
        cfg.addAnnotatedClass(Item.class);
        cfg.addAnnotatedClass(Container.class);

        return cfg.buildSessionFactory();
    }

    /**
     * simple container for items
     */
    @Entity(name = "Container")
    private static class Container {
        @Id
        @GeneratedValue
        Long id;

        @OneToMany(cascade = CascadeType.ALL, mappedBy = "container", orphanRemoval = true)
        List<Item> items = new ArrayList<Item>();

        void addItem(Item item) {
            items.add(item);
            item.container = this;
        }
    }

    /**
     * simple item
     */
    @Entity(name = "Item")
    private static class Item {
        @Id
        @GeneratedValue
        Long id;

        @ManyToOne
        Container container;

        String name;

        Item() {

        }

        Item(String name) {
            this.name = name;
        }
    }

}
