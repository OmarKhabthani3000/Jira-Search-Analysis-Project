package org.hibernate.ejb.test.hhh5081;

import javax.persistence.Embeddable;

@Embeddable
public class Address {

    private String street;

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }
}
