package org.hibernate.ejb.test.hhh5081;

import java.io.Serializable;

public class Email implements Serializable {
    private String domain;
    private String address;

    public Email() {
    }

    public Email(String address, String domain) {
        this.domain = domain;
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    @Override
    public String toString() {
        return getAddress() + "@" + getDomain();
    }
}
