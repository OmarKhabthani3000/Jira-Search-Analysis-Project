package org.hibernate.ejb.test.hhh5081;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.ejb.test.TestCase;

public class TestEmployeeDAO extends TestCase {

    private void saveEntity(EntityManager em) {
        Employee employee = new Employee();
        employee.setName("Test");
        employee.setEmail(new Email("James","test.org")); // THIS SAID new Email("Test","test.org")
        em.persist(employee);
		em.flush();
    }

    public void testFindEntityByJPAQLQuery() {
		EntityManager em = getOrCreateEntityManager();
		em.getTransaction().begin();
        
		saveEntity(em);
		TypedQuery<Employee> query = em.createQuery("select e from Employee e where e.email = :email", Employee.class);
		query.setParameter("email", new Email("James","test.org"));
		
        Employee employee = query.getSingleResult();
        assertEquals("James@test.org", employee.getEmail().toString());

        em.remove(employee);
		em.getTransaction().commit();
		em.close();
    }

    public void testFindEntityByCriteriaQuery() {
		EntityManager em = getOrCreateEntityManager();
		em.getTransaction().begin();
		
		saveEntity(em);
		CriteriaQuery<Employee> cq = em.getCriteriaBuilder().createQuery(Employee.class);
		Root<Employee> root = cq.from(Employee.class);
		cq.where(em.getCriteriaBuilder().equal(root.get("email"), new Email("James","test.org")));
		TypedQuery<Employee> query = em.createQuery(cq);

		Employee employee = query.getSingleResult();
        assertEquals("James@test.org", employee.getEmail().toString());

        em.remove(employee);
		em.getTransaction().commit();
		em.close();
    }

	@Override
	protected Class<?>[] getAnnotatedClasses() {
		return new Class<?>[] {org.hibernate.ejb.test.hhh5081.Address.class,
				org.hibernate.ejb.test.hhh5081.Email.class,
				org.hibernate.ejb.test.hhh5081.EmailType.class,
				org.hibernate.ejb.test.hhh5081.Employee.class};

	}
}
