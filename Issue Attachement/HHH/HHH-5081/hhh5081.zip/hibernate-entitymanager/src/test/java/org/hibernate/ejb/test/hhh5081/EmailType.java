package org.hibernate.ejb.test.hhh5081;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.hibernate.HibernateException;
import org.hibernate.type.EnumType;
import org.hibernate.type.StringType;
import org.hibernate.usertype.UserType;


@SuppressWarnings("serial")
public class EmailType implements UserType, Serializable {

    private int sqlType = Types.VARCHAR;

    public int[] sqlTypes() {
        return new int[] { sqlType };
    }

    public Object nullSafeGet(ResultSet rs, String[] names, Object owner) throws HibernateException, SQLException {
        String object = rs.getString( names[0] );
        if ( rs.wasNull() ) {
            return null;
        }
        Email email = (Email) new Email();
        email.setAddress(object.substring(0, object.indexOf("@")));
        email.setDomain(object.substring(object.indexOf("@")+1));
        return email;
    }

    public void nullSafeSet(PreparedStatement st, Object value, int index) throws HibernateException, SQLException {
        if ( value == null ) {
            st.setNull( index, sqlType );
        }
        else {
            Email email = (Email) value;
            st.setString( index, email.toString());
        }
    }

    public Object assemble(Serializable cached, Object owner)
            throws HibernateException {
        return null;
    }

    public Object deepCopy(Object value) throws HibernateException {
        return value;
    }

    public Serializable disassemble(Object value) throws HibernateException {
        return null;
    }

    public boolean equals(Object x, Object y) throws HibernateException {
        return x == y;
    }

    public int hashCode(Object x) throws HibernateException {
        return x.hashCode();
    }

    public boolean isMutable() {
        return true;
    }

    public Object replace(Object original, Object target, Object owner)
            throws HibernateException {
        return original;
    }

    public Class returnedClass() {
        return Email.class;
    }
}
