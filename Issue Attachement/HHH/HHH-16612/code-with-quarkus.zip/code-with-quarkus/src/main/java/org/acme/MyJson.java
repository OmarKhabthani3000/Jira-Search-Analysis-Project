
package org.acme;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Embeddable;

/**
 * @since 09.05.2023
 */
@Embeddable
@Access( AccessType.PROPERTY )
public class MyJson {

    private String stringProp;
    private Long longProp;

    public String getStringProp() {
        return stringProp;
    }

    public void setStringProp(String aStringProp) {
        this.stringProp = aStringProp;
    }

    public Long getLongProp() {
        return longProp;
    }

    public void setLongProp(Long aLongProp) {
        this.longProp = aLongProp;
    }
}
