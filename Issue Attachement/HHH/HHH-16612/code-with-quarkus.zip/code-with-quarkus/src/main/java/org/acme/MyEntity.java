package org.acme;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
@Table(name = "MY_ENTITY", schema = "base") //with explict table-name & schema it won't work
public class MyEntity {

    @Id
    @Column
    public Long id;

    @JdbcTypeCode(SqlTypes.JSON)
    MyJson jsonProperty;
}
