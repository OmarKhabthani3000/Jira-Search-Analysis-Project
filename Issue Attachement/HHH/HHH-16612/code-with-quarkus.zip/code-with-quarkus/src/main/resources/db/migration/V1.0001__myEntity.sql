CREATE SCHEMA IF NOT EXISTS base;
comment on schema base is 'datamodel for service-base-service management';

CREATE TABLE IF NOT EXISTS base.my_entity
(
    id 				bigint ,
    LOCALIZED_JSON_STRING json
);