package org.acme;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Tuple;
import jakarta.transaction.Transactional;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/**
 *
 * @since 09.05.2023
 */
@QuarkusTest
class MyEntityTest {

    @Inject
    EntityManager em;
    private static final long PK = 123L;

    @Test
    @Transactional
    void shouldQueryMyEntity() throws Exception {
        insert();
        findAndUpdate();
        List<MyEntity> resultWithoutFilter = selectWithoutFilter();
        selectFiltered();
        
    }

    @Transactional
    void findAndUpdate() {
        MyEntity found = em.find(MyEntity.class, PK);
        found.jsonProperty.setStringProp("TEST");
    }

    @Transactional
    void selectFiltered() {
        //then
        List<Tuple> resultWithFilter = em
                .createQuery("SELECT e FROM MyEntity e WHERE e.jsonProperty.longProp = :x", Tuple.class)
                                .setParameter("x", 100L)
                .getResultList();
        assertEquals(1, resultWithFilter.size());
    }


    @Transactional
    List<MyEntity> selectWithoutFilter() {
        List<MyEntity> resultWithoutFilter = em
                .createQuery("SELECT e FROM MyEntity e", MyEntity.class)
                .getResultList();
        assertEquals(1, resultWithoutFilter.size());
        return resultWithoutFilter;
    }

    @Transactional(Transactional.TxType.REQUIRES_NEW)
    void insert() {
        //given
        MyEntity myEntity = new MyEntity();
        myEntity.id = PK;
        MyJson myJson = new MyJson();
        myJson.setLongProp(100L);
        myJson.setStringProp("Hallo");
        myEntity.jsonProperty = myJson;
//        myEntity.jsonProperty = new HashMap<>(Map.of("x", "Y"));
        //when
        em.persist(myEntity);
    }
}
