package be.test;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class ViaAnnotations {

	@Id
	@GeneratedValue(generator = "viaAnnotations")
	@SequenceGenerator(name = "viaAnnotations", sequenceName = "via_annotations", initialValue = 1, allocationSize = 20)
	private Long id;
}
