package be.test;

/**
 * Created by koen on 28/04/15.
 */

import static org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType.H2;
import static org.testng.Assert.assertEquals;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.GenerationType;
import javax.persistence.SequenceGenerator;
import javax.persistence.TableGenerator;
import javax.sql.DataSource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataBuilder;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.SessionFactoryBuilder;
import org.hibernate.boot.model.IdGeneratorStrategyInterpreter;
import org.hibernate.boot.model.IdentifierGeneratorDefinition.Builder;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.jdbc.Work;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.Test;

import be.test.HibernateTest.BootContext;

@Test
@ContextConfiguration(classes = BootContext.class)
public class HibernateTest extends AbstractTestNGSpringContextTests {

	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * -- THIS WORKS -- Via annotations interceptor is applied and increment value becomes 1
	 */
	public void testViaAnnotations() {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();

		session.save(new ViaAnnotations());
		session.flush();

		session.doWork(new Work() {
			@Override
			public void execute(final Connection connection) throws SQLException {
				CallableStatement statement = connection.prepareCall("call currval('via_annotations')");
				statement.execute();
				ResultSet rs = statement.getResultSet();
				rs.next();
				assertEquals(rs.getInt(1), 1);
			}
		});

		tx.rollback();
	}

	/**
	 * -- THIS DOES NOT WORK, BUT IT SHOULD -- Via XML interceptor is NOT applied and increment value remains 20
	 */
	public void testViaXml() {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();

		session.save(new ViaXml());
		session.flush();

		session.doWork(new Work() {
			@Override
			public void execute(final Connection connection) throws SQLException {
				CallableStatement statement = connection.prepareCall("call currval('via_xml')");
				statement.execute();
				ResultSet rs = statement.getResultSet();
				rs.next();
				assertEquals(rs.getInt(1), 1);
			}
		});

		tx.rollback();
	}

	@Configuration
	public static class BootContext {

		@Autowired
		private DataSource dataSource;

		@Bean
		public DataSource dataSource() {
			return new EmbeddedDatabaseBuilder().setType(H2).build();
		}

		@Bean
		public SessionFactory sessionFactory() {
			StandardServiceRegistryBuilder standardRegistryBuilder = new StandardServiceRegistryBuilder();
			standardRegistryBuilder.applySetting("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
			standardRegistryBuilder.applySetting("hibernate.connection.datasource", dataSource);
			standardRegistryBuilder.applySetting("hibernate.current_session_context_class", "thread");
			standardRegistryBuilder.applySetting("hibernate.hbm2ddl.auto", "create");
			StandardServiceRegistry standardRegistry = standardRegistryBuilder.build();

			MetadataSources sources = new MetadataSources(standardRegistry);
			sources.addAnnotatedClass(ViaAnnotations.class);
			sources.addResource("be/test/mapping.hbm.xml");

			MetadataBuilder metadataBuilder = sources.getMetadataBuilder();
			metadataBuilder.applyIdGenerationTypeInterpreter(new IdGeneratorStrategyInterpreter() {
				@Override
				public String determineGeneratorName(final GenerationType generationType, final GeneratorNameDeterminationContext context) {
					return generationType.name();
				}

				@Override
				public void interpretTableGenerator(final TableGenerator tableGeneratorAnnotation, final Builder definitionBuilder) {
				}

				@Override
				public void interpretSequenceGenerator(final SequenceGenerator sequenceGeneratorAnnotation, final Builder definitionBuilder) {
					definitionBuilder.addParam("increment_size", "1");
				}
			});

			Metadata metadata = metadataBuilder.build();

			SessionFactoryBuilder sessionFactoryBuilder = metadata.getSessionFactoryBuilder();

			return sessionFactoryBuilder.build();
		}
	}
}