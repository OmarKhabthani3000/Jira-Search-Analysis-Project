/*
 * gloxr-domain - Copyright (C) 2010 Semantix - http://www.semantix.com/
 * All rights reserved. Semantix PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.semantix.sandbox.hibtc;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

@Entity
public class Entry extends BaseEntity
  {
  private static final long serialVersionUID = -8721934932480175900L;

  @ManyToOne(fetch = FetchType.LAZY)
  protected EntryCollection entryCollection;
  @Basic
  protected String          form;

  // Recomendado por Hibernate - NO USAR DIRECTAMENTE!!!
  protected Entry( )
    {}

  Entry( EntryCollection entryCollection )
    {
    if( entryCollection != null )
      this.entryCollection = entryCollection;
    else
      throw new NullPointerException( );
    }

  public EntryCollection getEntryCollection( )
    {
    return this.entryCollection;
    }

  public String getForm( )
    {
    return this.form;
    }

  public void setForm( String form )
    {
    this.form = form;
    }
  }
