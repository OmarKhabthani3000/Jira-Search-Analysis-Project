/*
 * gloxr-domain - Copyright (C) 2010 Semantix - http://www.semantix.com/
 * All rights reserved. Semantix PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.semantix.sandbox.hibtc;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cascade;

@Entity
public class EntryCollection extends BaseEntity
  {
  private static final long serialVersionUID = -7413182343675889006L;

  @OneToMany(cascade = CascadeType.ALL, mappedBy = "entryCollection")
  @Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
  protected List<Entry>     entries          = new ArrayList<Entry>( );

  protected EntryCollection( )
    {}

  public Entry createEntry( )
    {
    Entry newEntry = new Entry( this );
    this.entries.add( newEntry );
    return newEntry;
    }

  public void removeEntry( Entry entry )
    {
    this.entries.remove( entry );
    }

  public List<Entry> getEntries( )
    {
    return Collections.unmodifiableList( this.entries );
    }
  }
