/*
 * gloxr-domain - Copyright (C) 2010 Semantix - http://www.semantix.com/
 * All rights reserved. Semantix PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.semantix.sandbox.hibtc;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;

@MappedSuperclass
public abstract class BaseEntity implements Serializable
  {
  private static final long serialVersionUID = -7454329237962441950L;

  @Id
  @GeneratedValue(generator = "system-uuid")
  @GenericGenerator(name = "system-uuid", strategy = "uuid")
  @Column(length = 50)
  private String            id;

  @SuppressWarnings("unused")
  @Version
  private long              optlock;

  public String getId( )
    {
    return id;
    }
  }
