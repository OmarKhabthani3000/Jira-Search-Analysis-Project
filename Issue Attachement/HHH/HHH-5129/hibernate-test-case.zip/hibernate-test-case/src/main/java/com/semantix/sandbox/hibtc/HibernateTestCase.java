/*
 * gloxr-db - Copyright (C) 2010 Semantix - http://www.semantix.com/
 * All rights reserved. Semantix PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.semantix.sandbox.hibtc;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class HibernateTestCase
  {
  public static void main( String[] args )
    {
    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory( "hibtc" );
    EntityManager entityManager = entityManagerFactory.createEntityManager( );
    EntityTransaction tx = entityManager.getTransaction( );

    tx.begin( );
    EntryCollection entryCollection = new EntryCollection( );
    entityManager.persist( entryCollection );
    String collectionID = entryCollection.getId( );
    tx.commit( );
    entityManager.clear( );

    tx.begin( );
    entryCollection = entityManager.find( EntryCollection.class, collectionID );
    Entry entry1 = entryCollection.createEntry( );
    Entry entry2 = entryCollection.createEntry( );
    entryCollection.removeEntry( entry2 );
    tx.commit( );

    entityManager.close( );
    entityManagerFactory.close( );
    }
  }
