/************************************************
 *
 * copyright (c) energy & meteo systems GmbH, 2018
 *
 * mail@energymeteo.com www.energymeteo.com
 *
 ************************************************/

package org.hibernate.bugs;

import javax.persistence.Entity;

@Entity
public class Bar extends Base {

}
