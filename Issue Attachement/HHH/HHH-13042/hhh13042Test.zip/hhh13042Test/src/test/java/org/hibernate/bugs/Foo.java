/************************************************
 *
 * copyright (c) energy & meteo systems GmbH, 2018
 *
 * mail@energymeteo.com www.energymeteo.com
 *
 ************************************************/

package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

@Entity
public class Foo extends Base {
	private List<Bar> bars = new ArrayList<>();

	@OneToMany(mappedBy = "foo", cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	public List<Bar> getBars() {
		return bars;
	}

	public void setBars(List<Bar> bars) {
		this.bars = bars;
	}
}
