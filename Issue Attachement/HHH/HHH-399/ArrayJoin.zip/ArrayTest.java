//$Id:$
package org.hibernate.test.emmanuel;

import org.hibernate.test.TestCase;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * @author Emmanuel Bernard
 */
public class ArrayTest extends TestCase {
	public void testArrayLazy() throws Exception {
		Session s;
		Transaction tx;
		s = openSession();
		tx = s.beginTransaction();
		A a = new A();
		B b = new B();
		a.setBs( new B[] {b} );
		s.persist( a );
		tx.commit();
		s.close();

		s = openSession();
		tx = s.beginTransaction();
		a = (A) s.get( A.class, a.getId() );
		assertNotNull( a );
		assertNotNull( a.getBs() );
		tx.commit();
		s.close();
	}
	public ArrayTest(String x) {
		super( x );
	}

	protected String[] getMappings() {
		return new String[] {
			"emmanuel/A.hbm.xml"
		};
	}
}
