package com.mydomain.ejb;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.ejb.TimerService;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.mydomain.peristence.Child;
import com.mydomain.peristence.Parent;
import com.mydomain.peristence.QChild;
import com.mydomain.peristence.QParent;
import com.mysema.query.jpa.impl.JPAQuery;

@Startup
@Singleton
public class StarterBean {

    @PersistenceContext(unitName = "SamplePU")
    private EntityManager entityManager;

    @Resource
    private TimerService timerService;

    @PostConstruct
    public void onStartup() {
        this.timerService.createSingleActionTimer(3000L, new TimerConfig(new Starter(), false));
    }

    @Timeout
    public void onTimeout(Timer timer) {
        if (timer.getInfo() instanceof Starter) {
            start();
        } else if (timer.getInfo() instanceof Executor) {
            execute();
        }
    }

    private void start() {
        Parent parent = new Parent();
        parent.setName("Parent");
        this.entityManager.persist(parent);

        for (int i = 0; i < 10; i++) {
            Child child = new Child();
            child.setParent(parent);
            parent.getChildren().add(child);
            this.entityManager.persist(child);
        }

        this.entityManager.flush();

        this.timerService.createSingleActionTimer(3000L, new TimerConfig(new Executor(), false));
    }

    private void execute() {
        QChild qChild = QChild.child;
        JPAQuery query = new JPAQuery(this.entityManager);
        List<Child> list = query.from(qChild).orderBy(qChild.id.asc()).list(qChild);
        System.out.print("list=" + list);
    }

    private static final class Starter implements Serializable {
    }

    private static final class Executor implements Serializable {
    }

}
