package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Locale;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import domain.PointOfInterest;

public class EntityManagerTest {

	/**
	 * A reference to the entity manager.
	 */
	private static EntityManager em;

	/**
	 * Prepare all test cases.
	 * @throws Exception
	 */
	@BeforeClass
	public static void before() throws Exception {		
		// create local test specific entity manager
		em = Persistence.createEntityManagerFactory("test-PU").createEntityManager();
	}
	
	/**
	 * Cleanup all test cases.
	 */
	@AfterClass
	public static void after() throws Exception {
		em.close();
	}

	/**
	 * Testcase for the Hibernate HHH-4967 issue.
	 * @throws Exception
	 */
	@Test
	public void testHHH4967() throws Exception {
		EntityTransaction tx = em.getTransaction();		
		try {
	    	// Prepare point of interest with description
	    	PointOfInterest poi = new PointOfInterest("My Point Of Interest");
	    	poi.setDescription(Locale.ENGLISH, "Old castle");
	    	
	    	tx.begin();
	    	em.persist(poi);
	    	tx.commit();
	    	
	    	// check if description has been persisted correctly
	    	PointOfInterest check = em.find(PointOfInterest.class, poi.getId());
	    	assertEquals("description not persisted", 
	    			poi.getDescription(Locale.ENGLISH),
	    			check.getDescription(Locale.ENGLISH));
	    	
	    	// modify description
	    	check.setDescription(Locale.ENGLISH, "changed");

	    	tx.begin();
	    	check = em.merge(check);
	    	tx.commit();

	    	// test if update of description works correctly
	    	PointOfInterest updated = em.find(PointOfInterest.class, poi.getId());	    	
	    	assertEquals("description not updated", check.getDescription(Locale.ENGLISH),
	    			updated.getDescription(Locale.ENGLISH));
	    	assertTrue("wrong list of all descriptions" ,updated.getDescriptions().size() == 1);
	    	assertEquals("wrong description text", "changed", updated.getDescriptions().iterator().next().getText());
	    	
		} catch (Exception e) {
			if (tx != null && tx.isActive()) tx.rollback();
			throw e;
		}  	
	}
}
