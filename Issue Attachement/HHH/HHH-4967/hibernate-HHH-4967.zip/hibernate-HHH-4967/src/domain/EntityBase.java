package domain;

import java.io.Serializable;
import java.util.UUID;

/**
 * EntityBase base class.
 */
public abstract class EntityBase implements Serializable {
	private static final String TO_STRING_ID = ", id = ";

	/**
	 * This class' serial version UID.
	 */
	private static final long serialVersionUID = -9040212156330292483L;

	/**
	 * Technical primary key.
	 */
	private String id = UUID.randomUUID().toString();

	/**
	 * The version - used for optimistic locking.
	 */
	@SuppressWarnings("unused")
	private long version;

	/**
	 * Gets the technical key for this entity instance.
	 * @return	the technical key
	 * @see de.der.pu.domain.Entity#getId()
	 */
	public String getId() {
		return this.id;
	}
	
	/** @inheritDoc */
	@Override
	public String toString() {
		return (new StringBuffer(getClass().getName())).
			append(TO_STRING_ID).append(getId()).toString();
	}

	/**
	 * Due to a bug when deserializing HashMaps and HashSets
	 * (see http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4957674)
	 * implement {@code equals()} and {@code hashCode()} using the 
	 * {@code id} attribute always in <b>subclass</b>.
	 * <p>
	 * Sample:
	 * <pre>
	 * public boolean equals(Object obj) {
	 *     if (this == obj)
	 * 	       return true;
	 *     if (obj == null)
	 *         return false;
	 *     if (! (obj instanceof MyClass))
	 *         return false;
	 *     MyClass other = (MyClass) obj;
	 * 	   if (getId() == null) {
	 *         if (other.getId() != null)
	 *             return false;
	 *     } else if (!getId().equals(other.getId()))
	 *         return false;
	 *     return true;
	 * }
	 * </pre>
	 * This will guarantee correct deserialization.
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public abstract boolean equals(Object other);

	/**
	 * Due to a bug when deserializing HashMaps and HashSets
	 * (see http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4957674)
	 * implement {@code equals()} and {@code hashCode()} using the 
	 * {@code id} attribute always in <b>subclass</b>.
	 * <p>
	 * Sample:
	 * <pre>
	 * public int hashCode() {
	 *     final int prime = 31;
	 *     int result = 1;
	 *     result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
	 *     return result;
	 * }
	 * </pre>
	 * 
	 * This will guarantee correct deserialization.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public abstract int hashCode();	

}