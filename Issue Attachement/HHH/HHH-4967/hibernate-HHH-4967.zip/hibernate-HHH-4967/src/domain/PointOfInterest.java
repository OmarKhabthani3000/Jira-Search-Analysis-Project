package domain;

import java.io.Serializable;
import java.util.Collection;
import java.util.Locale;

/**
 * The PointOfInterest entity. Sample to show n..m association from Hotel.
 */
public class PointOfInterest extends EntityBase implements Serializable {

	/**
	 *  This class' serial version UID.
	 */
	private static final long serialVersionUID = -1429494299L;
	
	/**
	 * the point of interest name.
	 */
	private String name;

	/**
	 * Holds the 1:N relation to the entity's multilingual description:
	 * POI description.
	 */
	private java.util.Map<String, MultilingualText> description = new java.util.HashMap<String, MultilingualText>();

	/**
	 * Default constructor.
	 */
	public PointOfInterest() {
	}
	
	/**
	 * Construct entity PointOfInterest with complete attribute list.
	 * @param name the poi name
	 */
	public PointOfInterest(String name) {
		setName(name);
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns all language dependent descriptions.
	 * @return all language dependent descriptions
	 */
	public Collection<MultilingualText> getDescriptions() {
		return this.description.values();
	}
	
	/**
	 * Gets the description in a specified language.
	 * @param locale the locale
	 * @return the <code>description</code> in the specified language.
	 */
	public String getDescription(Locale locale) {
		if (locale != null) {
			MultilingualText mlText = this.description.get(locale.getLanguage());
			if (mlText != null) {
				return mlText.getText();
			}
		}
		return null;
	}

	/**
	 * Sets the description in a specified language.
	 * @param locale the locale
	 * @param description the <code>description</code> in the specified language.
	 */
	public void setDescription(Locale locale, String description) {
		if (locale != null) {
			String code = locale.getLanguage();
			MultilingualText mlText = this.description.get(code);
			if (mlText != null) {
				mlText.setText(description);
			} else {
				this.description.put(code, new MultilingualText(code, description));
			}
		}
	}

	/**
	 * Removes the description in a specified language.
	 * @param locale the locale
	 */
	public void removeDescription(Locale locale) {
		if (locale != null) {
			this.description.remove(locale.getLanguage());
		}
	}
	
	/**
	 * Returns a hash code value for the object.
	 * @return a hash code value for this object.
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
		return result;
	}

	/**
	 * Indicates whether some other object is "equal to" this one.
	 * @param obj the reference object with which to compare.
	 * @return <code>true</code> if this object is the same as the obj argument; <code>false</code> otherwise.
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (! (obj instanceof PointOfInterest))
			return false;
		PointOfInterest other = (PointOfInterest) obj;
		if (getId() == null) {
			if (other.getId() != null)
				return false;
		} else if (!getId().equals(other.getId()))
			return false;
		return true;
	}

}
