package domain;

import java.io.Serializable;

/**
 * A multilingual text consisting of a language (lower-case, two-letter codes as defined by ISO-639) and a text.
 */
public class MultilingualText extends EntityBase implements Serializable {

	/**
	 * This class' serial version UID.
	 */
	private static final long serialVersionUID = 7122304746237708335L;

	/**
	 * A valid ISO Language Code.  These codes are the lower-case, 
	 * two-letter codes as defined by ISO-639. 
	 */
	private String locale;
	
	/**
	 * The text.
	 */
	private String text;

	/**
	 * Default constructor.
	 */
	public MultilingualText() {
	}
	
	/**
	 * @param locale lower-case, two-letter language code as defined by ISO-639
	 * @param text
	 */
	public MultilingualText(String locale, String text) {
		setLocale(locale);
		setText(text);
	}

	/**
	 * @return lower-case, two-letter language code as defined by ISO-639
	 */
	public String getLocale() {
		return locale;
	}

	/**
	 * Sets the lower-case, two-letter language code as defined by ISO-639
	 * @param locale the locale to set
	 */
	public void setLocale(String locale) {
		this.locale = locale;
	}

	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param text the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * Returns a hash code value for the object.
	 * @return a hash code value for this object.
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
		return result;
	}

	/**
	 * Indicates whether some other object is "equal to" this one.
	 * @param obj the reference object with which to compare.
	 * @return <code>true</code> if this object is the same as the obj argument; <code>false</code> otherwise.
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (! (obj instanceof MultilingualText))
			return false;
		MultilingualText other = (MultilingualText) obj;
		if (getId() == null) {
			if (other.getId() != null)
				return false;
		} else if (!getId().equals(other.getId()))
			return false;
		return true;
	}

}
