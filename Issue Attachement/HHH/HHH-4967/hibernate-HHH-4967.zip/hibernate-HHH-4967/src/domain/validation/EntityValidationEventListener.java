package domain.validation;

/**
 * Validates entity constraints before inserting / updating.
 */
public class EntityValidationEventListener {

	/**
	 * This class' serial version UID.
	 */
	private static final long serialVersionUID = -2717943574875350172L;

	/**
	 * Executed before the entity manager persist operation is actually 
	 * executed or cascaded. This call is synchronous with the persist operation.
	 * @param entity the entity to be persisted
	 */
	public void prePersist(Object entity) {
		// do something
	}
	
	/**
	 * Executed before the entity manager initiates a database UPDATE operation.
	 * @param entity the entity to be updated
	 */
	public void preUpdate(Object entity) {
		// do something
	}
}
