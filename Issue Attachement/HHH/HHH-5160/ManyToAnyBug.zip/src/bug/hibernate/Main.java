package bug.hibernate;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Main {
    public static void main(String[] args) {
		Session session =
			new AnnotationConfiguration().configure().buildSessionFactory().openSession();
		Transaction tx = session.beginTransaction();

        Entity1 entity1 = new Entity1();
        entity1.setId("entity1");
        entity1.setValue1("foo");
        session.save(entity1);

        Entity2 entity2 = new Entity2();
        entity2.setId("entity2");
        entity2.setValue2("bar");
        session.save(entity2);

        EntityBag bag = new EntityBag();
        bag.setId("bag");
        bag.getMyEntities().add(entity1);
        bag.getMyEntities().add(entity2);
        session.save(bag);

        tx.commit();

        tx = session.beginTransaction();

        bag = (EntityBag) session.load(EntityBag.class, "bag");
        bag.getMyEntities().remove(entity1);
        session.save(bag);

        tx.commit();

/* Output:
Hibernate: insert into T_ENTITY1 (C_VERSION, C_VALUE2, C_ID) values (?, ?, ?)
Hibernate: insert into T_ENTITY2 (C_VERSION, C_VALUE2, C_ID) values (?, ?, ?)
Hibernate: insert into T_ENTITY_BAG (C_VERSION, C_ID) values (?, ?)
Hibernate: insert into T_ENTITY_BAG_ENTITIES (C_ENTITY_BAG_ID, C_ENTITY_TYPE, C_ENTITY_ID) values (?, ?, ?)
Hibernate: insert into T_ENTITY_BAG_ENTITIES (C_ENTITY_BAG_ID, C_ENTITY_TYPE, C_ENTITY_ID) values (?, ?, ?)
Hibernate: update T_ENTITY_BAG set C_VERSION=? where C_ID=? and C_VERSION=?
Hibernate: delete from T_ENTITY_BAG_ENTITIES where C_ENTITY_BAG_ID=? and C_ENTITY_ID=?
Exception in thread "main" org.hibernate.exception.GenericJDBCException: could not delete collection rows: [bug.hibernate.EntityBag.myEntities#bag]
        at org.hibernate.exception.SQLStateConverter.handledNonSpecificException(SQLStateConverter.java:140)
        at org.hibernate.exception.SQLStateConverter.convert(SQLStateConverter.java:128)...
 Caused by: java.sql.SQLException: Invalid Column Index
        at oracle.jdbc.driver.SQLStateMapping.newSQLException(SQLStateMapping.java:70)
        at oracle.jdbc.driver.DatabaseError.newSQLException(DatabaseError.java:131)
        ...
        at org.hibernate.type.AnyType.nullSafeSet(AnyType.java:167)
 */
    }
}
