package bug.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="T_ENTITY2")
public class Entity2 extends AbstractEntity {
	private static final long serialVersionUID = 1L;

    @Column(name="C_VALUE2")
    private String value2;

    public String getValue2() {
        return value2;
    }

    public void setValue2(String value2) {
        this.value2 = value2;
    }
}
