package bug.hibernate;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;
import javax.persistence.Version;
import org.hibernate.annotations.AnyMetaDef;
import org.hibernate.annotations.ManyToAny;
import org.hibernate.annotations.MetaValue;

@Entity
@Table(name="T_ENTITY_BAG")
public class EntityBag implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="C_ID")
    private String id;

    @Version
    @Column(name="C_VERSION")
    private Long version;

    @ManyToAny(metaColumn=@Column(name="C_ENTITY_TYPE"))
    @AnyMetaDef(idType="string", metaType="string",
        metaValues={
            @MetaValue(targetEntity=Entity1.class, value="ENTITY1"),
            @MetaValue(targetEntity=Entity2.class, value="ENTITY2")
    })
    @JoinTable(name="T_ENTITY_BAG_ENTITIES",
        joinColumns=@JoinColumn(name="C_ENTITY_BAG_ID"),
        inverseJoinColumns=@JoinColumn(name="C_ENTITY_ID")
    )
    private Set<AbstractEntity> myEntities = new HashSet<AbstractEntity>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public Set<AbstractEntity> getMyEntities() {
        return myEntities;
    }

    public void setMyEntities(Set<AbstractEntity> myEntities) {
        this.myEntities = myEntities;
    }
}
