package bug.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="T_ENTITY1")
public class Entity1 extends AbstractEntity {
	private static final long serialVersionUID = 1L;

    @Column(name="C_VALUE2")
    private String value1;

    public String getValue1() {
        return value1;
    }

    public void setValue1(String value1) {
        this.value1 = value1;
    }
}
