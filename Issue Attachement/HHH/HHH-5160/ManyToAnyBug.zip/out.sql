
    drop table T_ENTITY1 cascade constraints;

    drop table T_ENTITY2 cascade constraints;

    drop table T_ENTITY_BAG cascade constraints;

    drop table T_ENTITY_BAG_ENTITIES cascade constraints;

    create table T_ENTITY1 (
        C_ID varchar2(255) not null,
        C_VERSION number(19,0),
        C_VALUE2 varchar2(255),
        primary key (C_ID)
    );

    create table T_ENTITY2 (
        C_ID varchar2(255) not null,
        C_VERSION number(19,0),
        C_VALUE2 varchar2(255),
        primary key (C_ID)
    );

    create table T_ENTITY_BAG (
        C_ID varchar2(255) not null,
        C_VERSION number(19,0),
        primary key (C_ID)
    );

    create table T_ENTITY_BAG_ENTITIES (
        C_ENTITY_BAG_ID varchar2(255) not null,
        C_ENTITY_TYPE varchar2(255),
        C_ENTITY_ID varchar2(255) not null,
        primary key (C_ENTITY_BAG_ID, C_ENTITY_ID)
    );

    alter table T_ENTITY_BAG_ENTITIES 
        add constraint FKFAA8A4A9B4CD85A1 
        foreign key (C_ENTITY_BAG_ID) 
        references T_ENTITY_BAG;
