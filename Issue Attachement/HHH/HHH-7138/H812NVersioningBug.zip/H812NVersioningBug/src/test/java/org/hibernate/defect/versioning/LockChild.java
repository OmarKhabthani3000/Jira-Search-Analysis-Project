package org.hibernate.defect.versioning;

import javax.persistence.*;

@Entity(name="test_child")
public class LockChild {
    @Id
    @Column(name = "childId", unique = true, nullable = false)
    public int id;

    @ManyToOne
    @JoinColumn(name = "parentId", nullable = false)
    public LockParent parent;

    @Column(name = "myval", nullable = false)
    public int myval;

    @Version
    @Column(name = "version", nullable = false)
    public int version;
}
