package org.hibernate.defect.versioning;

import org.junit.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class LockTest {

    private EntityManagerFactory entityManagerFactory;

    private final class LockRunner implements Runnable {
        private final int id;

        private LockRunner(final int id) {
            this.id = id;
        }

        @Override
        public void run() {
            try {
                slowCreateChild(id);
            } catch (final InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Before
    public void before() {
        entityManagerFactory = Persistence.createEntityManagerFactory("org.hibernate.defect.versioning");
    }

    @After
    public void after() {
        entityManagerFactory.close();
    }

    @Test
    public void test() throws InterruptedException {
        createParent();

        final Thread thread1 = helper(1);
        final Thread thread2 = helper(2);
        thread1.join();
        thread2.join();

        deleteAll();
    }

    private Thread helper(final int id) {
        final Thread thread = new Thread(new LockRunner(id));
        thread.start();
        return thread;
    }

    public void createParent() {
        final EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        final LockParent parent = new LockParent();
        parent.id = 0;
        em.persist(parent);

        em.getTransaction().commit();
        em.close();
    }

    private void slowCreateChild(final int childId) throws InterruptedException {
        final EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        final LockParent parent = em.find(LockParent.class, 0);

        //Sleep for a bit to trigger concurrency issue
        Thread.sleep(500);

        final LockChild child = new LockChild();
        child.id = childId;
        child.myval = 0;
        child.parent = parent;
        parent.children.add(child);
        em.persist(child);

        em.getTransaction().commit();
        em.close();
    }


    private void deleteAll() {
        final EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        em.createQuery("delete from test_child").executeUpdate();
        em.createQuery("delete from test_parent").executeUpdate();

        em.getTransaction().commit();
        em.close();
    }
}
