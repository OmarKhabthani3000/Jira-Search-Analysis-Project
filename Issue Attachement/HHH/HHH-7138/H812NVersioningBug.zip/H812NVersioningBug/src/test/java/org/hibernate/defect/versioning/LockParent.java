package org.hibernate.defect.versioning;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity(name="test_parent")
public class LockParent {
    @Id
    @Column(name = "parentId", unique = true, nullable = false)
    public int id;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "parent")
    public List<LockChild> children = new ArrayList<>();

    @Version
    @Column(name = "version", nullable = false)
    public int version;
}
