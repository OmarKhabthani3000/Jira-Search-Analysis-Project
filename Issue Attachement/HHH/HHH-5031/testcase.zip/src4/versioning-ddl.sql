
    create table CCC.Test.Deal (
        DealId int not null unique,
        AccountSpecialist varchar(256) null,
        ApprovalLevel varchar(50) null,
        AssetManager varchar(256) null,
        Banker varchar(256) null,
        CAAnnualReviewDate datetime null,
        CAExpirationDate datetime null,
        CAGID numeric(19,0) null,
        City varchar(50) null,
        Classification varchar(10) null,
        ClosingDate datetime null,
        CoreCADDApproval tinyint null,
        CoreCADDDate datetime null,
        CreatedBy varchar(255) null,
        CreatedDate datetime null,
        CreditOfficer varchar(256) null,
        DealName varchar(256) not null,
        DealSize numeric(20,5) null,
        DealType varchar(256) null,
        InvestmentType varchar(100) null,
        isLegacy tinyint null,
        ModifiedBy varchar(255) null,
        ModifiedDate datetime null,
        OutsideMaturityDate datetime null,
        PercentCompleteBudget double precision null,
        PercentCompleteEngineering double precision null,
        PortfolioId int not null,
        PricingDesk varchar(50) null,
        ProductSubTypeId int null,
        ProductType varchar(50) null,
        PropertyStatus varchar(50) null,
        PropertyType varchar(50) null,
        RiskEngineer varchar(256) null,
        State varchar(50) null,
        Status varchar(50) null,
        StatusDescription varchar(256) null,
        WireOff double precision null,
        primary key (DealId)
    );

    create table CCC.Test.DealComments (
        commentId int not null unique,
        Comment varchar(2000) not null,
        CommentDate datetime not null,
        DealId int not null,
        UserId varchar(16) not null,
        primary key (commentId)
    );

    create table REVINFO (
        REV int identity not null,
        REVTSTMP numeric(19,0) null,
        primary key (REV)
    );
