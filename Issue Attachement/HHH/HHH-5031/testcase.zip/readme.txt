The build.xml contains the hbm2ddl task.  This is where the exception happens.


1.  sql.ddl -- the script to create the two tables
2.  build.xml -- contains ant tasks to try to generate the ddl scripts
3.  test.db.properties & test.rev.eng.xml -- used to reverse engineer the two database tables

to run:

1.  ant -verbose  create -- to create the java source files and classes attached

2.  ant -verbose  createDDL -- trying to create the ddl scripts 