package org.hibernate.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {
	@Id
	@GeneratedValue
	long id;

	String name;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	@JoinColumn(foreignKey = @ForeignKey(name = "EMP_DEP"))
	Department department;

	protected Employee() {
		// make JPA happy
	}

	public Employee(String name, Department department) {
		this.name = name;
		this.department = department;
	}

	public String getName() {
		return name;
	}

	@Override
	public boolean equals(Object other) {
		if (other == null) {
			return false;
		}
		if (other == this) {
			return true;
		}
		if (!(other instanceof Employee)) {
			return false;
		}
		Employee castOther = (Employee) other;
		return this.getName().equals(castOther.getName());
	}

	@Override
	public int hashCode() {
		return name.hashCode();
	}

}
