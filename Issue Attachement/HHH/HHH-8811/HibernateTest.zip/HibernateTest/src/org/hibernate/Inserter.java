package org.hibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.model.Department;
import org.hibernate.model.Employee;

public class Inserter {
	public static void main(String[] args) throws Exception {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hib");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		for (int i = 0; i < 2500; i++) {
			Department dep = new Department("dep_" + i);
			em.persist(dep);
			for (int j = 0; j < 3; j++) {
				em.persist(new Employee("emp_" + i + "_" + j, dep));
			}

		}
		
		em.getTransaction().commit();
		em.close();
		emf.close();
	}

}
