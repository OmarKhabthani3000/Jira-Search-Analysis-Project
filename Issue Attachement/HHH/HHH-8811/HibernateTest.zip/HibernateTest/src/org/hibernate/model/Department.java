package org.hibernate.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Department {
	@Id
	@GeneratedValue
	long id;
	
	String name;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "department", cascade = CascadeType.ALL)
	protected Set<Employee> employees = new HashSet<>();

	protected Department() {
		// make JPA happy
	}

	public Department(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
	public Set<Employee> getEmployees() {
		return employees;
	}

	@Override
	public boolean equals(Object other) {
		if (other == null) {
			return false;
		}
		if (other == this) {
			return true;
		}
		if (!(other instanceof Department)) {
			return false;
		}
		Department castOther = (Department) other;
		return this.getName().equals(castOther.getName());
	}

	@Override
	public int hashCode() {
		return name.hashCode();
	}

}
