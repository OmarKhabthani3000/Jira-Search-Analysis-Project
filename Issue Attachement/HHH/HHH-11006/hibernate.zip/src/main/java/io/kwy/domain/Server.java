package io.kwy.domain;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ConstraintMode;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.MapKeyColumn;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = false, exclude = { "headers" })
@EqualsAndHashCode(callSuper = false, of = { "id" })
@Entity
public class Server implements Serializable {
  private static final long serialVersionUID = 774924486248120860L;
  @Id
  private String id;

  @Column
  private String externalPath;

  @Column
  private String internalPath;

  @Column
  private String externalHost;

  @Column
  private String internalHost;

  @Column
  private Integer generalPort;

  @Column
  private Integer securePort;

  @ElementCollection
  @CollectionTable(name = "Server_Headers", foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
  @MapKeyColumn(name = "header")
  @Lob
  @Column(name = "value")
  private Map<String, String> headers = new HashMap<String, String>();
}