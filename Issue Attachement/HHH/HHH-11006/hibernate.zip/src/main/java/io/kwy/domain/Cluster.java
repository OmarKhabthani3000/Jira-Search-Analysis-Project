package io.kwy.domain;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ConstraintMode;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyJoinColumn;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = false, exclude = { "servers" })
@EqualsAndHashCode(callSuper = false, of = { "id" })
@Entity
public class Cluster implements Serializable {
  private static final long serialVersionUID = -1515057292914459397L;
  @Id
  private String id;

  private String name;

  @ElementCollection
  @CollectionTable(name = "Cluster_Servers", foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT), joinColumns = @JoinColumn(foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT)))
  @MapKeyJoinColumn(name = "Server_id", foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
  @Column(name = "sequence")
  private Map<Server, Integer> servers = new HashMap<Server, Integer>();
}
