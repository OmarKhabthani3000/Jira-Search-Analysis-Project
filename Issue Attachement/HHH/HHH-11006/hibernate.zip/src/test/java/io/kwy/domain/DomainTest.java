package io.kwy.domain;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.EnumSet;
import java.util.Properties;

import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Environment;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.hibernate.tool.schema.TargetType;
import org.junit.Test;

public class DomainTest {
  public static final int BUFFER_SIZE = 4096;

  @Test
  public void test() throws FileNotFoundException, IOException {
    File file = Files.createTempFile(Paths.get(System.getProperty("java.io.tmpdir")), "schema", ".sql").toFile();

    Properties properties = Environment.getProperties();
    properties.put(org.hibernate.cfg.AvailableSettings.DIALECT, org.hibernate.dialect.H2Dialect.class);

    MetadataSources metadataSources = new MetadataSources(new StandardServiceRegistryBuilder().applySettings(properties).build());
    metadataSources.addAnnotatedClassName(Cluster.class.getName());
    metadataSources.addAnnotatedClassName(Server.class.getName());

    SchemaExport schemaExport = new SchemaExport();
    schemaExport.setOutputFile(file.getPath());
    schemaExport.setDelimiter(";");
    schemaExport.setFormat(true);
    schemaExport.createOnly(EnumSet.of(TargetType.SCRIPT), metadataSources.buildMetadata());

    StringWriter out = new StringWriter();
    copy(new FileReader(file), out);
    System.out.println(out.toString());
  }

  public static int copy(Reader in, Writer out) throws IOException {
    try {
      int byteCount = 0;
      char[] buffer = new char[BUFFER_SIZE];
      int bytesRead = -1;
      while ((bytesRead = in.read(buffer)) != -1) {
        out.write(buffer, 0, bytesRead);
        byteCount += bytesRead;
      }
      out.flush();
      return byteCount;
    }
    finally {
      try {
        in.close();
      }
      catch (IOException ex) {
      }
      try {
        out.close();
      }
      catch (IOException ex) {
      }
    }
  }
}
