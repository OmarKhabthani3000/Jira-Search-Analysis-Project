import java.util.List;
import java.util.Map;
import java.util.HashMap;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class CascadeSaveTest
{
 public static void main(String args[])
 {
  Configuration cfg = new Configuration();

  cfg.configure("hibernate.cfg.xml");

  cfg.setProperty(Environment.HBM2DDL_AUTO, "create");

  SessionFactory factory = cfg.buildSessionFactory();

  addTestData(factory);

  deleteTestData(factory);

  factory.close();
 }

 static void addTestData(SessionFactory factory)
 {
  Session s = factory.openSession();

  Transaction tx=null;

  try
    {
     tx = s.beginTransaction();

     Doc doc = new Doc();

     RouteContext routeContext = new RouteContext();
     doc.addRouteContext(routeContext);

     s.persist(routeContext);

     routeContext = new RouteContext();
     doc.addRouteContext(routeContext);

     s.persist(routeContext);

     Map content = new HashMap();
     content.put("doc",doc);

     s.openSession(EntityMode.MAP).persist("DocContent",content);

     tx.commit();
    }
  catch( RuntimeException e )
    {
     if (tx!=null) tx.rollback();
     throw e;
    }
  finally { s.close(); }
 }

 static void deleteTestData(SessionFactory factory)
 {
  Session s = factory.openSession();

  Transaction tx=null;

  try
    {
     tx = s.beginTransaction();

     List<RouteContext> list = (List<RouteContext>)s.createCriteria(RouteContext.class).list();

     for( RouteContext context: list )
       {
        System.out.println("Deleting "+context);

        s.delete(context);
       }

     tx.commit();
    }
  catch( RuntimeException e )
    {
     if (tx!=null) tx.rollback();
     throw e;
    }
  finally { s.close(); }
 }
}
