import java.util.Set;
import java.util.HashSet;


public class Doc
{
 private int id;

 private Set<RouteContext> contexts;

 public void addRouteContext(RouteContext routeContext)
 {
   if( contexts==null ) contexts = new HashSet<RouteContext>(2);

   routeContext.setDoc(this);
   contexts.add(routeContext);
 }

 public String toString() { return "Doc("+id+")"; }
}
