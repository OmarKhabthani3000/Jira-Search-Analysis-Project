
public class RouteContext
{
 private int id;

 private Doc doc;

 void setDoc(Doc _doc) { doc = _doc; }

 public String toString() { return "RouteContext("+id+")"; }
}
