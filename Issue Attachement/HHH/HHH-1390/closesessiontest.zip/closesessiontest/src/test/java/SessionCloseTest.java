import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import junit.framework.TestCase;

public class SessionCloseTest extends TestCase {
    
    SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
    
    public void testSessionClose() {
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.createSQLQuery("SELECT * FROM DUAL");
            tx.commit();
        }
        catch (HibernateException he) {
            if (tx!=null) {
                tx.rollback();
            }
            throw he;
        }
        finally {
            session.close();
        }
    }

    public void testSessionCloseWithIsOpenCheck() {
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.createSQLQuery("SELECT * FROM DUAL");
            tx.commit();
        }
        catch (HibernateException he) {
            if (tx!=null) {
                tx.rollback();
            }
            throw he;
        }
        finally {
            if (session.isOpen()) {
                session.close();
            }
        }
    }
}
