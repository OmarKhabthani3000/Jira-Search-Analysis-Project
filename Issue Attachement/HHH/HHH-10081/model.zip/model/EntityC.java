package com.eightd.ftk.db.hibernate.criteria.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = EntityC.TABLE_NAME)
public class EntityC {

	public static final String TABLE_NAME = "EntityC";
	public static final String ATTRIBUTE_NAME = "name";
	private String name;

	public EntityC() {
	}

	public EntityC( String name ) {
		this.name = name;
	}

	@Id
	public String getName() {
		return name;
	}

	public void setName( String name ) {
		this.name = name;
	}


	public boolean equals( Object o ) {
		return o != null //
				&& this.getClass().equals( o.getClass() ) //
				&& ( //
				this.getName() == ((EntityC) o).getName() //
						|| (this.getName() != null && this.getName().equals( ((EntityC) o).getName() )) //
		);
	}

}
