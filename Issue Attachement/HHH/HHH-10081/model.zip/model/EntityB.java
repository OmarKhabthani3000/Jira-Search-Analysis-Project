package com.eightd.ftk.db.hibernate.criteria.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity(name = EntityB.TABLE_NAME)
public class EntityB {

	public static final String TABLE_NAME = "EntityB";
	public static final String ATTRIBUTE_NAME = "name";
	public static final String ATTRIBUTE_ENTITYC_LIST = "entityClist";

	private String name;
	private List<EntityC> entityClist;

	public EntityB() {
	}

	public EntityB( String name ) {
		this.name = name;
	}

	@ManyToMany(cascade = CascadeType.ALL)
	public List<EntityC> getEntityClist() {
		if ( entityClist == null ) {
			entityClist = new ArrayList<>();
		}
		return entityClist;
	}

	public void setEntityClist( List<EntityC> entityClist ) {
		this.entityClist = entityClist;
	}

	@Id
	public String getName() {
		return name;
	}

	public void setName( String name ) {
		this.name = name;
	}

}
