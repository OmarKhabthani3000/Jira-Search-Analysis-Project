package com.eightd.ftk.db.hibernate.criteria.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity(name = EntityA.TABLE_NAME)
public class EntityA {

	public static final String TABLE_NAME = "EntityA";
	public static final String ATTRIBUTE_NAME = "name";
	public static final String ATTRIBUTE_ENTITYB_LIST = "entityBlist";

	private String name;
	private List<EntityB> entityBlist;

	public EntityA() {
	}

	public EntityA( String name ) {
		this.name = name;
	}

	@ManyToMany(cascade = CascadeType.ALL)
	public List<EntityB> getEntityBlist() {
		if ( entityBlist == null ) {
			entityBlist = new ArrayList<>();
		}
		return entityBlist;
	}

	public void setEntityBlist( List<EntityB> entityCList ) {
		this.entityBlist = entityCList;
	}

	@Id
	public String getName() {
		return name;
	}

	public void setName( String name ) {
		this.name = name;
	}
}
