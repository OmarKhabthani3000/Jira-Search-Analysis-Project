package test.hibernate.hhh7302;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Map;

import org.dom4j.Node;
import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.engine.spi.Mapping;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.internal.util.compare.CalendarComparator;
import org.hibernate.metamodel.relational.Size;
import org.hibernate.type.ForeignKeyDirection;
import org.hibernate.type.Type;

public class MultiFieldCalendarType implements Type {
	private static final long serialVersionUID = 1L;
	static final boolean[] nullness = new boolean[] { true, true, true, true, true, true, true };
	
	protected static final Size DEFAULT_SIZE = new Size( 19, 2, 255, Size.LobMultiplier.NONE ); // match legacy behavior
	protected static final Size LEGACY_SIZE = new Size(); // match legacy behavior



	@Override
	public int[] sqlTypes(Mapping mapping) throws MappingException {
		return new int[] { java.sql.Types.INTEGER, java.sql.Types.INTEGER, java.sql.Types.INTEGER, java.sql.Types.INTEGER, java.sql.Types.INTEGER };
	}

	@Override
	public int getColumnSpan(Mapping mapping) throws MappingException {
		return 5;
	}

	@Override
	public Object nullSafeGet(ResultSet rs, String[] names,
			SessionImplementor session, Object owner)
			throws HibernateException, SQLException {
		Integer i;
		int year, month, day, hour, min, sec, milli;
		i = rs.getInt(names[0]);
		if (i == null)
			return null;
		else
			year = 100 * i;
		i = rs.getInt(names[1]);
		if (i == null)
			return null;
		else
			year += i;
		i = rs.getInt(names[2]);
		if (i == null || i == 0)
			return null;
		else
			month = i-1;
		i = rs.getInt(names[3]);
		if (i == null || i == 0)
			return null;
		else
			day = i;

		i = rs.getInt(names[4]);
		if (i == null)
			return null;
		else {
			hour = (i / 1000000);
			min =  (i / 10000) % 100;
			sec =  (i / 100) % 100;
			milli = (i % 100) * 10;
		}
		
		
		Calendar ret = new GregorianCalendar(year, month, day, hour, min, sec);
		ret.set(Calendar.MILLISECOND, milli);
		return ret;
	}

	@Override
	public Object nullSafeGet(ResultSet rs, String name,
			SessionImplementor session, Object owner)
			throws HibernateException, SQLException {
		throw new RuntimeException("This type can not be stored in a single field.");
	}

	@Override
	public void nullSafeSet(PreparedStatement st, Object value, int index,
			boolean[] settable, SessionImplementor session)
			throws HibernateException, SQLException {
		nullSafeSet(st, value, index, session);
	}

	@Override
	public void nullSafeSet(PreparedStatement st, Object value, int index, SessionImplementor session) throws HibernateException, SQLException {
		int idx = index;
		Calendar cal = (Calendar) value;
		if (value == null) {
			st.setInt(idx++, 0);
			st.setInt(idx++, 0);
			st.setInt(idx++, 0);
			st.setInt(idx++, 0);
			st.setInt(idx++, 0);
		} else {
			st.setInt(idx++, cal.get(Calendar.YEAR) / 100);
			st.setInt(idx++, cal.get(Calendar.YEAR) % 100);
			st.setInt(idx++, cal.get(Calendar.MONTH)+1);
			st.setInt(idx++, cal.get(Calendar.DATE));
			st.setInt(idx++, 
					(cal.get(Calendar.HOUR_OF_DAY) * 1000000) + 
					(cal.get(Calendar.MINUTE)      * 10000  ) +
					(cal.get(Calendar.SECOND)      * 100    ) +
					(cal.get(Calendar.MILLISECOND) / 10     )
			);
		}
	}

	@Override
	public String getName() {
		return "multifield_calendar";
	}

	@Override
	public boolean[] toColumnNullness(Object value, Mapping mapping) {
		// legacy app uses 0-fill to represent null
		return nullness;
	}

	
	@Override
	public boolean isAssociationType() {
		return false;
	}

	@Override
	public boolean isCollectionType() {
		return false;
	}

	@Override
	public boolean isComponentType() {
		return false;
	}

	@Override
	public boolean isEntityType() {
		return false;
	}

	@Override
	public boolean isAnyType() {
		return false;
	}

	@Override
	public boolean isXMLElement() {
		return true;
	}

	@Override
	public Class<Calendar> getReturnedClass() {
		return Calendar.class;
	}

	@Override
	public boolean isSame(Object x, Object y) throws HibernateException {
		return isEqual(x, y);
	}

	@Override
	public boolean isEqual(Object x, Object y) throws HibernateException {
		return x.equals(y);
	}

	@Override
	public boolean isEqual(Object x, Object y, SessionFactoryImplementor factory) throws HibernateException {
		return isEqual(x, y);
	}

	@Override
	public int getHashCode(Object x) throws HibernateException {
		return x.hashCode();
	}

	@Override
	public int getHashCode(Object x, SessionFactoryImplementor factory) throws HibernateException {
		return getHashCode(x);
	}

	@Override
	public int compare(Object x, Object y) {
		if (x != null && y != null)
			return CalendarComparator.INSTANCE.compare((Calendar) x, (Calendar)y);
		else if (x == null && y == null)
			return 0;
		else if (x == null)
			return -1;
		else 
			return 1;
	}

	@Override
	public boolean isDirty(Object old, Object current, SessionImplementor session) throws HibernateException {
		return compare(old, current) != 0;
	}

	@Override
	public boolean isDirty(Object old, Object current, boolean[] checkable, SessionImplementor session) throws HibernateException {
		return isDirty(old, current, session);
	}

	@Override
	public boolean isModified(Object oldHydratedState, Object currentState,
			boolean[] checkable, SessionImplementor session)
			throws HibernateException {
		return isDirty(oldHydratedState, currentState, session);
	}

	@Override
	public String toLoggableString(Object value, SessionFactoryImplementor factory) throws HibernateException {
		Calendar cal = (Calendar) value;
		return String.format("%04d-%02d-%02d %02d:%02d:%02d", 
				cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1,
				cal.get(Calendar.DATE), cal.get(Calendar.HOUR_OF_DAY),
				cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
	}

	@Override
	public Object fromXMLNode(Node xml, Mapping factory)
			throws HibernateException {
		String milli = xml.getText();

		if (milli == null || milli.isEmpty())
			return null;
		
		try {
			Calendar ret = Calendar.getInstance();
			ret.setTimeInMillis(Long.parseLong(milli));
			return ret;
		} catch (NumberFormatException e) {
			return null;
		}
	}
	
	@Override
	public void setToXMLNode(Node node, Object value,
			SessionFactoryImplementor factory) throws HibernateException {
		if (value != null)
			node.setText(Long.toString(((Calendar) value).getTimeInMillis()));
		else
			node.setText("");
	}

	@Override
	public Object deepCopy(Object value, SessionFactoryImplementor factory) throws HibernateException {
		if (value == null)
			return null;
		else
			return (Calendar) ((Calendar) value).clone();
	}

	@Override
	public boolean isMutable() {
		return true;
	}

	@Override
	public Serializable disassemble(Object value, SessionImplementor session,
			Object owner) throws HibernateException {
		return (Calendar) value;
	}

	@Override
	public Object assemble(Serializable cached, SessionImplementor session,
			Object owner) throws HibernateException {
		return cached;
	}

	@Override
	public void beforeAssemble(Serializable cached, SessionImplementor session) {
		// don't care
	}

	@Override
	public Object hydrate(ResultSet rs, String[] names,
			SessionImplementor session, Object owner)
			throws HibernateException, SQLException {
		return nullSafeGet(rs, names, session, owner);
	}

	@Override
	public Object resolve(Object value, SessionImplementor session, Object owner)
			throws HibernateException {
		return value;
	}

	@Override
	public Object semiResolve(Object value, SessionImplementor session,
			Object owner) throws HibernateException {
		return value;
	}

	@Override
	public Type getSemiResolvedType(SessionFactoryImplementor factory) {
		return this;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Object replace(Object original, Object target,
			SessionImplementor session, Object owner, Map copyCache)
			throws HibernateException {
		return ((original==null)?null:((Calendar) original).clone());
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Object replace(Object original, Object target,
			SessionImplementor session, Object owner, Map copyCache,
			ForeignKeyDirection foreignKeyDirection) throws HibernateException {
		return replace(original, target, session, owner, copyCache);
	}

	@Override
	public Size[] dictatedSizes(Mapping mapping) throws MappingException {
		Size[] ret = new Size[getColumnSpan(mapping)];
		for (int i = 0; i < ret.length; i++) {
			ret[i] = LEGACY_SIZE;
		}
		
		return ret;
	}

	@Override
	public Size[] defaultSizes(Mapping mapping) throws MappingException {
		Size[] ret = new Size[getColumnSpan(mapping)];
		for (int i = 0; i < ret.length; i++) {
			ret[i] = DEFAULT_SIZE;
		}
		
		return ret;
	}

}
