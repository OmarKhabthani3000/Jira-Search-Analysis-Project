package test.hibernate.hhh7302;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Main {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hhh7302");
		EntityManager em = emf.createEntityManager();
		try {
			List<CompareDate> results;
			TypedQuery<CompareDate> tqAll = em.createQuery("Select o From CompareDate o", CompareDate.class);
			TypedQuery<CompareDate> tq = em.createQuery("Select o From CompareDate o WHERE o.date > :after ORDER BY o.date", CompareDate.class);
			Calendar after;
			
			System.out.println("=== All Records ================================================================");
			results = tqAll.getResultList();
			for (CompareDate o : results)
				System.out.println(o);

			after = new GregorianCalendar(1999, 11, 31);
			System.out.format("=== Records After %tF ===================================================%n", after);
			tq.setParameter("after", after);
			results = tq.getResultList();
			for (CompareDate o : results)
				System.out.println(o);

			System.out.println("================================================================================");

		} finally {
			em.close();
			emf.close();
		}
	}
	
}
