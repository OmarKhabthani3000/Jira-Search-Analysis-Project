package test.hibernate.hhh7302;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "compare_date")
public class CompareDate {

	@Id
	@Column(name="record")
	protected int id;
	@Column(name="title")
	protected String title;
	@Type(type="multifield_calendar")
	@Columns(columns = {
		@Column(name = "century", length=2, nullable = false),
		@Column(name = "year", length=2, nullable = false),
		@Column(name = "month", length=2, nullable = false),
		@Column(name = "day", length=2, nullable = false),
		@Column(name = "time", length=8, nullable = false)
	})
	protected Calendar date;
	
	@Override
	public String toString() {
		return String.format("CompareDate[%02d, %tFT%tT, %s]", id, date, date, title);
	}
}
