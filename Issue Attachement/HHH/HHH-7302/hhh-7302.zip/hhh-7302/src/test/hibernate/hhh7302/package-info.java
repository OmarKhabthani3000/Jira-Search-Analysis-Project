

@TypeDefs(value = { 
	@TypeDef(name = "multifield_calendar", typeClass=MultiFieldCalendarType.class)
})

package test.hibernate.hhh7302;

import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
