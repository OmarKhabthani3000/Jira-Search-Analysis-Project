package test.hibernate.hhh7302;


/**
 * This dielect is for testing bug  HHH-7302 which is a bug in the translate
 * code used to handle database the do not support row value constructors.
 * i.e. (1999, 1, 30) < (2000, 2, 14) 
 * 
 * This dialect tells hibernate the MySQL does not support row value constructors
 * to make testing the bug/fix easier.
 */
public class DebugDialect extends org.hibernate.dialect.MySQL5Dialect {

	@Override
	public boolean supportsRowValueConstructorSyntax() {
		return false;
	}
}
