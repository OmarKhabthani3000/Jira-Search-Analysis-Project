package hibernate.bug;

import hibernate.bug.model.MyEntity;
import hibernate.bug.model.MyEmbeddable;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.hibernate.engine.spi.SessionImplementor;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        MyEntity a = new MyEntity();
        a.getEmbeddables().add(MyEmbeddable.newInstance());
        
        em.persist(a);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testTreat1() {
        EntityManager em = emf.createEntityManager();
        SessionImplementor session = em.unwrap(SessionImplementor.class);
        
        try (Statement s = session.connection().createStatement(); ResultSet rs = s.executeQuery("select year, time from embeddables")) {
            ResultSetMetaData rsmd = rs.getMetaData();
            assertEquals("The year column should be of type java.sql.Types.INTEGER!", Types.INTEGER, rsmd.getColumnType(1));
            assertEquals("The time column should be of type java.sql.Types.TIME!", Types.TIME, rsmd.getColumnType(2));
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        
        em.close();
    }
}
