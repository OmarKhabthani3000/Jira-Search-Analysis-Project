package hibernate.bug.model;

import hibernate.bug.converter.LocalTimeConverter;
import hibernate.bug.converter.YearConverter;
import java.io.Serializable;
import java.time.LocalTime;
import java.time.Year;

import javax.persistence.Convert;
import javax.persistence.Embeddable;

@Embeddable
public class MyEmbeddable implements Serializable {

    private static final long serialVersionUID = 1L;

    private Year year;
    private LocalTime time;

    public MyEmbeddable() {
    }

    public static MyEmbeddable newInstance() {
        MyEmbeddable t = new MyEmbeddable();
        t.setYear(Year.now());
        t.setTime(LocalTime.now());
        return t;
    }

    @Convert(converter = YearConverter.class)
    public Year getYear() {
        return year;
    }

    public void setYear(Year year) {
        this.year = year;
    }

    @Convert(converter = LocalTimeConverter.class)
    public LocalTime getTime() {
        return time;
    }

    public void setTime(LocalTime time) {
        this.time = time;
    }

}
