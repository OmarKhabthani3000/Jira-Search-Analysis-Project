// ____________________________________________________________________________
//
// (c) 2016, ORTHOsoft Inc. All Rights Reserved
//
// The contents of this file may not be disclosed, copied or duplicated in
// any form, in whole or part, without the prior written permission of
// ORTHOsoft Inc.
// ____________________________________________________________________________

package org.hibernate.bugs;

import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "b")
public class EntityB {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column()
  private Long primaryKey;

  @OneToMany(mappedBy="b")
  private Set<EntityA> a;

  @OneToMany(mappedBy="b")
  private Set<EntityC> c;

  public Long getPrimaryKey() {
    return primaryKey;
  }

  public void setPrimaryKey(Long primaryKey) {
    this.primaryKey = primaryKey;
  }

  public Set<EntityA> getA() {
    return a;
  }

  public void setA(Set<EntityA> a) {
    this.a = a;
  }

  public Set<EntityC> getC() {
    return c;
  }

  public void setC(Set<EntityC> c) {
    this.c = c;
  }
}
