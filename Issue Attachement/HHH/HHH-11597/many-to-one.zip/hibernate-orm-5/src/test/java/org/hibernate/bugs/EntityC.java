// ____________________________________________________________________________
//
// (c) 2016, ORTHOsoft Inc. All Rights Reserved
//
// The contents of this file may not be disclosed, copied or duplicated in
// any form, in whole or part, without the prior written permission of
// ORTHOsoft Inc.
// ____________________________________________________________________________

package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;

/**
 * Created by carnusj on 05/12/2016.
 */
@Entity
@Table(name = "c")
public class EntityC {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column()
  private Long primaryKey;

  @ManyToOne(optional=true, fetch=FetchType.LAZY)
  @JoinColumn(name="b_fk")
  private EntityB b;

  public Long getPrimaryKey() {
    return primaryKey;
  }

  public void setPrimaryKey(Long primaryKey) {
    this.primaryKey = primaryKey;
  }

  public EntityB getB() {
    return b;
  }

  public void setB(EntityB b) {
    this.b = b;
  }
}
