package com.example.hibernate6;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;

@SpringBootApplication
public class Hibernate6Application {

    public static void main(String[] args) {
        SpringApplication.run(Hibernate6Application.class, args);
    }

}

@Entity
@Getter
@Setter
class Post {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    @OneToMany
    private List<PostComment> comments;
}

@Entity
@Getter
@Setter
class PostComment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String text;
    private int    score;

    @ManyToOne(optional = false)
    private Post post;
}
