package com.example.hibernate6;

import static org.assertj.core.api.Assertions.assertThatNoException;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.ParameterExpression;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;

@DataJpaTest
class Hibernate6ApplicationTests {

    @Autowired
    private EntityManager entityManager;

    @Test
    void criteria() {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();

        CriteriaQuery<Post> query = builder.createQuery(Post.class);
        Root<Post> p = query.from(Post.class);

        ParameterExpression<Integer> minScore = builder.parameter(Integer.class);
        Subquery<Integer> subQuery = query.subquery(Integer.class);
        Root<PostComment> pc = subQuery.from(PostComment.class);
        subQuery
                .select(builder.literal(1))
                .where(
                        builder.equal(pc.get(PostComment_.post), p),
                        builder.gt(pc.get(PostComment_.score), minScore)
                );

        query.where(builder.exists(subQuery));

        assertThatNoException()
                .isThrownBy(() -> entityManager.createQuery(query)
                        .setParameter(minScore, 10)
                        .getResultList());
    }

    @Test
    void jpql() {
        assertThatNoException()
                .isThrownBy(() -> entityManager.createQuery("""
                                select p
                                from Post p
                                where exists (
                                   select 1
                                   from PostComment pc
                                   where
                                      pc.post = p and
                                      pc.score > :minScore
                                )
                                order by p.id""", Post.class)
                        .setParameter("minScore", 10)
                        .getResultList());
    }

}
