package com.justtest.hibernate;

import javax.persistence.*;
import java.io.Serializable;

/**
 * User: Grisha Klimov
 * Date: May 29, 2008
 * Time: 7:00:14 PM
 */

@Entity
@Table(name = "criteria")
public class Criterion implements Serializable {

    private static final long serialVersionUID = -6055689568932659292L;

    @Id
    @GeneratedValue
    private Long id;

    /*@ManyToOne
    @JoinColumn(name = "rule_id")
    private Rule rule;*/

    @Column(name = "field")
    private String field;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "operation")
    private Operation operation;

    @Column(name = "value")
    private String value;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    /*public Rule getRule() {
        return rule;
    }

    public void setRule(Rule rule) {
        this.rule = rule;
    }*/

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public Operation getOperation() {
        return operation;
    }

    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Criterion criterion = (Criterion) o;

        if (field != null ? !field.equals(criterion.field) : criterion.field != null) return false;
        if (id != null ? !id.equals(criterion.id) : criterion.id != null) return false;
        if (operation != criterion.operation) return false;
        if (value != null ? !value.equals(criterion.value) : criterion.value != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        result = (id != null ? id.hashCode() : 0);
        result = 31 * result + (field != null ? field.hashCode() : 0);
        result = 31 * result + (operation != null ? operation.hashCode() : 0);
        result = 31 * result + (value != null ? value.hashCode() : 0);
        return result;
    }
}
