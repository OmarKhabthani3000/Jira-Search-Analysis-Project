package com.justtest.hibernate;

import javax.persistence.*;
import java.io.Serializable;

/**
 * User: Grisha Klimov
 * Date: Jul 7, 2008
 * Time: 6:48:04 PM
 */

@Entity
@Table(name = "user_attrs")
@IdClass(UserAttributeID.class)
public class UserAttribute implements Serializable {

    private static final long serialVersionUID = -4690042221368809112L;

    @Id
    private User user;

    @Id
    private String name;

    @Column(name = "value")
    private String value;


    public UserAttribute() {
    }

    public UserAttribute(User user, String name, String value) {
        this.user = user;
        this.name = name;
        this.value = value;
    }


    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


    @Override
    @SuppressWarnings({"RedundantIfStatement"})
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserAttribute that = (UserAttribute) o;

        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (user != null ? !user.equals(that.user) : that.user != null) return false;
        if (value != null ? !value.equals(that.value) : that.value != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        result = (user != null ? user.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (value != null ? value.hashCode() : 0);
        return result;
    }
}
