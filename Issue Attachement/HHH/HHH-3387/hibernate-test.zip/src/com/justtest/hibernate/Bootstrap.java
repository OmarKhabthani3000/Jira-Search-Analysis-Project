package com.justtest.hibernate;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * User: Grisha Klimov
 * Date: May 29, 2008
 * Time: 7:20:55 PM
 */

public class Bootstrap {

    public static void main(String[] args) {
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        Session session = sessionFactory.openSession();
        session.setFlushMode(FlushMode.COMMIT);
        Transaction transaction = session.beginTransaction();

        /*Rule rule = new Rule();
        rule.setId(1L);
        rule.setName("Test equality");

        session.saveOrUpdate(rule);*/

        User user = (User) session.get(User.class, 1L);
        Set<UserAttribute> attributes = new HashSet<UserAttribute>();
        attributes.add(new UserAttribute(user, "test1", "aaaa"));
        attributes.add(new UserAttribute(user, "test3", "cccc"));
        user.setAttributes(attributes);

        transaction.commit();
        session.close();

        String name = HibernateUtil.getPKColumnName(User.class);
        System.out.println(name);
    }
}
