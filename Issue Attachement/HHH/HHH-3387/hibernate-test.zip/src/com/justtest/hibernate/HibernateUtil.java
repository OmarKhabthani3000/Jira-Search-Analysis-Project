package com.justtest.hibernate;

import org.hibernate.SessionFactory;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.mapping.*;
import org.hibernate.property.Getter;

import java.util.Iterator;

/**
 * User: Grisha Klimov
 * Date: Apr 7, 2008
 * Time: 4:23:26 PM
 */

public class HibernateUtil {

    private static Configuration configuration;
    private static SessionFactory sessionFactory;

    static {
        configuration = new AnnotationConfiguration();
        configuration.setInterceptor(new VersionInterceptor());
        configuration.configure();

        sessionFactory = configuration.buildSessionFactory();
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static PersistentClass getPersistentClass(Class clazz) {
        return configuration.getClassMapping(clazz.getName());
    }

    public static String getTableName(Class clazz) {
        PersistentClass pClass = getPersistentClass(clazz);
        if (pClass != null) {
            Table table = pClass.getTable();
            if (table != null)
                return table.getName();
        }
        return null;
    }

    public static String getTableColumnName(Class clazz, String propertyName) {
        PersistentClass pClass = getPersistentClass(clazz);
        if (pClass != null) {
            Property property = pClass.getProperty(propertyName);
            if (property != null) {
                Column column = (Column) property.getColumnIterator().next();
                if (column != null) {
                    return column.getName();
                }
            }
        }
        return null;
    }

    public static String getPKColumnName(Class clazz) {
        PersistentClass pClass = getPersistentClass(clazz);
        if (pClass != null) {
            Property property = pClass.getIdentifierProperty();
            return property.getName();
        }
        return null;
    }

    public static Object getPKValue(Object entity) {
        PersistentClass pClass = getPersistentClass(entity.getClass());
        if (pClass != null) {
            Property identifierProperty = pClass.getIdentifierProperty();
            if (identifierProperty != null) {
                Getter getter = identifierProperty.getGetter(entity.getClass());
                if (getter != null) {
                    return getter.get(entity);
                }
            } else if (pClass.getIdentifier() instanceof Component) {
                Component component = (Component) pClass.getIdentifier();
                if (component != null && component.isEmbedded()) {
                    Class compClass = component.getComponentClass();
                    Object key = null;
                    try {
                        key = compClass.newInstance();
                        for (Iterator i = component.getPropertyIterator(); i.hasNext(); ) {
                            Property property = (Property) i.next();
                            Object value = property.getGetter(compClass).get(entity);
                            property.getSetter(compClass).set(key, value, (SessionFactoryImplementor) sessionFactory);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return key;
                }
            }
        }
        return null;
    }

    public static String generateManyToManyInsert(Class clazz, String propertyName) {
        PersistentClass pClass = getPersistentClass(clazz);
        if (pClass != null) {
            Property property = pClass.getProperty(propertyName);
            if (property != null) {
                Value value = property.getValue();
                if (value instanceof Collection) {
                    Collection collection = (Collection) property.getValue();
                    Table colTable = collection.getCollectionTable();
                    String insPart = "insert into " + colTable.getName() + " (";
                    String valPart = "values (";
                    for (Iterator i = colTable.getColumnIterator(); i.hasNext(); ) {
                        Column col = (Column) i.next();
                        insPart += col.getName() + ", ";
                        valPart += "?, ";
                    }
                    return insPart.substring(0, insPart.length() - 2) + ") " + valPart.substring(0, valPart.length() - 2) + ")";
                }
            }
        }
        return null;
    }
}
