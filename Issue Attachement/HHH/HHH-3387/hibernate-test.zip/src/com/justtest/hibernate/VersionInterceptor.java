package com.justtest.hibernate;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

import java.io.Serializable;
import java.util.Date;

/**
 * User: Grisha Klimov
 * Date: Jul 10, 2008
 * Time: 3:57:23 PM
 */

public class VersionInterceptor extends EmptyInterceptor {

    private static final long serialVersionUID = 4889611313636390174L;



    //delete
    @Override
    public void onDelete(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
        // do nothing
    }

    //update
    @Override
    public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState, String[] propertyNames, Type[] types) {
        boolean currentStateModified = false;
        for (int i = 0; i < propertyNames.length; i++) {
            if ("version".equals(propertyNames[i])) {
                currentStateModified = true;
                currentState[i] = new Date();
                break;
            }
        }
        return currentStateModified;
    }

    //insert
    @Override
    public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
        boolean currentStateModified = false;
        for (int i = 0; i < propertyNames.length; i++) {
            if ("version".equals(propertyNames[i])) {
                currentStateModified = true;
                state[i] = new Date();
                break;
            }
        }
        return currentStateModified;
    }

}
