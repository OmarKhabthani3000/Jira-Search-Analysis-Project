package eu.pinske.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.Test;

import eu.pinske.model.Child;
import eu.pinske.model.Parent;

public class LazyLoadTest {

    @Test
    public void test() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Child c = new Child();
        em.persist(c);
        Parent p = new Parent();
        p.setChild(c);
        em.persist(p);
        em.getTransaction().commit();
        em.clear();
        em.close();

        em = emf.createEntityManager();
        em.getTransaction().begin();
        p = em.find(Parent.class, p.getId());
        em.flush(); // unwanted lazy load occurs here
        em.getTransaction().commit();
        em.close();

        emf.close();
    }

}
