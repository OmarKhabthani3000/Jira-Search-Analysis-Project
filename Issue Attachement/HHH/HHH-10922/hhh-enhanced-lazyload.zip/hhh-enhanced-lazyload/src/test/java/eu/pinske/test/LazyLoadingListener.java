package eu.pinske.test;

import org.hibernate.HibernateException;
import org.hibernate.event.spi.LoadEvent;
import org.hibernate.event.spi.LoadEventListener;

public class LazyLoadingListener implements LoadEventListener {
    private static final long serialVersionUID = 1L;

    public void onLoad(LoadEvent event, LoadType loadType) throws HibernateException {
        if (loadType == IMMEDIATE_LOAD) {
            String msg = loadType + ":" + event.getEntityClassName() + "#" + event.getEntityId();
            throw new RuntimeException(msg);
        }
    }

}
