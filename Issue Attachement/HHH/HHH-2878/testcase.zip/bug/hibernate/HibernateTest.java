package bug.hibernate;

import java.util.List;

import org.hibernate.Session;

import com.ftid.capgui.hibernate.HibernateUtil;
import com.ftid.testutils.DBTestCase;

/**
 * DBTestCase just loads up an in-memory database with the
 * test data.
 */
public class HibernateTest extends DBTestCase {
	public void testGetOne() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		List<One> ones = session.createQuery("from One").list();
		ones.get(0).getThrees().size();	// Force a lazy load
		session.close();
	}
}
