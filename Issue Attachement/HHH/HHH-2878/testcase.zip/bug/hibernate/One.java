/**
 * Copyright(c) 2007, Interactive Data
 */
package bug.hibernate;

import java.util.Set;

/**
 * @author pandrews
 *
 */
public class One {
	int id;
	String value;
	Set threes;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the threes
	 */
	public Set getThrees() {
		return threes;
	}
	/**
	 * @param threes the threes to set
	 */
	public void setThrees(Set threes) {
		this.threes = threes;
	}
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
}
