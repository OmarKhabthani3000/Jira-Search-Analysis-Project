/**
 * Copyright(c) 2007, Interactive Data
 */
package bug.hibernate;

/**
 * @author pandrews
 *
 */
public class Three {
	int id;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
}
