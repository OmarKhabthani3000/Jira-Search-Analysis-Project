-- Hibernate test tables
CREATE TABLE ONE (
    o_id_pk   NUMBER(10) NOT NULL,
    o_val     VARCHAR2(20) NOT NULL
);

CREATE TABLE TWO (
	t_id_pk		NUMBER(10) NOT NULL,
	t_o_val_fk	VARCHAR2(20) NOT NULL,
	t_f_id_fk	NUMBER(10) NOT NULL
);

CREATE TABLE THREE (
	f_id_pk		NUMBER(10) NOT NULL
);

INSERT INTO ONE (o_id_pk, o_val) VALUES (1, 'a');
INSERT INTO ONE (o_id_pk, o_val) VALUES (2, 'a');
INSERT INTO ONE (o_id_pk, o_val) VALUES (3, 'b');
INSERT INTO THREE (f_id_pk) VALUES (1);
INSERT INTO THREE (f_id_pk) VALUES (2);
INSERT INTO TWO (t_id_pk, t_o_val_fk, t_f_id_fk) VALUES (1, 'b', 1);
INSERT INTO TWO (t_id_pk, t_o_val_fk, t_f_id_fk) VALUES (2, 'a', 2);
