package org.hibernate.testing.derby;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DerbyClobTest {

	private SessionFactory sessionFactory;

	@Before
	public void setUp() throws Exception {
		sessionFactory = new Configuration().configure().buildSessionFactory();
	}

	@After
	public void tearDown() throws Exception {
		if (sessionFactory != null) {
			sessionFactory.close();
		}
	}

	@Test
	public void testSmallStringWorks() {
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		session.save(new Record("a record with a small string"));
		session.getTransaction().commit();
		session.close();

		session = sessionFactory.openSession();
		session.beginTransaction();
		@SuppressWarnings("unchecked")
		List<Record> result = session.createQuery("from Record").list();
		assertEquals(1, result.size());
		session.getTransaction().commit();
		session.close();
	}

	// 255 is the default size picked by Hibernate for Derby, somewhere.
	private static final int MAX_STRING_SIZE_WHEN_USING_DERBY = 255;

	// FailsWhenUsingDerby
	@Test
	public void testWithLargeString() {
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		String large = createString(MAX_STRING_SIZE_WHEN_USING_DERBY + 1, 'a');

		try {
			session.save(new Record(large));
		} catch (RuntimeException e) {
			session.getTransaction().rollback();
			session.close();
			throw e;
		}
		session.getTransaction().commit();
		session.close();

		session = sessionFactory.openSession();
		session.beginTransaction();
		@SuppressWarnings("unchecked")
		List<Record> result = session.createQuery("from Record").list();
		assertEquals(1, result.size());
		session.getTransaction().commit();
		session.close();
	}

	// FailsWhenUsingDerby
	@Test
	public void testWithVeryLargeString_FailsWhenUsingDerby() {
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		String large = createString(MAX_STRING_SIZE_WHEN_USING_DERBY * 10, 'a');

		try {
			session.save(new Record(large));
		} catch (RuntimeException e) {
			session.getTransaction().rollback();
			session.close();
			throw e;
		}
		session.getTransaction().commit();
		session.close();

		session = sessionFactory.openSession();
		session.beginTransaction();
		@SuppressWarnings("unchecked")
		List<Record> result = session.createQuery("from Record").list();
		assertEquals(1, result.size());
		session.getTransaction().commit();
		session.close();
	}

	/**
	 * Creates a string of given length
	 */
	private String createString(int length, char c) {
		final String tooLarge;
		{
			char[] array = new char[length];
			Arrays.fill(array, c);
			tooLarge = new String(array);
		}
		return tooLarge;
	}
}
