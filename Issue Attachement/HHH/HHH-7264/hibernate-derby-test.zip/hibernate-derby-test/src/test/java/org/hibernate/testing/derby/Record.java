package org.hibernate.testing.derby;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "RECORDS")
public class Record {

	private long id;
	private String message;

	// Required for JPA/Hibernate
	@SuppressWarnings("unused")
	private Record() {
	}

	public Record(String message) {
		this.message = message;
	}

	@Id
	@Column(name = "ID")
	@GeneratedValue
	public long getId() {
		return id;
	}

	// This is what seems to go wrong with Derby
	@Lob
	@Column(name = "MESSAGE")
	public String getMessage() {
		return message;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
