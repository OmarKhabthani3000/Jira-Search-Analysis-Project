package issue;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OneToOneIssueMain {

    private final Logger logger = LoggerFactory.getLogger(getClass());
    private EntityManagerFactory entityManagerFactory;

    public static void main(String[] args) {
        try {
            new OneToOneIssueMain().run();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void run() throws Exception {
        setUp();
        initData();
        query1();
        query2();
    }

    private void setUp() throws Exception {
        entityManagerFactory = Persistence.createEntityManagerFactory("issue");
    }

    private void initData() {
        Picture p = new Picture();
        Frame f = new Frame();

        f.setId(3);
        f.setPicture(p);
        p.setId(5);
        p.setFrame(f);

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.persist(f);
        entityManager.persist(p);
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    private void query1() {
        logger.info("Query1");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        Picture pictureRef = entityManager.getReference(Picture.class, 5L);

        // list Frames by Picture reference (works)
        List<Frame> frames = entityManager.createQuery("from Frame f where f.picture = :picture", Frame.class)
            .setParameter("picture", pictureRef)
            .getResultList();

        for (Frame f : frames) {
            logger.info("id: {}, picture id: {}", f.getId(), f.getPicture().getId());
        }

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    private void query2() {
        logger.info("Query2");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        Frame frameRef = entityManager.getReference(Frame.class, 3L);

        // list Pictures by Frame reference (crashes!)
        List<Picture> pictures = entityManager.createQuery("from Picture p where p.frame = :frame", Picture.class)
            .setParameter("frame", frameRef)
            .getResultList();

        for (Picture p : pictures) {
            logger.info("id: {}, frame id: {}", p.getId(), p.getFrame().getId());
        }

        entityManager.getTransaction().commit();
        entityManager.close();
    }

}
