package issue;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Picture implements Serializable {

    private static final long serialVersionUID = -1460176252898462917L;

    @Id
    private long id;

    @OneToOne(mappedBy = "picture")
    private Frame frame;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Frame getFrame() {
        return frame;
    }

    public void setFrame(Frame frame) {
        this.frame = frame;
    }

}
