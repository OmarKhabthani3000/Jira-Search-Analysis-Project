
package hibernate.bug.model;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class Person implements Serializable {
    
    private PersonId id;
    private String name;

    public Person() {
    }

    public Person(PersonId id, String name) {
        this.id = id;
        this.name = name;
    }

    @EmbeddedId
    public PersonId getId() {
        return id;
    }

    public void setId(PersonId id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
