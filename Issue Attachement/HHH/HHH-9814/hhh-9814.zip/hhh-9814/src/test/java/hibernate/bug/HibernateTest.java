package hibernate.bug;

import hibernate.bug.model.Person;
import hibernate.bug.model.PersonId;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p1 = new Person(new PersonId("123", "Mosby"), "Ted");
        Person p2 = new Person(new PersonId("123", "Eriksen"), "Marshall");
        
        em.persist(p1);
        em.persist(p2);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testIssue() throws Throwable {
        EntityManager em = emf.createEntityManager();
        
        Long count = em.createQuery("SELECT COUNT(DISTINCT o) FROM Person o", Long.class).getSingleResult();
        Assert.assertEquals(2, count.longValue());
        
        em.close();
    }
}
