package com.example.demo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

@Entity
public class TestEntity {
    @Id
    int id;

    @CreationTimestamp // removing this line fixes the issue
    @Column
    Instant createdAt;
}
