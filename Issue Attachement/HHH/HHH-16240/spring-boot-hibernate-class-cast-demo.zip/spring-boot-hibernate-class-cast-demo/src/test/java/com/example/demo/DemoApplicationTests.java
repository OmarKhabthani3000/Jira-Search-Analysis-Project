package com.example.demo;

import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import org.hibernate.Session;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {

	@Inject EntityManager entityManager;

	@Test
	void showcaseBug() {
		var session = entityManager.unwrap(Session.class);
		try (var statelessSession = session.getSessionFactory().openStatelessSession()) {
			statelessSession.getTransaction().begin();
			statelessSession.insert(new TestEntity());
			statelessSession.getTransaction().commit();
		}
	}

}
