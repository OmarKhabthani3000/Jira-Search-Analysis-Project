package org.test;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;

@Entity
public class Song implements Serializable {

    private static final long serialVersionUID = 19830910L;

    private Long id;                // NUMBER
    private Serializable rawData;   // BLOB

    public Song() {
    }

    public Song(Serializable rawData) {
        this.rawData = rawData;
    }

    @Id
    @GeneratedValue
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Lob
    public Serializable getRawData() {
        return rawData;
    }

    public void setRawData(Serializable rawData) {
        this.rawData = rawData;
    }
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Song)) {
            return false;
        }
        Song other = (Song) object;
        return !((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id)));
    }

    @Override
    public String toString() {
        return "Song{" + "id=" + id + '}';
    }

}
