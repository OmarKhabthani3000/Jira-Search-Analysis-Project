package org.test;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestCase {

    public static void main(String[] args) throws Exception {

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("songs");

        try {
            System.out.println("\ncreating EntityManager and starting transaction");
            EntityManager em = factory.createEntityManager();
            em.getTransaction().begin();

            System.out.println("saving a song");
            Song song = new Song("WildFly - 4.3.7.Final".getBytes());
            em.persist(song);

            System.out.print("committing transaction...");
            em.getTransaction().commit();
            System.out.println("done");

            System.out.print("closing EntityManager...");
            em.close();
            System.out.println("done");

            System.out.println("\ncreating EntityManager and starting transaction");
            em = factory.createEntityManager();
            em.getTransaction().begin();

            System.out.println("listing songs");
            List<Song> songs = em.createQuery("select s from Song s").getResultList();  // exception happens here
            for (Song s : songs) {
                System.out.println("song: " + s.getId() + ", data: " + new String((byte[]) s.getRawData()));
            }
            System.out.print("committing transaction...");
            em.getTransaction().commit();
            System.out.println("done");

            System.out.print("closing EntityManager...");
            em.close();
            System.out.println("done");

        } finally {
            factory.close();
        }
    }
}
