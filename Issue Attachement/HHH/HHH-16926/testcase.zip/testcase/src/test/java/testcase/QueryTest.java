/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package testcase;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Root;
import java.math.BigDecimal;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static org.assertj.core.api.Assertions.assertThat;
import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.output.MigrateResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testcase.db.Primary;
import testcase.db.Primary_;
import testcase.db.Secondary_;

public class QueryTest {

    private static final Logger LOGGER = LogManager.getLogger();

    private EntityManagerFactory emf;
    private EntityManager em;


    @Test
    public void executeQuery() {
        //given
        CriteriaBuilder cb = em.getCriteriaBuilder();
        var query = cb.createQuery(Primary.class);
        Root<Primary> root = query.from(Primary.class);
        var secondaryJoin = root.join(Primary_.secondary);
        //when
        query.select(root).orderBy(
                cb.asc(secondaryJoin.get(Secondary_.name)),
                cb.asc(secondaryJoin.get(Secondary_.secondName))
        );
        var list = em.createQuery(query).getResultList();
        //then
        assertThat(list).hasSize(4);
    }

    @BeforeClass
    private void beforeClass() {
        Flyway flyway = Flyway.configure().dataSource("jdbc:hsqldb:mem:jpa_test", "user", "password").load();
        MigrateResult migrateResult = flyway.migrate();
        LOGGER.info("Migrations: {}", migrateResult.migrationsExecuted);
        emf = Persistence.createEntityManagerFactory("jpa_test");
        em = emf.createEntityManager();
    }

    @AfterClass
    private void afterClass() {
        em.close();
        emf.close();
    }

    @BeforeMethod
    private void beforeMethod() {
        em.getTransaction().begin();
    }

    @AfterMethod
    private void afterMethod() {
        em.getTransaction().rollback();
    }
}
