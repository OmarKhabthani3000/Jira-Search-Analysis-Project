
create schema test;

create table test.t_secondary (
    id integer primary key,
    name character varying (50),
    second_name character varying (50)
);

create table test.t_primary (
    t_secondary_id integer primary key,
    name character varying (50),
    constraint d_primary_t_secondary_id_fkey foreign key(t_secondary_id)
        references test.t_secondary(id) match simple
);

insert into test.t_secondary(id, name, second_name) values (1, 'a', 'a'), (2, 'a', 'ab'),
    (3, 'b', 'ba'), (4, 'b', 'bb');

insert into test.t_primary(t_secondary_id, name)
    values (1, 'a'), (2, 'aa'), (3, 'b'), (4, 'bb');
