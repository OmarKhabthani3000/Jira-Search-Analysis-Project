import java.util.Set;
import java.util.HashSet;


public class Parent
{
 private int id;

 private Set<Child> childs;


 void addChild(Child child)
 {
  if( childs==null ) childs = new HashSet<Child>();

  childs.add(child);
  child.setParent(this);  
 }

 public String toString() { return "Parent("+id+")"; }
}
