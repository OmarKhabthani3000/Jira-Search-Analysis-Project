
public class SubChild
{
 private int id;

 private Child parent;

 public void setParent(Child _parent)
 {
  parent = _parent;
 }
}
