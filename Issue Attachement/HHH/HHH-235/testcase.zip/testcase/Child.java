import java.util.Set;
import java.util.HashSet;

public class Child
{
 private int id;

 private Parent parent;

 private Set<SubChild> subChilds;

 public void setParent(Parent _parent) { parent = _parent; }

 void addSubChild(SubChild subChild)
 {
  if( subChilds==null ) subChilds = new HashSet<SubChild>();

  subChilds.add(subChild);
  subChild.setParent(this);  
 }
}
