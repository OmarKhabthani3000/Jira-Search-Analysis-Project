import java.util.List;

import org.hibernate.*;
import org.hibernate.cfg.*;
import org.hibernate.criterion.*;

public class CriteriaTest
{
 public static void main(String args[])
 {
  Configuration cfg = new Configuration();

  cfg.configure("hibernate.cfg.xml");

  cfg.setProperty(Environment.HBM2DDL_AUTO, "create");

  SessionFactory factory = cfg.buildSessionFactory();

  addTestData(factory);

  queryTestData(factory);

  factory.close();
 }

 static void addTestData(SessionFactory factory)
 {
  Session s = factory.openSession();

  Transaction tx=null;

  try
    {
     tx = s.beginTransaction();

     Parent parent = new Parent();

     Child child = new Child();

     child.addSubChild( new SubChild() );

     parent.addChild(child);

     s.save(parent);

     tx.commit();
    }
  catch( RuntimeException e )
    {
     if (tx!=null) tx.rollback();
     throw e;
    }
  finally { s.close(); }
 }

 static void queryTestData(SessionFactory factory)
 {
  Session s = factory.openSession();

  Transaction tx=null;

  try
    {
     tx = s.beginTransaction();

     Criteria criteria = s.createCriteria(SubChild.class);

//     criteria.setFetchMode("parent",FetchMode.JOIN);

     criteria.createAlias("parent.parent","rootParent");

     criteria.add( Restrictions.eq( "rootParent.id", 1 ) );

     List list = criteria.list();

     for( Object content: list )
       {
        System.out.println("Listing: "+content);
       }

     tx.commit();
    }
  catch( RuntimeException e )
    {
     if (tx!=null) tx.rollback();
     throw e;
    }
  finally { s.close(); }
 }
}
