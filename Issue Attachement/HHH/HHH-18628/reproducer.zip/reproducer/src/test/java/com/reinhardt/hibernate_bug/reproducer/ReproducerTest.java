package com.reinhardt.hibernate_bug.reproducer;

import java.util.List;
import java.util.function.Consumer;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Root;

public class ReproducerTest {

    private EntityManagerFactory emf;

    @BeforeEach
    public void before() throws Exception {
        emf = Persistence.createEntityManagerFactory("ReproducerPU"); //$NON-NLS-1$
    }

    private void inTransaction(final Consumer<EntityManager> work) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        try {
            work.accept(em);
        } finally {
            transaction.rollback();
        }
    }

    @Test
    void shouldTest() throws Exception {
        inTransaction(em -> {
            CriteriaBuilder cb = em.getCriteriaBuilder();

            CriteriaQuery<MessagePair> query = cb.createQuery(MessagePair.class);
            Root<Message> msg = query.from(Message.class);
            Join<Message, MessagePair> startPair = msg.join(Message_.startMessagePair, JoinType.INNER);

            query
                .select(startPair);

            List<MessagePair> list = em.createQuery(query).getResultList();
            Assertions.assertNotNull(list);
        });
    }
}
