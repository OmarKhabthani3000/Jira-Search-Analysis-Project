package com.reinhardt.hibernate_bug.reproducer;

import java.io.Serializable;
import java.math.BigInteger;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "`MessagePair`")
public class MessagePair implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "`Id`", nullable = false)
    @GeneratedValue
    private BigInteger id;

    @OneToOne(optional = false, targetEntity = Message.class, fetch = FetchType.LAZY, cascade = {})
    @JoinColumns({ @JoinColumn(name = "`StartMessageId`", referencedColumnName = "`Id`", nullable = false) })
    private Message startMessage;

    @OneToOne(targetEntity = Message.class, fetch = FetchType.LAZY, cascade = {})
    @JoinColumns({ @JoinColumn(name = "`EndMessageId`", referencedColumnName = "`Id`") })
    private Message endMessage;

    public MessagePair() {
    }

    public BigInteger getId() {
        return this.id;
    }

    public Message getStartMessage() {
        return this.startMessage;
    }

    public void setStartMessage(final Message value) {
        this.startMessage = value;
    }

    public Message getEndMessage() {
        return this.endMessage;
    }

    public void setEndMessage(final Message value) {
        this.endMessage = value;
    }

    @Override
    public String toString() {
        return String.valueOf(getId());
    }
}
