package com.reinhardt.hibernate_bug.reproducer;

import java.io.Serializable;
import java.math.BigInteger;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "`Message`")
public class Message implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "`Id`", nullable = false)
    @GeneratedValue
    private BigInteger id;

    @OneToOne(mappedBy = "startMessage", targetEntity = MessagePair.class, fetch = FetchType.LAZY)
    private MessagePair startMessagePair;

    @OneToOne(mappedBy = "endMessage", targetEntity = MessagePair.class, fetch = FetchType.LAZY)
    private MessagePair endMessagePair;

    public Message() {
    }

    public BigInteger getId() {
        return this.id;
    }

    public MessagePair getStartMessagePair() {
        return this.startMessagePair;
    }

    public void setStartMessagePair(final MessagePair value) {
        this.startMessagePair = value;
    }

    public MessagePair getEndMessagePair() {
        return this.endMessagePair;
    }

    public void setEndMessagePair(final MessagePair value) {
        this.endMessagePair = value;
    }

    @Override
    public String toString() {
        return String.valueOf(getId());
    }
}
