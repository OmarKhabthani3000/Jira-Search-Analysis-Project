package org.hibernate.bugs;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;

public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    public void intParamOnlyTypeInferenceTest() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        // Entity can be anything, doesn't matter here
        CriteriaQuery<Stuff> criteriaQuery = criteriaBuilder.createQuery(Stuff.class);
        Root<Stuff> root = criteriaQuery.from(Stuff.class);

        ParameterExpression<Integer> p1 = criteriaBuilder.parameter(Integer.class);
        ParameterExpression<Integer> p2 = criteriaBuilder.parameter(Integer.class);
        ParameterExpression<Integer> p3 = criteriaBuilder.parameter(Integer.class);

        Predicate predicate = criteriaBuilder.equal(criteriaBuilder.sum(p1, p2), p3);

        criteriaQuery.select(root).where(predicate);

        TypedQuery<Stuff> query = entityManager.createQuery(criteriaQuery);

        query.setParameter(p1, 1);
        query.setParameter(p2, 2);
        query.setParameter(p3, 3);

        // Exception will be thrown, Hibernate fails to infer the type
        query.getResultList();

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    @Test
    public void mixedTypeInferenceTest() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

        //  int_field = long_field: WORKS
        CriteriaQuery<Stuff> criteriaQuery = criteriaBuilder.createQuery(Stuff.class);
        Root<Stuff> root = criteriaQuery.from(Stuff.class);
        Predicate predicate = criteriaBuilder.equal(root.get("id"), root.get("number"));
        criteriaQuery.select(root).where(predicate);
        TypedQuery<Stuff> query = entityManager.createQuery(criteriaQuery);
        query.getResultList();

        //  int_param = long_param: WORKS
        criteriaQuery = criteriaBuilder.createQuery(Stuff.class);
        root = criteriaQuery.from(Stuff.class);
        ParameterExpression<Integer> p1 = criteriaBuilder.parameter(Integer.class);
        ParameterExpression<Long> p2 = criteriaBuilder.parameter(Long.class);
        predicate = criteriaBuilder.equal(p1, p2);
        criteriaQuery.select(root).where(predicate);
        query = entityManager.createQuery(criteriaQuery);
        query.setParameter(p1, 1);
        query.setParameter(p2, 1L);
        query.getResultList();

        // -(int_field) = -(long_param): WORKS
        // Ugly-ass workaround for bug of the last case
        criteriaQuery = criteriaBuilder.createQuery(Stuff.class);
        root = criteriaQuery.from(Stuff.class);
        p2 = criteriaBuilder.parameter(Long.class);
        predicate = criteriaBuilder.equal(criteriaBuilder.neg(root.get("id")), criteriaBuilder.neg(p2));
        criteriaQuery.select(root).where(predicate);
        query = entityManager.createQuery(criteriaQuery);
        query.setParameter(p2, 1L);
        query.getResultList();

        //  int_field = long_param: FAILS, throws ClassCastException
        criteriaQuery = criteriaBuilder.createQuery(Stuff.class);
        root = criteriaQuery.from(Stuff.class);
        p2 = criteriaBuilder.parameter(Long.class);
        predicate = criteriaBuilder.equal(root.get("id"), p2);
        criteriaQuery.select(root).where(predicate);
        query = entityManager.createQuery(criteriaQuery);
        query.setParameter(p2, 1L);
        query.getResultList();

        entityManager.getTransaction().commit();
        entityManager.close();
    }

}
