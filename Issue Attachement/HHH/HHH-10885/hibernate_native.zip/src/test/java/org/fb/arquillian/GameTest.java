/*
 * ----------------------------------------------------------------------------
 * Copyright 2009 - 2016 by PostFinance AG - all rights reserved
 * ----------------------------------------------------------------------------
 */
package org.fb.arquillian;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.Archive;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(Arquillian.class)
public class GameTest {

    @Deployment
    public static Archive<?> init() {
        Archive war =
            ShrinkWrap.create(JavaArchive.class) //
            .addClass(Game.class) //
            .addAsResource("test-persistence.xml", "META-INF/persistence.xml") //
            .addAsManifestResource(EmptyAsset.INSTANCE, "beans.xml");
        System.out.println(war.toString(true));
        return war;
    }

    private static final String[] GAME_TITLES = { "Super Mario Brothers", "Mario Kart", "F-Zero" };

    @PersistenceContext
    private EntityManager entityManager;

    @Inject
    private UserTransaction utx;

    @Before
    public void setUp()
        throws Exception {
        clearData();
        insertData();
        startTransaction();
    }

    private void clearData()
        throws Exception {
        utx.begin();
        entityManager.joinTransaction();
        System.out.println("dumping old recoreds..");
        entityManager.createQuery("delete from Game").executeUpdate();
        utx.commit();
    }

    private void insertData()
        throws Exception {
        utx.begin();
        entityManager.joinTransaction();
        System.out.println("inserting records...");
        for (String title : GAME_TITLES) {
            Game game = new Game(title);
            entityManager.persist(game);
        }
        utx.commit();
        entityManager.clear();
    }

    private void startTransaction()
        throws Exception {
        utx.begin();
        entityManager.joinTransaction();
    }

    @After
    public void tearDown()
        throws Exception {
        utx.commit();
    }

    @Test
    public void testNativeQuery_indexed_ordinal_parameter() {
        Query query = entityManager.createNativeQuery("SELECT * FROM Game g WHERE title = ?1");
        query.setParameter(1, GAME_TITLES[0]);
        List list = query.getResultList();
        assertEquals(1, list.size());
    }
    @Test
    public void testNativeQuery_ordinal_parameter() {
        Query query = entityManager.createNativeQuery("SELECT * FROM Game g WHERE title = ?");
        query.setParameter(1, GAME_TITLES[0]);
        List list = query.getResultList();
        assertEquals(1, list.size());
    }
}
