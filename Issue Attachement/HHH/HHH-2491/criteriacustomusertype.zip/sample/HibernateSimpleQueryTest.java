package sample;

import java.util.List;

import junit.framework.TestCase;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateSimpleQueryTest extends TestCase {

	Configuration configuration = new Configuration();
	SessionFactory sessionFactory = null;
	
	
	public HibernateSimpleQueryTest() {
		configuration.setProperty("hibernate.hbm2ddl.auto",
				"create-drop");
		configuration.addClass(SimpleEntity.class);
		sessionFactory = configuration.buildSessionFactory();
	}

	public void testUniqueResult() throws Exception {
		
		Session s = sessionFactory.openSession();

		// Create
		SimpleEntity de = new SimpleEntity();
		de.setDummyField("dummyText");
		assertNull(de.getEntityPK());
		s.save(de);
		s.flush();
		s.clear();
		assertNotNull(de.getEntityPK());

		// Read
		SimpleEntity de2 = (SimpleEntity) s.load(SimpleEntity.class, de
				.getEntityPK());
		assertNotNull(de2);
		assertEquals(de.getEntityPK(), de2.getEntityPK());

		// Query
		Criteria crit = s.createCriteria(SimpleEntity.class);
		List results = crit.list(); // FAILING IllegalArgumentException in class: sample.SimpleEntity, setter method of property: entityPK
		                            // expected type: sample.IEntityPK, actual value: java.lang.Long
		assertNotNull(results);
		assertEquals(1, results.size());
	}
}
