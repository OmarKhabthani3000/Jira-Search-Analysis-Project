package sample;

import java.io.Serializable;

public interface IEntityPK extends Serializable {

}
