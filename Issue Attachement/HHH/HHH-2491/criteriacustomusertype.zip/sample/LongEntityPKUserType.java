package sample;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.hibernate.HibernateException;
import org.hibernate.type.LongType;
import org.hibernate.usertype.EnhancedUserType;

public class LongEntityPKUserType implements EnhancedUserType {

	public LongEntityPKUserType() {

	}

	public Object assemble(Serializable cached, Object owner) throws HibernateException {
		return cached;
	}

	public Object deepCopy(Object value) throws HibernateException {
		// immutable
		return value;
	}

	public Serializable disassemble(Object value) throws HibernateException {
		return (Serializable) value;
	}

	public boolean equals(Object x, Object y) throws HibernateException {
		return new EqualsBuilder().append(x, y).isEquals();
	}

	public int hashCode(Object x) throws HibernateException {
		return x.hashCode();
	}

	public Object nullSafeGet(ResultSet resultSet, String[] names, Object owner) throws HibernateException, SQLException {
		return new LongType().nullSafeGet(resultSet, names, null, owner);
	}

	public Object replace(Object original, Object target, Object owner) throws HibernateException {
		return original;
	}

	public Class returnedClass() {
		return LongEntityPK.class;
	}

	public int[] sqlTypes() {
		return new LongType().sqlTypes(null);
	}

	public Object fromXMLString(String arg0) {
		return new LongType().fromXMLString(arg0, null);
	}

	public String objectToSQLString(Object arg0) {
		try {
			return new LongType().objectToSQLString(arg0, null);
		} catch (Exception e) {
			IllegalStateException ise = new IllegalStateException();
			ise.initCause(e);
			throw ise;
		}
	}

	public String toXMLString(Object arg0) {
		return new LongType().toXMLString(arg0, null);
	}

	public boolean isMutable() {
		return false;
	}

	public void nullSafeSet(PreparedStatement arg0, Object arg1, int arg2) throws HibernateException, SQLException {
		new LongType().nullSafeSet(arg0, ((LongEntityPK) arg1).getLong(), arg2, null);
	}


}
