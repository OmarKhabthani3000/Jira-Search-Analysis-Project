package sample;

import java.io.Serializable;


public class LongEntityPK implements IEntityPK, Serializable {

	private Long id = null;

	public LongEntityPK(Long id) {
		this.id = id;
	}

	public LongEntityPK(long id) {
		this.id = new Long(id);
	}

	public Long getLong() {
		return id;
	}
	public String toString() {
		if (this.id == null) {
			return super.toString();
		} else {
			return this.id.toString();
		}
	}

	public boolean equals(Object obj) {
		if (!(obj instanceof LongEntityPK)) {
			return false;
		}

		if (this == obj) {
			return true;
		}
		LongEntityPK rhs = (LongEntityPK) obj;
		if (this.id == null || rhs.getLong() == null) {
			return super.equals(rhs);
		} else {
			return this.id.longValue() == rhs.getLong().longValue();
		}
	}

	public int hashCode() {
		if (this.id == null) {
			return super.hashCode();
		} else {
			return this.id.hashCode();
		}
	}

}
