package sample;


public class SimpleEntity {

	private IEntityPK entityPK;
	
	private String dummyField = null;

	public String getDummyField() {
		return dummyField;
	}

	public void setDummyField(String dummyField) {
		this.dummyField = dummyField;
	}

	public IEntityPK getEntityPK() {
		return entityPK;
	}

	public void setEntityPK(IEntityPK entityPK) {
		this.entityPK = entityPK;
	}
	
}
