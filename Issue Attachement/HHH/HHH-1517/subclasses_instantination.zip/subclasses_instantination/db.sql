drop table port;
drop table path;
drop table ne;

create table port(
  name varchar(50),
  t varchar(10),
  NE_ID  varchar(50)
);

create table path(
  name varchar(50),
  t varchar(10),
  LOCAL_NE_ID varchar(50),
  LOCAL_PORT_ID  varchar(50)
);

create table ne(
  name varchar(50),
  t varchar(10),
  config_level int
);

insert into ne values ( 'ne1', 'NE',1);
insert into ne values ( 'ne2', 'NE',1);
insert into ne values ( 'ne3', 'NE',1);
insert into ne values ( 'router1', 'RT',2);

insert into port values ( 'p1', 'PT','router1');

insert into path values( 'path1','P','router1','p1');