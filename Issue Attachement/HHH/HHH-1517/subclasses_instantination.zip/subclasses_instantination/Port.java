package subclasses_instantination;

/**
 * Created by IntelliJ IDEA.
 * User: kosta
 * Date: Feb 22, 2006
 * Time: 12:49:21 PM
 */
public class Port {
  String name;
  NE owner;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public NE getOwner() {
    return owner;
  }

  public void setOwner(NE owner) {
    this.owner = owner;
  }
}
