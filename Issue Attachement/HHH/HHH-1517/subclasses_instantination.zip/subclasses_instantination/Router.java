package subclasses_instantination;

/**
 * Created by IntelliJ IDEA.
 * User: kosta
 * Date: Feb 22, 2006
 * Time: 12:47:12 PM
 */
public class Router extends NE{

  int configLevel;

  public int getConfigLevel() {
    return configLevel;
  }

  public void setConfigLevel(int configLevel) {
    this.configLevel = configLevel;
  }
}
