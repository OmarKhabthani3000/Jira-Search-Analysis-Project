package subclasses_instantination;

/**
 * Created by IntelliJ IDEA.
 * User: kosta
 * Date: Feb 22, 2006
 * Time: 12:48:15 PM
 */
public class Path {
  String name;
  NE localNE;
  Port localPort;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public NE getLocalNE() {
    return localNE;
  }

  public void setLocalNE(NE localNE) {
    this.localNE = localNE;
  }

  public Port getLocalPort() {
    return localPort;
  }

  public void setLocalPort(Port localPort) {
    this.localPort = localPort;
  }
}
