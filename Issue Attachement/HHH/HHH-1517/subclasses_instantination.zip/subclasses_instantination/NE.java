package subclasses_instantination;

/**
 * Created by IntelliJ IDEA.
 * User: kosta
 * Date: Feb 22, 2006
 * Time: 12:47:03 PM
 */
public class NE {
  String name;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}
