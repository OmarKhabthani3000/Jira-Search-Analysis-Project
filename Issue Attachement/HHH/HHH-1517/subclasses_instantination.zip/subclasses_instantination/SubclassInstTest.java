package subclasses_instantination;

import com.sourcelabs.hibernate.tests.HibTest;
import org.hibernate.Session;
import org.hibernate.Hibernate;
import propaccessor.PropListClass;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kosta
 * Date: Feb 22, 2006
 * Time: 12:42:12 PM
 */
public class SubclassInstTest  extends HibTest {

  public void test( Session s ) throws Exception{

    Path p = (Path) s.get( Path.class,"path1");
    System.out.println("path.ne.class = " + p.getLocalNE().getClass().getName() );
    System.out.println( "H thinks it is " + Hibernate.getClass(  p.getLocalNE() ) );
    Port port = p.getLocalPort();
    Router r =  (Router) p.getLocalNE();
  }

  protected String getMappingResource() {
     return "subclasses_instantination/map.hbm.xml";
   }


  public static void main(String[] args) {
    SubclassInstTest t = new SubclassInstTest();
    t.executeTests();
  }


}
