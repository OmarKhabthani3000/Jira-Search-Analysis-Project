package org.hibernate.bugs;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;
import java.util.HashMap;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.hibernate.bugs.model.MyEntity;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestBug {

    private EntityManager em;

    @Before
    public void setup() {

        em = Persistence.createEntityManagerFactory("domain").createEntityManager();
    }

    @After
    public void teardown() {
        em.close();
    }
    
    /**
     * This test currently FAILS with Hibernate 5.1.0.Final
     */
    @Test
    public void test() {
    	em.getTransaction().begin();
    	MyEntity myEntity = new MyEntity();
    	myEntity.setValue("xxx");
    	myEntity.setBytes(new String("abcdefg").getBytes());
        em.persist(myEntity); 
        Long id = myEntity.getId();
        em.getTransaction().commit();
        
        // update the non audited value
    	em.getTransaction().begin();
    	myEntity = em.find(MyEntity.class, id);
    	myEntity.setValue("abc");
        em.getTransaction().commit();
        
        // An audit row should NOT be added for the update, as the audited values have not changed.
        Query q = em.createNativeQuery("select count(*) from MyEntity_aud;");
        long count = ((BigInteger) q.getSingleResult()).longValue();
        
        // If there are 2 rows, that means an audit row was added for the update, which is incorrect.
        assertEquals(1, count);
  
		
    }

}
