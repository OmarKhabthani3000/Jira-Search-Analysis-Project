package com.bsi.common.dao.impl;
/**
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o
 * Implementation of a Generic DAO class with declarative transaction demarcation.
 */
import java.io.Serializable;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.bsi.common.BaseBean;
import com.bsi.common.HibernateMetadaUtil;
import com.bsi.common.HibernateUtil;
import com.bsi.common.dao.DAO;
import com.bsi.common.dao.DAOException;

@SuppressWarnings("unchecked")
public  class BaseDAOImpl<T extends BaseBean>  implements DAO<T>{

	
	private static final Log log = LogFactory.getLog(BaseDAOImpl.class);

	   
	protected SessionFactory sessionFactory;

	protected Class persistentClass;
	protected static final int PAGE_SIZE = 200;

	public BaseDAOImpl ()
	{} 

	/**
	 * 
	 * @param persistentClass its highly recommend that the persistent class be a super class of the BaseBean class
	 */
	public BaseDAOImpl (Class <T> persistentClass)
	{ 
		this.persistentClass = persistentClass;
	}

	public BaseDAOImpl(HibernateUtil hibernateUtil, Class persistentClass) {
		this.persistentClass = persistentClass;
		sessionFactory = hibernateUtil.getSessionFactory();
	}

	public T findById(Map idMap) throws DAOException {
		T baseBean = null;
		//		Transaction transaction = null;
		Session session = null;
		HibernateMetadaUtil metaDataUtil = new HibernateMetadaUtil(sessionFactory);
		Transaction transaction = null;
		try {
			if (persistentClass == null) 
				throw new DAOException("REQUIRED PERSISTENT CLASS NOT FOUND");

			Serializable serializable = (Serializable)metaDataUtil.getIdClassIntance(persistentClass);
			if (metaDataUtil.isPrimitive(serializable.getClass())) 
				serializable = (Serializable)idMap.get("id"); 
			else { 
				for (Object key : idMap.keySet()){ 
					BeanUtils.copyProperty(serializable, (String)key, idMap.get(key));
				}
			}
			session = sessionFactory.openSession();
			transaction = session.beginTransaction(); 
			transaction.begin();
			baseBean = (T)session.get(persistentClass, serializable);
			transaction.commit();
		}catch (Exception ex)
		{ 
			rollbackTransaction(transaction);
			throw new DAOException (ex);
		} 
		finally { 
			closeSession(session);
		}
		return baseBean;
	}

	public void makeTransient(T baseBean) throws DAOException {
		Transaction transaction = null;
		Session session =null;
		try { 
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			transaction.begin();
			session.delete(baseBean);
			transaction.commit();
		}catch (Exception ex)
		{ 
			rollbackTransaction(transaction);
			throw new DAOException (ex);
		} 
		finally { 
			closeSession(session);
		}
	}

	protected void rollbackTransaction(Transaction transaction)throws DAOException
	{
		if (transaction !=null && transaction.isActive() && !transaction.wasCommitted()) { 
			try { 
				transaction.rollback();
			}catch (Exception ex1) 
			{ 
				ex1.printStackTrace();
			}

		}
	}

	public void saveOrUpdate(T object) throws DAOException {
		Transaction transaction = null;
		Session session =null;
		try { 
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			transaction.begin();
			session.saveOrUpdate(object);
			transaction.commit();
		}catch (Exception ex)
		{ 
			rollbackTransaction(transaction);
			throw new DAOException (ex);
		} 
		finally { 
			closeSession(session);
		}
	}

	protected void closeSession(Session session) {
		if (session!=null && session.isOpen()) 
			try { 
				session.close();
			}catch (Exception ex1) 
			{ 
				ex1.printStackTrace();
			}		
	}

	
	
	 public void persist(T transientInstance) {
	        log.debug("persisting T instance");
	        try {
	            sessionFactory.getCurrentSession().persist(transientInstance);
	            log.debug("persist successful");
	        }
	        catch (RuntimeException re) {
	            log.error("persist failed", re);
	            throw re;
	        }
	    }
	    
	    public void attachDirty(T instance) {
	        log.debug("attaching dirty Address instance");
	        try {
	            sessionFactory.getCurrentSession().saveOrUpdate(instance);
	            log.debug("attach successful");
	        }
	        catch (RuntimeException re) {
	            log.error("attach failed", re);
	            throw re;
	        }
	    }
	    
	    public void attachClean(T instance) {
	        log.debug("attaching clean Address instance");
	        try {
	            sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
	            log.debug("attach successful");
	        }
	        catch (RuntimeException re) {
	            log.error("attach failed", re);
	            throw re;
	        }
	    }
	
	/**
	 * @return the persistentClass
	 */
	public Class<T> getPersistentClass() {
		return persistentClass;
	}

	/**
	 * @param persistentClass the persistentClass to set
	 */
	public void setPersistentClass(Class <T> persistentClass) {
		this.persistentClass = persistentClass;
	}

	/**
	 * @return the sessionFactory
	 */
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	/**
	 * @param sessionFactory the sessionFactory to set
	 */
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void refresh (T bean)
	{
		 
		sessionFactory.getCurrentSession().refresh( bean );
	}
}
