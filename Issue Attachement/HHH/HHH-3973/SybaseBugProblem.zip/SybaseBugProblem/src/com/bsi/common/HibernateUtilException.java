/**
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o
 */
package com.bsi.common;

/**
 * @author Jose Carlos Canova - BSI Tecnologia - 21/05/2009 
 *
 */
public class HibernateUtilException extends UnsupportedOperationException
 {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4260681526509777657L;

	/**
	 * 
	 */
	public HibernateUtilException() {
	}

	/**
	 * @param arg0
	 */
	public HibernateUtilException(String arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 */
	public HibernateUtilException(Throwable arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public HibernateUtilException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
