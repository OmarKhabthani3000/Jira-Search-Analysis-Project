package com.bsi.common;

import java.util.regex.Pattern;

/**
 * @author Jose Carlos Canova - BSI Tecnologia - 21/05/2009 
 *
 */
public class BsiStringUtil {


	public static Boolean isEmpty(String value) 
	{ 
		return (value == null || value.trim().length() == 0)?true:false;
	}
	
	public static String traillingZeroesLeft (String value , int length  ) 
	{ 
		StringBuilder builder = new StringBuilder(value);
		if (!(length - value.length() < 0 ))
		for (int i = 0 ; i < length - value.length(); i++)
		{ 
			builder.insert(0 , '0');
		}
		return builder.toString();
	}
	

	/**
	 * Very simple expression to evaluate if some String is a numeric representation
	 * @param value
	 * @return
	 */
	public static boolean isIntNumber (String value) 
	{ 
		return Pattern.matches("[0-9]*", value);
	}
	
	
	public static void main (String args[])
	{ 
		System.out.println(traillingZeroesLeft ("6" , 2));
	}
	
}
