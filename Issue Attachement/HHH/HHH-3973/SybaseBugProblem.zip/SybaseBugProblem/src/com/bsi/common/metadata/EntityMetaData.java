package com.bsi.common.metadata;
/**
 * 
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o.
 *
 * @param <T>
 */
public interface EntityMetaData<T> {

	/**
	 * @return the fieldName
	 */
	public abstract String getFieldName();

	/**
	 * @param fieldName the fieldName to set
	 */
	public abstract void setFieldName(String fieldName);

	/**
	 * @return the fieldType
	 */
	public abstract Class<T> getFieldType();

	/**
	 * @param fieldType the fieldType to set
	 */
	public abstract void setFieldType(Class<T> fieldType);

	/**
	 * @return the required
	 */
	public abstract Boolean getRequired();

	/**
	 * @param required the required to set
	 */
	public abstract void setRequired(Boolean required);

	/**
	 * @return the length
	 */
	public abstract Long getLength();

	/**
	 * @param length the length to set
	 */
	public abstract void setLength(Long length);

	/**
	 * @return the min
	 */
	public abstract Long getMin();

	/**
	 * @param min the min to set
	 */
	public abstract void setMin(Long min);

	/**
	 * @return the max
	 */
	public abstract Long getMax();

	/**
	 * @param max the max to set
	 */
	public abstract void setMax(Long max);

	/**
	 * @return the isColletion
	 */
	public abstract Boolean getIsColletion();

	/**
	 * @param isColletion the isColletion to set
	 */
	public abstract void setIsColletion(Boolean isColletion);

	/**
	 * @return the colletionClass
	 */
	public abstract Boolean getColletionClass();

	/**
	 * @param colletionClass the colletionClass to set
	 */
	public abstract void setColletionClass(Boolean colletionClass);

}