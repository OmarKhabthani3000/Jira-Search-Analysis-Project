package com.bsi.common;
/**
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o
 */
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

	private SessionFactory sessionFactory;
	private static final String defaultHibernateConfiguration = "com/bsi/config/hibernate.cfg.xml";
	private String resourcePath;  
	private static final Semaphore criticalPoint = new Semaphore(1);
	private static HibernateUtil instance = null; 
	private static Map<String , HibernateUtil> instanceMap = new ConcurrentHashMap<String ,HibernateUtil>(); 
	
	private HibernateUtil() {

        sessionFactory = new Configuration()
        .configure( defaultHibernateConfiguration  )
        .buildSessionFactory();
        resourcePath = defaultHibernateConfiguration;
        
	}

	private HibernateUtil(String resourcePath) {

        sessionFactory = new Configuration()
        .configure(resourcePath)
        .buildSessionFactory();
        this.resourcePath = resourcePath;
		
	}
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}


	public static HibernateUtil getInstance () 
	{ 
		try { 
			criticalPoint.acquire();
			if (instance == null) 
				instance = new HibernateUtil ();
		}catch (Exception ex) { 
			ex.printStackTrace();
			throw new HibernateUtilException(ex);
		}finally { 
			criticalPoint.release();
		}
		return instance;
	}

	public static HibernateUtil getInstance (String resourcePath) 
	{ 
		
		try { 
			criticalPoint.acquire();
			HibernateUtil hibernateUtil = null;
			hibernateUtil = (HibernateUtil)instanceMap.get(resourcePath); 
			if (hibernateUtil == null) {  
				hibernateUtil = new HibernateUtil (resourcePath);
				instanceMap.put(resourcePath, hibernateUtil);
			}
			if (hibernateUtil == null) 
				throw new Exception ("Hibernate util creation failed");
			return hibernateUtil;
		}catch (Exception ex) { 
			ex.printStackTrace();
			throw new HibernateUtilException(ex);
		}finally { 
			criticalPoint.release();
		}
		
	}
}
