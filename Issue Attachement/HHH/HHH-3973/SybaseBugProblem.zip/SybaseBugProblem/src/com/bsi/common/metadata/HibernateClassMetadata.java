package com.bsi.common.metadata;
/**
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o
 */
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.metadata.ClassMetadata;

/**
 * @author Jose Carlos Canova - BSI - 209-05-11
 *
 */
public class HibernateClassMetadata implements PersistentClassMetadata {

	private ClassMetadata metaData;
	@SuppressWarnings("unused")
	private Map  <String , MetadataDescriptor>hashMap;
	private String entityName;
	
	/**
	 * 
	 */
	public HibernateClassMetadata() {
	}
	
	/**
	 * @param metaData 
	 * 
	 */
	public HibernateClassMetadata(ClassMetadata meta) {
		this.metaData = meta;
		entityName = metaData.getEntityName();
		String [] propertyNames = metaData.getPropertyNames();
		this.hashMap = Collections.synchronizedMap(new HashMap <String , MetadataDescriptor>());
	}

	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.PersistentClassMetadata#getPropertyClass(java.lang.String)
	 */
	public String getPropertyClass(String propertyName)
			throws PersistentClassMetadataException {
		
		return null;
	}

	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.PersistentClassMetadata#getPropertyLenght(java.lang.String)
	 */
	public String getPropertyLenght(String propertyName)
			throws PersistentClassMetadataException {
		
		return null;
	}

	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.PersistentClassMetadata#getPropertyName(java.lang.String)
	 */
	public String getPropertyName(String propertyName)
			throws PersistentClassMetadataException {
		
		return null;
	}

	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.PersistentClassMetadata#getPropertyNames()
	 */
	public String[] getPropertyNames() {
		return null;
	}
	/**
	 * @return the metaData
	 */
	public ClassMetadata getMetaData() {
		return metaData;
	}
	/**
	 * @param metaData the metaData to set
	 */
	public void setMetaData(ClassMetadata metaData) {
		this.metaData = metaData;
	}
	/**
	 * @return the entityName
	 */
	public String getEntityName() {
		return entityName;
	}
	/**
	 * @param entityName the entityName to set
	 */
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
}
