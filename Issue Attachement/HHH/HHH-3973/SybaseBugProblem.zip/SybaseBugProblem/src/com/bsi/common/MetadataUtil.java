package com.bsi.common;
/**
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o
 */
/**
 * @author Jose Carlos Canova - BSI Tecnologia - 21/05/2009 
 *
 */
public interface MetadataUtil {

	/**
	 * 
	 * @param persistentClass
	 * @return an Empty instance of the ID of the persistent class.
	 * @throws HibernateUtilException
	 */
	@SuppressWarnings("unchecked")
	public abstract Object getIdClassIntance(Class persistentClass)
			throws MetadataUtilException;

}