package com.bsi.common.metadata;
/**
 * 
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o.
 *
 */
@SuppressWarnings("unchecked")
public class MetadataDescriptor {

	public String name; 
	public Integer length; 
	public Boolean required; 
	
	public Class type;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the length
	 */
	public Integer getLength() {
		return length;
	}
	/**
	 * @param length the length to set
	 */
	public void setLength(Integer length) {
		this.length = length;
	}
	/**
	 * @return the required
	 */
	public Boolean getRequired() {
		return required;
	}
	/**
	 * @param required the required to set
	 */
	public void setRequired(Boolean required) {
		this.required = required;
	}
	/**
	 * @return the type
	 */
	public Class getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(Class type) {
		this.type = type;
	}
	
}
