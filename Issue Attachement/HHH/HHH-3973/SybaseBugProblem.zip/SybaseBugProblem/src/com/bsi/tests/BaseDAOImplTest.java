package com.bsi.tests;

import java.util.List;

import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;

import com.bsi.common.HibernateUtil;
import com.bsi.common.dao.impl.BaseDAOImpl;
import com.bsi.domain.TestTablePersistentClass;

public class BaseDAOImplTest extends TestCase {

	public void testSaveOrUpdate() {
		HibernateUtil hutil = HibernateUtil.getInstance(); 
		SessionFactory sessionFactory = hutil.getSessionFactory(); 
		BaseDAOImpl<TestTablePersistentClass<Long>> dao = new BaseDAOImpl<TestTablePersistentClass<Long>>();
		dao.setSessionFactory(sessionFactory); 
		TestTablePersistentClass<Long> person = new TestTablePersistentClass<Long>();
		person.setFirstName("JOSE"); 
		person.setLastName("CANOVA"); 
		person.setPhoneNumber("111222333");
		try {
			dao.saveOrUpdate(person);
		} catch (Exception e) {
			e.printStackTrace();
		}
		fail("Not yet implemented");
	}

	public void testFindByProcedureTransformer()
	{ 		
		HibernateUtil hutil = HibernateUtil.getInstance(); 
		SessionFactory sessionFactory = hutil.getSessionFactory(); 
		Session session = sessionFactory.openSession();
		Query query = session.createSQLQuery("FIND_TEST_TABLE"); 
		query.setResultTransformer( Transformers.aliasToBean(TestTablePersistentClass.class));
		try {
			List <TestTablePersistentClass<Long>> results = query.list();
			assertTrue(results.size() > 0);
		} catch (Throwable e) {
			e.printStackTrace();
		}
		
	}
}
