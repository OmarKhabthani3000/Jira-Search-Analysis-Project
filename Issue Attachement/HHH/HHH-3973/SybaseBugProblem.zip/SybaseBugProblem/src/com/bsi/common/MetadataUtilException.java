/**
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o
 */
package com.bsi.common;

/**
 * @author Jose Carlos Canova - BSI Tecnologia - 21/05/2009 
 *
 */
public class MetadataUtilException extends UnsupportedOperationException	 {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3356223450983387723L;

	/**
	 * 
	 */
	public MetadataUtilException() {
	}

	/**
	 * @param message
	 */
	public MetadataUtilException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public MetadataUtilException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public MetadataUtilException(String message, Throwable cause) {
		super(message, cause);
	}

}
