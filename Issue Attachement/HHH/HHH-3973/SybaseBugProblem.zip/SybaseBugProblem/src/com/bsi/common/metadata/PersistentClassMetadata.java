/**
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o
 */
package com.bsi.common.metadata;

/**
 * @author Jose Carlos Canova - BSI - 11/04/2009
 *
 */
public interface PersistentClassMetadata {

		public String [] getPropertyNames();
		public String getPropertyName(String propertyName) throws PersistentClassMetadataException; 
		public String getPropertyClass(String propertyName)throws PersistentClassMetadataException; 
		public String getPropertyLenght(String propertyName)throws PersistentClassMetadataException; 
}
