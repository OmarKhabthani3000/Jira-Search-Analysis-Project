package com.bsi.common;
/**
 * @author Jose Carlos Canova - BSI Tecnologia - 21/05/2009 
 *
 */
public class DispatcherServletException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4847033983731613941L;

	public DispatcherServletException() {
	}

	public DispatcherServletException(String message) {
		super(message);
	}

	public DispatcherServletException(Throwable cause) {
		super(cause);
	}

	public DispatcherServletException(String message, Throwable cause) {
		super(message, cause);
	}

}
