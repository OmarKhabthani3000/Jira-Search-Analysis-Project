/**
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o
 */
package com.bsi.common.metadata;

/**
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o
 *
 */
public class PersistentClassMetadataException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7105866756829713319L;

	public PersistentClassMetadataException() {
	}

	/**
	 * @param message
	 */
	public PersistentClassMetadataException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public PersistentClassMetadataException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public PersistentClassMetadataException(String message, Throwable cause) {
		super(message, cause);
	}

}
