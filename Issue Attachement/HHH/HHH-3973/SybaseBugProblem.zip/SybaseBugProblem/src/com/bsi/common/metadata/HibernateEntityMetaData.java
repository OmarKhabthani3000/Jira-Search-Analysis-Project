package com.bsi.common.metadata;
/**
 * 
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o.
 *
 * @param <T>
 */
public class  HibernateEntityMetaData<T> implements EntityMetaData<T> {

	public String fieldName; 
	public Class<T> fieldType; 
	public Boolean required; 
	public Long length; 
	public Long min; 
	public Long max; 
	public Boolean isColletion;
	public Boolean colletionClass;
	public Integer getFieldOrder;
	
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#getFieldName()
	 */
	public String getFieldName() {
		return fieldName;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#setFieldName(java.lang.String)
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#getFieldType()
	 */
	public Class<T> getFieldType() {
		return fieldType;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#setFieldType(java.lang.Class)
	 */
	public void setFieldType(Class<T> fieldType) {
		this.fieldType = fieldType;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#getRequired()
	 */
	public Boolean getRequired() {
		return required;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#setRequired(java.lang.Boolean)
	 */
	public void setRequired(Boolean required) {
		this.required = required;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#getLength()
	 */
	public Long getLength() {
		return length;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#setLength(java.lang.Long)
	 */
	public void setLength(Long length) {
		this.length = length;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#getMin()
	 */
	public Long getMin() {
		return min;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#setMin(java.lang.Long)
	 */
	public void setMin(Long min) {
		this.min = min;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#getMax()
	 */
	public Long getMax() {
		return max;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#setMax(java.lang.Long)
	 */
	public void setMax(Long max) {
		this.max = max;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#getIsColletion()
	 */
	public Boolean getIsColletion() {
		return isColletion;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#setIsColletion(java.lang.Boolean)
	 */
	public void setIsColletion(Boolean isColletion) {
		this.isColletion = isColletion;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#getColletionClass()
	 */
	public Boolean getColletionClass() {
		return colletionClass;
	}
	/* (non-Javadoc)
	 * @see com.bsi.common.metadata.EntityMetaData#setColletionClass(java.lang.Boolean)
	 */
	public void setColletionClass(Boolean colletionClass) {
		this.colletionClass = colletionClass;
	}
}
