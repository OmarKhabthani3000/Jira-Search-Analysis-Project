package com.bsi.common;
/**
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o
 */
import java.beans.PropertyDescriptor;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.EntityMode;
import org.hibernate.SessionFactory;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.type.Type;

/**
 * @author Jose Carlos Canova - BSI TECNOLOGIA- 04/05/2009
 *
 */
public class HibernateMetadaUtil implements MetadataUtil {

	private SessionFactory sessionFactory;


	public HibernateMetadaUtil() {
	}

	public HibernateMetadaUtil(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}


	/* (non-Javadoc)
	 * @see com.bsi.common.MetadataUtil#getIdClassIntance(java.lang.Class)
	 */
	@SuppressWarnings("unchecked")
	public Object getIdClassIntance(Class persistentClass) throws MetadataUtilException
	{ 		
		assert (sessionFactory !=null);
		Class idClass = null; 
		Object idInstance = null;
		try { 
			ClassMetadata clazzMeta = sessionFactory.getClassMetadata(persistentClass);
			Type primaryKeyType  = clazzMeta.getIdentifierType(); 
			PropertyDescriptor descriptor = new PropertyDescriptor(clazzMeta.getIdentifierPropertyName() ,clazzMeta.getMappedClass(EntityMode.POJO));
			idClass = descriptor.getPropertyType();
			if (isPrimitive(primaryKeyType.getReturnedClass()))
			{ 
				idInstance = createPrimitiveInstance(idClass);
			}else if ( clazzMeta.getMappedClass(EntityMode.POJO).getConstructor(new Class[]{})!=null) {

				Constructor contructor = idClass.getConstructor(new Class[]{}) ;
				idInstance = contructor.newInstance();
			}
		}catch (Exception ex) 
		{ 
			throw new MetadataUtilException (ex);
		}
		assert (idInstance!=null);
		return (Object) idInstance;
	}


	@SuppressWarnings("unchecked")
	public Serializable createPrimitiveInstance(Class primitiveClass) throws MetadataUtilException {
		Serializable primitiveInstance = null;
		assert (isPrimitive(primitiveClass));
		try { 
			if (primitiveClass.getSuperclass().equals(Number.class))
			{ 	
				primitiveInstance = (Serializable) primitiveClass.getConstructor(new Class[]{String.class}).newInstance(new Object []{"0"});				
			}else if (primitiveClass.equals(String.class)) { 
				primitiveInstance = new String ("");
			}else if (primitiveClass.equals(Timestamp.class)||primitiveClass.equals(Date.class) ) { 
				DateFormat df = new SimpleDateFormat ("YYYY-MM-DD");
				Date date = df.parse("1970-01-01");
				if (primitiveClass.equals(Timestamp.class)) 
					primitiveInstance = new Timestamp(date.getTime());
				else primitiveInstance = date;
			}else { 
				throw new HibernateUtilException ("NON PRIMITIVE INSTANCE CLASS");
			}
		}catch (Exception ex) 
		{ 
			throw new HibernateUtilException (ex);
		}
		assert (primitiveInstance!=null);
		return primitiveInstance;
	}

	//	     * @see     java.lang.Boolean#TYPE
	//	     * @see     java.lang.Character#TYPE
	//	     * @see     java.lang.Byte#TYPE
	//	     * @see     java.lang.Short#TYPE
	//	     * @see     java.lang.Integer#TYPE
	//	     * @see     java.lang.Long#TYPE
	//	     * @see     java.lang.Float#TYPE
	//	     * @see     java.lang.Double#TYPE
	//	     * @see     java.lang.Void#TYPE
	//	     * @see     java.lang.String
	//	     * @see     java.util.Date
	@SuppressWarnings("unchecked")
	public boolean isPrimitive (Class clazz)
	{ 
		Boolean retCode = false; 

		retCode = (clazz.getSuperclass().equals(Number.class) || clazz.equals(Character.class) || clazz.equals(String.class) ||  clazz.equals(Timestamp.class)||clazz.equals(Date.class) )? true : false;

		return retCode;
	}

	/**
	 * @return the sessionFactory
	 */
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	/**
	 * @param sessionFactory the sessionFactory to set
	 */
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

}
