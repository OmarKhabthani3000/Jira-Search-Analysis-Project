/**
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o
 */
package com.bsi.common.dao;

import java.util.Map;

import org.hibernate.SessionFactory;

import com.bsi.common.BaseBean;

/**
 * @author Jose Carlos Canova - BSI TECNOLOGIA- 04/05/2009
 *
 */
@SuppressWarnings("unchecked")
public interface DAO <T>{


	void saveOrUpdate (T object) throws DAOException; 
	void makeTransient (T object)throws DAOException; 
	BaseBean findById(Map idMap)throws DAOException;
	void setSessionFactory (SessionFactory sessionFactory);
	Class<T> getPersistentClass();
	public void persist(T transientInstance);
	public void attachDirty(T instance);
	public void attachClean(T instance) ;
	
	/**
	 * Re-read the state of the given instance from the underlying database. It is inadvisable to use this to implement
	 * long-running sessions that span many business tasks. This method is, however, useful in certain special circumstances.
	 * For example 
	 * <ul> 
	 * <li>where a database trigger alters the object state upon insert or update</li>
	 * <li>after executing direct SQL (eg. a mass update) in the same session</li>
	 * <li>after inserting a Blob or Clob</li>
	 * </ul>
	 */
	public void refresh (T bean);

}
