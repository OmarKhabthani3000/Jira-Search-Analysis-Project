package com.bsi.common;
/**
 * @author Jcanova - 06/06/2009 - BSI Tecnologia de Informa��o
 */
import java.io.Serializable;

/**
 * @author Jose Carlos Canova - BSI TECNOLOGIA- 04/05/2009
 *
 */
public interface BaseBean<T extends Serializable> extends Serializable {

	public T getId(); 
	public void setId(T id ); 
	
}
