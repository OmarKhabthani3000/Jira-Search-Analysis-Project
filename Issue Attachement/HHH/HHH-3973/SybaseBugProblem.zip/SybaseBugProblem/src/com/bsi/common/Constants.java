package com.bsi.common;

/**
 * @author Jose Carlos Canova - BSI Tecnologia - 21/05/2009 
 *
 */
public interface Constants {
	
	public  static final String CLAIM = "claim";
	public  static final String targetActionName = "targetAction";
	public static final String targetURL = "targetURL";
	public static final String HIBERNATE_CONFIG_LOCATION = "com/aegis/config/hibernate.cfg.xml";
	public static final String DEFAULT_CONFIG_LOCATION = "/WEB-INF/tracker-config.xml";
	public static final String CLAIM_LOG_BO = "claimLogBO";
	public static final String  TRACKER_INIT_PARAMETER = "tracker-config-location";
	public static final String  HIBERNATE_INIT_PARAMETER = "hibernate-config-location";
	public static final String ACTION_MAP = "actionMap";
	public static final String TRACKER_KEY = "com.bsi.common.DISPATHER_SERVLET";
	public static final String ACTION_PARAMETER = "performAction";
	
	public static final String LOGID = "logid";
	public static final String CLIENT_NO = "clientNo";
	public static final String CONTRACT_NO = "contractNo";
	public static final String CLAIM_NO = "claimNo";

	//MENSAGENS
	public static final String NAO_LEU_CONFIGURACAO = "Nao leu configura��o";
	
	public static final String actionName = "performAction";
	public static final String servletName = "/main";
	
	
	//Constants for handling interaction using InvocationHandler.
	public static final String CLAIM_TRANSACTION_STATUS = "CLAIM_TRANSACTION_STATUS";
	public static final String NEW_CLAIM_NO = "NEW_CLAIM_NO";
	
	//TODO: put the command class which will handle the current context.
	
	public static final String NEW_CLAIM_STATUS_COMMAND = "NEW_CLAIM_STATUS_COMMAND";
	
	public static final String COMMAND = "COMMAND";
	
	public static final String ACTION_NAME = "ACTION_NAME";
	public static final String AEGIS_USER = "AEGIS_USER";
	public static final String AEGIS_CONTRACT = "contract";

	public static final String CONTRACT = "CONTRACT";
	public static final String AEGIS_USERNAME = "AEGIS_USERNAME";
	public static final String LANGUAGE_ID = "LANGUAGE_ID";
	public static final String CLIENT_NUMBER = "CLIENT_NUMBER";
	public static final String CONTRACT_NUMBER = "CONTRACT_NUMBER";
	public static final String AEGIS_CRITICAL_CONSUMER = "AEGIS_CRITICAL_CONSUMER";
	public static final String CLAIM_TYPE = "CLAIM_TYPE";
	
	public static final String EXPIRED_CLAIM = "EXPIRED_CLAIM";
	
	//EASSIST CODES
	public static final String ASSISTENCE_CODE = "ASSISTENCE_CODE";
	public static final String ATTENDANCE_OBJECT = "atendimento"; 
	public static final String ATTENDANCE_CODE = "codigoAtendimento"; 
	
	public final String ELEMENT_CODE = "dataElementCode"; 
	public final String ELEMENT_NAME = "dataElementName"; 
	
	
	public final String REPAIRER = "REPAIRER"; 
	//BACKEND CONSTANTS> 
	public static final String  BACKEND_MESSAGE = "BACKEND_MESSAGE";

	public static final String INVALID_COMMAND_CALL = "INVALID COMMAND CALL";
	
	public static final String TRUE = "true";
	public static final String FALSE= "false";
	public static final String IS_NO_DEFECT = "SEM_DEFEITO";
	
	public static final String  NEW_CLAIM_HANDLER = "NEW_CLAIM_HANDLER";
	
	public static final String  CURRENT_EVENT = "CURRENT_EVENT";
	public static final String  CURRENT_RECORD = "CURRENT_RECORD";
	
	
	
}
