USE GDBRWRPR;

create procedure dbo.FIND_TEST_TABLE
as
begin


select id = id,
firstName = first_name , 
lastName = last_name, 
phoneNumber = phone_number 
from dbo.TEST_TABLE 

end;


GO
