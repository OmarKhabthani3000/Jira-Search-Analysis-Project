package org.hibernate.hhh9745;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.util.Properties;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Environment;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@RunWith(SpringJUnit4ClassRunner.class)
@TransactionConfiguration
@Transactional
@ContextConfiguration(classes = {
        TestCreateException.TestConfig.class
})
public class TestCreateException extends AbstractTransactionalJUnit4SpringContextTests {

    protected final static String PACKAGE = "org.hibernate.hhh9745";

    @Configuration
    @EnableTransactionManagement
    @ComponentScan(PACKAGE)
    public static class TestConfig {

        @Bean(destroyMethod = "shutdown")
        public EmbeddedDatabase dataSource() {
            return new EmbeddedDatabaseBuilder().
                    setType(EmbeddedDatabaseType.HSQL).
                    ignoreFailedDrops(true).
                    addDefaultScripts().
                    setScriptEncoding("UTF-8").
                    build();
        }

        @Bean
        public SessionFactory sessionFactory() throws IOException, PropertyVetoException {
            final LocalSessionFactoryBuilder factory = new LocalSessionFactoryBuilder(dataSource());
            factory.scanPackages(PACKAGE);
            factory.addProperties(buildProperties());

            return factory.buildSessionFactory();
        }

        @Bean
        public HibernateTransactionManager transactionManager() throws IOException, PropertyVetoException {
            final HibernateTransactionManager txManager = new HibernateTransactionManager();
            txManager.setSessionFactory(sessionFactory());
            txManager.setNestedTransactionAllowed(true);
            txManager.afterPropertiesSet();

            return txManager;
        }

        private Properties buildProperties() {
            final Properties properties = new Properties();

            properties.put(Environment.DIALECT, "org.hibernate.dialect.HSQLDialect");
            properties.put(Environment.SHOW_SQL, true);
            properties.put(Environment.FORMAT_SQL, true);

            properties.put(Environment.AUTOCOMMIT, false);
            properties.put(Environment.RELEASE_CONNECTIONS, "auto");
            properties.put(Environment.FLUSH_BEFORE_COMPLETION, true);
            properties.put(Environment.AUTO_CLOSE_SESSION, false);
            properties.put(Environment.USE_STRUCTURED_CACHE, true);
            properties.put(Environment.GENERATE_STATISTICS, false);

            properties.put(Environment.HBM2DDL_AUTO, "create");
            //properties.put(Environment.HBM2DDL_AUTO, "create-drop");
            //properties.put(Environment.HBM2DDL_AUTO, "validate");
            //properties.put(Environment.HBM2DDL_AUTO, "update");

            return properties;
        }
    }

    @Test
    public void testCreate() {
        Assert.assertNotNull(this);
    }
}
