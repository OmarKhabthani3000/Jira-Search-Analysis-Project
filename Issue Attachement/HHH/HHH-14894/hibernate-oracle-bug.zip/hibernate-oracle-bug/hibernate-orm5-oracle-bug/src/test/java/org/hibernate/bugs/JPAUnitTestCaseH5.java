package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TemporalType;

import org.apache.commons.lang3.time.FastDateFormat;
import org.hibernate.bugs.data.Transaction;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCaseH5 {

	private static final FastDateFormat DATE_FORMAT_FULL = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");
	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh14894TestNativeQuery() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		// Do stuff...

		createTransaction(entityManager, 1L, 123L, "100.00", "2021-10-15 00:00:00");
		createTransaction(entityManager, 2L, 123L,"-200.00", "2021-10-16 00:00:00");
		createTransaction(entityManager, 3L, 123L, "300.00", "2021-10-17 00:00:00");
		createTransaction(entityManager, 4L, 123L, "-400.00", "2021-10-18 00:00:00");

		List<Object[]> result = entityManager
				.createNamedQuery("transaction.calculateValues")
				.setParameter("valueDate", DATE_FORMAT_FULL.parse("2021-10-17 00:00:00"), TemporalType.DATE)
				.getResultList();

		assertThat(result).hasSize(1);
		assertThat(result.get(0)[2]).isEqualTo(new BigDecimal("-100"));

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	private void createTransaction(EntityManager entityManager, Long transactionId, Long accountId, String amount, String valueDate) throws ParseException {
		Transaction tx = new Transaction();
		tx.setTransactionId(transactionId);
		tx.setAccountId(accountId);
		tx.setAmount(new BigDecimal(amount));
		tx.setTimestamp(new Date());
		tx.setValueDate(DATE_FORMAT_FULL.parse(valueDate));
		entityManager.persist(tx);
	}
}
