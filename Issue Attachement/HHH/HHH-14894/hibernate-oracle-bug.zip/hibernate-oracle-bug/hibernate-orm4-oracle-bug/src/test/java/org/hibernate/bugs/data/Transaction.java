package org.hibernate.bugs.data;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "transactions")
@NamedNativeQueries(
        @NamedNativeQuery(
                name = "transaction.calculateValues",
                query = "select account_id, " +
                        " sum(amount) as total, " +
                        // " 0 as day_value " +
                        " SUM(DECODE(SIGN(value_date - :valueDate), -1, amount, 0)) AS day_value " +
                        "from transactions " +
                        "group by account_id",
                resultSetMapping = "transaction.calculateResult"
        )
)
@SqlResultSetMappings(
        @SqlResultSetMapping(
                name = "transaction.calculateResult",
                columns = {
                        @ColumnResult(name = "account_id", type = Long.class),
                        @ColumnResult(name = "total", type = BigDecimal.class),
                        @ColumnResult(name = "day_value", type = BigDecimal.class),
                }
        )
)
public class Transaction {
    @Id
    @Column(name = "transaction_id")
    private Long transactionId;

    @Column(name = "account_id")
    private Long accountId;

    @Column(name = "amount")
    private BigDecimal amount;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "timestamp")
    private Date timestamp;

    @Temporal(TemporalType.DATE)
    @Column(name = "value_date")
    private Date valueDate;

    public Long getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Long transactionId) {
        this.transactionId = transactionId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public Date getValueDate() {
        return valueDate;
    }

    public void setValueDate(Date valueDate) {
        this.valueDate = valueDate;
    }
}
