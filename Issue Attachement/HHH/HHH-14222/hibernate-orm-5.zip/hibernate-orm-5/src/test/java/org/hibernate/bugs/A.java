package org.hibernate.bugs;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class A {
	
	@Id
	@Column(columnDefinition = "char(10)")
	private String id;
	
	@Column(columnDefinition = "char(10)")
	private String something;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn
	private List<B> many;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<B> getMany() {
		return many;
	}

	public void setMany(List<B> many) {
		this.many = many;
	}

	public String getSomething() {
		return something;
	}

	public void setSomething(String something) {
		this.something = something;
	}

}
