package org.hibernate.bugs;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.Statement;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.SessionFactory;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;
	private ConnectionProvider dataSource;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
		ConnectionProvider dataSource = getDataSource(entityManagerFactory);
		this.dataSource = dataSource;
	}
	
    public static ConnectionProvider getDataSource(EntityManagerFactory entityManagerFactory) {
    ConnectionProvider cp = ((SessionFactory) entityManagerFactory).getSessionFactoryOptions()
            .getServiceRegistry()
            .getService(ConnectionProvider.class);
    return cp;
    }

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	/*
	 * This test fails when underlying database uses fixed width columns
	 * for primary and foreign keys. 
	 * 
	 * In this project, H2 is configured with "MODE=PostgreSQL" to emulate 
	 * that behavior. Check persistente.xml.
	 * 
	 * When loading the collection owner "A" by primary key "a", 
	 * StatefulPersistenceContext caches the entity with key "a", 
	 * as passed by parameter to entityManager.find(A.class, "a").
	 * 
	 * When loading "a.getMany()", method getCollectionOwner(Serializable, CollectionPersister)
	 * tries getEntity(EntityKey key). That key is not "a" but "a         ",
	 * because the loaded B row foreign key value is "a         ".
	 * 
	 * This mismatch between primary key "a" passed by parameter
	 * and loaded foreign key value "a         ", yields an empty collection.  
	 */
	@Test
	public void testFindByPrimaryKeyFailsToGetCollectionOwnerWhenJoinColumnWidthIsFixed() throws Exception {
		
		try (Connection connection = dataSource.getConnection()) {
			Statement statement = connection.createStatement();
			statement.addBatch("INSERT INTO A (id, something) VALUES ('a', 'test')"); 
			statement.addBatch("INSERT INTO B (id, many_id) VALUES ('b','a')");
			statement.executeBatch();
			connection.commit();
		}
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		// Do stuff...
		A a = entityManager.find(A.class, "a");
		assertNotNull(a);
		assertEquals("a", a.getId()); // <-- No padding because it's not loaded from database
		assertEquals("test      ", a.getSomething());
		assertNotNull(a.getMany());
		assertEquals(1, a.getMany().size()); // <<<---- FAILS
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	@Test
	public void testFindByQuerySucceedsToGetCollectionOwnerEvenIfJoinColumnWidthIsFixed() throws Exception {
		
		try (Connection connection = dataSource.getConnection()) {
			Statement statement = connection.createStatement();
			statement.addBatch("INSERT INTO A (id, something) VALUES ('a', 'test')"); 
			statement.addBatch("INSERT INTO B (id, many_id) VALUES ('b','a')");
			statement.executeBatch();
			connection.commit();
		}
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		// Do stuff...
		A a = entityManager.createQuery("select a from A a where id = 'a'", A.class).getSingleResult();
		assertNotNull(a);
		assertEquals("a         ", a.getId()); // <<-- Padded because it is loaded from database
		assertEquals("test      ", a.getSomething());
		assertNotNull(a.getMany());
		assertEquals(1, a.getMany().size()); // <<<---- SUCCEEDS
		entityManager.getTransaction().commit();
		entityManager.close();
	}

}
