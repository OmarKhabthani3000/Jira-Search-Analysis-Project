package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import java.io.Serializable;
import java.util.Objects;

@Entity
public class Child implements Serializable {

	@Id
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	private Parent parent;

	@Id
	private String value;

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof Child))
			return false;
		Child child = (Child) o;
		return Objects.equals(parent, child.parent) &&
				Objects.equals(value, child.value);
	}

	@Override
	public int hashCode() {
		return Objects.hash(parent, value);
	}

}
