package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Set;

import static org.junit.Assert.assertEquals;

public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void hhh12276Test() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		Parent parent = new Parent();
		parent.setId(10);
		Child child = new Child();
		child.setParent(parent);
		child.setValue("old");
		parent.getChildren().add(child);

		entityManager.persist(parent);
		entityManager.flush();
		entityManager.detach(parent);
		entityManager.getTransaction().commit();
		entityManager.close();

		// 'parent' is now detached; now let's change it and merge
		Child oldChild = parent.getChildren().iterator().next();
		Child newChild = new Child();
		newChild.setParent(parent);
		newChild.setValue("new");
		parent.getChildren().add(newChild);
		parent.getChildren().remove(oldChild);

		entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(parent);
		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
