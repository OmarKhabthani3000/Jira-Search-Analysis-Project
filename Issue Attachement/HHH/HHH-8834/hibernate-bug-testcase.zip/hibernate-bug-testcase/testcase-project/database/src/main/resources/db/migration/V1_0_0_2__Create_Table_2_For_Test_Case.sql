CREATE TABLE device_property (
  id int(11) NOT NULL AUTO_INCREMENT,
  property_type_id int(11) NOT NULL,
  prop_value varchar(4000) DEFAULT NULL,
  row_version int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (id),
  KEY property_type_id (property_type_id)
) ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;
