CREATE TABLE device_type_property (
  id int(11) NOT NULL AUTO_INCREMENT,
  property_type_id int(11) NOT NULL,
  prop_value varchar(4000) DEFAULT NULL,
  row_version int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (id),
  KEY property_type_id (property_type_id)
) ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;

CREATE TABLE device_type_property_xref (
  device_type_id int(11) NOT NULL,
  property_id int(11) NOT NULL,
  UNIQUE KEY uix_dtpx (device_type_id,property_id),
  KEY property_id (property_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;