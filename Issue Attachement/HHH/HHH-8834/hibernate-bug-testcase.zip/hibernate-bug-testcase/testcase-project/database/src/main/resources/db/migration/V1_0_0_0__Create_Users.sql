
/*
 * USERS connecting to the database
 */
GRANT ALL PRIVILEGES ON *.* TO '${testcase.mysql.user}'\@'${testcase.mysql.server}' IDENTIFIED BY '${testcase.mysql.pass}' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON *.* TO '${testcase.mysql.user}'\@'%' IDENTIFIED BY '${testcase.mysql.pass}' WITH GRANT OPTION;