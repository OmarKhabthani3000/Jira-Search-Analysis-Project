CREATE TABLE property_type (
  id int(11) NOT NULL AUTO_INCREMENT,
  prop_key varchar(64) NOT NULL,
  prop_type varchar(64) DEFAULT NULL,
  description varchar(256) DEFAULT NULL,
  row_version int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (id),
  UNIQUE KEY prop_key (prop_key)
) ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8