package testcase.persistence;

import java.util.ArrayList;
import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import testcase.model.Device;
import testcase.model.DeviceType;

@Component
public abstract class CommonTestBase extends AbstractTransactionalJUnit4SpringContextTests
{
  
  protected abstract DeviceDao getDeviceDao();
  @Resource
  protected DeviceTypeDao deviceTypeDao;

  @Transactional
  public Device testCreateAndSaveDevice()
  {
    return testCreateAndSaveDevice(1);
  }
  
  @Transactional
  public Device testCreateAndSaveDevice(final int index)
  {

    final DeviceType deviceType = deviceTypeDao.load(1);
    Assert.notNull(deviceType);
   
    Device device = new Device();
    device.setDeviceType(deviceType);
    device.setCalibrated(false);
    device.setDeviceAddress(String.format("F6-03-01-01-%02X", (index == 1) ? 0x46 : index));
    device.setDeviceIndex(1);
    device.setDescription("device-description");

    device = getDeviceDao().save(device);
    logger.info("Device Saved.");
    return device;
  }

  public static <T> T getLastItemInList(final Collection<T> collection)
  {
    Assert.notNull(collection, "collection was null");
    Assert.notEmpty(collection, "collection was empty");
    final ArrayList<T> allItems = new ArrayList<T>(collection);
    return allItems.get(allItems.size() - 1);
  }

}
