package testcase.persistence;

import java.util.Collection;

import testcase.model.DevicePropertyValue;

public interface DevicePropertyValueDao extends Dao<DevicePropertyValue, Integer>
{
  Collection<DevicePropertyValue> findAll();
}
