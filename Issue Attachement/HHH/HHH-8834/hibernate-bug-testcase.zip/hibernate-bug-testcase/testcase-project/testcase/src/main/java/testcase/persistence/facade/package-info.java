/**
 * Facade objects.
 * 
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 */
package testcase.persistence.facade;