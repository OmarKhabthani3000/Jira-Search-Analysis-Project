package testcase.persistence.impl.database;

import java.util.Collection;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import testcase.model.DomainObject;
import testcase.persistence.Dao;

public class DaoJPAImpl<T extends DomainObject<PK>, PK extends Number> implements Dao<T, PK>
{

  protected Class<T> domainClass;

  @Resource
  protected EntityManager entityManager;

  public DaoJPAImpl(Class<T> domainClass)
  {
    this.domainClass = domainClass;
  }

  public EntityManager getEntityManager()
  {
    return entityManager;
  }

  public void setEntityManager(EntityManager entityManager)
  {
    this.entityManager = entityManager;
  }

  @Transactional(propagation = Propagation.REQUIRED)
  @Override
  public void delete(final T entity)
  {
    this.getEntityManager().remove(getEntityManager().getReference(domainClass, entity.getId()));
  }
  
  public void detach(T entity)
  {
    getEntityManager().detach(entity);
  }

  @Transactional
  @Override
  public T load(final PK id)
  {
    return this.getEntityManager().find(domainClass, id);
  }

  @Transactional(propagation = Propagation.NOT_SUPPORTED)
  @Override
  public T loadAndDetach(final PK id)
  {
    final T entity = this.load(id);
    getEntityManager().detach(entity);
    return entity;
  }

  @Transactional
  @Override
  public T loadReference(final PK id)
  {
    return getEntityManager().getReference(domainClass, id);
  }
  
  @Transactional
  @Override
  public T save(final T entity)
  {
    return this.getEntityManager().merge(entity);
  }

  @Override
  public Collection<T> findAll(int first, int count)
  {
    final CriteriaQuery<T> cQuery = getEntityManager().getCriteriaBuilder().createQuery(domainClass);
    final Root<T> root = cQuery.from(domainClass);
    cQuery.select(root);
    final TypedQuery<T> query = getEntityManager().createQuery(cQuery);
    query.setFirstResult(first);
    query.setMaxResults(count);
    return query.getResultList();
  }

  @Override
  public Long getCount()
  {
    final CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
    final CriteriaQuery<Long> query = cb.createQuery(Long.class);
    final Root<T> root = query.from(domainClass);
    query.select(cb.count(root));
    return getEntityManager().createQuery(query).getSingleResult();
  }

}
