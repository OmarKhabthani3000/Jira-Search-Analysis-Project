/**
 * 
 */
package testcase.persistence;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import testcase.model.Device;
import testcase.util.LogManager;

/**
 * Tests for Device Dao.
 * 
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 * @version 1.0
 */
@Component
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:testcase/persistence/package-context.xml")
@Rollback
public class DeviceTest extends CommonTestBase
{
  
  @Resource
  private DeviceDao deviceDao;
  @Resource
  private PropertyTypeDao propTypeDao;

  public String port;
  public String dbName;
  public String server;
  
  @PostConstruct
  public void showDatabaseServer()
  {
    LogManager.getLogger(getClass()).info("MySQL Server: jdbc:mysql://{}:{}/{}", server, port, dbName);
  }

  @Value("${testcase.mysql.server}")
  public void setServer(final String server)
  {
    this.server = server;
  }

  @Value("${testcase.mysql.port}")
  public void setPort(final String port)
  {
    this.port = port;
  }

  @Value("${testcase.mysql.dbname}")
  public void setDbName(final String dbName)
  {
    this.dbName = dbName;
  }

//  @Test
//  @Transactional
//  public void lookupPropertyValueForDeviceSmokeTest()
//  {
//    super.testCreateAndSaveDevice();
//    // Just want to make sure the query doesn't bomb out... no value will be available.
//    deviceDao.findDevicePropertyValue(getLastItemInList(deviceDao.findAll()), WaterHeaterPropertyTypes.ELEMENT_RATING_KEY);
//  }
  
  @Test
  public void loadDevice()
  {
    LogManager.getLogger(getClass()).debug("test loadReference()");
    Device device = deviceDao.loadReference(Integer.valueOf(807));
    Assert.notNull(device, "device was null on loadReference() call");
    LogManager.getLogger(getClass()).debug("got a reference with id: {}", device.getId());
    LogManager.getLogger(getClass()).debug("test load()");
    device = deviceDao.load(Integer.valueOf(device.getId()));
    Assert.notNull(device, "device was null on load() call");
    LogManager.getLogger(getClass()).info(ToStringBuilder.reflectionToString(device));
    LogManager.getLogger(getClass()).info("TEST WORKED!");
  }
  
  @Override
  protected DeviceDao getDeviceDao()
  {
    return deviceDao;
  }

}
