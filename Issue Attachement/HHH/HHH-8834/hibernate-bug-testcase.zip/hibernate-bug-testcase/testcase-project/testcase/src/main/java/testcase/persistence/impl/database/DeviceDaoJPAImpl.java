package testcase.persistence.impl.database;

import java.util.Collection;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import testcase.model.Device;
import testcase.model.DevicePropertyValue;
import testcase.persistence.DeviceDao;

@Repository
public class DeviceDaoJPAImpl extends DaoJPAImpl<Device, Integer> implements DeviceDao
{

  public DeviceDaoJPAImpl()
  {
    super(Device.class);
  }

  @Override
  @Transactional
  public Collection<Device> findAll()
  {
    TypedQuery<Device> query = getEntityManager().createQuery("select entity from Device entity", Device.class);
    return query.getResultList();
  }

  @Override
  public Device findByAddress(final String deviceAddress)
  {
    Assert.notNull(deviceAddress, "device address is null");
    final TypedQuery<Device> query = getEntityManager().createQuery("SELECT d from Device d WHERE d.deviceAddress = :deviceAddress", Device.class);
    query.setParameter("deviceAddress", deviceAddress);
    return query.getSingleResult();
  }


  @Override
  public DevicePropertyValue findDevicePropertyValue(final Device device, final String propertyTypeKey)
  {
    Assert.notNull(device, "device was null");
    Assert.notNull(propertyTypeKey, "propertyTypeKey was null");
    final TypedQuery<DevicePropertyValue> query = getEntityManager().createQuery("select pv from DevicePropertyValue pv JOIN pv.device dev where dev.id = :deviceId and pv.deviceProperty.key = :propertyTypeKey", DevicePropertyValue.class);
    query.setParameter("deviceId", device.getId());
    query.setParameter("propertyTypeKey", propertyTypeKey);
    final Collection<DevicePropertyValue> results = query.getResultList();
    if (results != null && results.size() > 0)
    {
      return results.iterator().next();
    }
    return null;
  }

  @Override
  public void deleteProperties(final Device device)
  {
    Assert.notNull(device, "device was null");
    final javax.persistence.Query query = getEntityManager().createQuery("delete from DevicePropertyValue pv where pv.device.id = :deviceId");
    query.setParameter("deviceId", device.getId());
    query.executeUpdate();
  }

  public void clearCache()
  {
    // Do nothing, not a caching impl.
  }

}
