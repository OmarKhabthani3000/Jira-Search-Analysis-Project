package testcase.model;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Represents a property for a device. Devices might have different properties based on the specific device type
 * assigned.
 * 
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 * @version 1.0
 * @created 31-May-2013 4:10:47 PM
 */
@Entity
@Cacheable
@Table(name = "property_type")
public class PropertyType extends DescriptiveDomainObject<Integer>
{

  private static final long serialVersionUID = -4832671305390948585L;

  /**
   * The (java?) type for values of this property.
   */
  @Column(name = "prop_type")
  private String type;

  /**
   * The property key - unique string identifier.
   */
  @Column(name = "prop_key", length = 64, unique = true, nullable = false)
  private String key;

  public PropertyType()
  {
    super();
  }

  /**
   * @return the type
   */
  public String getType()
  {
    return type;
  }

  /**
   * @param type the type to set
   */
  public void setType(final String type)
  {
    this.type = type;
  }

  /**
   * @return the key
   */
  public String getKey()
  {
    return key;
  }

  /**
   * @param key the key to set
   */
  public void setKey(String key)
  {
    this.key = key;
  }

  @Override
  protected final int domainObjectPrimeNumber()
  {
    return 59;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode()
  {
    final int prime = domainObjectPrimeNumber();
    int result = super.hashCode();
    result = prime * result + ((getKey() == null) ? 0 : getKey().hashCode());
    return result;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj)
  {
    if (this == obj) return true;
    if (!super.equals(obj)) return false;
    if (!(obj instanceof PropertyType)) return false;
    PropertyType other = (PropertyType) obj;
    if (getKey() == null)
    {
      if (other.getKey() != null) return false;
    }
    else if (!getKey().equals(other.getKey())) return false;
    return true;
  }

  public void finalize() throws Throwable
  {
  }

}