/**
 * 
 */
package testcase.model;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 */
@Entity
@Cacheable
@Table(name = "device_type_property")
public class DeviceTypeProperty extends DevicePropertyBase<Integer>
{

  private static final long serialVersionUID = 6320159034979157577L;

  @ManyToOne(cascade = { CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH }, fetch = FetchType.LAZY)
  @JoinTable(name = "device_type_property_xref", 
          joinColumns = @JoinColumn(name ="property_id", referencedColumnName = "id"),
          inverseJoinColumns = @JoinColumn(name = "device_type_id", referencedColumnName = "id"))
  private DeviceType deviceType;
  
  public DeviceTypeProperty()
  {
    super();
  }

  /**
   * @return the deviceType
   */
  public DeviceType getDeviceType()
  {
    return deviceType;
  }

  /**
   * @param deviceType the deviceType to set
   */
  public void setDeviceType(DeviceType deviceType)
  {
    this.deviceType = deviceType;
  }

  /**
   * The value, in this case, is for default values to be set for device properties when they're transferred over to a
   * device.
   */
  @Override
  public String getValue()
  {
    return super.getValue();
  }
 
  @Override
  protected final int domainObjectPrimeNumber()
  {
    return 7;
  }
  
  /**
   * See notes in {@link DomainObject#hashCode()}. This class uses a business key of deviceType and deviceProperty (
   * {@link PropertyType}), which should be immutable and unique after saving an object, in addition to the primary key
   * as implemented in {@link DomainObject#hashCode()}.
   */
  @Override
  public int hashCode()
  {
    final int prime = domainObjectPrimeNumber();
    int result = super.hashCode();
    result = prime * result + ((getDeviceType() == null) ? 0 : getDeviceType().hashCode());
    result = prime * result + ((getDeviceProperty() == null) ? 0 : getDeviceProperty().hashCode());
    return result;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(final Object obj)
  {
    if (this == obj) return true;
    if (!super.equals(obj)) return false;
    if (!(obj instanceof DeviceTypeProperty)) return false;
    final DeviceTypeProperty other = (DeviceTypeProperty) obj;
    if (getDeviceType() == null)
    {
      if (other.getDeviceType() != null) return false;
    }
    else if (!getDeviceType().equals(other.getDeviceType())) return false;
    if (getDeviceProperty() == null)
    {
      if (other.getDeviceProperty() != null) return false;
    }
    else if (!getDeviceProperty().equals(other.getDeviceProperty())) return false;
    return true;
  }

}
