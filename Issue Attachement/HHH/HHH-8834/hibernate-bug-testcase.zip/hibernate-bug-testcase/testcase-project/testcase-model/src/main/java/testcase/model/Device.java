package testcase.model;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.util.Assert;

/**
 * This object refers to a controllable load in the field.
 * 
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 * @version 1.0
 * @created 31-May-2013 4:10:46 PM
 */
@Entity
@Cacheable
@Table(name = "device")
public class Device extends DescriptiveDomainObject<Integer>
{

  private static final long serialVersionUID = 1672057670908387510L;

  @Column(name = "device_group_id")
  private int deviceGroupId;

  /**
   * This is the device's unique MAC Address, Serial Number, or Security Key or a combination of the Gateway MAC Address
   * and a Device Identifier. GatewayMAC::DeviceSeqR::DeviceIndex example: 00:50:C2:75:9D:D1::XX:XX:XX:XX:XX:00::00
   */
  @Basic
  @Valid
  @Pattern(regexp = "^([0-9A-F]{2}[-]){4}([0-9A-F]{2})$")
  @Column(name = "address")
  private String deviceAddress;
  /**
   * The index of this device -- used when dispatching messages.
   */
  @Column(name = "device_index")
  private int deviceIndex;
  /**
   * Manually set flag noting that this device has been calibrated.
   */
  @Column(name = "calibrated", columnDefinition = "BIT", length = 1)
  private boolean calibrated;
  /**
   * This is a collection of the set of properties / values for this specific device. The property set is based on the
   * DeviceType assigned, and they will be things like: Capacity, DeadBand, DesiredTemp, EfficiencyRating, KWIncrement,
   * MaxTemp, MinTemp, RatedKW, etc. (as an example for a water heater).
   */

  @ManyToOne
  @JoinColumn(name = "device_type_id", referencedColumnName = "id")
  private DeviceType deviceType;

  @OneToMany(mappedBy = "device", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
  @OrderBy
  private Set<DevicePropertyValue> deviceProperties;

  public Device()
  {
    super();
  }

  /**
   * @return the deviceType
   */
  public DeviceType getDeviceType()
  {
    return deviceType;
  }

  /**
   * @param deviceType the deviceType to set
   */
  public void setDeviceType(final DeviceType deviceType)
  {
    this.deviceType = deviceType;
  }


  /**
   * @return the deviceAddress
   */
  public String getDeviceAddress()
  {
    return deviceAddress;
  }

  /**
   * @param deviceAddress the deviceAddress to set
   */
  public void setDeviceAddress(final String deviceAddress)
  {
    Assert.notNull(deviceAddress, "deviceAddress was null");
    Assert.isTrue(deviceAddress.matches("^([0-9A-F]{2}[-]){4}([0-9A-F]{2})$"), "the deviceAddress string does not match the required pattern");
    this.deviceAddress = deviceAddress;
  }

  /**
   * @return the deviceIndex
   */
  public int getDeviceIndex()
  {
    return deviceIndex;
  }

  public String getDerivedDeviceAddress()
  {
    return formatDerivedDeviceAddress(deviceAddress, deviceIndex);
  }

  public static String formatDerivedDeviceAddress(final String deviceAddress, final int deviceIndex)
  {
    return String.format("%s-%02X", (deviceAddress != null && deviceAddress.matches("^([0-9A-F]{2}[-]){4}([0-9A-F]{2})$")) ? deviceAddress : "00-00-00-00-00", (deviceIndex & 0xFF));
  }

  /**
   * This will set the deviceAddress and the device index based on a string matching the following RE pattern:
   * ^([0-9A-F]{2}[-]){5}([0-9]{2})$ Where the last octet is the device index (padded with a zero if needed).
   * 
   * @param derivedDeviceAddress the derived device address
   */
  public void setDerivedDeviceAddress(final String derivedDeviceAddress)
  {
    setDeviceAddress(parseDeviceAddress(derivedDeviceAddress));
    setDeviceIndex(parseDeviceIndex(derivedDeviceAddress));
  }

  private static void checkDerivedAddressFormat(final String derivedDeviceAddress)
  {
    Assert.notNull(derivedDeviceAddress, "derivedDeviceAddress was null");
    Assert.isTrue(derivedDeviceAddress.matches("^([0-9A-F]{2}[-]){5}([0-9A-F]{2})$"), "the derivedDeviceAddress string does not match the required pattern");
  }

  public static String parseDeviceAddress(final String derivedDeviceAddress)
  {
    checkDerivedAddressFormat(derivedDeviceAddress);
    return derivedDeviceAddress.substring(0, 14);
  }

  public static int parseDeviceIndex(final String derivedDeviceAddress)
  {
    checkDerivedAddressFormat(derivedDeviceAddress);
    return Integer.valueOf(derivedDeviceAddress.substring(15, 17), 16);
  }

  /**
   * @param deviceIndex the deviceIndex to set
   */
  public void setDeviceIndex(final int deviceIndex)
  {
    Assert.isTrue(deviceIndex >= 0 && deviceIndex < 256, "deviceIndex is out of the range of valid values (0 - 255)");
    this.deviceIndex = deviceIndex;
  }

  /**
   * @return the calibrated
   */
  public boolean isCalibrated()
  {
    return calibrated;
  }

  /**
   * @param calibrated the calibrated to set
   */
  public void setCalibrated(final boolean calibrated)
  {
    this.calibrated = calibrated;
  }

  /**
   * @return the deviceProperties
   */
  public Collection<DevicePropertyValue> getDeviceProperties()
  {
    return deviceProperties;
  }

  /**
   * @param deviceProperties the deviceProperties to set
   */
  public void setDeviceProperties(final Collection<DevicePropertyValue> deviceProperties)
  {
    if (deviceProperties instanceof Set)
    {
      this.deviceProperties = (Set<DevicePropertyValue>) deviceProperties;
    }
    else
    {
      this.deviceProperties = new LinkedHashSet<DevicePropertyValue>(deviceProperties);
    }
  }

  public int getDeviceGroupId()
  {
    return deviceGroupId;
  }

  public void setDeviceGroupId(int deviceGroupId)
  {
    this.deviceGroupId = deviceGroupId;
  }

  @Override
  protected final int domainObjectPrimeNumber()
  {
    return 107;
  }

  /**
   * See notes in {@link DomainObject#hashCode()}. This class uses a business key of deviceAddress and deviceType, which
   * should be immutable after saving an object, in addition to the primary key as implemented in
   * {@link DomainObject#hashCode()}.
   */
  @Override
  public int hashCode()
  {
    int result = super.hashCode();
    result = domainObjectPrimeNumber() * result + ((getDeviceAddress() == null) ? 0 : getDerivedDeviceAddress().hashCode());
    return result;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(final Object obj)
  {
    if (this == obj) return true;
    if (!super.equals(obj)) return false;
    if (!(obj instanceof Device)) return false;
    final Device other = (Device) obj;
    if (getDeviceAddress() == null)
    {
      if (other.getDeviceAddress() != null) return false;
    }
    else if (!getDeviceAddress().equals(other.getDeviceAddress())) return false;
    return true;
  }

  public void finalize() throws Throwable
  {
  }

  /**
   * Quick test of the setDerivedDeviceAddress / getDerivedDeviceAddress method.
   * 
   * @param args none required
   */
  public static void main(final String[] args)
  {
    final Device dev = new Device();
    dev.setDerivedDeviceAddress("06-03-01-01-A6-AF");
    System.out.println(Integer.valueOf("AF", 16));
    Assert.isTrue("06-03-01-01-A6".equals(dev.getDeviceAddress()), String.format("device address doesn't match: %s", dev.getDeviceAddress()));
    Assert.isTrue(dev.getDeviceIndex() == 175, String.format("device index is incorrect: %03d", dev.getDeviceIndex()));
    System.out.println(String.format("Derived DeviceAddres: %s\nDeviceAddress: %s\nDeviceIndex: %02d", dev.getDerivedDeviceAddress(), dev.getDeviceAddress(), dev.getDeviceIndex()));
    System.out.println(ToStringBuilder.reflectionToString(dev, ToStringStyle.MULTI_LINE_STYLE));
    final Device dev2 = new Device();
    System.out.println(String.format("DerivedDeviceAddres:2 = %s", dev2.getDerivedDeviceAddress()));
    dev2.setDeviceAddress("06-03-01-01-A6-AF");
    System.out.println(String.format("DerivedDeviceAddres:2 = %s", dev2.getDerivedDeviceAddress()));
  }

}