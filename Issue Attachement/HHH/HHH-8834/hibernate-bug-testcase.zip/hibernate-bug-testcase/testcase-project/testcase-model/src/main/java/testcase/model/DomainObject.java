package testcase.model;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * The base persistable object.
 * 
 * @author Jeff Eden <edenj@battelle.org>
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 */
@MappedSuperclass
public abstract class DomainObject<PK_TYPE extends Number> implements Serializable
{

  private static final long serialVersionUID = -3568573436641866286L;
  @Transient
  final UUID _defaultKey;

  protected DomainObject()
  {
    _defaultKey = UUID.randomUUID();
  }

  /*
   * The identifier for the persistence object
   */
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "id")
  protected PK_TYPE id;

  /**
   * The persistence row version for optimistic locks
   */
  @Version
  @Column(name = "row_version")
  protected Integer rowVersion = 0;

  public PK_TYPE getId()
  {
    return id;
  }

  public void setId(PK_TYPE id)
  {
    this.id = id;
  }

  public Integer getRowVersion()
  {
    return rowVersion;
  }

  public void setRowVersion(final Integer rowVersion)
  {
    this.rowVersion = rowVersion;
  }

  @Override
  public String toString()
  {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
  }

  /**
   * Note, the implementation works like this:<br/>
   * <br/>
   * - If we DO NOT yet have a primary key (obtained by saving the domain object to the database via JPA persistence),
   * we use a default key (a random UUID generated in the constructor).<br/>
   * - If we DO have a primary key, then we use it as the basis for calculating a hashCode.<br/>
   * <br/>
   * Note: Since it works this way, this means that the hashCode *will likely* change between the time you create a new
   * domain object and the time the persistence engine returns a NEW object; so... you'll want to make sure to remove
   * and re-add the new object handed back from the persistence engine to any hash-based map / collection the domain
   * object has been inserted into, otherwise you might "lose track of it" in the collection since the hashCode will
   * have changed.<br/>
   * <br/>
   * Also, if you have a true business key that is immutable that's valid both before and after the persistence engine
   * saves a domain object, you should override and re-implement the hashCode() method using the business key so you
   * never have to worry about this (at least as long as all parts of the business key are set BEFORE you add the object
   * to the collection / map).
   * 
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode()
  {
    final int prime = (getClass() != DomainObject.class) ? domainObjectPrimeNumber() : 31;
    int result = 1;
    result = prime * result + ((getId() == null) ? _defaultKey.hashCode() : getId().hashCode());
    return result;
  }

  /**
   * This method should be implemented by all "final" domain objects, and should provide a unique prime number for use
   * in this method's hashCode() implementation, and all overridden hashCode() methods should call this method to get
   * the prime number to use (even though it could be obtained "locally"), just for consistency's sake.
   * 
   * @return
   */
  protected abstract int domainObjectPrimeNumber();

  /*
   * (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj)
  {
    if (this == obj) return true;
    if (obj == null) return false;
    if (!(obj instanceof DomainObject)) return false;
    @SuppressWarnings("unchecked")
    final DomainObject<PK_TYPE> other = (DomainObject<PK_TYPE>) obj;
    if (id == null)
    {
      if (other.id != null) return false;
      else if (!other._defaultKey.equals(_defaultKey)) return false;
    }
    else if (!id.equals(other.id)) return false;
    return true;
  }

}
