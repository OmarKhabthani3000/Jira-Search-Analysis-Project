package testcase.model;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;

/**
 * This class is a property value pair base class.
 * 
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 * @version 1.0
 * @created 27-July-2013 4:10:46 PM
 */
@MappedSuperclass
public abstract class DevicePropertyBase<PK_TYPE extends Number> extends DomainObject<PK_TYPE>
{

  private static final long serialVersionUID = 8241222580526919551L;

  /**
   * Identifier
   */

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "property_type_id", referencedColumnName = "id")
  private PropertyType deviceProperty;

  @Column(name = "prop_value")
  private String value;

  public DevicePropertyBase()
  {
    super();
  }

  /**
   * Copy constructor.
   * 
   * @param input object to copy
   */
  public DevicePropertyBase(final DevicePropertyBase<PK_TYPE> input)
  {
    super();
    setDeviceProperty(input.getDeviceProperty());
    setValue(input.getValue());
  }

  /**
   * @return the deviceProperty
   */
  public PropertyType getDeviceProperty()
  {
    return deviceProperty;
  }

  /**
   * @param deviceProperty the deviceProperty to set
   */
  public void setDeviceProperty(final PropertyType deviceProperty)
  {
    this.deviceProperty = deviceProperty;
  }

  /**
   * @return the value
   */
  public String getValue()
  {
    return value;
  }

  /**
   * @param value the value to set
   */
  public void setValue(final String value)
  {
    this.value = value;
  }

  public void finalize() throws Throwable
  {
  }

}