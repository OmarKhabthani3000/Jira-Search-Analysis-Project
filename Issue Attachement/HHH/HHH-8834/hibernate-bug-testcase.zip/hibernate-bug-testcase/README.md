# README #

### What is this repository for? ###

* Repository with a test case for a hibernate bug I found and want to track with future hibernate releases.

### Who do I talk to? ###

* Kendal Montgomery <kendal.montgomery@armadapower.com>
