/**
 * 
 */
package testcase.persistence;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import testcase.model.Device;
import testcase.persistence.facade.DeviceFacade;
import testcase.util.LogManager;

/**
 * Tests for Device Dao.
 * 
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 * @version 1.0
 */
@Component
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@TransactionConfiguration(defaultRollback = true)
public class DeviceTest extends CommonTestBase
{
  
  @Resource
  private DeviceFacade deviceFacade;
  @Resource
  private DeviceDao deviceDao;
  @Resource
  private PropertyTypeDao propTypeDao;

  public String port;
  public String dbName;
  public String server;
  
  private String deviceIds;

  @PostConstruct
  public void showDatabaseServer()
  {
    LogManager.getLogger(getClass()).info("MySQL Server: jdbc:mysql://{}:{}/{}", server, port, dbName);
  }

  @Value("${mysql.server}")
  public void setServer(final String server)
  {
    this.server = server;
  }

  @Value("${mysql.port}")
  public void setPort(final String port)
  {
    this.port = port;
  }

  @Value("${mysql.dbname}")
  public void setDbName(final String dbName)
  {
    this.dbName = dbName;
  }

//  @Test
//  @Transactional
//  public void lookupPropertyValueForDeviceSmokeTest()
//  {
//    super.testCreateAndSaveDevice();
//    // Just want to make sure the query doesn't bomb out... no value will be available.
//    deviceDao.findDevicePropertyValue(getLastItemInList(deviceDao.findAll()), WaterHeaterPropertyTypes.ELEMENT_RATING_KEY);
//  }
  
//  @Test
  @Transactional
//  public void testResetDeviceProperties()
//  {
//    super.testCreateAndSaveDevice();
//    final Device device = getLastItemInList(deviceDao.findAll());
//    deviceFacade.resetDevicePropertiesToDefaults(device);
//  }

//  @Test
//  public void runResetAll()
//  {
//    Assert.notNull(deviceFacade, "deviceFacade was null");
//    LogManager.getLogger(getClass()).info("Running property reset on devices {}", deviceIds);
//    for (final String deviceId : deviceIds.split(","))
//    {
//      LogManager.getLogger(getClass()).debug("running on id {}", deviceId);
//      final Device device = deviceFacade.loadDevice(Integer.valueOf(deviceId));
//      if (device != null)
//      {
//        final Device updatedDevcie = deviceFacade.resetDevicePropertiesToDefaults(device);
//
//        for (final DevicePropertyValue value : updatedDevcie.getDeviceProperties())
//        {
//          LogManager.getLogger(getClass()).info("new property value {} = {}", value.getDeviceProperty().getKey(), value.getValue());
//        }
//      }
//      else
//      {
//        LogManager.getLogger(getClass()).info("skipping {}, no device found.", deviceId);
//      }
//    }
//  }

  @Test
  public void loadDevice()
  {
    LogManager.getLogger(getClass()).debug("test loadReference()");
    Device device = deviceDao.loadReference(Integer.valueOf(807));
    Assert.notNull(device, "device was null on loadReference() call");
    LogManager.getLogger(getClass()).debug("got a reference with id: {}", device.getId());
    LogManager.getLogger(getClass()).debug("test load()");
    device = deviceDao.load(Integer.valueOf(device.getId()));
    Assert.notNull(device, "device was null on load() call");
    LogManager.getLogger(getClass()).info("TEST WORKED!");
  }
  
//  @Value("${reset.properties.deviceIds}")
//  public void setDeviceIds(final String deviceIds)
//  {
//    this.deviceIds = deviceIds;
//  }
//
  @Override
  protected DeviceFacade getDeviceFacade()
  {
    return deviceFacade;
  }

}
