package testcase.persistence;

import java.util.Collection;

import testcase.model.PropertyType;

public interface PropertyTypeDao extends Dao<PropertyType, Integer>
{
  
  Collection<PropertyType> findAll();
  PropertyType findByPropertyKey(final String key);
  Collection<PropertyType> findPropertiesStartingWith(final String prefix);
  Long findPropertyCountStartingWith(final String prefix);
  Collection<PropertyType> findPropertiesStartingWith(final String prefix, int first, int count);
 
}
