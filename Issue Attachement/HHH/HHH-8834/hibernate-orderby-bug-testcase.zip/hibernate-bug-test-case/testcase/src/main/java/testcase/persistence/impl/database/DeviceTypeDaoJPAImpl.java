package testcase.persistence.impl.database;

import java.util.Collection;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import testcase.model.DeviceType;
import testcase.model.DeviceTypeProperty;
import testcase.persistence.DeviceTypeDao;

@Repository
public class DeviceTypeDaoJPAImpl extends DaoJPAImpl<DeviceType, Integer> implements DeviceTypeDao
{

  public DeviceTypeDaoJPAImpl()
  {
    super(DeviceType.class);
  }

  @Override
  @Transactional
  public Collection<DeviceType> findAll()
  {
    final TypedQuery<DeviceType> query = getEntityManager().createQuery("select entity from DeviceType entity", DeviceType.class);
    return query.getResultList();
  }

  @Transactional
  @Override
  public DeviceType findByDescription(final String description)
  {
    Assert.notNull(description, "description was null");
    final TypedQuery<DeviceType> query = getEntityManager().createQuery("select entity from DeviceType entity where entity.description = :description", DeviceType.class);
    query.setParameter("description", description);
    return query.getSingleResult();
  }

  @Transactional
  @Override
  public Collection<DeviceTypeProperty> getDeviceTypeProperties(final DeviceType deviceType)
  {
    Assert.notNull(deviceType, "device type was null");
    final TypedQuery<DeviceTypeProperty> query = getEntityManager().createQuery("select prop from DeviceTypeProperty prop where prop.deviceType.id = :deviceTypeId", DeviceTypeProperty.class);
    query.setParameter("deviceTypeId", deviceType.getId());
    return query.getResultList();
  }
}
