package testcase.persistence.impl.database;

import java.util.Collection;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import testcase.model.DevicePropertyValue;
import testcase.persistence.DevicePropertyValueDao;

@Repository
public class DevicePropertyValueDaoJPAImpl extends DaoJPAImpl<DevicePropertyValue, Integer> implements DevicePropertyValueDao
{

  public DevicePropertyValueDaoJPAImpl()
  {
    super(DevicePropertyValue.class);
  }
  
  @Override
  @Transactional
  public Collection<DevicePropertyValue> findAll()
  {
    TypedQuery<DevicePropertyValue> query = getEntityManager().createQuery("select entity from DevicePropertyValue entity", DevicePropertyValue.class);
    return query.getResultList();
  }
}
