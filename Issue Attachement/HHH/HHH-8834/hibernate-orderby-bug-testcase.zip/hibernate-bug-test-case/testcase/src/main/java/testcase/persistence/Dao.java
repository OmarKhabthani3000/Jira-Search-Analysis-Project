package testcase.persistence;

import java.util.Collection;

import testcase.model.DomainObject;


public interface Dao<T extends DomainObject<PK>, PK extends Number>
{
  public void delete(final T o);
  
  public void detach(T entity);

  public T load(final PK id);
  
  public T loadAndDetach(final PK id);
  
  public T loadReference(final PK id);
  
  public Collection<T> findAll(final int first, final int count);
  
  public Long getCount();

  public T save(final T o);
}
