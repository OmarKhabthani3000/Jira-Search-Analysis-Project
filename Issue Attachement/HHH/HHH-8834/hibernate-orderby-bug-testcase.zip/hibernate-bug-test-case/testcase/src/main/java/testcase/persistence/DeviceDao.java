package testcase.persistence;

import java.util.Collection;

import testcase.model.Device;
import testcase.model.DevicePropertyValue;

public interface DeviceDao extends Dao<Device, Integer>
{
  Collection<Device> findAll();
  Device findByAddress(final String deviceAddress);

  /**
   * Find a Device using the load controller gateway id and the device address (in format matching pattern:
   * ^([0-9A-F]{2}[-]){4}([0-9A-F]{2})$ -- NOT including the device index).
   * 
   * @param loadControllerGatewayId the load controller gateway id
   * @param address the device address (no device index suffix)
   * @return a device or null if none found.
   */

  DevicePropertyValue findDevicePropertyValue(final Device device, final String propertyTypeKey);
  void delete(final Device device);
  void deleteProperties(final Device device);
  void clearCache();
}
