/**
 * 
 */
package testcase.persistence.facade;

import java.util.Collection;
import java.util.LinkedHashSet;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import testcase.model.Device;
import testcase.model.DevicePropertyValue;
import testcase.model.DeviceType;
import testcase.model.DeviceTypeProperty;
import testcase.persistence.DeviceDao;
import testcase.persistence.DeviceTypeDao;

/**
 * Device Facade class for working with devices and related DAOs.
 * 
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 * @version 1.0
 */
@Repository
public class DeviceFacade
{

  /* static constants for use during the pilot for database lookups */
  public static final Integer PILOT_LOAD_MANAGER_ID = 1;
  public static final Integer PILOT_DEVICE_GROUP_ID = 1;

  @Resource
  private DeviceDao deviceDao;

  @Resource
  private DeviceTypeDao deviceTypeDao;

  @Resource
  private EntityManager entityManager;

  public DeviceFacade()
  {
  }

  public Device loadDevice(final Integer id)
  {
    return deviceDao.load(id);
  }

  public boolean deviceExists(final String deviceAddress)
  {
    try
    {
      return (deviceDao.findByAddress(deviceAddress) != null);
    }
    catch (final NoResultException nre)
    {
      return false;
    }
  }

  public Device getDeviceReference(final Integer id)
  {
    return deviceDao.loadReference(id);
  }

  public Long getDeviceCount()
  {
    return deviceDao.getCount();
  }

  public Collection<Device> findAllDevices(final int first, final int count)
  {
    return deviceDao.findAll(first, count);
  }

  public DevicePropertyValue findDevicePropertyValue(final Device device, final String propertyTypeKey)
  {
    return deviceDao.findDevicePropertyValue(device, propertyTypeKey);
  }

  public void flush()
  {
    entityManager.flush();
  }

  public void clearCache()
  {
    deviceDao.clearCache();
  }

  @Transactional(propagation = Propagation.REQUIRED)
  public Device saveDevice(final Device device)
  {
    /* NOTE: For the pilot, we're only dealing with water heaters, so just add the water heater device type in there */
    return deviceDao.save(device);
  }

  @Transactional(propagation = Propagation.REQUIRED)
  public Device resetDevicePropertiesToDefaults(final Device device)
  {
    // deviceDao.deleteProperties(device);
    if (device.getDeviceProperties() != null)
    {
      device.getDeviceProperties().clear();
    }
    else
    {
      device.setDeviceProperties(new LinkedHashSet<DevicePropertyValue>());
    }
    final Collection<DeviceTypeProperty> dtProps = deviceTypeDao.getDeviceTypeProperties(device.getDeviceType());
    for (final DeviceTypeProperty templateProp : dtProps)
    {
      final DevicePropertyValue newDevProp = new DevicePropertyValue(templateProp);
      newDevProp.setDevice(device);
      device.getDeviceProperties().add(newDevProp);
    }

    return deviceDao.save(device);
  }

  public DeviceType findDeviceTypeByDescription(final String description)
  {
    return deviceTypeDao.findByDescription(description);
  }

  public Collection<DeviceTypeProperty> getDeviceTypeProperties(final DeviceType deviceType)
  {
    return deviceTypeDao.getDeviceTypeProperties(deviceType);
  }

  @Transactional
  public void deleteDevice(final Integer deviceId)
  {
    deviceDao.delete(deviceDao.load(deviceId));
  }

}
