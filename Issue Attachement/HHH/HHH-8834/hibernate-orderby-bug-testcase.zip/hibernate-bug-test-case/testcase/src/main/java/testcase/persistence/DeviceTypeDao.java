package testcase.persistence;

import java.util.Collection;

import testcase.model.DeviceType;
import testcase.model.DeviceTypeProperty;

public interface DeviceTypeDao extends Dao<DeviceType, Integer>
{
  
  Collection<DeviceType> findAll();
  DeviceType findByDescription(final String description);
  Collection<DeviceTypeProperty> getDeviceTypeProperties(final DeviceType deviceType);
  
}
