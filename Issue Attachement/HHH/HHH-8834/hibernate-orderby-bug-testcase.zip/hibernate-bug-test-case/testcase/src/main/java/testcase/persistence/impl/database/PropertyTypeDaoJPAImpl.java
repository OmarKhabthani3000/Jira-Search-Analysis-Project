package testcase.persistence.impl.database;

import java.util.Collection;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import testcase.model.PropertyType;
import testcase.persistence.PropertyTypeDao;

@Repository
public class PropertyTypeDaoJPAImpl extends DaoJPAImpl<PropertyType, Integer> implements PropertyTypeDao
{

  public PropertyTypeDaoJPAImpl()
  {
    super(PropertyType.class);
  }

  @Override
  @Transactional
  public Collection<PropertyType> findAll()
  {
    TypedQuery<PropertyType> query = getEntityManager().createQuery("select entity from PropertyType entity", PropertyType.class);
    return query.getResultList();
  }

  @Override
  @Transactional
  public PropertyType findByPropertyKey(final String key)
  {
    final TypedQuery<PropertyType> query = getEntityManager().createQuery("select entity from PropertyType entity where entity.key = ?1", PropertyType.class);
    query.setParameter(1, key);
    return query.getSingleResult();
  }

  @Override
  @Transactional
  public Collection<PropertyType> findPropertiesStartingWith(final String prefix)
  {
    Assert.notNull(prefix, "prefix is null");
    Assert.doesNotContain(prefix, "%", "the prefix should not contain a %");
    final TypedQuery<PropertyType> query = getEntityManager().createQuery("select entity from PropertyType entity where entity.key like :prefix order by entity.key", PropertyType.class);
    query.setParameter("prefix", prefix+"%");
    return query.getResultList();
  }

  @Override
  @Transactional
  public Collection<PropertyType> findPropertiesStartingWith(final String prefix, int first, int count)
  {
    Assert.notNull(prefix, "prefix is null");
    Assert.doesNotContain(prefix, "%", "the prefix should not contain a %");
    final TypedQuery<PropertyType> query = getEntityManager().createQuery("select entity from PropertyType entity where entity.key like :prefix order by entity.key", PropertyType.class);
    query.setParameter("prefix", prefix+"%");
    query.setFirstResult(first);
    query.setMaxResults(count);
    return query.getResultList();
  }

  @Override
  @Transactional
  public Long findPropertyCountStartingWith(final String prefix)
  {
    Assert.notNull(prefix, "prefix is null");
    Assert.doesNotContain(prefix, "%", "the prefix should not contain a %");
//    final TypedQuery<PropertyType> query = getEntityManager().createQuery("select entity from PropertyType entity where entity.key like :prefix order by entity.key", PropertyType.class);
    final CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
    final CriteriaQuery<Long> query = cb.createQuery(Long.class);
    final Root<PropertyType> root = query.from(PropertyType.class);
    query.select(cb.count(root));
    query.where(cb.like(root.<String>get("key"), prefix+"%"));
    return getEntityManager().createQuery(query).getSingleResult();
  }

}
