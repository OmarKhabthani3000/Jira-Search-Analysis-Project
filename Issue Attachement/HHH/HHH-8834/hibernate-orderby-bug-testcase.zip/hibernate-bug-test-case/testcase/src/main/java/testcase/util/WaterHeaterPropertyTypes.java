/**
 * 
 */
package testcase.util;

/**
 * This is a constant class defining water heater property keys.
 * 
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 * @version 1.0
 */
public final class WaterHeaterPropertyTypes
{

  // Note: this may not be the correct place for this, but it'll do for now.
  public static final String DEVICE_TYPE_WATER_HEATER = "Water Heater";
  public static final String DEVICE_TYPE_3_ELEMENT_WATER_HEATER = "Water Heater - 3 Element";
  public static final String DEVICE_TYPE_SIMULATED_WATER_HEATER = "Simulated Water Heater";
  
  // Prefix
  public static final String DEVICE_TYPE_KEY_PREFIX = "bfrs.device";
  
  // Property Type Keys
  public static final String CAPACITY_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.Capacity";
  public static final String ELEMENT_RATING_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.ElementRating";
  public static final String PHASES_KEY = DEVICE_TYPE_KEY_PREFIX + ".Phases";
  public static final String VOLTAGE_KEY = DEVICE_TYPE_KEY_PREFIX + ".Voltage";
  public static final String EFFICIENCY_RATING_KEY = DEVICE_TYPE_KEY_PREFIX + ".EfficiencyRating";
  public static final String KW_INCREMENT_KEY = DEVICE_TYPE_KEY_PREFIX + ".KWIncrement";
  public static final String DESIRED_TEMP_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.DesiredTemperature";
  public static final String INITIAL_SET_POINT_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.InitialCustomerSetPoint";
  public static final String CALIBRATED_SET_POINT_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.CalibratedSetPoint";
  public static final String MAX_TEMP_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.MaxTemperature";
  public static final String MIN_TEMP_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.MinTemperature";
  public static final String DEAD_BAND_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.DeadBand";
  public static final String INSULATION_VALUE_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.InsulationValue";
  public static final String NOMINAL_FLOW_RATE_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.NominalFlowRate";
  public static final String SURFACE_AREA_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.SurfaceArea";
  public static final String WALL_THICKNESS_TOP_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.WallThickness-Top";
  public static final String WALL_THICKNESS_SIDE_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.WallThickness-Side";
  public static final String WALL_THICKNESS_BOTTOM_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.WallThickness-Bottom";
  public static final String TANK_MATERIAL_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.TankMaterial";
  public static final String THERMISTOR_1_LOCATION_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.Thermistor1Location";
  public static final String THERMISTOR_2_LOCATION_KEY = DEVICE_TYPE_KEY_PREFIX + ".wh.Thermistor2Location";
  public static final String VOLTAGE_SCALE_FACTOR_KEY = DEVICE_TYPE_KEY_PREFIX + ".phase.VoltageScaleFactor";
  public static final String CURRENT_SCALE_FACTOR_KEY = DEVICE_TYPE_KEY_PREFIX + ".phase.CurrentScaleFactor";

}
