package testcase.util;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * LogManger - manages the slf4j logger intances.
 * 
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 */
public abstract class LogManager
{
  
  private static final Map<Class<?>, Logger> loggerMap;
  private static final Map<String, Logger> loggerNameMap;
  
  static
  {
    loggerMap = new HashMap<Class<?>, Logger>();
    loggerNameMap = new HashMap<String, Logger>();
  }
  
  public static Logger getLogger(final Class<?> clazz)
  {
    if (loggerMap.containsKey(clazz))
      return loggerMap.get(clazz);
    
    final Logger logger = LoggerFactory.getLogger(clazz);
    loggerMap.put(clazz,logger);
    return logger;
  }
  
  public static Logger getLogger(final Class<?> clazz, final String suffix)
  {
    final String loggerName = clazz.getName() + ":" + suffix;
    if (loggerNameMap.containsKey(loggerName))
      return loggerNameMap.get(loggerName);
    
    final Logger logger = LoggerFactory.getLogger(loggerName);
    loggerNameMap.put(loggerName, logger);
    return logger;
  }    
  
}
