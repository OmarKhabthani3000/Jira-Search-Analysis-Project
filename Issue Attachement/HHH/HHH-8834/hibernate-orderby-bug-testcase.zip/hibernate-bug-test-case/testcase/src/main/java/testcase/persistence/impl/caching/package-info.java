/**
 * Caching persistence classes.
 * 
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 */
package testcase.persistence.impl.caching;