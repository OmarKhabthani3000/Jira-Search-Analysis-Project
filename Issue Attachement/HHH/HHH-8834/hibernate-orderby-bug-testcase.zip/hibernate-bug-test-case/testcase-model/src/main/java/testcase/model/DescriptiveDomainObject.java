package testcase.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 * Persitable domain objects that have a description field
 * 
 * @author Jeff Eden <edenj@battelle.org>
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 * @version 1.0
 */
@MappedSuperclass
public abstract class DescriptiveDomainObject<PK_TYPE extends Number> extends DomainObject<PK_TYPE>
{
  private static final long serialVersionUID = 4072111360693301465L;

  @Column(name = "description")
  protected String description;

  public DescriptiveDomainObject()
  {
    super();
  }

  public String getDescription()
  {
    return description;
  }

  public void setDescription(String description)
  {
    this.description = description;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode()
  {
    final int prime = 37;
    int result = super.hashCode();
    result = prime * result + ((description == null) ? 0 : description.hashCode());
    return result;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(final Object obj)
  {
    if (this == obj) return true;
    if (!super.equals(obj)) return false;
    if (!(obj instanceof DescriptiveDomainObject)) return false;
    @SuppressWarnings("unchecked")
    final DescriptiveDomainObject<PK_TYPE> other = (DescriptiveDomainObject<PK_TYPE>) obj;
    if (description == null)
    {
      if (other.description != null) return false;
    }
    else if (!description.equals(other.description)) return false;
    return true;
  }

}
