package testcase.model;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * This class is a property value pair.
 * 
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 * @version 1.0
 * @created 31-May-2013 4:10:46 PM
 */
@Entity
@Cacheable
@Table(name = "device_property")
public class DevicePropertyValue extends DevicePropertyBase<Integer>
{

  private static final long serialVersionUID = -1116270108543607833L;

  @ManyToOne(cascade = { CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH }, fetch = FetchType.LAZY)
  @JoinTable(name = "device_property_xref", joinColumns = @JoinColumn(name = "property_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "device_id", referencedColumnName = "id"))
  private Device device;

  public DevicePropertyValue()
  {
    super();
  }

  /**
   * Copy constructor.
   * 
   * @see DevicePropertyBase#DevicePropertyBase(DevicePropertyBase)
   */
  public DevicePropertyValue(final DevicePropertyBase<Integer> input)
  {
    super(input);
  }

  /**
   * @return the device
   */
  public Device getDevice()
  {
    return device;
  }

  /**
   * @param device the device to set
   */
  public void setDevice(Device device)
  {
    this.device = device;
  }

  @Override
  protected final int domainObjectPrimeNumber()
  {
    return 3;
  }

  /**
   * See notes in {@link DomainObject#hashCode()}. This class uses a business key of device and deviceProperty (
   * {@link PropertyType}), which should be immutable and unique after saving an object, in addition to the primary key
   * as implemented in {@link DomainObject#hashCode()}.
   */
  @Override
  public int hashCode()
  {
    final int prime = domainObjectPrimeNumber();
    int result = super.hashCode();
    result = prime * result + ((getDevice() == null) ? 0 : getDevice().hashCode());
    result = prime * result + ((getDeviceProperty() == null) ? 0 : getDeviceProperty().hashCode());
    return result;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(final Object obj)
  {
    if (this == obj) return true;
    if (!super.equals(obj)) return false;
    if (!(obj instanceof DevicePropertyValue)) return false;
    final DevicePropertyValue other = (DevicePropertyValue) obj;
    if (getDevice() == null)
    {
      if (other.getDevice() != null) return false;
    }
    else if (!getDevice().equals(other.getDevice())) return false;
    if (getDeviceProperty() == null)
    {
      if (other.getDeviceProperty() != null) return false;
    }
    else if (!getDeviceProperty().equals(other.getDeviceProperty())) return false;
    return true;
  }

}