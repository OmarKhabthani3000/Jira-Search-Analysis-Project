package testcase.model;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * Represents the type of a device.
 * 
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 * @version 1.0
 * @created 31-May-2013 4:10:46 PM
 */
@Entity
@Cacheable
@Table(name = "device_type")
@AttributeOverride(name = "description", column = @Column(name = "description", nullable = false, unique = true, length = 256))
public class DeviceType extends DescriptiveDomainObject<Integer>
{

  private static final long serialVersionUID = -6749430183674939845L;

  @Column(name = "vendor_id")
  private Integer vendorId;

  /**
   * A list of device properties (with optional default values) that this device type supports. This is just a template
   * that gets applied as a set of properties to put on a device that has this device type assigned.
   */
  @Transient
  // to be resolved with DAO.find
  // @OrderBy
  private Set<DeviceTypeProperty> deviceTypeProperties;

  public DeviceType()
  {
    super();
  }

  /**
   * @return the vendorId
   */
  public Integer getVendorId()
  {
    return vendorId;
  }

  /**
   * @param vendorId the vendorId to set
   */
  public void setVendorId(Integer vendorId)
  {
    this.vendorId = vendorId;
  }

  /**
   * @return the deviceTypeProperties
   */
  public Collection<DeviceTypeProperty> getDeviceTypeProperties()
  {
    return deviceTypeProperties;
  }

  /**
   * @param deviceTypeProperties the deviceTypeProperties to set
   */
  public void setDeviceTypeProperties(final Collection<DeviceTypeProperty> deviceTypeProperties)
  {
    if (deviceTypeProperties instanceof Set)
    {
      this.deviceTypeProperties = (Set<DeviceTypeProperty>) deviceTypeProperties;
    }
    else
    {
      this.deviceTypeProperties = new LinkedHashSet<DeviceTypeProperty>(deviceTypeProperties);
    }
  }

  @Override
  protected final int domainObjectPrimeNumber()
  {
    return 401;
  }

  /**
   * See notes in {@link DomainObject#hashCode()}. This class uses a business key of vendorId, which should be immutable
   * and unique after saving an object, in addition to the primary key as implemented in {@link DomainObject#hashCode()}
   * .
   */
  @Override
  public int hashCode()
  {
    final int prime = domainObjectPrimeNumber();
    int result = super.hashCode();
    result = prime * result + ((getVendorId() == null) ? 0 : getVendorId().hashCode());
    return result;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj)
  {
    if (this == obj) return true;
    if (!super.equals(obj)) return false;
    if (!(obj instanceof DeviceType)) return false;
    final DeviceType other = (DeviceType) obj;
    if (vendorId == null)
    {
      if (other.vendorId != null) return false;
    }
    else if (!vendorId.equals(other.vendorId)) return false;
    return true;
  }

  public void finalize() throws Throwable
  {
  }

}