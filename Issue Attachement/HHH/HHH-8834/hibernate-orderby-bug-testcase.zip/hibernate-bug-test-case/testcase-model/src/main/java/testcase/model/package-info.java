/**
 * Test case model objects.
 * 
 * @author Kendal Montgomery <montgomerykl@battelle.org>
 */
package testcase.model;