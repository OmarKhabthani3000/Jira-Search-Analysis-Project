
CREATE TABLE device_type (
  id int(11) NOT NULL AUTO_INCREMENT,
  vendor_id int(11) DEFAULT NULL,
  description varchar(255) NOT NULL,
  row_version int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (id),
  UNIQUE KEY description (description)
) ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;