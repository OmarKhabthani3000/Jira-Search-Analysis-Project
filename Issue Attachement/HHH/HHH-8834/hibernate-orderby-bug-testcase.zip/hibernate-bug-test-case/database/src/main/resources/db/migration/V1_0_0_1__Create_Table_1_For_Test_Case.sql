CREATE TABLE device (
  id int(11) NOT NULL AUTO_INCREMENT,
  description varchar(256) NOT NULL,
  device_type_id int(11) NULL,
  calibrated bit(1) NOT NULL DEFAULT b'0',
  address varchar(128) NOT NULL,
  device_index int(11) NOT NULL,
  operational_mode_id int(11) NOT NULL DEFAULT '1',
  device_group_id int(11) NULL,
  device_location_id int(11)  NULL,
  device_gateway_id int(11)  NULL,
  row_version int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (id),
  UNIQUE KEY device_gateway_id (device_gateway_id,address),
  KEY device_location_id (device_location_id),
  KEY device_type_id (device_type_id),
  KEY device_group_id (device_group_id),
  KEY operational_mode_id (operational_mode_id)
) ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;
