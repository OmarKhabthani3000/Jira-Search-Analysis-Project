CREATE TABLE device_property_xref (
  device_id int(11) NOT NULL,
  property_id int(11) NOT NULL,
  UNIQUE KEY uix_dpx (device_id,property_id),
  KEY property_id (property_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;