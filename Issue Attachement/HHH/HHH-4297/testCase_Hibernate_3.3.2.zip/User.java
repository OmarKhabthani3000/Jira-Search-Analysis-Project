package org.hibernate.test.querycache.bag;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

//@EntityListeners(value={EpgEntityListener.class})
@Entity
public class User {
	@Id
	long id;
	
	@Column
    private String firstName;

    @ManyToOne(fetch = FetchType.LAZY)
    Company company;
    
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company group) {
		this.company = group;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
    
}
