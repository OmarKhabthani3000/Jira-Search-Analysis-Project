package org.hibernate.test.querycache.bag;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import junit.framework.TestCase;

import org.hibernate.engine.SessionImplementor;

public class QueryCacheReturningNullItemsTest extends TestCase {

    private static Logger logger = Logger.getLogger(QueryCacheReturningNullItemsTest.class.getName());

    private EntityManagerFactory emFactory;

    private EntityManager em;

    private Connection connection;

    public QueryCacheReturningNullItemsTest(String testName) {
        super(testName);
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        try {
            logger.info("Starting in-memory HSQL database for unit tests");
            Class.forName("org.hsqldb.jdbcDriver");
            connection = DriverManager.getConnection("jdbc:hsqldb:mem:unit-testing-jpa", "sa", "");
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Exception during HSQL database startup.");
        }
        try {
            logger.info("Building JPA EntityManager for unit tests");
            emFactory = Persistence.createEntityManagerFactory("testPU");
            em = createEntityManager();
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Exception during JPA EntityManager instanciation.");
        }
    }

    private EntityManager createEntityManager() {
        em = emFactory.createEntityManager();
        //HibernateUtils.setSessionFactory(((SessionImplementor)em.getDelegate()).getFactory());
        return em;
	}

	@Override
    protected void tearDown() throws Exception {
        super.tearDown();
        logger.info("Shuting down Hibernate JPA layer.");
        if (em != null) {
            em.close();
        }
        if (emFactory != null) {
            emFactory.close();
        }
        logger.info("Stopping in-memory HSQL database.");
        try {
            connection.createStatement().execute("SHUTDOWN");
        } catch (Exception ex) {}
    }


    
    @SuppressWarnings("unchecked")
	public void testQueryCacheOnCollections() {
        try {

            em.getTransaction().begin();

            Query q = em.createQuery("select c.users from Company c where c.id=:id");
    		q.setHint("org.hibernate.cacheable", Boolean.TRUE);
            
            // get the users list
            List<User> users0 = q.setParameter("id", 0L).getResultList();
            assertTrue(users0.size()==0);
            
            User u = new User();
            u.setFirstName("myFirstName");

            em.persist(u);
            assertTrue(em.contains(u));

            Company g = new Company();
            g.addUser(u);

            em.persist(g);
            em.flush();
            assertTrue(em.contains(g));

            // get the users list
            doQuery(q);
            doQuery(q);
            doQuery(q);


            g.removeUser(u);
            em.remove(u);
            em.merge(g);
            assertFalse(em.contains(u));

            em.getTransaction().commit();

        } catch (Exception ex) {
            em.getTransaction().rollback();
            ex.printStackTrace();
            fail("Exception during testPersistence");
        }    	
    }

	private void doQuery(Query q2) {
		try { Thread.sleep(500); } catch (Exception e) {}
		// starting a new session
		logger.info("starting new session --------------------------------------------");
		em.getTransaction().commit();
		em = createEntityManager();
		em.getTransaction().begin();

		// doing the query
		logger.info("do query");
		Query q = em.createQuery("select c.users from Company c where c.id=:id");
		q.setHint("org.hibernate.cacheable", Boolean.TRUE);
		List<User> users1 = q.setParameter("id", 0L).getResultList();
		if (users1.get(0)==null) {
			logger.warning("get(0) is null!!!");
		}
		assertTrue(users1.size()==1);
		assertTrue(users1.get(0)!=null);
	}
}
