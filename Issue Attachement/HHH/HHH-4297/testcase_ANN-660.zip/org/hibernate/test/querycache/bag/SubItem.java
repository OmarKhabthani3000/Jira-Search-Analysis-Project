package org.hibernate.test.querycache.bag;

import org.hibernate.test.querycache.bag.Item;

/**
 * @author Jacek Halat
 */
public class SubItem{
	private String id;
	private String name;
	private Item item;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
}
