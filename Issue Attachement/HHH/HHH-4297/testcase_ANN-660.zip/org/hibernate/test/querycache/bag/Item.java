package org.hibernate.test.querycache.bag;

import java.util.List;


/**
 * @author Jacek Halat
 */
public class Item {
	private long id;
	private String name;
	private List<SubItem> subItems;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<SubItem> getSubItems() {
		return subItems;
	}
	public void setSubItems(List<SubItem> subItems) {
		this.subItems = subItems;
	}
}
