package cx.pei.testapps.hibernate.slsession;

public class DomainObject {
    private Long id;
    private String name;
    private RelationA a;
    private RelationB b;

    public Long getId() {
	return id;
    }

    public void setId(Long id) {
	this.id = id;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public RelationA getA() {
	return a;
    }

    public void setA(RelationA a) {
	this.a = a;
    }

    public RelationB getB() {
	return b;
    }

    public void setB(RelationB b) {
	this.b = b;
    }
}
