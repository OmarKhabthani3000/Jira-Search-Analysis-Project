package cx.pei.testapps.hibernate.slsession;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.hibernate.tool.hbm2ddl.SchemaExport;

/**
 * Hello world!
 * 
 */
public class App {
    public static void main(String[] args) {
	try {
	    Class.forName("org.hsqldb.jdbcDriver");
	} catch (ClassNotFoundException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	    System.exit(1);
	}
	Configuration cfg = new Configuration().configure();
	SchemaExport export = new SchemaExport(cfg);
	export.create(false, true);
	SessionFactory sf = cfg.buildSessionFactory();
	Session session = sf.openSession();
	RelationA a = new RelationA();
	a.setName("Relation A");
	RelationB b = new RelationB();
	b.setName("Relation B");
	DomainObject obj1 = new DomainObject();
	obj1.setName("DomainObject");
	obj1.setA(a);
	obj1.setB(b);
	Transaction tx = session.beginTransaction();
	session.save(a);
	session.save(b);
	session.save(obj1);
	tx.commit();
	StatelessSession s = sf.openStatelessSession();
	Query q = s.createQuery("from DomainObject obj join fetch obj.a");
	DomainObject obj2 = (DomainObject) q.list().get(0);
	System.out.println("DomainObject id=" + obj2.getId());
	System.out.println("RelationA name=" + obj2.getA().getName());
	System.out.println("RelationB id=" + obj2.getB().getId());
	s.close();
    }
}
