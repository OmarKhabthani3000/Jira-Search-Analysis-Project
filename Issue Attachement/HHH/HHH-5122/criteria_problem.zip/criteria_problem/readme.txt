Hi!

to reproduce it : 
1) you must have a database named 'criteria_problem' already existing.
2) set jdbc properties in test/resources/applicationContext.properties
3) mvn test -Pdb-create,db-insert-test-data

--Thomas