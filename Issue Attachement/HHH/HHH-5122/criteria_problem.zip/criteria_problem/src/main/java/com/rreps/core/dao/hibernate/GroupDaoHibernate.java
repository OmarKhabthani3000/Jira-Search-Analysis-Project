package com.rreps.core.dao.hibernate;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.impl.CriteriaImpl;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.rreps.core.dao.GroupDao;
import com.rreps.core.model.Group;

@Repository
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class GroupDaoHibernate extends HibernateDaoSupport implements GroupDao, Serializable {

	private static final long serialVersionUID = -6047386290014248846L;

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	public GroupDaoHibernate(@Qualifier("sessionFactory") SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@SuppressWarnings("unchecked")
	public List<Group> getGroups() {
		CriteriaImpl c = (CriteriaImpl) getSession().createCriteria(Group.class);
		
		ProjectionList pl = Projections.projectionList();
		for (String property : getSessionFactory().getClassMetadata(Group.class).getPropertyNames()) {
			pl.add(Projections.property(property), property);
		}

		c.setProjection(Projections.distinct(pl)).setResultTransformer(new AliasToBeanResultTransformer(Group.class));

		return c.addOrder(Order.asc("name")).setFirstResult(0).setMaxResults(2).list();	

	}

}
