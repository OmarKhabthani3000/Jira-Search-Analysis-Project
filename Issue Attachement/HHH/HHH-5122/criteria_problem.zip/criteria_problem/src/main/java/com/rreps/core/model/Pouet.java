package com.rreps.core.model;


public class Pouet {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i = 0;
		System.out.println("i = " + 1);
		Pouet p = new Pouet();
		p.add(i);
		System.out.println("i = " + 1);
	}

	public void add(int i){
		i++;
	}
}
