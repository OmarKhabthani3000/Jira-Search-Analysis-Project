package com.rreps.core.dao;

import java.util.List;

import com.rreps.core.model.Group;

public interface GroupDao {

	List<Group> getGroups();
}
