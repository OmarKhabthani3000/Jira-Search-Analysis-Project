package com.rreps.core.dao;


import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.rreps.core.model.Group;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext-core.xml" })
public class GroupDaoTestCase {

	@Autowired
	private GroupDao dao;

    @Test
	public void testFailing(){
		List<Group> l = dao.getGroups();
		assertNotNull(l);
	}
}
