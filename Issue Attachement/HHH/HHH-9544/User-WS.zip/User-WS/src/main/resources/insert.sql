insert into user(id) values (1);
insert into token(id, language, user_id) values (1, 1, 1);
