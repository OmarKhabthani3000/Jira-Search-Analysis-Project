package be.groups.common.jpa;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class LanguageConverter implements AttributeConverter<Language, Integer> {

	@Override
	public Integer convertToDatabaseColumn(Language attribute) {
		return (attribute != null) ? attribute.getCode() : null;
	}

	@Override
	public Language convertToEntityAttribute(Integer dbData) {
		return (dbData != null) ? Language.valueOf(dbData).orElse(null) : null;
	}

}
