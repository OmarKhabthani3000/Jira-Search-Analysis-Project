package be.groups.common.jaxrs;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import static javax.ws.rs.core.MediaType.TEXT_PLAIN;

@Path("/user")
@Stateless
public class UserResource {

	@PersistenceContext
	private EntityManager em;

	@GET
	@Produces(TEXT_PLAIN)
	public String getNbTokens() {
		return em.createQuery("select count(t) from Token t").getSingleResult().toString();
	}

}
