package be.groups.common.jaxrs;

import io.swagger.jaxrs.config.BeanConfig;
import io.swagger.jaxrs.listing.ApiListingResource;
import io.swagger.jaxrs.listing.SwaggerSerializers;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import org.jboss.resteasy.plugins.interceptors.CorsFilter;

@ApplicationPath("/")
public class DefaultJaxRsConfig extends Application {

	private final BeanConfig swaggerConfig = new BeanConfig();
	private final Set<Object> singletons;
	private final Set<Class<?>> classes;

	public DefaultJaxRsConfig() {
		swaggerConfig.setScan();
		swaggerConfig.setResourcePackage("be.groups.common.jaxrs");
		swaggerConfig.setBasePath("/user-ws");
		swaggerConfig.setVersion("1.0");

		CorsFilter corsFilter = new CorsFilter();
		corsFilter.getAllowedOrigins().add("*");
		this.singletons = Collections.singleton(corsFilter);
		this.classes = new HashSet<>(Arrays.asList(UserResource.class, ApiListingResource.class, SwaggerSerializers.class));
	}

	@Override
	public final Set<Object> getSingletons() {
		return singletons;
	}

	@Override
	public final Set<Class<?>> getClasses() {
		return classes;
	}

}
