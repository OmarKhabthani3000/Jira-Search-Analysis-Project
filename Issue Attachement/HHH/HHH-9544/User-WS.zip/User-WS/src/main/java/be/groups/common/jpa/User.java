package be.groups.common.jpa;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class User implements Serializable {

	@Id
	private long id;

	protected User() {
	}

}
