package be.groups.common.jpa;

import java.util.Arrays;
import java.util.Optional;

public enum Language {

	FR(1), NL(2), DE(3), EN(4);

	private final int code;

	Language(int code) {
		this.code = code;
	}

	static Optional<Language> valueOf(int code) {
		return Arrays.stream(values()).filter(lc -> lc.code == code).findFirst();
	}

	int getCode() {
		return code;
	}

}
