package be.groups.common.jpa;

import java.io.Serializable;

import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Token implements Serializable {

	@Id
	private String id;

	@Convert(converter = LanguageConverter.class)
	private Language language;

	@ManyToOne
	private User user;

	protected Token() {
	}

}
