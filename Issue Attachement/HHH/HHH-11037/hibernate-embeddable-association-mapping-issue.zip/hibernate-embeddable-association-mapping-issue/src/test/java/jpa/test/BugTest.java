package jpa.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BugTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void setup() {
        emf = Persistence.createEntityManagerFactory("TestPU");
    }
    
    @After
    public void tearDown() {
        if (emf != null && emf.isOpen()) {
            emf.close();
        }
    }
    
    @Test
    public void testBug() {
        EntityManager em = emf.createEntityManager();
        // Apparently if the base class Contact contains properties that have the same name as properties of a subtype embeddable, 
        // the subtype embeddable properties are ignored
        
        // Verify that the table exists to assert that associations of subtype embeddables picked up
        em.createNativeQuery("select * from employee_embeddable_person_map").getResultList();
    }
}
