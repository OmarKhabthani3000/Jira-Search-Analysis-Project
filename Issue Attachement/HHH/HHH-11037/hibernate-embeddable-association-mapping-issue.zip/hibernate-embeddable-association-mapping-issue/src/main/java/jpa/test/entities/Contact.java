package jpa.test.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.persistence.CollectionTable;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;

@Embeddable
public class Contact implements Serializable {
    
    private Person alertContact;
    private Set<Person> alerteeContacts = new HashSet<>();
    private List<Person> personList = new ArrayList<>();
    private Map<String, Person> personMap = new HashMap<>();

    public Contact() {
    }

    @ManyToOne
    @JoinColumn(name = "embeddable_alert_contact")
    public Person getAlertContact() {
        return alertContact;
    }

    public void setAlertContact(Person alertContact) {
        this.alertContact = alertContact;
    }

    @OneToMany
    @JoinColumn(name = "embeddable_alert_contact")
    public Set<Person> getAlerteeContacts() {
        return alerteeContacts;
    }

    public void setAlerteeContacts(Set<Person> alerteeContacts) {
        this.alerteeContacts = alerteeContacts;
    }

    @ManyToMany
    @OrderColumn(name = "list_idx")
    @JoinTable(name = "embeddable_person_list")
    public List<Person> getPersonList() {
        return personList;
    }

    public void setPersonList(List<Person> personList) {
        this.personList = personList;
    }

    @ManyToMany
    @CollectionTable(name = "embeddable_person_map")
    @MapKeyColumn(name = "person_key", length = 20)
    public Map<String, Person> getPersonMap() {
        return personMap;
    }

    public void setPersonMap(Map<String, Person> personMap) {
        this.personMap = personMap;
    }
}
