
package jpa.test.entities;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "managers")
public class Manager extends Person {
    
    private Integer managerNumber;
    private ManagerContact managerContact;

    public Manager() {
    }

    public Integer getManagerNumber() {
        return managerNumber;
    }

    public void setManagerNumber(Integer managerNumber) {
        this.managerNumber = managerNumber;
    }

    @Embedded
    public ManagerContact getManagerContact() {
        return managerContact;
    }

    public void setManagerContact(ManagerContact managerContact) {
        this.managerContact = managerContact;
    }
}
