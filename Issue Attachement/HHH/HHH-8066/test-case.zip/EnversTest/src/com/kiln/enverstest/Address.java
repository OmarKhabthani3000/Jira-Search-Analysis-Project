package com.kiln.enverstest;

import org.hibernate.envers.*;

import javax.persistence.*;
import java.util.Set;

@Audited
@Entity
public class Address {
    @Id
    @GeneratedValue
    private int id;

    private String streetName;

    private Integer houseNumber;

    private Integer flatNumber;


    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @ManyToOne
    @JoinColumn (name="addressTypeFk", referencedColumnName="EntityId",nullable=false)
    //@AuditMappedBy(mappedBy = "entityId")
    private AddressTypeLookup addressType;


//    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
//    @NotAudited
    @OneToMany(mappedBy = "address", cascade=CascadeType.ALL)
    private Set<Person> persons;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public Integer getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(Integer houseNumber) {
        this.houseNumber = houseNumber;
    }

    public Integer getFlatNumber() {
        return flatNumber;
    }

    public void setFlatNumber(Integer flatNumber) {
        this.flatNumber = flatNumber;
    }

    public Set<Person> getPersons() {
        return persons;
    }

    public void setPersons(Set<Person> persons) {
        this.persons = persons;
    }

    public AddressTypeLookup getAddressType() {
        return addressType;
    }

    public void setAddressType(AddressTypeLookup addressType) {
        this.addressType = addressType;
    }
}