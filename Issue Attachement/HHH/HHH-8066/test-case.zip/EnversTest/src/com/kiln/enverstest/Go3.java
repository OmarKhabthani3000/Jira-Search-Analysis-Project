package com.kiln.enverstest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.HashSet;
import java.util.Set;

/**
 * just create the db, nothing else.
 */
public class Go3
{
    public static void main(String[] args)
    {
        EntityManagerFactory entityManagerFactory =  Persistence.createEntityManagerFactory("enverstest");
        EntityManager em = entityManagerFactory.createEntityManager();

        EntityTransaction userTransaction = em.getTransaction();
        userTransaction.begin();


        userTransaction.commit();
        em.close();
        entityManagerFactory.close();

    }
}
