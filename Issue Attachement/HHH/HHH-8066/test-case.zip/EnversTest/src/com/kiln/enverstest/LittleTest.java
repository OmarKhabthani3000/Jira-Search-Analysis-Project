package com.kiln.enverstest;

import java.math.BigDecimal;

public class LittleTest
{

    public static void main(String[] args) {

        //Double d = 1234567890123456.235d;
        Double d = 12345678.01234567;
        System.out.println(d);
        BigDecimal bd = new BigDecimal(d);
        System.out.println(bd);


    }


}
