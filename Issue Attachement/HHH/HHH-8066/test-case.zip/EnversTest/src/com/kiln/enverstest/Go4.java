package com.kiln.enverstest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

/**
 * createa a bunch of records
 */
public class Go4
{
    public static void main(String[] args)
    {
        EntityManagerFactory entityManagerFactory =  Persistence.createEntityManagerFactory("enverstest");
        EntityManager em = entityManagerFactory.createEntityManager();

        EntityTransaction userTransaction = em.getTransaction();
        userTransaction.begin();

        // blah

        Double d = 1234567890123456.235;
        BigDecimal bd = new BigDecimal("1234567890123456.235");

        System.out.println("double is:"+d.toString());

        // address type


        Person person = new Person();
        person.setName("tim");
        person.setSurname("kane");
        person.setIncome(d);
        person.setIncome2(bd);


        em.persist(person);


        userTransaction.commit();






        em.close();
        entityManagerFactory.close();

    }
}
