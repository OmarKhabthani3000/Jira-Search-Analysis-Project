package com.kiln.enverstest;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * create a bunch of records
 */
public class Go
{
    public static void main(String[] args)
    {
        EntityManagerFactory entityManagerFactory =  Persistence.createEntityManagerFactory("enverstest");
        EntityManager em = entityManagerFactory.createEntityManager();

        EntityTransaction userTransaction = em.getTransaction();
        userTransaction.begin();

        // address type

        AddressTypeLookup addressType = new AddressTypeLookup();
        addressType.setDescr("Type 1");
        addressType.setEntityId(1234);
        AddressTypeLookup addressType2 = new AddressTypeLookup();
        addressType2.setDescr("Type 2");
        addressType2.setEntityId(5678);

        em.persist(addressType);
        em.persist(addressType2);

        // address and person

        Address address = new Address();
        address.setHouseNumber(50);
        address.setStreetName("Camberley Av");
        address.setAddressType(addressType);

        Person person = new Person();
        person.setName("tim");
        person.setSurname("kane");

        Set<Person> persons = address.getPersons();
        if (persons == null) {
            persons = new HashSet<Person>();
            address.setPersons(persons);
        }
        address.getPersons().add(person);

        person.setAddress(address);


        AddressExtra addressExtra = new AddressExtra();
        addressExtra.setPostcode("ws7 1an");
        addressExtra.setAddress(address);


        em.persist(address);
        em.persist(addressExtra);
//        em.persist(person);


        Person p2 = new Person();
        p2.setName("jane");
        p2.setSurname("cummings");
        em.persist(p2);


        userTransaction.commit();


        // change address type

        userTransaction = em.getTransaction();
        userTransaction.begin();

        address.setAddressType(addressType2);

        userTransaction.commit();






        em.close();
        entityManagerFactory.close();

    }
}
