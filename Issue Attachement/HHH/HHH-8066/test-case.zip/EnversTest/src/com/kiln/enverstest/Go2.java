package com.kiln.enverstest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 * update some data
 */
public class Go2
{
    public static void main(String[] args)
    {
        EntityManagerFactory entityManagerFactory =  Persistence.createEntityManagerFactory("enverstest");
        EntityManager em = entityManagerFactory.createEntityManager();

        EntityTransaction userTransaction = em.getTransaction();
        userTransaction.begin();



        Address address = em.find(Address.class, 1);
//        Object[] arr = address.getPersons().toArray();
//        Person person = (Person)arr[0];
        address.setHouseNumber(51);
//        person.setName("Bob");


        AddressTypeLookup addressType = em.find(AddressTypeLookup.class, 2);
        address.setAddressType(addressType);

        em.persist(address);


        userTransaction.commit();

        em.close();
        entityManagerFactory.close();

    }
}
