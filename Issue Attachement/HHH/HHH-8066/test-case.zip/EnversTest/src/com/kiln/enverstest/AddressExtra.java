package com.kiln.enverstest;

import javax.persistence.*;

@Entity
public class AddressExtra
{
    @Id
    @GeneratedValue
    private int id;
    private String postcode;

    @OneToOne
    @JoinColumn(name="address_id")
    private Address address;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
}
