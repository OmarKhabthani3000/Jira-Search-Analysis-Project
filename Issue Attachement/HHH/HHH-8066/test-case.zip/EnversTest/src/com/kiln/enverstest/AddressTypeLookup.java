package com.kiln.enverstest;

import org.hibernate.envers.Audited;

import javax.persistence.*;

//@Audited
@Entity
public class AddressTypeLookup
{
    @Id
    @GeneratedValue
    private int id;
    private String descr;
    private int entityId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescr() {
        return descr;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public int getEntityId() {
        return entityId;
    }

    public void setEntityId(int entityId) {
        this.entityId = entityId;
    }
}
