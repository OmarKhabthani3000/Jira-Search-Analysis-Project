package com.kiln.enverstest;

import org.hibernate.envers.*;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Audited
public class Person {
    @Id
    @GeneratedValue
    private int id;

    private String name;

    private String surname;

    @Column(columnDefinition = "DECIMAL(19,3)")
    private Double income;

    private BigDecimal income2;


    @ManyToOne
    private Address address;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Double getIncome() {
        return income;
    }

    public void setIncome(Double income) {
        this.income = income;
    }

    public BigDecimal getIncome2() {
        return income2;
    }

    public void setIncome2(BigDecimal income2) {
        this.income2 = income2;
    }
}