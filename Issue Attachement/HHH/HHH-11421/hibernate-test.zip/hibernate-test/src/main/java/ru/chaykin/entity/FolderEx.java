package ru.chaykin.entity;

import javax.persistence.Entity;

@Entity
public class FolderEx extends Folder {

	private String description;
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getDescription() {
		return description;
	}
}