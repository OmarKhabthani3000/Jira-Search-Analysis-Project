package ru.chaykin.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class File {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch=FetchType.LAZY)
	private Folder folder;
	
	public Long getId() {
		return id;
	}

	public Folder getFolder() {
		return folder;
	}
	
	public void setFolder(Folder route) {
		this.folder = route;
	}
}