package ru.chaykin;
import java.util.function.Consumer;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Hibernate;
import org.junit.Assert;
import org.junit.Test;

import ru.chaykin.entity.File;
import ru.chaykin.entity.Folder;
import ru.chaykin.entity.FolderEx;

public class HibernateTest {

	@Test
	public void test() {
		read(store());
	}
	
	private Long store() {
		FolderEx folder = new FolderEx();
		folder.setDescription("Description");
		
		File file = new File();
		file.setFolder(folder);
		
		execute(em -> {
			em.persist(folder);
			em.persist(file);
		});
		return file.getId();
	}
	
	private void read(Long fileId) {
		execute(em -> {
			File file = em.find(File.class, fileId);
			Folder folder = file.getFolder();
			Assert.assertNotNull(folder);
			Assert.assertEquals(FolderEx.class, Hibernate.getClass(folder));
			Assert.assertTrue(folder instanceof FolderEx); // Fail!
			
			FolderEx folderEx = (FolderEx) folder;
			Assert.assertEquals("Description", folderEx.getDescription());
		});
	}
	
	private void execute(Consumer<EntityManager> consumer) {
		EntityManagerFactory emFactory = null;
		try {
			emFactory = Persistence.createEntityManagerFactory("test-postgres");
			EntityManager em = emFactory.createEntityManager();
			em.getTransaction().begin();
			consumer.accept(em);
			em.getTransaction().commit();
		} finally {
			if (emFactory != null) {
				emFactory.close();
			}
		}
	}
}
