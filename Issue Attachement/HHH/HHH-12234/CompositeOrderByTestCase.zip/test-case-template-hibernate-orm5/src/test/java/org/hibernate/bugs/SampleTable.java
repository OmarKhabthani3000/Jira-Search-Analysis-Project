package org.hibernate.bugs;

import java.time.LocalDateTime;

public class SampleTable {
    private int id;

    private LocalDateTime someDateTime;

    public int getId() {
        return id;
    }

    public void setId(int userId) {
        this.id = userId;
    }

    public LocalDateTime getSomeDateTime() {
      return someDateTime;
    }

    public void setSomeDateTime(LocalDateTime someDateTime) {
      this.someDateTime = someDateTime;
    }

    @Override
    public boolean equals(Object obj) {
      if (obj instanceof SampleTable) {
        SampleTable c = (SampleTable) obj;
        if (this.id == c.id && this.someDateTime.equals(c.someDateTime)) return true;
      }
      return false;
    }

    @Override
    public int hashCode() {
      return id * someDateTime.hashCode();
    }

}