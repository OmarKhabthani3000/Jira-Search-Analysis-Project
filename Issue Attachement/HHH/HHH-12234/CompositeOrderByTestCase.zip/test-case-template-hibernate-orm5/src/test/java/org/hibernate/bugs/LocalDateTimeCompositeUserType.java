package org.hibernate.bugs;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.type.IntegerType;
import org.hibernate.type.Type;
import org.hibernate.usertype.CompositeUserType;


public class LocalDateTimeCompositeUserType implements CompositeUserType {


  private DateTimeFormatter ofPatternDate;
  private DateTimeFormatter ofPatternTime;

  @Override
  public Object assemble(Serializable arg0, SharedSessionContractImplementor arg1, Object arg2) throws HibernateException {
    return arg0;
  }

  @Override
  public Object deepCopy(Object arg0) throws HibernateException {
    return arg0;
  }

  @Override
  public Serializable disassemble(Object arg0, SharedSessionContractImplementor arg1) throws HibernateException {
    return (Serializable) arg0;
  }

  @Override
  public boolean equals(Object arg0, Object arg1) throws HibernateException {
    return Objects.equals(arg0, arg1);
  }

  @Override
  public String[] getPropertyNames() {
    return new String[] { "date", "time" };
  }

  @Override
  public Type[] getPropertyTypes() {
    return new Type[] { IntegerType.INSTANCE, IntegerType.INSTANCE};
  }

  @Override
  public Object getPropertyValue(Object arg0, int arg1) throws HibernateException {
    LocalDateTime dateTime = (LocalDateTime) arg0;
    switch(arg1) {
      case 0:
        ofPatternDate = DateTimeFormatter.ofPattern("yyyyMMdd");
        return Integer.parseInt(ofPatternDate.format(dateTime.toLocalDate()));
      case 1:
        ofPatternTime = DateTimeFormatter.ofPattern("HHmmss");
        return Integer.parseInt(ofPatternTime.format(dateTime.toLocalTime()));
      default:
        throw new HibernateException("Not a valid property " + arg1);
    }
  }

  @Override
  public int hashCode(Object arg0) throws HibernateException {
    return Objects.hashCode(arg0);
  }

  @Override
  public boolean isMutable() {
    return false;
  }

  @Override
  public Object nullSafeGet(ResultSet rs, String[] names, SharedSessionContractImplementor session, Object owner)
      throws HibernateException, SQLException {
    Integer datePart = (Integer) IntegerType.INSTANCE.nullSafeGet(rs, names[0], session, owner);
    Integer timePart = (Integer) IntegerType.INSTANCE.nullSafeGet(rs, names[1], session, owner);

    LocalDate localDate = LocalDate.parse(datePart.toString(), ofPatternDate);
    LocalTime localTime = LocalTime.parse(timePart.toString(), ofPatternTime);

    if (localDate == null && localTime.equals(LocalTime.MIDNIGHT)) {
      return null;
    }

    if (localDate == null) {
      throw new HibernateException("A time has been specified in [" + names[1] + "] without the date in [" + names[0] + "]");
    }

    return localDate.atTime(localTime);
  }

  @Override
  public void nullSafeSet(PreparedStatement st, Object value, int index, SharedSessionContractImplementor session)
      throws HibernateException, SQLException {
    LocalDateTime localDateTime = (LocalDateTime) value;
    if (localDateTime == null) {
      IntegerType.INSTANCE.nullSafeSet(st, null, index, session);
      IntegerType.INSTANCE.nullSafeSet(st, null, index + 1, session);
    } else {
      IntegerType.INSTANCE.nullSafeSet(st, Integer.parseInt(ofPatternDate.format(localDateTime.toLocalDate())), index, session);
      IntegerType.INSTANCE.nullSafeSet(st, Integer.parseInt(ofPatternTime.format(localDateTime.toLocalTime())), index + 1, session);
    }

  }

  @Override
  public Object replace(Object arg0, Object arg1, SharedSessionContractImplementor arg2, Object arg3) throws HibernateException {
    return arg0;
  }

  @Override
  public Class returnedClass() {
    return LocalDateTime.class;
  }

  @Override
  public void setPropertyValue(Object arg0, int arg1, Object arg2) throws HibernateException {
    throw new UnsupportedOperationException("LocalDateTime is immutable");
  }


}
