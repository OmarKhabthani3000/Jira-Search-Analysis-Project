package entity.failing;

import lombok.Getter;

@Getter
public enum AccountType {
    OVERDRAWN("O"),
    DEBIT("D"),
    CREDIT("C");

    private String dbValue;
    AccountType(String dbValue) {
        this.dbValue = dbValue;
    }

}