/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * License: GNU Lesser General Public License (LGPL), version 2.1 or later.
 * See the lgpl.txt file in the root directory or <http://www.gnu.org/licenses/lgpl-2.1.html>.
 */
package org.test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import entity.failing.Account;
import entity.failing.AccountBuilder;
import entity.failing.AccountType;
import entity.failing.Client;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;


public class BugTest {
    private static EntityManagerFactory entityManagerFactory;

    @BeforeAll
    public static void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @AfterAll
    public static void destroy() {
        entityManagerFactory.close();
    }

    @BeforeEach
    public void prepareTestData() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        final Client c = new Client(1, "Gavin");
        final Account da = new AccountBuilder(1, 2, 3.0, c, AccountType.DEBIT).build();
        final Account ca = new AccountBuilder(2, 2, 3.0, c, AccountType.CREDIT).build();
        final Account oa = new AccountBuilder(3, -2, 3.0, c, AccountType.OVERDRAWN).build();
        c.getAccounts().add(da);
        c.getAccounts().add(ca);
        c.getAccounts().add(oa);
        entityManager.persist(c);
        entityManager.getTransaction().commit();

    }

    @AfterEach
    public void dropTestData() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.remove(entityManager.find(Client.class, 1));

    }

    @Test
    public void findClientAccountsTest() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        final Client client = entityManager.find(Client.class, 1);
        assertEquals(3, client.getAccounts().size());

    }
}

