package testlockcase;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.LockModeType;
import javax.persistence.Persistence;
import testlockcase.entity.TestLock;

public class TestLockCase {

    public static void main(String[] args) {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("default");        
        EntityManager manager = entityManagerFactory.createEntityManager();

        long testLockId = 0;
        manager.getTransaction().begin();
        try {
            TestLock testLock = new TestLock();
            manager.persist(testLock);
            testLockId = testLock.getTestLockId();
            manager.getTransaction().commit();
        } catch (Exception e) {
            printThrowable(e);
            manager.getTransaction().rollback();
        }
        
        manager.getTransaction().begin();
        try {
            TestLock testLock = manager.getReference(TestLock.class, testLockId);
            manager.lock(testLock, LockModeType.WRITE);
            manager.remove(testLock);
            manager.getTransaction().commit();
        } catch (Exception e) {
            printThrowable(e);
            manager.getTransaction().rollback();
        }
        
    }
    
    private static void printThrowable(Throwable throwable) {
        if (throwable == null) {
            return;
        }
        throwable.printStackTrace();
        printThrowable(throwable.getCause());
        
    }
}
