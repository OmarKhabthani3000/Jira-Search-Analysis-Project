package testlockcase.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.TableGenerator;
import javax.persistence.Version;

@Entity
public class TestLock {

    public TestLock() {
    }

    public Long getTestLockId() {
        return testLockId;
    }

    public void update() {
        updated = System.currentTimeMillis();
    }

    @Column(name = "testLockId") @Id @TableGenerator(name = "PKGen", table = "PKGen", pkColumnName = "genId", pkColumnValue = "PKGen", valueColumnName = "allocated", allocationSize = 100) @GeneratedValue(strategy = GenerationType.TABLE, generator = "PKGen") 
    protected Long testLockId;

    @Version
    protected long version;
    
    protected long updated;
}
