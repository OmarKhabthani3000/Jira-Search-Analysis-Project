CREATE TABLE pkgen
(
  genid character varying(255) NOT NULL,
  allocated numeric(18,0) NOT NULL
);

CREATE TABLE testlock
(
  testlockid numeric(18,0) NOT NULL,
  version numeric(36,0) NOT NULL,
  updated numeric(18,0)
);