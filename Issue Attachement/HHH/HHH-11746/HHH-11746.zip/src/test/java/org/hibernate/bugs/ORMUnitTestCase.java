/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Objects;

import static org.junit.Assert.assertEquals;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 * <p>
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

    // Add your entities here.
    @Override
    protected Class[] getAnnotatedClasses() {
        return new Class[]{
                Address.class,
                Person.class,
        };
    }

    // If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
    @Override
    protected String[] getMappings() {
        return new String[]{
//				"Foo.hbm.xml",
//				"Bar.hbm.xml"
        };
    }

    // If those mappings reside somewhere other than resources/org/hibernate/test, change this.
    @Override
    protected String getBaseForMappings() {
        return "org/hibernate/test/";
    }

    // Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
    @Override
    protected void configure(Configuration configuration) {
        super.configure(configuration);

        configuration.setProperty(AvailableSettings.SHOW_SQL, Boolean.TRUE.toString());
        configuration.setProperty(AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString());
        configuration.setProperty(AvailableSettings.HBM2DDL_AUTO, "create-drop");
        //configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, "true" );
    }

    // Add your tests, using standard JUnit.
    @Test
    public void hhh11746Test() throws Exception {
        // BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
        Session s = openSession();
        Transaction tx = s.beginTransaction();
        insertTestData(s);
        tx.commit();

        s.clear();
        tx = s.beginTransaction();
        Person person = s.find(Person.class, new PersonId("a1", "s1"));
        Address adr = person.address;
        assertEquals(person.id, adr.id);

        person = s.find(Person.class, new PersonId("a2", "s2"));
        adr = person.address;
        assertEquals(person.id, adr.id);

        tx.commit();
        s.close();
    }



    private void insertTestData(Session s) {
        Person person1 = new Person();
        person1.id = new PersonId("p1", "s1");
        Address address1 = new Address();
        address1.street = "address1";
        person1.address = address1;
        s.persist(person1);

        Person person2 = new Person();
        person2.id = new PersonId("p2", "s2");
        Address address2 = new Address();
        address2.street = "address2";
        person2.address = address2;
        s.persist(person2);
    }

    @Entity(name = "Person")
    public static class Person {

        @Column(name = "id")
        @EmbeddedId
        private PersonId id;

        @OneToOne(cascade = CascadeType.ALL)
        @MapsId("id")
        private Address address;

    }

    @Embeddable
    public static class PersonId implements Serializable {

        private String id;

        private String socialId;

        public PersonId() {
        }

        public PersonId(String id, String socialId) {
            this.id = id;
            this.socialId = socialId;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getSocialId() {
            return socialId;
        }

        public void setSocialId(String socialId) {
            this.socialId = socialId;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof PersonId)) return false;
            PersonId that = (PersonId) o;
            return Objects.equals(getId(), that.getId()) &&
                Objects.equals(getSocialId(), that.getSocialId());
        }

        @Override
        public int hashCode() {
            return Objects.hash(getId(), getSocialId());
        }
    }

    @Entity(name = "Address")
    @Table(name = "address")
    public static class Address {

        @Id
        @Column(name = "id")
        private String id;

        @Column(name = "street")
        String street;

    }
}
