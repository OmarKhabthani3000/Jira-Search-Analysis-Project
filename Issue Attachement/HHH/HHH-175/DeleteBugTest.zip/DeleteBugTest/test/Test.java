package test;

import org.hibernate.*;
import org.hibernate.cfg.*;
import org.hibernate.type.*;

import java.sql.*;
import java.util.Properties;
import java.io.FileInputStream;
import java.math.BigDecimal;

public class Test {
    public static void main(String[] argv) {
        Session sess = null;

        try {

            Configuration cfg = new Configuration();
            cfg.addFile("mapping.xml");
            cfg.addProperties(loadProperties());
            SessionFactory fact = cfg.buildSessionFactory();
            sess = fact.openSession();

            Invoice inv1 = new Invoice("John Doe");
            inv1.addLineItem(new InvoiceLineItem("Sofa",3,new BigDecimal("799.99")));
            inv1.addLineItem(new InvoiceLineItem("Bed",5,new BigDecimal("1159.99")));

            Transaction tx = sess.beginTransaction();
            sess.save(inv1);
            tx.commit();

            tx = sess.beginTransaction();
            sess.delete(inv1);
            tx.commit();
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
        finally {
            if (sess != null) sess.close();
        }
    }

    private static Properties loadProperties() throws Exception {
        Properties props = new Properties();
        FileInputStream propStream = new FileInputStream("test.properties");
        props.load(propStream);
        propStream.close();
        return props;
    }
}
