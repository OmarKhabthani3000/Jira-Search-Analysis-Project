package test;

import org.hibernate.classic.Lifecycle;
import org.hibernate.Session;
import java.io.Serializable;

import java.util.Set;
import java.util.HashSet;

public class Invoice implements Lifecycle
{
    private Long id;
    private String customerName;
    private Set lineItems = new HashSet();

    public Invoice() {}

    public Invoice(String customerName) {
        setCustomerName(customerName);
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setCustomerName(String custName) {
        this.customerName = custName;
    }

    public String getCustomerName() {
        return this.customerName;
    }

    public void setLineItems(Set lineItems) {
        this.lineItems = lineItems;
    }

    public Set getLineItems() {
        return lineItems;
    }

    public void addLineItem(InvoiceLineItem li) {
        lineItems.add(li);
    }

    // Lifecycle Interface
    public boolean onDelete(Session session) {return NO_VETO;}
    public void onLoad(Session s,Serializable id) {}
    public boolean onSave(Session s) {return NO_VETO;}
    public boolean onUpdate(Session s) {return NO_VETO;}
}
