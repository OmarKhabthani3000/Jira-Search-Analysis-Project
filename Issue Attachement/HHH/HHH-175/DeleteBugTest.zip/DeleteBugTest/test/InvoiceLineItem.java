package test;

import org.hibernate.classic.Lifecycle;
import org.hibernate.Session;
import java.io.Serializable;

import java.math.BigDecimal;

public class InvoiceLineItem implements Lifecycle
{
    private Long id;
    private String productName;
    private int quantity;
    private BigDecimal unitPrice;

    public InvoiceLineItem() {}

    public InvoiceLineItem(String productName,int quantity,BigDecimal unitPrice)
    {
        setProductName(productName);
        setQuantity(quantity);
        setUnitPrice(unitPrice);
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductName() {
        return productName;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setUnitPrice(BigDecimal price) {
        this.unitPrice = price;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public boolean equals(Object obj) {
        if (id == null) return super.equals(obj);
        return (obj instanceof InvoiceLineItem) && id.equals(((InvoiceLineItem)obj).getId());
    }

    public int hashCode() {
        if (id == null) return super.hashCode();
        return id.hashCode();
    }

    // Lifecycle Interface
    public boolean onDelete(Session session) {return NO_VETO;}
    public void onLoad(Session s,Serializable id) {}
    public boolean onSave(Session s) {return NO_VETO;}
    public boolean onUpdate(Session s) {return NO_VETO;}

}
