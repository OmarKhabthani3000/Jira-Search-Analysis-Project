drop table invoice_item
/

drop table invoice
/

drop sequence invoice_seq
/
