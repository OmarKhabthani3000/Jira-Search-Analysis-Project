create table invoice
(
   id number(18),
   customer_name varchar2(40),
   constraint pk_invoice primary key (id)
)
/

create table invoice_item
(
   id number(18),
   invoice_id number(18),
   product_name varchar2(40),
   quantity number(10),
   unit_price number(12,2),
   constraint pk_invoice_item primary key(id),
   constraint fk_invoice_item foreign key (invoice_id) references invoice(id)
)
/

create sequence invoice_seq
/
