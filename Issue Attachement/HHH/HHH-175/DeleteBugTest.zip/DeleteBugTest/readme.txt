This program demonstrates a bug in bulk deletes in Hibernate 3 (HHH-175).  
To run:
- Run build.sql to build the tables in Oracle.
- Edit test.properties to reference your local environment.
- Run the default target in build.xml to build and run the test.  The
  test program fails with a NullPointerException.

