/*
 * B.java
 *
 * Created on 4. August 2005, 20:39
 */

import java.util.*;
/**
 *
 * @author  Peter Fassev
 */
public class A implements Cloneable {
	
	protected long id;
	
	protected int version;
	
	List elements = new ArrayList();
	
	/** Creates a new instance of B */
	public A() {
	}
	
	/**
	 * Getter for property id.
	 * @return Value of property id.
	 */
	public long getId() {
		return id;
	}
	
	/**
	 * Setter for property id.
	 * @param id New value of property id.
	 */
	public void setId(long id) {
		this.id = id;
	}
	
	/**
	 * Getter for property version.
	 * @return Value of property version.
	 */
	public int getVersion() {
		return version;
	}
	
	/**
	 * Setter for property version.
	 * @param version New value of property version.
	 */
	public void setVersion(int version) {
		this.version = version;
	}
	
	/**
	 * Getter for property elements.
	 * @return Value of property elements.
	 */
	public List getElements() {
		return elements;
	}
	
	/**
	 * Setter for property elements.
	 * @param elements New value of property elements.
	 */
	public void setElements(List elements) {
		this.elements = elements;
	}
	
	public void addElement(B b) {
		if (!elements.contains(b)) {
			b.setA(this);
			elements.add(b);
		}
	}
}
