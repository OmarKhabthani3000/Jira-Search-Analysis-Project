/*
 * TestCase.java
 *
 * Created on 4. August 2005, 19:53
 */

import java.net.URL;
import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.engine.*;

/**
 *
 * @author  Peter Fassev
 */
public class TestCase {
	
	private static SessionFactory sessionFactory;
	
	/** Creates b new instance of TestCase */
	public TestCase() {
	}

	protected static void init() {
		URL configFile = TestCase.class.getResource("/test_hibernate.hbm.xml");
		Configuration configuration = new Configuration();
		configuration.addURL(configFile);
		sessionFactory = configuration.buildSessionFactory();
	}
	
	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		init();
		
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		A a = new A();
		B b = new B();
		b.addElement("test1");
		b.addElement("test2");
		a.addElement(b);
		session.saveOrUpdate(a);
		long id = a.getId();
		transaction.commit();
		session.close();
		
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		a = (A)session.get(A.class, new Long(id));
		b  = (B)a.getElements().get(0);
		b.addElement("test3");
		session.saveOrUpdate(b);
		transaction.commit();
		session.close();

		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		a = (A)session.get(A.class, new Long(id));
		b = (B)a.getElements().get(0);
		transaction.commit();
		session.close();
	}
	
}
