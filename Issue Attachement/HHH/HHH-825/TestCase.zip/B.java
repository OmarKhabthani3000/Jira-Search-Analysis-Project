/*
 * A.java
 *
 * Created on 4. August 2005, 19:52
 */

/**
 *
 * @author  Peter Fassev
 */
public class B implements Cloneable {
	
	protected long id;
	
	protected int version;
	
	protected A a;
	
	protected String[] elements = new String[0];
	
	/** Creates a new instance of A */
	public B() {
	}
	
	
	/**
	 * Getter for property id.
	 * @return Value of property id.
	 */
	public long getId() {
		return id;
	}
	
	/**
	 * Setter for property id.
	 * @param id New value of property id.
	 */
	public void setId(long id) {
		this.id = id;
	}
	
	/**
	 * Getter for property version.
	 * @return Value of property version.
	 */
	public int getVersion() {
		return version;
	}
	
	/**
	 * Setter for property version.
	 * @param version New value of property version.
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	/**
	 * Getter for property elements.
	 * @return Value of property elements.
	 */
	public java.lang.String[] getElements() {
		return this.elements;
	}
	
	/**
	 * Setter for property elements.
	 * @param elements New value of property elements.
	 */
	public void setElements(java.lang.String[] elements) {
		this.elements = elements;
	}
	
	public void addElement(String str) {
		String[] newElements = new String[elements.length + 1];
		System.arraycopy(elements, 0, newElements, 0, elements.length);
		newElements[elements.length] = str;
		elements = newElements;
	}
	
	public void removeElement(int index) {
		String[] newElements = new String[elements.length - 1];
		if (index > 0) {
			System.arraycopy(elements, 0, newElements, 0, index);
		}
		if (index + 1 < elements.length) {
			System.arraycopy(elements, index + 1, newElements, 0, elements.length);
		}
		elements = newElements;
	}

	public void setElement(int index, String str) {
		elements[index] = str;
	}
	
	/**
	 * Getter for property a.
	 * @return Value of property a.
	 */
	public A getA() {
		return a;
	}
	
	/**
	 * Setter for property a.
	 * @param a New value of property a.
	 */
	public void setA(A a) {
		this.a = a;
	}
}
