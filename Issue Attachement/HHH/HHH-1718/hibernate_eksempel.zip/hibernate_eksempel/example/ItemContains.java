package example;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "ITEM_CONTAINS")
public class ItemContains implements Serializable {
	private static final long serialVersionUID = -2258534827883092609L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_contains_id")
	private Long itemContainsId;

	@ManyToOne()
	@JoinColumn(name = "item_id")
	private Item item;

	@Column(name = "contains_qty", nullable=false)
	private Integer quantity;

	@ManyToOne()
	@JoinColumn(name="contains_item_id")
	private Item contains;

	@Version
	private Integer version;

	public ItemContains() {}

	public Item getContains() {
		return contains;
	}

	public void setContains(Item contains) {
		this.contains = contains;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Long getItemContainsId() {
		return itemContainsId;
	}

	public void setItemContainsId(Long itemContainsId) {
		this.itemContainsId = itemContainsId;
	}

}
