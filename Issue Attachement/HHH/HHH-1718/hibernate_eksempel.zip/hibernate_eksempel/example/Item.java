package example;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "ITEM")
public class Item implements Serializable {
	private static final long serialVersionUID = -382535078856947980L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_id")
	private Long itemId;

	@Column(name = "description", nullable=false)
	private String description;

	@OneToMany(fetch=FetchType.EAGER, mappedBy="item")
	// This fetchmode is not JPA compliant, but we *must* set a fetchmode explicitly
	// when fetching order objects in order to avoid two bags in the same object graph
	// Thus, we need to uncomment the next line to make it work...
	//@org.hibernate.annotations.Fetch(org.hibernate.annotations.FetchMode.SUBSELECT)
	private List<ItemContains> contains;

	@Version
	private Integer version;

	public Item() {}


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}


	public List<ItemContains> getContains() {
		return contains;
	}


	public void setContains(List<ItemContains> contains) {
		this.contains = contains;
	}


}
