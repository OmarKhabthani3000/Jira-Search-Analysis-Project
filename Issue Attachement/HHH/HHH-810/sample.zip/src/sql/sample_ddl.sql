CREATE TABLE product (
  category INT NOT NULL,
  id INT NOT NULL,
  price DECIMAL,
  PRIMARY KEY(category, id)
) TYPE=INNODB;

CREATE TABLE customer (id INT NOT NULL,
  PRIMARY KEY (id)
) TYPE=INNODB;

CREATE TABLE product_order (
  no INT NOT NULL AUTO_INCREMENT,
  product_category INT NOT NULL,
  product_id INT NOT NULL,
  customer_id INT NOT NULL,
  PRIMARY KEY(no),
  INDEX (product_category, product_id),
  FOREIGN KEY (product_category, product_id)
  REFERENCES product(category, id)
  ON UPDATE CASCADE ON DELETE RESTRICT,
  INDEX (customer_id),
  FOREIGN KEY (customer_id)
  REFERENCES customer(id)
) TYPE=INNODB;

