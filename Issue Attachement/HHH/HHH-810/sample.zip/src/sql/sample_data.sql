truncate table car;
insert into car(version, license_plate, description, garage_id) values(0, '34 TTD 2202','ferrari', null);
insert into car(version, license_plate, description, garage_id) values(0, '35 TTD 2202','porsche', null);

truncate table garage;
insert into garage(id, description) values(1,'garage 1');
insert into garage(id, description) values(2,'garage 2');
insert into garage(id, description) values(3,'garage 3');
insert into garage(id, description) values(4,'garage 4');
