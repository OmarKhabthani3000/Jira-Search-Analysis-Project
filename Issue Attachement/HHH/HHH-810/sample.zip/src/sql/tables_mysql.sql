DROP TABLE IF EXISTS garage;
CREATE TABLE garage (
  id numeric(30) not null,
  description varchar(30) ,
  PRIMARY KEY(id),
  INDEX (id)
) TYPE = InnoDB;

DROP TABLE IF EXISTS car;
CREATE TABLE car (
  version int(10) not null,
  license_plate varchar(30) ,
  description varchar(30) ,
  available int(1) ,
  car_size varchar(1) ,
  garage_id numeric(30),
  PRIMARY KEY(license_plate),
  INDEX (license_plate),
  INDEX (garage_id),
  FOREIGN KEY (garage_id) REFERENCES garage(id)
) TYPE = InnoDB;
