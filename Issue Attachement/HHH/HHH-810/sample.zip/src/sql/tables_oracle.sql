DROP TABLE car;
CREATE TABLE car (
  version numeric(10),
  license_plate varchar(30),
  description varchar(30),
  available numeric(1),
  car_size varchar(1)
);

