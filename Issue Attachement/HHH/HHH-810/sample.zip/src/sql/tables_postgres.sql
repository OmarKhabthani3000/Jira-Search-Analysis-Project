DROP TABLE car;
CREATE TABLE car (
  version numeric(10),
  license_plate varchar(30),
  description varchar(30),
  available boolean,
  car_size varchar(1),
  garage_id numeric(30)
);

drop table garage;
CREATE TABLE garage (
  id numeric(30),
  description varchar(30)
);

grant all on car to public;
grant all on garage to public;
