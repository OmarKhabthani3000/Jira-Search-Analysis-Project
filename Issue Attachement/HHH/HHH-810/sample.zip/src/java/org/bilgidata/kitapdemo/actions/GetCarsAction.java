package org.bilgidata.kitapdemo.actions;

import org.hibernate.Session;
import org.apache.struts.action.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import org.bilgidata.kitapdemo.service.HibernateSession;
import org.bilgidata.kitapdemo.pojo.Car;
import org.bilgidata.kitapdemo.pojo.Garage;
import org.apache.commons.beanutils.BeanUtils;
import org.bilgidata.kitapdemo.dao.CarDAO;
import org.bilgidata.kitapdemo.dao.GarageDAO;
import org.bilgidata.kitapdemo.util.*;
/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class GetCarsAction extends Action
{
	private static Logger logger = Logger.getLogger("appLogger");

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
        throws Exception {

        StopWatch.start(StopWatch.GET_CARS_ACTION);
        
        CarDAO cdao = new CarDAO();
        GarageDAO gdao = new GarageDAO();
            
        request.getSession().setAttribute("carList", cdao.fetchCarList());
        request.getSession().setAttribute("garageList", gdao.fetchGarageLabels());
            
        StopWatch.stop(StopWatch.GET_CARS_ACTION);
        
        return mapping.findForward("success");
    }    
}
