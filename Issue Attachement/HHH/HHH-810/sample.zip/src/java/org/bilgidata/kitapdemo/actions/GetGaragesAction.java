package org.bilgidata.kitapdemo.actions;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.bilgidata.kitapdemo.service.HibernateSession;
import org.bilgidata.kitapdemo.pojo.Car;
import org.bilgidata.kitapdemo.pojo.Garage;
import org.hibernate.Session;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.DynaActionForm;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.bilgidata.kitapdemo.dao.GarageDAO;
import org.bilgidata.kitapdemo.util.StopWatch;
/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class GetGaragesAction extends Action
{
	private static Logger logger = Logger.getLogger("appLogger");

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
        throws Exception {

        StopWatch.start(StopWatch.GET_GARAGES_ACTION);
        
        GarageDAO gdao = new GarageDAO();
            
        request.getSession().setAttribute("garageList", gdao.fetchGarageList());
                    
        StopWatch.stop(StopWatch.GET_GARAGES_ACTION);

        return mapping.findForward("success");
    }    
}

