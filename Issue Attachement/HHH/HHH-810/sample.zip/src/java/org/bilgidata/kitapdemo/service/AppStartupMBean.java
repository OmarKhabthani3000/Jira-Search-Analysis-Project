package org.bilgidata.kitapdemo.service;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public interface AppStartupMBean  {
    
  public abstract void init() throws Exception;
  public abstract void start() throws Exception;
  public abstract void stop() throws Exception;
  public abstract void destroy() throws Exception;
}
