/*
 * Machine.java
 *
 * Version:
 * $Id: Machine.java,v 1.8 2005/03/15 15:54:55 burakba Exp $
 *
 * Revisions:
 * $Log: Machine.java,v $
 * Revision 1.8  2005/03/15 15:54:55  burakba
 * ""
 *
 */

package org.bilgidata.kitapdemo.pojo;

import java.io.*;
import java.util.*;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class Car {
    
    public Car() { }

    int version = -1;

    /**
     * Get the Version value.
     * @return the Version value.
     */
    public int getVersion() {
        return version;
    }

    /**
     * Set the Version value.
     * @param newVersion The new Version value.
     */
    public void setVersion(int newVersion) {
        this.version = newVersion;
    }
    
    String licensePlate;

    /**
     * Get the LicensePlate value.
     * @return the LicensePlate value.
     */
    public String getLicensePlate() {
        return licensePlate;
    }

    /**
     * Set the LicensePlate value.
     * @param newLicensePlate The new LicensePlate value.
     */
    public void setLicensePlate(String newLicensePlate) {
        this.licensePlate = newLicensePlate;
    }
    
    String description;

    /**
     * Get the Description value.
     * @return the Description value.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set the Description value.
     * @param newDescription The new Description value.
     */
    public void setDescription(String newDescription) {
        this.description = newDescription;
    }

    Boolean available;

    /**
     * Get the Available value.
     * @return the Available value.
     */
    public Boolean getAvailable() {
        return available;
    }

    /**
     * Set the Available value.
     * @param newAvailable The new Available value.
     */
    public void setAvailable(Boolean newAvailable) {
        this.available = newAvailable;
    }

    
    String size;

    /**
     * Get the Size value.
     * @return the Size value.
     */
    public String getSize() {
        return size;
    }

    /**
     * Set the Size value.
     * @param newSize The new Size value.
     */
    public void setSize(String newSize) {
        this.size = newSize;
    }


    Garage garage;

    /**
     * Get the Garage value.
     * @return the Garage value.
     */
    public Garage getGarage() {
        return garage;
    }

    /**
     * Set the Garage value.
     * @param newGarage The new Garage value.
     */
    public void setGarage(Garage newGarage) {
        this.garage = newGarage;
    }
    
    /**
     * Retrieve a String representation of this object
     * 
     * @return a <code>String</code> representation of this object.
     * @see Object#toString()
     */
    public String toString() {
        return
            "licensePlate=" + licensePlate + " " +
            "size=" + size + " " +
            "description=" + description + " " +
            "version="+ version + " " +
            "available="+available + " " + 
            "garage="+garage;        
    }

	/**
     * Describe <code>equals</code> method here.
     *
     * @param other an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object other) {
		if (other==null) return false;
		if ( !(other instanceof Car) ) return false;
		return ( (Car) other ).getLicensePlate().equals(licensePlate);
	}
    
	public int hashCode() {
		return licensePlate.hashCode();
	}
    
    
}
