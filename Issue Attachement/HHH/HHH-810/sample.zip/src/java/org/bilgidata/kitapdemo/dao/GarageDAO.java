/*
 * Dao.java
 *
 * Version:
 * $Id: Dao.java,v 1.2 2005/03/10 10:21:16 burakba Exp $
 *
 * Revisions:
 * $Log: Dao.java,v $
 * Revision 1.2  2005/03/10 10:21:16  burakba
 * ""
 *
 * Revision 1.1  2005/03/09 15:45:25  burakba
 * ""
 *
 */

package org.bilgidata.kitapdemo.dao;

import org.apache.log4j.Logger;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import org.hibernate.*;
import org.hibernate.cfg.*;
import org.bilgidata.kitapdemo.service.*;
import org.bilgidata.kitapdemo.pojo.*;
import org.bilgidata.kitapdemo.util.*;
import java.util.HashMap;
import org.apache.struts.util.*;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class GarageDAO   {

    /**
     * Creates a new <code>Dao</code> instance.
     *
     * @param s a <code>Session</code> value
     */
    public GarageDAO() {
        HibernateSession.beginTransaction();        
    }

    /**
     * Describe <code>fetchCarList</code> method here.
     *
     * @return a <code>List</code> value
     */
    public List fetchGarageList() {
        
        Session s = HibernateSession.openSession();        
        Query  query = s.createQuery("from Garage");        
//         query.setCacheable(true);
//         query.setCacheRegion("KitapDemoQueries");        
        return query.list();
    }

    
    /**
     * Describe <code>getGaragesForCars</code> method here.
     *
     * @param description a <code>String</code> value
     * @return a <code>List</code> value
     */
    public List getGaragesForCars(String description) {
        Session s = HibernateSession.openSession();
        Query query = s.createQuery(
                                    "select garage from Garage garage " +
                                    "left join garage.cars car " +
                                    "where car.description = :description "
                                    );
        query.setString("description", description);
//         query.setCacheable(true);
//         query.setCacheRegion("KitapDemoQueries");        
        return query.list();
    }    
        
    /**
     * Describe <code>fetchGarageLabels</code> method here.
     *
     * @return a <code>List</code> value
     */
    public List fetchGarageLabels() {
        List garages = fetchGarageList();
        Vector garageList = new Vector();
        garageList.add(new LabelValueBean("",""));
        for (int i=0;i<garages.size();i++) {
            garageList.add(new LabelValueBean(
                                              ((Garage)garages.get(i)).getDescription(),
                                              ((Garage)garages.get(i)).getGarageId().toString()
                                              )
                           );
        }

        return garageList;
    }
    
}
