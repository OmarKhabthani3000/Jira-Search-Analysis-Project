package org.bilgidata.kitapdemo.util;

import java.util.StringTokenizer;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.File;

import junit.framework.TestSuite;

/**
 * Describe class <code>AllTest</code> here.
 *
 * @author <a href="mailto:burak.bayramli@oksijen.com">Burak Bayramli</a>
 * @version 1.0
 */
public class AllTest extends TestSuite
{        
	/**
     * Describe <code>suite</code> method here.
     *
     * @return a <code>TestSuite</code> value
     */
    public static TestSuite suite()
	{ 
		return new AllTest();
	}

	/**
     * Describe <code>suite</code> method here.
     *
     * @param testSuffix a <code>String</code> value
     * @return a <code>TestSuite</code> value
     */
    public static TestSuite suite(String testSuffix)
	{ 
		return new AllTest(testSuffix);
	}

	/**
     * Creates a new <code>AllTest</code> instance.
     *
     */
    public AllTest()
	{
		this(DEFAULT_CLASS_SUFFIX);
	}

	/**
     * Creates a new <code>AllTest</code> instance.
     *
     * @param testSuffix a <code>String</code> value
     */
    public AllTest(String testSuffix)
	{
		this.testSuffix = testSuffix;
		try
		{
			String classPath = System.getProperty("java.class.path");
			String separator = System.getProperty("path.separator");
			gatherFiles(splitClassPath(classPath, separator));
		}
		catch (Throwable unexpected)
		{
			unexpected.printStackTrace();
		}
	}

	/**
     * Describe <code>getSuffixString</code> method here.
     *
     * @return a <code>String</code> value
     */
    public String getSuffixString()
	{
		return testSuffix;
	}

	/**
     * Describe <code>main</code> method here.
     *
     * @param args a <code>String[]</code> value
     */
    public static void main(String[] args)
	{
		junit.textui.TestRunner.run(args[0] == null ? suite() : suite(args[0]));
        System.exit(0);
	}

	/**
     * Describe <code>setSuffixString</code> method here.
     *
     * @param suffix a <code>String</code> value
     */
    public void setSuffixString(String suffix)
	{
		this.testSuffix = suffix;
	}

	/**
     * Describe <code>gatherFiles</code> method here.
     *
     * @param roots a <code>List</code> value
     */
    private void gatherFiles(List roots)
	{
		Iterator i = roots.iterator();
		while (i.hasNext())
		{
			gatherFiles(new File((String) i.next()), "");
		}
	}
    
	/**
     * Describe <code>gatherFiles</code> method here.
     *
     * @param classRoot a <code>File</code> value
     * @param classFilename a <code>String</code> value
     */
    private void gatherFiles(File classRoot, String classFilename)
	{
		File thisRoot = new File(classRoot, classFilename);
		if (thisRoot.isFile())
		{
			maybeAddTestFor(classFilename);
			return;
		}
		String[] contents = thisRoot.list();
		// sometime the list() method returns a null
		if (contents != null)
		{
			for (int i = 0; i < contents.length; i++)
			{
				gatherFiles(classRoot, classFilename
                            + File.separatorChar + contents[i]);
			}
		}
	}

	/**
     * Describe <code>splitClassPath</code> method here.
     *
     * @param classPath a <code>String</code> value
     * @param separator a <code>String</code> value
     * @return a <code>List</code> value
     */
    private static List splitClassPath(String classPath, String separator)
	{
		List result = new ArrayList();
		StringTokenizer tokenizer = new StringTokenizer(classPath, separator);
		while (tokenizer.hasMoreTokens())
		{
			result.add(tokenizer.nextToken());
		}
		return result;
	}

	/**
     * Describe <code>maybeAddTestFor</code> method here.
     *
     * @param classFileName a <code>String</code> value
     */
    private void maybeAddTestFor(String classFileName)
	{
		if (!classFileName.endsWith(getSuffixString()))
		{
			return;
		}
		try
		{
			Class testClass = classFromFile(classFileName);
			if (isTest(testClass) && testClass != this.getClass())
			{
				System.out.println("Adding " + testClass.getName());
				TestSuite suite = new TestSuite(testClass);
				addTest(suite);
			}
		}
		catch (ClassNotFoundException expected)
		{
		}
		catch (NoClassDefFoundError expected)
		{
		}
	}

	/**
     * Describe <code>isTest</code> method here.
     *
     * @param c a <code>Class</code> value
     * @return a <code>boolean</code> value
     */
    private static boolean isTest(Class c)
	{
		return junit.framework.Test.class.isAssignableFrom(c);
	}

	/**
     * Describe <code>classFromFile</code> method here.
     *
     * @param classFileName a <code>String</code> value
     * @return a <code>Class</code> value
     * @exception ClassNotFoundException if an error occurs
     */
    private static Class classFromFile(String classFileName)
		throws ClassNotFoundException
	{
		return Class.forName(classNameFromFile(classFileName));
	}

	/**
     * Describe <code>classNameFromFile</code> method here.
     *
     * @param classFileName a <code>String</code> value
     * @return a <code>String</code> value
     */
    private static String classNameFromFile(String classFileName)
	{
		String clean = trimTrailingDotClass(trimLeadingFileSeparator(classFileName));
		return clean.replace(File.separatorChar, '.');
	}

	/**
     * Describe <code>trimLeadingFileSeparator</code> method here.
     *
     * @param s a <code>String</code> value
     * @return a <code>String</code> value
     */
    private static String trimLeadingFileSeparator(String s)
	{
		if (s.charAt(0) == File.separatorChar)
		{            
			return s.substring(1);
		}
		else
		{
			return s;
		}
	}

	/**
     * Describe <code>trimTrailingDotClass</code> method here.
     *
     * @param s a <code>String</code> value
     * @return a <code>String</code> value
     */
    private static String trimTrailingDotClass(String s)
	{
		return s.substring(0, s.length() - ".class".length());
	}

	/**
     * Describe class <code>Test</code> here.
     *
     */
    public static class Test extends junit.framework.TestCase
	{
		public Test(String testName)
		{
			super(testName);
		}

		public void testClassFromFile()
			throws ClassNotFoundException
		{
			String classFilename =
				"org.bilgidata.kitapdemo.util.AllTest$Test.class";
			assertEquals("org.bilgidata.kitapdemo.util.AllTest$Test",
                         classNameFromFile(classFilename));
			assertSame(this.getClass(), classFromFile(classFilename));
		}

		public void testSplitClassPath()
		{
			List dirs = splitClassPath("/dir1:.:another:/dirB/blah", ":");
			int i = 0;
			assertEquals("/dir1", dirs.get(i++));
			assertEquals(".", dirs.get(i++));
			assertEquals("another", dirs.get(i++));
	 		assertEquals("/dirB/blah", dirs.get(i++));
		}
	}

	private String testSuffix;

	public static final String DEFAULT_CLASS_SUFFIX = "Test.class";
}
