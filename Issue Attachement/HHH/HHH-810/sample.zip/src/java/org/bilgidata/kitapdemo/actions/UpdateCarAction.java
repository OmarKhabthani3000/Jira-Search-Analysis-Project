package org.bilgidata.kitapdemo.actions;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.bilgidata.kitapdemo.service.HibernateSession;
import org.bilgidata.kitapdemo.pojo.Car;
import org.bilgidata.kitapdemo.pojo.Garage;
import org.hibernate.Session;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.DynaActionForm;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.bilgidata.kitapdemo.util.StopWatch;


/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class UpdateCarAction extends Action
{
	private static Logger logger = Logger.getLogger("appLogger");

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
        throws Exception {
        
        StopWatch.start(StopWatch.UPDATE_CAR_ACTION);

        DynaActionForm daf = (DynaActionForm) form;
        
        if (logger.isDebugEnabled()) logger.debug("daf=" + daf);

                
        ActionErrors errors=new ActionErrors();

        String id = "";
        String result = "";
        
        try {
            Session s = HibernateSession.openSession();
            HibernateSession.beginTransaction();
            
            id = (String)daf.get("licensePlate");
            Car car = new Car();
            BeanUtils.copyProperties(car, daf);
            String available = request.getParameter("available");
            if (logger.isDebugEnabled()) logger.debug("available=" + available);
            if (available == null) {
                car.setAvailable(new Boolean(false));
            }             
            
            Integer formGarageId = (Integer)daf.get("garageId");
            if (formGarageId != null && !formGarageId.equals(new Integer(0))) {
                Garage garage = (Garage)s.get(Garage.class, formGarageId);
                car.setGarage(garage);
            } 
            
            s.merge(car);
            
            HibernateSession.commitTransaction();
            result = "success";

        } catch (org.hibernate.StaleObjectStateException e) {             
            errors.add(ActionMessages.GLOBAL_MESSAGE,
                       new ActionError("optimistic.car.update.failed", id));
            saveErrors(request,errors);
            HibernateSession.rollbackTransaction();
            result = "fail";
        }
        
        // form icindeki degerleri sil
        HttpSession session = request.getSession();
        session.removeAttribute(mapping.getAttribute());

        StopWatch.stop(StopWatch.UPDATE_CAR_ACTION);

        // geri don
        return mapping.findForward(result);
    }    
}

