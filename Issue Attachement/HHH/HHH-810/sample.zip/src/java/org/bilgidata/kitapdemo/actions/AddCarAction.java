package org.bilgidata.kitapdemo.actions;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.bilgidata.kitapdemo.service.HibernateSession;
import org.bilgidata.kitapdemo.pojo.Car;
import org.bilgidata.kitapdemo.pojo.Garage;
import org.hibernate.Session;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.DynaActionForm;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.bilgidata.kitapdemo.util.StopWatch;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class AddCarAction extends Action
{
	private static Logger logger = Logger.getLogger("appLogger");

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
        throws Exception {
        
        StopWatch.start(StopWatch.ADD_CAR_ACTION);
        
        DynaActionForm daf = (DynaActionForm) form;

        if (logger.isDebugEnabled()) logger.debug("getting garage 2");
        
        Car car = new Car ();
        BeanUtils.copyProperties(car, daf);

        if (logger.isDebugEnabled()) logger.debug("getting garage 3");
        
        Session s = HibernateSession.openSession();
        HibernateSession.beginTransaction();
            
        // ebeveyn ili�kisini kur
        if (logger.isDebugEnabled()) logger.debug("getting garage 1");
        Integer garageId = (Integer)daf.get("garageId");
        if (logger.isDebugEnabled()) logger.debug("garageId=" + garageId);            
            
        if (garageId != null && !garageId.equals("")) {
            if (logger.isDebugEnabled()) logger.debug("getting garage");
            Garage garage = (Garage)s.get(Garage.class, garageId);
            car.setGarage(garage);
            garage.getCars().add(car);
        } 
            
        s.saveOrUpdate(car);

        // form icindeki degerleri sil
        HttpSession session = request.getSession();
        session.removeAttribute(mapping.getAttribute());        
                
        StopWatch.stop(StopWatch.ADD_CAR_ACTION);

        return mapping.findForward("success");
    }
    
}
