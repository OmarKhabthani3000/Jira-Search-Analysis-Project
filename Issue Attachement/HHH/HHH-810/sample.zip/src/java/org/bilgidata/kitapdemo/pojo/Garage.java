/*
 * Garage.java
 *
 * Version:
 * $Id$
 *
 * Revisions:
 * $Log$
 */

package org.bilgidata.kitapdemo.pojo;

import java.io.*;
import java.util.*;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class Garage   {
    
    public Garage() {
    }

    Integer garageId;

    /**
     * Get the GarageId value.
     * @return the GarageId value.
     */
    public Integer getGarageId() {
        return garageId;
    }

    /**
     * Set the GarageId value.
     * @param newGarageId The new GarageId value.
     */
    public void setGarageId(Integer newGarageId) {
        this.garageId = newGarageId;
    }

    String description;

    /**
     * Get the Description value.
     * @return the Description value.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set the Description value.
     * @param newDescription The new Description value.
     */
    public void setDescription(String newDescription) {
        this.description = newDescription;
    }

    Set cars;

    /**
     * Get the Cars value.
     * @return the Cars value.
     */
    public Set getCars() {
        return cars;
    }

    /**
     * Set the Cars value.
     * @param newCars The new Cars value.
     */
    public void setCars(Set newCars) {
        this.cars = newCars;
    }

	/**
     * Describe <code>equals</code> method here.
     *
     * @param other an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object other) {
		if (other==null) return false;
		if ( !(other instanceof Garage) ) return false;
		return ( (Garage) other ).getGarageId().equals(garageId);
	}
    
	public int hashCode() {
		return garageId.hashCode();
	}
    
    /**
     * Retrieve a String representation of this object
     * 
     * @return a <code>String</code> representation of this object.
     * @see Object#toString()
     */
    public String toString() {
        return
            "garageId="+garageId + " " +
            "description="+description;
    }
    
    
}
