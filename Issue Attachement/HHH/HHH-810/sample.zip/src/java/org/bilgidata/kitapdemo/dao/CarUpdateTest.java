package org.bilgidata.kitapdemo.dao;

import junit.framework.TestCase;

import java.sql.*;
import org.bilgidata.kitapdemo.util.TestUtil;
import org.bilgidata.kitapdemo.pojo.*;
import org.bilgidata.kitapdemo.service.*;
import org.hibernate.*;
import org.hibernate.cfg.*;
import java.util.Calendar;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class CarUpdateTest extends TestCase  { 

    public CarUpdateTest() { }

    public void testDoubleUpdateSimple() throws Exception {
        
        Connection c = TestUtil.createTestConnection();        
        TestUtil.createFromFile("tables_mysql.sql", c);        
        TestUtil.insertFromFile("sample_data.sql", c);

        boolean exceptionThrown = false;
        
        Session s = HibernateSession.openSession();
        HibernateSession.beginTransaction();            

        Car car1 = null;
        Car car2 = null;
        
        try {
                
            //
            // read car1
            //
            HibernateSession.getSessionFactory().evict(Car.class, "34 TTD 2202");
            s.evict(Car.class);            
            car1 = (Car) s.get(Car.class, "34 TTD 2202");
            String description = "" + Calendar.getInstance().getTimeInMillis();
            car1.setDescription(description);
            System.out.println("version after read car 1 " + car1.getVersion());

            //
            // read car2
            //
            HibernateSession.getSessionFactory().evict(Car.class, "34 TTD 2202");
            s.evict(Car.class);
            car2 = (Car) s.get(Car.class, "34 TTD 2202");
            description = "" + Calendar.getInstance().getTimeInMillis();
            car2.setDescription(description);
            System.out.println("version after read car 2 " + car2.getVersion());

            //
            // update car1
            //
            System.out.println("---- right before update");            
            System.out.println("new description is " + description); 
            System.out.println("version is " + car1.getVersion());
            s.saveOrUpdate(car1);

            HibernateSession.commitTransaction();

            System.out.println("version after update car 1 " + car1.getVersion());
            System.out.println("version after update car 2 " + car2.getVersion());
        } finally {
            HibernateSession.closeSession();                 
        } // end of finally
            
        // ----------------------------------------------------------
        // ---------------------------------------------------------

        try {
            
            s = HibernateSession.openSession();
            HibernateSession.beginTransaction();            

            System.out.println("---- right before update");            
            String description = "" + Calendar.getInstance().getTimeInMillis();
            System.out.println("new description is " + description); 
            System.out.println("version car1 before second update is " + car1.getVersion());
            System.out.println("version car2 before second update is " + car2.getVersion());
            String dbVal = TestUtil.getStringRowVal("select version from car where license_plate = \'34 TTD 2202\'", c);
            System.out.println("db version before second update is " + dbVal);

            // alttaki comment out edilmezse, herif exception atmiyor
            // (atmasini istiyoruz).
            // bu nasil is? aralarinda hicbir iliski olmamasina ragmen,
            // car2'nin version degeri car1 update'den sonra degisiyor!!!!
            // hibernate versiyon tag'i tam bir hokus pokuscuymus yani indeed! 
            car2.setVersion(0);
            
            s.saveOrUpdate(car2);
            HibernateSession.commitTransaction();
                        
        } catch (org.hibernate.StaleObjectStateException e) {
            exceptionThrown = true;
        } finally {
            HibernateSession.closeSession();                 
        } // end of finally
        
        
        assertEquals(true, exceptionThrown);
    }    

    
}
