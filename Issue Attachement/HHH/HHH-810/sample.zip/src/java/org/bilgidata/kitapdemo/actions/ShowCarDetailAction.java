package org.bilgidata.kitapdemo.actions;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.bilgidata.kitapdemo.service.HibernateSession;
import org.bilgidata.kitapdemo.pojo.Car;
import org.bilgidata.kitapdemo.pojo.Garage;
import org.hibernate.Session;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.DynaActionForm;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.bilgidata.kitapdemo.dao.GarageDAO;
import org.bilgidata.kitapdemo.util.StopWatch;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class ShowCarDetailAction extends Action
{
	private static Logger logger = Logger.getLogger("appLogger");

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
        throws Exception {

        StopWatch.start(StopWatch.VIEW_CAR_ACTION);
        
        String licensePlate = request.getParameter("licensePlate");
                
        Session s = HibernateSession.openSession();
        HibernateSession.beginTransaction();

        Car car = (Car)s.get(Car.class, licensePlate);
        if (logger.isDebugEnabled()) logger.debug("car=" + car);
            
        DynaActionForm daf = (DynaActionForm) form;
        BeanUtils.copyProperties(daf, car);
        if (car.getGarage() != null) {
            daf.set("garageId", car.getGarage().getGarageId());
        } else {
            daf.set("garageId", new Integer(0));
        } // end of else
        
        GarageDAO gdao = new GarageDAO();
        
        request.getSession().setAttribute("garageList", gdao.fetchGarageLabels());
        request.getSession().setAttribute("car", car);	    
        
        StopWatch.stop(StopWatch.VIEW_CAR_ACTION);

        return mapping.findForward("success");
    }
    
}
