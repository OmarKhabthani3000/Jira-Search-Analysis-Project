package org.bilgidata.kitapdemo.service;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import org.bilgidata.kitapdemo.util.StopWatch;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class AppStartup  implements AppStartupMBean {
	
           
    public AppStartup() {        
    }

    public ObjectName preRegister(MBeanServer server, ObjectName name) throws java.lang.Exception {
        return new ObjectName(":service=AppStartup");
    }

    public void postRegister(java.lang.Boolean registrationDone) {
    }
    
    public void preDeregister() throws java.lang.Exception {
    }
    
    public void postDeregister() {
    }
    
    public void init() throws Exception {
        System.out.println("----------------- INIT ---------------------");
    }

    public void start() throws Exception {
        new StopWatch().startThread();
        HibernateSession.openSession();
        HibernateSession.closeSession();
        System.out.println("----------------- STARTED ---------------------");
    }
    
    public void stop() throws Exception {
        System.out.println("----------------- STOP ---------------------");
    }
    
    public void destroy() throws Exception {
        System.out.println("----------------- DESTROYED ---------------------");
    }

 
}
