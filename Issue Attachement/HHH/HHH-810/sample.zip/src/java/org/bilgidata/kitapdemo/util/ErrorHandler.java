package org.bilgidata.kitapdemo.util;

/*
 * ErrorHandler.java
 *
 * Version:
 * $Id$
 *
 * Revisions:
 * $Log$
 */


import org.apache.struts.action.*;
import org.apache.struts.config.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import javax.servlet.*;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class ErrorHandler extends ExceptionHandler {

	private static Logger logger = Logger.getLogger("appLogger");

    public ActionForward execute(Exception ex,
                                 ExceptionConfig ae,
                                 ActionMapping mapping,
                                 ActionForm formInstance,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
        
        throws ServletException {

        logger.error("Struts Generic Handler Caught This Exception", ex);
        
        return mapping.findForward("error");        
    }
    
}
