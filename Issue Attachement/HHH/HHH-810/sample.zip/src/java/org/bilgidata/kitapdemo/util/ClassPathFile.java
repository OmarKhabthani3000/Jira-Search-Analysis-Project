package org.bilgidata.kitapdemo.util;

import java.io.*;


import org.apache.log4j.Logger;

/**
 * Describe class <code>ClassPathFile</code> here.
 *
 * @author <a href="mailto:burak.bayramli@oksijen.com">Burak Bayramli</a>
 * @version 1.0
 */
public class ClassPathFile {

	private Logger logger = Logger.getLogger("appLogger");
    
    String fileName ;
        
    /**
     * Creates a new <code>ClassPathFile</code> instance.
     *
     * @param file a <code>String</code> value
     */
    public ClassPathFile (String file) {
        fileName = file;
    }

    /**
     * Describe <code>getClassPath</code> method here.
     *
     * @return a <code>String[]</code> value
     */
    private String[] getClassPath() {
        java.util.Vector x = new java.util.Vector();
        String classPath = System.getProperty("java.class.path");
        String s = "";
                
               
        for (int i = 0; i < classPath.length(); i++) {
            if(System.getProperty("os.name").toLowerCase().indexOf("windows") > -1)
                if (classPath.charAt(i) == ';') {
                    x.add(s);
                    s = "";
                } else {
                    s += classPath.charAt(i);
                }
            else {
                if (classPath.charAt(i) == ':') {
                    x.add(s);
                    s = "";
                } else {
                    s += classPath.charAt(i);
                }
            }
        }
        
        if (!s.equals("")) x.add(s);
        String javaHome = System.getProperty("java.home");
        if (javaHome != null) x.add(javaHome + File.separatorChar + "lib" + File.separatorChar + "rt.jar");
        String[] retVal = new String[x.size()];
        x.copyInto(retVal);
        return retVal;
    }
        
    /**
     * Describe <code>openFile</code> method here.
     *
     * @return a <code>File</code> value
     */
    public File openFile () {

        File file = null;
                
        try {
            FIND: {
                // first check if the file is in the current directory
                File f = new File(fileName);
                if (f.exists()) {
                    file = f;
                    break FIND;
                }

                // now check if the file is anywhere in the class path (or in a jar file)
                String[] classPath = getClassPath();
                for (int i = 0; i < classPath.length; i++) {
                    f = new File(classPath[i]);
                    if (f.exists()) {
                        if (f.isDirectory()) {
                            // if class path is directory check if file found along that path
                            f = new File(classPath[i] + File.separatorChar + fileName);
                            if (f.isFile()) {
                                file = f;
                                break FIND;
                            }
                        }
                    }
                }
                // if we get to this pount then throw file not found exception
                if (file == null) throw new FileNotFoundException(fileName);
            }
        } catch (Exception e ) {
            logger.error("File not found!", e);
        }
                
        return file;
    }
        
}
