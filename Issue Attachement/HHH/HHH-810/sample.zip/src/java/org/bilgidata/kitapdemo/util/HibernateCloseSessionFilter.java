package org.bilgidata.kitapdemo.util;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;

import org.bilgidata.kitapdemo.service.*;

/**
 * Describe class <code>RequestCharacterEncodingFilter</code> here.
 *
 * @author <a href="mailto:burak.bayramli@oksijen.com">Burak Bayramli</a>
 * @version 1.0
 */
public class HibernateCloseSessionFilter implements Filter {

    private Logger logger = Logger.getLogger("appLogger");

    /**
     * Describe <code>init</code> method here.
     *
     * @param filterConfig a <code>FilterConfig</code> value
     * @exception ServletException if an error occurs
     */
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    /**
     * Describe <code>doFilter</code> method here.
     *
     * @param request a <code>ServletRequest</code> value
     * @param response a <code>ServletResponse</code> value
     * @param chain a <code>FilterChain</code> value
     * @exception IOException if an error occurs
     * @exception ServletException if an error occurs
     */
    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain) throws IOException, ServletException
    {
        try {
            chain.doFilter(request, response);
            HibernateSession.commitTransaction();
        } finally {
            HibernateSession.closeSession();
        } 
        
    }

    public void destroy() { }

}
