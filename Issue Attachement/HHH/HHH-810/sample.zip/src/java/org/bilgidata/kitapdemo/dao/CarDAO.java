/*
 * Dao.java
 *
 * Version:
 * $Id: Dao.java,v 1.2 2005/03/10 10:21:16 burakba Exp $
 *
 * Revisions:
 * $Log: Dao.java,v $
 * Revision 1.2  2005/03/10 10:21:16  burakba
 * ""
 *
 * Revision 1.1  2005/03/09 15:45:25  burakba
 * ""
 *
 */

package org.bilgidata.kitapdemo.dao;

import org.apache.log4j.Logger;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.*;
import org.hibernate.cfg.*;
import org.bilgidata.kitapdemo.service.*;
import org.bilgidata.kitapdemo.pojo.*;
import org.bilgidata.kitapdemo.util.*;
import java.util.HashMap;


/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class CarDAO   {

    /**
     * Creates a new <code>Dao</code> instance.
     *
     * @param s a <code>Session</code> value
     */
    public CarDAO() {
        HibernateSession.beginTransaction();        
    }

    /**
     * Describe <code>fetchCarList</code> method here.
     *
     * @return a <code>List</code> value
     */
    public List fetchCarList() {
        
        Session s = HibernateSession.openSession();        
        Query  query = s.createQuery("from Car");        
//         query.setCacheable(true);
//         query.setCacheRegion("KitapDemoQueries");                
        return query.list();
    }

    public List fetchCarsForGarage(String garageId) {
        
        Session s = HibernateSession.openSession();        
        Query  query = s.createQuery("");
        
        return query.list();
    }

    /**
     * Describe <code>fetCar</code> method here.
     *
     * @param currPage a <code>String</code> value
     * @param nextPage a <code>String</code> value
     * @return a <code>Page</code> value
     */
    public Page fetchCar(String currPage, String nextPage) {
        Session s = HibernateSession.openSession();
        return new Page( 
                        s.createQuery("from Car"),
                        new Integer(currPage).intValue(),
                        new Integer(nextPage).intValue()
                        );
    }
    
    
}
