/*
 * HibernateSession.java
 *
 * Version:
 * $Id: HibernateSession.java,v 1.3 2005/03/03 14:42:47 burakba Exp $
 *
 * Revisions:
 * $Log: HibernateSession.java,v $
 * Revision 1.3  2005/03/03 14:42:47  burakba
 * ""
 *
 * Revision 1.2  2005/03/03 09:37:02  burakba
 * *** empty log message ***
 *
 * Revision 1.1  2005/03/02 13:49:32  burakba
 * *** empty log message ***
 *
 */

package org.bilgidata.kitapdemo.service;

import org.hibernate.*;
import org.hibernate.cfg.*;
import java.util.Properties;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class HibernateSession   {

	private static Logger logger = Logger.getLogger("appLogger");

    public static Properties props = null;
    
    private static SessionFactory sessionFactory = null;
    
    private static final ThreadLocal threadSession = new ThreadLocal();
    private static final ThreadLocal threadTransaction = new ThreadLocal();

    static {
        Configuration c = new Configuration().configure();
        props = c.getProperties();
        sessionFactory = c.buildSessionFactory();
    }

    /**
     * Describe <code>getProperties</code> method here.
     *
     * @return a <code>Properties</code> value
     */
    public static Properties getProperties() {
        return props;
    }
    
    public static Session openSession() { 
        // Open a new Session, if this thread has none yet
        Session s = (Session) threadSession.get();
        if (s == null) {
            s = sessionFactory.openSession();
            threadSession.set(s);
        }
        return s;
    }
    
    public static void closeSession() { 
        Session s = (Session) threadSession.get();
        threadSession.set(null);
        if (s != null && s.isOpen())
            s.close();
    }
    public static void beginTransaction() { 
        Transaction tx = (Transaction) threadTransaction.get();
        if (tx == null) {
            tx = openSession().beginTransaction();
            threadTransaction.set(tx);
        }
    }    

    public static void commitTransaction() { 
        Transaction tx = (Transaction) threadTransaction.get();
        if ( tx != null && !tx.wasCommitted()
             && !tx.wasRolledBack() )
            tx.commit();
        threadTransaction.set(null);
    }


    public static void rollbackTransaction() { 
        Transaction tx = (Transaction) threadTransaction.get();
        try {
            threadTransaction.set(null);
            if ( tx != null && !tx.wasCommitted()
                 && !tx.wasRolledBack() ) {    

                tx.rollback();
            }
        } finally {
            closeSession();
        }
    }

    /**
     * Describe <code>getSessionFactory</code> method here.
     *
     * @return a <code>SessionFactory</code> value
     */
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
                
}
