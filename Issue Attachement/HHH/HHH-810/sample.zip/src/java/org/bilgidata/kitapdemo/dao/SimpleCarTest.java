/*
 * SimpleCarTest.java
 *
 * Version:
 * $Id$
 *
 * Revisions:
 * $Log$
 */

package org.bilgidata.kitapdemo.dao;

import junit.framework.TestCase;

import java.sql.*;
import org.bilgidata.kitapdemo.util.*;
import org.bilgidata.kitapdemo.pojo.*;
import org.bilgidata.kitapdemo.service.*;
import org.hibernate.*;
import org.hibernate.cfg.*;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class SimpleCarTest  extends TestCase  { 
    
    public SimpleCarTest() { }

    public void testTraverse() throws Exception {
        Connection c = TestUtil.createTestConnection();
        
        TestUtil.createFromFile("tables_mysql.sql", c);        
        TestUtil.insertFromFile("sample_data.sql", c);
        
        
        try {
            Session s = HibernateSession.openSession();

            Car car = (Car) s.get(Car.class, "35 TTD 2202");
            assertEquals("porsche", car.getDescription());

        } finally {
            HibernateSession.closeSession();
        } 
    }
    
}
