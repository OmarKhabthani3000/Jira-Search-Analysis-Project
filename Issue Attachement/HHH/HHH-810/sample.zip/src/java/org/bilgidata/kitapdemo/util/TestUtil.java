package org.bilgidata.kitapdemo.util;

import java.sql.*;
import java.util.*;
import java.io.*;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.bilgidata.kitapdemo.service.HibernateSession;

public class TestUtil {

    private static Logger logger = Logger.getLogger("appLogger");

    /**
     * Describe <code>createTestConnection</code> method here.
     *
     * @return a <code>Connection</code> value
     * @exception Exception if an error occurs
     */
    public static Connection createTestConnection() throws Exception {
        Properties props = HibernateSession.getProperties();                
        Class.forName(props.getProperty(org.hibernate.cfg.Environment.DRIVER));
        return DriverManager.getConnection
            (props.getProperty(org.hibernate.cfg.Environment.URL),
             props.getProperty(org.hibernate.cfg.Environment.USER),
             props.getProperty(org.hibernate.cfg.Environment.PASS)); 
    }
    
    /**
     * Describe <code>getRowCount</code> method here.
     *
     * @param tableName a <code>String</code> value
     * @param c a <code>Connection</code> value
     * @return an <code>int</code> value
     * @exception Exception if an error occurs
     */
    public static int getRowCount(String tableName, Connection c) throws Exception{
        PreparedStatement ps = 
            c.prepareStatement("SELECT COUNT(*) from " + tableName);
        ResultSet rs = ps.executeQuery();
        int count = 0;
        rs.next();
        return rs.getInt(1);
    }

    /**
     * Describe <code>getRowCount</code> method here.
     *
     * @param tableName a <code>String</code> value
     * @param c a <code>Connection</code> value
     * @return an <code>int</code> value
     * @exception Exception if an error occurs
     */
    public static String getStringRowVal(String sql, Connection c) throws Exception{
        PreparedStatement ps = 
            c.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        rs.next();
        return rs.getString(1);
    }
    
    /**
     * Describe <code>runSql</code> method here.
     *
     * @param arg a <code>String</code> value
     * @param c a <code>Connection</code> value
     * @exception Exception if an error occurs
     */
    public static void runSql(String arg, Connection c) throws Exception{
        PreparedStatement ps = 
            c.prepareStatement(arg);
        ps.execute();
    }

    /**
     * Describe <code>insertFromFile</code> method here.
     *
     * @param file a <code>String</code> value
     * @param c a <code>Connection</code> value
     */
    public static void insertFromFile (String file, Connection c) {
        try {
            ClassPathFile f = new ClassPathFile (file);
            FileInputStream istr = new FileInputStream(f.openFile());
            InputStreamReader irdr = new InputStreamReader( istr ); // promote
            BufferedReader    brdr = new BufferedReader( irdr );    // promote
            String line = "";
            while ( (line = brdr.readLine()) != null ) {
                if (line.indexOf("delete from") < 0 &&
                    line.indexOf("DELETE FROM") < 0 ) {
                    try {
                        runSql(line, c);
                    } catch (Exception e) {
                        System.out.println(e);
                        logger.error("Exception in runSql!!!",e);
                    }
                }
            }
            
        } catch (Exception e) {
            System.out.println(e);
            logger.error("",e);
        }         
    }

    /**
     * Describe <code>createFromFile</code> method here.
     *
     * @param file a <code>String</code> value
     * @param c a <code>Connection</code> value
     */
    public static void createFromFile (String file, Connection c) {
        try {
            ClassPathFile f = new ClassPathFile (file);
            FileInputStream istr = new FileInputStream(f.openFile());
            InputStreamReader irdr = new InputStreamReader( istr ); // promote
            BufferedReader    brdr = new BufferedReader( irdr );    // promote
            StringBuffer total = new StringBuffer("");
            String line = "";
            while ( (line = brdr.readLine()) != null ) {
                if (line.indexOf(';') > -1) {
                    line = line.replace(';',' ');
                    total.append(line);
                    total.append("\n");
                    runSql(total.toString(), c);
                    System.out.println(total);
                    total = new StringBuffer("");
                } else {
                    total.append(line);
                    total.append("\n");                     
                } // end of else
                                
            }
                        
        } catch (Exception e) {
            System.out.println(e);
            logger.error("Exception in createFromFile!!!",e);
        }
    }





}
