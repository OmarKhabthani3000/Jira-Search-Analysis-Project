package org.bilgidata.kitapdemo.actions;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.bilgidata.kitapdemo.service.HibernateSession;
import org.bilgidata.kitapdemo.pojo.Car;
import org.bilgidata.kitapdemo.pojo.Garage;
import org.hibernate.Session;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.DynaActionForm;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.bilgidata.kitapdemo.util.StopWatch;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class DeleteCarAction extends Action
{
	private static Logger logger = Logger.getLogger("appLogger");

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
        throws Exception {
        
        StopWatch.start(StopWatch.DELETE_CAR_ACTION);
        
        DynaActionForm daf = (DynaActionForm) form;

        String selectedItems[] = (String[])daf.get("selectedItems");

        if (logger.isDebugEnabled()) logger.debug("selectedItems=" + selectedItems);
                
        Session s = HibernateSession.openSession();
        HibernateSession.beginTransaction();            
        for (int i=0;i<selectedItems.length;i++) {
            if (logger.isDebugEnabled()) logger.debug("selectedItems deleted:" + selectedItems[i]);
            Car car = (Car)s.get(Car.class, selectedItems[i]);
            if (car != null) {
                s.delete(car);                 
            } 
        }
                
        StopWatch.stop(StopWatch.DELETE_CAR_ACTION);
        
        return mapping.findForward("success");
    }
    
}
