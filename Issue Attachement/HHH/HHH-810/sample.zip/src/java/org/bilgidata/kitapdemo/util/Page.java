package org.bilgidata.kitapdemo.util;

import java.util.*;
import org.hibernate.*;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class Page   {
    
    private List results;
    private int pageSize;
    private int page;
   
    public Page(Query query, int page, int pageSize) {
       
        this.page = page;
        this.pageSize = pageSize;
//         query.setCacheable(true);
//         query.setCacheRegion("KitapDemoQueries");        
        results = query.setFirstResult(page * pageSize)
            .setMaxResults(pageSize+1)
            .list();
   
    }
   
    public boolean isNextPage() {
        return results.size() > pageSize;
    }
   
    public boolean isPreviousPage() {
        return page > 0;
    }
    
    public List getList() {
        return isNextPage() ?
            results.subList(0, pageSize-1) :
            results;
    }

    public Integer getNextPageCount() {
        return new Integer(page + 1);
    }
      
    public Integer getPreviousPageCount() {
        return new Integer(page - 1);
    }      
    
}
