/*
 * StopWatch.java
 *
 * Version:
 * $Id$
 *
 * Revisions:
 * $Log$
 */

package org.bilgidata.kitapdemo.util;
    
import java.util.Calendar;
import java.util.HashMap;
import java.util.TimeZone;
import org.apache.log4j.Logger;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class StopWatch   {

	private static Logger logger = Logger.getLogger("appLogger"); 

    private Calendar startCal;
    private Calendar endCal;
    private TimeZone tz = TimeZone.getTimeZone("CST");
    
    private static Thread stopWatchThread = null;
    
    // ... 
    public static final String GET_CARS_ACTION = "GET_CARS_ACTION";
    public static final String VIEW_CAR_ACTION = "VIEW_CAR_ACTION";
    public static final String GET_GARAGES_ACTION = "GET_GARAGES_ACTION";
    public static final String GET_CARS_FOR_GARAGE_ACTION = "GET_CARS_FOR_GARAGE_ACTION";
    public static final String ADD_CAR_ACTION = "ADD_CAR_ACTION";
    public static final String DELETE_CAR_ACTION = "DELETE_CAR_ACTION";
    public static final String LIST_CAR_PAGE_ACTION = "LIST_CAR_PAGE_ACTION";
    public static final String UPDATE_CAR_ACTION = "UPDATE_CAR_ACTION";
    
    public StopWatch() {  }
    
    /**
     * Internal thread which, once kicked off, is responsible
     * printing out the result at regular intervals. 
     *
     */
    public class ShowThread extends Thread {
        public ShowThread() { }
        public void run() {
            while (true) {
                try {
                    Thread.sleep(10000L);
                } catch (Exception e) {                
                } // end of try-catch
                StopWatch.showAll();
            } // end of while (true)     
        }
    }
    
    /**
     * Creates a new <code>StopWatch</code> instance.
     *
     * @param tzoneStr a <code>String</code> value
     */
    public StopWatch(String tzoneStr) {
        tz = TimeZone.getTimeZone(tzoneStr);
    }
    
    /**
     * Start the stopwatch
     *
     */
    public void start() {
        startCal = Calendar.getInstance(tz);
    }
    
    /**
     * Stop the stopwatch
     *
     */
    public void stop() {
        endCal = Calendar.getInstance(tz);
    }
    
    /**
     * Measure the elapsed time in different units
     *
     * @return a <code>double</code> value
     */
    public double elapsedSeconds() {
        return (endCal.getTimeInMillis() - startCal.getTimeInMillis())/1000.0;
    }
    
    /**
     * Describe <code>elapsedMillis</code> method here.
     *
     * @return a <code>long</code> value
     */
    public long elapsedMillis() {
        return endCal.getTimeInMillis() - startCal.getTimeInMillis();
    }
    
    /**
     * Describe <code>elapsedMinutes</code> method here.
     *
     * @return a <code>double</code> value
     */
    public double elapsedMinutes() {
        return (endCal.getTimeInMillis() - startCal.getTimeInMillis())/(1000.0 * 60.0);
    }

    // ---------------- STATIC SECTION -------------------------
    

    public void startThread() {
        stopWatchThread = new ShowThread();
        stopWatchThread.start();
    }

    /**
     * Describe variable <code>watch</code> here.
     *
     */
    private static HashMap watches = new HashMap();
    
    /**
     * Describe variable <code>values</code> here.
     *
     */
    private static HashMap values = new HashMap();
    
    /**
     * Describe variable <code>values</code> here.
     *
     */
    private static HashMap counts = new HashMap();
    
    /**
     * Describe <code>start</code> method here.
     *
     * @param key a <code>String</code> value
     */
    public static synchronized void start(String key) {
        StopWatch stopWatch = new StopWatch();
        if (!values.containsKey(key)) {
            values.put(key, new Double(0));
            counts.put(key, new Integer(0));
        } 
        
        watches.put(key, stopWatch);
        
        stopWatch.start();
    }
    
    /**
     * Describe <code>end</code> method here.
     *
     * @param key a <code>String</code> value
     */
    public static synchronized void stop(String key) {
        StopWatch stopWatch = (StopWatch)watches.get(key);
        stopWatch.stop();
        
        double old = ((Double)values.get(key)).doubleValue();
        int oldCount = ((Integer)counts.get(key)).intValue();
        
        values.put(key, new Double(old + stopWatch.elapsedSeconds()));
        counts.put(key, new Integer(oldCount + 1));
    }

    /**
     * Describe <code>showAll</code> method here.
     *
     */
    public static synchronized void showAll() {
        logger.debug(values);
        logger.debug(counts);
        System.out.println(values);
        System.out.println(counts);
    }
}
