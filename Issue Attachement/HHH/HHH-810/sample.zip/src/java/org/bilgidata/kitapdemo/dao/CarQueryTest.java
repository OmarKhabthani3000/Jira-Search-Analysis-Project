/*
 * SimpleCarTest.java
 *
 * Version:
 * $Id$
 *
 * Revisions:
 * $Log$
 */

package org.bilgidata.kitapdemo.dao;


import junit.framework.TestCase;

import java.sql.*;
import org.bilgidata.kitapdemo.util.*;
import org.bilgidata.kitapdemo.pojo.*;
import org.bilgidata.kitapdemo.service.*;
import org.hibernate.*;
import org.hibernate.cfg.*;

/**
 * << Class description goes here >>
 *
 * @author Burak Bayramli
 */
public class CarQueryTest  extends TestCase  { 
    
    public CarQueryTest() { }

    public void testList() throws Exception {
        Connection c = TestUtil.createTestConnection();
        
        TestUtil.createFromFile("tables_mysql.sql", c);        
        TestUtil.insertFromFile("sample_data.sql", c);

        try {
            Session s = HibernateSession.openSession();
            HibernateSession.beginTransaction();

            CarDAO dao = new CarDAO();
            assertEquals(new Integer(2), new Integer(dao.fetchCarList().size()));

            HibernateSession.commitTransaction();

        } finally {
            HibernateSession.closeSession();
        } 
    }
    
}
