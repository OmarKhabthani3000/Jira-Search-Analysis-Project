# bu script'in isletilme sebebi, windows uzerinde
# scp'ye c:/.. verince, : degerinin yanlis anlasilmasi. 

$_ = $ARGV[0];
s/c\:/\/cygdrive\/c/sg;
$to = $ARGV[1];
chomp($to);
print "Deploying <<$_>> to <<$to>>" . "\n";
system("scp -r $_ $to");
