echo "additional tasks"
remotejboss=$1\@$2\:$3
dizin=$3/server/default/deploy/kitapdemo.sar/kitapdemo.war
ssh $2 -l $1 cp $dizin/WEB-INF/classes/hibernate.mysql.remote.cfg.xml $dizin/WEB-INF/classes/hibernate.cfg.xml
