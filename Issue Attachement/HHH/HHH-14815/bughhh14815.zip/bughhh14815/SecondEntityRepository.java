package com.github.vlsergey.springdata.entitysecurity.bughhh14815;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SecondEntityRepository extends JpaRepository<SecondEntity, String> {

}
