package com.github.vlsergey.springdata.entitysecurity.bughhh14815;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FirstEntityRepository extends JpaRepository<FirstEntity, String> {

}
