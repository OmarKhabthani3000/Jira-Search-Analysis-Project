package org.hibernate.bugreport.jointable.constraintviolation;

import org.hibernate.bugreport.jointable.constraintviolation.entity.Component;
import org.hibernate.bugreport.jointable.constraintviolation.entity.Laptop;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JoinTableTests {

    @Test
    public void testSetup() {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JoinTableConstraintViolation");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();

        Laptop laptop = new Laptop();
        laptop.setBrand("Toshiba");
        laptop.setSeries("Protege");

        Component component = new Component();
        component.setName("RAM");

        laptop.addComponent(component);

        entityManager.persist(laptop);
        transaction.commit();
    }

}
