/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * License: GNU Lesser General Public License (LGPL), version 2.1 or later.
 * See the lgpl.txt file in the root directory or <http://www.gnu.org/licenses/lgpl-2.1.html>.
 */
package org.hibernate.envers.bugs;

import org.hibernate.Hibernate;
import org.hibernate.Transaction;
import org.junit.Test;

/**
 * Quick summary:
 * <p>                                                                                                                                                 
 * In TX 3, at commit time, 'b' is attached to the session, but 'a' is not.                                                                                       
 * Since a's collection of b-s is changed, Envers creates an instance of                                                                                          
 * org.hibernate.envers.internal.synchronization.work.CollectionChangeWorkUnit,                                                                                   
 * which upon trying to generate data for Envers auditing tries to 'visit' all properties of a.
 * <p>                                                                 
 * Due to the fix for https://hibernate.atlassian.net/browse/HHH-13760                                                                                            
 * this includes initializing all lazy-init proxies (only 'a.c', since 'a.bs' is fully initialized before),                                                       
 * using session which was originally used for loading 'a'.
 * <p>                                                                                                       
 * Obviously, by this time, that session is closed, and reference to it removed from lazy initializer instance in 'a.c'.                                          
 * It is, however, unclear why is the lazy-proxy initialization needed at all,                                                                                    
 * when a.c.id is present in lazy loader in any case (AbstractLazyInitializer.getIdentifier()).
 * <p>                                                                   
 * Also, org.hibernate.envers.internal.entities.mapper.relation.ToOneIdMapper.mapToMapFromEntity(SessionImplementor, Map<String, Object>, Object, Object)         
 * invokes delegate.mapToMapFromEntity( newData, entity );                                                                                                        
 * where 'delegate' is an instance of org.hibernate.envers.internal.entities.mapper.id.IdMapper,                                                                  
 * whose all implementations handle HibernateProxy-s explicitly                                                                                                   
 * (and without initializing the proxy, by using hibernateProxy.getHibernateLazyInitializer().getIdentifier()).                                                   
 */
public class EnversUnitTestCase extends AbstractEnversTestCase {

	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
				EntityA.class,
				EntityB.class,
				EntityC.class
		};
	}

    @Test
    public void testAbc() {
    	EntityA a;
    	EntityB b;
    	EntityC c;

        //
        // TX 1 - create A with C
        //
        
        Transaction tx1 = openAndBegin();

        a = new EntityA(1L, "a");
        c = new EntityC(1L, "c");
        a.c = c;
        session.save(a); // cascades to C

        commitAndClose(tx1);

        //
        // TX 2 - load A, initialize B-s collection, do NOT initialize C reference
        //
        
        Transaction tx2 = openAndBegin();

        a = session.get(EntityA.class, a.id);
        Hibernate.initialize(a.bs);

        commitAndClose(tx2);

        //
        // TX 3 - create B and add it to A (loaded in previous session)
        //
        
        Transaction tx3 = openAndBegin();

        b = new EntityB(1L, "b", a);
        a.bs.add(b);
        session.save(b);

        commitAndClose(tx3); // LazyInit here

    }

    private Transaction openAndBegin() {
        openSession();
        return session.beginTransaction();
    }

    private void commitAndClose(Transaction tx) {
        tx.commit();
        session.close();
    }
    
}
