package org.hibernate.envers.bugs;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "ENTITY_C")
@Audited
public class EntityC {

    @Id @Column(name = "ID") Long id;

    @Column(name = "STR", nullable = false) String str;

    public EntityC() {}

    public EntityC(Long id, String str) {
        this.id = id;
        this.str = str;
    }

    @Override
    public int hashCode() {
        return str != null ? str.hashCode() : 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof EntityC)) {
            return false;
        }
        final EntityC other = (EntityC)obj;
        return Objects.equals(this.str, other.str);
    }

}