package org.hibernate.envers.bugs;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.envers.Audited;

@Entity
@Table(name = "ENTITY_A")
@Audited
public class EntityA {

    @Id @Column(name = "ID") Long id;

    @Column(name = "STR", nullable = false) String str;

    @OneToMany(mappedBy = "a", fetch = FetchType.LAZY) @Fetch(FetchMode.SELECT) Set<EntityB> bs = new HashSet<>();

    @ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY) @JoinColumn(name = "C_ID") EntityC c;

    public EntityA() {}

    public EntityA(Long id, String str) {
        this.id = id;
        this.str = str;
    }

    @Override
    public int hashCode() {
        return str != null ? str.hashCode() : 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof EntityA)) {
            return false;
        }
        final EntityA other = (EntityA)obj;
        return Objects.equals(this.str, other.str);
    }

}