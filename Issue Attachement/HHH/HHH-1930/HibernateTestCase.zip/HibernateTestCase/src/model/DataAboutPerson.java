package model;

public class DataAboutPerson {

	private Integer id;
	private Person whoImAllAbout;
	private Integer referenceMe;
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public Person getWhoImAllAbout() {
		return whoImAllAbout;
	}

	public void setWhoImAllAbout(Person whoImAllAbout) {
		this.whoImAllAbout = whoImAllAbout;
	}

	public Integer getReferenceMe() {
		return referenceMe;
	}
	
	public void setReferenceMe(Integer referenceMe) {
		this.referenceMe = referenceMe;
	}
}
