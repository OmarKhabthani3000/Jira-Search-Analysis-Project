import model.Person;

import org.hibernate.Session;

import util.HibernateUtil;
import junit.framework.TestCase;


public class TestWhereClause extends TestCase {

	protected void setUp() throws Exception {
	}
	
	public void testTheWhereClause() {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();

        session.beginTransaction();

        session.createQuery("select person, count(data.referenceMe) from DataAboutPerson as data right join data.whoImAllAbout as person with (data.referenceMe like 'me%')");

        session.getTransaction().commit();
	}

}
