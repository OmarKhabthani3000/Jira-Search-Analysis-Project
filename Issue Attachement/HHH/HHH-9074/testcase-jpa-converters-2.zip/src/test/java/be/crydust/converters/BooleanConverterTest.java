package be.crydust.converters;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import static org.junit.Assert.*;
import org.junit.Test;

public class BooleanConverterTest {

    @Test(timeout = 10000)
    public void testBooleanConverter() {
        boolean success = false;
        EntityManagerFactory emf = null;
        try {
            emf = Persistence.createEntityManagerFactory("manager");
            EntityManager em = null;
            try {
                em = emf.createEntityManager();
                em.getTransaction().begin();

//                em.persist(new EntityWithBooleanField());
//                em.flush();
                em.createQuery("SELECT ewbf FROM EntityWithBooleanField ewbf WHERE ewbf.booleanValue = TRUE", EntityWithBooleanField.class).getResultList();
                em.getTransaction().commit();
                success = true;
            } finally {
                if (em != null) {
                    em.close();
                }
            }
        } finally {
            if (emf != null) {
                emf.close();
            }
        }
        assertTrue(success);
    }
}
