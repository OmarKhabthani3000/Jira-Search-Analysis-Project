package pl.avd.sample.jpa.converters;

import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class EntityWithBooleanField {

  @Id
  @GeneratedValue( strategy = GenerationType.AUTO)
  private long id;

  @Convert(converter = YesNoBooleanConverter.class)
  private String booleanValue;

  public long getId() {
    return id;
  }

  public String getBooleanValue() {
    return booleanValue;
  }

  public void setBooleanValue(String booleanValue) {
    this.booleanValue = booleanValue;
  }

}
