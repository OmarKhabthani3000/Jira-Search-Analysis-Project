package pl.avd.sample.jpa.converters;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.testng.annotations.Test;

public class BooleanConverterTest {
  
  private static EntityManagerFactory factory = Persistence.createEntityManagerFactory("manager");
  
  @Test
  public void testBooleanConverter() {
    EntityManager em = factory.createEntityManager();
    
    Session s = (Session) em.getDelegate();
    s.beginTransaction();
    
    s.createQuery( "select ewbf from EntityWithBooleanField ewbf where ewbf.booleanValue = true" );

    s.getTransaction().commit();
    s.close();
  }
}
