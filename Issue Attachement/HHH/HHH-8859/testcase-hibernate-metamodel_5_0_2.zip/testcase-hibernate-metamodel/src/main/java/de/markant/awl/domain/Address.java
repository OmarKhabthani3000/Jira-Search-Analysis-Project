package de.markant.awl.domain;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Address {

//	@Id
//	private long id;
	
	@ManyToOne
	private Person person;

	@OneToOne
	private Person person2;
	
	private String location;

//	public long getId() {
//		return id;
//	}
//
//	public void setId(long id) {
//		this.id = id;
//	}

	
	public String getLocation() {
		return location;
	}

	public Person getPerson() {
		return person;
	}

	public Person getPerson2() {
		return person2;
	}

	public void setPerson2(Person person2) {
		this.person2 = person2;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
}
