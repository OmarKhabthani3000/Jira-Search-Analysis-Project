
package hibernate.bug.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Document implements Serializable {
    
    private Integer id;
    private Map<Integer, Text> texts = new HashMap<Integer, Text>();

    @Id
    @GeneratedValue
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @ElementCollection
    public Map<Integer, Text> getTexts() {
        return texts;
    }

    public void setTexts(Map<Integer, Text> texts) {
        this.texts = texts;
    }

}
