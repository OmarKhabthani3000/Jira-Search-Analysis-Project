package hibernate.bug;

import hibernate.bug.model.Document;
import hibernate.bug.model.Text;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class IsEmptyTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Text t1 = new Text("t1");
        Text t2 = new Text("t2");
        Document d = new Document();
        
        d.getTexts().put(1, t1);
        d.getTexts().put(2, t2);
        
        em.persist(d);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testIsEmpty() {
        EntityManager em = emf.createEntityManager();
        
        List l = em.createQuery("SELECT d FROM Document d WHERE d.texts IS EMPTY").getResultList();
        Assert.assertEquals(0, l.size());
        
        em.close();
    }
    
    @Test
    public void testIsNotEmpty() {
        EntityManager em = emf.createEntityManager();
        
        List l = em.createQuery("SELECT d FROM Document d WHERE d.texts IS NOT EMPTY").getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
    
}
