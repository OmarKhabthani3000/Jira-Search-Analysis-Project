package org.hibernate.bugs;

import org.hibernate.bugs.model.Event;
import org.hibernate.bugs.model.EventType;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;
import java.util.List;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void selectCaseTest() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();

        CriteriaQuery<Event> criteria = cb.createQuery(Event.class);

        Root<Event> event = criteria.from(Event.class);
        Path<EventType> type = event.get("type");

        Expression<String> caseWhen = cb.<String>selectCase()
                .when(cb.equal(type, EventType.TYPE1), "Admin Event")
                .when(cb.equal(type, EventType.TYPE2), "User Event")
                .when(cb.equal(type, EventType.TYPE3), "Reporter Event")
                .otherwise("");

        criteria.select(event);
        criteria.where(cb.equal(caseWhen, "Admin Event")); // OK when use cb.like() method and others
        List<Event> resultList = entityManager.createQuery(criteria).getResultList();

        entityManager.getTransaction().commit();
        entityManager.close();

        Assert.assertNotNull(resultList);
    }

    @Test
    public void selectSimpleCaseTest() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();

        CriteriaQuery<Event> criteria = cb.createQuery(Event.class);

        Root<Event> event = criteria.from(Event.class);
        Path<EventType> type = event.get("type");

        Expression<String> caseWhen = cb.<EventType, String>selectCase(type)
                .when(EventType.TYPE1, "Admin Event")
                .when(EventType.TYPE2, "User Event")
                .when(EventType.TYPE3, "Reporter Event")
                .otherwise("");

        criteria.select(event);
        criteria.where(cb.equal(caseWhen, "Admin Event")); // OK when use cb.like() method and others
        List<Event> resultList = entityManager.createQuery(criteria).getResultList();

        entityManager.getTransaction().commit();
        entityManager.close();

        Assert.assertNotNull(resultList);
    }

}
