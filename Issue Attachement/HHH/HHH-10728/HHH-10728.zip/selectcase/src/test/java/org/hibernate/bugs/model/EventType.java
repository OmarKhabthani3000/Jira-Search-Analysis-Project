package org.hibernate.bugs.model;

public enum EventType {

    TYPE1, TYPE2, TYPE3

}
