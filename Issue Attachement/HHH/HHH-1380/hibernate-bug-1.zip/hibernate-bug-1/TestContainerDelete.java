import org.hibernate.Transaction;
import org.hibernate.SessionFactory;

import junit.framework.TestCase;

public class TestContainerDelete extends TestCase {
	static SessionFactory sessionFactory = null;
	
	protected void setUp() throws Exception {
		// Create and initialize an HSQLDB database we can use later
		// Create the session factory
	}

	protected void tearDown() throws Exception {
	}

	public void testDelete() throws Exception {
		// Use a 'skeleton' object
		TestContainer expected = new TestContainer();
		expected.setId(100);
//		HashSet items = new HashSet();
//		TestItem item = new TestItem();
//		item.setId(100);
//		item.setParent(expected);
//		items.add(item);
//		expected.setItems(items);
		
		Transaction tx = sessionFactory.getCurrentSession().beginTransaction();
		
		try {
			sessionFactory.getCurrentSession().delete(expected);
			// So we can see the SQL statements that hibernate generates
			tx.commit();

			// Try and retrieve the child objects - should fail
			tx = sessionFactory.getCurrentSession().beginTransaction();
			try {
				Object obj = sessionFactory.getCurrentSession().get(TestItem.class, new Integer(100));
				if (obj != null)
					fail("Find should have failed");
			} catch (Exception e) {				
			}
			
			tx.commit();
		} catch (RuntimeException re) {
			tx.rollback();
			
			throw re;
		}		
	}
}
