public class TestItem {
	private int id;
	private String value;
	private TestContainer parent;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public TestContainer getParent() {
		return parent;
	}
	public void setParent(TestContainer parent) {
		this.parent = parent;
	}
}
