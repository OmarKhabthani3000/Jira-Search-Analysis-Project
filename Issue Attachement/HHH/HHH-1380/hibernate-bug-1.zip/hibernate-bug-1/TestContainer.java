import java.util.Set;

public class TestContainer {
	private int id;
	private Set items;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Set getItems() {
		return items;
	}
	public void setItems(Set items) {
		this.items = items;
	}
}
