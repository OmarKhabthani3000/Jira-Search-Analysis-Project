package hibernate.bug;

import hibernate.bug.model.Document;
import hibernate.bug.model.Person;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CollectionTableMapKeyWithClauseTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p1 = new Person();
        Person p2 = new Person();
        Document d = new Document();
        
        d.getContacts().put(1, p1);
        d.getContacts().put(2, p2);
        
        em.persist(p1);
        em.persist(p2);
        em.persist(d);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        
        List l = em.createQuery("SELECT d.id FROM Document d LEFT JOIN d.contacts c WITH KEY(c) = 1").getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
}
