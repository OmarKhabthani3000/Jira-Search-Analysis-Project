package test.hhh9888;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

/**
 * @author Marina Vatkina
 */
@Entity
public class Customer {

	@Id
    private int id;
    private String name;
    
    @OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="CUSTOMER_ID", referencedColumnName="ID")
    private Collection<Order> orders = new ArrayList<Order>();

    public Customer() {
	}

	public Customer(int id, String name) {
		this.id = id;
		this.name = name;
	}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Collection<Order> getOrders() {
        return orders;
    }

    public void setOrders(Collection<Order> newValue) {
    	this.orders.clear();
    	if (newValue != null) {
    		this.orders.addAll(newValue);
    	}
    }
    
    public Customer addOrder(int id, String address) {
    	Order o = new Order();
    	o.setId(id);
    	o.setAddress(address);
    	this.orders.add(o);
    	return this;
    }

}
