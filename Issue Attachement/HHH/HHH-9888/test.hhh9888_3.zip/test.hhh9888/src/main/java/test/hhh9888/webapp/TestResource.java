package test.hhh9888.webapp;

import java.io.PrintWriter;
import java.io.StringWriter;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import test.hhh9888.Customer;
import test.hhh9888.CustomerFacade;

@Stateless
@Path("test")
public class TestResource {
	
	@EJB
	private CustomerFacade facade;
	
	@PostConstruct
	public void initialize() {
	}
	
	@Path("ok")
	@GET
	@Produces("text/plain")
	public Response testOk() {
		int nr = new Long(System.currentTimeMillis()).intValue() % 1000_000;
		return createCustomerWithId(nr);
	}

	private Response createCustomerWithId(int id) {
		Customer c = new Customer(id, "Test " + id);
		try {
			c = this.facade.saveWithJdbc(c);
			return Response.ok("test created id=" + c.getId()).status(Response.Status.OK).build();
			
		} catch(Exception exp) {
			StringWriter errors = new StringWriter();
			exp.printStackTrace(new PrintWriter(errors));

			return Response.ok("Failed: " + errors).status(Response.Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Path("fail")
	@GET
	@Produces("text/plain")
	public Response testFail() {
		return createCustomerWithId(100);
	}

}
