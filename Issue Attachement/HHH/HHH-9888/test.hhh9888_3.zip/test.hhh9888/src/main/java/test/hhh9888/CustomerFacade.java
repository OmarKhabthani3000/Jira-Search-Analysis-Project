package test.hhh9888;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.sql.DataSource;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class CustomerFacade {
	
	@Resource(name="jdbc/hhh9888DataSource")
	private DataSource dataSource;
	
	@Resource
	private SessionContext context;

	public Customer save(Customer customer) {
		return customer;
	}
	
	public Customer saveWithJdbc(Customer customer) {
		Connection con = null;
		PreparedStatement stm = null;
		try {
			con = this.dataSource.getConnection();
			stm = con.prepareStatement("insert into CUSTOMER (ID,NAME) values (?,?)");
			stm.setInt   (1, customer.getId());
			stm.setString(2, customer.getName());
			
			stm.executeUpdate();
			
		} catch (SQLException exp) {
			this.context.setRollbackOnly();
			throw new IllegalArgumentException("The update could not run", exp);

		} finally {
			try {
				if (con != null) { con.close(); }
				if (stm != null) { stm.close(); }
			} catch (SQLException closeExp) {
				throw new IllegalStateException("Failed to close resources", closeExp);
			}
		}
		return customer;
	}

}
