package test.hhh9888.webapp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringApplicationContext {
	
	private static SpringApplicationContext instance;

    private ApplicationContext applicationContext;

	private SpringApplicationContext() {
		this.applicationContext = new ClassPathXmlApplicationContext("/META-INF/spring/hhh9888-app-context.xml");
	}

	public static SpringApplicationContext getInstance() {
		if (instance == null) {
			instance = new SpringApplicationContext();
		}
		return instance;
	}

    public <T> T getBean(String beanName, Class<T> beanClass) {
        return applicationContext.getBean(beanName, beanClass);
    }
}