package test.hhh9888;

/**
 * Data access operations.
 *
 * @author  Adelino Rodrigues (created by)
 * @author  $Author: replacedWhenCheckedIn $ (last change by)
 * @version $Revision: 1.1 $ (cvs revision)
 * @since 21 Jul 2015 (creation date)
 * @revisionDate  $Date: 2003/12/19 10:51:34 18 Nov 2014 $
 */
public interface CustomerDAO {

	Customer save(Customer customer);
}
