package test.hhh9888.webapp;

import java.io.PrintWriter;
import java.io.StringWriter;

import javax.annotation.PostConstruct;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import test.hhh9888.Customer;
import test.hhh9888.CustomerDAO;

@Path("ok")
public class TestResource {
	
	private CustomerDAO customerDAO = null;
	
	@PostConstruct
	public void initialize() {
		this.customerDAO = SpringApplicationContext.getInstance().getBean("customerDAO", CustomerDAO.class);
	}
	
	@GET
	@Produces("text/plain")
	public Response testOk() {
		int nr = new Long(System.currentTimeMillis()).intValue() % 1000_000;
		Customer c = new Customer(100, "Joe Smith" + nr)
				.addOrder(nr + 100, "7 Westferry circus, London, UK")
				.addOrder(nr + 200, "25 Churchill place, London, UK");

		try {
			customerDAO.save(c);
			return Response.ok("test created id=" + c.getId()).status(Response.Status.OK).build();
			
		} catch(Exception exp) {
			StringWriter errors = new StringWriter();
			exp.printStackTrace(new PrintWriter(errors));

			return Response.ok("Failed: " + errors).status(Response.Status.INTERNAL_SERVER_ERROR).build();
		}
		
	}

}
