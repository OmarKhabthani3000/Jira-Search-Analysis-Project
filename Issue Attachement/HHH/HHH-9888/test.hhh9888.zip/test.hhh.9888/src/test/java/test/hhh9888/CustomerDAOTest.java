package test.hhh9888;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@ContextConfiguration(locations = {
        "/META-INF/spring/hhh9888-context.xml",
		"/META-INF/spring/test-hhh9888-context.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class CustomerDAOTest {
	
	@Autowired
	private CustomerDAO customerDAO;
	
	@Test
	@Transactional
	@Rollback(false)
	public void testSave() {
		int nr = new Long(System.currentTimeMillis()).intValue() % 1000_000;
		nr = (nr < 0) ? - nr : nr;
		Customer c = new Customer(nr, "Joe Smith" + nr)
				.addOrder(nr + 100, "7 Westferry circus, London, UK")
				.addOrder(nr + 200, "25 Churchill place, London, UK");
		assertEquals(2, c.getOrders().size());
		customerDAO.save(c);
	}

}
