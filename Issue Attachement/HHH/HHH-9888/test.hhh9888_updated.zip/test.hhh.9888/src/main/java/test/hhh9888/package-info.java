/**
 * This example is taken from
 * {@link https://glassfish.java.net/javaee5/persistence/persistence-example.html}.
 *
 * @author  Adelino Rodrigues (created by)
 * @author  $Author: replacedWhenCheckedIn $ (last change by)
 * @version $Revision: 1.1 $ (cvs revision)
 * @since 20 Jul 2015 (creation date)
 * @revisionDate  $Date: 2003/12/19 10:51:34 18 Nov 2014 $
 */
package test.hhh9888;