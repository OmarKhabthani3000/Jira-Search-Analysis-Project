package test.hhh9888;

import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.persistence.SharedCacheMode;
import javax.persistence.ValidationMode;
import javax.persistence.spi.ClassTransformer;
import javax.persistence.spi.PersistenceUnitInfo;
import javax.persistence.spi.PersistenceUnitTransactionType;
import javax.sql.DataSource;

class JpaConfig {
	
	static class PersistenceUnitConfig implements PersistenceUnitInfo {
		
		private String persistenceUnitName;
		private String persistenceProviderClassName;
		private PersistenceUnitTransactionType transactionType;
		private DataSource jtaDataSource;
		private DataSource nonJtaDataSource;
		private List<String> mappingFileNames;
		private List<URL> jarFileUrls;
		private URL persistenceUnitRootUrl;
		private List<String> managedClassNames;
		private boolean excludeUnlistedClasses;
		private SharedCacheMode sharedCacheMode;
		private ValidationMode validationMode;
		private Properties properties;
		private String persistenceXMLSchemaVersion;
		private ClassLoader classLoader;
		private ClassLoader newTempClassLoader;

		@Override
		public void addTransformer(ClassTransformer transformer) {
			throw new UnsupportedOperationException();
		}

		public String getPersistenceProviderClassName() {
			return persistenceProviderClassName;
		}

		public void setPersistenceProviderClassName(String persistenceProviderClassName) {
			this.persistenceProviderClassName = persistenceProviderClassName;
		}

		public PersistenceUnitTransactionType getTransactionType() {
			return transactionType;
		}

		public void setTransactionType(PersistenceUnitTransactionType transactionType) {
			this.transactionType = transactionType;
		}

		public DataSource getJtaDataSource() {
			return jtaDataSource;
		}

		public void setJtaDataSource(DataSource jtaDataSource) {
			this.jtaDataSource = jtaDataSource;
		}

		public DataSource getNonJtaDataSource() {
			return nonJtaDataSource;
		}

		public void setNonJtaDataSource(DataSource nonJtaDataSource) {
			this.nonJtaDataSource = nonJtaDataSource;
		}

		public List<String> getMappingFileNames() {
			return mappingFileNames;
		}

		public void setMappingFileNames(List<String> mappingFileNames) {
			this.mappingFileNames = mappingFileNames;
		}

		public List<URL> getJarFileUrls() {
			return jarFileUrls;
		}

		public void setJarFileUrls(List<URL> jarFileUrls) {
			this.jarFileUrls = jarFileUrls;
		}

		public URL getPersistenceUnitRootUrl() {
			return persistenceUnitRootUrl;
		}

		public void setPersistenceUnitRootUrl(URL persistenceUnitRootUrl) {
			this.persistenceUnitRootUrl = persistenceUnitRootUrl;
		}

		public List<String> getManagedClassNames() {
			return managedClassNames;
		}

		public void setManagedClassNames(List<String> managedClassNames) {
			this.managedClassNames = managedClassNames;
		}

		public SharedCacheMode getSharedCacheMode() {
			return sharedCacheMode;
		}

		public void setSharedCacheMode(SharedCacheMode sharedCacheMode) {
			this.sharedCacheMode = sharedCacheMode;
		}

		public ValidationMode getValidationMode() {
			return validationMode;
		}

		public void setValidationMode(ValidationMode validationMode) {
			this.validationMode = validationMode;
		}

		public Properties getProperties() {
			return properties;
		}

		public void setProperties(Properties properties) {
			this.properties = properties;
		}

		public String getPersistenceXMLSchemaVersion() {
			return persistenceXMLSchemaVersion;
		}

		public void setPersistenceXMLSchemaVersion(String persistenceXMLSchemaVersion) {
			this.persistenceXMLSchemaVersion = persistenceXMLSchemaVersion;
		}

		public ClassLoader getClassLoader() {
			return classLoader;
		}

		public void setClassLoader(ClassLoader classLoader) {
			this.classLoader = classLoader;
		}

		public ClassLoader getNewTempClassLoader() {
			return newTempClassLoader;
		}

		public void setNewTempClassLoader(ClassLoader newTempClassLoader) {
			this.newTempClassLoader = newTempClassLoader;
		}

		public String getPersistenceUnitName() {
			return this.persistenceUnitName;
		}

		public void setPersistenceUnitName(String persistenceUnitName) {
			this.persistenceUnitName = persistenceUnitName;
		}

		@Override
		public boolean excludeUnlistedClasses() {
			return this.excludeUnlistedClasses;
		}
	}

	static PersistenceUnitInfo getAppPersistenceUnitInfo(DataSource dataSource) {
		PersistenceUnitConfig result = new PersistenceUnitConfig();
		result.setPersistenceUnitName("pu1");
		result.setPersistenceXMLSchemaVersion("1.0");
		result.setJtaDataSource(dataSource);
		result.setManagedClassNames(Arrays.asList("test.hhh9888.Customer", "test.hhh9888.Order"));
		result.setTransactionType(PersistenceUnitTransactionType.JTA);

		return result;
	}
	
	static Map<String, String> getProviderProperties() {
		Map<String, String> result = new HashMap<>();
		result.put("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
		result.put("hibernate.transaction.jta.platform",
				"org.hibernate.service.jta.platform.internal.WeblogicJtaPlatform");
		return result;
	}
}
