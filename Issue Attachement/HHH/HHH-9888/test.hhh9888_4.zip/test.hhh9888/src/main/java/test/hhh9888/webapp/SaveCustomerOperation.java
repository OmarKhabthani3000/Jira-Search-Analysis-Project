package test.hhh9888.webapp;

import test.hhh9888.Customer;

public interface SaveCustomerOperation {

	Customer save(Customer customer);

}
