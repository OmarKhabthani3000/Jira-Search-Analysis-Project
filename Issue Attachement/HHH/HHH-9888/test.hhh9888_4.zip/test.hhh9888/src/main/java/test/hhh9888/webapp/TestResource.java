package test.hhh9888.webapp;

import java.io.PrintWriter;
import java.io.StringWriter;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import test.hhh9888.Customer;
import test.hhh9888.CustomerFacade;

@Stateless
@Path("test")
public class TestResource {
	
	@EJB
	private CustomerFacade facade;
	
	private SaveCustomerOperation saveWithJdbcOperation;
	private SaveCustomerOperation saveWithJpaOperation;
	
	@PostConstruct
	public void initialize() {
		this.saveWithJdbcOperation = new SaveCustomerOperation() {
			@Override
			public Customer save(Customer customer) {
				return facade.saveWithJdbc(customer);
			}
		};

		this.saveWithJpaOperation = new SaveCustomerOperation() {
			@Override
			public Customer save(Customer customer) {
				return facade.save(customer);
			}
		};
	}
	
	@Path("ok")
	@GET
	@Produces("text/plain")
	public Response testOk() {
		int nr = new Long(System.currentTimeMillis()).intValue() % 1000_000;
		return createCustomerWithId(nr, this.saveWithJdbcOperation);
	}

	@Path("fail")
	@GET
	@Produces("text/plain")
	public Response testFail() {
		return createCustomerWithId(100, this.saveWithJdbcOperation);
	}

	@Path("jpaOk")
	@GET
	@Produces("text/plain")
	public Response testJpaOk() {
		int nr = new Long(System.currentTimeMillis()).intValue() % 1000_000;
		return createCustomerWithId(nr, this.saveWithJpaOperation);
	}

	@Path("jpaFail")
	@GET
	@Produces("text/plain")
	public Response testJpaFail() {
		return createCustomerWithId(100, this.saveWithJpaOperation);
	}

	private Response createCustomerWithId(int id, SaveCustomerOperation op) {
		Customer c = new Customer(id, "Test " + id);
		try {
			op.save(c);
			return Response.ok("test created id=" + c.getId()).status(Response.Status.OK).build();
			
		} catch(Exception exp) {
			StringWriter errors = new StringWriter();
			exp.printStackTrace(new PrintWriter(errors));

			return Response.ok("Failed: " + errors).status(Response.Status.INTERNAL_SERVER_ERROR).build();
		}
	}

}
