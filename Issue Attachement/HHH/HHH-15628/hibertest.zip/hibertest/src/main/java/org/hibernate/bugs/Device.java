package org.hibernate.bugs;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import org.hibernate.annotations.Cascade;

import java.util.Set;

@Entity
@Table(name = "DEVICE_T")
public class Device {
    @Id
    private Long pk;

    @Column(nullable = false)
    private String name;

    @OneToOne(targetEntity = DevClientId.class, mappedBy = "device", cascade = {
            CascadeType.ALL }, fetch = FetchType.LAZY)
    @Cascade(org.hibernate.annotations.CascadeType.ALL)
    private DevClientId devClientId;

    @OneToOne(targetEntity = DevServerId.class, mappedBy = "device", cascade = {
            CascadeType.ALL }, fetch = FetchType.LAZY)
    @Cascade(org.hibernate.annotations.CascadeType.ALL)
    private DevServerId devServerId;

    @OneToMany(targetEntity = DevPart.class, mappedBy = "device", fetch = FetchType.EAGER)
    private Set<DevPart> devParts;

    public Device(String name) {
        this.name = name;
    }

    /** default constructor */
    public Device() {
        super();
    }

    public Long getPk() {
        return pk;
    }

    public void setPk(Long pk) {
        this.pk = pk;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public DevClientId getDevClientId() {
        return devClientId;
    }

    public void setDevClientId(DevClientId devClientId) {
        this.devClientId = devClientId;
    }

    public DevServerId getDevServerId() {
        return devServerId;
    }

    public void setDevServerId(DevServerId devServerId) {
        this.devServerId = devServerId;
    }

    public Set<DevPart> getDevParts() {
        return devParts;
    }

    public void setDevParts(Set<DevPart> devParts) {
        this.devParts = devParts;
    }

}
