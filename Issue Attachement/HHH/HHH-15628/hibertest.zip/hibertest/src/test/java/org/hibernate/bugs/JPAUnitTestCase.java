package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private static final Logger logger = LogManager.getLogger(JPAUnitTestCase.class);

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		logger.info("----------------------------- In destroy -----------------------");
		entityManagerFactory.close();
	}

	@Test
	public void testOneToOneTwoWayMapping() {
		logger.debug("--- IN testOneToOneTwoWayMapping");
		final String DEVICE_NAME = "device1";
		final String DEVICE_CLIENT_ID = "device1ClientId";
		final String DEVICE_SERVER_ID = "device1ServerId";

		EntityManager entityManager = null;
		try {

			// Setup:

			entityManager = entityManagerFactory.createEntityManager();
			entityManager.getTransaction().begin();
			//Session session = (Session)entityManager;
			var device1 = new Device(DEVICE_NAME);
			device1.setPk(1000L);
			entityManager.persist(device1);

			var device1ClientId = new DevClientId(DEVICE_CLIENT_ID);
			device1ClientId.setPk(1101L);
			device1ClientId.setDevice(device1);
			entityManager.persist(device1ClientId);

			var device1ServerId = new DevServerId(DEVICE_SERVER_ID);
			device1ServerId.setPk(1201L);
			device1ServerId.setDevice(device1);
			entityManager.persist(device1ServerId);

			entityManager.flush();

			logger.info("-------------------------- before executing query -----------------------------");
			TypedQuery<Device> query = entityManager.createQuery("select e from org.hibernate.bugs.Device as e", Device.class);

			List<Device> results = query.getResultList();
			logger.info("-------------------------- after executing query -----------------------------");
			assertEquals(1, results.size());
			var first = results.get(0);
			assertEquals(DEVICE_NAME, first.getName());

			// This fails when hibernate.max_fetch_depth" is set to 1, but also if
			assertNotNull(first.getDevClientId());
			assertNotNull(first.getDevServerId());


			entityManager.getTransaction().commit();

		} catch(Exception ex) {
			entityManager.getTransaction().setRollbackOnly();

		} finally {
			if (entityManager != null) entityManager.close();
		}
	}

}
