package org.hibernate.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "person",
		uniqueConstraints = {
			@UniqueConstraint(columnNames = {"id"})}
)
public class Person implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name = "id", unique = true, nullable = false)
	protected Long id;

	@Column(name = "name")
	protected String name;

	@Column(name = "dob")
	protected Date dob;

	public Person() {}
	public Person(String name, Date dob) {
		this.name = name;
		this.dob = dob;
	}

	//<editor-fold defaultstate="collapsed" desc="get/set">
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}
	//</editor-fold>
}
