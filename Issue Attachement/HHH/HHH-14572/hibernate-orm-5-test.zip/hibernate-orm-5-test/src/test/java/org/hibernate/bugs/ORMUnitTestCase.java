
package org.hibernate.bugs;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.entities.*;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;
import org.junit.Assert;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 *
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
			Person.class,
			PersonDTOQueries.class
		};
	}

	// If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
	@Override
	protected String[] getMappings() {
		return new String[] {
//				"Foo.hbm.xml",
//				"Bar.hbm.xml"
		};
	}
	// If those mappings reside somewhere other than resources/org/hibernate/test, change this.
	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/test/";
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );

		configuration.setProperty( AvailableSettings.SHOW_SQL, Boolean.TRUE.toString() );
		configuration.setProperty( AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString() );
		//configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, "true" );
	}

	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		// BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		
			Person p = new Person("john doe", parseDate("2000-01-01"));
//			System.out.println(p);
			s.saveOrUpdate(p);
			
			p = new Person("jane doe", parseDate("2005-01-01"));
//			System.out.println(p);
			s.saveOrUpdate(p);
		
			p = new Person("Odd Mike", parseDate("2010-01-01"));
//			System.out.println(p);
			s.saveOrUpdate(p);
			
			p = new Person("Even Mike", parseDate("2015-01-01"));
//			System.out.println(p);
			s.saveOrUpdate(p);
			
			p = new Person("Alan Brown", parseDate("2020-01-01"));
//			System.out.println(p);
			s.saveOrUpdate(p);
			
		tx.commit();
		
		Query query = s.createNamedQuery("PersonDOBAllDTO", PersonDTO.class);
		List<PersonDTO> personDTOList = query.getResultList();
		
		Assert.assertTrue(personDTOList.size() == 5);
		
		Date dateFrom = parseDate("2013-01-01");
		Date dateTo = parseDate("2030-01-01");
		
		query = s.createNamedQuery("PersonDOBRangeCountDTO", PersonDTO.class)
			.setParameter("dobFrom", dateFrom)
			.setParameter("dobTo", dateTo);
		
		personDTOList = query.getResultList();
		
		Assert.assertTrue(personDTOList.size() == 2);

//		System.out.println("**********************************************");
//		System.out.println("dateFrom: " + dateFrom);
//		System.out.println("dateTo: " + dateTo);
//		System.out.println("personDTOList.size(): " + personDTOList.size());
//		for(PersonDTO persDTO: personDTOList) {
//			System.out.println(persDTO.toString());
//		}
	
		s.close();
	}
	
	public static Date parseDate(String date) {
		try {
			return new SimpleDateFormat("yyyy-MM-dd").parse(date);
		}
		catch(ParseException e) {
			return null;
		}
	}
}
