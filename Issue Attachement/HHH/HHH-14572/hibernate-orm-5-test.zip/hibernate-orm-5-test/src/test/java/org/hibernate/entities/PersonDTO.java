
package org.hibernate.entities;

import java.util.Date;

/** CalendarOrderCountDTO		*/
public class PersonDTO {
	
	private String name;
	private Date dob;

	public PersonDTO(String name, Date dob) {
		this.name = name;
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "PersonDTO {\n" +
			"name: " + name + "\n" +
			"dob: " + dob +
		"\n}";
	}

	//<editor-fold defaultstate="collapsed" desc="mutator/accessor methods">
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}
	//</editor-fold>
}
