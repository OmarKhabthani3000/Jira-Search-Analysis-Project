
package org.hibernate.entities;

import java.util.Date;
import javax.persistence.*;

@MappedSuperclass
@NamedNativeQueries({
	@NamedNativeQuery(
		name = "PersonDOBAllDTO",			
		query =	"SELECT * " +
				"FROM person p",
		resultSetMapping = "PersonCountDTOResult"

		/* Params:
				Date dateFrom
				Date dateTo
				ProductionStatus.getId() statusFrom
				ProductionStatus.getId() statusTo
		 */
	),
	@NamedNativeQuery(
		name = "PersonDOBRangeCountDTO",			
		query =	"SELECT p.name, p.dob " +
				"FROM person p " +
				"WHERE p.dob BETWEEN :dobFrom AND :dobTo",
		resultSetMapping = "PersonCountDTOResult"

		/* Params:
				Date dateFrom
				Date dateTo
				ProductionStatus.getId() statusFrom
				ProductionStatus.getId() statusTo
		 */
	),
})
@SqlResultSetMappings({
	@SqlResultSetMapping(
		name = "PersonCountDTOResult",
		classes = @ConstructorResult(				
			targetClass = PersonDTO.class,
			columns = {
				// converter mapping will be available in Hibernate 6
				// source: see Hibernate Issue No HHH-13082
				@ColumnResult(name = "name",		type = String.class),
				@ColumnResult(name = "dob",			type = Date.class),
			}
		)
	),
})
public abstract class PersonDTOQueries {}