package org.hibernate.bugs;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.hibernate.MappingException;
import org.junit.After;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.PersistenceException;

/**
 * This testclass show that the wrong sequencename is used to get out of the database when a {@link org.hibernate.boot.model.naming.PhysicalNamingStrategy} is used to rename a art of the sequence
 */
public class JPAUnitTestCase {

	/**
	 * A Sequence with REPLACE_SEQ is created in the database with an incrementBy of 1. This is different from the allocationSize so an {@link MappingException} is thrown.
	 * But there is a {@link org.hibernate.boot.model.naming.PhysicalNamingStrategy} that replaces REPLACE_SEQ with MY_SEQ. MY_SEQ should be used instead of REPLACE_SEQ
	 * @throws Exception
	 */
	@DisplayName("This test shows that the wrong name of the sequence is used to get the sequence out of the database")
	@Test
	public void wrongSequencenameUsed() throws Exception {
		try (Connection conn = DriverManager.getConnection("jdbc:h2:mem:db1", "sa", "")) {
			// Create a sequence with an increment by of 1 which differs from the allocationSize of 50
			// REPLACE_SEQ is the name before the physical naming strategy is configured
			conn.createStatement().execute("create sequence REPLACE_SEQ start with 1 increment by 1;");
			conn.createStatement().execute("create table MY_ENTITY(id bigint not null, primary key (id));");

			// When hibernate configures it should throw an MappingException because allocationSize and incrementBy are different
			PersistenceException pe = assertThrows(PersistenceException.class, () -> {
				EntityManagerFactory factory = Persistence.createEntityManagerFactory("templatePU");
				factory.close();
			});

			assertThat(pe.getCause().getCause().getLocalizedMessage()).contains("The increment size of the [REPLACE_SEQ] sequence is set to [50] in the entity mapping while the associated database sequence increment size is [1].");
		}
	}

	/**
	 * This test should fail because MY_SEQ has a different incrementBy in the database then allocationSize in the {@link jakarta.persistence.SequenceGenerator}.
	 * This test doesn't fail because the wrong name REPLACE_SEQ is used.
	 * @throws Exception
	 */
	@DisplayName("Throw an MappingException when allocationSize in SequenceGenerator differs from incrementBy in the database when using PhysicalNamingStrategy")
	@Test
	public void shouldFailWhenCorrectNameIsUed() throws Exception {
		try (Connection conn = DriverManager.getConnection("jdbc:h2:mem:db1", "sa", "")) {
			// Create a sequence with an increment by of 1 which differs from the allocationSize of 50
			// MY_SEQ is the physicalname that is configured in MyPhysicalNamingStrategy
			conn.createStatement().execute("create sequence MY_SEQ start with 1 increment by 1;");
			conn.createStatement().execute("create table MY_ENTITY(id bigint not null, primary key (id));");

			// When hibernate configures it should throw an MappingException because allocationSize and incrementBy are different
			assertThrows(MappingException.class, () -> {
				EntityManagerFactory factory = Persistence.createEntityManagerFactory("templatePU");
				factory.close();
			});
		}
	}
}
