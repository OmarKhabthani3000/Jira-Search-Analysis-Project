package org.hibernate.bugs;

import demo.example.Employee;
import demo.example.Employee_;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory emf;

    @Before
    public void init() {
        emf = Persistence.createEntityManagerFactory("example-unit");
        persistEntity();
    }

    @After
    public void destroy() {
        emf.close();
    }

    @Test
    public void testJPQLListJoinIndexTest() {
        EntityManager em = emf.createEntityManager();
        TypedQuery<Object[]> query = em.createQuery("Select e.name, INDEX(p), p from Employee e JOIN e.phoneNumbers p",
                Object[].class);
        List<Object[]> resultList = query.getResultList();
        Assert.assertTrue(resultList.size() == 3);
        Assert.assertEquals(resultList.get(0)[1], 0);
        Assert.assertEquals(resultList.get(1)[1], 1);
        Assert.assertEquals(resultList.get(2)[1], 2);

        resultList.forEach(o-> System.out.println(Arrays.toString(o)));
        em.close();
    }


    @Test
    public void testCriteriaMapJoinEntryTest() {
        EntityManager entityManager = emf.createEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Object[]> query = criteriaBuilder.createQuery(Object[].class);
        Root<Employee> employeeRoot = query.from(Employee.class);
        ListJoin<Employee, String> phoneNumbersJoin = employeeRoot.joinList(Employee_.PHONE_NUMBERS);
        query.multiselect(employeeRoot.get(Employee_.NAME), phoneNumbersJoin.index(), phoneNumbersJoin);
        List<Object[]> resultList = entityManager.createQuery(query).getResultList();
        Assert.assertTrue(resultList.size() == 3);
        Assert.assertEquals(resultList.get(0)[1], 0);
        Assert.assertEquals(resultList.get(1)[1], 1);
        Assert.assertEquals(resultList.get(2)[1], 2);
        resultList.forEach(o -> System.out.println(Arrays.toString(o)));
        entityManager.close();

    }


    private void persistEntity() {
        EntityManager em = emf.createEntityManager();
        Employee employee = Employee.create("Diana", 2000, "IT",
                "111-111-111", "666-666-666", "777-777-777");
        em.getTransaction().begin();
        em.persist(employee);
        em.getTransaction().commit();
        em.close();
    }
}