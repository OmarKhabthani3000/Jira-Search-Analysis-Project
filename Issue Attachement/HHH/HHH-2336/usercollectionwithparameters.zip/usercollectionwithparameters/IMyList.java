package org.hibernate.test.usercollectionwithparameters;

import java.util.List;

public interface IMyList extends List {
    String getDefaultValue();
}
