


import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class TestBean {

	private String id;
	private Date date1;
	
	@Id
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public Date getDate1() {
		return date1;
	}
	public void setDate1(Date date) {
		this.date1 = date;
	}
	
	
}
