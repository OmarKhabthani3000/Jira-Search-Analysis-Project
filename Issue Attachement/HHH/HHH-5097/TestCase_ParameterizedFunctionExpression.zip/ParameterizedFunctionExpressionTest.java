

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.Assert;
import org.junit.Test;

public class ParameterizedFunctionExpressionTest {

	@Test
	public void testParameterizedFunctionExpression() throws Exception {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("userDatabase");
		EntityManager em = factory.createEntityManager();
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<String> createQuery = cb.createQuery(String.class);
		Root<TestBean> from = createQuery.from(TestBean.class);

		createQuery.select(
				cb.function("TO_CHAR", String.class, from.get("date1"),
						cb.literal("DD.MM.YYYY"))).distinct(true).where(
				from.get("id").in(
						Arrays.asList(new String[] { "1", "2" }).toArray()));
		List<String> resultList = em.createQuery(createQuery).getResultList();
		Assert.assertTrue(true);
	}
}
