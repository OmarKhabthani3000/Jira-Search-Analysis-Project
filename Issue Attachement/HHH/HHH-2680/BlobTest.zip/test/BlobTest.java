package test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;


public class BlobTest extends TestCase {
   
    public void testCreateUserAndProperty() throws SerialException, FileNotFoundException, SQLException, IOException {

       AnnotationConfiguration configuration = new AnnotationConfiguration();
       configuration.configure(this.getClass().getResource("/hibernate.cfg.xml"));
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        Domain domain = new Domain();
        session.save(domain);
        Integer id = domain.getId();
        assertNotNull(id);
        transaction.commit();
        session.close();

        ////////////////////////////////////////////
        session = sessionFactory.openSession();
        transaction = session.beginTransaction();
         
        domain = (Domain) session.load(Domain.class, id);
        assertNotNull(domain);
        assertNull(domain.getBlob());
        assertNull(domain.getName());
        Blob image = new SerialBlob(new byte[] {42});
        domain.setBlob(image);
        domain.setName("42");
        session.merge(domain);
         
        transaction.commit();
        session.close();        

        ////////////////////////////////////////////
        session = sessionFactory.openSession();
        transaction = session.beginTransaction();
         
        domain = (Domain) session.load(Domain.class, id);
        assertNotNull(domain);
        assertNotNull(domain.getBlob());
        assertEquals(42, domain.getBlob().getBytes(1, 1)[0]);
        assertEquals("42", domain.getName());
        image = new SerialBlob(new byte[] {43});
        domain.setBlob(image);
        domain.setName("43");
        session.merge(domain);
        transaction.commit();
        session.close();        

        ////////////////////////////////////////////
        session = sessionFactory.openSession();
        transaction = session.beginTransaction();
         
        domain = (Domain) session.load(Domain.class, id);
        assertNotNull(domain);
        assertNotNull(domain.getBlob());
        assertEquals("43", domain.getName());
        assertEquals(43, domain.getBlob().getBytes(1, 1)[0]);

        transaction.commit();
        session.close();        

        ////////////////////////////////////////////
        session = sessionFactory.openSession();
        transaction = session.beginTransaction();
         
        domain = (Domain) session.load(Domain.class, id);
        assertNotNull(domain);
        assertNotNull(domain.getBlob());
        assertEquals(43, domain.getBlob().getBytes(1, 1)[0]);
        assertEquals("43", domain.getName());
        session.evict(domain);
        image = new SerialBlob(new byte[] {44});
        domain.setBlob(image);
        domain.setName("44");
        session.merge(domain);
        transaction.commit();
        session.close();        

        ////////////////////////////////////////////
        session = sessionFactory.openSession();
        transaction = session.beginTransaction();
         
        domain = (Domain) session.load(Domain.class, id);
        assertNotNull(domain);
        assertNotNull(domain.getBlob());
        assertEquals("44", domain.getName());
        assertEquals(44, domain.getBlob().getBytes(1, 1)[0]);

        transaction.commit();
        session.close();        
    }
        
    
}
