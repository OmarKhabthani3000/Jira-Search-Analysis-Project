package foo;

import java.util.*;

public class Order {

  private int orderId;

  public int getOrderId() {
    return orderId;
  }

  private Set<OrderLine> orderLines = new HashSet<OrderLine>();

  public Set<OrderLine> getLines() {
    return Collections.unmodifiableSet(orderLines);
  }

  public void addLine(OrderLine orderLine){
    orderLine.setOrder(this);
    this.orderLines.add(orderLine);
  }
  
  public String toString() {
    return "" + getOrderId() + " - " + getLines();
  }
}