package foo;

import org.hibernate.test.TestCase;
import org.hibernate.Session;
import org.hibernate.Criteria;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Expression;
import org.hibernate.sql.JoinFragment;

import java.util.List;

/**
 * @author Mattias Jiderhamn
 */
public class SubcriteriaTest extends TestCase {

  public SubcriteriaTest(String s) {
    super(s);
  }

  protected String getBaseForMappings() {
    return "foo/";
  }

  protected String[] getMappings() {
    return new String[] { "Order.hbm.xml" };
  }

  public void testSubcriteria() {
    Session s = openSession();
    s.getTransaction().begin();

    // Order with one mathing line
    Order order = new Order();
    OrderLine line = new OrderLine();
    line.setArticleId("1000");
    order.addLine(line);
    line = new OrderLine();
    line.setArticleId("3000");
    order.addLine(line);
    s.persist(order);

    // Order with no lines
    order = new Order();
    s.persist(order);

    // Order with non-matching line
    order = new Order();
    line = new OrderLine();
    line.setArticleId("3000");
    order.addLine(line);
    s.persist(order);

    s.flush();
    s.clear();

    // Get order
    order = (Order) s.get(Order.class, 1);
    assertEquals("Order 1 has 2 lines", 2, order.getLines().size());
    s.clear(); // (Removing this makes it work)

    // Search orders with specified article
    List orders = findOrders(s, "3000", "3000");
    assertEquals(2, orders.size());
    order = (Order) orders.get(0);
    assertEquals("Order 1 has 2 lines", 2, order.getLines().size()); // FAILS!

    // Search order with no lines, or
    orders = findOrders(s, null, "1000");
    assertEquals(2, orders.size());
    order = (Order) orders.get(1);
    assertTrue("No lines on order no 2", order.getLines().isEmpty());
    order = (Order) orders.get(0);
    assertEquals("Order 1 has 2 lines", 2, order.getLines().size()); // FAILS!

    s.close();
  }

  /**
   * Find orders by criteria in search form.
   * @param articleIdFrom Start of selection interval. If not provided, include orders
   * with no lines.
   * @param articleIdto End of selection interval.
   */
  private List findOrders(Session s, String articleIdFrom, String articleIdto) {
    Criteria criteria = s.createCriteria(Order.class);
    // criteria.setFetchMode("orderLines", FetchMode.SELECT); // Note: Does not help
    // Note: JoinFragment.LEFT_OUTER_JOIN must be used to include orders with no lines
    Criteria linesCritera = criteria.createCriteria("orderLines", JoinFragment.LEFT_OUTER_JOIN);

    /* Same result:
    criteria.createAlias("orderLines", "lines", JoinFragment.LEFT_OUTER_JOIN);
    */

    if(! isBlank(articleIdFrom) || ! isBlank(articleIdto)) {
      if(! isBlank(articleIdFrom)) {
        linesCritera.add(Expression.ge("articleId", articleIdFrom)); // >=
        if(! isBlank(articleIdto)) // To also
          linesCritera.add(Expression.le("articleId", articleIdto)); // <=
      }
      else if(! isBlank(articleIdto)) { // Only to
        linesCritera.add(Expression.or(
          Expression.isNull("articleId"),          // Allow null
          Expression.le("articleId", articleIdto)) // <=
        );
      }
    }

    criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY); // Needed b.o. left join

    return criteria.list();

  }

  private static boolean isBlank(String s) {
    return s == null || s.trim().length() == 0;
  }
}