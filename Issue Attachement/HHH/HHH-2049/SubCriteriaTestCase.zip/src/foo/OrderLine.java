package foo;

public class OrderLine {

  private int lineId = 0;
  
  private Order order;
  
  private String articleId;

  
  public int getLineId() {
    return lineId;
  }

  public Order getOrder() {
    return order;
  }  

  public String getArticleId() {
    return articleId;
  }

  public void setOrder(Order order) {
    this.order = order;
  }

  public void setArticleId(String articleId) {
    this.articleId = articleId;
  }
  
  public String toString() {
    return "[" + getLineId() + ":" + getArticleId() + "]";
  }
}