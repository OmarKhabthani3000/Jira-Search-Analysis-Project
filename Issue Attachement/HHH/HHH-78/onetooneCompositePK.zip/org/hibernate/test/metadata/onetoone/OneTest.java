//$Id:$
package org.hibernate.test.metadata.onetoone;

import org.hibernate.test.TestCase;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * @author Emmanuel Bernard
 */
public class OneTest extends TestCase {
	public OneTest(String x) {
		super(x);
	}

	public void testTest() throws Exception {
		Session s;
		Transaction tx;
		s = openSession();
		tx = s.beginTransaction();
		ComputerPk cid = new ComputerPk();
		cid.setBrand("IBM");
		cid.setModel("ThinkPad");
		Computer c = new Computer();
		c.setId(cid);
		c.setCpu("2 GHz");
		SerialNumberPk sid = new SerialNumberPk();
		sid.setBrand( cid.getBrand() );
		sid.setModel( cid.getModel() );
		SerialNumber sn = new SerialNumber();
		sn.setId(sid);
		sn.setValue("REZREZ23424");
		c.setSerial(sn);
		s.create(c);
		tx.commit();
		s.close();

		s = openSession();
		tx = s.beginTransaction();
		c = (Computer) s.get(Computer.class, cid);
		assertNotNull(c);
		assertNotNull( c.getSerial() );
		assertEquals( sn.getValue(), c.getSerial().getValue() );
		tx.commit();
		s.close();
	}

	protected String[] getMappings() {
		return new String[] {
			"metadata/onetoone/Computer.hbm.xml",
			"metadata/onetoone/SerialNumber.hbm.xml"
		};
	}
}
