//$Id:$
package org.hibernate.test.metadata.onetoone;

import javax.ejb.Entity;
import javax.ejb.OneToOne;
import javax.ejb.Id;
import javax.ejb.CascadeType;


/**
 * @author Emmanuel Bernard
 */
@Entity
public class Computer {

	private ComputerPk id;
	private String cpu;
	private SerialNumber serial;

	@OneToOne(cascade = {CascadeType.CREATE})
	public SerialNumber getSerial() {
		return serial;
	}

	public void setSerial(SerialNumber serial) {
		this.serial = serial;
	}

	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Computer)) return false;

		final Computer computer = (Computer) o;

		if (!id.equals(computer.id)) return false;

		return true;
	}

	public int hashCode() {
		return id.hashCode();
	}

	@Id
	public ComputerPk getId() {
		return id;
	}

	public void setId(ComputerPk id) {
		this.id = id;
	}

	public String getCpu() {
		return cpu;
	}

	public void setCpu(String cpu) {
		this.cpu = cpu;
	}
}
