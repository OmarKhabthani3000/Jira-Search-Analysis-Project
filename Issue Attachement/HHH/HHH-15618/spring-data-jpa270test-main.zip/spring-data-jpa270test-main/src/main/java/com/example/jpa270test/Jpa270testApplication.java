package com.example.jpa270test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jpa270testApplication {

	public static void main(String[] args) {
		SpringApplication.run(Jpa270testApplication.class, args);
	}

}
