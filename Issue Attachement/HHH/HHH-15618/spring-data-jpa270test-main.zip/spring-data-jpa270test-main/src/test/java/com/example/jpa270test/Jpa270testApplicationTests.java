package com.example.jpa270test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jpa270testApplicationTests {

	@Test
	void contextLoads() {
	}

}
