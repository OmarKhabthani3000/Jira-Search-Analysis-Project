package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM,
 * using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
	entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
	entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	entityManager.getTransaction().begin();
	final CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
	final CriteriaQuery<Long> query = criteriaBuilder.createQuery(Long.class);
	final Root<Marktteilnehmer> root = query.from(Marktteilnehmer.class);

	final Expression<String> nameAndVorname = criteriaBuilder.function(
		"decode", String.class,
		root.get("id"),
		criteriaBuilder.literal(0l),
		criteriaBuilder.nullLiteral(String.class),
		criteriaBuilder.concat(
			root.<String>get("name"),
			criteriaBuilder.function("decode", String.class,
				root.get("vorname"),
				criteriaBuilder.nullLiteral(String.class),
				criteriaBuilder.nullLiteral(String.class),
				criteriaBuilder.concat(
					criteriaBuilder.literal(", "),
					root.<String>get("vorname")
				)
			)
		)
	);
	/*
	Results in:
	select count(marktteiln0_.id) as col_0_0_ 
	  from marktteilnehmer marktteiln0_ 
         where decode(marktteiln0_.id, 0, null, marktteiln0_.name||decode(marktteiln0_.vorname||null||null||?||marktteiln0_.vorname)) like ?
		
	Expected Result is
	select count(marktteiln0_.id) as col_0_0_ 
	  from marktteilnehmer marktteiln0_ 
         where decode(marktteiln0_.id, 0, null, marktteiln0_.name||decode(marktteiln0_.vorname,null, null, ?||marktteiln0_.vorname)) like ?	
	 */
	long cnt = entityManager.createQuery(
		query.select(criteriaBuilder.count(root)).where(criteriaBuilder.like(nameAndVorname, "%"))
	).getSingleResult();
	Assert.assertEquals(0l, cnt);
	entityManager.getTransaction().commit();
	entityManager.close();
    }
}
