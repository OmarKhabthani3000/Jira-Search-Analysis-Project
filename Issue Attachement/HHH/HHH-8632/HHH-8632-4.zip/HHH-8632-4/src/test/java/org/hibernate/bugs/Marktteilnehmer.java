/*
 * Copyright 2015 EuregJUG.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "marktteilnehmer")
public class Marktteilnehmer implements Serializable {

    private static final long serialVersionUID = -2488354242899068540L;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "marktteilnehmer_id_seq_generator")
    @SequenceGenerator(name = "marktteilnehmer_id_seq_generator", sequenceName = "marktteilnehmer_id_seq")
    private Integer id;
       
    @Column(name = "name", length = 512, nullable = false)   
    private String name;

    @Column(name = "vorname", length = 512, nullable = false)    
    private String vorname;

    public Marktteilnehmer() {
    }

    public Marktteilnehmer(String name, String vorname) {
	this.name = name;
	this.vorname = vorname;
    }

    public Integer getId() {
	return id;
    }

    public String getName() {
	return name;
    }

    public String getVorname() {
	return vorname;
    }

    @Override
    public int hashCode() {
	int hash = 3;
	hash = 73 * hash + Objects.hashCode(this.name);
	hash = 73 * hash + Objects.hashCode(this.vorname);
	return hash;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj) {
	    return true;
	}
	if (obj == null) {
	    return false;
	}
	if (getClass() != obj.getClass()) {
	    return false;
	}
	final Marktteilnehmer other = (Marktteilnehmer) obj;
	if (!Objects.equals(this.name, other.name)) {
	    return false;
	}
	return Objects.equals(this.vorname, other.vorname);
    }
}
