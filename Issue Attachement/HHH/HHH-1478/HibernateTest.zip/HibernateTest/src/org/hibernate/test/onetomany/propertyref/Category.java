package org.hibernate.test.onetomany.propertyref;

/**
 * @author Enri
 */
public class Category {
  CategoryId id;

  public Category(){}
  
  public CategoryId getId() {
    return id;
  }

  public void setId(CategoryId id) {
    this.id = id;
  }

  /**public boolean equals(Object o) {
    if( !(o instanceof Category) ) return false;
    return id.equals( ((Category)o).getId() );
  }
  
  public int hashCode() {
    assert id!=null : "Id category null!";
	return id.hashCode();
  }*/
}