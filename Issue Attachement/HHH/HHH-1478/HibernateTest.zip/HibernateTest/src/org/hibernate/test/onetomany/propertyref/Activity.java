package org.hibernate.test.onetomany.propertyref;
import java.util.HashSet;
import java.util.Set;

/**
 * @author Enri
 */
public class Activity  {
  private Long id;
  private Set allMyCategories;
  private Long category;
  
  public Long getId() {
    return id;
  }
  public void setId(Long idActivity) {
    this.id = idActivity;
  }
  public Set getAllMyCategories() {
    // this line makes the test fail!
	if(allMyCategories==null) return new HashSet();
	
	return allMyCategories;
  }
  public void setAllMyCategories(Set allMyCategories) {
    this.allMyCategories = allMyCategories;
  }
  
  private Long getCategory() {
    return category;
  }
  private void setCategory(Long category) {
    this.category = category;
  }

  
}