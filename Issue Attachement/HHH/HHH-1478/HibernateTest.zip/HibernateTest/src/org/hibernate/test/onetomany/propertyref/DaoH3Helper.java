package org.hibernate.test.onetomany.propertyref;

import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class DaoH3Helper extends HibernateDaoSupport  {

  public void save(Object object) {
    getHibernateTemplate().save( object ); 
  }
  
  public void flush() {
    getHibernateTemplate().execute( 
        new HibernateCallback() {
          public Object doInHibernate(Session session) {
            session.flush();
            return null;
          }
        } );
  }
  
  public void deleteActivity() {
    getHibernateTemplate().execute( 
  	  new HibernateCallback() {
          public Object doInHibernate(Session session) {
            session.createQuery( "delete Activity" ).executeUpdate();
            return null;
          }
        } );
  }
}