package org.hibernate.test.onetomany.propertyref;

import java.io.Serializable;

public class CategoryId implements Serializable {
  private static final long serialVersionUID = 1564085688885929509L;
  String idCategory;
  String idDesc;

  public String getIdCategory() {
    return idCategory;
  }

  public void setIdCategory(String idCategory) {
    this.idCategory = idCategory;
  }

  public String getIdDesc() {
    return idDesc;
  }

  public void setIdDesc(String idDesc) {
    this.idDesc = idDesc;
  }
  
  public boolean equals(Object o){
    if (o!=null && o instanceof CategoryId){
      CategoryId da = (CategoryId)o;
      assert idCategory!=null && idDesc!=null : "null keys!";
      return ( idCategory.equals(da.getIdCategory()) && (idDesc.equals(da.getIdDesc())) );  
    }
    return false;
  }
  
  public int hashCode(){
	String total = idCategory+idDesc;
	assert total!=null : "null keys!";
    byte b[] = total.getBytes();
    return b.length;
  }


}