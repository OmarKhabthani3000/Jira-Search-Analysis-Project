package org.hibernate.test.onetomany.propertyref;

import junit.framework.TestCase;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

/**
 * @author Enri
 */
public class TestNullableRef extends TestCase {
  ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(new String[] {
     "org/hibernate/test/onetomany/propertyref/config.xml"
  });
  
  DaoH3Helper daoHelper = (DaoH3Helper)appContext.getBean("dao");
  HibernateTransactionManager tm = (HibernateTransactionManager) appContext.getBean( "myTxManager" );
  DefaultTransactionDefinition td = new DefaultTransactionDefinition( TransactionDefinition.PROPAGATION_REQUIRED );
  TransactionStatus status;
  
  public void setUp() {
    status = tm.getTransaction( td );
    daoHelper.deleteActivity();
  }
  public void tearDown() {
    tm.rollback( status );
  }
  
  public void testCollection() {
	Activity att = new Activity();
    
	daoHelper.save(att);
	
	daoHelper.flush();
  }  
}
