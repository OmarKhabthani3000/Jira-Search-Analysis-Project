package ejb3Test;


import java.util.Hashtable;
import java.util.List;

import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.transaction.TransactionManager;

import junit.extensions.TestSetup;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import model.Injury;
import model.Person;

import org.jboss.ejb3.embedded.EJB3StandaloneBootstrap;

/**
 * Comment
 *
 * @author <a href="mailto:bill@jboss.org">Bill Burke</a>
 * @version $Revision: 42757 $
 */
public class EmbeddedEjb3TestCase extends TestCase {
	public EmbeddedEjb3TestCase() {
		super("EmbeddedEjb3TestCase");
	}

	public static Test suite() throws Exception {
		TestSuite suite = new TestSuite();
		suite.addTestSuite(EmbeddedEjb3TestCase.class);

		// setup test so that embedded JBoss is started/stopped once for all tests here.
		TestSetup wrapper = new TestSetup(suite) {
			protected void setUp() {
				startupEmbeddedJboss();
			}

			protected void tearDown() {
				shutdownEmbeddedJboss();
			}
		};

		return wrapper;
	}

	public void setUp() {
		startupEmbeddedJboss();
	}

	public void tearDown() {
		shutdownEmbeddedJboss();
	}

	public static void startupEmbeddedJboss() {
		EJB3StandaloneBootstrap.boot(null);
		EJB3StandaloneBootstrap.scanClasspath();
	}

	public static void shutdownEmbeddedJboss() {
		EJB3StandaloneBootstrap.shutdown();
	}

	public void testBug() throws Exception {

		Person person = new Person();
		person.setName("myName");
		
		Injury injury = new Injury();
		injury.setName("blahblah");
		
		injury.setPerson(person);
		
		EntityManager em = (EntityManager) getInitialContext().lookup(
				"java:/EntityManagers/custdb");

		TransactionManager tm = (TransactionManager) getInitialContext()
				.lookup("java:/TransactionManager");

		tm.begin();
		em.persist(person);
		em.persist(injury);
		tm.commit();

		tm.begin();
		List result = em.createQuery("from Injury").getResultList();
		tm.commit();
	}

	public static InitialContext getInitialContext() throws Exception {
		Hashtable props = getInitialContextProperties();
		return new InitialContext(props);
	}

	private static Hashtable getInitialContextProperties() {
		Hashtable props = new Hashtable();
		props.put("java.naming.factory.initial",
				"org.jnp.interfaces.LocalOnlyContextFactory");
		props.put("java.naming.factory.url.pkgs",
				"org.jboss.naming:org.jnp.interfaces");
		return props;
	}
}
