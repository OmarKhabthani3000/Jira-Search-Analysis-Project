package hibernate;

import java.util.List;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import model.Injury;
import model.Person;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * @author Anthony
 *

 */
public class BugTest extends HibernateTestCase{
	public void testBug() throws Exception  {
		Session session = openSession();
		Transaction tx = null ;
		try {
			tx = session.beginTransaction();
			Person person = new Person();
			person.setName("myName");
			
			Injury injury = new Injury();
			injury.setName("blahblah");
			
			injury.setPerson(person);
			

			session.persist(person);
			session.persist(injury);
			tx.commit();
			session.close();

			session = openSession();
			tx = session.beginTransaction();
			List result = session.createQuery("from Injury").list();
			tx.commit();
		}
		catch (Exception e) {
			if (tx != null) {
				try {
					tx.rollback();
				} catch (HibernateException he) {
				throw he;
				}
			}
			throw e;
		}
		finally {
			try {
			  session.close();
			} catch (HibernateException ex) {
			  throw new Exception(ex); 	//exception fatale
			}			
		}
	}
	
	public BugTest(String arg0) {
		super(arg0);
	}
	
	public String[] getMappings() {
		return new String[] {"hibernate/Person.hbm.xml"};
	}

	public static Test suite() {
		return new TestSuite(BugTest.class);
	}
	
	public static void main(String[] args) throws Exception {
		TestRunner.run( suite() );
	}
}
