package model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
@Entity
public class Suspect extends Person{

	private Set<Case> cases = new HashSet<Case>();


	@OneToMany(cascade=javax.persistence.CascadeType.ALL, targetEntity=Case.class, fetch=FetchType.EAGER)
	//uncomment as a workaround
	//@Fetch(FetchMode.SELECT)
	public Set<Case> getCases() {
		return cases;
	}

	public void setCases(Set<Case> cases) {
		this.cases = cases;
	}
	
}
