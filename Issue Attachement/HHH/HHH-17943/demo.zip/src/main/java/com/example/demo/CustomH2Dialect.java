package com.example.demo;

import org.hibernate.dialect.H2Dialect;

public class CustomH2Dialect extends H2Dialect {

	@Override
	public String getTemporaryTableCreateOptions() {
		return "TRANSACTIONAL";
	}
}
