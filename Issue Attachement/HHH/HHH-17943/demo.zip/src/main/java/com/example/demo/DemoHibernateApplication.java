package com.example.demo;

import java.util.UUID;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.OneToOne;

public class DemoHibernateApplication {

	private static SessionFactory sessionFactory;

	public static void main(String[] args) {
		System.out.println("Start");

		try (Session session = getSessionFactory().openSession()) {
			Transaction transaction = session.beginTransaction();

			session.persist(newMyFirstEntityWithTitle("a"));
			session.flush();
			session.createMutationQuery("UPDATE MY_SECOND_ENTITY SET title=null")
					.executeUpdate();

			transaction.rollback();
		}

		System.out.println("After first transaction");

		try (Session session = getSessionFactory().openSession()) {
			Transaction transaction = session.beginTransaction();

			session.persist(newMyFirstEntityWithTitle("a"));

			transaction.commit();
		}

		System.out.println("End");
	}

	private static SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			StandardServiceRegistry registry = new StandardServiceRegistryBuilder().build();

			sessionFactory = new MetadataSources(registry)
					.addAnnotatedClass(MyFirstEntity.class)
					.addAnnotatedClass(MySecondEntity.class)
					.buildMetadata()
					.buildSessionFactory();
		}

		return sessionFactory;
	}

	private static MyFirstEntity newMyFirstEntityWithTitle(String title) {
		MyFirstEntity myFirstEntity = new MyFirstEntity();
		myFirstEntity.setId(UUID.randomUUID());
		myFirstEntity.setTitle(title);
		return myFirstEntity;
	}

	@Entity(name = "MY_FIRST_ENTITY")
	public static class MyFirstEntity {

		@Id
		private UUID id;

		@Column(nullable = false, unique = true, columnDefinition = "nvarchar")
		private String title;

		public UUID getId() {
			return id;
		}

		public void setId(UUID id) {
			this.id = id;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

	}

	@Entity(name = "MY_SECOND_ENTITY")
	public static class MySecondEntity {

		@Id
		private UUID id;

		@Column(nullable = false, columnDefinition = "nvarchar")
		private String title;

		@OneToOne
		@JoinTable(name = "MY_SECOND_ENTITY_MAPPING", joinColumns = { @JoinColumn(name = "a") }, inverseJoinColumns = { @JoinColumn(name = "b") })
		private MySecondEntity anotherMySecondEntity;

		public UUID getId() {
			return id;
		}

		public void setId(UUID id) {
			this.id = id;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public MySecondEntity getAnotherMySecondEntity() {
			return anotherMySecondEntity;
		}

		public void setAnotherMySecondEntity(MySecondEntity anotherMySecondEntity) {
			this.anotherMySecondEntity = anotherMySecondEntity;
		}

	}

}
