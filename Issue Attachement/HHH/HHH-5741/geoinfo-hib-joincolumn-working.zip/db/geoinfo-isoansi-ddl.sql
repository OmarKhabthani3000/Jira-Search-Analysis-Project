CREATE TABLE Countries
(
  iso_code CHAR(2) NOT NULL,
  name VARCHAR(50) NOT NULL,
  PRIMARY KEY (iso_code)
);

CREATE TABLE States
(
  country_code CHAR(2) NOT NULL,
  iso_code VARCHAR(5) NOT NULL,
  name VARCHAR(100) NOT NULL,
  PRIMARY KEY (country_code, iso_code),
  FOREIGN KEY (country_code) REFERENCES Countries (iso_code)
);

CREATE TABLE Cities
(
  country_code CHAR(2) NOT NULL,
  state_code VARCHAR(5) NOT NULL,
  name VARCHAR(100) NOT NULL,
  PRIMARY KEY (country_code, state_code, name),
  FOREIGN KEY (country_code, state_code) REFERENCES States (country_code, iso_code)
);

CREATE TABLE Zips
(
  country_code CHAR(2) NOT NULL,
  code VARCHAR(10) NOT NULL,
  PRIMARY KEY (country_code, code),
  FOREIGN KEY (country_code) REFERENCES Countries (iso_code)
);

CREATE TABLE ZipAreas
(
  country_code CHAR(2) NOT NULL,
  zip_code VARCHAR(10) NOT NULL,
  state_code VARCHAR(5) NOT NULL,
  city_name VARCHAR(100) NOT NULL,
  PRIMARY KEY (country_code, zip_code, state_code, city_name),
  FOREIGN KEY (country_code, zip_code) REFERENCES Zips (country_code, code),
  FOREIGN KEY (country_code, state_code, city_name) REFERENCES Cities (country_code, state_code, name)
);

