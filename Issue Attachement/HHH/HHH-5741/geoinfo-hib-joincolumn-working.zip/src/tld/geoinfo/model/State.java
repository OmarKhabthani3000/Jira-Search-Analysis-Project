package tld.geoinfo.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "States")
@IdClass(value = StateId.class)
public class State implements Serializable
{
	@Id
	@Column(name = "country_code")
	private String countryCode;

	@Id
	@Column(name = "iso_code")
	private String isoCode;

	@Column(name = "name")
	private String name;

	@ManyToOne
	@JoinColumn(name = "country_code", referencedColumnName = "iso_code", insertable = false, updatable = false)
	private Country country = null;

	@OneToMany(targetEntity = City.class, mappedBy = "state")
	private Set<City> cities = new HashSet<City>();

	public State()
	{
	}

	public State(String countryCode, String isoCode)
	{
		this(countryCode, isoCode, null);
	}

	public State(String countryCode, String isoCode, String name)
	{
		this.countryCode = countryCode;
		this.isoCode = isoCode;
		this.name = name;

		if ( countryCode != null )
		{
			this.country = new Country(countryCode);
		}
	}

	public String getCountryCode()
	{
		return countryCode;
	}

	public String getIsoCode()
	{
		return isoCode;
	}

	public void setIsoCode(String isoCode)
	{
		this.isoCode = isoCode;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Country getCountry()
	{
		return country;
	}

	public void setCountry(Country country)
	{
		this.country = country;
		this.countryCode = country.getIsoCode();
	}

	public Set<City> getCities()
	{
		return cities;
	}

	public void setCities(Set<City> cities)
	{
		this.cities = cities;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		State rhs = (State)obj;

		return new EqualsBuilder().append(countryCode, rhs.getCountryCode()).append(isoCode, rhs.getIsoCode()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(435727523, 92821).append(countryCode).append(isoCode).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("countryCode", countryCode).append("isoCode", isoCode).append("name", name).append("country", country).toString();
	}

}
