package tld.geoinfo.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class CityId implements Serializable
{
	private String countryCode;

	private String stateCode;

	private String name;

	public CityId()
	{
	}

	public CityId(String countryCode, String stateCode, String name)
	{
		this.countryCode = countryCode;
		this.stateCode = stateCode;
		this.name = name;
	}

	public String getCountryCode()
	{
		return countryCode;
	}

	public void setCountryCode(String countryCode)
	{
		this.countryCode = countryCode;
	}

	public String getStateCode()
	{
		return stateCode;
	}

	public void setStateCode(String stateCode)
	{
		this.stateCode = stateCode;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		CityId rhs = (CityId)obj;

		return new EqualsBuilder().append(countryCode, rhs.getCountryCode()).append(stateCode, rhs.getStateCode()).append(name, rhs.getName()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(1348146737, 92821).append(countryCode).append(stateCode).append(name).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("countryCode", countryCode).append("stateCode", stateCode).append("name", name).toString();
	}

}
