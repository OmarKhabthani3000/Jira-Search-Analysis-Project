package tld.geoinfo.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class ZipAreaId implements Serializable
{
	private String countryCode;

	private String zipCode;

	private String stateCode;

	private String cityName;

	public ZipAreaId()
	{
	}

	public ZipAreaId(String countryCode, String zipCode, String stateCode, String cityName)
	{
		this.countryCode = countryCode;
		this.zipCode = zipCode;
		this.stateCode = stateCode;
		this.cityName = cityName;
	}

	public String getCountryCode()
	{
		return countryCode;
	}

	public void setCountryCode(String countryCode)
	{
		this.countryCode = countryCode;
	}

	public String getZipCode()
	{
		return zipCode;
	}

	public void setZipCode(String zipCode)
	{
		this.zipCode = zipCode;
	}

	public String getStateCode()
	{
		return stateCode;
	}

	public void setStateCode(String stateCode)
	{
		this.stateCode = stateCode;
	}

	public String getCityName()
	{
		return cityName;
	}

	public void setCityName(String cityName)
	{
		this.cityName = cityName;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		ZipAreaId rhs = (ZipAreaId)obj;

		return new EqualsBuilder().append(countryCode, rhs.getCountryCode()).append(zipCode, rhs.getZipCode()).append(stateCode, rhs.getStateCode()).append(cityName, rhs.getCityName()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(1649372225, 92821).append(countryCode).append(zipCode).append(stateCode).append(cityName).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("countryCode", countryCode).append("zipCode", zipCode).append("stateCode", stateCode).append("cityName", cityName).toString();
	}

}
