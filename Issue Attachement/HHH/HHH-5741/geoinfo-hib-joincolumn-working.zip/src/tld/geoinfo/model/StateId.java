package tld.geoinfo.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class StateId implements Serializable
{
	private String countryCode;

	private String isoCode;

	public StateId()
	{
	}

	public StateId(String countryCode, String isoCode)
	{
		this.countryCode = countryCode;
		this.isoCode = isoCode;
	}

	public String getCountryCode()
	{
		return countryCode;
	}

	public void setCountryCode(String countryCode)
	{
		this.countryCode = countryCode;
	}

	public String getIsoCode()
	{
		return isoCode;
	}

	public void setIsoCode(String isoCode)
	{
		this.isoCode = isoCode;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		StateId rhs = (StateId)obj;

		return new EqualsBuilder().append(countryCode, rhs.getCountryCode()).append(isoCode, rhs.getIsoCode()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(821475663, 92821).append(countryCode).append(isoCode).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("countryCode", countryCode).append("isoCode", isoCode).toString();
	}

}
