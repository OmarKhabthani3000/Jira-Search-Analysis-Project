
package tld.geoinfo;

import java.io.*;
import java.util.*;
import java.util.logging.*;
import java.sql.*;
import java.text.*;

import javax.sql.*;
import javax.persistence.*;

import tld.geoinfo.model.*;

public class Main
{
		
	public static void main(String... sArgs) throws Exception
	{
		String sDbName = "geoinfo";
		createInMemoryDbViaJdbc(sDbName); // via JDBC statements
	
		System.out.println();
		System.out.println("Database created!");
		System.out.println();
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(sDbName);
		EntityManager em = emf.createEntityManager();
		
		System.out.println();
		System.out.println("Entity manager created!");
		System.out.println();
		
		//em.find(ZipAreaId.class, new ZipAreaId());
		
		//em.close();
		//emf.close();
	}
	
	private static void createInMemoryDbViaJdbc(String sDbName) throws Exception
	{
		String sBatchSqlScript = readFile(new File("db", sDbName + "-isoansi-ddl.sql"));
		
		//System.out.println(sBatchSqlScript);
		
		List<String> lsStatements = new ArrayList<String>();
		
		StringTokenizer sto = new StringTokenizer(sBatchSqlScript, ";");
	
		while ( sto.hasMoreTokens() )
		{
			String sStatement = sto.nextToken().trim();
			//System.out.println("---------------------------------------------------------------------------------------------------");
			//System.out.println(sStatement);
			
			if ( !sStatement.isEmpty() )
			{
				lsStatements.add(sStatement);
			}
		}
 
		// loads the JDBC driver (needed for HSQLDB pre 2.0.0)
		Class.forName("org.hsqldb.jdbcDriver");	
		
		PreparedStatement ps = null;
		Connection conn = null;
		
		String sCurrStatement = null;
		
		try
		{
			conn = DriverManager.getConnection("jdbc:hsqldb:mem:" + sDbName, "sa", "");
			
			for ( String sStatement : lsStatements )
			{
				sCurrStatement = sStatement;
				ps = conn.prepareStatement(sStatement);
				ps.executeUpdate();
			}
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			System.out.println(sCurrStatement);
			System.exit(1);
		}
		finally
		{
			try
			{
				conn.close();
			}
			catch ( SQLException e )
			{
				e.printStackTrace();
			}
		}
    }
	
	private static String readFile(File flRead)
	{
		String sContent = null;
		FileInputStream fis = null;
		
		try
		{
			fis = new FileInputStream(flRead);
			byte[] readBuffer = new byte[(int)flRead.length()];
			
			fis.read(readBuffer);
			sContent = new String(readBuffer);
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			return null;
		}
		finally
		{
			if ( fis != null )
			{
				try
				{
					fis.close();
				}
				catch ( Throwable t )
				{
					System.err.println("File input stream couldn't be closed!");
				}
			}
		}
	
		return sContent;
	}

}
