package tld.geoinfo.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.PrimaryKeyJoinColumns;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "Cities")
@IdClass(value = CityId.class)
public class City implements Serializable
{
	@Id
	@Column(name = "country_code")
	private String countryCode;

	@Id
	@Column(name = "state_code")
	private String stateCode;

	@Id
	@Column(name = "name")
	private String name;

	@ManyToOne
	@PrimaryKeyJoinColumns(value = {@PrimaryKeyJoinColumn(name = "country_code", referencedColumnName = "country_code"), @PrimaryKeyJoinColumn(name = "state_code", referencedColumnName = "iso_code")})
	private State state = null;

	@OneToMany(targetEntity = ZipArea.class, mappedBy = "city")
	private Set<ZipArea> zipAreas = new HashSet<ZipArea>();

	public City()
	{
	}

	public City(String countryCode, String stateCode, String name)
	{
		this.countryCode = countryCode;
		this.stateCode = stateCode;
		this.name = name;

		if ( countryCode != null && stateCode != null )
		{
			this.state = new State(countryCode, stateCode);
		}
	}

	public String getCountryCode()
	{
		return countryCode;
	}

	public String getStateCode()
	{
		return stateCode;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public State getState()
	{
		return state;
	}

	public void setState(State state)
	{
		this.state = state;
		this.countryCode = state.getCountryCode();
		this.stateCode = state.getIsoCode();
	}

	public Set<ZipArea> getZipAreas()
	{
		return zipAreas;
	}

	public void setZipAreas(Set<ZipArea> zipAreas)
	{
		this.zipAreas = zipAreas;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		City rhs = (City)obj;

		return new EqualsBuilder().append(countryCode, rhs.getCountryCode()).append(stateCode, rhs.getStateCode()).append(name, rhs.getName()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(1501085729, 92821).append(countryCode).append(stateCode).append(name).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("countryCode", countryCode).append("stateCode", stateCode).append("name", name).append("state", state).toString();
	}

}
