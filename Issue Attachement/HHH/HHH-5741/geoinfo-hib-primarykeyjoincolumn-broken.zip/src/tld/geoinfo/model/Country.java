package tld.geoinfo.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "Countries")
public class Country implements Serializable
{
	@Id
	@Column(name = "iso_code")
	private String isoCode;

	@Column(name = "name")
	private String name;

	@OneToMany(targetEntity = State.class, mappedBy = "country")
	private Set<State> states = new HashSet<State>();

	@OneToMany(targetEntity = Zip.class, mappedBy = "country")
	private Set<Zip> zips = new HashSet<Zip>();

	public Country()
	{
	}

	public Country(String isoCode)
	{
		this(isoCode, null);
	}

	public Country(String isoCode, String name)
	{
		this.isoCode = isoCode;
		this.name = name;
	}

	public String getIsoCode()
	{
		return isoCode;
	}

	public void setIsoCode(String isoCode)
	{
		this.isoCode = isoCode;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Set<State> getStates()
	{
		return states;
	}

	public void setStates(Set<State> states)
	{
		this.states = states;
	}

	public Set<Zip> getZips()
	{
		return zips;
	}

	public void setZips(Set<Zip> zips)
	{
		this.zips = zips;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		Country rhs = (Country)obj;

		return new EqualsBuilder().append(isoCode, rhs.getIsoCode()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(2054187723, 92821).append(isoCode).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("isoCode", isoCode).append("name", name).toString();
	}

}
