package tld.geoinfo.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.PrimaryKeyJoinColumns;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "ZipAreas")
@IdClass(value = ZipAreaId.class)
public class ZipArea implements Serializable
{
	@Id
	@Column(name = "country_code")
	private String countryCode;

	@Id
	@Column(name = "zip_code")
	private String zipCode;

	@Id
	@Column(name = "state_code")
	private String stateCode;

	@Id
	@Column(name = "city_name")
	private String cityName;

	@ManyToOne
	@PrimaryKeyJoinColumns(value = {@PrimaryKeyJoinColumn(name = "country_code", referencedColumnName = "country_code"), @PrimaryKeyJoinColumn(name = "zip_code", referencedColumnName = "code")})
	private Zip zip = null;

	@ManyToOne
	@PrimaryKeyJoinColumns(value = {@PrimaryKeyJoinColumn(name = "country_code", referencedColumnName = "country_code"), @PrimaryKeyJoinColumn(name = "state_code", referencedColumnName = "state_code"), @PrimaryKeyJoinColumn(name = "city_name", referencedColumnName = "name")})
	private City city = null;

	public ZipArea()
	{
	}

	public ZipArea(String countryCode, String zipCode, String stateCode, String cityName)
	{
		this.countryCode = countryCode;
		this.zipCode = zipCode;
		this.stateCode = stateCode;
		this.cityName = cityName;

		if ( countryCode != null && zipCode != null )
		{
			this.zip = new Zip(countryCode, zipCode);
		}

		if ( countryCode != null && stateCode != null && cityName != null )
		{
			this.city = new City(countryCode, stateCode, cityName);
		}
	}

	public String getCountryCode()
	{
		return countryCode;
	}

	public String getZipCode()
	{
		return zipCode;
	}

	public String getStateCode()
	{
		return stateCode;
	}

	public String getCityName()
	{
		return cityName;
	}

	public Zip getZip()
	{
		return zip;
	}

	public void setZip(Zip zip)
	{
		this.zip = zip;
		this.countryCode = zip.getCountryCode();
		this.zipCode = zip.getCode();
	}

	public City getCity()
	{
		return city;
	}

	public void setCity(City city)
	{
		this.city = city;
		this.countryCode = city.getCountryCode();
		this.stateCode = city.getStateCode();
		this.cityName = city.getName();
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		ZipArea rhs = (ZipArea)obj;

		return new EqualsBuilder().append(countryCode, rhs.getCountryCode()).append(zipCode, rhs.getZipCode()).append(stateCode, rhs.getStateCode()).append(cityName, rhs.getCityName()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(311681221, 92821).append(countryCode).append(zipCode).append(stateCode).append(cityName).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("countryCode", countryCode).append("zipCode", zipCode).append("stateCode", stateCode).append("cityName", cityName).append("zip", zip).append("city", city).toString();
	}

}
