package org.hibernate.bugs;

import javax.persistence.CascadeType;
import javax.persistence.Embeddable;
import javax.persistence.OneToOne;

/**
 * <code>Finances</code> -
 *
 * @author Vlad Mihalcea
 */
@Embeddable
public class Finances {

	@OneToOne(cascade = CascadeType.PERSIST) //
	private Account selectedAccount;

	public Account getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(Account selectedAccount) {
		this.selectedAccount = selectedAccount;
	}
}
