package org.hibernate.bugs;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * <code>User</code> -
 *
 * @author Vlad Mihalcea
 */
@Entity(name = "User")
public class User {

	@Id
	@GeneratedValue
	private Long id;

	@Embedded
	private Finances finances = new Finances();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Finances getFinances() {
		return finances;
	}

	public void setFinances(Finances finances) {
		this.finances = finances;
	}
}
