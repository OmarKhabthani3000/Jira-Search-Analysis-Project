package com.example.hhh10562.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "parent")
public class Parent implements Serializable
{
    private static final long serialVersionUID = 1L;
    private Long id;
    private Set<Child> children = new HashSet<>();

    @Id
    @Column(name = "id", unique = true, nullable = false, updatable = false)
    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    @OneToMany(mappedBy = "parent")
    public Set<Child> getChildren()
    {
        return this.children;
    }

    public void setChildren(Set<Child> children)
    {
        this.children = children;
    }

    @Override
    public String toString()
    {
        return String.format("%s#%d", getClass().getSimpleName(), getId());
    }

}
