package com.example.hhh10562;

import com.example.hhh10562.model.Child;
import com.example.hhh10562.model.Parent;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataBuilder;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.SessionFactoryBuilder;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.engine.spi.EntityEntry;
import org.hibernate.engine.spi.ManagedEntity;

public class Main implements AutoCloseable
{

    public static void main(final String[] arguments)
    {
        try (final Main main = new Main())
        {
            main.setup();
            main.test();
        }
    }

    public Main()
    {
        final StandardServiceRegistryBuilder registryBuilder = new StandardServiceRegistryBuilder();
        registryBuilder.configure();
        final StandardServiceRegistry registry = registryBuilder.build();
        final MetadataSources metadataSources = new MetadataSources(registry);
        final MetadataBuilder metadataBuilder = metadataSources.getMetadataBuilder();
        final Metadata metadata = metadataBuilder.build();
        final SessionFactoryBuilder sessionFactoryBuilder = metadata.getSessionFactoryBuilder();
        this.sessionFactory = sessionFactoryBuilder.build();
    }

    private final SessionFactory sessionFactory;

    public void setup()
    {
        try (final Session session = sessionFactory.openSession())
        {
            final Transaction transaction = session.beginTransaction();
            final Parent parent = new Parent();
            parent.setId(1L);
            session.save(parent);
            for (long id = 1L; id <= 4L; id++)
            {
                final Child child = new Child();
                child.setId(id);
                child.setParent(parent);
                session.save(child);
            }
            transaction.commit();
        }
    }

    public void test()
    {
        try (final Session session = sessionFactory.openSession())
        {
            final Transaction transaction = session.beginTransaction();
            final Parent parent = session.get(Parent.class, 1L);
            final Set<Child> children = parent.getChildren();
            final Set<Child> copy = new HashSet<>(children);
            final Iterator<Child> iterator = children.iterator();
            while (iterator.hasNext())
            {
                final Child child = iterator.next();
                debug(child);
                iterator.remove();
                session.delete(child);
            }
            session.flush();
            for (final Child child : copy)
            {
                debug(child);
                session.evict(child);
            }
            transaction.commit();
        } catch (final NegativeArraySizeException exception)
        {
            System.err.println("EntityEntryContext.count was somehow negative");
            exception.printStackTrace(System.err);
        } catch (final NullPointerException exception)
        {
            System.err.println("EntityEntryContext.head was somehow null, so an array containing null values only was returned from EntityEntryContext.reentrantSafeEntityEntries()");
            exception.printStackTrace(System.err);
        }
    }

    @Override
    public void close()
    {
        sessionFactory.close();
    }

    private void debug(final Object object)
    {
        if (object instanceof ManagedEntity)
        {
            final ManagedEntity managed = (ManagedEntity) object;
            final ManagedEntity previous = managed.$$_hibernate_getPreviousManagedEntity();
            final ManagedEntity next = managed.$$_hibernate_getNextManagedEntity();
            final EntityEntry entry = managed.$$_hibernate_getEntityEntry();
            System.out.println(String.format("%s: previous=%s, next=%s, entry=%s", managed, previous, next, entry));
        }
        else
        {
            System.err.println("Object is not a ManagedEntity! Maybe bytecode enhancement is disabled?");
        }
    }

}
