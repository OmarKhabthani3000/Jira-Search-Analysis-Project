package case15607;


import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.redhat.gss.hibernate.EntityManagerTestCase;

public class TestCase15607 extends EntityManagerTestCase {

	protected Class[] getAnnotatedClasses() {
		return new Class[] { Customer.class, Account.class };
	}
	
	// works
	public void testSelectQuery() {
		EntityManager em = getEntityManager();
		Query query = em.createQuery("from Customer c where exists (select a from c.account a where a.accountName = :param)").setParameter("param", "blah");
		query.getResultList();
		em.close();
	}

	// broken
	public void testDeleteQuery() {
		EntityManager em = getEntityManager();
		Query query = em.createQuery("delete from Customer c where exists (select a from c.account a where a.accountName = :param)").setParameter("param", "blah");
		query.getResultList();
		em.close();
	}

}
