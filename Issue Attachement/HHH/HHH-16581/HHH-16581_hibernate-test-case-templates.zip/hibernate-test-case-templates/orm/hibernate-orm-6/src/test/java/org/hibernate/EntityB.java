package org.hibernate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.FilterDefs;

import java.util.Objects;

@FilterDefs(value = @FilterDef(name = "filterA"))
@Entity
public class EntityB {
    @Id
    private long id;

    private String something;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSomething() {
        return something;
    }

    public void setSomething(String something) {
        this.something = something;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EntityB entityB = (EntityB) o;
        return id == entityB.id && Objects.equals(something, entityB.something);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, something);
    }
}
