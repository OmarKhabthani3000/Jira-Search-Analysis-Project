package pvarga.hibernate.hhh8346;

import javax.persistence.Parameter;

/**
 * Simple Parameter implementation.
 *
 * @author pvarga
 */
public class ParameterImpl<T> implements Parameter<T> {

    private String name;
    private Integer position;
    private Class<T> parameterType;

    public ParameterImpl(String name, Integer position, Class<T> parameterType) {
        this.name = name;
        this.position = position;
        this.parameterType = parameterType;
    }

    public String getName() {
        return name;
    }

    public Integer getPosition() {
        return position;
    }

    public Class<T> getParameterType() {
        return parameterType;
    }
}
