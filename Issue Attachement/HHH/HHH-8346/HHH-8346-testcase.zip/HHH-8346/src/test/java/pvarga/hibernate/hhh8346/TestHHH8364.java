package pvarga.hibernate.hhh8346;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Parameter;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Test cases for HHH-8346. Needs a Derby sample DB.
 *
 * @author pvarga
 */
public class TestHHH8364 {

    private EntityManagerFactory emf;
    private EntityManager em;
    private TypedQuery<Customer> query;

    @Before
    public void setUp() {
        emf = Persistence.createEntityManagerFactory("hhh8346");
        em = emf.createEntityManager();
        query = em.createQuery("SELECT c FROM Customer c WHERE c.name = :name", Customer.class);
    }

    @After
    public void tearDown() {
        em.close();
    }

    /**
     * This will succeed.
     */
    @Test
    public void testWithParameterName() {
        query.setParameter("name", "New Enterprises");
        List<Customer> customers = query.getResultList();
        for (Customer c : customers) {
            System.out.println("found customer: " + c.getName());
        }
    }

    /**
     * This will fail with IllegalArgumentException.
     */
    @Test
    public void testWithParameterObject() {
        Parameter<String> nameParam = new ParameterImpl<String>("name", null, String.class);
        query.setParameter(nameParam, "New Enterprises");
        List<Customer> customers = query.getResultList();
        for (Customer c : customers) {
            System.out.println("found customer: " + c.getName());
        }
    }
}
