package uk.me.krupa.enversdefect;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import uk.me.krupa.enversdefect.entities.ContainerEntity;
import uk.me.krupa.enversdefect.entities.RelatedEntity;
import uk.me.krupa.enversdefect.entities.EntityProcessingService;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;

/**
 * @author krupagj
 *         Date: 16/09/11
 *         Time: 10:51
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/spring-config.xml" })
public class SampleFailureTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(SampleFailureTest.class);

    @Autowired
    private EntityProcessingService entityProcessingService;

    @Autowired
    JpaTransactionManager transactionManager;

        @PersistenceContext
	private transient EntityManager em;

    public void setEntityProcessingService(EntityProcessingService entityProcessingService) {
        this.entityProcessingService = entityProcessingService;
    }

    @Before
    public void init() {
    }

    @Test
    @Rollback(false)
    public void sampleFailure() {
        TransactionStatus tx = transactionManager.getTransaction(null);
        LOGGER.info("Creating the initial structure");
        ContainerEntity container = new ContainerEntity();
        container.setId(1L);
        container.setData("I am the container");

        RelatedEntity parent = new RelatedEntity();
        parent.setId(1L);
        parent.setData("I am the parent");
        parent.setChildren(new ArrayList<RelatedEntity>());
        parent.getChildren().add(parent);
        parent.setParent(parent);

        RelatedEntity child = new RelatedEntity();
        child.setId(2L);
        child.setData("I am the child");
        child.setParent(parent);
        parent.getChildren().add(child);

        container.setRelatedEntities(new ArrayList<RelatedEntity>());
        container.getRelatedEntities().add(parent);
        container.getRelatedEntities().add(child);
        child.setContainer(container);
        parent.setContainer(container);

        entityProcessingService.createEntities(container);
        transactionManager.commit(tx);

        tx = transactionManager.getTransaction(null);
        LOGGER.info("Loading and updating 1");
        ContainerEntity loaded = entityProcessingService.retrieve(1L);
        Assert.assertNotNull(loaded);
        loaded.getRelatedEntities().get(0).setData("I am still the parent");
        loaded.setData("I am still the container");
        entityProcessingService.createEntities(container);
        transactionManager.commit(tx);

        tx = transactionManager.getTransaction(null);
        LOGGER.info("Loading and updating 2");
        loaded = entityProcessingService.retrieve(1L);
        loaded.getRelatedEntities().get(0).setData("I am still the parent 2");
        loaded.setData("I am still the container 2");
        RelatedEntity intendedParent = loaded.getRelatedEntities().get(0);
        RelatedEntity child2 = new RelatedEntity();
        child2.setId(3L);
        child2.setData("I am the imposter");
        child2.setParent(intendedParent);
        intendedParent.getChildren().add(child2);
        loaded.getRelatedEntities().add(child2);
        entityProcessingService.createEntities(loaded);
        transactionManager.commit(tx);

        tx = transactionManager.getTransaction(null);
        LOGGER.info("Retrieving previous version");
        ContainerEntity oldOne = entityProcessingService.retrievePreviousVersion(1L);
        transactionManager.rollback(tx);
    }

}
