package uk.me.krupa.enversdefect.entities;

import org.apache.commons.collections.ComparatorUtils;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import uk.me.krupa.enversdefect.entities.ContainerEntity;
import uk.me.krupa.enversdefect.entities.RelatedEntity;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.awt.*;
import java.util.*;
import java.util.List;

/**
 * @author krupagj
 *         Date: 16/09/11
 *         Time: 11:23
 */
public class EntityProcessingService {

    @PersistenceContext
	private transient EntityManager em;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void createEntities(ContainerEntity entity) {
        em.merge(entity);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public ContainerEntity retrieve(Long id) {
        ContainerEntity c = em.find(ContainerEntity.class, id);
        if (c != null) {
            c.getRelatedEntities().size();
            for (RelatedEntity rel: c.getRelatedEntities()) {
                if (rel.getChildren() != null) {
                    rel.getChildren().size();
                }
            }
        }
        return c;
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public ContainerEntity retrievePreviousVersion(Long id) {
        AuditReader ar = AuditReaderFactory.get(em);
        List<Number> revisionIds = ar.getRevisions(ContainerEntity.class, id);
        Collections.sort(revisionIds, ComparatorUtils.naturalComparator());
        final Number previousRevisionId = revisionIds.get(revisionIds.size() - 2);
        ContainerEntity c = ar.find(ContainerEntity.class, id, previousRevisionId);
        if (c != null) {
            c.getRelatedEntities().size();
            for (RelatedEntity rel: c.getRelatedEntities()) {
                if (rel.getChildren() != null) {
                    rel.getChildren().size();
                }
            }
        }
        return c;
    }

}
