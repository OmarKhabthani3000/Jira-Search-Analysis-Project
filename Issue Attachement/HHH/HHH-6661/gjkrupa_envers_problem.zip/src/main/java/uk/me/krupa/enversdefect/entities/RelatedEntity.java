package uk.me.krupa.enversdefect.entities;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;

import javax.persistence.*;
import javax.swing.*;
import java.io.Serializable;
import java.util.List;

/**
 * @author krupagj
 *         Date: 16/09/11
 *         Time: 10:42
 */
@Entity
@Table(name="RELATED_ENTITY")
@Audited
public class RelatedEntity implements Serializable {

    @Id
    @Column(name="ID")
    private Long id;

    @OneToOne
    private ContainerEntity container;

    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @AuditJoinTable(name = "RELATED_REL", inverseJoinColumns = { @JoinColumn(name = "ID_PARENT", nullable = true, updatable = false) })
    @JoinTable(name = "RELATED_REL", joinColumns = { @JoinColumn(name = "ID_CHILD", nullable = true, updatable = false) }, inverseJoinColumns = { @JoinColumn(name = "ID_PARENT", nullable = true, updatable = false) })
    private RelatedEntity parent;

    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL)
    private List<RelatedEntity> children;

    @Column(name="SOME_DATA")
    @Audited
    private String data;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public RelatedEntity getParent() {
        return parent;
    }

    public void setParent(RelatedEntity parent) {
        this.parent = parent;
    }

    public List<RelatedEntity> getChildren() {
        return children;
    }

    public void setChildren(List<RelatedEntity> children) {
        this.children = children;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public ContainerEntity getContainer() {
        return container;
    }

    public void setContainer(ContainerEntity container) {
        this.container = container;
    }
}
