package uk.me.krupa.enversdefect.entities;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * @author krupagj
 *         Date: 16/09/11
 *         Time: 10:39
 */
@Entity
@Table(name="CONTAINER_ENTITY")
@Audited
public class ContainerEntity implements Serializable {
    @Id
    @Column(name="ID")
    @Audited(targetAuditMode = RelationTargetAuditMode.AUDITED)
    private Long id;

    @OneToMany(mappedBy="container", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    @Audited(targetAuditMode = RelationTargetAuditMode.AUDITED)
    private List<RelatedEntity> relatedEntities;

    @Column(name="SOME_DATA")
    @Audited
    private String data;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<RelatedEntity> getRelatedEntities() {
        return relatedEntities;
    }

    public void setRelatedEntities(List<RelatedEntity> relatedEntities) {
        this.relatedEntities = relatedEntities;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
