// $Id: $
package com.webmd.testbrokenhibernate;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Map;
import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

/**
 * @author bgoudreault
 *
 */
public class TestEntityTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		final AnnotationConfiguration configuration = new AnnotationConfiguration();
		final InputStream is = TestEntityTester.class.getResourceAsStream("/jdbc.properties");
		final Properties props = new Properties();
		try {
	        props.load(is);
        } catch(IOException e) {
	        e.printStackTrace();
        }
		configuration.addProperties(props);
		configuration.configure();
		final SessionFactory factory = configuration.buildSessionFactory();
		final Session session = factory.openSession();
		final Map roleMap = Collections.singletonMap("editor", new AccessPeriod(null, null));
		TestEntity test = new TestEntity(roleMap);
		session.save(test);
		session.flush();
		session.clear();
		
		// reload
		TestEntity test2 = (TestEntity) session.load(TestEntity.class, test.getId());
		System.out.println(test2.getRoleAccesses().size());
		test(1 == test2.getRoleAccesses().size()); // <---- FAILS HERE
		final AccessPeriod ap = test2.getRoleAccesses().get("editor");
		test(ap != null);
		test(ap.getActiveDate() == null);
		test(ap.getExpirationDate() == null);
	}

	private static void test(boolean condition) {
		if(!condition)
			throw new RuntimeException("Bad");
	}
}
