// $Id: $
package com.webmd.testbrokenhibernate;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Embeddable;

@Embeddable
public class AccessPeriod implements Serializable {
	private Date expirationDate;
	private Date activeDate;
	
	public AccessPeriod(Date activeDate, Date expirationDate) {
	    this.expirationDate = expirationDate;
	    this.activeDate = activeDate;
    }
	
	AccessPeriod() {}
	
	public Date getExpirationDate() {
    	return expirationDate;
    }
	public void setExpirationDate(Date expirationDate) {
    	this.expirationDate = expirationDate;
    }
	public Date getActiveDate() {
    	return activeDate;
    }
	public void setActiveDate(Date activeDate) {
    	this.activeDate = activeDate;
    }
	@Override
    public int hashCode() {
	    final int prime = 31;
	    int result = 1;
	    result = prime * result + ((expirationDate == null) ? 0 : expirationDate.hashCode());
	    result =
	            prime * result
	                    + ((activeDate == null) ? 0 : activeDate.hashCode());
	    return result;
    }
	@Override
    public boolean equals(Object obj) {
	    if(this == obj) return true;
	    if(obj == null) return false;
	    if(getClass() != obj.getClass()) return false;
	    AccessPeriod other = (AccessPeriod) obj;
	    if(expirationDate == null) {
		    if(other.expirationDate != null) return false;
	    } else if(!expirationDate.equals(other.expirationDate)) return false;
	    if(activeDate == null) {
		    if(other.activeDate != null) return false;
	    } else if(!activeDate.equals(other.activeDate)) return false;
	    return true;
    }
	
}
