// $Id: $
package com.webmd.testbrokenhibernate;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.CollectionOfElements;

@Entity
public class TestEntity {
	@Id
	private int id;
	@CollectionOfElements
	private Map<String, AccessPeriod> roleAccesses = new HashMap<String, AccessPeriod>();
	
	public TestEntity(Map<String, AccessPeriod> roleAccesses) {
		this.roleAccesses = roleAccesses;
	}
	
	protected TestEntity() {}
	

    public Map<String, AccessPeriod> getRoleAccesses() {
		return roleAccesses;
	}
	
    protected void setRoleAccesses(Map<String, AccessPeriod> roleAccesses) {
		this.roleAccesses = roleAccesses;
	}

	public int getId() {
    	return id;
    }

	protected void setId(int id) {
    	this.id = id;
    }

	public void resetRoleAccesses(Map<String, AccessPeriod> roleAccesses) {
    	getRoleAccesses().clear();
    	if(roleAccesses != null)
    		getRoleAccesses().putAll(roleAccesses);
    }
}
