package test.mdlandon;

import org.hibernate.*;
import org.hibernate.cfg.*;

import java.sql.Connection;

/**
 * Basic Hibernate helper class, handles SessionFactory, Session and Transaction.
 * <p>
 * Uses a static initializer for the initial SessionFactory creation
 * and holds Session and Transactions in thread local variables. All
 * exceptions are wrapped in an unchecked InfrastructureException.
 *
 * @author christian@hibernate.org
 */
public class HibernateUtil {
    
    private static Configuration configuration;
    private static SessionFactory sessionFactory;
    private static final ThreadLocal threadSession = new ThreadLocal();
    private static final ThreadLocal threadTransaction = new ThreadLocal();
    private static final ThreadLocal threadInterceptor = new ThreadLocal();
    
    // Create the initial SessionFactory from the default configuration files
    static {
        try {
//			configuration = new AnnotationConfiguration();
            configuration = new Configuration();
            sessionFactory = configuration.configure().buildSessionFactory();
            // We could also let Hibernate bind it to JNDI:
            // configuration.configure().buildSessionFactory()
        } catch (Throwable ex) {
            // We have to catch Throwable, otherwise we will miss
            // NoClassDefFoundError and other subclasses of Error
            System.err.println("Building SessionFactory failed: " + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }
    
    /**
     * Returns the SessionFactory used for this static class.
     *
     * @return SessionFactory
     */
    public static SessionFactory getSessionFactory() {
                /* Instead of a static variable, use JNDI:
                SessionFactory sessions = null;
                try {
                        Context ctx = new InitialContext();
                        String jndiName = "java:hibernate/HibernateFactory";
                        sessions = (SessionFactory)ctx.lookup(jndiName);
                } catch (NamingException ex) {
                        throw new InfrastructureException(ex);
                }
                return sessions;
                 */
        return sessionFactory;
    }
    
    /**
     * Returns the original Hibernate configuration.
     *
     * @return Configuration
     */
    public static Configuration getConfiguration() {
        return configuration;
    }
    
    /**
     * Rebuild the SessionFactory with the static Configuration.
     *
     */
    public static void rebuildSessionFactory()
    throws Exception {
        synchronized(sessionFactory) {
            try {
                sessionFactory = getConfiguration().buildSessionFactory();
            } catch (Exception ex) {
                throw ex;
            }
        }
    }
    
    /**
     * Rebuild the SessionFactory with the given Hibernate Configuration.
     *
     * @param cfg
     */
    public static void rebuildSessionFactory(Configuration cfg)
    throws Exception {
        synchronized(sessionFactory) {
            try {
                sessionFactory = cfg.buildSessionFactory();
                configuration = cfg;
            } catch (Exception ex) {
                throw ex;
            }
        }
    }
    
    /**
     * Retrieves the current Session local to the thread.
     * <p/>
     * If no Session is open, opens a new Session for the running thread.
     *
     * @return Session
     */
    public static Session getSession()
    throws Exception {
        return getSession(null);
    }
    
    /**
     * Retrieves the current Session local to the thread.
     * <p/>
     * If no Session is open, opens a new Session for the running thread w/
     * the given Connection (if given).
     *
     * @param c dB Connection to use w/ Session.  If null, a connection will
     *          be provided by Hibernate's pool.
     * @return Session
     */
    private static Session getSession(Connection c)
    throws Exception {
        Session s = (Session) threadSession.get();
        try {
            if (s == null) {
                System.out.println("Opening new Session for this thread.");
                System.out.println("Provided connection: " + c);
                Interceptor i = getInterceptor();
                if (i != null) {
                    System.out.println("Using interceptor: " + i.getClass());
                    if(c == null) s = getSessionFactory().openSession(i);
                    else s = getSessionFactory().openSession(c, i);
                }
                else {
                    if(c == null) s = getSessionFactory().openSession();
                    else s = getSessionFactory().openSession(c);
                } // end if-else
                threadSession.set(s);
            }
        } catch (HibernateException ex) {
            throw ex;
        }
        return s;
    }
    
    /**
     * Closes the Session local to the thread.
     */
    public static void closeSession()
    throws Exception {
        try {
            Session s = (Session) threadSession.get();
            threadSession.set(null);
            commitTransaction();
            if (s != null && s.isOpen()) {
                System.out.println("Closing Session of this thread.");
                s.close();
            }
        } catch (HibernateException ex) {
            throw ex;
        }
    }
    
    /**
     * Start a new database transaction.
     */
    public static void beginTransaction()
    throws Exception {
        beginTransaction(null);
    }
    
    /**
     * Start a new database transaction w/ given Connection (if any)
     */
    public static void beginTransaction(Connection c)
    throws Exception {
        Transaction tx = (Transaction) threadTransaction.get();
        try {
            if (tx == null) {
                System.out.println("Starting new database transaction in this thread.");
                tx = getSession(c).beginTransaction();
                threadTransaction.set(tx);
            }
        } catch (HibernateException ex) {
            throw ex;
        }
    }
    
    /**
     * Commit the database transaction.
     */
    public static void commitTransaction()
    throws Exception {
        Transaction tx = (Transaction) threadTransaction.get();
        try {
            if ( tx != null && !tx.wasCommitted() && !tx.wasRolledBack() ) {
                System.out.println("Committing database transaction of this thread.");
                tx.commit();
            }
            threadTransaction.set(null);
        } catch (HibernateException ex) {
            rollbackTransaction();
            throw ex;
        }
    }
    
    /**
     * Rollback the database transaction.
     */
    public static void rollbackTransaction()
    throws Exception {
        Transaction tx = (Transaction) threadTransaction.get();
        try {
            threadTransaction.set(null);
            if ( tx != null && !tx.wasCommitted() && !tx.wasRolledBack() ) {
                System.out.println("Tyring to rollback database transaction of this thread.");
                tx.rollback();
            }
        } catch (HibernateException ex) {
            throw ex;
        } finally {
            closeSession();
        }
    }
    
    /**
     * Register a Hibernate interceptor with the current thread.
     * <p>
     * Every Session opened is opened with this interceptor after
     * registration. Has no effect if the current Session of the
     * thread is already open, effective on next close()/getSession().
     */
    public static void registerInterceptor(Interceptor interceptor) {
        threadInterceptor.set(interceptor);
    }
    
    private static Interceptor getInterceptor() {
        Interceptor interceptor =
                (Interceptor) threadInterceptor.get();
        return interceptor;
    }
    
}

