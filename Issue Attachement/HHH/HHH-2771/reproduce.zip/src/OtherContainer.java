package test.mdlandon; 

public class OtherContainer { 
   private Long otherId;
   private String name;
   private ZonesContainer zone;
   public Long getOtherId() { 
      return otherId; 
   } 
   public void setOtherId(Long otherId) { 
      this.otherId = otherId; 
   } 
   public String getName() { 
      return name; 
   } 
   public void setName(String name) { 
      this.name = name; 
   } 
   public ZonesContainer getZone() { 
      return zone; 
   } 
   public void setZone(ZonesContainer zone) { 
      this.zone = zone; 
   } 
    
} 