package test.mdlandon; 

import java.util.Set; 

public class ZonesContainer { 
   private Long zoneId; 
   private String name;
   private Set zones; 
   private Set others; 
   public Long getZoneId() { 
      return zoneId; 
   } 
   public void setZoneId(Long zoneId) { 
      this.zoneId = zoneId; 
   } 
   public String getName() { 
      return name; 
   } 
   public void setName(String name) { 
      this.name = name; 
   } 
   public Set getZones() { 
      return zones; 
   } 
   public void setZones(Set zones) { 
      this.zones = zones; 
   } 
   public Set getOthers() { 
      return others; 
   } 
   public void setOthers(Set others) { 
      this.others = others; 
   } 
    
} 