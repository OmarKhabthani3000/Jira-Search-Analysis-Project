package test.mdlandon; 

import java.util.HashSet; 
import java.util.List; 
import java.util.Set; 

import org.hibernate.Query; 
import org.hibernate.Session; 

public class TestIt { 
    
   public void testIt() throws Exception { 
      Session s = HibernateUtil.getSession(); 
      Query q = s.createQuery("from ZonesContainer as zc left join fetch zc.others left join fetch zc.zones"); 
      List result = q.list(); 
      System.out.println("result size="+result.size()); 
      ZonesContainer zc = (ZonesContainer)result.get(0); 
      System.out.println(""+zc.getZones()); 
      System.out.println(""+zc.getOthers()); 
      s.close(); 
   } 

   public static void main (String args[]) throws Exception {
       TestIt it = new TestIt();
       it.testIt();
   }

} 
