package bug.db;

import java.io.Serializable;

/**
 * @author James.Norton.Ctr
 */
public class ImmutableTest implements Serializable {
    /**
	 * 
	 */
    private static final long serialVersionUID = 2284319297733168902L;
    private String field1 = "abc";
    private String field2 = "def";
    private String field3 = "ghi";
    private Integer id;

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        ImmutableTest other = (ImmutableTest) obj;
        if (field1 == null) {
            if (other.field1 != null) {
                return false;
            }
        } else if (!field1.equals(other.field1)) {
            return false;
        }
        if (field2 == null) {
            if (other.field2 != null) {
                return false;
            }
        } else if (!field2.equals(other.field2)) {
            return false;
        }
        if (field3 == null) {
            if (other.field3 != null) {
                return false;
            }
        } else if (!field3.equals(other.field3)) {
            return false;
        }
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    /**
     * @return the field1
     */
    public String getField1() {
        return field1;
    }

    /**
     * @return the field2
     */
    public String getField2() {
        return field2;
    }

    /**
     * @return the field3
     */
    public String getField3() {
        return field3;
    }

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((field1 == null) ? 0 : field1.hashCode());
        result = prime * result + ((field2 == null) ? 0 : field2.hashCode());
        result = prime * result + ((field3 == null) ? 0 : field3.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /**
     * @param field1
     *            the field1 to set
     */
    public void setField1(String field1) {
        this.field1 = field1;
    }

    /**
     * @param field2
     *            the field2 to set
     */
    public void setField2(String field2) {
        this.field2 = field2;
    }

    /**
     * @param field3
     *            the field3 to set
     */
    public void setField3(String field3) {
        this.field3 = field3;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("MutableTest [field1=");
        builder.append(field1);
        builder.append(", field2=");
        builder.append(field2);
        builder.append(", field3=");
        builder.append(field3);
        builder.append(", id=");
        builder.append(id);
        builder.append("]");
        return builder.toString();
    }
}
