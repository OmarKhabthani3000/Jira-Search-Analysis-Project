/**
 * 
 */
package bug;

import java.io.PrintWriter;
import java.io.StringWriter;

import junit.framework.Test;
import junit.framework.TestCase;

import org.hibernate.Criteria;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import bug.db.ImmutableTest;
import bug.db.MutableTest;

/**
 * @author James.Norton.Ctr
 */
public class BugReportTestCase extends FunctionalTestCase {

    public final static class OrderedTest extends TestCase {

        public OrderedTest() {
            super();
        }

        public OrderedTest(String name) {
            super(name);
        }

        public void testOrderedTest() {
            assertTrue("I want to control the order of the test suite", true);
        }

    }

    private static final Logger log = LoggerFactory.getLogger(BugReportTestCase.class);

    public static Test suite() {
        final FunctionalTestClassTestSuite testSuite = new FunctionalTestClassTestSuite(OrderedTest.class, BugReportTestCase.class.getName());
        testSuite.addTest(new BugReportTestCase("testSaveMutable"));
        testSuite.addTest(new BugReportTestCase("testSaveImmutable"));
        testSuite.addTest(new BugReportTestCase("testMutableSaved"));
        testSuite.addTest(new BugReportTestCase("testImmutableSaved"));
        testSuite.addTest(new BugReportTestCase("testRefreshTransientMutable"));
        testSuite.addTest(new BugReportTestCase("testRefreshTransientImmutable"));
        return testSuite;
    }

    private ImmutableTest immutableTest;

    private MutableTest mutableTest;

    /**
     * @param string
     */
    public BugReportTestCase(String string) {
        super(string);
    }

    /*
     * (non-Javadoc)
     * @see
     * org.hibernate.junit.functional.FunctionalTestCase#getBaseForMappings()
     */
    @Override
    public String getBaseForMappings() {
        return "bug/db/mapping/";
    }

    /**
     * @return the immutableTest
     */
    public ImmutableTest getImmutableTest() {
        return immutableTest;
    }

    @Override
    public String[] getMappings() {
        String[] mapping = new String[] {
            "ImmutableTest.hbm.xml", "MutableTest.hbm.xml"
        };
        return mapping;
    }

    /**
     * @return the mutableTest
     */
    public MutableTest getMutableTest() {
        return mutableTest;
    }

    /**
     * @param immutableTest
     *            the immutableTest to set
     */
    public void setImmutableTest(ImmutableTest immutableTest) {
        this.immutableTest = immutableTest;
    }

    /**
     * @param mutableTest
     *            the mutableTest to set
     */
    public void setMutableTest(MutableTest mutableTest) {
        this.mutableTest = mutableTest;
    }

    public void testImmutableSaved() {
        Session session = openSession();
        final Criteria criteria = session.createCriteria(ImmutableTest.class);
        setImmutableTest((ImmutableTest) criteria.uniqueResult());
        assertNotNull("ImmutableTest should exist", getImmutableTest());
        session.close();
    }

    public void testMutableSaved() {
        Session session = openSession();
        final Criteria criteria = session.createCriteria(MutableTest.class);
        setMutableTest((MutableTest) criteria.uniqueResult());
        assertNotNull("MutableTest should exist", getMutableTest());
        session.close();
    }

    public void testRefreshTransientImmutable() {
        testImmutableSaved();
        Session session = openSession();
        try {
            session.refresh(getImmutableTest());
        } catch (Exception e) {
            StringWriter stringWriter = new StringWriter();
            PrintWriter printWriter = new PrintWriter(stringWriter);
            e.printStackTrace(printWriter);
            log.error(stringWriter.toString());
            printWriter.close();
            fail("This test failed because org.hibernate.event.def.DefaultRefreshEventListener tried to set the readonly state of the transient object to source.isDefaultReadOnly()");
        } finally {
            session.close();
        }
    }

    public void testRefreshTransientMutable() {
        testMutableSaved();
        Session session = openSession();
        try {
            session.refresh(getMutableTest());
            assertTrue("This test succeeded because the Mutable Object allows to have its readonly set", true);
        } catch (Exception e) {
            StringWriter stringWriter = new StringWriter();
            PrintWriter printWriter = new PrintWriter(stringWriter);
            e.printStackTrace(printWriter);
            log.error(stringWriter.toString());
            printWriter.close();
            fail("An unexpected Exception occurred");
        } finally {
            session.close();
        }
    }

    public void testSaveImmutable() {
        ImmutableTest immutable = new ImmutableTest();
        Session session = openSession();
        Transaction transaction = session.beginTransaction();
        session.save(immutable);
        transaction.commit();
        assertNotNull("Saved", session.getIdentifier(immutable));
        session.close();
    }

    public void testSaveMutable() {
        MutableTest mutable = new MutableTest();
        Session session = openSession();
        Transaction transaction = session.beginTransaction();
        session.save(mutable);
        transaction.commit();
        assertNotNull("Saved", session.getIdentifier(mutable));
        session.close();
    }

}
