package com.example.demo.domain;

import javax.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@Entity
public class Entity2 extends AbstractEntity {
  public Entity2(long id, String name) {
    super(id, name);
  }
}
