package com.example.demo.domain;

import javax.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Entity
public class Entity1 extends AbstractEntity {
  public Entity1(long id, String name) {
    super(id, name);
  }
}
