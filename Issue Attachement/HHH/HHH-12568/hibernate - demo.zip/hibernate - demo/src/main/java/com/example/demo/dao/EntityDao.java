package com.example.demo.dao;

import com.example.demo.domain.AbstractEntity;
import java.util.List;
import java.util.Set;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Transactional
public interface EntityDao extends JpaRepository<AbstractEntity, Long> {

  @Query("SELECT e FROM AbstractEntity e WHERE e.class = :type OR :type IS null")
  List<AbstractEntity> findByClass(@Param("type") String type);

   /*IndexOutOfBoundsException during bootstrap
  @Query("SELECT e FROM AbstractEntity e WHERE TYPE(e) = :type")
  List<AbstractEntity> findByTypeClass(@Param("type") Class type);*/

  @Query("SELECT e FROM AbstractEntity e WHERE TYPE(e) = :type OR :type IS null")
  List<AbstractEntity> findByTypeString(@Param("type") String type);

  @Query("SELECT e FROM AbstractEntity e WHERE TYPE(e) IN (:type)")
  List<AbstractEntity> findByClassIn(@Param("type") Iterable<Class> type);

  @Query("SELECT e FROM AbstractEntity e WHERE :type IS NULL OR (:type IS NOT NULL AND TYPE(e) IN (:type))")
  List<AbstractEntity> findByClassInNullSafe(@Param("type") Iterable<Class> type);

}
