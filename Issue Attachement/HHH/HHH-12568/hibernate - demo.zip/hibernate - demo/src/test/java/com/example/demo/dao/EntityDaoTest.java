package com.example.demo.dao;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.*;

import com.example.demo.domain.AbstractEntity;
import com.example.demo.domain.Entity1;
import com.example.demo.domain.Entity2;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

@DataJpaTest
@RunWith(SpringRunner.class)
public class EntityDaoTest {
  @Autowired
  private EntityDao dao;

  @Test
  public void shouldFindByClass() {
    //given
    AbstractEntity entity1 = new Entity1(1, "entity1");
    AbstractEntity entity2 = new Entity2(2, "entity2");
    dao.saveAll(Arrays.asList(entity1, entity2));
    //when
    List<AbstractEntity> all = dao.findByClass(null);
    List<AbstractEntity> filtered = dao.findByClass("Entity1"); //InvalidDataAccessApiUsageException when anything but SINGLE_TABLE strategy is used
    //then
    assertEquals(all.size(), 2);
    assertEquals(filtered.size(), 1);
    assertThat(filtered.get(0), equalTo(entity1));
  }

  @Test
  public void shouldFindByClassIn() {
    //given
    AbstractEntity entity1 = new Entity1(1, "entity1");
    AbstractEntity entity2 = new Entity2(2, "entity2");
    dao.saveAll(Arrays.asList(entity1, entity2));
    //when
    List<AbstractEntity> all = dao.findAll();
    List<AbstractEntity> filtered = dao.findByClassIn(Arrays.asList(Entity1.class));
    //then
    assertEquals(all.size(), 2);
    assertEquals(filtered.size(), 1);
    assertThat(filtered.get(0), equalTo(entity1));
  }

  @Test
  public void shouldFindByClassInNull() {
    //given
    AbstractEntity entity1 = new Entity1(1, "entity1");
    AbstractEntity entity2 = new Entity2(2, "entity2");
    dao.saveAll(Arrays.asList(entity1, entity2));
    //when
    List<AbstractEntity> filtered = dao.findByClassInNullSafe(Arrays.asList(Entity1.class));
    List<AbstractEntity> all = dao.findByClassInNullSafe(null); //NullPointerException
    //then
    assertEquals(all.size(), 2);
    assertEquals(filtered.size(), 1);
    assertThat(filtered.get(0), equalTo(entity1));
  }

  @Test
  public void shouldFindByType() {
    //given
    AbstractEntity entity1 = new Entity1(1, "entity1");
    AbstractEntity entity2 = new Entity2(2, "entity2");
    dao.saveAll(Arrays.asList(entity1, entity2));
    //when
    List<AbstractEntity> filtered = dao.findByTypeString("Entity1"); //IllegalArgumentException
    List<AbstractEntity> all = dao.findByTypeString(null); //NullPointerException when TABLE_PER_CLASS strategy is used
    //then
    assertEquals(all.size(), 2);
    assertEquals(filtered.size(), 1);
    assertThat(filtered.get(0), equalTo(entity1));
  }

}