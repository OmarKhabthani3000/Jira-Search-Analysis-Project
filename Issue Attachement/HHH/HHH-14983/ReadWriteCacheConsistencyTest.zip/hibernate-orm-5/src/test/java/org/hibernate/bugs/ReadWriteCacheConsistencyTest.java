/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.cache.ehcache.ConfigSettings;
import org.hibernate.cache.spi.access.AccessType;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;

import org.hibernate.testing.TestForIssue;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.hibernate.testing.transaction.TransactionUtil;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * This test illustrates the issue with the strong consistency guarantees when using Hibernate second-level
 * cache and {@link CacheConcurrencyStrategy#READ_WRITE read-write} concurrency strategy.
 *
 * @autor Nikola Bekcic
 */
public class ReadWriteCacheConsistencyTest extends BaseCoreFunctionalTestCase {
	private static final Long TEST_USER_ID = 1L;

	@Override
	protected boolean rebuildSessionFactoryOnError() {
		return false;
	}

	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
				User.class
		};
	}

	@Override
	protected String getCacheConcurrencyStrategy() {
		return AccessType.READ_WRITE.getExternalName();
	}

	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );

		configuration.setProperty( AvailableSettings.USE_SECOND_LEVEL_CACHE, Boolean.TRUE.toString() );
		configuration.setProperty( AvailableSettings.CACHE_REGION_FACTORY, "ehcache" );
		configuration.setProperty( ConfigSettings.EHCACHE_CONFIGURATION_RESOURCE_NAME, "ehcache-configuration.xml" );

		configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, Boolean.TRUE.toString() );

		configuration.setProperty( AvailableSettings.SHOW_SQL, Boolean.TRUE.toString() );
		configuration.setProperty( AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString() );
	}

	@Before
	public void setUp() {
		User user = new User( TEST_USER_ID, "initial_user_name" );

		TransactionUtil.doInHibernate( this::sessionFactory, session -> {
			log.infof( "Saving '%s' in the DB before running tests", user );
			session.save( user );
		} );

		assertTrue( sessionFactory().getCache().containsEntity( User.class, TEST_USER_ID ) );
	}

	@Test
	@TestForIssue(jiraKey = "HHH-14983")
	public void testEntityLoadUponHQLUpdate() {

		TransactionUtil.doInHibernate( this::sessionFactory, session -> {
			log.info( "Updating user using HQL..." );

			String newUserName = "new_user_name";

			boolean isUserUpdated = session.createQuery( "update User set name = :name where id = :id" )
					.setParameter( "name", newUserName )
					.setParameter( "id", TEST_USER_ID )
					.executeUpdate() == 1;

			assertTrue( isUserUpdated );

			User user = session.load( User.class, TEST_USER_ID );

			assertEquals( newUserName, user.getName() );
		} );
	}


	@Entity(name = "User")
	@Cacheable
	@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "Users")
	private static class User {

		@Id
		private Long id;

		private String name;

		public User() {
		}

		public User(Long id, String name) {
			this.id = id;
			this.name = name;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		@Override
		public String toString() {
			return "User{" + "id=" + id +
					", name='" + name + '\'' +
					'}';
		}
	}
}
