package com.myproject.entities.master;

import com.myproject.entities.IEntity;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NaturalId;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name ="users")
public class User implements IEntity
{
    public final static String USER_NAME_COLUMN = "user_name";

	protected User() {}
	
	public User(String username, String password, String namespace)
	{
		_username = username;
		_password = password;
		_namespace = namespace;
	}

    public User addRole(Roles role)
    {
        _roles.add(new Role(this, role));
        return this;
    }
	
	private String _username;
	private String _namespace;
	private String _password;

    private Set<Role> _roles = new HashSet<Role>();

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name=USER_NAME_COLUMN)
    @Fetch(value= FetchMode.JOIN)
    public Set<Role> getRoles() {
        return _roles;
    }

    public void setRoles(Set<Role> roles) {
        _roles = roles;
    }

    @Column(name=USER_NAME_COLUMN)
	@Id
    @NaturalId
	public String getUsername() 
	{
		return _username;
	}
	
	@Column(name="user_namespace", nullable = false)
	public String getNamespace() 
	{
		return _namespace;
	}
	public void setUsername(String _username) 
	{
		this._username = _username;
	}
	public void setNamespace(String _namespace) 
	{
		this._namespace = _namespace;
	}

	@Column(name="user_pass", nullable = false)
	public String getPassword() {
		return _password;
	}

	public void setPassword(String _password) {
		this._password = _password;
	}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        User user = (User) o;

        if (!_namespace.equals(user._namespace)) return false;
        if (!_username.equals(user._username)) return false;
        if (!_password.equals(user._password)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = _username.hashCode();
        return result;
    }
}
