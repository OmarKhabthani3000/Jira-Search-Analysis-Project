package com.myproject.entities.master;

import com.myproject.entities.IEntity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;

@Entity
@Table(name ="user_roles")
public class Role implements IEntity, Serializable
{
    protected Role() {}
	
	private Roles _role;
    private String _user;
	
	public Role(User user, Roles role)
	{
		_user = user.getUsername();
		_role = role;
	}

    @Id
    @Column(name=User.USER_NAME_COLUMN)
    public String getUser() {
        return _user;
    }

    public void setUser(String user) {
        _user = user;
    }
	
	@Column(name = "role_name")
    @Enumerated(value=EnumType.STRING)
    @Id
	public Roles getRole() {
		return _role;
	}

	public void setRole(Roles role)
    {
        _role = role;
	}

    @Transient
    public boolean isAdmin()
    {
        return _role == Roles.admin;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Role role = (Role) o;
        if (_role != role._role) return false;
        if (!_user.equals(role._user)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = _user.hashCode();
        result = 31 * result + _role.hashCode();
        return result;
    }

    public static boolean isAdmin(Collection<Role> roles)
    {
        for(Role role : roles)
            if(role.isAdmin())
                return true;

        return false;
    }
}
