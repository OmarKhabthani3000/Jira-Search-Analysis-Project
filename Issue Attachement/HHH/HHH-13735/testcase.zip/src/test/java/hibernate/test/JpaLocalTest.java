package hibernate.test;

import java.sql.DriverManager;
import java.util.function.Consumer;
import java.util.function.Function;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import hibernate.model.Association;
import hibernate.model.SubItem;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import hibernate.model.Item;


public class JpaLocalTest
{
    private EntityManagerFactory emf;

    @Test
    public void test1()
    {
        consume(em -> {
            SubItem topItem = new SubItem();
            topItem.setName("Y");
            topItem.setId(2L);
            em.persist(topItem);
            em.flush();

            em.detach(topItem);
            //topItem.setName("test");
            SubItem output = em.merge(topItem);
            em.flush();
        });
    }

    protected void consume(Consumer<EntityManager> consumer)
    {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try
        {
            tx.begin();
            consumer.accept(em);
            tx.commit();
        }
        catch(Exception e)
        {
            tx.rollback();
            throw e;
        }
        finally
        {
            if(em.isOpen())
            {
                em.close();
            }
        }
    }

    protected <T> T execute(Function<EntityManager, T> function)
    {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try
        {
            tx.begin();
            T result = function.apply(em);
            tx.commit();
            return result;
        }
        catch(Exception e)
        {
            tx.rollback();
            throw e;
        }
        finally
        {
            if(em.isOpen())
            {
                em.close();
            }
        }
    }

    @Before
    public void beforeClass()
    {
        emf = Persistence.createEntityManagerFactory("test");
    }

    @After
    public void afterClass()
    {
        if(emf != null && emf.isOpen())
        {
            emf.close();
        }

        try
        {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
            DriverManager.getConnection("jdbc:derby:memory:test;drop=true");
        }
        catch(Exception e)
        {
            //e.printStackTrace();
        }
    }
}
