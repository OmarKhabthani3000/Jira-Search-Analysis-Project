/*
 * ----------------------------------------------------------------------------
 * Copyright 2019 by PostFinance Ltd - all rights reserved
 * ----------------------------------------------------------------------------
 */

package hibernate.model;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.HashSet;
import java.util.Set;

@Entity
@DiscriminatorValue("subitem")
public class SubItem extends Item {

    @Id
    private Long id;

    @OneToMany(mappedBy = "lowerItem", cascade = { CascadeType.ALL }, orphanRemoval = true)
    private Set<Association> superAssociation = new HashSet<>();

    @OneToMany(mappedBy = "subItem")
    private Set<Item> superItems = new HashSet<>();

    public Set<Association> getSuperAssociation() {
        return superAssociation;
    }

    public void setSuperAssociation(Set<Association> superAssociation) {
        this.superAssociation = superAssociation;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
