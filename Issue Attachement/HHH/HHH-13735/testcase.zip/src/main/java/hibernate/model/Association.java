/*
 * ----------------------------------------------------------------------------
 * Copyright 2019 by PostFinance Ltd - all rights reserved
 * ----------------------------------------------------------------------------
 */

package hibernate.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="ASSOCIATION")
public class Association {

    @Id
    private Long id;

    @ManyToOne
    @JoinColumn(name = "LOWER_ITEM_ID")
    private Item lowerItem;

    @ManyToOne
    @JoinColumn(name = "UPPER_ITEM_ID")
    private Item upperItem;

    public Association() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Item getLowerItem() {
        return lowerItem;
    }

    public void setLowerItem(Item lowerItem) {
        this.lowerItem = lowerItem;
    }

    public Item getUpperItem() {
        return upperItem;
    }

    public void setUpperItem(Item upperItem) {
        this.upperItem = upperItem;
    }
}
