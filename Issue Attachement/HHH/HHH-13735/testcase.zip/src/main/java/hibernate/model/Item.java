package hibernate.model;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="ITEM")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "TYPE")
public class Item implements Serializable
{
    private static final long serialVersionUID = 1L;

    @Column(nullable = false)
    @LazyToOne(LazyToOneOption.NO_PROXY)
    private String name;

    @Id
    @Column(nullable = false)
    private Long id;

    @ManyToOne
    private SubItem subItem;

    @OneToMany(mappedBy = "upperItem", cascade = { CascadeType.ALL }, orphanRemoval = true)
    private Set<Association> lowerAssociation = new HashSet<>();

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Set<Association> getLowerAssociation() {
        return lowerAssociation;
    }

    public void setLowerAssociation(Set<Association> lowerAssociation) {
        this.lowerAssociation = lowerAssociation;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public SubItem getSubItem() {
        return subItem;
    }

    public void setSubItem(SubItem subItem) {
        this.subItem = subItem;
    }
}
