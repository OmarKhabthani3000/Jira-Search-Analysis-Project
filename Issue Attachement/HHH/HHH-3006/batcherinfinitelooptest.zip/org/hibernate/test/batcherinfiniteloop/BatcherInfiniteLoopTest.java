package com.sulake.danny.vmk;

import junit.framework.TestCase;
import org.hibernate.HibernateException;
import org.hibernate.Interceptor;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.jdbc.AbstractBatcher;
import org.hibernate.jdbc.ConnectionManager;
import org.hibernate.jdbc.Expectation;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.lib.legacy.ClassImposteriser;

import java.sql.*;
import java.math.BigDecimal;
import java.io.InputStream;
import java.io.Reader;
import java.util.Map;
import java.util.Calendar;
import java.util.ConcurrentModificationException;
import java.net.URL;

/**
 * JUnit test case to reproduce HHH-3006
 * http://opensource.atlassian.com/projects/hibernate/browse/HHH-3006
 * Note: this test case runs into an infinite loop if the bug is present
 * Date: 12.12.2007
 */
public class BatcherInfiniteLoopTest extends TestCase {

    private Mockery mockeryContext = new Mockery(){{
        setImposteriser(ClassImposteriser.INSTANCE);
    }};

    private PreparedStatement dummyStatement = new DummyPreparedStatement();

    private AbstractBatcher abstractBatcher;

    @Override
    protected void setUp() throws Exception {
        super.setUp();

        final ConnectionManager mockConnectionManager = mockeryContext.mock(ConnectionManager.class);
        final Interceptor mockInterceptor = mockeryContext.mock(Interceptor.class);
        final SessionFactoryImplementor mockSessionFactory = mockeryContext.mock(SessionFactoryImplementor.class);

        mockeryContext.checking(new Expectations() {{
            allowing(mockConnectionManager).getFactory(); will(returnValue(mockSessionFactory));
        }});

        abstractBatcher = new AbstractBatcher(mockConnectionManager, mockInterceptor) {
            protected void doExecuteBatch(PreparedStatement ps) throws SQLException, HibernateException {
            }

            public void addToBatch(Expectation expectation) throws SQLException, HibernateException {
            }
        };
    }

    public void testHHH3006() throws SQLException {
        // start thread that modifies HashSet while batcher is iterating over it
        ConcurrentModificationThread thread = new ConcurrentModificationThread();
        thread.setDaemon(true);
        thread.start();

        try {
            // give ConcurrentModificationThread some time to fill the resultSetsToClose HashSet
            Thread.sleep(500);
        } catch (InterruptedException e) {
            // ignore
        }
        try {
            abstractBatcher.closeStatements();
        } catch (ConcurrentModificationException e) {
            // this is actually fine as long as we don't run into an infinite loop!
        }
    }

    public static void main(String[] args) {
        BatcherInfiniteLoopTest test = new BatcherInfiniteLoopTest();
        try {
            test.setUp();
            test.testHHH3006();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    class ConcurrentModificationThread extends Thread {

        @Override
        public void run() {
            super.run();

            while (true) {
                if (abstractBatcher != null) {
                    try {
                        abstractBatcher.getResultSet(dummyStatement);
                    } catch (SQLException e) {
                        fail(e.getMessage());
                    }
                }
                try {
                    Thread.sleep(5);
                } catch (InterruptedException e) {
                    //
                }
            }
        }

    }

    // *** The only non-trivial method implementations after this point are
    // *** DummyPreparedStatement.executeQuery()
    // *** and DummyResultSet.close()

    class DummyPreparedStatement implements PreparedStatement {

        public ResultSet executeQuery() throws SQLException {
            return new DummyResultSet();
        }

        public int executeUpdate() throws SQLException {
            return 0;
        }

        public void setNull(int parameterIndex, int sqlType) throws SQLException {
        }

        public void setBoolean(int parameterIndex, boolean x) throws SQLException {
        }

        public void setByte(int parameterIndex, byte x) throws SQLException {
        }

        public void setShort(int parameterIndex, short x) throws SQLException {
        }

        public void setInt(int parameterIndex, int x) throws SQLException {
        }

        public void setLong(int parameterIndex, long x) throws SQLException {
        }

        public void setFloat(int parameterIndex, float x) throws SQLException {
        }

        public void setDouble(int parameterIndex, double x) throws SQLException {
        }

        public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
        }

        public void setString(int parameterIndex, String x) throws SQLException {
        }

        public void setBytes(int parameterIndex, byte x[]) throws SQLException {
        }

        public void setDate(int parameterIndex, Date x) throws SQLException {
        }

        public void setTime(int parameterIndex, Time x) throws SQLException {
        }

        public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {
        }

        public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
        }

        @Deprecated
        public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
        }

        public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {
        }

        public void clearParameters() throws SQLException {
        }

        public void setObject(int parameterIndex, Object x, int targetSqlType, int scale) throws SQLException {
        }

        public void setObject(int parameterIndex, Object x, int targetSqlType) throws SQLException {
        }

        public void setObject(int parameterIndex, Object x) throws SQLException {
        }

        public boolean execute() throws SQLException {
            return false;
        }

        public void addBatch() throws SQLException {
        }

        public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException {
        }

        public void setRef(int i, Ref x) throws SQLException {
        }

        public void setBlob(int i, Blob x) throws SQLException {
        }

        public void setClob(int i, Clob x) throws SQLException {
        }

        public void setArray(int i, Array x) throws SQLException {
        }

        public ResultSetMetaData getMetaData() throws SQLException {
            return null;
        }

        public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException {
        }

        public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException {
        }

        public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException {
        }

        public void setNull(int paramIndex, int sqlType, String typeName) throws SQLException {
        }

        public void setURL(int parameterIndex, URL x) throws SQLException {
        }

        public ParameterMetaData getParameterMetaData() throws SQLException {
            return null;
        }

        public ResultSet executeQuery(String sql) throws SQLException {
            return null;
        }

        public int executeUpdate(String sql) throws SQLException {
            return 0;
        }

        public void close() throws SQLException {
        }

        public int getMaxFieldSize() throws SQLException {
            return 0;
        }

        public void setMaxFieldSize(int max) throws SQLException {
        }

        public int getMaxRows() throws SQLException {
            return 0;
        }

        public void setMaxRows(int max) throws SQLException {
        }

        public void setEscapeProcessing(boolean enable) throws SQLException {
        }

        public int getQueryTimeout() throws SQLException {
            return 0;
        }

        public void setQueryTimeout(int seconds) throws SQLException {
        }

        public void cancel() throws SQLException {
        }

        public SQLWarning getWarnings() throws SQLException {
            return null;
        }

        public void clearWarnings() throws SQLException {
        }

        public void setCursorName(String name) throws SQLException {
        }

        public boolean execute(String sql) throws SQLException {
            return false;
        }

        public ResultSet getResultSet() throws SQLException {
            return null;
        }

        public int getUpdateCount() throws SQLException {
            return 0;
        }

        public boolean getMoreResults() throws SQLException {
            return false;
        }

        public void setFetchDirection(int direction) throws SQLException {
        }

        public int getFetchDirection() throws SQLException {
            return 0;
        }

        public void setFetchSize(int rows) throws SQLException {
        }

        public int getFetchSize() throws SQLException {
            return 0;
        }

        public int getResultSetConcurrency() throws SQLException {
            return 0;
        }

        public int getResultSetType() throws SQLException {
            return 0;
        }

        public void addBatch(String sql) throws SQLException {
        }

        public void clearBatch() throws SQLException {
        }

        public int[] executeBatch() throws SQLException {
            return new int[0];
        }

        public Connection getConnection() throws SQLException {
            return null;
        }

        public boolean getMoreResults(int current) throws SQLException {
            return false;
        }

        public ResultSet getGeneratedKeys() throws SQLException {
            return null;
        }

        public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException {
            return 0;
        }

        public int executeUpdate(String sql, int columnIndexes[]) throws SQLException {
            return 0;
        }

        public int executeUpdate(String sql, String columnNames[]) throws SQLException {
            return 0;
        }

        public boolean execute(String sql, int autoGeneratedKeys) throws SQLException {
            return false;
        }

        public boolean execute(String sql, int columnIndexes[]) throws SQLException {
            return false;
        }

        public boolean execute(String sql, String columnNames[]) throws SQLException {
            return false;
        }

        public int getResultSetHoldability() throws SQLException {
            return 0;
        }
    }

    class DummyResultSet implements ResultSet {

        public boolean next() throws SQLException {
            return false;
        }

        public void close() throws SQLException {
            try {
                // this is called by AbstractBatcher.closeStatements()
                // we create an artificial delay here so that ConcurrentModificationThread
                // has time to actually modify the resultSetsToClose HashSet.
                Thread.sleep(500);
            } catch (InterruptedException e) {
                // ignore
            }
        }

        public boolean wasNull() throws SQLException {
            return false;
        }

        public String getString(int columnIndex) throws SQLException {
            return null;
        }

        public boolean getBoolean(int columnIndex) throws SQLException {
            return false;
        }

        public byte getByte(int columnIndex) throws SQLException {
            return 0;
        }

        public short getShort(int columnIndex) throws SQLException {
            return 0;
        }

        public int getInt(int columnIndex) throws SQLException {
            return 0;
        }

        public long getLong(int columnIndex) throws SQLException {
            return 0;
        }

        public float getFloat(int columnIndex) throws SQLException {
            return 0;
        }

        public double getDouble(int columnIndex) throws SQLException {
            return 0;
        }

        @Deprecated
        public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException {
            return null;
        }

        public byte[] getBytes(int columnIndex) throws SQLException {
            return new byte[0];
        }

        public Date getDate(int columnIndex) throws SQLException {
            return null;
        }

        public Time getTime(int columnIndex) throws SQLException {
            return null;
        }

        public Timestamp getTimestamp(int columnIndex) throws SQLException {
            return null;
        }

        public InputStream getAsciiStream(int columnIndex) throws SQLException {
            return null;
        }

        @Deprecated
        public InputStream getUnicodeStream(int columnIndex) throws SQLException {
            return null;
        }

        public InputStream getBinaryStream(int columnIndex) throws SQLException {
            return null;
        }

        public String getString(String columnName) throws SQLException {
            return null;
        }

        public boolean getBoolean(String columnName) throws SQLException {
            return false;
        }

        public byte getByte(String columnName) throws SQLException {
            return 0;
        }

        public short getShort(String columnName) throws SQLException {
            return 0;
        }

        public int getInt(String columnName) throws SQLException {
            return 0;
        }

        public long getLong(String columnName) throws SQLException {
            return 0;
        }

        public float getFloat(String columnName) throws SQLException {
            return 0;
        }

        public double getDouble(String columnName) throws SQLException {
            return 0;
        }

        @Deprecated
        public BigDecimal getBigDecimal(String columnName, int scale) throws SQLException {
            return null;
        }

        public byte[] getBytes(String columnName) throws SQLException {
            return new byte[0];
        }

        public Date getDate(String columnName) throws SQLException {
            return null;
        }

        public Time getTime(String columnName) throws SQLException {
            return null;
        }

        public Timestamp getTimestamp(String columnName) throws SQLException {
            return null;
        }

        public InputStream getAsciiStream(String columnName) throws SQLException {
            return null;
        }

        @Deprecated
        public InputStream getUnicodeStream(String columnName) throws SQLException {
            return null;
        }

        public InputStream getBinaryStream(String columnName) throws SQLException {
            return null;
        }

        public SQLWarning getWarnings() throws SQLException {
            return null;
        }

        public void clearWarnings() throws SQLException {
        }

        public String getCursorName() throws SQLException {
            return null;
        }

        public ResultSetMetaData getMetaData() throws SQLException {
            return null;
        }

        public Object getObject(int columnIndex) throws SQLException {
            return null;
        }

        public Object getObject(String columnName) throws SQLException {
            return null;
        }

        public int findColumn(String columnName) throws SQLException {
            return 0;
        }

        public Reader getCharacterStream(int columnIndex) throws SQLException {
            return null;
        }

        public Reader getCharacterStream(String columnName) throws SQLException {
            return null;
        }

        public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
            return null;
        }

        public BigDecimal getBigDecimal(String columnName) throws SQLException {
            return null;
        }

        public boolean isBeforeFirst() throws SQLException {
            return false;
        }

        public boolean isAfterLast() throws SQLException {
            return false;
        }

        public boolean isFirst() throws SQLException {
            return false;
        }

        public boolean isLast() throws SQLException {
            return false;
        }

        public void beforeFirst() throws SQLException {
        }

        public void afterLast() throws SQLException {
        }

        public boolean first() throws SQLException {
            return false;
        }

        public boolean last() throws SQLException {
            return false;
        }

        public int getRow() throws SQLException {
            return 0;
        }

        public boolean absolute(int row) throws SQLException {
            return false;
        }

        public boolean relative(int rows) throws SQLException {
            return false;
        }

        public boolean previous() throws SQLException {
            return false;
        }

        public void setFetchDirection(int direction) throws SQLException {
        }

        public int getFetchDirection() throws SQLException {
            return 0;
        }

        public void setFetchSize(int rows) throws SQLException {
        }

        public int getFetchSize() throws SQLException {
            return 0;
        }

        public int getType() throws SQLException {
            return 0;
        }

        public int getConcurrency() throws SQLException {
            return 0;
        }

        public boolean rowUpdated() throws SQLException {
            return false;
        }

        public boolean rowInserted() throws SQLException {
            return false;
        }

        public boolean rowDeleted() throws SQLException {
            return false;
        }

        public void updateNull(int columnIndex) throws SQLException {
        }

        public void updateBoolean(int columnIndex, boolean x) throws SQLException {
        }

        public void updateByte(int columnIndex, byte x) throws SQLException {
        }

        public void updateShort(int columnIndex, short x) throws SQLException {
        }

        public void updateInt(int columnIndex, int x) throws SQLException {
        }

        public void updateLong(int columnIndex, long x) throws SQLException {
        }

        public void updateFloat(int columnIndex, float x) throws SQLException {
        }

        public void updateDouble(int columnIndex, double x) throws SQLException {
        }

        public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException {
        }

        public void updateString(int columnIndex, String x) throws SQLException {
        }

        public void updateBytes(int columnIndex, byte x[]) throws SQLException {
        }

        public void updateDate(int columnIndex, Date x) throws SQLException {
        }

        public void updateTime(int columnIndex, Time x) throws SQLException {
        }

        public void updateTimestamp(int columnIndex, Timestamp x) throws SQLException {
        }

        public void updateAsciiStream(int columnIndex, InputStream x, int length) throws SQLException {
        }

        public void updateBinaryStream(int columnIndex, InputStream x, int length) throws SQLException {
        }

        public void updateCharacterStream(int columnIndex, Reader x, int length) throws SQLException {
        }

        public void updateObject(int columnIndex, Object x, int scale) throws SQLException {
        }

        public void updateObject(int columnIndex, Object x) throws SQLException {
        }

        public void updateNull(String columnName) throws SQLException {
        }

        public void updateBoolean(String columnName, boolean x) throws SQLException {
        }

        public void updateByte(String columnName, byte x) throws SQLException {
        }

        public void updateShort(String columnName, short x) throws SQLException {
        }

        public void updateInt(String columnName, int x) throws SQLException {
        }

        public void updateLong(String columnName, long x) throws SQLException {
        }

        public void updateFloat(String columnName, float x) throws SQLException {
        }

        public void updateDouble(String columnName, double x) throws SQLException {
        }

        public void updateBigDecimal(String columnName, BigDecimal x) throws SQLException {
        }

        public void updateString(String columnName, String x) throws SQLException {
        }

        public void updateBytes(String columnName, byte x[]) throws SQLException {
        }

        public void updateDate(String columnName, Date x) throws SQLException {
        }

        public void updateTime(String columnName, Time x) throws SQLException {
        }

        public void updateTimestamp(String columnName, Timestamp x) throws SQLException {
        }

        public void updateAsciiStream(String columnName, InputStream x, int length) throws SQLException {
        }

        public void updateBinaryStream(String columnName, InputStream x, int length) throws SQLException {
        }

        public void updateCharacterStream(String columnName, Reader reader, int length) throws SQLException {
        }

        public void updateObject(String columnName, Object x, int scale) throws SQLException {
        }

        public void updateObject(String columnName, Object x) throws SQLException {
        }

        public void insertRow() throws SQLException {
        }

        public void updateRow() throws SQLException {
        }

        public void deleteRow() throws SQLException {
        }

        public void refreshRow() throws SQLException {
        }

        public void cancelRowUpdates() throws SQLException {
        }

        public void moveToInsertRow() throws SQLException {
        }

        public void moveToCurrentRow() throws SQLException {
        }

        public Statement getStatement() throws SQLException {
            return null;
        }

        public Object getObject(int i, Map<String, Class<?>> map) throws SQLException {
            return null;
        }

        public Ref getRef(int i) throws SQLException {
            return null;
        }

        public Blob getBlob(int i) throws SQLException {
            return null;
        }

        public Clob getClob(int i) throws SQLException {
            return null;
        }

        public Array getArray(int i) throws SQLException {
            return null;
        }

        public Object getObject(String colName, Map<String, Class<?>> map) throws SQLException {
            return null;
        }

        public Ref getRef(String colName) throws SQLException {
            return null;
        }

        public Blob getBlob(String colName) throws SQLException {
            return null;
        }

        public Clob getClob(String colName) throws SQLException {
            return null;
        }

        public Array getArray(String colName) throws SQLException {
            return null;
        }

        public Date getDate(int columnIndex, Calendar cal) throws SQLException {
            return null;
        }

        public Date getDate(String columnName, Calendar cal) throws SQLException {
            return null;
        }

        public Time getTime(int columnIndex, Calendar cal) throws SQLException {
            return null;
        }

        public Time getTime(String columnName, Calendar cal) throws SQLException {
            return null;
        }

        public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException {
            return null;
        }

        public Timestamp getTimestamp(String columnName, Calendar cal) throws SQLException {
            return null;
        }

        public URL getURL(int columnIndex) throws SQLException {
            return null;
        }

        public URL getURL(String columnName) throws SQLException {
            return null;
        }

        public void updateRef(int columnIndex, Ref x) throws SQLException {
        }

        public void updateRef(String columnName, Ref x) throws SQLException {
        }

        public void updateBlob(int columnIndex, Blob x) throws SQLException {
        }

        public void updateBlob(String columnName, Blob x) throws SQLException {
        }

        public void updateClob(int columnIndex, Clob x) throws SQLException {
        }

        public void updateClob(String columnName, Clob x) throws SQLException {
        }

        public void updateArray(int columnIndex, Array x) throws SQLException {
        }

        public void updateArray(String columnName, Array x) throws SQLException {
        }
    }
}
