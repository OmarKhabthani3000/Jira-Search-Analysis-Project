package br.com.architecteam;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 *
 * @author <a href="mailto:fabio@simula.com.br">Fabio Braga de Oliveira</a>
 */
@Entity
@Table(uniqueConstraints={@UniqueConstraint(columnNames={"orderCode", "part"})})
public class SalesOrder  implements Serializable {

    @Id
    private int id;

    private String orderCode;

    private String part;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getPart() {
        return part;
    }

    public void setPart(String part) {
        this.part = part;
    }

    
}
