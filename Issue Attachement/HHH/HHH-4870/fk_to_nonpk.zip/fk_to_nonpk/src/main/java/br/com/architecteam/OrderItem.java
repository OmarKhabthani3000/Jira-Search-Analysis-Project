package br.com.architecteam;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

/**
 *
 * @author <a href="mailto:fabio@simula.com.br">Fabio Braga de Oliveira</a>
 */
@Entity
public class OrderItem implements Serializable {

    @Id
    private int id;
    private int quantity;
    @ManyToOne
    @JoinColumns({
        @JoinColumn(name = "orderCode", referencedColumnName = "orderCode"),
        @JoinColumn(name = "part", referencedColumnName = "part")})
    private SalesOrder order;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public SalesOrder getOrder() {
        return order;
    }

    public void setOrder(SalesOrder order) {
        this.order = order;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
