/*
 *   UserPreference.java
 * 	 @Author Oleg Gorobets
 *   Created: 07.11.2007
 *   CVS-ID: $Id: 
 *************************************************************************/

package org.sibutu.kernel.security.entity;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class UserPreference implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4712684187909382049L;
	
	@SuppressWarnings("serial")
	public static class Id implements Serializable {
		
		private Long userId;
		private String key;
		
		public Id() {
		}
		
		public Id(Long userId, String key) {
			super();
			this.userId = userId;
			this.key = key;
		}


		@Override
		public int hashCode() {
			return new HashCodeBuilder()
				.append(userId)
				.append(key)
				.toHashCode();
		}
		
		@Override
		public boolean equals(Object obj) {
			if (!(obj instanceof Id)) {
				return false;
			}
			
			Id up = (Id) obj;
			
			return new EqualsBuilder()
				.append(this.userId, up.userId)
				.append(this.key, up.key)
				.isEquals();
		}
	}
	
	private Id id;
	
	private Long preferenceId;
	
	private List<String> values;
	
	public UserPreference() {
	}
	
	public long getPreferenceId() {
		return hashCode();
	}
	public void setPreferenceId(long preferenceId) {
		this.preferenceId = preferenceId;
	}

	

	public Id getId() {
		return id;
	}

	public void setId(Id id) {
		this.id = id;
	}

	public List<String> getValues() {
		return values;
	}
	public void setValues(List<String> values) {
		this.values = values;
	}
	
	
	@Override
	public int hashCode() {
		return id.hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof UserPreference)) {
			return false;
		}
		
		UserPreference up = (UserPreference) obj;
		
		return up.id.equals(id);
	}
	
}
