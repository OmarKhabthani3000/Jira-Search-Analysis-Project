INSERT INTO `test`.`brands` (`id` ,
`brand` 
)
VALUES (NULL , 'Hugo Bass'
), (NULL , 'Funky Girl'
), (NULL , 'Denim Second'
), (NULL , 'GG Fashion'
), (NULL , 'Vitty'
);