package com.example.test;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "brands")
public class Brand {
	
	@Id
	@GeneratedValue
	@Access(AccessType.PROPERTY)
	private Integer id;
	
	@Column(name = "brand", nullable = false, length = 150)
	private String brand;

	protected Brand() {		
	}
	
	public Brand(String brand) {
		this.brand = brand;
	}
	
	public Integer getId() {
		return id;
	}
	
	protected void setId(Integer id) {
		this.id = id;
	}
	
	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

}
