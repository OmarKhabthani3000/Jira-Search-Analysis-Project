package com.example.test;

public class BrandWrapper {
	private final Brand brand;
	
	public BrandWrapper(Brand brand) {
		this.brand = brand;
	}
	
	public Brand getBrand() {
		return brand;
	}
	
}
