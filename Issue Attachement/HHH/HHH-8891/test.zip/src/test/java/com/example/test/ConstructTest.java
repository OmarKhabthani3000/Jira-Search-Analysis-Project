package com.example.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.Test;

public class ConstructTest {
	
	@Test
	public void test() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myPersistenceUnit");
		try {
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			try {
				
				CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
				CriteriaQuery<BrandWrapper> query = criteriaBuilder.createQuery(BrandWrapper.class);
				
				Root<Brand> from = query.from(Brand.class);
				query.select(criteriaBuilder.construct(BrandWrapper.class, from));
				
				// THIS LINE WILL EXECUTE 1 + N QUERIES
				List<BrandWrapper> resultList = entityManager.createQuery(query).getResultList();
				
			} finally {
				entityManager.close();
			}
		} finally {
			entityManagerFactory.close();
		}
	}
	
}
