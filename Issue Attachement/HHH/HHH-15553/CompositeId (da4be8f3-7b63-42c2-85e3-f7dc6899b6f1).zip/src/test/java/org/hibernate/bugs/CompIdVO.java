package org.hibernate.bugs;

public interface CompIdVO {

    public String getId1();

    public void setId1(String id1);

    public String getId2();

    public void setId2(String id2);
}
