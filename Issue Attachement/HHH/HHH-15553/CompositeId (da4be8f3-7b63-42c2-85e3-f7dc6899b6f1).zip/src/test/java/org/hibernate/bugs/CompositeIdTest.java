package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.jdbc.Work;
import org.hibernate.query.Query;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CompositeIdTest extends BaseCoreFunctionalTestCase {

    @Override
    protected String[] getMappings() {
        return new String[] {"CompId.hbm.xml"};
    }

    @Override
    protected void configure(Configuration configuration) {
        super.configure( configuration );

        configuration.setProperty( AvailableSettings.SHOW_SQL, Boolean.TRUE.toString() );
        configuration.setProperty( AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString() );
    }

    @Test
    public void testImplicitCompositeIdInDynamicMapMode() {
        Session session = openSession();
        session.doWork(new Work() {
            @Override
            public void execute(Connection connection) throws SQLException {
                connection.createStatement().execute("insert into CompId values ('1', '2')");
                connection.commit();
            }
        });

        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery cq = cb.createQuery(CompIdVOImpl.class);

        Root root = cq.from(CompIdVOImpl.class);

        List<Predicate> predicates = new ArrayList<>();
        predicates.add(cb.equal(root.get("id1"), "1"));
        predicates.add(cb.equal(root.get("id2"), "2"));

        cq.where(cb.and(predicates.toArray(new Predicate[0])));
        Query query = session.createQuery(cq);

        List<CompIdVO> entities = query.getResultList();
    }
}


