package org.hibernate.bugs;

import java.io.Serializable;

public class CompIdVOImpl implements CompIdVO, Serializable {

    private String id1;
    private String id2;

    public CompIdVOImpl() {

    }

    public CompIdVOImpl(String id1, String id2) {
        this.id1 = id1;
        this.id2 = id2;
    }

    @Override
    public String getId1() {
        return id1;
    }

    @Override
    public void setId1(String id1) {
        this.id1 = id1;
    }

    @Override
    public String getId2() {
        return id2;
    }

    @Override
    public void setId2(String id2) {
        this.id2 = id2;
    }
}
