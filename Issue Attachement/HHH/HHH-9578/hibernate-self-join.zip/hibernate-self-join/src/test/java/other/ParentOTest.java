package other;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.junit.Test;

import test.utils.HibernateUtil;

public class ParentOTest {

	private static final boolean CREATE = true;

	@Test
	public void shouldCreateAndReadEntitiesO() {

		try {
			if (CREATE) {
				ChildO c1 = new ChildO();
				c1.setName("c1");
				ChildO c2 = new ChildO();
				c2.setName("c2");
				ChildO c3 = new ChildO();
				c3.setName("c3");

				Set<ChildO> ChildOren1 = new HashSet<ChildO>();
				ChildOren1.add(c2);
				c1.setChildren(ChildOren1);

				Set<ChildO> ChildOren2 = new HashSet<ChildO>();
				ChildOren2.add(c3);
				c2.setChildren(ChildOren2);

				Session session = HibernateUtil.getSessionFactory().openSession();
				session.beginTransaction();
				session.persist(c1);
				session.getTransaction().commit();
			}

			Session newSession = HibernateUtil.getSessionFactory().openSession();
			List<ChildO> result = newSession.createCriteria(ChildO.class).list();
			/* the following actually works */
			// List<Child> result = newSession.createQuery("from ChildO").list();
			System.out.println(result);
		} finally {
			HibernateUtil.shutdown();
		}
	}
}
