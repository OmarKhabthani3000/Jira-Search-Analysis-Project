package c.s.p.f.yg;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.junit.Test;

import test.utils.HibernateUtil;

public class ParentTest {

	private static final boolean CREATE = true;

	@Test
	public void shouldCreateAndReadEntities() {

		try {
			if (CREATE) {
				Child c1 = new Child();
				c1.setName("c1");
				Child c2 = new Child();
				c2.setName("c2");
				Child c3 = new Child();
				c3.setName("c3");
				
				Set<Child> children1 = new HashSet<Child>();
				children1.add(c2);
				c1.setChildren(children1);

				Set<Child> children2 = new HashSet<Child>();
				children2.add(c3);
				c2.setChildren(children2);

				Session session = HibernateUtil.getSessionFactory().openSession();
				session.beginTransaction();
				session.persist(c1);
				session.getTransaction().commit();
			}

			Session newSession = HibernateUtil.getSessionFactory().openSession();
			List<Child> result = newSession.createCriteria(Child.class).list();
			System.out.println(result);
		} finally {
			HibernateUtil.shutdown();
		}
	}
}
