package org.demo;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class GenericDescribedDataColumn<T> {
    @Column
    public T myvalue = null;

    @Column
    public String description = null;
}
