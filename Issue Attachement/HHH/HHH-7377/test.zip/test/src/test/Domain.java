package test;


public class Domain
{
	Long pkey;
	String id;

	public Domain()
	{
	}

	public Domain(String id)
	{
		this.id = id;
	}
}
