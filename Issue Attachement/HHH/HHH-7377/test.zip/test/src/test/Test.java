package test;

import java.io.File;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class Test
{
	public static Domain getDomainByNaturalId(String id, Session session)
	{
		Domain domain = (Domain) session.byNaturalId(Domain.class).using("id", id).load();
		if(domain == null)
		{
			domain = new Domain(id);
			session.save(domain);
			session.flush();
		}
		return domain;
	}

	public static Domain getDomainByQuery(String id, Session session)
	{
		Criteria crit = session.createCriteria(Domain.class);
		crit.add(Restrictions.eq("id", id));
		Domain domain = (Domain) crit.uniqueResult();
		if(domain == null)
		{
			domain = new Domain(id);
			session.save(domain);
			session.flush();
		}
		return domain;
	}

	public static void main(String[] args)
	{
		Configuration config = new Configuration();
		config.configure(new File("hibernate.cfg.xml"));

		SessionFactory factory = config.buildSessionFactory();
		Session session = factory.openSession();
		session.beginTransaction();
		session.setFlushMode(FlushMode.COMMIT);

		getDomainByNaturalId("", session);
		getDomainByNaturalId("", session);
		session.flush();
		session.clear();
		getDomainByNaturalId("", session);


		session.getTransaction().commit();
	}
}
