package org.baeldung.persistence.service;

import org.baeldung.persistence.deletion.config.PersistenceJPAConfigDeletion;
import org.baeldung.persistence.deletion.model.Bar;
import org.baeldung.persistence.deletion.model.Foo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PersistenceJPAConfigDeletion.class}, loader = AnnotationConfigContextLoader.class)
public class DeletionIntegrationTest {

    @PersistenceContext
    private EntityManager entityManager;

    @Test
    @Transactional
    public final void givenEntityIsRemovedAndReferencedByAnotherEntity_thenItIsNotRemoved() {
        Bar bar = new Bar("bar");

        Foo foo = new Foo("foo");
        foo.setBar(bar);

        entityManager.persist(foo);
        entityManager.persist(bar);

        entityManager.flush();

        entityManager.remove(foo);
        entityManager.remove(bar);

        entityManager.flush();

        assertThat(entityManager.find(Foo.class, foo.getId()), nullValue());
        assertThat(entityManager.find(Bar.class, bar.getId()), nullValue());
    }
}
