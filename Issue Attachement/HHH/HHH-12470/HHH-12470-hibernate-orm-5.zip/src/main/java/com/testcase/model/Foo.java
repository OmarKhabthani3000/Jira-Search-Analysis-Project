package com.testcase.model;


import javax.persistence.*;

@Entity
@Table(name = "FOO")
@Inheritance(strategy = InheritanceType.JOINED)
public class Foo extends AbstractFoo {

    public Foo() {
        super();
    }

    public Foo(final String name) {
        super();
        this.name = name;
    }

    @Column(name = "NAME")
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "BAR_ID")
    private Bar bar;

    public Bar getBar() {
        return bar;
    }

    public void setBar(final Bar bar) {
        this.bar = bar;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }
}
