package hibernate.bug.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CollectionOfElements;

@Entity
@Table
public class TestEntity {

    private Integer id;
    private List<CollectionElement> elements = new ArrayList<CollectionElement>();

    @Id
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @CollectionOfElements
    public List<CollectionElement> getElements() {
        return elements;
    }

    public void setElements(List<CollectionElement> elements) {
        this.elements = elements;
    }
}
