package hibernate.bug.entities;

import java.io.Serializable;

public class CollectionElement implements Serializable {

    private Component component;
    private Integer number;
    private String property;

    public Component getComponent() {
        return component;
    }

    public void setComponent(Component component) {
        this.component = component;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public String getProperty() {
        return property;
    }

    public void setProperty(String property) {
        this.property = property;
    }
}