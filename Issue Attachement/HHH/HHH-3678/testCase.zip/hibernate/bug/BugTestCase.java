package hibernate.bug;

import static org.junit.Assert.assertNull;
import hibernate.bug.entities.CollectionElement;
import hibernate.bug.entities.Component;
import hibernate.bug.entities.TestEntity;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cache.OSCacheProvider;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BugTestCase {

    private AnnotationConfiguration config;
    private SessionFactory sessionFactory;

    @Before
    public void setUp() {

        if (sessionFactory == null) {
            config = new AnnotationConfiguration();

            config.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
            config.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
            config.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:test");
            config.setProperty("hibernate.show_sql", "true");
            config.setProperty("hibernate.cglib.use_reflection_optimizer", "false");
            config.setProperty("hibernate.current_session_context_class", "managed");
            config.setProperty("hibernate.cache.provider_class", OSCacheProvider.class.getName());
            config.setProperty("hibernate.cache.use_second_level_cache", "false");
            config.addAnnotatedClass(Component.class);
            config.addAnnotatedClass(CollectionElement.class);
            config.addAnnotatedClass(TestEntity.class);

            sessionFactory = config.buildSessionFactory();
        }

        SchemaExport schemaExport = new SchemaExport(config);
        schemaExport.drop(true, true);
        schemaExport.create(true, true);
    }

    @After
    public void tearDown() {

        if (sessionFactory != null) {
            sessionFactory.close();
        }
        SchemaExport schemaExport = new SchemaExport(config);
        schemaExport.drop(true, true);
    }

    @Test
    public void testName() {

        List<CollectionElement> elements = saveAndRecoverCollection();
        for (CollectionElement collectionElement : elements) {
            Component component = collectionElement.getComponent();
            assertNull("Name is not null - value: [" + component.getName() + "]", component
                    .getName());
        }

    }

    @Test
    public void testDescription() {

        List<CollectionElement> elements = saveAndRecoverCollection();
        for (CollectionElement collectionElement : elements) {
            Component component = collectionElement.getComponent();
            assertNull("Description is not null - value: [" + component.getDescription() + "]",
                    component.getDescription());
        }

    }

    @Test
    public void testMiddleName() {

        List<CollectionElement> elements = saveAndRecoverCollection();
        for (CollectionElement collectionElement : elements) {
            Component component = collectionElement.getComponent();
            assertNull("Middle name is not null - value: [" + component.getMiddleName() + "]",
                    component.getMiddleName());
        }

    }

    @Test
    public void testLastName() {

        List<CollectionElement> elements = saveAndRecoverCollection();
        for (CollectionElement collectionElement : elements) {
            Component component = collectionElement.getComponent();
            assertNull("Last name is not null - value: [" + component.getLastName() + "]",
                    component.getLastName());
        }

    }

    private List<CollectionElement> saveAndRecoverCollection() {
        TestEntity entity = new TestEntity();
        entity.setId(1);
        entity.setElements(getCollectionOfElements(1));
        save(entity);
        Session newSession = sessionFactory.openSession();
        TestEntity recoveredEntity = (TestEntity) newSession.get(TestEntity.class, 1);
        List<CollectionElement> elements = recoveredEntity.getElements();
        return elements;
    }

    private List<CollectionElement> getCollectionOfElements(Integer size) {

        List<CollectionElement> collectionOfElements = new ArrayList<CollectionElement>(size);
        for (int i = 1; i <= size; i++) {
            collectionOfElements.add(getCollectionElement(i));
        }
        return collectionOfElements;
    }

    private CollectionElement getCollectionElement(Integer number) {

        CollectionElement element = new CollectionElement();
        element.setNumber(number);
        element.setProperty("property");
        element.setComponent(getComponent(number));
        return element;
    }

    private Component getComponent(Integer id) {

        Component component = new Component();
        component.setId(id);
        component.setName("name" + id);
        component.setDescription("description" + id);
        return component;
    }

    private void save(Object obj) {

        Session session = sessionFactory.openSession();
        Transaction t = session.beginTransaction();
        session.save(obj);
        t.commit();
        session.close();
    }
}
