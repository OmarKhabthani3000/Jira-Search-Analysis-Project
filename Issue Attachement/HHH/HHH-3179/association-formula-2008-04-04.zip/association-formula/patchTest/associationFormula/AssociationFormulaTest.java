// $Id: RefreshTest.java 10976 2006-12-12 23:22:26Z steve.ebersole@jboss.com $
package patchTest.associationFormula;

import junit.framework.Test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;


/**
 * Implementation of test for patch not-found-keep.
 * 
 * @author Heinz Huber
 */
public class AssociationFormulaTest extends FunctionalTestCase {
    
    public AssociationFormulaTest( String name ) {
        super( name );
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see FunctionalTestCase#getBaseForMappings()
     */
    public String getBaseForMappings() {
        return "patchTest/";
    }
    
    public String[] getMappings() {
        return new String[] { "associationFormula/mapping.hbm.xml" };
    }
    
    public static Test suite() {
        return new FunctionalTestClassTestSuite( AssociationFormulaTest.class );
    }
    
    public void testAssociationFormula() throws Throwable {
        Session session = openSession();
        Transaction txn = session.beginTransaction();
        
        AssociationFormula obj = new AssociationFormula( new Data( "val1", "val2" ) );
        session.persist( obj );
        session.flush();
        
        obj.getData().setVal1( "updated" );
        session.persist( obj );
        session.flush();
        
        session.delete( obj );
        session.flush();
        
        txn.rollback();
        session.close();
    }
}
