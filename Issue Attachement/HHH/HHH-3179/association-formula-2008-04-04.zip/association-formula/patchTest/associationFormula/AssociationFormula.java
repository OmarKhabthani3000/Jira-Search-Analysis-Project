package patchTest.associationFormula;

public class AssociationFormula {
    private Long id;
    
    private Data data;
    
    public AssociationFormula() {
        super();
    }
    
    public AssociationFormula( Data data ) {
        super();
        this.data = data;
    }
    
    public Data getData() {
        return data;
    }
    
    public void setData( Data data ) {
        this.data = data;
    }
    
    public Long getId() {
        return id;
    }
    
    public void setId( Long id ) {
        this.id = id;
    }
    
}
