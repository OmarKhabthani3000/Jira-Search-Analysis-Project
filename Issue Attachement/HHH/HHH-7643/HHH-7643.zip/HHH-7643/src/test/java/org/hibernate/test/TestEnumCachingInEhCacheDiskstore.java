package org.hibernate.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;


@ContextConfiguration(locations = "classpath:context.xml")
public class TestEnumCachingInEhCacheDiskstore extends AbstractTransactionalJUnit4SpringContextTests {

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private TransactionTemplate transactionTemplate;


    @Before
    public void setupData() {
        transactionTemplate.execute(new TransactionCallback<Object>() {
            @Override
            public Object doInTransaction(TransactionStatus transactionStatus) {
                Session session = sessionFactory.getCurrentSession();
                for (int i = 10; i > 0; i--) {
                    session.save(new Item("active-" + i, Status.ACTIVE));
                    session.save(new Item("inactive-" + i, Status.INACTIVE));
                }
                session.flush();
                return null;
            }
        });
    }

    @Test
    public void test() {
        transactionTemplate.execute(new TransactionCallback<List>() {
            @Override
            public List doInTransaction(TransactionStatus transactionStatus) {
                return sessionFactory.getCurrentSession()
                        .createQuery("FROM Item WHERE status = :s")
                        .setParameter("s", Status.ACTIVE)
                        .setCacheable(true)
                        .list();
            }
        });

        sessionFactory.getStatistics();
    }
}
