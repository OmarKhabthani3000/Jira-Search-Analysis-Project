package org.hibernate.test;

public enum Status {
    ACTIVE,
    INACTIVE
}
