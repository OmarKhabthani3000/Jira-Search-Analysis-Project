/**
 * Copyright Schantz A/S, all rights reserved
 */
package test.orderproblem;

import org.hibernate.*;
import org.hibernate.boot.registry.*;
import org.hibernate.cfg.*;
import org.junit.*;

public class PersonAnimalOrderTest {

	private SessionFactory sessionFactory;

	@Before public void setup() {
		final Configuration configure = new Configuration().configure();
		sessionFactory = configure.buildSessionFactory(new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build());
	}

	@After public void teardown() {
		sessionFactory.close();
	}

	static long id = 0;

	private void testSaveAndRetrieve(Animal animal1, Person person1, Animal animal2, Person person2) {
		PersonIdPair personIdPair;
		try (Session session = sessionFactory.openSession()) {
			personIdPair = savePetsAndPersons(animal1, person1, animal2, person2, session);
		}
		try (Session session = sessionFactory.openSession()) {
			assertPersonsPersisted(personIdPair, session);
		}
	}

	private PersonIdPair savePetsAndPersons(Animal animal1, Person person1, Animal animal2, Person person2, Session session) {
		PersonIdPair personIdPair = new PersonIdPair();

		session.setFlushMode(FlushMode.COMMIT);
		session.getTransaction().begin();

		animal1.setId(++id);
		person1.setId(++id);
		personIdPair.id1 = id;
		person1.setAnimal(animal1);
		session.persist(person1);

		animal2.setId(++id);
		person2.setId(++id);
		personIdPair.id2 = id;
		person2.setAnimal(animal2);
		session.persist(person2);

		session.getTransaction().commit();

		return personIdPair;
	}

	private void assertPersonsPersisted(PersonIdPair personIdPair, Session session) {
		session.setFlushMode(FlushMode.COMMIT);
		session.getTransaction().begin();

		Person person1 = session.load(Person.class, personIdPair.id1);
		Animal animal1 = person1.getAnimal();
		Assert.assertTrue(animal1 != null);

		Person person2 = session.load(Person.class, personIdPair.id2);
		Animal animal2 = person2.getAnimal();
		Assert.assertTrue(animal2 != null);
	}

	@Test
	public void test1(){
		Animal animal1 = new Animal();
		Person person1 = new Person();
		Animal animal2 = new Animal();
		Person person2 = new Person();

		testSaveAndRetrieve(animal1, person1, animal2, person2);
	}

	/* FAILS */
	@Test
	public void test2(){
		testSaveAndRetrieve(new Elephant(), new Man(), new Elephant(), new Woman());
	}

	@Test
	public void test3(){
		testSaveAndRetrieve(new Elephant(), new Man(), new Horse(), new Woman());
	}

	@Test
	public void test4(){
		testSaveAndRetrieve(new Elephant(), new Man(), new Horse(), new Man());
	}

	public class PersonIdPair {
		long id1;
		long id2;

	}
}