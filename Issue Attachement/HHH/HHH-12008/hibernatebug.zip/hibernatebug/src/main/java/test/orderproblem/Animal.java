package test.orderproblem;

import javax.persistence.*;

@Entity
@Access(AccessType.FIELD)
public class Animal {

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	String petName;

	@Id
	private Long id;

	public void setId(Long id) {
		this.id = id;
	}

	public Long getId() {
		return id;
	}


}
