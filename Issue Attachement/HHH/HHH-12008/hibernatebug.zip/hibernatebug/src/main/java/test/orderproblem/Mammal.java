/**
 * Copyright Schantz A/S, all rights reserved
 */
package test.orderproblem;

import javax.persistence.*;

@Entity
@Access(AccessType.FIELD)
public class Mammal extends Animal{
}
