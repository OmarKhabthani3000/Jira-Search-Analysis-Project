package test.orderproblem;

import javax.persistence.*;

@Entity
@Access(AccessType.FIELD)
public class Person {

	@Id
	private Long id;

	public void setId(Long id) {
		this.id = id;
	}

	//Test 2 fails, also when @ManyToOne is used
	@OneToOne(cascade={CascadeType.ALL})
	private Animal animal;

	public void setAnimal(Animal animal) {
		this.animal = animal;
	}

	public Long getId() {
		return id;
	}

	public Animal getAnimal(){
		return animal;
	}

}
