package test.orderproblem;

import javax.persistence.*;

@Entity
@Access(AccessType.FIELD)
public class Woman extends Person {

}
