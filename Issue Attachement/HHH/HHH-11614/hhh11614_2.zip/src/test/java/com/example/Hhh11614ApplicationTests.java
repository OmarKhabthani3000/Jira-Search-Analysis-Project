package com.example;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class Hhh11614ApplicationTests {

    @Autowired
    private HHH11614EntityRepository repo;

	@Test
	public void contextLoads() {
	}

	@Test
    public void persistLob() {
        HHH11614Entity hhh11614Entity = new HHH11614Entity();
        hhh11614Entity.setData("example data");
        repo.saveAndFlush(hhh11614Entity);
    }

}
