package com.example;

import org.springframework.data.jpa.repository.JpaRepository;

public interface HHH11614EntityRepository extends JpaRepository<HHH11614Entity, Long> {
}
