package org.hibernate.bugs;

import javax.persistence.*;

@Entity
@Table(name = "being")
@Inheritance
@DiscriminatorColumn(name = "type")
public abstract class Being {

    @Id
    private Long id;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}