package org.hibernate.bugs;

import javax.persistence.*;

@Entity
@SecondaryTable(name = "animal")
public abstract class Animal extends Being {
    @Column(name = "uuid", table = "animal")
    private String uuid;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
}