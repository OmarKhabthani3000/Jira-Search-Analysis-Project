package org.hibernate.bugs;

import javax.persistence.*;

@Entity
public class Toy {
    @Id
    private Long id;

    // @Column(name = "animal_uuid")
    // private String animalUuid;

    // what mapping can I use here? The following does't work.
    @ManyToOne
    @JoinColumn(name = "animal_uuid", referencedColumnName = "uuid")
    private Cat cat;

    public Cat getCat() {
        return cat;
    }

    public void setCat(Cat cat) {
        this.cat = cat;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}