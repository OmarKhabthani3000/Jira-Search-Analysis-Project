just excecute project


