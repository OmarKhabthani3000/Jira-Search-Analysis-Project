package com.test.common;

import java.io.Serializable;
import java.util.Date;

public class CreationDateEntity
        implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer id;
    private Date creationDate;

	public CreationDateEntity() {
	}

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }
}
