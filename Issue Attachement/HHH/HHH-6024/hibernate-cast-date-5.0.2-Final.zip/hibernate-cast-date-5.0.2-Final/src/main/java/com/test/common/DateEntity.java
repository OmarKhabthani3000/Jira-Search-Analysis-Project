package com.test.common;

import java.io.Serializable;
import java.util.Date;

public class DateEntity
        implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer id;
    private Date date;

	public DateEntity() {
	}

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
