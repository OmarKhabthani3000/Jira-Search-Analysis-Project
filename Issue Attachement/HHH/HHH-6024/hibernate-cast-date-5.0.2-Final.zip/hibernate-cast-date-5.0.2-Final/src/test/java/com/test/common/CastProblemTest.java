package com.test.common;

import com.test.persistence.HibernateUtil;
import org.hibernate.Session;
import org.junit.Test;

public class CastProblemTest {

    @Test
    public void nullPointerExceptionInCastFunction() {
        Session session = HibernateUtil.getSessionFactory().openSession();

        //
        // This throws an NPE in CastFunction...
        //
        session.createQuery("SELECT entity FROM DateEntity AS entity WHERE CAST(entity.date AS date) = ? ");
    }

    @Test()
    public void passes() {
        Session session = HibernateUtil.getSessionFactory().openSession();

        //
        // If we rename the "date" field to "creationDate", then the NPE disappears...
        //
        session.createQuery("SELECT entity FROM CreationDateEntity AS entity WHERE CAST(entity.creationDate AS date) = ? ");
    }
}
