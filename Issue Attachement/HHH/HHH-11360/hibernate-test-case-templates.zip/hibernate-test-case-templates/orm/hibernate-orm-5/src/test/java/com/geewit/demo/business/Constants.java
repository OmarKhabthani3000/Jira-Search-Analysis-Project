package com.geewit.demo.business;



/**
 * 常量类
 *
 * @author gelif
 * @since 2015-5-18
 */
public class Constants {

    //股权明细表：增持、减持、冻结、扣冻、分红节点计算, 费用
    public enum OPERATION_TYPE {
        增持, 减持, 冻结, 扣冻, 分红节点计算, 费用
    }
}
 