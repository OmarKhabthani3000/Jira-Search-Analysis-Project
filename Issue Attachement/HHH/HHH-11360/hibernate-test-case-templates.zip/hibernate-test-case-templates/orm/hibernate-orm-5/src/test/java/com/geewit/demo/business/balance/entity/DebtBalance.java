package com.geewit.demo.business.balance.entity;

import com.geewit.demo.business.Product;
import com.geewit.demo.business.ProductType;
import com.geewit.demo.business.balance.persistence.converter.ProductTypeConverter;

import javax.persistence.*;
import java.math.BigDecimal;


/**
 * 债持有信息
 *
 * @author gelif
 * @since 2015-5-18
 */
@Entity
@Table(name = "debt_balance")
public class DebtBalance extends Balance {
    public DebtBalance() {
        super();
        super.product = Product.债权;
    }

    public DebtBalance(ProductType productType, Number amount) {
        super.product = Product.债权;
        this.productType = productType;
        super.amount = BigDecimal.valueOf(amount.floatValue());
    }

    //债类型
    private ProductType productType;


    @Convert(converter = ProductTypeConverter.class)
    @Column(name = "product_type", columnDefinition = "smallint")
    public ProductType getProductType() {
        return productType;
    }

    public DebtBalance setProductType(ProductType productType) {
        this.productType = productType;
        return this;
    }
}
