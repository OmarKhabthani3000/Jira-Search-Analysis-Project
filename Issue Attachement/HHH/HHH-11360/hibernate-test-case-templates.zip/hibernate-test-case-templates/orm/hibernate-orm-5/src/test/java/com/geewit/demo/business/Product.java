package com.geewit.demo.business;


/**
 * 产品
 *
 * @author gelif
 * @since 2015-5-18
 */
public enum Product {
    债权,
    ALL
}
