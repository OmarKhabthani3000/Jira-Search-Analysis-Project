package com.geewit.demo.basic.persistence.listener;

import com.geewit.demo.basic.entity.ListenedEntity;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import java.util.Calendar;

/**
 创建时间, 更新时间, 删除标志自动保存/更新的JPA 监听器
 @author gelif
 @since  2015-5-18
 */
public class PersistenceListener {
    @PrePersist
    public void prePersist(ListenedEntity listenedEntity) {
        listenedEntity.setDelFlag(false);
        if(listenedEntity.getCreateTime() == null) {
            listenedEntity.setCreateTime(Calendar.getInstance().getTime());
        }
    }

    @PreUpdate
    public void preUpdate(ListenedEntity listenedEntity) {
        listenedEntity.setUpdateTime(Calendar.getInstance().getTime());
    }
}
