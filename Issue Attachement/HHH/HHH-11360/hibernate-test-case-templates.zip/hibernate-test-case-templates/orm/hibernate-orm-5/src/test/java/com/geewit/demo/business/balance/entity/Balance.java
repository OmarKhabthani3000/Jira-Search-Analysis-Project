package com.geewit.demo.business.balance.entity;

import com.geewit.demo.business.Product;
import com.geewit.demo.basic.entity.ListenedEntity;

import javax.persistence.*;
import java.math.BigDecimal;

/**
 * 股东产品持有信息，为五种产品持有信息的基类
 * @author gelif
 * @since  2015-5-18
 */
@Entity
@Table(name = "balance")
@Inheritance(strategy = InheritanceType.JOINED)
public class Balance extends ListenedEntity {
    //编号
    protected Integer id;
    //产品类型
    protected Product product;
    //金额
    protected BigDecimal amount;
    //备注
    protected String remark;

    @Id
    @Column(name = "id", columnDefinition = "int")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getId() {
        return id;
    }

    public Balance setId(Integer id) {
        this.id = id;
        return this;
    }

    @Enumerated
    @Column(name = "product", columnDefinition = "SMALLINT")
    public Product getProduct() {
        return product;
    }

    public Balance setProduct(Product product) {
        this.product = product;
        return this;
    }

    @Basic
    @Column(name = "remark", columnDefinition = "TEXT")
    public String getRemark() {
        return remark;
    }

    public Balance setRemark(String remark) {
        this.remark = remark;
        return this;
    }

    @Basic
    @Column(name = "amount", columnDefinition = "FLOAT(18, 2)")
    public BigDecimal getAmount() {
        return amount;
    }

    public Balance setAmount(BigDecimal amount) {
        this.amount = amount;
        return this;
    }
}
