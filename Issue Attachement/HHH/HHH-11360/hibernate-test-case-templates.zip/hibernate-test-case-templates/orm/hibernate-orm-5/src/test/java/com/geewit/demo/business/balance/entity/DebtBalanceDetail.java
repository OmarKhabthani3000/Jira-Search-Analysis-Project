package com.geewit.demo.business.balance.entity;

import com.geewit.demo.business.ProductType;
import com.geewit.demo.business.balance.persistence.converter.ProductTypeConverter;

import javax.persistence.*;
import java.math.BigDecimal;


/**
 * 债明细
 *
 * @author gelif
 * @since 2015-5-18
 */
@Entity
@Table(name = "debt_balance_details")
public class DebtBalanceDetail extends BalanceDetail {
    public DebtBalanceDetail() {
    }


    //编号
    private Integer id;
    //债类型
    private ProductType productType;
    //债金额
    private BigDecimal amount;


    @Id
    @Column(name = "id", columnDefinition = "int")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getId() {
        return id;
    }

    public DebtBalanceDetail setId(Integer id) {
        this.id = id;
        return this;
    }

    @Convert(converter = ProductTypeConverter.class)
    @Column(name = "product_type", columnDefinition = "smallint")
    public ProductType getProductType() {
        return productType;
    }

    public DebtBalanceDetail setProductType(ProductType productType) {
        this.productType = productType;
        return this;
    }

    @Basic
    @Column(name = "amount", columnDefinition = "float(18, 2)")
    public BigDecimal getAmount() {
        return amount;
    }

    public DebtBalanceDetail setAmount(BigDecimal amount) {
        this.amount = amount;
        return this;
    }
}
