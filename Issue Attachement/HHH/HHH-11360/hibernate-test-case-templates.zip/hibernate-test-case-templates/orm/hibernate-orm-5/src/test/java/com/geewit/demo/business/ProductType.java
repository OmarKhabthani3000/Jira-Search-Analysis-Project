package com.geewit.demo.business;

/**
 产品类型
 @author gelif
 @since  2015-5-18
 */
public enum ProductType {
    ALL("ALL", -1),

    DEBT_六个月("六个月", ((1 << 10) + 0)),
    DEBT_十二个月("十二个月", ((1 << 10) + 1)),
    DEBT_廿四个月("廿四个月",((1 << 10) + 2)),
    DEBT_种子金("种子金", ((1 << 10) + 4));

    ProductType(String name, int value) {
        this.name = name;
        this.value = value;
    }

    private String name;
    private int value;

    public int value() {
        return value;
    }

    public String getName() {
        return name;
    }
}
