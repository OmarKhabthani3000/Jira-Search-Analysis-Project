package com.geewit.demo.business.balance.entity;

import com.geewit.demo.business.Constants;
import com.geewit.demo.basic.entity.ListenedEntity;

import javax.persistence.*;

/**
 公共产品持有明细信息
 @author gelif
 @since 2015/5/25
 */
@MappedSuperclass
public abstract class BalanceDetail extends ListenedEntity {

    //备注
    protected String remark;

    //操作类型
    protected Constants.OPERATION_TYPE operationType;



    @Basic
    @Column(name = "remark", columnDefinition = "TEXT")
    public String getRemark() {
        return remark;
    }

    public BalanceDetail setRemark(String remark) {
        this.remark = remark;
        return this;
    }

    @Enumerated
    @Column(name = "operation_type", columnDefinition = "smallint")
    public Constants.OPERATION_TYPE getOperationType() {
        return operationType;
    }

    public BalanceDetail setOperationType(Constants.OPERATION_TYPE operationType) {
        this.operationType = operationType;
        return this;
    }

}
