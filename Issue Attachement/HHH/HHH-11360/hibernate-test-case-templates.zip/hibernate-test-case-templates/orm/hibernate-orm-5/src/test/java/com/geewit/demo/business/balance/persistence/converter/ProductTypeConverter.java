package com.geewit.demo.business.balance.persistence.converter;

import com.geewit.demo.business.ProductType;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

/**
 * Created by gelif on 2015/6/4.
 */
@Converter(autoApply = true)
public class ProductTypeConverter implements AttributeConverter<ProductType, Integer> {

    @Override
    public Integer convertToDatabaseColumn(ProductType productType) {
        return productType != null ? productType.value() : null;
    }

    @Override
    public ProductType convertToEntityAttribute(Integer value) {
        if(value == null) {
            return null;
        }
        for (ProductType productType : ProductType.values()) {
            if (productType.value() == value) {
                return productType;
            }
        }
        return null;
    }
}
