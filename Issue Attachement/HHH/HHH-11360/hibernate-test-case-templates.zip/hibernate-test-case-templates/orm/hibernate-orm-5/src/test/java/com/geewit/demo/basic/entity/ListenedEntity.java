package com.geewit.demo.basic.entity;

import com.geewit.demo.basic.persistence.listener.PersistenceListener;

import javax.persistence.*;
import java.util.Date;

/**
 创建时间, 更新时间, 删除标志的公共实体类
 @author gelif
 @since  2015-5-18
 */
@MappedSuperclass
@EntityListeners({PersistenceListener.class})
public abstract class ListenedEntity implements java.io.Serializable {
    protected Date createTime; //创建时间

    protected Date updateTime;

    protected boolean delFlag = false;


    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time", columnDefinition = "datetime")
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }


    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "update_time", columnDefinition = "datetime")
    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Column(name = "del_flag", columnDefinition = "tinyint")
    public boolean getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(boolean delFlag) {
        this.delFlag = delFlag;
    }
}
