/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

import se.zaleth.jar.material.AbstractMaterial;

/**
 *
 * @author krister
 */
public class MaterialContainerBlastFurnacePart {
    
    AbstractMaterial material;
    double materialAmount;
    double materialAmountKgPerTonHotMetal;

    public AbstractMaterial getMaterial() {
        return material;
    }

    public void setMaterial(AbstractMaterial material) {
        this.material = material;
    }

    public double getMaterialAmount() {
        return materialAmount;
    }

    public void setMaterialAmount(double materialAmount) {
        this.materialAmount = materialAmount;
    }

    public double getMaterialAmountKgPerTonHotMetal() {
        return materialAmountKgPerTonHotMetal;
    }

    public void setMaterialAmountKgPerTonHotMetal(double materialAmountKgPerTonHotMetal) {
        this.materialAmountKgPerTonHotMetal = materialAmountKgPerTonHotMetal;
    }
    
}
