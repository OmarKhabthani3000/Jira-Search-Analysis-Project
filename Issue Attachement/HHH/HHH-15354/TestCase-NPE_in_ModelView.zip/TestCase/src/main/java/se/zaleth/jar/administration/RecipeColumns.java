/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.administration;

/**
 *
 * @author krister
 */
public class RecipeColumns {
    
    private long id;
    private boolean showStockDryColumn;
    private boolean showDryMaterialPriceColumn;
    private boolean showMoistMaterialPriceColumn;
    private boolean showDryIngredientQuantityColumn;
    private boolean showMoistIngredientQuantityColumn;
    private boolean showPercentAddedDryColumn;
    private boolean showPercentAddedMoistColumn;
    private boolean showAddedPerDumpDryColumn;
    private boolean showAddedPerDumpMoistColumn;
    private boolean showTotalCostColumn;
    private UserGroup userGroup;

}
