/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.product;

import java.util.ArrayList;
import java.util.List;
import se.zaleth.jar.administration.PROJECTUser;
import se.zaleth.jar.generic.Composition;
import se.zaleth.jar.generic.MetalComposition;
import se.zaleth.jar.material.RawMaterial;

/**
 *
 * @author krister
 */
public class TargetProduct {
    
    private long id;
    private String name;
    private String description;
    private ArrayList<RawMaterial> rawMaterials;
    private Composition maxComposition;
    private Composition minComposition;
    private Composition aimComposition;
    private MetalComposition hotHeelComposition;
    private TargetProductGroup targetProductGroup;
    private PROJECTUser owner;
    private double targetCAfterOxidization;
    private double targetCAfterMainFurnace;
    private double targetPhosphorAfterDephosphorization;
    private double targetSulfurAfterDesulfurization;
    private boolean useDecarburization;
    private boolean useDephosphorization;
    private boolean useDesulfurization;
    private boolean useTargetCarbonMainFurnace;
    private boolean treatedAtImport;
    private List<ElementsCombinationConstraint> elementsCombinationsConstraints;
    private String productSystemName;

}
