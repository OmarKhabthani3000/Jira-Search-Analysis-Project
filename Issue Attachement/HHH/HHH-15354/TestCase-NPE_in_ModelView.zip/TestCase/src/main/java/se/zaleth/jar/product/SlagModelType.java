/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.product;

/**
 *
 * @author krister
 */
public enum SlagModelType {
    SLAG_MODEL_TYPE_BASIC(1), SLAG_MODEL_TYPE_SLAG(2), SLAG_MODEL_TYPE_MGOSAT(3), SLAG_MODEL_TYPE_BASIC_CUPOLA(4);
    private final int slagModelTypeValue;

    private SlagModelType(int slagModelTypeValue) {
        this.slagModelTypeValue = slagModelTypeValue;
    }
    
}
