/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import se.zaleth.jar.generic.QuantityUnitType;

/**
 *
 * @author krister
 */
public class EnergyAndReductionGasMaterial extends AbstractMaterial {
    
    private double heatContentEnergy;
    private double consumptionO2;
    private double levelOneCO2;
    private QuantityUnitType quantityUnitType;

    public double getHeatContentEnergy() {
        return heatContentEnergy;
    }

    public void setHeatContentEnergy(double heatContentEnergy) {
        this.heatContentEnergy = heatContentEnergy;
    }

    public double getConsumptionO2() {
        return consumptionO2;
    }

    public void setConsumptionO2(double consumptionO2) {
        this.consumptionO2 = consumptionO2;
    }

    public double getLevelOneCO2() {
        return levelOneCO2;
    }

    public void setLevelOneCO2(double levelOneCO2) {
        this.levelOneCO2 = levelOneCO2;
    }

    public QuantityUnitType getQuantityUnitType() {
        return quantityUnitType;
    }

    public void setQuantityUnitType(QuantityUnitType quantityUnitType) {
        this.quantityUnitType = quantityUnitType;
    }

    public int getQuantityUnitTypeValue() {
        return 0;
    }

    public void setQuantityUnitTypeValue(int value) {
    }

}
