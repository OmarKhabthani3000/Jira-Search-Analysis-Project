/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.product;

import java.util.Set;
import se.zaleth.jar.generic.MetalComposition;
import se.zaleth.jar.project.ProductionProfile;

/**
 *
 * @author krister
 */
public class DistributionFactorSet {
    
    private long id;
    private String name;
    private String description;
    private String nameKey;
    private String descriptionKey;
    private boolean available;
    private boolean hidden;
    private MetalComposition distributionValues;
    private DistributeAll distributeAll;
    private double distributionAl;
    private double distributionC;
    private double distributionCo;
    private double distributionCr;
    private double distributionCu;
    private double distributionFe;
    private double distributionMn;
    private double distributionMo;
    private double distributionN;
    private double distributionNb;
    private double distributionNi;
    private double distributionP;
    private double distributionS;
    private double distributionSi;
    private double distributionTi;
    private double distributionV;
    private double distributionAs;
    private double distributionW;
    private double distributionCe;
    private double distributionB;
    private double distributionBi;
    private double distributionPb;
    private double distributionCa;
    private double distributionTa;
    private double distributionSn;
    private double distributionZn;
    private double distributionO;
    private double distributionH;
    private double distributionTe;
    private double distributionSb;
    private double originalDistributionP;
    private double originalDistributionV;
    private Set<ProductionProfile> productionProfiles;
    private Set<Integer> productionUnitTypes;
    private double distributionMgO;
    private double distributionMgCO3;

}
