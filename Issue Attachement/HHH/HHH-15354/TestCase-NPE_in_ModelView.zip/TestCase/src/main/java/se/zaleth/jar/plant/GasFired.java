/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

import se.zaleth.jar.generic.MetalComposition;

/**
 *
 * @author krister
 */
public class GasFired extends ProductionUnit {
    
    private double capacity;
    private double averagePowerOn;
    private double averagePowerOff;
    private double averagePowerOnTime;
    private double averagePowerOffTime;
    private double heatLoss;
    private double idlePoweroffHeatLoss;
    private double availability;
    private double dustBurnoff;
    private MetalComposition metallicElementsBurnoff;
    private double aluminiumProductionCost;
    private double slagProductionCost;
    private double dustProductionCost;

    public double getInputAluminiumProductionCost() {
        return 0;
    }

    public void setInputAluminiumProductionCost(double aluminiumProductionCost) {
    }

    public double getSlagProductionCost() {
        return 0;
    }

    public void setSlagProductionCost(double slagProductionCost) {
    }

    public double getInputSlagProductionCost() {
        return 0;
    }

    public void setInputSlagProductionCost(double slagProductionCost) {
    }

    public double getDustProductionCost() {
        return 0;
    }

    public void setDustProductionCost(double dustProductionCost) {
    }

    public double getInputDustProductionCost() {
        return 0;
    }

    public void setInputDustProductionCost(double dustProductionCost) {
    }

    public double getCapacity() {
        return capacity;
    }

    public void setCapacity(double capacity) {
        this.capacity = capacity;
    }

    public double getAveragePowerOn() {
        return averagePowerOn;
    }

    public void setAveragePowerOn(double averagePowerOn) {
        this.averagePowerOn = averagePowerOn;
    }

    public double getAveragePowerOff() {
        return averagePowerOff;
    }

    public void setAveragePowerOff(double averagePowerOff) {
        this.averagePowerOff = averagePowerOff;
    }

    public double getAveragePowerOnTime() {
        return averagePowerOnTime;
    }

    public void setAveragePowerOnTime(double averagePowerOnTime) {
        this.averagePowerOnTime = averagePowerOnTime;
    }

    public double getAveragePowerOffTime() {
        return averagePowerOffTime;
    }

    public void setAveragePowerOffTime(double averagePowerOffTime) {
        this.averagePowerOffTime = averagePowerOffTime;
    }

    public double getHeatLoss() {
        return heatLoss;
    }

    public void setHeatLoss(double heatLoss) {
        this.heatLoss = heatLoss;
    }

    public double getIdlePoweroffHeatLoss() {
        return idlePoweroffHeatLoss;
    }

    public void setIdlePoweroffHeatLoss(double idlePoweroffHeatLoss) {
        this.idlePoweroffHeatLoss = idlePoweroffHeatLoss;
    }

    public double getAvailability() {
        return availability;
    }

    public void setAvailability(double availability) {
        this.availability = availability;
    }

    public double getDustBurnoff() {
        return dustBurnoff;
    }

    public void setDustBurnoff(double dustBurnoff) {
        this.dustBurnoff = dustBurnoff;
    }

    public MetalComposition getMetallicElementsBurnoff() {
        return metallicElementsBurnoff;
    }

    public void setMetallicElementsBurnoff(MetalComposition metallicElementsBurnoff) {
        this.metallicElementsBurnoff = metallicElementsBurnoff;
    }

    public double getAluminiumProductionCost() {
        return aluminiumProductionCost;
    }

    public void setAluminiumProductionCost(double aluminiumProductionCost) {
        this.aluminiumProductionCost = aluminiumProductionCost;
    }

}
