/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.generic;

import se.zaleth.jar.material.RawMaterial;
import se.zaleth.jar.plant.Depot;

/**
 *
 * @author krister
 */
public class StockRecord {
    
    private long id;
    private double quantity;
    private Inventory inventory;
    private RawMaterial material;
    private Depot depot;

}
