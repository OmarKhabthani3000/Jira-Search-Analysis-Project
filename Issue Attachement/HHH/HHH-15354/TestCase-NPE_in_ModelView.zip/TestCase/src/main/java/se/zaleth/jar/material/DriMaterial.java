/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import java.util.Set;
import se.zaleth.jar.generic.Currency;
import se.zaleth.jar.plant.MaterialContainer;
import se.zaleth.jar.plant.ReductionShaftFurnace;

/**
 *
 * @author krister
 */
public class DriMaterial extends RawMaterial {
    
    private ReductionShaftFurnace furnace;
    private Set<MaterialContainer> chargedMaterials;
    private double metallization;
    private double carbonContent;
    private double gasRFconst1;
    private double gasRFconst2;
    private double staffCost;
    private double capitalCost;
    private double overheadCost;
    private double maintinaceCost;
    private double briquettingCost;
    private double dustLossCost;
    private double oreFobCost;
    private double oreFreightCost;
    private double oreLandsideCost;
    private double naturalGasCost;
    private double electricCost;
    private double waterCost;
    private double oxygenCost;
    private boolean validCalculation;
    private boolean recentlyCalculated;
    private double ratioOreDri;
    private double maxCarbon;
    private double minCarbon;
    private Currency oreAndDRICurrency;

}
