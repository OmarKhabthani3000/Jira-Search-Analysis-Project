/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

/**
 *
 * @author krister
 */
public class CarbonSourceMaterial extends AbstractMaterial {
    
    private double heatContentEnergy;

    public double getHeatContentEnergy() {
        return heatContentEnergy;
    }

    public void setHeatContentEnergy(double heatContentEnergy) {
        this.heatContentEnergy = heatContentEnergy;
    }

}
