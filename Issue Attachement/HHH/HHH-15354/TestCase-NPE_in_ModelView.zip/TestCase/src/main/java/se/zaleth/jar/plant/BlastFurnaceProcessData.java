/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

/**
 *
 * @author krister
 */
public class BlastFurnaceProcessData {
    
    private long id;
    private double cokeConsumption;
    private double energyLossUpperZone;
    private double energyLossLowerZone;
    private double thermalZoneTemp;
    private double shaftEfficiency;
    private double calcination;
    private double topGasTemperature;
    private double topGasEtaH2;
    private double topGasEtaH2Constant;
    private double topGasEtaCo;
    private double topGasCO;
    private double topGasCO2;
    private double topGasH2;
    private double topFlowN2;
    private double hotMetalTemperature;
    private double blastTemperature;
    private double oxygenEnrichment;
    private double specificBlast;
    private double blastMoisture;
    private double blastAirTemperature;
    private double blastAirMoisture;
    private double productivity;
    private double flameTemperature;
    private double cRedMole;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getCokeConsumption() {
        return cokeConsumption;
    }

    public void setCokeConsumption(double cokeConsumption) {
        this.cokeConsumption = cokeConsumption;
    }

    public double getEnergyLossUpperZone() {
        return energyLossUpperZone;
    }

    public void setEnergyLossUpperZone(double energyLossUpperZone) {
        this.energyLossUpperZone = energyLossUpperZone;
    }

    public double getEnergyLossLowerZone() {
        return energyLossLowerZone;
    }

    public void setEnergyLossLowerZone(double energyLossLowerZone) {
        this.energyLossLowerZone = energyLossLowerZone;
    }

    public double getThermalZoneTemp() {
        return thermalZoneTemp;
    }

    public void setThermalZoneTemp(double thermalZoneTemp) {
        this.thermalZoneTemp = thermalZoneTemp;
    }

    public double getShaftEfficiency() {
        return shaftEfficiency;
    }

    public void setShaftEfficiency(double shaftEfficiency) {
        this.shaftEfficiency = shaftEfficiency;
    }

    public double getCalcination() {
        return calcination;
    }

    public void setCalcination(double calcination) {
        this.calcination = calcination;
    }

    public double getTopGasTemperature() {
        return topGasTemperature;
    }

    public void setTopGasTemperature(double topGasTemperature) {
        this.topGasTemperature = topGasTemperature;
    }

    public double getTopGasEtaH2() {
        return topGasEtaH2;
    }

    public void setTopGasEtaH2(double topGasEtaH2) {
        this.topGasEtaH2 = topGasEtaH2;
    }

    public double getTopGasEtaH2Constant() {
        return topGasEtaH2Constant;
    }

    public void setTopGasEtaH2Constant(double topGasEtaH2Constant) {
        this.topGasEtaH2Constant = topGasEtaH2Constant;
    }

    public double getTopGasEtaCo() {
        return topGasEtaCo;
    }

    public void setTopGasEtaCo(double topGasEtaCo) {
        this.topGasEtaCo = topGasEtaCo;
    }

    public double getTopGasCO() {
        return topGasCO;
    }

    public void setTopGasCO(double topGasCO) {
        this.topGasCO = topGasCO;
    }

    public double getTopGasCO2() {
        return topGasCO2;
    }

    public void setTopGasCO2(double topGasCO2) {
        this.topGasCO2 = topGasCO2;
    }

    public double getTopGasH2() {
        return topGasH2;
    }

    public void setTopGasH2(double topGasH2) {
        this.topGasH2 = topGasH2;
    }

    public double getTopFlowN2() {
        return topFlowN2;
    }

    public void setTopFlowN2(double topFlowN2) {
        this.topFlowN2 = topFlowN2;
    }

    public double getHotMetalTemperature() {
        return hotMetalTemperature;
    }

    public void setHotMetalTemperature(double hotMetalTemperature) {
        this.hotMetalTemperature = hotMetalTemperature;
    }

    public double getBlastTemperature() {
        return blastTemperature;
    }

    public void setBlastTemperature(double blastTemperature) {
        this.blastTemperature = blastTemperature;
    }

    public double getOxygenEnrichment() {
        return oxygenEnrichment;
    }

    public void setOxygenEnrichment(double oxygenEnrichment) {
        this.oxygenEnrichment = oxygenEnrichment;
    }

    public double getSpecificBlast() {
        return specificBlast;
    }

    public void setSpecificBlast(double specificBlast) {
        this.specificBlast = specificBlast;
    }

    public double getBlastMoisture() {
        return blastMoisture;
    }

    public void setBlastMoisture(double blastMoisture) {
        this.blastMoisture = blastMoisture;
    }

    public double getBlastAirTemperature() {
        return blastAirTemperature;
    }

    public void setBlastAirTemperature(double blastAirTemperature) {
        this.blastAirTemperature = blastAirTemperature;
    }

    public double getBlastAirMoisture() {
        return blastAirMoisture;
    }

    public void setBlastAirMoisture(double blastAirMoisture) {
        this.blastAirMoisture = blastAirMoisture;
    }

    public double getProductivity() {
        return productivity;
    }

    public void setProductivity(double productivity) {
        this.productivity = productivity;
    }

    public double getFlameTemperature() {
        return flameTemperature;
    }

    public void setFlameTemperature(double flameTemperature) {
        this.flameTemperature = flameTemperature;
    }

    public double getcRedMole() {
        return cRedMole;
    }

    public void setcRedMole(double cRedMole) {
        this.cRedMole = cRedMole;
    }

}
