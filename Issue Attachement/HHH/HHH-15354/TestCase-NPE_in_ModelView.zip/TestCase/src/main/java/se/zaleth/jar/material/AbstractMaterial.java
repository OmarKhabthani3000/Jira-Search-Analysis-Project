/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import se.zaleth.jar.administration.PROJECTUser;
import se.zaleth.jar.generic.Composition;
import se.zaleth.jar.generic.Currency;
import se.zaleth.jar.generic.MassConstraint;

/**
 *
 * @author krister
 */
public class AbstractMaterial {
    
    private long id;
    //private MaterialCategory materialCategory;
    private int epdType;
    private double price;
    private double distPrice;
    private double carbonLevel1;
    private double carbonLevel2;
    protected String name;
    protected String description;
    protected String loadingDescription;
    protected String co2Level2Description;
    private String attachmentFileName;
    private String attachmentContentType;
    private String attachmentFileName2;
    private String attachmentContentType2;
    private Date created;
    private Date updated;
    private boolean disabled;
    private byte[] imageBlob;
    private String imageBlobContentType;
    private byte[] attachment;
    private byte[] attachment2;
    private Set<DistributedRawMaterialSetting> materialSettings;
    protected Composition composition;
    private Composition standardDeviation;
    private Composition oxidationPercent;
    private Currency originalCurrency;
    private RawMaterialGroup parentGroup;
    private RawMaterialInheritance inheritance;
    protected MassConstraint massConstraint;
    protected boolean prioritized;
    protected double dustablePart;
    protected Double mass;
    protected Double slaggMass;
    protected int type;
    private Composition backupComposition;
    private PROJECTUser owner;
    private PROJECTUser executioner;
    private String zombieGroupName;
    private Date timeOfDeath;
    public Double massOfUndisMgO;
    private boolean temp;
    protected double initTemperature;
    protected int rawMatPhase;
    private boolean selected;
    public double massOfMaterialAfterDustRemoval;
    private double moisturePercent;
    private double foreignInertPercent;
    private double foreignCombustiblePercent;
    private double foreignCombustibleHeatContent;
    private double foreignInertHeatCapacity;
    private double foreignProcessCo2;
    private double foreignOxygenConsumption;
    private double yieldMainEelement;
    private Set<String> easilyOxidizedElementsForAluminum;
    private Set<String> easilyOxidizedElementsForIron;
    private boolean oxidized;
    private double totalConcentrationAfterOxidation;
    private String materialSystemName;
    public boolean treatedAtImport;
    //private SortingCategory sortingCategory;
    private double priceByForeignOxidation;
    private double energyFromEasilyOxidizedMaterial;
    private Composition originalCompositionBeforeSTD;
    private double materialOrderInBasket;
    private double materialBulkDensity;
    public String alternativeMaterial;
    public double loadingInterval;
    public static final int RECYLCLED = 0;
    public static final int PRIMARY = 1;
    public Integer recycled;
    private boolean hasCompositionWithStandardDeviation;

    public AbstractMaterial() {
        materialSettings = new HashSet<>();
        easilyOxidizedElementsForAluminum = new HashSet<>();
        easilyOxidizedElementsForIron = new HashSet<>();
    }
    
    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }

    public double getInputPrice() {
        return 0;
    }
    
    public void setInputPrice(double price) {
        
    }
    
    public int getMaterialCategoryValue() {
        return 0;
    }

    public void setMaterialCategoryValue(int materialCategory) {
        
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<DistributedRawMaterialSetting> getMaterialSettings() {
        return materialSettings;
    }

    public void setMaterialSettings(Set<DistributedRawMaterialSetting> materialSettings) {
        this.materialSettings = materialSettings;
    }

    public Set<String> getEasilyOxidizedElementsForAluminum() {
        return easilyOxidizedElementsForAluminum;
    }

    public void setEasilyOxidizedElementsForAluminum(Set<String> easilyOxidizedElementsForAluminum) {
        this.easilyOxidizedElementsForAluminum = easilyOxidizedElementsForAluminum;
    }

    public Set<String> getEasilyOxidizedElementsForIron() {
        return easilyOxidizedElementsForIron;
    }

    public void setEasilyOxidizedElementsForIron(Set<String> easilyOxidizedElementsForIron) {
        this.easilyOxidizedElementsForIron = easilyOxidizedElementsForIron;
    }

    public int getEpdType() {
        return epdType;
    }

    public void setEpdType(int epdType) {
        this.epdType = epdType;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getDistPrice() {
        return distPrice;
    }

    public void setDistPrice(double distPrice) {
        this.distPrice = distPrice;
    }

    public double getCarbonLevel1() {
        return carbonLevel1;
    }

    public void setCarbonLevel1(double carbonLevel1) {
        this.carbonLevel1 = carbonLevel1;
    }

    public double getCarbonLevel2() {
        return carbonLevel2;
    }

    public void setCarbonLevel2(double carbonLevel2) {
        this.carbonLevel2 = carbonLevel2;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLoadingDescription() {
        return loadingDescription;
    }

    public void setLoadingDescription(String loadingDescription) {
        this.loadingDescription = loadingDescription;
    }

    public String getCo2Level2Description() {
        return co2Level2Description;
    }

    public void setCo2Level2Description(String co2Level2Description) {
        this.co2Level2Description = co2Level2Description;
    }

    public String getAttachmentFileName() {
        return attachmentFileName;
    }

    public void setAttachmentFileName(String attachmentFileName) {
        this.attachmentFileName = attachmentFileName;
    }

    public String getAttachmentContentType() {
        return attachmentContentType;
    }

    public void setAttachmentContentType(String attachmentContentType) {
        this.attachmentContentType = attachmentContentType;
    }

    public String getAttachmentFileName2() {
        return attachmentFileName2;
    }

    public void setAttachmentFileName2(String attachmentFileName2) {
        this.attachmentFileName2 = attachmentFileName2;
    }

    public String getAttachmentContentType2() {
        return attachmentContentType2;
    }

    public void setAttachmentContentType2(String attachmentContentType2) {
        this.attachmentContentType2 = attachmentContentType2;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public boolean isDisabled() {
        return disabled;
    }

    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    public byte[] getImageBlob() {
        return imageBlob;
    }

    public void setImageBlob(byte[] imageBlob) {
        this.imageBlob = imageBlob;
    }

    public String getImageBlobContentType() {
        return imageBlobContentType;
    }

    public void setImageBlobContentType(String imageBlobContentType) {
        this.imageBlobContentType = imageBlobContentType;
    }

    public byte[] getAttachment() {
        return attachment;
    }

    public void setAttachment(byte[] attachment) {
        this.attachment = attachment;
    }

    public byte[] getAttachment2() {
        return attachment2;
    }

    public void setAttachment2(byte[] attachment2) {
        this.attachment2 = attachment2;
    }

    public Composition getComposition() {
        return composition;
    }

    public void setComposition(Composition composition) {
        this.composition = composition;
    }

    public Composition getStandardDeviation() {
        return standardDeviation;
    }

    public void setStandardDeviation(Composition standardDeviation) {
        this.standardDeviation = standardDeviation;
    }

    public Composition getOxidationPercent() {
        return oxidationPercent;
    }

    public void setOxidationPercent(Composition oxidationPercent) {
        this.oxidationPercent = oxidationPercent;
    }

    public Currency getOriginalCurrency() {
        return originalCurrency;
    }

    public void setOriginalCurrency(Currency originalCurrency) {
        this.originalCurrency = originalCurrency;
    }

    public RawMaterialGroup getParentGroup() {
        return parentGroup;
    }

    public void setParentGroup(RawMaterialGroup parentGroup) {
        this.parentGroup = parentGroup;
    }

    public RawMaterialInheritance getInheritance() {
        return inheritance;
    }

    public void setInheritance(RawMaterialInheritance inheritance) {
        this.inheritance = inheritance;
    }

    public MassConstraint getMassConstraint() {
        return massConstraint;
    }

    public void setMassConstraint(MassConstraint massConstraint) {
        this.massConstraint = massConstraint;
    }

    public boolean isPrioritized() {
        return prioritized;
    }

    public void setPrioritized(boolean prioritized) {
        this.prioritized = prioritized;
    }

    public double getDustablePart() {
        return dustablePart;
    }

    public void setDustablePart(double dustablePart) {
        this.dustablePart = dustablePart;
    }

    public Double getMass() {
        return mass;
    }

    public void setMass(Double mass) {
        this.mass = mass;
    }

    public Double getSlaggMass() {
        return slaggMass;
    }

    public void setSlaggMass(Double slaggMass) {
        this.slaggMass = slaggMass;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public Composition getBackupComposition() {
        return backupComposition;
    }

    public void setBackupComposition(Composition backupComposition) {
        this.backupComposition = backupComposition;
    }

    public PROJECTUser getOwner() {
        return owner;
    }

    public void setOwner(PROJECTUser owner) {
        this.owner = owner;
    }

    public PROJECTUser getExecutioner() {
        return executioner;
    }

    public void setExecutioner(PROJECTUser executioner) {
        this.executioner = executioner;
    }

    public String getZombieGroupName() {
        return zombieGroupName;
    }

    public void setZombieGroupName(String zombieGroupName) {
        this.zombieGroupName = zombieGroupName;
    }

    public Date getTimeOfDeath() {
        return timeOfDeath;
    }

    public void setTimeOfDeath(Date timeOfDeath) {
        this.timeOfDeath = timeOfDeath;
    }

    public Double getMassOfUndisMgO() {
        return massOfUndisMgO;
    }

    public void setMassOfUndisMgO(Double massOfUndisMgO) {
        this.massOfUndisMgO = massOfUndisMgO;
    }

    public boolean isTemp() {
        return temp;
    }

    public void setTemp(boolean temp) {
        this.temp = temp;
    }

    public double getInitTemperature() {
        return initTemperature;
    }

    public void setInitTemperature(double initTemperature) {
        this.initTemperature = initTemperature;
    }

    public int getRawMatPhase() {
        return rawMatPhase;
    }

    public void setRawMatPhase(int rawMatPhase) {
        this.rawMatPhase = rawMatPhase;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public double getMassOfMaterialAfterDustRemoval() {
        return massOfMaterialAfterDustRemoval;
    }

    public void setMassOfMaterialAfterDustRemoval(double massOfMaterialAfterDustRemoval) {
        this.massOfMaterialAfterDustRemoval = massOfMaterialAfterDustRemoval;
    }

    public double getMoisturePercent() {
        return moisturePercent;
    }

    public void setMoisturePercent(double moisturePercent) {
        this.moisturePercent = moisturePercent;
    }

    public double getForeignInertPercent() {
        return foreignInertPercent;
    }

    public void setForeignInertPercent(double foreignInertPercent) {
        this.foreignInertPercent = foreignInertPercent;
    }

    public double getForeignCombustiblePercent() {
        return foreignCombustiblePercent;
    }

    public void setForeignCombustiblePercent(double foreignCombustiblePercent) {
        this.foreignCombustiblePercent = foreignCombustiblePercent;
    }

    public double getForeignCombustibleHeatContent() {
        return foreignCombustibleHeatContent;
    }

    public void setForeignCombustibleHeatContent(double foreignCombustibleHeatContent) {
        this.foreignCombustibleHeatContent = foreignCombustibleHeatContent;
    }

    public double getForeignInertHeatCapacity() {
        return foreignInertHeatCapacity;
    }

    public void setForeignInertHeatCapacity(double foreignInertHeatCapacity) {
        this.foreignInertHeatCapacity = foreignInertHeatCapacity;
    }

    public double getForeignProcessCo2() {
        return foreignProcessCo2;
    }

    public void setForeignProcessCo2(double foreignProcessCo2) {
        this.foreignProcessCo2 = foreignProcessCo2;
    }

    public double getForeignOxygenConsumption() {
        return foreignOxygenConsumption;
    }

    public void setForeignOxygenConsumption(double foreignOxygenConsumption) {
        this.foreignOxygenConsumption = foreignOxygenConsumption;
    }

    public double getYieldMainEelement() {
        return yieldMainEelement;
    }

    public void setYieldMainEelement(double yieldMainEelement) {
        this.yieldMainEelement = yieldMainEelement;
    }

    public boolean isOxidized() {
        return oxidized;
    }

    public void setOxidized(boolean oxidized) {
        this.oxidized = oxidized;
    }

    public double getTotalConcentrationAfterOxidation() {
        return totalConcentrationAfterOxidation;
    }

    public void setTotalConcentrationAfterOxidation(double totalConcentrationAfterOxidation) {
        this.totalConcentrationAfterOxidation = totalConcentrationAfterOxidation;
    }

    public String getMaterialSystemName() {
        return materialSystemName;
    }

    public void setMaterialSystemName(String materialSystemName) {
        this.materialSystemName = materialSystemName;
    }

    public boolean isTreatedAtImport() {
        return treatedAtImport;
    }

    public void setTreatedAtImport(boolean treatedAtImport) {
        this.treatedAtImport = treatedAtImport;
    }

    public double getPriceByForeignOxidation() {
        return priceByForeignOxidation;
    }

    public void setPriceByForeignOxidation(double priceByForeignOxidation) {
        this.priceByForeignOxidation = priceByForeignOxidation;
    }

    public double getEnergyFromEasilyOxidizedMaterial() {
        return energyFromEasilyOxidizedMaterial;
    }

    public void setEnergyFromEasilyOxidizedMaterial(double energyFromEasilyOxidizedMaterial) {
        this.energyFromEasilyOxidizedMaterial = energyFromEasilyOxidizedMaterial;
    }

    public Composition getOriginalCompositionBeforeSTD() {
        return originalCompositionBeforeSTD;
    }

    public void setOriginalCompositionBeforeSTD(Composition originalCompositionBeforeSTD) {
        this.originalCompositionBeforeSTD = originalCompositionBeforeSTD;
    }

    public double getMaterialOrderInBasket() {
        return materialOrderInBasket;
    }

    public void setMaterialOrderInBasket(double materialOrderInBasket) {
        this.materialOrderInBasket = materialOrderInBasket;
    }

    public double getMaterialBulkDensity() {
        return materialBulkDensity;
    }

    public void setMaterialBulkDensity(double materialBulkDensity) {
        this.materialBulkDensity = materialBulkDensity;
    }

    public String getAlternativeMaterial() {
        return alternativeMaterial;
    }

    public void setAlternativeMaterial(String alternativeMaterial) {
        this.alternativeMaterial = alternativeMaterial;
    }

    public double getLoadingInterval() {
        return loadingInterval;
    }

    public void setLoadingInterval(double loadingInterval) {
        this.loadingInterval = loadingInterval;
    }

    public Integer getRecycled() {
        return recycled;
    }

    public void setRecycled(Integer recycled) {
        this.recycled = recycled;
    }

    public boolean isHasCompositionWithStandardDeviation() {
        return hasCompositionWithStandardDeviation;
    }

    public void setHasCompositionWithStandardDeviation(boolean hasCompositionWithStandardDeviation) {
        this.hasCompositionWithStandardDeviation = hasCompositionWithStandardDeviation;
    }
    
}
