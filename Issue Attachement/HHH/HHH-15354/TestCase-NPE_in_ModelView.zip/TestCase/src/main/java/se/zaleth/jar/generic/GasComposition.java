/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.generic;

/**
 *
 * @author krister
 */
public class GasComposition {
    
    private long id;
    private double O2;
    private double N2;
    private double H2;
    private double NO;
    private double CO;
    private double CO2;
    private double H2O;
    private double SO2;
    private double ZnS;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getO2() {
        return O2;
    }

    public void setO2(double O2) {
        this.O2 = O2;
    }

    public double getN2() {
        return N2;
    }

    public void setN2(double N2) {
        this.N2 = N2;
    }

    public double getH2() {
        return H2;
    }

    public void setH2(double H2) {
        this.H2 = H2;
    }

    public double getNO() {
        return NO;
    }

    public void setNO(double NO) {
        this.NO = NO;
    }

    public double getCO() {
        return CO;
    }

    public void setCO(double CO) {
        this.CO = CO;
    }

    public double getCO2() {
        return CO2;
    }

    public void setCO2(double CO2) {
        this.CO2 = CO2;
    }

    public double getH2O() {
        return H2O;
    }

    public void setH2O(double H2O) {
        this.H2O = H2O;
    }

    public double getSO2() {
        return SO2;
    }

    public void setSO2(double SO2) {
        this.SO2 = SO2;
    }

    public double getZnS() {
        return ZnS;
    }

    public void setZnS(double ZnS) {
        this.ZnS = ZnS;
    }

}
