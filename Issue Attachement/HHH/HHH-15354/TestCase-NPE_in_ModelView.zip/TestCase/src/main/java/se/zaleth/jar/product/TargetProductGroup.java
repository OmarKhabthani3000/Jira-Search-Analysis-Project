/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.product;

import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import se.zaleth.jar.administration.PROJECTUser;
import se.zaleth.jar.administration.UserGroup;
import se.zaleth.jar.generic.GroupMassConstraint;
import se.zaleth.jar.generic.MassConstraint;
import se.zaleth.jar.generic.Visibility;
import se.zaleth.jar.material.AbstractMaterial;
import se.zaleth.jar.material.CarbonSourceMaterial;
import se.zaleth.jar.material.RawMaterial;
import se.zaleth.jar.project.ProductionProfile;

/**
 *
 * @author krister
 */
public class TargetProductGroup {
    
    private long id;
    private String name;
    private String description;
    private Set<TargetProduct> targetProducts;
    private SortedSet<AbstractMaterial> rawMaterials;
    private Set<RawMaterial> rawMaterialWithConstraints;
    private Set<CarbonSourceMaterial> carbonMaterialWithConstraints;
    private PROJECTUser owner;
    private UserGroup group;
    private boolean standard;
    private boolean showForEducationVersion;
    private DistributionFactorSet factorSet;
    private DistributionFactorSet defaultFactorSet;
    private boolean selected;
    private boolean customSetup;
    private int slagModelType;
    private BasicModel slagModel;
    private BasicModel defaultSlagModel;
    private boolean useDustModel;
    private double slagMeltingEnergy;
    private Set<ProductionProfile> productionProfiles;
    private Visibility visibilitySetting;
    private List<GroupMassConstraint> targetGroupMassConstraints;
    private MassConstraint targetGroupTotalMassConstraint;
    private TargetProductCollection targetGroupColl;

}
