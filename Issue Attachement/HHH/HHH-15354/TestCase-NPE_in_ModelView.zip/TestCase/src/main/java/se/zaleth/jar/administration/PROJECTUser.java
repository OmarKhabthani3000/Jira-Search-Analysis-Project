/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.administration;

import se.zaleth.jar.generic.UserAuthorization;
import java.util.List;
import se.zaleth.jar.generic.Country;
import se.zaleth.jar.generic.Currency;

/**
 *
 * @author krister
 */
public class PROJECTUser {
    
    private long id;
    private String name;
    private List<UserGroupPermission> userP;
    private String userComment;
    private String displayName;
    private String email;
    private Country country;
    private String company;
    private int sysAdmin;
    private boolean supportUser;
    private int deleted;
    private boolean translator;
    private String presentation;
    private byte[] imageBlob;
    private String imageBlobContentType;
    private String www;
    private UserAuthorization authorization;
    private String sessionId;
    private Currency displayCurrency;
    private SanityCheck sanityCheck;
    private boolean forceChangePassword;
    private boolean approvedDisclaimer;
    private boolean acceptCookies;

}
