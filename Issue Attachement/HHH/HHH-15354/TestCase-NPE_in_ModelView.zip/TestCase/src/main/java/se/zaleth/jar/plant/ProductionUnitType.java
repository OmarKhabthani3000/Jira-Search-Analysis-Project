/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

/**
 *
 * @author krister
 */
public enum ProductionUnitType {
    REDUCTION_SHAFT_FURNACE(1), MELTING_FURNACE(2), INVENTORY(3), INDUCTION_FURNACE(4), CUPOLA_FURNACE(5), GAS_FIRED_FURNACE(6),
    BLAST_FURNACE(7), LD(8), SAF_FURNACE(9);
    private final long typeId;
    private final String languageKey;

    private ProductionUnitType(long typeId) {
        this.typeId = typeId;
        languageKey = "";
    }
    
}
