/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.administration;

/**
 *
 * @author krister
 */
public class UserGroupPermission {
    
    private int perm_pos;
    private long id;
    private int defGroup;
    private UserGroup group;
    private PROJECTRole role;
    private PROJECTUser owner;

    public int getRoleValue() {
        return 0;
    }
    
    public void setRoleValue(int value) {
        
    }
    
    public int getPerm_pos() {
        return perm_pos;
    }

    public void setPerm_pos(int perm_pos) {
        this.perm_pos = perm_pos;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getDefGroup() {
        return defGroup;
    }

    public void setDefGroup(int defGroup) {
        this.defGroup = defGroup;
    }

    public UserGroup getGroup() {
        return group;
    }

    public void setGroup(UserGroup group) {
        this.group = group;
    }

    public PROJECTRole getRole() {
        return role;
    }

    public void setRole(PROJECTRole role) {
        this.role = role;
    }

    public PROJECTUser getOwner() {
        return owner;
    }

    public void setOwner(PROJECTUser owner) {
        this.owner = owner;
    }

}
