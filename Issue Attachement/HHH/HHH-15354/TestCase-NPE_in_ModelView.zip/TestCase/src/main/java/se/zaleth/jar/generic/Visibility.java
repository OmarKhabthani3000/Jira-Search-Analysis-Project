/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.generic;

/**
 *
 * @author krister
 */
public enum Visibility {
    PUBLIC(1), PRIVATE(2), HIDDEN(3);
    private final int visibilityValue;
    private final String languageKey;

    private Visibility(int visibilityValue) {
        this.visibilityValue = visibilityValue;
        languageKey = "";
    }
    
}
