/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.product;

import java.util.Date;
import se.zaleth.jar.administration.PROJECTUser;
import se.zaleth.jar.administration.UserGroup;

/**
 *
 * @author krister
 */
public class TargetProductCollection {
    
    private long id;
    private TargetProductCollection parentTargetCollection;
    private String name;
    private String description;
    private Date createdDate;
    private Date updatedDate;
    private PROJECTUser createdBy;
    private UserGroup userGroup;

}
