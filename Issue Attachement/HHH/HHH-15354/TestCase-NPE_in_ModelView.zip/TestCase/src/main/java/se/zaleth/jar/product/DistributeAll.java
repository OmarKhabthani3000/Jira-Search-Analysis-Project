/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.product;

/**
 *
 * @author krister
 */
public class DistributeAll {
    
    private long id;
    private Boolean C;
    private Boolean Si;
    private Boolean Mn;
    private Boolean P;
    private Boolean S;
    private Boolean Cr;
    private Boolean Ni;
    private Boolean Mo;
    private Boolean Nb;
    private Boolean N;
    private Boolean Ti;
    private Boolean Cu;
    private Boolean Al;
    private Boolean V;
    private Boolean W;
    private Boolean Fe;
    private Boolean H;
    private Boolean O;
    private Boolean Co;
    private Boolean As;
    private Boolean B;
    private Boolean Bi;
    private Boolean Pb;
    private Boolean Ca;
    private Boolean Ta;
    private Boolean Sn;
    private Boolean Zn;
    private Boolean Ce;
    private Boolean Sb;
    private Boolean Te;
    private Boolean Na;
    private Boolean K;
    private Boolean Mg;
    private Boolean Li;
    private Boolean Ba;
    private Boolean Be;
    private Boolean Sr;
    private Boolean Zr;
    private Boolean Cd;
    private Boolean Hg;
    private Boolean Cl;
    private Boolean Ag;
    private Boolean F;
    private boolean notNullC;
    private boolean notNullSi;
    private boolean notNullMn;
    private boolean notNullP;
    private boolean notNullS;
    private boolean notNullCr;
    private boolean notNullNi;
    private boolean notNullMo;
    private boolean notNullNb;
    private boolean notNullN;
    private boolean notNullTi;
    private boolean notNullCu;
    private boolean notNullAl;
    private boolean notNullV;
    private boolean notNullW;
    private boolean notNullFe;
    private boolean notNullH;
    private boolean notNullO;
    private boolean notNullCo;
    private boolean notNullAs;
    private boolean notNullB;
    private boolean notNullBi;
    private boolean notNullPb;
    private boolean notNullCa;
    private boolean notNullTa;
    private boolean notNullSn;
    private boolean notNullZn;
    private boolean notNullCe;
    private boolean notNullSb;
    private boolean notNullTe;
    private boolean notNullNa;
    private boolean notNullK;
    private boolean notNullMg;
    private boolean notNullLi;
    private boolean notNullBa;
    private boolean notNullBe;
    private boolean notNullSr;
    private boolean notNullZr;
    private boolean notNullCd;
    private boolean notNullHg;
    private boolean notNullCl;
    private boolean notNullAg;
    private boolean notNullF;

}
