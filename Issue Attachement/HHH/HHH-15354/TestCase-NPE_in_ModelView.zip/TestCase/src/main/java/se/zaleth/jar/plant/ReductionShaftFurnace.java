/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

/**
 *
 * @author krister
 */
public class ReductionShaftFurnace extends ProductionUnit {
    
    double bricketingCost;
    double metallization;
    double carbon;
    double gasConsumption;
    double electricConsumption;
    double oxygenConsumption;
    double waterConstumption;
    double productivity;
    double gasRFconst1;
    double gasRFconst2;
    double chargeTemperaturetoEAF;
    double productionYield;
    double averageCpDRI;

    public double getBricketingCost() {
        return bricketingCost;
    }

    public void setBricketingCost(double bricketingCost) {
        this.bricketingCost = bricketingCost;
    }

    public double getInputBricketingCost() {
        return 0;
    }

    public void setInputBricketingCost(double bricketingCost) {
    }

    public double getMetallization() {
        return metallization;
    }

    public void setMetallization(double metallization) {
        this.metallization = metallization;
    }

    public double getCarbon() {
        return carbon;
    }

    public void setCarbon(double carbon) {
        this.carbon = carbon;
    }

    public double getGasConsumption() {
        return gasConsumption;
    }

    public void setGasConsumption(double gasConsumption) {
        this.gasConsumption = gasConsumption;
    }

    public double getElectricConsumption() {
        return electricConsumption;
    }

    public void setElectricConsumption(double electricConsumption) {
        this.electricConsumption = electricConsumption;
    }

    public double getOxygenConsumption() {
        return oxygenConsumption;
    }

    public void setOxygenConsumption(double oxygenConsumption) {
        this.oxygenConsumption = oxygenConsumption;
    }

    public double getWaterConstumption() {
        return waterConstumption;
    }

    public void setWaterConstumption(double waterConstumption) {
        this.waterConstumption = waterConstumption;
    }

    public double getProductivity() {
        return productivity;
    }

    public void setProductivity(double productivity) {
        this.productivity = productivity;
    }

    public double getGasRFconst1() {
        return gasRFconst1;
    }

    public void setGasRFconst1(double gasRFconst1) {
        this.gasRFconst1 = gasRFconst1;
    }

    public double getGasRFconst2() {
        return gasRFconst2;
    }

    public void setGasRFconst2(double gasRFconst2) {
        this.gasRFconst2 = gasRFconst2;
    }

    public double getChargeTemperaturetoEAF() {
        return chargeTemperaturetoEAF;
    }

    public void setChargeTemperaturetoEAF(double chargeTemperaturetoEAF) {
        this.chargeTemperaturetoEAF = chargeTemperaturetoEAF;
    }

    public double getProductionYield() {
        return productionYield;
    }

    public void setProductionYield(double productionYield) {
        this.productionYield = productionYield;
    }

    public double getAverageCpDRI() {
        return averageCpDRI;
    }

    public void setAverageCpDRI(double averageCpDRI) {
        this.averageCpDRI = averageCpDRI;
    }

}
