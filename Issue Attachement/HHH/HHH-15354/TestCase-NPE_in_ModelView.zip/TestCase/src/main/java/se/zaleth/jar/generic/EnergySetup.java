/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.generic;

import se.zaleth.jar.material.AbstractMaterial;

/**
 *
 * @author krister
 */
public class EnergySetup {
    
    private long id;
    private AbstractMaterial energySourceOne;
    private AbstractMaterial energySourceTwo;
    private AbstractMaterial energySourceThree;
    private AbstractMaterial energySourceFour;
    private AbstractMaterial energySourceElectrode;
    private double efficiencyOne;
    private double efficiencyTwo;
    private double efficiencyThree;
    private double efficiencyFour;
    private double quantityOfOne;
    private double quantityOfTwo;
    private double quantityOfThree;
    private double quantityOfFour;
    private double smeltTemperature;
    private double castingTemperature;
    private boolean calculateUseOfSourceThree;
    private boolean calculateUseOfSourceFour;
    private double percentLoadCupola;
    private double temperatureLossAfterTap;

}
