/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

import se.zaleth.jar.material.RawMaterial;

/**
 *
 * @author krister
 */
public class Depot {
    
    private long id;
    private String name;
    private String shortName;
    private String description;
    private double capacity;
    private int order;
    private RawMaterialStore rawMaterialStore;
    private RawMaterial material;
    private double temporaryQuantity;

}
