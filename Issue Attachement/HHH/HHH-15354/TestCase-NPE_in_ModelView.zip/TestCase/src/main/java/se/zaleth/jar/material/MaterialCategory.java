/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

/**
 *
 * @author krister
 */
public enum MaterialCategory {
    SCRAP_AND_ALLOYS(1), ORES(2), REDUCTION_AGENTS(3), SLAG_FORMERS(4), ENERGY_AND_REDUCTION_GASES(5), CARBON_SOURCE(6), ELECTRICITY(7),
    PROCESS_GASES(8), MEDIA(9), DRI(10), CALCULATION_RESULT(11), DRI_VARIABLE_C(12), DUMMY_MATERIAL(13), ALLOYS(14), ALLOYING_MATERIALS(15),
    DESULFURIZATION_AGENT(16), DEPHOSPHORIZATION_AGENT(17), HOT_METAL(18);
    private final int categoryValue;
    private final String actionClass;
    private final String messageKey;

    private MaterialCategory(int category) {
        categoryValue = category;
        actionClass = "";
        messageKey = "";
    }    
}
