/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

import se.zaleth.jar.material.AbstractMaterial;

/**
 *
 * @author krister
 */
public class MaterialContainerBlastFurnace {
    
    AbstractMaterial material;
    double materialAmount;
    double amountMin;
    double amountMax;
    double materialAmountKgPerTonHotMetal;
    double pctAmount;
    double cost;

    public int getMaterialSortValue() {
        return 0;
    }

    public void setMaterialSortValue(int materialCategory) {
    }

    public AbstractMaterial getMaterial() {
        return material;
    }

    public void setMaterial(AbstractMaterial material) {
        this.material = material;
    }

    public double getMaterialAmount() {
        return materialAmount;
    }

    public void setMaterialAmount(double materialAmount) {
        this.materialAmount = materialAmount;
    }

    public double getAmountMin() {
        return amountMin;
    }

    public void setAmountMin(double amountMin) {
        this.amountMin = amountMin;
    }

    public double getAmountMax() {
        return amountMax;
    }

    public void setAmountMax(double amountMax) {
        this.amountMax = amountMax;
    }

    public double getMaterialAmountKgPerTonHotMetal() {
        return materialAmountKgPerTonHotMetal;
    }

    public void setMaterialAmountKgPerTonHotMetal(double materialAmountKgPerTonHotMetal) {
        this.materialAmountKgPerTonHotMetal = materialAmountKgPerTonHotMetal;
    }

    public double getPctAmount() {
        return pctAmount;
    }

    public void setPctAmount(double pctAmount) {
        this.pctAmount = pctAmount;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

}
