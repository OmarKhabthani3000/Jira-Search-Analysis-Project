/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.generic;

import java.util.Date;
import java.util.Set;
import se.zaleth.jar.project.ProductionProfile;

/**
 *
 * @author krister
 */
public class License {

    private long id;
    private Date validFrom;
    private Date validTo;
    private int usercapacity;
    private int maxFurnaces;
    private int maxRawMaterials;
    private int maxRawMaterialGroups;
    private int maxTargetProducts;
    private int maxTargetProductsGroup;
    private Set<ProductionProfile> productionProfiles;
    private long permission;
    private int selectedProfile;

}
