package se.zaleth.jar.generic;


import se.zaleth.jar.administration.PROJECTUser;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author krister
 */
public class UserAuthorization {
    
    private PROJECTUser holder;
    private boolean allowFurnaceCreation;
    private boolean allowCreateNewStoredProduct;
    private boolean allowCreationOfNewStoredMaterials;
    private boolean allowCreationOfNewRawMaterialGroups;
    private boolean allowCreationOfNewProductGroups;
    private boolean allowImportOfSuppliedAndStandardMaterials;
    private double numberOfMaterialAllowedToCreate;

}
