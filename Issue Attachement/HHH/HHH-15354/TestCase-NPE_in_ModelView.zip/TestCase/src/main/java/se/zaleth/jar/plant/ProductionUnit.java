/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

import java.util.List;
import se.zaleth.jar.administration.PROJECTUser;
import se.zaleth.jar.administration.UserGroup;
import se.zaleth.jar.generic.Currency;
import se.zaleth.jar.generic.EnergySetup;
import se.zaleth.jar.generic.TypeConstraint;
import se.zaleth.jar.generic.Visibility;
import se.zaleth.jar.material.AbstractMaterial;
import se.zaleth.jar.material.CarbonSourceMaterial;
import se.zaleth.jar.material.MediaMaterial;
import se.zaleth.jar.material.ProcessGasMaterial;

/**
 *
 * @author krister
 */
public class ProductionUnit {
    
    private long id;
    private String name;
    private String description;
    private boolean online;
    private EnergySetup energySetup;
    private boolean belongsToStandardSet;
    private double costPersonnel;
    private double costOverHead;
    private double costMaintenance;
    private ProductionUnitType productionUnitType;
    private CarbonSourceMaterial electrodeMaterial;
    private MediaMaterial waterSource;
    private double processWaterUse;
    private double electricityUse;
    private double costCapitalDepreciation;
    private double costCapitalInterest;
    private double costCapitalInvest;
    private UserGroup userGroup;
    private String locationName;
    private Currency currency;
    private List<TypeConstraint> typeConstraints;
    private int numOfTypeConstraints;
    private double percentFromForeignMaterialOrOxidation;
    private double averageTimeLossByForeignMaterialOrOxidation;
    private double valueGeneration;
    private Visibility visibilitySetting;
    private PROJECTUser owner;
    private boolean advancedView;
    private double amountInFirstBasket;
    private double minMaterialToDistributeBetweenTwoBaskets;
    private String plantSystemName;
    private double castingCapacity;
    private int secondaryFurnaceType;
    private CarbonSourceMaterial electrodeMaterialSecondary;
    private double electrodeUseSecondaryFurnace;
    private double averagePowerOnSecondary;
    private double heatLossSecondary;
    private double secondaryTreatmentLosses;
    private double gasSecondaryAmount;
    private double electricitySecondaryAmount;
    private ProcessGasMaterial secondaryGasMaterial;
    private AbstractMaterial electricitySecondary;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public AbstractMaterial getElectricitySecondary() {
        return electricitySecondary;
    }

    public void setElectricitySecondary(AbstractMaterial electricitySecondary) {
        this.electricitySecondary = electricitySecondary;
    }

    public int getVisibilitySettingValue() {
        return 0;
    }

    public void setVisibilitySettingValue(int vivibilitySetting) {
    
    }
    
    public double getInputCostPersonnelYear() {
        return 0;
    }

    public void setInputCostPersonnelYear(double costPersonnel) {
    }

    public double getCostCapitalYearLocalCurrency() {
        return 0;
    }

    public double getCostCapitalYear() {
        return 0;
    }

    public double getCostMaintenanceYear() {
        return 0;
    }

    public void setCostMaintenanceYear(double costMaintenance) {
    }

    public double getInputCostMaintenanceYear() {
        return 0;
    }

    public void setInputCostMaintenanceYear(double costMaintenance) {
    }

    public double getCostOverHeadYear() {
        return 0;
    }

    public void setCostOverHeadYear(double costOverHead) {
    }

    public double getInputCostOverHeadYear() {
        return 0;
    }

    public void setInputCostOverHeadYear(double costOverHead) {
    }

    public double getCostPersonnelYear() {
        return 0;
    }

    public void setCostPersonnelYear(double costPersonnel) {
    }

    public double getInputCostCapitalInvest() {
        return 0;
    }

    public void setInputCostCapitalInvest(double costCapitalInvest) {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isOnline() {
        return online;
    }

    public void setOnline(boolean online) {
        this.online = online;
    }

    public EnergySetup getEnergySetup() {
        return energySetup;
    }

    public void setEnergySetup(EnergySetup energySetup) {
        this.energySetup = energySetup;
    }

    public boolean isBelongsToStandardSet() {
        return belongsToStandardSet;
    }

    public void setBelongsToStandardSet(boolean belongsToStandardSet) {
        this.belongsToStandardSet = belongsToStandardSet;
    }

    public double getCostPersonnel() {
        return costPersonnel;
    }

    public void setCostPersonnel(double costPersonnel) {
        this.costPersonnel = costPersonnel;
    }

    public double getCostOverHead() {
        return costOverHead;
    }

    public void setCostOverHead(double costOverHead) {
        this.costOverHead = costOverHead;
    }

    public double getCostMaintenance() {
        return costMaintenance;
    }

    public void setCostMaintenance(double costMaintenance) {
        this.costMaintenance = costMaintenance;
    }

    public ProductionUnitType getProductionUnitType() {
        return productionUnitType;
    }

    public void setProductionUnitType(ProductionUnitType productionUnitType) {
        this.productionUnitType = productionUnitType;
    }

    public CarbonSourceMaterial getElectrodeMaterial() {
        return electrodeMaterial;
    }

    public void setElectrodeMaterial(CarbonSourceMaterial electrodeMaterial) {
        this.electrodeMaterial = electrodeMaterial;
    }

    public MediaMaterial getWaterSource() {
        return waterSource;
    }

    public void setWaterSource(MediaMaterial waterSource) {
        this.waterSource = waterSource;
    }

    public double getProcessWaterUse() {
        return processWaterUse;
    }

    public void setProcessWaterUse(double processWaterUse) {
        this.processWaterUse = processWaterUse;
    }

    public double getElectricityUse() {
        return electricityUse;
    }

    public void setElectricityUse(double electricityUse) {
        this.electricityUse = electricityUse;
    }

    public double getCostCapitalDepreciation() {
        return costCapitalDepreciation;
    }

    public void setCostCapitalDepreciation(double costCapitalDepreciation) {
        this.costCapitalDepreciation = costCapitalDepreciation;
    }

    public double getCostCapitalInterest() {
        return costCapitalInterest;
    }

    public void setCostCapitalInterest(double costCapitalInterest) {
        this.costCapitalInterest = costCapitalInterest;
    }

    public double getCostCapitalInvest() {
        return costCapitalInvest;
    }

    public void setCostCapitalInvest(double costCapitalInvest) {
        this.costCapitalInvest = costCapitalInvest;
    }

    public UserGroup getUserGroup() {
        return userGroup;
    }

    public void setUserGroup(UserGroup userGroup) {
        this.userGroup = userGroup;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public List<TypeConstraint> getTypeConstraints() {
        return typeConstraints;
    }

    public void setTypeConstraints(List<TypeConstraint> typeConstraints) {
        this.typeConstraints = typeConstraints;
    }

    public int getNumOfTypeConstraints() {
        return numOfTypeConstraints;
    }

    public void setNumOfTypeConstraints(int numOfTypeConstraints) {
        this.numOfTypeConstraints = numOfTypeConstraints;
    }

    public double getPercentFromForeignMaterialOrOxidation() {
        return percentFromForeignMaterialOrOxidation;
    }

    public void setPercentFromForeignMaterialOrOxidation(double percentFromForeignMaterialOrOxidation) {
        this.percentFromForeignMaterialOrOxidation = percentFromForeignMaterialOrOxidation;
    }

    public double getAverageTimeLossByForeignMaterialOrOxidation() {
        return averageTimeLossByForeignMaterialOrOxidation;
    }

    public void setAverageTimeLossByForeignMaterialOrOxidation(double averageTimeLossByForeignMaterialOrOxidation) {
        this.averageTimeLossByForeignMaterialOrOxidation = averageTimeLossByForeignMaterialOrOxidation;
    }

    public double getValueGeneration() {
        return valueGeneration;
    }

    public void setValueGeneration(double valueGeneration) {
        this.valueGeneration = valueGeneration;
    }

    public Visibility getVisibilitySetting() {
        return visibilitySetting;
    }

    public void setVisibilitySetting(Visibility visibilitySetting) {
        this.visibilitySetting = visibilitySetting;
    }

    public PROJECTUser getOwner() {
        return owner;
    }

    public void setOwner(PROJECTUser owner) {
        this.owner = owner;
    }

    public boolean isAdvancedView() {
        return advancedView;
    }

    public void setAdvancedView(boolean advancedView) {
        this.advancedView = advancedView;
    }

    public double getAmountInFirstBasket() {
        return amountInFirstBasket;
    }

    public void setAmountInFirstBasket(double amountInFirstBasket) {
        this.amountInFirstBasket = amountInFirstBasket;
    }

    public double getMinMaterialToDistributeBetweenTwoBaskets() {
        return minMaterialToDistributeBetweenTwoBaskets;
    }

    public void setMinMaterialToDistributeBetweenTwoBaskets(double minMaterialToDistributeBetweenTwoBaskets) {
        this.minMaterialToDistributeBetweenTwoBaskets = minMaterialToDistributeBetweenTwoBaskets;
    }

    public String getPlantSystemName() {
        return plantSystemName;
    }

    public void setPlantSystemName(String plantSystemName) {
        this.plantSystemName = plantSystemName;
    }

    public double getCastingCapacity() {
        return castingCapacity;
    }

    public void setCastingCapacity(double castingCapacity) {
        this.castingCapacity = castingCapacity;
    }

    public int getSecondaryFurnaceType() {
        return secondaryFurnaceType;
    }

    public void setSecondaryFurnaceType(int secondaryFurnaceType) {
        this.secondaryFurnaceType = secondaryFurnaceType;
    }

    public CarbonSourceMaterial getElectrodeMaterialSecondary() {
        return electrodeMaterialSecondary;
    }

    public void setElectrodeMaterialSecondary(CarbonSourceMaterial electrodeMaterialSecondary) {
        this.electrodeMaterialSecondary = electrodeMaterialSecondary;
    }

    public double getElectrodeUseSecondaryFurnace() {
        return electrodeUseSecondaryFurnace;
    }

    public void setElectrodeUseSecondaryFurnace(double electrodeUseSecondaryFurnace) {
        this.electrodeUseSecondaryFurnace = electrodeUseSecondaryFurnace;
    }

    public double getAveragePowerOnSecondary() {
        return averagePowerOnSecondary;
    }

    public void setAveragePowerOnSecondary(double averagePowerOnSecondary) {
        this.averagePowerOnSecondary = averagePowerOnSecondary;
    }

    public double getHeatLossSecondary() {
        return heatLossSecondary;
    }

    public void setHeatLossSecondary(double heatLossSecondary) {
        this.heatLossSecondary = heatLossSecondary;
    }

    public double getSecondaryTreatmentLosses() {
        return secondaryTreatmentLosses;
    }

    public void setSecondaryTreatmentLosses(double secondaryTreatmentLosses) {
        this.secondaryTreatmentLosses = secondaryTreatmentLosses;
    }

    public double getGasSecondaryAmount() {
        return gasSecondaryAmount;
    }

    public void setGasSecondaryAmount(double gasSecondaryAmount) {
        this.gasSecondaryAmount = gasSecondaryAmount;
    }

    public double getElectricitySecondaryAmount() {
        return electricitySecondaryAmount;
    }

    public void setElectricitySecondaryAmount(double electricitySecondaryAmount) {
        this.electricitySecondaryAmount = electricitySecondaryAmount;
    }

    public ProcessGasMaterial getSecondaryGasMaterial() {
        return secondaryGasMaterial;
    }

    public void setSecondaryGasMaterial(ProcessGasMaterial secondaryGasMaterial) {
        this.secondaryGasMaterial = secondaryGasMaterial;
    }
    
}
