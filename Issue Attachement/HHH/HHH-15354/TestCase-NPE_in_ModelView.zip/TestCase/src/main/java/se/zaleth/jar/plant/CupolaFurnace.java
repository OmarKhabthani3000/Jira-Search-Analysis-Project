/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

import se.zaleth.jar.generic.MetalComposition;

/**
 *
 * @author krister
 */
public class CupolaFurnace extends ProductionUnit {
    
    private double percentLoadFirstCokeMaterial;
    private double capacity;
    private double dustBurnoff;
    private double feOxidationDegree;
    private double dumpWeight;
    private double slagBasicity;
    private double averagePowerOn;
    private double heatLoss;
    private double blastTemperature;
    private double blastOxygenEnrichment;
    private double ettaCO;
    private double heatExchangerEfficiency;
    private double offGasTemperature;
    private MetalComposition metallicElementsBurnoff;

    public double getPercentLoadFirstCokeMaterial() {
        return percentLoadFirstCokeMaterial;
    }

    public void setPercentLoadFirstCokeMaterial(double percentLoadFirstCokeMaterial) {
        this.percentLoadFirstCokeMaterial = percentLoadFirstCokeMaterial;
    }

    public double getCapacity() {
        return capacity;
    }

    public void setCapacity(double capacity) {
        this.capacity = capacity;
    }

    public double getDustBurnoff() {
        return dustBurnoff;
    }

    public void setDustBurnoff(double dustBurnoff) {
        this.dustBurnoff = dustBurnoff;
    }

    public double getFeOxidationDegree() {
        return feOxidationDegree;
    }

    public void setFeOxidationDegree(double feOxidationDegree) {
        this.feOxidationDegree = feOxidationDegree;
    }

    public double getDumpWeight() {
        return dumpWeight;
    }

    public void setDumpWeight(double dumpWeight) {
        this.dumpWeight = dumpWeight;
    }

    public double getSlagBasicity() {
        return slagBasicity;
    }

    public void setSlagBasicity(double slagBasicity) {
        this.slagBasicity = slagBasicity;
    }

    public double getAveragePowerOn() {
        return averagePowerOn;
    }

    public void setAveragePowerOn(double averagePowerOn) {
        this.averagePowerOn = averagePowerOn;
    }

    public double getHeatLoss() {
        return heatLoss;
    }

    public void setHeatLoss(double heatLoss) {
        this.heatLoss = heatLoss;
    }

    public double getBlastTemperature() {
        return blastTemperature;
    }

    public void setBlastTemperature(double blastTemperature) {
        this.blastTemperature = blastTemperature;
    }

    public double getBlastOxygenEnrichment() {
        return blastOxygenEnrichment;
    }

    public void setBlastOxygenEnrichment(double blastOxygenEnrichment) {
        this.blastOxygenEnrichment = blastOxygenEnrichment;
    }

    public double getEttaCO() {
        return ettaCO;
    }

    public void setEttaCO(double ettaCO) {
        this.ettaCO = ettaCO;
    }

    public double getHeatExchangerEfficiency() {
        return heatExchangerEfficiency;
    }

    public void setHeatExchangerEfficiency(double heatExchangerEfficiency) {
        this.heatExchangerEfficiency = heatExchangerEfficiency;
    }

    public double getOffGasTemperature() {
        return offGasTemperature;
    }

    public void setOffGasTemperature(double offGasTemperature) {
        this.offGasTemperature = offGasTemperature;
    }

    public MetalComposition getMetallicElementsBurnoff() {
        return metallicElementsBurnoff;
    }

    public void setMetallicElementsBurnoff(MetalComposition metallicElementsBurnoff) {
        this.metallicElementsBurnoff = metallicElementsBurnoff;
    }

}
