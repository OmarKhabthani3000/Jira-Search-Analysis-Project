/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import se.zaleth.jar.generic.Composition;
import se.zaleth.jar.generic.MetalComposition;
import se.zaleth.jar.material.AbstractMaterial;
import se.zaleth.jar.material.CarbonSourceMaterial;
import se.zaleth.jar.material.ElectricityMaterial;
import se.zaleth.jar.material.ProcessGasMaterial;

/**
 *
 * @author krister
 */
public class BlastFurnace extends ProductionUnit {
    
    private Composition compositionCalibration;
    private double maxPAverage;
    private double maxVAverage;
    private Composition dustCompositionCalibration;
    private double dustAmountCalibration;
    private Date calibrationStartDate;
    private String calibrationStartTime;
    private Date calibrationEndDate;
    private String calibrationEndTime;
    private String calibrationComment;
    private List<MaterialContainerBlastFurnace> calibrationMaterials;
    private MetalComposition distributionFactorCalibrate;
    private double meltAmountCalibrate;
    private double slagAmountCalibrate;
    private MetalComposition distributionFactorUse;
    private MetalComposition useCalibratedDistributionFactor;
    private MetalComposition metalCompositionUse;
    private MetalComposition metalCompositionOfSlagElementsUse;
    private MetalComposition metalCompositionOfSlagElementsCalib;
    private double maxPUse;
    private double maxVUse;
    private MetalComposition useAverageMetalComposition;
    private MetalComposition useAverageMetalCompositionOfSlagElements;
    private double slagBasicityUse;
    private double slagAmountUse;
    private boolean useAverageSlagBasicity;
    private boolean useCalibratedSlagAmount;
    private boolean useMaxPAverage;
    private boolean useMaxVAverage;
    private List<MaterialContainerBlastFurnace> defaultMaterials;
    private CarbonSourceMaterial coke;
    private double cokeAmount;
    private CarbonSourceMaterial injectionOne;
    private AbstractMaterial injectionTwo;
    private double injectionOneAmount;
    private double injectionTwoAmount;
    private double dustAmount;
    private double blastAmount;
    private ProcessGasMaterial blastSource;
    private ProcessGasMaterial oxygenSource;
    private ElectricityMaterial electricitySource;
    private double electricityAmountKWh;
    private double oxygenVolume;
    private BlastFurnaceProcessData processDataCalibration;
    private BlastFurnaceProcessData processDataUse;
    private BlastFurnaceProcessData isUseCalibrationProcessData;
    private double availability;
    private double blastCapacity;
    private double annualProduction;
    private double slagProductionCost;
    private double gasProductionCost;
    double productivity;
    private Integer isEtaH2Used;
    private Integer isBlastMoistureUsed;

    public Composition getCompositionCalibration() {
        return compositionCalibration;
    }

    public void setCompositionCalibration(Composition compositionCalibration) {
        this.compositionCalibration = compositionCalibration;
    }

    public double getMaxPAverage() {
        return maxPAverage;
    }

    public void setMaxPAverage(double maxPAverage) {
        this.maxPAverage = maxPAverage;
    }

    public double getMaxVAverage() {
        return maxVAverage;
    }

    public void setMaxVAverage(double maxVAverage) {
        this.maxVAverage = maxVAverage;
    }

    public Composition getDustCompositionCalibration() {
        return dustCompositionCalibration;
    }

    public void setDustCompositionCalibration(Composition dustCompositionCalibration) {
        this.dustCompositionCalibration = dustCompositionCalibration;
    }

    public double getDustAmountCalibration() {
        return dustAmountCalibration;
    }

    public void setDustAmountCalibration(double dustAmountCalibration) {
        this.dustAmountCalibration = dustAmountCalibration;
    }

    public Date getCalibrationStartDate() {
        return calibrationStartDate;
    }

    public void setCalibrationStartDate(Date calibrationStartDate) {
        this.calibrationStartDate = calibrationStartDate;
    }

    public String getCalibrationStartTime() {
        return calibrationStartTime;
    }

    public void setCalibrationStartTime(String calibrationStartTime) {
        this.calibrationStartTime = calibrationStartTime;
    }

    public Date getCalibrationEndDate() {
        return calibrationEndDate;
    }

    public void setCalibrationEndDate(Date calibrationEndDate) {
        this.calibrationEndDate = calibrationEndDate;
    }

    public String getCalibrationEndTime() {
        return calibrationEndTime;
    }

    public void setCalibrationEndTime(String calibrationEndTime) {
        this.calibrationEndTime = calibrationEndTime;
    }

    public String getCalibrationComment() {
        return calibrationComment;
    }

    public void setCalibrationComment(String calibrationComment) {
        this.calibrationComment = calibrationComment;
    }

    public List<MaterialContainerBlastFurnace> getCalibrationMaterials() {
        return calibrationMaterials;
    }

    public void setCalibrationMaterials(List<MaterialContainerBlastFurnace> calibrationMaterials) {
        this.calibrationMaterials = calibrationMaterials;
    }

    public MetalComposition getDistributionFactorCalibrate() {
        return distributionFactorCalibrate;
    }

    public void setDistributionFactorCalibrate(MetalComposition distributionFactorCalibrate) {
        this.distributionFactorCalibrate = distributionFactorCalibrate;
    }

    public double getMeltAmountCalibrate() {
        return meltAmountCalibrate;
    }

    public void setMeltAmountCalibrate(double meltAmountCalibrate) {
        this.meltAmountCalibrate = meltAmountCalibrate;
    }

    public double getSlagAmountCalibrate() {
        return slagAmountCalibrate;
    }

    public void setSlagAmountCalibrate(double slagAmountCalibrate) {
        this.slagAmountCalibrate = slagAmountCalibrate;
    }

    public MetalComposition getDistributionFactorUse() {
        return distributionFactorUse;
    }

    public void setDistributionFactorUse(MetalComposition distributionFactorUse) {
        this.distributionFactorUse = distributionFactorUse;
    }

    public MetalComposition getUseCalibratedDistributionFactor() {
        return useCalibratedDistributionFactor;
    }

    public void setUseCalibratedDistributionFactor(MetalComposition useCalibratedDistributionFactor) {
        this.useCalibratedDistributionFactor = useCalibratedDistributionFactor;
    }

    public MetalComposition getMetalCompositionUse() {
        return metalCompositionUse;
    }

    public void setMetalCompositionUse(MetalComposition metalCompositionUse) {
        this.metalCompositionUse = metalCompositionUse;
    }

    public MetalComposition getMetalCompositionOfSlagElementsUse() {
        return metalCompositionOfSlagElementsUse;
    }

    public void setMetalCompositionOfSlagElementsUse(MetalComposition metalCompositionOfSlagElementsUse) {
        this.metalCompositionOfSlagElementsUse = metalCompositionOfSlagElementsUse;
    }

    public MetalComposition getMetalCompositionOfSlagElementsCalib() {
        return metalCompositionOfSlagElementsCalib;
    }

    public void setMetalCompositionOfSlagElementsCalib(MetalComposition metalCompositionOfSlagElementsCalib) {
        this.metalCompositionOfSlagElementsCalib = metalCompositionOfSlagElementsCalib;
    }

    public double getMaxPUse() {
        return maxPUse;
    }

    public void setMaxPUse(double maxPUse) {
        this.maxPUse = maxPUse;
    }

    public double getMaxVUse() {
        return maxVUse;
    }

    public void setMaxVUse(double maxVUse) {
        this.maxVUse = maxVUse;
    }

    public MetalComposition getUseAverageMetalComposition() {
        return useAverageMetalComposition;
    }

    public void setUseAverageMetalComposition(MetalComposition useAverageMetalComposition) {
        this.useAverageMetalComposition = useAverageMetalComposition;
    }

    public MetalComposition getUseAverageMetalCompositionOfSlagElements() {
        return useAverageMetalCompositionOfSlagElements;
    }

    public void setUseAverageMetalCompositionOfSlagElements(MetalComposition useAverageMetalCompositionOfSlagElements) {
        this.useAverageMetalCompositionOfSlagElements = useAverageMetalCompositionOfSlagElements;
    }

    public double getSlagBasicityUse() {
        return slagBasicityUse;
    }

    public void setSlagBasicityUse(double slagBasicityUse) {
        this.slagBasicityUse = slagBasicityUse;
    }

    public double getSlagAmountUse() {
        return slagAmountUse;
    }

    public void setSlagAmountUse(double slagAmountUse) {
        this.slagAmountUse = slagAmountUse;
    }

    public boolean isUseAverageSlagBasicity() {
        return useAverageSlagBasicity;
    }

    public void setUseAverageSlagBasicity(boolean useAverageSlagBasicity) {
        this.useAverageSlagBasicity = useAverageSlagBasicity;
    }

    public boolean isUseCalibratedSlagAmount() {
        return useCalibratedSlagAmount;
    }

    public void setUseCalibratedSlagAmount(boolean useCalibratedSlagAmount) {
        this.useCalibratedSlagAmount = useCalibratedSlagAmount;
    }

    public boolean isUseMaxPAverage() {
        return useMaxPAverage;
    }

    public void setUseMaxPAverage(boolean useMaxPAverage) {
        this.useMaxPAverage = useMaxPAverage;
    }

    public boolean isUseMaxVAverage() {
        return useMaxVAverage;
    }

    public void setUseMaxVAverage(boolean useMaxVAverage) {
        this.useMaxVAverage = useMaxVAverage;
    }

    public List<MaterialContainerBlastFurnace> getDefaultMaterials() {
        return defaultMaterials;
    }

    public void setDefaultMaterials(List<MaterialContainerBlastFurnace> defaultMaterials) {
        this.defaultMaterials = defaultMaterials;
    }

    public CarbonSourceMaterial getCoke() {
        return coke;
    }

    public void setCoke(CarbonSourceMaterial coke) {
        this.coke = coke;
    }

    public double getCokeAmount() {
        return cokeAmount;
    }

    public void setCokeAmount(double cokeAmount) {
        this.cokeAmount = cokeAmount;
    }

    public CarbonSourceMaterial getInjectionOne() {
        return injectionOne;
    }

    public void setInjectionOne(CarbonSourceMaterial injectionOne) {
        this.injectionOne = injectionOne;
    }

    public AbstractMaterial getInjectionTwo() {
        return injectionTwo;
    }

    public void setInjectionTwo(AbstractMaterial injectionTwo) {
        this.injectionTwo = injectionTwo;
    }

    public double getInjectionOneAmount() {
        return injectionOneAmount;
    }

    public void setInjectionOneAmount(double injectionOneAmount) {
        this.injectionOneAmount = injectionOneAmount;
    }

    public double getInjectionTwoAmount() {
        return injectionTwoAmount;
    }

    public void setInjectionTwoAmount(double injectionTwoAmount) {
        this.injectionTwoAmount = injectionTwoAmount;
    }

    public double getDustAmount() {
        return dustAmount;
    }

    public void setDustAmount(double dustAmount) {
        this.dustAmount = dustAmount;
    }

    public double getBlastAmount() {
        return blastAmount;
    }

    public void setBlastAmount(double blastAmount) {
        this.blastAmount = blastAmount;
    }

    public ProcessGasMaterial getBlastSource() {
        return blastSource;
    }

    public void setBlastSource(ProcessGasMaterial blastSource) {
        this.blastSource = blastSource;
    }

    public ProcessGasMaterial getOxygenSource() {
        return oxygenSource;
    }

    public void setOxygenSource(ProcessGasMaterial oxygenSource) {
        this.oxygenSource = oxygenSource;
    }

    public ElectricityMaterial getElectricitySource() {
        return electricitySource;
    }

    public void setElectricitySource(ElectricityMaterial electricitySource) {
        this.electricitySource = electricitySource;
    }

    public double getElectricityAmountKWh() {
        return electricityAmountKWh;
    }

    public void setElectricityAmountKWh(double electricityAmountKWh) {
        this.electricityAmountKWh = electricityAmountKWh;
    }

    public double getOxygenVolume() {
        return oxygenVolume;
    }

    public void setOxygenVolume(double oxygenVolume) {
        this.oxygenVolume = oxygenVolume;
    }

    public BlastFurnaceProcessData getProcessDataCalibration() {
        return processDataCalibration;
    }

    public void setProcessDataCalibration(BlastFurnaceProcessData processDataCalibration) {
        this.processDataCalibration = processDataCalibration;
    }

    public BlastFurnaceProcessData getProcessDataUse() {
        return processDataUse;
    }

    public void setProcessDataUse(BlastFurnaceProcessData processDataUse) {
        this.processDataUse = processDataUse;
    }

    public BlastFurnaceProcessData getIsUseCalibrationProcessData() {
        return isUseCalibrationProcessData;
    }

    public void setIsUseCalibrationProcessData(BlastFurnaceProcessData isUseCalibrationProcessData) {
        this.isUseCalibrationProcessData = isUseCalibrationProcessData;
    }

    public double getAvailability() {
        return availability;
    }

    public void setAvailability(double availability) {
        this.availability = availability;
    }

    public double getBlastCapacity() {
        return blastCapacity;
    }

    public void setBlastCapacity(double blastCapacity) {
        this.blastCapacity = blastCapacity;
    }

    public double getAnnualProduction() {
        return annualProduction;
    }

    public void setAnnualProduction(double annualProduction) {
        this.annualProduction = annualProduction;
    }

    public double getSlagProductionCost() {
        return slagProductionCost;
    }

    public void setSlagProductionCost(double slagProductionCost) {
        this.slagProductionCost = slagProductionCost;
    }

    public double getGasProductionCost() {
        return gasProductionCost;
    }

    public void setGasProductionCost(double gasProductionCost) {
        this.gasProductionCost = gasProductionCost;
    }

    public double getProductivity() {
        return productivity;
    }

    public void setProductivity(double productivity) {
        this.productivity = productivity;
    }

    public Integer getIsEtaH2Used() {
        return isEtaH2Used;
    }

    public void setIsEtaH2Used(Integer isEtaH2Used) {
        this.isEtaH2Used = isEtaH2Used;
    }

    public Integer getIsBlastMoistureUsed() {
        return isBlastMoistureUsed;
    }

    public void setIsBlastMoistureUsed(Integer isBlastMoistureUsed) {
        this.isBlastMoistureUsed = isBlastMoistureUsed;
    }

}
