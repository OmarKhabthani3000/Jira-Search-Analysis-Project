/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import java.util.Set;
import se.zaleth.jar.administration.PROJECTUser;
import se.zaleth.jar.administration.UserGroup;
import se.zaleth.jar.generic.MassConstraint;
import se.zaleth.jar.generic.Visibility;
import se.zaleth.jar.project.ProductionProfile;

/**
 *
 * @author krister
 */
public class RawMaterialGroup {
    
    private long id;
    private Set<AbstractMaterial> rawMaterials;
    private PROJECTUser owner;
    private PROJECTUser supplier;
    private Set<UserGroup> distributedGroups;
    private UserGroup group;
    private String name;
    private String description;
    private Visibility visibilitySetting;
    private boolean distributed;
    private boolean belongsToStandard;
    private boolean showForEducationVersion;
    private MassConstraint massConstraint;
    private int distributionType;
    private byte[] logotype;
    private String logotypeContentType;
    private byte[] attachment;
    private String attachmentFileName;
    private String attachmentContentType;
    private Set<ProductionProfile> productionProfiles;
    private MaterialCategory groupMaterialCategory;
    private Integer loadingUnit;
    private MaterialCollection materialGroupColl;

}
