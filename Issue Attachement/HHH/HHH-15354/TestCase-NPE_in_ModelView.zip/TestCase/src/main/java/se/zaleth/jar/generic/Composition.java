/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.generic;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author krister
 */
public class Composition {
    
    private static Set<String> elementSet;
    private long id;
    private SlagComposition slagComposition;
    private MetalComposition metalComposition;
    private SlagComposition producedOxideComposition;
    private double elementTemperature;
    
    public Composition() {
        elementSet = new HashSet<>();
    }

    public static Set<String> getElementSet() {
        return elementSet;
    }

    public static void setElementSet(Set<String> elementSet) {
        Composition.elementSet = elementSet;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public SlagComposition getSlagComposition() {
        return slagComposition;
    }

    public void setSlagComposition(SlagComposition slagComposition) {
        this.slagComposition = slagComposition;
    }

    public MetalComposition getMetalComposition() {
        return metalComposition;
    }

    public void setMetalComposition(MetalComposition metalComposition) {
        this.metalComposition = metalComposition;
    }

    public SlagComposition getProducedOxideComposition() {
        return producedOxideComposition;
    }

    public void setProducedOxideComposition(SlagComposition producedOxideComposition) {
        this.producedOxideComposition = producedOxideComposition;
    }

    public double getElementTemperature() {
        return elementTemperature;
    }

    public void setElementTemperature(double elementTemperature) {
        this.elementTemperature = elementTemperature;
    }

}
