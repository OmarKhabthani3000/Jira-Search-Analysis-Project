/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.administration;

import java.util.List;
import java.util.Set;
import se.zaleth.jar.generic.License;
import se.zaleth.jar.material.MetalPrice;
import se.zaleth.jar.plant.ProductionUnit;
import se.zaleth.jar.product.TargetProductGroup;
import se.zaleth.jar.project.ProductionProfile;

/**
 *
 * @author krister
 */
public class UserGroup {
    
    private long id;
    private String name;
    private int deleted;
    private License license;
    private String legalName;
    private String addressLineOne;
    private String addressLineTwo;
    private String postcode;
    private String postArea;
    private String email;
    private String organizationNumber;
    private String reference;
    private String phone;
    private String country;
    private List<String> elements;
    private String selectedElementString;
    private String unSelectedElementString;
    private String selectedSlagElementString;
    private String unSelectedSlagElementString;
    private List<UserGroupStandardDeviation> userGroupStandardDeviations;
    private double standradScore;
    private String mainElement;
    private RecipeColumns recipeColumns;
    private boolean inactive;
    private boolean useEnergyInOptimization;
    private boolean nameChargesAfterNumber;
    private List<String> typeConstraintNames;
    private String typeConstraintNamesString;
    private TargetProductGroup referenceTargetProductGroup;
    private ProductionUnit referenceFurnace;
    public static final int ROUNDING_UNIT_KG = 0;
    private Integer roundingUnit;
    private Integer roundingValue;
    public static final int BASKET_UNIT_M3 = 0;
    private Integer basketUnit;
    public static final int CALCULATION_BY_PLANT_DATA = 0;
    private Integer productionCostCalculationMethod;
    private MetalPriceName metalPriceNameOne;
    private MetalPriceName metalPriceNameTwo;
    private MetalPriceName metalPriceNameThree;
    private String mainMetalPriceNameFour;
    private String mainMetalPriceNameFive;
    private Set<MetalPrice> metalPrices;
    private Set<ProductionProfile> productionProfiles;

}
