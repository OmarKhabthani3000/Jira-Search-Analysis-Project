/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

/**
 *
 * @author krister
 */
public class ProcessGasMaterial extends AbstractMaterial {
    
    private int processGasType;

    public int getProcessGasType() {
        return processGasType;
    }

    public void setProcessGasType(int processGasType) {
        this.processGasType = processGasType;
    }

}
