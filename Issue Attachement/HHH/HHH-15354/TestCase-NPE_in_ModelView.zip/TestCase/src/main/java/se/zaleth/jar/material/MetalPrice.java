/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import java.util.Date;
import se.zaleth.jar.administration.PROJECTUser;
import se.zaleth.jar.administration.UserGroup;
import se.zaleth.jar.generic.Currency;
import se.zaleth.jar.generic.MetalComposition;

/**
 *
 * @author krister
 */
public class MetalPrice {
    
    private long id;
    private PROJECTUser owner;
    private UserGroup userGroup;
    private String market;
    private Date date;
    private Currency currency;
    private MetalComposition metalPriceOne;
    private MetalComposition metalPriceTwo;
    private MetalComposition metalPriceThree;
    private double mainElementFour;
    private double mainElementFive;

}
