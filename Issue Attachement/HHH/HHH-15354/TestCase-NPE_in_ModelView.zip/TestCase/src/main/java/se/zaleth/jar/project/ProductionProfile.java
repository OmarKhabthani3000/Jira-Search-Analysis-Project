/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.project;

import java.util.Set;
import se.zaleth.jar.generic.MetalComposition;
import se.zaleth.jar.generic.SlagComposition;
import se.zaleth.jar.product.DistributionFactorSet;

/**
 *
 * @author krister
 */
public class ProductionProfile {
    
    private long id;
    private String name;
    private MetalComposition defaultMaxComposition;
    private MetalComposition defaultElementsOrder;
    private SlagComposition defaultSlagElementsOrder;
    private String mainMetalElement;
    private Set<DistributionFactorSet> availableFactorSets;
    private int thermoFactor;

}
