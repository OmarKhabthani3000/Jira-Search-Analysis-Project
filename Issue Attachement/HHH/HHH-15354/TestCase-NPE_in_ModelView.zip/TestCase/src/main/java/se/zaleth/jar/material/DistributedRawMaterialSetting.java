/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import se.zaleth.jar.administration.UserGroup;

/**
 *
 * @author krister
 */
public class DistributedRawMaterialSetting {
    
    private long id;
    private AbstractMaterial material;
    private double price;
    private double mass;
    private int type;
    private boolean useDistributorPrice;
    private double extraCost;
    private UserGroup userGroup;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public AbstractMaterial getMaterial() {
        return material;
    }

    public void setMaterial(AbstractMaterial material) {
        this.material = material;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getMass() {
        return mass;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public boolean isUseDistributorPrice() {
        return useDistributorPrice;
    }

    public void setUseDistributorPrice(boolean useDistributorPrice) {
        this.useDistributorPrice = useDistributorPrice;
    }

    public double getExtraCost() {
        return extraCost;
    }

    public void setExtraCost(double extraCost) {
        this.extraCost = extraCost;
    }

    public UserGroup getUserGroup() {
        return userGroup;
    }

    public void setUserGroup(UserGroup userGroup) {
        this.userGroup = userGroup;
    }

}
