/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import se.zaleth.jar.generic.OreComposition;

/**
 *
 * @author krister
 */
public class OreMaterial extends RawMaterial {
    
    private OreComposition oreComposition;
    private double priceFOB;
    private double priceLandSide;
    private double priceFreight;
    private double dischargePortFines;
    private double finesDRI;
    private double dustLoss;

    public OreComposition getOreComposition() {
        return oreComposition;
    }

    public void setOreComposition(OreComposition oreComposition) {
        this.oreComposition = oreComposition;
    }

    public double getPriceFOB() {
        return priceFOB;
    }

    public void setPriceFOB(double priceFOB) {
        this.priceFOB = priceFOB;
    }

    public double getPriceLandSide() {
        return priceLandSide;
    }

    public void setPriceLandSide(double priceLandSide) {
        this.priceLandSide = priceLandSide;
    }

    public double getPriceFreight() {
        return priceFreight;
    }

    public void setPriceFreight(double priceFreight) {
        this.priceFreight = priceFreight;
    }

    public double getDischargePortFines() {
        return dischargePortFines;
    }

    public void setDischargePortFines(double dischargePortFines) {
        this.dischargePortFines = dischargePortFines;
    }

    public double getFinesDRI() {
        return finesDRI;
    }

    public void setFinesDRI(double finesDRI) {
        this.finesDRI = finesDRI;
    }

    public double getDustLoss() {
        return dustLoss;
    }

    public void setDustLoss(double dustLoss) {
        this.dustLoss = dustLoss;
    }

    public double getInputPriceFOB() {
        return 0;
    }

    public void setInputPriceFOB(double priceFOB) {
    }

    public double getInputPriceFreight() {
        return 0;
    }

    public void setInputPriceFreight(double priceFreight) {
        
    }
    
    public double getInputPriceLandSide() {
        return 0;
    }

    public void setInputPriceLandSide(double priceLandSide) {
        
    }
    
}
