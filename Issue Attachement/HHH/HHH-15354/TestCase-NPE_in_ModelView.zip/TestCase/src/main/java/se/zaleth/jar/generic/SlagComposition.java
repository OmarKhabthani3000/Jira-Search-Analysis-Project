/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.generic;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author krister
 */
public class SlagComposition {
    
    private static Set<String> elementSet;
    private long id;
    private double SiO2;
    private double Al2O3;
    private double FeO;
    private double MnO;
    private double CaO;
    private double MgO;
    private double P2O5;
    private double VO2;
    private double TiO2;
    private double CrO;
    private double Cr2O3;
    private double Fe2O3;
    private double Fe3O4;
    private double MoO2;
    private double MoO3;
    private double NiO;
    private double CaF2;
    private double CaCO3;
    private double MgCO3;
    private double S2;
    private double Sb2O3;
    private double TeO2;
    private double K2O;
    private double Na2O;
    private double NbO;
    private double B2O3;
    private double Bi2O3;
    private double As2O3;
    private double Ta2O5;
    private double CoO;
    private double PbO;
    private double CeO2;
    private double CuO;
    private double WO3;
    private double SnO2;
    private double ZnO;
    private double NaCl;
    private double KCl;
    private double Li2O;
    private double BaO;
    private double BeO;
    private double SrO;
    private double ZrO2;
    private double CdO;
    private double HgO;
    private double Ag2O;
    private double CaS;
    private double MgS;
    private double Cu2S;
    private double FeS;
    private double Cu2O;
    private double FeOOH;
    private double FeCO3;
    private double CaSO4;
    private double CaCl2;
    private double CaO2H2;
    private double moisture;
    private double MgOUndissolved;
    
    public SlagComposition() {
        elementSet = new HashSet<>();
    }

    public static Set<String> getElementSet() {
        return elementSet;
    }

    public static void setElementSet(Set<String> elementSet) {
        SlagComposition.elementSet = elementSet;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getSiO2() {
        return SiO2;
    }

    public void setSiO2(double SiO2) {
        this.SiO2 = SiO2;
    }

    public double getAl2O3() {
        return Al2O3;
    }

    public void setAl2O3(double Al2O3) {
        this.Al2O3 = Al2O3;
    }

    public double getFeO() {
        return FeO;
    }

    public void setFeO(double FeO) {
        this.FeO = FeO;
    }

    public double getMnO() {
        return MnO;
    }

    public void setMnO(double MnO) {
        this.MnO = MnO;
    }

    public double getCaO() {
        return CaO;
    }

    public void setCaO(double CaO) {
        this.CaO = CaO;
    }

    public double getMgO() {
        return MgO;
    }

    public void setMgO(double MgO) {
        this.MgO = MgO;
    }

    public double getP2O5() {
        return P2O5;
    }

    public void setP2O5(double P2O5) {
        this.P2O5 = P2O5;
    }

    public double getVO2() {
        return VO2;
    }

    public void setVO2(double VO2) {
        this.VO2 = VO2;
    }

    public double getTiO2() {
        return TiO2;
    }

    public void setTiO2(double TiO2) {
        this.TiO2 = TiO2;
    }

    public double getCrO() {
        return CrO;
    }

    public void setCrO(double CrO) {
        this.CrO = CrO;
    }

    public double getCr2O3() {
        return Cr2O3;
    }

    public void setCr2O3(double Cr2O3) {
        this.Cr2O3 = Cr2O3;
    }

    public double getFe2O3() {
        return Fe2O3;
    }

    public void setFe2O3(double Fe2O3) {
        this.Fe2O3 = Fe2O3;
    }

    public double getFe3O4() {
        return Fe3O4;
    }

    public void setFe3O4(double Fe3O4) {
        this.Fe3O4 = Fe3O4;
    }

    public double getMoO2() {
        return MoO2;
    }

    public void setMoO2(double MoO2) {
        this.MoO2 = MoO2;
    }

    public double getMoO3() {
        return MoO3;
    }

    public void setMoO3(double MoO3) {
        this.MoO3 = MoO3;
    }

    public double getNiO() {
        return NiO;
    }

    public void setNiO(double NiO) {
        this.NiO = NiO;
    }

    public double getCaF2() {
        return CaF2;
    }

    public void setCaF2(double CaF2) {
        this.CaF2 = CaF2;
    }

    public double getCaCO3() {
        return CaCO3;
    }

    public void setCaCO3(double CaCO3) {
        this.CaCO3 = CaCO3;
    }

    public double getMgCO3() {
        return MgCO3;
    }

    public void setMgCO3(double MgCO3) {
        this.MgCO3 = MgCO3;
    }

    public double getS2() {
        return S2;
    }

    public void setS2(double S2) {
        this.S2 = S2;
    }

    public double getSb2O3() {
        return Sb2O3;
    }

    public void setSb2O3(double Sb2O3) {
        this.Sb2O3 = Sb2O3;
    }

    public double getTeO2() {
        return TeO2;
    }

    public void setTeO2(double TeO2) {
        this.TeO2 = TeO2;
    }

    public double getK2O() {
        return K2O;
    }

    public void setK2O(double K2O) {
        this.K2O = K2O;
    }

    public double getNa2O() {
        return Na2O;
    }

    public void setNa2O(double Na2O) {
        this.Na2O = Na2O;
    }

    public double getNbO() {
        return NbO;
    }

    public void setNbO(double NbO) {
        this.NbO = NbO;
    }

    public double getB2O3() {
        return B2O3;
    }

    public void setB2O3(double B2O3) {
        this.B2O3 = B2O3;
    }

    public double getBi2O3() {
        return Bi2O3;
    }

    public void setBi2O3(double Bi2O3) {
        this.Bi2O3 = Bi2O3;
    }

    public double getAs2O3() {
        return As2O3;
    }

    public void setAs2O3(double As2O3) {
        this.As2O3 = As2O3;
    }

    public double getTa2O5() {
        return Ta2O5;
    }

    public void setTa2O5(double Ta2O5) {
        this.Ta2O5 = Ta2O5;
    }

    public double getCoO() {
        return CoO;
    }

    public void setCoO(double CoO) {
        this.CoO = CoO;
    }

    public double getPbO() {
        return PbO;
    }

    public void setPbO(double PbO) {
        this.PbO = PbO;
    }

    public double getCeO2() {
        return CeO2;
    }

    public void setCeO2(double CeO2) {
        this.CeO2 = CeO2;
    }

    public double getCuO() {
        return CuO;
    }

    public void setCuO(double CuO) {
        this.CuO = CuO;
    }

    public double getWO3() {
        return WO3;
    }

    public void setWO3(double WO3) {
        this.WO3 = WO3;
    }

    public double getSnO2() {
        return SnO2;
    }

    public void setSnO2(double SnO2) {
        this.SnO2 = SnO2;
    }

    public double getZnO() {
        return ZnO;
    }

    public void setZnO(double ZnO) {
        this.ZnO = ZnO;
    }

    public double getNaCl() {
        return NaCl;
    }

    public void setNaCl(double NaCl) {
        this.NaCl = NaCl;
    }

    public double getKCl() {
        return KCl;
    }

    public void setKCl(double KCl) {
        this.KCl = KCl;
    }

    public double getLi2O() {
        return Li2O;
    }

    public void setLi2O(double Li2O) {
        this.Li2O = Li2O;
    }

    public double getBaO() {
        return BaO;
    }

    public void setBaO(double BaO) {
        this.BaO = BaO;
    }

    public double getBeO() {
        return BeO;
    }

    public void setBeO(double BeO) {
        this.BeO = BeO;
    }

    public double getSrO() {
        return SrO;
    }

    public void setSrO(double SrO) {
        this.SrO = SrO;
    }

    public double getZrO2() {
        return ZrO2;
    }

    public void setZrO2(double ZrO2) {
        this.ZrO2 = ZrO2;
    }

    public double getCdO() {
        return CdO;
    }

    public void setCdO(double CdO) {
        this.CdO = CdO;
    }

    public double getHgO() {
        return HgO;
    }

    public void setHgO(double HgO) {
        this.HgO = HgO;
    }

    public double getAg2O() {
        return Ag2O;
    }

    public void setAg2O(double Ag2O) {
        this.Ag2O = Ag2O;
    }

    public double getCaS() {
        return CaS;
    }

    public void setCaS(double CaS) {
        this.CaS = CaS;
    }

    public double getMgS() {
        return MgS;
    }

    public void setMgS(double MgS) {
        this.MgS = MgS;
    }

    public double getCu2S() {
        return Cu2S;
    }

    public void setCu2S(double Cu2S) {
        this.Cu2S = Cu2S;
    }

    public double getFeS() {
        return FeS;
    }

    public void setFeS(double FeS) {
        this.FeS = FeS;
    }

    public double getCu2O() {
        return Cu2O;
    }

    public void setCu2O(double Cu2O) {
        this.Cu2O = Cu2O;
    }

    public double getFeOOH() {
        return FeOOH;
    }

    public void setFeOOH(double FeOOH) {
        this.FeOOH = FeOOH;
    }

    public double getFeCO3() {
        return FeCO3;
    }

    public void setFeCO3(double FeCO3) {
        this.FeCO3 = FeCO3;
    }

    public double getCaSO4() {
        return CaSO4;
    }

    public void setCaSO4(double CaSO4) {
        this.CaSO4 = CaSO4;
    }

    public double getCaCl2() {
        return CaCl2;
    }

    public void setCaCl2(double CaCl2) {
        this.CaCl2 = CaCl2;
    }

    public double getCaO2H2() {
        return CaO2H2;
    }

    public void setCaO2H2(double CaO2H2) {
        this.CaO2H2 = CaO2H2;
    }

    public double getMoisture() {
        return moisture;
    }

    public void setMoisture(double moisture) {
        this.moisture = moisture;
    }

    public double getMgOUndissolved() {
        return MgOUndissolved;
    }

    public void setMgOUndissolved(double MgOUndissolved) {
        this.MgOUndissolved = MgOUndissolved;
    }
    
}
