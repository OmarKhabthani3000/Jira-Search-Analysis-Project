/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.generic;

import java.util.Map;
import java.util.Set;

/**
 *
 * @author krister
 */
public class OreComposition {
    
    private long id;
    private double Fe;
    private double FeO;
    private double SiO2;
    private double CaO;
    private double MgO;
    private double Al2O3;
    private double TiO2;
    private double Na2O;
    private double K2O;
    private double Cr;
    private double Cu;
    private double Mn;
    private double Mo;
    private double Ni;
    private double P;
    private double S;
    private double Sn;
    private double V;
    private double Zn;
    private double F;
    private double Cl;
    private double CaBound_H2O;
    private double FeBound_H2O;
    private double CaBound_CO2;
    private double FeBound_CO2;
    private double moisture;
    private Set<String> elementSet;
    private Map<String, Double> cachedElementMap;

}
