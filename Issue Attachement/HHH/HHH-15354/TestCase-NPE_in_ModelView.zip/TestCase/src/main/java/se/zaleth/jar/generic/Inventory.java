/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.generic;

import java.util.Date;
import java.util.Set;
import se.zaleth.jar.administration.PROJECTUser;
import se.zaleth.jar.plant.RawMaterialStore;

/**
 *
 * @author krister
 */
public class Inventory {
    
    private long id;
    private String name;
    private String description;
    private boolean complete;
    private Date revisionDate;
    private RawMaterialStore materialStore;
    private PROJECTUser responsibleUser;
    private Set<StockRecord> stockRecords;

}
