/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.generic;

import java.util.List;

/**
 *
 * @author krister
 */
public class Country {
    
    private long id;
    private String countryName;
    private String abbreviation;
    private List<String> countryNameList;
    private boolean checked;
    public String[] CountryList;

}
