/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

import se.zaleth.jar.generic.MetalComposition;

/**
 *
 * @author krister
 */
public class LDConverter extends ProductionUnit {
    
    private double capacity;
    private double averageOxygen;
    private double etaCO;
    private double innerDiameter;
    private int noOfFurnaces;
    private double averageOxygenOffTime;
    private double oxygenOffHeatLoss;
    private double heatLoss;
    private double availability;
    private double steelProductionCost;
    private double slagProductionCost;
    private double dustProductionCost;
    private double dustBurnoff;
    private MetalComposition metallicElementsBurnoff;
    private double feOxidationDegree;

    public double getCapacity() {
        return capacity;
    }

    public void setCapacity(double capacity) {
        this.capacity = capacity;
    }

    public double getAverageOxygen() {
        return averageOxygen;
    }

    public void setAverageOxygen(double averageOxygen) {
        this.averageOxygen = averageOxygen;
    }

    public double getEtaCO() {
        return etaCO;
    }

    public void setEtaCO(double etaCO) {
        this.etaCO = etaCO;
    }

    public double getInnerDiameter() {
        return innerDiameter;
    }

    public void setInnerDiameter(double innerDiameter) {
        this.innerDiameter = innerDiameter;
    }

    public int getNoOfFurnaces() {
        return noOfFurnaces;
    }

    public void setNoOfFurnaces(int noOfFurnaces) {
        this.noOfFurnaces = noOfFurnaces;
    }

    public double getAverageOxygenOffTime() {
        return averageOxygenOffTime;
    }

    public void setAverageOxygenOffTime(double averageOxygenOffTime) {
        this.averageOxygenOffTime = averageOxygenOffTime;
    }

    public double getOxygenOffHeatLoss() {
        return oxygenOffHeatLoss;
    }

    public void setOxygenOffHeatLoss(double oxygenOffHeatLoss) {
        this.oxygenOffHeatLoss = oxygenOffHeatLoss;
    }

    public double getHeatLoss() {
        return heatLoss;
    }

    public void setHeatLoss(double heatLoss) {
        this.heatLoss = heatLoss;
    }

    public double getAvailability() {
        return availability;
    }

    public void setAvailability(double availability) {
        this.availability = availability;
    }

    public double getSteelProductionCost() {
        return steelProductionCost;
    }

    public void setSteelProductionCost(double steelProductionCost) {
        this.steelProductionCost = steelProductionCost;
    }

    public double getSlagProductionCost() {
        return slagProductionCost;
    }

    public void setSlagProductionCost(double slagProductionCost) {
        this.slagProductionCost = slagProductionCost;
    }

    public double getDustProductionCost() {
        return dustProductionCost;
    }

    public void setDustProductionCost(double dustProductionCost) {
        this.dustProductionCost = dustProductionCost;
    }

    public double getDustBurnoff() {
        return dustBurnoff;
    }

    public void setDustBurnoff(double dustBurnoff) {
        this.dustBurnoff = dustBurnoff;
    }

    public MetalComposition getMetallicElementsBurnoff() {
        return metallicElementsBurnoff;
    }

    public void setMetallicElementsBurnoff(MetalComposition metallicElementsBurnoff) {
        this.metallicElementsBurnoff = metallicElementsBurnoff;
    }

    public double getFeOxidationDegree() {
        return feOxidationDegree;
    }

    public void setFeOxidationDegree(double feOxidationDegree) {
        this.feOxidationDegree = feOxidationDegree;
    }

    public double getInputSteelProductionCost() {
        return 0;
    }

    public void setInputSteelProductionCost(double steelProductionCost) {
    }

    public double getInputSlagProductionCost() {
        return 0;
    }

    public void setInputSlagProductionCost(double slagProductionCost) {
    }

    public double getInputDustProductionCost() {
        return 0;
    }

    public void setInputDustProductionCost(double dustProductionCost) {
    }

}
