/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import java.util.Collection;
import se.zaleth.jar.generic.Composition;
import se.zaleth.jar.generic.MetalComposition;
import se.zaleth.jar.product.TargetProductGroup;

/**
 *
 * @author krister
 */
public class RawMaterial extends AbstractMaterial {
    
    public boolean allocationInfinity;
    public MetalComposition trampElements;
    public Collection<TargetProductGroup> targetProductGroups;
    public double adjustedPriceByStandardDeviation;
    public boolean hasStandardDeviation;
    public String selectedElementForAlloyCorrection;
    public boolean useMetalPrice;
    public MetalComposition metalPriceCoefficients;
    public MetalComposition metalPriceOptions;
    public double metalPriceOtherFactors;
    private Composition elementProbability;

    public boolean isAllocationInfinity() {
        return allocationInfinity;
    }

    public void setAllocationInfinity(boolean allocationInfinity) {
        this.allocationInfinity = allocationInfinity;
    }

    public MetalComposition getTrampElements() {
        return trampElements;
    }

    public void setTrampElements(MetalComposition trampElements) {
        this.trampElements = trampElements;
    }

    public Collection<TargetProductGroup> getTargetProductGroups() {
        return targetProductGroups;
    }

    public void setTargetProductGroups(Collection<TargetProductGroup> targetProductGroups) {
        this.targetProductGroups = targetProductGroups;
    }

    public double getAdjustedPriceByStandardDeviation() {
        return adjustedPriceByStandardDeviation;
    }

    public void setAdjustedPriceByStandardDeviation(double adjustedPriceByStandardDeviation) {
        this.adjustedPriceByStandardDeviation = adjustedPriceByStandardDeviation;
    }

    public boolean isHasStandardDeviation() {
        return hasStandardDeviation;
    }

    public void setHasStandardDeviation(boolean hasStandardDeviation) {
        this.hasStandardDeviation = hasStandardDeviation;
    }

    public String getSelectedElementForAlloyCorrection() {
        return selectedElementForAlloyCorrection;
    }

    public void setSelectedElementForAlloyCorrection(String selectedElementForAlloyCorrection) {
        this.selectedElementForAlloyCorrection = selectedElementForAlloyCorrection;
    }

    public boolean isUseMetalPrice() {
        return useMetalPrice;
    }

    public void setUseMetalPrice(boolean useMetalPrice) {
        this.useMetalPrice = useMetalPrice;
    }

    public MetalComposition getMetalPriceCoefficients() {
        return metalPriceCoefficients;
    }

    public void setMetalPriceCoefficients(MetalComposition metalPriceCoefficients) {
        this.metalPriceCoefficients = metalPriceCoefficients;
    }

    public MetalComposition getMetalPriceOptions() {
        return metalPriceOptions;
    }

    public void setMetalPriceOptions(MetalComposition metalPriceOptions) {
        this.metalPriceOptions = metalPriceOptions;
    }

    public double getMetalPriceOtherFactors() {
        return metalPriceOtherFactors;
    }

    public void setMetalPriceOtherFactors(double metalPriceOtherFactors) {
        this.metalPriceOtherFactors = metalPriceOtherFactors;
    }

    public Composition getElementProbability() {
        return elementProbability;
    }

    public void setElementProbability(Composition elementProbability) {
        this.elementProbability = elementProbability;
    }

}
