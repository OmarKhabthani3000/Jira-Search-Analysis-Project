/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

import se.zaleth.jar.generic.MetalComposition;

/**
 *
 * @author krister
 */
public class EAFIFProductionUnit extends ProductionUnit {
    
    private double capacity;
    private int smeltModel;
    private double averagePowerOn;
    private double averagePowerOff;
    private double averagePowerOnTime;
    private double averagePowerOffTime;
    private double etaCO;
    private double heatLoss;
    private double idlePoweroffHeatLoss;
    private double availability;
    private double slagCarryOver;
    private double slagCarryOverWithHotHeel;
    private double dustBurnoff;
    private MetalComposition metallicElementsBurnoff;
    private boolean inductionFurnace;
    private double steelProductionCost;
    private double slagProductionCost;
    private double dustProductionCost;
    private double innerDiameter;
    private int noOfFurnaces;
    private double feOxidationDegree;

    public MetalComposition getMetallicElementsBurnoff() {
        return metallicElementsBurnoff;
    }

    public void setMetallicElementsBurnoff(MetalComposition metallicElementsBurnoff) {
        this.metallicElementsBurnoff = metallicElementsBurnoff;
    }

    public double getInputSteelProductionCost() {
        return 0;
    }

    public void setInputSteelProductionCost(double steelProductionCost) {
    }

    public double getInputSlagProductionCost() {
        return 0;
    }

    public void setInputSlagProductionCost(double slagProductionCost) {
    }

    public double getInputDustProductionCost() {
        return 0;
    }

    public void setInputDustProductionCost(double dustProductionCost) {
    }

    public double getCapacity() {
        return capacity;
    }

    public void setCapacity(double capacity) {
        this.capacity = capacity;
    }

    public int getSmeltModel() {
        return smeltModel;
    }

    public void setSmeltModel(int smeltModel) {
        this.smeltModel = smeltModel;
    }

    public double getAveragePowerOn() {
        return averagePowerOn;
    }

    public void setAveragePowerOn(double averagePowerOn) {
        this.averagePowerOn = averagePowerOn;
    }

    public double getAveragePowerOff() {
        return averagePowerOff;
    }

    public void setAveragePowerOff(double averagePowerOff) {
        this.averagePowerOff = averagePowerOff;
    }

    public double getAveragePowerOnTime() {
        return averagePowerOnTime;
    }

    public void setAveragePowerOnTime(double averagePowerOnTime) {
        this.averagePowerOnTime = averagePowerOnTime;
    }

    public double getAveragePowerOffTime() {
        return averagePowerOffTime;
    }

    public void setAveragePowerOffTime(double averagePowerOffTime) {
        this.averagePowerOffTime = averagePowerOffTime;
    }

    public double getEtaCO() {
        return etaCO;
    }

    public void setEtaCO(double etaCO) {
        this.etaCO = etaCO;
    }

    public double getHeatLoss() {
        return heatLoss;
    }

    public void setHeatLoss(double heatLoss) {
        this.heatLoss = heatLoss;
    }

    public double getIdlePoweroffHeatLoss() {
        return idlePoweroffHeatLoss;
    }

    public void setIdlePoweroffHeatLoss(double idlePoweroffHeatLoss) {
        this.idlePoweroffHeatLoss = idlePoweroffHeatLoss;
    }

    public double getAvailability() {
        return availability;
    }

    public void setAvailability(double availability) {
        this.availability = availability;
    }

    public double getSlagCarryOver() {
        return slagCarryOver;
    }

    public void setSlagCarryOver(double slagCarryOver) {
        this.slagCarryOver = slagCarryOver;
    }

    public double getSlagCarryOverWithHotHeel() {
        return slagCarryOverWithHotHeel;
    }

    public void setSlagCarryOverWithHotHeel(double slagCarryOverWithHotHeel) {
        this.slagCarryOverWithHotHeel = slagCarryOverWithHotHeel;
    }

    public double getDustBurnoff() {
        return dustBurnoff;
    }

    public void setDustBurnoff(double dustBurnoff) {
        this.dustBurnoff = dustBurnoff;
    }

    public boolean isInductionFurnace() {
        return inductionFurnace;
    }

    public void setInductionFurnace(boolean inductionFurnace) {
        this.inductionFurnace = inductionFurnace;
    }

    public double getSteelProductionCost() {
        return steelProductionCost;
    }

    public void setSteelProductionCost(double steelProductionCost) {
        this.steelProductionCost = steelProductionCost;
    }

    public double getSlagProductionCost() {
        return slagProductionCost;
    }

    public void setSlagProductionCost(double slagProductionCost) {
        this.slagProductionCost = slagProductionCost;
    }

    public double getDustProductionCost() {
        return dustProductionCost;
    }

    public void setDustProductionCost(double dustProductionCost) {
        this.dustProductionCost = dustProductionCost;
    }

    public double getInnerDiameter() {
        return innerDiameter;
    }

    public void setInnerDiameter(double innerDiameter) {
        this.innerDiameter = innerDiameter;
    }

    public int getNoOfFurnaces() {
        return noOfFurnaces;
    }

    public void setNoOfFurnaces(int noOfFurnaces) {
        this.noOfFurnaces = noOfFurnaces;
    }

    public double getFeOxidationDegree() {
        return feOxidationDegree;
    }

    public void setFeOxidationDegree(double feOxidationDegree) {
        this.feOxidationDegree = feOxidationDegree;
    }

}
