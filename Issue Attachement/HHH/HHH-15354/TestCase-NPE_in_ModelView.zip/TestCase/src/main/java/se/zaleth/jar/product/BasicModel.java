/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.product;

import se.zaleth.jar.material.ProcessGasMaterial;
import se.zaleth.jar.material.RawMaterial;

/**
 *
 * @author krister
 */
public class BasicModel {

    private long id;
    private String name;
    private double MFEMET;
    private boolean belongsToStandardSet;
    private double concentrationFeO;
    private double concentrationCaO20;
    private SlagModelType slagModelType;
    private RawMaterial deoxidationMaterial;
    private double deoxidationMaterialAmount;
    private RawMaterial dephosphorizationAgent;
    private RawMaterial desulfurizationAgent;
    private ProcessGasMaterial oxygenSource;
    private RawMaterial ladleLiningMaterial;
    private RawMaterial cupolaSlagFormer;
    private boolean cupolaModel;
    private double ladleLiningAmount;
    private DistributionFactorSet ladleFactorSet;

}
