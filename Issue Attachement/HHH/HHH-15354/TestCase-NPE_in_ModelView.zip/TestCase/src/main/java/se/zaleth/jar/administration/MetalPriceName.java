/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.administration;

/**
 *
 * @author krister
 */
public class MetalPriceName {
    
    private long id;
    private String C;
    private String Si;
    private String Mn;
    private String P;
    private String S;
    private String Cr;
    private String Ni;
    private String Mo;
    private String Nb;
    private String Ti;
    private String Cu;
    private String Al;
    private String V;
    private String W;
    private String Fe;
    private String Co;
    private String As;
    private String B;
    private String Bi;
    private String Pb;
    private String Ca;
    private String Ta;
    private String Sn;
    private String Zn;
    private String Ce;
    private String Te;
    private String Sb;
    private String Na;
    private String K;
    private String Mg;
    private String Li;
    private String Ba;
    private String Be;
    private String Sr;
    private String Zr;
    private String Cd;
    private String Hg;
    private String Ag;

}
