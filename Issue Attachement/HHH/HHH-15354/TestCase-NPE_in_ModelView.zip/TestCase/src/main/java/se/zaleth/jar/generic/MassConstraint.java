/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.generic;

/**
 *
 * @author krister
 */
public class MassConstraint {

    private long id;
    private double max;
    private double min;
    private double value;
    private int type;
    private boolean active;
    private double percentInBasketOne;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getMax() {
        return max;
    }

    public void setMax(double max) {
        this.max = max;
    }

    public double getMin() {
        return min;
    }

    public void setMin(double min) {
        this.min = min;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public double getPercentInBasketOne() {
        return percentInBasketOne;
    }

    public void setPercentInBasketOne(double percentInBasketOne) {
        this.percentInBasketOne = percentInBasketOne;
    }
    
}
