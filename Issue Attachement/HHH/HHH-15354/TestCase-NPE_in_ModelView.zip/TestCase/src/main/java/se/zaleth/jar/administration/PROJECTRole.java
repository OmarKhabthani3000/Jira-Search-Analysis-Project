/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.administration;

/**
 *
 * @author krister
 */
public enum PROJECTRole {
    ROLE_GROUPADMIN(1), ROLE_USER(2);
    private final int role_type;

    private PROJECTRole(int role_type) {
        this.role_type = role_type;
    }
    
}
