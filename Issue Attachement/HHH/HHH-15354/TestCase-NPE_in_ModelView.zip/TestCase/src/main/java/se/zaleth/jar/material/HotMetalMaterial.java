/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import java.util.ArrayList;
import java.util.List;
import se.zaleth.jar.generic.MetalComposition;
import se.zaleth.jar.generic.SlagComposition;
import se.zaleth.jar.generic.GasComposition;
import se.zaleth.jar.plant.BlastFurnace;
import se.zaleth.jar.plant.BlastFurnaceProcessData;
import se.zaleth.jar.plant.MaterialContainerBlastFurnace;

/**
 *
 * @author krister
 */
public class HotMetalMaterial extends RawMaterial {
    
    private BlastFurnace furnace;
    private HotMetalHeatBalanceMode hotMetalHeatBalanceMode;
    private List<MaterialContainerBlastFurnace> chargedMaterials;
    private CarbonSourceMaterial coke;
    private double calculatedCoke;
    private double cokePrice;
    private double cokeCost;
    private CarbonSourceMaterial injectionOne;
    private AbstractMaterial injectionTwo;
    private double injectionOneAmount;
    private double injectionTwoAmount;
    private double injectionOnePrice;
    private double injectionTwoPrice;
    private double injectionOneCost;
    private double injectionTwoCost;
    private double dustAmount;
    private ProcessGasMaterial blastSource;
    private ProcessGasMaterial oxygenSource;
    private ElectricityMaterial electricitySource;
    private MediaMaterial waterSource;
    private double electricityAmountKWh;
    private double oxygenVolume;
    private double waterVolume;
    private double blastPrice;
    private double electricityPrice;
    private double oxygenPrice;
    private double waterPrice;
    private double blastCost;
    private double electricityCost;
    private double oxygenCost;
    private double waterCost;
    private BlastFurnaceProcessData heatBalanceData;
    private MetalComposition distributionFactor;
    private MetalComposition metalCompositionAverage;
    private MetalComposition metalCompositionOfSlagElements;
    private SlagComposition slagCompositionResult;
    private double slagBasicity;
    private double slagAmount;
    private double slagBasicityResult;
    private double slagAmountResult;
    private GasComposition offGasComposition;
    private double sumMaterialCosts;
    private double staffCost;
    private double overheadCost;
    private double maintenanceCost;
    private double capitalCost;
    private double creditGas;
    private double creditSlag;
    private double creditGasCost;
    private double creditSlagCost;
    private double offGasEnergy;
    private double topGasDryAmount;
    private double topGasDryHeatContent;
    private double topGasDryKmolTot;
    private Integer isEtaH2Used;
    private Integer isBlastMoistureUsed;
    private boolean calculated;
    private double kmoleCO2;
    private double kmoleCO;
    private boolean validCalculation;

    public HotMetalMaterial() {
        super();
        chargedMaterials = new ArrayList<>();
    }
    
    public BlastFurnace getFurnace() {
        return furnace;
    }

    public void setFurnace(BlastFurnace furnace) {
        this.furnace = furnace;
    }

    public List<MaterialContainerBlastFurnace> getChargedMaterials() {
        return chargedMaterials;
    }

    public void setChargedMaterials(List<MaterialContainerBlastFurnace> chargedMaterials) {
        this.chargedMaterials = chargedMaterials;
    }

    public HotMetalHeatBalanceMode getHotMetalHeatBalanceMode() {
        return hotMetalHeatBalanceMode;
    }

    public void setHotMetalHeatBalanceMode(HotMetalHeatBalanceMode hotMetalHeatBalanceMode) {
        this.hotMetalHeatBalanceMode = hotMetalHeatBalanceMode;
    }

    public int getHeatBalanceMode() {
        return 0;
    }

    public void setHeatBalanceMode(int mode) {
        
    }
    
    public CarbonSourceMaterial getCoke() {
        return coke;
    }

    public void setCoke(CarbonSourceMaterial coke) {
        this.coke = coke;
    }

    public double getCalculatedCoke() {
        return calculatedCoke;
    }

    public void setCalculatedCoke(double calculatedCoke) {
        this.calculatedCoke = calculatedCoke;
    }

    public double getCokePrice() {
        return cokePrice;
    }

    public void setCokePrice(double cokePrice) {
        this.cokePrice = cokePrice;
    }

    public double getCokeCost() {
        return cokeCost;
    }

    public void setCokeCost(double cokeCost) {
        this.cokeCost = cokeCost;
    }

    public CarbonSourceMaterial getInjectionOne() {
        return injectionOne;
    }

    public void setInjectionOne(CarbonSourceMaterial injectionOne) {
        this.injectionOne = injectionOne;
    }

    public AbstractMaterial getInjectionTwo() {
        return injectionTwo;
    }

    public void setInjectionTwo(AbstractMaterial injectionTwo) {
        this.injectionTwo = injectionTwo;
    }

    public double getInjectionOneAmount() {
        return injectionOneAmount;
    }

    public void setInjectionOneAmount(double injectionOneAmount) {
        this.injectionOneAmount = injectionOneAmount;
    }

    public double getInjectionTwoAmount() {
        return injectionTwoAmount;
    }

    public void setInjectionTwoAmount(double injectionTwoAmount) {
        this.injectionTwoAmount = injectionTwoAmount;
    }

    public double getInjectionOnePrice() {
        return injectionOnePrice;
    }

    public void setInjectionOnePrice(double injectionOnePrice) {
        this.injectionOnePrice = injectionOnePrice;
    }

    public double getInjectionTwoPrice() {
        return injectionTwoPrice;
    }

    public void setInjectionTwoPrice(double injectionTwoPrice) {
        this.injectionTwoPrice = injectionTwoPrice;
    }

    public double getInjectionOneCost() {
        return injectionOneCost;
    }

    public void setInjectionOneCost(double injectionOneCost) {
        this.injectionOneCost = injectionOneCost;
    }

    public double getInjectionTwoCost() {
        return injectionTwoCost;
    }

    public void setInjectionTwoCost(double injectionTwoCost) {
        this.injectionTwoCost = injectionTwoCost;
    }

    public double getDustAmount() {
        return dustAmount;
    }

    public void setDustAmount(double dustAmount) {
        this.dustAmount = dustAmount;
    }

    public ProcessGasMaterial getBlastSource() {
        return blastSource;
    }

    public void setBlastSource(ProcessGasMaterial blastSource) {
        this.blastSource = blastSource;
    }

    public ProcessGasMaterial getOxygenSource() {
        return oxygenSource;
    }

    public void setOxygenSource(ProcessGasMaterial oxygenSource) {
        this.oxygenSource = oxygenSource;
    }

    public ElectricityMaterial getElectricitySource() {
        return electricitySource;
    }

    public void setElectricitySource(ElectricityMaterial electricitySource) {
        this.electricitySource = electricitySource;
    }

    public MediaMaterial getWaterSource() {
        return waterSource;
    }

    public void setWaterSource(MediaMaterial waterSource) {
        this.waterSource = waterSource;
    }

    public double getElectricityAmountKWh() {
        return electricityAmountKWh;
    }

    public void setElectricityAmountKWh(double electricityAmountKWh) {
        this.electricityAmountKWh = electricityAmountKWh;
    }

    public double getOxygenVolume() {
        return oxygenVolume;
    }

    public void setOxygenVolume(double oxygenVolume) {
        this.oxygenVolume = oxygenVolume;
    }

    public double getWaterVolume() {
        return waterVolume;
    }

    public void setWaterVolume(double waterVolume) {
        this.waterVolume = waterVolume;
    }

    public double getBlastPrice() {
        return blastPrice;
    }

    public void setBlastPrice(double blastPrice) {
        this.blastPrice = blastPrice;
    }

    public double getElectricityPrice() {
        return electricityPrice;
    }

    public void setElectricityPrice(double electricityPrice) {
        this.electricityPrice = electricityPrice;
    }

    public double getOxygenPrice() {
        return oxygenPrice;
    }

    public void setOxygenPrice(double oxygenPrice) {
        this.oxygenPrice = oxygenPrice;
    }

    public double getWaterPrice() {
        return waterPrice;
    }

    public void setWaterPrice(double waterPrice) {
        this.waterPrice = waterPrice;
    }

    public double getBlastCost() {
        return blastCost;
    }

    public void setBlastCost(double blastCost) {
        this.blastCost = blastCost;
    }

    public double getElectricityCost() {
        return electricityCost;
    }

    public void setElectricityCost(double electricityCost) {
        this.electricityCost = electricityCost;
    }

    public double getOxygenCost() {
        return oxygenCost;
    }

    public void setOxygenCost(double oxygenCost) {
        this.oxygenCost = oxygenCost;
    }

    public double getWaterCost() {
        return waterCost;
    }

    public void setWaterCost(double waterCost) {
        this.waterCost = waterCost;
    }

    public BlastFurnaceProcessData getHeatBalanceData() {
        return heatBalanceData;
    }

    public void setHeatBalanceData(BlastFurnaceProcessData heatBalanceData) {
        this.heatBalanceData = heatBalanceData;
    }

    public MetalComposition getDistributionFactor() {
        return distributionFactor;
    }

    public void setDistributionFactor(MetalComposition distributionFactor) {
        this.distributionFactor = distributionFactor;
    }

    public MetalComposition getMetalCompositionAverage() {
        return metalCompositionAverage;
    }

    public void setMetalCompositionAverage(MetalComposition metalCompositionAverage) {
        this.metalCompositionAverage = metalCompositionAverage;
    }

    public MetalComposition getMetalCompositionOfSlagElements() {
        return metalCompositionOfSlagElements;
    }

    public void setMetalCompositionOfSlagElements(MetalComposition metalCompositionOfSlagElements) {
        this.metalCompositionOfSlagElements = metalCompositionOfSlagElements;
    }

    public SlagComposition getSlagCompositionResult() {
        return slagCompositionResult;
    }

    public void setSlagCompositionResult(SlagComposition slagCompositionResult) {
        this.slagCompositionResult = slagCompositionResult;
    }

    public double getSlagBasicity() {
        return slagBasicity;
    }

    public void setSlagBasicity(double slagBasicity) {
        this.slagBasicity = slagBasicity;
    }

    public double getSlagAmount() {
        return slagAmount;
    }

    public void setSlagAmount(double slagAmount) {
        this.slagAmount = slagAmount;
    }

    public double getSlagBasicityResult() {
        return slagBasicityResult;
    }

    public void setSlagBasicityResult(double slagBasicityResult) {
        this.slagBasicityResult = slagBasicityResult;
    }

    public double getSlagAmountResult() {
        return slagAmountResult;
    }

    public void setSlagAmountResult(double slagAmountResult) {
        this.slagAmountResult = slagAmountResult;
    }

    public GasComposition getOffGasComposition() {
        return offGasComposition;
    }

    public void setOffGasComposition(GasComposition offGasComposition) {
        this.offGasComposition = offGasComposition;
    }

    public double getSumMaterialCosts() {
        return sumMaterialCosts;
    }

    public void setSumMaterialCosts(double sumMaterialCosts) {
        this.sumMaterialCosts = sumMaterialCosts;
    }

    public double getStaffCost() {
        return staffCost;
    }

    public void setStaffCost(double staffCost) {
        this.staffCost = staffCost;
    }

    public double getOverheadCost() {
        return overheadCost;
    }

    public void setOverheadCost(double overheadCost) {
        this.overheadCost = overheadCost;
    }

    public double getMaintenanceCost() {
        return maintenanceCost;
    }

    public void setMaintenanceCost(double maintenanceCost) {
        this.maintenanceCost = maintenanceCost;
    }

    public double getCapitalCost() {
        return capitalCost;
    }

    public void setCapitalCost(double capitalCost) {
        this.capitalCost = capitalCost;
    }

    public double getCreditGas() {
        return creditGas;
    }

    public void setCreditGas(double creditGas) {
        this.creditGas = creditGas;
    }

    public double getCreditSlag() {
        return creditSlag;
    }

    public void setCreditSlag(double creditSlag) {
        this.creditSlag = creditSlag;
    }

    public double getCreditGasCost() {
        return creditGasCost;
    }

    public void setCreditGasCost(double creditGasCost) {
        this.creditGasCost = creditGasCost;
    }

    public double getCreditSlagCost() {
        return creditSlagCost;
    }

    public void setCreditSlagCost(double creditSlagCost) {
        this.creditSlagCost = creditSlagCost;
    }

    public double getOffGasEnergy() {
        return offGasEnergy;
    }

    public void setOffGasEnergy(double offGasEnergy) {
        this.offGasEnergy = offGasEnergy;
    }

    public double getTopGasDryAmount() {
        return topGasDryAmount;
    }

    public void setTopGasDryAmount(double topGasDryAmount) {
        this.topGasDryAmount = topGasDryAmount;
    }

    public double getTopGasDryHeatContent() {
        return topGasDryHeatContent;
    }

    public void setTopGasDryHeatContent(double topGasDryHeatContent) {
        this.topGasDryHeatContent = topGasDryHeatContent;
    }

    public double getTopGasDryKmolTot() {
        return topGasDryKmolTot;
    }

    public void setTopGasDryKmolTot(double topGasDryKmolTot) {
        this.topGasDryKmolTot = topGasDryKmolTot;
    }

    public Integer getIsEtaH2Used() {
        return isEtaH2Used;
    }

    public void setIsEtaH2Used(Integer isEtaH2Used) {
        this.isEtaH2Used = isEtaH2Used;
    }

    public Integer getIsBlastMoistureUsed() {
        return isBlastMoistureUsed;
    }

    public void setIsBlastMoistureUsed(Integer isBlastMoistureUsed) {
        this.isBlastMoistureUsed = isBlastMoistureUsed;
    }

    public boolean isCalculated() {
        return calculated;
    }

    public void setCalculated(boolean calculated) {
        this.calculated = calculated;
    }

    public double getKmoleCO2() {
        return kmoleCO2;
    }

    public void setKmoleCO2(double kmoleCO2) {
        this.kmoleCO2 = kmoleCO2;
    }

    public double getKmoleCO() {
        return kmoleCO;
    }

    public void setKmoleCO(double kmoleCO) {
        this.kmoleCO = kmoleCO;
    }

    public boolean isValidCalculation() {
        return validCalculation;
    }

    public void setValidCalculation(boolean validCalculation) {
        this.validCalculation = validCalculation;
    }
    
}
