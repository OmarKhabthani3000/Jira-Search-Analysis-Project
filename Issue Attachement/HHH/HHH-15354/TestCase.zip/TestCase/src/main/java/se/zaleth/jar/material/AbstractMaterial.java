/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author krister
 */
public class AbstractMaterial {
    
    private long id;
    private Set<DistributedRawMaterialSetting> materialSettings;
    private Set<String> easilyOxidizedElementsForAluminum;
    private Set<String> easilyOxidizedElementsForIron;

    public AbstractMaterial() {
        materialSettings = new HashSet<>();
        easilyOxidizedElementsForAluminum = new HashSet<>();
        easilyOxidizedElementsForIron = new HashSet<>();
    }
    
    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }

    public Set<DistributedRawMaterialSetting> getMaterialSettings() {
        return materialSettings;
    }

    public void setMaterialSettings(Set<DistributedRawMaterialSetting> materialSettings) {
        this.materialSettings = materialSettings;
    }

    public Set<String> getEasilyOxidizedElementsForAluminum() {
        return easilyOxidizedElementsForAluminum;
    }

    public void setEasilyOxidizedElementsForAluminum(Set<String> easilyOxidizedElementsForAluminum) {
        this.easilyOxidizedElementsForAluminum = easilyOxidizedElementsForAluminum;
    }

    public Set<String> getEasilyOxidizedElementsForIron() {
        return easilyOxidizedElementsForIron;
    }

    public void setEasilyOxidizedElementsForIron(Set<String> easilyOxidizedElementsForIron) {
        this.easilyOxidizedElementsForIron = easilyOxidizedElementsForIron;
    }
    
}
