/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author krister
 */
public class BlastFurnace extends ProductionUnit {
    
    private List<MaterialContainerBlastFurnace> calibrationMaterials;
    private List<MaterialContainerBlastFurnace> defaultMaterials;

    public BlastFurnace() {
        super();
        calibrationMaterials = new ArrayList<>();
        defaultMaterials = new ArrayList<>();
    }
    
    public List<MaterialContainerBlastFurnace> getCalibrationMaterials() {
        return calibrationMaterials;
    }

    public void setCalibrationMaterials(List<MaterialContainerBlastFurnace> calibrationMaterials) {
        this.calibrationMaterials = calibrationMaterials;
    }

    public List<MaterialContainerBlastFurnace> getDefaultMaterials() {
        return defaultMaterials;
    }

    public void setDefaultMaterials(List<MaterialContainerBlastFurnace> defaultMaterials) {
        this.defaultMaterials = defaultMaterials;
    }
    
}
