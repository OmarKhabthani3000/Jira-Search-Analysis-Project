/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import java.util.ArrayList;
import java.util.List;
import se.zaleth.jar.plant.BlastFurnace;
import se.zaleth.jar.plant.MaterialContainerBlastFurnace;

/**
 *
 * @author krister
 */
public class HotMetalMaterial extends RawMaterial {
    
    private BlastFurnace furnace;
    private List<MaterialContainerBlastFurnace> chargedMaterials;

    public HotMetalMaterial() {
        super();
        chargedMaterials = new ArrayList<>();
    }
    
    public BlastFurnace getFurnace() {
        return furnace;
    }

    public void setFurnace(BlastFurnace furnace) {
        this.furnace = furnace;
    }
    
}
