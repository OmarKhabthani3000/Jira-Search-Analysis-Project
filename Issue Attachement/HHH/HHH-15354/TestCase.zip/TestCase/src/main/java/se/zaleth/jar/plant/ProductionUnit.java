/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

import se.zaleth.jar.material.AbstractMaterial;

/**
 *
 * @author krister
 */
public class ProductionUnit {
    
    private long id;
    private AbstractMaterial electricitySecondary;
    
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public AbstractMaterial getElectricitySecondary() {
        return electricitySecondary;
    }

    public void setElectricitySecondary(AbstractMaterial electricitySecondary) {
        this.electricitySecondary = electricitySecondary;
    }
    
}
