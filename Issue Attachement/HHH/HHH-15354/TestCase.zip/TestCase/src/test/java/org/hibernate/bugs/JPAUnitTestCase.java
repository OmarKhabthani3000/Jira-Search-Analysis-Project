/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.hibernate.bugs;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.Session;

import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private SessionFactory sf;

	@Before
	public void setup() {
		StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
			// Add in any settings that are specific to your test. See resources/hibernate.properties for the defaults.
                        .configure("hibernate.cfg.xml")
			.applySetting( "hibernate.show_sql", "true" )
			.applySetting( "hibernate.format_sql", "true" )
			/*.applySetting( "hibernate.hbm2ddl.auto", "update" )*/;

		Metadata metadata = new MetadataSources( srb.build() )
		// Add your entities here.
		//	.addAnnotatedClass( Foo.class )
                        /*.addResource("META-INF/BlastFurnaceProcessData.hbm.xml")
                        .addResource("META-INF/Composition.hbm.xml")*/
                        .addResource("META-INF/DistributedRawMaterialSetting.hbm.xml")
                        //.addResource("META-INF/GasComposition.hbm.xml")
                        .addResource("META-INF/Material.hbm.xml")
                        //.addResource("META-INF/MetalComposition.hbm.xml")
                        .addResource("META-INF/ProductionUnit.hbm.xml")
                        /*.addResource("META-INF/RawMaterialInheritance.hbm.xml")
                        .addResource("META-INF/SlagComposition.hbm.xml")*/
			.buildMetadata();

		sf = metadata.buildSessionFactory();
	}

	// Add your tests, using standard JUnit.
	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
            // No actual tests to be run, crash happens when creating the Session Factory
            Session session = sf.openSession();
	}
}
