package hibernate.bug;

import hibernate.bug.model.A;
import hibernate.bug.model.B;
import java.util.ArrayList;
import java.util.Properties;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CountTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        Properties properties = new Properties();
        properties.put("javax.persistence.jdbc.url",      System.getProperty("jdbc.url",      "jdbc:postgresql://localhost:5432/test"));
        properties.put("javax.persistence.jdbc.user",     System.getProperty("jdbc.user",     "postgres"));
        properties.put("javax.persistence.jdbc.password", System.getProperty("jdbc.password", "postgres"));
        properties.put("javax.persistence.jdbc.driver",   System.getProperty("jdbc.driver",   "org.postgresql.Driver"));
        properties.put("hibernate.hbm2ddl.auto", "create-drop");
        emf = Persistence.createEntityManagerFactory("Test", properties);
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        B b1 = new B(1, "1");
        B b2 = new B(2, "2");
        A a1 = new A(1, "1");
        A a2 = new A(2, "2");
        A a3 = new A(3, "3");
        
        a1.setB(b1);
        a2.setB(b2);
        a3.setB(b2);
        
        em.persist(a1);
        em.persist(a2);
        em.persist(a3);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testInLiteral() {
        EntityManager em = emf.createEntityManager();
        
        Long size = em.createQuery("SELECT COUNT(a) FROM A a WHERE a.id IN ()", Long.class).getSingleResult();
        Assert.assertEquals(0L, size.longValue());
    }
    
    @Test
    public void testInEmptyParameterList() {
        EntityManager em = emf.createEntityManager();
        
        Long size = em.createQuery("SELECT COUNT(a) FROM A a WHERE a.id IN :collection_valued_input_parameter", Long.class)
                .setParameter("collection_valued_input_parameter", new ArrayList<Object>(0))
                .getSingleResult();
        Assert.assertEquals(0L, size.longValue());
    }
}
