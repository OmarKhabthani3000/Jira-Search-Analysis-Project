
package hibernate.bug.model;

import java.io.Serializable;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class A implements Serializable {
    @Id
    public Integer aId;
    public String aName;

    @Embedded
    public B b;

    public A() {
    }

    public A(Integer id, String name) {
        this.aId = id;
        this.aName = "A" + name;
        this.b = new B(id + 100, "B" + name);
    }

    public Integer getaId() {
        return aId;
    }

    public void setaId(Integer aId) {
        this.aId = aId;
    }

    public String getaName() {
        return aName;
    }

    public void setaName(String aName) {
        this.aName = aName;
    }

    public B getB() {
        return b;
    }

    public void setB(B b) {
        this.b = b;
    }
}
