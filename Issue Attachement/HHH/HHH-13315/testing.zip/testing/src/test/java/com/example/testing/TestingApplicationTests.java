package com.example.testing;

import com.example.testing.entity.Authority;
import com.example.testing.entity.Role;
import com.example.testing.repository.AuthorityRepository;
import com.example.testing.repository.RoleRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestingApplicationTests {

	private static final String ID = "00000000-0000-0000-0000-000000000001";

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
    private AuthorityRepository authorityRepository;

	@Test
    @Transactional
	public void findById_RoleManyToManyAuthority_Success() {
		Optional<Role> role = roleRepository.findById(ID);
		assertTrue(role.isPresent() && role.get().getAuthorities().size() == 1);
	}

    @Test
    @Transactional
    public void findAll_Authority_Success() {
        List<Authority> authorities = authorityRepository.findAll();
        assertTrue(authorities.size() == 1);
    }
}
