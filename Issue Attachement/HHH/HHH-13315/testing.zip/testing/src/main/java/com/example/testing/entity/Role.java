package com.example.testing.entity;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "roles")
public class Role {

    @Id
    @Column(columnDefinition = "char(36)")
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid2")
    private String id;

    @Column(nullable = false)
    @Length(max = 255)
    private String name;

    @ManyToMany
    @JoinTable(name = "roles_authorities", joinColumns = {
        @JoinColumn(name = "role_id")
    }, inverseJoinColumns = {
        @JoinColumn(name = "authority_code", referencedColumnName = "code") })
    private List<Authority> authorities;
}
