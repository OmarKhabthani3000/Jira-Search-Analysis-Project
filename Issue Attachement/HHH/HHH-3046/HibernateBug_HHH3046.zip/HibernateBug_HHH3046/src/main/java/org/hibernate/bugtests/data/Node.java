package org.hibernate.bugtests.data;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Transient;

@Entity
public class Node {

	@Id
	@SequenceGenerator(name="NODE_SEQ", sequenceName="NODE_SEQ", initialValue=1, allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="NODE_SEQ")
	private Long nodeID;
	
	private String name;
	
	/** the list of orders that are delivered at this node */
	@OneToMany(fetch=FetchType.LAZY, cascade={CascadeType.MERGE, CascadeType.REFRESH}, mappedBy="deliveryNode")
	private List<Transport> deliveryTransport = new ArrayList<Transport>();
	
	/** the list of orders that are picked up at this node */
	@OneToMany(fetch=FetchType.LAZY, cascade=CascadeType.ALL, mappedBy="pickupNode")
	private List<Transport> pickupTransport = new ArrayList<Transport>();
	
	/** the route to which this node belongs */
	@ManyToOne(targetEntity=Route.class, optional=false, fetch=FetchType.EAGER)
	@JoinColumn(name="ROUTEID", nullable=false, insertable=true, updatable=true)
	private Route route = null;
	
	/** the tour this node belongs to, null if this node does not belong to a tour (e.g first node of a route) */
	@ManyToOne(targetEntity=Tour.class, cascade={CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH}, optional=true, fetch=FetchType.LAZY)
	@JoinColumn(name="TOURID", nullable=true, insertable=true, updatable=true)
	private Tour tour;
	
	@Transient
	private String transientField = "node original value";

	public List<Transport> getDeliveryTransport() {
		return deliveryTransport;
	}

	public void setDeliveryTransport(List<Transport> deliveryTransport) {
		this.deliveryTransport = deliveryTransport;
	}

	public List<Transport> getPickupTransport() {
		return pickupTransport;
	}

	public void setPickupTransport(List<Transport> pickupTransport) {
		this.pickupTransport = pickupTransport;
	}

	public Long getNodeID() {
		return nodeID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Route getRoute() {
		return route;
	}

	public void setRoute(Route route) {
		this.route = route;
	}

	public Tour getTour() {
		return tour;
	}
	
	public void setTour(Tour tour) {
		this.tour = tour;
	}
	
	public String toString()
	{
		StringBuffer buffer = new StringBuffer();
		
		buffer.append(name + " id: " + nodeID + " route name: " + route.getName() + " tour name: " + tour.getName() + "\n");
		for (Transport transport : pickupTransport) {
			buffer.append("Pickup transport: " + transport);
		}
		
		for (Transport transport : deliveryTransport) {
			buffer.append("Delivery transport: " + transport);
		}
		
		return buffer.toString();
	}

	public String getTransientField() {
		return transientField;
	}

	public void setTransientField(String transientField) {
		this.transientField = transientField;
	}

}
