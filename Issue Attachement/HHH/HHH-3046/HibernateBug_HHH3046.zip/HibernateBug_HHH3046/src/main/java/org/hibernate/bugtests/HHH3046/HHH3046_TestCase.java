package org.hibernate.bugtests.HHH3046;

import javax.persistence.EntityManager;

import org.hibernate.bugtests.data.Node;
import org.hibernate.bugtests.data.Route;
import org.hibernate.bugtests.data.Tour;
import org.hibernate.bugtests.data.Transport;

import junit.framework.TestCase;

/**
 * See http://opensource.atlassian.com/projects/hibernate/browse/HHH-3046
 * 
 * @author pavol.zibrita
 */
public class HHH3046_TestCase extends TestCase {

	String[] dbSetup = {
			"drop sequence NODE_SEQ",
			"drop sequence TRANSPORT_SEQ",
			"drop sequence ROUTE_SEQ",
			"drop sequence TOUR_SEQ",
			"drop table ROUTE cascade constraints",
			"drop table NODE cascade constraints",
			"drop table TRANSPORT cascade constraints",
			"drop table TOUR cascade constraints",
			"create sequence NODE_SEQ",
			"create sequence TRANSPORT_SEQ",
			"create sequence ROUTE_SEQ",
			"create sequence TOUR_SEQ",
			"create table NODE (nodeID number(10) not null, routeID number(10) not null, tourID number(10), name varchar2(100), constraint PK_NODE primary key (NODEID))",
			"create table ROUTE (routeID number(10) not null, name varchar2(100), constraint PK_ROUTE primary key (ROUTEID))",
			"create table TOUR (tourID number(10) not null, name varchar2(100), constraint PK_TOUR primary key (TOURID))",
			"create table TRANSPORT (transportID number(10) not null, name varchar2(100), pickupNodeID number(10), deliveryNodeID number(10), constraint PK_TRANSPORT primary key (TRANSPORTID))",
			"alter table NODE " +
			    "add constraint FK_NODE_ROUTE foreign key (ROUTEID) " +
			       "references ROUTE (ROUTEID) on delete cascade",
			"alter table TRANSPORT " +
			    "add constraint FK_TRAN_DELIVERYNODE foreign key (DELIVERYNODEID) " +
			       "references NODE (NODEID) on delete cascade",
			"alter table TRANSPORT " +
			    "add constraint FK_TRAN_PICKUPNODE foreign key (PICKUPNODEID) " +
			       "references NODE (NODEID) on delete cascade"
	};
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		EntityManager em = EntityManagerHelper.createEntityManager();
		for (String sql : dbSetup) {
			try {
				em.getTransaction().begin();
				em.createNativeQuery(sql).executeUpdate();
				em.getTransaction().commit();
			} catch (Exception e) {
				em.getTransaction().rollback();
				System.out.println(e.getMessage());
			}
		}
		EntityManagerHelper.commitAndCloseEntityManager(em);	
	}
	
	private Node pickupNode;
	
	private Node deliveryNode;
	
	private Tour tour;
	
	private Transport transport;
	

	private void createObjects(Route route)
	{
		tour = new Tour();
		tour.setName("tourB");
		
		transport = new Transport();
		transport.setName("transportB");
		
		pickupNode = new Node();
		pickupNode.setName("pickupNodeB");

		deliveryNode = new Node();
		deliveryNode.setName("deliveryNodeB");
	}
	
	private void setRelations(Route route)
	{
		pickupNode.setRoute(route);
		pickupNode.setTour(tour);
		pickupNode.getPickupTransport().add(transport);
		
		deliveryNode.setRoute(route);
		deliveryNode.setTour(tour);
		deliveryNode.getDeliveryTransport().add(transport);
		
		tour.getNode().add(pickupNode);
		tour.getNode().add(deliveryNode);
		
		route.getNode().add(pickupNode);
		route.getNode().add(deliveryNode);
		
		transport.setPickupNode(pickupNode);
		transport.setDeliveryNode(deliveryNode);
	}
	
	private void saveData() {
		EntityManager em = EntityManagerHelper.createEntityManager();
		
		Route route = new Route();
		route.setName("routeA");
		em.persist(route);
		
		EntityManagerHelper.commitAndCloseEntityManager(em);
	}
	
	void mergeData()
	{
		EntityManager em = EntityManagerHelper.createEntityManager();
		
		Route route = em.find(Route.class, new Long(1));
		//System.out.println(route);
		
		route.setTransientField(new String("sfnaouisrbn"));
		
		createObjects(route);
		
		transport.setTransientField("aaaaaaaaaaaaaa");
		pickupNode.setTransientField("pickup node aaaaaaaaaaa");
		deliveryNode.setTransientField("delivery node aaaaaaaaa");
		
		setRelations(route);
		
		System.out.println(route);
		Route routeEntity = em.merge(route);
		System.out.println("--------------------------------------");
		System.out.println(routeEntity);
		System.out.println(routeEntity.getNode().get(0).getPickupTransport().get(0).getTransientField());
		System.out.println(routeEntity.getNode().get(0).getTransientField());
		System.out.println(routeEntity.getNode().get(1).getTransientField());
		System.out.println("--------------------------------------");
		
		EntityManagerHelper.commitAndCloseEntityManager(em);		
	}
	
	
	/**
	 * THE test method 
	 */
	public void testBug_HHH3046()
	{
		saveData();	
		mergeData();
	}
}
