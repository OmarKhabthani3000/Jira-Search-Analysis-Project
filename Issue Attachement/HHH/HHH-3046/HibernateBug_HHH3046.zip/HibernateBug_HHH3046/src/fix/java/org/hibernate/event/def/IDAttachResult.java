/*
 * Copyright (C) 2006 Whitestein Technologies AG, Poststrasse 22, CH-6300 Zug, Switzerland.
 * All rights reserved. The use of this file in source or binary form requires a written license from Whitestein Technologies AG.
 *
 */
package org.hibernate.event.def;

import java.io.Serializable;

import org.hibernate.engine.EntityKey;

public class IDAttachResult
{

	private EntityKey key;
	private boolean immediateAccess;
	private boolean useIdentityColumn;
	private Serializable id;
	private boolean performSave;

	public IDAttachResult(Serializable id)
	{
		this.id = id;
		this.performSave = false;
	}

	public IDAttachResult(Serializable generatedId, EntityKey key, boolean immediateAccess, boolean useIdentityColumn)
	{
		this.id = generatedId;
		this.key = key;
		this.immediateAccess = immediateAccess;
		this.useIdentityColumn = useIdentityColumn;
		this.performSave = true;
	}

	public boolean isRequiresImmediateAccess()
	{
		return immediateAccess;
	}

	public EntityKey getKey()
	{
		return key;
	}

	public boolean isUseIdentityColumn()
	{
		return useIdentityColumn;
	}

	public boolean performSave() {
		return performSave;
	}

	public Serializable getId()
	{
		return id;
	}
}
