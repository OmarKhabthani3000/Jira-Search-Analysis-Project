package entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


@Entity
public abstract class Country {
	private static Log logger = LogFactory.getLog(Country.class);
	private PropertyUtils utils;

	@Id
	@GeneratedValue
	private Long id;
}
