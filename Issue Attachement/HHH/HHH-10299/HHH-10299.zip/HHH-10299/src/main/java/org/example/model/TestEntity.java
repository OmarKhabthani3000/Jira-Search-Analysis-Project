package org.example.model;

import org.hibernate.envers.Audited;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class TestEntity {
  @Id      @Column public Long   id;
  @Audited @Column public String name;
}
