package org.hibernate.bugs;

import org.hibernate.testing.junit4.BaseNonConfigCoreFunctionalTestCase;
import org.example.model.TestEntity;
import org.junit.Test;

public class HHH10299 extends BaseNonConfigCoreFunctionalTestCase {

	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] { TestEntity.class };
	}

	@Test
	public void test() {}

}
