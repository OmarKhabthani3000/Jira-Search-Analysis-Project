package sobos2.domain;

import sobos2.domain.keys.DyspozycjaDokumentyId;

public class DyspozycjaDokumenty {
	private DyspozycjaDokumentyId id;
	private String tytulem;
	private String dokument1;
	private String dokument2;
	private String dokument3;
	
	public DyspozycjaDokumenty() {
		super();
	}

	public DyspozycjaDokumenty(DyspozycjaDokumentyId id) {
		super();
		this.id = id;
	}

	public DyspozycjaDokumentyId getId() {
		return id;
	}

	public void setId(DyspozycjaDokumentyId id) {
		this.id = id;
	}

	public String getTytulem() {
		return tytulem;
	}

	public void setTytulem(String tytulem) {
		this.tytulem = tytulem;
	}

	public String getDokument1() {
		return dokument1;
	}

	public void setDokument1(String dokument1) {
		this.dokument1 = dokument1;
	}

	public String getDokument2() {
		return dokument2;
	}

	public void setDokument2(String dokument2) {
		this.dokument2 = dokument2;
	}

	public String getDokument3() {
		return dokument3;
	}

	public void setDokument3(String dokument3) {
		this.dokument3 = dokument3;
	}

	@Override
	public int hashCode() {
		return id.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		final DyspozycjaDokumenty other = (DyspozycjaDokumenty) obj;
		return id.equals(other.id);
	}

}
