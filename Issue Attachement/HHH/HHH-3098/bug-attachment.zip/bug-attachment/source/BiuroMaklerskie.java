package sobos2.domain;

public class BiuroMaklerskie {
	private String kod;
	private String nazwa;
	private String skreslonySl;
	private String osobaFizyczna;
	private String czyRezydent;
	
	public BiuroMaklerskie() {
		super();
	}

	public String getKod() {
		return kod;
	}

	public void setKod(String kod) {
		this.kod = kod;
	}

	public String getNazwa() {
		return nazwa;
	}

	public void setNazwa(String nazwa) {
		this.nazwa = nazwa;
	}

	public String getSkreslonySl() {
		return skreslonySl;
	}

	public void setSkreslonySl(String skreslonySl) {
		this.skreslonySl = skreslonySl;
	}

	public String getOsobaFizyczna() {
		return osobaFizyczna;
	}

	public void setOsobaFizyczna(String osobaFizyczna) {
		this.osobaFizyczna = osobaFizyczna;
	}

	public String getCzyRezydent() {
		return czyRezydent;
	}

	public void setCzyRezydent(String czyRezydent) {
		this.czyRezydent = czyRezydent;
	}

	@Override
	public int hashCode() {
		return kod.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		final BiuroMaklerskie other = (BiuroMaklerskie) obj;
		return kod.equals(other.kod);
	}
	
}
