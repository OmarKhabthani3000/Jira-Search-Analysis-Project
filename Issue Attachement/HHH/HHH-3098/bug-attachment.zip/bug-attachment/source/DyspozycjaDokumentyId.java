package sobos2.domain.keys;

import java.io.Serializable;
import java.util.Date;

@SuppressWarnings("serial")
public class DyspozycjaDokumentyId implements Serializable {
	private Long numerDyspozycji;
	private Date dataKsiegowania;
	
	public DyspozycjaDokumentyId() {
		super();
	}

	public DyspozycjaDokumentyId(Long numerDyspozycji, Date dataKsiegowania) {
		super();
		this.numerDyspozycji = numerDyspozycji;
		this.dataKsiegowania = dataKsiegowania;
	}

	public Long getNumerDyspozycji() {
		return numerDyspozycji;
	}

	public void setNumerDyspozycji(Long numerDyspozycji) {
		this.numerDyspozycji = numerDyspozycji;
	}

	public Date getDataKsiegowania() {
		return dataKsiegowania;
	}

	public void setDataKsiegowania(Date dataKsiegowania) {
		this.dataKsiegowania = dataKsiegowania;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dataKsiegowania == null) ? 0 : dataKsiegowania.hashCode());
		result = prime * result + ((numerDyspozycji == null) ? 0 : numerDyspozycji.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final DyspozycjaDokumentyId other = (DyspozycjaDokumentyId) obj;
		if (dataKsiegowania == null) {
			if (other.dataKsiegowania != null)
				return false;
		} else if (!dataKsiegowania.equals(other.dataKsiegowania))
			return false;
		if (numerDyspozycji == null) {
			if (other.numerDyspozycji != null)
				return false;
		} else if (!numerDyspozycji.equals(other.numerDyspozycji))
			return false;
		return true;
	}
	
}
