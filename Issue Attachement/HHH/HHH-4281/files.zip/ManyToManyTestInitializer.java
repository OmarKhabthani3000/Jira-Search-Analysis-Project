package com.fdc.dsd.example.test;


import org.testng.annotations.*;

import com.fdc.dsd.common.model.*;
import com.fdc.dsd.common.persistence.*;
import com.fdc.dsd.example.model.*;


public class ManyToManyTestInitializer extends ExampleHbnAwareTester
{
	private GenericDao<Referencee, Long> eeDao = null;
	private GenericDao<Referencer, Long> erDao = null;
	

	public ManyToManyTestInitializer()
	{
		super( false, false );
	}


	@Test
	public void initModel() throws Exception
	{
		HrProfile barry = new HrProfileDao().findById( "179453" );

		CurrentUserRegistry.set( barry );
		
		eeDao = new GenericDao<Referencee, Long>( Referencee.class );
		erDao = new GenericDao<Referencer, Long>( Referencer.class );
		
		if (eeDao.findAll().size() == 0)
			addEntries();
		
		for (Referencer er : erDao.findAll())
			for (Referencee e : er.getSet())
				e.dump();
	}
	
	
	private void addEntries()
	{
		Referencee eeOne = new Referencee( "Referencee One" );
		Referencee eeTwo = new Referencee( "Referencee Two" );
		Referencee eeThree = new Referencee( "Referencee Three" );
		
		eeDao.makePersistent( eeOne );
		eeDao.makePersistent( eeTwo );
		eeDao.makePersistent( eeThree );
		
		Referencer erOne = new Referencer( "Referencer 1" );
		Referencer erTwo = new Referencer( "Referencer 2" );
		Referencer erThree = new Referencer( "Referencer 3" );
		
		erOne.getSet().add( eeOne );
		erOne.getSet().add( eeTwo );
		erTwo.getSet().add( eeTwo );
		erTwo.getSet().add( eeThree );
		erThree.getSet().add( eeOne );
		erThree.getSet().add( eeThree );
		
		erDao.makePersistent( erOne );
		erDao.makePersistent( erTwo );
		erDao.makePersistent( erThree );
		
		HbnSessionUtil.commitAndBeginNewTransaction();
	}
}
