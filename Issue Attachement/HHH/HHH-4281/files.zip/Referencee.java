package com.fdc.dsd.example.model;


import javax.persistence.*;

import org.apache.commons.logging.*;

import com.fdc.dsd.common.test.*;


@Entity
public class Referencee implements Dumpable
{
	private Log		log		= LogFactory.getLog( getClass() );

	private Long	id		= null;
	private String	name	= null;


	public Referencee()
	{
	}


	public Referencee( String name )
	{
		setName( name );
	}


	@Override
	public void dump()
	{
		log.info( "Referencee:" );
		log.info( "\tname:\t" + getName() );
		log.info( "" );
	}


	@Id
	public Long getId()
	{
		return id;
	}


	private void setId( Long id )
	{
		this.id = id;
	}


	public String getName()
	{
		return name;
	}


	public void setName( String name )
	{
		this.name = name;
	}
}
