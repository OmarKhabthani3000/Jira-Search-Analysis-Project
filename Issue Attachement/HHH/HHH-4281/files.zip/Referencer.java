package com.fdc.dsd.example.model;


import java.util.*;

import javax.persistence.*;

import org.apache.commons.logging.*;

import com.fdc.dsd.common.test.*;


@Entity
public class Referencer implements Dumpable
{
	private Log				log		= LogFactory.getLog( getClass() );

	private Long			id		= null;
	private String			name	= null;
	private Set<Referencee>	set		= new HashSet<Referencee>();


	public Referencer()
	{
	}


	public Referencer( String name )
	{
		setName( name );
	}


	@Override
	public void dump()
	{
		log.info( "Referencer:" );
		log.info( "\tname:\t" + getName() );
		log.info( "" );
	}


	@Id
	@GeneratedValue( strategy = GenerationType.AUTO )
	public Long getId()
	{
		return id;
	}


	private void setId( Long id )
	{
		this.id = id;
	}


	public String getName()
	{
		return name;
	}


	public void setName( String name )
	{
		this.name = name;
	}


	@ManyToMany
	@JoinTable( joinColumns = { @JoinColumn( nullable = false ) }, inverseJoinColumns = { @JoinColumn( nullable = false ) } )
	public Set<Referencee> getSet()
	{
		return set;
	}


	public void setSet( Set<Referencee> set )
	{
		this.set = set;
	}

}
