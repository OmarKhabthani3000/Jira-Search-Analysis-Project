/**
 * Copyright (c) 2013 Elaxy Financial Software & Solutions Gmbh & Co. KG Alle
 * Rechte vorbehalten.
 *
 * @file OrderProblemTest.java
 */
package test.orderproblem;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * TODO Beschreibung der Klasse
 *
 * @file OrderProblemTest.java
 * @since 11.06.2015
 * @author RME
 */
public class OrderProblemTest
{
  private SessionFactory sessionFactory;

  @Before
  public void setup()
  {
    final Configuration configure = new Configuration().configure();
    sessionFactory = configure.buildSessionFactory(new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml")
                                                                                       .build());
  }

  @After
  public void teardown()
  {
    sessionFactory.close();
  }

  @Test
  public void testOrder()
  {
    final Session session = sessionFactory.openSession();
    session.getTransaction().begin();

    // First object with dependent object (address)
    final Person person = new Person();
    person.addAddress(new Address());
    session.persist(person);

    // Derived Object with dependent object (address)
    final SpecialPerson specialPerson = new SpecialPerson();
    specialPerson.addAddress(new Address());
    session.persist(specialPerson);

    session.getTransaction().commit();
    session.close();
  }
}
