/**
 * Copyright (c) ELAXY Financial Software & Solutions GmbH & Co. KG Alle Rechte
 * vorbehalten.
 */
package test.orderproblem;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Address class.
 *
 */
@Entity
@Access(AccessType.FIELD)
@Table(name = "ADDRESS")
public class Address
{

  @Id
  @Column(name = "ID", nullable = false)
  @SequenceGenerator(name = "ID", sequenceName = "ADDRESS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ID")
  private Long id;
}
