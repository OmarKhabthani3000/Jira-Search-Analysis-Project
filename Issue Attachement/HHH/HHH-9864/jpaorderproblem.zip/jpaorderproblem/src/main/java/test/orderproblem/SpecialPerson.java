/**
 * Copyright (c) ELAXY Financial Software & Solutions GmbH & Co. KG Alle Rechte
 * vorbehalten.
 */
package test.orderproblem;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * Derived person class.
 */
@Entity
@Access(AccessType.FIELD)
@DiscriminatorValue("2")
public class SpecialPerson extends Person
{

  @Column(name = "special")
  private String special;
}
