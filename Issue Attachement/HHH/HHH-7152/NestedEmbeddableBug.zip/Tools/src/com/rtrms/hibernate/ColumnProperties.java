package com.rtrms.hibernate;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Type;

@Embeddable
public class ColumnProperties {
    
    @Column(name = "CONFIGURATION")
    @Type(type = "text")
    private String configuration;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "FILTER_ID")
    private FilterImpl filter;
    
}
