package com.rtrms.hibernate;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.IndexColumn;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.HSQLDialect;
import org.hsqldb.jdbcDriver;

@Entity
@Table(name = "VIEW")
public class View {
    
    @Id
    @Column(name = "ID")
    protected Long id;
    
    @JoinTable(name = "VIEW_COLUMN", joinColumns = { @JoinColumn(name = "VIEW_ID") })
    @ElementCollection
    @IndexColumn(name = "COLUMN_INDEX")
    @Cascade(CascadeType.ALL)
    private List<ViewColumn> columns;
    
    public static void main(String[] args) {
        Configuration config = new AnnotationConfiguration().addAnnotatedClass(View.class).addAnnotatedClass(FilterImpl.class);
        config.setProperty(Environment.DIALECT, HSQLDialect.class.getName());
        config.setProperty(Environment.DRIVER, jdbcDriver.class.getName());
        config.setProperty(Environment.URL, "jdbc:hsqldb:mem:testDB;shutdown=true");
        config.setProperty(Environment.USER, "SA");
        config.setProperty(Environment.PASS, "");
        config.buildSessionFactory();
    }
}
