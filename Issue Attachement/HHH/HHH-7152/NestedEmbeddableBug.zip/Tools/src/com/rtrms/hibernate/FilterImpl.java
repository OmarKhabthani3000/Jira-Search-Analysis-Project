package com.rtrms.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "FILTER")
public class FilterImpl {
    
    @Id
    @Column(name = "ID")
    protected Long id;
    
}
