package com.rtrms.hibernate;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;

@Embeddable
public class ViewColumn {
    
    @Column(name = "NAME")
    private String name;
    
    @Embedded
    private ColumnProperties properties = new ColumnProperties();
    
}
