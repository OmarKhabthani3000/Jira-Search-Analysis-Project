package testcase;


public enum ColorType {
	RED("R"),
	GREEN("G"),
	BLUE("B");
	
	private String dbString;
	
	private ColorType(String dbString) {
		this.dbString = dbString;
	}
	
	public String getDbString() {
		return dbString;
	}
	
	public static ColorType build(String dbString) {
		switch (dbString) {
			case "R":
				return RED;
			case "G":
				return GREEN;
			case "B":
				return BLUE;
			default:
				throw new IllegalArgumentException(dbString + " ist an invalid value for ColorType");
		}
	}
}
