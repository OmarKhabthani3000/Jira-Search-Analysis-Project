package testcase;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class ColorTypeConverter implements AttributeConverter<ColorType, String> {
	@Override
	public String convertToDatabaseColumn(ColorType hobbyType) {
		return hobbyType.getDbString();
	}

	@Override
	public ColorType convertToEntityAttribute(String dbString) {
		return ColorType.build(dbString);
	}
}
