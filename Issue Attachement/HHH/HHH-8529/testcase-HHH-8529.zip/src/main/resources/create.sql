-- H2
ALTER SEQUENCE hibernate_sequence RESTART WITH 5000;

-- Oracle
-- DROP SEQUENCE hibernate_sequence;
-- CREATE SEQUENCE hibernate_sequence START WITH 5000;
