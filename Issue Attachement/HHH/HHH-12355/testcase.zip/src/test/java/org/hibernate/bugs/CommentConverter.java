package org.hibernate.bugs;

import org.hibernate.bugs.model.Comment;

import javax.persistence.AttributeConverter;

public class CommentConverter implements AttributeConverter<Comment, String> {

    @Override
    public String convertToDatabaseColumn(Comment addresses) {
        return addresses.getComment().replace("NoSql","***");
    }

    @Override
    public Comment convertToEntityAttribute(String s) {
        return new Comment(s);
    }
}
