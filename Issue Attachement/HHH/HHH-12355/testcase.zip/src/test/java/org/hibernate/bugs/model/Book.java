package org.hibernate.bugs.model;

import java.io.Serializable;
import java.util.Objects;
public class Book implements Serializable {

    String id;
//    String version;
    IntermediateObject intermediateObject;

    public IntermediateObject getIntermediateObject() {
        return intermediateObject;
    }

    public void setIntermediateObject(IntermediateObject intermediateObject) {
        this.intermediateObject = intermediateObject;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

//    public String getVersion() {
//        return version;
//    }
//
//    public void setVersion(String version) {
//        this.version = version;
//    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
//        return Objects.equals(id, book.id) && Objects.equals(version, book.version);
        return Objects.equals(id, book.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
