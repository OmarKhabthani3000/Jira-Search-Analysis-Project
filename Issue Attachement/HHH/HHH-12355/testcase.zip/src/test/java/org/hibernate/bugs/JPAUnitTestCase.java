package org.hibernate.bugs;

import org.hibernate.bugs.model.Book;
import org.hibernate.bugs.model.Comment;
import org.hibernate.bugs.model.IntermediateObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.*;

import static org.junit.Assert.assertEquals;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {
	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Add your tests, using standard JUnit.
	@Test
	public void hhhxxxxTest() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		entityManager.getTransaction().begin();
		Book bookNoComment = new Book();
		bookNoComment.setId(UUID.randomUUID().toString());
		Book bookWithComment = new Book();
		bookWithComment.setId(UUID.randomUUID().toString());
		bookWithComment.setIntermediateObject(new IntermediateObject(new Comment("This is a comment")));

		entityManager.persist(bookNoComment);
		entityManager.persist(bookWithComment);

		entityManager.getTransaction().commit();

		entityManager.clear();
		entityManager.close();
	}
}
