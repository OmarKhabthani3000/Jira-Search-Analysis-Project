package org.hibernate.bugs.model;

public class IntermediateObject {
    private Comment comment;

    public IntermediateObject() {
    }

    public IntermediateObject(Comment comment) {
        this.comment = comment;
    }

    public Comment getComment() {
        return comment;
    }

    public void setComment(Comment comment) {
        this.comment = comment;
    }
}
