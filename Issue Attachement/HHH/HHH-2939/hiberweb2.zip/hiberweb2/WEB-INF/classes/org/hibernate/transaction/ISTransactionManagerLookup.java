package org.hibernate.transaction;

import java.util.Properties;

import javax.transaction.TransactionManager;

import org.hibernate.HibernateException;

/**
 * TransactionManager lookup strategy for Fujitsu Interstage
 * @author Hideki Hara
 */
public class ISTransactionManagerLookup implements TransactionManagerLookup {

	/**
	 * @see org.hibernate.transaction.TransactionManagerLookup#getTransactionManager(Properties)
	 */
	public TransactionManager getTransactionManager(Properties props) throws HibernateException {
		try {
			Class clazz = Class.forName("com.fujitsu.interstage.transaction.ISTransactionManager");
			return (javax.transaction.TransactionManager)clazz.newInstance();

		}
		catch (Exception e){
			throw new HibernateException( "Could not obtain Interstage transaction manager instance", e );
		}
	}

	/**
	 * @see org.hibernate.transaction.TransactionManagerLookup#getUserTransactionName()
	 */
	public String getUserTransactionName() {
		return "java:comp/UserTransaction";
	}
}
