package com;
public class Employee{
	private int no;
	private String name;

	private Employee(){};

	public Employee(String name){
		this.name = name;
	}

	public int getNo(){
		return this.no;
	}

	public String getName(){
		return this.name;
	}

	public void setName(String name){
		this.name = name;
	}

	public void setNo(int no){
		this.no = no;
	}

}