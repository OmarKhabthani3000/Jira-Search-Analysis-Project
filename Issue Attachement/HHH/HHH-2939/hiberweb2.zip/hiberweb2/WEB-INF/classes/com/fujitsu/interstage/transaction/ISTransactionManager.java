package com.fujitsu.interstage.transaction;

import javax.transaction.* ;
import javax.naming.InitialContext ;
import javax.naming.Context ;

public class ISTransactionManager implements TransactionManager {

	UserTransaction tran = null ;

	public ISTransactionManager() throws javax.naming.NamingException {
		InitialContext context = new InitialContext() ;
		tran = (UserTransaction)context.lookup( "java:comp/UserTransaction" ) ;
	}

	public void begin() throws javax.transaction.NotSupportedException,javax.transaction.SystemException{
		tran.begin() ;
	}

	public void commit() throws RollbackException,
                   HeuristicMixedException,
                   HeuristicRollbackException,
                   SecurityException,
                   IllegalStateException,
                   SystemException {
		tran.commit() ;
	}

	public int getStatus() throws javax.transaction.SystemException{
		return tran.getStatus() ;
	}

	public Transaction getTransaction() {
		throw new java.lang.UnsupportedOperationException() ;
	}

	public void resume(Transaction tobj) {
		throw new java.lang.UnsupportedOperationException() ;
	}

	public void rollback() throws javax.transaction.SystemException{
		tran.rollback() ;
	}

	public void setRollbackOnly() throws javax.transaction.SystemException{
		tran.setRollbackOnly() ;
	}

	public void setTransactionTimeout(int seconds) throws javax.transaction.SystemException{
		tran.setTransactionTimeout(seconds) ;
	}

	public Transaction suspend() {
		throw new java.lang.UnsupportedOperationException() ;
	}

}

