package com.hh.hara;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class Login extends javax.servlet.http.HttpServlet{

  public void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {

  request.setCharacterEncoding("ISO-8859-1");
  response.setContentType("text/html;charset=Windows-31j");

  String name = request.getParameter("name");
  if (name == null){
    name = "";
  }
  name = new String(name.getBytes("ISO-8859-1"),"Windows-31j");

  String pass = request.getParameter("pass");
  if (pass == null){
    pass = "";
  }
  pass = new String(pass.getBytes("ISO-8859-1"),"Windows-31j");

  String hidden = request.getParameter("hidden");
  if (hidden == null){
    hidden = "";
  }
  hidden = new String(hidden.getBytes("ISO-8859-1"),"Windows-31j");


  Enumeration enumaaa = request.getHeaderNames();

  String aaa = "";
  String bbb = "";
  String ccc = "";
  String ddd = "";

  String eee = "";
  String fff = "";

		org.hibernate.SessionFactory sessionfactory = new org.hibernate.cfg.Configuration().configure().buildSessionFactory();
		org.hibernate.Session session = sessionfactory.openSession();
		org.hibernate.Transaction tx = session.beginTransaction();
		com.Employee emp = new com.Employee("vreqeeee");
		com.Employee emp6 = new com.Employee("aaavreqeeee");
		com.Employee emp7 = new com.Employee("hara");
		com.Employee emp8 = new com.Employee("serikawa");
		com.Employee emp9 = new com.Employee("murakami");
		session.save(emp);
		session.save(emp7);
		session.save(emp8);
		session.save(emp9);
		session.save(emp6);
		tx.commit();
		session.close();
		

  try{
  com.fujitsu.interstage.transaction.ISTransactionManager istm = new com.fujitsu.interstage.transaction.ISTransactionManager();
  istm.begin();
  String zzz = "";
  eee = istm.toString();
  istm.commit();

  java.lang.Class clazz = java.lang.Class.forName("com.fujitsu.interstage.transaction.ISTransactionManager");
  javax.transaction.TransactionManager istmm = (javax.transaction.TransactionManager)clazz.newInstance();
  fff = istmm.toString();
  istmm.begin();
  istmm.commit();

  }catch(javax.transaction.SystemException e){e.printStackTrace();}
  catch(javax.transaction.RollbackException e){e.printStackTrace();}
  catch(javax.transaction.NotSupportedException e){e.printStackTrace();}
  catch(javax.transaction.HeuristicMixedException e){e.printStackTrace();}
  catch(javax.transaction.HeuristicRollbackException e){e.printStackTrace();}
  catch(javax.naming.NamingException e){e.printStackTrace();}
  catch(java.lang.ClassNotFoundException e){e.printStackTrace();}
  catch(java.lang.InstantiationException e){e.printStackTrace();}
  catch(java.lang.IllegalAccessException e){e.printStackTrace();}
  




  response.setContentType("text/html;charset=Windows-31j");
  java.io.PrintWriter out = response.getWriter();
  out.println("<html>");
  out.println("<head>");
  out.println("</head>");
  out.println("<body>");
  out.println("name = " + name + "<br>");
  out.println("pass = " + pass + "<br>");
  out.println("hidden = " + hidden + "<br>");
  out.println("transaction istm = " + eee + "<br>");
  out.println("transaction istmm = " + fff + "<br>");
  while(enumaaa.hasMoreElements()){
    String s = (String)enumaaa.nextElement();
    String t = request.getHeader(s);
    out.println("header = " + s + " : " + t + "<br>");
  }
  out.println("</body>");
  out.println("</html>");



  }
  public void init(){}
  public void destroy(){}
}