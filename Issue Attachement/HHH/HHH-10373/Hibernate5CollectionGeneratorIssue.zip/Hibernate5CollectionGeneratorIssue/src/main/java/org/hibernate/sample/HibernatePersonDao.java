package org.hibernate.sample;

import org.hibernate.SessionFactory;

public class HibernatePersonDao {

	private SessionFactory sessionFactory;

	public void savePerson(Person person) {
		sessionFactory.getCurrentSession().save(person);
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
}
