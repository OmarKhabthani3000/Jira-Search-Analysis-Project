ALTER SESSION SET DEFERRED_SEGMENT_CREATION = false;

ALTER SESSION SET NLS_LENGTH_SEMANTICS='CHAR';

CREATE TABLE email (
	id NUMBER(19) NOT NULL,
	email VARCHAR2(200) NOT NULL,
	is_primary NUMBER(1) NOT NULL
	
);

ALTER TABLE email ADD CONSTRAINT pk_email PRIMARY KEY (id);
ALTER TABLE email ADD CONSTRAINT uq_email UNIQUE (email);

CREATE SEQUENCE seq_email_id INCREMENT BY 1 START WITH 1 NOMAXVALUE NOCYCLE NOCACHE NOORDER;

CREATE TABLE person (
	id NUMBER(19) NOT NULL,
	first_name VARCHAR2(100) NOT NULL,
	last_name VARCHAR2(100) NOT NULL
);

ALTER TABLE person ADD CONSTRAINT pk_person PRIMARY KEY (id);

CREATE SEQUENCE seq_person_id INCREMENT BY 1 START WITH 1 NOMAXVALUE NOCYCLE NOCACHE NOORDER;

CREATE TABLE person_email (
	id NUMBER(19) NOT NULL,
	ref_person NUMBER(19) NOT NULL,
	ref_email NUMBER(19) NOT NULL
);

ALTER TABLE person_email ADD CONSTRAINT pk_person_email PRIMARY KEY (id);
ALTER TABLE person_email ADD CONSTRAINT fk_person_email_person FOREIGN KEY (ref_person) REFERENCES person (id);
ALTER TABLE person_email ADD CONSTRAINT fk_person_email_email FOREIGN KEY (ref_email) REFERENCES email (id);
ALTER TABLE person_email ADD CONSTRAINT uq_person_email UNIQUE (ref_person, ref_email);

CREATE INDEX fk_person_email_person_idx ON person_email (ref_person);
CREATE INDEX fk_person_email_email_idx ON person_email (ref_email);

CREATE SEQUENCE seq_person_email_id INCREMENT BY 1 START WITH 1 NOMAXVALUE NOCYCLE NOCACHE NOORDER;