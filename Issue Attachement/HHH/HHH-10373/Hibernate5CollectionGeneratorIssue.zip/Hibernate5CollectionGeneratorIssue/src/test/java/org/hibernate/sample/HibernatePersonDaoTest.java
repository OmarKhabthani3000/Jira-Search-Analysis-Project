package org.hibernate.sample;

import org.junit.Test;
import org.unitils.UnitilsJUnit4;
import org.unitils.spring.annotation.SpringApplicationContext;
import org.unitils.spring.annotation.SpringBeanByType;

@SpringApplicationContext({"classpath:spring/applicationContext-hibernate.xml",
    "classpath:spring/testContext-ds.xml",
    "classpath:spring/testContext-hibernate-tx.xml",
    "classpath:spring/testContext-dao.xml"})
public class HibernatePersonDaoTest extends UnitilsJUnit4 {

	@SpringBeanByType
	private HibernatePersonDao personDao;
	
	@Test
	public void testSavePerson() {
		Person person = new Person();
		person.setFirstName("John");
		person.setLastName("Doe");
		
		Email email = new Email();
		
		email.setValue("john.doe@hibernate.org");
		email.setIsPrimary(true);
		
		person.getEmails().add(email);
		
		personDao.savePerson(person);
	}
}
