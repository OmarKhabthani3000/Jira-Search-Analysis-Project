package org.hibernate.test.annotations.cidcache;

import java.io.Serializable;

public class FootballerPk implements Serializable {
	private String firstname2;
	private String lastname;

	public String getFirstname2() {
		return firstname2;
	}

	public String getLastname() {
		return lastname;
	}

	public void setFirstname2(String firstname) {
		this.firstname2 = firstname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public FootballerPk() {
	}

	public FootballerPk(String firstname, String lastname) {
		this.firstname2 = firstname;
		this.lastname = lastname;

	}

	public boolean equals(Object o) {
		if ( this == o ) return true;
		if ( !( o instanceof FootballerPk ) ) return false;

		final FootballerPk t = (FootballerPk) o;

		if ( !firstname2.equals( t.firstname2 ) ) return false;
		if ( !lastname.equals( t.lastname ) ) return false;

		return true;
	}

	public int hashCode() {
		return 1;
	}

}
