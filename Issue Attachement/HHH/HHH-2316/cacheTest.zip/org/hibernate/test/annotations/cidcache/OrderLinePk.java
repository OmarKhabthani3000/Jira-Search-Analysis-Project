package org.hibernate.test.annotations.cidcache;


import java.io.Serializable;


public class OrderLinePk implements Serializable {
	private String firstname;
	private String lastname;

	public OrderLinePk() {
	}

	public OrderLinePk(String firstname, String lastname) {
		this.firstname = firstname;
		this.lastname = lastname;

	}

	public String getFirstname() {
		return firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


	public boolean equals(Object o) {
		if ( this == o ) return true;
		if ( !( o instanceof OrderLinePk ) ) return false;

		final OrderLinePk t = (OrderLinePk) o;

		if ( !firstname.equals( t.firstname ) ) return false;
		if ( !lastname.equals( t.lastname ) ) return false;

		return true;
	}

	public int hashCode() {
		return 1;
	}

}
