package org.hibernate.test.annotations.cidcache;

import javax.persistence.Entity;
import javax.persistence.IdClass;
import javax.persistence.Id;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


@Entity
@IdClass(OrderLinePk.class)
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE, region="rw")
public class OrderLine {
    
    private String firstname;
    
    private String lastname;
    
	public boolean equals(Object o) {
		if ( this == o ) return true;
		if ( !( o instanceof OrderLine ) ) return false;

		final OrderLine t = (OrderLine) o;

		if ( !firstname.equals( t.firstname ) ) return false;
		if ( !lastname.equals( t.lastname ) ) return false;

		return true;
	}

	public int hashCode() {
		return 1;
	}
	
    public static boolean equals(Object object1, Object object2) {
        if (object1 == object2) {
            return true;
        }
        if ((object1 == null) || (object2 == null)) {
            return false;
        }
        return object1.equals(object2);
    }

    @Id
	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	@Id
	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}	
}
