//$Id: Footballer.java 11171 2007-02-08 03:40:51Z epbernard $
package org.hibernate.test.annotations.cidcache;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


@Entity
@IdClass(FootballerPk.class)
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE, region="rw")
public class Footballer {
	private String firstname2;
	private String lastname;
	private String club;

	public Footballer() {
	}

	public Footballer(String firstname, String lastname, String club) {
		this.firstname2 = firstname;
		this.lastname = lastname;
		this.club = club;
	}

	public boolean equals(Object o) {
		if ( this == o ) return true;
		if ( !( o instanceof Footballer ) ) return false;

		final Footballer t = (Footballer) o;

		if ( !firstname2.equals( t.firstname2 ) ) return false;
		if ( !lastname.equals( t.lastname ) ) return false;

		return true;
	}

	public int hashCode() {
		return 1;
	}

	@Id
	public String getFirstname2() {
		return firstname2;
	}

	public void setFirstname2(String firstname) {
		this.firstname2 = firstname;
	}

	@Id
	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getClub() {
		return club;
	}

	public void setClub(String club) {
		this.club = club;
	}
}
