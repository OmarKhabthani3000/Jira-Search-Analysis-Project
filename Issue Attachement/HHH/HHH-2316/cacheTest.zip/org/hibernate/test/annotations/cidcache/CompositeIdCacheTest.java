package org.hibernate.test.annotations.cidcache;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.annotations.TestCase;

public class CompositeIdCacheTest extends TestCase {

	public CompositeIdCacheTest(String x) {
		super( x );
	}
	
	public void testCache() throws Exception {
		Session s;
		Transaction tx;
		s = openSession();
		tx = s.beginTransaction();
		
		Footballer f = new Footballer();
		f.setFirstname2( "Bob" );
		f.setLastname( "Baron" );
		f.setClub("club1" );
		s.persist( f );
		
		OrderLine orderLine = new OrderLine();
		orderLine.setFirstname( "Bob" );
		orderLine.setLastname( "Baron" );
		
		
		s.persist(orderLine);

		tx.commit();
		s.close();
	}
	

	protected Class[] getMappings() {
		return new Class[]{
				FootballerPk.class,
				Footballer.class,
                OrderLine.class,
                OrderLinePk.class
        };	}

}
