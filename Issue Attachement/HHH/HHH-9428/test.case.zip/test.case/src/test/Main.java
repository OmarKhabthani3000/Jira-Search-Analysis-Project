package test;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;

public class Main
{
	private static final String CONFIG_FILE = "test/hibernate.cfg.xml";
	
	private SessionFactory createFactory()
	{
		AnnotationConfiguration ac = new AnnotationConfiguration();
		
		ac.configure(CONFIG_FILE);
		
		return ac.buildSessionFactory();
	}
	
	public static void main(String[] args)
	{
		new Main().run();
	}
	
	public void run()
	{
        SessionFactory factory = createFactory();
        
        createInitialData(factory);

        System.out.println("Getting test case ");
        getCollection(factory);
        
        
        
	}


	private void getCollection(SessionFactory factory)
	{
		
		Session session = factory.openSession();
		session.beginTransaction();

		
		Criteria criteria = session.createCriteria(Opportunity.class, "opportunity");
		criteria.createAlias("opportunity.currency", "currency", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("opportunity.totalContractValueSplits", "tcv", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("currency.conversions", "conversions", JoinType.LEFT_OUTER_JOIN, Restrictions.conjunction()
			.add(Restrictions.eqProperty("conversions.localCurrency", "currency.code"))
			.add(Restrictions.eqProperty("conversions.effectiveMonth", "tcv.month"))
		);


				
		criteria.list();
		
		session.getTransaction().commit();
		session.close();
		
	}

    private void createInitialData(SessionFactory factory)
    {
        Session session = factory.openSession();
	    session.beginTransaction();

        session.getTransaction().commit();
        session.close();
    }
    

}
