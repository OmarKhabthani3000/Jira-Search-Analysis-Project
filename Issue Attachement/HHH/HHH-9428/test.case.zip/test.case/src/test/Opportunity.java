package test;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

@Entity
@Table(name = "opportunities")
public class Opportunity  {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	@ManyToOne(cascade = { CascadeType.DETACH })
	private Currency currency;
	

	@OrderBy("month")
	@OneToMany(mappedBy = "opportunityId", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<TotalContractValueSplit> totalContractValueSplits = new ArrayList<TotalContractValueSplit>();


	public Currency getCurrency() {
		return currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public List<TotalContractValueSplit> getTotalContractValueSplits() {
		return totalContractValueSplits;
	}

	public void setTotalContractValueSplits(List<TotalContractValueSplit> totalContractValueSplits) {
		this.totalContractValueSplits = totalContractValueSplits;
	}

}