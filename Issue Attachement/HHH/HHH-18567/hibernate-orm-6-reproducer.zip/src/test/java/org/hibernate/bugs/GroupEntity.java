package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderColumn;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity(name = "GroupEntity")
@Table(name = "GroupEntity")
public class GroupEntity {

    @Id
    @Column(name = "ID", nullable = false, length = 36)
    private String ID;

    @Column(name = "NAME", unique = true, length = 255)
    private String name;

    @OneToMany(targetEntity = GroupEntity.class, fetch = FetchType.LAZY)
    @Cascade(org.hibernate.annotations.CascadeType.PERSIST)
    @Fetch(FetchMode.SELECT)
    @JoinColumn(name = "parentGroup_ID")
    @OrderColumn(name = "position")
    private List<GroupEntity> childGroups;

    @ManyToOne(targetEntity = GroupEntity.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "parentGroup_ID", insertable = false, updatable = false)
    private GroupEntity parentGroup;

    @ManyToMany(targetEntity = ArticleEntity.class, fetch = FetchType.LAZY)
    @Cascade(org.hibernate.annotations.CascadeType.PERSIST)
    @Fetch(FetchMode.SELECT)
    private List<ArticleEntity> articles;

    @Column(name = "SYNC_VERSION")
    private long syncVersion = -1;

    @Version
    private int version;

    public GroupEntity() {
        this.articles = new ArrayList<>();
        this.childGroups = new ArrayList<>();
    }

    public GroupEntity(String name, String id) {
        this();
        this.name = name;
        this.ID = id;
    }

    public void addArticle(ArticleEntity article) {
        article.addGroup(this);
        articles.add(article);
    }

    public void addChildGroup(GroupEntity childGroup) {
        childGroup.setParentGroup(this);
        if (!childGroups.contains(childGroup)) {
            childGroups.add(childGroup);
        }
    }

    public void setParentGroup(GroupEntity parentGroup) {
        this.parentGroup = parentGroup;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof GroupEntity))
            return false;
        GroupEntity that = (GroupEntity) o;
        return Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name);
    }

    public String toString() {
        return String.format("%s ID=%s name=%s", getClass(), ID, name);
    }
}
