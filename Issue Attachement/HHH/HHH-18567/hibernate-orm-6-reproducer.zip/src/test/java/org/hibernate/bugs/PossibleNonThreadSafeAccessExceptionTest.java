package org.hibernate.bugs;

import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Apparently the values of the UUIDs decide whether the failure is reproduced or not.
 * The two test cases in this class are identical, except for the values of the UUIDs.
 */
public class PossibleNonThreadSafeAccessExceptionTest {

    private EntityManagerFactory entityManagerFactory;

    @BeforeEach
    void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @AfterEach
    void destroy() {
        entityManagerFactory.close();
    }

    @Test
    void possibleNonThreadSafeAccessExceptionIsReproduced() {
        try (EntityManager entityManager = entityManagerFactory.createEntityManager()) {
            entityManager.getTransaction().begin();

            GroupEntity secondRootGroup = new GroupEntity("secondRootGroup", "f05ad4f1-404e-46c5-9491-78839f347f3e");
            GroupEntity subGroup = new GroupEntity("subGroup", "3f05f1d8-2089-409b-9fd9-08cb51ea145b");
            secondRootGroup.addChildGroup(subGroup);

            ArticleEntity article1 = new ArticleEntity("article1", "b11d9abf-a926-402e-8649-490c16cef078");
            entityManager.persist(article1);
            ArticleEntity article2 = new ArticleEntity("article2", "35314b48-3e70-41c4-9f3b-5a076d0b87e0");
            entityManager.persist(article2);

            subGroup.addArticle(article1);
            subGroup.addArticle(article2);
            secondRootGroup.addArticle(article2);

            entityManager.persist(secondRootGroup);
            entityManager.getTransaction().commit();

            entityManager.clear();

            performQuery(entityManager);
        }
    }

    @Test
    void possibleNonThreadSafeAccessExceptionIsNotReproduced() {
        try (EntityManager entityManager = entityManagerFactory.createEntityManager()) {
            entityManager.getTransaction().begin();

            GroupEntity secondRootGroup = new GroupEntity("secondRootGroup", "834e1c21-8446-44bc-8232-409c2fc2d8ed");
            GroupEntity subGroup = new GroupEntity("subGroup", "d36736d3-e484-410e-8303-056e04688388");
            secondRootGroup.addChildGroup(subGroup);

            ArticleEntity article1 = new ArticleEntity("article1", "21e7ad53-b706-4fe8-9962-625730254a31");
            entityManager.persist(article1);
            ArticleEntity article2 = new ArticleEntity("article2", "0432181d-f12d-4821-a9e0-043e7914aec5");
            entityManager.persist(article2);

            subGroup.addArticle(article1);
            subGroup.addArticle(article2);
            secondRootGroup.addArticle(article2);

            entityManager.persist(secondRootGroup);
            entityManager.getTransaction().commit();

            entityManager.clear();

            performQuery(entityManager);
        }
    }

    private void performQuery(EntityManager entityManager) {
        // This query fails with a "possible non-threadsafe access to the session" error
        try (ScrollableResults<ArticleEntity> articlesResult = entityManager.unwrap(Session.class)
                .createQuery("select article from "
                        + "ArticleEntity article "
                        + "join fetch article.groups "
                        + "where article.syncVersion >= :indexSyncVersion "
                        + "order by article.syncVersion", ArticleEntity.class)
                .setParameter("indexSyncVersion", -1)
                .scroll(ScrollMode.FORWARD_ONLY)) {
            while (articlesResult.next()) {
                System.out.println("found article: " + articlesResult.get());
            }
        }
    }
}
