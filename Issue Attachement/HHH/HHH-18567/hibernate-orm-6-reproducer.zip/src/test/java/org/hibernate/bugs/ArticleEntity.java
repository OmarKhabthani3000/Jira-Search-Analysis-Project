package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity(name = "ArticleEntity")
@Table(name = "ArticleEntity")
public class ArticleEntity {

    @Id
    @Column(name = "ID", nullable = false, length = 36)
    private String ID;

    @Column(name = "NAME", unique = true, nullable = false, length = 255)
    private String name;

    @ManyToMany(targetEntity = GroupEntity.class, fetch = FetchType.LAZY, mappedBy = "articles")
    @Fetch(FetchMode.SELECT)
    private List<GroupEntity> groups;

    @Column(name = "SYNC_VERSION")
    private long syncVersion = 123;

    @Version
    private int version;

    ArticleEntity() {
        this.groups = new ArrayList<>();
    }

    public ArticleEntity(String name, String id) {
        this();
        this.name = name;
        this.ID = id;
    }

    protected void addGroup(GroupEntity group) {
        groups.add(group);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof ArticleEntity))
            return false;
        ArticleEntity that = (ArticleEntity) o;
        return Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name);
    }

    @Override
    public String toString() {
        return String.format("%s ID=%s NAME=%s", getClass(), ID, name);
    }
}
