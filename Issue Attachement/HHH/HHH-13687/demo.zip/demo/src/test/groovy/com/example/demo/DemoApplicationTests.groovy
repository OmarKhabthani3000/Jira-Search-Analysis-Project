package com.example.demo

import com.example.demo.dao.BookDao
import com.example.demo.domains.Book
import groovy.util.logging.Slf4j
import org.hibernate.Session
import org.hibernate.SessionFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.ContextConfiguration
import org.springframework.transaction.annotation.Transactional
import spock.lang.Specification

@Slf4j
@ContextConfiguration(classes = [DemoConfiguration])
@SpringBootTest
class DemoApplicationTests extends Specification {

  @Autowired
  BookDao bookDao
  @Autowired
  SessionFactory sessionFactory

  @Transactional
  void "test multi tenancy"() {
    when:
    Session session = sessionFactory.currentSession

    Book book = new Book(name: "book1")
    session.save(book)

    then:
    book.id != null
  }
}
