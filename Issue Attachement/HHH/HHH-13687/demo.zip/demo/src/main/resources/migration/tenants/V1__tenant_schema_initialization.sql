create table book(
    id bigint auto_increment,
    name varchar(255)
);