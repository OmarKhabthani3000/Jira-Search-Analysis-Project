package com.example.demo.dao

import com.example.demo.domains.Book
import org.hibernate.SessionFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Repository

@Repository
class BookDao {

  @Autowired
  SessionFactory sessionFactory



}
