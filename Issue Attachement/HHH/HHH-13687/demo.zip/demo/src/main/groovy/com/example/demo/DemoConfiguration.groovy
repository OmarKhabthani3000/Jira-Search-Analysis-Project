package com.example.demo

import com.example.demo.db.CurrentTenant
import com.example.demo.db.SchemaBasedMultiTenantConnectionProvider
import com.example.demo.db.TenantSchemaResolver
import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import org.flywaydb.core.Flyway
import org.hibernate.MultiTenancyStrategy
import org.hibernate.SessionFactory
import org.hibernate.cfg.AvailableSettings
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.ComponentScan
import org.springframework.context.annotation.Configuration
import org.springframework.orm.hibernate5.HibernateTransactionManager
import org.springframework.orm.hibernate5.LocalSessionFactoryBean
import org.springframework.transaction.annotation.EnableTransactionManagement

import javax.sql.DataSource

@Configuration
@ComponentScan("com.example")
@EnableTransactionManagement
@EnableAutoConfiguration(exclude = [
  DataSourceAutoConfiguration,
  DataSourceTransactionManagerAutoConfiguration,
  HibernateJpaAutoConfiguration,
  FlywayAutoConfiguration
])
class DemoConfiguration {

  private final Logger log = LoggerFactory.getLogger(DemoConfiguration)

  @Bean
  DataSource dataSource() {
    log.info("Creating bean: dataSource")
    HikariConfig config = new HikariConfig()
    config.setJdbcUrl("jdbc:h2:mem:test;DB_CLOSE_ON_EXIT=FALSE")
    return new HikariDataSource(config)
  }

  @Bean
  LocalSessionFactoryBean sessionFactory(TenantSchemaResolver tenantSchemaResolver,
                                         SchemaBasedMultiTenantConnectionProvider connectionProvider) {
    log.info("Creating bean: sessionFactory")
    LocalSessionFactoryBean localSessionFactoryBean = new LocalSessionFactoryBean()
    localSessionFactoryBean.setPackagesToScan("com.example.demo.domains")
    localSessionFactoryBean.setMultiTenantConnectionProvider(connectionProvider)
    localSessionFactoryBean.setCurrentTenantIdentifierResolver(tenantSchemaResolver)

    Properties properties = new Properties()
    properties.put(AvailableSettings.MULTI_TENANT, MultiTenancyStrategy.SCHEMA)
    properties.put(AvailableSettings.DIALECT, "org.hibernate.dialect.H2Dialect")
    properties.put(AvailableSettings.SHOW_SQL, true)
    properties.put(AvailableSettings.FORMAT_SQL, false)

    localSessionFactoryBean.setHibernateProperties(properties)
    return localSessionFactoryBean
  }

  @Bean
  HibernateTransactionManager hibernateTransactionManager(SessionFactory sessionFactory) {
    HibernateTransactionManager txManager = new HibernateTransactionManager()
    txManager.setAutodetectDataSource(false)
    txManager.setSessionFactory(sessionFactory)
    return txManager
  }

  @Bean
  Flyway flyway(DataSource dataSource) {
    log.info("Migrating default schema ")
    Flyway flyway = Flyway.configure()
      .locations("/migration/default")
      .dataSource(dataSource)
      .load()
    flyway.migrate()

    Flyway flyway1 = Flyway.configure()
      .locations("/migration/tenants")
      .schemas("tenant1")
      .dataSource(dataSource)
      .load()
    flyway1.migrate()

    // Set current tenant here so it will have been set before the test starts
    CurrentTenant.set("tenant1")
    return flyway
  }
}
