package com.example.demo.db

import groovy.sql.Sql
import groovy.util.logging.Slf4j
import org.hibernate.engine.jdbc.connections.spi.MultiTenantConnectionProvider
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import javax.sql.DataSource
import java.sql.Connection
import java.sql.SQLException

@Slf4j
@Component
class SchemaBasedMultiTenantConnectionProvider implements MultiTenantConnectionProvider {

  @Autowired
  DataSource dataSource

  @Override
  Connection getAnyConnection() throws SQLException {
    log.info("getAnyConnection")
    Connection connection = dataSource.getConnection()
    log.info("getAnyConnection. schemaName={}", connection.getSchema())
    return connection
  }

  @Override
  void releaseAnyConnection(Connection connection) throws SQLException {
    log.info("releaseAnyConnection. schemaName={}", connection.getSchema())
    connection.close()
  }

  @Override
  Connection getConnection(String tenantIdentifier) throws SQLException {
    Connection connection = dataSource.getConnection()
    String currentSchemaName = connection.getSchema()
    log.info("getConnection. currentSchemaName={}, newSchemaName={}", currentSchemaName, tenantIdentifier)
    connection.setSchema(tenantIdentifier)
    return connection
  }

  @Override
  void releaseConnection(String tenantIdentifier, Connection connection) throws SQLException {
    log.info("releaseConnection: {}", tenantIdentifier)
    connection.setSchema(TenantSchemaResolver.DEFAULT_SCHEMA_NAME)
    connection.close()
  }

  @Override
  boolean isUnwrappableAs(Class unwrapType) {
    return false
  }

  @Override
  <T> T unwrap(Class<T> unwrapType) {
    return null
  }

  @Override
  boolean supportsAggressiveRelease() {
    return true
  }

  List<String> resolveSchemaNames() {
    log.debug("Resolve schema names")
    Sql sql = new Sql(dataSource)
    def rows = sql.rows("SELECT schema_name FROM information_schema.schemata WHERE schema_name LIKE 'ec_client%'")
    List<String> schemaNames = rows.collect({ it.schema_name })
    return schemaNames
  }
}

