package com.example.demo.db

import groovy.util.logging.Slf4j

@Slf4j
class CurrentTenant {
  private static ThreadLocal<String> currentTenant = new ThreadLocal<String>()

  static String get() {
    return currentTenant.get()
  }

  static void set(String tenantSchema) {
    String oldTenantSchema = get()
    if (oldTenantSchema != tenantSchema) {
      log.debug("Change current tenant. newValue={}, oldValue={}", tenantSchema, oldTenantSchema)
      currentTenant.set(tenantSchema)
    }
  }

  static void clear() {
    log.debug("Clear current tenant")
    currentTenant.set(null)
  }
}
