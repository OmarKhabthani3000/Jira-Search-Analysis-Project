package com.example.demo.db

import groovy.util.logging.Slf4j
import org.hibernate.context.spi.CurrentTenantIdentifierResolver
import org.springframework.stereotype.Component

@Component
@Slf4j
class TenantSchemaResolver implements CurrentTenantIdentifierResolver {

  static final String DEFAULT_SCHEMA_NAME = "PUBLIC"

  @Override
  String resolveCurrentTenantIdentifier() {
    String tenantIdentifier = CurrentTenant.get()
    if (!tenantIdentifier) {
      tenantIdentifier = DEFAULT_SCHEMA_NAME
    }

    log.info("resolveTenantIdentifier: {}", tenantIdentifier)
    return tenantIdentifier
  }

  @Override
  boolean validateExistingCurrentSessions() {
    log.info("validateExistingCurrentSessions")
    return true
  }
}
