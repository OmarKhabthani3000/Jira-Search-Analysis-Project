package com.example;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "POI")
public class Poi {

    @Id
    public Long id;

    @Column(name = "name")
    public String name;

}
