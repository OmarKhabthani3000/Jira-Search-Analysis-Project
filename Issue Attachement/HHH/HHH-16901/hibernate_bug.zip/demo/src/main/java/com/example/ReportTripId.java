package com.example;

import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import java.io.Serializable;

@Embeddable
public class ReportTripId implements Serializable {

    @ManyToOne
    @JoinColumn(name = "report_id_fk")
    public Report report;

    @ManyToOne
    @JoinColumn(name = "trip_id_fk")
    public Trip trip;

}
