package com.example;

import jakarta.persistence.*;

@Entity
@Table(name = "trip")
public class Trip {

    @Id
    public Long id;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "date", column = @Column(name = "date_position1")),
    })
    @AssociationOverride(name = "poi", joinColumns = @JoinColumn(name = "poi1_id_fk"))
    public Location position1 = new Location();

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "date", column = @Column(name = "date_position2")),
    })
    @AssociationOverride(name = "poi", joinColumns = @JoinColumn(name = "poi2_id_fk"))
    public Location position2 = new Location();
}
