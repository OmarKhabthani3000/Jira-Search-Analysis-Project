package com.example;

import jakarta.persistence.Embeddable;
import jakarta.persistence.ManyToOne;

import java.util.Date;

@Embeddable
public class Location {

    public Date date;

    @ManyToOne
    Poi poi;

}
