package com.example;

import jakarta.persistence.*;

import java.util.List;

import static jakarta.persistence.CascadeType.ALL;

@Entity
@Table(name = "report")
public class Report {

    @Id
    public Long id;

    @OneToMany(mappedBy = "compositeKey.report", cascade = ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    public List<ReportTrip> reportTripList;

}
