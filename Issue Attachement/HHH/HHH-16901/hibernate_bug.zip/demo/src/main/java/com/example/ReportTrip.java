package com.example;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "report_trip")
public class ReportTrip {

    @EmbeddedId
    public ReportTripId compositeKey = new ReportTripId();

    @Column(name = "other")
    public String other;
}
