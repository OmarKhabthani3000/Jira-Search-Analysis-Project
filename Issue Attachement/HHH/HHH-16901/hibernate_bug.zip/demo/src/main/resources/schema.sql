create table poi
(
    id   int primary key,
    name varchar2(255)
);

create table trip
(
    id             int primary key,
    date_position1 timestamp,
    poi1_id_fk     int,
    date_position2 timestamp,
    poi2_id_fk     int
);

create table report
(
    id int primary key
);

create table report_trip
(
    report_id_fk int,
    trip_id_fk   int,
    other        varchar2,
    constraint c2 primary key (report_id_fk, trip_id_fk),
    constraint c3 foreign key (report_id_fk) references report (id),
    constraint c4 foreign key (trip_id_fk) references trip (id)
);