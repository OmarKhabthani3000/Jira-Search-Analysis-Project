package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.jdbc.Sql;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Sql(value = "/data.sql")
class DemoApplicationTests {

    @Autowired
    private ReportRepository repository;

	@Autowired
	private TripRepository tripRepository;

    @Test
    void bug() {
		// Given
		Trip trip = tripRepository.findById(1L).orElseThrow();
		assertThat(trip.position1).isNotNull();
		assertThat(trip.position2).isNotNull();

		// When
		Optional<Report> reportOptional = repository.findById(1L);
        assertThat(reportOptional).isPresent();

        Report report = reportOptional.get();
        assertThat(report.reportTripList.get(0).compositeKey.trip.position1).isNotNull();
        assertThat(report.reportTripList.get(0).compositeKey.trip.position2).isNotNull(); // ko
    }
}
