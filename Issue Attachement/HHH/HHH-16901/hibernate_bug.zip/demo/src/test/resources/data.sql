insert into poi(id, name)
values (1, 'poi1');

insert into trip(id, date_position1, poi1_id_fk, date_position2, poi2_id_fk)
values (1, current_date, 1, current_date, null);

insert into report(id)
values (1);

insert into report_trip(report_id_fk, trip_id_fk, other)
values (1, 1, 'commentary');