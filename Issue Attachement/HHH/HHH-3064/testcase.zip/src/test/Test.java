package test;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Hibernate;
import org.hibernate.cfg.Environment;
import org.hibernate.ejb.HibernatePersistence;

public class Test {
	protected EntityManagerFactory factory;
	
	public static void main(String[] args) {
		new Test().run();
	}
	
	public void run() {
		factory = new HibernatePersistence().createEntityManagerFactory( getConfig() );
		EntityManager em = factory.createEntityManager();
		// step 1: initialize data
		em.getTransaction().begin();

		Parent parent = new Parent();
		parent.setParentNo( 10 );
		em.persist( parent );
		
		Image image = new Image();
		image.setImageNo( 10 );
		image.setName("image1" );
		em.persist( image );
		parent.getImages().add( image );

		em.getTransaction().commit();
		em.close();
		parent = null;
		image = null;
		
		// step 2
		em = factory.createEntityManager();

		em.getTransaction().begin();

		Parent parent2 = em.find( Parent.class, 10 );
		Hibernate.initialize( parent2.getImages());
		em.merge( parent2 );
		
		em.getTransaction().commit();
		em.close();
		
		factory.close();
	}
	
	public Class[] getAnnotatedClasses() {
		return new Class[]{
				Parent.class,
				Image.class
		};
	}
	
	private Properties loadProperties() {
		Properties props = new Properties();
		InputStream stream = Persistence.class.getResourceAsStream( "/hibernate.properties" );
		if ( stream != null ) {
			try {
				props.load( stream );
			}
			catch (Exception e) {
				throw new RuntimeException( "could not load hibernate.properties" );
			}
			finally {
				try {
					stream.close();
				}
				catch (IOException ioe) {
				}
			}
		}
		props.setProperty( Environment.HBM2DDL_AUTO, "create-drop" );
		return props;
	}

	private Map getConfig() {
		Map config = loadProperties();
		ArrayList<Class> classes = new ArrayList<Class>();

		for ( Class clazz : getAnnotatedClasses() ) {
			classes.add( clazz );
		}
		config.put( HibernatePersistence.LOADED_CLASSES, classes );
		return config;
	}
}
