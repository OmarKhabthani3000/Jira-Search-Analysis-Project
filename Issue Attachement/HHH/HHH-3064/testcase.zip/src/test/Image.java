package test;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Image implements Serializable{
	@Id
	private Integer imageNo;

	private String name;

	
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getImageNo() {
		return this.imageNo;
	}

	public void setImageNo(Integer imageNo) {
		this.imageNo = imageNo;
	}
}
