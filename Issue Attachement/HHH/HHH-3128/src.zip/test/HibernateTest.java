package test;

import junit.framework.TestCase;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

/**
 * HibernateTest
 * <p/>
 */
public class HibernateTest extends TestCase {

    public void testSessionFactory() throws Exception {
        Configuration cfg = new Configuration();
        cfg.addResource("Test.hbm.xml");
        cfg.addResource("Item.hbm.xml");
        cfg.setProperty(Environment.DIALECT, "org.hibernate.dialect.Oracle9iDialect");
        cfg.buildSessionFactory();
    }
}
