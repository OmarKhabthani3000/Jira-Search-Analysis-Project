package test;

import java.util.Collection;
import java.util.HashSet;

/**
 * Test
 * <p/>
 */
public class Test {

    private Long id;
    private String name;
    private Collection items = new HashSet();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Collection getItems() { return items; }
    public void setItems(Collection items) { this.items = items; }
}
