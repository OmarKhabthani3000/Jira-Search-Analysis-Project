package ockham.manytomany.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;

import org.hibernate.Hibernate;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@SequenceGenerator(name = "SEQ_GEN", sequenceName = "workspace_id_sequence")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class Workspace extends BaseVersionedEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN")
	@Column(name = "workspace_id")
	private Long id = null;

	@Column(length = 100, nullable = false)
	private String name = null;

	@Column(length = 2048)
	private String description = null;

	@ManyToMany
	@JoinTable(name = "uniteanalyse_item", joinColumns = @JoinColumn(name = "workspace_id", referencedColumnName = "workspace_id"), inverseJoinColumns = @JoinColumn(name = "item_id", referencedColumnName = "item_id"))
	private Set<Item> items = new HashSet<>();

	@Override
	public Long getId() {
		return this.id;
	}

	@Override
	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<Item> getItems() {
		return items;
	}

	public void setItems(Set<Item> items) {
		this.items = items;
	}

	public void removeItem(Item item) {
		if (item == null) {
			throw new IllegalArgumentException("Item cannot be Null");
		}
		items.remove(item);
	}

	public void loadItems() {
		Hibernate.initialize(items);
	}

	@Override
	public String toString() {
		return this.name;
	}

}
