package ockham.manytomany.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import ockham.manytomany.bean.Item;

@Repository
public class ItemDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	@Qualifier("defaultSchema")
	private String defaultSchema;

	public Item find(Long id) {
		return entityManager.find(Item.class, id);
	}

	public List<Item> findAll() {
		Query query = entityManager.createQuery("from Item");
		return query.getResultList();
	}

}
