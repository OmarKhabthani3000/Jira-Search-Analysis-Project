package ockham.manytomany.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@SequenceGenerator(name = "SEQ_GEN", sequenceName = "item_id_sequence")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class Item extends BaseVersionedEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN")
	@Column(name = "item_id")
	private Long id = null;

	@Column(length = 100, nullable = false)
	private String name = null;

	@Column(length = 2048)
	private String description = null;

	@Override
	public Long getId() {
		return id;
	}

	@Override
	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
