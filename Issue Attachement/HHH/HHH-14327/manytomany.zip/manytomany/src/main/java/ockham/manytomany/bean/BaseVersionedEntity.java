package ockham.manytomany.bean;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.Version;

@MappedSuperclass
public abstract class BaseVersionedEntity extends BaseEntity {

	@Version
	@Column(nullable = false)
	private Timestamp version = null;

	@Column(name = "creation", nullable = false)
	private Timestamp dateCreation = null;

	@PrePersist
	protected void beforeCreate() {
		if (dateCreation == null) {
			dateCreation = new Timestamp(System.currentTimeMillis());
		}
	}

	public Timestamp getVersion() {
		return this.version;
	}

	public void setVersion(Timestamp version) {
		this.version = version;
	}

	public Timestamp getDateCreation() {
		return this.dateCreation;
	}

	public void setDateCreation(Timestamp creation) {
		this.dateCreation = creation;
	}

}
