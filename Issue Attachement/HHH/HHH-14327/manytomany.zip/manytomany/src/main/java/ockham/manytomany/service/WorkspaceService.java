package ockham.manytomany.service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ockham.manytomany.bean.Item;
import ockham.manytomany.bean.Workspace;

@Service
public class WorkspaceService {

	private Logger log = LoggerFactory.getLogger(WorkspaceService.class);

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private WorkspaceDAO workspaceDAO;

	@Autowired
	private ItemDAO itemDAO;

	@Transactional
	public Workspace fillWorkspace(String name, String description, int size) {
		Long wsId = workspaceDAO.restoreUniteAnalyse(null, name, description);

		for (int i = 0; i < size; i++) {
			Item item = createItem("item-#" + i);

			Workspace ws = workspaceDAO.find(wsId);
			log.info("item created name:{}, id:{}", item.getName(), item.getId());
			workspaceDAO.addItem(ws, item);
			log.info("item attached {} to the workspace {}", item.getName(), ws.getId());
			entityManager.flush();
			entityManager.clear();

		}

		return workspaceDAO.find(wsId);
	}

	private Item createItem(String name) {
		Item item = new Item();
		item.setName(name);
		entityManager.persist(item);
		entityManager.flush();
		return item;
	}

	@Transactional
	public Item createAndGet(String name) {
		Item item = createItem(name);
		return itemDAO.find(item.getId());
	}

	public Item getItem(Long id) {
		return itemDAO.find(id);
	}
}
