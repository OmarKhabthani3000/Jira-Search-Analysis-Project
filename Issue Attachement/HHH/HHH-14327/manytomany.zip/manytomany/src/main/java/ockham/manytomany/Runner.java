package ockham.manytomany;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import ockham.manytomany.service.WorkspaceService;

public class Runner {

	public static void main(String... args) {

		AbstractApplicationContext context = new AnnotationConfigApplicationContext(ManyToManyConfiguration.class);

		WorkspaceService service = context.getBean(WorkspaceService.class);
		service.fillWorkspace("test", "test", 5000);

		context.registerShutdownHook();
		context.close();

	}
}
