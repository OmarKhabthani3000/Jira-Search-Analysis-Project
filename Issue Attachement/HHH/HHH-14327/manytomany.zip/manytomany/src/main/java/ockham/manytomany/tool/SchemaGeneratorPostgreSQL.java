package ockham.manytomany.tool;

import static java.lang.Boolean.TRUE;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import javax.persistence.Persistence;

import org.hibernate.cfg.AvailableSettings;
import org.hibernate.dialect.PostgreSQL95Dialect;

public class SchemaGeneratorPostgreSQL {

	public static void main(String[] args) throws IOException {
		String persistenceUnitName = args[0];
		String destination = args[1];

		File destFile = new File(destination);
		if (destFile.exists()) {
			destFile.delete();
		}

		final Properties props = new Properties();
		props.setProperty(AvailableSettings.HBM2DDL_AUTO, "");
		props.setProperty(AvailableSettings.HBM2DDL_DATABASE_ACTION, "none");

		props.setProperty(AvailableSettings.HBM2DDL_SCRIPTS_ACTION, "create");
		props.setProperty(AvailableSettings.HBM2DDL_CREATE_SOURCE, "metadata");

		props.setProperty(AvailableSettings.DEFAULT_SCHEMA, "manytomany");
		props.setProperty(AvailableSettings.FORMAT_SQL, TRUE.toString());
		props.setProperty(AvailableSettings.HBM2DDL_DELIMITER, ";");
		props.setProperty(AvailableSettings.USE_SQL_COMMENTS, TRUE.toString());
		props.setProperty(AvailableSettings.DIALECT, PostgreSQL95Dialect.class.getName());
		props.setProperty(AvailableSettings.DRIVER, "org.postgresql.Driver");

		props.setProperty(AvailableSettings.HBM2DDL_SCRIPTS_CREATE_TARGET, destination);
		Persistence.generateSchema(persistenceUnitName, props);
	}
}