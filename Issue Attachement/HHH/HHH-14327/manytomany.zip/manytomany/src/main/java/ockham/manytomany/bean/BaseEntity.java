package ockham.manytomany.bean;

import static java.util.stream.Collectors.groupingBy;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class BaseEntity {

	/**
	 * @return the id
	 */
	public abstract Long getId();

	public abstract void setId(Long id);

	public boolean isNew() {
		return getId() == null;
	}

	@Override
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof BaseEntity)) {
			return false;
		}

		if (!getClass().equals(other.getClass())) {
			return false;
		}

		BaseEntity otherObjetMetier = (BaseEntity) other;

		if (this.getId() == null) {
			return false;
		} else {
			return this.getId().equals(otherObjetMetier.getId());
		}
	}

	@Override
	public int hashCode() {
		return getId() == null ? 0 : getId().intValue();
	}

	public static <V extends BaseEntity> List<Long> toIdList(Collection<V> objects) {
		List<Long> ids = new ArrayList<Long>();
		for (BaseEntity o : objects) {
			ids.add(o.getId());
		}
		return ids;
	}

	public static <V extends BaseEntity> Set<Long> toIdSet(Collection<V> objects) {
		Set<Long> ids = new HashSet<Long>();
		for (BaseEntity o : objects) {
			ids.add(o.getId());
		}
		return ids;
	}

	public static <V extends BaseEntity> List<Long> toIdList(V object) {
		List<Long> ids = new ArrayList<Long>();
		ids.add(object.getId());
		return ids;
	}

	public static <V extends BaseEntity> Map<Long, V> toIdValueMap(Collection<V> objects) {
		if (objects == null) {
			return null;
		}
		Map<Long, V> map = new HashMap<Long, V>();
		for (V o : objects) {
			if (o != null) {
				map.put(o.getId(), o);
			}
		}
		return map;
	}

	public static <K, V extends BaseEntity> Map<K, List<V>> group(Collection<V> objects, Function<V, K> keyProvider) {
		return objects.stream().collect(groupingBy(keyProvider));
	}

}
