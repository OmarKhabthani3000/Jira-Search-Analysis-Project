package ockham.manytomany.tool.cache;

import static java.util.stream.Collectors.toList;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;

import javax.cache.CacheManager;

import org.ehcache.config.Configuration;
import org.ehcache.core.EhcacheManager;
import org.ehcache.core.spi.service.StatisticsService;
import org.ehcache.jsr107.EhcacheCachingProvider;
import org.ehcache.spi.service.Service;
import org.ehcache.spi.service.ServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

/**
 * Use the scale factor (cache.scale.factor from ApplicationProperties) to scale the cache sizes. <br/>
 * Storing single instance of StatisticsService and CacheManager for monitoring purpose (until api makes it available).
 */
public class CustomCachingProvider extends EhcacheCachingProvider {

	private static final Logger logger = LoggerFactory.getLogger(CustomCachingProvider.class);

	private static final int DEFAULT_BASE_CACHE_SIZE = 100;
	private static final int ITEM_BASE_CACHE_SIZE = 50000;
	private static final int WORKSPACE_BASE_CACHE_SIZE = 5000;
	private static final int QUERY_BASE_CACHE_SIZE = 200;
	private static final int TIMESTAMPS_BASE_CACHE_SIZE = 4096;

	private static final String DEFAULT_CACHE_NAME = "default";

	static class CacheSize {
		int baseSize;
		boolean scalable;
		String placeHolderName;

		public CacheSize(int baseSize, boolean scalable, String placeHolderName) {
			this.baseSize = baseSize;
			this.scalable = scalable;
			this.placeHolderName = placeHolderName;
		}
	}

	private static StatisticsService statisticsService;
	private static CacheManager cacheManager;

	private static Map<String, CacheSize> cacheSizeByName;

	private URI configUri;

	static {
		cacheSizeByName = new HashMap<>();

		cacheSizeByName.put("ockham.manytomany.bean.Item",
				new CacheSize(ITEM_BASE_CACHE_SIZE, true, "item.cache.size"));

		cacheSizeByName.put("ockham.manytomany.bean.Workspace",
				new CacheSize(WORKSPACE_BASE_CACHE_SIZE, true, "ws.cache.size"));
		cacheSizeByName.put("default-query-results-region",
				new CacheSize(QUERY_BASE_CACHE_SIZE, true, "query.cache.size"));
		cacheSizeByName.put("default-update-timestamps-region",
				new CacheSize(TIMESTAMPS_BASE_CACHE_SIZE, true, "timestamps.cache.size"));
		cacheSizeByName.put(DEFAULT_CACHE_NAME, new CacheSize(DEFAULT_BASE_CACHE_SIZE, false, "default.cache.size"));
	}

	public static StatisticsService getStatisticsServiceInstance() {
		return statisticsService;
	}

	public static CacheManager getCacheManagerInstance() {
		return cacheManager;
	}

	@Override
	public CacheManager getCacheManager(URI uri, ClassLoader classLoader, Properties properties) {
		return storeStatisticsService(super.getCacheManager(getURI(), classLoader, properties));
	}

	@Override
	public CacheManager getCacheManager(URI uri, Configuration config) {
		return storeStatisticsService(super.getCacheManager(getURI(), config));
	}

	@Override
	public CacheManager getCacheManager(URI uri, Configuration config, Properties properties) {
		return storeStatisticsService(super.getCacheManager(getURI(), config, properties));
	}

	private URI getURI() {
		if (configUri == null) {
			try {
				configUri = initConfig();
			} catch (IOException e) {
				throw new RuntimeException("Cannot init ehcache config", e);
			}
		}
		return configUri;
	}

	private URI initConfig() throws IOException {
		// Read cache scale factor and compute cache size
		double scaleFactor = 1.0;
		logger.info("Initializing caches with cache.scale.factor: {}", scaleFactor);
		Map<String, String> placeHolders = new HashMap<>();
		for (CacheSize cs : cacheSizeByName.values()) {
			placeHolders.put(cs.placeHolderName, Long.toString(getCacheSize(cs, scaleFactor)));
		}
		// Generate ehcache.xml using templated config file
		try (BufferedReader templateReader = new BufferedReader(new InputStreamReader(
				new ClassPathResource("/ehcache.xml.template").getInputStream(), StandardCharsets.UTF_8))) {
			List<String> cfgLines = templateReader.lines() //
					.map(x -> replacePlaceHolder(x, placeHolders)) //
					.collect(toList());
			File file = createTempFile("ehcache", ".xml");
			file.deleteOnExit();
			Files.write(file.toPath(), cfgLines, StandardCharsets.UTF_8);
			return file.toURI();
		}
	}

	public static long getCacheSize(String cacheName) {
		CacheSize cs = cacheSizeByName.get(cacheName);
		if (cs == null) {
			cs = cacheSizeByName.get(DEFAULT_CACHE_NAME);
		}
		return getCacheSize(cacheSizeByName.get(cacheName), 1.0);
	}

	private static long getCacheSize(CacheSize cs, double scaleFactor) {
		if (cs.scalable) {
			return (long) (scaleFactor * cs.baseSize);
		} else {
			return cs.baseSize;
		}
	}

	/**
	 * Temporary hack to expose the cacheManager and the statisticsService that are deeply buried in ehCache API when
	 * using jsr107.
	 */
	private CacheManager storeStatisticsService(CacheManager cm) {
		EhcacheManager ehcacheManager = cm.unwrap(EhcacheManager.class);
		Field field;
		try {
			field = EhcacheManager.class.getDeclaredField("serviceLocator");
		} catch (NoSuchFieldException | SecurityException e) {
			throw new RuntimeException(e);
		}
		field.setAccessible(true);
		ServiceProvider<Service> serviceProvider;
		try {
			serviceProvider = (ServiceProvider<Service>) field.get(ehcacheManager);
		} catch (IllegalArgumentException | IllegalAccessException e) {
			throw new RuntimeException(e);
		}
		statisticsService = serviceProvider.getService(StatisticsService.class);
		cacheManager = cm;
		return cm;
	}

	/**
	 * Replaces in the given string the given placeholder. All strings with %key% will be replaced if the key exists in
	 * the given map
	 * 
	 * @param ori
	 *            the string to replace
	 * @param placeHolders
	 *            the place holders keys and values
	 * @return a new string with the replacement done
	 */
	public static String replacePlaceHolder(String ori, Map<String, ?> placeHolders) {
		String result = ori;
		if (ori.contains("%")) {
			for (String key : placeHolders.keySet()) {
				if (result.contains("%" + key + "%")) {
					Object replacingValue = placeHolders.get(key);
					if (replacingValue == null) {
						replacingValue = "";
					}
					result = result.replaceAll("%" + key + "%", Matcher.quoteReplacement(replacingValue.toString()));
				}
			}
		}
		return result;
	}

	public static File createTempFile(String prefix, String suffix, File directory) throws IOException {
		if (directory != null && !directory.exists()) {
			directory.mkdirs();
		}
		return File.createTempFile(prefix, suffix, directory);
	}

	// wrapping for coherence
	public static File createTempFile(String prefix, String suffix) throws IOException {
		return createTempFile(prefix, suffix, null);
	}

}
