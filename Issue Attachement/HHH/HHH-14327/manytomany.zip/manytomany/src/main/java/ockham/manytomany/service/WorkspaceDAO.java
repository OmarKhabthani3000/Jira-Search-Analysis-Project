package ockham.manytomany.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import ockham.manytomany.bean.Item;
import ockham.manytomany.bean.Workspace;

@Repository
public class WorkspaceDAO {

	@Autowired
	@Qualifier("defaultSchema")
	private String defaultSchema;

	@PersistenceContext
	private EntityManager entityManager;

	public void addItem(Workspace ua, Item r) {
		if (ua == null) {
			throw new IllegalArgumentException("Null workspace.");
		}
		if (r == null) {
			throw new IllegalArgumentException("Null item.");
		}

		ua.getItems().add(r);

	}

	public Workspace find(Long id) {
		return entityManager.find(Workspace.class, id);
	}

	public List<Workspace> findAll() {
		Query query = entityManager.createQuery("from Workspace");
		return query.getResultList();
	}

	public Long restoreUniteAnalyse(Long targetId, String name, String desc) {
		Long result = targetId;
		if (targetId == null) {
			Workspace target = new Workspace();
			target.setName(name);
			target.setDescription(desc);
			entityManager.persist(target);
			entityManager.flush();
			result = target.getId();
		}
		return result;
	}

}
