package ockham.manytomany.tool.cache;

import org.ehcache.event.CacheEvent;
import org.ehcache.event.CacheEventListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CacheEventLogger<K, V> implements CacheEventListener<K, V> {

	private Logger logger = LoggerFactory.getLogger(CacheEventLogger.class);

	@Override
	public void onEvent(CacheEvent<? extends K, ? extends V> event) {
		logger.info("cache event thrown, cache name: {}, type: {}", event.getKey(), event.getType());

	}

}
