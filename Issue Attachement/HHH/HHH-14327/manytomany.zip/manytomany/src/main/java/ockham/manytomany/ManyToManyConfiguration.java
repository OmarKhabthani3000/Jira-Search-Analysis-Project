package ockham.manytomany;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

// Spring configuration for unit tests.
@Configuration
@ComponentScan(basePackages = { //
		"ockham.manytomany", //
})
@ImportResource(locations = { //
		"classpath:/applicationContext-persistence.xml", //
		"classpath:/applicationContext-properties.xml", //
})
public class ManyToManyConfiguration {

	static private void prepareProperties() {

		Properties props = new Properties();
		try (InputStream in = ManyToManyConfiguration.class.getResourceAsStream("/test.properties")) {
			props.load(in);

		} catch (IOException ex) {
			ex.printStackTrace();
		}
		props.forEach((key, value) -> {
			System.setProperty((String) key, (String) value);
		});
	}

	@Bean
	public static PropertyPlaceholderConfigurer getPropertyConfigurer() {
		prepareProperties();
		return new PropertyPlaceholderConfigurer();
	}

}
