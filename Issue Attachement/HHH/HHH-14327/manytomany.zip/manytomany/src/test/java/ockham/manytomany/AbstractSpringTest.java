package ockham.manytomany;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;

public abstract class AbstractSpringTest {

	@Autowired
	protected ApplicationContext context;
	@Autowired
	protected Environment env;

	protected boolean isProfileActive(String... profiles) {
		boolean result = false;
		String[] activesProfiles = env.getActiveProfiles();
		if (activesProfiles != null && profiles != null && profiles.length > 0) {
			result = Arrays.stream(activesProfiles).anyMatch(p -> {
				for (String s : profiles) {
					if (p.equals(s)) {
						return true;
					}
				}
				return false;
			});
		}
		return result;

	}

}
