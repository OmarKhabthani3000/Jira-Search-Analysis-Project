package ockham.manytomany.service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ockham.manytomany.AbstractSpringTest;
import ockham.manytomany.ManyToManyConfiguration;
import ockham.manytomany.bean.Workspace;

@ActiveProfiles("test")
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ManyToManyConfiguration.class })
public class WorkspaceServiceTest extends AbstractSpringTest {

	@Autowired
	private WorkspaceService wokspaceService;

	@Test
	public void testFillWorkspace() {

		Workspace ws = wokspaceService.fillWorkspace("test", "test with 5000 items", 5000);
		Assert.assertNotNull(ws);

	}

}
