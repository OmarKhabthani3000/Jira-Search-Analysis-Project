import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Test
{
	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		SessionFactory sessionFactory  = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		List list = session.getNamedQuery("getFAQCategories").list();
		sessionFactory.close();
		System.out.println("Success!");
	}
}
