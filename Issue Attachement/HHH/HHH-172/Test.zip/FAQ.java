public class FAQ
{
	/** The unique identifier for the FAQ */
	private int id;

	/** The question for the FAQ. */
	private String question;

	/** The user who created the FAQ. */
	private Category category;

	/**
	 * Constructs a default FAQ object.
	 */
	public FAQ()
	{
		this.category = new Category();
	}

	/**
	 * Constructs a full FAQ object with the given values
	 * 
	 * @param id
	 */
	public FAQ(int id)
	{
		this.id = id;
		this.category = new Category();
	}

	/**
	 * @return returns the createdBy.
	 */
	public Category getCategory()
	{
		return this.category;
	}

	/**
	 * @param createdBy
	 *        the createdBy to set.
	 */
	public void setCategory(Category category)
	{
		this.category = category;
	}

	/**
	 * @return returns the id.
	 */
	public int getId()
	{
		return this.id;
	}

	/**
	 * @param id
	 *        the id to set.
	 */
	public void setId(int id)
	{
		this.id = id;
	}

	/**
	 * @return returns the question.
	 */
	public String getQuestion()
	{
		return this.question;
	}

	/**
	 * @param question
	 *        the question to set.
	 */
	public void setQuestion(String question)
	{
		this.question = question;
	}
}