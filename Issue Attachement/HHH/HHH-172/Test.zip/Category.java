public class Category
{
	/** The unique identifier for the <code>User</code>. */
	int id;

	/** The user's domain name for their logon. */
	private String name;

	/**
	 * Creates a new user with no data and empty roles and preferences.
	 */
	public Category()
	{
	}

	/**
	 * Creates a new <code>User</code> that has the given id.
	 * 
	 * @param id
	 *        the unique identifier of the user.
	 */
	public Category(int id)
	{
		this.id = id;
	}

	/**
	 * @return Returns the id.
	 */
	public int getId()
	{
		return this.id;
	}

	/**
	 * @param id
	 *        The id to set.
	 */
	public void setId(int id)
	{
		this.id = id;
	}

	/**
	 * @return Returns the userName.
	 */
	public String getName()
	{
		return this.name;
	}

	/**
	 * @param userName
	 *        The userName to set.
	 */
	public void setName(String name)
	{
		this.name = name;
	}
}