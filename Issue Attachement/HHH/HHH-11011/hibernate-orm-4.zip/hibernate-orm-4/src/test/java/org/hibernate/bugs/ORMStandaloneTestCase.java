package org.hibernate.bugs;

import java.sql.Connection;
import java.sql.SQLException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.jdbc.Work;
import org.hibernate.service.ServiceRegistry;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a standalone test case for
 * Hibernate ORM. Although this is perfectly acceptable as a reproducer, usage
 * of ORMUnitTestCase is preferred!
 */
public class ORMStandaloneTestCase {

    private Configuration cfg;

    private SessionFactory sf;

    @Before
    public void setup() {
        cfg = new Configuration();

        // Add your entities here.
        cfg.addAnnotatedClass(LinkEntity.class);
        // Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
        cfg.setProperty("hibernate.show_sql", "true");
        cfg.setProperty("hibernate.format_sql", "true");
        cfg.setProperty("hibernate.hbm2ddl.auto", "update");

        StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder();
        ServiceRegistry sr = srb.build();
        sf = cfg.buildSessionFactory(sr);

        final Session session = sf.openSession();
        Transaction t = session.beginTransaction();
        session.doWork(new Work() {
            @Override
            public void execute(Connection cnctn) throws SQLException {
                cnctn.createStatement().execute("drop table if exists links");
                cnctn.createStatement().execute("\n"
                        + "create table links (\n"
                        + "    id                    serial primary key,\n"
                        + "    type                  varchar(32) not null default 'generic',    \n"
                        + "    target                varchar(1024) not null,    \n"
                        + "    title                 varchar(512) not null,\n"
                        + "    sort_col             integer not null default 0,\n"
                        + "    icon                  varchar(128),\n"
                        + "    local_image_resource  varchar(128),    \n"
                        + "    \n"
                        + "    CONSTRAINT links_uk UNIQUE (target)\n"
                        + ")\n"
                        + "");
            }
        });
        t.commit();
    }

    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
        
        final Session session = sf.openSession();
        Transaction t = session.beginTransaction();
        for(int i=0;i<10;++i) {
            LinkEntity linkEntity = new LinkEntity("http://hibernate.org" + i, "hibernate");
            session.save(linkEntity);
        }
        t.commit();
    }
}
