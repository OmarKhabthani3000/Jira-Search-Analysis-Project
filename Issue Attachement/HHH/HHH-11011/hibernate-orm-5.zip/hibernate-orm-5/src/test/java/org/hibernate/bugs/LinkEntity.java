/*
 * Copyright 2015-2016 EuregJUG.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author Michael J. Simons, 2015-12-27
 */
@Entity
@Table(name = "links")

public class LinkEntity implements Serializable {

    private static final long serialVersionUID = 2624180625891214911L;

    /**
     * Types of links
     */
    public enum Type {

        generic, profile, sponsor
    }

    /**
     * Primary key of this link.
     */
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "links_id_seq_generator")    
    @SequenceGenerator(name = "links_id_seq_generator", sequenceName = "links_id_seq")    
    private Integer id;

    /**
     * Type of the link.
     */
    @Column(name = "type")
    @Enumerated(EnumType.STRING)
    private Type type = Type.generic;

    /**
     * Target of the link.
     */
    @Column(name = "target", length = 1024, nullable = false, unique = true)
    private String target;

    /**
     * Title of the link.
     */
    @Column(name = "title", length = 512, nullable = false)
    private String title;

    @Column(name = "sort_col", nullable = false)
    private Integer sortCol = 0;

    /**
     * An optional font-awesome or similar icon.
     */
    @Column(name = "icon", length = 128)
    private String icon;

    /**
     * An optional, local image resoure relative to {@code /img}.
     */
    @Column(name = "local_image_resource", length = 128)
    private String localImageResource;

    /**
     * Needed for Hibernate, not to be called by application code.
     */
    @SuppressWarnings({"squid:S2637"})
    protected LinkEntity() {
    }

    public LinkEntity(final String target, final String title) {
        this.target = target;
        this.title = title;
    }

    public Integer getId() {
        return id;
    }

    public Type getType() {
        return type;
    }

    public void setType(final Type type) {
        this.type = type;
    }

    public String getTarget() {
        return target;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(final String title) {
        this.title = title;
    }

    public Integer getSortCol() {
        return sortCol;
    }

    public void setSortCol(final Integer sortCol) {
        this.sortCol = sortCol;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(final String icon) {
        this.icon = icon;
    }

    public String getLocalImageResource() {
        return localImageResource;
    }

    public void setLocalImageResource(final String localImageResource) {
        this.localImageResource = localImageResource;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.target);
        return hash;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final LinkEntity other = (LinkEntity) obj;
        return Objects.equals(this.target, other.target);
    }
}
