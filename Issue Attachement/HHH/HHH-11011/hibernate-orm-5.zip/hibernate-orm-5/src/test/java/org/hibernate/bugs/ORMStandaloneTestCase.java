package org.hibernate.bugs;

import java.sql.Connection;
import java.sql.SQLException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.jdbc.Work;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a standalone test case for
 * Hibernate ORM. Although this is perfectly acceptable as a reproducer, usage
 * of ORMUnitTestCase is preferred!
 */
public class ORMStandaloneTestCase {

    private SessionFactory sf;

    @Before
    public void setup() {
        StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
                // Add in any settings that are specific to your test. See resources/hibernate.properties for the defaults.
                .applySetting("hibernate.show_sql", "true")
                .applySetting("hibernate.format_sql", "true")
                .applySetting("hibernate.hbm2ddl.auto", "none")
                .applySetting("hibernate.id.new_generator_mappings", false)
                ;

        Metadata metadata = new MetadataSources(srb.build())
                // Add your entities here.
                .addAnnotatedClass(LinkEntity.class)
                .buildMetadata();

        sf = metadata.buildSessionFactory();
        final Session session = sf.openSession();
        Transaction t = session.beginTransaction();
        
        session.doWork(cnctn -> {
            cnctn.createStatement().execute("drop table if exists links");
            cnctn.createStatement().execute("\n"
                    + "create table links (\n"
                    + "    id                    serial primary key,\n"
                    + "    type                  varchar(32) not null default 'generic',    \n"
                    + "    target                varchar(1024) not null,    \n"
                    + "    title                 varchar(512) not null,\n"
                    + "    sort_col             integer not null default 0,\n"
                    + "    icon                  varchar(128),\n"
                    + "    local_image_resource  varchar(128),    \n"
                    + "    \n"
                    + "    CONSTRAINT links_uk UNIQUE (target)\n"
                    + ")\n"
                    + "");
        });
        t.commit();
    }

    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
               
        final Session session = sf.openSession();
        Transaction t = session.beginTransaction();
        for(int i=0;i<10;++i) {
            LinkEntity linkEntity = new LinkEntity("http://hibernate.org" + i, "hibernate");
            session.save(linkEntity);
        }
        
        t.commit();
    }
}
