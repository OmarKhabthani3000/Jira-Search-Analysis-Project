package test.dom4j.ie;

import java.io.StringReader;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.hibernate.EntityMode;
import org.hibernate.HibernateException;
import org.hibernate.ReplicationMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class XMLImportSubclassTest extends TestCase {

	private static final Logger logger = Logger.getLogger(XMLImportSubclassTest.class);
	
	static String superClassXML = "<Person><personId>1</personId><races><PersonRace><personRaceId>1</personRaceId><person>1</person><race><id>100</id><descriptor>White</descriptor></race></PersonRace><PersonRace><personRaceId>2</personRaceId><person>1</person><race><id>200</id><descriptor>Hispanic</descriptor></race></PersonRace></races></Person>";
	static String subClassXML   = "<Client><personId>1</personId><races><PersonRace><personRaceId>1</personRaceId><person>1</person><race><id>100</id><descriptor>White</descriptor></race></PersonRace><PersonRace><personRaceId>2</personRaceId><person>1</person><race><id>200</id><descriptor>Hispanic</descriptor></race></PersonRace></races></Client>";

	// Note: This passes with v3.0.3 provided the .addClass(Client.class) remains commented out 
	//       in the getSession1() method.
	public void testImportSuperClass() {

		logger.info("###################### Begin Import");
		Session session = getSession();
		Session dom4JSession = session.getSession(EntityMode.DOM4J);
		Transaction transaction = session.beginTransaction();
		SAXReader reader = new SAXReader();
    	try {
			Document doc = reader.read(new StringReader(superClassXML));
			List results = doc.selectNodes("//Person");
			for (Iterator it = results.iterator(); it.hasNext();) {
				Element person = (Element) it.next();
				logger.debug(person.asXML());				
				dom4JSession.replicate("test.dom4j.ie.Person", person, ReplicationMode.OVERWRITE);
			}
			transaction.commit();
			dom4JSession.close();
		} catch (DocumentException e) {
			logger.fatal("Error reading Document", e);
			fail(e.getLocalizedMessage());
		} catch (HibernateException e) {
			logger.fatal("Hibernate Exception",e);
			fail(e.getLocalizedMessage());
		}
		logger.info("###################### End Import");
	}

	// Note: This fails with v3.0.3.
	public void testImportSubClass() {

		logger.info("###################### Begin Import");
		Session session = getSubclassSession();
		Session dom4JSession = session.getSession(EntityMode.DOM4J);
		Transaction transaction = session.beginTransaction();
		SAXReader reader = new SAXReader();
    	try {
			Document doc = reader.read(new StringReader(subClassXML));
			List results = doc.selectNodes("//Client");
			for (Iterator it = results.iterator(); it.hasNext();) {
				Element person = (Element) it.next();
				logger.debug(person.asXML());				
				dom4JSession.replicate("test.dom4j.ie.Client", person, ReplicationMode.OVERWRITE);
			}
			transaction.commit();
			dom4JSession.close();
		} catch (DocumentException e) {
			logger.fatal("Error reading Document", e);
			fail(e.getLocalizedMessage());
		} catch (HibernateException e) {
			logger.fatal("Hibernate Exception",e);
			fail(e.getLocalizedMessage());
		}
	}
	
	public void tearDown() throws Exception {
		super.tearDown();
	}
	
	protected Session getSession() {

		Configuration cfg = new Configuration()
             .addClass(Person.class)
//             .addClass(Client.class) // Superclass test doesn't work if uncommented.
		     .addClass(Race.class)
		     .addClass(PersonRace.class)
		     .setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver")
		     .setProperty("hibernate.connection.url","jdbc:hsqldb:C:\\hsql\\xmltest")
		     .setProperty("hibernate.dialect","org.hibernate.dialect.HSQLDialect")
		     .setProperty("hibernate.jdbc.batch_size", "0")
		     .setProperty("hibernate.connection.username", "sa")
		     .setProperty("hibernate.connection.password", "")
		     .setProperty("hibernate.connection.autocommit", "false")
		     .setProperty("hibernate.show_sql", "true")  
		     .setProperty("hibernate.hbm2ddl.auto", "create-drop");

		return cfg.buildSessionFactory().openSession();
	}
	
	protected Session getSubclassSession() {

		Configuration cfg = new Configuration()
             .addClass(Person.class)
             .addClass(Client.class)
		     .addClass(Race.class)
		     .addClass(PersonRace.class)
		     .setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver")
		     .setProperty("hibernate.connection.url","jdbc:hsqldb:C:\\hsql\\xmltest")
		     .setProperty("hibernate.dialect","org.hibernate.dialect.HSQLDialect")
		     .setProperty("hibernate.jdbc.batch_size", "0")
		     .setProperty("hibernate.connection.username", "sa")
		     .setProperty("hibernate.connection.password", "")
		     .setProperty("hibernate.connection.autocommit", "false")
		     .setProperty("hibernate.show_sql", "true")  
		     .setProperty("hibernate.hbm2ddl.auto", "create-drop");

		return cfg.buildSessionFactory().openSession();

	}
}
