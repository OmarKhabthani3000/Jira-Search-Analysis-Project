package test.dom4j.ie;

public class Client extends Person {

}
