package com.example.hhh10551;

import com.example.hhh10551.model.MyEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataBuilder;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.SessionFactoryBuilder;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Main implements AutoCloseable
{

    public static void main(final String[] arguments)
    {
        try (final Main main = new Main())
        {
            main.setup();
            main.test();
        }
    }

    public Main()
    {
        final StandardServiceRegistryBuilder registryBuilder = new StandardServiceRegistryBuilder();
        registryBuilder.configure();
        final StandardServiceRegistry registry = registryBuilder.build();
        final MetadataSources metadataSources = new MetadataSources(registry);
        final MetadataBuilder metadataBuilder = metadataSources.getMetadataBuilder();
        final Metadata metadata = metadataBuilder.build();
        final SessionFactoryBuilder sessionFactoryBuilder = metadata.getSessionFactoryBuilder();
        this.sessionFactory = sessionFactoryBuilder.build();
    }

    private final SessionFactory sessionFactory;

    public void setup()
    {
        try (final Session session = sessionFactory.openSession())
        {
            final Transaction transaction = session.beginTransaction();
            final MyEntity entity = new MyEntity();
            entity.setId(1L);
	    entity.setBytes(new byte[1]);
            session.save(entity);
            transaction.commit();
        }
    }

    public void test()
    {
        try (final Session session = sessionFactory.openSession())
        {
            final Transaction transaction = session.beginTransaction();
            final MyEntity entity = session.get(MyEntity.class, 1L);
            transaction.commit();
        } catch (final ClassCastException exception)
        {
            System.err.println("HHH-10551 has been reproduced: ");
            exception.printStackTrace(System.err);
        }
    }

    @Override
    public void close()
    {
        sessionFactory.close();
    }

}
