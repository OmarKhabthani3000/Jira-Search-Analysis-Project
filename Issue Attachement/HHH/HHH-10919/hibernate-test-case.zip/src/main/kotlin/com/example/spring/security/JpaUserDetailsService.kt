package com.example.spring.security

import org.springframework.security.core.GrantedAuthority
import org.springframework.security.core.userdetails.User
import org.springframework.security.core.userdetails.UserDetails
import org.springframework.security.core.userdetails.UserDetailsService
import org.springframework.security.core.userdetails.UsernameNotFoundException

/**
 * @author Sola
 */
open class JpaUserDetailsService<T : UserDetails>(val detailsRepository: UserDetailsRepository<T>) : UserDetailsService {

	override fun loadUserByUsername(username: String): UserDetails {
		return detailsRepository.findByUsername(username)
				?: throw UsernameNotFoundException("User '$username' not found.")
	}

}

interface UserDetailsRepository<T : Any> {
	fun findByUsername(username: String): T?
}

open class JpaUserDetails<T : Any> : User {

	val user: T

	constructor(username: String?,
	            password: String?,
	            authorities: Collection<GrantedAuthority>,
	            user: T)
	: super(username, password, authorities) {
		this.user = user
	}

	constructor(username: String?,
	            password: String?,
	            enabled: Boolean,
	            accountNonExpired: Boolean,
	            credentialsNonExpired: Boolean,
	            accountNonLocked: Boolean,
	            authorities: Collection<GrantedAuthority>,
	            user: T)
	: super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities) {
		this.user = user
	}

}

