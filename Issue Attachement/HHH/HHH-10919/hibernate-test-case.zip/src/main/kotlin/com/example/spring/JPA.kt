package com.example.spring

import com.mchange.v2.c3p0.ComboPooledDataSource
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import javax.sql.DataSource

/**
 * @author Sola
 */
@Configuration
open class C3P0DataSourceConfiguration {

	@Bean
	open fun dataSource(@Value("\${c3p0.config.name}") name: String): DataSource = when {
		name.equals("default") -> ComboPooledDataSource()
		else -> ComboPooledDataSource(name)
	}

}


