package com.example.entity;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Sola
 */
public interface StuffRepository extends JpaRepository<Stuff, Integer> {

	Stuff findByUsername(String username);

	Page<Stuff> findByValid(Boolean valid, Pageable pageable);

	Page<Stuff> findByUsernameContainsAndValid(String key, Boolean valid, Pageable pageable);

}
