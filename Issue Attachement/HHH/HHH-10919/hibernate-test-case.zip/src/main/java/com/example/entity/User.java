package com.example.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.ToString;
import org.hibernate.annotations.DynamicInsert;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.util.List;

/**
 * 用户
 *
 * @author Sola
 */
@Entity
@DynamicInsert
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "users")
@ToString
public class User implements UserDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer id;
	@Column(length = 18, unique = true, nullable = false)
	String username;
	@Column(length = 60, nullable = false, columnDefinition = "binary(60)")
	String password;
	@ManyToMany(fetch = FetchType.EAGER)
	List<Permission> authorities;
	Boolean valid = true;

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return valid;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@JsonIgnore
	@Override
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public List<Permission> getAuthorities() {
		return authorities;
	}

	public void setAuthorities(List<Permission> authorities) {
		this.authorities = authorities;
	}

	public Boolean getValid() {
		return valid;
	}

	public void setValid(Boolean valid) {
		this.valid = valid;
	}

}
