package com.example.entity;

import com.example.spring.security.UserDetailsRepository;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Sola
 */
public interface UserRepository extends JpaRepository<User, Integer>, UserDetailsRepository<User> {

}
