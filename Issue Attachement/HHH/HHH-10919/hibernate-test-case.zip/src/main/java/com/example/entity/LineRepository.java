package com.example.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;

/**
 * @author Sola
 */
public interface LineRepository extends JpaRepository<Line, Integer> {

	@Query("select l from Line l join l.stuffs stfs where ?3 in (key(stfs)) and l.date=?1 and l.shift=?2")
	Line findBySignLog(LocalDate date, Shift shift, Stuff stuff);

}
