package com.example.entity;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Sola
 */
public interface LineTypeRepository extends JpaRepository<LineType, Integer> {

	LineType findByName(String name);

	Page<LineType> findByValid(Boolean valid, Pageable pageable);

	Page<LineType> findByNameContainsAndValid(String key, Boolean valid, Pageable pageable);

}
