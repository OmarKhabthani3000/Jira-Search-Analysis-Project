package com.example.entity;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Sola
 */
public interface ShiftRepository extends JpaRepository<Shift, Integer> {

	Shift findByName(String name);

}
