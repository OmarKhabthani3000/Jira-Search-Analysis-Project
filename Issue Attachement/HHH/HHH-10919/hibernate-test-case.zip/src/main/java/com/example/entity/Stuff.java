package com.example.entity;

import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.DynamicInsert;

import javax.persistence.*;

/**
 * 员工
 *
 * @author Sola
 */
@Entity
@DynamicInsert
@Table(name = "stuffs")
@ToString
@EqualsAndHashCode(callSuper = true)
public class Stuff extends User {

	@Column(unique = true)
	Integer stuffId;
	@Column(length = 11)
	String tel;

	public Integer getStuffId() {
		return stuffId;
	}

	public void setStuffId(Integer stuffId) {
		this.stuffId = stuffId;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

}

