package com.example.entity;

import lombok.ToString;
import org.hibernate.annotations.DynamicInsert;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Map;

/**
 * Line
 *
 * @author Sola
 */
@Entity
@DynamicInsert
@Table(name = "line")
@ToString
public class Line {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer id;
	LocalDate date;
	@ManyToOne(optional = false)
	Shift shift;
	@ManyToOne(optional = false)
	LineType lineType;
	@ManyToOne(optional = false)
	SKU sku;
	Integer produce;
	Integer manHours;
	@ManyToOne(optional = false)
	Leader leader;
	@ElementCollection
	Map<Stuff, WorkLog> stuffs;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public Shift getShift() {
		return shift;
	}

	public void setShift(Shift shift) {
		this.shift = shift;
	}

	public LineType getLineType() {
		return lineType;
	}

	public void setLineType(LineType lineType) {
		this.lineType = lineType;
	}

	public SKU getSku() {
		return sku;
	}

	public void setSku(SKU sku) {
		this.sku = sku;
	}

	public Integer getProduce() {
		return produce;
	}

	public void setProduce(Integer produce) {
		this.produce = produce;
	}

	public Integer getManHours() {
		return manHours;
	}

	public void setManHours(Integer manHours) {
		this.manHours = manHours;
	}

	public Leader getLeader() {
		return leader;
	}

	public void setLeader(Leader leader) {
		this.leader = leader;
	}

	public Map<Stuff, WorkLog> getStuffs() {
		return stuffs;
	}

	public void setStuffs(Map<Stuff, WorkLog> stuffs) {
		this.stuffs = stuffs;
	}

}
