package com.example.entity;

import lombok.ToString;

import javax.persistence.Embeddable;

/**
 * @author Sola
 */
@Embeddable
@ToString
public class WorkLog {

	Integer workTime;
	Boolean overtimed;

	public Integer getWorkTime() {
		return workTime;
	}

	public void setWorkTime(Integer workTime) {
		this.workTime = workTime;
	}

	public Boolean getOvertimed() {
		return overtimed;
	}

	public void setOvertimed(Boolean overtimed) {
		this.overtimed = overtimed;
	}

}
