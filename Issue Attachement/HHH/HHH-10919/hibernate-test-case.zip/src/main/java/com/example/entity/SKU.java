package com.example.entity;

import lombok.ToString;
import org.hibernate.annotations.DynamicInsert;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * SKU
 *
 * @author Sola
 */
@Entity
@DynamicInsert
@Table(name = "sku")
@ToString
public class SKU {

	@Id
	Integer id;
	@Column(precision = 2)
	Float packCost;
	Integer targetCases;
	Integer targetStuff;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Float getPackCost() {
		return packCost;
	}

	public void setPackCost(Float packCost) {
		this.packCost = packCost;
	}

	public Integer getTargetCases() {
		return targetCases;
	}

	public void setTargetCases(Integer targetCases) {
		this.targetCases = targetCases;
	}

	public Integer getTargetStuff() {
		return targetStuff;
	}

	public void setTargetStuff(Integer targetStuff) {
		this.targetStuff = targetStuff;
	}

}
