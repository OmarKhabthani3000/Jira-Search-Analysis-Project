package com.example.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Collection;
import java.util.List;

/**
 * @author Sola
 */
public interface PermissionRepository extends JpaRepository<Permission, Integer> {

	Permission findByAuthority(String name);

	@Query("select p from Permission p where p.id in ?1")
	List<Permission> findByIdIn(Collection<Integer> ids);

}