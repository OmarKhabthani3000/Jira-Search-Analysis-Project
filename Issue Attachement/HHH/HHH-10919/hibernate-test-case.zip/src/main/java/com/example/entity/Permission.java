package com.example.entity;

import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.DynamicInsert;
import org.springframework.security.core.GrantedAuthority;

import javax.persistence.*;

/**
 * 权限
 *
 * @author Sola
 */
@Entity
@DynamicInsert
@Table(name = "permission")
@ToString
@EqualsAndHashCode(of = "authority")
public class Permission implements GrantedAuthority {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer id;
	@Column(length = 20, unique = true)
	String authority;

	public Permission() {
	}

	public Permission(Integer id) {
		this.id = id;
	}

	public Permission(String authority) {
		this.authority = authority;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public String getAuthority() {
		return authority;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

}
