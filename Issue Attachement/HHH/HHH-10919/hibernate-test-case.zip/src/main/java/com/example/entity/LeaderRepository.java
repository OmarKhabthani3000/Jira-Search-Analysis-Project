package com.example.entity;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Sola
 */
public interface LeaderRepository extends JpaRepository<Leader, Integer> {

	Leader findByName(String name);

	Page<Leader> findByValid(Boolean valid, Pageable pageable);

	Page<Leader> findByNameContainsAndValid(String key, Boolean valid, Pageable pageable);

}
