package com.example.entity;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 * @author Sola
 */
public interface SkuRepository extends JpaRepository<SKU, Integer> {

	@Query("select sku from SKU sku where str(sku.id) like %?1%")
	Page<SKU> findByIdContaining(String key, Pageable pageable);

	@Query("select sku from SKU sku where sku.packCost is null or sku.targetCases is null or sku.targetStuff is null")
	Page<SKU> findUnfinished(Pageable pageable);

}
