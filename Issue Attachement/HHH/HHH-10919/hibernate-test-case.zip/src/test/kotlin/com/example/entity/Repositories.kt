package com.example.entity

import com.example.ApplicationTests
import org.junit.Test
import org.springframework.beans.factory.annotation.Autowired
import java.time.LocalDate

/**
 * @author Sola
 */

open class LineRepositoryTest : ApplicationTests() {

	@Autowired open lateinit var lineRepo: LineRepository
	@Autowired open lateinit var shiftRepo: ShiftRepository
	@Autowired open lateinit var stuffRepo: StuffRepository

	@Test
	fun testFindBySignLog() {
		val shift = shiftRepo.findByName("1")
		val stuff = stuffRepo.findByUsername("wushunxin")
		println(
				lineRepo.findBySignLog(
						LocalDate.of(2016, 6, 6),
						shift, stuff)
		)
	}
}