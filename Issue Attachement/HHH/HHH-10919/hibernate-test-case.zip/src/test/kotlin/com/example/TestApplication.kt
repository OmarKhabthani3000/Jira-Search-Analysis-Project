package com.example

import org.springframework.boot.SpringApplication

/**
 * @author Sola
 */
open class TestApplication : Application()

fun main(args: Array<String>) {
	SpringApplication.run(TestApplication::class.java, *args)
}