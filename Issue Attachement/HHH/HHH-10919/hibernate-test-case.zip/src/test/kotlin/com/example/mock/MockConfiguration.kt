package com.example.mock

import com.example.entity.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Configuration
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import java.time.LocalDate
import java.time.LocalTime
import javax.annotation.PostConstruct

/**
 * @author Sola
 */
@Configuration
open class MockConfiguration {

	var passwordEncoder = BCryptPasswordEncoder()
	@Autowired open lateinit var permissionRepository: PermissionRepository
	@Autowired open lateinit var userRepository: UserRepository
	@Autowired open lateinit var stuffRepository: StuffRepository
	@Autowired open lateinit var leaderRepo: LeaderRepository
	@Autowired open lateinit var shiftRepo: ShiftRepository
	@Autowired open lateinit var lineTypeRepo: LineTypeRepository
	@Autowired open lateinit var skuRepo: SkuRepository
	@Autowired open lateinit var stuffRepo: StuffRepository
	@Autowired open lateinit var lineRepo: LineRepository

	@PostConstruct
	open fun init() {
		mockPermission()
		mockUser()
		mockStuff()
		mockLeader()
		mockShift()
		mockLineType()
		mockSKU()
		mockLine()
	}

	fun mockPermission() {
		permissionRepository.save(Permission("ROLE_ADMIN"))
		permissionRepository.save(Permission("ROLE_STUFF"))
		permissionRepository.save(Permission("ROLE_USER"))
		permissionRepository.save(Permission("sku_edit_price"))
		permissionRepository.save(Permission("sku_edit_target"))
	}

	fun mockUser() {
		val allPermissions = permissionRepository.findAll()
		val userPermissions = listOf(permissionRepository.findByAuthority("ROLE_USER"))
		userRepository.save(User().apply {
			username = "sola"
			password = passwordEncoder.encode("test")
			authorities = allPermissions
		})
		userRepository.save(User().apply {
			username = "dayuege"
			password = passwordEncoder.encode("test")
			authorities = userPermissions
		})
	}

	fun mockStuff() {
		val stuffRole = permissionRepository.findByAuthority("ROLE_STUFF")
		stuffRepository.save(Stuff().apply {
			username = "wushunxin"
			password = passwordEncoder.encode("shit")
			authorities = listOf(stuffRole)
			valid = true
			stuffId = 213
			tel = "13838838438"
		})
		stuffRepository.save(Stuff().apply {
			username = "yujianping"
			password = passwordEncoder.encode("shit")
			authorities = listOf(stuffRole)
			valid = false
			stuffId = 223
			tel = "13838838438"
		})
	}

	fun mockLeader() {
		leaderRepo.save(Leader("Java"))
		leaderRepo.save(Leader("JavaScript"))
		leaderRepo.save(Leader("Python"))
		leaderRepo.save(Leader("Groovy"))
		leaderRepo.save(Leader("Ruby"))
	}

	fun mockShift() {
		shiftRepo.save(Shift().apply {
			id = 1
			name = "1"
			start = LocalTime.of(7, 50)
			end = LocalTime.of(11, 50)
		})
		shiftRepo.save(Shift().apply {
			id = 2
			name = "2"
			start = LocalTime.of(15, 50)
			end = LocalTime.of(17, 50)
		})
	}

	fun mockLineType() {
		lineTypeRepo.save(LineType().apply { name = "A" })
		lineTypeRepo.save(LineType().apply { name = "B" })
		lineTypeRepo.save(LineType().apply { name = "C" })
		lineTypeRepo.save(LineType().apply { name = "D" })
		lineTypeRepo.save(LineType().apply { name = "H" })
		lineTypeRepo.save(LineType().apply { name = "P" })
		lineTypeRepo.save(LineType().apply { name = "Q" })
		lineTypeRepo.save(LineType().apply { name = "FH1" })
	}

	fun mockSKU() {
		skuRepo.save(SKU().apply {
			id = 1234567
			packCost = 233.33F
			targetCases = 10
			targetStuff = 2
		})
		skuRepo.save(SKU().apply {
			id = 7654321
		})
		skuRepo.save(SKU().apply {
			id = 7654123
			packCost = 321.123F
		})
		skuRepo.save(SKU().apply {
			id = 4567321
			targetCases = 10000
			targetStuff = 5
		})
	}

	fun mockLine() {
		val shift = shiftRepo.findByName("1")
		val lineType = lineTypeRepo.findByName("Q")
		val sku = skuRepo.findOne(1234567)
		val stuff = stuffRepo.findByUsername("wushunxin")
		val leader = leaderRepo.findByName("Python")
		lineRepo.save(Line().apply {
			date = LocalDate.of(2016, 6, 6)
			this.shift = shift
			this.lineType = lineType
			this.sku = sku
			this.stuffs = mapOf(stuff to WorkLog().apply {
				overtimed = false
			})
			this.leader = leader
			produce = 6
			manHours = 2
		})
	}

}