package test;

import model.Component;
import model.Main;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Expression;
import org.hibernate.type.Type;

import java.util.Iterator;
import java.util.List;

public class BugTest {
    private static SessionFactory sessionFactory = new Configuration().configure("hibernate.test.xml").buildSessionFactory();
    private static Log log = LogFactory.getLog(BugTest.class);

    public static void main(String[] args) throws Exception {
        log.debug("--> Begin test!");
        log.debug("--> Expected result: ");
        BugTest.testExpectedResult();

        log.debug("--> Bug result:");
        BugTest.testBugResult();

        log.debug("--> End test!");
    }

    /**
     * The bug occures in Expression.in(...)
     * <p/>
     * The query-criteria yield no result.
     */
    public static void testBugResult() {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        Component[] components = new Component[]{new Component(new Long(9998), "02"), new Component(new Long(9996), "04")};
        List list = session.createCriteria(Main.class)
                .add(Expression.in("component", components))
                .list();

        log.debug("--> BugResult list " + list.size());
        for (Iterator iterator = list.iterator(); iterator.hasNext();) {
            Main o = (Main) iterator.next();
            log.debug("--> - " + o);
        }

        tx.commit();
        session.flush();
        session.close();
    }

    /**
     * The Expectet result is found using an Expression.sql(...)
     * <p/>
     * The query-criteria yields expected result.
     */
    public static void testExpectedResult() {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        Object[] paramters = new Object[4];
        Type[] types = new Type[4];

        paramters[0] = new Long(9998);
        types[0] = Hibernate.LONG;
        paramters[1] = "02";
        types[1] = Hibernate.STRING;
        paramters[2] = new Long(9996);
        types[2] = Hibernate.LONG;
        paramters[3] = "04";
        types[3] = Hibernate.STRING;

        List list = session.createCriteria(Main.class)
                .add(Expression.sql("(this_.longValue, this_.stringValue) in ( (?,?), (?,?) )", paramters, types))
                .list();

        log.debug("--> ExpectedResult list " + list.size());
        for (Iterator iterator = list.iterator(); iterator.hasNext();) {
            Main o = (Main) iterator.next();
            log.debug("--> - " + o);
        }

        tx.commit();
        session.flush();
        session.close();
    }
}
