package model;

public class Component {
    private Long longValue;
    private String stringValue;

    public Component() {
    }

    public Component(Long longValue, String stringValue) {
        this.longValue = longValue;
        this.stringValue = stringValue;
    }

    public Long getLongValue() {
        return longValue;
    }

    public void setLongValue(Long longValue) {
        this.longValue = longValue;
    }

    public String getStringValue() {
        return stringValue;
    }

    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Component)) return false;

        final Component component = (Component) o;

        if (longValue != null ? !longValue.equals(component.longValue) : component.longValue != null) return false;
        if (stringValue != null ? !stringValue.equals(component.stringValue) : component.stringValue != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (longValue != null ? longValue.hashCode() : 0);
        result = 29 * result + (stringValue != null ? stringValue.hashCode() : 0);
        return result;
    }

    public String toString() {
        return "Component{" +
                "longValue=" + longValue +
                ", stringValue='" + stringValue + "'" +
                "}";
    }
}
