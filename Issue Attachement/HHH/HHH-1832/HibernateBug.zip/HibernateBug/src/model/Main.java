package model;

import java.io.Serializable;

public class Main implements Serializable {
    private long id;
    private Component component;
    private String other;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Component getComponent() {
        return component;
    }

    public void setComponent(Component component) {
        this.component = component;
    }

    public String getOther() {
        return other;
    }

    public void setOther(String other) {
        this.other = other;
    }

    public String toString() {
        return "Main{" +
                "id=" + id +
                ", component=" + component +
                ", other='" + other + "'" +
                "}";
    }
}
