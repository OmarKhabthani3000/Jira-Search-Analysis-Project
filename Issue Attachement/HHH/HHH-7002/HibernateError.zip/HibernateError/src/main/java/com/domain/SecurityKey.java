package com.domain;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity
@Table(name = "SECURITY_KEY")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class SecurityKey
{

    
    //~ Static attributes/initializers -------------------------------------------------------------

    /** manually assigned serial version number */
    private static final long serialVersionUID = 1L;


    //~ Domain Property Instance Variables ------------------------------------------------------------------------------

    @SequenceGenerator(name = "common_seq", sequenceName = "common_seq")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "common_seq")
    @Id
    @Column(name = "ID")
    @Basic
    protected Long id;

    @Basic(optional = false)
    @Column(name = "VAL", length = 4000)
    private String value;
    
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "DEVICE_ID")
    private Device device;

   
    //~ Other Methods ------------------------------------------------------------------------------
    //  (Code in this section manually editable, preserved during code generation)




    //~ Domain Property Methods --------------------------------------------------------------------
    //  (Code in this section auto generated from annotations. Do not edit manually)


    /**
     * Getter for id field
     * @return Returns the id.
     */
    public Long getId()
    {
        return this.id;
    }

    /**
     * Setter for the id field
     * @param aId The id to set.
     */
    public void setId(Long aId)
    {
        this.id = aId;
    }

    //
    //*** value
    //

    /**
     * Returns the value.
     * @return the value.
     */
    public String getValue()
    {
        return this.value;
    }

    /**
     * Sets the value.
     * @param aValue The value to set.
     */
    public void setValue(String aValue)
    {
        this.value = aValue;
    }


    //
    //*** device
    //

    public Device getMedicalDevice()
    {
        return this.device;
    }

    public void setDevice(Device aDevice)
    {
        this.device = aDevice;
    }


    /**
     * Returns the string representing this object.
     * @return the string representing this object.
     */
    @Override
    public String toString()
    {
        return String.format("%s[@%s]: id=%d, value=%s", this.getClass().getSimpleName(), this.hashCode(), getId(), getValue()); 
    }


    /**
     * Default constructor 
     */
    public SecurityKey()
    {
        // implicit call to super constructor
    }
}

// END OF FILE