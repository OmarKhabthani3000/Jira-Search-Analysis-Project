package com.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.OptimisticLock;
import org.hibernate.annotations.Type;



@Entity
@Table(name = "DEVICE")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Device 
{
    //~ Static attributes/initializers -------------------------------------------------------------

    /** manually assigned serial version number */
    private static final long serialVersionUID = 1L;

    //~ Domain Property Instance Variables ------------------------------------------------------------------------------

    @SequenceGenerator(name = "common_seq", sequenceName = "common_seq")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "common_seq")
    @Id
    @Column(name = "ID")
    @Basic
    protected Long id;

    @Basic(optional = false)
    @Column(name = "SERIAL_NBR")
    private String serialNumber;

    @Basic(optional = false)
    @Column(name = "USED_FLAG")
    @Type(type = "yes_no")
    private Boolean used = Boolean.FALSE;
    
    @Basic
    @Column(name = "END_DATE")
    private Date endDate;

    @OneToMany(mappedBy = "device")
    @OptimisticLock (excluded = true)
    private List<SecurityKey> securityKeys;

    //~ Other Methods ------------------------------------------------------------------------------

    /**
     * Getter for id field
     * @return Returns the id.
     */
    public Long getId()
    {
        return this.id;
    }
    
    /**
     * Getter for serialNumber field
     * @return Returns the serialNumber.
     */
    public String getSerialNumber()
    {
        return this.serialNumber;
    }
    
    /**
     * Getter for endDate field
     * @return Returns the endDate.
     */
    public Date getEndDate()
    {
        return this.endDate;
    }
    
    /**
     * Getter for used field
     * @return Returns the used.
     */
    public Boolean getUsed()
    {
        return this.used;
    }
    
    /**
     * Setter for the id field
     * @param aId The id to set.
     */
    public void setId(Long aId)
    {
        this.id = aId;
    }
    
    /**
     * Setter for the endDate field
     * @param aEndDate The endDate to set.
     */
    public void setEndDate(Date aEndDate)
    {
        this.endDate = aEndDate;
    }
    
    /**
     * Setter for the serialNumber field
     * @param aSerialNumber The serialNumber to set.
     */
    public void setSerialNumber(String aSerialNumber)
    {
        this.serialNumber = aSerialNumber;
    }
    
    /**
     * Setter for the used field
     * @param aUsed The used to set.
     */
    public void setUsed(Boolean aUsed)
    {
        this.used = aUsed;
    }


    //
    //*** securityKeys
    //

    /**
     * Returns an unmodifiable List(SecurityKey).
     * This is a bidirectional relationship managed by its owner SecurityKey.medicalDevice.
     * @return an unmodifiable List(SecurityKey).
     */
    public List<SecurityKey> getSecurityKeys()
    {
        return Collections.unmodifiableList(getSecurityKeys_());
    }

    /**
     * Returns the trusted securityKeys.
     * @return the trusted securityKeys.
     */
    protected List<SecurityKey> getSecurityKeys_()
    {
        if (this.securityKeys == null)
        {
            this.securityKeys = new ArrayList<SecurityKey>();
        }
        return this.securityKeys;
    }

    /**
     * Sets the trusted securityKeys.
     * @param aSecurityKeys The trusted securityKeys to set.
     */
    protected void setSecurityKeys_(List<SecurityKey> aSecurityKeys)
    {
        //Do nothing.
    }

    /**
     * Returns the string representing this object.
     * @return the string representing this object.
     */
    @Override
    public String toString()
    {
        return String.format("%s[@%s]: id=%d, serial=%s, used=%s, endDate=%s", this.getClass().getSimpleName(), this.hashCode(), getId(), getSerialNumber(), getUsed(), getEndDate()); 
    }


    /**
     * Default constructor 
     */
    public Device()
    {
        // implicit call to super constructor
    }

}

// END OF FILE