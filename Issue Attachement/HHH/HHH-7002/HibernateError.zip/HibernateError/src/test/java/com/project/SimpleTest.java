package com.project;


import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class SimpleTest
{
    /** Logger */
    private static final Logger LOGGER = Logger.getLogger(SimpleTest.class);
    
    /** domain transaction helper */
    @Autowired
    protected TxnHelper txnConHelper;
    
    @Autowired
    protected BasicDataSource dataSource;
    
    /**
     */
    @Test
    public void testTransactionInterceptor()
    {
        try
        {
            LOGGER.info("============================================================================================================");
            logDataSourceStats();

            long dev0 = this.txnConHelper.makeDevice();
            logDataSourceStats();
            LOGGER.info(">>> Created Device with ID=" + dev0);

            LOGGER.info(">>> Found Device with ID=" + dev0 + "; " + this.txnConHelper.findById(dev0));
            logDataSourceStats();

            long dev1 = this.txnConHelper.makeDevice();
            logDataSourceStats();
            LOGGER.info(">>> Created Device with ID=" + dev1);
            LOGGER.info(">>> Found Device with ID=" + dev1 + "; " + this.txnConHelper.findById(dev1));
            logDataSourceStats();


            LOGGER.info("============================================================================================================");
        
        }
        catch (RuntimeException e) 
        {
            LOGGER.error("Exception caught: ", e);
            throw e;
        }
    }
    
    /**
     * 
     */
    protected void logDataSourceStats()
    {
        LOGGER.info(String.format(">>>>> DataSource: active/max %d/%d; idle=%d", dataSource.getNumActive(), dataSource.getMaxActive(), dataSource.getNumIdle()));
    }
    
}
