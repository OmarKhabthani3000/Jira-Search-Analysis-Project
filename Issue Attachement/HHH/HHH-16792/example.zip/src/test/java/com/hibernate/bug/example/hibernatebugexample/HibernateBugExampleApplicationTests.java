package com.hibernate.bug.example.hibernatebugexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateBugExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
