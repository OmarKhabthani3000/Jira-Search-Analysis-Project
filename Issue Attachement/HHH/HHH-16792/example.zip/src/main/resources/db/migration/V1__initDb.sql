CREATE TABLE IF NOT EXISTS "Users"
(
    "id"               UUID         NOT NULL,
    "name"             varchar(50)  NOT NULL,
    PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "Patients"
(
    "id"               UUID         NOT NULL,
    "weight"           INTEGER      NOT NULL,
    PRIMARY KEY ("id"),
    FOREIGN KEY ("id") REFERENCES "Users" ("id")
);

insert into "Users" ("id", "name")
values('4202c1f5-6963-4632-8472-d20132bf5eb1', 'patient1');

insert into "Patients" ("id", "weight")
values('4202c1f5-6963-4632-8472-d20132bf5eb1', 65);