package com.hibernate.bug.example.hibernatebugexample;

import com.hibernate.bug.example.hibernatebugexample.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernateBugExampleApplication {

	@Autowired
	private PatientService patientService;

	public static void main(String[] args) {
		SpringApplication.run(HibernateBugExampleApplication.class, args);
	}

}
