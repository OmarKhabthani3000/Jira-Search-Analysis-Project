package com.hibernate.bug.example.hibernatebugexample.dal;

import com.hibernate.bug.example.hibernatebugexample.dal.model.PatientEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface IPatientDal extends CrudRepository<PatientEntity, UUID> {
}
