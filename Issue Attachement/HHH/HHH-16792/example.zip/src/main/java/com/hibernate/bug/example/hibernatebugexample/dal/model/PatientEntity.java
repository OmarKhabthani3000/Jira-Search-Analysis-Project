package com.hibernate.bug.example.hibernatebugexample.dal.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import java.util.UUID;

@Entity
@Table(name = "Patients")
public class PatientEntity extends UserEntity {
    @Column
    private int weight;

    public PatientEntity(UUID id, String name, int weight) {
        super(id, name);
        this.weight = weight;
    }

    public PatientEntity() {
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
}
