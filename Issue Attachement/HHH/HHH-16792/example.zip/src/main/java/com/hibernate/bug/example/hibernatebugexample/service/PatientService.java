package com.hibernate.bug.example.hibernatebugexample.service;

import com.hibernate.bug.example.hibernatebugexample.dal.model.PatientEntity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaUpdate;
import jakarta.persistence.criteria.Root;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class PatientService {
    @PersistenceContext
    private EntityManager entityManager;

    @Transactional
    public void updatePatient() {

        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaUpdate<PatientEntity> update = criteriaBuilder.createCriteriaUpdate(PatientEntity.class);
        Root<PatientEntity> entityRoot = update.from(PatientEntity.class);
        update.set(entityRoot.get("weight"), 100);
        update.where(criteriaBuilder.equal(entityRoot.get("name"), "patient1"));

        entityManager.createQuery(update).executeUpdate();
    }
}
