CREATE TABLE A
(
  fk1_id numeric(6) NOT NULL,
  fk2_id numeric(6) NOT NULL,
  property numeric(6) NOT NULL
); 

CREATE TABLE B
(
  fk1_id numeric(6) NOT NULL,
  fk2_id numeric(6) NOT NULL
);

CREATE TABLE C
(
  id numeric(6) NOT NULL
);

insert into A( fk1_id, fk2_id, property ) values( 1, 2, 0 );
insert into A( fk1_id, fk2_id, property ) values( 1, 3, 1 );

insert into B( fk1_id, fk2_id) values( 1, 1 );

insert into C(id) values(1);