/*
 * Created on 2005-03-28
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pzl.copier.test;

import java.io.FileInputStream;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.hibernate.EntityMode;
import org.hibernate.ReplicationMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * @author Mickek
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class HH282Test {

	public static void main(String[] args) {
		
		SAXReader xmlReader = new SAXReader();
	    Document dictionaries = null;
	    
		Configuration cfg = new Configuration();
		cfg.configure("pzl/copier/test/import.cfg.xml");
		cfg.setProperty("hibernate.show_sql", "true");		
		SessionFactory sessions = cfg.buildSessionFactory();
		
		Session session = sessions.openSession();
		Session dom4jSession = session.getSession( EntityMode.DOM4J );
	    
	    try {
	    	
	    	FileInputStream zis = new  FileInputStream("HH282.xml");	    	
			dictionaries = xmlReader.read(zis);
			zis.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Transaction tx = dom4jSession.beginTransaction();
		
		try {
			
			List<Element> dictList = dictionaries.getRootElement().elements();

			for( Element cc : dictList ){
				
				List<Element> elementsToImport = (List<Element>)cc.elements();

				String entityName = cc.getName();
				
				System.err.println( "Importing: " + entityName );			
				for( Element item : elementsToImport )
					dom4jSession.replicate(entityName, item, ReplicationMode.OVERWRITE);
				
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		try {
			List<Element> foo = dom4jSession.createQuery("from B").list();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		tx.commit();
		

		
	}		
		
}
