package org.hibernate.test;

import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.stat.SecondLevelCacheStatistics;

public class HibernateBulkTest extends TestCase {

    public void testCacheInteraction() {
        final long settingsId = 1;
        final SessionFactory sessionFactory = new Configuration()
                .configure("org/hibernate/test/hibernate.cfg.xml").buildSessionFactory();
        try {
            Session session = sessionFactory.openSession();;

            SecondLevelCacheStatistics settingsStatistics =
                    sessionFactory.getStatistics().getSecondLevelCacheStatistics(
                            Settings.class.getCanonicalName());
            assertEquals(0, settingsStatistics.getMissCount());
            assertEquals(0, settingsStatistics.getHitCount());

            // fill cache
            Transaction tx = session.beginTransaction();
            session.get(Settings.class, settingsId);
            assertEquals(1, settingsStatistics.getMissCount());
            assertEquals(0, settingsStatistics.getHitCount());
            tx.rollback();
            session.close();

            // do executeUpdate
            session = sessionFactory.openSession();
            tx = session.beginTransaction();
            Query query = session.createQuery(
                    "update Settings m set m.SizeLimit = ? where m.id = ?");
            query.setLong(0, 100000L);
            query.setLong(1, -1L);
            query.executeUpdate();
            tx.rollback();
            session.close();

            // data is not in cache anymore
            session = sessionFactory.openSession();
            tx = session.beginTransaction();
            session.get(Settings.class, settingsId);
            assertEquals(1, settingsStatistics.getMissCount());
            assertEquals(1, settingsStatistics.getHitCount());

            tx.rollback();
            session.close();
        } finally {
            sessionFactory.close();
        }
    }

}
