package org.hibernate.test;

public class Settings {

    Long id;
    Long sizeLimit;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getSizeLimit() {
        return sizeLimit;
    }
    public void setSizeLimit(Long sizeLimit) {
        this.sizeLimit = sizeLimit;
    }

}
