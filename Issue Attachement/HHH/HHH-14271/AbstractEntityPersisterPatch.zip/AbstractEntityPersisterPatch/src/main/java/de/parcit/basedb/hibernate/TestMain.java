package de.parcit.basedb.hibernate;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class TestMain {

	public static void main(String[] args) {
		try {
			Configuration cfg = new Configuration().configure();

			String templateHbm = readTemplateHbm();

			// copy the template using different entity-names to save me the trouble of duplication the class
			for (int i = 0; i < 1000; i++)
				cfg.addInputStream(readAndReplace(templateHbm, i));

			SessionFactory sessionFactory = cfg.buildSessionFactory();
			System.out.println("SessionFactory created");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String readTemplateHbm() throws IOException {
		String filename = "src/main/java/de/parcit/basedb/hibernate/Account.hbm.xml";
		Path path = Paths.get(filename);
		return new String(Files.readAllBytes(path), StandardCharsets.ISO_8859_1);
	}

	public static InputStream readAndReplace(String templateHbm, int n) throws Exception {

		templateHbm = templateHbm.replaceAll("@CLASS", "Account" + n);
		templateHbm = templateHbm.replaceAll("@TABLE", "account" + n);
		templateHbm = templateHbm.replaceAll("@Node", "Account" + n);
		InputStream stream = new ByteArrayInputStream(
				templateHbm.getBytes(StandardCharsets.ISO_8859_1));
		return stream;
	}

}
