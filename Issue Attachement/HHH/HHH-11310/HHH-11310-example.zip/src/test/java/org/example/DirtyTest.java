package org.example;

import static org.assertj.core.api.Assertions.assertThat;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.junit.Test;

public class DirtyTest {

	@Test
	public void testCollection() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("example");
		try {
			EntityManager em = emf.createEntityManager();

			em.getTransaction().begin();
			ExampleEntity example = new ExampleEntity();
			em.persist(example);
			em.getTransaction().commit();

			ExampleEntity loadedExample = em.find(ExampleEntity.class, example.getId());
			em.detach(loadedExample);

			assertThat(em.unwrap(Session.class).isDirty()).as("session is dirty").isFalse();
			em.merge(loadedExample);

			// This is not working:
			assertThat(em.unwrap(Session.class).isDirty()).as("session is dirty").isFalse();
		} finally {
			emf.close();
		}
	}

}
