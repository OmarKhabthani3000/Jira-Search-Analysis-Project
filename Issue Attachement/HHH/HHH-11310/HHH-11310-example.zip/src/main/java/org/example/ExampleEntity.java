package org.example;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class ExampleEntity {

	@Id
	@GeneratedValue
	private Long id;

	@ManyToOne
	private ExampleEntity parent;

	@OneToMany(mappedBy = "parent")
	private Set<ExampleEntity> children;

	public Set<ExampleEntity> getChildren() {
		return children;
	}

	public Long getId() {
		return id;
	}

	public ExampleEntity getParent() {
		return parent;
	}

	public void setParent(ExampleEntity parent) {
		this.parent = parent;
	}

}
