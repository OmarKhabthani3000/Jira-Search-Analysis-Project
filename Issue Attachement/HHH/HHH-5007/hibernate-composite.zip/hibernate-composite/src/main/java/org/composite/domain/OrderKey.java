package org.composite.domain;

import java.io.Serializable;

public class OrderKey implements Serializable {

	private String companyCode;
	private String orderId;

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String pCompanyCode) {
		companyCode = pCompanyCode;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String pOrderId) {
		orderId = pOrderId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((companyCode == null) ? 0 : companyCode.hashCode());
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderKey other = (OrderKey) obj;
		if (companyCode == null) {
			if (other.companyCode != null)
				return false;
		} else if (!companyCode.equals(other.companyCode))
			return false;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		return true;
	}

}
