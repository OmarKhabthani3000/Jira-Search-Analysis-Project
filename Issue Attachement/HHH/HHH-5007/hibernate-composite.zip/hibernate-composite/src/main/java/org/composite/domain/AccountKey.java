package org.composite.domain;

import java.io.Serializable;

public class AccountKey implements Serializable {

	private String companyCode;
	private String accountId;

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String pCompanyCode) {
		companyCode = pCompanyCode;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String pAccountId) {
		accountId = pAccountId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((accountId == null) ? 0 : accountId.hashCode());
		result = prime * result
				+ ((companyCode == null) ? 0 : companyCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountKey other = (AccountKey) obj;
		if (accountId == null) {
			if (other.accountId != null)
				return false;
		} else if (!accountId.equals(other.accountId))
			return false;
		if (companyCode == null) {
			if (other.companyCode != null)
				return false;
		} else if (!companyCode.equals(other.companyCode))
			return false;
		return true;
	}

}
