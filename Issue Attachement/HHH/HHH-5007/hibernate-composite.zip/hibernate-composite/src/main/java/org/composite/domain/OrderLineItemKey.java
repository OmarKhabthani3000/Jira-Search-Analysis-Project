package org.composite.domain;

import java.io.Serializable;

public class OrderLineItemKey implements Serializable {

	private String companyCode;
	private String orderId;
	private Integer index;

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String pCompanyCode) {
		companyCode = pCompanyCode;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String pOrderId) {
		orderId = pOrderId;
	}

	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer pIndex) {
		index = pIndex;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((companyCode == null) ? 0 : companyCode.hashCode());
		result = prime * result + ((index == null) ? 0 : index.hashCode());
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderLineItemKey other = (OrderLineItemKey) obj;
		if (companyCode == null) {
			if (other.companyCode != null)
				return false;
		} else if (!companyCode.equals(other.companyCode))
			return false;
		if (index == null) {
			if (other.index != null)
				return false;
		} else if (!index.equals(other.index))
			return false;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		return true;
	}

}
