Dependencies:

1. Access to an empty oracle schema
2. Installed maven2

Install:

1. Fill the database access properties in src\main\filters\filter.properties
2. run: mvn test

This project will fail on the unit test, because the saveOrUpdate/persist operation
will not be cascaded for the ManyToOne association in an Embeddable element.