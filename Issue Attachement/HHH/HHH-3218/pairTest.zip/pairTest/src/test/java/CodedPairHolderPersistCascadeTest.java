import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;


public class CodedPairHolderPersistCascadeTest extends TestCase {

	public void testPersistCascade() {
		final SessionFactory sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
		final Session sess = sessionFactory.openSession();
		try {
			final Transaction trx  = sess.beginTransaction();
			try {
				final Set<PersonPair> setOfPairs = new HashSet<PersonPair>();
				setOfPairs.add(new PersonPair(new Person("PERSON NAME 1"), new Person("PERSON NAME 2")));
				sess.saveOrUpdate(new CodedPairHolder("CODE", setOfPairs));
				sess.flush();
			} finally {
				trx.rollback();
			}
		} finally {
			sess.close();
		}
	}

	public void testPersistCascadeWithEntityManager() {
		final EntityManagerFactory emf = Persistence.createEntityManagerFactory("test");
		final EntityManager em = emf.createEntityManager();
		try {
			final EntityTransaction trx  = em.getTransaction();
			trx.begin();
			try {
				final Set<PersonPair> setOfPairs = new HashSet<PersonPair>();
				setOfPairs.add(new PersonPair(new Person("PERSON NAME 1"), new Person("PERSON NAME 2")));
				em.persist(new CodedPairHolder("CODE", setOfPairs));
				em.flush();
			} finally {
				trx.rollback();
			}
		} finally {
			em.close();
		}
	}

}
