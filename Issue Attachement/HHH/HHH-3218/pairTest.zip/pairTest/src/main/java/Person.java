

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@org.hibernate.annotations.Entity(dynamicInsert = true, dynamicUpdate = true)
@Table(name = "PERSON")
class Person implements Serializable {

	private static final long serialVersionUID = 960914272100925312L;

	@Id
	@SequenceGenerator(name = "person_sequence", sequenceName = "PERSON_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "person_sequence")
	@Column(name = "ID")
	private Long id;

	@Column(name = "NAME", nullable = false, unique = true, updatable = false, length = 256)
	private String name;

	Person() {
		super();
	}

	Person(final String pName) {
		super();
		this.name = pName;
	}

	Long getId() {
		return this.id;
	}

	String getName() {
		return this.name;
	}

	@Override
	public int hashCode() {
		final int prime = 103;
		int result = 1;
		result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object pObject) {
		if (this == pObject) {
			return true;
		}
		if (pObject == null) {
			return false;
		}
		if (!(pObject instanceof Person)) {
			return false;
		}
		final Person other = (Person) pObject;
		if (getName() == null) {
			if (other.getName() != null) {
				return false;
			}
		} else if (!getName().equals(other.getName())) {
			return false;
		}
		return true;
	}

}
