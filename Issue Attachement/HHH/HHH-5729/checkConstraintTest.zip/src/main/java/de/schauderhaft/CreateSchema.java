package de.schauderhaft;

import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.dialect.Oracle10gDialect;

public class CreateSchema {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		AnnotationConfiguration config = new AnnotationConfiguration()
				.addAnnotatedClass(TestClass.class);
		final String[] script = config
				.generateSchemaCreationScript(new Oracle10gDialect());

		for (String string : script) {
			System.out.println(string);
		}
	}

}
