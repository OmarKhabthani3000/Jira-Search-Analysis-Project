package de.schauderhaft;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
public class TestClass {

	@Id
	private Long id;

	@Max(10)
	@Min(2)
	private Integer min2Max10;

	@Max(99999)
	@Min(0)
	private Integer min0max99;
}
