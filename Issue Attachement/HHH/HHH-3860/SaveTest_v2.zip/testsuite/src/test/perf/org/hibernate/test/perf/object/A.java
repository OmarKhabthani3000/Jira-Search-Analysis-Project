package org.hibernate.test.perf.object;

import java.util.Map;

public class A {
	protected long id;

	protected int a;

	protected Map map;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public Map getMap() {
		return map;
	}

	public void setMap(Map map) {
		this.map = map;
	}

	public long getId() {
		return id;
	}

}
