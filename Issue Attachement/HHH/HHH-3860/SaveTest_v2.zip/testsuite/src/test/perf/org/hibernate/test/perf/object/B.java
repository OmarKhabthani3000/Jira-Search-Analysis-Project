package org.hibernate.test.perf.object;

import java.util.List;

public class B {
	protected long id;

	protected int b;

	protected List list;

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public long getId() {
		return id;
	}

}
