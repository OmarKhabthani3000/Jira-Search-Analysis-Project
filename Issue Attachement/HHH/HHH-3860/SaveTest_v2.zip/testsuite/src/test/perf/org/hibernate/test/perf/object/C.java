package org.hibernate.test.perf.object;

public class C {
	protected long id;

	protected int c;

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public long getId() {
		return id;
	}
}
