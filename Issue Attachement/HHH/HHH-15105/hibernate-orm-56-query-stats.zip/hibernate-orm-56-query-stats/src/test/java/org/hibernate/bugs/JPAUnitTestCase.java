package org.hibernate.bugs;

import javax.persistence.*;

import org.hibernate.SessionFactory;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.jpa.QueryHints;
import org.hibernate.stat.CacheRegionStatistics;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		CacheRegionStatistics cacheRegionStatistics = entityManagerFactory
			.unwrap(SessionFactoryImplementor.class)
			.getStatistics()
			.getQueryRegionStatistics("default-query-results-region");

		entityManager.createQuery(
			"select pc " +
			"from PostComment pc " +
			"order by pc.post.id desc", PostComment.class)
			.setMaxResults(10)
			.setHint(QueryHints.HINT_CACHEABLE, true)
			.getResultList();

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	@Entity(name = "Post")
	@Table(name = "post")
	@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
	public static class Post {

		@Id
		private Long id;

		private String title;

		@OneToMany(cascade = CascadeType.ALL, mappedBy = "post", orphanRemoval = true)
		@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
		private List<PostComment> comments = new ArrayList<>();

		public Long getId() {
			return id;
		}

		public Post setId(Long id) {
			this.id = id;
			return this;
		}

		public String getTitle() {
			return title;
		}

		public Post setTitle(String title) {
			this.title = title;
			return this;
		}

		public List<PostComment> getComments() {
			return comments;
		}

		public Post addComment(PostComment comment) {
			comments.add(comment);
			comment.setPost(this);
			return this;
		}
	}

	@Entity(name = "PostComment")
	@Table(name = "post_comment")
	@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
	public static class PostComment {

		@Id
		private Long id;

		@ManyToOne(fetch = FetchType.LAZY)
		private Post post;

		private String review;

		public Long getId() {
			return id;
		}

		public PostComment setId(Long id) {
			this.id = id;
			return this;
		}

		public Post getPost() {
			return post;
		}

		public PostComment setPost(Post post) {
			this.post = post;
			return this;
		}

		public String getReview() {
			return review;
		}

		public PostComment setReview(String review) {
			this.review = review;
			return this;
		}
	}
}
