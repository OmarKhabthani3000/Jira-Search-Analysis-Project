package org.hibernate.bugs;

import static org.junit.Assert.assertEquals;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM,
 * using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;
	private EntityManager entityManager;

	@Before
	public void init() {
		StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
				// Add in any settings that are specific to your test. See
				// resources/hibernate.properties for the defaults.
				.applySetting("hibernate.show_sql", "false").applySetting("hibernate.format_sql", "true")
				.applySetting("hibernate.hbm2ddl.auto", "update");

		Metadata metadata = new MetadataSources(srb.build())
				// Add your entities here.
				.addAnnotatedClass(Parent.class).addAnnotatedClass(Child.class).buildMetadata();

		entityManagerFactory = metadata.buildSessionFactory();
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh15027Test() {
		entityManager = entityManagerFactory.createEntityManager();
	    // Create new parent
		Parent parent1 = new Parent();
		beginTransaction();
		insert(parent1);
		commitTransaction();

		// Gets a fresh on from the db in order to get a fresh persistent bag instance
		entityManager.refresh(parent1); 

		beginTransaction();
		Parent parent2 = new Parent();

		Child c1 = new Child(parent1);
		c1.setName("C1-P1");
		parent1.addChild(c1); // Now in operationQueue of PersistentBag so parent 1 has one child

		/**
		 * This insert causes the parent1 child to be missing. Flushing causes
		 * clearing of the operationQueue the PersistentBag leading to missing
		 * of added child
		 */
		insert(parent2);

		assertEquals(1, parent1.getChilds().size());
		
		commitTransaction();

		entityManager.close();
	}

	private void insert(Parent parent1) {
		entityManager.persist(parent1);
		entityManager.flush();
	}

	private void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	private void beginTransaction() {
		entityManager.getTransaction().begin();
	}
}
