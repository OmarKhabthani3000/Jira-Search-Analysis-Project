package org.hibernate.bugs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "parent")
@Access(AccessType.FIELD)
public class Parent implements Serializable {

	private static final long serialVersionUID = -1798070786993154676L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(unique = true, nullable = false)
	private Integer id;

	@OneToMany(mappedBy = "childId", fetch = FetchType.LAZY)
	private List<Child> childs = new ArrayList<>();

	public Integer getId() {
		return id;
	}

	public void setEmployeeId(Integer employeeId) {
		this.id = employeeId;
	}

	public List<Child> getChilds() {
		return childs;
	}

	public void addChild(Child child) {
		this.childs.add(child);
	}
	
	@Override
	public String toString() {
		return "Parent-" + getId();
	}
}
