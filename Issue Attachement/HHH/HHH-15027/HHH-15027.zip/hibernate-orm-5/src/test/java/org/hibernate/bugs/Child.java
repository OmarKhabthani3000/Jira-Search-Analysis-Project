package org.hibernate.bugs;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "child")
@Access(AccessType.FIELD)
public class Child implements Serializable 
{
	private static final long serialVersionUID = -6790693372846798580L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(unique = true, nullable = false)
	private Integer childId;
	private String name;

	@ManyToOne
	private Parent parent;
	
	public Child(Parent p) {
		this.parent = p;
	}
	
	
	public Integer getChildId() {
		return childId;
	}

	public void setChildId(Integer accountId) {
		this.childId = accountId;
	}
	
	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}
	
	
	@Override
	public String toString() {
		return "Child-" + getName() + " P="+getParent();
	}	
}
