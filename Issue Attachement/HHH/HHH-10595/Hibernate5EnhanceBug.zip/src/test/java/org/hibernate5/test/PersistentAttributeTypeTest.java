package org.hibernate5.test;

import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.SharedCacheMode;
import javax.persistence.ValidationMode;
import javax.persistence.metamodel.Attribute.PersistentAttributeType;
import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.Metamodel;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.spi.PersistenceUnitTransactionType;

import org.hibernate.bytecode.enhance.spi.EnhancementContext;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.H2Dialect;
import org.hibernate.jpa.HibernateEntityManagerFactory;
import org.hibernate.jpa.HibernatePersistenceProvider;
import org.hibernate.jpa.boot.spi.Bootstrap;
import org.hibernate.jpa.boot.spi.EntityManagerFactoryBuilder;
import org.hibernate.jpa.boot.spi.PersistenceUnitDescriptor;
import org.hibernate.testing.junit4.BaseUnitTestCase;
import org.hibernate5.entity.Customer;
import org.hibernate5.entity.PrimaryAddress;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class PersistentAttributeTypeTest extends BaseUnitTestCase {
	private HibernateEntityManagerFactory entityManagerFactory;

	@Before
	public void setup() {
		EntityManagerFactoryBuilder entityManagerFactoryBuilder = Bootstrap.getEntityManagerFactoryBuilder(buildPersistenceUnitDescriptor(), buildSettings());
		entityManagerFactory = entityManagerFactoryBuilder.build().unwrap(HibernateEntityManagerFactory.class);
	}

	private PersistenceUnitDescriptor buildPersistenceUnitDescriptor() {
		return new TestingPersistenceUnitDescriptorImpl("org.hibernate5.entity");
	}

	public static class TestingPersistenceUnitDescriptorImpl implements PersistenceUnitDescriptor {
		private final String name;

		public TestingPersistenceUnitDescriptorImpl(String name) {
			this.name = name;
		}

		@Override
		public URL getPersistenceUnitRootUrl() {
			return null;
		}

		@Override
		public String getName() {
			return name;
		}

		@Override
		public String getProviderClassName() {
			return HibernatePersistenceProvider.class.getName();
		}

		@Override
		public boolean isUseQuotedIdentifiers() {
			return false;
		}

		@Override
		public boolean isExcludeUnlistedClasses() {
			return false;
		}

		@Override
		public PersistenceUnitTransactionType getTransactionType() {
			return null;
		}

		@Override
		public ValidationMode getValidationMode() {
			return null;
		}

		@Override
		public SharedCacheMode getSharedCacheMode() {
			return null;
		}

		@Override
		public List<String> getManagedClassNames() {
			return Arrays.asList(PrimaryAddress.class.getName(), Customer.class.getName());
		}

		@Override
		public List<String> getMappingFileNames() {
			return null;
		}

		@Override
		public List<URL> getJarFileUrls() {
			return null;
		}

		@Override
		public Object getNonJtaDataSource() {
			return null;
		}

		@Override
		public Object getJtaDataSource() {
			return null;
		}

		@Override
		public Properties getProperties() {
			return null;
		}

		@Override
		public ClassLoader getClassLoader() {
			return null;
		}

		@Override
		public ClassLoader getTempClassLoader() {
			return null;
		}

		@Override
		public void pushClassTransformer(EnhancementContext enhancementContext) {
		}
	}
	
	protected Map<String, String> buildSettings() {
		Map<String, String> config = new HashMap<>();
		config.put(Environment.DRIVER, "org.h2.Driver");
		config.put(Environment.URL, "jdbc:h2:mem:bug");
		config.put(Environment.USER, "sa");
		config.put(Environment.PASS, "");
		config.put(Environment.POOL_SIZE, "1");
		config.put(Environment.CURRENT_SESSION_CONTEXT_CLASS, "thread");
		config.put(Environment.DIALECT, H2Dialect.class.getName());
		return config;
	}
	
	@Test
	public void testPersistanceAttributeType() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Metamodel metamodel = entityManager.getMetamodel();
		EntityType<PrimaryAddress> entityType = metamodel.entity(PrimaryAddress.class);
		SingularAttribute<? super PrimaryAddress, ?> singularAttr = entityType.getSingularAttribute("customer");
		Assert.assertTrue("Should be ONE_TO_ONE but is " + singularAttr.getPersistentAttributeType(), 
				singularAttr.getPersistentAttributeType() == PersistentAttributeType.ONE_TO_ONE);
	}

}
