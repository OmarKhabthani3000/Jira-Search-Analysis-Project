package org.hibernate5.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Customer")
public class Customer {
	private Long id;

	private PrimaryAddress address = new PrimaryAddress();

	@Id
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@OneToOne
	@JoinColumn(name = "primary_address_id")
	public PrimaryAddress getAddress() {
		return address;
	}

	public void setAddress(PrimaryAddress address) {
		this.address = address;
	}

}