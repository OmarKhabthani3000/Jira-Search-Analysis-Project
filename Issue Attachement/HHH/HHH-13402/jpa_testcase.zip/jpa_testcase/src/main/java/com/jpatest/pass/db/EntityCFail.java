package com.jpatest.pass.db;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

//This is renamed copy of EntityC with reference to EntityBFail instead of EntityB
@Entity
public class EntityCFail implements Serializable {

    @Id
    private String code;
    @ManyToOne
    @JoinColumn(name = "b_ref_id")
    private EntityBFail entityB;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public EntityBFail getEntityB() {
        return entityB;
    }

    public void setEntityB(EntityBFail entityB) {
        this.entityB = entityB;
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EntityCFail entityC = (EntityCFail) o;
        return Objects.equals(getCode(), entityC.getCode());
    }

    @Override public int hashCode() {
        return Objects.hash(getCode());
    }
}
