package com.jpatest.fail.db;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class EntityA implements Serializable {
    @Id
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EntityA entityA = (EntityA) o;
        return getId() == entityA.getId();
    }

    @Override public int hashCode() {
        return Objects.hash(getId());
    }
}
