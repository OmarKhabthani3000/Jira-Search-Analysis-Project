package com.jpatest.fail.db;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class EntityC implements Serializable {

    @Id
    private String code;
    @ManyToOne
    @JoinColumn(name = "b_ref_id")
    private EntityB entityB;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public EntityB getEntityB() {
        return entityB;
    }

    public void setEntityB(EntityB entityB) {
        this.entityB = entityB;
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EntityC entityC = (EntityC) o;
        return Objects.equals(getCode(), entityC.getCode());
    }

    @Override public int hashCode() {
        return Objects.hash(getCode());
    }
}
