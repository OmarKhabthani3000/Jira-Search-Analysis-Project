package com.jpatest.fail;

import com.jpatest.BaseJpaUnit;
import com.jpatest.fail.db.EntityA;
import com.jpatest.fail.db.EntityB;
import com.jpatest.fail.db.EntityC;
import javax.persistence.EntityManager;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * This test case fails during persistence initialization because of the package name of entity classes, mapping is the same as in pass.db package
 * */
public class FailPackageTest extends BaseJpaUnit {

    @Override protected String getPuName() {
        return "fail_package_pu";
    }

    @Override
    public void insertAndSelect() {
        //given
        EntityManager em = lookupEm();
        //when
        EntityA entityA = new EntityA();
        entityA.setId(1);
        em.persist(entityA);
        em.flush();

        EntityB entityB = new EntityB();
        entityB.setEntityA(entityA);
        em.persist(entityB);
        em.flush();

        EntityC entityC = new EntityC();
        entityC.setCode("65XE");
        entityC.setEntityB(entityB);
        em.persist(entityC);
        em.flush();

        EntityC loaded = em.find(EntityC.class, "65XE");

        //then
        assertThat(loaded.getCode()).isEqualTo(entityC.getCode());
        assertThat(loaded.getEntityB().getEntityA().getId()).isSameAs(entityC.getEntityB().getEntityA().getId());
    }
}
