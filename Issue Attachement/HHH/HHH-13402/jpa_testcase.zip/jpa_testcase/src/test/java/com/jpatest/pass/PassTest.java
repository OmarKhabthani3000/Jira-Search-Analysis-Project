package com.jpatest.pass;

import com.jpatest.BaseJpaUnit;
import com.jpatest.pass.db.EntityA;
import com.jpatest.pass.db.EntityB;
import com.jpatest.pass.db.EntityC;
import javax.persistence.EntityManager;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * This test case pass persistence initialization
 * */
public class PassTest extends BaseJpaUnit {

    @Override protected String getPuName() {
        return "pass_pu";
    }

    @Override
    public void insertAndSelect() {
        //given
        EntityManager em = lookupEm();
        //when
        EntityA entityA = new EntityA();
        entityA.setId(1);
        em.persist(entityA);
        em.flush();

        EntityB entityB = new EntityB();
        entityB.setEntityA(entityA);
        em.persist(entityB);
        em.flush();

        EntityC entityC = new EntityC();
        entityC.setCode("65XE");
        entityC.setEntityB(entityB);
        em.persist(entityC);
        em.flush();

        EntityC loaded = em.find(EntityC.class, "65XE");

        //then
        assertThat(loaded.getCode()).isEqualTo(entityC.getCode());
        assertThat(loaded.getEntityB().getEntityA().getId()).isSameAs(entityC.getEntityB().getEntityA().getId());
    }
}
