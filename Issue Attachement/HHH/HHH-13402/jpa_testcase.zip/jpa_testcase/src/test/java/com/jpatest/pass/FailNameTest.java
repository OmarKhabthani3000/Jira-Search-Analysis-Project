package com.jpatest.pass;

import com.jpatest.BaseJpaUnit;
import com.jpatest.pass.db.EntityA;
import com.jpatest.pass.db.EntityBFail;
import com.jpatest.pass.db.EntityCFail;
import javax.persistence.EntityManager;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * This test case fails during persistence initialization because of the name of entity classes
 * */
public class FailNameTest extends BaseJpaUnit {

    @Override protected String getPuName() {
        return "fail_name_pu";
    }

    @Override
    public void insertAndSelect() {
        //given
        EntityManager em = lookupEm();
        //when
        EntityA entityA = new EntityA();
        entityA.setId(1);
        em.persist(entityA);
        em.flush();

        EntityBFail entityB = new EntityBFail();
        entityB.setEntityA(entityA);
        em.persist(entityB);
        em.flush();

        EntityCFail entityC = new EntityCFail();
        entityC.setCode("65XE");
        entityC.setEntityB(entityB);
        em.persist(entityC);
        em.flush();

        EntityCFail loaded = em.find(EntityCFail.class, "65XE");

        //then
        assertThat(loaded.getCode()).isEqualTo(entityC.getCode());
        assertThat(loaded.getEntityB().getEntityA().getId()).isSameAs(entityC.getEntityB().getEntityA().getId());
    }
}
