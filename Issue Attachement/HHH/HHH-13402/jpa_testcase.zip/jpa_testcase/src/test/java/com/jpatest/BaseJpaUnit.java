package com.jpatest;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.Test;

public abstract class BaseJpaUnit {

    private EntityManagerFactory entityManagerFactory;
    private EntityManager entityManager;


    private void initJpa() {
        String puName = getPuName();
        Map properties = new HashMap<>();
        properties.put("javax.persistence.schema-generation.database.action", "create");
        Persistence.generateSchema(puName, properties);
        entityManagerFactory = Persistence.createEntityManagerFactory(puName);
    }

    @Test
    public final void executeInsertAndSelect() throws Exception {
        initJpa();
        lookupEm().getTransaction().begin();

        insertAndSelect();

        lookupEm().getTransaction().rollback();
        lookupEm().close();
        entityManager = null;
        entityManagerFactory.close();
    }


    protected final EntityManager lookupEm() {
        if(Objects.isNull(entityManager)) {
            entityManager  = entityManagerFactory.createEntityManager();
        }
        return entityManager;
    }

    protected abstract String getPuName();

    protected abstract void insertAndSelect();

}
