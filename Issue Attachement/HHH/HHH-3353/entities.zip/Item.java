package com.kaching.experimental.users.pascal;

import java.util.ArrayList;
import java.util.Collection;

class Item {

  int id;
  
  Collection<Comment> comments;
  
  Item() {
    comments = new ArrayList<Comment>();
  }
  
}
