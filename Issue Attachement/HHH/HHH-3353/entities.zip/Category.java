package com.kaching.experimental.users.pascal;

class Category {

  int id;
  
}
