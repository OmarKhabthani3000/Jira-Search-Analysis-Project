package com.kaching.experimental.users.pascal;

class Comment {

  int id;
  
  Item item;
  
  Category category;
  
  Comment() {
  }
  
}
