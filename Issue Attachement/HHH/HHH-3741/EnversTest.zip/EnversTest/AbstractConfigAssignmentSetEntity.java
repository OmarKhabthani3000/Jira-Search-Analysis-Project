package entity.test;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;


@Entity
@Table(name="ConfigAssignmentSet")
@Audited
@Inheritance(strategy=InheritanceType.JOINED)

public abstract class AbstractConfigAssignmentSetEntity
	extends AbstractEntity {
	
	// ------------------------------------------------------------
	@OneToMany (fetch = FetchType.LAZY)
	@LazyCollection(LazyCollectionOption.EXTRA)
	@Cascade (value={CascadeType.ALL,CascadeType.DELETE_ORPHAN})	

	@JoinTable(name="configAssignmentSet_configAssignment", 
			joinColumns = @JoinColumn(name="configAssignmentSet_id"),
			inverseJoinColumns = @JoinColumn(name="configAssignment_id"))
		
	@AuditJoinTable(name="configAssignmentSet_configAssignment_aud", 
		inverseJoinColumns = @JoinColumn(name="configAssignment_id"))
	// ------------------------------------------------------------

	private Set <AbstractConfigAssignmentEntity> configAssignments = 
		new HashSet<AbstractConfigAssignmentEntity>();
	
	public Set<AbstractConfigAssignmentEntity> getConfigAssignments() {		
		return configAssignments;
	}

	public void setConfigAssignments(Set<AbstractConfigAssignmentEntity> configAssignments) {
		this.configAssignments = configAssignments;
	}

	public boolean addConfigAssignment(AbstractConfigAssignmentEntity configAssignment) {
		return configAssignments.add(configAssignment);		
	}

	public boolean removeConfigAssignment(AbstractConfigAssignmentEntity configAssignment) {
		return configAssignments.remove(configAssignment);
	}
}
