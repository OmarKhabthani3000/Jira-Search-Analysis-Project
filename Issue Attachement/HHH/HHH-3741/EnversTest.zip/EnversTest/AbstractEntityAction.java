package entity.test;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Remove;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.log.Log;

import entity.entityabstract.AbstractEntity;

@Stateless
@Name("AbstractEntityAction")
public class AbstractEntityAction implements IAbstractEntityAction {

	@PersistenceContext
	EntityManager entityManager;
	
	@Logger Log log;
	
	public AbstractEntityAction(){}
	
	public void remove(AbstractEntity persistentInstance){
		entityManager.remove(merge(persistentInstance));
	}
	
	public AbstractEntity merge(AbstractEntity detachedInstance){
		if(detachedInstance == null){
			log.error("Merge Failed - Null Entity");
		}
		try{
			log.info("Merging " + detachedInstance.getId());
			AbstractEntity result = (AbstractEntity) entityManager.merge(detachedInstance);
			entityManager.flush();
			return result;
		}catch(RuntimeException re){
			throw re;
		}
	}

	public AbstractEntity findById(Long id){
		
		try {
			AbstractEntity instance = entityManager.find(AbstractEntity.class, id);
			return instance;
		} catch(RuntimeException re) {
			throw re;
		}
	}
	
	protected List<AbstractEntity> getAll(String entityName){		
		Query q = entityManager.createQuery(
		" from " + entityName +  " ae");
		return q.getResultList();
	}

	public List<AbstractEntity> getAll(){		
		return null;
	}
	
	@Remove
	public void destroy(){				
	}
	
	@PreDestroy
	public void beforeDestroy(){
	}
	
	@PostConstruct
	public void afterConstruct(){
	}

	public AbstractEntity merge(AbstractEntity newEntity, AbstractEntity oldEntity, List changes) {
		if(newEntity == null){
			log.error("Merge Failed - Null Entity");
		}
		try{
			log.info("Merging " + newEntity.getId());
			AbstractEntity result = (AbstractEntity)entityManager.merge(newEntity);
			entityManager.flush();
			return result;
		}catch(RuntimeException re){
			throw re;
		}
	}
}
