package entity.test;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.jboss.seam.annotations.Name;

@Entity
@Name("MyAssignmentEntity")
@Table(name="MyAssignment")
@Audited

public class MyAssignmentEntity extends AbstractConfigAssignmentEntity {

	private String data;

	public String getData() {
		return data;
	}	
	
	public void setData(String data) {
		this.data = data;
	}
}
