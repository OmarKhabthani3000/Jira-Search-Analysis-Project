package entity.test;

import java.util.List;

public interface IDataManagementDelegate {
	public void remove(AbstractEntity persistentInstance);
	public AbstractEntity merge(AbstractEntity detachedInstance);
	public AbstractEntity merge(AbstractEntity newEntity, AbstractEntity oldEntity, List changes);
	public AbstractEntity findById(Long id);
	public List<? extends AbstractEntity> getAll();
}
