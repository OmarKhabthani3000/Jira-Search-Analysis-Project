package entity.test;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.log.Log;

@Stateless
@Name("mySetAction")
public class MySetAction extends AbstractEntityAction implements IAbstractEntityAction {

	private static final String MANAGED_ENTITY = "MySetEntity";
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Logger Log log;
	
	public MySetAction(){}
	
	@Override
	public List<AbstractEntity> getAll(){
		return super.getAll(MANAGED_ENTITY);
	}
	
	public static String getManagedEntity() {
		return MANAGED_ENTITY;
	}	
}
