package unittest;

import java.util.List;

import org.jboss.seam.mock.SeamTest;
import org.testng.annotations.Test;

import entity.test.AbstractEntity;
import entity.test.IAbstractEntityAction;
import entity.test.MyAssignmentEntity;
import entity.test.MySetEntity;

public class MyTest extends SeamTest{

	@Test
	public void testRegistration() throws Exception {
		new ComponentTest(){
			@Override
			protected void testComponents() throws Exception {
								
				IAbstractEntityAction mySetAction = (IAbstractEntityAction) getInstance("mySetAction");
				MySetEntity mySet = new MySetEntity();
				mySet.setDescription("Test Set");
				mySet = (MySetEntity) mySetAction.merge(mySet);					

				IAbstractEntityAction myAssignmentAction = (IAbstractEntityAction) getInstance("myAssignmentAction");
				MyAssignmentEntity myAssignment = new MyAssignmentEntity();
				myAssignment.setData("Test Data");
				myAssignment = (MyAssignmentEntity) myAssignmentAction.merge(myAssignment);
					
				mySet.addConfigAssignment(myAssignment);
				mySetAction.merge(mySet);
			
				// add asserts here
				List<? extends AbstractEntity> all = myAssignmentAction.getAll();
				assert(all != null);
			}
		}.run();
	}
}
