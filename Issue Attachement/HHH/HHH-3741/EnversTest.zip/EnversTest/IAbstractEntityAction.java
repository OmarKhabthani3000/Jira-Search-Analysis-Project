package entity.test;
import javax.ejb.Local;

@Local
public interface IAbstractEntityAction extends IDataManagementDelegate {
	
	public void beforeDestroy();
	public void afterConstruct();
	public void destroy();
	
}
