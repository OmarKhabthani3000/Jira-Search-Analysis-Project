package entity.test;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Table(name="ConfigAssignment")
@Audited
@Inheritance(strategy=InheritanceType.JOINED)

public abstract class AbstractConfigAssignmentEntity 
	extends AbstractEntity {
	
	@ManyToOne (fetch = FetchType.LAZY)
	@JoinColumn(name="configAssignmentSet_Id", 
			insertable = false, 
			updatable = false) 
	private AbstractConfigAssignmentSetEntity configAssignmentSet;	

	public AbstractConfigAssignmentSetEntity getConfigAssignmentSet() {
		return configAssignmentSet;
	}
}
