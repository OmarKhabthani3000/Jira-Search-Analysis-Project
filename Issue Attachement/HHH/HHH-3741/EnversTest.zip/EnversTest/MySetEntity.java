package entity.test;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.jboss.seam.annotations.Name;

@Entity
@Name("MySetEntity")
@Table(name="MySet")
@Audited

public class MySetEntity extends AbstractConfigAssignmentSetEntity {

    	private String description;		

	public String getDescription() {
		return description;
	}    

	public void setDescription(String description) {
		this.description = description;
	}		
}
