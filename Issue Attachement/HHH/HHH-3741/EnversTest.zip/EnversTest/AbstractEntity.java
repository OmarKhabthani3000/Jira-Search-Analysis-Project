package entity.test;

import java.io.Serializable;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.SequenceGenerator;

@MappedSuperclass
public abstract class AbstractEntity
	implements Serializable {

	@Id
	@SequenceGenerator(name = "entitySequence", sequenceName = "entity_sequence")	
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "entitySequence")
    	private Long id;		

	public Long getId() {
		return id;
	}    

	public void setId(Long id) {
		this.id = id;
	}

	private String name;

	public String getName() {
		return name;
	}	

	public void setName(String name) {
		this.name = name;
	}		

}
