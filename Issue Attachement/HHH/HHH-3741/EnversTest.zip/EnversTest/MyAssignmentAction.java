package entity.test;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.log.Log;

@Stateless
@Name("myAssignmentAction")
public class MyAssignmentAction extends AbstractEntityAction implements IAbstractEntityAction {

	private static final String MANAGED_ENTITY = "MyAssignmentEntity";
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Logger Log log;
	
	public MyAssignmentAction(){}
	
	@Override
	public List<AbstractEntity> getAll(){
		return super.getAll(MANAGED_ENTITY);
	}
	
	public static String getManagedEntity() {
		return MANAGED_ENTITY;
	}	
}
