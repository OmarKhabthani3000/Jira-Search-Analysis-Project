import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class C {

    @Column(length=500)
    private String comment;

    public String getComment() {
        return comment;
    }
    public void setComment(String comment) {
        this.comment = comment;
    }
}
