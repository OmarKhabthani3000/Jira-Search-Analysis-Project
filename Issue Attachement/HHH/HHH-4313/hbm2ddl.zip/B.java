import java.util.List;

import javax.persistence.Embeddable;

import org.hibernate.annotations.CollectionOfElements;
import org.hibernate.annotations.IndexColumn;

@Embeddable
public class B {
    @CollectionOfElements
    @IndexColumn(name="ndx")
    private List<C> listOfC;

    public List<C> getListOfC() {
        return listOfC;
    }
    public void setListOfC(List<C> listOfC) {
        this.listOfC = listOfC;
    }
}
