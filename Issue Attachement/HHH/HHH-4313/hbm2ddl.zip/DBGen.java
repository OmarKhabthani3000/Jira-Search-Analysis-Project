import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;


public class DBGen {
	/**
	 * Simple program to generate the database schema from the
	 * Hibernate annotations
	 */
	public static void main(String[] args) {
		if (args.length != 1) {
			System.out.println("usage: DBGen <sqlFile>");
			System.exit(-1);
		}
		try {
            Configuration cfg =
                new AnnotationConfiguration().configure("WEB-INF/hibernate.cfg.xml");
            new SchemaExport(cfg).
                //setOutputFile(args[0]).
                setFormat(true).
                setDelimiter(";").
                create(true, false);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
}
