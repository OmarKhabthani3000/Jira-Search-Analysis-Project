package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
public class Functionalareadata  {

    @Id
    @Column(name="FUNCL_AREA_KEY",
            insertable=false, updatable=false)
    private int functionalAreaKey;

    @Column(name="FUNCL_AREA_NM")
    private String functionalAreaName;

    public int getFunctionalAreaKey() {
        return functionalAreaKey;
    }

    public void setFunctionalAreaKey(int functionalAreaKey) {
        this.functionalAreaKey = functionalAreaKey;
    }

    public String getFunctionalAreaName() {
        return functionalAreaName;
    }

    public void setFunctionalAreaName(String functionalAreaName) {
        this.functionalAreaName = functionalAreaName;
    }

}
