package org.hibernate.bugs;

import org.hibernate.dialect.Oracle12cDialect;
import org.hibernate.dialect.pagination.LimitHandler;
import org.hibernate.dialect.pagination.SQL2008StandardLimitHandler;

/**
 * An SQL dialect for Oracle 12c. Temp fix 
 *
 * @author vnathan
 */
public class OverrideLimitHandler extends Oracle12cDialect {

	@Override
	public LimitHandler getLimitHandler() {
		return SQL2008StandardLimitHandler.INSTANCE;
	}

	
}
