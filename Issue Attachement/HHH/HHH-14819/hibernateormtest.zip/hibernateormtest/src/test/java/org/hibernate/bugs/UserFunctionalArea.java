package org.hibernate.bugs;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
public class UserFunctionalArea {

    @Id
    @Column(name="USER_KEY")
    private int userKey;

    @OneToOne
    @JoinColumn(name="FUNCL_AREA_KEY", referencedColumnName="FUNCL_AREA_KEY",
            insertable=false, updatable=false)
    private Functionalareadata functionalAreaName;


       public int getUserKey() {
        return userKey;
    }

    public void setUserKey(int userKey) {
        this.userKey = userKey;
    }
    public Functionalareadata getFunctionalAreaName() {
        return functionalAreaName;
    }

    public void setFunctionalAreaName(Functionalareadata functionalAreaName) {
        this.functionalAreaName = functionalAreaName;
    }

}
