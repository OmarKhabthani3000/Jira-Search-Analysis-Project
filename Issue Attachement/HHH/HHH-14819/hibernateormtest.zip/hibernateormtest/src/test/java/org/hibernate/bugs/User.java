package org.hibernate.bugs;

import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.CascadeType;
import javax.persistence.*;



/**
 *
 * @author AG20883
 *
 */

@Entity
public class User {

    @Id
    @Column(name="USER_KEY")
    private Integer userKey;

    private String status;

    @OneToMany
    @JoinColumn(name="USER_KEY" , referencedColumnName="USER_KEY")
    private  List<UserFunctionalArea> functionalArea;

    public int getUserKey() {
        return userKey;
    }

    public void setUserKey(int userKey) {
        this.userKey = userKey;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String theStatus) {
        this.status = theStatus;
    }

    public UserFunctionalArea getFunctionalArea() {
        return functionalArea.size()>=1?functionalArea.get(0): null;
    }

    public void setFunctionalArea(List<UserFunctionalArea> functionalArea) {
        this.functionalArea = functionalArea;
    }

}
