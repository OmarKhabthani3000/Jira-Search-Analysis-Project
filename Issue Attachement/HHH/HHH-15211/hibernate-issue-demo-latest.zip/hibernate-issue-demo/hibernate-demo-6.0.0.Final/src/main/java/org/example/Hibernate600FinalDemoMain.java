package org.example;

import org.example.entity.ProductEntity;
import org.example.entity.ProductPrice;
import org.example.model.MyBigDecimal;
import org.example.util.HibernateUtil;
import org.hibernate.Session;

import java.util.Arrays;

public class Hibernate600FinalDemoMain {
    public static void main(final String[] args) {
        run();
    }

    public static void run() {
        System.out.println("Hibernate 6.0.0.Final");
        final Session session = HibernateUtil.getSessionFactory().openSession();

        // Create and save the new product
        int newProductId = saveProduct(session);

        // Load the new product, ClassCastException will be thrown here
        loadProduct(session, newProductId);

        HibernateUtil.shutdown();
    }

    private static void loadProduct(final Session session, final int productId) {
        session.beginTransaction();
        final ProductEntity productEntity = session.get(ProductEntity.class, productId);
        System.out.println(productEntity.toString());

        /*
            The commit here will cause the following exception:
            java.lang.ClassCastException: class org.example.model.MyBigDecimal cannot be cast to class java.math.BigDecimal (org.example.model.MyBigDecimal is in unnamed module of loader 'app'; java.math.BigDecimal is in module java.base of loader 'bootstrap')
         */
        session.getTransaction().commit();
    }

    private static int saveProduct(final Session session) {
        session.beginTransaction();

        //Add new Product object
        final ProductEntity productEntity = getNewProductEntity();

        session.save(productEntity);

        session.getTransaction().commit();

        return productEntity.getProductId();
    }

    private static ProductEntity getNewProductEntity() {
        final ProductPrice productPriceUS = new ProductPrice();
        productPriceUS.setCountryCode("US");
        productPriceUS.setPrice(new MyBigDecimal(15));

        final ProductPrice productPriceDE = new ProductPrice();
        productPriceDE.setCountryCode("DE");
        productPriceDE.setPrice(new MyBigDecimal(12));

        final ProductEntity productEntity = new ProductEntity();
        productEntity.setProductName("Product A");
        productEntity.setProductPrices(Arrays.asList(productPriceUS, productPriceDE));

        return productEntity;
    }
}
