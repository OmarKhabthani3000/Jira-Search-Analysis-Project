package org.example.converter;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import org.example.model.MyBigDecimal;

import java.math.BigDecimal;

@Converter(autoApply = true)
public class MyBigDecimalConverter implements AttributeConverter<MyBigDecimal, BigDecimal> {
    @Override
    public BigDecimal convertToDatabaseColumn(MyBigDecimal attribute) {
        return BigDecimal.valueOf(attribute.getValue());
    }

    @Override
    public MyBigDecimal convertToEntityAttribute(BigDecimal dbData) {
        return new MyBigDecimal(dbData.doubleValue());
    }

    public MyBigDecimalConverter() {
        System.out.println("Registered MyBigDecimalConverter");
    }
}
