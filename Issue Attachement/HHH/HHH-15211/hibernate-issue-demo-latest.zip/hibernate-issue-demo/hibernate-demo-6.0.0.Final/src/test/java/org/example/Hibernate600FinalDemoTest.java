package org.example;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class Hibernate600FinalDemoTest {
    @Test
    public void test() {
        Assertions.assertDoesNotThrow(() -> Hibernate600FinalDemoMain.run());
    }
}
