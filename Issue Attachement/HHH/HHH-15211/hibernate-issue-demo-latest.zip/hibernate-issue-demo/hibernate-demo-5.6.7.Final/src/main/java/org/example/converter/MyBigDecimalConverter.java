package org.example.converter;

import org.example.model.MyBigDecimal;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.math.BigDecimal;

@Converter(autoApply = true)
public class MyBigDecimalConverter implements AttributeConverter<MyBigDecimal, BigDecimal> {
    @Override
    public BigDecimal convertToDatabaseColumn(MyBigDecimal attribute) {
        return BigDecimal.valueOf(attribute.getValue());
    }

    @Override
    public MyBigDecimal convertToEntityAttribute(BigDecimal dbData) {
        return new MyBigDecimal(dbData.doubleValue());
    }

    public MyBigDecimalConverter() {
        System.out.println("Registered MyBigDecimalConverter");
    }
}
