package org.example.entity;

import org.example.model.MyBigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ProductPrice {

    @Column(name="price", nullable=false)
    private MyBigDecimal price;

    @Column(name="country_code", nullable=false)
    private String countryCode;

    public MyBigDecimal getPrice() {
        return price;
    }

    public void setPrice(MyBigDecimal price) {
        this.price = price;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @Override
    public String toString() {
        return "ProductPrice{" + "price=" + price + ", countryCode=" + countryCode + '}';
    }
}
