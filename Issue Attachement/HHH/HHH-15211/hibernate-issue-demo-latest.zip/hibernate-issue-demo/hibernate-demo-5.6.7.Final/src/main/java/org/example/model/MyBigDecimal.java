package org.example.model;

/**
 * Dummy custom object to show case the issue with AttributeConverter during commit()
 */
public class MyBigDecimal {
    private double value;

    public MyBigDecimal(double value) {
        this.value = value;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "MyBigDecimal{" + "value=" + value + '}';
    }
}
