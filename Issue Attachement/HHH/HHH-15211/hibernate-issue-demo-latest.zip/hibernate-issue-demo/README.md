# Demo Project
## Introduction
This is the demo project which showcases that the AttributeConverter related changes in hibernate 6.0.0.Final will throw an exception if the following conditions met:
1. An @Embeddable class with **custom-type** variable.
1. An @AttributeConverter converter which converter the same **custom-type** mentioned above.

PS: hibernate 5.6.7.Final works fine.

## Project setting
* ProductEntity
    * A simple entity which contains:
        * productId: Integer
        * productName: String
        * productPrices: List<ProductPrice>
            * Collection table
* ProductPrice
    * An embeddable class which contains:
        * countryCode: String
        * price: MyBigDecimal
* MyBigDecimal
    * Custom class which is to showcase the issue
* MyBigDecimalConverter
    * An attribute convert which convert MyBigDecimal into BigDecimal and vice versa.

## Run the demo projects
1. Run mvn clean test at root (hibernate-issue-demo).
    <br>Results:
    * hibernate-demo-5.6.7.Final - Test passed
    * hibernate-demo-6.0.0.Final - Test failed
1. To run the single demo project, run the main class:
    * org.example.Hibernate567FinalDemoMain
    * org.example.Hibernate600FinalDemoMain
1. The error will be thrown after fetching data and run commit() in hibernate 6.0.0.Final.

## Exception
```
Exception in thread "main" java.lang.ClassCastException: class org.example.model.MyBigDecimal cannot be cast to class java.math.BigDecimal (org.example.model.MyBigDecimal is in unnamed module of loader 'app'; java.math.BigDecimal is in module java.base of loader 'bootstrap')
	at org.hibernate.type.descriptor.java.BigDecimalJavaType.extractHashCode(BigDecimalJavaType.java:22)
	at org.hibernate.type.AbstractStandardBasicType.getHashCode(AbstractStandardBasicType.java:165)
	at org.hibernate.type.ComponentType.getHashCode(ComponentType.java:241)
	at org.hibernate.collection.spi.PersistentBag.nullableHashCode(PersistentBag.java:192)
	at org.hibernate.collection.spi.PersistentBag.groupByEqualityHash(PersistentBag.java:179)
	at org.hibernate.collection.spi.PersistentBag.equalsSnapshot(PersistentBag.java:128)
	at org.hibernate.engine.spi.CollectionEntry.dirty(CollectionEntry.java:159)
	at org.hibernate.engine.spi.CollectionEntry.preFlush(CollectionEntry.java:183)
	at org.hibernate.event.internal.AbstractFlushingEventListener.lambda$prepareCollectionFlushes$0(AbstractFlushingEventListener.java:180)
	at org.hibernate.engine.internal.StatefulPersistenceContext.forEachCollectionEntry(StatefulPersistenceContext.java:1120)
	at org.hibernate.event.internal.AbstractFlushingEventListener.prepareCollectionFlushes(AbstractFlushingEventListener.java:180)
	at org.hibernate.event.internal.AbstractFlushingEventListener.flushEverythingToExecutions(AbstractFlushingEventListener.java:83)
	at org.hibernate.event.internal.DefaultFlushEventListener.onFlush(DefaultFlushEventListener.java:38)
	at org.hibernate.event.service.internal.EventListenerGroupImpl.fireEventOnEachListener(EventListenerGroupImpl.java:107)
	at org.hibernate.internal.SessionImpl.doFlush(SessionImpl.java:1419)
	at org.hibernate.internal.SessionImpl.managedFlush(SessionImpl.java:473)
	at org.hibernate.internal.SessionImpl.flushBeforeTransactionCompletion(SessionImpl.java:2231)
	at org.hibernate.internal.SessionImpl.beforeTransactionCompletion(SessionImpl.java:1927)
	at org.hibernate.engine.jdbc.internal.JdbcCoordinatorImpl.beforeTransactionCompletion(JdbcCoordinatorImpl.java:439)
	at org.hibernate.resource.transaction.backend.jdbc.internal.JdbcResourceLocalTransactionCoordinatorImpl.beforeCompletionCallback(JdbcResourceLocalTransactionCoordinatorImpl.java:183)
	at org.hibernate.resource.transaction.backend.jdbc.internal.JdbcResourceLocalTransactionCoordinatorImpl$TransactionDriverControlImpl.commit(JdbcResourceLocalTransactionCoordinatorImpl.java:281)
	at org.hibernate.engine.transaction.internal.TransactionImpl.commit(TransactionImpl.java:101)
	at org.example.Hibernate567FinalDemoMain.loadProduct(Main.java:33)
	at org.example.Hibernate567FinalDemoMain.main(Main.java:19)
```