/*
 * Created on 2004-nov-25
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package se.im.optlock;

/**
 * @author behl
 * 
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public abstract class ClassA {

    /**
     * Unique identifier of the Entity; should not contain any business data.
     * Populated by Hibernate when the Entity is created, at transaction commit.
     */
    public Long ivOid;

    /**
     * Version id, used by Hibernate for optimistic locking control. Hibernate
     * use and updates this property, must never be altered from any other code.
     */
    private int ivVersion;

    private int ivNumberA;

    /**
     * @return Returns the oid.
     */
    public Long getOid() {
        return ivOid;
    }
    /**
     * @param pOid The oid to set.
     */
    public void setOid(Long pOid) {
        ivOid = pOid;
    }
    /**
     * @return Returns the version.
     */
    public int getVersion() {
        return ivVersion;
    }
    /**
     * @param pVersion The version to set.
     */
    public void setVersion(int pVersion) {
        ivVersion = pVersion;
    }

    /**
     * @return Returns the number.
     */
    public int getNumberA() {
        return ivNumberA;
    }

    /**
     * @param pNumber
     *            The number to set.
     */
    public void setNumberA(int pNumber) {
        ivNumberA = pNumber;
    }
}
