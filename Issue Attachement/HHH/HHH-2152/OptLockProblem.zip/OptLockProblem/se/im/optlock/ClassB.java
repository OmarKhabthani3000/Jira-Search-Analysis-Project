package se.im.optlock;

public class ClassB extends ClassA {

    private int ivNumberB;
    
    public ClassB() {
    }
    
    public ClassB(int pNumberA, int pNumberB) {
        setNumberA(pNumberA);
        setNumberB(pNumberB);
    }
    
    /**
     * @return Returns the number.
     */
    public int getNumberB() {
        return ivNumberB;
    }
    /**
     * @param pNumber The number to set.
     */
    public void setNumberB(int pNumber) {
        ivNumberB = pNumber;
    }
    
    public String toString() {
        return new String("ClassB, numberA= " + getNumberA() + ", numberB= " + getNumberB() +
                ", oid= " + getOid() + ", version= " + getVersion());
          
    }
}