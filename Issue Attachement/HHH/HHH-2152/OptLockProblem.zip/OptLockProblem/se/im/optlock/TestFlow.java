package se.im.optlock;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * @author pewn
 * 
 *  
 */
public class TestFlow extends Thread {
    static SessionFactory sessionFactory;
    static {
        try {
            sessionFactory = new Configuration().configure().buildSessionFactory();
        } catch (HibernateException he) {
            System.err.println("Error when initating Hibernate: " + he.getMessage());
            throw he;
        }
    }

    public static void main(String[] args) {
        
        TestFlow aTestFlow1 = new TestFlow();
        TestFlow aTestFlow2 = new TestFlow();

        // add an instance to db
        aTestFlow1.init();

        // run test flow
        aTestFlow1.start();
        aTestFlow2.start();
    }

    public void run() {
        Session tSession = null;
        // lock instance in db and update it
        try {
            tSession = sessionFactory.openSession();
            Transaction tTransaction = tSession.beginTransaction();
            
            Query tQuery = tSession.createQuery("from ClassB this where numberB=:aNumber");
            tQuery.setParameter("aNumber", new Integer(20));
            tQuery.setLockMode("this", LockMode.UPGRADE);
            List tList = tQuery.list();
            sleep(1000);
            if (!tList.isEmpty()) {
                ClassB tClassB = (ClassB) tList.get(0);
                System.out.println("Query result: " + tClassB);
                System.out.println("Updates numberA to: " + new Integer(tClassB.getNumberA() + 1));
                tClassB.setNumberA(tClassB.getNumberA() + 1);
            } else {
                System.out.println("Empty result set");
            }
            tTransaction.commit();
        } catch (Throwable e) {
            System.err.println("Error at runTestFlow: " + e.getMessage());
            e.printStackTrace();
        } finally {
            tSession.close();            
        }
    }

    private void init() {
        Session session = null;
        // create an instance of classB
        try {
            session = sessionFactory.openSession();
            Transaction tTransaction = session.beginTransaction();
            ClassB tClassB = new ClassB(10, 20);
            session.save(tClassB);
            tTransaction.commit();
        } catch (Throwable e) {
            System.err.println("Error at init: " + e.getMessage());
            e.printStackTrace();
        } finally {
            session.close();            
        }
    }
}
