package enverstest.hibernate;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Audited
@Table(name = "EMP")
public class AuditedEntity {

	@Id
	@GeneratedValue
	@SequenceGenerator(schema = "enverstest", name = "EMP_SEQ", allocationSize = 1)
	private long Id;

	@Column(name = "F_NAME")
	private String firstName = null;

	@Column(name = "L_NAME")
	private String lastName = null;

	@Column(name = "DOB")
	private Date dateOfBirth = null;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public long getId() {
		return Id;
	}

	public String toString() {
		return "[ID=" + Id + ", F_NAME=" + firstName + ", L_NAME=" + lastName
				+ ", DOB=" + dateOfBirth + "]";
	}

}
