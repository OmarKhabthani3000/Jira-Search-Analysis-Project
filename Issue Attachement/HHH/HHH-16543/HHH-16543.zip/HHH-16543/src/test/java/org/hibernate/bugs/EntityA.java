package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "ENTITY_A")
public class EntityA extends AbstractEntity {

}