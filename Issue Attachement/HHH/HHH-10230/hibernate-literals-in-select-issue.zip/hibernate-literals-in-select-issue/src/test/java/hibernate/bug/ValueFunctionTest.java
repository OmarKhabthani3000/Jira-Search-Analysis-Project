/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hibernate.bug;

import hibernate.bug.model.Workflow;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ValueFunctionTest {
    
    private EntityManagerFactory emf;
    private EntityManager em;
    
    @Before
    public void setup() {
        emf = Persistence.createEntityManagerFactory("Test");
        em = emf.createEntityManager();
        
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Workflow w1 = new Workflow("w1");

        em.persist(w1);
        
        tx.commit();
    }
    
    @After
    public void tearDown() {
        em.close();
        emf.close();
    }
    
    @Test
    public void testSelectLiterals() {
        List<Object[]> elements = em.createQuery("SELECT true, false, NULL, w.name FROM Workflow w", Object[].class).getResultList();
        Assert.assertEquals(1, elements.size());
    }
}
