CREATE USER hibernate LOGIN;
CREATE DATABASE hibernate WITH OWNER = hibernate;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO hibernate;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO hibernate;

CREATE TABLE seq_test
(
  id bigserial NOT NULL,
  some_data bigint NOT NULL,
  other_data character varying(128),
  PRIMARY KEY (id)
);

INSERT INTO seq_test(some_data, other_data) VALUES(13, 'Matt Smith'),
(5,'Peter Davison'),
(6,'Colin Baker'),
(15,NULL),
(4,'Tom Baker'),
(2,'Patrick Troughton'),
(1,'William Hartnell'),
(3,'Jon Pertwee'),
(7,'Sylvester McCoy'),
(8,'Paul McGann'),
(9,'John Hurt'),
(10,'Christopher Eccleston'),
(11,'David Tennant'),
(12,'David Tennant'), -- What an ego! Taking two regenerations
(14,'Peter Capaldi');
