package org.hibernate.bugs;

import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.persistence.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "testPU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void hhh10560Test() throws Exception {
		EntityManager em = entityManagerFactory.createEntityManager();
		em.getTransaction().begin();

		SeqTest st1 = new SeqTest();
		st1.setSomeData(Long.MIN_VALUE);
		st1.setOtherData("testing");
		em.persist(st1);

		SeqTest st2 = new SeqTest();
		st2.setSomeData(Long.MAX_VALUE);
		st2.setOtherData("testing");
		em.persist(st2);

		em.getTransaction().commit();
		em.close();
	}

	private static final Pattern nopattern = Pattern.compile("dalek", Pattern.CASE_INSENSITIVE);

	@Entity
	@Table(name = "seq_test")
	public class SeqTest implements Serializable {
		private static final long serialVersionUID = 1L;

		@Id
		@SequenceGenerator(name = "seq_test_gen", sequenceName = "seq_test_id_seq")
		@GeneratedValue(generator = "seq_test_gen")
		private Long id;

		@Column(name = "some_data")
		private Long someData;

		@Column(name = "other_data")
		private String otherData;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public Long getSomeData() {
			return someData;
		}

		public void setSomeData(Long someData) {
			this.someData = someData;
		}

		public String getOtherData() {
			return otherData;
		}

		public void setOtherData(String otherData) {
			this.otherData = otherData;
		}

		@PrePersist
		@PreUpdate
		public void validate() {
			if (otherData == null) {
				return;
			} 
			Matcher m = nopattern.matcher(otherData);
			if (m.find()) {
				throw new IllegalArgumentException("No daleks allowed!");
			}
		}
	}
}
