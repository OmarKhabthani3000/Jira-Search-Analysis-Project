package org.hibernate.test.timestampStateless;

import java.util.Date;

/**
 * {@inheritDoc}
 *
 * @author Steve Ebersole
 */
public class Order {
	private Long number;
	private Date placed;
	private Person orderee;

	public Order() {
	}

	public Order(Long number, Person orderee) {
		this.number = number;
		this.orderee = orderee;
		this.placed = new Date();
	}

	public Long getNumber() {
		return number;
	}

	public void setNumber(Long number) {
		this.number = number;
	}

	public Date getPlaced() {
		return placed;
	}

	public void setPlaced(Date placed) {
		this.placed = placed;
	}

	public Person getOrderee() {
		return orderee;
	}

	public void setOrderee(Person orderee) {
		this.orderee = orderee;
	}
}
