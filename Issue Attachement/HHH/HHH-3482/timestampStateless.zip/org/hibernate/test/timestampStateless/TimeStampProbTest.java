package org.hibernate.test.timestampStateless;

import junit.framework.Test;

import org.hibernate.StatelessSession;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;

public class TimeStampProbTest extends FunctionalTestCase {
	public TimeStampProbTest(String name) {
		super( name );
	}

	public String[] getMappings() {
		return new String[] { "timestampStateless/Mapping.hbm.xml" };
	}

	public static Test suite() {
		return new FunctionalTestClassTestSuite( TimeStampProbTest.class );
	}

	public void testTimeStampTest() {
		StatelessSession s = getSessions().openStatelessSession();
		s.beginTransaction();
		Person p = new Person( new Long(1), "steve", 123 );
		s.insert(p);
		Order o = new Order( new Long(1), p );
		s.insert(o);
		s.getTransaction().commit();
		s.close();
	}
}
