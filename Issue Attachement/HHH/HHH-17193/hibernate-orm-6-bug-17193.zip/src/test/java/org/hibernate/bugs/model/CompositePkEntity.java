package org.hibernate.bugs.model;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import java.util.Objects;

@Entity
@Table(name = "composite_pk_entity")
public class CompositePkEntity {

    @EmbeddedId
    private CompositePkEntityKey id;

    @Column(name = "some_value")
    private String someValue;

    public CompositePkEntity(CompositePkEntityKey id, String someValue) {
        this.id = id;
        this.someValue = someValue;
    }

    public CompositePkEntity() {
    }

    public CompositePkEntityKey getId() {
        return id;
    }

    public void setId(CompositePkEntityKey id) {
        this.id = id;
    }

    public String getSomeValue() {
        return someValue;
    }

    public void setSomeValue(String someValue) {
        this.someValue = someValue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CompositePkEntity that = (CompositePkEntity) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "CompositePkEntity{" +
                "id=" + id +
                ", someValue=" + someValue +
                '}';
    }
}
