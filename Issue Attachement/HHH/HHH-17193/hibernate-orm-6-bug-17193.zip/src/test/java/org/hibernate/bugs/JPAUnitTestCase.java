package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.hibernate.bugs.model.CompositePkEntity;
import org.hibernate.bugs.model.CompositePkEntityKey;
import org.hibernate.bugs.model.SomeChildEntity;
import org.hibernate.bugs.model.SomeEntity;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;

public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    /**
     * Populate DB with initial test data.
     */
    private void populate(EntityManager em) {
        SomeEntity someEntity = new SomeEntity(1L, Collections.emptyList());
        em.persist(someEntity);

        SomeChildEntity child1 = new SomeChildEntity(1L, someEntity);
        em.persist(child1);
        SomeChildEntity child2 = new SomeChildEntity(2L, someEntity);
        em.persist(child2);

        CompositePkEntityKey compositeId = new CompositePkEntityKey(someEntity, "value");
        CompositePkEntity compositePkEntity = new CompositePkEntity(compositeId, "initial-value");
        em.persist(compositePkEntity);

        em.flush();
        em.clear();
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    public void hhh17193Test() {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        populate(em);

        SomeEntity someEntity = em.find(SomeEntity.class, 1L);

        CompositePkEntityKey compositeId = new CompositePkEntityKey(someEntity, "value");
        CompositePkEntity compositePkEntity = new CompositePkEntity(compositeId, "new-value");

        // As it happens in JpaRepository#save()
        em.merge(compositePkEntity);

        em.flush();
        em.clear();
        em.getTransaction().commit();
        em.close();
    }
}
