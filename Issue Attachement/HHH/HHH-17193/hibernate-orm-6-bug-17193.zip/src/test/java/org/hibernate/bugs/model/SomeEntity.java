package org.hibernate.bugs.model;

import jakarta.persistence.*;

import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "some_entity")
public class SomeEntity {

    @Id
    private Long id;

    @OneToMany(mappedBy = "someEntity", cascade = {CascadeType.ALL})
    private List<SomeChildEntity> childEntities;

    public SomeEntity(Long id, List<SomeChildEntity> childEntities) {
        this.id = id;
        this.childEntities = childEntities;
    }

    public SomeEntity() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SomeEntity that = (SomeEntity) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "SomeEntity{" +
                "id=" + id +
                ", childEntities=" + childEntities +
                '}';
    }
}
