package org.hibernate.bugs.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import java.util.Objects;

@Embeddable
public class CompositePkEntityKey {

    @ManyToOne(optional = false)
    @JoinColumn(name = "some_entity_id", nullable = false)
    private SomeEntity someEntity;

    @Column(name = "some_pk_value", nullable = false)
    private String somePkValue;

    public CompositePkEntityKey(SomeEntity someEntity, String somePkValue) {
        this.someEntity = someEntity;
        this.somePkValue = somePkValue;
    }

    public CompositePkEntityKey() {
    }

    public SomeEntity getSomeEntity() {
        return someEntity;
    }

    public void setSomeEntity(SomeEntity someEntity) {
        this.someEntity = someEntity;
    }

    public String getSomePkValue() {
        return somePkValue;
    }

    public void setSomePkValue(String somePkValue) {
        this.somePkValue = somePkValue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CompositePkEntityKey that = (CompositePkEntityKey) o;
        return Objects.equals(someEntity, that.someEntity) && Objects.equals(somePkValue, that.somePkValue);
    }

    @Override
    public int hashCode() {
        return Objects.hash(someEntity, somePkValue);
    }

    @Override
    public String toString() {
        return "CompositePkEntityKey{" +
                "someEntity=" + someEntity +
                ", somePkValue=" + somePkValue +
                '}';
    }
}
