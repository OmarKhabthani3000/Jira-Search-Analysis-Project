package eu.pinske.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.Test;

import eu.pinske.model.SomeEntity;
import eu.pinske.model.Thing;

public class ThingTest {

    @Test
    public void test() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        Thing thing = new Thing();
        em.persist(thing);

        SomeEntity entity = new SomeEntity();
        entity.getThings();
        em.persist(entity);
        entity.getChildren();
        entity.getThings().add(thing);

        em.flush();
        em.getTransaction().commit();
        em.clear();
        em.close();

        emf.close();
    }

}
