package eu.pinske.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

@Entity
public class SomeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private long version;

    @Temporal(TemporalType.TIMESTAMP)
    private Date lastChangedAt;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "parent")
    private Set<SomeEntity> children;

    @ManyToOne(fetch = FetchType.LAZY)
    private SomeEntity parent;

    @ManyToMany(fetch = FetchType.LAZY)
    private Set<Thing> things;

    public Long getId() {
        return this.id;
    }

    @PreUpdate
    protected void onPreUpdate() {
        lastChangedAt = new Date();
    }

    public Date getLastChangedAt() {
        return lastChangedAt;
    }

    public Set<SomeEntity> getChildren() {
        if (children == null) {
            children = new HashSet<SomeEntity>();
        }
        return children;
    }

    public SomeEntity getParent() {
        return parent;
    }

    public void setParent(SomeEntity parent) {
        this.parent = parent;
    }

    public Set<Thing> getThings() {
        if (things == null) {
            things = new HashSet<Thing>();
        }
        return things;
    }

}
