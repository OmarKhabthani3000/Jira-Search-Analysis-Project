package de.di.hibernate.tests;

public class Subclass2 extends RootClass2
{
  private int _age;

  public int getAge()
  {
    return _age;
  }

  public void setAge(int age)
  {
    _age = age;
  }
}
