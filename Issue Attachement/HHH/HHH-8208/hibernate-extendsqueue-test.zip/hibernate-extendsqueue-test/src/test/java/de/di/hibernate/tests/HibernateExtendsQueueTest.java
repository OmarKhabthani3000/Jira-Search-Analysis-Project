package de.di.hibernate.tests;

import org.hibernate.cfg.Configuration;
import org.junit.Test;

public class HibernateExtendsQueueTest
{
  @Test
  public void rootClassesBeforeSubclasses() throws Exception
  {
    new Configuration()
        .configure("/hibernate.cfg.xml")
        .addInputStream(getClass().getResourceAsStream("/RootClasses.hbm.xml"))
        .addInputStream(getClass().getResourceAsStream("/Subclasses.hbm.xml"))
        .buildSessionFactory()
        .close();
  }

  @Test
  public void subclassesBeforeRootClasses() throws Exception
  {
    new Configuration()
        .configure("/hibernate.cfg.xml")
        .addInputStream(getClass().getResourceAsStream("/Subclasses.hbm.xml"))
        .addInputStream(getClass().getResourceAsStream("/RootClasses.hbm.xml"))
        .buildSessionFactory()
        .close();
  }
}
