package de.di.hibernate.tests;

public class Subclass1 extends RootClass1
{
  private int _age;

  public int getAge()
  {
    return _age;
  }

  public void setAge(int age)
  {
    _age = age;
  }
}
