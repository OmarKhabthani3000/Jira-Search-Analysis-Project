package rh.test.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import rh.test.hibernate.entity.SubEntity;
import rh.test.hibernate.xml.SubXML;

public class JoinedSubclassTest {

  private static final SessionFactory sessionFactory = SessionFactoryFactory.build();
  private Session session;

  @Before
  public void openSession() {
    session = sessionFactory.openSession();
    session.beginTransaction();
  }

  @After
  public void closeSession() {
    session.flush();
    session.close();
  }

  @Test
  public void testXML() {
    SubXML subXML = new SubXML();
    session.persist(subXML);
    session.createCriteria(SubXML.class).add(Restrictions.idEq(subXML.getId())).uniqueResult();
  }

  @Test
  public void testEntity() {
    SubEntity subEntity = new SubEntity();
    session.persist(subEntity);
    session.createCriteria(SubEntity.class).add(Restrictions.idEq(subEntity.getId())).uniqueResult();
  }

}