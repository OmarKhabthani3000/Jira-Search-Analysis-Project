package rh.test.hibernate;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.HSQLDialect;
import org.hsqldb.jdbc.JDBCDriver;
import rh.test.hibernate.entity.ParentEntity;
import rh.test.hibernate.entity.SubEntity;
import rh.test.hibernate.entity.SubSubEntity;

public class SessionFactoryFactory {

  static SessionFactory build() {
    Configuration configuration = new Configuration();

    configuration.addFile(ClassLoader.getSystemResource("mapping.hbm.xml").getFile());
    configuration.addAnnotatedClass(ParentEntity.class);
    configuration.addAnnotatedClass(SubEntity.class);
    configuration.addAnnotatedClass(SubSubEntity.class);

    configuration.setProperty(Environment.URL, "jdbc:hsqldb:mem:test");
    configuration.setProperty(Environment.DRIVER, JDBCDriver.class.getName());
    configuration.setProperty(Environment.USER, "sa");
    configuration.setProperty(Environment.PASS, "");
    configuration.setProperty(Environment.DIALECT, HSQLDialect.class.getName());
    configuration.setProperty(Environment.HBM2DDL_AUTO, "create");
    configuration.setProperty(Environment.SHOW_SQL, "true");

    SessionFactory sessionFactory = configuration.buildSessionFactory();

    return sessionFactory;

  }

}
