package rh.test.hibernate.xml;

public class SubSubXML extends SubXML {
}
