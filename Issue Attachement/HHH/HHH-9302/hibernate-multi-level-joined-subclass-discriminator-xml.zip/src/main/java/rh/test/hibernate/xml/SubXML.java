package rh.test.hibernate.xml;

public class SubXML extends ParentXML {
}
