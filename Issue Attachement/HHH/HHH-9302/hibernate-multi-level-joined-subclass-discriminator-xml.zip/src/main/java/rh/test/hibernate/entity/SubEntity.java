package rh.test.hibernate.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("SUB")
public class SubEntity extends ParentEntity {
}
