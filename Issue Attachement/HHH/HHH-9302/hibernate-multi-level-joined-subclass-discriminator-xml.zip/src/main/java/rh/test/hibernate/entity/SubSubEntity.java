package rh.test.hibernate.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("SUB-SUB")
public class SubSubEntity extends SubEntity {
}
