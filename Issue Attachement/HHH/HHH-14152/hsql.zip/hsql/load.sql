/*
 *  (C) Copyright Thales 2020
 *  This computer program includes confidential, proprietary information
 *  and is a trade secret of Thales. All use, disclosure, or reproduction
 *  is prohibited unless authorized in writing by an officer of Thales.
 *  All Rights Reserved.
 */
SET AUTOCOMMIT FALSE;
SET DATABASE REFERENTIAL INTEGRITY FALSE;
INSERT INTO RESOURCES
VALUES (1, 1, 'IssuerImpl', NULL, NULL, 'BIPlatform', 'https://localhost:8443/biw/platform/simulator/manager',
        CURRENT_TIMESTAMP, NULL,  NULL,
        CURRENT_TIMESTAMP, NULL, NULL,
        NULL, NULL, 0);
INSERT INTO ISSUERS VALUES (1, 1, 'BIPlatform', NULL, NULL);
INSERT INTO RESOURCES
VALUES (1, '7ff2e1bb-e3a3-451d-bf0a-c5652abda7b5', 'NotificationTaskImpl', NULL, NULL, 'NotificationTask', NULL,
        CURRENT_TIMESTAMP, NULL, NULL,
        CURRENT_TIMESTAMP, NULL, NULL,
        NULL, NULL, 0);
INSERT INTO COLLECTIONS VALUES (1, 1, 1, '7ff2e1bb-e3a3-451d-bf0a-c5652abda7b5');
--INSERT INTO COLLECTIONS VALUES (1, 1, 1, '7ff2e1bb-e3a3-451d-bf0a-c5652abda7b5', 0);
INSERT INTO TASKS VALUES (1, '7ff2e1bb-e3a3-451d-bf0a-c5652abda7b5', 5, 'MINUTES', 1000, 100, 'DISABLED');
INSERT INTO RESOURCES
VALUES (1, '8efdd3d9-7c6c-45b3-97ba-f32f5a5541c7', 'ImportTaskImpl', NULL, NULL, 'ImportTask', NULL,
        CURRENT_TIMESTAMP, NULL, NULL,
        CURRENT_TIMESTAMP, NULL, NULL,
        NULL, NULL, 0);
INSERT INTO TASKS VALUES (1, '8efdd3d9-7c6c-45b3-97ba-f32f5a5541c7', 5, 'MINUTES', 1000, 100, 'DISABLED');
INSERT INTO COLLECTIONS VALUES (1, 1, 1, '8efdd3d9-7c6c-45b3-97ba-f32f5a5541c7');
-- INSERT INTO COLLECTIONS VALUES (1, 1, 1, '8efdd3d9-7c6c-45b3-97ba-f32f5a5541c7', 0);
INSERT INTO RESOURCES
VALUES (1, '8df2e1bb-e3a3-451d-bf0a-c5652abda8b5', 'FaceTaskImpl', NULL, NULL, 'FaceTask', NULL,
        CURRENT_TIMESTAMP, NULL, NULL,
        CURRENT_TIMESTAMP, NULL, NULL,
        NULL, NULL, 0);
INSERT INTO TASKS VALUES (1, '8df2e1bb-e3a3-451d-bf0a-c5652abda8b5', 1, 'MINUTES', 1000, 100, 'DISABLED');
INSERT INTO COLLECTIONS VALUES (1, 1, 1, '8df2e1bb-e3a3-451d-bf0a-c5652abda8b5');
-- INSERT INTO COLLECTIONS VALUES (1, 1, 1, '8df2e1bb-e3a3-451d-bf0a-c5652abda8b5', 0);
INSERT INTO RESOURCES
VALUES (1, '8df2e1bb-e3a3-451d-bf0a-c5652abda8b6', 'TenprintTaskImpl', NULL, NULL, 'TenprintTask', NULL,
        CURRENT_TIMESTAMP, NULL, NULL,
        CURRENT_TIMESTAMP, NULL, NULL,
        NULL,
        NULL,
        0);
INSERT INTO TASKS VALUES (1, '8df2e1bb-e3a3-451d-bf0a-c5652abda8b6', 1, 'MINUTES', 1000, 100, 'DISABLED');
INSERT INTO COLLECTIONS VALUES (1, 1, 1, '8df2e1bb-e3a3-451d-bf0a-c5652abda8b6');
-- 	INSERT INTO COLLECTIONS VALUES (@ISSUER, @IDENTIFIER, @ISSUER, '8df2e1bb-e3a3-451d-bf0a-c5652abda8b6', 0;
SET DATABASE REFERENTIAL INTEGRITY TRUE;
COMMIT;
