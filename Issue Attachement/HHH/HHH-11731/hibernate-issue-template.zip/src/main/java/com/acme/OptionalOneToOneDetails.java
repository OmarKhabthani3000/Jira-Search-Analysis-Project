package com.acme;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyToOne;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import java.util.Collection;

import static javax.persistence.FetchType.LAZY;
import static org.hibernate.annotations.LazyToOneOption.NO_PROXY;

@Entity(name = "OptionalOneToOneDetails")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OptionalOneToOneDetails {

  @Id
  private Long id;

  private String something;

  @Column(name = "parts_as_str", nullable = false)
  @Convert(converter = PartsConverter.class)
  private Collection<Part> parts;

  @OneToOne(fetch = LAZY)
  @MapsId
  @JoinColumn(name = "id")
  @LazyToOne(NO_PROXY)
  private Post post;

}
