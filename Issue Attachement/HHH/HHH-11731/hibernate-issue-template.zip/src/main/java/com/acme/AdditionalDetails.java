package com.acme;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;

@Entity(name = "AdditionalDetails")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdditionalDetails {

  @Id
  private Long id;

  private String details;

  @OneToOne(optional = false)
  @MapsId
  @JoinColumn(name = "id")
//  @LazyToOne(NO_PROXY)
  private Post post;

}
