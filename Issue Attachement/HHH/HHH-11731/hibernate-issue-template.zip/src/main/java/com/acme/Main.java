package com.acme;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.HashSet;
import java.util.Set;

import static org.hibernate.Hibernate.initialize;

public class Main {
  private static final SessionFactory ourSessionFactory;

  static {
    try {
      ourSessionFactory = new Configuration().
          configure("hibernate.cfg.xml").
          buildSessionFactory();
    } catch (Throwable ex) {
      throw new ExceptionInInitializerError(ex);
    }
  }

  public static Session newSession() throws HibernateException {
    return ourSessionFactory.openSession();
  }

  public static void main(final String[] args) throws Exception {
    long postId;
    long anotherPostId;

    Session session = newSession();
    try {
      session.beginTransaction();
      Post post = new Post();

      Set<Tag> tags = new HashSet<>();
      tags.add(Tag.builder().name("tag1").build());
      tags.add(Tag.builder().name("tag2").build());
      post.setTags(tags);

      AdditionalDetails details =
          AdditionalDetails.builder().details("Some data").post(post).build();
      post.setAdditionalDetails(details);

      postId = (Long) session.save(post);
      session.getTransaction().commit();
    } finally {
      session.close();
    }

    session = newSession();
    try {
      session.beginTransaction();
      Query query = session.createQuery("from AdditionalDetails where id=" + postId);
      AdditionalDetails additionalDetails = (AdditionalDetails) query.getSingleResult();
      additionalDetails.setDetails("New data");
      session.persist(additionalDetails);
      session.getTransaction().commit();
    } finally {
      session.close();
    }

    session = newSession();
    try {
      session.beginTransaction();
      Query query = session.createQuery("from Post where id=" + postId);
      Post retrievedPost = (Post) query.getSingleResult();
      if (retrievedPost.getTags().size() != 0) {
        retrievedPost.getTags().forEach(tag -> System.out.println("Found tag: " + tag));
      } else {
        System.out.println("No tags found");
      }
      initialize(retrievedPost.getAdditionalDetails());
    } finally {
      session.close();
    }

    ourSessionFactory.close();
  }

}
