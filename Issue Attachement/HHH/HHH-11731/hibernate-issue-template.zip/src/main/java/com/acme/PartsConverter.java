package com.acme;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.util.Arrays;
import java.util.Collection;

import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

@Converter(autoApply = true)
public class PartsConverter implements AttributeConverter<Collection<Part>, String> {
  @Override
  public String convertToDatabaseColumn(Collection<Part> parts) {
    if (parts != null) {
      return parts.stream().map(Part::getValue).collect(joining(","));
    }
    return null;
  }

  @Override
  public Collection<Part> convertToEntityAttribute(String serialized) {
    if (serialized != null) {
      return Arrays.asList(serialized.split(",")).stream().map(v -> Part.builder().value(v).build())
          .collect(toList());
    }
    return null;
  }
}
