package com.acme;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyToOne;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import java.util.Set;

import static javax.persistence.CascadeType.ALL;
import static javax.persistence.FetchType.LAZY;
import static org.hibernate.annotations.LazyToOneOption.NO_PROXY;

@Entity(name = "Post")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Post {

  @Id
  @GeneratedValue
  private Long id;

  @ManyToMany(cascade = ALL)
  @JoinTable(name = "PostTag",
             joinColumns = {@JoinColumn(name = "post_id", referencedColumnName = "id")},
             inverseJoinColumns = {
                 @JoinColumn(name = "tag_id", referencedColumnName = "id")})
  private Set<Tag> tags;

  @OneToOne(fetch = LAZY, mappedBy = "post", cascade = ALL)
  @LazyToOne(NO_PROXY)
  private AdditionalDetails additionalDetails;

  @OneToOne(fetch = LAZY, mappedBy = "post", cascade = ALL)
  @LazyToOne(NO_PROXY)
  private OptionalOneToOneDetails oneToOneDetails;

}
