package net.kernevez.hibernate.entity.bugHibernate;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.NaturalId;

import java.io.Serializable;

@Entity
@Table(name = "CURRENCY")
// Serializable because of : https://hibernate.atlassian.net/browse/HHH-7668
public class CurrencyEntity implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_CURRENCY")
    @SequenceGenerator(name = "SEQ_CURRENCY", sequenceName = "SEQ_CURRENCY", allocationSize = 1)
    private Long id;

    @NaturalId
    @NotNull
    private String isoCode;

    public String getIsoCode() {
        return isoCode;
    }
}
