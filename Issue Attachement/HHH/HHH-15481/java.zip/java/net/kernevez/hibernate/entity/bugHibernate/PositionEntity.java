package net.kernevez.hibernate.entity.bugHibernate;

import jakarta.persistence.*;

@Entity
@Table(name = "POSITION")
public class PositionEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_POSITION")
    @SequenceGenerator(name = "SEQ_POSITION", sequenceName = "SEQ_POSITION", allocationSize = 1)
    private Long id;

    @Embedded
    private Amount netAmount;

}
