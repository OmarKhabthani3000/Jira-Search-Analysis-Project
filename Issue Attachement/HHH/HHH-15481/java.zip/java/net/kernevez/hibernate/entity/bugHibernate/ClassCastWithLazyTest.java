package net.kernevez.hibernate.entity.bugHibernate;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.transaction.Transactional;
import org.hibernate.SessionFactory;
import org.hibernate.stat.Statistics;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

@ExtendWith(SpringExtension.class)
@DataJpaTest
@Transactional
class ClassCastWithLazyTest {

    @Autowired
    private EntityManager em;

    @Autowired
    private PositionRepository sut;

    @Autowired
    private EntityManagerFactory entityManagerFactory;

    @BeforeEach
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @AfterEach
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    void testSelectARangeOfPositionWithEagerOrLazy() {
        // Given
        SessionFactory sessionFactory = entityManagerFactory.unwrap(SessionFactory.class);
        Statistics stats = sessionFactory.getStatistics();
        stats.clear();
        em.clear();

        // When => failed with java.lang.ClassCastException:
        // class org.hibernate.sql.results.graph.embeddable.internal.EmbeddableFetchInitializer cannot be cast to
        // class org.hibernate.sql.results.graph.entity.AbstractEntityInitializer
        // (org.hibernate.sql.results.graph.embeddable.internal.EmbeddableFetchInitializer and org.hibernate.sql.results.graph.entity.AbstractEntityInitializer are in unnamed module of loader 'app')
        List<PositionEntity> positions = sut.findAllByIdIn(List.of(1L, 2L, 3L, 4L));

    }
}
