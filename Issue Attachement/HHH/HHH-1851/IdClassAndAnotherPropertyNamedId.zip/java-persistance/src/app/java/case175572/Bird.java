package case175572;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.List;

import javax.persistence.*;

/**
 * test
 * 
 * @generated
 */

@IdClass(_BirdPK.class)
@Entity
@Table(name = "Bird")
public class Bird  implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 * @generated
	 */
	private String id;
	/**
	 * 
	 * @generated
	 */
	@Id
	@Column(name = "firstName")
	private String firstName;
	/**
	 * 
	 * @generated
	 */
	@Id
	@Column(name = "lastName")
	private String lastName;

	/**
	 *  
	 * @generated
	 */
	public void setid(String id) {
		this.id = id;
	}

	/**
	 *  
	 * @generated
	 */
	public String getid() {
		if (id == null) {
			id = null;
		}

		return this.id;
	}

	/**
	 *  
	 * @generated
	 */
	public void setfirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 *  
	 * @generated
	 */
	public String getfirstName() {
		return this.firstName;
	}

	/**
	 *  
	 * @generated
	 */
	public void setlastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 *  
	 * @generated
	 */
	public String getlastName() {
		return this.lastName;
	}

	/**
	 * 
	 * @generated
	 */
	//@OneToMany(mappedBy = "hostBird", cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH }, fetch = FetchType.LAZY)
	@Transient
	private List<Wing> wings = new java.util.ArrayList<Wing>();

	/**
	 *  
	 * @generated
	 */
	public void setwings(List<Wing> wings) {
		this.wings = wings;
	}

	/**
	 *  
	 * @generated
	 */
	public List<Wing> getwings() {
		return this.wings;
	}





}

