package case175572;

import java.io.Serializable;

/**
 * 
 * @generated
 */
public class _BirdPK implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * @generated
	 */
	public _BirdPK() {
	}

	/**
	 * @generated
	 */
	private String firstName;
	/**
	 * @generated
	 */
	private String lastName;

	/**
	 *  
	 * @generated
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 *  
	 * @generated
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 *  
	 * @generated
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 *  
	 * @generated
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * @generated
	 */
	public int hashCode() {
		int hash = 5;
		if (firstName != null)
			hash = 31 * hash + firstName.hashCode();
		if (lastName != null)
			hash = 31 * hash + lastName.hashCode();
		return hash;
	}

	/**
	 * @generated
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof _BirdPK))
			return false;
		if (obj == null)
			return false;
		_BirdPK equalCheck = (_BirdPK) obj;
		if ((firstName == null && equalCheck.firstName != null) || (firstName != null && equalCheck.firstName == null))
			return false;
		if (firstName != null && !firstName.equals(equalCheck.firstName))
			return false;
		if ((lastName == null && equalCheck.lastName != null) || (lastName != null && equalCheck.lastName == null))
			return false;
		if (lastName != null && !lastName.equals(equalCheck.lastName))
			return false;
		return true;
	}

}
