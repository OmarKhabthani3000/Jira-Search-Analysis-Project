package pkg;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "class_b")
public class ClassB implements Serializable {

    private static final long serialVersionUID = -7351211870913401598L;

    @EmbeddedId
    private ClassBPK classBPK;

    public ClassBPK getClassBPK() {
        return classBPK;
    }

    public void setClassBPK(ClassBPK classBPK) {
        this.classBPK = classBPK;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((classBPK == null) ? 0 : classBPK.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ClassB other = (ClassB) obj;
        if (classBPK == null) {
            if (other.classBPK != null)
                return false;
        } else if (!classBPK.equals(other.classBPK))
            return false;
        return true;
    }

}
