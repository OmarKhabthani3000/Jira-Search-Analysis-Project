package pkg;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import junit.framework.TestCase;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Environment;
import org.hibernate.classic.Session;
import org.hibernate.dialect.HSQLDialect;

public class HibernateTest extends TestCase {

    private SessionFactory sessionFactory;

    @Override
    protected void setUp() throws Exception {
        AnnotationConfiguration configuration = new AnnotationConfiguration();
        configuration.setProperty(Environment.DRIVER, "org.hsqldb.jdbcDriver");
        configuration.setProperty(Environment.URL,
                "jdbc:hsqldb:mem:HibernateTest");
        configuration.setProperty(Environment.USER, "sa");
        configuration.setProperty(Environment.DIALECT, HSQLDialect.class
                .getName());
        configuration.setProperty(Environment.FORMAT_SQL, "true");
        configuration.setProperty(Environment.HBM2DDL_AUTO, "create-drop");
        configuration.addAnnotatedClass(ClassA.class);
        configuration.addAnnotatedClass(ClassB.class);

        sessionFactory = configuration.buildSessionFactory();
    }

    @Override
    protected void tearDown() throws Exception {
        sessionFactory.close();
    }

    public void testBug() throws Exception {
        Session session = sessionFactory.openSession();
        try {
            ClassA classA;
            Transaction transaction = session.beginTransaction();
            transaction.begin();
            try {
                classA = new ClassA();
                List<ClassB> children = new ArrayList<ClassB>();

                ClassB classB = new ClassB();
                ClassBPK pk = new ClassBPK();
                pk.setClassA(classA);
                pk.setName(UUID.randomUUID().toString());
                classB.setClassBPK(pk);

                children.add(classB);
                classA.setChildren(children);

                session.persist(classA);
            } catch (Exception e) {
                transaction.rollback();
                throw e;
            }
            transaction.commit();
            session.evict(classA);

            session.get(ClassA.class, classA.getId());
        } catch (Exception e) {
            session.close();
            throw e;
        }
    }
}
