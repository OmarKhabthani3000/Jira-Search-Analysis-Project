package com.mycompany.hbparentid;

import javax.annotation.Resource;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@TransactionConfiguration
public class ParentIdTest extends AbstractTransactionalJUnit4SpringContextTests {

	@Resource
	private SessionFactory sessionFactory;

	@Test
	public void testParentId() {
		Session session = sessionFactory.getCurrentSession();

		Son son = new Son();
		Parent1 parent1 = new Parent1();
		parent1.addChild(son);

		Parent2 parent2 = new Parent2();
		parent2.addChild(son);
		
		session.save(parent2);
		session.save(parent1);
	}

}
