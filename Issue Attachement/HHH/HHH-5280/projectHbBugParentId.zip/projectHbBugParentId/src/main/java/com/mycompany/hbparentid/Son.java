package com.mycompany.hbparentid;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Son extends PersistentBean {

	@ManyToOne(optional = false)
	@JoinColumn(name = "parent1_id", insertable = false, updatable = false, nullable = false)
	Parent1 parent1;

	@ManyToOne
	Parent2 parent2;

	public Son() {
	}

}
