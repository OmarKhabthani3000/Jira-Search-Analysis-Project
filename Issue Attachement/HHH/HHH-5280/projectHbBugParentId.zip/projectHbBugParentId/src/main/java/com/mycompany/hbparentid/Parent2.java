package com.mycompany.hbparentid;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
public class Parent2 extends PersistentBean {

	@OneToMany(mappedBy = "parent2")
	@Cascade({ CascadeType.SAVE_UPDATE })
	private List<Son> children2;

	public Parent2() {
		this.children2 = new ArrayList();
	}

	public void addChild(Son child) {
		this.children2.add(child);
		child.parent2 = this;
	}

}
