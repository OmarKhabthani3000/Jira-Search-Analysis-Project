package com.mycompany.hbparentid;

import java.io.Serializable;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class PersistentBean implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	public Long getId() {
		return id;
	}

	@Override
	public boolean equals(Object object) {
		if (object == null || !(this.getClass().isAssignableFrom(object.getClass()))) {
			return false;
		}
		PersistentBean other = (PersistentBean) object;
		if (this.id == null && other.id == null) {
			// les 2 entités n'ont pas encore été persistées : on s'appuie sur le equals de Object
			return super.equals(other);
		}

		if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
			return false;
		}
		return true;
	}

	@Override
	public int hashCode() {
		return (id == null ? super.hashCode() : id.intValue());
	}

	@Override
	public String toString() {
		return this.getClass().getName() + "[id=" + id + "]";
	}
}
