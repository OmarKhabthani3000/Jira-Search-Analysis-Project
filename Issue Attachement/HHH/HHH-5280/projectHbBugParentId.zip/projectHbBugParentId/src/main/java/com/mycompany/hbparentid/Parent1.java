package com.mycompany.hbparentid;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.IndexColumn;

@Entity
public class Parent1 extends PersistentBean {

	@Cascade({ CascadeType.SAVE_UPDATE })
	@IndexColumn(name = "idxParent1")
	@JoinColumn(name = "parent1_id", nullable = false)
	@OneToMany
	private List<Son> children1;

	public Parent1() {
		this.children1 = new ArrayList();
	}

	public void addChild(Son child) {
		this.children1.add(child);
		child.parent1 = this;
	}



}
