package org.hibernate.dialect.variant;

import org.hibernate.type.AbstractSingleColumnStandardBasicType;
import org.hibernate.type.MaterializedBlobType;
import org.hibernate.type.descriptor.java.PrimitiveByteArrayTypeDescriptor;

/**
 * Replacement for MaterializedBlobType which always uses the JDBC getBytes()/setBytes() calls.
 */
public class MateralizedVarBinaryBlobType extends AbstractSingleColumnStandardBasicType<byte[]> {
	public static final MateralizedVarBinaryBlobType INSTANCE = new MateralizedVarBinaryBlobType();
	
	public MateralizedVarBinaryBlobType() {
		super( VarBinaryBlobTypeDescriptor.INSTANCE, PrimitiveByteArrayTypeDescriptor.INSTANCE );
	}

	public String getName() {
		return MaterializedBlobType.INSTANCE.getName();
	}
}
