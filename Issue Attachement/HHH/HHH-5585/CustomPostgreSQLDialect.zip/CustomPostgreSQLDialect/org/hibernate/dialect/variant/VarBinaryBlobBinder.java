package org.hibernate.dialect.variant;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.hibernate.type.descriptor.ValueBinder;
import org.hibernate.type.descriptor.WrapperOptions;
import org.hibernate.type.descriptor.java.JavaTypeDescriptor;
import org.hibernate.type.descriptor.sql.SqlTypeDescriptor;

/**
 * Needed only because bind() is final in BasicBinder.
 * 
 * @author jsands
 */
public class VarBinaryBlobBinder<J> implements ValueBinder<J> {
	private final JavaTypeDescriptor<J> javaDescriptor;
	private final SqlTypeDescriptor sqlDescriptor;
	
	public JavaTypeDescriptor<J> getJavaDescriptor() {
		return javaDescriptor;
	}

	public SqlTypeDescriptor getSqlDescriptor() {
		return sqlDescriptor;
	}

	public VarBinaryBlobBinder(JavaTypeDescriptor<J> javaDescriptor, SqlTypeDescriptor sqlDescriptor) {
		this.javaDescriptor = javaDescriptor;
		this.sqlDescriptor = sqlDescriptor;
	}
	
	/**
	 * Try to use setBytes() for all values.
	 */
	public final void bind(PreparedStatement st, J value, int index, WrapperOptions options) throws SQLException {
		if ( value == null || byte[].class.isInstance( value ) ) {
			// expected case, WrapperOptions are not applicable here
			st.setBytes(index, (byte[])value);
		}
		else {
			// not expected, at worst javaTypeDescriptor provies exception handling 
			st.setBytes( index, javaDescriptor.unwrap( value, byte[].class, options ) );
		}
	}
}
