package org.hibernate.dialect.variant;

import java.sql.Types;

import org.hibernate.dialect.PostgreSQLDialect;

public class PostgreSQLBinaryBlobDialect extends PostgreSQLDialect {

    public PostgreSQLBinaryBlobDialect() {
        super();
        
		registerColumnType( Types.BLOB, "bytea" );
    }
}
