package org.hibernate.dialect.variant;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.type.descriptor.ValueBinder;
import org.hibernate.type.descriptor.ValueExtractor;
import org.hibernate.type.descriptor.WrapperOptions;
import org.hibernate.type.descriptor.java.JavaTypeDescriptor;
import org.hibernate.type.descriptor.sql.BasicExtractor;
import org.hibernate.type.descriptor.sql.BlobTypeDescriptor;
import org.hibernate.type.descriptor.sql.SqlTypeDescriptor;

/**
 * Assumes all data is accessible using getBytes()/setBytes()
 * 
 * @author jsands
 */
public class VarBinaryBlobTypeDescriptor extends BlobTypeDescriptor implements SqlTypeDescriptor {
	public static final BlobTypeDescriptor INSTANCE = new VarBinaryBlobTypeDescriptor();
	
	public <X> ValueBinder<X> getBinder(final JavaTypeDescriptor<X> javaTypeDescriptor) {
		return new VarBinaryBlobBinder<X>(javaTypeDescriptor, this);
	}
	
	/**
	 * Assumes getBytes() 
	 */
	public <X> ValueExtractor<X> getExtractor(final JavaTypeDescriptor<X> javaTypeDescriptor) {
		return new BasicExtractor<X>( javaTypeDescriptor, this ) {
			@Override
			protected X doExtract(ResultSet rs, String name, WrapperOptions options) throws SQLException {
				return (X)rs.getBytes(name);
			}
		};
	}
}
