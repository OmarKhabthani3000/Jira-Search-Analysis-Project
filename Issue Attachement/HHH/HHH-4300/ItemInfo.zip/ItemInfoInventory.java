
package my.package.model;

import java.io.Serializable;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import org.hibernate.annotations.Where;

/**
 *
 * @author por
 */
@Entity
@DiscriminatorValue( "1" )
@Where( clause = "MYCONDITION" )
public class ItemInfoInventory extends ItemInfoBase implements Serializable
{
}
