
package my.package.model;

import java.io.Serializable;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import org.hibernate.annotations.Where;

/**
 *
 * @author por
 */
@Entity
@DiscriminatorValue( "0" )
@Where( clause = "MYCONDITION" )
public class ItemInfoPurchase extends ItemInfoBase implements Serializable
{
}
