package my.package.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import org.hibernate.annotations.Where;

/**
 *
 * @author por
 */
@Entity
@Table( name = "ITEMTABLE" )
@Inheritance( strategy = InheritanceType.SINGLE_TABLE )
@DiscriminatorColumn( name = "MODULETYPE",
                      discriminatorType = DiscriminatorType.INTEGER )
@Where( clause = "MYCONDITION" )
public abstract class ItemInfoBase implements Serializable
{
    private ItemInfoPrimaryKey      id;
    private Float                   quantity;

    public enum ModuleType {
        Inventory,
        Purchase,
        Sales,
        smmQuotation,
    };

    @EmbeddedId
    public ItemInfoPrimaryKey getId()
    {
        return ( id );
    }

    public void setId( ItemInfoPrimaryKey id )
    {
        this.id = id;
    }

    @Column( name = "QUANTITY" )
    public Float getQuantity()
    {
        return quantity;
    }

    public void setQuantity( Float quantity )
    {
        this.quantity = quantity;
    }
}
