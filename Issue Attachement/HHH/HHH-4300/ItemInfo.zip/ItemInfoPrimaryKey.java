
package my.package.model;

import my.package.model.ItemInfoBase.ModuleType;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import org.hibernate.annotations.Type;

/**
 *
 * @author por
 */
@Embeddable
public class ItemInfoPrimaryKey implements Serializable
{
    private String      itemId;
    private ModuleType  moduleType;

    @Type( type = "String" )
    @Column( name = "ITEMID" )
    public String getItemId()
    {
        return itemId;
    }

    public void setItemId( String itemId )
    {
        this.itemId = itemId;
    }

    @Column( name = "MODULETYPE", insertable = false, updatable = false )
    public ModuleType getModuleType()
    {
        return moduleType;
    }

    public void setModuleType( ModuleType moduleType )
    {
        this.moduleType = moduleType;
    }

    @Override
    public boolean equals( Object obj )
    {
        if ( obj == null )
            return false;
        if ( getClass() != obj.getClass() )
            return false;
        final ItemInfoPrimaryKey other = (ItemInfoPrimaryKey) obj;
        if ( ( this.itemId == null ) ? ( other.itemId != null ) : !this.itemId.equals( other.itemId ) )
            return false;
        if ( this.moduleType != other.moduleType )
            return false;
        return true;
    }

    @Override
    public int hashCode()
    {
        int hash = 5;
        hash = 43 * hash + ( this.itemId != null ? this.itemId.hashCode() : 0 );
        hash = 43 * hash + ( this.moduleType != null ? this.moduleType.hashCode() : 0 );
        return hash;
    }
}
