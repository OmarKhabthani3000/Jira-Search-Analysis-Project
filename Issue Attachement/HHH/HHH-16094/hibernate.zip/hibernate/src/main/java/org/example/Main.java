package org.example;

import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.tool.hbm2ddl.SchemaValidator;

import java.util.Map;

public class Main {
    public static void main(String[] args) {
        StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
                .applySettings(
                        Map.of(
                                "hibernate.connection.driver_class", "com.mysql.jdbc.Driver",
                                "hibernate.dialect", "org.hibernate.dialect.MySQL8Dialect",
                                "hibernate.connection.url", "jdbc:mysql://localhost/foodb",
                                "hibernate.connection.username", "admin",
                                "hibernate.connection.password", "admin",
                                "hibernate.default_schema", "foodb"
                        )
                )
                .build();

        Metadata metadata = new MetadataSources(serviceRegistry)
                .addAnnotatedClass(Foo.class)
                .buildMetadata();

        new SchemaValidator().validate(metadata, serviceRegistry);
    }
}