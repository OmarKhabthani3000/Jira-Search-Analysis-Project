package com.project;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.math.RandomUtils;
import org.hibernate.Filter;
import org.hibernate.Session;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.domain.Device;

/**
 *
 */
@Service
public class TxnHelper
{
    /** entity manager */
    @PersistenceContext
    protected EntityManager entityManager;
    
    
    /**
     * Returns a minimal device.
     * @return a minimal device.
     */
    @Transactional
    public Long makeDevice()
    {
        Device dev = new Device();
        dev.setSerialNumber(RandomStringUtils.randomAlphanumeric(6));
        boolean bUsed = RandomUtils.nextBoolean();
        dev.setUsed(bUsed);
        if (bUsed)
        {
            dev.setEndDate(new Date());
        }
        entityManager.persist(dev);
        entityManager.flush();
        return dev.getId();
    }
    
    /**
     * Finds a device
     * @param id
     * @return
     */
    @Transactional
    public Device findById(long id)
    {
        Device dev = entityManager.find(Device.class, id);
        return dev;
    }
    
    /**
     * @return
     */
    @Transactional
    public List<?> findAllUntyped()
    {
        Session session = entityManager.unwrap(Session.class);
        Filter filter = session.enableFilter("LOGICAL_DELETE");
        
        Query q = entityManager.createQuery("from " + Device.class.getSimpleName() + " x order by x.id desc");
        
        return q.getResultList();
    }
    
    /**
     * @return
     */
    @Transactional
    public List<Device> findAllTyped()
    {
        Session session = entityManager.unwrap(Session.class);
        session.enableFilter("LOGICAL_DELETE");

        TypedQuery<Device> tq = entityManager.createQuery("from " + Device.class.getSimpleName() + " x order by x.id asc", Device.class);
        
        return tq.getResultList();

    }
    
}
