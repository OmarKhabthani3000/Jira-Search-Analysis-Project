package org.hibernate.bugs;


import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class ContractpositionId implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "VERTRAG_ID", nullable = false)
	private Integer contractId;

	@Column(name = "POSITIONSNUMMER", nullable = false)
	private int positionNumber;

	public ContractpositionId() {
	    super();
	}

	public ContractpositionId(Integer contractId, int positionNumber) {
		this.contractId = contractId;
		this.positionNumber = positionNumber;
	}

	// *****************************************************************************************************************

	public boolean equals(Object other)
	{
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof ContractpositionId))
			return false;
		ContractpositionId castOther = (ContractpositionId) other;

		return (this.getContractId() == castOther.getContractId())
				&& (this.getPositionNumber() == castOther.getPositionNumber());
	}

	@Override
	public int hashCode() {
		return Objects.hash(contractId, positionNumber);
	}

	// *****************************************************************************************************************
	@Override
	public String toString() {
		return "ContractpositionId{" +
				"contractId=" + contractId +
				", positionNumber=" + positionNumber +
				'}';
	}

	public Integer getContractId() {
		return contractId;
	}

	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}

	public int getPositionNumber() {
		return positionNumber;
	}

	public void setPositionNumber(int positionNumber) {
		this.positionNumber = positionNumber;
	}
}
