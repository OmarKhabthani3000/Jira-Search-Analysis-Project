package org.hibernate.bugs;

import java.io.Serializable;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;

@Entity
public class Contractposition implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    @AttributeOverrides(
            {
                    @AttributeOverride(name = "contractId", column = @Column(name = "VERTRAG_ID", nullable = false)),
                    @AttributeOverride(name = "positionNumber", column = @Column(name = "POSITIONSNUMMER", nullable = false))})
    private ContractpositionId id;

    public ContractpositionId getId() {
        return id;
    }

    public void setId(ContractpositionId id) {
        this.id = id;
    }
}
