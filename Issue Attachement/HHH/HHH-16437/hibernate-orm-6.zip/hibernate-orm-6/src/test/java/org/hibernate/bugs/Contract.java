package org.hibernate.bugs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;


@Entity
public class Contract implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private Integer contractId;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "id.contractId")
    @OrderBy(value = "id.positionNumber")
    private List<Contractposition> contractpositions = new ArrayList<>();

    public Integer getContractId() {
        return contractId;
    }

    public void setContractId(Integer contractId) {
        this.contractId = contractId;
    }

    public List<Contractposition> getContractpositions() {
        return contractpositions;
    }

    public void setContractpositions(List<Contractposition> contractpositions) {
        this.contractpositions = contractpositions;
    }
}
