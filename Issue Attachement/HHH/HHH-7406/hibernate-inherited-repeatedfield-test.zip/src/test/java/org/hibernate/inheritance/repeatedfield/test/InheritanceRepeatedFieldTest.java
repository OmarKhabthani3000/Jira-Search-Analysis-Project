package org.hibernate.inheritance.repeatedfield.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import junit.framework.Assert;

import org.hibernate.inheritance.repeatedfield.entity.Country;
import org.hibernate.inheritance.repeatedfield.entity.Mountain;
import org.hibernate.inheritance.repeatedfield.entity.Place;
import org.hibernate.inheritance.repeatedfield.entity.Town;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class InheritanceRepeatedFieldTest {

	private EntityManagerFactory emf;
	private EntityManager em;
	
	@Before
	public void setUp() throws Exception {
		this.emf = Persistence.createEntityManagerFactory("PlaceTest");
		this.em = emf.createEntityManager();
	}

	@After
	public void tearDown() throws Exception {
		if (this.em != null) {
			this.em.close();
		}
		if (this.emf != null) {
			this.emf.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void inheritanceOrderByTest() {
		
		prepareData();
		
		String hql = "select pl from Place pl " +			
				" where pl.population > 1000";
		Query query = em.createQuery(hql);
		List<Place> places = query.getResultList();
		
		//Expected list of length 2. Expected London and Andorra
		Assert.assertEquals(2L, places.size());
		
		
	}
	
	private void prepareData() {
		//Create locality object	
    	Town town = new Town(1L, "London" , 5000000);
    	Country country = new Country(2L, "Andorra" , 10000);    
    	Mountain mountain = new Mountain(3L, "Mont Blanc", 4810);
		
		EntityTransaction tx = null;
		try {
			//Create transaction
		    tx = em.getTransaction();
		    tx.begin();
	    	    	
	    	//Persist entities
			em.persist(town);
			em.persist(country);
			em.persist(mountain);

			//Commit transaction
		    tx.commit();
		    								    		    
		} catch (RuntimeException e) {
		    if ( tx != null && tx.isActive() ) tx.rollback();
		    throw e; // or display error message
		}
		
		//clear entitymanager before loading
		em.clear();
	}
	
}
