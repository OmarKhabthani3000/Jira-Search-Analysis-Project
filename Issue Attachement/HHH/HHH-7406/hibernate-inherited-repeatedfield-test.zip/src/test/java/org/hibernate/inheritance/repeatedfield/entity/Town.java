package org.hibernate.inheritance.repeatedfield.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="TOWN")
@PrimaryKeyJoinColumn(name="PLACE_ID", referencedColumnName="PLACE_ID")
public class Town extends Place {

	@Column(name="NU_POPULATION")
	private Integer population;
	
	public Town() {};
	
	public Town(Long id, String name, Integer population) {
		super(id, name);
		this.population = population;
	}	

	public Integer getPopulation() {
		return population;
	}

	public void setPopulation(Integer population) {
		this.population = population;
	}

	
}
