package org.hibernate.inheritance.repeatedfield.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name="PLACE")
@Inheritance(strategy=InheritanceType.JOINED)
public abstract class Place {
	    
	protected Place() {}
	
	protected Place(Long id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	@Id
	@Column(name="PLACE_ID")
	private Long id;
	
	@Column(name="PLACE_NAME")
	private String name;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}