package org.hibernate.inheritance.repeatedfield.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="MOUNTAIN")
@PrimaryKeyJoinColumn(name="PLACE_ID", referencedColumnName="PLACE_ID")
public class Mountain extends Place {
	
	@Column(name="NU_HEIGHT")
	private Integer height;

	public Mountain() {};
	
	public Mountain(Long id, String name, Integer height) {
		super(id, name);
		this.height = height;
	}	
	
	public Integer getHeight() {
		return height;
	}

	public void setHeight(Integer height) {
		this.height = height;
	}

}
