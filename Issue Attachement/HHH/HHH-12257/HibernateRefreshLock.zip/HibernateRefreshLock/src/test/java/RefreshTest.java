import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.LockModeType;
import javax.persistence.Persistence;

import org.hibernate.cfg.AvailableSettings;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class RefreshTest {

    private EntityManager em;

    @Before
    public void testSetup() {

        Map<String, Object> properties = new HashMap<>();

        // Configure hibernate specific properties
        properties.put(AvailableSettings.SHOW_SQL, true);
        properties.put(AvailableSettings.FORMAT_SQL, false);
        properties.put(AvailableSettings.USE_SQL_COMMENTS, true);
        //properties.put(AvailableSettings.HBM2DDL_AUTO, Action.CREATE_DROP);
        properties.put(AvailableSettings.HBM2DDL_AUTO, "create-drop");

        properties.put(AvailableSettings.JPA_JDBC_DRIVER, "org.hsqldb.jdbcDriver");
        properties.put(AvailableSettings.JPA_JDBC_URL, "jdbc:hsqldb:mem:hibtest");
        properties.put(AvailableSettings.JPA_JDBC_USER, "");
        properties.put(AvailableSettings.JPA_JDBC_PASSWORD, "");

        // Load persistence unit from src/META-INF/persistence.xml
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("test", properties);
        em = emf.createEntityManager();
        em.getTransaction().begin();
    }

    @After
    public void testEnd() {
        em.getTransaction().rollback();
        em.close();
        em.getEntityManagerFactory().close();
    }

    @Test
    public void testLockModeAfterRefresh() {
        Integer customerId = null;

        {
            // Create a record in DB
            Customer customer = new Customer();
            customer.setCustomerName("John Doe");
            em.persist(customer);
            em.flush();
            customerId = customer.getCustomerId();
            em.clear();
        }

        {
            // Retrieve record with lock
            Customer customer = em.find(Customer.class, customerId, LockModeType.PESSIMISTIC_WRITE);
            Assert.assertNotNull(customer);
            Assert.assertEquals(LockModeType.PESSIMISTIC_WRITE, em.getLockMode(customer));

            em.refresh(customer);
            Assert.assertEquals(LockModeType.PESSIMISTIC_WRITE, em.getLockMode(customer));
        }
    }

}
