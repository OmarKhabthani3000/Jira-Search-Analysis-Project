import java.io.Serializable;

public class Address implements Serializable {

	private static final long serialVersionUID = 5612922591474923059L;

	public Address() {
	}
	
	private String address1;
	
	private String address2;
	
	private String address3;
	
	private int ID;
	
	private Customer customer;
	
	public void setAddress1(String value) {
		this.address1 = value;
	}
	
	public String getAddress1() {
		return address1;
	}
	
	public void setAddress2(String value) {
		this.address2 = value;
	}
	
	public String getAddress2() {
		return address2;
	}
	
	public void setAddress3(String value) {
		this.address3 = value;
	}
	
	public String getAddress3() {
		return address3;
	}
	
	public void setID(int value) {
		this.ID = value;
	}
	
	public int getID() {
		return ID;
	}
	
	public void setCustomer(Customer value) {
		this.customer = value;
	}
	
	public Customer getCustomer() {
		return customer;
	}
	
	public boolean equals(Object aObj) {
		if (aObj == this)
			return true;
		if (!(aObj instanceof Address))
			return false;
		Address address = (Address)aObj;
		if (getID() != address.getID())
			return false;
		if (getCustomer() == null && address.getCustomer() != null)
			return false;
		if (!getCustomer().equals(address.getCustomer()))
			return false;
		return true;
	}
	
	public int hashCode() {
		int hashcode = 0;
		hashcode = hashcode + (int) getID();
		if (getCustomer() != null) {
			hashcode = hashcode + (int) getCustomer().getID();
		}
		return hashcode;
	}
	
}
