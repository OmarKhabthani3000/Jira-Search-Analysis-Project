public class Customer {
	public Customer() {
	}
	
	private String firstname;
	
	private String lastname;
	
	private int ID;
	
	private Address address;
	
	public void setFirstname(String value) {
		this.firstname = value;
	}
	
	public String getFirstname() {
		return firstname;
	}
	
	public void setLastname(String value) {
		this.lastname = value;
	}
	
	public String getLastname() {
		return lastname;
	}
	
	public void setID(int value) {
		this.ID = value;
	}
	
	public int getID() {
		return ID;
	}
	
	public void setAddress(Address value) {
		this.address = value;
	}
	
	public Address getAddress() {
		return address;
	}
	
}
