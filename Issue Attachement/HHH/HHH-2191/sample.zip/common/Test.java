package common;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Property;

public class Test {
	public static void main(String[] args){
			
		try {
			//Creating Session
			SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
			Session session=sessionFactory.openSession();
			
			// Saving objects
			Group g=new Group();
			g.setName("The Group");
			session.save(g);
			Site s=new Site();
			s.setName("The Site");
			s.setGroup(g);
			session.save(s);
			
			//creating criteria
			DetachedCriteria c = DetachedCriteria.forClass(Site.class)
			//.add(Property.forName("name").eq("site"))
			.createCriteria("group")
			.add(Property.forName("name").eq("Group"));
			
			//executing criteria
			List l=c.getExecutableCriteria(session).list();
							
		} catch (Throwable ex) {
			ex.printStackTrace();
		};
	}
}
