package common;

public class Site {
    private String id;
    private String name;
    private Group  group;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public Group getGroup() {
        return group;
    }
    public void setGroup(Group group) {
        this.group = group;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return this.getName();
    }
}
