package org.hibernate.bugs.hhh16003;

/**
 * The transport mode of a land transport.
 */
public enum TransportMode {

    DOMESTIC, INTERNATIONAL;

}
