package org.hibernate.bugs.hhh16003;


public enum MasterDataImportStatus {

    CREATED,
    FAILED,
    SUCCESS;
}
