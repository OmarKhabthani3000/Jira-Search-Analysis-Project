package com.example;

import javax.persistence.*;


@Entity
public class Alias {

    private AliasId aliasId;
    private Person person;

    @EmbeddedId
    public AliasId getAliasId() {
        return aliasId;
    }

    public void setAliasId(AliasId aliasId) {
        this.aliasId = aliasId;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "personId", nullable = false)
    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }
}

