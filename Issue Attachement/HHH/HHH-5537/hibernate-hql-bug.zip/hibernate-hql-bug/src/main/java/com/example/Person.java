package com.example;

import org.hibernate.annotations.JoinColumnOrFormula;
import org.hibernate.annotations.JoinColumnsOrFormulas;
import org.hibernate.annotations.JoinFormula;

import javax.persistence.*;

@Entity
public class Person {


    private String id;
    private Alias bestCurrentAlias;

    @Id
    @Column(name = "personId")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    // The formula retrieves the firstId and secondId from the Alias table where personId is equal to the current person
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumnsOrFormulas({
            @JoinColumnOrFormula(formula =
                @JoinFormula(value = "(select a.firstId from Alias a where a.personId = personId)", referencedColumnName = "firstId")),
            @JoinColumnOrFormula(formula =
                @JoinFormula(value = "(select a.secondId from Alias a where a.personId = personId)", referencedColumnName = "secondId"))
    })
    public Alias getBestCurrentAlias() {
        return bestCurrentAlias;
    }

    public void setBestCurrentAlias(Alias bestCurrentAlias) {
        this.bestCurrentAlias = bestCurrentAlias;
    }
}