package com.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;


public class Tests {

    @Test
    public void testReportedBug() {
        Configuration config = new AnnotationConfiguration();
		config.configure();
		SessionFactory sessionFactory = config.buildSessionFactory();

        // populate some data
        Person person = new Person();
        person.setId("1");

        Session session = sessionFactory.openSession();
        session.save(person);
        session.flush();

        session = sessionFactory.openSession();
        AliasId aliasId = new AliasId();
        aliasId.setFirstId("first");
        aliasId.setSecondId("second");

        Alias alias = new Alias();
        alias.setAliasId(aliasId);
        alias.setPerson(person);  // Link this alias to the person

        session.save(alias);
        session.flush();

        Person p = (Person)session.get(Person.class, "1");
        assertNotNull(p.getBestCurrentAlias()); // This passes

        Person p2 = (Person) session.createQuery("from Person p where p.bestCurrentAlias.person.id = ?")
                .setParameter(0, "1")
                .uniqueResult();
        assertNotNull(p2.getBestCurrentAlias()); // This passes

        Person p3 = (Person)session.createQuery("from Person p where p.bestCurrentAlias.id.firstId = ?")
               .setParameter(0, "first")
               .uniqueResult();
        // NullPointerException is thrown during query
        assertNotNull(p3.getBestCurrentAlias());
    }
}
