import java.io.Serializable;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import xxx.hibernate.util.HibernateCallback;
import xxx.hibernate.util.HibernateUtil;


public class TestMultiTableDelete {

  public static void main(String[] args) {
    try {
      InMemoryServer.dbStartup();

      final Serializable id = HibernateUtil.execute(new HibernateCallback<Serializable>() {

        public Serializable doInTransaction(Session session, Transaction transaction) {

          Bean04 b04 = new Bean04();
          b04.setS1("s1");
          b04.setS2("s2");
          Serializable id = session.save(b04);

          System.out.println("b04.id: " + id);

          return id;
        }
      });

      Integer nRows = HibernateUtil.execute(new HibernateCallback<Integer>() {

        public Integer doInTransaction(Session session, Transaction transaction) {

          Query query;
          query = session.createQuery("" //
              + "delete from Bean04 a" //
              + " where a.id=:paramId" //
              + "" //
          );
          query.setParameter("paramId", id);
          return query.executeUpdate();
        }
      });

      System.out.println("nRows: " + nRows);

    } finally {
      HibernateUtil.getSessionFactory().close();
      InMemoryServer.dbShutdown();
    }

    System.out.println("Done.");
  }

}
