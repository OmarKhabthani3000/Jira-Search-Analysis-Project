package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.After;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");

        // Test fixture: just persist an arbitrary MyEntity object
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        MyEntity my = new MyEntity();
        my.setProp1("p1"); my.setProp2("p2");
        MyEmbedded comp = new MyEmbedded();
        comp.setValue1("v1"); comp.setValue2("v2");
        my.setComp(comp);
        entityManager.persist(my);
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    // This test succeeds, just to narrow the problem
    public void hhh11767Test1() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        Query q = entityManager.createQuery(
                "insert into MyEntity (prop1, prop2, comp) select prop1, prop2, comp from MyEntity");
        int insCnt = q.executeUpdate();
        assertEquals(1, insCnt); // because of the test fixture

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    @Test
    // This test fails in Hibernate 4 and 5
    public void hhh11767Test2() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        // The generated SQL contains parentheses around the parameter values, which is wrong
        // insert into MyEntity ( version, id, prop1, prop2, value1, value2 ) select ..., (?, ?) from MyEntity
        Query q = entityManager.createQuery(
                "insert into MyEntity (prop1, prop2, comp) select prop1, prop2, :comp from MyEntity");
        MyEmbedded comp = new MyEmbedded();
        comp.setValue1("val1");
        comp.setValue2("val2");
        q.setParameter("comp", comp);
        int insCnt = q.executeUpdate();
        assertEquals(1, insCnt); // because of the test fixture

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    @Test
    // This test fails in Hibernate 4 and 5
    public void hhh11767Test3() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        // Hibernate fails to deal with dereferencing embedded fields
        // org.hibernate.QueryException: could not resolve property:  of: org.hibernate.bugs.MyEntity ...
        // (Is valid JPQL/HQL?)
        Query q = entityManager.createQuery(
                "insert into MyEntity (prop1, prop2, comp.value1, comp.value2) "
              + "select prop1, prop2, :v1, :v2 from MyEntity");
        q.setParameter("v1", "val1");
        q.setParameter("v2", "val2");
        int insCnt = q.executeUpdate();
        assertEquals(1, insCnt); // because of the test fixture

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
