package org.hibernate.bugs;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "MyEntity")
public class MyEntity {
    @Id @GeneratedValue
    private Integer id;
    private String prop1;
    private String prop2;
    @Embedded
    private MyEmbedded comp;
    @Version
    private Integer version;

    public Integer getId() { return id; }
    public String getProp1() { return prop1; }
    public void setProp1(String prop1) { this.prop1 = prop1; }
    public String getProp2() { return prop2; }
    public void setProp2(String prop2) { this.prop2 = prop2; }
    public MyEmbedded getComp() { return comp;}
    public void setComp(MyEmbedded comp) { this.comp = comp; }
}
