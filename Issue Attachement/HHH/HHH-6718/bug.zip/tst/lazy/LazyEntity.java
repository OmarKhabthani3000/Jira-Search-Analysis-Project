package tst.lazy;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Version;

/**
 * Entity implementation class for Entity: MasterEntity
 * 
 */
@Entity
public class LazyEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	@Version
	private Long concurrency;


	protected LazyEntity() {
		super();

		id = java.util.UUID.randomUUID().toString();
	}

	public String getId() {
		return this.id;
	}

	public Long getConcurrency() {
		return this.concurrency;
	}
}
