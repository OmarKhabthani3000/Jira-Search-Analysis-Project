package tst.lazy;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Version;

/**
 * Entity implementation class for Entity: MasterEntity
 * 
 */
@Entity
public class ReferencedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	@Version
	private Long concurrency;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private LazyEntity lazyReference;


	public ReferencedEntity() {
		super();

		id = java.util.UUID.randomUUID().toString();
		lazyReference = new LazyEntity();
	}

	public String getId() {
		return this.id;
	}

	public Long getConcurrency() {
		return this.concurrency;
	}

	public LazyEntity getLazyReference() {
		return lazyReference;
	}


}
