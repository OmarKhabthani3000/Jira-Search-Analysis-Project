package tst.lazy;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestLazy {
	private static final Logger log = LoggerFactory.getLogger(TestLazy.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Map<String, String> configOverrides = new HashMap<String, String>();
		EntityManagerFactory emf;
		EntityManager em;
		EntityTransaction tx = null;

		configOverrides.put("hibernate.hbm2ddl.auto", "create");
		emf = Persistence.createEntityManagerFactory("HibernateLazy",
			configOverrides);


		String master_id;
		String ref_id;
		MasterEntity me;
		ReferencedEntity re;

		// create initial object hiehrarchy and store it in the DB
		log.trace("1. Create now initial object hierarchy and store it in the DB");
		em = emf.createEntityManager();
		try {
			tx = em.getTransaction();
			tx.begin();

			re = new ReferencedEntity();
			em.persist(re);

			me = new MasterEntity(re);
			em.persist(me);

			tx.commit();

			master_id = me.getId();
			ref_id = re.getId();
		}
		catch (RuntimeException e) {
			if (tx != null && tx.isActive())
				tx.rollback();
			throw e; // or display error message
		}
		finally {
			em.close();
		}


		// add new child to master entity
		log.trace("2. modify and merge detached master entity");
		em = emf.createEntityManager();
		try {
			tx = em.getTransaction();
			tx.begin();

			// re = em.find(ReferencedEntity.class, ref_id);
			me.setData("modified");
			em.merge(me);

			tx.commit();
		}
		catch (RuntimeException e) {
			if (tx != null && tx.isActive())
				tx.rollback();
			throw e; // or display error message
		}
		finally {
			em.close();
		}


		// load master entity from db
		log.trace("3. load master entitiy from db");
		em = emf.createEntityManager();
		try {
			me = em.find(MasterEntity.class, master_id);
		}
		catch (RuntimeException e) {
			throw e; // or display error message
		}
		finally {
			em.close();
		}


		emf.close();
	}
}
