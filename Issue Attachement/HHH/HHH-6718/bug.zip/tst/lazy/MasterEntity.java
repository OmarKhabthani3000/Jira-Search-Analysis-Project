package tst.lazy;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Version;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

/**
 * Entity implementation class for Entity: MasterEntity
 * 
 */
@Entity
public class MasterEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	@Version
	private Long concurrency;


	private String data;

	@OneToOne
	@Fetch(FetchMode.SELECT)
	private ReferencedEntity reference;


	protected MasterEntity() {
		super();
	}

	public MasterEntity(ReferencedEntity reference) {
		super();

		id = java.util.UUID.randomUUID().toString();
		this.reference = reference;
		this.data = "initial";
	}

	public String getId() {
		return this.id;
	}

	public Long getConcurrency() {
		return this.concurrency;
	}


	public ReferencedEntity getReference() {
		return reference;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
}
