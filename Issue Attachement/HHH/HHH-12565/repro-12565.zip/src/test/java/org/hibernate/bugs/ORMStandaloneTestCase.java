package org.hibernate.bugs;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.criteria.HibernateCriteriaBuilder;
import org.hibernate.query.criteria.JpaCriteriaQuery;
import org.hibernate.query.criteria.JpaRoot;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a standalone test case for Hibernate ORM.  Although this is perfectly
 * acceptable as a reproducer, usage of ORMUnitTestCase is preferred!
 */
public class ORMStandaloneTestCase {

	private SessionFactory sf;

	@Before
	public void setup() {
		StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
			// Add in any settings that are specific to your test. See resources/hibernate.properties for the defaults.
			.applySetting( "hibernate.show_sql", "true" )
			.applySetting( "hibernate.format_sql", "true" )
			.applySetting( "hibernate.hbm2ddl.auto", "update" );

		Metadata metadata = new MetadataSources( srb.build() )
		// Add your entities here.
			.addAnnotatedClass(Parent.class)
			.addAnnotatedClass(Father.class)
			.addAnnotatedClass(Mother.class)
			.buildMetadata();

		sf = metadata.buildSessionFactory();
	}

	// Add your tests, using standard JUnit.

	@Test
	public void hhh12565Test() throws Exception {
        HibernateCriteriaBuilder cb = sf.getCriteriaBuilder();
        JpaCriteriaQuery<Father> query = cb.createQuery(Father.class);
        JpaRoot<Father> root = query.from(Father.class);
        query.where(cb.equal(root.type(), Father.class));
        Session session = sf.openSession();
        Transaction transaction = session.beginTransaction();
        Father father = new Father();
        father.id = 42L;
        session.persist(father);
        session.flush();
        List<Father> result = session.createQuery(query).getResultList();
        Assert.assertEquals(result, List.of(father));
        transaction.rollback();
    }
}
