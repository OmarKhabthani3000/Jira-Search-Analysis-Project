package org.hibernate.bugs;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

@Entity(name = "Father")
public class Father extends Parent {
    @Column
    String fathersDay;
}
