package org.hibernate.bugs;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

@Entity(name = "Mother")
public class Mother extends Parent {

    @Column
    String mothersDay;
}

