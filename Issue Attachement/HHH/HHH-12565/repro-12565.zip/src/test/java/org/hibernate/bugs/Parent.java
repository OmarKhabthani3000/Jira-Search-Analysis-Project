package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;

@Entity(name = "Parent")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class Parent {

    @Id
    public Long id;

}
