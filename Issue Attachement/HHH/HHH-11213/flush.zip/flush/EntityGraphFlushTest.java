package org.hibernate.jpa.test.graphs.flush;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.jpa.QueryHints;
import org.hibernate.jpa.test.BaseEntityManagerFunctionalTestCase;
import org.hibernate.testing.TestForIssue;
import org.junit.Before;
import org.junit.Test;

/**
 * @author David Gofferje
 */
public class EntityGraphFlushTest extends BaseEntityManagerFunctionalTestCase {
	
	@Test
	@TestForIssue( jiraKey = "HHH-11213")
	public void testFlushOnEntityGraphHintedQuery() {
		EntityManager entityManager = getOrCreateEntityManager();
		entityManager.getTransaction().begin();
		
		Query query = entityManager.createQuery( "from " + Location.class.getName() );
		Location location = (Location)query.getSingleResult();

		// modify the address of the location
		location.address = "123 somewhereelse";

		EntityGraph<?> entityGraph = entityManager.getEntityGraph( "getCompany" );
		query = entityManager.createQuery( "from " + Company.class.getName()  );
		query.setHint( QueryHints.HINT_LOADGRAPH, entityGraph );

		List results = query.getResultList();
		
		Company companyResult = (Company)results.get( 0 );
		assertTrue( Hibernate.isInitialized( companyResult.location ) );
		
		assertTrue( companyResult.location.address.equals("123 somewhereelse"));
		
		Session session = entityManager.unwrap(Session.class);
		SQLQuery sqlQuery = session.createSQLQuery( "select * from Location l where l.address = '123 somewhereelse'" );
		assertEquals(1, sqlQuery.list().size());
		 
		entityManager.getTransaction().commit();
		entityManager.close();

	}
	
	@Before
	public void createData() {
		EntityManager entityManager = getOrCreateEntityManager();
		entityManager.getTransaction().begin();
			
		Location location = new Location();
		location.address = "123 somewhere";
		location.zip = 12345;
		entityManager.persist( location );
			
		Company company = new Company();
		company.location = location;

		entityManager.persist( company );
		
		entityManager.getTransaction().commit();
		entityManager.close();
	}

	@Override
	protected Class<?>[] getAnnotatedClasses() {
		return new Class<?>[] { Company.class, Location.class };
	}	
}
