package org.example;


import junit.framework.Assert;
import org.hibernate.HibernateException;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.persistence.EntityManagerFactory;
import java.util.List;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Hello world!
 */

@SpringBootTest
public class AppTest {

    @Autowired
    EntityManagerFactory factory;

    @Test
    public void test_whenUsingScroll_FailsWithLazyInitializationException_StartingWithHibernate5_3_11() throws HibernateException {
        //obtain session factory
        SessionFactory sessionFactory = factory.unwrap(SessionFactory.class);
        //open session
        Session session = sessionFactory.openSession();

        //Obtain students via ScrollableResults
        ScrollableResults scroll = session
                .createQuery("from org.example.Student")
                .scroll(ScrollMode.FORWARD_ONLY);
        ScrollableResultsIterator<Student> iterator = new ScrollableResultsIterator(scroll);
        Spliterator spliterator = Spliterators.spliteratorUnknownSize(iterator, 256);
        Stream<Student> stream = StreamSupport.stream(spliterator, false);
        List<Student> studentList = stream.collect(Collectors.toList());

        //close session
        session.close();

        //expecting to have at least 1 student at index 0
        Student student = studentList.get(0);

        //expecting to have a course with id 1
        Assert.assertEquals(1, student.getCourses().get(0).getId().intValue());
        //But what happens is that the following exception is thrown
        //org.hibernate.LazyInitializationException: failed to lazily initialize a collection of role: org.example.Student.courses, could not initialize proxy - no Session
    }

    @Test
    public void test_whenUsingList_WorksAsExpected_WithAnyHibernate5_3_11_plus() throws HibernateException {
        //obtain session factory
        SessionFactory sessionFactory = factory.unwrap(SessionFactory.class);
        //open session
        Session session = sessionFactory.openSession();

        //Obtain students via list()
        List<Student> studentList = session
                .createQuery("from org.example.Student")
                .list();
        //close session
        session.close();

        //expecting to have at least 1 student at index 0
        Student student = studentList.get(0);

        //expecting to have a course with id 1
        Assert.assertEquals(1, student.getCourses().get(0).getId().intValue());
    }
}
