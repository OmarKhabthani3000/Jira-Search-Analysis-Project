package org.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManagerFactory;

/**
 * Hello world!
 */

@SpringBootApplication
public class App {

    @Autowired
    CourseRepo courseRepo;
    @Autowired
    SudentRepo sudentRepo;

    @Autowired
    EntityManagerFactory factory;

    public static void main(String[] args) {
        try {
            SpringApplication.run(App.class, args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @PostConstruct
    public void init()  {
        sudentRepo.save(createStudentWithCourses(1, 1, 2));
        sudentRepo.save(createStudentWithCourses(2, 3, 4));
    }

    private static Student createStudentWithCourses(int studentId, int... coursesIds) {
        Student student = new Student();
        student.setStudentId(studentId);
        for(int courseId : coursesIds) {
            student.adCourse(new Course(courseId));
        }
        return student;
    }

}
