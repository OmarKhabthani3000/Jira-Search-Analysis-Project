package org.example;


import org.hibernate.ScrollableResults;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Closeable;
import java.io.IOException;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScrollableResultsIterator<T> implements Iterator<T>, Closeable {
    private static final Logger LOG = LoggerFactory.getLogger(ScrollableResultsIterator.class);

    private ScrollableResults sr;
    private AtomicBoolean open = new AtomicBoolean(true);

    public ScrollableResultsIterator(ScrollableResults sr) {
        this.sr = sr;
    }

    /**
     * ScrollableResults does not provide a hasNext method, implemented here for Iterator interface.
     */
    @Override
    @SuppressWarnings("unchecked")
    public boolean hasNext() {
        return sr.next();
    }

    @Override
    @SuppressWarnings("unchecked")
    public T next() {
        Object[] next = sr.get();
        if (next.length == 1) {
            return (T) next[0];
        } else {
            return (T) next;
        }
    }

    public void flush() {
    }

    /**
     * Unsupported Operation for this implementation.
     */
    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void close() throws IOException {
        if (open.compareAndSet(true, false)) {
            sr.close();
            flush();
        }
    }
}

