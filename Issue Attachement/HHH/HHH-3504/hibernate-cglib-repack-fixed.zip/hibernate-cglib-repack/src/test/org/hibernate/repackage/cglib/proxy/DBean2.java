package org.hibernate.repackage.cglib.proxy;

class DBean2 {
    public int getAge() {
        return 18;
    }
}
