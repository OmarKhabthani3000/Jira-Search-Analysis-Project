package org.hibernate.repackage.cglib.proxy;

public interface DI2 {
    public String derby();
}
