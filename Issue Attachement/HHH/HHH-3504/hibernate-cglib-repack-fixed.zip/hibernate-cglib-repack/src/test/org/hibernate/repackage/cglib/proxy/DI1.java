package org.hibernate.repackage.cglib.proxy;

public interface DI1 {
    public String herby();
}
