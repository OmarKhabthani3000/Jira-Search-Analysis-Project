package org.hibernate.bugs;

import java.sql.Statement;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class SelectBeforeUpdateTest extends TestCase {
	private static final String FOO_NAME = "foo";
	private static final String BAR_NAME = "bar";
	private SessionFactory sessionFactory;
	private Foo foo; 
	/**
	 * Test that we get an unnecessary update to the db even though the object 
	 * has not changed. 
	 * @throws Exception
	 */
    public void testUpdate() throws Exception {
   	
        sessionFactory = createSessionFactory();
        init();
        load();
        check();
        sessionFactory.close();
    }

    private void init() {
    	Session s = sessionFactory.openSession();
    	Transaction tx = s.beginTransaction();
    	try {
    		Statement insert = s.connection().createStatement();	
    		insert.execute("insert into v_bar(inf_obj_id, inf_version_no, name) values(1, 0, '"+BAR_NAME+"')"); 
    		insert.execute("insert into v_foo(inf_obj_id, inf_version_no, name, bar) values(1, 0, '"+FOO_NAME+"', 1)");
		} catch (Exception e) {
			fail("We don't expect an exception here!");
		}
    	tx.commit();
    	s.close();
	}

    private void load() {
    	Session s = sessionFactory.openSession();
		Transaction tx = s.beginTransaction();
	        foo = (Foo)s.load(Foo.class, 1l);
	        assertNotNull(foo);
	        assertEquals(1, foo.getId().intValue());
	        assertEquals(FOO_NAME, foo.getName());
	        assertEquals(0, foo.getVersion().intValue());
	        assertNotNull("bar was not loaded", foo.getBar());
	    tx.commit();
		s.close();
	}
    
    private void check() {
    	Session s = sessionFactory.openSession();
		Transaction tx = s.beginTransaction();
			assertEquals("The version number is NOT what we expect!",0, foo.getVersion().intValue());
	      	s.update(foo);
	      	s.flush();
	        assertEquals(1, foo.getId().intValue());
	        assertEquals(FOO_NAME, foo.getName());
	        assertNotNull("bar was not loaded", foo.getBar());
	        assertEquals("The version number has been updated and we did NOT change the object!",0, foo.getVersion().intValue());
	    tx.commit();
		s.close();
	}
    
    private SessionFactory createSessionFactory() {
        final Configuration cfg = new Configuration();
        cfg.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        cfg.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:updateTest");
        cfg.setProperty("hibernate.connection.username", "sa");
        cfg.setProperty("hibernate.connection.password", "");
        cfg.setProperty("hibernate.connection.pool_size", "20");
        cfg.setProperty("hibernate.hbm2ddl.auto", "create");
        cfg.setProperty("hibernate.cache.provider_class", "org.hibernate.cache.EhCacheProvider");
        cfg.setProperty("hibernate.show_sql", "true");
        cfg.addFile("Foo.hbm.xml");
        cfg.addFile("Bar.hbm.xml");
        return cfg.buildSessionFactory();
     }
}
