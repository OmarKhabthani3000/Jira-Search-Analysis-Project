package org.hibernate.bugs;

public class Bar {
	private Long id;
	private String name;
    private Integer infVersion;
    public void setVersion(Integer version) {
        this.infVersion = version;
    }
    public Integer getVersion() {
        return infVersion;
    }
    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setId(final Long id) {
        this.id = id;
    }
    
    public Long getId() {
        return id;
    }
}
