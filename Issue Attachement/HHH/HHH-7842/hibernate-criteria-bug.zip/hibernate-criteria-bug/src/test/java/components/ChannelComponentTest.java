package components;

import data.Channel;
import data.Program;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.util.Assert;

import java.util.List;
import java.util.Locale;

/**
 * @author dionis
 */
public class ChannelComponentTest {
    private ChannelComponent channelComponent;

    @Before
    public void setUp() throws Exception {
        Locale.setDefault(Locale.ENGLISH);
        System.setProperty("user.country", "en");
        System.setProperty("user.language", "en");
        ApplicationContext context = new ClassPathXmlApplicationContext("application-context.xml");
        channelComponent = context.getBean(ChannelComponent.class);

        ClassPathResource resource = new ClassPathResource("/initial_data.sql");
        final List<String> insertClauses = IOUtils.readLines(resource.getInputStream());
        TransactionTemplate transactionTemplate = context.getBean(TransactionTemplate.class);
        final JdbcTemplate jdbcTemplate = context.getBean(JdbcTemplate.class);
        transactionTemplate.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus transactionStatus) {
                int[] updateResults = jdbcTemplate.batchUpdate(insertClauses.toArray(new String[insertClauses.size()]));
                for (int updateResult : updateResults) {
                    Assert.isTrue(updateResult == 1);
                }
            }
        });
    }

    @Test
    public void channelShouldRespectFetchModeWithoutAliases() {
        List<Channel> channels = channelComponent.listAllChannelsByCriteriaWithoutAliases();
        for (Channel channel : channels) {
            for (Program program : channel.getPrograms()) {
                System.out.println(program.getContent());
            }
        }
    }

    @Test
    public void channelShouldRespectFetchModeWithAliases() {
        List<Channel> channels = channelComponent.listAllChannelsByCriteriaWithAliases();
        for (Channel channel : channels) {
            for (Program program : channel.getPrograms()) {
                System.out.println(program.getContent());
            }
        }
    }
}
