import components.ChannelComponent;
import data.Channel;
import data.Program;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;
import java.util.Locale;

/**
 * @author dionis
 */
public class Main {
    public static void main(String[] args) {
        Locale.setDefault(Locale.ENGLISH);
        System.setProperty("user.country","en");
        System.setProperty("user.language","en");
        ApplicationContext context = new ClassPathXmlApplicationContext("application-context.xml");
        ChannelComponent channelComponent = context.getBean(ChannelComponent.class);
//        System.out.println(channelComponent.listAllChannels());
//        System.out.println(channelComponent.listAllContacts());
        //channelComponent.playground();
        DetachedCriteria criteria = DetachedCriteria.forClass(Channel.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        criteria.setFetchMode("channelOffers", FetchMode.JOIN);
        criteria.setFetchMode("cos", FetchMode.JOIN);
        criteria.setFetchMode("order.cos", FetchMode.JOIN);
        criteria.createAlias("channelOffers", "cos", CriteriaSpecification.INNER_JOIN);
//        criteria.createAlias("channelOffers", "cos");
//        criteria.setFetchMode("channelOffers", FetchMode.JOIN);
        List<Channel> channels = channelComponent.listAllChannelsByCriteriaWithoutAliases();
        for (Channel channel : channels) {
            for (Program program : channel.getPrograms()) {
                System.out.println(program.getId()+" :: "+ program.getContent());
            }
        }
    }
}
