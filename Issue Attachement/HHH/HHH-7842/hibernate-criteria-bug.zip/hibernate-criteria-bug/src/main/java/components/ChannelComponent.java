package components;

import data.Channel;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author dionis
 */
@Transactional
@Service
public class ChannelComponent {
    @Autowired
    private HibernateTemplate hibernateTemplate;

    @SuppressWarnings("unchecked")
    public List<Channel> listAllChannelsByCriteriaWithoutAliases() {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Channel.class);
        detachedCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        detachedCriteria.setFetchMode("programs", FetchMode.JOIN);
        return hibernateTemplate.findByCriteria(detachedCriteria);
    }

    @SuppressWarnings("unchecked")
    public List<Channel> listAllChannelsByCriteriaWithAliases() {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Channel.class);
        detachedCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        detachedCriteria.createAlias("programs", "programs");
        detachedCriteria.setFetchMode("programs", FetchMode.JOIN);
        return hibernateTemplate.findByCriteria(detachedCriteria);
    }
}
