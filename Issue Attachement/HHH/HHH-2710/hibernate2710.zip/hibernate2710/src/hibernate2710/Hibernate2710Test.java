package hibernate2710;

import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Hibernate2710Test extends TestCase {

	private SessionFactory sessionFactory;

	@Override
	protected void setUp() throws Exception {
		sessionFactory = new Configuration().configure().buildSessionFactory();
	}

	@Override
	protected void tearDown() throws Exception {
		sessionFactory.close();
	}

	public void test2710() {
		Session session = sessionFactory.getCurrentSession();

		// create a document
		session.beginTransaction();
		Document doc = new Document();
		doc.getReferences().add("ref1");
		doc.getReferences().add("ref2");
		doc.getTitles().put("fr", "Mon titre");
		doc.getTitles().put("en", "My title");
		session.save(doc);
		session.getTransaction().commit();

		// bulk delete all created documents (we have only one but imagine we
		// have several thousand documents in the database)
		// this will throw a ConstraintViolationException here because we do not
		// set on-delete=cascade on the key of the map element and on the key of
		// the set element.
		// But if we set it, we got a MappingException : only inverse
		// one-to-many associations may use on-delete="cascade"
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		Query query = session.createQuery("delete from hibernate2710.Document");
		query.executeUpdate();
		session.getTransaction().commit();
	}

}