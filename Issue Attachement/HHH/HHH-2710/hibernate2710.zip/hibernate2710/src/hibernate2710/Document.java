package hibernate2710;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Document {

	private Long id;
	private Map titles = new HashMap();
	private Set references = new HashSet();
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Map getTitles() {
		return titles;
	}
	public void setTitles(Map titles) {
		this.titles = titles;
	}
	public Set getReferences() {
		return references;
	}
	public void setReferences(Set references) {
		this.references = references;
	}
	
}
