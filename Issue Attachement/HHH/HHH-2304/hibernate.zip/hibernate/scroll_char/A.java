package hibernate.scroll_char;

public class A
{
  protected long id;
  protected String a;
}
