package acmeco.model;

@javax.persistence.Entity(name = "EMPLOYEE")
public class Employee {
    private int id;
    private String firstName;
    private String lastName;
    private int salary;
    java.util.Set<String> projectCodes;

    public Employee() {}
    public Employee(int id, String fname, String lname, int salary, java.util.Set<String> projectCodes) {
        this.id = id;
        this.firstName = fname;
        this.lastName = lname;
        this.salary = salary;
        this.projectCodes = projectCodes;
    }

    @javax.persistence.Id
    @javax.persistence.Column(name = "ID")
    public int getId() {
        return id;
    }

    public void setId( int id ) {
        this.id = id;
    }

    @javax.persistence.Column(name = "FNAME")
    public String getFirstName() {
        return firstName;
    }


    public void setFirstName( String first_name ) {
        this.firstName = first_name;
    }

    @javax.persistence.Column(name = "LNAME")
    public String getLastName() {
        return lastName;
    }

    public void setLastName( String last_name ) {
        this.lastName = last_name;
    }

    @javax.persistence.Column(name = "SALARY")
    public int getSalary() {
        return salary;
    }


    @javax.persistence.ElementCollection(fetch = javax.persistence.FetchType.EAGER)
    @javax.persistence.CollectionTable(name = "EMP_CODE", joinColumns = @javax.persistence.JoinColumn(name = "EMPLOYEE_ID"))
    public java.util.Set<String> getProjectCodes() {
        return projectCodes;
    }

    public void setProjectCodes(java.util.Set<String> projectCodes) {
        this.projectCodes = projectCodes;
    }


    public void setSalary( int salary ) {
        this.salary = salary;
    }
}