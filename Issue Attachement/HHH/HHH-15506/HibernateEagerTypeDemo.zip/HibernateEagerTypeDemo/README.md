
#### Installation instructions ####


1. Download MySQL (8.0.28 or higher)

```
# for ubuntu
sudo apt-get install mysql-server
sudo service mysql start
```

2. Run the secure installation (below command gives option set to root password)

`sudo mysql_secure_installation`

4. Create database and user. In a terminal window,

```
sudo mysqladmin --user=root create acmeco

```

5. Give permissions to user on database
```
# create user and privileges
sudo mysql -u root

# in mysql session
CREATE USER 'acmeco'@'%' IDENTIFIED BY 'Acmeco1234#';
GRANT ALL PRIVILEGES ON acmeco.* TO 'acmeco'@'%';

# verify
SELECT user,host FROM mysql.user; SHOW GRANTS for acmeco;
exit

# optionally, check if you can login with the new user
mysql -u acmeco -p
```

6. Create tables and values
```
sudo mysql -u root < dbinit.sql
```

#### Test instructions ####

7. Run mvn package

8. Run the script: script/run.sh

#### To see a working version ####

Replace the pom.xml with the pom.xml.hibernate.5.3.10

Replace the src/main/assembly.xml with the assembly.xml.hibernate.5.3.10

Rerun steps 7 and 8 above.