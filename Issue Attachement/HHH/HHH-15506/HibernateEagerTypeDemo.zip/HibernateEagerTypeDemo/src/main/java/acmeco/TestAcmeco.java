package acmeco;

import acmeco.model.Part;
import acmeco.model.Widget;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;



public class TestAcmeco {

    public static void main(String[] args) {
		TestAcmeco myTest = new TestAcmeco();

        if (args.length > 0 ) {
            if ("--useSessionGet".equalsIgnoreCase(args[0])) {
                myTest.usingSessionGet();
                System.exit(0);
            }
        }

		myTest.usingScrollableResult();
	}


    /*
        using session.get is not an issue. Provided as an example.
     */
	public void usingSessionGet() {
        System.out.println("----- USING SESSION GET -----");

        Configuration cfg = new Configuration();

        cfg.configure(TestAcmeco.class.getResource("/hibernate.cfg.xml"));

        try (
            SessionFactory factory = cfg.buildSessionFactory();
            Session session = factory.openSession();
        ){
            Widget w = session.get(Widget.class, 5001L);
            System.out.println("widget.name: " + w.getName());
            System.out.println();

            session.close();
            factory.close();

            System.out.println("getParts() is not called yet, calling now...");
            for (Part p : w.getParts()) {
                System.out.println("p.getName: " + p.getName());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void usingScrollableResult() {
        System.out.println("----- USING SCROLLABLE RESULT -----");

        Configuration cfg = new Configuration();

        cfg.configure(TestAcmeco.class.getResource("/hibernate.cfg.xml"));


        try (
            SessionFactory factory = cfg.buildSessionFactory();
            Session session = factory.openSession();

             ScrollableResults scrollableResults = session.createQuery(
                "from WIDGET").scroll()
        ) {
            scrollableResults.next();
            Widget w = (Widget) scrollableResults.get()[0];
            System.out.println("widget.name: " + w.getName());
            System.out.println("");

            session.close();
            factory.close();

            System.out.println("getParts() is not called yet, calling now...");
            System.out.println();

            for (Part p : w.getParts()) {
                System.out.println("p.getName: " + p.getName());
            }
        } catch (Exception e ) {
            e.printStackTrace();
        }
    }
}
