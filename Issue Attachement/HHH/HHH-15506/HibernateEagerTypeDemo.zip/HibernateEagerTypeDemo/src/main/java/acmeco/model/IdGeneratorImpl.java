package acmeco.model;






import java.util.concurrent.atomic.AtomicLong;

@SuppressWarnings("deprecation")
public class IdGeneratorImpl implements IdGenerator {


    static AtomicLong count;

    @Override
    public synchronized Long getNextIdentifier(String domain) {




        return count.incrementAndGet();
    }

}
