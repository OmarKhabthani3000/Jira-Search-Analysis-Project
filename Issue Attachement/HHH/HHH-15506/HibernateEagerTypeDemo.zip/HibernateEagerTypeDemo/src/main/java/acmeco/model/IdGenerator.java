package acmeco.model;

public interface IdGenerator {

	public Long getNextIdentifier(String domain);

}
