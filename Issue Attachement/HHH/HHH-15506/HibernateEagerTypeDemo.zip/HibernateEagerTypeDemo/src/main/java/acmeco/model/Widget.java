package acmeco.model;




import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.annotations.*;
import org.jadira.usertype.dateandtime.joda.PersistentLocalDate;
import org.jadira.usertype.dateandtime.joda.PersistentLocalDateTime;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
import java.util.Set;

@Entity(name = "WIDGET")
@Access(AccessType.PROPERTY)
@TypeDefs({
        @TypeDef(name = "joda-localdate", typeClass = PersistentLocalDate.class),
        @TypeDef(name = "joda-localdatetime", typeClass = PersistentLocalDateTime.class)
})
public class Widget implements Serializable {
    private static final long serialVersionUID = 3073785123613802499L;

    private Long id;
    private String name;
    private Set<String> codes;
    private Set<Part> parts;
    private List<Long> orderedIdentifiers;
    private LocalDate createdDate;
    private LocalDateTime updatedTime;

    @Id

    @Column(name = "ID")
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    @Column(name = "WIDGET_NAME")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Fetch(value = FetchMode.SELECT)
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "WIDGET_CODE", joinColumns = @JoinColumn(name = "WIDGET_ID"))
    public Set<String> getCodes() {
        return codes;
    }

    public void setCodes(Set<String> codes) {
        this.codes = codes;
    }

    @Fetch(FetchMode.SELECT)
    @JoinColumn(name = "WIDGET_ID")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true, targetEntity = Part.class)
    public Set<Part> getParts() {
        return parts;
    }

    public void setParts(Set<Part> parts) {
        this.parts = parts;
    }

    @Fetch(value = FetchMode.SELECT)
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "WIDGET_ID_TABLE", joinColumns = @JoinColumn(name = "WIDGET_ID"))
    @OrderColumn(name = "IDENTIFIER_INDEX")
    @Column(name = "IDENTIFIER")
    public List<Long> getOrderedIdentifiers() {
        return orderedIdentifiers;
    }

    public void setOrderedIdentifiers(List<Long> orderedIdentifiers) {
        this.orderedIdentifiers = orderedIdentifiers;
    }

    @Column(name = "CREATED_DATE")
    @Type(type = "joda-localdate")
    public LocalDate getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDate createdDate) {
        this.createdDate = createdDate;
    }

    @Column(name = "UPDATED_TIME")
    @Type(type = "joda-localdatetime")
    public LocalDateTime getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(LocalDateTime updatedTime) {
        this.updatedTime = updatedTime;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }
}
