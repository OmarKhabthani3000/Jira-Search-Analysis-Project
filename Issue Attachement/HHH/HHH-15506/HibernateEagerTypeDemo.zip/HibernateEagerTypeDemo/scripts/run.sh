#!/usr/bin/env bash


set -x

SCRIPTS_DIR="`dirname \"$0\"`"
PROJ_DIR="`( cd \"$SCRIPTS_DIR/../\" && pwd )`"

CLASSPATH="$PROJ_DIR/target/HibernateEagerTypeDemo:$PROJ_DIR/target/HibernateEagerTypeDemo/lib/*"


java -cp "$CLASSPATH" acmeco.TestAcmeco "$@"
