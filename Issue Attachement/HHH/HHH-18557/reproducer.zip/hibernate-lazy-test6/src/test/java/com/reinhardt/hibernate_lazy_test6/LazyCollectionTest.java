package com.reinhardt.hibernate_lazy_test6;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.stat.Statistics;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.reinhardt.hibernate_lazy_test6.db.Component;
import com.reinhardt.hibernate_lazy_test6.db.Operation;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

@SuppressWarnings("nls")
public class LazyCollectionTest {

    private Session psession;
    private Long opId;
    private Long comp2Id;

    private EntityManagerFactory emf;
    private Transaction transaction;

    @BeforeEach
    public void before() throws Exception {
        emf = Persistence.createEntityManagerFactory("HibernateLazyTest_Unmanaged");
        psession = emf.createEntityManager().unwrap(Session.class);
        transaction = psession.beginTransaction();

        Component comp1 = new Component("comp1");
        psession.persist(comp1);

        Component comp2 = new Component("comp2");
        psession.persist(comp2);
        comp2Id = comp2.getId();

        Operation op1 = new Operation(comp1, "10");
        psession.persist(op1);

        opId = op1.getId();

        psession.flush();
        psession.clear();
    }

    @AfterEach
    public void after() throws Exception {
        transaction.rollback();
    }

    @Test
    public void shouldNotFetchLazyCollection() throws Exception {
        Statistics statistics = psession.getSessionFactory().getStatistics();
        statistics.setStatisticsEnabled(true);

        Operation op = psession.get(Operation.class, opId);
        Component comp2 = psession.get(Component.class, comp2Id);

        statistics.clear();

        op.setComponent(comp2);

        psession.persist(op);
        psession.flush();

        statistics.logSummary();

        Assertions.assertEquals(1, statistics.getEntityUpdateCount());
        Assertions.assertEquals(0, statistics.getCollectionFetchCount());
    }
}
