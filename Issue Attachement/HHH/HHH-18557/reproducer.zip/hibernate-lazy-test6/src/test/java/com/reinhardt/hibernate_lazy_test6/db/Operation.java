package com.reinhardt.hibernate_lazy_test6.db;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "`Operation`")
public class Operation implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue
    @Column(name = "`Id`", nullable = false)
    private Long id;

    @Column(name = "`Name`", nullable = false, length = 255)
    private String name;

    @ManyToOne(targetEntity = Component.class, fetch = FetchType.LAZY)
    @JoinColumns({ @JoinColumn(name = "`ComponentId`", referencedColumnName = "`Id`", nullable = false) })
    private Component component;

    public Operation() {
    }

    public Operation(final Component component, final String name) {
        this.name = name;
        this.component = component;
    }

    public Long getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public Component getComponent() {
        return component;
    }

    public void setComponent(final Component component) {
        this.component = component;
    }

    @Override
    public String toString() {
        return String.valueOf(getId());
    }
}
