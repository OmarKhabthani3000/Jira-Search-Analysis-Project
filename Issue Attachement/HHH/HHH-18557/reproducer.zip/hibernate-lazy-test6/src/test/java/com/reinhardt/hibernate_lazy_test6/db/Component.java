package com.reinhardt.hibernate_lazy_test6.db;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "`Component`")
public class Component implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue
    @Column(name = "`Id`", nullable = false)
    private Long id;

    @Column(name = "`Name`", nullable = false, length = 255)
    private String name;

    @OneToMany(mappedBy = "component", targetEntity = Operation.class, fetch = FetchType.LAZY)
    private java.util.Set<Operation> operations = new java.util.HashSet<>();

    public Component() {
    }

    public Component(final String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public java.util.Set<Operation> getOperations() {
        return operations;
    }

    @Override
    public String toString() {
        return String.valueOf(getId());
    }
}
