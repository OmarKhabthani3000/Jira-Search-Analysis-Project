package hibernateBugHHH5078TestCase;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class HHH5078Test {

	@PersistenceContext(unitName = "testPersistenceUnit")
	private EntityManager em;
	
	@Test
	public void testJpaCriteriaApiQuoteAndDiff() {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Number> query = cb.createQuery(Number.class);
		query.from(SystemUser.class); // entity type doesn't matter, but must contain at least one entry for this test case. 
		query.select( // (2 - 1) / 2
				cb.quot(
						cb.diff(
								cb.literal(BigDecimal.valueOf(2.0)), 
								cb.literal(BigDecimal.valueOf(1.0))), 
						BigDecimal.valueOf(2.0))).distinct(true);

		Number result = em.createQuery(query).getSingleResult();
		assertEquals(0.5d, result.doubleValue(), 0.1d); // (2 - 1) / 2 = 0.5
	}
	

}
