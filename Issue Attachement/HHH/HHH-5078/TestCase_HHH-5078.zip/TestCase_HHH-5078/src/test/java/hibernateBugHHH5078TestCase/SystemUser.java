package hibernateBugHHH5078TestCase;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the SYSTEM_USERS database table.
 * 
 */
@Entity
@Table(name="SYSTEM_USERS", schema = "INFORMATION_SCHEMA")
public class SystemUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column
	private boolean admin;
	
	@Id
	@Column
	private String user;

    public SystemUser() {
    }

	public boolean getAdmin() {
		return this.admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public String getUser() {
		return this.user;
	}

	public void setUser(String user) {
		this.user = user;
	}

}