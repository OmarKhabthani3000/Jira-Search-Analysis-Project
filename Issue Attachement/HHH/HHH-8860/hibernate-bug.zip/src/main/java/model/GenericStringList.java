package model;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;

@Embeddable
public class GenericStringList {

    @OneToMany(fetch = FetchType.LAZY)
    public List<String> stringList = new LinkedList<>();
}
