package model;

import java.util.Map;
import java.util.TreeMap;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.MapKeyColumn;
import javax.persistence.Version;

@Entity
public class Data {

    @Version
    private Integer version;

    public Data() {
    }

    @Id
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @ElementCollection(fetch = FetchType.LAZY)
    @MapKeyColumn(name = "key")
    private Map<String, GenericStringList> stringlist = new TreeMap<>();

}
