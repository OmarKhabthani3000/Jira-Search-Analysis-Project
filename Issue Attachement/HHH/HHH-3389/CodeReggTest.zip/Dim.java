package myPackage;


public final class Dim {
	private Long id;

	private String name;

	public Dim(final String name) {
		this.name = name;
	}

	/**
	 * For Hibernate purposes.
	 */
	private Dim() {

	}
}
