package myPackage;

import org.apache.commons.lang.Validate;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public final class Codee {
	private Long id;

	private String code;

	private Dim parent;

	public Codee(final Dim parent, final String code) {
		this.parent = parent;
		setCode(code);
	}

	/**
	 * For Hibernate purposes.
	 */
	private Codee() {

	}

	public Dim getParent() {
		return parent;
	}

	public void setParent(final Dim parent) {
		this.parent = parent;
	}

	public String getCode() {
		return code;
	}

	public void setCode(final String code) {
		if (code != null) {
			Validate.notEmpty(code, "code must not be empty");
		}
		this.code = code;
	}

	@Override
	public boolean equals(final Object obj) {
		if (obj == this) {
			return true;
		}

		if (obj instanceof Codee) {
			Codee other = (Codee) obj;
			return new EqualsBuilder().appendSuper(super.equals(obj)).append(getCode(), other.getCode()).isEquals();
		}

		return false;
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().appendSuper(super.hashCode()).append(getCode()).toHashCode();
	}
}
