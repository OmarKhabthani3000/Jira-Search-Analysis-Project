package myPackage;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.junit.Test;

public class CodeReggInsertTest {
	@Test
	public void store() throws Exception {
		Session session = getMySession();
		Long dimensionId = 1L;
		String queryString = "INSERT INTO Regg (index, matchValue) "
		                + "SELECT (SELECT cast(count(*) - 1 as int) FROM Codee c2 "
		                + "WHERE c2.parent.id = c1.parent.id AND c2.id <= c1.id), c1.code " + "FROM Codee c1 "
		                + "WHERE c1.parent.id = :DIM_ID";
		Query q = session.createQuery(queryString);
		q.setParameter("DIM_ID", dimensionId, Hibernate.LONG);
		q.executeUpdate();
		session.close();
	}

	private Session getMySession() {
		return null;
	}
}
