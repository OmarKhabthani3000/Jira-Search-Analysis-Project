package myPackage;


public class Regg {

	private Long id;
	private String matchValue;

	private int index;

	private Regg() {
	}

	public Regg(String matchValue) {
		this.matchValue = matchValue;
	}

    public int getIndex() {
    	return index;
    }

    public void setIndex(int index) {
    	this.index = index;
    }
}
