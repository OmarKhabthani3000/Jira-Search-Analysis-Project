package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Tuple;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Stream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static org.assertj.core.api.Assertions.assertThat;
import org.hibernate.Session;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private static final Logger LOGGER = LogManager.getLogger();
	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void test() throws Exception {
		try(EntityManager entityManager = entityManagerFactory.createEntityManager()) {
			entityManager.getTransaction().begin();
			//given
			persistData(entityManager);
			var cb = entityManager.unwrap(Session.class).getCriteriaBuilder();
			var query = cb.createTupleQuery();
			var root = query.from(Primary.class);
			query.multiselect(
					root.get("id").alias("id"),
					cb.diff(
							cb.coalesce(root.get("componentA").get("income"), BigDecimal.ZERO),
							cb.coalesce(root.get("componentA").get("expense"), BigDecimal.ZERO)
					).alias("sum")
			);
			var result = entityManager.createQuery(query).getResultList();
			assertThat(result).hasSize(3);
			Iterator<Tuple> tupleIt = result.iterator();
			Tuple tuple = tupleIt.next();
			assertThat(tuple.get("id", Integer.class)).isEqualTo(1);
			assertThat(tuple.get("sum", BigDecimal.class)).isEqualByComparingTo("10");

			tuple = tupleIt.next();
			assertThat(tuple.get("id", Integer.class)).isEqualTo(2);
			assertThat(tuple.get("sum", BigDecimal.class)).isEqualByComparingTo("-5");

			tuple = tupleIt.next();
			assertThat(tuple.get("id", Integer.class)).isEqualTo(3);
			assertThat(tuple.get("sum", BigDecimal.class)).isEqualByComparingTo("7");
		} catch (Throwable t) {
			LOGGER.error(t.getMessage(), t);
			throw t;
		}
	}

	private void persistData(EntityManager em) {
		Stream.of(
				createPrimary(1, 10, null),
				createPrimary(2, null, 5),
				createPrimary(3, 15, 8)
		).forEach(em::persist);
		em.flush();
		em.clear();
	}

	private Primary createPrimary(int id, Integer income, Integer expense) {
		Function<Integer, BigDecimal> amountFactory = x -> Objects.nonNull(x) ? BigDecimal.valueOf(x) : null;
		ComponentA componentA = new ComponentA();
		componentA.setIncome(amountFactory.apply(income));
		componentA.setExpense(amountFactory.apply(expense));
		var entity = new Primary();
		entity.setId(id);
		entity.setComponentA(componentA);
		return entity;
	}
}
