/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package org.hibernate.bugs;

import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.util.Objects;

@Entity
@Table(schema = "public", name = "d_primary")
public class Primary  {

    @Id
    private Integer id;
    @Embedded
    private ComponentA componentA;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public ComponentA getComponentA() {
        return componentA;
    }

    public void setComponentA(ComponentA componentA) {
        this.componentA = componentA;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Primary primary = (Primary) o;
        return Objects.equals(id, primary.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }
}
