import java.util.Iterator;

import org.hibernate.cfg.Configuration;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.RootClass;

public class ClassTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.addFile("res/B.hbm.xml");
		cfg.addFile("res/C.hbm.xml");
		cfg.addFile("res/A.hbm.xml");
		cfg.buildMappings();
		Iterator iter = cfg.getClassMappings();
		while(iter.hasNext()){
			System.out.println(((PersistentClass)iter.next()).getClassName());
		}

	}

}
