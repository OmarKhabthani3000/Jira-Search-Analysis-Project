package me.chanjar;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Example testcase for Hibernate Search
 */
public class HqlSearchTest {

	private EntityManagerFactory emf;

	private EntityManager em;

	private static Logger log = LoggerFactory.getLogger( HqlSearchTest.class );

	@Before
	public void setUp() {
		initHibernate();
	}

	@After
	public void tearDown() {
		purge();
	}

	@Test
	public void testSearch() throws Exception {
//	Query query1 = em.createQuery("select p from Price p");
//	List price1 = query1.getResultList();
//	Assert.assertEquals(4, price1.size());
//		 
	TypedQuery<Price> query = em.createQuery("select p from Price p where p.status =?1 and locate(?2,concat(concat(?3,p.bustype),?4))-1 >= ?5", Price.class);
    
    query.setParameter(1, Boolean.TRUE);
    query.setParameter(2, ",B401,");
    query.setParameter(3, ",");
    query.setParameter(4, ",");
    query.setParameter(5, 0);
    
    List<Price> result = query.getResultList();
	for(Price p : result){
		System.out.println(p.getBustype());
	}
    Assert.assertEquals(3, result.size());
  }


	private void initHibernate() {
		emf = Persistence.createEntityManagerFactory( "hibernate-search-example" );
		em = emf.createEntityManager();
	}

	private void purge() {
    em.close();
		emf.close();
	}

}
