package com.test;

import javax.persistence.*;

@Entity
public class Entity2 {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ENTITY2_SEQ")
	@SequenceGenerator(name = "ENTITY2_SEQ")
	private Long id;


	public Long getId()
	{
		return id;
	}
}
