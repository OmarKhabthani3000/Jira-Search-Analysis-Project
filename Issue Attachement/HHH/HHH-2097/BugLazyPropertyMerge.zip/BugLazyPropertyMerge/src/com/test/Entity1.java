package com.test;

import javax.persistence.*;

@Entity
public class Entity1 {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ENTITY1_SEQ")
	@SequenceGenerator(name = "ENTITY1_SEQ")
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	private Entity2 e2;


	public Entity2 getE2()
	{
		return e2;
	}


	public void setE2(Entity2 e2)
	{
		this.e2 = e2;
	}


	public Long getId()
	{
		return id;
	}
}
