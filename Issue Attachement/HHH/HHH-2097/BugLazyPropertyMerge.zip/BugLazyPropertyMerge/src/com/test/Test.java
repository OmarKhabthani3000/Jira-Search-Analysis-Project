package com.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Test");
		EntityManager em;
		EntityTransaction tx;

		Entity1 e1 = new Entity1();
		Entity2 e2 = new Entity2();

		e1.setE2(e2);

		em = emf.createEntityManager();
		tx = em.getTransaction();
		tx.begin();
		em.persist(e2);
		em.persist(e1);
		tx.commit();
		em.close();
		
		em = emf.createEntityManager();
		
		e1 = em.find(Entity1.class, e1.getId());
		e2 = null;
		
		
		tx = em.getTransaction();
		tx.begin();
		em.merge(e1);
//		em.refresh(e1);
		tx.commit();
		em.close();

		
		emf.close();
	}

}
