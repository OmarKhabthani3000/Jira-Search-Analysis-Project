create table employee (
  id number(19) not null primary key,
  name varchar(120) not null
);

create table employee2jobfunction (
  employeeid number(19) constraint EMP_FK references employee (id),
  jobfunction varchar2(20) not null,
  primary key (employeeid , jobfunction)
);

insert into employee values (1, 'peter');
insert into employee values (2, 'john');
insert into employee values (3, 'paul');
insert into employee2jobfunction values (1,'MANAGER');
insert into employee2jobfunction values (2,'CODER');
insert into employee2jobfunction values (2,'CONSULTANT');
