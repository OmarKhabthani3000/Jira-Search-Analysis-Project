package foo.bar;

/**
 * Created by IntelliJ IDEA.
 * User: phartmann
 * Date: Apr 22, 2010
 * Time: 2:35:41 PM
 * To change this template use File | Settings | File Templates.
 */
public enum JobFunction {
    MANAGER,CODER,CONSULTANT,CONTROLLER;
}
