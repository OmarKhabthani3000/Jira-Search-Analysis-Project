package foo.bar;


import javax.persistence.*;
import java.util.Collection;
import java.util.Iterator;

@Entity
public class Employee {
    @Id
    long id;
    @Column
    String name;

    @Override
    public String toString() {
        String toString = "ID: " + id + " name: " + name + " ";
        for (Iterator<JobFunction> jobFunctionIterator = jobFunctions.iterator(); jobFunctionIterator.hasNext();) {
            JobFunction jobFunction = jobFunctionIterator.next();
            toString +=jobFunction  + ", ";
        }
        return toString;
    }

    @JoinTable(
            name = "employee2jobfunction", // ref table.
                joinColumns = {@JoinColumn(name = "employeeId")
            }
    )
    @Enumerated(EnumType.STRING)
    @Column(name = "jobfunction")
    @ElementCollection (fetch = FetchType.EAGER)
    Collection<JobFunction> jobFunctions;

    public Employee() {
    }

    public long getId() {
        return id;
    }

    public String getName() {

        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Collection<JobFunction> getJobFunctions() {
        return jobFunctions;
    }

    public void setJobFunctions(Collection<JobFunction> jobFunctions) {
        this.jobFunctions = jobFunctions;
    }
}
