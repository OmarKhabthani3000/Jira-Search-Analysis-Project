package foo.bar;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: phartmann
 * Date: Apr 23, 2010
 * Time: 9:31:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class Main {
    public static void main(String[] args) {
        listEmployees();
    }

    private static void listEmployees() {
        Transaction tx = null;
        Session session = getCurrentSession();
        try {
            tx = session.beginTransaction();
            String sql = "select e from Employee e where :function in elements( e.jobFunctions ) ";
            Query queryObject = session.createQuery(sql);
            queryObject.setParameter("function", JobFunction.MANAGER);
            List l = queryObject.list();
            for (Iterator iterator = l.iterator(); iterator.hasNext();) {
                Object o = iterator.next();
                System.out.println("o = " + o);
            }
            tx.commit();
        } catch (RuntimeException e) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    e1.printStackTrace();
                }
                throw e;
            }


        }
    }

    private static Session getCurrentSession() {
        return new AnnotationConfiguration().configure().buildSessionFactory().getCurrentSession();
    }

}
