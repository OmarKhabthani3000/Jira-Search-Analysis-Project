public class PersistWithDetachedTest {
    
    // Get datasource from somewhere
    private DataSource getDataSourceFromSomewhere() {
        return dataSource;
    }


//    @Test
    public void hibernateTwoSessionTest(){

        DataSource ds = getDataSourceFromSomewhere();
        
        Ejb3Configuration cfg = new Ejb3Configuration();
        cfg.setDataSource(ds);
        cfg.setProperty("hibernate.hbm2ddl.auto", "update");
//        cfg.setProperty("hibernate.jdbc.batch_size", "0");

        cfg.addAnnotatedClass(Person.class);
        cfg.addAnnotatedClass(Address.class);


        HibernateEntityManagerFactory emf = (HibernateEntityManagerFactory)
            cfg.buildEntityManagerFactory();
        
        SessionFactory sf = emf.getSessionFactory();
        Session s = sf.openSession();
        Transaction tx = s.beginTransaction();

        Address createAddr = new Address();
        createAddr.setId(System.currentTimeMillis());
        createAddr.setContent("21 Jump St");
        s.persist(createAddr);

        tx.commit();
        s.close();
        s = sf.openSession();
        tx = s.beginTransaction();

        Address loadedAddr = (Address) s.load(Address.class, createAddr.getId());

        tx.commit();
        s.close();
        s = sf.openSession();
        tx = s.beginTransaction();


        // Uncomment this line and the test will fail inside the persist()
        // operation with a LAzyInitExceptpion 
//        Address reloadedAddr = (Address) s.get(Address.class, createAddr.getId());

        Person person = new Person();
        person.setId(System.currentTimeMillis());
        person.setName("Johnny Depp");
        person.setAddress(loadedAddr);

        s.persist(person);

        tx.commit();
        s.close();
    }


}
