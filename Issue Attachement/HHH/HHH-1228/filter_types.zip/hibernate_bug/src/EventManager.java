import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.Session;
import org.hibernate.type.Type;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class EventManager
{

	public static void main(String[] args)
	{
		EventManager mgr = new EventManager();

		mgr.createAndStorePerson(21, "John", "Doe", "A meeting", new Date());
		mgr.listPersons();

		HibernateUtil.sessionFactory.close();
	}

	private void createAndStorePerson(int age, String firstName, String lastName, String eventTitle, Date eventDate)
	{
		Session session = HibernateUtil.currentSession();
		Transaction tx = session.beginTransaction();

		Person thePerson = new Person();
		thePerson.setAge(age);
		thePerson.setFirstname(firstName);
		thePerson.setLastname(lastName);

		Event theEvent = new Event();
		theEvent.setTitle(eventTitle);
		theEvent.setDate(eventDate);

		thePerson.getEvents().add(theEvent);

		session.save(theEvent);
		session.save(thePerson);

		tx.commit();
		HibernateUtil.closeSession();
	}

	private void listPersons()
	{
		Session session = HibernateUtil.currentSession();
		Transaction tx = session.beginTransaction();

		Query query = session.createQuery("from Person");
		Type[] returnTypes = query.getReturnTypes();
		System.out.println("query has " + returnTypes.length + " return types");

		List result = query.list();
		for (Iterator iter = result.iterator(); iter.hasNext();)
		{
			Person aPerson = (Person) iter.next();
			System.out.println(aPerson.getFirstname() + " " + aPerson.getLastname() + ", " + aPerson.getAge() + " has attended:");

			Query filterQuery = session.createFilter(aPerson.getEvents(), "where this.date >= :date");
			filterQuery.setDate("date", new Date());

			returnTypes = filterQuery.getReturnTypes();
			System.out.println("filter query has " + returnTypes.length + " return types");

			List events = filterQuery.list();
			for (Iterator it = events.iterator(); it.hasNext();)
			{
				Event event = (Event) it.next();
				System.out.println("\t" + event.getTitle() + " at " + event.getDate());
			}
		}

		tx.commit();
		session.close();
	}
}
