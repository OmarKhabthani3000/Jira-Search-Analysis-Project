package org.hibernate.envers.test.integration.onetoone.unidirectional;

import java.util.Arrays;
import javax.persistence.EntityManager;

import org.hibernate.envers.test.AbstractEntityTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import org.hibernate.ejb.Ejb3Configuration;

/**
 * @author Andrei Zagorneanu
 */
public class LocalPersonAddressTestCase extends AbstractEntityTest {
    public void configure(Ejb3Configuration cfg) {
        cfg.addAnnotatedClass(LocalAddress.class);
        cfg.addAnnotatedClass(LocalPerson.class);
    }

    @BeforeClass(dependsOnMethods = "init")
    public void initData() {
    	// address
        LocalAddress address1 = new LocalAddress(1, 1, "street1");

        // person with an address
        LocalPerson person1 = new LocalPerson(1, "person1", address1);
        // person without an address
        LocalPerson person2 = new LocalPerson(2, "person2", null);

        EntityManager em = getEntityManager();
        em.getTransaction().begin();

        em.persist(person1);
        em.persist(person2);

        em.getTransaction().commit();
    }

    @Test
    public void testRevisionsCounts() {
        assert Arrays.asList(1).equals(getAuditReader().getRevisions(LocalPerson.class, 1));
        assert Arrays.asList(1).equals(getAuditReader().getRevisions(LocalPerson.class, 2));
        assert Arrays.asList(1).equals(getAuditReader().getRevisions(LocalAddress.class, new LocalAddressPK(1, 1)));
    }

    @Test
    public void testHistoryOfPerson1() {
    	LocalAddress address1 = getEntityManager().find(LocalAddress.class, new LocalAddressPK(1, 1));
        LocalPerson revPerson1 = getAuditReader().find(LocalPerson.class, 1, 1);
        assert address1 != null;
        assert revPerson1.getAddress().equals(address1);
    }

    @Test
    public void testHistoryOfPerson2NotNull() {
        LocalPerson revPerson2 = getAuditReader().find(LocalPerson.class, 2, 1);
        // here address should be null but it is not null
        assert revPerson2.getAddress() == null;
    }
    
    @Test
    public void testHistoryOfPerson2Exception() {
        LocalPerson revPerson2 = getAuditReader().find(LocalPerson.class, 2, 1);
        // as you can see, address should be null but is not null
        assert revPerson2.getAddress() != null;
        // here an EntityNotFoundException will be raised
        revPerson2.getAddress().getStreet();
    }
}