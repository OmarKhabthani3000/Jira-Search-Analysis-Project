package org.hibernate.envers.test.integration.onetoone.unidirectional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import org.hibernate.envers.Audited;

/**
 * @author Andrei Zagorneanu
 */
@Entity
@Audited
@IdClass(LocalAddressPK.class)
public class LocalAddress {
	private Integer id;
	private Integer ver;
	private String street;

	public LocalAddress() {
	}

	public LocalAddress(Integer id, Integer ver, String street) {
		this.setId(id);
		this.setVer(ver);
		this.setStreet(street);
	}

	@Id
	@Column(name = "ID", nullable = false, updatable = false)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Id
	@Column(name = "VER", nullable = false, updatable = false)
	public Integer getVer() {
		return ver;
	}

	public void setVer(Integer ver) {
		this.ver = ver;
	}

	@Column(name = "STREET", nullable = false)
	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String toString() {
		return "LocalAddress[id = " + getId() + ", ver = " + getVer()
				+ ", street = " + getStreet() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((ver == null) ? 0 : ver.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof LocalAddress)) {
			return false;
		}
		LocalAddress other = (LocalAddress) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		if (ver == null) {
			if (other.ver != null) {
				return false;
			}
		} else if (!ver.equals(other.ver)) {
			return false;
		}
		return true;
	}
}
