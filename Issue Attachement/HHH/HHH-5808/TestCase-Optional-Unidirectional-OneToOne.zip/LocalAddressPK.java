package org.hibernate.envers.test.integration.onetoone.unidirectional;

import java.io.Serializable;

/**
 * @author Andrei Zagorneanu
 */
public class LocalAddressPK implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer id;
	private Integer ver;

	public LocalAddressPK() {
	}

	public LocalAddressPK(Integer id, Integer ver) {
		this.setId(id);
		this.setVer(ver);
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getVer() {
		return ver;
	}

	public void setVer(Integer ver) {
		this.ver = ver;
	}

	public String toString() {
		return "LocalAddressPK[id = " + getId() + ", ver = " + getVer() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((ver == null) ? 0 : ver.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof LocalAddressPK)) {
			return false;
		}
		LocalAddressPK other = (LocalAddressPK) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		if (ver == null) {
			if (other.ver != null) {
				return false;
			}
		} else if (!ver.equals(other.ver)) {
			return false;
		}
		return true;
	}
}
