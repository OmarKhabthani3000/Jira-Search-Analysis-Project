package org.hibernate.hhh8814;

public class Bean {
    private Long id;

    private Child child;

    public Bean() {
    }

    public Bean(final Child child) {
        this.child = child;
    }

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public Child getChild() {
        return child;
    }

    public void setChild(final Child child) {
        this.child = child;
    }
}
