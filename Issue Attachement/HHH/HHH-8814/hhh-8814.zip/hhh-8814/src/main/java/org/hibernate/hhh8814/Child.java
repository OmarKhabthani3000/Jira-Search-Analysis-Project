package org.hibernate.hhh8814;

public class Child {
    private Long id;

    private String value;

    public Child() {
    }

    public Child(final String value) {
        this.value = value;
    }

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getValue() {
        return value;
    }

    public void setValue(final String value) {
        this.value = value;
    }
}
