package org.hibernate.hhh8814;

import static org.hibernate.cfg.AvailableSettings.CURRENT_SESSION_CONTEXT_CLASS;
import static org.hibernate.cfg.AvailableSettings.HBM2DDL_AUTO;
import static org.hibernate.cfg.AvailableSettings.PASS;
import static org.hibernate.cfg.AvailableSettings.URL;
import static org.hibernate.cfg.AvailableSettings.USER;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.SQLException;

public class TestCase {

    private SessionFactory sessionFactory;

    @Before
    public void initializeSessionFactory() throws SQLException {
        final Configuration configuration = new Configuration();
        configuration.setProperty(URL, "jdbc:hsqldb:mem:test");
        configuration.setProperty(USER, "sa");
        configuration.setProperty(PASS, "");
        configuration.setProperty("hibernate.connection.shutdown", "true");
        configuration.setProperty(HBM2DDL_AUTO, "create-drop");
        configuration.setProperty(CURRENT_SESSION_CONTEXT_CLASS, "thread");
        // configuration.setProperty("hibernate.show_sql", "true");
        configuration.addResource("org/hibernate/hhh8814/Bean.hbm.xml");
        configuration.addResource("org/hibernate/hhh8814/Child.hbm.xml");
        sessionFactory = configuration.buildSessionFactory();
    }

    @After
    public void closeSessionFactory() {
        sessionFactory.close();
        sessionFactory = null;
    }

    @Test
    public void testCacasdeOperationsOnBeanWithSequenceAssignedId() {
        final Child c = new Child("whatever");
        final Bean b = new Bean(c);

        final Transaction persistTx = sessionFactory.getCurrentSession().beginTransaction();
        try {
            sessionFactory.getCurrentSession().persist(b);
            persistTx.commit();
        } catch (final Exception ex) {
            persistTx.rollback();
        }

        final Transaction checksTx = sessionFactory.getCurrentSession().beginTransaction();
        try {
            assertNotNull(b.getId());
            assertNotNull(c.getId());
            assertTrue(sessionFactory.getCurrentSession().contains(c));
            checksTx.commit();
        } catch (final Exception ex) {
            checksTx.rollback();
        }
    }
}
