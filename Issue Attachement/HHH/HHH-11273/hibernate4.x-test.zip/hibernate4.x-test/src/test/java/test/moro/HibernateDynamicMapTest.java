package test.moro;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by c-ionnmoro on 22-Nov-16.
 */
public class HibernateDynamicMapTest {

    @Test
    public void test_1() {
        Configuration configuration = new Configuration();
        configuration.configure("/test.hibernate.cfg.xml");
        StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties());
        SessionFactory sessionFactory = configuration.buildSessionFactory(builder.build());
        //------------------------------

        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Map insertMap = new HashMap();
        insertMap.put("name", "User_1");
        insertMap.put("password", "mypassword");
        session.save("user", insertMap);
        session.getTransaction().commit();
        session.close();
        sessionFactory.close();
    }
}
