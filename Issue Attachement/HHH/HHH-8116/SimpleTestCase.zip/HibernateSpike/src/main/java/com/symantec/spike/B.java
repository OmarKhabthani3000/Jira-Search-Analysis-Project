package com.symantec.spike;

import javax.persistence.*;

import java.util.Set;
import java.util.HashSet;

@Entity
public class B {
    @Id
    private Long id;

    private String foo;
}
