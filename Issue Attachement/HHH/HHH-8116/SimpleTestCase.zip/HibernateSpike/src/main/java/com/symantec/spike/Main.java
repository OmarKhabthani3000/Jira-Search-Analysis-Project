package com.symantec.spike;

import org.hibernate.*;
import org.hibernate.cfg.*;

import java.util.Properties;

public class Main {
    public static void main(String[] args){

        String url = args[0];
        String user = args[1];
        String password = args[2];

        Properties properties = new Properties();
        properties.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
        properties.setProperty("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
        properties.setProperty("hibernate.connection.url", url);
        properties.setProperty("hibernate.connection.username", user);
        properties.setProperty("hibernate.connection.password", password);
        properties.setProperty("hibernate.connection.pool_size", "5");

        Configuration cfg = new Configuration();
        cfg.addAnnotatedClass(A.class);
        cfg.addAnnotatedClass(B.class);
        cfg.setProperties(properties);

        SessionFactory sessionFactory = cfg.buildSessionFactory();

        Session session = sessionFactory.openSession();
        session.beginTransaction();

        session.createQuery("delete from A where b.foo = :param")
            .setString("param", "bar")
            .executeUpdate();

        session.getTransaction().commit();

        sessionFactory.close();
    }
}
