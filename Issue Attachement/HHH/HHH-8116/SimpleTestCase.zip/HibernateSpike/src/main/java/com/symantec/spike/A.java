package com.symantec.spike;

import javax.persistence.*;

@Entity
public class A {
    @Id
    private Long id;

    @ManyToOne
    private B b;
}
