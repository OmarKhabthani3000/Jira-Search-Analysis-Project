package model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

/**
 * @author Philipp
 * @author Joachim
 */
@Entity
@Table(name="io_version")
public class IoVersionModel {

	@EmbeddedId
	private IoVersionPk pk;

	@ManyToOne(fetch=FetchType.LAZY, optional=false)
	@MapsId("io")
	private IoModel ioModel;

	@Column(name="iov_description")
	private String description;

	@Column(name="iov_creator")
	private String createdBy;

	/**
	 * @return the pk
	 */
	public IoVersionPk getPk() {
		return pk;
	}

	/**
	 * @param pk the pk to set
	 */
	public void setPk(IoVersionPk pk) {
		this.pk = pk;
	}

	/**
	 * @return the ioModel
	 */
	public IoModel getIo() {
		return ioModel;
	}

	/**
	 * @param ioModel the ioModel to set
	 */
	public void setIo(IoModel ioModel) {
		this.ioModel = ioModel;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
}
