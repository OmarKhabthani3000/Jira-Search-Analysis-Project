package repository;

import model.IoLanguageVariantModel;
import model.IoLanguageVariantPk;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Joachim
 */
public interface IoLanguageVariantRepository extends JpaRepository<IoLanguageVariantModel, IoLanguageVariantPk> {

}
