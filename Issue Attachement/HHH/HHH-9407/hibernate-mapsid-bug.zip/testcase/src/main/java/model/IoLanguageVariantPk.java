/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: philipp $
 * $LastChangedDate: 2014-01-16 22:40:48 +0100 (Do, 16 Jan 2014) $
 * $HeadURL: svn://192.168.11.107/supplemental/philipp/cosima-api/trunk/persistence/persistence-jpa/src/main/java/de/docufy/cms/persistence/model/io/IoLanguageVariantPk.java $
 * $LastChangedRevision: 1475 $
 *******************************************************************************/
package model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;


/**
 * @author Philipp
 *
 */
@Embeddable
public class IoLanguageVariantPk implements Serializable {

	private static final long serialVersionUID = -2389392594014907806L;

	@Column(name="io_id", length=32)
	private String io;

	@Column(name="iov_number")
	private int version;

	@Column(name="ln_code", length=2)
	private String language;

	@Column(name="vr_code", length=2)
	private String variant;

	/**
	 * 
	 */
	protected IoLanguageVariantPk() {
		// Needed for JPA
	}

	/**
	 * @param io
	 * @param version
	 * @param language
	 * @param variant
	 */
	public IoLanguageVariantPk(String io, int version, String language,
			String variant) {
		this.io = io;
		this.version = version;
		this.language = language;
		this.variant = variant;
	}

	/**
	 * @return the io
	 */
	public String getIo() {
		return io;
	}

	/**
	 * @param io the io to set
	 */
	public void setIo(String io) {
		this.io = io;
	}

	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the variant
	 */
	public String getVariant() {
		return variant;
	}

	/**
	 * @param variant the variant to set
	 */
	public void setVariant(String variant) {
		this.variant = variant;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "IoLanguageVariantPk [io=" + io + ", version=" + version
				+ ", language=" + language + ", variant=" + variant + "]";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((io == null) ? 0 : io.hashCode());
		result = prime * result
				+ ((language == null) ? 0 : language.hashCode());
		result = prime * result + ((variant == null) ? 0 : variant.hashCode());
		result = prime * result + version;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IoLanguageVariantPk other = (IoLanguageVariantPk) obj;
		if (io == null) {
			if (other.io != null)
				return false;
		} else if (!io.equals(other.io))
			return false;
		if (language == null) {
			if (other.language != null)
				return false;
		} else if (!language.equals(other.language))
			return false;
		if (variant == null) {
			if (other.variant != null)
				return false;
		} else if (!variant.equals(other.variant))
			return false;
		if (version != other.version)
			return false;
		return true;
	}
}
