package repository;

import model.IoVersionModel;
import model.IoVersionPk;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Joachim
 */
public interface IoVersionRepository extends JpaRepository<IoVersionModel, IoVersionPk> {

}
