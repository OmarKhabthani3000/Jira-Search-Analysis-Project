package model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;


/**
 * @author Philipp
 *
 */
@Entity
@Table(name="io_language_variant")
public class IoLanguageVariantModel {

	@EmbeddedId
	private IoLanguageVariantPk pk;

	@ManyToOne(fetch=FetchType.LAZY, optional=false)
	@MapsId("io")
	private IoModel ioModel;

	@ManyToOne(fetch=FetchType.LAZY, optional=false)
	@JoinColumns({
		@JoinColumn(name="io_id", referencedColumnName="io_id", insertable=false, updatable=false), 
		@JoinColumn(name="iov_number", referencedColumnName="iov_number", insertable=false, updatable=false)
	})
	private IoVersionModel ioVersionModel;

	@Column(name="lgv_title")
	private String title;

	@Column(name="lgv_owner")
	private String owner;

	/**
	 * @return the pk
	 */
	public IoLanguageVariantPk getPk() {
		return pk;
	}

	/**
	 * @param pk the pk to set
	 */
	public void setPk(IoLanguageVariantPk pk) {
		this.pk = pk;
	}

	/**
	 * @return the ioModel
	 */
	public IoModel getIo() {
		return ioModel;
	}

	/**
	 * @param ioModel the ioModel to set
	 */
	public void setIo(IoModel ioModel) {
		this.ioModel = ioModel;
	}

	/**
	 * @return the ioVersionModel
	 */
	public IoVersionModel getIoVersion() {
		return ioVersionModel;
	}

	/**
	 * @param ioVersionModel the ioVersionModel to set
	 */
	public void setIoVersion(IoVersionModel ioVersionModel) {
		this.ioVersionModel = ioVersionModel;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * @param owner the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
}
