package repository;

import model.IoModel;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Joachim
 */
public interface IoRepository extends JpaRepository<IoModel, String> {

}
