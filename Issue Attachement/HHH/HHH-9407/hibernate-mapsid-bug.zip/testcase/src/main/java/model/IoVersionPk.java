package model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * @author Philipp
 *
 */
@Embeddable
public class IoVersionPk implements Serializable {

	private static final long serialVersionUID = -6134633489969475998L;

	@Column(name="io_id", length=32)
	private String io;

	@Column(name="iov_number")
	private int version;

	/**
	 * 
	 */
	protected IoVersionPk() {
		// Needed for JPA
	}

	/**
	 * @param io
	 * @param version
	 */
	public IoVersionPk(String io, int version) {
		this.io = io;
		this.version = version;
	}

	/**
	 * @return the io
	 */
	public String getIo() {
		return io;
	}

	/**
	 * @param io the io to set
	 */
	public void setIo(String io) {
		this.io = io;
	}

	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "IoVersionPk [io=" + io + ", version=" + version + "]";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((io == null) ? 0 : io.hashCode());
		result = prime * result + version;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IoVersionPk other = (IoVersionPk) obj;
		if (io == null) {
			if (other.io != null)
				return false;
		} else if (!io.equals(other.io))
			return false;
		if (version != other.version)
			return false;
		return true;
	}
}
