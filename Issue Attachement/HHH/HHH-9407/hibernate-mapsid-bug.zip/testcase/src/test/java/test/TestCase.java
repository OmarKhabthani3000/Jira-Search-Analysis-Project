/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: philipp $
 * $LastChangedDate: 2014-06-29 12:57:48 +0200 (So, 29 Jun 2014) $
 * $HeadURL: svn://192.168.11.107/supplemental/philipp/cosima-api/trunk/persistence/persistence-jpa/src/test/java/de/docufy/cms/persistence/test/TestCase.java $
 * $LastChangedRevision: 1851 $
 *******************************************************************************/
package test;

import java.util.UUID;

import model.IoLanguageVariantModel;
import model.IoLanguageVariantPk;
import model.IoModel;
import model.IoVersionModel;
import model.IoVersionPk;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import repository.IoLanguageVariantRepository;
import repository.IoRepository;
import repository.IoVersionRepository;

/**
 * @author Philipp
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:spring/persistence-context.xml"})
@Transactional
@TransactionConfiguration
public class TestCase {

	@Autowired
	IoRepository ioRepository;
	@Autowired
	IoVersionRepository ioVersionRepository;
	@Autowired
	IoLanguageVariantRepository ioLanguageVariantRepository;

	@Test
	public void createIoVersion() {
		IoModel io = new IoModel();
		io.setId(UUID.randomUUID().toString().substring(0, 32));
		io.setName("Test IO");
		io.setDescription("Yadda yadda");
		io = ioRepository.saveAndFlush(io);
		
		IoVersionModel ioVersion = new IoVersionModel();
		ioVersion.setPk(new IoVersionPk(io.getId(), 1));
		ioVersion.setIo(io);
		ioVersion.setDescription("More yadda yadda");
		ioVersion.setCreatedBy("testuser");
		ioVersionRepository.saveAndFlush(ioVersion);
		
		IoLanguageVariantModel ioLangVar = new IoLanguageVariantModel();
		ioLangVar.setPk(new IoLanguageVariantPk(io.getId(), 1, "en", "US"));
		ioLangVar.setIo(io);
		ioLangVar.setIoVersion(ioVersion);
		ioLangVar.setOwner("testuser");
		ioLangVar.setTitle("Test IO Title");
		ioLanguageVariantRepository.saveAndFlush(ioLangVar);
	}

}
