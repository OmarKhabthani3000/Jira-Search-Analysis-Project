package org.hibernate.bugs;
import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Id;

public class APK implements Serializable {

  private String a1;
  private String a4;
  private String a5;
  private String a6;

  @Column(name = "A1", nullable = false, length = 15)
  @Id
  public String getA1() {
    return a1;
  }

  public void setA1(String a1) {
    this.a1 = a1;
  }

  @Column(name = "A4", nullable = false, length = 15)
  @Id
  public String getA4() {
    return a4;
  }

  public void setA4(String a4) {
    this.a4 = a4;
  }

  @Column(name = "A5", nullable = false, length = 15)
  @Id
  public String getA5() {
    return a5;
  }

  public void setA5(String a5) {
    this.a5 = a5;
  }

  public String getA6() {
    return a6;
  }

  public void setA6(String a6) {
    this.a6 = a6;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    APK apk = (APK) o;
    return Objects.equals(a1, apk.a1) &&
        Objects.equals(a4, apk.a4) &&
        Objects.equals(a5, apk.a5) &&
        Objects.equals(a6, apk.a6);
  }

  @Override
  public int hashCode() {

    return Objects.hash(a1, a4, a5, a6);
  }
}
