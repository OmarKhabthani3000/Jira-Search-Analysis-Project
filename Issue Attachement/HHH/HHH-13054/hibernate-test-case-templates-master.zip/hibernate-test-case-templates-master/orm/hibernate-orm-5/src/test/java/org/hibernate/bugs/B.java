package org.hibernate.bugs;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "B", schema = "", catalog = "")
@IdClass(BPK.class)
public class B {

  private String a1;
  private String a2;
  private String a3;
  private String b1;
  private String b2;
  private A aObj;

  @Id
  @Column(name = "A1", nullable = false, length = 15)
  public String getA1() {
    return a1;
  }

  public void setA1(String a1) {
    this.a1 = a1;
  }

  @Id
  @Column(name = "A2", nullable = false, length = 15)
  public String getA2() {
    return a2;
  }

  public void setA2(String a2) {
    this.a2 = a2;
  }

  @Id
  @Column(name = "A3", nullable = false, length = 15)
  public String getA3() {
    return a3;
  }

  public void setA3(String a3) {
    this.a3 = a3;
  }

  @Basic
  @Column(name = "B1", nullable = false, length = 15)
  public String getB1() {
    return b1;
  }

  public void setB1(String b1) {
    this.b1 = b1;
  }

  @Basic
  @Column(name = "B2", nullable = false, length = 15)
  public String getB2() {
    return b2;
  }

  public void setB2(String b2) {
    this.b2 = b2;
  }


  @ManyToOne(targetEntity = A.class)
  @Fetch(FetchMode.SELECT)
  @JoinColumn(name ="A1", referencedColumnName = "A1" , insertable = false, updatable = false)
  public A getaObj() {
    return aObj;
  }

  public void setaObj(A aObj) {
    this.aObj = aObj;
  }
}
