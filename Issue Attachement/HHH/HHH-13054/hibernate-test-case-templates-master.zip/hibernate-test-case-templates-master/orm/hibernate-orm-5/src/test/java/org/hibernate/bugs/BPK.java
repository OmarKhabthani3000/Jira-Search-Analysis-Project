package org.hibernate.bugs;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Id;

public class BPK implements Serializable {

  private int a1;
  private String a2;
  private String a3;

  @Column(name = "A1", nullable = false, length = 15)
  @Id
  public int getA1() {
    return a1;
  }

  public void setA1(int a1) {
    this.a1 = a1;
  }

  @Column(name = "A2", nullable = false, length = 15)
  @Id
  public String getA2() {
    return a2;
  }

  public void setA2(String a2) {
    this.a2 = a2;
  }

  @Column(name = "A3", nullable = false, length = 15)
  @Id
  public String getA3() {
    return a3;
  }

  public void setA3(String a3) {
    this.a3 = a3;
  }
}
