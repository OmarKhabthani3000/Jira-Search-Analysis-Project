package org.hibernate.bugs;

import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "A", schema = "", catalog = "")
@IdClass(APK.class)
public class A {

  private String a1;
  private String a2;
  private String a3;
  private String a4;
  private String a5;
  private String a6;
  private List<B> bObj;

  @Id
  @Column(name = "A1", nullable = false, length = 15)
  public String getA1() {
    return a1;
  }

  public void setA1(String a1) {
    this.a1 = a1;
  }

  @Basic
  @Column(name = "A2", nullable = false, length = 15)
  public String getA2() {
    return a2;
  }

  public void setA2(String a2) {
    this.a2 = a2;
  }

  @Basic
  @Column(name = "A3", nullable = false, length = 15)
  public String getA3() {
    return a3;
  }

  public void setA3(String a3) {
    this.a3 = a3;
  }


  @Id
  @Column(name = "A4", nullable = false, length = 15)
  public String getA4() {
    return a4;
  }

  public void setA4(String a4) {
    this.a4 = a4;
  }


  @Id
  @Column(name = "A5", nullable = false, length = 15)
  public String getA5() {
    return a5;
  }

  public void setA5(String a5) {
    this.a5 = a5;
  }

  @Id
  @Column(name = "A6", nullable = false, length = 15)
  public String getA6() {
    return a6;
  }

  public void setA6(String a6) {
    this.a6 = a6;
  }

  @OneToMany(mappedBy = "aObj")
  public List<B> getB() {
    return bObj;
  }

  public void setB(List<B> bObj) {
    this.bObj = bObj;
  }
}
