package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		// Do stuff...
		
    A aTestObj = new A( );
    aTestObj.setA1("1");
    aTestObj.setA2("var1");
    aTestObj.setA3("var2");
    aTestObj.setA4("var3");
    aTestObj.setA5("var4");
    aTestObj.setA6("var5");
    entityManager.persist( aTestObj );
    B bTestObj = new B( );
    bTestObj.setA1(1);
    bTestObj.setA2("varB1");
    bTestObj.setA3("varB3");
    bTestObj.setB1("varB4");
    bTestObj.setB2("varB5");
    entityManager.persist( bTestObj );

	//I am using SPring boot application, so not sure if below qeury will work fine. But yeah spring boot
	//application itself is not coming up due to the error I have posted in Jira and Also I am using spring boot JPA so query will // be generated on run time but this is something I want to do. Infact since entities are not getting loaded because of this // error I am unable to test query run
    String var = entityManager.createQuery(
        "select b.b1 " +
            "from B b, A a where a.A1=b.A1", String.class)
        .getSingleResult();
    assertEquals("varB4", var);

    entityManager.persist( event );

    Event dbEvent = entityManager.createQuery(
            "select e " +
            "from Event e", Event.class)
        .getSingleResult();
    assertEquals(event.getCreatedOn(), dbEvent.getCreatedOn());

		
		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
