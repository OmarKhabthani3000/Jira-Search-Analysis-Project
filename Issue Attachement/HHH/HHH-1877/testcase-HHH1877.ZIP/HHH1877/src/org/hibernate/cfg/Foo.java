package org.hibernate.cfg;

public class Foo {
    private long id;
    private String someProperty;
}
