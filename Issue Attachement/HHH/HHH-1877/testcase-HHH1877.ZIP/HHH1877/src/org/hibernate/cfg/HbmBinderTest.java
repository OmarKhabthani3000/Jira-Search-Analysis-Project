package org.hibernate.cfg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.hibernate.mapping.RootClass;

/**
 * Test case for bug HHH-1877 - http://opensource.atlassian.com/projects/hibernate/browse/HHH-1877.
 */
public class HbmBinderTest extends TestCase {
    private Element node; //class node
    
    protected void setUp() throws Exception {        
        SAXReader xmlReader = new SAXReader();
        Document document = xmlReader.read(HbmBinderTest.class.getResourceAsStream("EntityAndJoin-HHH-1877.hbm.xml"));
        node = document.getRootElement().element("class");
    }    
    
    public void testBindRootClass() throws Exception{       
        Map inheritedMetas = new HashMap(); 
        Mappings mappings = newMappings();       
        RootClass rootClass = new RootClass();
        HbmBinder.bindRootClass(node, rootClass, mappings, inheritedMetas);        
    }
    
    /**
     * Creates new Mappings object through the reflection.
     */
    private Mappings newMappings() throws Exception{       
        NamingStrategy ns = new DefaultNamingStrategy();
        //7 x Map, 2x List, NamingStategy, 3 x Map, List, 2 x Map
        Object arguments[] = {new HashMap(),new HashMap(), new HashMap(), new HashMap(), new HashMap(), new HashMap(), new HashMap(), new ArrayList(), new ArrayList(), ns, new HashMap(), new HashMap(), new HashMap(), new ArrayList(), new HashMap(), new HashMap()};
        return (Mappings) Mappings.class.getDeclaredConstructors()[0].newInstance(arguments);
    }
    

}
