package org.hibernate.test.cfg;

import org.hibernate.cfg.Environment;
import org.hibernate.junit.functional.FunctionalTestCase;

/**
 * Test case for bug HHH-1877 -
 * http://opensource.atlassian.com/projects/hibernate/browse/HHH-1877.
 */
public class HbmBinderTest extends FunctionalTestCase {

	public HbmBinderTest(String string) {
		super(string);
		// only needed to run this test in eclipseIDE outside maven test harness..
		// remove if needed
		System.setProperty(Environment.DIALECT, "org.hibernate.dialect.Oracle9Dialect"); 
	}

	@Override
	protected void cleanupTest() throws Exception {
		System.clearProperty(Environment.DIALECT); 
	}

	public String[] getMappings() {
		return new String[] { "cfg/HbmBinder-HHH-1877.hbm.xml" };
	}
	
	public void testJustLoadingTheMappingFileShouldPerformTheTest() throws Exception {
		// no-op JustLoadingTheMappingFileShouldPerformTheTest
		// as long as no exceptions were thrown the test succeeds.
	}	
}

	
