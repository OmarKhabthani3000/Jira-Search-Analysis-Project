package org.hibernate.test.cfg;

public class SpecificationImpl {

	private Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}

class CoverageGroupImpl extends SpecificationImpl {
	private String annualStatementLine;

	public String getAnnualStatementLine() {
		return annualStatementLine;
	}

	public void setAnnualStatementLine(String annualStatementLine) {
		this.annualStatementLine = annualStatementLine;
	}
}
