package org.hibernate.bugs;

public enum PersonStatus {
	ACTIVE, INACTIVE
}
