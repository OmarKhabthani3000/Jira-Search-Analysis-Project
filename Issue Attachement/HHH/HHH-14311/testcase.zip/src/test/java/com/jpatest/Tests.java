package com.jpatest;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

@ContextConfiguration("/applicationContext.xml") 
public class Tests extends AbstractTransactionalTestNGSpringContextTests {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@PersistenceContext(unitName = "pu")
    EntityManager entityManager;

	@Autowired
	StudentRepository studentRepository;

	//@BeforeMethod
	public void init()
	{
		//Dorm dorm1 = new Dorm(1L, "Dorm 1");
		//entityManager.merge(dorm1);
	    
	    //Student student = new Student(10001L, "John", "A1234657", dorm1);
	    //entityManager.persist(student);	    

	    //entityManager.flush();
	    //entityManager.clear();
	}
	
	@Test
	public void test()
	{	
		logger.info("Student id 10001 -> {}", studentRepository.findById(
				new StudentId(new BigDecimal(10001L), 1000L)));
	}
}
