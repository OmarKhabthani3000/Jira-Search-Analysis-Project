package com.jpatest;

public interface IDorm {

	public Long getId();

	public void setId(Long id);

	public String getName();

	public void setName(String name);
}
