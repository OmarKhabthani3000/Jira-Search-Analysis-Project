package com.jpatest;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import org.hibernate.annotations.Loader;

@Entity
@Loader(namedQuery = Dorm.FIND_BY_ID)
@NamedQueries({
    @NamedQuery(name = Dorm.FIND_BY_ID, query = "from Dorm dorm " +
            "where dorm.id = :id")
})
public class Dorm implements IDorm {
	public static final String FIND_BY_ID = "findById";
	
	@Id
	//@GeneratedValue
	@Column(name = "dorm_id")
	private Long id;
	private String name;
	
	public Dorm() {
		super();
	}

	public Dorm(Long id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	public Long getId() {
		return id;
	}

	public final void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
