import javax.persistence.*;
//import org.hibernate.annotations.*;
import java.util.Set;

@Entity
@Table(name="user")
class User
{
	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
	Long id;

	@Version
	@Column(nullable = false)
	Long version;

	String name;

	// Variant 1 (bidirectionality is on the association)

	/*@OneToOne()
	@JoinColumn(name = "home_computer_id")
	ComputerHibernate homeComputer

	@OneToMany(cascade = CascadeType.ALL, targetEntity = ComputerHibernate.class)
    @JoinColumn(name = "owner_id", nullable = false)
	Set computers*/

	// Variant 2 (bidirectionality is on the list, see Computer class)

	/*@OneToOne()
	@JoinColumn(name = "home_computer_id")
	ComputerHibernate homeComputer

	@OneToMany(cascade = CascadeType.ALL, targetEntity = ComputerHibernate.class)
	@JoinColumn(name = "owner_id", nullable = false)
	Set computers*/

	// Variant 3 (cascade is on the association, this will *fail*)

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "home_computer_id")
	Computer homeComputer;

	@OneToMany(cascade = CascadeType.ALL, targetEntity = Computer.class)
	@JoinColumn(name = "owner_id", nullable = false)
	Set <Computer> computers;
}
