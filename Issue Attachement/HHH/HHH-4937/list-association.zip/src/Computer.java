import javax.persistence.*;
//import org.hibernate.annotations.*;

@Entity
@Table(name="computer")
class Computer
{
	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
	Long id;

	@Version
	@Column(nullable = false)
	Long version;

	String model;

	// Variant 1 (bidirectionality is on the association)

	/*@OneToOne(mappedBy = "homeComputer", optional = false)
	UserHibernate owner*/

	// Variant 2 (bidirectionality is on the list)

	/*@ManyToOne(optional = false)
	@JoinColumn(name = "owner_id", insertable = false, updatable = false, nullable = false)
	User owner;*/

	// Variant 3 (bidirectionality is on the list, will fail because of the cascade on the User class)

	@ManyToOne(optional = false)
	@JoinColumn(name = "owner_id", insertable = false, updatable = false, nullable = false)
	User owner;
}
