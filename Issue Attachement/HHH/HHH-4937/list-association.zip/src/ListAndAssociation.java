import java.util.*;
import org.hibernate.*;
import org.hibernate.cfg.AnnotationConfiguration;

public class ListAndAssociation
{
	public static void main(String[] args)
	{
		SessionFactory sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();

		Session session = sessionFactory.openSession();

		Transaction tx = session.beginTransaction();
		User user = new User();
		user.name = "Stan";
		Computer computer = new Computer();
		computer.model = "Asus UX30";
		user.homeComputer = computer;
		computer.owner = user;
		user.computers = new HashSet <Computer>();
		user.computers.add(computer);

		Long msgId = (Long) session.save(user);
		tx.commit();
		session.close();
	}
}
