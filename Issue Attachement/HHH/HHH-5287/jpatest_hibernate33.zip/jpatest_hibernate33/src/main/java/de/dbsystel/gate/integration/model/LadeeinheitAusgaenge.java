package de.dbsystel.gate.integration.model;


import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("AUSGANG")
public class LadeeinheitAusgaenge extends LadeeinheitEinausgaenge implements java.io.Serializable {

    private static final long serialVersionUID = 0L;

    public LadeeinheitAusgaenge() {
    }

}


