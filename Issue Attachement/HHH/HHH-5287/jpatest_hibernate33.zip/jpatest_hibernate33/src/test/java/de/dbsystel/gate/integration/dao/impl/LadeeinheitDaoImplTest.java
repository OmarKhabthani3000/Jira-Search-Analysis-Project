/**
 * Copyright 2010, DB Systel GmbH
 */
package de.dbsystel.gate.integration.dao.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author AndreasAWuest
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/beans-integration.xml",
        "classpath:spring/beans-integration-test.xml" })
public class LadeeinheitDaoImplTest {

    @Autowired
    private final LadeeinheitDaoImpl dao = null;

    @Test
    public void testFindByAuftragsnummer() {
        dao.findby();
    }
}
