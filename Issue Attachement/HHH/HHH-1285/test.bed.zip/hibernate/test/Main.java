/*
 * Main.java
 *
 * Created on 15. d�cembre 2005, 11:40
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package hibernate.test;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.Properties;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import org.hibernate.cfg.Configuration;


class WhatTodo {
    static final int NONE = 0;
    static final int ADD = 1;
    static final int UPD = 2;
    static final int DEL = 3;
    static final int MAX_ACTIONS = 3;
    
    int action=0;
    Record record=null;
}

class WorkingThread extends Thread {
    private String name = null;
    private boolean stop = false;
    public WorkingThread(String name) {
        this.name = name;
    }
    
    public void run() {
        // forever until stopped !
        for(;;) {
            Double dSleep = new Double((Math.random() * 5000) + 10);
            System.out.println(Main.df.format(new Date()) +" [" + name +"] sleeping for " + dSleep + "msec.");
            try {
                sleep(dSleep.longValue());
                System.out.println(Main.df.format(new Date()) +" [" + name +"] running .");
                
                WhatTodo todo = Main.whatTodo();
                if (todo == null)
                    continue;
                
                Session sess = null;
                Transaction tx = null;
                switch (todo.action) {
                    case WhatTodo.ADD:
                        try {
                            sess = Main.getSession();
                            tx = sess.beginTransaction();
                            sess.save(todo.record);
                            tx.commit();
                            System.out.println(Main.df.format(new Date()) +" [" + name +"] Added record with ID : " + todo.record.getId());
                            Main.actionCompleted(todo);
                        } catch (HibernateException he) {
                            System.out.println("\n" + Main.df.format(new Date()) + " *************\nHibernateException occurs : " + he.getMessage());
                            he.printStackTrace();
                            System.out.println("*************\n");
                            if (tx != null) {
                                tx.rollback();
                            }
                        } finally {
                            if (sess != null) {
                                sess.close();
                            }
                        }
                        break;
                    case WhatTodo.UPD:
                        try {
                            sess = Main.getSession();
                            tx = sess.beginTransaction();
                            sess.update(todo.record);
                            tx.commit();
                            System.out.println(Main.df.format(new Date()) + " [" + name +"] Updated record with ID : " + todo.record.getId());
                            Main.actionCompleted(todo);
                        } catch (HibernateException he) {
                            System.out.println("\n" + Main.df.format(new Date()) + " *************\nHibernateException occurs : " + he.getMessage());
                            he.printStackTrace();
                            System.out.println("*************\n");
                            if (tx != null) {
                                tx.rollback();
                            }
                        } finally {
                            if (sess != null) {
                                sess.close();
                            }
                        }
                        break;
                    case WhatTodo.DEL:
                        try {
                            sess = Main.getSession();
                            tx = sess.beginTransaction();
                            sess.delete(todo.record);
                            tx.commit();
                            System.out.println("[" + name +"] Deleted record with ID : " + todo.record.getId());
                            Main.actionCompleted(todo);
                        } catch (HibernateException he) {
                            System.out.println("\n" + Main.df.format(new Date()) + " *************\nHibernateException occurs : " + he.getMessage());
                            he.printStackTrace();
                            System.out.println("*************\n");
                            if (tx != null) {
                                tx.rollback();
                            }
                        } finally {
                            if (sess != null) {
                                sess.close();
                            }
                        }
                        break;
                }
                

                // now test 5 objects
                for (int loop=0; loop < 5; loop++) {
                    sess = null;
                    Record checkThis = Main.getObjectToCheck();
                    if (checkThis == null)
                        continue;
                    try {                        
                        sess = Main.getSession();
                        System.out.println("[" + name +"] fetching record with ID : " + checkThis.getId());
                        Record readRecord = (Record) sess.load(Record.class, checkThis.getId());
                        if (readRecord != null) {
                            if (! readRecord.getNom().equals(checkThis.getNom()))
                                System.out.println("*** unexpected content (Nom) on row with ID : " + checkThis.getId());
                            if (! readRecord.getChanges().equals(checkThis.getChanges()))
                                System.out.println("*** unexpected content (Changes) on row with ID : " + checkThis.getId());
                        }
                    } catch (HibernateException he) {
                        System.out.println("\n"+ Main.df.format(new Date()) + " [" + name +"] *************\nHibernateException occurs : " + he.getMessage());
                        he.printStackTrace();
                        System.out.println(Main.df.format(new Date()) + " [" + name +"] *************\n");
                    } finally {
                        if (sess != null) {
                            sess.close();
                        }
                    }
                }
                
                
                
            } catch (InterruptedException inte) {
                System.out.println(Main.df.format(new Date()) + " [" + name +"] interrupted ...");
                stop = true;
            }
            if (stop) {
                System.out.println(Main.df.format(new Date()) + " [" + name +"] stopping.");
                return;
            }
        }
    }
    
}

/**
 *
 * @author Patrick Lezy
 */
public class Main {
    
    static LinkedList objectsList = new LinkedList();
    static SessionFactory sf = null;
    static SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException, IOException {
        // configure Hibernate and create session factory
        Properties props = new Properties();
        java.io.InputStream is = Main.class.getResourceAsStream("/hibernate.properties");
        props.load(is);
        Configuration cnf = new Configuration();
        cnf.setProperties(props);
        cnf.addClass(Record.class);

        sf = cnf.buildSessionFactory();
        
        Thread threads[] = new Thread[10];
        for(int i=0; i<threads.length; i++) {
            threads[i] = new WorkingThread("Thread " + Integer.toString(i));
            threads[i].start();
        }
        
        Thread.sleep(120000);
        
        for(int i=0; i<threads.length; i++) {
            threads[i].interrupt();
        }
        
    }
    
    public static Session getSession() {
        return sf.openSession();
    }
    
    public static WhatTodo whatTodo() {
        WhatTodo result = new WhatTodo();
        result.action = WhatTodo.NONE;
        
        while (result.action == WhatTodo.NONE) {
            
            Double dAction = new Double(Math.random() * 100);
            
            int action = dAction.intValue();
            
            // r�partition statistique des modifications
            result.action = WhatTodo.UPD;
            if (action > 50)
                result.action = WhatTodo.ADD;
            if (action > 75)
                result.action = WhatTodo.DEL;
            
            // check sur les valeurs
            if (result.action > WhatTodo.MAX_ACTIONS)
                continue;
            
            if (objectsList.size() < 5) {
                if (result.action == WhatTodo.DEL )
                    result.action = WhatTodo.NONE;
            }
            if (objectsList.size() < 1) {
                if (result.action == WhatTodo.UPD )
                    result.action = WhatTodo.ADD;
            }
        }
        
        Double choix = null;
        switch (result.action) {
            case WhatTodo.ADD:
                result.record = new Record("", new Integer(1), new Date());
                result.record.setNom(result.record.toString());
                break;
            case WhatTodo.UPD:
                choix = new Double(Math.random() * objectsList.size());
                result.record = (Record) objectsList.get(choix.intValue());
                result.record.setChanges(new Integer(result.record.getChanges().intValue() + 1));
                result.record.setTsChange(new Date());
                break;
            case WhatTodo.DEL:
                choix = new Double(Math.random() * objectsList.size());
                result.record = (Record) objectsList.get(choix.intValue());
                break;
            default:
                return null;
        }
            
            
        return result;
    }
    
    public static synchronized void actionCompleted(WhatTodo done) {
        System.out.println(Main.df.format(new Date()) + "Entering actionCompleted");
        Record searchedRecord = null;
        
        switch (done.action) {
            case WhatTodo.ADD:
                System.out.println("Adding in list object with ID = " + done.record.getId());
                objectsList.addLast(done.record);
                break;
            case WhatTodo.UPD:
                searchedRecord = done.record;
                System.out.println("Updating in list object with ID = " + done.record.getId());
                for (int idx=0; idx<objectsList.size();idx++) {
                    Record oldRecord = (Record) objectsList.get(idx);
                    if (oldRecord.getId().equals(searchedRecord.getId())) {
                        objectsList.remove(idx);
                        objectsList.addLast(searchedRecord);
                        break;
                    }
                }
                break;
            case WhatTodo.DEL:
                searchedRecord = done.record;
                System.out.println("Deleting from list object with ID = " + done.record.getId());
                for (int idx=0; idx<objectsList.size();idx++) {
                    Record oldRecord = (Record) objectsList.get(idx);
                    if (oldRecord.getId().equals(searchedRecord.getId())) {
                        objectsList.remove(idx);
                        break;
                    }
                }
                break;
            default:
                return;
        }
        System.out.println(Main.df.format(new Date()) + "Leaving actionCompleted");
    }
    
    public static Record getObjectToCheck() {
        Record result = null;
        Double choix = new Double(Math.random() * objectsList.size());
        result = (Record) objectsList.get(choix.intValue());
        return result;
    }
}
