package hibernate.test;
// Generated 15 d�c. 2005 15:36:05 by Hibernate Tools 3.1.0 beta1JBIDERC2

import java.util.Date;


/**
 *     Record Object
 *     @author Patrick Lezy
 *     
 */

public class Record  implements java.io.Serializable {


    // Fields    

     private Integer id;
     private String nom;
     private Integer changes;
     private Date tsChange;


    // Constructors

    /** default constructor */
    public Record() {
    }

    
    /** full constructor */
    public Record(String nom, Integer changes, Date tsChange) {
        this.nom = nom;
        this.changes = changes;
        this.tsChange = tsChange;
    }
    

   
    // Property accessors

    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }

    public String getNom() {
        return this.nom;
    }
    
    public void setNom(String nom) {
        this.nom = nom;
    }

    public Integer getChanges() {
        return this.changes;
    }
    
    public void setChanges(Integer changes) {
        this.changes = changes;
    }

    public Date getTsChange() {
        return this.tsChange;
    }
    
    public void setTsChange(Date tsChange) {
        this.tsChange = tsChange;
    }
   








}
