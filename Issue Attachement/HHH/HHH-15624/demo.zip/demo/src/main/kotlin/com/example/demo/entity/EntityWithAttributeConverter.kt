package com.example.demo.entity

import jakarta.persistence.*
import org.springframework.stereotype.Repository

@Entity
@Table(name="hibernate_test_converter")
class EntityWithAttributeConverter(
    @Id
    @GeneratedValue
    var id: Long = 0,

    @Column
    @Convert(converter = BalanceUsageTypeListToStringConverter::class)
    var usageType: Set<BalanceUsageType>,
)

@Repository
class Repo

@Converter
class BalanceUsageTypeListToStringConverter : AttributeConverter<Set<BalanceUsageType>, String?> {
    override fun convertToDatabaseColumn(attribute: Set<BalanceUsageType>): String? {
        if (attribute.isEmpty()) {
            return null
        }
        val listOfString = attribute.map { it.toString() }

        return listOfString.joinToString(DELIMITER)
    }

    override fun convertToEntityAttribute(dbData: String?): Set<BalanceUsageType> {
        return dbData?.split(DELIMITER)?.map { BalanceUsageType.valueOf(it) }?.toSet() ?: emptySet()//EnumSet.copyOf(
    }

    companion object {
        private const val DELIMITER = ","
    }
}

enum class BalanceUsageType {
    DEPOSIT,
    COMMISSION,
    GENERAL,
}

