package com.example;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.io.Serializable;

/**
 * Created by br0x on 29.03.17.
 */
@Entity
@Data
@ToString
@NoArgsConstructor
public class AlternativeName implements Serializable {
    @Id
    @GeneratedValue
    private Long id;

    private String name;
    private String alternative;
}
