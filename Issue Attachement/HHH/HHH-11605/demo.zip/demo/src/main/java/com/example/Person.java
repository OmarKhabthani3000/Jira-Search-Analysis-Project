package com.example;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * Created by br0x on 02.12.2016.
 */
@Entity
@Data
@ToString
@NoArgsConstructor
public class Person implements Serializable {
    @Id
    @GeneratedValue
    private Long id;

    private String firstName;
    private String lastName;

    @OneToMany
    @JoinColumn(name="name", referencedColumnName = "firstName")
    List<AlternativeName> alternativeNameList;
}
