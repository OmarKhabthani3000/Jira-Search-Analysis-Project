package com.example;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * Created by br0x on 02.12.2016.
 */
@Entity
@Data
@ToString
@NoArgsConstructor
public class Event implements Serializable {
    @Id
    @GeneratedValue
    private Long id;

    private String message;
    private Long sourceId;

    @ManyToMany
    @JoinTable(name = "source_source_group",
            joinColumns = @JoinColumn(name = "source_id", referencedColumnName = "sourceId", updatable = false, insertable = false),
            inverseJoinColumns = @JoinColumn(name = "source_group_id", referencedColumnName = "id", updatable = false, insertable = false))
    List<SourceGroup> sourceGroups;
}
