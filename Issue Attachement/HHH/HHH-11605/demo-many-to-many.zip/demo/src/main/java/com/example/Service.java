package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by br0x on 30.03.17.
 */
@org.springframework.stereotype.Service
@Transactional
public class Service {

    @Autowired
    EventRepository eventRepository;

    public List<Event> go() {
        List<Event> all = eventRepository.findAll();
        return all;
    }
}
