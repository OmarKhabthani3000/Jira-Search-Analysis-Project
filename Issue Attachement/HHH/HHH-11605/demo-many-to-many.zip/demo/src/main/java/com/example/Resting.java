package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * Created by br0x on 01.12.2016.
 */
@Component
public class Resting {

    @Autowired
    Service service;

    @PostConstruct
    void init() {
        service.go();
    }

}
