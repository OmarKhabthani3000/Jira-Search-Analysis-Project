//
// Copyright (C) 2006 Siemens AG. All rights reserved.
//
package com.siemens.dbal.provider;

import com.siemens.dbal.services.impl.CustomerService;


/**
 *
 * Service Provider<br>
 * Offers all availabe DB Access Services
 *
 * @author Ronny Fries PSE KB C 4
 * @date 26.04.2006
 *
 */
public final class ServiceProvider {

    /**
     * Get Customer Service
     * @return Returns User Service Interface
     */
    public static CustomerService getCustomerService() {
        return (CustomerService) AppCtxService.getInstance().
                                    getAppCtx().getBean("CustomerService");
    }
    
    
}
