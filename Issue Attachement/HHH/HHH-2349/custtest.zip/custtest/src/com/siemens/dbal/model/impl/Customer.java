//
// Copyright (C) 2006 Siemens AG. All rights reserved.
//
package com.siemens.dbal.model.impl;

import javax.persistence.Entity;

/**
 *
 * TODO Description
 *
 * @author TODO Name PSE KB C 4
 * @date 20.12.2006
 *
 */
@Entity
public class Customer extends AbstractPersistentObject {

    private static final long serialVersionUID = 7252605547210663022L;
    
    private String name;
    
    private String type;
    
    private int marketstatus;

    /**
     * Returns marketstatus
     * @return Returns the marketstatus.
     */
    public int getMarketstatus() {
        return marketstatus;
    }

    /**
     * Set marketstatus
     * @param marketstatus The marketstatus to set.
     */
    public void setMarketstatus(int marketstatus) {
        this.marketstatus = marketstatus;
    }

    /**
     * Returns name
     * @return Returns the name.
     */
    public String getName() {
        return name;
    }

    /**
     * Set name
     * @param name The name to set.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns type
     * @return Returns the type.
     */
    public String getType() {
        return type;
    }

    /**
     * Set type
     * @param type The type to set.
     */
    public void setType(String type) {
        this.type = type;
    }
    
    
    
    

}
