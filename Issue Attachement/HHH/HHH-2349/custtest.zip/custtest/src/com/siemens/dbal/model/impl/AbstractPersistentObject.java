//
// Copyright (C) 2006 Siemens AG. All rights reserved.
//
package com.siemens.dbal.model.impl;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;

import com.siemens.dbal.model.IPersistentObject;
import com.siemens.dbal.util.IDGenerator;

/**
 *
 * Abstract Persistent Object<br>
 * Defines structure of a Model Bean and defines uniform access methods.<br>
 * Every Entity Bean has to extend this Object!
 *
 * @author Ronny Fries PSE KB C 4
 * @date 10.10.2006
 *
 */
@MappedSuperclass
public abstract class AbstractPersistentObject implements IPersistentObject {

    @Id @GeneratedValue(generator = "gen")
    @GenericGenerator(name = "gen", strategy = "assigned")
    private String id = IDGenerator.createId();
      
    @Version
    private Integer version;
    
    /**
     * Get ID
     * @return Returns ID of Object
     * @see com.siemens.dbal.model.IPersistentObject#getId()
     */
    public String getId() {
        return id;
    }

    /**
     * Get Version of Object
     * @return Returns Version
     * @see com.siemens.dbal.model.IPersistentObject#getVersion()
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * Set Object ID
     * @param id ID (UUID)
     * @see com.siemens.dbal.model.IPersistentObject#setId(java.lang.String)
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Set Object Version
     * @param version Version
     * @see com.siemens.dbal.model.IPersistentObject#setVersion(java.lang.Integer)
     */
    public void setVersion(Integer version) {
        this.version = version; 
    }

    /**
     * Equals Method
     * @param obj Object to compare
     * @return Returns true if equal, false if not equal
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        // if both references point to the same "address space"
        // they are equal, no further checking necessary
        if (this == obj) {
            return true;
        }
        
        // if object to compare is null or is not an instance of
        // the "Persistence Object", they are NOT equal
        if ( obj == null 
                || !(obj instanceof IPersistentObject)) {
            return false;
        }
        
        IPersistentObject other =
            (IPersistentObject) obj;
        
        // if id of base object is null, comparison is cancelled
        // and false is returned
        if (id == null ) {
            return false;
        }
        
        // if the comparison passed the above checks
        // the id's of both objects are compared
        return id.equals(other.getId());
    }

    /**
     * HashCode Method
     * @return Returns Object Hashcode
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        if (id != null) {
            return id.hashCode();
        } else {
            return super.hashCode();
        }
    }

    /**
     * ToString Method
     * @return Returns String Representation of Object
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        String text = this.getClass().getName() + "[ ID = " + id;
        if (version == null) {
            text = text + " ; Not Stored in DB ]";
        } else {
            text = text + " ; Stored in DB - Version = " + version + " ]";
        }
        return text;
    }

    

}
