//
// Copyright (C) 2006 Siemens AG. All rights reserved.
//
package com.siemens.dbal.services.impl;

import java.util.Collection;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.siemens.dbal.model.impl.Customer;
import com.siemens.dbal.model.impl.Intercept;

/**
 *
 * TODO Description
 *
 * @author TODO Name PSE KB C 4
 * @date 20.12.2006
 *
 */
public class CustomerService extends HibernateDaoSupport {
    
    public void storeCustomer(Customer customer) {
        getHibernateTemplate().save(customer);
    }
    
    public Collection<Customer> getOrderCustomersWithSpringTemplate1() {
        return getHibernateTemplate().
                    findByCriteria(DetachedCriteria.forClass(Customer.class).addOrder(Order.asc("id")), 990000, 1000);
    }
    
    public Collection<Customer> getOrderCustomersWithSpring1() {
        Collection<Customer> customers = null;
        customers = (Collection<Customer>) getHibernateTemplate().executeFind(new HibernateCallback() {
            public Object doInHibernate(Session session) throws HibernateException {
                Query query = getSession().createQuery("from Customer order by id");
                query.setMaxResults(1000);
                query.setFirstResult(991000);
                return query.list();
            }
        });
        return customers;
    }
    
    public Collection<Customer> getOrderCustomersWithSpring2() {
        Collection<Customer> customers = null;
        customers = (Collection<Customer>) getHibernateTemplate().executeFind(new HibernateCallback() {
            public Object doInHibernate(Session session) throws HibernateException {
                Criteria criteria= getSession().createCriteria(Customer.class);
                criteria.addOrder(Order.asc("id"));
                criteria.setFirstResult(990000);
                criteria.setMaxResults(1000);
                return criteria.list();
            }
        });
        return customers;
    }
    
}
