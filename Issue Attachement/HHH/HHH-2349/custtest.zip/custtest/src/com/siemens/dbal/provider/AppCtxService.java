//
// Copyright (C) 2006 Siemens AG. All rights reserved.
//
package com.siemens.dbal.provider;

import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 *
 * Application Context Service
 * Get the ApplciationContext in order to instantiate
 * the DB Access Layer Services
 *
 * @author Ronny Fries PSE KB C 4
 * @date 26.04.2006
 *
 */
public class AppCtxService {
    
    private ClassPathXmlApplicationContext appContext = null;
    private static AppCtxService instance = new AppCtxService();
    
    
    /**
     * Get Application Context for DB Access Layer
     * @return Returns Application Context
     */
    public ClassPathXmlApplicationContext getAppCtx() {
        return appContext;
    }
        
    /**
     * Set Application Context
     * @param ctx Context
     */
    public void setAppCtx(ClassPathXmlApplicationContext ctx) {
        this.appContext = ctx;
    }
    
    /**
     * Get Application Context Service Instance.
     * @return Returns Application Context Service Instance
     */
    public static AppCtxService getInstance() {
        return instance;
    }
  
}
