//
// Copyright (C) 2006 Siemens AG. All rights reserved.
//
package com.siemens.dbal.model;

import java.io.Serializable;

/**
 *
 * Interface Persistent Object<br>
 * Defines structure of a Model Bean
 *
 * @author Ronny Fries PSE KB C 4
 * @date 10.10.2006
 *
 */
public interface IPersistentObject extends Serializable {
    public String getId();
    public void setId(String id);
    
    public Integer getVersion();
    public void setVersion(Integer version);
}
