//
// Copyright (C) 2006 Siemens AG. All rights reserved.
//
package com.siemens.dbal.services;

import java.util.Collection;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.siemens.dbal.model.impl.Customer;
import com.siemens.dbal.provider.AppCtxService;
import com.siemens.dbal.provider.ServiceProvider;

import junit.framework.TestCase;

/**
 *
 * TODO Description
 *
 * @author TODO Name PSE KB C 4
 * @date 20.12.2006
 *
 */
public class CSTest extends TestCase {

private static Logger logger = Logger.getLogger(CSTest.class);
    
    /**
     * Test Initialization
     * @throws Exception Exception
     */
    public void testInitiate() throws Exception {
        
        //  set application context
        AppCtxService.getInstance().setAppCtx(
                new ClassPathXmlApplicationContext("././hibtest-appctx.xml"));
        
    }
    
    /**
     * Test method for {@link com.siemens.dbal.services.impl.CustomerService#storeCustomer(com.siemens.dbal.model.impl.Customer)}.
     */
    public void tStoreCustomer() {
        for (int i = 0; i < 1000000; i++) {
            Customer c = new Customer();
            c.setName("Test");
            c.setType("Test");
            c.setMarketstatus(1);
            ServiceProvider.getCustomerService().storeCustomer(c);
        }
    }

    /**
     * Test method for {@link com.siemens.dbal.services.impl.CustomerService#getOrderCustomersWithSpringTemplate1()}.
     */
    public void testGetOrderCustomersWithSpringTemplate1() {
        long start = 0;
        long end = 0;
        start = System.nanoTime();
        Collection<Customer> customers = 
            ServiceProvider.getCustomerService().
                getOrderCustomersWithSpringTemplate1();
        end = System.nanoTime();
        logger.debug("testGetOrderCustomersWithSpringTemplate1");
        logger.debug("Processing took " + ((end-start)/1000000) + "ms.");
    }

    /**
     * Test method for {@link com.siemens.dbal.services.impl.CustomerService#getOrderCustomersWithSpring1()}.
     */
    public void testGetOrderCustomersWithSpring1() {
        long start = 0;
        long end = 0;
        start = System.nanoTime();
        Collection<Customer> customers = 
            ServiceProvider.getCustomerService().
                getOrderCustomersWithSpring1();
        end = System.nanoTime();
        logger.debug("testGetOrderCustomersWithSpring1");
        logger.debug("Processing took " + ((end-start)/1000000) + "ms.");
    }

    /**
     * Test method for {@link com.siemens.dbal.services.impl.CustomerService#getOrderCustomersWithSpring2()}.
     */
    public void testGetOrderCustomersWithSpring2() {
        long start = 0;
        long end = 0;
        start = System.nanoTime();
        Collection<Customer> customers = 
            ServiceProvider.getCustomerService().
                getOrderCustomersWithSpring2();
        end = System.nanoTime();
        //assertTrue(customers.size() == 60);
        logger.debug("testGetOrderCustomersWithSpring2");
        logger.debug("Processing took " + ((end-start)/1000000) + "ms.");
    }

}
