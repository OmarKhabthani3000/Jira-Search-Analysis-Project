package org.hibernate.test.deletetransientmn;

import java.util.ArrayList;
import java.util.List;


/**
 * todo: describe Component
 *
 * @author Donnchadh Ó Donnabháin
 */
public class Component {
	private Long id;
	private String name;
    private List<Attribute> attributes = new ArrayList<Attribute>();
	public Component() {
	}

	public Component(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

    public void addAttribute(Attribute attribute) {
    	attribute.setComponent(this);
    	attribute.setIndex(attributes.size());
    	this.attributes.add(attribute);
    }

    /**
     * @return the attributes
     */
    public List<Attribute> getAttributes() {
    	return this.attributes;
    }

    /**
     * @param attributes
     *            the attributes to set
     */
    public void setAttributes(List<Attribute> attributes) {
    	this.attributes = attributes;
    }
    
}
