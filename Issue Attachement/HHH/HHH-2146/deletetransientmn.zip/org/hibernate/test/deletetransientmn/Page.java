package org.hibernate.test.deletetransientmn;

import java.util.ArrayList;
import java.util.List;


/**
 * todo: describe Page
 *
 * @author Donnchadh Ó Donnabháin
 */
public class Page {
	private Long id;
	private List<Cell> cells = new ArrayList<Cell>();
    public Page() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void moveComponent(int fromCellIndex, int toCellIndex, int componentIndex, int newComponentIndex) {
        Cell fromCell = getCells().get(fromCellIndex);
        PageComponent component = fromCell.removeComponent(componentIndex);
        Cell toCell = getCells().get(toCellIndex);
        toCell.addComponent(component.getComponent(), newComponentIndex);
    }

    public List<Cell> getCells() {
        return cells;
    }

    /**
     * @param cells
     *            the cells to set
     */
    public void setCells(List<Cell> cells) {
        this.cells = cells;
    }

    public Cell addCell() {
        Cell cell = new Cell();
        cell.setPage(this);
        cell.setPosition(cells.size());
        cells.add(cell);
        return cell;
    }

}
