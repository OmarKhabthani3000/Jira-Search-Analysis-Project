package org.hibernate.test.deletetransientmn;


/**
 * todo: describe PageAttribute
 *
 * @author Donnchadh Ó Donnabháin 
 */
public class PageAttribute {
	private Long id;
    private Attribute attribute;
    private PageComponent component;
    private String value;
	public PageAttribute() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

    public Attribute getAttribute() {
    	return attribute;
    }

    /**
     * @return the component
     */
    public PageComponent getComponent() {
        return component;
    }

    public String getValue() {
        return value;
    }

    public void setAttribute(Attribute attribute) {
    	this.attribute = attribute;
    }

    /**
     * @param component
     *            the component to set
     */
    public void setComponent(PageComponent component) {
        this.component = component;
    }

    public void setValue(String value) {
        this.value = value;
    }
    
}
