package org.hibernate.test.deletetransientmn;


/**
 * todo: describe Attribute
 *
 * @author Donnchadh Ó Donnabháin
 */
public class Attribute {
	private Long id;
	private String name;
    private Component component;
    private int index;
	public Attribute() {
	}

	public Attribute(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

    /**
     * @return the component
     */
    public Component getComponent() {
    	return component;
    }

    public int getIndex() {
    	return index;
    }

    /**
     * @param component
     *            the component to set
     */
    public void setComponent(Component component) {
    	this.component = component;
    }
    
    public void setIndex(int index) {
        this.index = index;
    }
    
}
