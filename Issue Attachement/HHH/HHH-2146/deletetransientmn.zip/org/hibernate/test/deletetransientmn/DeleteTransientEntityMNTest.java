package org.hibernate.test.deletetransientmn;

import junit.framework.Test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;

/**
 * todo: describe DeleteTransientEntityTest
 *
 * @author Steve Ebersole
 */
public class DeleteTransientEntityMNTest extends FunctionalTestCase {
	public DeleteTransientEntityMNTest(String name) {
		super( name );
	}

	public String[] getMappings() {
		return new String[] { "deletetransientmn/Page.hbm.xml" };
	}

	public static Test suite() {
		return new FunctionalTestClassTestSuite( DeleteTransientEntityMNTest.class );
	}

	/**
     * Test case for http://opensource.atlassian.com/projects/hibernate/browse/HHH-2146
     *
     */
    public void testBug2146() {
        Session s = openSession();
        Transaction t = s.beginTransaction();

        Component component = new Component();
        Attribute attribute = new Attribute("test attribute");
        component.addAttribute(attribute);
        s.save( component );
        s.flush();
        
        Page page = new Page();
        page.addCell();
        page.addCell();
        
        PageComponent pageComponent = page.getCells().get(0).addComponent(component, 0);
        s.save( page );

        t.commit();
        s.close();

        s = openSession();
        t = s.beginTransaction();
        
        pageComponent.setAttributeValue(attribute, "test value");
        
        
        page.moveComponent(0, 1, 0, 0);
        
        s.save( page );

        s.flush();

        t.rollback();
        
        s.close();
    }

}
