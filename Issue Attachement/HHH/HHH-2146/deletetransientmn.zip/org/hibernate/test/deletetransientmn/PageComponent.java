package org.hibernate.test.deletetransientmn;

import java.util.HashMap;
import java.util.Map;

/**
 * todo: describe PageComponent
 *
 * @author Donnchadh Ó Donnabháin
 */
public class PageComponent {
	private Long id;
	private Map<Long, PageAttribute> attributes = new HashMap<Long, PageAttribute>();
    private Cell cell;
    private Component component;
    private Integer componentIndex;

    public PageComponent() {
	}

	public PageComponent(Component component) {
        this.component = component;
    }

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	/**
     * @return the attributes
     */
    public Map<Long, PageAttribute> getAttributes() {
        return attributes;
    }

    /**
     * @return the cell
     */
    public Cell getCell() {
        return cell;
    }

    /**
     * @return the component
     */
    public Component getComponent() {
        return component;
    }

    /**
     * @return the componentIndex
     */
    public Integer getComponentIndex() {
        return componentIndex;
    }

    /**
     * @param attributes
     *            the attributes to set
     */
    public void setAttributes(Map<Long, PageAttribute> attributes) {
        this.attributes = attributes;
    }

    /**
     * @param cell
     *            the cell to set
     */
    public void setCell(Cell cell) {
        this.cell = cell;
    }

    /**
     * @param component
     *            the component to set
     */
    public void setComponent(Component component) {
        this.component = component;
    }

    /**
     * @param componentIndex
     *            the componentIndex to set
     */
    public void setComponentIndex(Integer componentIndex) {
        this.componentIndex = componentIndex;
    }
    
    public void setAttributeValue(Attribute attribute, String value) {
        PageAttribute templateAttribute = new PageAttribute();
        templateAttribute.setAttribute(attribute);
        templateAttribute.setComponent(this);   
        templateAttribute.setValue(value); 
        this.getAttributes().put(attribute.getId(), templateAttribute);
    }
    
}
