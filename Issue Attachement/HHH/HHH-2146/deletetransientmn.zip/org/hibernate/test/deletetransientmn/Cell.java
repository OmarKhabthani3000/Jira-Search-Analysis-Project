package org.hibernate.test.deletetransientmn;

import java.util.ArrayList;
import java.util.List;


/**
 * todo: describe Cell
 *
 * @author Donnchadh Ó Donnabháin
 */
public class Cell {
	private Long id;
	private String name;
    private Page page;
    private List<PageComponent> components = new ArrayList<PageComponent>();
    private int position;
	public Cell() {
	}

	public Cell(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

    public PageComponent addComponent(Component component, int index) {
        PageComponent templateComponent = new PageComponent(component);
    	return addPageComponent(templateComponent, index);
    }

    protected PageComponent addPageComponent(PageComponent templateComponent, int index) {
        templateComponent.setCell(this);
        templateComponent.setComponentIndex(index);
        getComponents().add(index, templateComponent);
        reindexComponents(index);
        return templateComponent;
    }

    public PageComponent removeComponent(int templateComponentIndex){
        PageComponent removedComponent = getComponents().remove(templateComponentIndex);
    	reindexComponents(templateComponentIndex);
    	return removedComponent;
    }

    private void reindexComponents(int startPosition) {
        for (int i = startPosition; i < components.size(); i++) {
            PageComponent templateComponent = components.get(i);
            templateComponent.setComponentIndex(Integer.valueOf(i));
        }
    }

    public Page getPage() {
    	return page;
    }

    public List<PageComponent> getComponents() {
    	return components;
    }

    public void setPage(Page page) {
    	this.page = page;
    }

    public void setComponents(List<PageComponent> templateComponents) {
    	this.components = templateComponents;
    }

    public int getPosition() {
    	return position;
    }

    public void setPosition(int position) {
    	this.position = position;
    }
    
}
