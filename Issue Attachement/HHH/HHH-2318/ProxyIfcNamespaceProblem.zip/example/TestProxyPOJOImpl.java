package example;

public class TestProxyPOJOImpl implements TestProxyPOJO {
  
  protected Long id = null;
  protected int version = -1;
  protected String name = null;
  protected String description = null;
  protected TestPOJO pojo = null;
  
  public TestProxyPOJOImpl(String name, String description) {
    super();
    this.name = name;
    this.description = description;
  }
  
  public TestProxyPOJOImpl() {
    super(); // for hibernate
  }

  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public Long getId() {
    return id;
  }
  public void setId(Long id) {
    this.id = id;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  
  public int getVersion() {
    return version;
  }
  public void setVersion(int version) {
    this.version = version;
  }

  public TestPOJO getPojo() {
    return this.pojo;
  }
  public void setPojo(TestPOJO pojo) {
    this.pojo = pojo;
  }

  public boolean equals(Object other) {
    if (!(other instanceof TestProxyPOJO)) {
      return false;
    }
    return this.getName().equals(((TestProxyPOJO) other).getName());
  }

  public int hashCode() {
    return this.getName().hashCode();
  }

  public String toString() {
    return this.getName();
  }
}
