package example;

public class TestPOJOImpl implements TestPOJO {
  
  protected Long id = null;
  protected int version = -1;
  protected String name = null;
  protected String description = null;
  protected TestProxyPOJO proxyPojo = null;
  
  public TestPOJOImpl(String name, String description) {
    super();
    this.name = name;
    this.description = description;
  }
  
  public TestPOJOImpl() {
    super(); // for hibernate
  }

  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public Long getId() {
    return id;
  }
  public void setId(Long id) {
    this.id = id;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  
  public int getVersion() {
    return version;
  }
  public void setVersion(int version) {
    this.version = version;
  }
  
  public TestProxyPOJO getProxyPojo() {
    return this.proxyPojo;
  }
  public void setProxyPojo(TestProxyPOJO proxyPojo) {
    this.proxyPojo = proxyPojo;
  }
  
  public boolean equals(Object other) {
    if (!(other instanceof TestPOJO)) {
      return false;
    }
    return this.getName().equals(((TestPOJO) other).getName());
  }

  public int hashCode() {
    return this.getName().hashCode();
  }

  public String toString() {
    return this.getName();
  }

}
