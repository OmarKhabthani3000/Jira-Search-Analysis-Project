package example;

public interface TestProxyPOJO {
  public Long getId();
  public String getName();
  public String getDescription();
  public TestPOJO getPojo();
  public void setPojo(TestPOJO pojo);
}
