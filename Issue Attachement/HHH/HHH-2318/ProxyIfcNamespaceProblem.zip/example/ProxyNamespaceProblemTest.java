package example;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

public class ProxyNamespaceProblemTest {

  public static void main(String[] args) throws Throwable {
    new ProxyNamespaceProblemTest().testProblemRepeatedly();
  }
  
  public void cleanupDB() throws Exception {
    SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
    Session session = sessionFactory.openSession();
    Transaction tx = session.beginTransaction();
    session.createQuery("delete from TestPOJOImpl").executeUpdate();
    session.createQuery("delete from TestProxyPOJOImpl").executeUpdate();
    tx.commit();
    session.close();
  }
  
  // for Junit4 un-comment the following line
  //@Test()
  public void testProblemRepeatedly() throws Throwable {
    for (int i = 0; i < 100; i++) {
      this.testProblem();
      System.out.println("test nr "+i+" succeed!");
    }
  }

  public void testProblem() throws Throwable {
    cleanupDB();
    ClassLoader cl = new CustomClassLoader("customNamespace", this.getClass().getClassLoader());
    Class clazz = cl.loadClass(this.getClass().getName());
    Object instance = clazz.newInstance();
    Method call = clazz.getDeclaredMethod("executeWithCustomClassLoader", new Class[] {});
    try {
      call.invoke(instance, new Object[] {});
    } catch (InvocationTargetException e) {
      throw e.getCause();
    }
  }

  public void executeWithCustomClassLoader() throws Exception {
    ClassLoader oldCcl = Thread.currentThread().getContextClassLoader();
    Thread.currentThread().setContextClassLoader(this.getClass().getClassLoader());
    SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
    this.insertObjects(sessionFactory);
    this.loadObjects(sessionFactory);
    Thread.currentThread().setContextClassLoader(oldCcl);
  }

  public void insertObjects(SessionFactory sessionFactory) {
    Session session = sessionFactory.openSession();
    TestPOJO pojo = new TestPOJOImpl("pojo-1", "a pojo");
    TestProxyPOJO proxyPojo = new TestProxyPOJOImpl("proxypojo-1", "a proxy pojo");
    pojo.setProxyPojo(proxyPojo);
    proxyPojo.setPojo(pojo);
    Transaction tx = session.beginTransaction();
    session.save(pojo);
    session.save(proxyPojo);
    tx.commit();
    session.close();
  }

  public void loadObjects(SessionFactory sessionFactory) {
    Session session = sessionFactory.openSession();
    TestPOJO pojo = (TestPOJO) session.createQuery("from TestPOJOImpl").uniqueResult();
    TestProxyPOJO proxyPojo = pojo.getProxyPojo();
    if(!pojo.equals(proxyPojo.getPojo())) {
      throw new RuntimeException("UUps "+pojo+" not equals "+proxyPojo.getPojo());
    }
    session.close();
  }

}
