package example;

public interface TestPOJO {
  public Long getId();
  public String getName();
  public String getDescription();
  public TestProxyPOJO getProxyPojo();
  public void setProxyPojo(TestProxyPOJO pojo);
}
