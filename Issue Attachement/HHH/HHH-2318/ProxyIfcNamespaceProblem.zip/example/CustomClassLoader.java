package example;

import java.io.File;
import java.net.*;
import java.util.StringTokenizer;


public class CustomClassLoader extends URLClassLoader {
  
  // a simple test class loader... the real class loader makes more sense of course...

  private static URL[] path;
  static {
    // initialize URL path with classpath
    String Classpath = System.getProperty("java.class.path");
    StringTokenizer ClasspathT = new StringTokenizer(Classpath, File.pathSeparator);
    int count = ClasspathT.countTokens();
    path = new URL[count];
    for (int i = 0; i < count; i++) {
      try {
        path[i] = new File(ClasspathT.nextToken()).toURL();
      } catch (MalformedURLException e) {
        System.err.println("Error initializing the classpath: "+ e);
      }
    }
  }

  private String namespace = "undefined";
  private ClassLoader commonClassLoader;

  public CustomClassLoader(String namespace, ClassLoader commonClassLoader) {
    super(path, null);
    this.namespace = namespace;
    this.commonClassLoader = commonClassLoader;
  }

  boolean isCustomNamespace(String name) {
    // only the example package reside in separate namespace...
    return name.startsWith("example.");
  }

  protected Class<?> findClass(String name) throws ClassNotFoundException {
    Class c = null;
    if (this.isCustomNamespace(name)) {
      c = super.findClass(name);
    } else {
      c = commonClassLoader.loadClass(name);
    }
    return c;
  }

  public String toString() {
    return "<" + namespace + ":" + super.toString() + ">";
  }

}
