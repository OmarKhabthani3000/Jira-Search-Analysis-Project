package org.hibernate.bugs;

import org.hibernate.Session;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.math.BigDecimal;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh8641Test() throws Exception {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		entityManager.unwrap(Session.class).doWork(conn -> {
			conn.createStatement().execute("insert into a values(1, 42)");
			conn.createStatement().execute("insert into b values(42)");
		});

		entityManager.getTransaction().commit();
		entityManager.close();


		entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		A reloadedA = entityManager.find(A.class, BigDecimal.valueOf(1));
		reloadedA.bs.size();

		entityManager.getTransaction().commit();
		entityManager.close();

	}
}
