package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.io.Serializable;
import java.math.BigDecimal;

@Entity
public class B implements Serializable {

    @Id
    @GeneratedValue
    public BigDecimal id;

    @ManyToOne
    @JoinColumn(name = "id", referencedColumnName = "nonPrimaryRelationId", insertable = false, updatable = false)
    public A a;

}
