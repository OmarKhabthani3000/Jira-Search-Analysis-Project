import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;

import entities.EntityOne;
import entities.EntityTwo;

public class TestCase {

    public static void main(String[] args) {
        new TestCase().start();
    }

    private void start() {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        ctx.register(Config.class);
        ctx.refresh();

        Config config = ctx.getBean(Config.class);

        EntityOne entityOne = new EntityOne();
        EntityTwo entityTwo = new EntityTwo();
        entityOne.addToManyToManyEntities(entityTwo);

        LocalSessionFactoryBean sessionFactory = config.sessionFactory();
        createTheInitialData(entityOne, entityTwo, sessionFactory);

        deleteTheDataWillCauseTheException(entityOne, entityTwo, sessionFactory);
    }

    private void deleteTheDataWillCauseTheException(EntityOne entityOne, EntityTwo entityTwo,
            LocalSessionFactoryBean sessionFactory) {
        Session currentSession = sessionFactory.getObject().openSession();
        Transaction currentTransaction = currentSession.beginTransaction();
        //When global_with_modified_flag is turned on deleting either EntityOne or EntityTwo 
        //results in a LazyInitializationException
        delete(currentSession, "EntityOne", entityOne.getId());
        delete(currentSession, "EntityTwo", entityTwo.getId());
        currentTransaction.commit();
        currentSession.close();
    }

    private void createTheInitialData(EntityOne entityOne, EntityTwo entityTwo,
            LocalSessionFactoryBean sessionFactory) {
        Session currentSession = sessionFactory.getObject().openSession();
        currentSession.beginTransaction();
        currentSession.saveOrUpdate(entityOne);
        currentSession.saveOrUpdate(entityTwo);
        currentSession.getTransaction().commit();
        currentSession.close();
    }

    private void delete(Session session, String entityName, long value) {
        Object queriedObject = find(session, entityName, value);
        session.delete(queriedObject);
    }

    private Object find(Session session, String entityName, long value) {
        Query query = session.createQuery("select t FROM " + entityName + " t where t.id = :param");
        query.setParameter("param", value);
        if (query.list().size() == 0) {
            throw new Error(entityName + " with ID: " + value + " could not be found.");
        }
        Object queriedObject = query.list().get(0);

        return queriedObject;
    }

}
