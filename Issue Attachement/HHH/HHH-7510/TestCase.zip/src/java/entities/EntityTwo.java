package entities;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "entity_two")
@Audited
public class EntityTwo {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "entity_two_id_seq")
    @SequenceGenerator(name = "entity_two_id_seq", sequenceName = "entity_two_id_seq")
    private long id;

    @ManyToMany(mappedBy = "relatedEntityTwos")
    private Set<EntityOne> mappedEntityOnes;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Set<EntityOne> getManyToManyEntities() {
        return mappedEntityOnes;
    }

    public void setManyToManyEntities(Set<EntityOne> mappedEntityOnes) {
        this.mappedEntityOnes = mappedEntityOnes;
    }
}
