package entities;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "entity_one")
@Audited
public class EntityOne {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "entity_one_id_seq")
    @SequenceGenerator(name = "entity_one_id_seq", sequenceName = "entity_one_id_seq")
    private long id;

    @ManyToMany
    @JoinTable(name = "entity_one_two", 
    joinColumns = @JoinColumn(name = "entity_one_id", referencedColumnName = "id"), 
    inverseJoinColumns = @JoinColumn(name = "entity_two_id", referencedColumnName = "id"))
    private Set<EntityTwo> relatedEntityTwos;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Set<EntityTwo> getManyToManyEntities() {
        return relatedEntityTwos;
    }

    public void addToManyToManyEntities(EntityTwo entityTwo) {
        if (relatedEntityTwos == null) {
            relatedEntityTwos = new HashSet<EntityTwo>();
        }
       relatedEntityTwos.add(entityTwo);
    }
}
