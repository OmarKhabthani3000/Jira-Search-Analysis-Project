package org.hibernate.test.cid.propertyref;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;

public class Order {
	public static class Id implements Serializable {
		private String customerId;
		private int orderNumber;

		public Id(String customerId, int orderNumber) {
			this.customerId = customerId;
			this.orderNumber = orderNumber;
		}
		public Id() {}

		/**
		 * @return Returns the customerId.
		 */
		public String getCustomerId() {
			return customerId;
		}
		/**
		 * @param customerId The customerId to set.
		 */
		public void setCustomerId(String customerId) {
			this.customerId = customerId;
		}
		/**
		 * @return Returns the orderNumber.
		 */
		public int getOrderNumber() {
			return orderNumber;
		}
		/**
		 * @param orderNumber The orderNumber to set.
		 */
		public void setOrderNumber(int orderNumber) {
			this.orderNumber = orderNumber;
		}
		public int hashCode() {
			return customerId.hashCode() + orderNumber;
		}
		public boolean equals(Object other) {
			if (other instanceof Id) {
				Id that = (Id) other;
				return that.customerId.equals(this.customerId) &&
					that.orderNumber == this.orderNumber;
			}
			else {
				return false;
			}
		}
	}
	
	private Id id = new Id();
	private Collection<LineItem> lineItems = new HashSet<LineItem>();
	private Long uniqueProperty;
	
	public Id getId() {
		return id;
	}
	public void setId(Id id) {
		this.id = id;
	}
	public Collection<LineItem> getLineItems() {
		return lineItems;
	}
	public void setLineItems(Collection<LineItem> lineItems) {
		this.lineItems = lineItems;
	}
	public Long getUniqueProperty() {
		return uniqueProperty;
	}
	public void setUniqueProperty(Long uniqueProperty) {
		this.uniqueProperty = uniqueProperty;
	}

}
