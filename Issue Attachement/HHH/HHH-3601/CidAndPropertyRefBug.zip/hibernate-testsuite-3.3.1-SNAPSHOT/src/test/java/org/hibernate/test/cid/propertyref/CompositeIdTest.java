//$Id: CompositeIdTest.java 10977 2006-12-12 23:28:04Z steve.ebersole@jboss.com $
package org.hibernate.test.cid.propertyref;

import java.util.List;

import junit.framework.Test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;
import org.hibernate.test.cid.propertyref.Order.Id;

/**
 * @author Gavin King
 */
public class CompositeIdTest extends FunctionalTestCase {
	
	public CompositeIdTest(String str) {
		super(str);
	}

	public String[] getMappings() {
		return new String[] { "cid/propertyref/Order.hbm.xml", "cid/propertyref//LineItem.hbm.xml" };
	}

	public static Test suite() {
		return new FunctionalTestClassTestSuite(CompositeIdTest.class);
	}
	
	public void testQuery() {
		try{
			Session s = openSession();
			Transaction t = s.beginTransaction();
			
			Order o = new Order();
			Id id = new Id();
			id.setCustomerId("blah");
			id.setOrderNumber(4);
			o.setId(id);
			o.setUniqueProperty(new Long(10));
			
			s.save(o);
			
			LineItem li1 = new LineItem();
			LineItem li2 = new LineItem();
			
			s.save(li1);
			s.save(li2);
			
			o.getLineItems().add(li1);
			o.getLineItems().add(li2);
			
			t.commit();
			s.close();
			
			s = openSession();
			t = s.beginTransaction();
			List results = s.createQuery("from Order").list();
			t.commit();
			s.close();
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}
	

}

