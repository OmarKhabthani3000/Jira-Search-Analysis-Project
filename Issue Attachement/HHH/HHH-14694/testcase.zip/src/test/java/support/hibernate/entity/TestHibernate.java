package support.hibernate.entity;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.log4j.Logger;

import org.junit.Test;

public class TestHibernate {
	private static Logger log = Logger.getLogger(TestHibernate.class.getCanonicalName());

	@Test
	public void test() {
		log.info("---> test started.");

		try {
			for (int i = 0 ; i < 50 ; i++ ) {
				try {
					EntityManagerFactory factory = Persistence.createEntityManagerFactory("TEST");
					factory.close();
				} catch (Throwable t) {
					log.error(t.getMessage(), t);
				}
			}

			log.info("Sleeping for 30 seconds, collect heap now ... (jmap -dump:format=b,file=heap.hprof <PID>)");
			Thread.sleep(30*1000);
			log.info("Awake, exiting ...");
		} catch (Throwable t) {
			log.error(t.getMessage(), t);
		} finally {
			log.info("---> test completed.");
		}
	}
}
