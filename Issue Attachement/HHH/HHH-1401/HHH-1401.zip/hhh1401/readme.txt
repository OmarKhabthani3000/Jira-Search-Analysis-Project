This directory is intended to be copied to

  <HIBERNATE>/test/org/hibernate/test


