package net.kch;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

/**
 * Simple entity.
 */
@Entity(name = "simple_entity")
public class SimpleEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column
	private String name;

	@Column
	@ElementCollection(targetClass = SimpleEnum.class)
	@CollectionTable(name = "entity_x_enum", joinColumns = @JoinColumn(name = "entity_id"),
			foreignKey = @ForeignKey(name = "fk_name"))
	private Set<SimpleEnum> collection = new HashSet<SimpleEnum>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<SimpleEnum> getCollection() {
		return collection;
	}

	public void setCollection(Set<SimpleEnum> collection) {
		this.collection = collection;
	}
}
