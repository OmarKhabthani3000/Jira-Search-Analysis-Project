package net.kch;

/**
 * Simple enum.
 */
public enum SimpleEnum {
	VALUE1, VALUE2
}
