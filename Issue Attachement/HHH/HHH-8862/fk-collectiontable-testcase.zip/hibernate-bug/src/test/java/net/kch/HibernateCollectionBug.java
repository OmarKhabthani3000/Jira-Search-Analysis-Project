package net.kch;

import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.junit.Test;

/**
 * Bug test case.
 */
public class HibernateCollectionBug {
	@Test
	public void testCase() {
		Configuration configuration = new Configuration();
		configuration.addAnnotatedClass(SimpleEntity.class).setProperty(Environment.USER, "test")
				.setProperty(Environment.PASS, "test").setProperty(Environment.URL, "jdbc:h2:mem:testdb")
				.setProperty(Environment.DIALECT, "org.hibernate.dialect.H2Dialect")
				.setProperty(Environment.DRIVER, "org.h2.Driver");

		SchemaExport export = new SchemaExport(configuration);
		export.setOutputFile("schema.sql");
		export.create(true, true);
	}
}
