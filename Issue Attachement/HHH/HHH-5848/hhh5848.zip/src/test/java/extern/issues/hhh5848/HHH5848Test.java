
package extern.issues.hhh5848;

import org.hibernate.cfg.Configuration;
import org.hibernate.dialect.HSQLDialect;
import org.testng.annotations.Test;

@Test
public class HHH5848Test {
	
	public void dummyTest() {
		Configuration cfg = new Configuration()
			.addAnnotatedClass(MyClass.class)
//			.addAnnotatedClass(Derived.class)
			.setNamingStrategy(new TestNamingStrategy());
		
		String[] script = cfg.generateSchemaCreationScript(new HSQLDialect());
		
		for (String line : script) {
			System.out.println(line);
		}
	}
	
}
