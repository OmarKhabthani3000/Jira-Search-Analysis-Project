
package extern.issues.hhh5848;

import org.hibernate.cfg.DefaultNamingStrategy;

public class TestNamingStrategy extends DefaultNamingStrategy {
	
	@Override
	public String tableName(String tableName) {
		return tableName.toLowerCase();
	}

}
