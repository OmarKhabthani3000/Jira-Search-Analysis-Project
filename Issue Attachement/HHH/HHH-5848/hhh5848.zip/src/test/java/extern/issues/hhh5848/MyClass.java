
package extern.issues.hhh5848;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TABLE")
public class MyClass {
	
	@Id
	@GeneratedValue
	private long id;
	
	@Column(table = "TABLE")
	private String myAttrib;

}
