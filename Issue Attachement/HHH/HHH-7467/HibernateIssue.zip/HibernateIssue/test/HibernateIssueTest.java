/**
 * 
 */

import junit.framework.TestCase;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateIssueTest extends TestCase {

	private static SessionFactory factory;

	static {
		try {
			factory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		super.tearDown();
	}


	public void testGetTestWithValidValue() {
		Session session = factory.openSession();
		Transaction tx = null;
		Test test = null;
		try {
			tx = session.beginTransaction();
			test = (Test) session.get(Test.class, "1111");
			if (test != null) {
				System.out.println(test);
			}
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		assertNotNull(test);
	}


	public void testGetTestWithInvalidValue() {
		Session session = factory.openSession();
		Transaction tx = null;
		Test test = null;
		try {
			tx = session.beginTransaction();
			test = (Test) session.get(Test.class, "5555");
			if (test != null) {
				System.out.println(test);
			}
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		assertNull(test);
	}

	public void testGetTestWithValueMoreThanColumnLength() {
		Session session = factory.openSession();
		Transaction tx = null;
		Test test = null;
		try {
			tx = session.beginTransaction();
			test = (Test) session.get(Test.class, "11111");
			if (test != null) {
				System.out.println(test);
			}
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		assertNull(test);
	}
}
