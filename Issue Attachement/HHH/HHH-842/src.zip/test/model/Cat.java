package test.model;

import java.io.Serializable;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class Cat implements Serializable {

    /** identifier field */
    private Integer catId;

    /** nullable persistent field */
    private String name;

    /** nullable persistent field */
    private String color;

    /** nullable persistent field */
    private String gender;

    /** persistent field */
    private Set kittens;

    /** full constructor */
    public Cat(String name, String color, String gender, Set kittens) {
        this.name = name;
        this.color = color;
        this.gender = gender;
        this.kittens = kittens;
    }

    /** default constructor */
    public Cat() {
    }

    /** minimal constructor */
    public Cat(Set kittens) {
        this.kittens = kittens;
    }

    public Integer getCatId() {
        return this.catId;
    }

    public void setCatId(Integer catId) {
        this.catId = catId;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return this.color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getGender() {
        return this.gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Set getKittens() {
        return this.kittens;
    }

    public void setKittens(Set kittens) {
        this.kittens = kittens;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("catId", getCatId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof Cat) ) return false;
        Cat castOther = (Cat) other;
        return new EqualsBuilder()
            .append(this.getCatId(), castOther.getCatId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getCatId())
            .toHashCode();
    }

}
