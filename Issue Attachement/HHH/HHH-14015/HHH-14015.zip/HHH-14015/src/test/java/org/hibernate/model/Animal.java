package org.hibernate.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "animal")
public class Animal implements Serializable {

    @EmbeddedId
    private AnimalId id;
    @Column(name = "info", nullable = false)
    private String info;


    public AnimalId getId() {
        return id;
    }

    public void setId(AnimalId id) {
        this.id = id;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
