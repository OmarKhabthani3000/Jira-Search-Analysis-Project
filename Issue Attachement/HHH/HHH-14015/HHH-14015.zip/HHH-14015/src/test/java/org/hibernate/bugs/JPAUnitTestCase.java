package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import org.junit.Test;

import javax.persistence.Persistence;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    @Test
    public void hhh123Test() throws Exception {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("templatePU");
        EntityManager em = emf.createEntityManager();
        em.createQuery("SELECT 1 FROM Animal a WHERE a.id = ALL(SELECT b.id FROM Animal b)").getResultList();
        emf.close();
    }
}
