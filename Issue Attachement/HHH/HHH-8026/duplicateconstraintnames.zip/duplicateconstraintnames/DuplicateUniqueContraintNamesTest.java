package duplicateconstraintnames;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.HSQLDialect;
import org.hibernate.dialect.Oracle10gDialect;
import org.hibernate.dialect.SQLServer2005Dialect;
import org.hibernate.exception.ConstraintViolationException;

public class DuplicateUniqueContraintNamesTest extends TestCase {
  
  public void testHsqlDb() {
    Configuration cfg = createConfiguration();
    cfg.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
    cfg.setProperty("hibernate.connection.username", "sa");
    cfg.setProperty("hibernate.connection.password", "");
    cfg.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:testdb");
    cfg.setProperty("hibernate.dialect", HSQLDialect.class.getName());

    useSession(cfg);
  }

  public void testOracle() {
    Configuration cfg = createConfiguration();
    cfg.setProperty("hibernate.connection.driver_class", "oracle.jdbc.driver.OracleDriver");
    cfg.setProperty("hibernate.connection.username", "username");
    cfg.setProperty("hibernate.connection.password", "password");
    cfg.setProperty("hibernate.connection.url", "jdbc:oracle:thin:@host:port:sid");
    cfg.setProperty("hibernate.dialect", Oracle10gDialect.class.getName());
    
    useSession(cfg);
  }
  
  public void testMssql() {
    Configuration cfg = createConfiguration();
    cfg.setProperty("hibernate.connection.driver_class", "com.microsoft.sqlserver.jdbc.SQLServerDriver");
    cfg.setProperty("hibernate.connection.username", "username");
    cfg.setProperty("hibernate.connection.password", "password");
    cfg.setProperty("hibernate.connection.url", "jdbc:sqlserver://host:port");
    cfg.setProperty("hibernate.dialect", SQLServer2005Dialect.class.getName());
    
    useSession(cfg);
  }
  
  private Configuration createConfiguration() {
    Configuration cfg = new Configuration();
    cfg.setProperty(Environment.HBM2DDL_AUTO, "create");
    cfg.setProperty(Environment.SHOW_SQL, "true");
    cfg.setProperty(Environment.FORMAT_SQL, "true");
    cfg.addResource("duplicateconstraintnames/duplicateconstraintnames.hbm.xml",
        DuplicateUniqueContraintNamesTest.class.getClassLoader());
    return cfg;
  }
  
  private void useSession(Configuration cfg) {
    @SuppressWarnings("deprecation")
    SessionFactory sf = cfg.buildSessionFactory();
    
    Session session = sf.openSession();
    
    Transaction tx = session.beginTransaction();

    String uniqueString = "unique";
    
    EntityB one = new EntityB();
    one.setUniqueProperty(uniqueString);
    session.save(one);

    try {
      EntityB two = new EntityB();
      two.setUniqueProperty(uniqueString);
      session.save(two);
      
      tx.commit();

      fail("should have raised a ConstraintViolationException");
    } catch (ConstraintViolationException e) {
      // expected
    }

    session.close();
  }

}
