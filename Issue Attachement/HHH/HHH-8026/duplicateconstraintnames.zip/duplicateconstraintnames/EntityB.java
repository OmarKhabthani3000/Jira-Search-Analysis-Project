package duplicateconstraintnames;

public class EntityB {
  
  private long id;
  private String uniqueProperty;
  
  public long getId() {
    return id;
  }
  
  public void setId(long id) {
    this.id = id;
  }
  
  public String getUniqueProperty() {
    return uniqueProperty;
  }
  
  public void setUniqueProperty(String unique) {
    this.uniqueProperty = unique;
  }
  
}
