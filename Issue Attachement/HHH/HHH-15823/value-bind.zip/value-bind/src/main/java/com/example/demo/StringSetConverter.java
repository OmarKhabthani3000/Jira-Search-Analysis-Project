package com.example.demo;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter
public class StringSetConverter implements AttributeConverter<Set<String>, String> {

	@Override
	public String convertToDatabaseColumn(Set<String> attribute) {
		if (attribute == null)
			return null;
		return String.join(",", attribute);
	}

	@Override
	public Set<String> convertToEntityAttribute(String dbData) {
		if (dbData == null)
			return null;
		Set<String> set = new LinkedHashSet<>();
		set.addAll(Arrays.asList(dbData.split(",")));
		return set;
	}

}
