package com.example.demo;

import java.util.Set;

import org.springframework.lang.Nullable;

import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
class Post {

	@Id
	@GeneratedValue
	private @Nullable Long id;

	@Convert(converter = StringSetConverter.class)
	private Set<String> tags;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Set<String> getTags() {
		return tags;
	}

	public void setTags(Set<String> tags) {
		this.tags = tags;
	}

}
