package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@DataJpaTest
@EnableJpaRepositories(basePackageClasses = PostRepository.class)
@EntityScan(basePackageClasses = Post.class)
class PostRepositoryTests {

	@Autowired
	PostRepository repository;

	@Test
	void test() {
		Post entity = new Post();
		entity.setTags(Set.of("foo", "bar"));
		this.repository.save(entity);
		Post post = this.repository.findAll().get(0);
		assertThat(post.getTags()).contains("foo", "bar");

		Specification<Post> containsFoo = (root, query, builder) -> builder
				.like(builder.concat(builder.concat(",", root.get("tags")), ","), "%foo%");
		assertThat(this.repository.count(containsFoo)).isEqualTo(1L); // java.lang.AssertionError with hibernate 6.x
	}

}
