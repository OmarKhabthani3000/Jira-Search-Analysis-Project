package test.hibernate;

import java.util.List;
import java.util.Set;
import java.util.Iterator;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Query;

import annotations.Company;
import annotations.Employee;

public class DBFunctions {

	Logger LOGGER = LoggerFactory.getLogger(DBFunctions.class);
	SessionFactory sessionFactory; 	
	
	public DBFunctions(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory; 
	}

	public void doCreateRecords() {

		try {

			Session s = sessionFactory.getCurrentSession();
			
			printMessage("Info", "Create company records in the sql database");

			Company company1 = new Company("SOBIS Software GmbH");
			company1 = getCreateCompany(company1);

			Company company2 = new Company("SOBIS Software Pvt. Ltd.");
			company2 = getCreateCompany(company2);

			Company company3 = new Company("SOBIS Software GmbH");
			company3 = getCreateCompany(company3);
				
			Company company4 = new Company("SOBIS K.S.A.");
			company4 = getCreateCompany(company4);

			printMessage("Info", "Create employee records in the sql database");
	
			int j = 1;
			
			for (int i = 101; i <= 110; i++) {
						
				Employee employee = new Employee("Employee Number " + i);
					
				switch (j) {
				case 1:
					employee.setCompany(company1);
					break;
				case 2:
					employee.setCompany(company2);
					break;
				case 3:
					employee.setCompany(company3);
					break;
				case 4:
					employee.setCompany(company4);
					break;
				default:
					j = 1;
					employee.setCompany(company1);
					break;
				}

				j++;
				employee = getCreateEmployee(employee);

			}

			s.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	


	private Employee getCreateEmployee(Employee employee) {


		printMessage("Info", "Get/create employee record: " + employee.getLastName());

		List<?> list = null;
		
		try {
	
			list =  getQueryList(employee, Employee.HQL_Query_Find_Employee_byLastName);
			
			if (list == null || list.isEmpty()) {
				createEmployee(employee);	
				printMessage("Info", "Employee created: " + employee.getLastName());
			} else { //can only be one entry 
				for (int j = 0; j < list.size(); j++) {
					employee = (Employee) list.get(j);
					printMessage("Info", "Employee found: " + employee.getLastName());
				}
			}
			
		} catch (Exception e) {
			printMessage("Error","ERROR Employee record could not be created or got !");
			printMessage("Error","ERROR: " + e.getMessage());
			e.printStackTrace();
		}
				
		return employee;
	}
	
	private void createEmployee(Employee employee) {
		Session s = sessionFactory.openSession();
		Transaction tx = null;

		try {
			tx = s.beginTransaction();
			s.save(employee);
			tx.commit();
			
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}

			e.printStackTrace();
		} finally {
			if (s.isOpen()) {
				s.close();
			}	
		}
	}

	private Company getCreateCompany(Company company) {
		printMessage("Info","Create/get company record: " + company.toString());
		List<?> list = null;
		
		try {
			
			list = getQueryList(company, Company.HQL_Query_Find_Company_ByName);
			
			if (list == null || list.isEmpty()) {
				createCompany(company);
				printMessage("Info","Company created: " + company.getCompanyName());
			} else { //can only be one entry 
				for (int j = 0; j < list.size(); j++) {
					company = (Company) list.get(j);
					printMessage("Info","Company found: " + company.getCompanyName());
				}
			}
			
		} catch (Exception e) {
			printMessage("Error","ERROR Company record could not be created or got !");
			printMessage("Error","ERROR: " + e.getMessage());
			e.printStackTrace();
		}
				
		return company;
	}
	
	private void createCompany(Company company) {
		Session s = sessionFactory.openSession();
		Transaction tx = null;

		try {
			tx = s.beginTransaction();
			s.save(company);
			tx.commit();

		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			e.printStackTrace();
		} finally {
			if (s.isOpen()) {
				s.close();
			}	
		}
	}

	private List<Company> getQueryList(Company company, String hqlQuery) {
		
		Session s = sessionFactory.openSession();
		Transaction tx = null;
		List<Company> list = null;

		String companyName = null; 
		String country = null;
		String city = null;
		String zip = null; 
		String street = null;
		
		try {
			tx = s.beginTransaction();

			if (company != null) {
				companyName = company.getCompanyName();
				
			Query query = s.createQuery(hqlQuery)
					.setParameter("companyName", companyName);

			list = query.list();

			}
			
		} catch (Exception e) {

			printMessage("Error",e.getCause() + ": " + e.getMessage());
			if (tx != null) {
				tx.rollback();
			}
			e.printStackTrace();

		} finally {
			if (s.isOpen()) {
				s.close();
			}	
		}
		
		return (List<Company>) list; 
	}
	
	private List<Employee> getQueryList(Employee employee, String hqlQuery) {

		Session s = sessionFactory.openSession();
		Transaction tx = null;

		List<?> list = null; 
		
		String lastName = null;
		
		try {
			
			tx = s.beginTransaction();
			
			if (employee != null) {
				lastName = employee.getLastName();
				
			//java.lang.ClassCastException: java.lang.String cannot be cast to java.lang.Long
				Query query = s.createQuery(hqlQuery)
					.setParameter("lastName", lastName);
					
				 list = query.list();
			}
			
		} catch (Exception e) {
			printMessage("Error",e.getCause() + ": " + e.getMessage());
			if (tx != null) {
				tx.rollback();
			}
			e.printStackTrace();

		} finally {
			if (s.isOpen()) {
				s.close();
			}	
		}

		return (List<Employee>) list; 
	}	

	public void printList(List list) {

		printMessage("Info", "##################################");
		printMessage("Info", "Records found: " + list.size());
		printMessage("Info","Records found: " + list.toString());
		printMessage("Info", "##################################");
		
		for (Iterator iterator = list.iterator(); 
				iterator.hasNext();
			)
				{
			Company company = (Company) iterator.next();
			printMessage("Info:", "# Get only the company name:" + "# Company Name: " + company.getCompanyName());
			printMessage("Info","# Get the company and the accociated employees: " + company.getCompanyName() + " " + company.getEmployees());
			printMessage("Info","----------------------------------");
			
			Set<Employee> employees = company.getEmployees();
			
			Iterator iteratorEmp = null;
			for (iteratorEmp = employees.iterator();
					iteratorEmp.hasNext();)
					{
						printMessage("Info","----------------------------------");
						Employee employee = (Employee) iteratorEmp.next(); 

						printMessage("Info","# Employee sql id: " + employee.getId());
						printMessage("Info","# Employee last name: " + employee.getLastName());
					}	
				}
	}

	public void printMessage(String strType, String strMessage) {

		if (strType.equals("Info")) {
			LOGGER.info(strMessage);			
		} 
		if (strType.equals("Debug")) {
			LOGGER.debug(strMessage);
		}
		if (strType.equals("Error")) {
			LOGGER.error(strMessage);
		}

		System.out.println(strMessage);
	}

	
	
}
