package test.hibernate;

import org.junit.Test;
import org.junit.Before;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import test.hibernate.DBFunctions;

import annotations.Company;
import annotations.HibernateUtil;

public class HibernateIssueFetchModeBug {
	
	private static SessionFactory sessionFactory;
	private static Session session;
	DBFunctions dbFunction;
	
	Criteria criteria;

	@Before
	public void setUp() {

		try {
			
			sessionFactory = HibernateUtil.getSessionFactory(true);
			dbFunction = new DBFunctions(sessionFactory);
			dbFunction.doCreateRecords();

		} catch (Exception e) {
				e.printStackTrace();
		}
	}


	@Test
	public void testCriteriaByFetchTypeSelect() {
		
		dbFunction.printMessage("Info", "##################################");
		dbFunction.printMessage("Info", "get collection/result set by testCriteriaByFetchTypeSelect == .LAZY.deprecated");
		dbFunction.printMessage("Info", "##################################");
		
		Transaction tx = null;

		try {

			session = sessionFactory.getCurrentSession();
			tx = session.beginTransaction();				   
				 
			Criteria crit = session
					.createCriteria(Company.class) 
					.setFetchMode(Company.FIELD_COMPANY_NAME, FetchMode.JOIN)
					.add(Restrictions.eq(Company.FIELD_ID, (long) 1));
				
			List list = crit.list();
			tx.commit();

			dbFunction.printMessage("Info", "##################################");
			dbFunction.printList(list);
				

		} catch (HibernateException e) {
	 		dbFunction.printMessage("Error", "Hibernate exception !" + e.getLocalizedMessage());
	 		dbFunction.printMessage("Error", e.getCause().toString() + ": " + e.getMessage());
			e.printStackTrace();
			if (tx!=null) {
	        	 tx.rollback();
	         }

		} catch (Exception e) {
			dbFunction.printMessage("Error", "ERROR Criteria test was not successful !");
			e.printStackTrace();

		} finally {
			if (session != null) {
				if (session.isOpen()) {
					session.close();	
				}
			}
		}

	}	

}
