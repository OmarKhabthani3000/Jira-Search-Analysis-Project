package annotations;

import java.util.EnumSet;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataBuilder;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.spi.MetadataImplementor;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.hibernate.tool.schema.TargetType;

public class HibernateUtil {

	   private static SessionFactory sessionFactory;

		// create the sql database tables
		private static final String PORT = "3306";
		private static final String HOST = "localhost";
		private static final String DBNAME = "dbhibernateHHHFetchTypeLazy";
		private static final String doCREATE_DATABASE_IF_NOT_EXIST = "&amp;createDatabaseIfNotExist=true";
		private static final String USER_NAME = "root";
		private static final String USER_PASSWORD = "";
	   
/*
	   private static SessionFactory buildSessionFactory() {

		   try {
	            // Create the SessionFactory from hibernate.cfg.xml
	            return new Configuration().configure().buildSessionFactory();
	      
		   }catch (Throwable ex) {
	            // Make sure you log the exception, as it might be swallowed
	            System.err.println("Initial SessionFactory creation failed." + ex);
	            throw new ExceptionInInitializerError(ex);
	       }
	    }
*/
	   
	   public static SessionFactory getSessionFactory() {
	        return sessionFactory;
	    }
	   
	    public static SessionFactory getSessionFactory(boolean doCreateDatabase) throws Exception {
	        if (sessionFactory == null) {
	            // loads configuration and mappings
	            Configuration configuration = new Configuration()
	            		.addAnnotatedClass(annotations.Employee.class)
	            		.addAnnotatedClass(annotations.Company.class)
	            		.addAnnotatedClass(annotations.Employee.class)
	            		.addAnnotatedClass(annotations.Company.class)
	            		.setProperty(AvailableSettings.GENERATE_STATISTICS, "true")
	            		.setProperty(AvailableSettings.DRIVER, "com.mysql.jdbc.Driver")
	            		.setProperty(AvailableSettings.URL,
	            				"jdbc:mysql://localhost:3306/dbhibernateHHHFetchTypeLazy")
//	            		.setProperty(AvailableSettings.URL,
//	            				"jdbc:mysql://" + HOST + ":" + PORT + "/" + DBNAME + doCREATE_DATABASE_IF_NOT_EXIST)
	            		.setProperty(AvailableSettings.USER, USER_NAME)
	            		.setProperty(AvailableSettings.PASS, USER_PASSWORD)
	            		.setProperty(AvailableSettings.POOL_SIZE, "5")
	            		.setProperty(AvailableSettings.DIALECT, "org.hibernate.dialect.MySQLDialect")
	            		.setProperty(AvailableSettings.CURRENT_SESSION_CONTEXT_CLASS, "thread")
	            		.setProperty(AvailableSettings.HBM2DDL_AUTO, "update")

	            		// <property name="cache.provider_class">org.hibernate.cache.NoCacheProvider</property>

	            		// <property name="use_sql_comments">true</property>
	            		.setProperty(AvailableSettings.USE_SQL_COMMENTS, "true")

	            		// <property name="format_sql">true</property>
	            		.setProperty(AvailableSettings.FORMAT_SQL, "true")

	            		// <property name="hibernate.show_sql">true</property>
	            		.setProperty(AvailableSettings.SHOW_SQL, "true");

	            configuration.configure();
	            ServiceRegistry serviceRegistry
	                = new StandardServiceRegistryBuilder()
	                    .applySettings(configuration.getProperties()).build();
	            
	            if (doCreateDatabase) {
	 	           createDatabase(configuration, serviceRegistry);	            	
	            }
	            
	            // builds a session factory from the service registry
	            sessionFactory = configuration.buildSessionFactory(serviceRegistry);           
	        }
	         
	        return sessionFactory;
	    }
	 
	    
		private static void createDatabase(Configuration cfg, ServiceRegistry serviceRegistry) throws Exception {
			
			MetadataSources metadataSources =  new MetadataSources(serviceRegistry);
			MetadataBuilder metadataBuilder = metadataSources
				    .getMetadataBuilder(cfg.getStandardServiceRegistryBuilder().build());
			
			Metadata metadata = metadataBuilder.build();
			MetadataImplementor metadataImpl = (MetadataImplementor) metadata;

//			MetadataImplementor metadataImpl = (MetadataImplementor) metadata;
//			SchemaExport schema = new SchemaExport(metadataImpl);
//			schema.create(true, true);
			
			SchemaExport schema = new SchemaExport();
			EnumSet<TargetType> e;
			e = EnumSet.of(TargetType.DATABASE); 
			schema.create(e, metadataImpl);
		}
}
