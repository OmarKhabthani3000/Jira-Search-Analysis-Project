package annotations;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import java.io.Serializable;


@Entity  
@Table(name= "table_Companies")  
public class Company implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8141434259660442726L;
	public static final String SQL_TABLE_ID_GENERATOR = "cpyIDGenerator";
	public static final String SQL_TABLE_COMPANIES = "table_Companies";
	public static final String SQL_TABLE_COMPANY_USERS = "company_users";
	public static final String SQL_TABLE_COMPANIES_FIELD_COMPANY_ID = "cpy_ID";
	public static final String SQL_TABLE_COMPANIES_FIELD_COMPANY_NAME = "cpy_NAME";

	public static final String FIELD_EMPLOYEES = "employees";
	public static final String FIELD_COMPANY_NAME = "companyName";
	public static final String FIELD_ID = "id";

	
	public static final String HQL_Query_Find_Company_ByName = "from Company where "
			+ "companyName = :companyName ";


	//Constructors
	public Company() {
	}

	
	//Constructors
	public Company(String strCompanyName) {
		//first check if the company address entry exist already
		this.companyName = strCompanyName; 
		this.employees = new HashSet<Employee>();
	}

	//Constructors
	public Company(String strCompanyName, Set<Employee> employees) {
		//first check if the company address entry exist already
		this.companyName = strCompanyName; 
		this.employees = employees;
	}
	
	
	@TableGenerator(
            name=SQL_TABLE_ID_GENERATOR, 
            table="ID_GEN", 
            pkColumnName="GEN_KEY", 
            valueColumnName="GEN_VALUE", 
            pkColumnValue=SQL_TABLE_COMPANIES_FIELD_COMPANY_ID, 
            allocationSize=1)
	
	@Id
	@Column(name=SQL_TABLE_COMPANIES_FIELD_COMPANY_ID, nullable=false,unique=true)
	@GeneratedValue(strategy=GenerationType.TABLE, generator=SQL_TABLE_ID_GENERATOR)
	private long id;
	public long getId() {  
	    return id;  
	}  

	@OneToMany(fetch=FetchType.LAZY)
	@JoinTable(name = SQL_TABLE_COMPANY_USERS, 
		joinColumns = {@JoinColumn(name = SQL_TABLE_COMPANIES_FIELD_COMPANY_ID)}, 
		inverseJoinColumns = { @JoinColumn(name = Employee.SQL_TABLE_EMPLOYEE_FIELD_ID_EMPLOYEE)}
	)
	
	private Set<Employee> employees;
	public  Set<Employee> getEmployees() {
		return this.employees;
	}

	public  Set<Employee> getEmployees(long cpyID) {

		return this.employees;
	}

	public  void setEmployees(Set<Employee> employees) {
		this.employees = employees;
	}
	
	@Column(name=SQL_TABLE_COMPANIES_FIELD_COMPANY_NAME)
	private String companyName;  
	public String getCompanyName() {  
	    return companyName;  
	}  
	public void setCompanyName(String strCompanyName) {  
	    this.companyName = strCompanyName;  
	}  
	
}
