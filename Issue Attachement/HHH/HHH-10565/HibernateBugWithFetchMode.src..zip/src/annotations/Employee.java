package annotations;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import java.io.Serializable;


@Entity  
@Table(name= "table_Employees")
public class Employee implements Serializable {
	
	private static final long serialVersionUID = 7958378780993630136L;
	public static final String SQL_TABLE_ID_GENERATOR = "empIDGenerator";
	public static final String SQL_TABLE_EMPLOYEES = "table_Employees";
	public static final String SQL_TABLE_COMPANY_USERS = "company_users";
	public static final String SQL_TABLE_EMPLOYEE_FIELD_ID_EMPLOYEE = "emp_ID";
	public static final String SQL_TABLE_EMPLOYEE_FIELD_NAME_LAST = "emp_LASTNAME";

	public static final String FIELD_LAST_NAME = "lastName";
	public static final String FIELD_COMPANY = "companyOfUser";
	
	public static final String HQL_Query_Find_Employee_byLastName = "from Employee where " 
			+ "lastName like :lastName"; 
	
	@TableGenerator(
            name=SQL_TABLE_ID_GENERATOR, 
            table="ID_GEN", 
            pkColumnName="GEN_KEY", 
            valueColumnName="GEN_VALUE", 
            pkColumnValue=SQL_TABLE_EMPLOYEE_FIELD_ID_EMPLOYEE, 
            allocationSize=1)
	
	@Id
	@Column(name=SQL_TABLE_EMPLOYEE_FIELD_ID_EMPLOYEE, nullable=false, unique=true)
    @GeneratedValue(strategy=GenerationType.TABLE, generator=SQL_TABLE_ID_GENERATOR)
  	private long id;
	public long getId() {  
	    return id;  
	} 	

	public Employee() {
	}
	
	public Employee(String strLastName) {
		this.lastName = strLastName;
	}


	@Column(name=SQL_TABLE_EMPLOYEE_FIELD_NAME_LAST, nullable=false)
	private String lastName;  
	public String getLastName() {  
	    return lastName;  
	}  
	public void setLastName(String strLastName) {  
	    this.lastName = strLastName;  
	}  

	
   @ManyToOne(cascade=CascadeType.ALL, fetch=FetchType.LAZY)
   @JoinTable(name = SQL_TABLE_COMPANY_USERS, 
   	joinColumns = {@JoinColumn(name = SQL_TABLE_EMPLOYEE_FIELD_ID_EMPLOYEE) }, 
   	inverseJoinColumns = { @JoinColumn(name = Company.SQL_TABLE_COMPANIES_FIELD_COMPANY_ID)})
   private Company companyOfUser;
   public Company getCompany() {
       return companyOfUser;
   }
 
   public void setCompany(Company company) {
       this.companyOfUser = company;
   }
	
}
