package hibernatemapcascadekey;

public class MyValueEntity {

    private Long id;

    private String valueString;

    public MyValueEntity() {}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getValueString() {
        return valueString;
    }

    public void setValueString(String valueString) {
        this.valueString = valueString;
    }
}
