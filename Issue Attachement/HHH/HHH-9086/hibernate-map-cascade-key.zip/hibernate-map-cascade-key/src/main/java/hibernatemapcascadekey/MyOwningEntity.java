package hibernatemapcascadekey;

import java.util.LinkedHashMap;
import java.util.Map;

public class MyOwningEntity {

    private Long id;

    private Map<MyKeyEntity, MyValueEntity> keyValueMap;

    public MyOwningEntity() {
        keyValueMap = new LinkedHashMap<MyKeyEntity, MyValueEntity>();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Map<MyKeyEntity, MyValueEntity> getKeyValueMap() {
        return keyValueMap;
    }

    public void setKeyValueMap(Map<MyKeyEntity, MyValueEntity> keyValueMap) {
        this.keyValueMap = keyValueMap;
    }
}
