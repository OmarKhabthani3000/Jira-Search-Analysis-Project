package hibernatemapcascadekey;

public class MyKeyEntity {

    private Long id;

    private String keyString;

    public MyKeyEntity() {}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getKeyString() {
        return keyString;
    }

    public void setKeyString(String keyString) {
        this.keyString = keyString;
    }
}
