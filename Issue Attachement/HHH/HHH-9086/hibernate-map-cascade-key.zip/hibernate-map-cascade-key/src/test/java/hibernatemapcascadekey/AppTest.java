package hibernatemapcascadekey;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.TransientObjectException;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

import java.io.Serializable;
import static junit.framework.Assert.*;

/**
 * Unit test for simple App.
 */
public class AppTest //extends TestCase
{
    static Configuration configuration;
    static SessionFactory sessionFactory;

    static {
        configuration = new Configuration().configure();
        sessionFactory = configuration.buildSessionFactory();
    }

//    Test MyKeyEntity just to make sure it works
    @Test
    public void testMyKeyEntity()
    {
        Session session = getSession();
        session.beginTransaction();

        MyKeyEntity myKeyEntity = new MyKeyEntity();
        Serializable id = session.save(myKeyEntity);
        session.getTransaction().commit();
        session.close();

//        Get a new session to assure a proper select is done
        session = getSession();
        MyKeyEntity mySavedKeyEntity = (MyKeyEntity) session.get(MyKeyEntity.class, id);
        assertNotNull(mySavedKeyEntity);
        assertEquals(myKeyEntity.getKeyString(), mySavedKeyEntity.getKeyString());
        session.close();
    }


//    Test testMyValueEntity just to make sure it works
    @Test
    public void testMyValueEntity()
    {
        Session session = getSession();
        session.beginTransaction();

        MyValueEntity myValueEntity = new MyValueEntity();
        Serializable id = session.save(myValueEntity);
        session.getTransaction().commit();
        session.close();

//        Get a new session to assure a proper select is done
        session = getSession();
        MyValueEntity mySavedValueEntity = (MyValueEntity) session.get(MyValueEntity.class, id);
        assertNotNull(mySavedValueEntity);
        assertEquals(myValueEntity.getValueString(), mySavedValueEntity.getValueString());
        session.close();
    }

//    Test the way it works.  Save the key and let hibernate cascade the save of teh value
    @Test
    public void testMyOwningEntity() {
        MyOwningEntity myOwningEntity = new MyOwningEntity();
        MyKeyEntity myKeyEntity = new MyKeyEntity();
        myKeyEntity.setKeyString("keyString");
        MyValueEntity myValueEntity = new MyValueEntity();
        myValueEntity.setValueString("valueString");
        myOwningEntity.getKeyValueMap().put(myKeyEntity, myValueEntity);

        Session session = getSession();
        session.beginTransaction();
//        Save the key.  The value will be added because of the cacsade="all" on the mapping
        session.save(myKeyEntity);
        Serializable id = session.save(myOwningEntity);

        session.getTransaction().commit();
        session.close();

//        Get a new session to assure a proper select is done
        session = getSession();
        MyOwningEntity mySavedOwningEntity = (MyOwningEntity) session.get(MyOwningEntity.class, id);
        assert 1 == mySavedOwningEntity.getKeyValueMap().size();
        assertEquals("keyString", ((MyKeyEntity)(mySavedOwningEntity.getKeyValueMap().keySet().toArray()[0])).getKeyString());
        assertEquals("valueString", ((MyValueEntity)(mySavedOwningEntity.getKeyValueMap().values().toArray()[0])).getValueString());
        session.close();
    }

//    I actually do not expect this exception at all!  But it is thrown because the key is still transient.
    @Test(expected = TransientObjectException.class)
    public void testMyOwningEntityDoesNotCascadeKey() {
        MyOwningEntity myOwningEntity = new MyOwningEntity();
        MyKeyEntity myKeyEntity = new MyKeyEntity();
        myKeyEntity.setKeyString("keyString");
        MyValueEntity myValueEntity = new MyValueEntity();
        myValueEntity.setValueString("valueString");
        myOwningEntity.getKeyValueMap().put(myKeyEntity, myValueEntity);

        Session session = getSession();
        session.beginTransaction();
//        Do not save the key

//        Save the value just for science even though we already know the save will cascade
        session.save(myValueEntity);
        Serializable id = session.save(myOwningEntity);

        session.getTransaction().commit();
        session.close();
    }

    private Session getSession() {
        return sessionFactory.openSession();
    }
}
