package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.MainTable;

@Repository
public interface MainTableRepo extends JpaRepository<MainTable, Long> {

	@Query("SELECT id FROM MainTable mt where (select count(*) from SubTable st where st.mainTable = mt.id) > 1")
	List<Long> test();

}
