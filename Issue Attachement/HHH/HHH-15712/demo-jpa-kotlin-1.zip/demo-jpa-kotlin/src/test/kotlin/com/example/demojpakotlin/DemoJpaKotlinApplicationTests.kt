package com.example.demojpakotlin

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class DemoJpaKotlinApplicationTests {

	@Test
	fun contextLoads() {
	}

}
