package org.demo;

public enum BookType {
    MAIN,
    SUB
}
