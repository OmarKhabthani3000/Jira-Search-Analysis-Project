package sample.persistence.envers;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.envers.RevisionListener;

public class RequestContextRevisionListener implements RevisionListener {

    private static final Log logger = LogFactory.getLog(RequestContextRevisionListener.class);

    @Override
    public void newRevision(Object obj) {
        RequestContextRevisionEntity revEntity = (RequestContextRevisionEntity) obj;
        //RequestContextAccessor & RequestContext are dummies!
        RequestContext requestContext = RequestContextAccessor.get();
        revEntity.setRequestId(requestContext.getId());
        revEntity.setClientId(requestContext.getClientId());
        revEntity.setUsername(requestContext.getUser());
    }

}
