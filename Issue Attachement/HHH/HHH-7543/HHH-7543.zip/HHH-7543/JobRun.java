package sample.jobframework.job;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <p>
 * A job run object corresponds to a single run of a requested job. If the job was successful in the first run, there
 * will only be one job run object for this job request. But if there were errors or the job was paused and resumed
 * there will be more than one job run object for this job request.
 * </p>
 */
public abstract class JobRun implements java.io.Serializable {

    /** Logger for the class java.lang.String */
    private static final Log LOGGER = LogFactory.getLog(JobRun.class);

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -4062017506351441100L;

    /**
     * the classes discriminator as stored in the class column
     */
    public static final String CLASS_DISCRIMINATOR = "JobRun";

    /**
     * <p>
     * The status of a job run describes its current position in its life cycle and if the job run was successful.
     * Possible values are: INITIALISING, RUNNING, PAUSING, STOPPED, FINISHED, FINISHED_WITH_ERRORS, FAILED, FATAL,
     * CLEANING_UP.
     * </p>
     */
    @NotNull
    private String status;

    /**
     * <p>
     * The time this job run started.
     * </p>
     */
    @NotNull
    private org.joda.time.LocalDateTime startTime;

    /**
     * <p>
     * The time this job run ended.
     * </p>
     */
    private org.joda.time.LocalDateTime endTime;

    /**
     * 
     */
    private java.lang.Long id;

    /**
     * <p>
     * A single job request might result in a single successful job run. In other cases, there might be more than one
     * job run for a single job request.
     * </p>
     */
    private SomeRelationEntity jobRequest = null;

    /**
     * The name of the user that inserted this entity
     */
    private String insertedBy;

    /**
     * The date at which this entity was inserted
     */
    private org.joda.time.LocalDateTime insertedAt;

    /**
     * The name of the user that updated this entity last.
     */
    private String updatedBy;

    /**
     * The date of the last modification of this entity
     */
    private org.joda.time.LocalDateTime updatedAt;

    /**
     * initializer template method to ensure it is correctly implemented in JobRunImpl.
     */
    protected abstract void _createJobRun(SomeRelationEntity jobRequest);

    /**
     * No-op default constructor
     */
    public JobRun() {
        super();
        this.insertedAt = new org.joda.time.LocalDateTime();
        this.insertedBy = sample.context.RequestContext.CLIENTID_UNKNOWN;
    }

    /**
     * <p>
     * The status of a job run describes its current position in its life cycle and if the job run was successful.
     * Possible values are: INITIALISING, RUNNING, PAUSING, STOPPED, FINISHED, FINISHED_WITH_ERRORS, FAILED, FATAL,
     * CLEANING_UP.
     * </p>
     */
    public String getStatus() {
        return this.status;
    }

    /**
     * <p>
     * The status of a job run describes its current position in its life cycle and if the job run was successful.
     * Possible values are: INITIALISING, RUNNING, PAUSING, STOPPED, FINISHED, FINISHED_WITH_ERRORS, FAILED, FATAL,
     * CLEANING_UP.
     * </p>
     */
    protected void setStatus(String status) {
        this.status = status;
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Set JobRun status of job " + getId() + " to " + getStatus());
        }
    }

    /**
     * <p>
     * The time this job run started.
     * </p>
     */
    public org.joda.time.LocalDateTime getStartTime() {
        return this.startTime;
    }

    /**
     * <p>
     * The time this job run started.
     * </p>
     */
    protected void setStartTime(org.joda.time.LocalDateTime startTime) {
        this.startTime = startTime;
    }

    /**
     * <p>
     * The time this job run ended.
     * </p>
     */
    public org.joda.time.LocalDateTime getEndTime() {
        return this.endTime;
    }

    /**
     * <p>
     * The time this job run ended.
     * </p>
     */
    protected void setEndTime(org.joda.time.LocalDateTime endTime) {
        this.endTime = endTime;
    }

    /**
     * 
     */
    public java.lang.Long getId() {
        return this.id;
    }

    /**
     * 
     */
    public void setId(java.lang.Long id) {
        this.id = id;
    }

    /**
     * Returns the name of the user that inserted this entity
     * 
     * @return The name of the user that inserted this entity
     */
    public String getInsertedBy() {
        return insertedBy;
    }

    /**
     * Sets the name of the user that inserted this entity
     */
    protected void setInsertedBy(String insertedBy) {
        this.insertedBy = insertedBy;
    }

    /**
     * Returns the date at which this entity was inserted
     * 
     * @return The date at which this entity was inserted
     */
    public org.joda.time.LocalDateTime getInsertedAt() {
        return insertedAt;
    }

    /**
     * Sets the date at which this entity was inserted
     */
    protected void setInsertedAt(org.joda.time.LocalDateTime insertedAt) {
        this.insertedAt = insertedAt;
    }

    /**
     * Returns the name of the user that updated this entity last.
     * 
     * @return The name of the user that updated this entity last.
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the name of the user that updated this entity last.
     */
    protected void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * Returns the date of the last modification of this entity
     * 
     * @return The date of the last modification of this entity
     */
    public org.joda.time.LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    /**
     * Sets the date of the last modification of this entity
     */
    protected void setUpdatedAt(org.joda.time.LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    /**
     * Returns the jobRequest property with lazy initialization.
     */
    protected SomeRelationEntity getJobRequest() {
        return this.jobRequest;
    }

    /**
     * Sets the jobRequest property.
     */
    protected void setJobRequest(SomeRelationEntity jobRequest) {
        this.jobRequest = jobRequest;
    }

    /**
     * 
     * @param exception
     * 
     * @param
     * 
     */
    public abstract void setException(java.lang.Throwable exception);

    /**
     * <p>
     * Sets the status of this jobRun to the final status FAILED.
     * </p>
     * 
     * @param exception
     * 
     * @param
     * 
     */
    public abstract void setFailed(java.lang.Exception exception);

    /**
     * <p>
     * Sets the status of this jobRun to the final status FINISHED.
     * </p>
     * 
     * @param
     * 
     */
    public abstract void setFinished();

    /**
     * 
     * @param
     * 
     */
    public abstract void setInitializing();

    /**
     * 
     * @param
     * 
     */
    public abstract void setRunning();

    /**
     * 
     * @param
     * 
     */
    public abstract void setPausing();

    /**
     * 
     * @param
     * 
     */
    public abstract void setCleaningUp();

    /**
     * 
     * @param
     * 
     */
    public abstract void setStopped();

    /**
     * 
     * @param
     * 
     */
    public abstract boolean isInFinalState();

    /**
     * 
     * @param
     * 
     */
    public abstract boolean isRunning();

    /**
     * 
     * @param
     * 
     */
    public abstract boolean isPausing();

    /**
     * <p>
     * Sets the status of this jobRun to the final status FATAL.
     * </p>
     * 
     * @param exception
     * 
     * @param
     * 
     */
    public abstract void setFatal(java.lang.Exception exception);

    /**
     * 
     * @param
     * 
     */
    public abstract boolean isFatal();

    /**
     * 
     * @param
     * 
     */
    public abstract boolean isFailed();

    /**
     * validate this entity
     */
    @SuppressWarnings("unchecked")
    public Set<ConstraintViolation<?>> validate() {
        Set constraintViolations = BeanValidatorFactory.createValidator().validate(this);
        return constraintViolations;
    }

    /**
     * check if entity is valid
     */
    public boolean isValid() {
        return BeanValidatorFactory.createValidator().validate(this).isEmpty();
    }

    /**
     * check if entity is and throw exception if not
     */
    public void checkValid() throws ConstraintViolationException {
        final Set<ConstraintViolation<?>> constraintViolations = validate();
        if (!constraintViolations.isEmpty()) {
            throw new ConstraintViolationException(constraintViolations);
        }
    }

    /**
     * Compares two instances by its (and its parents') properties
     */
    @Override
    public boolean equals(Object o) {

        if (o instanceof JobRun == false) {
            return false;
        }
        if (this == o) {
            return true;
        }

        JobRun rhs = (JobRun) o;
        return new EqualsBuilder()
                .append(getStatus(), rhs.getStatus())
                .append(getStartTime(), rhs.getStartTime())
                .append(getEndTime(), rhs.getEndTime())
                .append(getId(), rhs.getId())
                .isEquals();

    }

    private transient int cachedHashCode = 0;

    /**
     * Calculates the hash code by the instance's properties and the parents' hash code. Internally caches the hash code
     * after having been computed for the first time. This ensures immutablity and assures correct behavior, if this
     * object is being referenced by a Hibernate association through a Set.
     * 
     * Also, see https://www.hibernate.org/109.html
     */
    @Override
    public int hashCode() {
        if (this.cachedHashCode == 0) {
            this.cachedHashCode = _hashCode();
        }
        return this.cachedHashCode;
    }

    private int _hashCode() {
        return new HashCodeBuilder(960933527, 1000003)
                .append(getStatus())
                .append(getStartTime())
                .append(getEndTime())
                .append(getId()).toHashCode();
    }

    /**
     * Renders name, hash code and state of this entity as a String
     */
    @Override
    public String toString() {
        return new java.lang.StringBuffer().append("[").append(this.getClass().getSimpleName()).append("@")
                .append(Integer.toHexString(System.identityHashCode(this))).append(":")
                .append(" id='").append(getId()).append("'").append("'")
                .append(" status='").append(getStatus()).append("'")
                .append(" startTime='").append(getStartTime()).append("'")
                .append(" endTime='").append(getEndTime()).append("'")
                .append("]").toString();
    }

    // HibernateEntity.vsl merge-point
}