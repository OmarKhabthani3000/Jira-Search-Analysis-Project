package sample.persistence.envers;

import java.text.DateFormat;

import org.hibernate.envers.DefaultRevisionEntity;

 */
@SuppressWarnings("serial")
@org.hibernate.envers.RevisionEntity(RequestContextRevisionListener.class)
public class RequestContextRevisionEntity extends DefaultRevisionEntity {

    private String requestId;
    private String clientId;
    private String username;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String token) {
        this.requestId = token;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "(id=" + getId() + ", revisionDate="
                + DateFormat.getDateTimeInstance().format(getRevisionDate()) + ", requestId=" + getRequestId()
                + ", clientId=" + getClientId() + ", username=" + getUsername() + ")";
    }
}
