package sample.jobframework.job;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;
import org.joda.time.LocalDateTime;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import sample.job.errorhandling.JobErrorHelper;
import sample.job.util.XStreamUtils;
import sample.jobframework.control.JobRequest;

@Audited
public class JobRunImpl extends JobRun {

    private static final long serialVersionUID = -9164186317718556375L;

    @Override
    protected void _createJobRun(SomeRelationEntity jobRequest) {
        setStatus("INITIALISING");
        setStartTime(new LocalDateTime());
        setJobRequest(jobRequest);
    }

    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @Override
    protected SomeRelationEntity getJobRequest() {
        return super.getJobRequest();
    }

    @Override
    public void setInitializing() {
        setStartTime(new LocalDateTime());
        setStatus("INITIALISING");
    }

    @Override
    public void setCleaningUp() {
        setStatus("CLEANING_UP");
    }

    @Override
    public void setFinished() {
        if (isInFinalState()) {
            // we are already in a final state nothing to do.
            return;
        }
        setEndTime(new LocalDateTime());
        // dummy code
        Collection<String> jobErrors = findErrorByJobRun(this);
        if (CollectionUtils.isEmpty(jobErrors)) {
            setStatus("FINISHED");
        } else {
            setStatus("FINISHED_WITH_ERRORS");
        }
    }

    @Override
    public void setPausing() {
        setStatus("PAUSING");
    }

    @Override
    public void setRunning() {
        setStatus("RUNNING");
    }

    @Override
    public void setStopped() {
        setEndTime(new LocalDateTime());
        setStatus("STOPPED");
    }

    @Override
    public void setFailed(Exception exception) {
        setEndTime(new LocalDateTime());
        setStatus("FAILED");
        setException(exception);
    }

    @Override
    public void setFatal(Exception exception) {
        setEndTime(new LocalDateTime());
        setStatus("FATAL");
        setException(exception);
    }

    static List<String> jobEndStates = Arrays.asList("FAILED", "FINISHED", "FATAL",
            "FINISHED_WITH_ERRORS", "STOPPED");

    @Override
    public boolean isInFinalState() {
        String jobStatus = getStatus();
        return jobEndStates.contains(jobStatus);
    }

    @Override
    public boolean isRunning() {
        String jobStatus = getStatus();
        return "RUNNING".equals(jobStatus);
    }

    @Override
    public boolean isPausing() {
        String jobStatus = getStatus();
        return "PAUSING".equals(jobStatus);
    }

    @Override
    public boolean isFatal() {
        String jobStatus = getStatus();
        return "FATAL".equals(jobStatus);
    }

    @Override
    public boolean isFailed() {
        String jobStatus = getStatus();
        return "FAILED".equals(jobStatus);
    }

    @Override
    @Transactional
    public void setException(Throwable exception) {
        if (exception == null) {
            return;
        }
        // dummy code
        store(exception);
    }

}