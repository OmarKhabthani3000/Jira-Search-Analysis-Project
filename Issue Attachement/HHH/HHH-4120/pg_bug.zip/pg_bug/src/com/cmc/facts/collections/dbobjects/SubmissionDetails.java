package com.cmc.facts.collections.dbobjects;


import java.util.Date;

/**
 * SubmissionDetails entity.
 * 
 * @author Sridhar Ratna
 */

public class SubmissionDetails implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5936709110958454522L;
	private long rrid;
	private long sid;
	private long pfid;
	private String appTxnId;
	private Date timeStamp;
	private int schemaVersion;
	private String details;

	/** default constructor */
	public SubmissionDetails() {
	}

	/**
	 * @param rrid
	 * @param sid
	 * @param pfid
	 * @param appTxnId
	 * @param timeStamp
	 * @param schemaVersion
	 * @param details
	 */
	public SubmissionDetails(long rrid, long sid, long pfid, String appTxnId,
			Date timeStamp, int schemaVersion, String details) {
		super();
		this.rrid = rrid;
		this.sid = sid;
		this.pfid = pfid;
		this.appTxnId = appTxnId;
		this.timeStamp = timeStamp;
		this.schemaVersion = schemaVersion;
		this.details = details;
	}


	/**
	 * @return the rrid
	 */
	public long getRrid() {
		return rrid;
	}

	/**
	 * @param rrid the rrid to set
	 */
	public void setRrid(long rrid) {
		this.rrid = rrid;
	}

	/**
	 * @return the sid
	 */
	public long getSid() {
		return sid;
	}

	/**
	 * @param sid the sid to set
	 */
	public void setSid(long sid) {
		this.sid = sid;
	}

	/**
	 * @return the pfid
	 */
	public long getPfid() {
		return pfid;
	}

	/**
	 * @param pfid the pfid to set
	 */
	public void setPfid(long pfid) {
		this.pfid = pfid;
	}

	/**
	 * @return the timeStamp
	 */
	public Date getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * @return the schemaVersion
	 */
	public int getSchemaVersion() {
		return schemaVersion;
	}

	/**
	 * @param schemaVersion the schemaVersion to set
	 */
	public void setSchemaVersion(int schemaVersion) {
		this.schemaVersion = schemaVersion;
	}

	/**
	 * @return the details
	 */
	public String getDetails() {
		return details;
	}

	/**
	 * @param details the details to set
	 */
	public void setDetails(String details) {
		this.details = details;
	}

	/**
	 * @return the appTxnId
	 */
	public String getAppTxnId() {
		return appTxnId;
	}

	/**
	 * @param appTxnId the appTxnId to set
	 */
	public void setAppTxnId(String appTxnId) {
		this.appTxnId = appTxnId;
	}

}