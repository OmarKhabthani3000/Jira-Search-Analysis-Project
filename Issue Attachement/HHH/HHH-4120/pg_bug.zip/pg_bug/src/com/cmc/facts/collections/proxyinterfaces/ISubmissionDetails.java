package com.cmc.facts.collections.proxyinterfaces;


import com.cmc.facts.collections.dao.SubmissionDetailsDAO;
import com.cmc.facts.collections.dbobjects.SubmissionDetails;

/**
 * This is the Interface for <{@link SubmissionDetailsDAO}.
 * hbm file : SubmissionDetails_Master.hbm.xml
 * DB Table : COLL_FP_SUBMISSION_DETAILS
 * @author sridhar
 *
 */
public interface ISubmissionDetails {

	public static final String SID = "sid";
	public static final String PFID = "pfid";

	/**
	 * saves the SubmissionDetails object in database
	 * SubmissionDetails object updated with the generated rrid
	 * @param submissionDetails
	 */
	public abstract void save(SubmissionDetails submissionDetails);


}