package com.cmc.facts.collections.dao;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.cmc.facts.collections.dbobjects.SubmissionDetails;
import com.cmc.facts.collections.proxyinterfaces.ISubmissionDetails;

/**
 * A data access object (DAO) providing persistence and search support for
 * SubmissionDetails entities. Transaction control of the save(), update() and
 * delete() operations can directly support Spring container-managed
 * transactions or they can be augmented to handle user-managed Spring
 * transactions. Each of these methods provides additional information for how
 * to configure it for the desired type of transaction control.
 * 
 * @see com.cmc.facts.collections.dao.SubmissionDetails
 * @author MyEclipse Persistence Tools
 */

public class SubmissionDetailsDAO extends HibernateDaoSupport implements
		ISubmissionDetails {
	private static final Log log = LogFactory
			.getLog(SubmissionDetailsDAO.class);

	/*
	 * saves SubmissionDetails
	 * (non-Javadoc)
	 * 
	 * @see com.cmc.facts.collections.proxyinterfaces.ISubmissionDetails#save(com.cmc.facts.collections.dbobjects.SubmissionDetails)
	 */
	@Override
	public void save(SubmissionDetails submissionDetails) {
		log.debug("saving SubmissionDetails instance");
		submissionDetails.setRrid(123); 
		getHibernateTemplate().save(submissionDetails);
		
		log.debug("save successful");
	}

	/**
	 * return ISubmissionDetails from application context
	 * @param ctx
	 * @return
	 */
	public static ISubmissionDetails getFromApplicationContext(
			ApplicationContext ctx) {
		return (ISubmissionDetails) ctx.getBean("collSubmissionDetailsDAO");
	}
	
	public static void main(String[] args) {
		ISubmissionDetails subDtlsDAO = SubmissionDetailsDAO.getFromApplicationContext(new ClassPathXmlApplicationContext("applicationContext.xml"));
		SubmissionDetails subDtls = new SubmissionDetails();
		subDtls.setAppTxnId("testTxn");
		subDtls.setDetails("testdetails");
		subDtls.setPfid(1234567);
		subDtls.setSchemaVersion(1);
		subDtls.setSid(56789);
		subDtls.setTimeStamp(new Date());
		
		try {
			subDtlsDAO.save(subDtls);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}