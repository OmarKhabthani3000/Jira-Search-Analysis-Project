package org.hibernate.bugs.entities;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.ManyToOne;

@Embeddable
public class EntityBID {

	private EntityC entity;
	private Integer code;

	@ManyToOne
	public EntityC getEntity() {
		return entity;
	}
	public void setEntity(EntityC entity) {
		this.entity = entity;
	}
	
	@Column
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}

	@Override
	public int hashCode() {
		return Objects.hash(code, entity);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EntityBID other = (EntityBID) obj;
		return Objects.equals(code, other.code) && Objects.equals(entity, other.entity);
	}
}
