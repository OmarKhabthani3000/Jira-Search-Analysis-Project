package org.hibernate.bugs.entities;

import java.util.Map;
import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.MapKey;
import jakarta.persistence.Table;

@Entity
@Table(name="entityA")
public class EntityA {

	private Integer id;
	private Map<EntityC,EntityB> bEntities;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	@ManyToMany
	@MapKey(name="id.entity")
	public Map<EntityC, EntityB> getbEntities() {
		return bEntities;
	}
	public void setbEntities(Map<EntityC, EntityB> bEntities) {
		this.bEntities = bEntities;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EntityA other = (EntityA) obj;
		return Objects.equals(id, other.id);
	}	
}