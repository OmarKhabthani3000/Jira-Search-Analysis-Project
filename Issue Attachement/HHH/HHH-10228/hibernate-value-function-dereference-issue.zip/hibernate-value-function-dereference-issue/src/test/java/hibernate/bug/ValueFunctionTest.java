/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hibernate.bug;

import hibernate.bug.model.Person;
import hibernate.bug.model.Workflow;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ValueFunctionTest {
    
    private EntityManagerFactory emf;
    private EntityManager em;
    
    @Before
    public void setup() {
        emf = Persistence.createEntityManagerFactory("Test");
        em = emf.createEntityManager();
        
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p1 = new Person("p1");
        Person p2 = new Person("p2");

        Workflow w1 = new Workflow("w1");
        w1.getPersons().put("main", p1);
        w1.getPersons().put("alternative", p2);

        em.persist(p1);
        em.persist(p2);
        em.persist(w1);
        
        tx.commit();
    }
    
    @After
    public void tearDown() {
        em.close();
        emf.close();
    }
    
    @Test
    public void testWithValue() {
        List<String> elements = em.createQuery("SELECT VALUE(p).name FROM Workflow w LEFT JOIN w.persons p WHERE LENGTH(VALUE(p).name) > 0 ORDER BY VALUE(p).name ASC", String.class).getResultList();
        Assert.assertEquals(2, elements.size());
    }
    
    @Test
    public void testWithoutValue() {
        List<String> elements = em.createQuery("SELECT p.name FROM Workflow w LEFT JOIN w.persons p WHERE LENGTH(p.name) > 0 ORDER BY p.name ASC", String.class).getResultList();
        Assert.assertEquals(2, elements.size());
    }
}
