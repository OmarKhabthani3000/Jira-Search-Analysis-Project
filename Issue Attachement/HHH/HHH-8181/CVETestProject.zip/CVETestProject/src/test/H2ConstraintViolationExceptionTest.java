package test;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.hibernate.cfg.Configuration;

import com.atomikos.jdbc.nonxa.AtomikosNonXADataSourceBean;

public class H2ConstraintViolationExceptionTest extends
		AbstractConstraintViolationExceptionTest {

	@Override
	public void setUpDB(Configuration configuration) {
		Context ctx;
		try {
			ctx = new InitialContext();
			AtomikosNonXADataSourceBean ds = new AtomikosNonXADataSourceBean();
			ds.setUniqueResourceName("test");
			ds.setDriverClassName("org.h2.Driver");
			ds.setPassword("test");
			ds.setUser("test");
			ds.setUrl("jdbc:h2:file:C:/temp/temph2db");
			ctx.rebind("testDS", ds);
			ctx.close();
		} catch (NamingException e) {
			e.printStackTrace();
		}
		configuration
				.setProperty("dialect", ">org.hibernate.dialect.H2Dialect");
	}

}
