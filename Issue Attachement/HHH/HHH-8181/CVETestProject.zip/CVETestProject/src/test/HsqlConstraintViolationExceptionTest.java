package test;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.hibernate.cfg.Configuration;

import com.atomikos.jdbc.nonxa.AtomikosNonXADataSourceBean;

public class HsqlConstraintViolationExceptionTest extends
		AbstractConstraintViolationExceptionTest {

	@Override
	public void setUpDB(Configuration configuration) {
		Context ctx;
		try {
			ctx = new InitialContext();
			AtomikosNonXADataSourceBean ds = new AtomikosNonXADataSourceBean();
			ds.setUniqueResourceName("test");
			ds.setDriverClassName("org.hsqldb.jdbcDriver");
			ds.setUrl("jdbc:hsqldb:mem:testdb;shutdown=false");
			ctx.rebind("testDS", ds);
			ctx.close();
		} catch (NamingException e) {
			e.printStackTrace();
		}
		configuration.setProperty("dialect",
				"org.hibernate.dialect.HSQLDialect");

	}

}
