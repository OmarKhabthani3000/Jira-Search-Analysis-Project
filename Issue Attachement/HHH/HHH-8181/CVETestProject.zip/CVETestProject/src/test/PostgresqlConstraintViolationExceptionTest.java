package test;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.hibernate.cfg.Configuration;

import com.atomikos.jdbc.nonxa.AtomikosNonXADataSourceBean;

public class PostgresqlConstraintViolationExceptionTest extends AbstractConstraintViolationExceptionTest {

	@Override
	public void setUpDB(Configuration configuration) {
			Context ctx;
			try {
				ctx = new InitialContext();
				AtomikosNonXADataSourceBean ds = new AtomikosNonXADataSourceBean();
				ds.setUniqueResourceName("test");
				ds.setDriverClassName("org.postgresql.Driver");
				ds.setUser("postgres");
				ds.setPassword("postgres");
				ds.setUrl("jdbc:postgresql://localhost:5432/test");
				ds.setPoolSize(3);
				ctx.rebind("testDS", ds);
				ctx.close();
			} catch (NamingException e) {
				e.printStackTrace();
			}
			configuration.setProperty("dialect",
					"org.hibernate.dialect.PostgreSQLDialect");
	}


}
