package test;

import java.util.Arrays;
import java.util.List;

import javax.transaction.Status;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import test.entities.CreditCard;
import test.entities.Person;

@SuppressWarnings("nls")
public abstract class AbstractConstraintViolationExceptionTest {
	
	class UnitOfWork {
		public void run(Session s) {
			//
		}
	}

	UserTransaction userTransaction;
	SessionFactory sessionFactory;

	@Before
	public void before() {
		configure();
	}

	@After
	public void after() {
		sessionFactory.close();
	}

	@Test
	public void testCVE() throws Exception {
		doInTransaction(new UnitOfWork() {
			@Override
			public void run(Session s) {
				Person p = new Person();
				p.setName("first");
				CreditCard c = new CreditCard();
				c.setNumber("123");
				c.setPerson(p);
				p.setCreditCards(Arrays.asList(c));
				s.save(p);
			}
		});

		// this should fail with a ConstraintViolationException
		try {
			doInTransaction(new UnitOfWork() {
				@Override
				public void run(Session s) {
					Person p = new Person();
					p.setName("second");
					CreditCard c = new CreditCard();
					c.setNumber("123");
					c.setPerson(p);
					p.setCreditCards(Arrays.asList(c));
					s.save(p);
				}
			});
		} catch (Exception e) {
			boolean isConstraintViolationException = isConstraintViolationException(e);
			if (!isConstraintViolationException)
				Assert.fail("Expected ConstraintViolationException but got " + e.getClass().getName());
		}

		doInTransaction(new UnitOfWork() {
			@Override
			public void run(Session s) {
				System.out.println("\nList Persons");
				@SuppressWarnings("unchecked")
				List<Person> ps = s.createQuery("from Person").list();
				Assert.assertEquals(1, ps.size());
				Assert.assertEquals("first", ps.get(0).getName());
				Assert.assertEquals(1, ps.get(0).getCreditCards().size());
				Assert.assertEquals("123", ps.get(0).getCreditCards().get(0).getNumber());
			}
		});

	}
	
	public abstract void setUpDB(Configuration configuration);

	void configure() {
		Configuration configuration = new Configuration();
		setUpDB(configuration);
		configuration.configure("hibernate.cfg.xml");
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
				.applySettings(configuration.getProperties())
				.buildServiceRegistry();
		userTransaction = new com.atomikos.icatch.jta.UserTransactionImp();
		sessionFactory = configuration
				.buildSessionFactory(serviceRegistry);
	}

	void doInTransaction(UnitOfWork unitOfWork) throws Exception {
		try {
			userTransaction.setTransactionTimeout(240);
			userTransaction.begin();
			Session s = sessionFactory.getCurrentSession();
			unitOfWork.run(s);
			userTransaction.commit();
		} catch (Exception e) {
			try {
				if (userTransaction.getStatus() != Status.STATUS_NO_TRANSACTION) {
					try {
						userTransaction.rollback();
					} catch (Exception e2) {
						throw e2;
					}
				}
			} catch (SystemException e1) {
				//
			}
			throw e;
		}
	}
	
	boolean isConstraintViolationException(Throwable e) {
		do {
			if (e instanceof ConstraintViolationException) {
				return true;
			}
		} while ((e = e.getCause()) != null);
		return false;
	}
}
