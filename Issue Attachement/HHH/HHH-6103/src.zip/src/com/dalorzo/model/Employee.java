package com.dalorzo.model;

import java.io.Serializable;
import java.lang.String;
import java.util.Map;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Employee
 *
 */
@Entity
public class Employee implements Serializable {

	private static final long serialVersionUID = 1L;
	   
	@Id
	private int id;
	private String name;

	@ElementCollection(fetch=FetchType.LAZY)
	@CollectionTable(name="emp_phone")
	@MapKeyColumn(name="phone_type")
	@Column(name="phone_num")
	private Map<String, String> phoneNumbers;

	public Employee() {
		super();
	}   
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}   
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public Map<String, String> getPhoneNumbers() {
		return phoneNumbers;
	}
	
	public void setPhoneNumbers(Map<String, String> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", phoneNumbers="
				+ phoneNumbers + "]";
	}
}
