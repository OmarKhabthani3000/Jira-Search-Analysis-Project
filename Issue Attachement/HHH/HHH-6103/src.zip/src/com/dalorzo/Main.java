package com.dalorzo;

import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.RollbackException;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.MapJoin;
import javax.persistence.criteria.Root;

import com.dalorzo.model.Employee;

public class Main {
	
	private static final String JPA_PROVIDER = "org.hibernate.ejb.HibernatePersistence";
    private static final String JDBC_URL = "jdbc:apache:commons:dbcp:pmm";
    private static final String SQL_DIALECT = "org.hibernate.dialect.MySQL5Dialect";
    private static final String SHOW_SQL = "true";
    private static final String FORMAT_SQL = "true";
    private static final String SHOW_SQL_COMMENTS = "false";
    private static final String PERSISTENCE_UNIT = "Hibernate";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
            Map<String, Object> properties = new HashMap<String, Object>();
            properties.put("hibernate.dialect", SQL_DIALECT);
            properties.put("hibernate.show_sql", SHOW_SQL);
            properties.put("hibernate.format_sql", FORMAT_SQL);
            properties.put("hibernate.use_sql_comments", SHOW_SQL_COMMENTS);
            //properties.put("hibernate.hbm2ddl.auto", "create");  //{validate|update|create|create-drop}
            
            EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT, properties);
            EntityManager entityManager = entityManagerFactory.createEntityManager();
            
            //saveEmployee(entityManager);
            
            //String query = "SELECT e FROM Employee e JOIN e.phoneNumbers p WHERE KEY(p) IN ('HOME')";
            //System.out.println(entityManager.createQuery(query, Employee.class).getResultList());
            
            CriteriaBuilder builder = entityManager.getCriteriaBuilder();
            CriteriaQuery<Employee> criteria = builder.createQuery(Employee.class);
            Root<Employee> employeeRoot = criteria.from(Employee.class);
            criteria.select(employeeRoot);
            MapJoin<Employee, String, String> phoneRoot = employeeRoot.joinMap("phoneNumbers");
            
            criteria.where(builder.equal(phoneRoot.key(), "HOME"));
            
            System.out.println(entityManager.createQuery(criteria).getResultList());
            
            entityManager.close();
            entityManagerFactory.close();
        }
        catch (Exception e) {
        	e.printStackTrace();
            throw new RuntimeException(e);
        }
	}
	
	public static void saveEmployee(EntityManager entityManager){
		Map<String,String> phones = new HashMap<String, String>();
        phones.put("HOME", "22688883");
        phones.put("MOBILE", "88750372");
        phones.put("OFFICE", "25086418");
        
        Employee emp1 = new Employee();
        emp1.setId(1);
        emp1.setName("Edwin");
        emp1.setPhoneNumbers(phones);
        
        EntityTransaction t = entityManager.getTransaction();
        try{
        	t.begin();
        	entityManager.persist(emp1);
        	t.commit();
        }catch(RollbackException e){
        	throw e;
        }catch(Exception e){
        	t.rollback();
        	throw new RuntimeException(e);
        }
	}

}
