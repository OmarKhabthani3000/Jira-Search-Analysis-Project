package com.vladmihalcea.hibernate.masterclass.laboratory.flushing;

import com.vladmihalcea.hibernate.masterclass.laboratory.util.AbstractTest;
import org.hibernate.Session;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertSame;

/**
 * FlushTypeTest - Test to prove flushing capabilities
 *
 * @author Vlad Mihalcea
 */
public class FlushTypeTest extends AbstractTest {

    @Override
    protected Class<?>[] entities() {
        return new Class<?>[] {
            Product.class,
            User.class,
        };
    }

    @Test
    public void testAutoFlushNonClashingHQL() {
        doInTransaction(new TransactionCallable<Void>() {
            @Override
            public Void execute(Session session) {
                Product product = new Product("LCD");
                session.persist(product);
                LOGGER.info("Check if Product is flushed when selecting Users using HQL");
                assertEquals(0, ((Number) session.createQuery("select count(id) from User").uniqueResult()).intValue());
                assertEquals(1, ((Number) session.createQuery("select count(id) from Product").uniqueResult()).intValue());
                return null;
            }
        });
    }

    @Test
    public void testAutoFlushNonClashingSQL() {
        doInTransaction(new TransactionCallable<Void>() {
            @Override
            public Void execute(Session session) {
                Product product = new Product("LCD");
                session.persist(product);
                LOGGER.info("Check if Product is flushed when selecting Users using SQL");
                assertEquals(0, ((Number) session.createSQLQuery("select count(id) from user").uniqueResult()).intValue());
                assertEquals(product.getId(), session.createSQLQuery("select id from product").uniqueResult());
                return null;
            }
        });
    }
}
