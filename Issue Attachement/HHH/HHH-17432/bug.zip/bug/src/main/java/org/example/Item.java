package org.example;

import jakarta.persistence.*;

@Entity
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TEST_SEQ")
    @SequenceGenerator(name = "TEST_SEQ", sequenceName = "TEST_SEQ")
    private Long id;

    @Embedded
    private Attr value;

    public Item() {
    }

    public Item(Attr value) {
        this.value = value;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Attr getValue() {
        return value;
    }

    public void setValue(Attr value) {
        this.value = value;
    }
}
