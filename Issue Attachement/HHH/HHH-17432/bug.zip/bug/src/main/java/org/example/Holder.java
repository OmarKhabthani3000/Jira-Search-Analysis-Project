package org.example;

import jakarta.persistence.*;

import java.util.Collection;

@Entity
public class Holder {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TEST_SEQ")
    @SequenceGenerator(name = "TEST_SEQ", sequenceName = "TEST_SEQ")
    private Long id;

    @Column
    @JoinColumn(name = "holderId")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    private Collection<Item> items;

    public Holder() {
    }

    public Holder(Collection<Item> items) {
        this.items = items;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Collection<Item> getItems() {
        return items;
    }

    public void setItems(Collection<Item> items) {
        this.items = items;
    }
}
