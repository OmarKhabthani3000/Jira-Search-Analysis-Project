package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

import java.util.Arrays;
import java.util.Collection;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("example");
        EntityManager em = emf.createEntityManager();

        Holder holder = new Holder(Arrays.asList(new Item(new Attr(30)), new Item(new Attr(40))));
        em.persist(holder);
        em.flush();

        // Could not locate TableGroup - org.example.Holder(h).items(tmp).{element}.value(3667744688800)
        Query q = em.createQuery("select distinct h.id " +
                "from Holder h " +
                "join h.items tmp " +
                "where tmp.value.age = 40"
        );
        Collection<Number> list = q.getResultList();
        System.out.println(list.size());
        emf.close();
    }
}
