package com.example.hhh11371;

import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataBuilder;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Main
{

    public static void main(final String[] arguments)
    {
        final StandardServiceRegistryBuilder registryBuilder = new StandardServiceRegistryBuilder();
        registryBuilder.configure();
        final StandardServiceRegistry registry = registryBuilder.build();
        final MetadataSources metadataSources = new MetadataSources(registry);
        final MetadataBuilder metadataBuilder = metadataSources.getMetadataBuilder();
        final Metadata metadata = metadataBuilder.build();
    }

}
