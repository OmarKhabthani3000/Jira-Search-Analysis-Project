package com.example.hhh11371.model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table
public class Child implements Serializable
{

    private static final long serialVersionUID = 1L;
    private Parent parent;

    @Id
    @OneToOne
    @PrimaryKeyJoinColumn
    public Parent getParent()
    {
        return this.parent;
    }

    public void setParent(Parent parent)
    {
        this.parent = parent;
    }

}
