/**
 * LazySetInitTest.java
 * User: jonaka
 * Date: 2006-10-26
 * Time: 17:13:34
 *
 * Copyright (c) 2006 Roche Poland Ltd.
 */
package test.lazysetinit;

import org.hibernate.criterion.Order;
import test.BaseTestCase;

import java.util.*;

/**
 * SQLQueryTest
 *
 * @author jonaka
 * @version $Id$
 */
public class LazySetInitTest extends BaseTestCase {

	public void testInit() throws Exception {
		List result = new ArrayList(new LinkedHashSet(session.createCriteria(Record.class)
				//.add(Restrictions.ne("status", new Integer(Record.FINALIZED_STATUS)))
				.addOrder(Order.asc("id")).list()));
		System.out.println("" + result);
	}

	protected Iterator getClasses() {
		return Arrays.asList(new Class[] { Record.class } ).iterator();
	}
}
