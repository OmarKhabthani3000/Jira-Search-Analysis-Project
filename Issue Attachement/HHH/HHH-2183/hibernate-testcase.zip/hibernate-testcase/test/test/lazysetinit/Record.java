/**
 * Record.java
 * User: jonaka
 * Date: 2006-10-26
 * Time: 17:10:31
 *
 * Copyright (c) 2006 Roche Poland Ltd.
 */
package test.lazysetinit;

import java.util.Set;

/**
 * Record
 *
 * @author jonaka
 * @version $Id$
 */
public class Record {
	private long id;
	private long parentId;
	private int status;
	private Set titles;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Set getTitles() {
		return titles;
	}

	public void setTitles(Set titles) {
		this.titles = titles;
	}

	public long getParentId() {
		return parentId;
	}

	public void setParentId(long parentId) {
		this.parentId = parentId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		Record record = (Record) o;

		if (id != record.id) return false;

		return true;
	}

	public int hashCode() {
		return (int) (id ^ (id >>> 32));
	}

	public String toString() {
		return "Record{" +
				"id=" + id +
				", titles=" + titles +
				'}';
	}
}
