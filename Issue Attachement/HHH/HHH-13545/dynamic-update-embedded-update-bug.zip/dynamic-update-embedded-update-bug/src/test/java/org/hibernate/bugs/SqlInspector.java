package org.hibernate.bugs;

import org.hibernate.resource.jdbc.spi.StatementInspector;

public class SqlInspector implements StatementInspector {

    private static final long serialVersionUID = 1L;

    public static String LAST_STATEMENT;

    @Override
    public String inspect(String sql) {
        LAST_STATEMENT = sql;
        return sql;
    }
}
