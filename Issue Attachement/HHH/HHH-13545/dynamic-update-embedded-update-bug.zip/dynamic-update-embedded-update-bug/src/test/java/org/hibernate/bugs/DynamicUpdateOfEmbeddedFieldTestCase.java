package org.hibernate.bugs;

import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DynamicUpdateOfEmbeddedFieldTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    public void shouldOnlyUpdateChangedColumn() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        MyEntity myEntity = new MyEntity();

        entityManager.persist(myEntity);

        myEntity.getMyEmbeddable().change();
        entityManager.flush();

        assertEquals("update MyEntity set changed=? where id=?", SqlInspector.LAST_STATEMENT);

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
