package org.hibernate.bugs;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicUpdate
public class MyEntity {

    @Id
    @GeneratedValue
    private Long id;

    @Embedded
    private MyEmbeddable myEmbeddable = new MyEmbeddable();

    public MyEmbeddable getMyEmbeddable() {
        return myEmbeddable;
    }
}
