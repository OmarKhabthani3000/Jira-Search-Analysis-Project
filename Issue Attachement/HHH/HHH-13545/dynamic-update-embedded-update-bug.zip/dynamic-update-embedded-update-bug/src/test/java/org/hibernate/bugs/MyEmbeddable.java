package org.hibernate.bugs;

import javax.persistence.Embeddable;

@Embeddable
public class MyEmbeddable {

    private Integer changed;
    private Integer unchanged;

    MyEmbeddable() {
        this.changed = 0;
        this.unchanged = 0;
    }

    public void change() {
        this.changed = 1;
    }
}
