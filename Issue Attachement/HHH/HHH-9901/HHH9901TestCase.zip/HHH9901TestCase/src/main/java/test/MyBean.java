package test;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean(name = "myBean")
@RequestScoped
public class MyBean {
	
	@EJB
	private UserLocal userLocal;
	
	private String name;

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String doDisplay(long id, String tag) {
		return null;
	}

	public String doSubmit() {
		System.out.println("name " + name);

		User user = new User();;
		user.setName(name);

		userLocal.createUser(user);

		return null;
	}

}
