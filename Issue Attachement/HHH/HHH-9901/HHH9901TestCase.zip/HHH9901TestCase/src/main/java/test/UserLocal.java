/**
 * Copyright (c) 2015 JKLProjects Inc. All Rights Reserved.
 */
package test;

import javax.ejb.Local;


@Local
public interface UserLocal  {

	public void createUser(User user);


}