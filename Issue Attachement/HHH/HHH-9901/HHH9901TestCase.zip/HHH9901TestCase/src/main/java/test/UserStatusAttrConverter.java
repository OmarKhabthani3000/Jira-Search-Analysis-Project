package test;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class UserStatusAttrConverter implements
		AttributeConverter<UserStatus, Integer> {

	@Override
	public Integer convertToDatabaseColumn(UserStatus attribute) {
		return attribute.getId();
	}

	@Override
	public UserStatus convertToEntityAttribute(Integer dbData) {
		return UserStatus.toEnum(dbData);
	}

}
