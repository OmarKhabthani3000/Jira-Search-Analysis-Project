package test;

public enum UserStatus implements IStatus {
	NEW(1, "New"), PENDING_EMAIL_VERIFY(2, "Pending - E-Mail Verification"), ACTIVE(
			3, "Active"), INACTIVE(4, "In-Active"), PURGED(5, "Purged"), ACTIVE_TEMP_PWD(
			6, "Active - Temp Password"), LOCKED_MAX_INVALID_SIGNIN_ATTEMPTS(7,
			"Locked - Maximum invalid sign-in attempts ");

	private static String simpleName = UserStatus.class.getSimpleName();

	private int id;
	private String statusName;

	private UserStatus(int id, String statusName) {
		this.id = id;
		this.statusName = statusName;
	}

	@Override
	public int getId() {
		return id;
	}

	@Override
	public String getStatusName() {
		return statusName;
	}

	/**
	 * Lookup and return matching object or null if match is not found.
	 * 
	 * @param id
	 * @return matching status or null if match is not found.
	 */
	public static UserStatus toEnum(int id) {
		for (UserStatus en : UserStatus.values()) {
			if (en.getId() == id) {
				return en;
			}
		}

		return null;
	}

	/**
	 * Return true if status id is equal, false otherwise.
	 * 
	 * @param id
	 * @return true if status id is equal, false otherwise.
	 */
	@Override
	public boolean equals(int id) {
		return id == getId();
	}

	/**
	 * Return true if status equals one of the given statuses, false otherwise.
	 * 
	 * @param statuses
	 * @return true if status equals one of the given statuses, false otherwise.
	 */
	@Override
	public boolean in(IStatus... statuses) {
		for (IStatus ss : statuses) {
			if (ss.equals(this.getId())) {
				return true;
			}
		}
		return false;
	}

}
