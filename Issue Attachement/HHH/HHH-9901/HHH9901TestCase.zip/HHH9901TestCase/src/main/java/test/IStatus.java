package test;
public interface IStatus {

	public int getId();

	public String getStatusName();

	/**
	 * Return true if status id is equal, false otherwise.
	 * 
	 * @param id
	 * @return true if status id is equal, false otherwise.
	 */
	public boolean equals(int id);

	public boolean in(IStatus... statuses);

}