package test;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;

public class MyDAO {

	@PersistenceUnit(unitName = "mystoryJTAPU")
	private EntityManager em;

	public MyDAO() {
	}

	protected EntityManager getEM() {
		return em;
	}

	/**
	 * Check if the instance is a managed entity instance belonging to the
	 * current persistence context.
	 * 
	 * @param entity
	 * @return
	 * 
	 * @see EntityManager#contains(Object)
	 */
	public <T> boolean isManaged(T entity) {
		return entity != null ? em.contains(entity) : false;
	}

	/**
	 * Delete entity with given id.
	 * 
	 * @param id
	 * @param entityClass
	 */
	protected final <T> void delete(Object id, Class<T> entityClass) {
		T entityToBeRemoved = em.getReference(entityClass, id);

		em.remove(entityToBeRemoved);
	}

	/**
	 * Save entity.
	 * 
	 * @param entity
	 */
	public final <T> void persist(T entity) {
		em.persist(entity);
	}

	/**
	 * @param entityId
	 * @param entityClass
	 * 
	 * @return
	 */
	public final <T> T find(long entityId, Class<T> entityClass) {
		return em.find(entityClass, entityId);
	}

	/**
	 * Find entities using named query and query parameters.
	 * 
	 * @param namedQuery
	 *            query name
	 * @param queryParams
	 * @param entityClass
	 * 
	 * @return
	 */
	public final <T> List<T> find(String namedQuery,
			Map<String, Object> queryParams, Class<T> entityClass) {
		TypedQuery<T> tQ = em.createNamedQuery(namedQuery, entityClass);

		for (Map.Entry<String, Object> param : queryParams.entrySet()) {
			tQ.setParameter(param.getKey(), param.getValue());
		}
		return tQ.getResultList();
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public <T> List<T> findAll(Class<T> entityClass) {
		CriteriaQuery cq = getEM().getCriteriaBuilder().createQuery();
		cq.select(cq.from(entityClass));
		return getEM().createQuery(cq).getResultList();
	}

}
