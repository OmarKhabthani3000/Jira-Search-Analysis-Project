package test;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "T_USER")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@NamedQueries({ @NamedQuery(name = "findAll", query = "SELECT u FROM User u")})
public class User implements Serializable {

	private static final long serialVersionUID = 2059680239586919757L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "name")
	private String name;

//	@Column(name = "status")
//	@Convert(converter = UserStatusAttrConverter.class)
//	private UserStatus status;

	public User() {
		super();

//		status = UserStatus.NEW;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

//	public UserStatus getStatus() {
//		return status;
//	}
//
//	public void setStatus(UserStatus status) {
//		this.status = status;
//	}
//
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
