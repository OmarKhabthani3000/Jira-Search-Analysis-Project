package test;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class MyServiceImpl implements UserLocal {

	@PersistenceContext(unitName = "mystoryJTAPU")
	private EntityManager em;

	
	@EJB
	private UserLocal userService;

	
	
	/**
	 * Save entity.
	 * 
	 * @param entity
	 */
	public final <T> void persist(T entity) {
		em.persist(entity);
	}

	public MyServiceImpl() {
	}

	@Override
	public void createUser(User user) {
		em.persist(user);
	}

}