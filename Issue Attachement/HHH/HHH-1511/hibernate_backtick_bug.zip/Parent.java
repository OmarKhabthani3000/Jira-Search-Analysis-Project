import java.util.*;

public class Parent
{
  protected long id = -1;
  protected Set superChildren = new HashSet();
  protected Set subChildren   = new HashSet();

  public long getId() {
    return this.id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public Set getSubChildren() {
    return this.subChildren;
  }

  public void setSubChildren(Set subChildren) {
    this.subChildren = subChildren;
  }

  public Set getSuperChildren() {
    return this.superChildren;
  }

  public void setSuperChildren(Set superChildren) {
    this.superChildren = superChildren;
  }
}
