public class SuperChild
{
  protected long id = -1;
  protected Parent parent = new Parent();

  public long getId() {
    return this.id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public Parent getParent() {
    return this.parent;
  }

  public void setParent(Parent parent) {
    this.parent = parent;
  }
}
