CREATE TABLE parent (id INT NOT NULL PRIMARY KEY);
CREATE TABLE child_super (id INT NOT NULL PRIMARY KEY, parent_id INT NOT NULL);
CREATE TABLE child_sub (super_id INT NOT NULL);
INSERT INTO parent VALUES (1);
INSERT INTO child_super VALUES (1,1), (2,1);
INSERT INTO child_sub VALUES (2);
