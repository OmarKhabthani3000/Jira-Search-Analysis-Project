import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import java.util.Collection;

public class Test extends junit.framework.TestCase
{
  protected Session session = null;

  public void setUp() throws Exception {
    super.setUp();
    SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
    session = sessionFactory.openSession();
  }

  public void testParentChild() throws Exception {
    Parent parent = (Parent) session.get(Parent.class, new Long(1));
    Collection superChildren = parent.getSuperChildren();
    Collection subChildren   = parent.getSubChildren();
    assertEquals(superChildren.size(), 2);
    assertEquals(subChildren.size(), 1);
  }

  public void tearDown() throws Exception {
    super.tearDown();
    session.close();
  }
}
