public class SubChild extends SuperChild
{
}
