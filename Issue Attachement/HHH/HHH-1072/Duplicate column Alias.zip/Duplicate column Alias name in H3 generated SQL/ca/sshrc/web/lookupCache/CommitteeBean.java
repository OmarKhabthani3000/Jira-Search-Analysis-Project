package ca.sshrc.web.lookupCache;

public class CommitteeBean {
    private Integer committeeId;
    private Integer programId;
    private String nameEnglish;
    private String nameFrench;
    private String shortNameEnglish;
    private String shortNameFrench;

    /**
     * Constructor
     *
     * @param committeeId Integer
     * @param programId Integer
     * @param nameEnglish String
     * @param nameFrench String
     * @param shortNameEnglish String
     * @param shortNameFrench String
     */
    public CommitteeBean(Integer committeeId, Integer programId, String nameEnglish, String nameFrench, String shortNameEnglish, String shortNameFrench){
        this.committeeId= committeeId;
        this.programId = programId;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.shortNameEnglish = shortNameEnglish;
        this.shortNameFrench = shortNameFrench;
    }


        public Integer getCommitteeId() {
        return committeeId;
    }

    public Integer getProgramId() {
        return programId;
    }

    public String getNameEnglish() {
        return nameEnglish;
    }

    public String getNameFrench() {
        return nameFrench;
    }

    public String getShortNameEnglish() {
        return shortNameEnglish;
    }

    public String getShortNameFrench() {
        return shortNameFrench;
    }

    public void setCommitteeId(Integer committeeId) {
        this.committeeId = committeeId;
    }

    public void setProgramId(Integer programId) {
        this.programId = programId;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    public void setShortNameEnglish(String shortNameEnglish) {
        this.shortNameEnglish = shortNameEnglish;
    }

    public void setShortNameFrench(String shortNameFrench) {
        this.shortNameFrench = shortNameFrench;
    }
}
