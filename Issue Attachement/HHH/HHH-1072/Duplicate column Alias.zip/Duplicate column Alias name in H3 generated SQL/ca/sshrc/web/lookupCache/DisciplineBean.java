package ca.sshrc.web.lookupCache;

import java.util.*;

import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class DisciplineBean extends BeanBase {

    private Integer disciplineCode;
    private String nameFrench;
    private String nameEnglish;
    private String activeInd;
    private Date createDate;
    private String createUserId;
    private Date changeDate;
    private String changeUserId;
    private Integer mainDiscipline;

    /** full constructor */
    public DisciplineBean(Integer disciplineCode, String nameFrench, String nameEnglish, String activeInd,
                          Date createDate, String createUserId, Date changeDate, String changeUserId,
                          Integer mainDiscipline) {
        this.disciplineCode = disciplineCode;
        this.nameFrench = nameFrench;
        this.nameEnglish = nameEnglish;
        this.activeInd = activeInd;
        this.createDate = createDate;
        this.createUserId = createUserId;
        this.changeDate = changeDate;
        this.changeUserId = changeUserId;
        this.mainDiscipline = mainDiscipline;
    }

    /** default constructor */
    public DisciplineBean() {
    }

    public String getActiveInd() {
        return activeInd;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public String getChangeUserId() {
        return changeUserId;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public String getCreateUserId() {
        return createUserId;
    }

    public Integer getDisciplineCode() {
        return disciplineCode;
    }

    public String getNameEnglish() {
        return nameEnglish;
    }

    public String getNameFrench() {
        return nameFrench;
    }

    public Integer getMainDiscipline() {
        return mainDiscipline;
    }

    public void setActiveInd(String activeInd) {
        this.activeInd = activeInd;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public void setDisciplineCode(Integer disciplineCode) {
        this.disciplineCode = disciplineCode;
    }

    public void setMainDiscipline(Integer mainDiscipline) {
        this.mainDiscipline = mainDiscipline;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    /**
     * getDisciplineName
     *
     * @return String
     */
    public String getDisciplineName() {
        if (this.getNavigationBean().getFormLanguage().equals(Constants.FRENCH_CANADIAN_LOCALE)) {
            return this.nameFrench;
        } else {
            return this.nameEnglish;
        }
    }

    /**
     * setDisciplineName
     *
     * @param aDiscName String
     */
    public void setDisciplineName(String aDiscName) {
        if (this.getNavigationBean().getFormLanguage().equals(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.nameFrench = aDiscName;
        } else {
            this.nameEnglish = aDiscName;

        }
    }

}
