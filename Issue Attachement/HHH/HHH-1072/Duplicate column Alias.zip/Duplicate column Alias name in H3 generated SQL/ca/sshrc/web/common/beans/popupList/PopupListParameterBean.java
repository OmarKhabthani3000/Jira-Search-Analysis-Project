package ca.sshrc.web.common.beans.popupList;

public class PopupListParameterBean {

    /** listName
     * Originating list name (first list name used when caling this popup session).
     */
    private String listName;

    /** nextListName
     * Indicates what the nextListName will be, if known.
     */
    private String nextListName;

    /** lastList
     * Indicates if the current list is the last list and therefore indicates to update
     * the calling form's fields and close the popup.
     */
    private String lastList = "Y";

    /** levels
     *
     * Represent the number of pairs of variables to be updated with the user selection.
     * i.e. a value of 2 means that the popup will update 2 pairs, the field names contained in
     * codeFieldNames1, descFieldNames1, codeFieldNames2, descFieldNames2.
     */
    private int levels = 1;  // Default to one pair of var. to update

    /** currentLevel
     *
     * Represent the set of pairs of variables to be updated with the user selection.
     * i.e. a value of 1 means that the popup will update the field names contained in
     * codeFieldNames1, descFieldNames1.
     */
    private int currentLevel = 0; // Defaults to 0 pairs - no fields to update

    /** copies
     *
     * Represent the number of time the variables are used on the page/form to be updated by this popup.
     * For example, if a List button for Country list appears 6 time on a page, this value will contain 6.
     * The variables will be passed to this object as code1[0], desc1[0] for the first List button and
     * code1[1], desc1[1] for the second List button, etc...
     */
    private int copies = 1; // Defaults to 1, one pair (no array)

    /** currentPopupRank
     *
     * Represent the current popup's position among the popups to be displayed in the popup session.
     * i.e.: For the organization and department selection, there could be as much as 4 popups.
     * When popup 1 is displayed (country list), currentPopupRank value is 1. The country selection will
     * influence which popup will be next. If Canada or US is selected, one more popup will show to
     * ask for the province/state. The prov/state popup currentPopupRank variable would have a value of 2.
     * If the selected country isn't Canada or the US, popup 2 will be a list of organization for that country
     * and currentPopupRank will be set to 2.
     */
    private int currentPopupRank = 0;

    /** listTitle
     *
     * Represent the current popup's title. Will be used as the <title></title> value.
     */
    private String listTitle="Undefined title.";

    private String codeFieldNames1;
    private String codeFieldNames2;
    private String codeFieldNames3;
    private String codeFieldNames4;

    private String descFieldNames1;
    private String descFieldNames2;
    private String descFieldNames3;
    private String descFieldNames4;

    private String selectedValueCode1;
    private String selectedValueCode2;
    private String selectedValueCode3;
    private String selectedValueDesc1;
    private String selectedValueDesc2;
    private String selectedValueDesc3;


    public PopupListParameterBean() {
    }

    public String getListName() {
        return listName;
    }

    public String getNextListName() {
        return nextListName;
    }

    public int getLevels() {
        return levels;
    }

    public int getCopies() {
        return copies;
    }

    public void setListName(String listName) {
        this.listName = listName;
    }

    public void setNextListName(String nextListName) {
        this.nextListName = nextListName;
    }

    public void setLevels(int levels) {
        this.levels = levels;
    }

    public void setCopies(int copies) {
        this.copies = copies;
    }

    public void setCodeFieldNames1(String codeFieldNames1) {
        this.codeFieldNames1 = codeFieldNames1;
    }

    public void setCodeFieldNames2(String codeFieldNames2) {
        this.codeFieldNames2 = codeFieldNames2;
    }

    public void setCodeFieldNames3(String codeFieldNames3) {
        this.codeFieldNames3 = codeFieldNames3;
    }

    public void setCodeFieldNames4(String codeFieldNames4) {
        this.codeFieldNames4 = codeFieldNames4;
    }

    public void setDescFieldNames1(String descFieldNames1) {
        this.descFieldNames1 = descFieldNames1;
    }

    public void setDescFieldNames2(String descFieldNames2) {
        this.descFieldNames2 = descFieldNames2;
    }

    public void setDescFieldNames3(String descFieldNames3) {
        this.descFieldNames3 = descFieldNames3;
    }

    public void setDescFieldNames4(String descFieldNames4) {
        this.descFieldNames4 = descFieldNames4;
    }

    public void setSelectedValueCode1(String selectedValueCode1) {

        this.selectedValueCode1 = selectedValueCode1;
    }

    public void setSelectedValueCode2(String selectedValueCode2) {

        this.selectedValueCode2 = selectedValueCode2;
    }

    public void setSelectedValueCode3(String selectedValueCode3) {

        this.selectedValueCode3 = selectedValueCode3;
    }

    public void setCurrentLevel(int currentLevel) {
        this.currentLevel = currentLevel;
    }

    public void setLastList(String lastList) {
        this.lastList = lastList;
    }

    public void setCurrentPopupRank(int currentPopupRank) {
        this.currentPopupRank = currentPopupRank;
    }

    public void setSelectedValueDesc1(String selectedValueDesc1) {
        this.selectedValueDesc1 = selectedValueDesc1;
    }

    public void setSelectedValueDesc2(String selectedValueDesc2) {
        this.selectedValueDesc2 = selectedValueDesc2;
    }

    public void setSelectedValueDesc3(String selectedValueDesc3) {
        this.selectedValueDesc3 = selectedValueDesc3;
    }

    public void setListTitle(String listTitle) {
        this.listTitle = listTitle;
    }

    public String getCodeFieldNames1() {
        return codeFieldNames1;
    }

    public String getCodeFieldNames2() {
        return codeFieldNames2;
    }

    public String getCodeFieldNames3() {
        return codeFieldNames3;
    }

    public String getCodeFieldNames4() {
        return codeFieldNames4;
    }

    public String getDescFieldNames1() {

        return descFieldNames1;
    }

    public String getDescFieldNames2() {
        return descFieldNames2;
    }

    public String getDescFieldNames3() {
        return descFieldNames3;
    }

    public String getDescFieldNames4() {
        return descFieldNames4;
    }

    public String getSelectedValueCode1() {

        return selectedValueCode1;
    }

    public String getSelectedValueCode2() {

        return selectedValueCode2;
    }

    public String getSelectedValueCode3() {

        return selectedValueCode3;
    }

    public int getCurrentLevel() {
        return currentLevel;
    }

    public String getLastList() {
        return lastList;
    }

    public int getCurrentPopupRank() {
        return currentPopupRank;
    }

    public String getSelectedValueDesc1() {
        return selectedValueDesc1;
    }

    public String getSelectedValueDesc2() {
        return selectedValueDesc2;
    }

    public String getSelectedValueDesc3() {
        return selectedValueDesc3;
    }

    public String getListTitle() {
        return listTitle;
    }

    public int getFieldCount() {
        int fieldCount = 0;

        // Set of field 1
        if ((null != this.codeFieldNames1 && this.codeFieldNames1.length() > 0) &&
            (null != this.descFieldNames1 && this.descFieldNames1.length() > 0)) {
            ++fieldCount;
            // Set of field 2
            if ((null != this.codeFieldNames2 && this.codeFieldNames2.length() > 0) &&
                (null != this.descFieldNames2 && this.descFieldNames2.length() > 0)) {
                ++fieldCount;
                // Set of field 3
                if ((null != this.codeFieldNames3 && this.codeFieldNames3.length() > 0) &&
                    (null != this.descFieldNames3 && this.descFieldNames3.length() > 0)) {
                    ++fieldCount;
                    // Set of field 1
                    if ((null != this.codeFieldNames4 && this.codeFieldNames4.length() > 0) &&
                        (null != this.descFieldNames4 && this.descFieldNames4.length() > 0)) {
                        ++fieldCount;
                    }
                }
            }
        }

        return fieldCount;
    }
}
