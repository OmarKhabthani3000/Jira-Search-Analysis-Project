package ca.sshrc.web.common.services.baseObject;


import ca.sshrc.web.common.services.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public abstract class ActionBase extends RootBase {

    // Base constructor
    public ActionBase() {
    }
}
