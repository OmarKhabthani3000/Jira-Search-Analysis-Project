package ca.sshrc.web.forms.beans.cv;


import java.util.*;

import ca.sshrc.web.common.services.baseObject.*;
import org.apache.commons.beanutils.BeanComparator;
import ca.sshrc.web.common.util.Constants;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class AddressDataBean extends BeanBase {
    /**
     * AddressDataBean
     *
     * @param aiCid Integer
     * @param aiAddressType Integer
     */
    public AddressDataBean(Integer aiCid, Integer aiAddressType) {
        this.cid = aiCid;
        this.addressType = aiAddressType;
    }

    private Integer addressId;
    private Integer cid;
    private Integer formatType;
    private Integer addressType;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String municipality;
    private String provinceStateCode;
    private Integer countryCode;
    private String countryNameEnglish;
    private String countryNameFrench;
    private String postalZipCode;
    private String tmpPhoneCountryCode;
    private String tmpPhoneAreaCode;
    private String tmpPhoneNumber;
    private String tmpPhoneExtension;
    private String tmpFaxCountryCode;
    private String tmpFaxPhoneAreaCode;
    private String tmpFaxPhoneNumber;
    private String tmpFaxPhoneExtension;
    private String tmpEmailAddress;
    private Date tmpDateFrom;
    private Date tmpDateTo;
    private Date changeDate;
    private String tmpFromYear;
    private String tmpFromMonth;
    private String tmpFromDay;
    private String tmpToYear;
    private String tmpToMonth;
    private String tmpToDay;

    /**
     * AddressDataBean
     *
     * Empty constructor
     */
    public AddressDataBean() {
    }

    public void setAddressId(Integer addressId) {
        this.addressId = addressId;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public void setFormatType(Integer formatType) {
        this.formatType = formatType;
    }

    public void setAddressType(Integer addressType) {
        if (addressType.intValue() == 0) {
            this.addressType = null;
        }else{
            this.addressType = addressType;
        }
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    public void setAddress4(String address4) {
        this.address4 = address4;
    }

    public void setMunicipality(String municipality) {
        this.municipality = municipality;
    }

    public void setProvinceStateCode(String provinceStateCode) {
        this.provinceStateCode = provinceStateCode;
    }

    public void setCountryCode(Integer countryCode) {
        this.countryCode = countryCode;

    }

    public void setCountryName(String countryName) {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {
            this.countryNameFrench = countryName;
        } else {
            this.countryNameEnglish = countryName;
        }

    }

    public void setPostalZipCode(String postalZipCode) {
        this.postalZipCode = postalZipCode;
    }

    public void setTmpPhoneCountryCode(String tmpPhoneCountryCode) {
        this.tmpPhoneCountryCode = tmpPhoneCountryCode;
    }

    public void setTmpPhoneAreaCode(String tmpPhoneAreaCode) {
        this.tmpPhoneAreaCode = tmpPhoneAreaCode;
    }

    public void setTmpPhoneNumber(String tmpPhoneNumber) {
        this.tmpPhoneNumber = tmpPhoneNumber;
    }

    public void setTmpPhoneExtension(String tmpPhoneExtension) {
        this.tmpPhoneExtension = tmpPhoneExtension;
    }

    public void setTmpFaxCountryCode(String tmpFaxCountryCode) {
        this.tmpFaxCountryCode = tmpFaxCountryCode;
    }

    public void setTmpFaxPhoneAreaCode(String tmpFaxPhoneAreaCode) {
        this.tmpFaxPhoneAreaCode = tmpFaxPhoneAreaCode;
    }

    public void setTmpFaxPhoneNumber(String tmpFaxPhoneNumber) {
        this.tmpFaxPhoneNumber = tmpFaxPhoneNumber;
    }

    public void setTmpFaxPhoneExtension(String tmpFaxPhoneExtension) {
        this.tmpFaxPhoneExtension = tmpFaxPhoneExtension;
    }

    public void setTmpEmailAddress(String tmpEmailAddress) {
        this.tmpEmailAddress = tmpEmailAddress;
    }

    public void setTmpDateFrom(Date dateFrom) {
        this.tmpDateFrom = dateFrom;
    }

    public void setTmpDateTo(Date dateTo) {
        this.tmpDateTo = dateTo;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public void setTmpFromYear(String tmpFromYear) {
        this.tmpFromYear = tmpFromYear;

    }

    public void setTmpFromMonth(String tmpFromMonth) {
        this.tmpFromMonth = tmpFromMonth;

    }

    public void setTmpFromDay(String tmpFromDay) {
        this.tmpFromDay = tmpFromDay;

    }

    public void setTmpToYear(String tmpToYear) {
        this.tmpToYear = tmpToYear;

    }

    public void setTmpToMonth(String tmpToMonth) {
        this.tmpToMonth = tmpToMonth;

    }

    public void setTmpToDay(String tmpToDay) {
        this.tmpToDay = tmpToDay;

    }

    public Integer getAddressId() {
        return addressId;
    }

    public Integer getCid() {
        return cid;
    }

    public Integer getFormatType() {
        return formatType;
    }

    public Integer getAddressType() {
        return addressType;
    }

    public String getAddress1() {
        return address1;
    }

    public String getAddress2() {
        return address2;
    }

    public String getAddress3() {
        return address3;
    }

    public String getAddress4() {
        return address4;
    }

    public String getMunicipality() {
        return municipality;
    }

    public String getProvinceStateCode() {
        return provinceStateCode;
    }

    public Integer getCountryCode() {
        return countryCode;
    }

    public String getCountryName() {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {
            return this.countryNameFrench;
        } else {
            return this.countryNameEnglish;
        }

    }

    public String getPostalZipCode() {
        return postalZipCode;
    }

    public String getTmpPhoneCountryCode() {
        return tmpPhoneCountryCode;
    }

    public String getTmpPhoneAreaCode() {
        return tmpPhoneAreaCode;
    }

    public String getTmpPhoneNumber() {
        return tmpPhoneNumber;
    }

    public String getTmpPhoneExtension() {
        return tmpPhoneExtension;
    }

    public String getTmpFaxCountryCode() {
        return tmpFaxCountryCode;
    }

    public String getTmpFaxPhoneAreaCode() {
        return tmpFaxPhoneAreaCode;
    }

    public String getTmpFaxPhoneNumber() {
        return tmpFaxPhoneNumber;
    }

    public String getTmpFaxPhoneExtension() {
        return tmpFaxPhoneExtension;
    }

    public String getTmpEmailAddress() {
        return tmpEmailAddress;
    }

    public Date getTmpDateFrom() {
        return tmpDateFrom;
    }

    public Date getTmpDateTo() {
        return tmpDateTo;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public String getTmpToYear() {
        if (this.getTmpDateFrom() != null) {
            Calendar myDate = Calendar.getInstance();
            myDate.setTime(this.tmpDateTo);

            return String.valueOf(myDate.get(myDate.YEAR));
        } else {
            return "";

        }
    }

    public String getTmpToMonth() {
        if (this.getTmpDateFrom() != null) {
            Calendar myDate = Calendar.getInstance();
            myDate.setTime(this.tmpDateTo);

            return String.valueOf(myDate.get(myDate.MONTH));
        } else {
            return "";

        }
    }

    public String getTmpToDay() {
        if (this.getTmpDateFrom() != null) {
            Calendar myDate = Calendar.getInstance();
            myDate.setTime(this.tmpDateTo);

            return String.valueOf(myDate.get(myDate.DAY_OF_MONTH));
        } else {
            return "";

        }
    }

    /**
     * getFormYear
     *
     * @return String
     */
    public String getTmpFromYear() {
        if (this.getTmpDateFrom() != null) {
            Calendar myDate = Calendar.getInstance();
            myDate.setTime(this.tmpDateFrom);
            return String.valueOf(myDate.get(myDate.YEAR));
        } else {
            return "";
        }

    }

    /**
     * getFromMonth
     *
     * @return String
     */
    public String getTmpFromMonth() {
        if (this.getTmpDateFrom() != null) {
            Calendar myDate = Calendar.getInstance();
            myDate.setTime(this.tmpDateFrom);
            return String.valueOf(myDate.get(myDate.MONTH));
        } else {
            return "";
        }
    }

    /**
     * getFromDay
     *
     * @return String
     */
    public String getTmpFromDay() {
        if (this.getTmpDateFrom() != null) {
            Calendar myDate = Calendar.getInstance();
            myDate.setTime(this.tmpDateFrom);

            return String.valueOf(myDate.get(myDate.DAY_OF_MONTH));
        } else {

            return "";
        }
    }


    /**
     * AddressDataBean
     *
     * Full constructor
     */
    public AddressDataBean(Integer addressId,
                           Integer cid,
                           Integer formatType,
                           Integer addressType,
                           String address1,
                           String address2,
                           String address3,
                           String address4,
                           String municipality,
                           String provinceStateCode,
                           Integer countryCode,
                           String countryNameEnglish,
                           String countryNameFrench,
                           String postalZipCode,
                           String tmpPhoneCountryCode,
                           String tmpPhoneAreaCode,
                           String tmpPhoneNumber,
                           String tmpPhoneExtension,
                           String tmpFaxCountryCode,
                           String tmpFaxPhoneAreaCode,
                           String tmpFaxPhoneNumber,
                           String tmpFaxPhoneExtension,
                           String tmpEmailAddress,
                           Date tmpDateFrom,
                           Date tmpDateTo,
                           Date changeDate) {
        this.addressId = addressId;
        this.cid = cid;
        this.formatType = formatType;
        this.addressType = addressType;
        this.address1 = address1;
        this.address2 = address2;
        this.address3 = address3;
        this.address4 = address4;
        this.municipality = municipality;
        this.provinceStateCode = provinceStateCode;
        this.countryCode = countryCode;
        this.countryNameEnglish = countryNameEnglish;
        this.countryNameFrench = countryNameFrench;
        this.postalZipCode = postalZipCode;
        this.tmpPhoneCountryCode = tmpPhoneCountryCode;
        this.tmpPhoneAreaCode = tmpPhoneAreaCode;
        this.tmpPhoneNumber = tmpPhoneNumber;
        this.tmpPhoneExtension = tmpPhoneExtension;
        this.tmpFaxCountryCode = tmpFaxCountryCode;
        this.tmpFaxPhoneAreaCode = tmpFaxPhoneAreaCode;
        this.tmpFaxPhoneNumber = tmpFaxPhoneNumber;
        this.tmpFaxPhoneExtension = tmpFaxPhoneExtension;
        this.tmpEmailAddress = tmpEmailAddress;
        this.tmpDateFrom = tmpDateFrom;
        this.tmpDateTo = tmpDateTo;
        this.changeDate = changeDate;
    }

    /**
     * populateDateFields
     */
    public void populateDateFields() {
        if (this.tmpFromDay == null || this.tmpFromMonth == null || this.tmpFromYear == null ||
            this.tmpFromDay.trim().equals("") || this.tmpFromMonth.trim().equals("") ||
            this.tmpFromYear.trim().equals("")) {
            System.out.println("populateDateFields - we have an invalid date for the from date");
        } else {
            System.out.println("populateDateFields - we have a valid date for the from date");
            System.out.println("tmpFromYear ='" + this.tmpFromYear + "'");
            System.out.println("tmpFromMonth ='" + this.tmpFromMonth + "'");
            System.out.println("tmpFromDay ='" + this.tmpFromDay + "'");
            Calendar cal = Calendar.getInstance();
            cal.set(Integer.parseInt(this.tmpFromYear), Integer.parseInt(this.tmpFromMonth),
                    Integer.parseInt(this.tmpFromDay));
            this.tmpDateFrom = cal.getTime();

        }
        if (this.tmpToDay == null || this.tmpToMonth == null || this.tmpToYear == null ||
            this.tmpToDay.trim().equals("") || this.tmpToMonth.trim().equals("") ||
            this.tmpToYear.trim().equals("")) {
            System.out.println("populateDateFields - we have an invalid date for the To date");
        } else {
            System.out.println("populateDateFields - we have a valid date for the To date");
            System.out.println("tmpToYear ='" + this.tmpToYear + "'");
            System.out.println("tmpToMonth ='" + this.tmpToMonth + "'");
            System.out.println("tmpToDay ='" + this.tmpToDay + "'");
            Calendar cal = Calendar.getInstance();
            cal.set(Integer.parseInt(this.tmpToYear), Integer.parseInt(this.tmpToMonth),
                    Integer.parseInt(this.tmpToDay));
            this.tmpDateTo = cal.getTime();
        }

    }

    /**
     * hasData
     *
     * @return boolean
     */
    public boolean hasData() {
        if ((this.address1 == null || this.address1.trim().equals("")) &&
            (this.address2 == null || this.address2.trim().equals("")) &&
            (this.address3 == null || this.address3.trim().equals("")) &&
            (this.address4 == null || this.address4.trim().equals("")) &&
            (this.countryCode == null || this.countryCode.intValue() == 0) &&
            (this.municipality == null || this.municipality.trim().equals("")) &&
            (this.postalZipCode == null || this.postalZipCode.trim().equals("")) &&
            (this.provinceStateCode == null || this.provinceStateCode.trim().equals("")) &&
            (this.tmpEmailAddress == null || this.tmpEmailAddress.trim().equals("")) &&
            (this.tmpPhoneCountryCode == null || this.tmpPhoneCountryCode.trim().equals("")) &&
            (this.tmpPhoneAreaCode == null || this.tmpPhoneAreaCode.trim().equals("")) &&
            (this.tmpPhoneNumber == null || this.tmpPhoneNumber.trim().equals("")) &&
            (this.tmpPhoneExtension == null || this.tmpPhoneExtension.trim().equals("")) &&
            (this.tmpFaxCountryCode == null || this.tmpFaxCountryCode.trim().equals("")) &&
            (this.tmpFaxPhoneAreaCode == null || this.tmpFaxPhoneNumber.trim().equals("")) &&
            (this.tmpFaxPhoneNumber == null || this.tmpFaxPhoneNumber.trim().equals("")) &&
            (this.tmpFaxPhoneExtension == null || this.tmpFaxPhoneExtension.trim().equals("")) &&
            (this.tmpEmailAddress == null || this.tmpEmailAddress.trim().equals("")) &&
            (this.tmpFromYear == null || this.tmpFromYear.trim().equals("") ||
             this.tmpFromMonth == null || this.tmpFromMonth.trim().equals("") ||
             this.tmpFromDay == null || this.tmpFromDay.trim().equals("")) &&
            (this.tmpToYear == null || this.tmpToYear.trim().equals("") ||
             this.tmpToMonth == null || this.tmpToMonth.trim().equals("") ||
             this.tmpToDay == null || this.tmpToDay.trim().equals(""))) {
            return false;
        } else {
            return true;
        }
    }

}
