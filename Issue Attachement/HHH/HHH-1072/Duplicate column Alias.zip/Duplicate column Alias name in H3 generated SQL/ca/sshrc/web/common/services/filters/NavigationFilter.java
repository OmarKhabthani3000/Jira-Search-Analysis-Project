package ca.sshrc.web.common.services.filters;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import ca.sshrc.web.common.services.*;

public class NavigationFilter implements Filter {
    private Boolean isShowSessionAttributes = new Boolean(false);
    private Boolean isShowRequestAttributes = new Boolean(false);
    private FilterConfig filterConfig = null;
//    private boolean isAnyAttributeSynchronized = false;


    public void destroy() {
        this.filterConfig = null;
    }


    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException,
            ServletException {

        if (filterConfig == null) {
            return;
        }

        // Get config
        if (filterConfig.getInitParameter("ShowSessionAttributes") != null) {
            isShowSessionAttributes = Boolean.valueOf(filterConfig.getInitParameter("ShowSessionAttributes"));
        }

        if (filterConfig.getInitParameter("ShowRequestAttributes") != null) {
            isShowRequestAttributes = Boolean.valueOf(filterConfig.getInitParameter("ShowRequestAttributes"));
        }

        // Get HttpSession
        HttpSession session = ((HttpServletRequest) request).getSession(false);

        // Show session attributes
        if (session != null) {
            if (isShowSessionAttributes.booleanValue()) {
                for (Enumeration e = session.getAttributeNames(); e.hasMoreElements(); ) {
                    System.out.println("NavigationFilter - Session attributes " + e.nextElement());
                }
            }

            // Show request attributes
            if (isShowRequestAttributes.booleanValue()) {
                for (Enumeration e = ((HttpServletRequest) request).getParameterNames(); e.hasMoreElements(); ) {
                    String str = e.nextElement().toString();
                    System.out.println("NavigationFilter - Request attribute " + str + ": " +
                                       ((HttpServletRequest) request).getParameter(str));
                }
            }

            // Get navigationBean
            /*NavigationBean navigationBean = (NavigationBean) session.getAttribute("navigationBean");
            if (navigationBean != null) {

                // Get requested Subsystem Id  from request parameter
                String currentSubsystemId = (String) request.getAttribute("mainForm:currentSubsystemId");
                if (currentSubsystemId != null) {
                    if (!navigationBean.getCurrentSubsystemId().equals(new Integer(currentSubsystemId))) {
                        navigationBean.setCurrentSubsystemId(new Integer(currentSubsystemId));
                        isAnyAttributeSynchronized = true;
                    }
                }

                // Get requested Module Id from request parameter
                String currentModuleId = (String) request.getAttribute("mainForm:currentModuleId");
                if (currentModuleId != null) {
                    if (!navigationBean.getCurrentModuleId().equals(new Integer(currentModuleId))) {
                        navigationBean.setCurrentModuleId(new Integer(currentModuleId));
                        isAnyAttributeSynchronized = true;
                    }
                }

                // Get requested Subsystem Id  from request parameter
                String requestedSubsystemId = (String) request.getAttribute("mainForm:requestedSubsystemId");
                if (requestedSubsystemId != null) {
                    if (!navigationBean.getRequestedSubsystemId().equals(new Integer(requestedSubsystemId))) {
                        navigationBean.setRequestedSubsystemId(new Integer(requestedSubsystemId));
                        isAnyAttributeSynchronized = true;
                    }
                }

                // Get requested Module Id from request parameter
                String requestedModuleId = (String) request.getAttribute("mainForm:requestedModuleId");
                if (requestedModuleId != null) {
                    if (!navigationBean.getRequestedModuleId().equals(new Integer(requestedModuleId))) {
                        navigationBean.setRequestedModuleId(new Integer(requestedModuleId));
                        isAnyAttributeSynchronized = true;
                    }
                }
            } else {
                System.out.println("NavigationFilter - no navigationBean in session.");
            }*/
        }

        /*if (isAnyAttributeSynchronized) {
            System.out.println("NavigationFilter - SOME attributes were synchronized.");
        } else {
            System.out.println("NavigationFilter - NO attributes were synchronized.");
        }*/

        // keep going with filter chain
        chain.doFilter(request, response);
    }


    public void init(FilterConfig filterConfig) throws ServletException {
        this.filterConfig = filterConfig;
    }
}
