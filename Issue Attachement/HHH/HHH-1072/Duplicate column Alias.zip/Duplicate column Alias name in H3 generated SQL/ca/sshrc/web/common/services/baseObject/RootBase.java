package ca.sshrc.web.common.services.baseObject;



import javax.faces.context.*;
import javax.servlet.http.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.logon.*;


/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public abstract class RootBase {

    public RootBase() {
    }

    public NavigationBean getNavigationBean() {
        NavigationBean navigationBean = (NavigationBean) getHttpSession().getAttribute("navigationBean");
        return navigationBean;
    }

    /**
     * getLogonBean
     *
     * @return LogonBean
     */
    public LogonBean getLogonBean() {
        return (LogonBean) getHttpSession().getAttribute("logonBean");
    }

    public FacesContext getFacesContext() {
        return FacesContext.getCurrentInstance();
    }

    /*public ExternalContext getFacesContext() {
        return this.context;
         }*/

    public javax.faces.application.Application getApplication() {
        return getFacesContext().getApplication();
    }

    public HttpSession getHttpSession() {
        return ((HttpServletRequest) getHttpRequest()).getSession(false);
    }

    public HttpServletRequest getHttpRequest() {
        return (HttpServletRequest) getExternalContext().getRequest();
    }

    public ExternalContext getExternalContext() {
        return getFacesContext().getExternalContext();
    }
}
