package ca.sshrc.web.common.services;

import ca.sshrc.web.common.services.baseObject.*;
import hibernate.interceptors.*;
import org.apache.commons.logging.*;
import org.hibernate.*;
import org.hibernate.cfg.*;

public class HibernateUtil extends RootBase {
//    private static Logger logger = Logger.getLogger(HibernateUtil.class);
    private static final SessionFactory sessionFactory;
    private static final ThreadLocal threadSession = new ThreadLocal();
    private static Log log = LogFactory.getLog(HibernateUtil.class);

    static {
        try {
            // Create the SessionFactory
            sessionFactory = new Configuration().configure().
                             buildSessionFactory();


        } catch (Throwable ex) {
            log.error("Hibernate Initial SessionFactory creation failed.",
                         ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    private static final ThreadLocal threadTransaction = new ThreadLocal();

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static Session getSession() {
        Session s = (Session) threadSession.get();
        // Open a new Session, if this Thread has none yet opened one
        try {
            if (s == null) {

                // Interceptor is required to force hibernate to generate an update statement
                // when updating the Form (form_status column) table in the case where the status is not
                // changing (was N and set to N). This is required so the Form update's trigger is executed.
//                Interceptor interceptor = new FormStatusInterceptor();
//                s = sessionFactory.openSession(interceptor);
                s = sessionFactory.openSession();
                threadSession.set(s);
            }
        } catch (HibernateException ex) {
            ex.printStackTrace();
        }
        return s;
    }

    public static Session getSession(Interceptor interceptor) {
        Session s = (Session) threadSession.get();
        // Open a new Session, if this Thread has none yet opened one
        try {
            if (s == null) {

                // Interceptor is required to force hibernate to generate an update statement
                // when updating the Form (form_status column) table in the case where the status is not
                // changing (was N and set to N). This is required so the Form update's trigger is executed.
                s = sessionFactory.openSession(interceptor);
                threadSession.set(s);
            }
        } catch (HibernateException ex) {
            ex.printStackTrace();
        }
        return s;
    }

    public static void closeSession() {
        try {
            Session s = (Session) threadSession.get();
            threadSession.set(null);
            if (s != null && s.isOpen()) {
                s.close();
            }
        } catch (HibernateException ex) {
            ex.printStackTrace();
        }
    }

    public static void beginTransaction() {
        Transaction tx = (Transaction) threadTransaction.get();
        try {
            if (tx == null) {
                tx = getSession().beginTransaction();
                threadTransaction.set(tx);
            }
        } catch (HibernateException ex) {
            ex.printStackTrace();
        }
    }

    public static void commitTransaction() {
        Transaction tx = (Transaction) threadTransaction.get();
        try {
            if (tx != null && !tx.wasCommitted()
                && !tx.wasRolledBack()) {
                tx.commit();
            }
            threadTransaction.set(null);
        } catch (HibernateException ex) {
            rollbackTransaction();
            ex.printStackTrace();
        }
    }

    public static void rollbackTransaction() {
        Transaction tx = (Transaction) threadTransaction.get();
        try {
            threadTransaction.set(null);
            if (tx != null && !tx.wasCommitted()
                && !tx.wasRolledBack()) {
                tx.rollback();
            }
        } catch (HibernateException ex) {
            ex.printStackTrace();
        } finally {
            closeSession();
        }
    }
}
