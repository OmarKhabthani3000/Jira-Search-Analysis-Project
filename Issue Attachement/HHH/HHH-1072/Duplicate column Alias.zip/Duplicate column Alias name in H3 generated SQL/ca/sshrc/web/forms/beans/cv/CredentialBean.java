package ca.sshrc.web.forms.beans.cv;


import javax.faces.event.*;
import java.lang.reflect.*;
import java.util.*;

import javax.faces.component.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.services.baseObject.*;
import hibernate.*;
import org.hibernate.*;
import org.apache.commons.beanutils.*;
import org.apache.log4j.*;
import javax.servlet.http.HttpServletRequest;
import hibernate.interceptors.FormStatusInterceptor;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */

public class CredentialBean extends BeanBase {

    private ArrayList credentialList = new ArrayList();
    private UIData credTable;
    private int rowsPerPage = 6;

    private Logger logger = Logger.getLogger(CredentialBean.class.getName());

    public CredentialBean() {
        logger.info("CredentialBean - minimal constructor");
        Long FormId = new Long(this.getNavigationBean().getForm_id());
        System.out.print("CredentialBean.constructor - just before the retrieve called with fomrId = " +
                         FormId);
        if (this.getFacesContext().getRenderResponse()) {
            this.retrieve(FormId);
        } else {
            while (this.credentialList.size() < rowsPerPage) {
                Integer Cid = this.getLogonBean().getWeb_id();

                this.credentialList.add(new CredentialDataBean(Cid));

            }

        }
    }

    /**
     * deleteBean
     *
     * @param actionEvent ActionEvent
     */
    public void deleteBean(ActionEvent actionEvent) {
        /* retrieve the deleteRowId parameter
           retrieve that row from the database
           delete the row
           return to the page
         */
        System.out.println("Entered deleteBean method");
        // Get attribute names from request
        HttpServletRequest request = (HttpServletRequest)this.getExternalContext().
                                     getRequest();
        Integer rowId = new Integer(request.getParameter("deleteRowId"));

        Interceptor interceptor = new FormStatusInterceptor();

        Session session = HibernateUtil.getSession(interceptor);

        try {
            HibernateUtil.beginTransaction();
            List dQList = session.createQuery("from PersonDistinction " +
                                              "where distId = :id ")
                          .setParameter("id", rowId).list();
            PersonDistinction credentialRow = (PersonDistinction) dQList.get(0);
            session.delete(credentialRow);
            session.flush();
            HibernateUtil.commitTransaction();

        } catch (HibernateException ex) {
            HibernateUtil.rollbackTransaction();
            ex.printStackTrace();

        } finally {
            // retrieve the bean data
            this.retrieve(new Long(this.getNavigationBean().getForm_id()));

            // Close the Hibernate connection
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            HibernateUtil.closeSession();

        }

    }


    /**
     * save
     *
     * @return String
     */

    public String save(Session session) throws HibernateException, InvocationTargetException,
            IllegalAccessException, NoSuchMethodException {

        List queryList;
        CredentialDataBean tempBean = null;
        int dbRowCount = 0;

        boolean boBeanHasData;
        String saveOutcome = "failure"; // Defaults to failure

        logger.info("In CredentialBean.save()");
        logger.info("We have " + this.credentialList.size() + " beans in workexperiences");

        if (this.credentialList.size() > 0) {

            tempBean = (CredentialDataBean)this.credentialList.get(0);
            logger.info("the cid = " + tempBean.getCid());
        }

        HibernateUtil.beginTransaction();
        queryList = session.createQuery("from PersonDistinction " +
                                        "where cid = :cid ")
                    .setParameter("cid", tempBean.getCid())
                    .list();
        dbRowCount = queryList.size();
        logger.info("In CredentialBean.save() - Retrieved hibernate.PersonDistinction object for cid: " +
                    tempBean.getCid());

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Loaded hibernate.PersonDistinction objects : " + queryList.size());
        }

        if (this.credentialList.size() > 0) {
            for (int i = 0; i < this.credentialList.size(); i++) {
                logger.info("this is bean #" + i);
                tempBean = (CredentialDataBean)this.credentialList.get(i);
                boBeanHasData = tempBean.hasData();
                if (tempBean.getDistId() == null || tempBean.getCid().intValue() == 0) {
                    logger.info("this is a new record");

                    if (boBeanHasData) {
                        logger.info("there is data in #d" + i);
                        hibernate.PersonDistinction newDist = new PersonDistinction();
                        PropertyUtils.copyProperties(newDist, tempBean);
                        queryList.add(newDist);
                        session.saveOrUpdate((PersonDistinction) queryList.get(queryList.size() - 1));
                        //                       session.flush();

                        saveOutcome = "success";
                    }

                } else {

                    logger.info("this is an existing record #" + i);
//                    Iterator it = queryList.iterator();
                    for (int j = 0; j < dbRowCount; j++) {

                        if (((PersonDistinction) queryList.get(j)).getDistId().equals(tempBean.getDistId())) {
                            // this is the correct record, update and save
                            if (boBeanHasData) {
                                logger.info("there is has data in #" + i);
                                PropertyUtils.copyProperties((PersonDistinction) queryList.get(j), tempBean);
                                session.saveOrUpdate((PersonDistinction) queryList.get(j));
                                saveOutcome = "success";
                                break;
                            } else {
                                session.delete((PersonDistinction) queryList.get(j));
                                saveOutcome = "success";
                                break;
                            }
                        }
                    }
                }

            }
        }
        return saveOutcome;
    }


    /**
     * retrieve
     *
     * @param aCid Integer
     */

    public void retrieve(Long alFormId) {
        List queryList;
        logger.info("CredentialBean.retrieve passed parameter is Cid : " + alFormId);

        // If the passed form_id is 0, get the form_id from the NavigationBean
        if (alFormId.intValue() == 0) {
            alFormId = new Long(this.getNavigationBean().getForm_id());
            if (alFormId.longValue() == 0) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.error("Cannot load CredentialBean - no Cid : " + alFormId);
                    return;
                }
            } else {
                logger.info("CredentialBean.retrieve using navigationBean Cid : " + alFormId);
            }

        } else {
            logger.info("CredentialBean.retrieve using passed parm Cid : " + alFormId);
        }

        //Let's retrieve the data from the DB
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In CredentialBean.retrieve()");

            queryList = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.cv.CredentialDataBean( " +
                    "dist.distId, " +
                    "dist.cid, " +
                    "dist.distinctionType, " +
                    "dist.receivedDate, " +
                    "dist.distinctionName, " +
                    "dist.distinctionAmount, " +
                    "dist.countryCode, " +
                    "dist.changeDate, " +
                    "country.nameEnglish, " +
                    "country.nameFrench) " +
                    "from PersonDistinction dist, " +
                    "Form form, " +
                    "Country country " +
                    "where (dist.countryCode *= country.countryCode) and " +
                    "(dist.cid = form.cid) and " +
                    "(form.formId = :formId) " +
                    "order by dist.receivedDate DESC, " +
                    "dist.distId ASC")
                        .setParameter("formId", alFormId)
                        .list();

            logger.info("number of rows retrieved : " + queryList.size());

            if (queryList.size() > 0) {

                this.credentialList.addAll(queryList);

            }

            while (this.credentialList.size() < rowsPerPage) {
                this.credentialList.add(new CredentialDataBean(this.getLogonBean().getWeb_id()));

            }
        } catch (Exception ex) {
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
            ex.printStackTrace();

        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public void setCredentialList(ArrayList credentialList) {
        this.credentialList = credentialList;
    }

    public void setCredTable(UIData credTable) {
        this.credTable = credTable;
    }

    public ArrayList getCredentialList() {
        return credentialList;
    }

    public UIData getCredTable() {
        return credTable;
    }
}
