package ca.sshrc.web.lookupCache;

import java.text.*;
import java.util.*;

import hibernate.*;
import org.hibernate.*;
import org.apache.log4j.*;
import ca.sshrc.web.common.services.*;
import java.io.Serializable;
import ca.sshrc.web.common.util.Constants;

public class OrganizationCountryCache implements Serializable {
    private Logger logger = Logger.getLogger(OrganizationCountryCache.class.getName());
    private List queryList;

    public OrganizationCountryCache() {
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In OrganizationCountryCache");

            queryList = session.createQuery(
                    "select DISTINCT new hibernate.Country(Country.countryCode, " +
                    "Country.nameEnglish, " +
                    "Country.nameFrench, " +
                    "Country.activeInd) " +
                    "from Country as Country left outer join " +
                    "Country.organization as Organization " +
                    "where ((Country.countryCode not in(9000,9999)) and (Country.activeInd = 'Y'))").list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Organization country loaded: " + queryList.size());
            }

        } catch (HibernateException ex) {
            ex.printStackTrace();
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
        } finally {
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public static final Comparator nameEnglishOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            Country objComp1 = (Country) o1;
            Country objComp2 = (Country) o2;
            return myCollator.compare(objComp1.getNameEnglish(),
                                      objComp2.getNameEnglish());
        }
    };

    public static final Comparator nameFrenchOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Country objComp1 = (Country) o1;
            Country objComp2 = (Country) o2;
            return objComp1.getNameFrench().compareTo(objComp2.getNameFrench());
        }
    };
    public List getList(String language) {
        // Keep the original array. Use a copy for sorting
        List listTemp;
        listTemp = queryList;

        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            Collections.sort(listTemp, nameFrenchOrder);
        } else {
            Collections.sort(listTemp, nameEnglishOrder);
        }
        return listTemp;
    }
}
