package ca.sshrc.web.common.services.baseObject;

import java.lang.reflect.*;
import java.math.*;
import java.text.*;
import java.util.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.util.*;

import org.apache.commons.beanutils.*;
import org.apache.log4j.*;
import org.hibernate.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class BeanBase extends RootBase {

    private String[] propertyNamesForEmptiness;

    // Base constructor
    public BeanBase() {
    }

    public String save(Session session) throws HibernateException, Exception {
        return Constants.SUCCESS_OUTCOME;
    }

    public String validate(ValidationMessage messageContainer) throws HibernateException, Exception {
        return Constants.SUCCESS_OUTCOME;
    }

    public String print() {
        return Constants.SUCCESS_OUTCOME;
    }


    public void retrieve(Session session) {
        this.retrieve(session);
    }

    public boolean isStaleData(Date DBDate, Date WebDate) {
        Logger logger = Logger.getLogger(BeanBase.class.getName());
        boolean staleData = true;
        SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");

        if (DBDate != null && WebDate != null) {
            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("DBDate: " + sdformat.format(DBDate) + "/" + "WebDate: " +
                            sdformat.format(WebDate));
            }

            if (sdformat.format(DBDate).equalsIgnoreCase(sdformat.format(WebDate))) {
                staleData = false;
            }
        } else {
            if (DBDate == null && WebDate == null) {
                if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                    staleData = false;
                    logger.info("DBDate and WebDate are null - Not considered stale data - returning False");
                }
            }
            if (DBDate == null) {
                if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                    logger.info("DBDate is null");
                }
            }
            if (WebDate == null) {
                if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                    logger.info("WebDate is null");
                }
            }
        }
        return staleData;
    }

    // Used to trim value in constructor before setting the beans property.
    public String trim(String string) {
        return string == null ? null : string.trim();
    }

    public boolean isEmpty(String[] propertyList) throws
            IllegalArgumentException {

        boolean isEmpty = true;
        Object tempForNullObject;
        Integer valueInteger;
        Long valueLong;
        Short valueShort;
        BigDecimal valueBigDecimal;
        String valueString;
        Date valueDate;
        int valueInt;

        int nPropertyList = propertyList.length;
        java.lang.Class propertyType;

        if (null == this) {
            throw new IllegalArgumentException();
        }

        if (nPropertyList == 0) {
            throw new IllegalArgumentException();
        }

        for (int i = 0; i < nPropertyList; i++) {
            try {
                // Try getting the properety's datatype
                tempForNullObject = PropertyUtils.getPropertyType(this, propertyList[i]);

                // If property's datatype was found...
                if (null != tempForNullObject) {
                    propertyType = PropertyUtils.getPropertyType(this, propertyList[i]);

                    // String
                    if (propertyType.toString().equalsIgnoreCase("class java.lang.string")) {
                        valueString = (String) PropertyUtils.getProperty(this, propertyList[i]);
                        if (valueString != null && !valueString.trim().equals("")) {
                            isEmpty = false;
                            break;
                        } else {
                            continue;
                        }
                    }

                    // Long
                    if (propertyType.toString().equalsIgnoreCase("class java.lang.Long")) {
                        valueLong = (Long) PropertyUtils.getProperty(this, propertyList[i]);
                        if (valueLong != null && valueLong.longValue() > 0 ) {
                            isEmpty = false;
                            break;
                        } else {
                            continue;
                        }
                    }

                    // Integer
                    if (propertyType.toString().equalsIgnoreCase("class java.lang.Integer")) {
                        valueInteger = (Integer) PropertyUtils.getProperty(this, propertyList[i]);
                        if (valueInteger != null && valueInteger.intValue() > 0 ) {
                            isEmpty = false;
                            break;
                        } else {
                            continue;
                        }
                    }

                    // int
                    if (propertyType.toString().equalsIgnoreCase("class java.lang.int")) {
                        valueInt = ((Integer) PropertyUtils.getProperty(this, propertyList[i])).intValue();
                        if (valueInt > 0 ) {
                            isEmpty = false;
                            break;
                        } else {
                            continue;
                        }
                    }

                    // Short
                    if (propertyType.toString().equalsIgnoreCase("class java.lang.short")) {
                        valueShort = (Short) PropertyUtils.getProperty(this, propertyList[i]);
                        if (valueShort != null && valueShort.shortValue() > 0 ) {
                            isEmpty = false;
                            break;
                        } else {
                            continue;
                        }
                    }

                    // BigDecimal
                    if (propertyType.toString().equalsIgnoreCase("class java.math.bigdecimal")) {
                        valueBigDecimal = (BigDecimal) PropertyUtils.getProperty(this, propertyList[i]);
                        if (valueBigDecimal != null && valueBigDecimal.longValue() > 0 ) {
                            isEmpty = false;
                            break;
                        } else {
                            continue;
                        }
                    }

                    // Date
                    if (propertyType.toString().equalsIgnoreCase("class java.util.date")) {
                        valueDate = (Date) PropertyUtils.getProperty(this, propertyList[i]);
                        if (valueDate != null) {
                            isEmpty = false;
                            break;
                        } else {
                            continue;
                        }
                    }


                    throw new IllegalArgumentException("BeanBase.java:isEmpty() - Invalid datatype in property array: " + propertyType.toString());

                } else {
                    throw new IllegalArgumentException("BeanBase.java:isEmpty() - Invalid property in property array: " + propertyList[i]);
                }
            } catch (ClassCastException ex) {
                throw new ClassCastException("BeanBase.java:isEmpty() - For property: " + propertyList[i]);
            } catch (NoSuchMethodException ex) {
                ex.printStackTrace();
            } catch (InvocationTargetException ex) {
                ex.printStackTrace();
            } catch (IllegalAccessException ex) {
                ex.printStackTrace();
            }

        }

        return isEmpty;
    }

    public boolean isEmpty() {
        Logger logger = Logger.getLogger(BeanBase.class.getName());
        if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
            logger.error("BeanBase.isEmpty() - Property array NOT initialized - returning True");
        }

        return true;
    }
}
