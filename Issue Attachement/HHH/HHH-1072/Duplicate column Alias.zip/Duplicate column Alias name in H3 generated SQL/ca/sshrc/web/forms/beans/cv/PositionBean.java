package ca.sshrc.web.forms.beans.cv;

import java.lang.reflect.*;
import java.util.*;

import javax.faces.model.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.*;
import hibernate.*;
import org.apache.commons.beanutils.*;
import org.apache.log4j.*;
import org.hibernate.*;


/**
 * <p>Title: PositionBean</p>
 *
 * <p>Description: Bean used to populate the fields for the Current Position page
 *                 on the CV. The data will  </p>
 *
 * <p>Copyright:  Copyright (c) 2004</p>
 *
 * <p>Company: SSHRC</p>
 *
 * @author: Guy Bellemare
 * @version 1.0
 */
public class PositionBean extends BeanBase {

    private Logger logger = Logger.getLogger(PositionBean.class.getName());
    /** from Forms table */
    private Long formId;

    /** from Person_Position table     */
    private Integer positionId;
    private Integer cid;
    private OrgDeptLocation orgDeptLocId;
    private Cod positionNumber;
    private Integer positionType;
    private Integer employmentType;
    private String primaryOrgInd;
    private short positionStartYear;
    private String otherOrgName;
    private String otherDepartmentName;
    private String otherPositionName;
    private String phoneCountryCode;
    private String phoneAreaCode;
    private String phoneNumber;
    private String phoneExtension;
    private String faxCountryCode;
    private String faxAreaCode;
    private String faxNumber;
    private String faxPhoneExtension;
    private String emailAddress;
    private String scndEmailAddress;
    private String scndPhoneCountryCode;
    private String scndPhoneAreaCode;
    private String scndPhoneNumber;
    private String scndPhoneExtension;
    private String scndFaxCountryCode;
    private String scndFaxPhoneAreaCode;
    private String scndFaxPhoneNumber;
    private String scndFaxPhoneExtension;
    private Date changeDate;
    private Organization orgId;

    /** from Org_Dept_Location table through Org_Dept_Location_ID*/
    private String departmentNameEnglish;
    private String departmentNameFrench;

    /** from Organization table through Org_Id*/
    private String orgNameEnglish;
    private String orgNameFrench;


    /** from Codes table through Position_Type */
    private String positionTypeEnglish;
    private String positionTypeFrench;


    /**
     * PositionBean
     * default constructor
     */
    public PositionBean() {

        logger.info("PositionBean - minimal constructor ");
        long formID = getNavigationBean().getForm_id();
        logger.info("PositionBean - formID value: " + formID);

        try {
            // Get a session
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // Call this object's retrieve method
            this.retrieve(formID, session);

            HibernateUtil.commitTransaction();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("PositionBean - form id value: " + cid);
        }
    }

    /**
     * PositionBean
     * Full constructor
     */
    public PositionBean(Long formId, Integer positionId, Integer cid, OrgDeptLocation orgDeptLocId,
                        Cod positionNumber, Integer positionType, Integer employmentType,
                        String primaryOrgInd, short positionStartYear, String otherOrgName,
                        String otherDepartmentName, String otherPositionName, String phoneCountryCode,
                        String phoneAreaCode, String phoneNumber, String phoneExtension,
                        String faxCountryCode, String faxAreaCode, String faxNumber,
                        String faxPhoneExtension, String emailAddress, String scndEmailAddress,
                        String scndPhoneCountryCode, String scndPhoneAreaCode, String scndPhoneNumber,
                        String scndPhoneExtension, String scndFaxCountryCode, String scndFaxPhoneAreaCode,
                        String scndFaxPhoneNumber,
                        String scndFaxPhoneExtension, Date changeDate, Organization orgId,
                        String departmentNameEnglish,
                        String departmentNameFrench, String orgNameEnglish, String orgNameFrench,
                        String positionTypeEnglish, String positionTypeFrench
            ) {

        /**
                    "position.positionId, " +
                    "position.cid, " +
                    "position.orgDeptLocId," +
                    "position.positionNumber, " +
                    "position.positionType, " +
                    "position.employmentType," +
                    "position.primaryOrgInd, " +
                    "position.positionStartYear, " +
                    "position.otherOrgName, " +
                    "position.otherDepartmentName, " +
                    "position.otherPositionName, " +
                    "position.phoneCountryCode, " +
                    "position.phoneAreaCode, " +
                    "position.phoneNumber, " +
                    "position.phoneExtension, " +
                    "position.faxCountryCode, " +
                    "position.faxAreaCode, " +
                    "position.faxNumber, " +
                    "position.faxPhoneExtension, " +
                    "position.emailAddress, " +
                    "position.scndEmailAddress, " +
                    "position.scndPhoneCountryCode, " +
                    "position.scndPhoneAreaCode, " +
                    "position.scndPhoneNumber, " +
                    "position.scndPhoneExtension, " +
                    "position.scndFaxCountryCode, " +
                    "position.scndFaxPhoneAreaCode, " +
                    "position.scndFaxPhoneNumber, " +
                    "position.scndFaxPhoneExtension, " +
                    "position.changeDate, position.orgId, " +
                    "department.departmentNameEnglish, " +
                    "department.departmentNameFrench, " +
                    "organization.nameEnglish, " +
                    "organization.nameFrench, " +
                    "cod.shortNameEnglish, " +
                    "cod.shortNameFrench) " +

         */
        this.positionId = positionId;
        this.cid = cid;
        this.orgDeptLocId = orgDeptLocId;
        this.positionNumber = positionNumber;
        this.positionType = positionType;
        this.primaryOrgInd = primaryOrgInd;
        this.employmentType = employmentType;
        this.positionStartYear = positionStartYear;
        this.otherOrgName = otherOrgName;
        this.otherDepartmentName = otherDepartmentName;
        this.otherPositionName = otherPositionName;
        this.phoneCountryCode = phoneCountryCode;
        this.phoneAreaCode = phoneAreaCode;
        this.phoneNumber = phoneNumber;
        this.phoneExtension = phoneExtension;
        this.faxCountryCode = faxCountryCode;
        this.faxAreaCode = faxAreaCode;
        this.faxNumber = faxNumber;
        this.faxPhoneExtension = faxPhoneExtension;
        this.emailAddress = emailAddress;
        this.scndEmailAddress = scndEmailAddress;
        this.scndPhoneCountryCode = scndPhoneCountryCode;
        this.scndPhoneAreaCode = scndPhoneAreaCode;
        this.scndPhoneNumber = scndPhoneNumber;
        this.scndPhoneExtension = scndPhoneExtension;
        this.scndFaxCountryCode = scndFaxCountryCode;
        this.scndFaxPhoneAreaCode = scndFaxPhoneAreaCode;
        this.scndFaxPhoneNumber = scndFaxPhoneNumber;
        this.scndFaxPhoneExtension = scndFaxPhoneExtension;
        this.changeDate = changeDate;
        this.orgId = orgId;
        this.departmentNameFrench = departmentNameFrench;
        this.orgNameEnglish = orgNameEnglish;
        this.orgNameFrench = orgNameFrench;
        this.positionTypeEnglish = positionTypeEnglish;

        this.formId = formId;
        this.positionTypeFrench = positionTypeFrench;
        this.departmentNameEnglish = departmentNameEnglish;

    }

    public void setPositionId(Integer positionId) {
        this.positionId = positionId;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public void setOrgDeptLocId(OrgDeptLocation orgDeptLocId) {
        this.orgDeptLocId = orgDeptLocId;
    }

    public void setPositionNumber(Cod positionNumber) {
        this.positionNumber = positionNumber;
    }

    public void setPositionType(Integer positionType) {
        this.positionType = positionType;
    }

    public void setPrimaryOrgInd(String primaryOrgInd) {
        this.primaryOrgInd = primaryOrgInd;
    }


    public void setEmploymentType(Integer employmentType) {
        this.employmentType = employmentType;
    }

    public void setPositionStartYear(short positionStartYear) {
        this.positionStartYear = positionStartYear;
    }

    public void setOtherOrgName(String otherOrgName) {
        this.otherOrgName = otherOrgName;
    }

    public void setOtherDepartmentName(String otherDepartmentName) {
        this.otherDepartmentName = otherDepartmentName;
    }

    public void setOtherPositionName(String otherPositionName) {
        this.otherPositionName = otherPositionName;
    }

    public void setPhoneCountryCode(String phoneCountryCode) {
        this.phoneCountryCode = phoneCountryCode;
    }

    public void setPhoneAreaCode(String phoneAreaCode) {
        this.phoneAreaCode = phoneAreaCode;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setPhoneExtension(String phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public void setFaxCountryCode(String faxCountryCode) {
        this.faxCountryCode = faxCountryCode;
    }

    public void setFaxAreaCode(String faxAreaCode) {
        this.faxAreaCode = faxAreaCode;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public void setFaxPhoneExtension(String faxPhoneExtension) {
        this.faxPhoneExtension = faxPhoneExtension;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public void setScndEmailAddress(String scndEmailAddress) {
        this.scndEmailAddress = scndEmailAddress;
    }

    public void setScndPhoneCountryCode(String scndPhoneCountryCode) {
        this.scndPhoneCountryCode = scndPhoneCountryCode;
    }

    public void setScndPhoneAreaCode(String scndPhoneAreaCode) {
        this.scndPhoneAreaCode = scndPhoneAreaCode;
    }

    public void setScndPhoneNumber(String scndPhoneNumber) {
        this.scndPhoneNumber = scndPhoneNumber;
    }

    public void setScndPhoneExtension(String scndPhoneExtension) {
        this.scndPhoneExtension = scndPhoneExtension;
    }

    public void setScndFaxCountryCode(String scndFaxCountryCode) {
        this.scndFaxCountryCode = scndFaxCountryCode;
    }

    public void setScndFaxPhoneAreaCode(String scndFaxPhoneAreaCode) {
        this.scndFaxPhoneAreaCode = scndFaxPhoneAreaCode;
    }

    public void setScndFaxPhoneNumber(String scndFaxPhoneNumber) {
        this.scndFaxPhoneNumber = scndFaxPhoneNumber;
    }

    public void setScndFaxPhoneExtension(String scndFaxPhoneExtension) {
        this.scndFaxPhoneExtension = scndFaxPhoneExtension;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public void setOrgId(Organization orgId) {
        this.orgId = orgId;
    }

    public void setDepartmentNameFrench(String departmentNameFrench) {
        this.departmentNameFrench = departmentNameFrench;
    }

    public void setOrgNameEnglish(String orgNameEnglish) {
        this.orgNameEnglish = orgNameEnglish;
    }

    public void setOrgNameFrench(String orgNameFrench) {
        this.orgNameFrench = orgNameFrench;
    }

    public void setPositionTypeEnglish(String positionTypeEnglish) {
        this.positionTypeEnglish = positionTypeEnglish;
    }


    public void setFormId(Long formID) {
        this.formId = formID;
    }

    /*    public void setAddress(PositionAddressBean address) {
            this.address = address;
        }
     */

    public void setPositionTypeFrench(String positionTypeFrench) {
        this.positionTypeFrench = positionTypeFrench;
    }

    public void setDeptName(String DeptName) {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {
            this.departmentNameFrench = DeptName;
        } else {
            this.departmentNameEnglish = DeptName;
        }

    }


    public Integer getPositionId() {
        return positionId;
    }

    public Integer getCid() {
        return cid;
    }

    public OrgDeptLocation getOrgDeptLocId() {
        if (null == orgDeptLocId) {
            return new OrgDeptLocation();
        } else {
            return orgDeptLocId;
        }
    }

    public Cod getPositionNumber() {
        if (null == positionNumber) {
            return new Cod();
        } else {
            return positionNumber;
        }
    }

    public Integer getPositionType() {
        return positionType;
    }

    public String getPrimaryOrgInd() {
        return primaryOrgInd;
    }


    public Integer getEmploymentType() {
        return employmentType;
    }

    public short getPositionStartYear() {
        return positionStartYear;
    }

    public String getOtherOrgName() {
        return otherOrgName;
    }

    public String getOtherDepartmentName() {
        return otherDepartmentName;
    }

    public String getOtherPositionName() {
        return otherPositionName;
    }

    public String getPhoneCountryCode() {
        return phoneCountryCode;
    }

    public String getPhoneAreaCode() {
        return phoneAreaCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getPhoneExtension() {
        return phoneExtension;
    }

    public String getFaxCountryCode() {
        return faxCountryCode;
    }

    public String getFaxAreaCode() {
        return faxAreaCode;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public String getFaxPhoneExtension() {
        return faxPhoneExtension;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getScndEmailAddress() {
        return scndEmailAddress;
    }

    public String getScndPhoneCountryCode() {
        return scndPhoneCountryCode;
    }

    public String getScndPhoneAreaCode() {
        return scndPhoneAreaCode;
    }

    public String getScndPhoneNumber() {
        return scndPhoneNumber;
    }

    public String getScndPhoneExtension() {
        return scndPhoneExtension;
    }

    public String getScndFaxCountryCode() {
        return scndFaxCountryCode;
    }

    public String getScndFaxPhoneAreaCode() {
        return scndFaxPhoneAreaCode;
    }

    public String getScndFaxPhoneNumber() {
        return scndFaxPhoneNumber;
    }

    public String getScndFaxPhoneExtension() {
        return scndFaxPhoneExtension;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public Organization getOrgId() {
        if (null == orgId) {
            return new Organization();
        } else {
            return orgId;
        }
    }

    public String getDepartmentNameFrench() {
        return departmentNameFrench;
    }

    public String getOrgNameEnglish() {
        return orgNameEnglish;
    }

    public String getOrgNameFrench() {
        return orgNameFrench;
    }

    public String getPositionTypeEnglish() {
        return positionTypeEnglish;
    }

    public String getPositionTypeFrench() {
        return positionTypeFrench;
    }


    /*    public PositionAddressBean getAddress() {
            return address;
        }
     */
    public Long getFormId() {
        return formId;
    }

    public String getDeptName() {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            return this.departmentNameFrench;
        } else {
            return this.departmentNameEnglish;
        }

    }

    // Overwrite ancestor method
    public void retrieve(Session session) {
        retrieve(0, session);
    }

    /**
     * retrieve
     *
     * @param formId long
     */
    public void retrieve(long formId, Session session) {

        List queryList;

        if (null == session) {
            if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                logger.error("Cannot load PositionBean - Session is null");
                return;
            }
        }


        logger.info("PositionBean.retrieve passed parameter is FormId : " + formId);
        // If the passed form_id is 0, get the form_id from the NavigationBean
        if (formId == 0) {
            formId = getNavigationBean().getForm_id();
            if (formId == 0) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.error("Cannot load PositionBean - no FormId : " + formId);
                    return;
                }
            } else {
                logger.info("PositionBean.retrieve using navigationBean FormId : " + formId);
            }

        } else {
            logger.info("PositionBean.retrieve using passed parm FormId : " + formId);
        }

        // Retrieve data
        try {
            logger.info("In PositionBean.retrieve()");

            queryList = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.cv.PositionBean(form.formId, " +
                    "position.positionId, " +
                    "position.cid, " +
                    "position.orgDeptLocation," +
                    "position.positionNumber, " +
                    "position.positionType, " +
                    "position.employmentType," +
                    "position.primaryOrgInd, " +
                    "position.positionStartYear, " +
                    "position.otherOrgName, " +
                    "position.otherDepartmentName, " +
                    "position.otherPositionName, " +
                    "position.phoneCountryCode, " +
                    "position.phoneAreaCode, " +
                    "position.phoneNumber, " +
                    "position.phoneExtension, " +
                    "position.faxCountryCode, " +
                    "position.faxAreaCode, " +
                    "position.faxNumber, " +
                    "position.faxPhoneExtension, " +
                    "position.emailAddress, " +
                    "position.scndEmailAddress, " +
                    "position.scndPhoneCountryCode, " +
                    "position.scndPhoneAreaCode, " +
                    "position.scndPhoneNumber, " +
                    "position.scndPhoneExtension, " +
                    "position.scndFaxCountryCode, " +
                    "position.scndFaxPhoneAreaCode, " +
                    "position.scndFaxPhoneNumber, " +
                    "position.scndFaxPhoneExtension, " +
                    "position.changeDate, position.organization, " +
                    "department.departmentNameEnglish, " +
                    "department.departmentNameFrench, " +
                    "organization.nameEnglish, " +
                    "organization.nameFrench, " +
                    "cod.shortNameEnglish, " +
                    "cod.shortNameFrench) " +
                    "from Form form join fetch form.person as person " +
                    "left outer join fetch person.personPosition as position " +
                    "left outer join fetch position.positionNumber as cod " +
                    "left outer join fetch position.orgDeptLocation as department " +
                    "left outer join fetch position.organization as organization " +
                    "where (form.formId = :formID) and  " +
                    "(position.primaryOrgInd = 'Y')")
                        .setParameter("formID", new Long(formId))
                        .list();
            /*                  "where (form.cid = position.cid) and (position.positionNumber *= cod.code) and  " +
                                "(position.orgDeptLocId *= department.orgDeptLocId) and  " +
                                "(position.orgId *= organization.orgId) and (form.formId = :formID) and  " +
                                "(position.primaryOrgInd = 'Y')")
*/

            if (queryList.size() > 0) {
                this.loadData((PositionBean) queryList.get(0));
            } else {
                // the DB does not contain any rows. Make sure the bean exists.
                this.cid = this.getLogonBean().getWeb_id();
                this.primaryOrgInd = "Y";
            }

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded PositionBean : " + queryList.size());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void loadData(PositionBean bean) {
        logger.info("PositionBean : loadData()");
        // Set values
        try {
            // BeanUtils.copyProperties(destination, source)
            BeanUtils.copyProperties(this, bean);
        } catch (InvocationTargetException ex) {
            ex.printStackTrace();
            logger.info("PositionBean : loadData() - InvocationTargetException");
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
            logger.info("PositionBean : loadData() - IllegalAccessException");

        }
    }

    /**
     * save
     *
     * @return String
     */
    public String save(Session session) throws HibernateException, InvocationTargetException,
            IllegalAccessException, Exception {
        List queryList;
        String saveOutcome = "failure"; // Defaults to failure

        logger.info("In PositionBean.save()");

        HibernateUtil.beginTransaction();

        queryList = session.createQuery("from PersonPosition " +
                                        "where cid = :cid and Primary_Org_Ind = 'Y'")
                    .setParameter("cid", this.getCid())
                    .list();
        logger.info("In PositionBean.save() - Retrieved hibernate.PersonPosition object for cid: " +
                    this.getCid());
        if (queryList.size() > 0) {
            // Set values
            hibernate.PersonPosition myPosition = (hibernate.PersonPosition) queryList.get(0);

            // Check for stale data
            if (!isStaleData(myPosition.getChangeDate(), this.getChangeDate())) {
                logger.info("In PositionBean.save() - Not Stale data");
                // Save to DB

                // BeanUtils.copyProperties(destination, source)
                BeanUtils.copyProperties(myPosition, this);
                session.saveOrUpdate(myPosition);
                saveOutcome = "success";
            } else {
                logger.error("In PositionBean.save() - Stale data -  NOT Saving");
            }

        }

        /**
         * Save Form data (if save Person saved successfully)
         * */
        if (saveOutcome.equalsIgnoreCase(Constants.SUCCESS_OUTCOME)) {
            logger.info("In PositionBean.save() - saving Form data");
            logger.info("In PositionBean.save() - Retrieving hibernate.Form object for formId: " +
                        this.formId);
            queryList = session.createQuery("from Form form where form.formId = :formIdparm")
                        .setParameter("formIdparm", this.getFormId())
                        .list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded hibernate.Form objects : " + queryList.size());
            }

            if (queryList.size() > 0) {
                // Set values
                hibernate.Form myForm = (hibernate.Form) queryList.get(0);
                myForm.setFormStatus("N");
                session.saveOrUpdate(myForm);
                saveOutcome = "success";
                // Check for stale data
                /*if (!isStaleData(myForm.getChangeDate(), this.getChangeDate())) {
                    logger.info("In PositionBean.save() - Form - Not Stale data");
                    // Save to DB

                    myForm.setFormLanguage(this.getFormLanguage());
                    session.saveOrUpdate(myForm);
                    saveOutcome = Constants.SUCCESS_OUTCOME;
                                                 } else {
                    logger.error("In IdentificationBean.save() - Stale data in Form -  NOT Saving");
                                                 }*/
            }

        }
        return saveOutcome;
    }

    /**
     * getPositionTypeList
     *
     * @return String
     */
    public String getPositionNumberName() {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {
            return this.positionTypeFrench;

        } else {
            return this.positionTypeEnglish;

        }

    }

    /**
     * setPositionNumberName
     *
     * @param PositionNumberName String
     */
    public void setPositionNumberName(String PositionNumberName) {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {
            this.positionTypeFrench = PositionNumberName;

        } else {
            this.positionTypeEnglish = PositionNumberName;

        }

    }


    public SelectItem[] getOrgIdList() {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {
            return new SelectItem[] {
                    new SelectItem(this.orgId, this.orgNameFrench),
            };

        } else {
            return new SelectItem[] {
                    new SelectItem(this.orgId, this.orgNameEnglish),
            };

        }

    }

    public SelectItem[] getDeptIdList() {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {
            return new SelectItem[] {
                    new SelectItem(this.orgDeptLocId, this.departmentNameFrench),
            };

        } else {
            return new SelectItem[] {
                    new SelectItem(this.orgDeptLocId, this.departmentNameEnglish),
            };

        }

    }

    /**
     * getOrgName
     *
     * @return String
     */
    public String getOrgName() {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {
            return this.orgNameFrench;
        } else {
            return this.orgNameEnglish;
        }
    }

    /**
     * setOrgName
     *
     * @param OrgName String
     */
    public void setOrgName(String OrgName) {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {
            this.orgNameFrench = OrgName;
        } else {
            this.orgNameEnglish = OrgName;
        }

    }

}
