package ca.sshrc.web.common.services.phaseListener;

import java.util.*;

import javax.faces.application.*;
import javax.faces.component.*;
import javax.faces.context.*;
import javax.faces.event.*;
import javax.servlet.http.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.util.*;
import org.apache.log4j.*;


/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 *
 *
 *
 */

public class phaseTracker implements PhaseListener {
    private static String cphase = null;
    private static final Logger logger = Logger.getLogger(phaseTracker.class.getName());

    public PhaseId getPhaseId() {
        PhaseId phaseId = PhaseId.ANY_PHASE;
        /*        if(cphase == null) {
                 FacesContext context = FacesContext.getCurrentInstance();
                 cphase = (String)context.getExternalContext()
                                .getInitParameter(PHASE_PARAM);
              }*/

        if (cphase != null) {
            if ("RESTORE_VIEW".equals(cphase)) {
                phaseId = PhaseId.RESTORE_VIEW;
            } else if ("APPLY_REQUEST_VALUES".equals(cphase)) {
                phaseId = PhaseId.APPLY_REQUEST_VALUES;
            } else if ("PROCESS_VALIDATIONS".equals(cphase)) {
                phaseId = PhaseId.PROCESS_VALIDATIONS;
            } else if ("UPDATE_MODEL_VALUES".equals(cphase)) {
                phaseId = PhaseId.UPDATE_MODEL_VALUES;
            } else if ("INVOKE_APPLICATION".equals(cphase)) {
                phaseId = PhaseId.INVOKE_APPLICATION;
            } else if ("RENDER_RESPONSE".equals(cphase)) {
                phaseId = PhaseId.RENDER_RESPONSE;
            } else if ("ANY_PHASE".equals(cphase)) {
                phaseId = PhaseId.ANY_PHASE;
            }
        }
        return phaseId;

    }

    public void afterPhase(PhaseEvent e) {
        String phaseName = e.getPhaseId().toString();
        logger.info("AFTER PHASE: " + phaseName + " " + getViewId(e));
        String language;

        // Add generic message at top of page if a validation error occurred.
        if ("PROCESS_VALIDATIONS 3".equalsIgnoreCase(phaseName)) {
            // Add a top of page generic message if a FIELD validation error occurred
            FacesContext context = FacesContext.getCurrentInstance();
            Iterator it = context.getClientIdsWithMessages();

            if (it.hasNext()) {
                ResourceBundle validationErrorBundle = null;
                Locale locale = null;

                ExternalContext externalContext = FacesContext.getCurrentInstance().
                                          getExternalContext();
                HttpServletRequest request = (HttpServletRequest) externalContext.
                                             getRequest();
                HttpSession session = ((HttpServletRequest) request).getSession(false);

                NavigationBean navigationBean = (NavigationBean) session.getAttribute("navigationBean");
                // It's possible (when seving Registration.Jsp for example) the NavigationBean will not be there...
                if (null != navigationBean) {
                    language = navigationBean.getLanguageSite();
                } else {
                    // Try getting the site language from the request scope. It should be there.
                    language = (String) request.getParameter("mainForm:bodyContent:languageSite");
                }

                // Create Locale
                if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
                    locale = Locale.CANADA_FRENCH;
                } else {
                    locale = Locale.CANADA;
                }

                validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                        Constants.VALIDATION_ERROR_RESOURCES, locale);

                context.addMessage(null, new FacesMessage(validationErrorBundle.getString("errorGenericTopOfPage"),null));
            }
        }
    }

    public void beforePhase(PhaseEvent e) {
        logger.info("BEFORE PHASE: " + e.getPhaseId() + " " + getViewId(e));
    }

    public String getViewId(PhaseEvent event) {
        UIViewRoot view = event.getFacesContext().getViewRoot();
        String viewID = "no view";
        if (view != null) viewID = view.getViewId();

        return viewID;

    }
}
