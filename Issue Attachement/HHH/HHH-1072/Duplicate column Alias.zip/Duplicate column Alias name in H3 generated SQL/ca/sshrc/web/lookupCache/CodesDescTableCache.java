package ca.sshrc.web.lookupCache;

import java.io.*;
import javax.faces.model.SelectItem;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import java.util.*;
import ca.sshrc.web.common.services.*;
import org.hibernate.*;
import java.text.*;
import ca.sshrc.web.common.util.Constants;

public class CodesDescTableCache implements Serializable {

    private Logger logger = Logger.getLogger(CodesDescTableCache.class.getName());
    private String descType;  // Should be (s)hort description) or (l)ong description.
    private String sortOrder; // Specifies if the list returned by getList method will be sorted (A)scending or (D)escending.
    private String sortBy;    // Specifies if the list returned by getList method will be sorted on the (s)equence number or the (d)escription.
    private boolean insertBlankEntry; // Specifies weather to add a blank entry in list first position or not
    private SelectItem englishList[] = null;
    private SelectItem frenchList[] = null;
    private ArrayList englishObjectList = null;
    private ArrayList frenchObjectList = null;

    public CodesDescTableCache(Integer subGroup, String descType, String sortOrder, String sortBy, boolean insertBlankEntry) {

        List queryList = null;

        /**
         * Integer subGroup:         Sub group number to be used for the retrieval.
         * String descType:          Specifies which code's description will be returned by the getList method.
         *                           Should be (s)hort description) or (l)ong description.
         * String sortOrder:         Specifies if the list returned by getList method will be sorted (A)scending or (D)escending.
         * String sortBy:            Specifies if the list returned by getList method will be sorted on the (s)equence number or the (d)escription.
         * boolean insertBlankEntry: Specifies weather to add a blank entry in list first position or not
         */
        this.descType = descType;
        this.sortOrder = sortOrder;
        this.sortBy = sortBy;
        this.insertBlankEntry = insertBlankEntry;


        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In CodesDescTableCache");

            queryList = session.createQuery("select new ca.sshrc.web.lookupCache.CodesDescBean(Codes.code, " +
                                            "Codes.codeType, " +
                                            "Codes.nameEnglish, " +
                                            "Codes.nameFrench, " +
                                            "Codes.shortNameEnglish, " +
                                            "Codes.shortNameFrench, " +
                                            "Codes.sequenceNumber) " +
                                            "from Cod Codes " +
                                            "where ((Codes.codesTablByCodeTableId = :subGroup) and " +
                                            "(Codes.activeInd = 'Y')) " +
                                            "order by 5 Asc, 6 Asc")
                        .setParameter("subGroup", subGroup)
                        .list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("CodesDescTableCache for table ID: " + subGroup + " - Rows loaded: " +
                            queryList.size());
            }

        } catch (HibernateException ex) {
            ex.printStackTrace();
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
        } finally {
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            // Build the lists
            this.buildList(queryList);
        }
    }

    private void buildList(List queryList) {
        // Build a English list of SelecItem object
        // First get a copy of the queryList
        ArrayList englishListTemp = new ArrayList(queryList);
        ArrayList frenchListTemp = new ArrayList(queryList);
        int blankEntryToAdd = 0;  // used below to add a blank entry in a list

        // Keep the original array. Use a copy for sorting
        if (sortBy.equalsIgnoreCase("d")) {
            if (this.sortOrder.equalsIgnoreCase("a")) {
                if (descType.equalsIgnoreCase("s")) {
                    Collections.sort(englishListTemp, shortNameEnglishOrderAsc); // English - Ascending - Short description
                    Collections.sort(frenchListTemp, shortNameFrenchOrderAsc); // French - Ascending - Short description
                } else {
                    Collections.sort(englishListTemp, nameEnglishOrderAsc); // English - Ascending - Long description
                    Collections.sort(frenchListTemp, nameFrenchOrderAsc); // French - Ascending - Long description
                }
            } else {
                if (descType.equalsIgnoreCase("s")) {
                    Collections.sort(englishListTemp, shortNameEnglishOrderDesc); // English - Descending - Short description
                    Collections.sort(frenchListTemp, shortNameFrenchOrderDesc); // French - Descending - Short description
                } else {
                    Collections.sort(englishListTemp, nameEnglishOrderDesc); // English - Deccending - Long description
                    Collections.sort(frenchListTemp, nameFrenchOrderDesc); // French - Descending - Long description
                }
            }
        } else {
            Collections.sort(englishListTemp, sequenceNumberOrderAsc); // English - Ascending - Sequence number
            Collections.sort(frenchListTemp, sequenceNumberOrderAsc); // French - Ascending - Sequence number
        }


        // Store ArrayList in corresponding variables.
        englishObjectList = englishListTemp;
        frenchObjectList = frenchListTemp;

        // Build javax.faces.model.SelectItem arrays (Add one spot for the empty selection if insertBlankEntry=true)
        if (insertBlankEntry) {
            blankEntryToAdd = 1;
        }

        SelectItem englishSelectItemTemp[] = new SelectItem[englishListTemp.size()+blankEntryToAdd];
        SelectItem frenchSelectItemTemp[] = new SelectItem[frenchListTemp.size()+blankEntryToAdd];

        if (insertBlankEntry) {
            englishSelectItemTemp[0] = new SelectItem(new Integer(0),"");
            frenchSelectItemTemp[0] = new SelectItem(new Integer(0),"");
        }


        for (int i = blankEntryToAdd; i < englishListTemp.size()+blankEntryToAdd; i++) {
            if (descType.equalsIgnoreCase("s")) {
                englishSelectItemTemp[i] = new SelectItem(((CodesDescBean) englishListTemp.get(i-blankEntryToAdd)).
                                                getCode(),
                                                ((CodesDescBean) englishListTemp.get(i-blankEntryToAdd)).
                                                getShortNameEnglish());

                frenchSelectItemTemp[i] = new SelectItem(((CodesDescBean) frenchListTemp.get(i-blankEntryToAdd)).
                                               getCode(),
                                               ((CodesDescBean) frenchListTemp.get(i-blankEntryToAdd)).
                                               getShortNameFrench());
            } else {
                englishSelectItemTemp[i] = new SelectItem(((CodesDescBean) englishListTemp.get(i-blankEntryToAdd)).
                                                getCode(),
                                                ((CodesDescBean) englishListTemp.get(i-blankEntryToAdd)).
                                                getNameEnglish());

                frenchSelectItemTemp[i] = new SelectItem(((CodesDescBean) frenchListTemp.get(i-blankEntryToAdd)).
                                               getCode(),
                                               ((CodesDescBean) frenchListTemp.get(i-blankEntryToAdd)).
                                               getNameFrench());
            }
        }

        // Load class scope SelectItem variable
        this.englishList = englishSelectItemTemp;
        this.frenchList = frenchSelectItemTemp;
    }

    public SelectItem[] getSelectItem(String language) {
        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            return this.frenchList;

        } else {
            return this.englishList;
        }
    }

    public ArrayList getList(String language) {
        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            return this.frenchObjectList;

        } else {
            return this.englishObjectList;
        }
    }

    // Collator - Sort English desc. Ascending
    private static final Comparator nameEnglishOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp1.getNameEnglish(), objComp2.getNameEnglish());
        }
    };

    // Collator - Sort English desc. Descending
    private static final Comparator nameEnglishOrderDesc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp2.getNameEnglish(), objComp1.getNameEnglish());
        }
    };

    // Collator - Sort English desc. Ascending
    private static final Comparator shortNameEnglishOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp1.getShortNameEnglish(), objComp2.getShortNameEnglish());
        }
    };

    // Collator - Sort English desc. Descending
    private static final Comparator shortNameEnglishOrderDesc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp2.getShortNameEnglish(), objComp1.getShortNameEnglish());
        }
    };

    // Collator - Sort French desc. Ascending
    private static final Comparator nameFrenchOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return objComp1.getNameFrench().compareTo(objComp2.getNameFrench());
        }
    };

    // Collator - Sort French desc. Descending
    private static final Comparator nameFrenchOrderDesc = new Comparator() {
        public int compare(Object o1, Object o2) {
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return objComp2.getNameFrench().compareTo(objComp1.getNameFrench());
        }
    };

    // Collator - Sort French desc. Ascending
    private static final Comparator shortNameFrenchOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return objComp1.getShortNameFrench().compareTo(objComp2.getShortNameFrench());
        }
    };

    // Collator - Sort French desc. Descending
    private static final Comparator shortNameFrenchOrderDesc = new Comparator() {
        public int compare(Object o1, Object o2) {
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return objComp2.getShortNameFrench().compareTo(objComp1.getShortNameFrench());
        }
    };

    // Collator - Sort sequence number Ascending
    private static final Comparator sequenceNumberOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return objComp1.getSequenceNumber().compareTo(objComp2.getSequenceNumber());
        }
    };

}


