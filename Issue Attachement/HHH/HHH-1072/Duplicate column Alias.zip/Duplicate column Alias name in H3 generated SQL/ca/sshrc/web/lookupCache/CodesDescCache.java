package ca.sshrc.web.lookupCache;

import java.io.*;
import java.text.*;
import java.util.*;

import javax.faces.model.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.util.*;
import org.hibernate.*;
import org.apache.log4j.*;

public class CodesDescCache implements Serializable {
    private Logger logger = Logger.getLogger(CodesDescCache.class.getName());
    private String descType; // Should be (s)hort description) or (l)ong description.
    private String sortOrder; // Specifies if the list returned by getList method will be sorted (A)scending or (D)escending.
    private String sortBy; // Specifies if the list returned by getList method will be sorted on the (s)equence number or the (d)escription.
    private boolean insertBlankEntry; // Specifies weather to add a blank entry in list first position or not
    private SelectItem englishList[] = null;
    private SelectItem frenchList[] = null;
    private ArrayList englishObjectList = null;
    private ArrayList frenchObjectList = null;
    private ArrayList filterList = null;
    private boolean isFilterRange = false;
    private int blankEntryToAdd = 0;

    public CodesDescCache(Integer subGroup, String descType, String sortOrder, String sortBy,
                          boolean insertBlankEntry) {

        List queryList = null;

        /**
         * Integer subGroup:         Sub group number to be used for the retrieval.
         * String descType:          Specifies which code's description will be returned by the getList method.
         *                           Should be (s)hort description) or (l)ong description.
         * String sortOrder:         Specifies if the list returned by getList method will be sorted (A)scending or (D)escending.
         * String sortBy:            Specifies if the list returned by getList method will be sorted on the (s)equence number or the (d)escription.
         * boolean insertBlankEntry: Specifies weather to add a blank entry in list first position or not
         */
        this.descType = descType;
        this.sortOrder = sortOrder;
        this.sortBy = sortBy;
        this.insertBlankEntry = insertBlankEntry;

        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In CodesDescCache");

            queryList = session.createQuery("select new ca.sshrc.web.lookupCache.CodesDescBean(Codes.code, " +
                                            "Codes.codeType, " +
                                            "Codes.nameEnglish, " +
                                            "Codes.nameFrench, " +
                                            "Codes.shortNameEnglish, " +
                                            "Codes.shortNameFrench, " +
                                            "Codes.sequenceNumber, " +
                                            "CodesCategory.sequenceNumber, " +
                                            "CodesCategory.comp_id.subGroup) " +
                                            "from Cod Codes, " +
                                            "CodesCategory CodesCategory " +
                                            "where (Codes.code = CodesCategory.comp_id.codByCode) and " +
                                            "((CodesCategory.comp_id.subGroup = :subGroup) and " +
                                            "(Codes.activeInd = 'Y')) " +
                                            "order by 5 Asc, 6 Asc")
                        .setParameter("subGroup", subGroup)
                        .list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("CodesDescCache for sub group: " + subGroup + " - CodesDescBean object loaded: " +
                            queryList.size());
            }

        } catch (HibernateException ex) {
            ex.printStackTrace();
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
        } finally {
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            // Build the lists
            this.buildList(queryList);
        }
    }

    private void buildList(List queryList) {
        // Build a English list of SelecItem object
        // First get a copy of the queryList
        ArrayList englishListTemp = new ArrayList(queryList);
        ArrayList frenchListTemp = new ArrayList(queryList);

        // Keep the original array. Use a copy for sorting
        if (sortBy.equalsIgnoreCase("d")) { // sort by Description
            if (this.sortOrder.equalsIgnoreCase("a")) { // sort ascending
                if (descType.equalsIgnoreCase("s")) { // long or short description
                    Collections.sort(englishListTemp, shortNameEnglishOrderAsc); // English - Ascending - Short description
                    Collections.sort(frenchListTemp, shortNameFrenchOrderAsc); // French - Ascending - Short description
                } else {
                    Collections.sort(englishListTemp, nameEnglishOrderAsc); // English - Ascending - Long description
                    Collections.sort(frenchListTemp, nameFrenchOrderAsc); // French - Ascending - Long description
                }
            } else {
                if (descType.equalsIgnoreCase("s")) {
                    Collections.sort(englishListTemp, shortNameEnglishOrderDesc); // English - Descending - Short description
                    Collections.sort(frenchListTemp, shortNameFrenchOrderDesc); // French - Descending - Short description
                } else {
                    Collections.sort(englishListTemp, nameEnglishOrderDesc); // English - Deccending - Long description
                    Collections.sort(frenchListTemp, nameFrenchOrderDesc); // French - Descending - Long description
                }
            }
        } else {
            Collections.sort(englishListTemp, sequenceNumberOrderAsc); // English - Ascending - Sequence number
            Collections.sort(frenchListTemp, sequenceNumberOrderAsc); // French - Ascending - Sequence number
        }

        // Store ArrayList in corresponding variables.
        englishObjectList = englishListTemp;
        frenchObjectList = frenchListTemp;

        // Build javax.faces.model.SelectItem arrays (Add one spot for the empty selection if insertBlankEntry=true)
        if (insertBlankEntry) {
            blankEntryToAdd = 1;
        }

        SelectItem englishSelectItemTemp[] = new SelectItem[englishListTemp.size() + blankEntryToAdd];
        SelectItem frenchSelectItemTemp[] = new SelectItem[frenchListTemp.size() + blankEntryToAdd];

        if (insertBlankEntry) {
            englishSelectItemTemp[0] = new SelectItem(new Integer(0), "");
            frenchSelectItemTemp[0] = new SelectItem(new Integer(0), "");
        }

        for (int i = blankEntryToAdd; i < englishListTemp.size() + blankEntryToAdd; i++) {
            if (descType.equalsIgnoreCase("s")) {
                englishSelectItemTemp[i] = new SelectItem(((CodesDescBean) englishListTemp.get(i -
                        blankEntryToAdd)).
                        getCode(),
                        ((CodesDescBean) englishListTemp.get(i - blankEntryToAdd)).
                        getShortNameEnglish());

                frenchSelectItemTemp[i] = new SelectItem(((CodesDescBean) frenchListTemp.get(i -
                        blankEntryToAdd)).
                        getCode(),
                        ((CodesDescBean) frenchListTemp.get(i - blankEntryToAdd)).
                        getShortNameFrench());
            } else {
                englishSelectItemTemp[i] = new SelectItem(((CodesDescBean) englishListTemp.get(i -
                        blankEntryToAdd)).
                        getCode(),
                        ((CodesDescBean) englishListTemp.get(i - blankEntryToAdd)).
                        getNameEnglish());

                frenchSelectItemTemp[i] = new SelectItem(((CodesDescBean) frenchListTemp.get(i -
                        blankEntryToAdd)).
                        getCode(),
                        ((CodesDescBean) frenchListTemp.get(i - blankEntryToAdd)).
                        getNameFrench());
            }
        }

        // Load class scope SelectItem variable
        this.englishList = englishSelectItemTemp;
        this.frenchList = frenchSelectItemTemp;
    }

    public SelectItem[] getSelectItem(String language) {

        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (null != filterList) {
                return this.getFilteredList(frenchList);
            } else {
                return this.frenchList;
            }
        } else {
            if (null != filterList) {
                return this.getFilteredList(englishList);
            } else {
                return this.englishList;
            }
        }
    }

    // For filtering a list based on a list of codes to be included
    private SelectItem[] getFilteredList(SelectItem[] selectItem) {

        SelectItem selectItemTemp[] = new SelectItem[filterList.size() + blankEntryToAdd];
        int k = 0;

        // First, let's add the blank items
        for (int i = 0; i < this.blankEntryToAdd; i++) {
            selectItemTemp[i] = selectItem[0];
        }

        // filterList contains a list of values to be found
        if (!this.isFilterRange) {
            for (int i = 0 + blankEntryToAdd - 1; i < selectItem.length; i++) {

                for (int j = 0; j < this.filterList.size(); j++) {
                    if (((Integer) selectItem[i].getValue()).intValue() ==
                        ((Integer)this.filterList.get(j)).intValue()) {
                        selectItemTemp[j+blankEntryToAdd] = selectItem[i];
                    }
                }
            }

        } else { // filterList contains a range of values to be found (array position 0 and 1)
            for (int i = 0 + blankEntryToAdd - 1; i < selectItem.length; i++) {
                 if ((((Integer) selectItem[i].getValue()).intValue() == ((Integer)this.filterList.get(0)).intValue() || ((Integer) selectItem[i].getValue()).intValue() > ((Integer)this.filterList.get(0)).intValue()) && (((Integer) selectItem[i].getValue()).intValue() == ((Integer)this.filterList.get(1)).intValue() || ((Integer) selectItem[i].getValue()).intValue() < ((Integer)this.filterList.get(1)).intValue())) {
                    selectItemTemp[k + blankEntryToAdd] = selectItem[i];
                    k++;
                }
            }
        }
        // Reset
        this.filterList = null;

        return selectItemTemp;
    }

    public ArrayList getList(String language) {
        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            return this.frenchObjectList;

        } else {
            return this.englishObjectList;
        }
    }

    // Collator - Sort English desc. Ascending
    private static final Comparator nameEnglishOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp1.getNameEnglish(), objComp2.getNameEnglish());
        }
    };

    // Collator - Sort English desc. Descending
    private static final Comparator nameEnglishOrderDesc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp2.getNameEnglish(), objComp1.getNameEnglish());
        }
    };

    // Collator - Sort English desc. Ascending
    private static final Comparator shortNameEnglishOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp1.getShortNameEnglish(), objComp2.getShortNameEnglish());
        }
    };

    // Collator - Sort English desc. Descending
    private static final Comparator shortNameEnglishOrderDesc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp2.getShortNameEnglish(), objComp1.getShortNameEnglish());
        }
    };

    // Collator - Sort French desc. Ascending
    private static final Comparator nameFrenchOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA_FRENCH);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp1.getNameFrench(), objComp2.getNameFrench());
        }
    };

    // Collator - Sort French desc. Descending
    private static final Comparator nameFrenchOrderDesc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp2.getNameFrench(), objComp1.getNameFrench());
        }
    };

    // Collator - Sort French desc. Ascending
    private static final Comparator shortNameFrenchOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA_FRENCH);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp1.getShortNameFrench(), objComp2.getShortNameFrench());
        }
    };

    // Collator - Sort French desc. Descending
    private static final Comparator shortNameFrenchOrderDesc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA_FRENCH);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp2.getShortNameFrench(), objComp1.getShortNameFrench());
        }
    };

    // Collator - Sort sequence number Ascending
    private static final Comparator sequenceNumberOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return objComp1.getSequenceNumber().compareTo(objComp2.getSequenceNumber());
        }
    };

    public void setFilter(ArrayList filterList, boolean isFilterRange) {

        // Trim list
        filterList.trimToSize();

        // Do not set the variable for filter range if the filterList has more then 2 position filed
        if (isFilterRange) {
            if (filterList.size() == 2) {
                this.filterList = filterList;
                this.isFilterRange = isFilterRange;
            }
        } else {
            this.filterList = filterList;
            this.isFilterRange = isFilterRange;
        }
    }
}
