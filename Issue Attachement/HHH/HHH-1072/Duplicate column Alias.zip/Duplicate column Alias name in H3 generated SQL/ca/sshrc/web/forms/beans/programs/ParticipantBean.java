package ca.sshrc.web.forms.beans.programs;

import java.lang.reflect.*;
import java.math.*;
import java.util.*;

import javax.faces.component.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.*;
import hibernate.*;
import org.apache.commons.beanutils.*;
import org.apache.log4j.*;
import org.hibernate.*;

public class ParticipantBean extends BeanBase {
    private Logger logger = Logger.getLogger(ParticipantBean.class.getName());
    private ArrayList dataRowList = new ArrayList(ROWS_PER_PAGE.intValue()); // dataRowList must have enough room for one page
    private UIData dataTable = null;
    private Integer applId; // Place to keep the applId so we can use it to retrieve in the Save method.
    private UIData pageNumberingDataTable = null;
    private boolean isRetrieveForValidationPurposes = false;

    /**
     * Page control attributes:
     *
     * pageToDisplay
     * requestedPage
     * numberOfPages
     */

    // Defines how many rows are displayed per page
    private static final BigDecimal ROWS_PER_PAGE = new BigDecimal(6);
    /**
     * What page will be displayed - Internal, requestedPage will be transfered into pageToDisplay
     * if the requestedPage is valid if not pageToDisplay will be set to the last page.
     */
    // lastRowNumber contains the total number of rows retrieved (set in retrieve method)
    private int lastRowNumber;
    private int startingRow;
    private int endingRow;


    // Default Constructor
    public ParticipantBean() {

        /**
         * Only retrieve the data if the current phase is Render Response phase.
         * (There's no need to retrieve during the Restore View phase).
         * */
        if (this.getFacesContext().getRenderResponse()) {

            try {
                // Get a session
                Session session = HibernateUtil.getSession();
                HibernateUtil.beginTransaction();

                // Call this object's retrieve method
                this.retrieve(0, session);

            } catch (Exception ex) {
                HibernateUtil.closeSession();
                ex.printStackTrace();
            } finally {
                // Close the Hibernate connection
                try {
                    HibernateUtil.commitTransaction();
                    HibernateUtil.closeSession();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } else {
            /**
             * On her way back from the browser
             * Fill up ParticipantBean with empty ParticipantDataBean (6 per page - see attribute rowsPerPage).
             * JSF will put the JSP page data into these new objects.
             */
            for (int i = 0; i < ROWS_PER_PAGE.intValue(); i++) {
                this.dataRowList.add(new ParticipantDataBean());
            }
        }
    }

    // Overwrite ancestor method
    public void retrieve(Session session) {
        retrieve(0, session);
    }

    public void retrieve(long formId, Session session) {
        Logger logger = Logger.getLogger(ParticipantBean.class.getName());
        List queryList;

        if (null == session) {
            if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                logger.error("Cannot load ParticipantBean - Session is null");
                return;
            }
        }

        // If the passed form id is 0, get the form id from the NavigationBean
        if (formId == 0) {
            formId = getNavigationBean().getForm_id();
            if (formId == 0) {
                if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                    logger.error("Cannot load ParticipantBean - no FormId : " + formId);
                    return;
                }
            } else {
                logger.info("ParticipantBean.retrieve using navigationBean FormId : " + formId);
            }

        } else {
            logger.info("ParticipantBean.retrieve using passed parm FormId : " + formId);
        }

        // Retrieve data
        try {
            logger.info("In ParticipantBean.retrieve()");

            /** Original SQL from PB d_appl_participants
             *
             * SELECT  APPL_PARTICIPATION.Part_ID ,
                        APPL_PARTICIPATION.Participation_Type ,
                        APPL_PARTICIPATION.Appl_ID ,
                        APPL_PARTICIPATION.Role_Code ,
                        APPL_PARTICIPATION.Org_Dept_Loc_ID ,
                        APPL_PARTICIPATION.CID ,
                        APPL_PARTICIPATION.Family_Name ,
                        APPL_PARTICIPATION.Given_Name ,
                        APPL_PARTICIPATION.Initials ,
                        APPL_PARTICIPATION.Org_Name ,
                        APPL_PARTICIPATION.Department_Name ,
                        APPL_PARTICIPATION.Change_Date ,
                        APPL_PARTICIPATION.Org_ID ,
                        ORG_DEPT_LOCATION.Department_Name_English ,
                        ORG_DEPT_LOCATION.Department_Name_French ,
                        ORGANIZATION.Name_English ,
                        ORGANIZATION.Name_French ,
                        APPLICATION.Application_Language ,
                        APPL_PARTICIPATION.Data_Centre_ID
                     FROM APPL_PARTICIPATION ,
                        ORG_DEPT_LOCATION ,
                        ORGANIZATION ,
                        APPLICATION
                     WHERE ( APPL_PARTICIPATION.Org_Dept_Loc_ID *= ORG_DEPT_LOCATION.Org_Dept_Loc_ID) and
                     ( APPL_PARTICIPATION.Org_ID *= ORGANIZATION.Org_ID) and
                     ( APPLICATION.Appl_ID = APPL_PARTICIPATION.Appl_ID ) and
                     ( ( APPL_PARTICIPATION.Appl_ID = :al_appl_id ) And
                     ( APPL_PARTICIPATION.Role_Code in ( 148,149 ) ) )
             */

            queryList = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.programs.ParticipantDataBean(Form.formId, ApplParticipation.partId,  " +
                    "ApplParticipation.participationType,  " +
                    "ApplParticipation.applId,  " +
                    "ApplParticipation.roleCode,  " +
                    "ApplParticipation.orgDeptLocId,  " +
                    "ApplParticipation.cid,  " +
                    "ApplParticipation.familyName,  " +
                    "ApplParticipation.givenName,  " +
                    "ApplParticipation.initials,  " +
                    "ApplParticipation.orgName,  " +
                    "ApplParticipation.departmentName,  " +
                    "ApplParticipation.changeDate,  " +
                    "ApplParticipation.orgId,  " +
                    "ApplParticipation.dataCentreId,  " +
                    "OrgDeptLocation.departmentNameEnglish,  " +
                    "OrgDeptLocation.departmentNameFrench,  " +
                    "Organization.nameEnglish, " +
                    "Organization.nameFrench, " +
                    "Form.formLanguage) " +
                    "from Form Form, " +
                    "ApplParticipation ApplParticipation, " +
                    "Organization Organization, " +
                    "OrgDeptLocation OrgDeptLocation " +
                    "where (Form.formId = :formId) and " +
                    "(Form.application.applId = ApplParticipation.applId) and " +
                    "(ApplParticipation.orgDeptLocId *= OrgDeptLocation.orgDeptLocId) and " +
                    "(ApplParticipation.orgId *= Organization.orgId) and " +
                    "(ApplParticipation.roleCode in (148,149))").setParameter("formId", new Long(formId)).
                        list();
//                    "CASE WHEN ApplParticipation.orgId=1 THEN ApplParticipation.orgName WHEN ApplParticipation.orgId<>1 and UPPER(Form.formLanguage)='F' THEN Organization.nameFrench WHEN ApplParticipation.orgId<>1 and UPPER(Form.formLanguage)='E' THEN Organization.nameEnglish ELSE '' END as COMP, " +

//            "ApplParticipation as ApplParticipation LEFT OUTER JOIN OrgDeptLocation as OrgDeptLocation ON ApplParticipation.orgDeptLocId = OrgDeptLocation.orgDeptLocId LEFT OUTER JOIN Organization as Organization ON ApplParticipation.orgId = Organization.orgId " +
            /*            "from Form Form, " +
                        "ApplParticipation ApplParticipation, " +
                        "Organization Organization, " +
                        "OrgDeptLocation OrgDeptLocation " +
                        "where (Form.formId = :formId) and " +
                        "(Form.application.applId = ApplParticipation.applId) and " +
                        "(ApplParticipation.orgDeptLocId *= OrgDeptLocation.orgDeptLocId) and " +
                        "(ApplParticipation.orgId *= Organization.orgId) and " +
             "(ApplParticipation.roleCode in (148,149))").setParameter("formId", new Long(formId)).list();*/



            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded ParticipantBean : " + queryList.size());
            }

            /** This method's called from the Validate method. When that happens
             * all rows have to be loaded in dataRowList, not just the rows for
             * one page.
             */
            if (isRetrieveForValidationPurposes) {
                this.dataRowList = new ArrayList(queryList);
            } else {
                this.dataRowList = new ArrayList();

                this.calculatePagination(queryList.size());

                /**
                 * If query returned some rows, load dataRowList ArrayList object container,
                 */
                if (queryList.size() > 0) {
                    int j = 0;
                    for (int i = this.startingRow - 1; i < (this.endingRow); i++) {
                        this.dataRowList.add(j, queryList.get(i));
                        j++;
                    }

                    // Trim array
                    this.dataRowList.trimToSize();

                    // Set this ApplId attribute so it can be used in the Save method (retrieval prior to save)
                    this.applId = ((ParticipantDataBean) queryList.get(0)).getApplId();
                }

                /**
                 * If not enough rows to fill up the page, add empty object(s) to top it up
                 * ex.: queryList.size() = 10 and startingRow = 7
                 * Loop from 3 until < 6 ... will add 3 rows (3,4,5)
                 *
                 * ex.: queryList.size() = 3 and startingRow = 1
                 * Loop from 2 until < 6 ... will add 4 rows (2,3,4,5)
                 *
                 * ex.: queryList.size() = 0 and startingRow = 1
                 * Loop from -1 until < 6 ... will add 3 rows (3,4,5)
                 */
                if (dataRowList.size() < ROWS_PER_PAGE.intValue()) {
                    int startAddingRowAt = dataRowList.size();
                    // Fill up dataRowList with ParticipantDataBean
                    for (int i = startAddingRowAt; i < ROWS_PER_PAGE.intValue(); i++) {
                        dataRowList.add(new ParticipantDataBean());
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     *
     * @param rowsRetrieved int
     */
    public void calculatePagination(int rowsRetrieved) {

        this.lastRowNumber = rowsRetrieved;
        /**
         * Calculate number of possible pages based on number of queryList.size()/this.rowsPerPage (round up).
         * Set this.numberOfPages with calculation result.
         */
        try {
            this.getNavigationBean().setNumberOfPages(new BigDecimal(rowsRetrieved).divide(ROWS_PER_PAGE, 0,
                    BigDecimal.ROUND_UP).
                    intValue());

            /**
             * Set minimum pages, if 0 (rowsRetrieved is less then ROWS_PER_PAGE) then set to 1
             */

            if (this.getNavigationBean().getNumberOfPages() == 0) {
                this.getNavigationBean().setNumberOfPages(1);
            }
        } catch (ArithmeticException aex) {
            // This situation arise when the query returned no rows at all
            this.getNavigationBean().setNumberOfPages(1);
            aex.printStackTrace();
        }

        /**
         * Calculate requested page validity and, reset the pageToDisplay to 1 if it's not a valid value
         * Set this.pageToDisplay to this.requestedPage
         *
         * If this.requestedPage is > then this.numberOfPages then this.pageToDisplay = this.numberOfPages
         * else
         * this.pageToDisplay = this.requestedPage
         *
         */

        if (this.getNavigationBean().getRequestedPageNumber() == 0) {
            this.getNavigationBean().setRequestedPageNumber(1);
        }
        if (this.getNavigationBean().getRequestedPageNumber() > this.getNavigationBean().getNumberOfPages()) {
            this.getNavigationBean().setCurrentPageNumber(this.getNavigationBean().getNumberOfPages());
        } else {
            this.getNavigationBean().setCurrentPageNumber(this.getNavigationBean().getRequestedPageNumber());
        }

        /**
         * Calculate first row on page
         * ex.: pageToDisplay = 2 and ROWS_PER_PAGE = 6
         * (2 * 6) - (6 - 1) = 7
         *
         * ex.: pageToDisplay = 1 and ROWS_PER_PAGE = 6
         * (1 * 6) - (6 - 1) = 1
         */
        startingRow = (this.getNavigationBean().getCurrentPageNumber() * ROWS_PER_PAGE.intValue()) -
                      (ROWS_PER_PAGE.intValue() - 1);

        /**
         * Calculate the last row to be added to the dataRowList array.
         * ex.: Start row = 7 + (6 - 1) = 12
         * if endingRow (12) > query.size (11) then endingRow = query.size (11)
         *
         * Result: endingRow = 11
         */
        endingRow = startingRow + (ROWS_PER_PAGE.intValue() - 1);
        if (endingRow > rowsRetrieved) {
            endingRow = rowsRetrieved;
        }
    }

    /**
     * save
     *
     * @param session Session
     * @return String
     */
    public String save(Session session) throws HibernateException, InvocationTargetException,
            IllegalAccessException {

        String saveOutcome = Constants.SUCCESS_OUTCOME; // Defaults to success - If an error occurs, it will be changed to UPDAT_ERROR_OUTCOME

        int dataRowListSize = dataRowList.size();
        int queryListSize;

        boolean hasData = true;
        boolean isChangeDateRefreshRequired = false;
        boolean isKeyFound = false; // Tells if the web row was found in the DB table

        List queryList = null;

        logger.info("In ParticipantBean.save()");

        queryList = session.createQuery("from ApplParticipation ApplParticipation " +
                                        "where (ApplParticipation.applId = :applicationId) and " +
                                        "(ApplParticipation.roleCode in (148,149))")
                    .setParameter("applicationId", this.applId)
                    .list();

        queryListSize = queryList.size();

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Loaded hibernate.ApplParticipation objects : " + queryList.size());
        }

        if (dataRowListSize > 0) {
            // Set values
            for (int i = 0; i < dataRowListSize; i++) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("Saving dataRowList array pos.: " + i);
                }

                // Set hasData flag - Does the bean have data
                hasData = !((ParticipantDataBean)this.dataRowList.get(i)).isEmpty();

                // Check that this is an existing record using the row's key
                if (((ParticipantDataBean)this.dataRowList.get(i)).getPartId() == null) {
                    // there is no row, copy the bean and save.
                    // Save only if the bean has data

                    isKeyFound = true; // Tells if the web row was found in the DB table
                    if (hasData) {
                        logger.info("this is a new ApplParticipation (adding row)");
                        // Add new ApplParticipation bean to current query result list
                        queryList.add(new ApplParticipation());

                        // Transfer data from web bean to hibernate bean
                        try {
                            BeanUtils.copyProperties((ApplParticipation) queryList.get(queryList.size() -
                                    1),
                                    (ParticipantDataBean)this.dataRowList.get(i));

                            // Add the ApplId of the new created hibernate object
                            ((ApplParticipation) queryList.get(queryList.size() - 1)).setApplId(this.applId);
                            ((ApplParticipation) queryList.get(queryList.size() -
                                    1)).setRoleCode(new Integer(148));

                        } catch (Exception ex1) {
                            ex1.printStackTrace();
                            saveOutcome = Constants.UPDATE_ERROR_OUTCOME;
                        }

                        // Update DB
                        session.saveOrUpdate((ApplParticipation) queryList.get(queryList.size() - 1));
                        session.flush();

                        // Turn changeDate flag ON
                        isChangeDateRefreshRequired = true;

                        session.refresh((ApplParticipation) queryList.get(queryList.size() - 1));

                        // Copy DB values back to bean object
                        try {
                            PropertyUtils.copyProperties((ParticipantDataBean)this.dataRowList.get(i),
                                    (ApplParticipation) queryList.get(queryList.size() - 1));
                        } catch (Exception ex1) {
                            ex1.printStackTrace();
                            saveOutcome = Constants.UPDATE_ERROR_OUTCOME;
                        }
                    } else {
                        logger.info("No key but the row doesn't have data - not adding ApplParticipation");
                    }

                    // this is an existing row. Locate the matching one in the database
                } else {
                    for (int j = 0; j < queryListSize; j++) {
                        // Does this hibernate bean match the web bean?
                        if (((ApplParticipation) queryList.get(j)).getPartId().equals(
                                ((ParticipantDataBean)this.dataRowList.get(i)).getPartId())) {

                            isKeyFound = true; // Tells if the web row was found in the DB table
                            // this is the correct record, update and save
                            if (hasData) {
                                if (((ParticipantDataBean)this.dataRowList.get(i)).isDelete()) {
                                    System.out.println("Deleting ApplParticipation: " +
                                            ((ParticipantDataBean)this.dataRowList.get(i)).getPartId());
                                    // Update DB
                                    session.delete((ApplParticipation) queryList.get(j));
                                    session.flush();
                                }
                                if (!isStaleData(((ApplParticipation) queryList.get(j)).getChangeDate(),
                                                 ((ParticipantDataBean)this.dataRowList.get(i)).
                                                 getChangeDate())) {

                                    // Transfer data from web bean to hibernate bean
                                    try {
                                        BeanUtils.copyProperties((ApplParticipation) queryList.get(j),
                                                (ParticipantDataBean)this.dataRowList.get(i));
                                    } catch (Exception ex) {
                                        ex.printStackTrace();
                                        saveOutcome = Constants.UPDATE_ERROR_OUTCOME;
                                    }

                                    // Update DB
                                    session.saveOrUpdate((ApplParticipation) queryList.get(j));
                                    session.flush();

                                    // Turn isChangeDateRefreshRequired flag ON
                                    isChangeDateRefreshRequired = true;
                                    break;
                                } else {
                                    logger.error("Stale data in ApplParticipation: " +
                                                 ((ApplParticipation) queryList.get(j)).getPartId() +
                                                 " -  NOT Saving");

                                    saveOutcome = Constants.UPDATE_ERROR_OUTCOME;
                                    break;
                                }

                                // No more data in web bean, delete it.
                            } else {
                                session.delete((ApplParticipation) queryList.get(j));
                                session.flush();
                                this.dataRowList.remove(i);
                                break;
                            }
                        }
                        // Didn't find the key...
                        if (j == queryListSize - 1) {
                            isKeyFound = false; // Tells if the web row was found in the DB table
                        }
                    }
                }
                // If the web row was not found in the DB table... exit the main loop and change outcome to UPDATE_ERROR_OUTCOME
                if (!isKeyFound) {
                    saveOutcome = Constants.UPDATE_ERROR_OUTCOME;
                    break;
                }
            }

            // Is a refresh of the changeDate required ?
            if (isChangeDateRefreshRequired && saveOutcome == Constants.SUCCESS_OUTCOME) {
                // Get the first row's changeDate (from hibernate object) and apply it to the other rows
                session.refresh((ApplParticipation) queryList.get(0));

                // Set the Web beans changeDates with the first hibernate ApplParticipation.getChangeDate value
                for (int i = 0; i < dataRowList.size(); i++) {
                    // Update the changeDate only if the key's not Null
                    if (((ParticipantDataBean)this.dataRowList.get(i)).getPartId() != null) {
                        ((ParticipantDataBean)this.dataRowList.get(i)).setChangeDate(((
                                ApplParticipation)
                                queryList.get(0)).getChangeDate());
                    }
                }
            }
        }

        return saveOutcome;
    }

    public String validate(ValidationMessage validationMessage) throws HibernateException, Exception {
        Logger logger = Logger.getLogger(ParticipantDataBean.class.getName());

//        ResourceBundle moduleBundle = null;
        ResourceBundle applicationBundle = null;
        ResourceBundle validationErrorBundle = null;

        Locale locale = null;

        String validationOutcome = Constants.SUCCESS_OUTCOME;
        String moduleDisplayName = null;
        String errorMessage = null;
        String valueString1;
        String valueString2;

//        Short valueShort1;

        Integer subSystemId = null;
        Integer moduleId = null;
        Integer valueInteger1;
        Integer valueInteger2;

        Object tempForNullObject;

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("FundedResearchBean.validate - Start");
        }

        // If messageContainer is null, throw exception
        if (validationMessage == null) {
            throw new Exception("Invalid parameter. ValidationMessage object was null.");
        }

        subSystemId = this.getNavigationBean().getRequestedSubsystemId();
        moduleId = validationMessage.getModuleNavigationBarBean().getSequenceNumber();

        // Create Locale
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            locale = Locale.CANADA_FRENCH;
            moduleDisplayName = validationMessage.getModuleNavigationBarBean().getNameFrench();
        } else {
            locale = Locale.CANADA;
            moduleDisplayName = validationMessage.getModuleNavigationBarBean().getNameEnglish();
        }

        // Get resource bundles
        applicationBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                Constants.APPLICATION_RESOURCES, locale);
        validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                Constants.VALIDATION_ERROR_RESOURCES, locale);
//        moduleBundle = ResourceBundle.getBundle(validationMessage.getResourceBundleName(), locale);

        /**
         *
         * Validate Funded research data
         *
         * */

        try {
            // Get a session
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // Call this object's retrieve method
            isRetrieveForValidationPurposes = true; // Indicate to the Retrieve method to put all rows into dataRowList array
            this.retrieve(session);
            isRetrieveForValidationPurposes = false;

        } catch (Exception ex) {
            HibernateUtil.closeSession();
            ex.printStackTrace();
        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        // Set isEmpty property list to check - in this case on the table key property
        String[] propertyNamesForEmptiness = {"partId"};

        for (int i = 0; i < this.dataRowList.size(); i++) {
            // If no data on
            if (((ParticipantDataBean)this.dataRowList.get(i)).isEmpty(propertyNamesForEmptiness)) {

                // End the validation as soon as we detect an empty key and skip to next row
                continue;
            } else {

                /**
                 * Validate Role
                 *
                 */

                tempForNullObject = PropertyUtils.getProperty(((ParticipantDataBean)this.dataRowList.get(i)),
                        "roleCode");
                if (tempForNullObject != null) {
                    valueInteger1 = (Integer) tempForNullObject;
                } else {
                    valueInteger1 = null;
                }

                if (null == valueInteger1 || (valueInteger1.intValue() == 0)) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                    Object params[] = {applicationBundle.getString("role") + " " +
                                      validationErrorBundle.getString("errorEntryNumberLowerCase") +
                                      (i + 1)};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage,
                            params));
                }

                /**
                 * Validate family name
                 *
                 */

                tempForNullObject = PropertyUtils.getProperty(((ParticipantDataBean)this.dataRowList.get(i)),
                        "familyName");
                if (tempForNullObject != null) {
                    valueString1 = (String) tempForNullObject;
                } else {
                    valueString1 = null;
                }

                if (valueString1 != null) {
                    if ((valueString1.trim()).equals("")) {
                        // Add validation error message
                        errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                        Object params[] = {applicationBundle.getString("familyName") + " " +
                                          validationErrorBundle.getString("errorEntryNumberLowerCase") +
                                          (i + 1), ""};
                        validationMessage.addMessage(subSystemId,
                                moduleId,
                                moduleDisplayName,
                                validationMessage.substituteParams(locale, errorMessage, params));
                    }
                }

                /**
                 * Validate given name
                 *
                 */

                tempForNullObject = PropertyUtils.getProperty(((ParticipantDataBean)this.dataRowList.get(i)),
                        "givenName");
                if (tempForNullObject != null) {
                    valueString1 = (String) tempForNullObject;
                } else {
                    valueString1 = null;
                }

                // All other Org Name must have a value entered if there corresponding Org code equals 1.
                if (valueString1 != null) {
                    if ((valueString1.trim()).equals("")) {
                        // Add validation error message
                        errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                        Object params[] = {applicationBundle.getString("givenName") + " " +
                                          validationErrorBundle.getString("errorEntryNumberLowerCase") +
                                          (i + 1), ""};
                        validationMessage.addMessage(subSystemId,
                                moduleId,
                                moduleDisplayName,
                                validationMessage.substituteParams(locale, errorMessage, params));
                    }
                }

                /**
                 * Organization codes and "Other" fields
                 *
                 */

                // Avoid NullPointerException

                // Organization Id
                tempForNullObject = PropertyUtils.getProperty(((ParticipantDataBean)this.dataRowList.get(i)),
                        "orgId");
                if (tempForNullObject != null) {
                    valueInteger1 = (Integer) tempForNullObject;
                } else {
                    valueInteger1 = null;
                }

                // Organization Department Id
                tempForNullObject = PropertyUtils.getProperty(((ParticipantDataBean)this.dataRowList.get(i)),
                        "orgDeptLocId");
                if (tempForNullObject != null) {
                    valueInteger2 = (Integer) tempForNullObject;
                } else {
                    valueInteger2 = null;
                }

                // Other Organization name
                tempForNullObject = PropertyUtils.getProperty(((ParticipantDataBean)this.dataRowList.get(i)),
                        "orgName");
                if (tempForNullObject != null) {
                    valueString1 = (String) tempForNullObject;
                } else {
                    valueString1 = null;
                }

                // Other Organization name
                tempForNullObject = PropertyUtils.getProperty(((ParticipantDataBean)this.dataRowList.get(i)),
                        "departmentName");
                if (tempForNullObject != null) {
                    valueString2 = (String) tempForNullObject;
                } else {
                    valueString2 = null;
                }

                /** Organization - Was Org. Id selected */
                if (null == valueInteger1 || (valueInteger1.intValue() == 0)) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                    Object params[] = {applicationBundle.getString("organization") + " " +
                                      validationErrorBundle.getString("errorEntryNumberLowerCase") + (i + 1)};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage, params));
                    // Organization - Was Org. Id 1 selected - Other
                } else if (valueInteger1.intValue() == 1) { // Other
                    // Organization - Org. Id 1 selected - Was org. name entered
                    if (null == valueString1 || valueString1.trim().equals("")) {
                        // Add validation error message
                        errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                        Object params[] = {applicationBundle.getString("OtherOrganization") + " " +
                                          validationErrorBundle.getString("errorEntryNumberLowerCase") + (i + 1)};
                        validationMessage.addMessage(subSystemId,
                                                     moduleId,
                                                     moduleDisplayName,
                                                     validationMessage.substituteParams(locale, errorMessage,
                                params));
                    }
                }

                // Organization - Org. Id 1 not selected - org. name was entered
                if (null != valueString1 && !valueString1.trim().equals("") && valueInteger1.intValue() != 1) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorIfOther");
                    Object params[] = {applicationBundle.getString("organization"),
                                      validationErrorBundle.getString("errorEntryNumberUpperCase") + (i + 1)};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage, params));

                }

                // Department - Was dept. Id selected
                if (null == valueInteger2 || (valueInteger2.intValue() == 0)) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                    Object params[] = {applicationBundle.getString("Department") + " " +
                                      validationErrorBundle.getString("errorEntryNumberLowerCase") + (i + 1)};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage, params));
                    // Department - Was dept. Id 2 selected - Other
                } else if (valueInteger2.intValue() == 2) { // Other
                    // Department - Dept. Id 2 selected - Was Dept. name entered
                    if (null == valueString2 || valueString2.trim().equals("")) {
                        // Add validation error message
                        errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                        Object params[] = {applicationBundle.getString("OtherDepartment") + " " +
                                          validationErrorBundle.getString("errorEntryNumberLowerCase") + (i + 1)};
                        validationMessage.addMessage(subSystemId,
                                                     moduleId,
                                                     moduleDisplayName,
                                                     validationMessage.substituteParams(locale, errorMessage,
                                params));
                    }
                }

                // Organization - Org. Id 1 not selected - org. name was entered
                if (null != valueString2 && !valueString2.trim().equals("") &&
                    valueInteger2.intValue() != 2) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorIfOther");
                    Object params[] = {applicationBundle.getString("Department"),
                                      validationErrorBundle.getString("errorEntryNumberUpperCase") + (i + 1)};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage, params));

                }
            }
        } // End of i loop
        return validationOutcome;
    }

    public UIData getDataTable() {
        return dataTable;
    }

    public int getRowsPerPage() {
        return ROWS_PER_PAGE.intValue();
    }

    public void setDataTable(UIData table) {
        this.dataTable = table;
    }

    public void setDataRows(ArrayList dataRows) {
        this.dataRowList = dataRows;
    }

    public ArrayList getDataRows() {
        return dataRowList;
    }

    public Integer getApplId() {
        return applId;
    }

    public int getLastRowNumber() {
        return lastRowNumber;
    }

    public void setApplId(Integer applId) {
        this.applId = applId;
    }

    public void setLastRowNumber(int lastRowNumber) {
        this.lastRowNumber = lastRowNumber;
    }

    public UIData getPageNumberingDataTable() {
        return pageNumberingDataTable;
    }

    public void setPageNumberingDataTable(UIData table) {
        this.pageNumberingDataTable = table;
    }

    public ArrayList getDataTableRow() {

        ArrayList rows = new ArrayList();
        rows.add(new GenericDataTable("", "", true)); // value,styleclass,rendered
        rows.trimToSize();

        return rows;
    }

    public ArrayList getDataTableColumn() {
        boolean rendered;
        String styleClass = "CMDL";
        int numberOfPages = this.getNavigationBean().getNumberOfPages();
        int currentPageNumber = this.getNavigationBean().getCurrentPageNumber();
        ArrayList columns = new ArrayList(numberOfPages);

        if (numberOfPages > 1) {
            for (int i = 1; i <= numberOfPages; i++) {
                if (i == currentPageNumber) {
                    styleClass = "CMDL";
                    rendered = false; // OutputText
                } else {
                    styleClass = "MDL";
                    rendered = true; // CommandLink
                }
                columns.add(new GenericDataTable(i, styleClass, rendered)); // value,styleclass,rendered
            }
        }

        return columns;
    }
}
