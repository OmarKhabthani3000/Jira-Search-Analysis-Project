package ca.sshrc.web.logon;

import ca.sshrc.web.common.util.*;
import org.apache.log4j.*;

public class LogonService {

    /**
     * This method is used to validate a user id and password. The validation DOES NOT
     * verify is the account is in good standing (i.e.: Lock or password expired).
     * This is used by the Password Change page.
     *
     * @param web_id Integer
     * @param password String
     * @return String
     */
    public static String validateAccessRight(Integer web_id, String password) {
        LogonDBA logonDBA = new LogonDBA();

        return logonDBA.validateAccessRight(web_id, password);
    }

    /**
     * This method is used when a user is trying to log in the system.
     *
     * @param logon LogonBean
     * @return String
     */
    public static String validateAccessRight(LogonBean logonBean) {
        LogonDBA logonDBA = new LogonDBA();
        String outcome = logonDBA.validateAccessRight(logonBean);
        Logger logger = Logger.getLogger(LogonService.class.getName());

        if (outcome.equals(Constants.SUCCESS_OUTCOME)) {
            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Access granted to web ID: " + logonBean.getWeb_id());
            }
        }

        if (outcome.equals(Constants.FAILURE_OUTCOME)) {
            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Access refused to web ID: " + logonBean.getWeb_id());
            }
        }

        if (outcome.equals(Constants.ACCOUNT_LOCKED_OUTCOME)) {
            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Access refused (account locked) to web ID: " + logonBean.getWeb_id());
            }
        }

        if (outcome.equals(Constants.ACCOUNT_PASSWORD_EXPIRED_OUTCOME)) {
            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Access granted - Change password requested to web ID: " + logonBean.getWeb_id());
            }
        }

        return outcome;
    }
}
