package ca.sshrc.web.forms.beans.cv;

import java.lang.reflect.*;
import java.util.*;

import javax.faces.event.*;
import javax.faces.model.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.services.baseObject.*;
import org.hibernate.*;
import org.apache.commons.beanutils.*;
import org.apache.log4j.*;
import ca.sshrc.web.common.util.Constants;


/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class PositionAddressBean extends BeanBase {
    /**
     * PositionAddressBean
     * Minimal constructor
     *
     * @param aCid int
     * @param aiAddressType Integer
     */
    private Integer addressId;
    private Integer cid;
    private Integer formatType;
    private Integer addressType;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String municipality;
    private String provinceStateCode;
    private Integer countryCode;
    private String postalZipCode;
    private Date changeDate;
    private String CountryNameEnglish;
    private String CountryNameFrench;
    private Logger logger = Logger.getLogger(PositionAddressBean.class.getName());

    public PositionAddressBean(long aFormId, Integer aiAddressType) {

        this.addressType = aiAddressType;

        try {
            // Get a session
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // Call this object's retrieve method
            this.retrieve(aFormId, aiAddressType, session);
            HibernateUtil.commitTransaction();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        if (this.addressType == null) {
            this.setAddressType(new Integer(350));
        }
    }

    /**
     * PositionAddressBean
     * Full constructor
     */
    public PositionAddressBean(Integer addressId, Integer cid, Integer formatType, Integer addressType,
                               String address1, String address2, String address3, String address4,
                               String municipality, String provinceStateCode, Integer countryCode,
                               String postalZipCode, Date changeDate, String CountryNameEnglish,
                               String CountryNameFrench) {

        this.addressId = addressId;
        this.cid = cid;
        this.formatType = formatType;
        this.addressType = addressType;
        this.address1 = address1;
        this.address2 = address2;
        this.address3 = address3;
        this.address4 = address4;
        this.municipality = municipality;
        this.provinceStateCode = provinceStateCode;
        this.countryCode = countryCode;
        this.postalZipCode = postalZipCode;
        this.changeDate = changeDate;
        this.CountryNameEnglish = CountryNameEnglish;
        this.CountryNameFrench = CountryNameFrench;

    }


    /** AddressType - Radio button values and labels */
    private SelectItem[] addressTypeFrench = new SelectItem[] {new SelectItem(new Integer(168),
            "Canada"), new SelectItem(new Integer(169), "�tats-Unis"),
                                             new SelectItem(new Integer(170), "Autre")};
    private SelectItem[] addressTypeEnglish = new SelectItem[] {new SelectItem(new Integer(168),
            "Canada"), new SelectItem(new Integer(169), "United States"),
                                              new SelectItem(new Integer(170), "Other")};

    public PositionAddressBean() {
        logger.info("In PositionAddressBean empty constructor");
        long formID = this.getNavigationBean().getForm_id();

        /** IMPORTANT: If the default value of the address type has to be changed here,
         * it might also need to be changed in this.retrieve() method.
         */
        Integer addressType = new Integer(350);

        try {
            // Get a session
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // Call this object's retrieve method
            this.retrieve(formID, addressType, session);
            HibernateUtil.commitTransaction();

        } catch (Exception ex) {
            HibernateUtil.closeSession();
            ex.printStackTrace();
        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public void setAddressId(Integer addressId) {
        this.addressId = addressId;
    }


    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public void setFormatType(Integer formatType) {
        this.formatType = formatType;
    }

    public void setAddressType(Integer addressType) {
        this.addressType = addressType;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    public void setAddress4(String address4) {
        this.address4 = address4;
    }

    public void setMunicipality(String municipality) {
        this.municipality = municipality;
    }

    public void setProvinceStateCode(String provinceStateCode) {
        this.provinceStateCode = provinceStateCode;
    }

    public void setCountryCode(Integer countryCode) {
        this.countryCode = countryCode;
    }

    public void setPostalZipCode(String postalZipCode) {
        this.postalZipCode = postalZipCode;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public void setCountryNameFrench(String CountryNameFrench) {
        this.CountryNameFrench = CountryNameFrench;
    }

    public void setCountryNameEnglish(String CountryNameEnglish) {
        this.CountryNameEnglish = CountryNameEnglish;
    }

    public Integer getAddressId() {
        return addressId;
    }

    public Integer getCid() {
        return cid;
    }

    public Integer getFormatType() {
        if (null == formatType) { return new Integer(0);}
        return formatType;
    }

    public Integer getAddressType() {
        if (null == addressType) { return new Integer(0);}
        return addressType;

    }

    public String getAddress1() {
        return address1;
    }

    public String getAddress2() {
        return address2;
    }

    public String getAddress3() {
        return address3;
    }

    public String getAddress4() {
        return address4;
    }

    public String getMunicipality() {
        return municipality;
    }

    public String getProvinceStateCode() {
        return provinceStateCode;
    }

    public Integer getCountryCode() {
        return countryCode;
    }

    public String getPostalZipCode() {
        return postalZipCode;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public String getCountryNameFrench() {
        return CountryNameFrench;
    }

    public String getCountryNameEnglish() {
        return CountryNameEnglish;
    }

    // Overwrite ancestor method
    public void retrieve(Session session) {
        retrieve(0, new Integer(350), session);
    }

    /**
     * retrieve
     */
    public void retrieve(long aiFormId, Integer aIntType, Session session) {
        List queryList = null;

        if (null == session) {
            if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                logger.error("Cannot load PositionAddressBean - Session is null");
                return;
            }
        }

        // If the passed form_id is 0, get the form_id from the NavigationBean
        if (aiFormId == 0) {
            aiFormId = getNavigationBean().getForm_id();
            if (aiFormId == 0) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.error("Cannot load FundedResearchBean - no FormId : " + aiFormId);
                    return;
                }
            } else {
                logger.info("FundedResearchBean.retrieve using navigationBean FormId : " + aiFormId);
            }

        } else {
            logger.info("FundedResearchBean.retrieve using passed parm FormId : " + aiFormId);
        }

        // Retrieve data
        try {

            logger.info("In PositionAddressBean.retrieve()");

            queryList = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.cv.PositionAddressBean( " +
                    "address.addressId, " +
                    "address.cid, " +
                    "address.formatType, " +
                    "address.addressType, " +
                    "address.address1, " +
                    "address.address2, " +
                    "address.address3," +
                    "address.address4, " +
                    "address.municipality, " +
                    "address.provinceStateCode, " +
                    "address.country.countryCode, " +
                    "address.postalZipCode, " +
                    "address.changeDate, " +
                    "country.nameEnglish, " +
                    "country.nameFrench) " +
                    "from Form form join fetch form.person person " +
                    "left outer join fetch person.personAddress address " +
                    "left outer join fetch address.country country " +
                    "where (address.addressType = :addressType)" +
                    " and (form.formId = :formId)")
                        .setParameter("formId", new Long(aiFormId))
                        .setParameter("addressType", aIntType)
                        .list();

            if (queryList.size() > 0) {
                this.loadData((PositionAddressBean) queryList.get(0));
            }

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded PositionAddressBean : " + queryList.size());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void loadData(PositionAddressBean bean) {

        // Set values
        try {
            // BeanUtils.copyProperties(destination, source)
            BeanUtils.copyProperties(this, bean);
        } catch (InvocationTargetException ex) {
            ex.printStackTrace();

        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * getCountryName
     *
     * @return String
     */
    public String getCountryName() {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {
            return this.CountryNameFrench;
        } else {
            return this.CountryNameEnglish;
        }
    }

    /**
     * setCountryName
     *
     * @param CountryName String
     */
    public void setCountryName(String CountryName) {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {
            this.CountryNameFrench = CountryName;
        } else {
            this.CountryNameEnglish = CountryName;
        }
    }

    /**
     * save
     *
     * @return String
     */
    public String save(Session session) throws HibernateException, InvocationTargetException,
            IllegalAccessException {

        Logger logger = Logger.getLogger(PositionBean.class.getName());
        List queryList;
        String saveOutcome = "failure"; // Defaults to failure

        logger.info("In PositionAddressBean.save()");

        HibernateUtil.beginTransaction();

        queryList = session.createQuery("from PersonAddress " +
                                        "where cid = :cid and Address_Type = 350")
                    .setParameter("cid", this.getCid())
                    .list();
        logger.info("In PositionAddressBean.save() - Retrieved hibernate.PersonAddress object for cid: " +
                    this.getCid());
        logger.info("In PositionAddressBean.save() - QueryList size = : " + queryList.size());
        if (queryList.size() > 0) {
            // Set values
            hibernate.PersonAddress myAddress = (hibernate.PersonAddress) queryList.get(0);

            // Check for stale data
            if (!isStaleData(myAddress.getChangeDate(), this.getChangeDate())) {
                logger.info("In PositionAddressBean.save() - Not Stale data");
                // Save to DB

                // BeanUtils.copyProperties(destination, source)
                BeanUtils.copyProperties(myAddress, this);
                session.saveOrUpdate(myAddress);
                saveOutcome = "success";
            } else {
                logger.error("In PositionAddressBean.save() - Stale data -  NOT Saving");
            }

        }
        return saveOutcome;
    }

    /**
     * getEmptyString
     *
     * @return String
     */
    public String getEmptyString() {
        return "";
    }

    /**
     * getAddressTypes
     *
     * @return SelectItem
     *
     * function used to generate the address type radio button
     */
    public SelectItem[] getAddressTypes() {
        logger.info("PoritionAddress Bean - entering getAddressTypes");

/*        if (this.getNavigationBean().getFormLanguage() != null) {
            if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {
                return this.addressTypeFrench;
            } else {
                return this.addressTypeEnglish;
            }
        } else {*/
            return this.addressTypeEnglish;
 //      }
    }

    public void valueChanged(ValueChangeEvent valueChangeEvent) {
    }

}
