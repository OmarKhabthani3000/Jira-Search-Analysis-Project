package ca.sshrc.web.lookupCache;

import java.io.*;
import java.text.*;
import java.util.*;

import javax.faces.model.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.util.*;
import org.hibernate.*;
import org.apache.log4j.*;

public class ProgramCache implements Serializable {
    private Logger logger = Logger.getLogger(ProgramCache.class.getName());
    private List queryList;
    private List frenchSortedqueryList;
    private List englishSortedqueryList;
    private SelectItem englishSelectItem[] = null;
    private SelectItem frenchSelectItem[] = null;

    public ProgramCache() {
        Session session = HibernateUtil.getSession();
        HibernateUtil.beginTransaction();
        logger.info("In ProgramCache");

        try {
            queryList = session.createQuery(
                    "select new ca.sshrc.web.lookupCache.ProgramBean(Program.programId, " +
                    "Program.nameEnglish, " +
                    "Program.nameFrench) " +
                    "from Program Program " +
                    "order by 1 asc").list();

            /* Original query from PB - dddw_program_list
                         SELECT  PROGRAM.Program_ID ,
                                 PROGRAM.Name_English ,
                                 PROGRAM.Name_French
                                 FROM PROGRAM
             */
            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Program loaded: " + queryList.size());
            }

            // Pre-load French and English sorted ArrayList & SelectItem array
            if (queryList.size() > 0) {
                ArrayList listTemp;
                listTemp = (ArrayList) queryList;

                // Sorted ArrayList
                frenchSortedqueryList = this.sort(listTemp, Constants.FRENCH_CANADIAN_LOCALE);
                englishSortedqueryList = this.sort(listTemp, Constants.ENGLISH_CANADIAN_LOCALE);

                // Sorted SelectItem array
                SelectItem frenchSelectItemTemp[] = new SelectItem[frenchSortedqueryList.size() + 1];
                SelectItem englishSelectItemTemp[] = new SelectItem[englishSortedqueryList.size() + 1];

                englishSelectItemTemp[0] = new SelectItem(new Integer(0), "");
                frenchSelectItemTemp[0] = new SelectItem(new Integer(0), "");

                for (int i = 0; i < queryList.size(); i++) {
                    englishSelectItemTemp[i+1] = new SelectItem(((ProgramBean) queryList.get(i)).getProgramId(), ((ProgramBean) queryList.get(i)).getNameEnglish());

                    frenchSelectItemTemp[i+1] = new SelectItem(((ProgramBean) queryList.get(i)).getProgramId(),
                            ((ProgramBean) queryList.get(i)).
                            getNameFrench());
                }

                englishSelectItem = englishSelectItemTemp;
                frenchSelectItem = frenchSelectItemTemp;
            }
        } catch (HibernateException ex) {
            ex.printStackTrace();
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
        } finally {
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    // English comparator
    public static final Comparator nameEnglishOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            ProgramBean objComp1 = (ProgramBean) o1;
            ProgramBean objComp2 = (ProgramBean) o2;
            return myCollator.compare(objComp1.getNameEnglish(),
                                      objComp2.getNameEnglish());
        }
    };

    // French comparator
    public static final Comparator nameFrenchOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA_FRENCH);
            ProgramBean objComp1 = (ProgramBean) o1;
            ProgramBean objComp2 = (ProgramBean) o2;
            return myCollator.compare(objComp1.getNameFrench(),
                                      objComp2.getNameFrench());
        }
    };

    // Return complete list of program as SelectItem object
    public SelectItem[] getSelectItem(String language) {
        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            return this.frenchSelectItem;
        } else {
            return this.englishSelectItem;
        }
    }

    // Return complete list of program as ArrayList object
    public ArrayList getList(String language) {
        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            return (ArrayList)this.frenchSortedqueryList;
        } else {
            return (ArrayList)this.englishSortedqueryList;
        }
    }

    // Return partial list of program as SelectItem object
    public SelectItem[] getSelectItem(String language, int[] programId) {

        // Get ArrayList
        ArrayList listTemp = this.getList(language, programId);

        // Temporary repository for SelectItem objects
        SelectItem selectItemTemp[] = new SelectItem[listTemp.size() + 1];

        // Add blank entry
        selectItemTemp[0] = new SelectItem(new Integer(0), "");

        // Load ArrayList into SelectItem array
        for (int i = 0; i < listTemp.size(); i++) {
            if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
                selectItemTemp[i+1] = new SelectItem(((ProgramBean) listTemp.get(i)).getProgramId(), ((ProgramBean) listTemp.get(i)).getNameFrench());
            } else {
                selectItemTemp[i+1] = new SelectItem(((ProgramBean) queryList.get(i)).getProgramId(), ((ProgramBean) listTemp.get(i)).getNameEnglish());
            }
        }

        return selectItemTemp;
    }

    // Return partial list of program as ArrayList object
    public ArrayList getList(String language, int[] programId) {
        ArrayList listTemp = new ArrayList();
        int k = 0;

        // Main loop - full list
        for (int i = 0; i < queryList.size(); ++i) {
            // Secondary loop - program id list to get from full list
            for (int j = 0; j < programId.length; j++) {
                if (((ProgramBean) queryList.get(i)).getProgramId().intValue() == programId[j]) {
                    listTemp.add(queryList.get(i));
                    k++;
                }
            }
        }

        if (k > 1) {
            return this.sort(listTemp, language);
        } else {
            return listTemp;
        }
    }

    // Returns a sorted ArrayList object
    private ArrayList sort(ArrayList list, String language) {
        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Sorting Programs - " + language);
        }

        // Keep the original List. Use a copy for sorting
        ArrayList listTemp;
        listTemp = list;

        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            Collections.sort(listTemp, nameFrenchOrder);
        } else {
            Collections.sort(listTemp, nameEnglishOrder);
        }
        return listTemp;
    }
}
