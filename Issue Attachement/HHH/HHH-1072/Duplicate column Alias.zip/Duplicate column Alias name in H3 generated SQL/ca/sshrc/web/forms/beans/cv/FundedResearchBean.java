package ca.sshrc.web.forms.beans.cv;

import java.lang.reflect.*;
import java.util.*;

import javax.faces.component.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.*;
import hibernate.*;
import org.hibernate.*;
import org.apache.commons.beanutils.*;
import org.apache.log4j.*;

public class FundedResearchBean extends BeanBase {
    private Logger logger = Logger.getLogger(FundedResearchBean.class.getName());
    private ArrayList dataRowList = new ArrayList();
    private UIData dataTable = null;

    public FundedResearchBean() {
        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("FundedResearchBean.constructor");
        }
        /**
         * Only retrieve the data if the current phase is Render Response phase.
         * (There's no need to retrieve during the Restore View phase).
         * */
        if (this.getFacesContext().getRenderResponse()) {

            try {
                // Get a session
                Session session = HibernateUtil.getSession();
                HibernateUtil.beginTransaction();

                // Call this object's retrieve method
                this.retrieve(new Long(0), session);

            } catch (Exception ex) {
                HibernateUtil.closeSession();
                ex.printStackTrace();
            } finally {
                // Close the Hibernate connection
                try {
                    HibernateUtil.commitTransaction();
                    HibernateUtil.closeSession();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } else {
            // On her way back from the browser
            // Fill up FundedResearchBean with FundedResearchDataBean (8 per page)
            for (int i = 0; i < 8; i++) {
                dataRowList.add(new FundedResearchDataBean());
            }
        }
    }

    public UIData getDataTable() {
        return dataTable;
    }

    public void setDataTable(UIData table) {
        this.dataTable = table;
    }

    public void setDataRows(ArrayList dataRows) {
        this.dataRowList = dataRows;
    }

    public ArrayList getDataRows() {
        return dataRowList;
    }

    // Overwrite ancestor method
    public void retrieve(Session session) {
        retrieve(new Long(0), session);
    }

    /**
     * retrieve
     *
     * @param formId Long
     */
    public void retrieve(Long formId, Session session) {
        List queryList;
        logger.info("FundedResearchBean.retrieve passed parameter is formId : " + formId);

        if (null == session) {
            if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                logger.error("Cannot load FundedResearchBean - Session is null");
                return;
            }
        }

        // If the passed form_id is 0, get the form_id from the NavigationBean
        if (formId.longValue() == 0) {
            formId = new Long(getNavigationBean().getForm_id());
            if (formId.longValue() == 0) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.error("Cannot load FundedResearchBean - no FormId : " + formId);
                    return;
                }
            } else {
                logger.info("FundedResearchBean.retrieve using navigationBean FormId : " + formId);
            }

        } else {
            logger.info("FundedResearchBean.retrieve using passed parm FormId : " + formId);
        }

        //Let's retrieve the data from the DB
        try {
            logger.info("In FundedResearchBean.retrieve()");

            /*  Original query from PB     SELECT  PERSON_RESEARCH_SUPPORT.Ext_Support_ID ,
                                           PERSON_RESEARCH_SUPPORT.CID ,
                                           PERSON_RESEARCH_SUPPORT.Competition_Year ,
                                           PERSON_RESEARCH_SUPPORT.Funding_Org_ID ,
                                           PERSON_RESEARCH_SUPPORT.Org_Name ,
                                           PERSON_RESEARCH_SUPPORT.External_Appl_Title ,
                                           PERSON_RESEARCH_SUPPORT.Completion_Status_Code ,
                                           PERSON_RESEARCH_SUPPORT.Role_Code ,
                                           PERSON_RESEARCH_SUPPORT.Grant_Amount ,
                                           PERSON_RESEARCH_SUPPORT.Applicant_Family_Name ,
                                           PERSON_RESEARCH_SUPPORT.Applicant_First_Name ,
                                           PERSON_RESEARCH_SUPPORT.Applicant_Initials ,
                                           PERSON_RESEARCH_SUPPORT.Change_Date ,
                                           ORGANIZATION.Name_English ,
                                           ORGANIZATION.Name_French
                                        FROM PERSON_RESEARCH_SUPPORT ,
                                           ORGANIZATION
                    WHERE ( PERSON_RESEARCH_SUPPORT.Funding_Org_ID *= ORGANIZATION.Org_ID) and          ( ( PERSON_RESEARCH_SUPPORT.CID = :al_cid ) )*/

            queryList = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.cv.FundedResearchDataBean(Form.formId, PersonResearchSupport.extSupportId, " +
                    "PersonResearchSupport.cid, " +
                    "PersonResearchSupport.competitionYear, " +
                    "PersonResearchSupport.fundingOrganization, " +
                    "Organization.nameFrench, " +
                    "Organization.nameEnglish, " +
                    "PersonResearchSupport.orgName, " +
                    "PersonResearchSupport.applId, " +
                    "PersonResearchSupport.resultOfSshrcInd, " +
                    "PersonResearchSupport.externalApplTitle, " +
                    "PersonResearchSupport.externalProgramName, " +
                    "PersonResearchSupport.completionStatusCode, " +
                    "PersonResearchSupport.resultNote, " +
                    "PersonResearchSupport.roleCode, " +
                    "PersonResearchSupport.grantAmount, " +
                    "PersonResearchSupport.applicantFamilyName, " +
                    "PersonResearchSupport.applicantFirstName, " +
                    "PersonResearchSupport.applicantInitials, " +
                    "PersonResearchSupport.createUserId, " +
                    "PersonResearchSupport.createDate, " +
                    "PersonResearchSupport.changeUserId, " +
                    "PersonResearchSupport.changeDate) " +
                    "from Form Form join Form.person as person " +
                    "join fetch person.personResearchSupport as PersonResearchSupport " +
                    "left join fetch PersonResearchSupport.fundingOrganization as Organization " +
                    "where (Form.formId = :formId) " +
                    "order by PersonResearchSupport.competitionYear DESC, PersonResearchSupport.externalApplTitle ASC")
                        .setParameter("formId", formId)
                        .list();

/*                    "from PersonResearchSupport PersonResearchSupport, " +
                    "Form Form, " +
                    "Organization Organization " +
                    "where (Form.formId = :formId) and " +
                    "(PersonResearchSupport.cid = Form.cid) and " +
                    "(PersonResearchSupport.fundingOrgId *= Organization.orgId) " +
                    "order by PersonResearchSupport.competitionYear DESC, PersonResearchSupport.externalApplTitle ASC")
                        .setParameter("formId", formId)
                        .list();*/

            logger.info("FundedResearchBean.retrieve - number of rows retrieved = " + queryList.size());

            this.dataRowList = new ArrayList(queryList);
            if (queryList.size() < 8) {

                // Fill up dataRowList with FundedResearchDataBean ( 8 per page)
                for (int i = queryList.size(); i < 8; i++) {
                    dataRowList.add(new FundedResearchDataBean());
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    /**
     * save
     *
     * @param session Session
     * @return String
     */
    public String save(Session session) throws HibernateException, InvocationTargetException,
            IllegalAccessException {

        Integer cid = null;

        List queryList;
        boolean hasData = true;
        boolean isChangeDateRefreshRequired = false;
        boolean isKeyFound = false; // Tells if the web row was found in the DB table
        String saveOutcome = Constants.SUCCESS_OUTCOME; // Defaults to success

        int nDataRowList = dataRowList.size();
        int nQueryList;

        // Get Cid from logonBean
        cid = this.getLogonBean().getWeb_id();

        logger.info("In FundedResearchBean.save()");
        logger.info("We have " + nDataRowList + " beans in dataRowList");

        HibernateUtil.beginTransaction();

        queryList = session.createQuery("from PersonResearchSupport " +
                                        "where cid = :cid")
                    .setParameter("cid", cid)
                    .list();

        nQueryList = queryList.size();

        logger.info(
                "In PersonResearchSupport.save() - Retrieved hibernate.PersonResearchSupport object for cid: " +
                cid);

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Loaded hibernate.PersonResearchSupport objects : " + queryList.size());
        }

        if (nDataRowList > 0) {
            // Set values
            for (int i = 0; i < nDataRowList; i++) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("Saving dataRowList : " + i);
                }

                // Set hasData flag - Does the bean have data
                hasData = !((FundedResearchDataBean)this.dataRowList.get(i)).isEmpty();

                // Check that this is an existing record using the row's key
                if (((FundedResearchDataBean)this.dataRowList.get(i)).getExtSupportId() == null) {
                    logger.info("this is a new record");
                    // there is no record, copy the bean and save.
                    // Save only if the bean has data

                    isKeyFound = true; // Tells if the web row was found in the DB table
                    if (hasData) {
                        // Add new PersonResearchSupport bean to current query result list
                        queryList.add(new PersonResearchSupport());

                        // Transfer data from web bean to hibernate bean
                        try {
                            PropertyUtils.copyProperties((PersonResearchSupport) queryList.get(queryList.size() -
                                    1),
                                    (FundedResearchDataBean)this.dataRowList.get(i));

                            // Add the CID of the new created hibernate object
                            ((PersonResearchSupport) queryList.get(queryList.size() - 1)).setCid(cid);

                        } catch (Exception ex1) {
                            ex1.printStackTrace();
                            saveOutcome = Constants.UPDATE_ERROR_OUTCOME;
                        }

                        // Update DB
                        session.saveOrUpdate((PersonResearchSupport) queryList.get(queryList.size() - 1));
                        session.flush();

                        // Turn changeDate flag ON
                        isChangeDateRefreshRequired = true;

                        session.refresh((PersonResearchSupport) queryList.get(queryList.size() - 1));

                        // Copy DB values back to bean object
                        try {
                            PropertyUtils.copyProperties((FundedResearchDataBean)this.dataRowList.get(i),
                                    (PersonResearchSupport) queryList.get(queryList.size() - 1));
                        } catch (Exception ex1) {
                            ex1.printStackTrace();
                            saveOutcome = Constants.UPDATE_ERROR_OUTCOME;
                        }
                    }

                    // this is an existing record. Locate the matching one in the database
                } else {
                    for (int j = 0; j < nQueryList; j++) {
                        // Does this hibernate bean match the web bean?
                        if (((PersonResearchSupport) queryList.get(j)).getExtSupportId().equals(
                                ((FundedResearchDataBean)this.dataRowList.get(i)).getExtSupportId())) {

                            isKeyFound = true; // Tells if the web row was found in the DB table
                            // this is the correct record, update and save
                            if (hasData) {
                                if (((FundedResearchDataBean)this.dataRowList.get(i)).isDelete()) {
                                    System.out.println("Deleting: " +
                                            ((FundedResearchDataBean)this.dataRowList.get(i)).getExtSupportId());
                                    // Update DB
                                    session.delete((PersonResearchSupport) queryList.get(j));
                                    session.flush();
                                }
                                if (!isStaleData(((PersonResearchSupport) queryList.get(j)).getChangeDate(),
                                                 ((FundedResearchDataBean)this.dataRowList.get(i)).
                                                 getChangeDate())) {

                                    // Transfer data from web bean to hibernate bean
                                    try {
                                        BeanUtils.copyProperties((PersonResearchSupport) queryList.get(j),
                                                (FundedResearchDataBean)this.dataRowList.get(i));
                                    } catch (Exception ex) {
                                        ex.printStackTrace();
                                        saveOutcome = Constants.UPDATE_ERROR_OUTCOME;
                                    }

                                    // Update DB
                                    session.saveOrUpdate((PersonResearchSupport) queryList.get(j));
                                    session.flush();

                                    // Turn isChangeDateRefreshRequired flag ON
                                    isChangeDateRefreshRequired = true;
                                    break;
                                } else {
                                    logger.error("Stale data in PersonResearchSupport: " +
                                                 ((PersonResearchSupport) queryList.get(j)).getExtSupportId() +
                                                 " -  NOT Saving");

                                    saveOutcome = Constants.UPDATE_ERROR_OUTCOME;
                                    break;
                                }

                                // No more data in web bean, delete it.
                            } else {
                                session.delete((PersonResearchSupport) queryList.get(j));
                                session.flush();
                                this.dataRowList.remove(i);
                                break;
                            }
                        }
                        // Didn't find the key...
                        if (j == nQueryList - 1) {
                            isKeyFound = false; // Tells if the web row was found in the DB table
                        }
                    }
                }
                // If the web row was not found not in the DB table... exit the main loop and change outcome to UPDATE_ERROR_OUTCOME
                if (!isKeyFound) {
                    saveOutcome = Constants.UPDATE_ERROR_OUTCOME;
                    break;
                }
            }

            // Is a refresh of the changeDate required ?
            if (isChangeDateRefreshRequired && saveOutcome == Constants.SUCCESS_OUTCOME) {
                // Get the first row's changeDate (from hibernate object) and apply it to the other rows
                session.refresh((PersonResearchSupport) queryList.get(0));

                // Set the Web beans changeDates with the first hibernate PersonResearchSupport.getChangeDate value
                for (int i = 0; i < dataRowList.size(); i++) {
                    // Update the changeDate only if the key's not Null
                    if (((FundedResearchDataBean)this.dataRowList.get(i)).getExtSupportId() != null) {
                        ((FundedResearchDataBean)this.dataRowList.get(i)).setChangeDate(((
                                PersonResearchSupport)
                                queryList.get(0)).getChangeDate());
                    }
                }
            }
        }

        return saveOutcome;
    }

    public String validate(ValidationMessage validationMessage) throws HibernateException, Exception {
        Logger logger = Logger.getLogger(ExpertiseBean.class.getName());

        ResourceBundle moduleBundle = null;
//        ResourceBundle applicationBundle = null;
        ResourceBundle validationErrorBundle = null;

        Locale locale = null;

        String validationOutcome = Constants.SUCCESS_OUTCOME;
        String moduleDisplayName = null;
        String errorMessage = null;
        String valueString1;

        Short valueShort1;

        Integer subSystemId = null;
        Integer moduleId = null;
        Integer valueInteger1;

        Object tempForNullObject;

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("FundedResearchBean.validate - Start");
        }

        // If messageContainer is null, throw exception
        if (validationMessage == null) {
            throw new Exception("Invalid parameter. ValidationMessage object was null.");
        }

        subSystemId = this.getNavigationBean().getRequestedSubsystemId();
        moduleId = validationMessage.getModuleNavigationBarBean().getSequenceNumber();

        // Create Locale
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            locale = Locale.CANADA_FRENCH;
            moduleDisplayName = validationMessage.getModuleNavigationBarBean().getNameFrench();
        } else {
            locale = Locale.CANADA;
            moduleDisplayName = validationMessage.getModuleNavigationBarBean().getNameEnglish();
        }

        // Get resource bundles
        /*applicationBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                Constants.APPLICATION_RESOURCES, locale);*/
        validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                Constants.VALIDATION_ERROR_RESOURCES, locale);
        moduleBundle = ResourceBundle.getBundle(validationMessage.getResourceBundleName(), locale);

        /**
         *
         * Validate Funded research data
         *
         * */

        try {
            // Get a session
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // Call this object's retrieve method
            this.retrieve(new Long(0), session);

        } catch (Exception ex) {
            HibernateUtil.closeSession();
            ex.printStackTrace();
        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        // Set isEmpty property list to check - in this case on the table key property
        String[] propertyNamesForEmptiness = {"extSupportId"};

        for (int i = 0; i < this.dataRowList.size(); i++) {
            // If no data on
            if (((FundedResearchDataBean)this.dataRowList.get(i)).isEmpty(propertyNamesForEmptiness)) {

                // Only the last row(s) should be empty, therefore we end the validation as soon as we detect one
                break;
            } else {

                /**
                 * Funding organization codes and "Other" fields
                 *
                 */

                // check if they picked "other" in code field
                // Avoid NullPointerException
                tempForNullObject = PropertyUtils.getProperty(((FundedResearchDataBean)this.dataRowList.get(i)),
                        "fundingOrgId");
                if (tempForNullObject != null) {
                    valueInteger1 = (Integer) tempForNullObject;
                } else {
                    valueInteger1 = null;
                }

                tempForNullObject = PropertyUtils.getProperty(((FundedResearchDataBean)this.dataRowList.get(i)),
                        "orgName");
                if (tempForNullObject != null) {
                    valueString1 = (String) tempForNullObject;
                } else {
                    valueString1 = null;
                }

                // Org Id are mandatory
                if (valueInteger1 == null) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                    Object params[] = {moduleBundle.getString("fundingOrganization") + " " +
                                      validationErrorBundle.getString("errorEntryNumberLowerCase") + (i + 1)};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage,
                            params));
                } else {
                    if (valueInteger1 != null) {
                        // All code finishing by 99 must have a value entered in there corresponding other org name field.
                        if (valueInteger1.intValue() == 1) {
                            if (valueString1 == null || (valueString1.trim()).equals("")) {

                                // Add validation error message
                                errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                                Object params[] = {validationErrorBundle.getString("errorOther") +
                                                  moduleBundle.getString("fundingOrganization") + " " +
                                                  validationErrorBundle.getString("errorEntryNumberLowerCase") +
                                                  (i + 1)};
                                validationMessage.addMessage(subSystemId,
                                        moduleId,
                                        moduleDisplayName,
                                        validationMessage.substituteParams(locale, errorMessage, params));
                            }
                        }
                    }
                }

                // All other Org Name must have a value entered if there corresponding Org code equals 1.
                if (valueString1 != null) {
                    if (!(valueString1.trim()).equals("")) {
                        if (valueInteger1 == null || (valueString1.trim()).equals("") ||
                            valueInteger1.intValue() != 1) {

                            // Add validation error message
                            errorMessage = validationErrorBundle.getString("errorIfOther");
                            Object params[] = {moduleBundle.getString("fundingOrganization") + " " +
                                              validationErrorBundle.getString("errorEntryNumberLowerCase") +
                                              (i + 1),""};
                            validationMessage.addMessage(subSystemId,
                                    moduleId,
                                    moduleDisplayName,
                                    validationMessage.substituteParams(locale, errorMessage, params));
                        }
                    }
                }

                /**
                 * Validate year awarded (competitionYear attribute)
                 *
                 */
                tempForNullObject = PropertyUtils.getProperty(((FundedResearchDataBean)this.dataRowList.get(i)),
                        "competitionYear");
                if (tempForNullObject != null) {
                    valueShort1 = (Short) tempForNullObject;
                } else {
                    valueShort1 = null;
                }

                if (null == valueShort1 || (valueShort1.intValue() == 0)) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                    Object params[] = {moduleBundle.getString("yearAwarded") + " " +
                                      validationErrorBundle.getString("errorEntryNumberLowerCase") +
                                      (i + 1) +
                                      "."};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage,
                            params));
                }



                /**
                 * Validate completion status
                 *
                 */

                tempForNullObject = PropertyUtils.getProperty(((FundedResearchDataBean)this.dataRowList.get(i)),
                        "completionStatusCode");
                if (tempForNullObject != null) {
                    valueInteger1 = (Integer) tempForNullObject;
                } else {
                    valueInteger1 = null;
                }

                if (null == valueInteger1 || (valueInteger1.intValue() == 0)) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                    Object params[] = {moduleBundle.getString("completionStatus") + " " +
                                      validationErrorBundle.getString("errorEntryNumberLowerCase") +
                                      (i + 1)};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage,
                            params));
                }

                /**
                 * Validate Role
                 *
                 */

                tempForNullObject = PropertyUtils.getProperty(((FundedResearchDataBean)this.dataRowList.get(i)),
                        "roleCode");
                if (tempForNullObject != null) {
                    valueInteger1 = (Integer) tempForNullObject;
                } else {
                    valueInteger1 = null;
                }

                if (null == valueInteger1 || (valueInteger1.intValue() == 0)) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                    Object params[] = {moduleBundle.getString("role") + " " +
                                      validationErrorBundle.getString("errorEntryNumberLowerCase") +
                                      (i + 1)};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage,
                            params));
                }


                /**
                 * Validate project title
                 *
                 */

                tempForNullObject = PropertyUtils.getProperty(((FundedResearchDataBean)this.dataRowList.get(i)),
                        "externalApplTitle");
                if (tempForNullObject != null) {
                    valueString1 = (String) tempForNullObject;
                } else {
                    valueString1 = null;
                }

                if (valueString1 != null) {
                    if ((valueString1.trim()).equals("")) {
                            // Add validation error message
                            errorMessage = validationErrorBundle.getString("errorIfOther");
                            Object params[] = {moduleBundle.getString("projectTitle") + " " +
                                              validationErrorBundle.getString("errorEntryNumberLowerCase") +
                                              (i + 1),""};
                            validationMessage.addMessage(subSystemId,
                                    moduleId,
                                    moduleDisplayName,
                                    validationMessage.substituteParams(locale, errorMessage, params));
                    }
                }

            }
        } // End of i loop
        return validationOutcome;
    }
}
