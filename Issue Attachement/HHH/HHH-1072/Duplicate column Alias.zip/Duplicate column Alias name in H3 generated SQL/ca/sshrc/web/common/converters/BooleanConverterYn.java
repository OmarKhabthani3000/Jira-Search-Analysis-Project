package ca.sshrc.web.common.converters;

import javax.faces.component.*;
import javax.faces.context.*;
import javax.faces.convert.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public abstract class BooleanConverterYn implements Converter {

    public final static String CONVERTER_ID = "BooleanConverterYn";

    public Object getAsObject(FacesContext facesContext, UIComponent uIComponent, String string) {
        Boolean returnedBoolean = new Boolean(false);

        if (string.compareToIgnoreCase("y") == 0) {
            returnedBoolean = new Boolean(true);
        }
        return (Object) returnedBoolean;
    }

    public String getAsString(FacesContext facesContext, UIComponent uIComponent, Object value) throws
            ConverterException {
        String inputVal = null;
        String returnedString = "N";

        if (value == null) {
            return null;
        }

        try {
            inputVal = (String) value;
        } catch (ClassCastException ce) {
            throw new ConverterException(ce);
        }

        if (inputVal.equals(Boolean.TRUE)) {
            returnedString = "Y";
        }

        return returnedString;
    }

}
