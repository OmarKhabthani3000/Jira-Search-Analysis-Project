package ca.sshrc.web.lookupCache;


public class ProgramBean {
    private Integer programId;
    private String nameEnglish;
    private String nameFrench;


    /** default constructor */
    public ProgramBean() {
    }

    // Minimal constructor
    public ProgramBean(Integer programId, String nameEnglish, String nameFrench) {
        this.programId = programId;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
    }

    public Integer getProgramId() {
        return programId;
    }

    public String getNameEnglish() {
        return nameEnglish;
    }

    public String getNameFrench() {
        return nameFrench;
    }

    public void setProgramId(Integer programId) {
        this.programId = programId;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }
}
