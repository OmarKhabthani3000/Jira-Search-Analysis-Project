package ca.sshrc.web.lookupCache;

import java.io.*;
import java.text.*;
import java.util.*;

import ca.sshrc.web.common.services.*;
import org.hibernate.*;
import org.apache.log4j.*;
import ca.sshrc.web.common.util.Constants;

public class DepartmentCache implements Serializable {
    private Logger logger = Logger.getLogger(DepartmentCache.class.getName());
    private List queryList;

    public DepartmentCache() {
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In DepartmentCache");

            queryList = session.createQuery(
                    "select new ca.sshrc.web.lookupCache.DepartmentBean(OrgDeptLocation.orgDeptLocId, " +
                    "OrgDeptLocation.orgId, " +
                    "OrgDeptLocation.departmentNameEnglish, " +
                    "OrgDeptLocation.departmentNameFrench, " +
                    "Cod.code, " +
                    "Cod.shortNameEnglish, " +
                    "Cod.shortNameFrench, " +
                    "Organization.nameEnglish, " +
                    "Organization.nameFrench) " +
                    "from OrgDeptLocation OrgDeptLocation, " +
                    "Cod Cod, Organization Organization " +
                    "where OrgDeptLocation.locationId = Cod.code " +
                    "and Organization.orgId = OrgDeptLocation.orgId " +
                    "and (OrgDeptLocation.statusCode <> 63 and OrgDeptLocation.orgDeptLocId not in (1,3)) " +
                    "order by 2 asc, 1 asc").
                        list();

            /* Original PB SQL - dddw_department
             SELECT  ORG_DEPT_LOCATION.Org_Dept_Loc_ID ,
                                   ORG_DEPT_LOCATION.Org_ID ,
                                   ORG_DEPT_LOCATION.Department_Name_English ,
                                   ORG_DEPT_LOCATION.Department_Name_French ,
                                   CODES.Short_Name_English ,
                                   CODES.Short_Name_French ,
                                   ORGANIZATION.Name_English ,
                                   ORGANIZATION.Name_French ,
                                   CODES.Code
                                FROM ORG_DEPT_LOCATION ,
                                   CODES ,
                                   ORGANIZATION
                                WHERE ( ORG_DEPT_LOCATION.Location_ID = CODES.Code ) and
                                      ( ORGANIZATION.Org_ID = ORG_DEPT_LOCATION.Org_ID ) and
                                      ( ( ORG_DEPT_LOCATION.Status_Code <> 63 ) and
                                      ( ORG_DEPT_LOCATION.Org_Dept_Loc_ID not in ( 1,3 ) ) )  */


            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Department loaded: " + queryList.size());
            }

        } catch (HibernateException ex) {
            ex.printStackTrace();
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
        } finally {
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public static final Comparator nameEnglishOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            DepartmentBean objComp1 = (DepartmentBean) o1;
            DepartmentBean objComp2 = (DepartmentBean) o2;
            return myCollator.compare(objComp1.getDepartmentNameEnglish(),
                                      objComp2.getDepartmentNameEnglish());
        }
    };

    public static final Comparator nameFrenchOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA_FRENCH);
            DepartmentBean objComp1 = (DepartmentBean) o1;
            DepartmentBean objComp2 = (DepartmentBean) o2;
            return myCollator.compare(objComp1.getDepartmentNameFrench(),
                                      objComp2.getDepartmentNameFrench());
        }
    };
    public ArrayList getList(String language) {
        // Keep the original array. Use a copy for sorting
        ArrayList listTemp;
        listTemp = (ArrayList) queryList;

        return this.sort(listTemp, language);
    }

    public ArrayList getList(String language, int orgId) {
        ArrayList listTemp = new ArrayList();
        int found = 0;

        for (int i = 0; i < queryList.size(); ++i) {
            DepartmentBean departmentBean = (DepartmentBean) queryList.get(i);
            // Look for passed org id or Other department (getOrgDeptLocId = 2)
            if ((orgId == departmentBean.getOrgId()) || (departmentBean.getOrgDeptLocId() == 2)) {
                found++;
                listTemp.add(departmentBean);
            } else if (found > 1) {
                // queryList is sorted by orgId + org dept loc id
                // therefore, we stop the loop as soon as we find a non matching
                // pair (after we found at least one pair)
                break;
            }
        }

        if (found > 1) {
            return this.sort(listTemp, language);
        } else {
            return listTemp;
        }
    }

    private ArrayList sort(ArrayList list, String language) {
        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Sorting Departments - " + language);
        }

        // Keep the original List. Use a copy for sorting
        ArrayList listTemp;
        listTemp = list;

        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            Collections.sort(listTemp, nameFrenchOrder);
        } else {
            Collections.sort(listTemp, nameEnglishOrder);
        }
        return listTemp;
    }
}
