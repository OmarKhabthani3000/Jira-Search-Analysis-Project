package ca.sshrc.web.lookupCache;

import java.io.*;
import java.text.*;
import java.util.*;

import org.hibernate.*;
import org.apache.log4j.*;
import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.util.Constants;
import hibernate.Organization;

public class OrganizationCache implements Serializable {
    private Logger logger = Logger.getLogger(OrganizationCache.class.getName());
    private List queryList;

    public OrganizationCache() {
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In OrganizationCache");

            queryList = session.createQuery(
                    "select new ca.sshrc.web.lookupCache.OrganizationBean( Organization.orgId, " +
                    "Organization.orgCategoryCode, " +
                    "Organization.country.countryCode, " +
                    "Organization.provinceStateCode, " +
                    "Organization.nameEnglish, " +
                    "Organization.nameFrench, " +
                    "Organization.country.nameEnglish, " +
                    "Organization.country.nameFrench) " +
                    "from Organization as Organization left outer join " +
                    "Organization.country " +
                    "where Organization.orgStatusCode != 63 order by 3 asc, 4 asc").list();

            /**
             * Example from Hibernate forum
             * select course from Course as course join course.groups as group join group.events as groupEvent where groupEvent.eventReleased = 1
             **/

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded organizations : " + queryList.size());
            }
        } catch (Exception e) {
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
            e.printStackTrace();
        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public static final Comparator nameEnglishOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            OrganizationBean objComp1 = (OrganizationBean) o1;
            OrganizationBean objComp2 = (OrganizationBean) o2;
            return myCollator.compare(objComp1.getNameEnglish(), objComp2.getNameEnglish());
        }
    };

    public static final Comparator nameFrenchOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA_FRENCH);
            OrganizationBean objComp1 = (OrganizationBean) o1;
            OrganizationBean objComp2 = (OrganizationBean) o2;
            return myCollator.compare(objComp1.getNameFrench(), objComp2.getNameFrench());
        }
    };
    public ArrayList getList(String language) {
        return this.sort(new ArrayList(queryList), language);
    }

    public ArrayList getList(String language, Integer countryCode, String provinceStateCode) {
        ArrayList listTemp = new ArrayList();
        int orgFound = 0;

        /**
         * This method could be called with a null provinceStateCode. If it is, transfer the call to
         * this.getList(String language, Integer countryCode)
         */

        if ((null == provinceStateCode) || (provinceStateCode.length() == 0)) {
            listTemp = this.getList(language, countryCode);
        } else {

            for (int i = 0; i < queryList.size(); ++i) {
                OrganizationBean organizationBean = (OrganizationBean) queryList.get(i);
                if ((countryCode.equals(organizationBean.getCountryCode())) &&
                    (provinceStateCode.equalsIgnoreCase(organizationBean.getProvinceStateCode()))) {
                    orgFound++;
                    listTemp.add(organizationBean);
                } else if (orgFound > 0) {
                    // queryList is sorted by country code + provincestatecode
                    // therefore, we stop the loop as soon as we find a non matching
                    // pair (after we found at least one pair)
                    break;
                }
            }
        }

        if (orgFound > 1) {
            return this.sort(listTemp, language);
        } else {
            return listTemp;
        }
    }

    public ArrayList getList(String language, Integer countryCode) {
        ArrayList listTemp = new ArrayList();
        int orgFound = 0;

        for (int i = 0; i < queryList.size(); ++i) {
            OrganizationBean organizationBean = (OrganizationBean) queryList.get(i);
            if (countryCode.equals(organizationBean.getCountryCode())) {
                orgFound++;
                listTemp.add(organizationBean);
            } else if (orgFound > 0) {
                // queryList is sorted by country code + provincestatecode
                // therefore, we stop the loop as soon as we find a non matching
                // pair (after we found at least one pair)
                break;
            }
        }

        if (orgFound > 1) {
            return this.sort(listTemp, language);
        } else {
            return listTemp;
        }
    }

    private ArrayList sort(ArrayList list, String language) {
        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Sorting organizations - " + language);
        }

        // Keep the original List. Use a copy for sorting
        ArrayList listTemp;
        listTemp = list;

        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            Collections.sort(listTemp, nameFrenchOrder);
        } else {
            Collections.sort(listTemp, nameEnglishOrder);
        }
        return listTemp;
    }
}
