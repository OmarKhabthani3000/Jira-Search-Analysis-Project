/*
 * CacheInit.java
 *
 * Generated on Fri Aug 08 13:07:42 EDT 2003
 *
 * Initialize cache objects.
 * Each cache object have to be added here for it to be available elsewhere.
 */

package ca.sshrc.web.common.services;

import javax.servlet.http.*;

import ca.sshrc.web.lookupCache.*;
import org.apache.log4j.*;
import ca.sshrc.web.common.util.Constants;
import java.util.ArrayList;

public class CacheInit extends HttpServlet {
    public CacheInit() {
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static Logger logger = Logger.getLogger(CacheInit.class.getName());

    /**
     * WARNING: If the constructor of one of the objects below doesn't execute successfully,
     * the INIT() method is not called and the caches are not loaded in memory.
     *
     * There's no error messages on the console even if there's a TRY-CATCH in the object's constructor.
     *
     * If the SystemPropertyCache is not loaded in the lookUp cache, the logon process won't execute properly.
     */
    private TestDBAHibernate testDBAHibernate = new TestDBAHibernate();
    private ArrayList testList = new ArrayList(testDBAHibernate.TestDBAHibernate(new Long(5017777).longValue()));


    private SystemPropertyCache systemPropertyCache = new SystemPropertyCache();
    private OrganizationCache orgCache = new OrganizationCache();
    private ProvinceCache provCache = new ProvinceCache();
    private StateCache stateCache = new StateCache();
    private MenuCache menuCache = new MenuCache();
    private WebSubSystemCache webSubSystemCache = new WebSubSystemCache();
    private CodesDescCache codesGender = new CodesDescCache(new Integer(90),"L","A","D",false); // code, (L)ong/(S)hort desc, (A)sc/(d)esc, sort by (D)escription/(S)equence number, true/false add blank entry
    private CodesDescCache codesSalutation = new CodesDescCache(new Integer(78),"S","A","S",true);  // code, (L)ong/(S)hort desc, (A)sc/(d)esc, sort by (D)escription/(S)equence number, true/false add blank entry
    private CountryCache countryCache = new CountryCache();
    private OrganizationCountryCache orgCountryCache = new OrganizationCountryCache();
    private DepartmentCache departmentCache = new DepartmentCache();
    private DisciplineCache disciplineCache = new DisciplineCache();
    private CodesDescCache codesPosition = new CodesDescCache(new Integer(74),"S","A","S",false);  // code, (L)ong/(S)hort desc, (A)sc/(d)esc, sort by (D)escription/(S)equence number, true/false add blank entry
    private CodesDescCache codesDegreeType = new CodesDescCache(new Integer(102),"L","A","S",true);  // code, (L)ong/(S)hort desc, (A)sc/(d)esc, sort by (D)escription/(S)equence number, true/false add blank entry
    private CodesDescCache codesAreaOfResearch = new CodesDescCache(new Integer(76),"L","A","D",false);  // code, (L)ong/(S)hort desc, (A)sc/(d)esc, sort by (D)escription/(S)equence number, true/false add blank entry
    private CodesDescCache codesGeographicRegion = new CodesDescCache(new Integer(72),"S","A","S",false);  // code, (L)ong/(S)hort desc, (A)sc/(d)esc, sort by (D)escription/(S)equence number, true/false add blank entry
    private CodesDescTableCache codesDistinctionType = new CodesDescTableCache(new Integer(18),"S","A","S",true);  // code, (L)ong/(S)hort desc, (A)sc/(d)esc, sort by (D)escription/(S)equence number, true/false add blank entry
    private FundingOrganizationCache fundingOrganizationCache = new FundingOrganizationCache();
    private CodesDescCache codesCompletionStatus = new CodesDescCache(new Integer(104),"S","A","S",true);  // code, (L)ong/(S)hort desc, (A)sc/(d)esc, sort by (D)escription/(S)equence number, true/false add blank entry
    private CodesDescCache codesPersonRole = new CodesDescCache(new Integer(105),"S","A","S",true);  // code, (L)ong/(S)hort desc, (A)sc/(d)esc, sort by (D)escription/(S)equence number, true/false add blank entry
    private CommitteeCache committeeCache = new CommitteeCache();
    private SupplementsCache supplementsCache = new SupplementsCache();
    private CodesDescCache codesScholarshipType = new CodesDescCache(new Integer(79),"L","A","S",true);  // code, (L)ong/(S)hort desc, (A)sc/(d)esc, sort by (D)escription/(S)equence number, true/false add blank entry
    private CodesDescCache codesActivityType = new CodesDescCache(new Integer(95),"L","A","D",false);  // code, (L)ong/(S)hort desc, (A)sc/(d)esc, sort by (D)escription/(S)equence number, true/false add blank entry
    private CodesDescCache codesGeographicalScope = new CodesDescCache(new Integer(94),"L","A","D",true);  // code, (L)ong/(S)hort desc, (A)sc/(d)esc, sort by (D)escription/(S)equence number, true/false add blank entry
    private ProgramCache programCache = new ProgramCache();
    private CodesDescCache codesParticipantRole = new CodesDescCache(new Integer(71),"S","A","S",false);  // code, (L)ong/(S)hort desc, (A)sc/(d)esc, sort by (D)escription/(S)equence number, true/false add blank entry
    private ThemeCache themeCache = new ThemeCache();
    private SubThemeCache subThemeCache = new SubThemeCache();

    public void init() {

        try {
            CacheService lookupCacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            lookupCacheManager.put("SystemPropertyCache", systemPropertyCache);
            lookupCacheManager.put("OrganizationCache", orgCache);
            lookupCacheManager.put("ProvinceCache", provCache);
            lookupCacheManager.put("StateCache", stateCache);
            lookupCacheManager.put("GenderCache", codesGender);
            lookupCacheManager.put("SalutationCache", codesSalutation);
            lookupCacheManager.put("CountryCache", countryCache);
            lookupCacheManager.put("OrganizationCountryCache", orgCountryCache);
            lookupCacheManager.put("DepartmentCache", departmentCache);
            lookupCacheManager.put("PositionCache", codesPosition);
            lookupCacheManager.put("degreeTypeCache", codesDegreeType);
            lookupCacheManager.put("AreaOfResearchCache", codesAreaOfResearch);
            lookupCacheManager.put("GeographicRegionCache", codesGeographicRegion);
            lookupCacheManager.put("DisciplineCache", disciplineCache);
            lookupCacheManager.put("DistinctionType",codesDistinctionType);
            lookupCacheManager.put("FundingOrganizationCache", fundingOrganizationCache);
            lookupCacheManager.put("CompletionStatus", codesCompletionStatus);
            lookupCacheManager.put("PersonRole", codesPersonRole);
            lookupCacheManager.put("CommitteeCache", committeeCache);
            lookupCacheManager.put("SupplementsCache", supplementsCache);
            lookupCacheManager.put("CodesScholarshipTypeCache", codesScholarshipType);
            lookupCacheManager.put("CodesActivityTypeCache", codesActivityType);
            lookupCacheManager.put("codesGeographicalScopeCache", codesGeographicalScope);
            lookupCacheManager.put("ProgramCache", programCache);
            lookupCacheManager.put("ParticipantRoleCache", codesParticipantRole);
            lookupCacheManager.put("ThemeCache", themeCache);
            lookupCacheManager.put("SubThemeCache", subThemeCache);

            CacheService systemCacheCacheManager = CacheService.getInstance(Constants.SYSTEM_CACHE_MANAGER);
            systemCacheCacheManager.put("MenuCache", menuCache);
            systemCacheCacheManager.put("WebSubSystemCache", webSubSystemCache);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void doGet(HttpServletRequest req, HttpServletResponse res) {
    }

    private void jbInit() throws Exception {
    }
}
