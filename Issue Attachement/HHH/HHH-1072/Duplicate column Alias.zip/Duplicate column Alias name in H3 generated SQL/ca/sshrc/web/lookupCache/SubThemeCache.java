package ca.sshrc.web.lookupCache;

import java.io.*;
import java.text.*;
import java.util.*;

import javax.faces.context.*;
import javax.faces.model.*;
import javax.servlet.http.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.util.*;
import org.apache.log4j.*;
import org.hibernate.*;

public class SubThemeCache implements Serializable {
    private Logger logger = Logger.getLogger(SubThemeCache.class.getName());
    List queryList = null;

    public SubThemeCache() {

        /**
         * Integer subGroup:         Sub group number to be used for the retrieval.
         * String descType:          Specifies which code's description will be returned by the getList method.
         *                           Should be (s)hort description) or (l)ong description.
         * String sortOrder:         Specifies if the list returned by getList method will be sorted (A)scending or (D)escending.
         * String sortBy:            Specifies if the list returned by getList method will be sorted on the (s)equence number or the (d)escription.
         * boolean insertBlankEntry: Specifies weather to add a blank entry in list first position or not
         */


        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In ThemeCache");

            queryList = session.createQuery("select new ca.sshrc.web.lookupCache.CodesDescBean(Codes.code, " +
                                            "Codes.codeType, " +
                                            "Codes.nameEnglish, " +
                                            "Codes.nameFrench, " +
                                            "Codes.shortNameEnglish, " +
                                            "Codes.shortNameFrench, " +
                                            "Codes.sequenceNumber, " +
                                            "CodesCategory.sequenceNumber, " +
                                            "CodesCategory.comp_id.subGroup) " +
                                            "from Cod Codes, " +
                                            "CodesCategory CodesCategory " +
                                            "where (Codes.code = CodesCategory.comp_id.codByCode) and " +
                                            "((CodesCategory.comp_id.subGroup in (86,87)) and " +
                                            "(Codes.activeInd = 'Y')) " +
                                            "order by 9 Asc, 1 Asc")
                        .list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("ThemeCache loaded: " + queryList.size());
            }

        } catch (HibernateException ex) {
            ex.printStackTrace();
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
        } finally {
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    // Collator - Sort English desc. Ascending
    private static final Comparator shortNameEnglishOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp1.getShortNameEnglish(), objComp2.getShortNameEnglish());
        }
    };

    // Collator - Sort French desc. Ascending
    private static final Comparator shortNameFrenchOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA_FRENCH);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp1.getShortNameFrench(), objComp2.getShortNameFrench());
        }
    };

    public ArrayList getList(String language, Integer webSubsystemId) {
        ArrayList listTemp = new ArrayList();
        int found = 0;
        int subGroup = 0;

        // Based on passed subsystem id, set the subgroup rows to be returned
        switch (webSubsystemId.intValue()) {
        case 65: //  INE Skills
            subGroup = 86;
            break;
        default:
            subGroup = 87;
        }

        for (int i = 0; i < queryList.size(); ++i) {
            CodesDescBean codesDescBean = (CodesDescBean) queryList.get(i);
            // Look for passed program id)
            if (subGroup == codesDescBean.getSubGroup().intValue()) {
                found++;
                listTemp.add(codesDescBean);
            } else if (found > 1) {

                // queryList is sorted by subGroup
                // therefore, we stop the loop as soon as we find a non matching
                // pair (after we found at least one pair)
                break;
            }
        }

        // Trim arrayList
        listTemp.trimToSize();

        // Sort only if more then 1 item
        if (found > 1) {
            return this.sort(listTemp, language);
        } else {
            return listTemp;
        }
    }

    private ArrayList sort(ArrayList list, String language) {
        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Sorting Themes - " + language);
        }

        // Keep the original List. Use a copy for sorting
        ArrayList listTemp;
        listTemp = list;

        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            Collections.sort(listTemp, shortNameFrenchOrderAsc);
        } else {
            Collections.sort(listTemp, shortNameEnglishOrderAsc);
        }
        return listTemp;
    }

    public SelectItem[] getSelectItem(String language) {
        ArrayList listTemp = new ArrayList();

        // Need NavigationBean to get the current subsystem
        NavigationBean navigationBean = (NavigationBean) ((HttpServletRequest) (HttpServletRequest)
                FacesContext.getCurrentInstance().getExternalContext().getRequest()).getSession(false).
                                        getAttribute("navigationBean");

        // Get the current subsystem
        listTemp = this.getList(language, navigationBean.getCurrentSubsystemId());

        // Instantiate a SelectItem object in which we'll load the list
        SelectItem selectItemTemp[] = new SelectItem[listTemp.size() + 1];

        // Add a blank entry in first position
        selectItemTemp[0] = new SelectItem(new Integer(0), "");

        // Loop thru the list and add items to SeletItem object
        for (int i = 0; i < listTemp.size(); i++) {
            if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
                selectItemTemp[i + 1] = new SelectItem(((CodesDescBean) listTemp.get(i)).
                        getCode(),
                        ((CodesDescBean) listTemp.get(i)).
                        getShortNameFrench());
            } else {
                selectItemTemp[i + 1] = new SelectItem(((CodesDescBean) listTemp.get(i)).
                        getCode(),
                        ((CodesDescBean) listTemp.get(i)).
                        getShortNameEnglish());
            }
        }

        return selectItemTemp;
    }

}
