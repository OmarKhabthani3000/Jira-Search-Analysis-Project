package ca.sshrc.web.common.services;

import java.util.*;

import ca.sshrc.web.common.util.*;
import hibernate.*;
import org.hibernate.*;
import org.apache.log4j.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class CommonDBA {
    private Logger logger = Logger.getLogger(CommonDBA.class.getName());

    public CommonDBA() {
    }

    public ArrayList queryModuleBeanClass(Integer subSystemId, String moduleName) {
        ArrayList moduleBeanClassList = new ArrayList(0);

        try {
            logger.info("In CommonDBA.queryModuleBeanClass()");
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // Query must not be case sensitive, convert moduleName to lower case
            moduleName = moduleName.toLowerCase();

            // WebModuleBeanClass is cached by Hibernate - settings in WebModuleBeanClass.hbm.xml (read-only)
            Query query = session.createQuery(
                    "select BeanClass from WebModuleBeanClass as BeanClass where BeanClass.comp_id.webSubsystem = :subSysId and lower(BeanClass.comp_id.moduleName) = :moduleName")
                          .setParameter("subSysId", subSystemId)
                          .setParameter("moduleName", moduleName);

            for (Iterator it = query.iterate(); it.hasNext(); ) {
                WebModuleBeanClass webModuleBeanClass = (WebModuleBeanClass) it.next();
                if (webModuleBeanClass != null) {
                    moduleBeanClassList.add(webModuleBeanClass);
                }
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("In CommonDBA.queryModuleBeanClass() - Bean class name found : " +
                                webModuleBeanClass.getComp_id().getBeanClassName());
                }
            }

            HibernateUtil.commitTransaction();

        } catch (HibernateException e) {
            e.printStackTrace();

        } finally {
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        return moduleBeanClassList;
    }


    public ArrayList queryModuleBeanClass(Integer subSystemId) {
        ArrayList moduleBeanClassList = new ArrayList(0);

        try {
            logger.info("In CommonDBA.queryModuleBeanClass()");
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // WebModuleBeanClass is cached by Hibernate - settings in WebModuleBeanClass.hbm.xml (read-only)
            Query query = session.createQuery(
                    "select BeanClass from WebModuleBeanClass as BeanClass where BeanClass.comp_id.webSubsystem = :subSysId")
                          .setParameter("subSysId", subSystemId);

            // Load array with WebModuleBeanClass objects
            moduleBeanClassList = new ArrayList(query.list());

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("In CommonDBA.queryModuleBeanClass() - Number of Bean class name found : " +
                            moduleBeanClassList.size());
            }
            HibernateUtil.commitTransaction();

        } catch (HibernateException e) {
            e.printStackTrace();

        } finally {
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        return moduleBeanClassList;
    }


    /**
     * setFormStatus
     *
     * @param formId Long
     * @param status String
     * @param moduleName String
     * @param hibernateSession Session
     * @return String
     */
    public String setFormStatus(Long formId, String status, String moduleName, Session hibernateSession) {
        String returnValue = Constants.UPDATE_ERROR_OUTCOME;
        String formType = null;
        Integer userId = null;

        try {
            // Get Form status
            Query queryForm = hibernateSession.createQuery(
                    "select Form from Form as Form where Form.formId = :formId")
                              .setParameter("formId", formId);

            for (Iterator it1 = queryForm.iterate(); it1.hasNext(); ) {
                Form form = (Form) it1.next();
                if (form != null) {
                    userId = ((Person) form.getPerson()).getCid();

                    formType = form.getWebSubsystem().getFormType();
                    /**
                     * If the Status received in parm. is not N then...*/
                    if (!status.equalsIgnoreCase("n")) {
                        /* PB original SQL statement
                                                         // Update Form table using form id
                                                         UPDATE FORMS
                                                         SET Form_Status = :as_Status
                                                         WHERE FORMS.Form_ID = :al_id */

                        form.setFormStatus(status.toUpperCase());
                        hibernateSession.saveOrUpdate(form);
                        returnValue = Constants.SUCCESS_OUTCOME;

                    } else {
                        /**
                         * Updates based on Form Type
                         *
                         */
                        if (formType.equalsIgnoreCase("cv")) {
                            /* PB original SQL statement
                                                                 // Update Person
                                                                 UPDATE FORMS
                                                                 SET Form_Status = Upper(:as_status)
                             WHERE FORMS.CID = :al_id and FORMS.Subsystem_ID in (SELECT DISTINCT WEB_SUBSYSTEMS.Subsystem_ID
                                                                 FROM WEB_MODULES, WEB_SUBSYSTEMS
                             WHERE ( WEB_SUBSYSTEMS.Subsystem_ID = WEB_MODULES.Subsystem_ID ) and
                                                                 ( WEB_MODULES.Object_Name = :ls_ThisObjectClassName) ) and datediff(dd,Forms.change_date, getdate()) <= 90  and FORMS.Form_Status in ('Y',null) */

                            List queryFormForUpdate = hibernateSession.createQuery(
                                    "select Form from Form as Form where Form.person.cid = :userId and " +
                                    "Form.webSubsystem.subsystemId in (select WebSubsystem.subsystemId from WebSubsystem as WebSubsystem inner join WebSubsystem.webModuls as webModuls " +
                                    "where (webModuls.moduleName = :moduleName)) and " +
                                    "DATEDIFF(day,Form.changeDate, getdate()) < 90 and Form.formStatus in ('N','Y', null)")
                                    .setParameter("userId", userId)
                                    .setParameter("moduleName", moduleName).list();

                            if (queryFormForUpdate.size() > 0) {
                                for (int l = 0; l < queryFormForUpdate.size(); l++) {
                                    Form formFound = (Form) queryFormForUpdate.get(l);
                                    if (formFound != null) {
                                        formFound.setFormStatus(status.toUpperCase());
                                        hibernateSession.saveOrUpdate(formFound);
                                    }
                                }

                                // There might not be any rows to update so, it's alright to return Success even if no rows were updated
                                returnValue = Constants.SUCCESS_OUTCOME;

                            } else if (formType.equalsIgnoreCase("appl") ||
                                       formType.equalsIgnoreCase("assess")) {
                                /* PB original SQL statement
                                                                     // Update Application only
                                                                     UPDATE FORMS
                                                                     SET Form_Status = :as_Status
                                                                     WHERE FORMS.Appl_ID = :al_id */

                                form.setFormStatus(status);
                                hibernateSession.saveOrUpdate(form);
                                returnValue = Constants.SUCCESS_OUTCOME;
                            }
                        }
                    }
                }
            } // end loop

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return returnValue;
    }

    public boolean isEmailAddressExist(String emailAddress) {
        boolean isEmailAddressExist = false;
        ArrayList beanList;

        try {
            logger.info("In CommonDBA.isEmailAddressExist()");
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            Query query = session.createQuery(
                    "select Person.cid from Person as Person where upper(Person.emailAddress) = :emailAddress")
                          .setParameter("emailAddress", emailAddress.toUpperCase());

            // Load array
            beanList = new ArrayList(query.list());

            if (beanList.size() > 0) {
                isEmailAddressExist = true;
            }

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("In CommonDBA.isEmailAddressExist() - Number of matching account with Email Address : " +
                            beanList.size());
            }
            HibernateUtil.commitTransaction();

        } catch (HibernateException e) {
            e.printStackTrace();

        } finally {
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        return isEmailAddressExist;
    }
}
