package ca.sshrc.web.common.services;

import java.util.*;

import javax.faces.model.*;

import ca.sshrc.web.common.beans.popupList.*;
import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.*;
import ca.sshrc.web.lookupCache.*;
import org.apache.log4j.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class JspCacheService extends RootBase {
    private Logger logger = Logger.getLogger(JspCacheService.class.getName());
    private String formLanguage;

    // Default constructor
    public JspCacheService() {
        logger.info("In JspCacheService constructor");
        this.formLanguage = this.getNavigationBean().getFormLanguage();
    }


    /** Generic method call to cache manager
     *
     * Returns a SelectItem array
     *
     * */
    private SelectItem[] getSelectItemList(String cacheManagerName, String cacheObjectName) {
        CacheService cacheManager = null;
        CodesDescCache codesDescCache = null;
        SelectItem selectItemTemp[] = null;

        try {
            cacheManager = CacheService.getInstance(cacheManagerName);
            codesDescCache = (CodesDescCache) cacheManager.get(cacheObjectName);
            selectItemTemp = codesDescCache.getSelectItem(this.getNavigationBean().getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /**
     * getPositionTypeList
     *
     * @return SelectItem
     */
    public SelectItem[] getPositionTypeList() {

        logger.info("In JspCacheService getPositionTypeList. Form language: " + this.formLanguage);
        if (this.formLanguage.compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {

            return new SelectItem[] {
                    new SelectItem(new Integer(0), " "),
                    new SelectItem(new Integer(110), "Permanent"),
                    new SelectItem(new Integer(111), "Menant � la permanence"),
                    new SelectItem(new Integer(424), "Non universitaire"),
                    new SelectItem(new Integer(425), "Ne menant pas � la permanence")
            };

        } else {
            return new SelectItem[] {
                    new SelectItem(new Integer(0), " "),
                    new SelectItem(new Integer(110), "Tenure"),
                    new SelectItem(new Integer(111), "Tenure Track"),
                    new SelectItem(new Integer(424), "Non-Academic"),
                    new SelectItem(new Integer(425), "Non-Tenure Track")

            };

        }
    }

    /**
     * getEmploymentStatusList
     *
     * @return SelectItem[]
     */
    public SelectItem[] getEmploymentTypeList() {

        logger.info("In JspCacheService getEmploymentTypeList. Form language: " + this.formLanguage);
        if (this.formLanguage.compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {

            return new SelectItem[] {
                    new SelectItem(new Integer(0), " "),
                    new SelectItem(new Integer(340), "Plein temps"),
                    new SelectItem(new Integer(341), "Temps partiel"),
                    new SelectItem(new Integer(886), "Cong� autoris�"),
                    new SelectItem(new Integer(887), "Non-salari�")
            };

        } else {
            return new SelectItem[] {
                    new SelectItem(new Integer(0), " "),
                    new SelectItem(new Integer(340), "Full time"),
                    new SelectItem(new Integer(341), "Part time"),
                    new SelectItem(new Integer(886), "Leave of Absence"),
                    new SelectItem(new Integer(887), "Non-salaried")

            };

        }

    }

    /** Yes/No SelectItem array with no blank entry
     * For Radio buttons
     *
     * */
    public SelectItem[] getYesNoListForRadioButton() {
        return this.getYesNoList(false);
    }

    /** Yes/No SelectItem array
     *
     * */
    public SelectItem[] getYesNoList() {
        // Default to blank entry added
        return this.getYesNoList(true);
    }

    /** Yes/No SelectItem array
     *
     * */
    public SelectItem[] getYesNoList(boolean withBlankEntry) {

        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) ==
            0) {
            if (withBlankEntry) {
                return new SelectItem[] {
                        new SelectItem("", ""),
                        new SelectItem("N", "Non"),
                        new SelectItem("Y", "Oui"),
                };
            } else {
                return new SelectItem[] {
                        new SelectItem("N", "Non"),
                        new SelectItem("Y", "Oui"),
                };
            }
        } else {
            if (withBlankEntry) {
                return new SelectItem[] {
                        new SelectItem("", ""),
                        new SelectItem("N", "No"),
                        new SelectItem("Y", "Yes"),
                };
            } else {
                return new SelectItem[] {
                        new SelectItem("N", "No"),
                        new SelectItem("Y", "Yes"),
                };
            }
        }
    }

    public SelectItem[] getCompletionStatusList() {

        if (this.formLanguage.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {

            return new SelectItem[] {
                    new SelectItem(new Integer(0), " "),
                    new SelectItem(new Integer(297), "En cours"),
                    new SelectItem(new Integer(298), "Termin�")
            };

        } else {
            return new SelectItem[] {
                    new SelectItem(new Integer(0), " "),
                    new SelectItem(new Integer(297), "Incomplete"),
                    new SelectItem(new Integer(298), "Complete")
            };

        }
    }

    /**
     * getPersonRoleList
     *
     * @return SelectItem[]
     */
    public SelectItem[] getPersonRoleList() {
        if (this.formLanguage.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {

            return new SelectItem[] {
                    new SelectItem(new Integer(0), " "),
                    new SelectItem(new Integer(291), "Candidat"),
                    new SelectItem(new Integer(486), "Cochercheur"),
                    new SelectItem(new Integer(487), "Collaborateur"),
                    new SelectItem(new Integer(290), "�tudiant"),
                    new SelectItem(new Integer(574), "Assistant de recherche"),
                    new SelectItem(new Integer(596), "�tudiant-assistant")
            };

        } else {
            return new SelectItem[] {
                    new SelectItem(new Integer(0), " "),
                    new SelectItem(new Integer(291), "Applicant"),
                    new SelectItem(new Integer(486), "Co-applicant"),
                    new SelectItem(new Integer(487), "Collaborator"),
                    new SelectItem(new Integer(290), "Student"),
                    new SelectItem(new Integer(574), "Research Assistant"),
                    new SelectItem(new Integer(596), "Student Assistant")
            };

        }

    }

    /** Gender SelectItem array
     *
     * */
    public SelectItem[] getGenderList() {
        String cacheObjectName = "GenderCache";

        return getSelectItemList(Constants.LOOKUP_CACHE_MANAGER, cacheObjectName);
    }

    /** Language SelectItem array
     *
     * */
    public SelectItem[] getLanguageList() {

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            return new SelectItem[] {
                    new SelectItem("F", "Fran�ais"),
                    new SelectItem("E", "Anglais"),
            };

        } else {
            return new SelectItem[] {
                    new SelectItem("E", "English"),
                    new SelectItem("F", "French"),
            };
        }
    }

    /**
     * getTemporalPeriodList
     *
     * @return SelectItem
     */
    public SelectItem[] getTemporalPeriodList() {

        logger.info("In JspCacheService getTemporalPeriodList. Form language: " + this.formLanguage);
        if (this.formLanguage.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {

            return new SelectItem[] {
                    new SelectItem(new String(""), " "),
                    new SelectItem(new String("AD"), "apr. J.-C."),
                    new SelectItem(new String("BC"), "av. J.- C.")
            };

        } else {
            return new SelectItem[] {
                    new SelectItem(new String(""), " "),
                    new SelectItem(new String("AD"), "AD"),
                    new SelectItem(new String("BC"), "BC")
            };

        }
    }

    /** Salutation SelectItem array
     *
     * */
    public SelectItem[] getSalutationList() {
        String cacheObjectName = "SalutationCache";

        return getSelectItemList(Constants.LOOKUP_CACHE_MANAGER, cacheObjectName);
    }

    /** Country object cache array
     *
     * */
    public List getCountryList() {
        CacheService cacheManager = null;
        List selectItemTemp = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            selectItemTemp = ((CountryCache) cacheManager.get("CountryCache")).getList(this.getNavigationBean().
                    getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /** ProvinceState object cache array for provinces
     *
     * */
    public List getProvinceList() {
        CacheService cacheManager = null;
        List selectItemTemp = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            selectItemTemp = ((ProvinceCache) cacheManager.get("ProvinceCache")).getList(this.
                    getNavigationBean().getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /** ProvinceState object cache array for provinces
     *
     * */
    public List getStateList() {
        CacheService cacheManager = null;
        List selectItemTemp = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            selectItemTemp = ((StateCache) cacheManager.get("StateCache")).getList(this.getNavigationBean().
                    getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /** OrganizationCountryCache.OrganizationBean object cache array
     *
     * */
    public List getOrganizationCountryList() {
        CacheService cacheManager = null;
        List selectItemTemp = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            selectItemTemp = ((OrganizationCountryCache) cacheManager.get("OrganizationCountryCache")).
                             getList(this.getNavigationBean().getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /** OrganizationCountryCache.OrganizationBean object cache array
     *
     * */
    public List getOrganizationList() {
        CacheService cacheManager = null;
        List selectItemTemp = null;
        String selectedValue1 = null;
        String selectedValue2 = null;

        /**
         * This method's called directly from a JSP and requires parameter(s) to get the page's required data.
         * Therefore, we need to look for a PopupListParameterBean object in the request and use selectedValue1
         * and/or selectedValue2 to pass the country code and the province/state code.
         */

        // Attempt to get the request attribute
        PopupListParameterBean popupListParameterBean = (PopupListParameterBean)this.getHttpRequest().
                getAttribute("popupListParameterBean");

        if (null != popupListParameterBean) {
            /**
             * There's 3 such fields in popupListParameterBean but only 2 would be used for this list.
             * selectedValue1 would contain a country code
             * selectedValue2 would contain a province or state code
             */

            selectedValue1 = popupListParameterBean.getSelectedValueCode1(); // Should contain a country code (Integer)
            selectedValue2 = popupListParameterBean.getSelectedValueCode2(); // Might or might not contain a province/state code
        }

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            if (null != selectedValue1 && selectedValue1.length() > 0) {
                // Convert selectedValue1 (String) to selectedValue1Int (Integer)
                Integer selectedValue1Int = new Integer(selectedValue1);

                selectItemTemp = ((OrganizationCache) cacheManager.get("OrganizationCache")).
                                 getList(this.getNavigationBean().getFormLanguage(), selectedValue1Int,
                                         selectedValue2);
            } else {
                selectItemTemp = ((OrganizationCache) cacheManager.get("OrganizationCache")).
                                 getList(this.getNavigationBean().getFormLanguage());
            }
        } catch (NumberFormatException ex) {
            // I don't know what to do here... the action taken here needs to trigger an error page at server level.
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }


    public List getDepartmentList() {
        CacheService cacheManager = null;
        List selectItemTemp = null;
        String selectedValue = null;

        /**
         * This method's called directly from a JSP and requires parameter(s) to get the page's required data.
         * Therefore, we need to look for a PopupListParameterBean object in the request and use selectedValue1
         * and/or selectedValue2 to pass the country code and the province/state code.
         */

        // Attempt to get the request attribute
        PopupListParameterBean popupListParameterBean = (PopupListParameterBean)this.getHttpRequest().
                getAttribute("popupListParameterBean");

        if (null != popupListParameterBean) {
            /**
             * There's 3 such fields in popupListParameterBean but only 1 would be used for this list.
             * selectedValue1 would contain an org id
             */

            selectedValue = popupListParameterBean.getSelectedValueCode3(); // Should contain an org id
        }

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            if (null != selectedValue) {
                // Convert selectedValue1 (String) to selectedValue1Int (int)
                int selectedValue1Int = new Integer(selectedValue).intValue();

                selectItemTemp = ((DepartmentCache) cacheManager.get("DepartmentCache")).
                                 getList(this.getNavigationBean().getFormLanguage(), selectedValue1Int);
            }
        } catch (NumberFormatException ex) {
            // I don't know what to do here... the action taken here needs to trigger an error page at server level.
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }


    /** PositionCache object cache array
     *
     * */
    public List getPositionList() {
        CacheService cacheManager = null;
        List selectItemTemp = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            selectItemTemp = ((CodesDescCache) cacheManager.get("PositionCache")).
                             getList(this.getNavigationBean().getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /** AreaOfResearchCache object cache
     *
     * */
    public List getAreaOfResearchList() {
        CacheService cacheManager = null;
        List selectItemTemp = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            selectItemTemp = ((CodesDescCache) cacheManager.get("AreaOfResearchCache")).
                             getList(this.getNavigationBean().getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /** AreaOfResearchCache object cache
     *
     * */
    public List getGeographicRegionList() {
        CacheService cacheManager = null;
        List selectItemTemp = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            selectItemTemp = ((CodesDescCache) cacheManager.get("GeographicRegionCache")).
                             getList(this.getNavigationBean().getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /** Country object cache array
     *
     * */
    public List getFundingOrganizationList() {
        CacheService cacheManager = null;
        List selectItemTemp = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            selectItemTemp = ((FundingOrganizationCache) cacheManager.get("FundingOrganizationCache")).
                             getList(this.getNavigationBean().
                                     getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /**
     * getAddressTypes
     *
     * @return SelectItem
     *
     * function used to generate the address type radio button
     */
    public SelectItem[] getAddressTypes() {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) ==
            0) {
            return new SelectItem[] {new SelectItem(new Integer(168),
                    "Canada"), new SelectItem(new Integer(169), "�tats-Unis"),
                    new SelectItem(new Integer(170), "Autre")};

        } else {
            return new SelectItem[] {new SelectItem(new Integer(168),
                    "Canada"), new SelectItem(new Integer(169), "United States"),
                    new SelectItem(new Integer(170), "Other")};

        }

    }

    /**
     * getDegreeTypes
     *
     * @return List
     */
    public SelectItem[] getDegreeTypes() {
        String cacheObjectName = "degreeTypeCache";

        return this.getSelectItemList(Constants.LOOKUP_CACHE_MANAGER, cacheObjectName);
    }

    /**
     * getDisciplineList
     *
     * @return List
     */
    public List getDisciplineList() {
        CacheService cacheManager = null;
        List selectItemTemp = null;
        String selectedValue;

        /*
         *  This drop down has two level. The first time, we only display the master codes.
         *  therefore, we need to chack the request level.
         *  Level 1 we need to remove all the codes that are not main codes
         *  Level 2, we need to filterout according to the main code.
         */

        PopupListParameterBean popupListParameterBean = (PopupListParameterBean)this.getHttpRequest().
                getAttribute("popupListParameterBean");

        if (null != popupListParameterBean) {
            System.out.println(
                    "in jspcacheservices.getDisciplineList - popupListParameterBean object found in request");
            /**
             * There's 3 such fields in popupListParameterBean but only 1 would be used for this list.
             * selectedValue1 would contain an org id
             */
        }
        System.out.println("in jspcacheservices.getDisciplineList - popupListParameterBean.getCurrentLevel: " +
                           popupListParameterBean.getCurrentLevel());
        if (popupListParameterBean.getCurrentLevel() == 0) {
            try {
                cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
                selectItemTemp = ((DisciplineCache) cacheManager.get("DisciplineCache")).getMasterList();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (popupListParameterBean.getCurrentLevel() == 1) {
            try {
                cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
                selectedValue = popupListParameterBean.getSelectedValueCode1();
                // Convert selectedValue1 (String) to selectedValue1Int (int)
                Integer selectedValue1Int = new Integer(selectedValue);

                selectItemTemp = ((DisciplineCache) cacheManager.get("DisciplineCache")).getDetailList(
                        selectedValue1Int);
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        }

        return selectItemTemp;

    }

    /**
     * distinctionTypes
     *
     * @return List
     */
    public SelectItem[] getDistinctionTypes() {

        String cacheObjectName = "DistinctionType";
        CacheService cacheManager = null;
        CodesDescTableCache CodesDescTableCache = null;
        SelectItem selectItemTemp[] = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            CodesDescTableCache = (CodesDescTableCache) cacheManager.get(cacheObjectName);
            selectItemTemp = CodesDescTableCache.getSelectItem(this.getNavigationBean().getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;

    }

    /** Committee object cache array
     *
     * */
    public List getCommitteeList() {
        CacheService cacheManager = null;
        List selectItemTemp = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            selectItemTemp = ((CommitteeCache) cacheManager.get("CommitteeCache")).getList(this.
                    getNavigationBean().
                    getFormLanguage(),
                    CommonService.getProgramId(this.getNavigationBean().getCurrentSubsystemId()));

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /** Supplement SelectItem array
     *
     * */
    public SelectItem[] getSupplementList() {
        CacheService cacheManager = null;
        SupplementsCache supplementsCache = null;
        SelectItem selectItemTemp[] = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            supplementsCache = (SupplementsCache) cacheManager.get("SupplementsCache");
            selectItemTemp = supplementsCache.getSelectItem(this.getNavigationBean().getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /** Scholarship categories SelectItem array
     *
     * */
    public SelectItem[] getScholarCategoryList() {
        String cacheObjectName = "CodesScholarshipTypeCache";

        return getSelectItemList(Constants.LOOKUP_CACHE_MANAGER, cacheObjectName);
    }

    /** Scholarship categories SelectItem array
     *
     * */
    public SelectItem[] getResearcherCategoryList() {
        CacheService cacheManager = null;
        CodesDescCache codesDescCache = null;
        SelectItem selectItemTemp[] = null;
        ArrayList filterArrayList = new ArrayList(2);

        filterArrayList.add(0,new Integer(374));
        filterArrayList.add(1,new Integer(572));

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            codesDescCache = (CodesDescCache) cacheManager.get("CodesScholarshipTypeCache");

            // Filter list prior to calling codesDescCache.getSelectItem()
            codesDescCache.setFilter(filterArrayList, false);

            selectItemTemp = codesDescCache.getSelectItem(this.getNavigationBean().getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /** CodesActivityType object cache array for activity types
     *
     * */
    public List getActivityTypeList() {
        CacheService cacheManager = null;
        List selectItemTemp = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            selectItemTemp = ((CodesDescCache) cacheManager.get("CodesActivityTypeCache")).
                             getList(this.getNavigationBean().getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /** Geographical scope SelectItem object array
     *
     * */
    public SelectItem[] getGeographicalScopeList() {
        String cacheObjectName = "codesGeographicalScopeCache";

        return getSelectItemList(Constants.LOOKUP_CACHE_MANAGER, cacheObjectName);
    }

    /** Programs SelectItem object array
     *
     * */
    public SelectItem[] getProgramList() {
        CacheService cacheManager = null;
        SelectItem selectItemTemp[] = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            if (this.getNavigationBean().getCurrentSubsystemId().intValue() == 37) {
                int[] programIdToGet = {501,512,537,538,539,540,542};
                selectItemTemp = ((ProgramCache) cacheManager.get("ProgramCache")).
                                 getSelectItem(this.getNavigationBean().getFormLanguage(), programIdToGet);
            } else {
                selectItemTemp = ((ProgramCache) cacheManager.get("ProgramCache")).
                                 getSelectItem(this.getNavigationBean().getFormLanguage());
            }


        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /** Participant role SelectItem object array
     *
     * */
    public SelectItem[] getParticipantRoleList() {
        String cacheObjectName = "ParticipantRoleCache";

        return getSelectItemList(Constants.LOOKUP_CACHE_MANAGER, cacheObjectName);
    }

    /** Theme SelectItem array
     *
     * */
    public SelectItem[] getThemeList() {
        CacheService cacheManager = null;
        ThemeCache themeCache = null;
        SelectItem selectItemTemp[] = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            themeCache = (ThemeCache) cacheManager.get("ThemeCache");
            selectItemTemp = themeCache.getSelectItem(this.getNavigationBean().getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /** Sub Theme SelectItem array
     *
     * */
    public SelectItem[] getSubThemeList() {
        CacheService cacheManager = null;
        SubThemeCache subThemeCache = null;
        SelectItem selectItemTemp[] = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            subThemeCache = (SubThemeCache) cacheManager.get("SubThemeCache");
            selectItemTemp = subThemeCache.getSelectItem(this.getNavigationBean().getFormLanguage());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }
}
