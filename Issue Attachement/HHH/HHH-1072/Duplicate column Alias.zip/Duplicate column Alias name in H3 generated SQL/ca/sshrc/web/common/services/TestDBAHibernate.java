package ca.sshrc.web.common.services;

import java.util.*;

import org.apache.log4j.*;
import org.hibernate.*;
import ca.sshrc.web.forms.beans.cv.ExpertiseBean;
import ca.sshrc.web.forms.beans.cv.TestExpertiseBean;

public class TestDBAHibernate {
    private Logger logger = Logger.getLogger(TestDBAHibernate.class.getName());
    private List list;

    public List TestDBAHibernate(long formId) {
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In TestDBAHibernate - About to execute query ...");


            list = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.cv.TestExpertiseBean( " +
                    "PersonExpertise.cid, " +
                    "Discipline_a, " +
                    "Discipline_b, " +
                    "Discipline_c, " +
                    "Discipline_d, " +
                    "Discipline_e) " +
                    "from Form form join form.person as Person " +
                    "left join fetch Person.personExpertise as PersonExpertise " +
                    "left join fetch PersonExpertise.disciplineCode1 as Discipline_a " +
                    "left join fetch PersonExpertise.disciplineCode2 as Discipline_b " +
                    "left join fetch PersonExpertise.disciplineCode3 as Discipline_c " +
                    "left join fetch PersonExpertise.disciplineCode4 as Discipline_d " +
                    "left join fetch PersonExpertise.disciplineCode5 as Discipline_e " +
                    "where (form.formId = :formId)")
                        .setParameter("formId", new Long(formId))
                        .list();

                 if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                     logger.info("TestDBAHibernate rows retrieved: " +
                                 list.size());
                 }

            Iterator it = list.iterator();
            while (it.hasNext()) {
                TestExpertiseBean localDataCasting = (TestExpertiseBean) it.next();
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("TestDBAHibernate before calling getCid()");
                    logger.info("TestDBAHibernate getCid: " +
                                localDataCasting.getCid());
                }
            }
            HibernateUtil.commitTransaction();
            HibernateUtil.closeSession();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
