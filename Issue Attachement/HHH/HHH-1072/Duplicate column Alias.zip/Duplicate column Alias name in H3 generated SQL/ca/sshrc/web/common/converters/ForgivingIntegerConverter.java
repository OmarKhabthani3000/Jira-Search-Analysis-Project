package ca.sshrc.web.common.converters;



import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.NumberUtils;
import ca.sshrc.web.common.util.*;


/**
 * <p>{@link Converter} implementation for <code>java.lang.Integer</code>
 * (and int primitive) values. Will remove invalid characters before trying the
 * conversion. The characters removed are {.,$ and space}</p>
 */

public class ForgivingIntegerConverter implements Converter {


    // ------------------------------------------------------ Manifest Constants


    /**
     * <p>The standard converter id for this converter.</p>
     */
    public static final String CONVERTER_ID = "ForgivingIntegerConverter";


    // ------------------------------------------------------- Converter Methods


    /**
     * @exception ConverterException {@inheritDoc}
     * @exception NullPointerException {@inheritDoc}
     */
    public Object getAsObject(FacesContext context, UIComponent component,
                              String value) {

        if (context == null || component == null) {
            throw new NullPointerException();
        }

        // If the specified value is null or zero-length, return null
        if (value == null) {
            return (null);
        }
        value = value.trim();
        if (value.length() < 1) {
            return (null);
        }

        if (!NumberUtils.isDigits(value)) {
            // Try cleaning it up first
            for (int i=0;i<Constants.INVALID_CHARACTERS_IN_NUMERIC_FIELD.length;i++) {
                value = StringUtils.replace(value, Constants.INVALID_CHARACTERS_IN_NUMERIC_FIELD[i], "");
            }
        }

        try {
            return (Integer.valueOf(value));
        } catch (Exception e) {
            throw new ConverterException(e);
        }
    }

    /**
     * @exception ConverterException {@inheritDoc}
     * @exception NullPointerException {@inheritDoc}
     */
    public String getAsString(FacesContext context, UIComponent component,
                              Object value) {

        if (context == null || component == null) {
            throw new NullPointerException();
        }

        // If the specified value is null, return a zero-length String
        if (value == null) {
            return "";
        }

        // If the incoming value is still a string, play nice
        // and return the value unmodified
        if (value instanceof String) {
            return (String) value;
        }

        try {
            // If the incoming value is 0
            // return an empty string else return toString value
            int intTemp = ((Integer) value).intValue();
            if (intTemp == 0) {
                return "";
            } else {
                return (Integer.toString(((Integer) value).intValue()));
            }
        } catch (Exception e) {
            throw new ConverterException(e);
        }

    }


}
