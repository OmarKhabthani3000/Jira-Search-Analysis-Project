package ca.sshrc.web.lookupCache;

import java.io.*;
import java.text.*;
import java.util.*;

import ca.sshrc.web.common.services.*;
import org.hibernate.*;
import org.apache.log4j.*;
import ca.sshrc.web.common.util.Constants;

public class CommitteeCache implements Serializable {
    private Logger logger = Logger.getLogger(CommitteeCache.class.getName());
    private List queryList;

    public CommitteeCache() {
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In CommitteeCache");

            queryList = session.createQuery(
                    "select new ca.sshrc.web.lookupCache.CommitteeBean(Committee.committeeId, " +
                    "ProgCommittee.comp_id.program.programId, " +
                    "Committee.nameEnglish, " +
                    "Committee.nameFrench, " +
                    "Committee.shortNameEnglish, " +
                    "Committee.shortNameFrench) " +
                    "from Committee Committee, " +
                    "ProgCommittee ProgCommittee " +
                    "where Committee.committeeId = ProgCommittee.comp_id.committeeId " +
                    "and Committee.activeInd = 'Y' " +
                    "and ProgCommittee.activeInd = 'Y' " +
                    "order by 5 asc").
                        list();

            /* Original PB SQL - dddw_department
             SELECT  COMMITTEE.Short_Name_English ,
                        COMMITTEE.Short_Name_French ,
                        COMMITTEE.Name_English ,
                        COMMITTEE.Name_French ,
                        PROG_COMMITTEE.Program_ID ,
                        PROG_COMMITTEE.Committee_ID
                     FROM COMMITTEE ,
                        PROG_COMMITTEE
                     WHERE ( COMMITTEE.Committee_ID = PROG_COMMITTEE.Committee_ID ) and
                      ( ( COMMITTEE.Active_Ind = 'Y' ) and
                      ( PROG_COMMITTEE.Active_Ind = 'Y' ) )    */


            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Committee loaded: " + queryList.size());
            }

        } catch (HibernateException ex) {
            ex.printStackTrace();
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
        } finally {
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public static final Comparator shortNameEnglishOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            CommitteeBean objComp1 = (CommitteeBean) o1;
            CommitteeBean objComp2 = (CommitteeBean) o2;
            return myCollator.compare(objComp1.getShortNameEnglish(),
                                      objComp2.getShortNameEnglish());
        }
    };

    public static final Comparator shortNameFrenchOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA_FRENCH);
            CommitteeBean objComp1 = (CommitteeBean) o1;
            CommitteeBean objComp2 = (CommitteeBean) o2;
            return myCollator.compare(objComp1.getShortNameFrench(),
                                      objComp2.getShortNameFrench());
        }
    };
    public ArrayList getList(String language) {
        // Keep the original array. Use a copy for sorting
        ArrayList listTemp;
        listTemp = (ArrayList) queryList;

        return this.sort(listTemp, language);
    }

    public ArrayList getList(String language, int programId) {
        ArrayList listTemp = new ArrayList();
        int found = 0;

        for (int i = 0; i < queryList.size(); ++i) {
            CommitteeBean committeeBean = (CommitteeBean) queryList.get(i);
            // Look for passed program id)
            if (programId == committeeBean.getProgramId().intValue()) {
                found++;
                listTemp.add(committeeBean);
            } else if (found > 1) {
                // queryList is sorted by orgId + org dept loc id
                // therefore, we stop the loop as soon as we find a non matching
                // pair (after we found at least one pair)
                break;
            }
        }

        if (found > 1) {
            return this.sort(listTemp, language);
        } else {
            return listTemp;
        }
    }

    private ArrayList sort(ArrayList list, String language) {
        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Sorting Committees - " + language);
        }

        // Keep the original List. Use a copy for sorting
        ArrayList listTemp;
        listTemp = list;

        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            Collections.sort(listTemp, shortNameFrenchOrder);
        } else {
            Collections.sort(listTemp, shortNameEnglishOrder);
        }
        return listTemp;
    }
}
