package ca.sshrc.web.logon;

import java.util.*;

import javax.faces.application.*;
import javax.faces.component.*;
import javax.faces.context.*;
import javax.faces.model.*;
import javax.faces.validator.*;
import javax.servlet.http.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.*;
import ca.sshrc.web.lookupCache.*;
import hibernate.*;
import hibernate.interceptors.*;
import org.hibernate.*;
import org.apache.commons.beanutils.*;

public class RegistrationBean extends BeanBase {
    public RegistrationBean() {
        String languageSite;

        /** Get the language
         * Depending on the JSF phase this constructor is executed in, the language will be fetch from diffrent hidden fields
         * If it's the first time this page is called (page generated in Render Response phase),
         * the language value comes from the Logon.jsp page and the hidden field name is "mainForm:languageSite".
         *
         * If it's the request that's being generated, the language comes from
         * "mainForm:bodyContent:languageSite" on the Registration.jsp page.
         */

        if (this.getFacesContext().getRenderResponse()) {
            languageSite = this.getHttpRequest().getParameter("mainForm:languageSite");
            if (null != languageSite) {
                this.languageSite = languageSite;
            }
        } else {
            languageSite = this.getHttpRequest().getParameter("mainForm:bodyContent:languageSite");
            if (null != languageSite) {
                this.languageSite = languageSite;
            }
        }

    }

    /** identifier field */
    private Integer cid;

    /** nullable persistent field */
    private String familyName;


    /** nullable persistent field */
    private String givenName;

    /** nullable persistent field */
    private String initials;

    /** nullable persistent field */
    private Integer salutation;

    /** persistent field */
    private String correspondenceLanguageCode;

    /** nullable persistent field */
    private String emailAddress;
    private boolean emailAddressValidationError;

    /** nullable persistent field */
    private String password;
    private boolean passwordValidationError;

    /** nullable persistent field */
    private String passwordConfirmation;

    private String languageSite;

    /**
     * Getters & setters
     *
     */
    public Integer getCid() {
        return cid;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getFamilyName() {
        return familyName;
    }

    public String getGivenName() {
        return givenName;
    }

    public String getInitials() {
        return initials;
    }

    public String getPassword() {
        return password;
    }

    public String getPasswordConfirmation() {
        return passwordConfirmation;
    }

    public Integer getSalutation() {
        return salutation;
    }

    public String getLanguageSite() {
        return languageSite;
    }

    public String getCorrespondenceLanguageCode() {
        return correspondenceLanguageCode;
    }

    public boolean isEmailAddressValidationError() {
        return emailAddressValidationError;
    }

    public boolean isPasswordValidationError() {
        return passwordValidationError;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPasswordConfirmation(String passwordConfirmation) {
        this.passwordConfirmation = passwordConfirmation;
    }

    public void setSalutation(Integer salutation) {
        this.salutation = salutation;
    }

    public void setCorrespondenceLanguageCode(String correspondenceLanguageCode) {
        this.correspondenceLanguageCode = correspondenceLanguageCode;
    }

    public void setLanguageSite(String languageSite) {
        this.languageSite = languageSite;
    }

    /** Language SelectItem array
     *
     * */
    /**
     * getLanguageList
     *
     * Call to cache manager
     * List of Languages
     *
     * @return SelectItem[]
     */
    public SelectItem[] getLanguageList() {

        if (this.languageSite.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            return new SelectItem[] {
                    new SelectItem("F", "Fran�ais"),
                    new SelectItem("E", "Anglais"),
            };

        } else {
            return new SelectItem[] {
                    new SelectItem("E", "English"),
                    new SelectItem("F", "French"),
            };
        }
    }

    /**
     * getSalutationList
     *
     * Call to cache manager
     * List of Salutation
     *
     * @return SelectItem[]
     */
    public SelectItem[] getSalutationList() {
        CacheService cacheManager = null;
        CodesDescCache codesDescCache = null;
        SelectItem selectItemTemp[] = null;

        try {
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            codesDescCache = (CodesDescCache) cacheManager.get("SalutationCache");
            selectItemTemp = codesDescCache.getSelectItem(this.languageSite);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return selectItemTemp;
    }

    /**
     * validateEmailAddress
     *
     * Validate email address
     * - Address format
     * - Required
     *
     * @param context FacesContext
     * @param toValidate UIComponent
     * @param value Object
     * @throws ValidatorException
     */
    public void validateEmailAddress(FacesContext context, UIComponent toValidate, java.lang.Object value) throws
            ValidatorException {

        String errorMessage;

        // Resource bundle stuff to get error message & label
        ResourceBundle validationErrorBundle = null;
        Locale locale = null;

        // Create Locale
        if (this.languageSite.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            locale = Locale.CANADA_FRENCH;
        } else {
            locale = Locale.CANADA;
        }

        try {
            String emailAddress = (String) value;

            // Only validate if user entered something
            if (emailAddress != null) {

                if (!CommonService.isValidEmailAddress(emailAddress, true)) {
                    // Set validation indicator, used for label style
                    this.emailAddressValidationError = true;

                    // Get resource bundles
                    validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                            Constants.VALIDATION_ERROR_RESOURCES, locale);

                    // Get error message
                    errorMessage = validationErrorBundle.getString("errorInvalidEmailAddressFormat");

                    if (null != errorMessage) {
                        throw new ValidatorException(
                                new FacesMessage(errorMessage,
                                                 null));
                    } else {
                        throw new ValidatorException(
                                new FacesMessage("Invalid email address.",
                                                 null));
                    }
                }
            } else {
                // Set error indicator for that field
                this.emailAddressValidationError = true;

                // Get resource bundles
                validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                        Constants.CUSTOM_MESSAGES_RESOURCES, locale);

                // Get error message
                errorMessage = validationErrorBundle.getString("javax.faces.component.UIInput.REQUIRED");

                if (null != errorMessage) {
                    throw new ValidatorException(
                            new FacesMessage(errorMessage,
                                             null));
                } else {
                    throw new ValidatorException(
                            new FacesMessage("%%%javax.faces.component.UIInput.REQUIRED%%%",
                                             null));
                }
            }

        } catch (ClassCastException e) {
            throw new ValidatorException(
                    new FacesMessage(
                            "Validation Error: Value " +
                            "cannot be converted to String.",
                            null));
        }
    }

    /**
     * validatePassword
     *
     * Validate Passwords
     * - Length 6-10
     * - The 2 password attributes must be identical
     * - Required
     *
     * @param context FacesContext
     * @param toValidate UIComponent
     * @param value Object
     * @throws ValidatorException
     */
    public void validatePassword(FacesContext context, UIComponent toValidate, java.lang.Object value) throws
            ValidatorException {

        String errorMessage;
        String clientId = toValidate.getClientId(context);
        String theOtherPassword;

        // Resource bundle stuff to get error message & label
        ResourceBundle validationErrorBundle = null;
        Locale locale = null;

        // Create Locale
        if (this.languageSite.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            locale = Locale.CANADA_FRENCH;
        } else {
            locale = Locale.CANADA;
        }

        try {
            String password = (String) value;

            // Only validate if user entered something
            if (password != null) {

                password = password.trim();

                // Password must be between 6 and 10 chars.
                if (password.length() < 6 || password.length() > 10) {
                    // Set error indicator for that field
                    this.passwordValidationError = true;

                    // Get resource bundles
                    validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                            Constants.VALIDATION_ERROR_RESOURCES, locale);

                    // Get error message
                    errorMessage = validationErrorBundle.getString("errorPasswordLength");

                    if (null != errorMessage) {
                        throw new ValidatorException(
                                new FacesMessage(errorMessage,
                                                 null));
                    } else {
                        throw new ValidatorException(
                                new FacesMessage("%%%errorPasswordLength%%%",
                                                 null));
                    }
                }

                // Get the other password, if this one is the password field, get the passwordConfirmation field (or vice versa).
                if (clientId.endsWith("passwordConfirmation")) {
                    theOtherPassword = ((HttpServletRequest) context.getExternalContext().getRequest()).
                                       getParameter("mainForm:bodyContent:password");
                } else {
                    theOtherPassword = ((HttpServletRequest) context.getExternalContext().getRequest()).
                                       getParameter("mainForm:bodyContent:passwordConfirmation");
                }

                if (null == theOtherPassword || !password.equals(theOtherPassword)) {
                    // Set validation indicator, used for label style
                    this.passwordValidationError = true;

                    // Get resource bundles
                    validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                            Constants.VALIDATION_ERROR_RESOURCES, locale);

                    // Get error message
                    errorMessage = validationErrorBundle.getString("errorPasswordConfirmation");

                    if (null != errorMessage) {
                        throw new ValidatorException(
                                new FacesMessage(errorMessage,
                                                 null));
                    } else {
                        throw new ValidatorException(
                                new FacesMessage("%%%errorPasswordConfirmation%%%",
                                                 null));
                    }
                }
            } else {
                // Set error indicator for that field
                this.passwordValidationError = true;

                // Get resource bundles
                validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                        Constants.CUSTOM_MESSAGES_RESOURCES, locale);

                // Get error message
                errorMessage = validationErrorBundle.getString("javax.faces.component.UIInput.REQUIRED");

                if (null != errorMessage) {
                    throw new ValidatorException(
                            new FacesMessage(errorMessage,
                                             null));
                } else {
                    throw new ValidatorException(
                            new FacesMessage("%%%javax.faces.component.UIInput.REQUIRED%%%",
                                             null));
                }
            }

        } catch (ClassCastException e) {
            throw new ValidatorException(
                    new FacesMessage(
                            "Validation Error: Value " +
                            "cannot be converted to String.",
                            null));
        }
    }

    /**
     * validateSalutation
     *
     * Validate salutation - Required
     *
     * @param context FacesContext
     * @param toValidate UIComponent
     * @param value Object
     * @throws ValidatorException
     */
    public void validateSalutation(FacesContext context, UIComponent toValidate, java.lang.Object value) throws
            ValidatorException {

        String errorMessage;

        // Resource bundle stuff to get error message & label
        ResourceBundle validationErrorBundle = null;
        Locale locale = null;

        // Create Locale
        if (this.languageSite.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            locale = Locale.CANADA_FRENCH;
        } else {
            locale = Locale.CANADA;
        }

        try {
            Integer salutation = (Integer) value;

            // Only validate if user entered something
            if (salutation != null && salutation.intValue() > 0) {

            } else {

                // Get resource bundles
                validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                        Constants.CUSTOM_MESSAGES_RESOURCES, locale);

                // Get error message
                errorMessage = validationErrorBundle.getString("javax.faces.component.UIInput.REQUIRED");

                if (null != errorMessage) {
                    throw new ValidatorException(
                            new FacesMessage(errorMessage,
                                             null));
                } else {
                    throw new ValidatorException(
                            new FacesMessage("%%%javax.faces.component.UIInput.REQUIRED%%%",
                                             null));
                }
            }

        } catch (ClassCastException e) {
            throw new ValidatorException(
                    new FacesMessage(
                            "Validation Error: Value " +
                            "cannot be converted to Integer.",
                            null));
        }
    }

    /**
     * save
     *
     * Save the new user
     *
     * @return String
     * @throws HibernateException
     * @throws Exception
     */
    public String save() throws HibernateException, Exception {
        String saveOutcome = Constants.UPDATE_ERROR_OUTCOME; // Defaults to update error

        // Open Hibernate transaction
        try {

            // An update to form.formStatus column requires this interceptor.
            // See HibernateUtil.getSession() for more details.
            Interceptor interceptor = new FormStatusInterceptor();
            Session session = HibernateUtil.getSession(interceptor);

            HibernateUtil.beginTransaction();

            /**
             * Insert Person data
             * */
            Person newPerson = new Person();

            // BeanUtils.copyProperties(destination, source)
            PropertyUtils.copyProperties(newPerson, this);
            session.save(newPerson);
            session.flush();
            session.refresh(newPerson);


            /**
             * Insert a security profile in SecurityProfile
             * */
            SecurityProfile newSecurityProfile = new SecurityProfile();

            newSecurityProfile.setCid(newPerson.getCid());
            newSecurityProfile.setAccessCount(new Integer(1));
            newSecurityProfile.setLastAccessDatetime(newPerson.getCreateDate());
            newSecurityProfile.setCurrentPassword(this.getPassword().trim());
            newSecurityProfile.setLastPasswordChangeDatetime(newPerson.getCreateDate());
            newSecurityProfile.setProfileLockIndicator("N");
            newSecurityProfile.setInvalidPasswordAttempts(new Short("0"));

            session.save(newSecurityProfile);
            session.flush();
            HibernateUtil.commitTransaction();

            // Instantiate the LogonBean and set the Cid value
            FacesContext context = this.getFacesContext();
            LogonBean logonBean = (LogonBean) context.getApplication().getVariableResolver().resolveVariable(context, "logonBean");

            logonBean.setWeb_id(newPerson.getCid());

            saveOutcome = Constants.SUCCESS_OUTCOME;

        } catch (HibernateException ex) {
            HibernateUtil.rollbackTransaction();
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();

        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        return saveOutcome;
    }
}
