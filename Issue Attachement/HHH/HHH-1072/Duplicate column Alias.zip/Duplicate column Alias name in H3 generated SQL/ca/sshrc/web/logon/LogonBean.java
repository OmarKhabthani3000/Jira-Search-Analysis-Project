package ca.sshrc.web.logon;

/**
 * <p>Title: LogonBean</p>
 *
 * <p>Description: Contains log on properties and methods. </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Social Sciences and Humanities Research Council of Canada</p>
 *
 * @author Pierre Masse
 * @version 1.0
 */

import javax.faces.context.*;
import javax.servlet.http.*;
import ca.sshrc.web.common.util.Constants;

// Implements serializable - Kept in session bean
public class LogonBean implements java.io.Serializable {
    private Integer web_id;
    private String browserVersion;
    private String password;

    /**
     * siteLanguageAtLogon property's set by LongonDBA.validateAccessRight() on successfull
     * logon (using the user's correspondance language setting in Person)
     */
    private String siteLanguageAtLogon;


    // Constructor
    public LogonBean() {
    }

    public void setBrowserVersion(String browserVersion) {
        this.browserVersion = browserVersion;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setSiteLanguageAtLogon(String siteLanguageAtLogon) {
        this.siteLanguageAtLogon = siteLanguageAtLogon;
    }

    public void setWeb_id(Integer web_id) {
        this.web_id = web_id;
    }

    public String getBrowserVersion() {
        return this.browserVersion;
    }

    public String getPassword() {
        return this.password;
    }

    public String getSiteLanguageAtLogon() {
        return siteLanguageAtLogon;
    }

    public Integer getWeb_id() {
        return web_id;
    }

    /**
     * Three possible outcomes;
     * 1- SUCCESS_OUTCOME: Access granted, user id & password valid - Account wasn't locked.
     * 2- FAILURE_OUTCOME: Access refused, user id and/or password invalid - Account could have been locked at time of access validation.
     * 3- ACCOUNT_LOCKED_OUTCOME: Access refused - user id & password valid - Account was lockedat time of access validation.
     *
     * */
    public String logonValidation() {

        String outcome;

        LogonService logonService = new LogonService();
        outcome = logonService.validateAccessRight(this);

        if (!outcome.equals(Constants.SUCCESS_OUTCOME) &&
            !outcome.equals(Constants.ACCOUNT_PASSWORD_EXPIRED_OUTCOME)) {
            // Invalidate session
            FacesContext context = FacesContext.getCurrentInstance();
            HttpSession session = (HttpSession) context.getExternalContext().
                                  getSession(false);
            session.invalidate();
        }

        return outcome;
    }
}
