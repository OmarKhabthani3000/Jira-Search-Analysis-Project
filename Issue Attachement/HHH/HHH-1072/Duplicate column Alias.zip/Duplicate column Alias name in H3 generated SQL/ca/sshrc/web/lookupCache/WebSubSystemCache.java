package ca.sshrc.web.lookupCache;

import java.io.*;
import java.util.*;

import ca.sshrc.web.common.services.*;
import org.hibernate.*;
import org.apache.log4j.*;
import hibernate.WebSubsystem;

public class WebSubSystemCache implements Serializable {
    private Logger logger = Logger.getLogger(WebSubSystemCache.class.getName());
    private List queryList;

    public WebSubSystemCache() {
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In WebSubSystemCache");

            // Ordered descending because when we look for a subsystem id, will most likely
            // look for high value sub. Subsystem id are added overtime as we add forms to our system.
/*            queryList = session.createQuery(
                    "select new hibernate.WebSubsystem(WebSubsystem.subsystemId, " +
                    "WebSubsystem.subsystemDescription, " +
                    "WebSubsystem.nameEnglish, " +
                    "WebSubsystem.nameFrench, " +
                    "WebSubsystem.grantType, " +
                    "WebSubsystem.helpFile, " +
                    "WebSubsystem.reportObject, " +
                    "WebSubsystem.portfolioInd, " +
                    "WebSubsystem.activeInd, " +
                    "WebSubsystem.startDate, " +
                    "WebSubsystem.endDate, " +
                    "WebSubsystem.letterOfIntentInd, " +
                    "WebSubsystem.displayNameEnglish, " +
                    "WebSubsystem.displayNameFrench, " +
                    "WebSubsystem.attachmentFile, " +
                    "WebSubsystem.numberOfBudgetYears, " +
                    "WebSubsystem.finalReportInd, " +
                    "WebSubsystem.logoName, " +
                    "WebSubsystem.formType, " +
                    "WebSubsystem.dataEntryType, " +
                    "WebSubsystem.program) " +
                    "from WebSubsystem WebSubsystem " +
                    "order by 1 desc").list();*/

            queryList = session.createQuery(
                    "from WebSubsystem WebSubsystem " +
                    "order by WebSubsystem.subsystemId desc").list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("WebSubsystem loaded: " + queryList.size());
            }

            HibernateUtil.commitTransaction();

        } catch (HibernateException ex) {
            HibernateUtil.rollbackTransaction();
            ex.printStackTrace();
        } finally {
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public String getHelpFileName (Integer webSubsystemId) {
        String helpFileName = null;
        WebSubsystem webSubsystem = null;

        // Loop through the web subsystems
        for (Iterator it = queryList.iterator(); it.hasNext(); ) {
            // If sub found, get the help file name and break out
            webSubsystem = (WebSubsystem) it.next();
            if (webSubsystem.getSubsystemId().compareTo(webSubsystemId) == 0) {
                helpFileName = webSubsystem.getHelpFile();
                break;
            }
            // Exit loop if done querying requested subsystemid

            // Add found web module
        }

        return helpFileName;
    }

    public String getAttachmentName (Integer webSubsystemId) {
        String attachmentName = null;
        WebSubsystem webSubsystem = null;

        // Loop through the web subsystems
        for (Iterator it = queryList.iterator(); it.hasNext(); ) {
            // If sub found, get the attachment name and break out
            webSubsystem = (WebSubsystem) it.next();
            if (webSubsystem.getSubsystemId().compareTo(webSubsystemId) == 0) {
                attachmentName = webSubsystem.getAttachmentFile();
                break;
            }
        }

        return attachmentName;
    }

    public int getProgramId (Integer webSubsystemId) {
        Integer programId = new Integer(0);
        WebSubsystem webSubsystem = null;

        // Loop through the web subsystems
        for (Iterator it = queryList.iterator(); it.hasNext(); ) {
            // If sub found, get the program id and break out
            webSubsystem = (WebSubsystem) it.next();
            if (webSubsystem.getSubsystemId().compareTo(webSubsystemId) == 0) {
                programId = webSubsystem.getProgram().getProgramId();
                break;
            }
        }

        return programId.intValue();
    }
}
