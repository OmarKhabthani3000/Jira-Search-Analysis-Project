package ca.sshrc.web.forms.beans.cv;

import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.Constants;

public class ExperienceDetailBean extends BeanBase {

    private Integer positionId;
    private Integer cid;
//    private Integer orgDeptLocId;
//    private Integer positionNumber;
    private hibernate.OrgDeptLocation orgDeptLocation;
    private hibernate.Cod positionNumber;
    private String primaryOrgInd = "N";
    private Short positionStartYear;
    private Short positionEndYear;
    private String otherOrgName;
    private String otherDepartmentName;
    private String otherPositionName;
    private String organizationNameEnglish;
    private String departmentNameEnglish;
    private String positionNameFrench;
    private String organizationNameFrench;
    private String departmentNameFrench;
    private String positionNameEnglish;
    private hibernate.Organization organization;

    /**
     * ExperienceDetailBean
     * Full constructor
     */
    public ExperienceDetailBean(Integer positionId,
                                Integer cid,
                                hibernate.OrgDeptLocation orgDeptLocation,
                                hibernate.Cod positionNumber,
                                Short positionStartYear,
                                Short positionEndYear,
                                String otherOrgName,
                                String otherDepartmentName,
                                String otherPositionName,
                                hibernate.Organization organization,
                                String positionNameEng,
                                String positionNameFre,
                                String organizationNameEng,
                                String organizationNameFre,
                                String departmentNameEng,
                                String departmentNameFre) {
        this.positionId = positionId;
        this.cid = cid;
        this.orgDeptLocation = orgDeptLocation;
        this.positionNumber = positionNumber;
        this.positionStartYear = positionStartYear;
        this.positionEndYear = positionEndYear;
        this.otherOrgName = otherOrgName;
        this.otherDepartmentName = otherDepartmentName;
        this.otherPositionName = otherPositionName;
        this.organization = organization;
        this.positionNameEnglish = positionNameEng;
        this.positionNameFrench = positionNameFre;
        this.organizationNameEnglish = organizationNameEng;
        this.organizationNameFrench = organizationNameFre;
        this.departmentNameEnglish = departmentNameEng;
        this.departmentNameFrench = departmentNameFre;

    }

    /**
     * ExperienceDetailBean
     * Default constructor
     */
    public ExperienceDetailBean() {
        this.cid = this.getLogonBean().getWeb_id();
    }

    /**
     * ExperienceDetailBean
     *
     * @param aiCid Integer
     */
//    public ExperienceDetailBean(Integer aiCid) {
//        this.cid = aiCid;
//    }

    public void setPositionId(Integer positionId) {
        this.positionId = positionId;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public void setOrgDeptLocation(hibernate.OrgDeptLocation orgDeptLocation) {
        this.orgDeptLocation = orgDeptLocation;
    }

    public void setPositionNumber(hibernate.Cod positionNumber) {
        this.positionNumber = positionNumber;
    }

    public void setPrimaryOrgInd(String primaryOrgInd) {
        this.primaryOrgInd = primaryOrgInd;
    }

    public void setPositionStartYear(Short positionStartYear) {
        this.positionStartYear = positionStartYear;
    }

    public void setPositionEndYear(Short positionEndYear) {
        this.positionEndYear = positionEndYear;
    }

    public void setOtherOrgName(String otherOrgName) {
        this.otherOrgName = otherOrgName;
    }

    public void setOtherDepartmentName(String otherDepartmentName) {
        this.otherDepartmentName = otherDepartmentName;
    }

    public void setOtherPositionName(String otherPositionName) {
        this.otherPositionName = otherPositionName;
    }

    public void setPositionNameFrench(String positionNameFrench) {
        this.positionNameFrench = positionNameFrench;
    }

    public void setDepartmentNameEnglish(String DepartmentNameEng) {
        this.departmentNameEnglish = DepartmentNameEng;
    }

    public void setOrganizationNameEnglish(String OrganizationNameEnglish) {
        this.organizationNameEnglish = OrganizationNameEnglish;
    }

    public void setOrganizationNameFrench(String organizationNameFrench) {
        this.organizationNameFrench = organizationNameFrench;
    }

    public void setDepartmentNameFrench(String departmentNameFrench) {
        this.departmentNameFrench = departmentNameFrench;
    }

    public void setPositionNameEnglish(String positionNameEnglish) {
        this.positionNameEnglish = positionNameEnglish;
    }

    public void setOrgId(hibernate.Organization organization) {
        this.organization = organization;
    }

    public Integer getPositionId() {
        return positionId;
    }

    public Integer getCid() {
        return cid;
    }

    public hibernate.OrgDeptLocation getOrgDeptLocation() {
        if (null == orgDeptLocation) {
            orgDeptLocation = new hibernate.OrgDeptLocation();
        }
        return orgDeptLocation;
    }

    public hibernate.Cod getPositionNumber() {
        if (null == positionNumber) {
            positionNumber = new hibernate.Cod();
        }
        return positionNumber;
    }

    public String getPrimaryOrgInd() {
        return primaryOrgInd;
    }

    public Short getPositionStartYear() {
        return positionStartYear;
    }

    public Short getPositionEndYear() {
        return positionEndYear;
    }

    public String getOtherOrgName() {
        return otherOrgName;
    }

    public String getOtherDepartmentName() {
        return otherDepartmentName;
    }

    public String getOtherPositionName() {
        return otherPositionName;
    }

    public String getPositionNameFrench() {
        return positionNameFrench;
    }

    public String getDepartmentNameEnglish() {
        return departmentNameEnglish;
    }

    public String getOrganizationNameEnglish() {
        return organizationNameEnglish;
    }

    public String getOrganizationNameFrench() {
        return organizationNameFrench;
    }

    public String getDepartmentNameFrench() {
        return departmentNameFrench;
    }

    public String getPositionNameEnglish() {
        return positionNameEnglish;
    }

    public hibernate.Organization getOrganization() {
        if (null == organization) {
            organization = new hibernate.Organization();
        }
        return organization;
    }

    /**
     * getOrganizationName
     *
     * @return String
     */
    public String getOrganizationName() {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) ==
            0) {
            return this.organizationNameFrench;
        } else {
            return this.organizationNameEnglish;
        }

    }

    /**
     * setOrganizationName
     *
     * @param OrgName String
     */
    public void setOrganizationName(String OrgName) {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) ==
            0) {
            this.organizationNameFrench = OrgName;
        } else {
            this.organizationNameEnglish = OrgName;
        }

    }

    /**
     * getPositionName
     *
     * @return String
     */
    public String getPositionName() {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) ==
            0) {
            return this.positionNameFrench;
        } else {
            return this.positionNameEnglish;
        }

    }

    /**
     * setPositionName
     *
     * @param PositionName String
     */
    public void setPositionName(String PositionName) {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) ==
            0) {
            this.positionNameFrench = PositionName;
        } else {
            this.positionNameEnglish = PositionName;
        }

    }

    /**
     * getDeptName
     *
     * @return String
     */
    public String getDeptName() {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) ==
            0) {
            return this.departmentNameFrench;
        } else {
            return this.departmentNameEnglish;
        }

    }

    /**
     * setDeptName
     *
     * @param DeptName String
     */
    public void setDeptName(String DeptName) {
        if (this.getNavigationBean().getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) ==
            0) {
            this.departmentNameFrench = DeptName;
        } else {
            this.departmentNameEnglish = DeptName;
        }

    }
}
