package ca.sshrc.web.lookupCache;

public class DepartmentBean {
    private int orgDeptLocId;
    private int orgId;
    private String departmentNameEnglish;
    private String departmentNameFrench;
    private String shortNameEnglish;
    private String shortNameFrench;
    private Integer code;
    private String orgNameEnglish;
    private String orgNameFrench;

    public DepartmentBean(int orgDeptLocId, int orgId, String departmentNameEnglish,
                          String departmentNameFrench, Integer code, String shortNameEnglish,
                          String shortNameFrench, String orgNameEnglish, String orgNameFrench) {
        this.orgDeptLocId = orgDeptLocId;
        this.orgId = orgId;
        this.departmentNameEnglish = departmentNameEnglish;
        this.departmentNameFrench = departmentNameFrench;
        this.code = code;
        this.shortNameEnglish = shortNameEnglish;
        this.shortNameFrench = shortNameFrench;
        this.orgNameEnglish = orgNameEnglish;
        this.orgNameFrench = orgNameFrench;
    }


    public DepartmentBean() {
    }

    public void setOrgDeptLocId(int orgDeptLocId) {
        this.orgDeptLocId = orgDeptLocId;
    }

    public void setOrgId(int orgId) {
        this.orgId = orgId;
    }

    public void setDepartmentNameEnglish(String departmentNameEnglish) {
        this.departmentNameEnglish = departmentNameEnglish;
    }

    public void setDepartmentNameFrench(String departmentNameFrench) {
        this.departmentNameFrench = departmentNameFrench;
    }

    public void setShortNameEnglish(String shortNameEnglish) {
        this.shortNameEnglish = shortNameEnglish;
    }

    public void setShortNameFrench(String shortNameFrench) {
        this.shortNameFrench = shortNameFrench;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public void setOrgNameEnglish(String orgNameEnglish) {

        this.orgNameEnglish = orgNameEnglish;
    }

    public void setOrgNameFrench(String orgNameFrench) {

        this.orgNameFrench = orgNameFrench;
    }

    public int getOrgDeptLocId() {
        return orgDeptLocId;
    }

    public int getOrgId() {
        return orgId;
    }

    public String getDepartmentNameEnglish() {
        return departmentNameEnglish;
    }

    public String getDepartmentNameFrench() {
        return departmentNameFrench;
    }

    public String getShortNameEnglish() {
        return shortNameEnglish;
    }

    public String getShortNameFrench() {
        return shortNameFrench;
    }

    public Integer getCode() {
        return code;
    }

    public String getOrgNameEnglish() {

        return orgNameEnglish;
    }

    public String getOrgNameFrench() {

        return orgNameFrench;
    }
}
