package ca.sshrc.web.common.util;

public class Constants {
    // Action outcomes
    public final static String SUCCESS_OUTCOME = "success";
    public final static String CANCEL_OUTCOME = "cancel";
    public final static String FAILURE_OUTCOME = "failure";
    public final static String ERROR_OUTCOME = "error";
    public final static String UPDATE_ERROR_OUTCOME = "update_error";
    public final static String DB_ERROR_OUTCOME = "db_error";
    public final static String SYSTEM_ERROR_OUTCOME = "system_error";
    public final static String VALIDATION_ERROR_OUTCOME = "validation_error";
    public final static String ACCOUNT_LOCKED_OUTCOME = "account_locked";
    public final static String ACCOUNT_PASSWORD_EXPIRED_OUTCOME = "account_password_expired";

    // Resource file name
    public final static String APPLICATION_RESOURCES = "ApplicationResources";
    public final static String RESOURCES_PREFIXE = "resources";
    public final static String CUSTOM_MESSAGES_RESOURCES = "CustomMessages";
    public final static String VALIDATION_ERROR_RESOURCES = "ValidationErrorResources";

    // Misc. values
    public final static String PRINT_URL_PB = "/cgi-bin/pbisa70.dll/sshrc_form/n_cst_form/of_p_print_form_no_val/";
    public final static String LOOKUP_CACHE_MANAGER = "lookUp";
    public final static String SYSTEM_CACHE_MANAGER = "systemCache";
    public final static String ENGLISH_CANADIAN_LOCALE = "en_CA";
    public final static String FRENCH_CANADIAN_LOCALE = "fr_CA";
    public final static String[] INVALID_CHARACTERS_IN_NUMERIC_FIELD = {" ",".",",","$"};

    // Default values
    public final static Integer MAX_LOGON_ATTEMPT = new Integer(3);
    public final static Integer DAYS_BETWEEN_PASSWORD_CHANGE = new Integer(90);
    // This was set to 300 so that many applications would show up during testing.
    public final static Integer DAYS_PORTFOLIO_HISTORY = new Integer(90);
    public final static Integer DAYS_PORTFOLIO_HISTORY_FINAL_REPORT = new Integer(1825); // 5 yrs = 1825 days
}

