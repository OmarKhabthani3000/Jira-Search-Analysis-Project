package ca.sshrc.web.forms.beans.portFolio;

import java.util.*;
import ca.sshrc.web.common.util.Constants;

public class PortFolioBean {
    private Integer web_id;
    private Integer appl_id;
    private Integer program_id;
    private Integer subSystem_id;
    private Long form_id;

    private String appl_title;
    private String letter_Of_Intent_Ind;
    private String grantType_f;
    private String grantType_e;

    private String formName_f;
    private String formName_e;
    private String formLanguage;
    private String form_Status;
    private Date change_Date;

    /* Default constructor*/
    public PortFolioBean() {
    }

    /* constructor for loading Application fields*/
    public PortFolioBean(Integer appl_id, Integer program_id, String appl_title,
                         Integer web_id, Integer subSystem_id,
                         String letter_Of_Intent_Ind, String grantType_f,
                         String grantType_e, String applTitle_f,
                         String applTitle_e, String form_Status,
                         String formLanguage, Date change_Date, Long form_ID) {
        this.appl_id = appl_id;
        this.program_id = program_id;
        this.appl_title = appl_title;
        this.web_id = web_id;
        this.subSystem_id = subSystem_id;
        this.letter_Of_Intent_Ind = letter_Of_Intent_Ind;

        if (null != grantType_f && grantType_f.trim().length() > 0) {
            this.formName_f = grantType_f + " - " + applTitle_f;
        } else {
            this.formName_f = applTitle_f;
        }
        if (null != grantType_e && grantType_e.trim().length() > 0) {
            this.formName_e = grantType_e + " - " + applTitle_e;
        } else {
            this.formName_e = applTitle_e;
        }

        if (formLanguage.trim().length() == 1) {
            if (formLanguage.equalsIgnoreCase("f")) {
                this.formLanguage = Constants.FRENCH_CANADIAN_LOCALE;
            } else {
                this.formLanguage = Constants.ENGLISH_CANADIAN_LOCALE;
            }
        } else {
            this.formLanguage = formLanguage;
        }

        this.form_Status = form_Status;
        this.change_Date = change_Date;
        this.form_id = form_ID;
    }

    /* constructor for loading CV fields*/
    public PortFolioBean(Integer web_id, Integer subSystem_id,
                         String form_Status,
                         String formLanguage, Date change_Date,
                         Long form_ID, Integer appl_id) {
        this.appl_id = new Integer(0);
        this.program_id = new Integer(0);
        this.appl_title = new String();
        this.web_id = web_id;
        this.subSystem_id = subSystem_id;
        this.letter_Of_Intent_Ind = new String();

        this.formName_f = new String();
        this.formName_e = new String();

        if (formLanguage.trim().length() == 1) {
            if (formLanguage.equalsIgnoreCase("f")) {
                this.formLanguage = Constants.FRENCH_CANADIAN_LOCALE;
            } else {
                this.formLanguage = Constants.ENGLISH_CANADIAN_LOCALE;
            }
        } else {
            this.formLanguage = formLanguage;
        }
        this.form_Status = form_Status;
        this.change_Date = change_Date;
        this.form_id = form_ID;
        this.appl_id = appl_id;

    }

    /* Setters */
    public void setAppl_id(Integer appl_id) {
        this.appl_id = appl_id;
    }

    public void setProgram_id(Integer program_id) {
        this.program_id = program_id;
    }

    public void setAppl_title(String appl_title) {
        this.appl_title = appl_title;
    }

    public void setWeb_id(Integer web_id) {
        this.web_id = web_id;
    }

    public void setSubSystem_id(Integer subsystem_id) {
        this.subSystem_id = subsystem_id;
    }

    public void setLetter_Of_Intent_Ind(String letter_Of_Intent_Ind) {
        this.letter_Of_Intent_Ind = letter_Of_Intent_Ind;
    }

    public void setGrantType_f(String grantType_f) {
        this.grantType_f = grantType_f;
    }

    public void setGrantTypeName_e(String grantTypeName_e) {
        this.grantType_e = grantTypeName_e;
    }

    public void setFormName_f(String formName_f) {
        this.formName_f = formName_f;
    }

    public void setFormName_e(String formName_e) {
        this.formName_e = formName_e;
    }

    public void setFormLanguage(String formLanguage) {
        this.formLanguage = formLanguage;
    }

    public void setForm_Status(String form_Status) {
        this.form_Status = form_Status;
    }

    public void setChange_Date(Date Change_Date) {
        this.change_Date = Change_Date;
    }

    public void setForm_id(Long form_ID) {
        this.form_id = form_ID;
    }

    /* Getters */
    public Integer getAppl_id() {
        return this.appl_id;
    }

    public Integer getProgram_id() {
        return this.program_id;
    }

    public String getAppl_title() {
        return this.appl_title;
    }

    public Integer getWeb_id() {
        return this.web_id;
    }

    public Integer getSubSystem_id() {
        return this.subSystem_id;
    }

    public String getLetter_Of_Intent_Ind() {
        return this.letter_Of_Intent_Ind;
    }

    public String getGrantTypeName_f() {
        return this.grantType_f;
    }

    public String getGrantTypeName_e() {
        return this.grantType_e;
    }

    public String getFormName() {
        if (this.formLanguage == Constants.FRENCH_CANADIAN_LOCALE) {
            return this.formName_f;
        } else {
            return this.formName_e;
        }
    }
    public String getFormName_f() {
        return this.formName_f;
    }

    public String getFormName_e() {
        return this.formName_e;
    }

    public String getFormLanguage() {
        return this.formLanguage;
    }

    public String getForm_Status() {
        return this.form_Status;
    }

    public Date getChange_Date() {
        return this.change_Date;
    }

    public Long getForm_id() {
        return this.form_id;
    }

}
