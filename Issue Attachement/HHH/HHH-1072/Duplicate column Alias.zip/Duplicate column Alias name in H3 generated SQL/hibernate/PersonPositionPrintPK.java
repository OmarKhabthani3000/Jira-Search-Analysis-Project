package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class PersonPositionPrintPK implements Serializable {

    /** identifier field */
    private Integer applId;

    /** identifier field */
    private Integer positionId;

    /** full constructor */
    public PersonPositionPrintPK(Integer applId, Integer positionId) {
        this.applId = applId;
        this.positionId = positionId;
    }

    /** default constructor */
    public PersonPositionPrintPK() {
    }

    public Integer getApplId() {
        return this.applId;
    }

    public void setApplId(Integer applId) {
        this.applId = applId;
    }

    public Integer getPositionId() {
        return this.positionId;
    }

    public void setPositionId(Integer positionId) {
        this.positionId = positionId;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("applId", getApplId())
            .append("positionId", getPositionId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof PersonPositionPrintPK) ) return false;
        PersonPositionPrintPK castOther = (PersonPositionPrintPK) other;
        return new EqualsBuilder()
            .append(this.getApplId(), castOther.getApplId())
            .append(this.getPositionId(), castOther.getPositionId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getApplId())
            .append(getPositionId())
            .toHashCode();
    }

}
