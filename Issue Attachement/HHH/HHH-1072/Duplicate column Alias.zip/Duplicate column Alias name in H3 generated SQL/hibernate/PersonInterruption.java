package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class PersonInterruption implements Serializable {

    /** identifier field */
    private hibernate.PersonInterruptionPK comp_id;

    /** nullable persistent field */
    private Date endDate;

    /** nullable persistent field */
    private String validInterruptionInd;

    /** nullable persistent field */
    private String note;

    /** nullable persistent field */
    private String createUserId;

    /** nullable persistent field */
    private Date createDate;

    /** nullable persistent field */
    private String changeUserId;

    /** nullable persistent field */
    private Date changeDate;

    /** full constructor */
    public PersonInterruption(hibernate.PersonInterruptionPK comp_id, Date endDate, String validInterruptionInd, String note, String createUserId, Date createDate, String changeUserId, Date changeDate) {
        this.comp_id = comp_id;
        this.endDate = endDate;
        this.validInterruptionInd = validInterruptionInd;
        this.note = note;
        this.createUserId = createUserId;
        this.createDate = createDate;
        this.changeUserId = changeUserId;
        this.changeDate = changeDate;
    }

    /** default constructor */
    public PersonInterruption() {
    }

    /** minimal constructor */
    public PersonInterruption(hibernate.PersonInterruptionPK comp_id) {
        this.comp_id = comp_id;
    }

    public hibernate.PersonInterruptionPK getComp_id() {
        return this.comp_id;
    }

    public void setComp_id(hibernate.PersonInterruptionPK comp_id) {
        this.comp_id = comp_id;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getValidInterruptionInd() {
        return this.validInterruptionInd;
    }

    public void setValidInterruptionInd(String validInterruptionInd) {
        this.validInterruptionInd = validInterruptionInd;
    }

    public String getNote() {
        return this.note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof PersonInterruption) ) return false;
        PersonInterruption castOther = (PersonInterruption) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
