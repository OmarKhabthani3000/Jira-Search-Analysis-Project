package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class Message implements Serializable {

    /** identifier field */
    private hibernate.MessagePK comp_id;

    /** persistent field */
    private String descriptionEnglish;

    /** nullable persistent field */
    private String descriptionFrench;

    /** full constructor */
    public Message(hibernate.MessagePK comp_id, String descriptionEnglish, String descriptionFrench) {
        this.comp_id = comp_id;
        this.descriptionEnglish = descriptionEnglish;
        this.descriptionFrench = descriptionFrench;
    }

    /** default constructor */
    public Message() {
    }

    /** minimal constructor */
    public Message(hibernate.MessagePK comp_id, String descriptionEnglish) {
        this.comp_id = comp_id;
        this.descriptionEnglish = descriptionEnglish;
    }

    public hibernate.MessagePK getComp_id() {
        return this.comp_id;
    }

    public void setComp_id(hibernate.MessagePK comp_id) {
        this.comp_id = comp_id;
    }

    public String getDescriptionEnglish() {
        return this.descriptionEnglish;
    }

    public void setDescriptionEnglish(String descriptionEnglish) {
        this.descriptionEnglish = descriptionEnglish;
    }

    public String getDescriptionFrench() {
        return this.descriptionFrench;
    }

    public void setDescriptionFrench(String descriptionFrench) {
        this.descriptionFrench = descriptionFrench;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof Message) ) return false;
        Message castOther = (Message) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
