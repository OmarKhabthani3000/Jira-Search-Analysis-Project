package hibernate;

import java.io.*;
import java.util.*;

import org.apache.commons.lang.builder.*;

/** @author Hibernate CodeGenerator */
public class PersonExpertise implements Serializable {

    /** identifier field */
    private Integer cid;

    /** nullable persistent field */
    private String keywords;

    /** nullable persistent field */
    private hibernate.Discipline disciplineCode1;

    /** nullable persistent field */
    private String otherDisciplineName1;

    /** nullable persistent field */
    private hibernate.Discipline disciplineCode2;

    /** nullable persistent field */
    private String otherDisciplineName2;

    /** nullable persistent field */
    private hibernate.Discipline disciplineCode3;

    /** nullable persistent field */
    private String otherDisciplineName3;

    /** nullable persistent field */
    private hibernate.Discipline disciplineCode4;

    /** nullable persistent field */
    private String otherDisciplineName4;

    /** nullable persistent field */
    private hibernate.Discipline disciplineCode5;

    /** nullable persistent field */
    private String otherDisciplineName5;

    /** nullable persistent field */
    private hibernate.Cod areaOfResearchCode1;

    /** nullable persistent field */
    private hibernate.Cod areaOfResearchCode2;

    /** nullable persistent field */
    private hibernate.Cod areaOfResearchCode3;

    /** nullable persistent field */
    private hibernate.Cod geoPoliticalCode1;

    /** nullable persistent field */
    private hibernate.Cod geoPoliticalCode2;

    /** nullable persistent field */
    private hibernate.Cod geoPoliticalCode3;

    /** nullable persistent field */
    private hibernate.Country countryCode1;

    /** nullable persistent field */
    private hibernate.ProvinceState provinceStateCode1;

    /** nullable persistent field */
    private hibernate.Country countryCode2;

    /** nullable persistent field */
    private hibernate.ProvinceState provinceStateCode2;

    /** nullable persistent field */
    private hibernate.Country countryCode3;

    /** nullable persistent field */
    private hibernate.ProvinceState provinceStateCode3;

    /** nullable persistent field */
    private hibernate.Country countryCode4;

    /** nullable persistent field */
    private hibernate.ProvinceState provinceStateCode4;

    /** nullable persistent field */
    private hibernate.Country countryCode5;

    /** nullable persistent field */
    private hibernate.ProvinceState provinceStateCode5;

    /** nullable persistent field */
    private Integer temporalStartYear1;

    /** nullable persistent field */
    private String temporalStartBcAd1;

    /** nullable persistent field */
    private Integer temporalEndYear1;

    /** nullable persistent field */
    private String temporalEndBcAd1;

    /** nullable persistent field */
    private Integer temporalStartYear2;

    /** nullable persistent field */
    private String temporalStartBcAd2;

    /** nullable persistent field */
    private Integer temporalEndYear2;

    /** nullable persistent field */
    private String temporalEndBcAd2;

    /** nullable persistent field */
    private Date createDate;

    /** nullable persistent field */
    private String createUserId;

    /** nullable persistent field */
    private Date changeDate;

    /** nullable persistent field */
    private String changeUserId;

    /** full constructor */
    public PersonExpertise(Integer cid, String keywords, hibernate.Discipline disciplineCode1, String otherDisciplineName1,
                           hibernate.Discipline disciplineCode2, String otherDisciplineName2, hibernate.Discipline disciplineCode3,
                           String otherDisciplineName3, hibernate.Discipline disciplineCode4, String otherDisciplineName4,
                           hibernate.Discipline disciplineCode5, String otherDisciplineName5, hibernate.Cod areaOfResearchCode1,
                           hibernate.Cod areaOfResearchCode2, hibernate.Cod areaOfResearchCode3,
                           hibernate.Cod geoPoliticalCode1, hibernate.Cod geoPoliticalCode2, hibernate.Cod geoPoliticalCode3,
                           hibernate.Country countryCode1, hibernate.ProvinceState provinceStateCode1, hibernate.Country countryCode2,
                           hibernate.ProvinceState provinceStateCode2, hibernate.Country countryCode3, hibernate.ProvinceState provinceStateCode3,
                           hibernate.Country countryCode4, hibernate.ProvinceState provinceStateCode4, hibernate.Country countryCode5,
                           hibernate.ProvinceState provinceStateCode5, Integer temporalStartYear1, String temporalStartBcAd1,
                           Integer temporalEndYear1, String temporalEndBcAd1, Integer temporalStartYear2,
                           String temporalStartBcAd2, Integer temporalEndYear2, String temporalEndBcAd2,
                           Date createDate, String createUserId, Date changeDate, String changeUserId
            ) {
        this.cid = cid;
        this.keywords = keywords;
        this.disciplineCode1 = disciplineCode1;
        this.otherDisciplineName1 = otherDisciplineName1;
        this.disciplineCode2 = disciplineCode2;
        this.otherDisciplineName2 = otherDisciplineName2;
        this.disciplineCode3 = disciplineCode3;
        this.otherDisciplineName3 = otherDisciplineName3;
        this.disciplineCode4 = disciplineCode4;
        this.otherDisciplineName4 = otherDisciplineName4;
        this.disciplineCode5 = disciplineCode5;
        this.otherDisciplineName5 = otherDisciplineName5;
        this.areaOfResearchCode1 = areaOfResearchCode1;
        this.areaOfResearchCode2 = areaOfResearchCode2;
        this.areaOfResearchCode3 = areaOfResearchCode3;
        this.geoPoliticalCode1 = geoPoliticalCode1;
        this.geoPoliticalCode2 = geoPoliticalCode2;
        this.geoPoliticalCode3 = geoPoliticalCode3;
        this.countryCode1 = countryCode1;
        this.provinceStateCode1 = provinceStateCode1;
        this.countryCode2 = countryCode2;
        this.provinceStateCode2 = provinceStateCode2;
        this.countryCode3 = countryCode3;
        this.provinceStateCode3 = provinceStateCode3;
        this.countryCode4 = countryCode4;
        this.provinceStateCode4 = provinceStateCode4;
        this.countryCode5 = countryCode5;
        this.provinceStateCode5 = provinceStateCode5;
        this.temporalStartYear1 = temporalStartYear1;
        this.temporalStartBcAd1 = temporalStartBcAd1;
        this.temporalEndYear1 = temporalEndYear1;
        this.temporalEndBcAd1 = temporalEndBcAd1;
        this.temporalStartYear2 = temporalStartYear2;
        this.temporalStartBcAd2 = temporalStartBcAd2;
        this.temporalEndYear2 = temporalEndYear2;
        this.temporalEndBcAd2 = temporalEndBcAd2;
        this.createDate = createDate;
        this.createUserId = createUserId;
        this.changeDate = changeDate;
        this.changeUserId = changeUserId;
    }

    /** default constructor */
    public PersonExpertise() {
    }

    /** minimal constructor */
    public PersonExpertise(Integer cid) {
        this.cid = cid;
    }

    public Integer getCid() {
        return this.cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public String getKeywords() {
        return this.keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public hibernate.Discipline getDisciplineCode1() {
        return this.disciplineCode1;
    }

    public void setDisciplineCode1(hibernate.Discipline disciplineCode1) {
        this.disciplineCode1 = disciplineCode1;
    }

    public String getOtherDisciplineName1() {
        return this.otherDisciplineName1;
    }

    public void setOtherDisciplineName1(String otherDisciplineName1) {
        this.otherDisciplineName1 = otherDisciplineName1;
    }

    public hibernate.Discipline getDisciplineCode2() {
        return this.disciplineCode2;
    }

    public void setDisciplineCode2(hibernate.Discipline disciplineCode2) {
        this.disciplineCode2 = disciplineCode2;
    }

    public String getOtherDisciplineName2() {
        return this.otherDisciplineName2;
    }

    public void setOtherDisciplineName2(String otherDisciplineName2) {
        this.otherDisciplineName2 = otherDisciplineName2;
    }

    public hibernate.Discipline getDisciplineCode3() {
        return this.disciplineCode3;
    }

    public void setDisciplineCode3(hibernate.Discipline disciplineCode3) {
        this.disciplineCode3 = disciplineCode3;
    }

    public String getOtherDisciplineName3() {
        return this.otherDisciplineName3;
    }

    public void setOtherDisciplineName3(String otherDisciplineName3) {
        this.otherDisciplineName3 = otherDisciplineName3;
    }

    public hibernate.Discipline getDisciplineCode4() {
        return this.disciplineCode4;
    }

    public void setDisciplineCode4(hibernate.Discipline disciplineCode4) {
        this.disciplineCode4 = disciplineCode4;
    }

    public String getOtherDisciplineName4() {
        return this.otherDisciplineName4;
    }

    public void setOtherDisciplineName4(String otherDisciplineName4) {
        this.otherDisciplineName4 = otherDisciplineName4;
    }

    public hibernate.Discipline getDisciplineCode5() {
        return this.disciplineCode5;
    }

    public void setDisciplineCode5(hibernate.Discipline disciplineCode5) {
        this.disciplineCode5 = disciplineCode5;
    }

    public String getOtherDisciplineName5() {
        return this.otherDisciplineName5;
    }

    public void setOtherDisciplineName5(String otherDisciplineName5) {
        this.otherDisciplineName5 = otherDisciplineName5;
    }

    public hibernate.Cod getAreaOfResearchCode1() {
        return this.areaOfResearchCode1;
    }

    public void setAreaOfResearchCode1(hibernate.Cod areaOfResearchCode1) {
        this.areaOfResearchCode1 = areaOfResearchCode1;
    }

    public hibernate.Cod getAreaOfResearchCode2() {
        return this.areaOfResearchCode2;
    }

    public void setAreaOfResearchCode2(hibernate.Cod areaOfResearchCode2) {
        this.areaOfResearchCode2 = areaOfResearchCode2;
    }

    public hibernate.Cod getAreaOfResearchCode3() {
        return this.areaOfResearchCode3;
    }

    public void setAreaOfResearchCode3(hibernate.Cod areaOfResearchCode3) {
        this.areaOfResearchCode3 = areaOfResearchCode3;
    }

    public hibernate.Cod getGeoPoliticalCode1() {
        return this.geoPoliticalCode1;
    }

    public void setGeoPoliticalCode1(hibernate.Cod geoPoliticalCode1) {
        this.geoPoliticalCode1 = geoPoliticalCode1;
    }

    public hibernate.Cod getGeoPoliticalCode2() {
        return this.geoPoliticalCode2;
    }

    public void setGeoPoliticalCode2(hibernate.Cod geoPoliticalCode2) {
        this.geoPoliticalCode2 = geoPoliticalCode2;
    }

    public hibernate.Cod getGeoPoliticalCode3() {
        return this.geoPoliticalCode3;
    }

    public void setGeoPoliticalCode3(hibernate.Cod geoPoliticalCode3) {
        this.geoPoliticalCode3 = geoPoliticalCode3;
    }

    public hibernate.Country getCountryCode1() {
        return this.countryCode1;
    }

    public void setCountryCode1(hibernate.Country countryCode1) {
        this.countryCode1 = countryCode1;
    }

    public hibernate.ProvinceState getProvinceStateCode1() {
        return this.provinceStateCode1;
    }

    public void setProvinceStateCode1(hibernate.ProvinceState provinceStateCode1) {
        this.provinceStateCode1 = provinceStateCode1;
    }

    public hibernate.Country getCountryCode2() {
        return this.countryCode2;
    }

    public void setCountryCode2(hibernate.Country countryCode2) {
        this.countryCode2 = countryCode2;
    }

    public hibernate.ProvinceState getProvinceStateCode2() {
        return this.provinceStateCode2;
    }

    public void setProvinceStateCode2(hibernate.ProvinceState provinceStateCode2) {
        this.provinceStateCode2 = provinceStateCode2;
    }

    public hibernate.Country getCountryCode3() {
        return this.countryCode3;
    }

    public void setCountryCode3(hibernate.Country countryCode3) {
        this.countryCode3 = countryCode3;
    }

    public hibernate.ProvinceState getProvinceStateCode3() {
        return this.provinceStateCode3;
    }

    public void setProvinceStateCode3(hibernate.ProvinceState provinceStateCode3) {
        this.provinceStateCode3 = provinceStateCode3;
    }

    public hibernate.Country getCountryCode4() {
        return this.countryCode4;
    }

    public void setCountryCode4(hibernate.Country countryCode4) {
        this.countryCode4 = countryCode4;
    }

    public hibernate.ProvinceState getProvinceStateCode4() {
        return this.provinceStateCode4;
    }

    public void setProvinceStateCode4(hibernate.ProvinceState provinceStateCode4) {
        this.provinceStateCode4 = provinceStateCode4;
    }

    public hibernate.Country getCountryCode5() {
        return this.countryCode5;
    }

    public void setCountryCode5(hibernate.Country countryCode5) {
        this.countryCode5 = countryCode5;
    }

    public hibernate.ProvinceState getProvinceStateCode5() {
        return this.provinceStateCode5;
    }

    public void setProvinceStateCode5(hibernate.ProvinceState provinceStateCode5) {
        this.provinceStateCode5 = provinceStateCode5;
    }

    public Integer getTemporalStartYear1() {
        return this.temporalStartYear1;
    }

    public void setTemporalStartYear1(Integer temporalStartYear1) {
        this.temporalStartYear1 = temporalStartYear1;
    }

    public String getTemporalStartBcAd1() {
        return this.temporalStartBcAd1;
    }

    public void setTemporalStartBcAd1(String temporalStartBcAd1) {
        this.temporalStartBcAd1 = temporalStartBcAd1;
    }

    public Integer getTemporalEndYear1() {
        return this.temporalEndYear1;
    }

    public void setTemporalEndYear1(Integer temporalEndYear1) {
        this.temporalEndYear1 = temporalEndYear1;
    }

    public String getTemporalEndBcAd1() {
        return this.temporalEndBcAd1;
    }

    public void setTemporalEndBcAd1(String temporalEndBcAd1) {
        this.temporalEndBcAd1 = temporalEndBcAd1;
    }

    public Integer getTemporalStartYear2() {
        return this.temporalStartYear2;
    }

    public void setTemporalStartYear2(Integer temporalStartYear2) {
        this.temporalStartYear2 = temporalStartYear2;
    }

    public String getTemporalStartBcAd2() {
        return this.temporalStartBcAd2;
    }

    public void setTemporalStartBcAd2(String temporalStartBcAd2) {
        this.temporalStartBcAd2 = temporalStartBcAd2;
    }

    public Integer getTemporalEndYear2() {
        return this.temporalEndYear2;
    }

    public void setTemporalEndYear2(Integer temporalEndYear2) {
        this.temporalEndYear2 = temporalEndYear2;
    }

    public String getTemporalEndBcAd2() {
        return this.temporalEndBcAd2;
    }

    public void setTemporalEndBcAd2(String temporalEndBcAd2) {
        this.temporalEndBcAd2 = temporalEndBcAd2;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public String toString() {
        return new ToStringBuilder(this)
                .append("cid", getCid())
                .toString();
    }

    public boolean equals(Object other) {
        if (!(other instanceof PersonExpertise)) {
            return false;
        }
        PersonExpertise castOther = (PersonExpertise) other;
        return new EqualsBuilder()
                .append(this.getCid(), castOther.getCid())
                .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
                .append(getCid())
                .toHashCode();
    }

}
