package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class SystemParameter implements Serializable {

    /** identifier field */
    private Integer parmId;

    /** nullable persistent field */
    private Short lastFiscalYearClosed;

    /** nullable persistent field */
    private String fyClosedChangeUserId;

    /** nullable persistent field */
    private Date fyClosedChangeDate;

    /** nullable persistent field */
    private String fyClosedCreateUserId;

    /** nullable persistent field */
    private Date fyClosedCreateDate;

    /** nullable persistent field */
    private Date lastT4aRunDate;

    /** full constructor */
    public SystemParameter(Integer parmId, Short lastFiscalYearClosed, String fyClosedChangeUserId, Date fyClosedChangeDate, String fyClosedCreateUserId, Date fyClosedCreateDate, Date lastT4aRunDate) {
        this.parmId = parmId;
        this.lastFiscalYearClosed = lastFiscalYearClosed;
        this.fyClosedChangeUserId = fyClosedChangeUserId;
        this.fyClosedChangeDate = fyClosedChangeDate;
        this.fyClosedCreateUserId = fyClosedCreateUserId;
        this.fyClosedCreateDate = fyClosedCreateDate;
        this.lastT4aRunDate = lastT4aRunDate;
    }

    /** default constructor */
    public SystemParameter() {
    }

    /** minimal constructor */
    public SystemParameter(Integer parmId) {
        this.parmId = parmId;
    }

    public Integer getParmId() {
        return this.parmId;
    }

    public void setParmId(Integer parmId) {
        this.parmId = parmId;
    }

    public Short getLastFiscalYearClosed() {
        return this.lastFiscalYearClosed;
    }

    public void setLastFiscalYearClosed(Short lastFiscalYearClosed) {
        this.lastFiscalYearClosed = lastFiscalYearClosed;
    }

    public String getFyClosedChangeUserId() {
        return this.fyClosedChangeUserId;
    }

    public void setFyClosedChangeUserId(String fyClosedChangeUserId) {
        this.fyClosedChangeUserId = fyClosedChangeUserId;
    }

    public Date getFyClosedChangeDate() {
        return this.fyClosedChangeDate;
    }

    public void setFyClosedChangeDate(Date fyClosedChangeDate) {
        this.fyClosedChangeDate = fyClosedChangeDate;
    }

    public String getFyClosedCreateUserId() {
        return this.fyClosedCreateUserId;
    }

    public void setFyClosedCreateUserId(String fyClosedCreateUserId) {
        this.fyClosedCreateUserId = fyClosedCreateUserId;
    }

    public Date getFyClosedCreateDate() {
        return this.fyClosedCreateDate;
    }

    public void setFyClosedCreateDate(Date fyClosedCreateDate) {
        this.fyClosedCreateDate = fyClosedCreateDate;
    }

    public Date getLastT4aRunDate() {
        return this.lastT4aRunDate;
    }

    public void setLastT4aRunDate(Date lastT4aRunDate) {
        this.lastT4aRunDate = lastT4aRunDate;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("parmId", getParmId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof SystemParameter) ) return false;
        SystemParameter castOther = (SystemParameter) other;
        return new EqualsBuilder()
            .append(this.getParmId(), castOther.getParmId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getParmId())
            .toHashCode();
    }

}
