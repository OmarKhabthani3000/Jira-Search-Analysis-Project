package hibernate;

import java.io.*;

import org.apache.commons.lang.builder.*;

/** @author Hibernate CodeGenerator */
public class WebModuleBeanClass implements Serializable {

    /** identifier field */
    private hibernate.WebModuleBeanClassPK comp_id;

    /** persistent field */
    private String beanClassNickName;

    /** persistent field */
    private String MessageResourceName;


    /** full constructor */
    public WebModuleBeanClass(hibernate.WebModuleBeanClassPK comp_id) {
        this.comp_id = comp_id;
    }

    /** default constructor */
    public WebModuleBeanClass() {
    }

    /** minimal constructor */
/*    public WebModuleBeanClass(hibernate.WebModuleBeanClassPK comp_id, String objectName) {
        this.comp_id = comp_id;
    }*/

    public hibernate.WebModuleBeanClassPK getComp_id() {
        return this.comp_id;
    }

    public String getBeanClassNickName() {
        return beanClassNickName;
    }

    public String getMessageResourceName() {
        return MessageResourceName;
    }

    public void setComp_id(hibernate.WebModuleBeanClassPK comp_id) {
        this.comp_id = comp_id;
    }

    public void setBeanClassNickName(String beanClassNickName) {
        this.beanClassNickName = beanClassNickName;
    }

    public void setMessageResourceName(String MessageResourceName) {
        this.MessageResourceName = MessageResourceName;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof WebModuleBeanClass) ) return false;
        WebModuleBeanClass castOther = (WebModuleBeanClass) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
