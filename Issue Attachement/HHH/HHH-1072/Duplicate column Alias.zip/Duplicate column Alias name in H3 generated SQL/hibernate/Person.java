package hibernate;

import java.io.*;
import java.util.*;

import org.apache.commons.lang.builder.*;

/** @author Hibernate CodeGenerator */
public class Person implements Serializable {

    /** identifier field */
    private Integer cid;

    /** nullable persistent field */
    private Integer amisCid;

    /** nullable persistent field */
    private String familyName;

    /** nullable persistent field */
    private String givenName;

    /** nullable persistent field */
    private String initials;

    /** nullable persistent field */
    private Integer salutation;

    /** nullable persistent field */
    private Short yearOfBirth;

    /** nullable persistent field */
    private Integer sin;

    /** nullable persistent field */
    private String sshrcEmployeeInd;

    /** nullable persistent field */
    private Integer personStatusCode;

    /** nullable persistent field */
    private Date statusChangeDate;

    /** nullable persistent field */
    private Integer primaryMailAddrId;

    /** nullable persistent field */
    private Integer primaryMailAddrPositionId;

    /** nullable persistent field */
    private String assessorInvitationInd;

    /** nullable persistent field */
    private String assessorWillingToServeInd;

    /** nullable persistent field */
    private Integer assessorOrgId;

    /** nullable persistent field */
    private String assessorNominatedBy;

    /** nullable persistent field */
    private Date assessorNominatedDate;

    /** nullable persistent field */
    private Date assessorUnavailableFromDate;

    /** nullable persistent field */
    private Date assessorUnavailableToDate;

    /** nullable persistent field */
    private String assessorRecommendationInd;

    /** nullable persistent field */
    private String comInvitationForServiceInd;

    /** nullable persistent field */
    private String comWillingToServeInd;

    /** nullable persistent field */
    private Date comUnavailableFromDate;

    /** nullable persistent field */
    private Date comUnavailableToDate;

    /** nullable persistent field */
    private Integer comAppointedToId;

    /** nullable persistent field */
    private Integer citizenshipType;

    /** nullable persistent field */
    private Country otherCountryCode;

    /** nullable persistent field */
    private Date landedOnDate;

    /** nullable persistent field */
    private String permResStatusInd;

    /** nullable persistent field */
    private Integer gender;

    /** persistent field */
    private String correspondenceLanguageCode;

    /** persistent field */
    private String readEnglish;

    /** nullable persistent field */
    private String writeEnglish;

    /** nullable persistent field */
    private String speakEnglish;

    /** nullable persistent field */
    private String auralEnglish;

    /** nullable persistent field */
    private String readFrench;

    /** nullable persistent field */
    private String writeFrench;

    /** nullable persistent field */
    private String speakFrench;

    /** nullable persistent field */
    private String auralFrench;

    /** nullable persistent field */
    private String otherLanguages;

    /** nullable persistent field */
    private Date cvUpdateDate;

    /** nullable persistent field */
    private String cvKeywords;

    /** nullable persistent field */
    private String officerKeywords;

    /** nullable persistent field */
    private String expertiseNote;

    /** nullable persistent field */
    private String includePeerReviewInd;

    /** nullable persistent field */
    private String phoneCountryCode;

    /** nullable persistent field */
    private String phoneAreaCode;

    /** nullable persistent field */
    private String phoneNumber;

    /** nullable persistent field */
    private String phoneExtension;

    /** nullable persistent field */
    private String tmpPhoneCountryCode;

    /** nullable persistent field */
    private String tmpPhoneAreaCode;

    /** nullable persistent field */
    private String tmpPhoneNumber;

    /** nullable persistent field */
    private String tmpPhoneExtension;

    /** nullable persistent field */
    private String secPhoneCountryCode;

    /** nullable persistent field */
    private String secPhoneAreaCode;

    /** nullable persistent field */
    private String secPhoneNumber;

    /** nullable persistent field */
    private String secPhoneExtension;

    /** nullable persistent field */
    private String faxPhoneCountryCode;

    /** nullable persistent field */
    private String faxAreaCode;

    /** nullable persistent field */
    private String faxNumber;

    /** nullable persistent field */
    private String faxPhoneExtension;

    /** nullable persistent field */
    private String tmpFaxCountryCode;

    /** nullable persistent field */
    private String tmpFaxPhoneAreaCode;

    /** nullable persistent field */
    private String tmpFaxPhoneNumber;

    /** nullable persistent field */
    private String tmpFaxPhoneExtension;

    /** nullable persistent field */
    private String secFaxCountryCode;

    /** nullable persistent field */
    private String secFaxAreaCode;

    /** nullable persistent field */
    private String secFaxNumber;

    /** nullable persistent field */
    private String secFaxExtension;

    /** nullable persistent field */
    private String emailAddress;

    /** nullable persistent field */
    private String tmpEmailAddress;

    /** nullable persistent field */
    private String scndEmailAddress;

    /** nullable persistent field */
    private Date allTmpControlDateFrom;

    /** nullable persistent field */
    private Date allTmpControlDateTo;

    /** persistent field */
    private String createUserId;

    /** persistent field */
    private Date createDate;

    /** persistent field */
    private String changeUserId;

    /** persistent field */
    private Date changeDate;

    /** nullable persistent field */
    private String newPersonInd;

    /** nullable persistent field */
    private String alias;

    /** nullable persistent field */
    private String personConsentInd;

    /** nullable persistent field */
    private String transferredToAmisInd;

    /** nullable persistent field */
    private Date transferredDate;

    /** nullable persistent field */
    private String postalCode;

    /** nullable persistent field */
    private String formStatus;

    /** nullable persistent field */
    private String formLanguage;

    /** nullable persistent field */
    private String landedYear;

    /** nullable persistent field */
    private String landedMonth;

    /** nullable persistent field */
    private String landedDay;

    /** nullable persistent field */
    private Date lastAccessDate;

    /** nullable persistent field */
    private String previousFamilyName;

    private Set personPosition = new HashSet();

    private Set personAddress = new HashSet();

    private Set personAcademicBackground = new HashSet();

    private Set personExpertise = new HashSet();

    private Set personResearchSupport = new HashSet();

    /** full constructor */
    public Person(Integer cid, Integer amisCid, String familyName, String givenName, String initials,
                  Integer salutation, Short yearOfBirth, Integer sin, String sshrcEmployeeInd,
                  Integer personStatusCode, Date statusChangeDate, Integer primaryMailAddrId,
                  Integer primaryMailAddrPositionId, String assessorInvitationInd,
                  String assessorWillingToServeInd, Integer assessorOrgId, String assessorNominatedBy,
                  Date assessorNominatedDate, Date assessorUnavailableFromDate,
                  Date assessorUnavailableToDate, String assessorRecommendationInd,
                  String comInvitationForServiceInd, String comWillingToServeInd, Date comUnavailableFromDate,
                  Date comUnavailableToDate, Integer comAppointedToId, Integer citizenshipType,
                  Country otherCountryCode, Date landedOnDate, String permResStatusInd, Integer gender,
                  String correspondenceLanguageCode, String readEnglish, String writeEnglish,
                  String speakEnglish, String auralEnglish, String readFrench, String writeFrench,
                  String speakFrench, String auralFrench, String otherLanguages, Date cvUpdateDate,
                  String cvKeywords, String officerKeywords, String expertiseNote,
                  String includePeerReviewInd, String phoneCountryCode, String phoneAreaCode,
                  String phoneNumber, String phoneExtension, String tmpPhoneCountryCode,
                  String tmpPhoneAreaCode, String tmpPhoneNumber, String tmpPhoneExtension,
                  String secPhoneCountryCode, String secPhoneAreaCode, String secPhoneNumber,
                  String secPhoneExtension, String faxPhoneCountryCode, String faxAreaCode, String faxNumber,
                  String faxPhoneExtension, String tmpFaxCountryCode, String tmpFaxPhoneAreaCode,
                  String tmpFaxPhoneNumber, String tmpFaxPhoneExtension, String secFaxCountryCode,
                  String secFaxAreaCode, String secFaxNumber, String secFaxExtension, String emailAddress,
                  String tmpEmailAddress, String scndEmailAddress, Date allTmpControlDateFrom,
                  Date allTmpControlDateTo, String createUserId, Date createDate, String changeUserId,
                  Date changeDate, String newPersonInd, String alias, String personConsentInd,
                  String transferredToAmisInd, Date transferredDate, String postalCode, String
                  formStatus, String formLanguage, String landedYear, String landedMonth, String landedDay,
                  Date lastAccessDate, String previousFamilyName, Set personPosition, Set personAddress,
                  Set personExpertise, Set personResearchSupport) {
        this.cid = cid;
        this.amisCid = amisCid;
        this.familyName = familyName;
        this.givenName = givenName;
        this.initials = initials;
        this.salutation = salutation;
        this.yearOfBirth = yearOfBirth;
        this.sin = sin;
        this.sshrcEmployeeInd = sshrcEmployeeInd;
        this.personStatusCode = personStatusCode;
        this.statusChangeDate = statusChangeDate;
        this.primaryMailAddrId = primaryMailAddrId;
        this.primaryMailAddrPositionId = primaryMailAddrPositionId;
        this.assessorInvitationInd = assessorInvitationInd;
        this.assessorWillingToServeInd = assessorWillingToServeInd;
        this.assessorOrgId = assessorOrgId;
        this.assessorNominatedBy = assessorNominatedBy;
        this.assessorNominatedDate = assessorNominatedDate;
        this.assessorUnavailableFromDate = assessorUnavailableFromDate;
        this.assessorUnavailableToDate = assessorUnavailableToDate;
        this.assessorRecommendationInd = assessorRecommendationInd;
        this.comInvitationForServiceInd = comInvitationForServiceInd;
        this.comWillingToServeInd = comWillingToServeInd;
        this.comUnavailableFromDate = comUnavailableFromDate;
        this.comUnavailableToDate = comUnavailableToDate;
        this.comAppointedToId = comAppointedToId;
        this.citizenshipType = citizenshipType;
        this.otherCountryCode = otherCountryCode;
        this.landedOnDate = landedOnDate;
        this.permResStatusInd = permResStatusInd;
        this.gender = gender;
        this.correspondenceLanguageCode = correspondenceLanguageCode;
        this.readEnglish = readEnglish;
        this.writeEnglish = writeEnglish;
        this.speakEnglish = speakEnglish;
        this.auralEnglish = auralEnglish;
        this.readFrench = readFrench;
        this.writeFrench = writeFrench;
        this.speakFrench = speakFrench;
        this.auralFrench = auralFrench;
        this.otherLanguages = otherLanguages;
        this.cvUpdateDate = cvUpdateDate;
        this.cvKeywords = cvKeywords;
        this.officerKeywords = officerKeywords;
        this.expertiseNote = expertiseNote;
        this.includePeerReviewInd = includePeerReviewInd;
        this.phoneCountryCode = phoneCountryCode;
        this.phoneAreaCode = phoneAreaCode;
        this.phoneNumber = phoneNumber;
        this.phoneExtension = phoneExtension;
        this.tmpPhoneCountryCode = tmpPhoneCountryCode;
        this.tmpPhoneAreaCode = tmpPhoneAreaCode;
        this.tmpPhoneNumber = tmpPhoneNumber;
        this.tmpPhoneExtension = tmpPhoneExtension;
        this.secPhoneCountryCode = secPhoneCountryCode;
        this.secPhoneAreaCode = secPhoneAreaCode;
        this.secPhoneNumber = secPhoneNumber;
        this.secPhoneExtension = secPhoneExtension;
        this.faxPhoneCountryCode = faxPhoneCountryCode;
        this.faxAreaCode = faxAreaCode;
        this.faxNumber = faxNumber;
        this.faxPhoneExtension = faxPhoneExtension;
        this.tmpFaxCountryCode = tmpFaxCountryCode;
        this.tmpFaxPhoneAreaCode = tmpFaxPhoneAreaCode;
        this.tmpFaxPhoneNumber = tmpFaxPhoneNumber;
        this.tmpFaxPhoneExtension = tmpFaxPhoneExtension;
        this.secFaxCountryCode = secFaxCountryCode;
        this.secFaxAreaCode = secFaxAreaCode;
        this.secFaxNumber = secFaxNumber;
        this.secFaxExtension = secFaxExtension;
        this.emailAddress = emailAddress;
        this.tmpEmailAddress = tmpEmailAddress;
        this.scndEmailAddress = scndEmailAddress;
        this.allTmpControlDateFrom = allTmpControlDateFrom;
        this.allTmpControlDateTo = allTmpControlDateTo;
        this.createUserId = createUserId;
        this.createDate = createDate;
        this.changeUserId = changeUserId;
        this.changeDate = changeDate;
        this.newPersonInd = newPersonInd;
        this.alias = alias;
        this.personConsentInd = personConsentInd;
        this.transferredToAmisInd = transferredToAmisInd;
        this.transferredDate = transferredDate;
        this.postalCode = postalCode;
        this.formStatus = formStatus;
        this.formLanguage = formLanguage;
        this.landedYear = landedYear;
        this.landedMonth = landedMonth;
        this.landedDay = landedDay;
        this.lastAccessDate = lastAccessDate;
        this.previousFamilyName = previousFamilyName;
        this.personPosition = personPosition;
        this.personAddress = personAddress;
        this.personExpertise = personExpertise;
        this.personResearchSupport = personResearchSupport;
    }

    /** default constructor */
    public Person() {
        this.readEnglish = "N";
    }

    /** minimal constructor */
    public Person(Integer cid, String correspondenceLanguageCode, String readEnglish, String createUserId,
                  Date createDate, String changeUserId, Date changeDate) {
        this.cid = cid;
        this.correspondenceLanguageCode = correspondenceLanguageCode;
        this.readEnglish = readEnglish;
        this.createUserId = createUserId;
        this.createDate = createDate;
        this.changeUserId = changeUserId;
        this.changeDate = changeDate;
    }

    public Integer getCid() {
        return this.cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public Integer getAmisCid() {
        return this.amisCid;
    }

    public void setAmisCid(Integer amisCid) {
        this.amisCid = amisCid;
    }

    public String getFamilyName() {
        return this.familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getGivenName() {
        return this.givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getInitials() {
        return this.initials;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public Integer getSalutation() {
        return this.salutation;
    }

    public void setSalutation(Integer salutation) {
        this.salutation = salutation;
    }

    public Short getYearOfBirth() {
        return this.yearOfBirth;
    }

    public void setYearOfBirth(Short yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    public Integer getSin() {
        return this.sin;
    }

    public void setSin(Integer sin) {
        this.sin = sin;
    }

    public String getSshrcEmployeeInd() {
        return this.sshrcEmployeeInd;
    }

    public void setSshrcEmployeeInd(String sshrcEmployeeInd) {
        this.sshrcEmployeeInd = sshrcEmployeeInd;
    }

    public Integer getPersonStatusCode() {
        return this.personStatusCode;
    }

    public void setPersonStatusCode(Integer personStatusCode) {
        this.personStatusCode = personStatusCode;
    }

    public Date getStatusChangeDate() {
        return this.statusChangeDate;
    }

    public void setStatusChangeDate(Date statusChangeDate) {
        this.statusChangeDate = statusChangeDate;
    }

    public Integer getPrimaryMailAddrId() {
        return this.primaryMailAddrId;
    }

    public void setPrimaryMailAddrId(Integer primaryMailAddrId) {
        this.primaryMailAddrId = primaryMailAddrId;
    }

    public Integer getPrimaryMailAddrPositionId() {
        return this.primaryMailAddrPositionId;
    }

    public void setPrimaryMailAddrPositionId(Integer primaryMailAddrPositionId) {
        this.primaryMailAddrPositionId = primaryMailAddrPositionId;
    }

    public String getAssessorInvitationInd() {
        return this.assessorInvitationInd;
    }

    public void setAssessorInvitationInd(String assessorInvitationInd) {
        this.assessorInvitationInd = assessorInvitationInd;
    }

    public String getAssessorWillingToServeInd() {
        return this.assessorWillingToServeInd;
    }

    public void setAssessorWillingToServeInd(String assessorWillingToServeInd) {
        this.assessorWillingToServeInd = assessorWillingToServeInd;
    }

    public Integer getAssessorOrgId() {
        return this.assessorOrgId;
    }

    public void setAssessorOrgId(Integer assessorOrgId) {
        this.assessorOrgId = assessorOrgId;
    }

    public String getAssessorNominatedBy() {
        return this.assessorNominatedBy;
    }

    public void setAssessorNominatedBy(String assessorNominatedBy) {
        this.assessorNominatedBy = assessorNominatedBy;
    }

    public Date getAssessorNominatedDate() {
        return this.assessorNominatedDate;
    }

    public void setAssessorNominatedDate(Date assessorNominatedDate) {
        this.assessorNominatedDate = assessorNominatedDate;
    }

    public Date getAssessorUnavailableFromDate() {
        return this.assessorUnavailableFromDate;
    }

    public void setAssessorUnavailableFromDate(Date assessorUnavailableFromDate) {
        this.assessorUnavailableFromDate = assessorUnavailableFromDate;
    }

    public Date getAssessorUnavailableToDate() {
        return this.assessorUnavailableToDate;
    }

    public void setAssessorUnavailableToDate(Date assessorUnavailableToDate) {
        this.assessorUnavailableToDate = assessorUnavailableToDate;
    }

    public String getAssessorRecommendationInd() {
        return this.assessorRecommendationInd;
    }

    public void setAssessorRecommendationInd(String assessorRecommendationInd) {
        this.assessorRecommendationInd = assessorRecommendationInd;
    }

    public String getComInvitationForServiceInd() {
        return this.comInvitationForServiceInd;
    }

    public void setComInvitationForServiceInd(String comInvitationForServiceInd) {
        this.comInvitationForServiceInd = comInvitationForServiceInd;
    }

    public String getComWillingToServeInd() {
        return this.comWillingToServeInd;
    }

    public void setComWillingToServeInd(String comWillingToServeInd) {
        this.comWillingToServeInd = comWillingToServeInd;
    }

    public Date getComUnavailableFromDate() {
        return this.comUnavailableFromDate;
    }

    public void setComUnavailableFromDate(Date comUnavailableFromDate) {
        this.comUnavailableFromDate = comUnavailableFromDate;
    }

    public Date getComUnavailableToDate() {
        return this.comUnavailableToDate;
    }

    public void setComUnavailableToDate(Date comUnavailableToDate) {
        this.comUnavailableToDate = comUnavailableToDate;
    }

    public Integer getComAppointedToId() {
        return this.comAppointedToId;
    }

    public void setComAppointedToId(Integer comAppointedToId) {
        this.comAppointedToId = comAppointedToId;
    }

    public Integer getCitizenshipType() {
        return this.citizenshipType;
    }

    public void setCitizenshipType(Integer citizenshipType) {
        this.citizenshipType = citizenshipType;
    }

    public Country getOtherCountryCode() {
        return this.otherCountryCode;
    }

    public void setOtherCountryCode(Country otherCountryCode) {
        this.otherCountryCode = otherCountryCode;
    }

    public Date getLandedOnDate() {
        return this.landedOnDate;
    }

    public void setLandedOnDate(Date landedOnDate) {
        this.landedOnDate = landedOnDate;
    }

    public String getPermResStatusInd() {
        return this.permResStatusInd;
    }

    public void setPermResStatusInd(String permResStatusInd) {
        this.permResStatusInd = permResStatusInd;
    }

    public Integer getGender() {
        return this.gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public String getCorrespondenceLanguageCode() {
        return this.correspondenceLanguageCode;
    }

    public void setCorrespondenceLanguageCode(String correspondenceLanguageCode) {
        this.correspondenceLanguageCode = correspondenceLanguageCode;
    }

    public String getReadEnglish() {
        return this.readEnglish;
    }

    public void setReadEnglish(String readEnglish) {
        this.readEnglish = readEnglish;
    }

    public String getWriteEnglish() {
        return this.writeEnglish;
    }

    public void setWriteEnglish(String writeEnglish) {
        this.writeEnglish = writeEnglish;
    }

    public String getSpeakEnglish() {
        return this.speakEnglish;
    }

    public void setSpeakEnglish(String speakEnglish) {
        this.speakEnglish = speakEnglish;
    }

    public String getAuralEnglish() {
        return this.auralEnglish;
    }

    public void setAuralEnglish(String auralEnglish) {
        this.auralEnglish = auralEnglish;
    }

    public String getReadFrench() {
        return this.readFrench;
    }

    public void setReadFrench(String readFrench) {
        this.readFrench = readFrench;
    }

    public String getWriteFrench() {
        return this.writeFrench;
    }

    public void setWriteFrench(String writeFrench) {
        this.writeFrench = writeFrench;
    }

    public String getSpeakFrench() {
        return this.speakFrench;
    }

    public void setSpeakFrench(String speakFrench) {
        this.speakFrench = speakFrench;
    }

    public String getAuralFrench() {
        return this.auralFrench;
    }

    public void setAuralFrench(String auralFrench) {
        this.auralFrench = auralFrench;
    }

    public String getOtherLanguages() {
        return this.otherLanguages;
    }

    public void setOtherLanguages(String otherLanguages) {
        this.otherLanguages = otherLanguages;
    }

    public Date getCvUpdateDate() {
        return this.cvUpdateDate;
    }

    public void setCvUpdateDate(Date cvUpdateDate) {
        this.cvUpdateDate = cvUpdateDate;
    }

    public String getCvKeywords() {
        return this.cvKeywords;
    }

    public void setCvKeywords(String cvKeywords) {
        this.cvKeywords = cvKeywords;
    }

    public String getOfficerKeywords() {
        return this.officerKeywords;
    }

    public void setOfficerKeywords(String officerKeywords) {
        this.officerKeywords = officerKeywords;
    }

    public String getExpertiseNote() {
        return this.expertiseNote;
    }

    public void setExpertiseNote(String expertiseNote) {
        this.expertiseNote = expertiseNote;
    }

    public String getIncludePeerReviewInd() {
        return this.includePeerReviewInd;
    }

    public void setIncludePeerReviewInd(String includePeerReviewInd) {
        this.includePeerReviewInd = includePeerReviewInd;
    }

    public String getPhoneCountryCode() {
        return this.phoneCountryCode;
    }

    public void setPhoneCountryCode(String phoneCountryCode) {
        this.phoneCountryCode = phoneCountryCode;
    }

    public String getPhoneAreaCode() {
        return this.phoneAreaCode;
    }

    public void setPhoneAreaCode(String phoneAreaCode) {
        this.phoneAreaCode = phoneAreaCode;
    }

    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPhoneExtension() {
        return this.phoneExtension;
    }

    public void setPhoneExtension(String phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public String getTmpPhoneCountryCode() {
        return this.tmpPhoneCountryCode;
    }

    public void setTmpPhoneCountryCode(String tmpPhoneCountryCode) {
        this.tmpPhoneCountryCode = tmpPhoneCountryCode;
    }

    public String getTmpPhoneAreaCode() {
        return this.tmpPhoneAreaCode;
    }

    public void setTmpPhoneAreaCode(String tmpPhoneAreaCode) {
        this.tmpPhoneAreaCode = tmpPhoneAreaCode;
    }

    public String getTmpPhoneNumber() {
        return this.tmpPhoneNumber;
    }

    public void setTmpPhoneNumber(String tmpPhoneNumber) {
        this.tmpPhoneNumber = tmpPhoneNumber;
    }

    public String getTmpPhoneExtension() {
        return this.tmpPhoneExtension;
    }

    public void setTmpPhoneExtension(String tmpPhoneExtension) {
        this.tmpPhoneExtension = tmpPhoneExtension;
    }

    public String getSecPhoneCountryCode() {
        return this.secPhoneCountryCode;
    }

    public void setSecPhoneCountryCode(String secPhoneCountryCode) {
        this.secPhoneCountryCode = secPhoneCountryCode;
    }

    public String getSecPhoneAreaCode() {
        return this.secPhoneAreaCode;
    }

    public void setSecPhoneAreaCode(String secPhoneAreaCode) {
        this.secPhoneAreaCode = secPhoneAreaCode;
    }

    public String getSecPhoneNumber() {
        return this.secPhoneNumber;
    }

    public void setSecPhoneNumber(String secPhoneNumber) {
        this.secPhoneNumber = secPhoneNumber;
    }

    public String getSecPhoneExtension() {
        return this.secPhoneExtension;
    }

    public void setSecPhoneExtension(String secPhoneExtension) {
        this.secPhoneExtension = secPhoneExtension;
    }

    public String getFaxPhoneCountryCode() {
        return this.faxPhoneCountryCode;
    }

    public void setFaxPhoneCountryCode(String faxPhoneCountryCode) {
        this.faxPhoneCountryCode = faxPhoneCountryCode;
    }

    public String getFaxAreaCode() {
        return this.faxAreaCode;
    }

    public void setFaxAreaCode(String faxAreaCode) {
        this.faxAreaCode = faxAreaCode;
    }

    public String getFaxNumber() {
        return this.faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public String getFaxPhoneExtension() {
        return this.faxPhoneExtension;
    }

    public void setFaxPhoneExtension(String faxPhoneExtension) {
        this.faxPhoneExtension = faxPhoneExtension;
    }

    public String getTmpFaxCountryCode() {
        return this.tmpFaxCountryCode;
    }

    public void setTmpFaxCountryCode(String tmpFaxCountryCode) {
        this.tmpFaxCountryCode = tmpFaxCountryCode;
    }

    public String getTmpFaxPhoneAreaCode() {
        return this.tmpFaxPhoneAreaCode;
    }

    public void setTmpFaxPhoneAreaCode(String tmpFaxPhoneAreaCode) {
        this.tmpFaxPhoneAreaCode = tmpFaxPhoneAreaCode;
    }

    public String getTmpFaxPhoneNumber() {
        return this.tmpFaxPhoneNumber;
    }

    public void setTmpFaxPhoneNumber(String tmpFaxPhoneNumber) {
        this.tmpFaxPhoneNumber = tmpFaxPhoneNumber;
    }

    public String getTmpFaxPhoneExtension() {
        return this.tmpFaxPhoneExtension;
    }

    public void setTmpFaxPhoneExtension(String tmpFaxPhoneExtension) {
        this.tmpFaxPhoneExtension = tmpFaxPhoneExtension;
    }

    public String getSecFaxCountryCode() {
        return this.secFaxCountryCode;
    }

    public void setSecFaxCountryCode(String secFaxCountryCode) {
        this.secFaxCountryCode = secFaxCountryCode;
    }

    public String getSecFaxAreaCode() {
        return this.secFaxAreaCode;
    }

    public void setSecFaxAreaCode(String secFaxAreaCode) {
        this.secFaxAreaCode = secFaxAreaCode;
    }

    public String getSecFaxNumber() {
        return this.secFaxNumber;
    }

    public void setSecFaxNumber(String secFaxNumber) {
        this.secFaxNumber = secFaxNumber;
    }

    public String getSecFaxExtension() {
        return this.secFaxExtension;
    }

    public void setSecFaxExtension(String secFaxExtension) {
        this.secFaxExtension = secFaxExtension;
    }

    public String getEmailAddress() {
        return this.emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getTmpEmailAddress() {
        return this.tmpEmailAddress;
    }

    public void setTmpEmailAddress(String tmpEmailAddress) {
        this.tmpEmailAddress = tmpEmailAddress;
    }

    public String getScndEmailAddress() {
        return this.scndEmailAddress;
    }

    public void setScndEmailAddress(String scndEmailAddress) {
        this.scndEmailAddress = scndEmailAddress;
    }

    public Date getAllTmpControlDateFrom() {
        return this.allTmpControlDateFrom;
    }

    public void setAllTmpControlDateFrom(Date allTmpControlDateFrom) {
        this.allTmpControlDateFrom = allTmpControlDateFrom;
    }

    public Date getAllTmpControlDateTo() {
        return this.allTmpControlDateTo;
    }

    public void setAllTmpControlDateTo(Date allTmpControlDateTo) {
        this.allTmpControlDateTo = allTmpControlDateTo;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getNewPersonInd() {
        return this.newPersonInd;
    }

    public void setNewPersonInd(String newPersonInd) {
        this.newPersonInd = newPersonInd;
    }

    public String getAlias() {
        return this.alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getPersonConsentInd() {
        return this.personConsentInd;
    }

    public void setPersonConsentInd(String personConsentInd) {
        this.personConsentInd = personConsentInd;
    }

    public String getTransferredToAmisInd() {
        return this.transferredToAmisInd;
    }

    public void setTransferredToAmisInd(String transferredToAmisInd) {
        this.transferredToAmisInd = transferredToAmisInd;
    }

    public Date getTransferredDate() {
        return this.transferredDate;
    }

    public void setTransferredDate(Date transferredDate) {
        this.transferredDate = transferredDate;
    }

    public String getPostalCode() {
        return this.postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getFormStatus() {
        return this.formStatus;
    }

    public void setFormStatus(String formStatus) {
        this.formStatus = formStatus;
    }

    public String getFormLanguage() {
        return this.formLanguage;
    }

    public void setFormLanguage(String formLanguage) {
        this.formLanguage = formLanguage;
    }

    public String getLandedYear() {
        return this.landedYear;
    }

    public void setLandedYear(String landedYear) {
        this.landedYear = landedYear;
    }

    public String getLandedMonth() {
        return this.landedMonth;
    }

    public void setLandedMonth(String landedMonth) {
        this.landedMonth = landedMonth;
    }

    public String getLandedDay() {
        return this.landedDay;
    }

    public void setLandedDay(String landedDay) {
        this.landedDay = landedDay;
    }

    public Date getLastAccessDate() {
        return this.lastAccessDate;
    }

    public void setLastAccessDate(Date lastAccessDate) {
        this.lastAccessDate = lastAccessDate;
    }

    public String getPreviousFamilyName() {
        return this.previousFamilyName;
    }

    public Set getPersonPosition() {
        return personPosition;
    }

    public Set getPersonAddress() {
        return personAddress;
    }

    public Set getPersonAcademicBackground() {
        return personAcademicBackground;
    }

    public Set getPersonExpertise() {
        return personExpertise;
    }

    public Set getPersonResearchSupport() {
        return personResearchSupport;
    }

    public void setPreviousFamilyName(String previousFamilyName) {
        this.previousFamilyName = previousFamilyName;
    }

    public void setPersonPosition(Set personPosition) {
        this.personPosition = personPosition;
    }

    public void setPersonAddress(Set personAddress) {
        this.personAddress = personAddress;
    }

    public void setPersonAcademicBackground(Set personAcademicBackground) {
        this.personAcademicBackground = personAcademicBackground;
    }

    public void setPersonExpertise(Set personExpertise) {
        this.personExpertise = personExpertise;
    }

    public void setPersonResearchSupport(Set personResearchSupport) {
        this.personResearchSupport = personResearchSupport;
    }

    public String toString() {
        return new ToStringBuilder(this)
                .append("cid", getCid())
                .toString();
    }

    public boolean equals(Object other) {
        if (!(other instanceof Person)) {
            return false;
        }
        Person castOther = (Person) other;
        return new EqualsBuilder()
                .append(this.getCid(), castOther.getCid())
                .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
                .append(getCid())
                .toHashCode();
    }

}
