package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class CodesCategoryGroup implements Serializable {

    /** identifier field */
    private Integer subGroup;

    /** persistent field */
    private String subGroupName;

    /** nullable persistent field */
    private String activeInd;

    /** nullable persistent field */
    private String amisUsageInd;

    /** nullable persistent field */
    private String webUsageInd;

    /** nullable persistent field */
    private String comments;

    /** persistent field */
    private Date createDate;

    /** persistent field */
    private String createUserId;

    /** persistent field */
    private Date changeDate;

    /** persistent field */
    private String changeUserId;

    /** full constructor */
    public CodesCategoryGroup(Integer subGroup, String subGroupName, String activeInd, String amisUsageInd, String webUsageInd, String comments, Date createDate, String createUserId, Date changeDate, String changeUserId) {
        this.subGroup = subGroup;
        this.subGroupName = subGroupName;
        this.activeInd = activeInd;
        this.amisUsageInd = amisUsageInd;
        this.webUsageInd = webUsageInd;
        this.comments = comments;
        this.createDate = createDate;
        this.createUserId = createUserId;
        this.changeDate = changeDate;
        this.changeUserId = changeUserId;
    }

    /** default constructor */
    public CodesCategoryGroup() {
    }

    /** minimal constructor */
    public CodesCategoryGroup(Integer subGroup, String subGroupName, Date createDate, String createUserId, Date changeDate, String changeUserId) {
        this.subGroup = subGroup;
        this.subGroupName = subGroupName;
        this.createDate = createDate;
        this.createUserId = createUserId;
        this.changeDate = changeDate;
        this.changeUserId = changeUserId;
    }

    public Integer getSubGroup() {
        return this.subGroup;
    }

    public void setSubGroup(Integer subGroup) {
        this.subGroup = subGroup;
    }

    public String getSubGroupName() {
        return this.subGroupName;
    }

    public void setSubGroupName(String subGroupName) {
        this.subGroupName = subGroupName;
    }

    public String getActiveInd() {
        return this.activeInd;
    }

    public void setActiveInd(String activeInd) {
        this.activeInd = activeInd;
    }

    public String getAmisUsageInd() {
        return this.amisUsageInd;
    }

    public void setAmisUsageInd(String amisUsageInd) {
        this.amisUsageInd = amisUsageInd;
    }

    public String getWebUsageInd() {
        return this.webUsageInd;
    }

    public void setWebUsageInd(String webUsageInd) {
        this.webUsageInd = webUsageInd;
    }

    public String getComments() {
        return this.comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("subGroup", getSubGroup())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof CodesCategoryGroup) ) return false;
        CodesCategoryGroup castOther = (CodesCategoryGroup) other;
        return new EqualsBuilder()
            .append(this.getSubGroup(), castOther.getSubGroup())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getSubGroup())
            .toHashCode();
    }

}
