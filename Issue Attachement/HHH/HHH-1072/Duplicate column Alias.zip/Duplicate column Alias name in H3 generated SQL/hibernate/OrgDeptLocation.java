package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class OrgDeptLocation implements Serializable {

    /** identifier field */
    private Integer orgDeptLocId;

    /** persistent field */
    private int id;

    /** persistent field */
    private int departmentCategoryCode;

    /** persistent field */
    private Integer locationId;

    /** persistent field */
    private int statusCode;

    /** nullable persistent field */
    private String shortNameEnglish;

    /** nullable persistent field */
    private String shortNameFrench;

    /** persistent field */
    private String departmentNameEnglish;

    /** persistent field */
    private String departmentNameFrench;

    /** persistent field */
    private Date statusChangedDate;

    /** nullable persistent field */
    private Short sigDeptFulltimeTeachers;

    /** nullable persistent field */
    private String fmsVendorCode;

    /** nullable persistent field */
    private String emailAddress;

    /** nullable persistent field */
    private String phoneCountryCode;

    /** nullable persistent field */
    private String phoneAreaCode;

    /** nullable persistent field */
    private String phoneNumber;

    /** nullable persistent field */
    private String phoneExtension;

    /** nullable persistent field */
    private String faxPhoneCountryCode;

    /** nullable persistent field */
    private String faxAreaCode;

    /** nullable persistent field */
    private String faxNumber;

    /** nullable persistent field */
    private String faxPhoneExtension;

    /** nullable persistent field */
    private String deptWebAddress;

    /** nullable persistent field */
    private String createUserId;

    /** nullable persistent field */
    private Date createDate;

    /** nullable persistent field */
    private String changeUserId;

    /** nullable persistent field */
    private Date changeDate;

    /** full constructor */
    public OrgDeptLocation(Integer orgDeptLocId, int orgId, int departmentCategoryCode, Integer locationId, int statusCode, String shortNameEnglish, String shortNameFrench, String departmentNameEnglish, String departmentNameFrench, Date statusChangedDate, Short sigDeptFulltimeTeachers, String fmsVendorCode, String emailAddress, String phoneCountryCode, String phoneAreaCode, String phoneNumber, String phoneExtension, String faxPhoneCountryCode, String faxAreaCode, String faxNumber, String faxPhoneExtension, String deptWebAddress, String createUserId, Date createDate, String changeUserId, Date changeDate) {
        this.orgDeptLocId = orgDeptLocId;
        this.id = orgId;
        this.departmentCategoryCode = departmentCategoryCode;
        this.locationId = locationId;
        this.statusCode = statusCode;
        this.shortNameEnglish = shortNameEnglish;
        this.shortNameFrench = shortNameFrench;
        this.departmentNameEnglish = departmentNameEnglish;
        this.departmentNameFrench = departmentNameFrench;
        this.statusChangedDate = statusChangedDate;
        this.sigDeptFulltimeTeachers = sigDeptFulltimeTeachers;
        this.fmsVendorCode = fmsVendorCode;
        this.emailAddress = emailAddress;
        this.phoneCountryCode = phoneCountryCode;
        this.phoneAreaCode = phoneAreaCode;
        this.phoneNumber = phoneNumber;
        this.phoneExtension = phoneExtension;
        this.faxPhoneCountryCode = faxPhoneCountryCode;
        this.faxAreaCode = faxAreaCode;
        this.faxNumber = faxNumber;
        this.faxPhoneExtension = faxPhoneExtension;
        this.deptWebAddress = deptWebAddress;
        this.createUserId = createUserId;
        this.createDate = createDate;
        this.changeUserId = changeUserId;
        this.changeDate = changeDate;
    }

    /** default constructor */
    public OrgDeptLocation() {
    }

    /** minimal constructor */
    public OrgDeptLocation(Integer orgDeptLocId, int orgId, int departmentCategoryCode, Integer locationId, int statusCode, String departmentNameEnglish, String departmentNameFrench, Date statusChangedDate) {
        this.orgDeptLocId = orgDeptLocId;
        this.id = orgId;
        this.departmentCategoryCode = departmentCategoryCode;
        this.locationId = locationId;
        this.statusCode = statusCode;
        this.departmentNameEnglish = departmentNameEnglish;
        this.departmentNameFrench = departmentNameFrench;
        this.statusChangedDate = statusChangedDate;
    }

    public Integer getOrgDeptLocId() {
        return this.orgDeptLocId;
    }

    public void setOrgDeptLocId(Integer orgDeptLocId) {
        this.orgDeptLocId = orgDeptLocId;
    }

    public int getOrgId() {
        return this.id;
    }

    public void setOrgId(int orgId) {
        this.id = orgId;
    }

    public int getDepartmentCategoryCode() {
        return this.departmentCategoryCode;
    }

    public void setDepartmentCategoryCode(int departmentCategoryCode) {
        this.departmentCategoryCode = departmentCategoryCode;
    }

    public Integer getLocationId() {
        return this.locationId;
    }

    public void setLocationId(Integer locationId) {
        this.locationId = locationId;
    }

    public int getStatusCode() {
        return this.statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getShortNameEnglish() {
        return this.shortNameEnglish;
    }

    public void setShortNameEnglish(String shortNameEnglish) {
        this.shortNameEnglish = shortNameEnglish;
    }

    public String getShortNameFrench() {
        return this.shortNameFrench;
    }

    public void setShortNameFrench(String shortNameFrench) {
        this.shortNameFrench = shortNameFrench;
    }

    public String getDepartmentNameEnglish() {
        return this.departmentNameEnglish;
    }

    public void setDepartmentNameEnglish(String departmentNameEnglish) {
        this.departmentNameEnglish = departmentNameEnglish;
    }

    public String getDepartmentNameFrench() {
        return this.departmentNameFrench;
    }

    public void setDepartmentNameFrench(String departmentNameFrench) {
        this.departmentNameFrench = departmentNameFrench;
    }

    public Date getStatusChangedDate() {
        return this.statusChangedDate;
    }

    public void setStatusChangedDate(Date statusChangedDate) {
        this.statusChangedDate = statusChangedDate;
    }

    public Short getSigDeptFulltimeTeachers() {
        return this.sigDeptFulltimeTeachers;
    }

    public void setSigDeptFulltimeTeachers(Short sigDeptFulltimeTeachers) {
        this.sigDeptFulltimeTeachers = sigDeptFulltimeTeachers;
    }

    public String getFmsVendorCode() {
        return this.fmsVendorCode;
    }

    public void setFmsVendorCode(String fmsVendorCode) {
        this.fmsVendorCode = fmsVendorCode;
    }

    public String getEmailAddress() {
        return this.emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPhoneCountryCode() {
        return this.phoneCountryCode;
    }

    public void setPhoneCountryCode(String phoneCountryCode) {
        this.phoneCountryCode = phoneCountryCode;
    }

    public String getPhoneAreaCode() {
        return this.phoneAreaCode;
    }

    public void setPhoneAreaCode(String phoneAreaCode) {
        this.phoneAreaCode = phoneAreaCode;
    }

    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPhoneExtension() {
        return this.phoneExtension;
    }

    public void setPhoneExtension(String phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public String getFaxPhoneCountryCode() {
        return this.faxPhoneCountryCode;
    }

    public void setFaxPhoneCountryCode(String faxPhoneCountryCode) {
        this.faxPhoneCountryCode = faxPhoneCountryCode;
    }

    public String getFaxAreaCode() {
        return this.faxAreaCode;
    }

    public void setFaxAreaCode(String faxAreaCode) {
        this.faxAreaCode = faxAreaCode;
    }

    public String getFaxNumber() {
        return this.faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public String getFaxPhoneExtension() {
        return this.faxPhoneExtension;
    }

    public void setFaxPhoneExtension(String faxPhoneExtension) {
        this.faxPhoneExtension = faxPhoneExtension;
    }

    public String getDeptWebAddress() {
        return this.deptWebAddress;
    }

    public void setDeptWebAddress(String deptWebAddress) {
        this.deptWebAddress = deptWebAddress;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("orgDeptLocId", getOrgDeptLocId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof OrgDeptLocation) ) return false;
        OrgDeptLocation castOther = (OrgDeptLocation) other;
        return new EqualsBuilder()
            .append(this.getOrgDeptLocId(), castOther.getOrgDeptLocId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getOrgDeptLocId())
            .toHashCode();
    }

}
