package hibernate;

import java.io.*;
import java.math.*;
import java.util.*;

import org.apache.commons.lang.builder.*;

/** @author Hibernate CodeGenerator */
public class PersonResearchSupport implements Serializable {

    /** identifier field */
    private Integer extSupportId;

    /** persistent field */
    private Integer cid;

    /** nullable persistent field */
    private Short competitionYear;

    /** nullable persistent field */
    private hibernate.Organization fundingOrganization;

    /** nullable persistent field */
    private String orgName;

    /** nullable persistent field */
    private Integer applId;

    /** nullable persistent field */
    private String resultOfSshrcInd;

    /** nullable persistent field */
    private String externalApplTitle;

    /** nullable persistent field */
    private String externalProgramName;

    /** nullable persistent field */
    private Integer completionStatusCode;

    /** nullable persistent field */
    private String resultNote;

    /** nullable persistent field */
    private Integer roleCode;

    /** nullable persistent field */
    private BigDecimal grantAmount;

    /** nullable persistent field */
    private String applicantFamilyName;

    /** nullable persistent field */
    private String applicantFirstName;

    /** nullable persistent field */
    private String applicantInitials;

    /** nullable persistent field */
    private String createUserId;

    /** nullable persistent field */
    private Date createDate;

    /** nullable persistent field */
    private String changeUserId;

    /** nullable persistent field */
    private Date changeDate;

    /** full constructor */
    public PersonResearchSupport(Integer extSupportId,
                                 Integer cid,
                                 Short competitionYear,
                                 hibernate.Organization fundingOrganization,
                                 String orgName,
                                 Integer applId,
                                 String resultOfSshrcInd,
                                 String externalApplTitle,
                                 String externalProgramName,
                                 Integer completionStatusCode,
                                 String resultNote,
                                 Integer roleCode,
                                 BigDecimal grantAmount,
                                 String applicantFamilyName,
                                 String applicantFirstName,
                                 String applicantInitials,
                                 String createUserId,
                                 Date createDate,
                                 String
                                 changeUserId,
                                 Date changeDate) {
        this.extSupportId = extSupportId;
        this.cid = cid;
        this.competitionYear = competitionYear;
        this.fundingOrganization = fundingOrganization;
        this.orgName = orgName;
        this.applId = applId;
        this.resultOfSshrcInd = resultOfSshrcInd;
        this.externalApplTitle = externalApplTitle;
        this.externalProgramName = externalProgramName;
        this.completionStatusCode = completionStatusCode;
        this.resultNote = resultNote;
        this.roleCode = roleCode;
        this.grantAmount = grantAmount;
        this.applicantFamilyName = applicantFamilyName;
        this.applicantFirstName = applicantFirstName;
        this.applicantInitials = applicantInitials;
        this.createUserId = createUserId;
        this.createDate = createDate;
        this.changeUserId = changeUserId;
        this.changeDate = changeDate;
    }

    /** default constructor */
    public PersonResearchSupport() {
    }

    /** minimal constructor */
    public PersonResearchSupport(Integer extSupportId, Integer cid) {
        this.extSupportId = extSupportId;
        this.cid = cid;
    }

    public Integer getExtSupportId() {
        return this.extSupportId;
    }

    public void setExtSupportId(Integer extSupportId) {
        this.extSupportId = extSupportId;
    }

    public Integer getCid() {
        return this.cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public Short getCompetitionYear() {
        return this.competitionYear;
    }

    public void setCompetitionYear(Short competitionYear) {
        this.competitionYear = competitionYear;
    }

    public String getOrgName() {
        return this.orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public Integer getApplId() {
        return this.applId;
    }

    public void setApplId(Integer applId) {
        this.applId = applId;
    }

    public String getResultOfSshrcInd() {
        return this.resultOfSshrcInd;
    }

    public void setResultOfSshrcInd(String resultOfSshrcInd) {
        this.resultOfSshrcInd = resultOfSshrcInd;
    }

    public String getExternalApplTitle() {
        return this.externalApplTitle;
    }

    public void setExternalApplTitle(String externalApplTitle) {
        this.externalApplTitle = externalApplTitle;
    }

    public String getExternalProgramName() {
        return this.externalProgramName;
    }

    public void setExternalProgramName(String externalProgramName) {
        this.externalProgramName = externalProgramName;
    }

    public Integer getCompletionStatusCode() {
        return this.completionStatusCode;
    }

    public void setCompletionStatusCode(Integer completionStatusCode) {
        this.completionStatusCode = completionStatusCode;
    }

    public String getResultNote() {
        return this.resultNote;
    }

    public void setResultNote(String resultNote) {
        this.resultNote = resultNote;
    }

    public Integer getRoleCode() {
        return this.roleCode;
    }

    public void setRoleCode(Integer roleCode) {
        this.roleCode = roleCode;
    }

    public BigDecimal getGrantAmount() {
        return this.grantAmount;
    }

    public void setGrantAmount(BigDecimal grantAmount) {
        this.grantAmount = grantAmount;
    }

    public String getApplicantFamilyName() {
        return this.applicantFamilyName;
    }

    public void setApplicantFamilyName(String applicantFamilyName) {
        this.applicantFamilyName = applicantFamilyName;
    }

    public String getApplicantFirstName() {
        return this.applicantFirstName;
    }

    public void setApplicantFirstName(String applicantFirstName) {
        this.applicantFirstName = applicantFirstName;
    }

    public String getApplicantInitials() {
        return this.applicantInitials;
    }

    public void setApplicantInitials(String applicantInitials) {
        this.applicantInitials = applicantInitials;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public Organization getFundingOrganization() {
        return fundingOrganization;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public void setFundingOrganization(Organization fundingOrganization) {
        this.fundingOrganization = fundingOrganization;
    }

    public String toString() {
        return new ToStringBuilder(this)
                .append("extSupportId", getExtSupportId())
                .toString();
    }

    public boolean equals(Object other) {
        if (!(other instanceof PersonResearchSupport)) {
            return false;
        }
        PersonResearchSupport castOther = (PersonResearchSupport) other;
        return new EqualsBuilder()
                .append(this.getExtSupportId(), castOther.getExtSupportId())
                .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
                .append(getExtSupportId())
                .toHashCode();
    }

}
