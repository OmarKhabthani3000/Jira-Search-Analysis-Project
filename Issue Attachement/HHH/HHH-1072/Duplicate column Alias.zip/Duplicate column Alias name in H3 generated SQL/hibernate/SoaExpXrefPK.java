package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class SoaExpXrefPK implements Serializable {

    /** identifier field */
    private Integer dataEntryType;

    /** identifier field */
    private Integer sequenceNumber;

    /** full constructor */
    public SoaExpXrefPK(Integer dataEntryType, Integer sequenceNumber) {
        this.dataEntryType = dataEntryType;
        this.sequenceNumber = sequenceNumber;
    }

    /** default constructor */
    public SoaExpXrefPK() {
    }

    public Integer getDataEntryType() {
        return this.dataEntryType;
    }

    public void setDataEntryType(Integer dataEntryType) {
        this.dataEntryType = dataEntryType;
    }

    public Integer getSequenceNumber() {
        return this.sequenceNumber;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("dataEntryType", getDataEntryType())
            .append("sequenceNumber", getSequenceNumber())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof SoaExpXrefPK) ) return false;
        SoaExpXrefPK castOther = (SoaExpXrefPK) other;
        return new EqualsBuilder()
            .append(this.getDataEntryType(), castOther.getDataEntryType())
            .append(this.getSequenceNumber(), castOther.getSequenceNumber())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getDataEntryType())
            .append(getSequenceNumber())
            .toHashCode();
    }

}
