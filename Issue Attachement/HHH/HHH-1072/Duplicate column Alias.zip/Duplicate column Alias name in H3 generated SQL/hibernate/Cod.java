package hibernate;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class Cod implements Serializable {

    /** identifier field */
    private Integer code;

    /** nullable persistent field */
    private String codeType;

    /** nullable persistent field */
    private Integer sequenceNumber;

    /** persistent field */
    private String activeInd;

    /** nullable persistent field */
    private String amisUsageInd;

    /** nullable persistent field */
    private String webUsageInd;

    /** persistent field */
    private String shortNameEnglish;

    /** persistent field */
    private String shortNameFrench;

    /** nullable persistent field */
    private String nameEnglish;

    /** nullable persistent field */
    private String nameFrench;

    /** nullable persistent field */
    private String comments;

    /** persistent field */
    private Date createDate;

    /** persistent field */
    private String createUserId;

    /** persistent field */
    private Date changeDate;

    /** persistent field */
    private String changeUserId;

    /** persistent field */
    private hibernate.CodesTabl codesTablByCodeTableId;

    /** persistent field */
    private Set codesCategoriesByCode;

    /** persistent field */
//    private Set applIneThemsBySubThemeCode;

    /** persistent field */
//    private Set applIneThemsByThemeCode;

    /** persistent field */
    //    private Set frrCommentsBySatisfactionInd1;

    /** persistent field */
    //    private Set frrCommentsBySatisfactionInd3;

    /** persistent field */
    //    private Set frrCommentsBySatisfactionInd2;

    /** persistent field */
    //    private Set frrCommentsBySatisfactionInd4;

    /** full constructor */
//    public Cod(Integer code, String codeType, Integer sequenceNumber, String activeInd, String amisUsageInd, String webUsageInd, String shortNameEnglish, String shortNameFrench, String nameEnglish, String nameFrench, String comments, Date createDate, String createUserId, Date changeDate, String changeUserId, hibernate.CodesTabl codesTablByCodeTableId, Set codesCategoriesByCode, Set applIneThemsBySubThemeCode, Set applIneThemsByThemeCode, Set frrCommentsBySatisfactionInd1, Set frrCommentsBySatisfactionInd3, Set frrCommentsBySatisfactionInd2, Set frrCommentsBySatisfactionInd4) {
    public Cod(Integer code, String codeType, Integer sequenceNumber, String activeInd, String amisUsageInd, String webUsageInd, String shortNameEnglish, String shortNameFrench, String nameEnglish, String nameFrench, String comments, Date createDate, String createUserId, Date changeDate, String changeUserId, hibernate.CodesTabl codesTablByCodeTableId, Set codesCategoriesByCode) {
        this.code = code;
        this.codeType = codeType;
        this.sequenceNumber = sequenceNumber;
        this.activeInd = activeInd;
        this.amisUsageInd = amisUsageInd;
        this.webUsageInd = webUsageInd;
        this.shortNameEnglish = shortNameEnglish;
        this.shortNameFrench = shortNameFrench;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.comments = comments;
        this.createDate = createDate;
        this.createUserId = createUserId;
        this.changeDate = changeDate;
        this.changeUserId = changeUserId;
        this.codesTablByCodeTableId = codesTablByCodeTableId;
        this.codesTablByCodeTableId = codesTablByCodeTableId;
        this.codesCategoriesByCode = codesCategoriesByCode;
        this.codesCategoriesByCode = codesCategoriesByCode;
/*        this.applIneThemsBySubThemeCode = applIneThemsBySubThemeCode;
        this.applIneThemsByThemeCode = applIneThemsByThemeCode;
        this.frrCommentsBySatisfactionInd1 = frrCommentsBySatisfactionInd1;
        this.frrCommentsBySatisfactionInd3 = frrCommentsBySatisfactionInd3;
        this.frrCommentsBySatisfactionInd2 = frrCommentsBySatisfactionInd2;
        this.frrCommentsBySatisfactionInd4 = frrCommentsBySatisfactionInd4;*/
    }

    /** default constructor */
    public Cod() {
    }

    /** minimal constructor */
    public Cod(Integer code, String activeInd, String shortNameEnglish, String shortNameFrench, Date createDate, String createUserId, Date changeDate, String changeUserId, hibernate.CodesTabl codesTablByCodeTableId, Set codesCategoriesByCode) {
        this.code = code;
        this.activeInd = activeInd;
        this.shortNameEnglish = shortNameEnglish;
        this.shortNameFrench = shortNameFrench;
        this.createDate = createDate;
        this.createUserId = createUserId;
        this.changeDate = changeDate;
        this.changeUserId = changeUserId;
        this.codesTablByCodeTableId = codesTablByCodeTableId;
        this.codesTablByCodeTableId = codesTablByCodeTableId;
        this.codesCategoriesByCode = codesCategoriesByCode;
        this.codesCategoriesByCode = codesCategoriesByCode;
/*        this.applIneThemsBySubThemeCode = applIneThemsBySubThemeCode;
        this.applIneThemsByThemeCode = applIneThemsByThemeCode;
        this.frrCommentsBySatisfactionInd1 = frrCommentsBySatisfactionInd1;
        this.frrCommentsBySatisfactionInd3 = frrCommentsBySatisfactionInd3;
        this.frrCommentsBySatisfactionInd2 = frrCommentsBySatisfactionInd2;
        this.frrCommentsBySatisfactionInd4 = frrCommentsBySatisfactionInd4;*/
    }

    public Integer getCode() {
        return this.code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getCodeType() {
        return this.codeType;
    }

    public void setCodeType(String codeType) {
        this.codeType = codeType;
    }

    public Integer getSequenceNumber() {
        return this.sequenceNumber;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String getActiveInd() {
        return this.activeInd;
    }

    public void setActiveInd(String activeInd) {
        this.activeInd = activeInd;
    }

    public String getAmisUsageInd() {
        return this.amisUsageInd;
    }

    public void setAmisUsageInd(String amisUsageInd) {
        this.amisUsageInd = amisUsageInd;
    }

    public String getWebUsageInd() {
        return this.webUsageInd;
    }

    public void setWebUsageInd(String webUsageInd) {
        this.webUsageInd = webUsageInd;
    }

    public String getShortNameEnglish() {
        return this.shortNameEnglish;
    }

    public void setShortNameEnglish(String shortNameEnglish) {
        this.shortNameEnglish = shortNameEnglish;
    }

    public String getShortNameFrench() {
        return this.shortNameFrench;
    }

    public void setShortNameFrench(String shortNameFrench) {
        this.shortNameFrench = shortNameFrench;
    }

    public String getNameEnglish() {
        return this.nameEnglish;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public String getNameFrench() {
        return this.nameFrench;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    public String getComments() {
        return this.comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public hibernate.CodesTabl getCodesTablByCodeTableId() {
        return this.codesTablByCodeTableId;
    }

    public void setCodesTablByCodeTableId(hibernate.CodesTabl codesTablByCodeTableId) {
        this.codesTablByCodeTableId = codesTablByCodeTableId;
    }

    public Set getCodesCategoriesByCode() {
        return this.codesCategoriesByCode;
    }

    public void setCodesCategoriesByCode(Set codesCategoriesByCode) {
        this.codesCategoriesByCode = codesCategoriesByCode;
    }

/*    public Set getApplIneThemsBySubThemeCode() {
        return this.applIneThemsBySubThemeCode;
    }

    public void setApplIneThemsBySubThemeCode(Set applIneThemsBySubThemeCode) {
        this.applIneThemsBySubThemeCode = applIneThemsBySubThemeCode;
    }

    public Set getApplIneThemsByThemeCode() {
        return this.applIneThemsByThemeCode;
    }

    public void setApplIneThemsByThemeCode(Set applIneThemsByThemeCode) {
        this.applIneThemsByThemeCode = applIneThemsByThemeCode;
    }

    public Set getFrrCommentsBySatisfactionInd1() {
        return this.frrCommentsBySatisfactionInd1;
    }

    public void setFrrCommentsBySatisfactionInd1(Set frrCommentsBySatisfactionInd1) {
        this.frrCommentsBySatisfactionInd1 = frrCommentsBySatisfactionInd1;
    }

    public Set getFrrCommentsBySatisfactionInd3() {
        return this.frrCommentsBySatisfactionInd3;
    }

    public void setFrrCommentsBySatisfactionInd3(Set frrCommentsBySatisfactionInd3) {
        this.frrCommentsBySatisfactionInd3 = frrCommentsBySatisfactionInd3;
    }

    public Set getFrrCommentsBySatisfactionInd2() {
        return this.frrCommentsBySatisfactionInd2;
    }

    public void setFrrCommentsBySatisfactionInd2(Set frrCommentsBySatisfactionInd2) {
        this.frrCommentsBySatisfactionInd2 = frrCommentsBySatisfactionInd2;
    }

    public Set getFrrCommentsBySatisfactionInd4() {
        return this.frrCommentsBySatisfactionInd4;
    }

    public void setFrrCommentsBySatisfactionInd4(Set frrCommentsBySatisfactionInd4) {
        this.frrCommentsBySatisfactionInd4 = frrCommentsBySatisfactionInd4;
    }
*/
    public String toString() {
        return new ToStringBuilder(this)
            .append("code", getCode())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof Cod) ) return false;
        Cod castOther = (Cod) other;
        return new EqualsBuilder()
            .append(this.getCode(), castOther.getCode())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getCode())
            .toHashCode();
    }

}
