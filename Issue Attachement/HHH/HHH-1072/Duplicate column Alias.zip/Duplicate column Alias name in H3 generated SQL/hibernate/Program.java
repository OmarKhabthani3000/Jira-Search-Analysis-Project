package hibernate;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class Program implements Serializable {

    /** identifier field */
    private Integer programId;

    /** nullable persistent field */
    private Date startDate;

    /** nullable persistent field */
    private Date endDate;

    /** persistent field */
    private String activeInd;

    /** persistent field */
    private String nameEnglish;

    /** persistent field */
    private String nameFrench;

    /** nullable persistent field */
    private String objectivesEnglish;

    /** nullable persistent field */
    private String objectivesFrench;

    /** persistent field */
    private String taxableInd;

    /** nullable persistent field */
    private Date awardStartDate;

    /** nullable persistent field */
    private Integer totalAwardMonths;

    /** nullable persistent field */
    private BigDecimal totalAwardAmount;

    /** nullable persistent field */
    private BigDecimal monthAwardAmount;

    /** nullable persistent field */
    private String subjectFileClassNumber;

    /** persistent field */
    private Integer dataEntryType;

    /** persistent field */
    private String externallyAccessedInd;

    /** nullable persistent field */
    private BigDecimal maximumResearchAllowance;

    /** nullable persistent field */
    private BigDecimal timeStipendAmount;

    /** nullable persistent field */
    private BigDecimal timeStipendSshrcPercent;

    /** nullable persistent field */
    private Short assessmentDueWeeks;

    /** persistent field */
    private String globalPaymentInd;

    /** persistent field */
    private String fellowshipPaymentSchInd;

    /** persistent field */
    private String tbpInd;

    /** nullable persistent field */
    private Short defaultCompetitionYear;

    /** nullable persistent field */
    private String createUserId;

    /** nullable persistent field */
    private Date createDate;

    /** nullable persistent field */
    private String changeUserId;

    /** nullable persistent field */
    private Date changeDate;

    /** persistent field */
    private Set webSubsystems;

    /** persistent field */
    private Set progCommittees;

    /** full constructor */
    public Program(Integer programId, Date startDate, Date endDate, String activeInd, String nameEnglish, String nameFrench, String objectivesEnglish, String objectivesFrench, String taxableInd, Date awardStartDate, Integer totalAwardMonths, BigDecimal totalAwardAmount, BigDecimal monthAwardAmount, String subjectFileClassNumber, Integer dataEntryType, String externallyAccessedInd, BigDecimal maximumResearchAllowance, BigDecimal timeStipendAmount, BigDecimal timeStipendSshrcPercent, Short assessmentDueWeeks, String globalPaymentInd, String fellowshipPaymentSchInd, String tbpInd, Short defaultCompetitionYear, String createUserId, Date createDate, String changeUserId, Date changeDate, Set webSubsystems, Set progCommittees) {
        this.programId = programId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.activeInd = activeInd;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.objectivesEnglish = objectivesEnglish;
        this.objectivesFrench = objectivesFrench;
        this.taxableInd = taxableInd;
        this.awardStartDate = awardStartDate;
        this.totalAwardMonths = totalAwardMonths;
        this.totalAwardAmount = totalAwardAmount;
        this.monthAwardAmount = monthAwardAmount;
        this.subjectFileClassNumber = subjectFileClassNumber;
        this.dataEntryType = dataEntryType;
        this.externallyAccessedInd = externallyAccessedInd;
        this.maximumResearchAllowance = maximumResearchAllowance;
        this.timeStipendAmount = timeStipendAmount;
        this.timeStipendSshrcPercent = timeStipendSshrcPercent;
        this.assessmentDueWeeks = assessmentDueWeeks;
        this.globalPaymentInd = globalPaymentInd;
        this.fellowshipPaymentSchInd = fellowshipPaymentSchInd;
        this.tbpInd = tbpInd;
        this.defaultCompetitionYear = defaultCompetitionYear;
        this.createUserId = createUserId;
        this.createDate = createDate;
        this.changeUserId = changeUserId;
        this.changeDate = changeDate;
        this.webSubsystems = webSubsystems;
        this.progCommittees = progCommittees;
    }

    /** default constructor */
    public Program() {
    }

    /** minimal constructor */
    public Program(Integer programId, String activeInd, String nameEnglish, String nameFrench, String taxableInd, Integer dataEntryType, String externallyAccessedInd, String globalPaymentInd, String fellowshipPaymentSchInd, String tbpInd, Set webSubsystems, Set progCommittees) {
        this.programId = programId;
        this.activeInd = activeInd;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.taxableInd = taxableInd;
        this.dataEntryType = dataEntryType;
        this.externallyAccessedInd = externallyAccessedInd;
        this.globalPaymentInd = globalPaymentInd;
        this.fellowshipPaymentSchInd = fellowshipPaymentSchInd;
        this.tbpInd = tbpInd;
        this.webSubsystems = webSubsystems;
        this.progCommittees = progCommittees;
    }

    public Integer getProgramId() {
        return this.programId;
    }

    public void setProgramId(Integer programId) {
        this.programId = programId;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getActiveInd() {
        return this.activeInd;
    }

    public void setActiveInd(String activeInd) {
        this.activeInd = activeInd;
    }

    public String getNameEnglish() {
        return this.nameEnglish;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public String getNameFrench() {
        return this.nameFrench;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    public String getObjectivesEnglish() {
        return this.objectivesEnglish;
    }

    public void setObjectivesEnglish(String objectivesEnglish) {
        this.objectivesEnglish = objectivesEnglish;
    }

    public String getObjectivesFrench() {
        return this.objectivesFrench;
    }

    public void setObjectivesFrench(String objectivesFrench) {
        this.objectivesFrench = objectivesFrench;
    }

    public String getTaxableInd() {
        return this.taxableInd;
    }

    public void setTaxableInd(String taxableInd) {
        this.taxableInd = taxableInd;
    }

    public Date getAwardStartDate() {
        return this.awardStartDate;
    }

    public void setAwardStartDate(Date awardStartDate) {
        this.awardStartDate = awardStartDate;
    }

    public Integer getTotalAwardMonths() {
        return this.totalAwardMonths;
    }

    public void setTotalAwardMonths(Integer totalAwardMonths) {
        this.totalAwardMonths = totalAwardMonths;
    }

    public BigDecimal getTotalAwardAmount() {
        return this.totalAwardAmount;
    }

    public void setTotalAwardAmount(BigDecimal totalAwardAmount) {
        this.totalAwardAmount = totalAwardAmount;
    }

    public BigDecimal getMonthAwardAmount() {
        return this.monthAwardAmount;
    }

    public void setMonthAwardAmount(BigDecimal monthAwardAmount) {
        this.monthAwardAmount = monthAwardAmount;
    }

    public String getSubjectFileClassNumber() {
        return this.subjectFileClassNumber;
    }

    public void setSubjectFileClassNumber(String subjectFileClassNumber) {
        this.subjectFileClassNumber = subjectFileClassNumber;
    }

    public Integer getDataEntryType() {
        return this.dataEntryType;
    }

    public void setDataEntryType(Integer dataEntryType) {
        this.dataEntryType = dataEntryType;
    }

    public String getExternallyAccessedInd() {
        return this.externallyAccessedInd;
    }

    public void setExternallyAccessedInd(String externallyAccessedInd) {
        this.externallyAccessedInd = externallyAccessedInd;
    }

    public BigDecimal getMaximumResearchAllowance() {
        return this.maximumResearchAllowance;
    }

    public void setMaximumResearchAllowance(BigDecimal maximumResearchAllowance) {
        this.maximumResearchAllowance = maximumResearchAllowance;
    }

    public BigDecimal getTimeStipendAmount() {
        return this.timeStipendAmount;
    }

    public void setTimeStipendAmount(BigDecimal timeStipendAmount) {
        this.timeStipendAmount = timeStipendAmount;
    }

    public BigDecimal getTimeStipendSshrcPercent() {
        return this.timeStipendSshrcPercent;
    }

    public void setTimeStipendSshrcPercent(BigDecimal timeStipendSshrcPercent) {
        this.timeStipendSshrcPercent = timeStipendSshrcPercent;
    }

    public Short getAssessmentDueWeeks() {
        return this.assessmentDueWeeks;
    }

    public void setAssessmentDueWeeks(Short assessmentDueWeeks) {
        this.assessmentDueWeeks = assessmentDueWeeks;
    }

    public String getGlobalPaymentInd() {
        return this.globalPaymentInd;
    }

    public void setGlobalPaymentInd(String globalPaymentInd) {
        this.globalPaymentInd = globalPaymentInd;
    }

    public String getFellowshipPaymentSchInd() {
        return this.fellowshipPaymentSchInd;
    }

    public void setFellowshipPaymentSchInd(String fellowshipPaymentSchInd) {
        this.fellowshipPaymentSchInd = fellowshipPaymentSchInd;
    }

    public String getTbpInd() {
        return this.tbpInd;
    }

    public void setTbpInd(String tbpInd) {
        this.tbpInd = tbpInd;
    }

    public Short getDefaultCompetitionYear() {
        return this.defaultCompetitionYear;
    }

    public void setDefaultCompetitionYear(Short defaultCompetitionYear) {
        this.defaultCompetitionYear = defaultCompetitionYear;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Set getWebSubsystems() {
        return this.webSubsystems;
    }

    public void setWebSubsystems(Set webSubsystems) {
        this.webSubsystems = webSubsystems;
    }

    public Set getProgCommittees() {
        return this.progCommittees;
    }

    public void setProgCommittees(Set progCommittees) {
        this.progCommittees = progCommittees;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("programId", getProgramId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof Program) ) return false;
        Program castOther = (Program) other;
        return new EqualsBuilder()
            .append(this.getProgramId(), castOther.getProgramId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getProgramId())
            .toHashCode();
    }

}
