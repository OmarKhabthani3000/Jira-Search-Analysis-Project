package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class CodesCategoryPK implements Serializable {

    /** identifier field */
    private Integer subGroup;

    /** identifier field */
    private hibernate.Cod codByCode;

    /** full constructor */
    public CodesCategoryPK(Integer subGroup, hibernate.Cod codByCode) {
        this.subGroup = subGroup;
        this.codByCode = codByCode;
        this.codByCode = codByCode;
    }

    /** default constructor */
    public CodesCategoryPK() {
    }

    public Integer getSubGroup() {
        return this.subGroup;
    }

    public void setSubGroup(Integer subGroup) {
        this.subGroup = subGroup;
    }

    public hibernate.Cod getCodByCode() {
        return this.codByCode;
    }

    public void setCodByCode(hibernate.Cod codByCode) {
        this.codByCode = codByCode;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("subGroup", getSubGroup())
            .append("codByCode", getCodByCode())
            .append("codByCode", getCodByCode())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof CodesCategoryPK) ) return false;
        CodesCategoryPK castOther = (CodesCategoryPK) other;
        return new EqualsBuilder()
            .append(this.getSubGroup(), castOther.getSubGroup())
            .append(this.getCodByCode(), castOther.getCodByCode())
            .append(this.getCodByCode(), castOther.getCodByCode())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getSubGroup())
            .append(getCodByCode())
            .append(getCodByCode())
            .toHashCode();
    }

}
