package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class ProgCommitteePK implements Serializable {

    /** identifier field */
    private Integer committeeId;

    /** identifier field */
    private hibernate.Program program;

    /** full constructor */
    public ProgCommitteePK(Integer committeeId, hibernate.Program program) {
        this.committeeId = committeeId;
        this.program = program;
    }

    /** default constructor */
    public ProgCommitteePK() {
    }

    public Integer getCommitteeId() {
        return this.committeeId;
    }

    public void setCommitteeId(Integer committeeId) {
        this.committeeId = committeeId;
    }

    public hibernate.Program getProgram() {
        return this.program;
    }

    public void setProgram(hibernate.Program program) {
        this.program = program;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("committeeId", getCommitteeId())
            .append("program", getProgram())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof ProgCommitteePK) ) return false;
        ProgCommitteePK castOther = (ProgCommitteePK) other;
        return new EqualsBuilder()
            .append(this.getCommitteeId(), castOther.getCommitteeId())
            .append(this.getProgram(), castOther.getProgram())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getCommitteeId())
            .append(getProgram())
            .toHashCode();
    }

}
