package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class ProgGrantTypePK implements Serializable {

    /** identifier field */
    private Integer programId;

    /** identifier field */
    private Integer grantType;

    /** full constructor */
    public ProgGrantTypePK(Integer programId, Integer grantType) {
        this.programId = programId;
        this.grantType = grantType;
    }

    /** default constructor */
    public ProgGrantTypePK() {
    }

    public Integer getProgramId() {
        return this.programId;
    }

    public void setProgramId(Integer programId) {
        this.programId = programId;
    }

    public Integer getGrantType() {
        return this.grantType;
    }

    public void setGrantType(Integer grantType) {
        this.grantType = grantType;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("programId", getProgramId())
            .append("grantType", getGrantType())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof ProgGrantTypePK) ) return false;
        ProgGrantTypePK castOther = (ProgGrantTypePK) other;
        return new EqualsBuilder()
            .append(this.getProgramId(), castOther.getProgramId())
            .append(this.getGrantType(), castOther.getGrantType())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getProgramId())
            .append(getGrantType())
            .toHashCode();
    }

}
