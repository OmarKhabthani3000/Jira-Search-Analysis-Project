package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class UserSession implements Serializable {

    /** identifier field */
    private Integer sessionId;

    /** nullable persistent field */
    private Integer cid;

    /** nullable persistent field */
    private Date startSessionDatetime;

    /** nullable persistent field */
    private Date endSessionDatetime;

    /** nullable persistent field */
    private Integer numberOfAccess;

    /** nullable persistent field */
    private Long sessionKey;

    /** full constructor */
    public UserSession(Integer sessionId, Integer cid, Date startSessionDatetime, Date endSessionDatetime, Integer numberOfAccess, Long sessionKey) {
        this.sessionId = sessionId;
        this.cid = cid;
        this.startSessionDatetime = startSessionDatetime;
        this.endSessionDatetime = endSessionDatetime;
        this.numberOfAccess = numberOfAccess;
        this.sessionKey = sessionKey;
    }

    /** default constructor */
    public UserSession() {
    }

    /** minimal constructor */
    public UserSession(Integer sessionId) {
        this.sessionId = sessionId;
    }

    public Integer getSessionId() {
        return this.sessionId;
    }

    public void setSessionId(Integer sessionId) {
        this.sessionId = sessionId;
    }

    public Integer getCid() {
        return this.cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public Date getStartSessionDatetime() {
        return this.startSessionDatetime;
    }

    public void setStartSessionDatetime(Date startSessionDatetime) {
        this.startSessionDatetime = startSessionDatetime;
    }

    public Date getEndSessionDatetime() {
        return this.endSessionDatetime;
    }

    public void setEndSessionDatetime(Date endSessionDatetime) {
        this.endSessionDatetime = endSessionDatetime;
    }

    public Integer getNumberOfAccess() {
        return this.numberOfAccess;
    }

    public void setNumberOfAccess(Integer numberOfAccess) {
        this.numberOfAccess = numberOfAccess;
    }

    public Long getSessionKey() {
        return this.sessionKey;
    }

    public void setSessionKey(Long sessionKey) {
        this.sessionKey = sessionKey;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("sessionId", getSessionId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof UserSession) ) return false;
        UserSession castOther = (UserSession) other;
        return new EqualsBuilder()
            .append(this.getSessionId(), castOther.getSessionId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getSessionId())
            .toHashCode();
    }

}
