package hibernate;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class CodesTabl implements Serializable {

    /** identifier field */
    private Integer codeTableId;

    /** persistent field */
    private String codeName;

    /** nullable persistent field */
    private String activeInd;

    /** nullable persistent field */
    private String amisUsageInd;

    /** nullable persistent field */
    private String webUsageInd;

    /** nullable persistent field */
    private String comments;

    /** persistent field */
    private Date createDate;

    /** persistent field */
    private String createUserId;

    /** persistent field */
    private Date changeDate;

    /** persistent field */
    private String changeUserId;

    /** persistent field */
    private Set codsByCodeTableId;

    /** full constructor */
    public CodesTabl(Integer codeTableId, String codeName, String activeInd, String amisUsageInd, String webUsageInd, String comments, Date createDate, String createUserId, Date changeDate, String changeUserId, Set codsByCodeTableId) {
        this.codeTableId = codeTableId;
        this.codeName = codeName;
        this.activeInd = activeInd;
        this.amisUsageInd = amisUsageInd;
        this.webUsageInd = webUsageInd;
        this.comments = comments;
        this.createDate = createDate;
        this.createUserId = createUserId;
        this.changeDate = changeDate;
        this.changeUserId = changeUserId;
        this.codsByCodeTableId = codsByCodeTableId;
        this.codsByCodeTableId = codsByCodeTableId;
    }

    /** default constructor */
    public CodesTabl() {
    }

    /** minimal constructor */
    public CodesTabl(Integer codeTableId, String codeName, Date createDate, String createUserId, Date changeDate, String changeUserId, Set codsByCodeTableId) {
        this.codeTableId = codeTableId;
        this.codeName = codeName;
        this.createDate = createDate;
        this.createUserId = createUserId;
        this.changeDate = changeDate;
        this.changeUserId = changeUserId;
        this.codsByCodeTableId = codsByCodeTableId;
        this.codsByCodeTableId = codsByCodeTableId;
    }

    public Integer getCodeTableId() {
        return this.codeTableId;
    }

    public void setCodeTableId(Integer codeTableId) {
        this.codeTableId = codeTableId;
    }

    public String getCodeName() {
        return this.codeName;
    }

    public void setCodeName(String codeName) {
        this.codeName = codeName;
    }

    public String getActiveInd() {
        return this.activeInd;
    }

    public void setActiveInd(String activeInd) {
        this.activeInd = activeInd;
    }

    public String getAmisUsageInd() {
        return this.amisUsageInd;
    }

    public void setAmisUsageInd(String amisUsageInd) {
        this.amisUsageInd = amisUsageInd;
    }

    public String getWebUsageInd() {
        return this.webUsageInd;
    }

    public void setWebUsageInd(String webUsageInd) {
        this.webUsageInd = webUsageInd;
    }

    public String getComments() {
        return this.comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public Set getCodsByCodeTableId() {
        return this.codsByCodeTableId;
    }

    public void setCodsByCodeTableId(Set codsByCodeTableId) {
        this.codsByCodeTableId = codsByCodeTableId;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("codeTableId", getCodeTableId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof CodesTabl) ) return false;
        CodesTabl castOther = (CodesTabl) other;
        return new EqualsBuilder()
            .append(this.getCodeTableId(), castOther.getCodeTableId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getCodeTableId())
            .toHashCode();
    }

}
