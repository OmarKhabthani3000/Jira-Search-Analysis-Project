package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class WebSubsystemCrossref implements Serializable {

    /** identifier field */
    private hibernate.WebSubsystemCrossrefPK comp_id;

    /** nullable persistent field */
    private String logonPage;

    /** full constructor */
    public WebSubsystemCrossref(hibernate.WebSubsystemCrossrefPK comp_id, String logonPage) {
        this.comp_id = comp_id;
        this.logonPage = logonPage;
    }

    /** default constructor */
    public WebSubsystemCrossref() {
    }

    /** minimal constructor */
    public WebSubsystemCrossref(hibernate.WebSubsystemCrossrefPK comp_id) {
        this.comp_id = comp_id;
    }

    public hibernate.WebSubsystemCrossrefPK getComp_id() {
        return this.comp_id;
    }

    public void setComp_id(hibernate.WebSubsystemCrossrefPK comp_id) {
        this.comp_id = comp_id;
    }

    public String getLogonPage() {
        return this.logonPage;
    }

    public void setLogonPage(String logonPage) {
        this.logonPage = logonPage;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof WebSubsystemCrossref) ) return false;
        WebSubsystemCrossref castOther = (WebSubsystemCrossref) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
