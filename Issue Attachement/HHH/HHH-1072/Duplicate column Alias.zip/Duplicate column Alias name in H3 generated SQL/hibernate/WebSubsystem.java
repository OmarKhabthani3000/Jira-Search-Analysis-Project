package hibernate;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class WebSubsystem implements Serializable {

    /** identifier field */
    private Integer subsystemId;

    /** persistent field */
    private String subsystemDescription;

    /** nullable persistent field */
    private String nameEnglish;

    /** nullable persistent field */
    private String nameFrench;

    /** nullable persistent field */
    private Integer grantType;

    /** nullable persistent field */
    private String helpFile;

    /** nullable persistent field */
    private String reportObject;

    /** nullable persistent field */
    private String portfolioInd;

    /** nullable persistent field */
    private String activeInd;

    /** nullable persistent field */
    private Date startDate;

    /** nullable persistent field */
    private Date endDate;

    /** nullable persistent field */
    private String letterOfIntentInd;

    /** nullable persistent field */
    private String displayNameEnglish;

    /** nullable persistent field */
    private String displayNameFrench;

    /** nullable persistent field */
    private String attachmentFile;

    /** nullable persistent field */
    private Short numberOfBudgetYears;

    /** nullable persistent field */
    private String finalReportInd;

    /** nullable persistent field */
    private String logoName;

    /** persistent field */
    private String formType;

    /** nullable persistent field */
    private Integer dataEntryType;

    /** persistent field */
    private hibernate.Program program;

    /** persistent field */
    private Set webModuls;

    /** persistent field */
    private Set form;

    /** persistent field */
    private Set bySubsystemId;

    /** persistent field */
    private Set byPortfolioSubsystemId;

    /** full constructor */
    public WebSubsystem(Integer subsystemId, String subsystemDescription, String nameEnglish, String nameFrench, Integer grantType, String helpFile, String reportObject, String portfolioInd, String activeInd, Date startDate, Date endDate, String letterOfIntentInd, String displayNameEnglish, String displayNameFrench, String attachmentFile, Short numberOfBudgetYears, String finalReportInd, String logoName, String formType, Integer dataEntryType, hibernate.Program program, Set webModuls, Set form, Set bySubsystemId, Set byPortfolioSubsystemId) {
        this.subsystemId = subsystemId;
        this.subsystemDescription = subsystemDescription;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.grantType = grantType;
        this.helpFile = helpFile;
        this.reportObject = reportObject;
        this.portfolioInd = portfolioInd;
        this.activeInd = activeInd;
        this.startDate = startDate;
        this.endDate = endDate;
        this.letterOfIntentInd = letterOfIntentInd;
        this.displayNameEnglish = displayNameEnglish;
        this.displayNameFrench = displayNameFrench;
        this.attachmentFile = attachmentFile;
        this.numberOfBudgetYears = numberOfBudgetYears;
        this.finalReportInd = finalReportInd;
        this.logoName = logoName;
        this.formType = formType;
        this.dataEntryType = dataEntryType;
        this.program = program;
        this.webModuls = webModuls;
        this.form = form;
        this.bySubsystemId = bySubsystemId;
        this.byPortfolioSubsystemId = byPortfolioSubsystemId;
    }

    /** ca.sshrc.web.lookupCache.WebSubSystemCache required constructor */
    public WebSubsystem(Integer subsystemId, String subsystemDescription, String nameEnglish, String nameFrench, Integer grantType, String helpFile, String reportObject, String portfolioInd, String activeInd, Date startDate, Date endDate, String letterOfIntentInd, String displayNameEnglish, String displayNameFrench, String attachmentFile, Short numberOfBudgetYears, String finalReportInd, String logoName, String formType, Integer dataEntryType, hibernate.Program program) {
        this.subsystemId = subsystemId;
        this.subsystemDescription = subsystemDescription;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.grantType = grantType;
        this.helpFile = helpFile;
        this.reportObject = reportObject;
        this.portfolioInd = portfolioInd;
        this.activeInd = activeInd;
        this.startDate = startDate;
        this.endDate = endDate;
        this.letterOfIntentInd = letterOfIntentInd;
        this.displayNameEnglish = displayNameEnglish;
        this.displayNameFrench = displayNameFrench;
        this.attachmentFile = attachmentFile;
        this.numberOfBudgetYears = numberOfBudgetYears;
        this.finalReportInd = finalReportInd;
        this.logoName = logoName;
        this.formType = formType;
        this.dataEntryType = dataEntryType;
        this.program = program;
    }

    /** default constructor */
    public WebSubsystem() {
    }

    /** minimal constructor */
    public WebSubsystem(Integer subsystemId, String subsystemDescription, String formType, hibernate.Program program, Set webModuls, Set form, Set bySubsystemId, Set byPortfolioSubsystemId) {
        this.subsystemId = subsystemId;
        this.subsystemDescription = subsystemDescription;
        this.formType = formType;
        this.program = program;
        this.webModuls = webModuls;
        this.form = form;
        this.bySubsystemId = bySubsystemId;
        this.byPortfolioSubsystemId = byPortfolioSubsystemId;
    }

    public Integer getSubsystemId() {
        return this.subsystemId;
    }

    public void setSubsystemId(Integer subsystemId) {
        this.subsystemId = subsystemId;
    }

    public String getSubsystemDescription() {
        return this.subsystemDescription;
    }

    public void setSubsystemDescription(String subsystemDescription) {
        this.subsystemDescription = subsystemDescription;
    }

    public String getNameEnglish() {
        return this.nameEnglish;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public String getNameFrench() {
        return this.nameFrench;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    public Integer getGrantType() {
        return this.grantType;
    }

    public void setGrantType(Integer grantType) {
        this.grantType = grantType;
    }

    public String getHelpFile() {
        return this.helpFile;
    }

    public void setHelpFile(String helpFile) {
        this.helpFile = helpFile;
    }

    public String getReportObject() {
        return this.reportObject;
    }

    public void setReportObject(String reportObject) {
        this.reportObject = reportObject;
    }

    public String getPortfolioInd() {
        return this.portfolioInd;
    }

    public void setPortfolioInd(String portfolioInd) {
        this.portfolioInd = portfolioInd;
    }

    public String getActiveInd() {
        return this.activeInd;
    }

    public void setActiveInd(String activeInd) {
        this.activeInd = activeInd;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getLetterOfIntentInd() {
        return this.letterOfIntentInd;
    }

    public void setLetterOfIntentInd(String letterOfIntentInd) {
        this.letterOfIntentInd = letterOfIntentInd;
    }

    public String getDisplayNameEnglish() {
        return this.displayNameEnglish;
    }

    public void setDisplayNameEnglish(String displayNameEnglish) {
        this.displayNameEnglish = displayNameEnglish;
    }

    public String getDisplayNameFrench() {
        return this.displayNameFrench;
    }

    public void setDisplayNameFrench(String displayNameFrench) {
        this.displayNameFrench = displayNameFrench;
    }

    public String getAttachmentFile() {
        return this.attachmentFile;
    }

    public void setAttachmentFile(String attachmentFile) {
        this.attachmentFile = attachmentFile;
    }

    public Short getNumberOfBudgetYears() {
        return this.numberOfBudgetYears;
    }

    public void setNumberOfBudgetYears(Short numberOfBudgetYears) {
        this.numberOfBudgetYears = numberOfBudgetYears;
    }

    public String getFinalReportInd() {
        return this.finalReportInd;
    }

    public void setFinalReportInd(String finalReportInd) {
        this.finalReportInd = finalReportInd;
    }

    public String getLogoName() {
        return this.logoName;
    }

    public void setLogoName(String logoName) {
        this.logoName = logoName;
    }

    public String getFormType() {
        return this.formType;
    }

    public void setFormType(String formType) {
        this.formType = formType;
    }

    public Integer getDataEntryType() {
        return this.dataEntryType;
    }

    public void setDataEntryType(Integer dataEntryType) {
        this.dataEntryType = dataEntryType;
    }

    public hibernate.Program getProgram() {
        return this.program;
    }

    public void setProgram(hibernate.Program program) {
        this.program = program;
    }

    public Set getWebModuls() {
        return this.webModuls;
    }

    public void setWebModuls(Set webModuls) {
        this.webModuls = webModuls;
    }

    public Set getForm() {
        return this.form;
    }

    public void setForm(Set form) {
        this.form = form;
    }

    public Set getBySubsystemId() {
        return this.bySubsystemId;
    }

    public void setBySubsystemId(Set bySubsystemId) {
        this.bySubsystemId = bySubsystemId;
    }

    public Set getByPortfolioSubsystemId() {
        return this.byPortfolioSubsystemId;
    }

    public void setByPortfolioSubsystemId(Set byPortfolioSubsystemId) {
        this.byPortfolioSubsystemId = byPortfolioSubsystemId;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("subsystemId", getSubsystemId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof WebSubsystem) ) return false;
        WebSubsystem castOther = (WebSubsystem) other;
        return new EqualsBuilder()
            .append(this.getSubsystemId(), castOther.getSubsystemId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getSubsystemId())
            .toHashCode();
    }

}
