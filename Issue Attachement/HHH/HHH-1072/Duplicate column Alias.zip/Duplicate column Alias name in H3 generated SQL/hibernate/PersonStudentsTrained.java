package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class PersonStudentsTrained implements Serializable {

    /** identifier field */
    private Integer studentId;

    /** nullable persistent field */
    private Integer cid;

    /** nullable persistent field */
    private Short trainingYearFrom;

    /** nullable persistent field */
    private Short trainingYearTo;

    /** nullable persistent field */
    private String familyName;

    /** nullable persistent field */
    private String givenName;

    /** nullable persistent field */
    private String initials;

    /** nullable persistent field */
    private Integer countryCode;

    /** nullable persistent field */
    private Integer roleCode;

    /** nullable persistent field */
    private String resultOfSshrcInd;

    /** nullable persistent field */
    private Integer applId;

    /** nullable persistent field */
    private String note;

    /** nullable persistent field */
    private String gradProgInd;

    /** nullable persistent field */
    private Integer studentType;

    /** nullable persistent field */
    private String createUserId;

    /** nullable persistent field */
    private Date createDate;

    /** nullable persistent field */
    private String changeUserId;

    /** nullable persistent field */
    private Date changeDate;

    /** full constructor */
    public PersonStudentsTrained(Integer studentId, Integer cid, Short trainingYearFrom, Short trainingYearTo, String familyName, String givenName, String initials, Integer countryCode, Integer roleCode, String resultOfSshrcInd, Integer applId, String note, String gradProgInd, Integer studentType, String createUserId, Date createDate, String changeUserId, Date changeDate) {
        this.studentId = studentId;
        this.cid = cid;
        this.trainingYearFrom = trainingYearFrom;
        this.trainingYearTo = trainingYearTo;
        this.familyName = familyName;
        this.givenName = givenName;
        this.initials = initials;
        this.countryCode = countryCode;
        this.roleCode = roleCode;
        this.resultOfSshrcInd = resultOfSshrcInd;
        this.applId = applId;
        this.note = note;
        this.gradProgInd = gradProgInd;
        this.studentType = studentType;
        this.createUserId = createUserId;
        this.createDate = createDate;
        this.changeUserId = changeUserId;
        this.changeDate = changeDate;
    }

    /** default constructor */
    public PersonStudentsTrained() {
    }

    /** minimal constructor */
    public PersonStudentsTrained(Integer studentId) {
        this.studentId = studentId;
    }

    public Integer getStudentId() {
        return this.studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public Integer getCid() {
        return this.cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public Short getTrainingYearFrom() {
        return this.trainingYearFrom;
    }

    public void setTrainingYearFrom(Short trainingYearFrom) {
        this.trainingYearFrom = trainingYearFrom;
    }

    public Short getTrainingYearTo() {
        return this.trainingYearTo;
    }

    public void setTrainingYearTo(Short trainingYearTo) {
        this.trainingYearTo = trainingYearTo;
    }

    public String getFamilyName() {
        return this.familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getGivenName() {
        return this.givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getInitials() {
        return this.initials;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public Integer getCountryCode() {
        return this.countryCode;
    }

    public void setCountryCode(Integer countryCode) {
        this.countryCode = countryCode;
    }

    public Integer getRoleCode() {
        return this.roleCode;
    }

    public void setRoleCode(Integer roleCode) {
        this.roleCode = roleCode;
    }

    public String getResultOfSshrcInd() {
        return this.resultOfSshrcInd;
    }

    public void setResultOfSshrcInd(String resultOfSshrcInd) {
        this.resultOfSshrcInd = resultOfSshrcInd;
    }

    public Integer getApplId() {
        return this.applId;
    }

    public void setApplId(Integer applId) {
        this.applId = applId;
    }

    public String getNote() {
        return this.note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getGradProgInd() {
        return this.gradProgInd;
    }

    public void setGradProgInd(String gradProgInd) {
        this.gradProgInd = gradProgInd;
    }

    public Integer getStudentType() {
        return this.studentType;
    }

    public void setStudentType(Integer studentType) {
        this.studentType = studentType;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("studentId", getStudentId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof PersonStudentsTrained) ) return false;
        PersonStudentsTrained castOther = (PersonStudentsTrained) other;
        return new EqualsBuilder()
            .append(this.getStudentId(), castOther.getStudentId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getStudentId())
            .toHashCode();
    }

}
