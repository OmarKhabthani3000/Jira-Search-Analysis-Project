package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class UserSessionHistory implements Serializable {

    /** identifier field */
    private Integer sessionId;

    /** nullable persistent field */
    private Integer cid;

    /** nullable persistent field */
    private Date startSessionDatetime;

    /** nullable persistent field */
    private Date endSessionDatetime;

    /** nullable persistent field */
    private Integer numberOfAccess;

    /** full constructor */
    public UserSessionHistory(Integer sessionId, Integer cid, Date startSessionDatetime, Date endSessionDatetime, Integer numberOfAccess) {
        this.sessionId = sessionId;
        this.cid = cid;
        this.startSessionDatetime = startSessionDatetime;
        this.endSessionDatetime = endSessionDatetime;
        this.numberOfAccess = numberOfAccess;
    }

    /** default constructor */
    public UserSessionHistory() {
    }

    /** minimal constructor */
    public UserSessionHistory(Integer sessionId) {
        this.sessionId = sessionId;
    }

    public Integer getSessionId() {
        return this.sessionId;
    }

    public void setSessionId(Integer sessionId) {
        this.sessionId = sessionId;
    }

    public Integer getCid() {
        return this.cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public Date getStartSessionDatetime() {
        return this.startSessionDatetime;
    }

    public void setStartSessionDatetime(Date startSessionDatetime) {
        this.startSessionDatetime = startSessionDatetime;
    }

    public Date getEndSessionDatetime() {
        return this.endSessionDatetime;
    }

    public void setEndSessionDatetime(Date endSessionDatetime) {
        this.endSessionDatetime = endSessionDatetime;
    }

    public Integer getNumberOfAccess() {
        return this.numberOfAccess;
    }

    public void setNumberOfAccess(Integer numberOfAccess) {
        this.numberOfAccess = numberOfAccess;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("sessionId", getSessionId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof UserSessionHistory) ) return false;
        UserSessionHistory castOther = (UserSessionHistory) other;
        return new EqualsBuilder()
            .append(this.getSessionId(), castOther.getSessionId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getSessionId())
            .toHashCode();
    }

}
