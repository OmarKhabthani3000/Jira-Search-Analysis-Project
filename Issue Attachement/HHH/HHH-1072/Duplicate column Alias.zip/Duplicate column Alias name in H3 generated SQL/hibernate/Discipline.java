package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class Discipline implements Serializable {

    /** identifier field */
    private Integer disciplineCode;

    /** persistent field */
    private String nameFrench;

    /** persistent field */
    private String nameEnglish;

    /** persistent field */
    private String activeInd;

    /** persistent field */
    private Date createDate;

    /** persistent field */
    private String createUserId;

    /** persistent field */
    private Date changeDate;

    /** persistent field */
    private String changeUserId;

    /** persistent field */
    private hibernate.MainDiscipline mainDiscipline;

    /** full constructor */
    public Discipline(Integer disciplineCode, String nameFrench, String nameEnglish, String activeInd, Date createDate, String createUserId, Date changeDate, String changeUserId, hibernate.MainDiscipline mainDiscipline) {
        this.disciplineCode = disciplineCode;
        this.nameFrench = nameFrench;
        this.nameEnglish = nameEnglish;
        this.activeInd = activeInd;
        this.createDate = createDate;
        this.createUserId = createUserId;
        this.changeDate = changeDate;
        this.changeUserId = changeUserId;
        this.mainDiscipline = mainDiscipline;
    }

    /** default constructor */
    public Discipline() {
    }

    public Integer getDisciplineCode() {
        return this.disciplineCode;
    }

    public void setDisciplineCode(Integer disciplineCode) {
        this.disciplineCode = disciplineCode;
    }

    public String getNameFrench() {
        return this.nameFrench;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    public String getNameEnglish() {
        return this.nameEnglish;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public String getActiveInd() {
        return this.activeInd;
    }

    public void setActiveInd(String activeInd) {
        this.activeInd = activeInd;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public hibernate.MainDiscipline getMainDiscipline() {
        return this.mainDiscipline;
    }

    public void setMainDiscipline(hibernate.MainDiscipline mainDiscipline) {
        this.mainDiscipline = mainDiscipline;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("disciplineCode", getDisciplineCode())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof Discipline) ) return false;
        Discipline castOther = (Discipline) other;
        return new EqualsBuilder()
            .append(this.getDisciplineCode(), castOther.getDisciplineCode())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getDisciplineCode())
            .toHashCode();
    }

}
