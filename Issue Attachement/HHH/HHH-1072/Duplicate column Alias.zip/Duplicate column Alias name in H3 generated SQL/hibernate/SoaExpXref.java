package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class SoaExpXref implements Serializable {

    /** identifier field */
    private hibernate.SoaExpXrefPK comp_id;

    /** nullable persistent field */
    private Integer code;

    /** nullable persistent field */
    private Integer lineType;

    /** full constructor */
    public SoaExpXref(hibernate.SoaExpXrefPK comp_id, Integer code, Integer lineType) {
        this.comp_id = comp_id;
        this.code = code;
        this.lineType = lineType;
    }

    /** default constructor */
    public SoaExpXref() {
    }

    /** minimal constructor */
    public SoaExpXref(hibernate.SoaExpXrefPK comp_id) {
        this.comp_id = comp_id;
    }

    public hibernate.SoaExpXrefPK getComp_id() {
        return this.comp_id;
    }

    public void setComp_id(hibernate.SoaExpXrefPK comp_id) {
        this.comp_id = comp_id;
    }

    public Integer getCode() {
        return this.code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public Integer getLineType() {
        return this.lineType;
    }

    public void setLineType(Integer lineType) {
        this.lineType = lineType;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof SoaExpXref) ) return false;
        SoaExpXref castOther = (SoaExpXref) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
