package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class WebModul implements Serializable {

    /** identifier field */
    private hibernate.WebModulPK comp_id;

    /** persistent field */
    private String objectName;

    /** nullable persistent field */
    private String nameEnglish;

    /** nullable persistent field */
    private String nameFrench;

    /** nullable persistent field */
    private String shortNameEnglish;

    /** nullable persistent field */
    private String shortNameFrench;

    /** nullable persistent field */
    private String toolBar;

    /** nullable persistent field */
    private String moduleName;

    /** full constructor */
    public WebModul(hibernate.WebModulPK comp_id, String objectName, String nameEnglish, String nameFrench, String shortNameEnglish, String shortNameFrench, String toolBar, String moduleName) {
        this.comp_id = comp_id;
        this.objectName = objectName;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.shortNameEnglish = shortNameEnglish;
        this.shortNameFrench = shortNameFrench;
        this.toolBar = toolBar;
        this.moduleName = moduleName;
    }

    /** default constructor */
    public WebModul() {
    }

    /** minimal constructor */
    public WebModul(hibernate.WebModulPK comp_id, String objectName) {
        this.comp_id = comp_id;
        this.objectName = objectName;
    }

    public hibernate.WebModulPK getComp_id() {
        return this.comp_id;
    }

    public void setComp_id(hibernate.WebModulPK comp_id) {
        this.comp_id = comp_id;
    }

    public String getObjectName() {
        return this.objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public String getNameEnglish() {
        return this.nameEnglish;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public String getNameFrench() {
        return this.nameFrench;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    public String getShortNameEnglish() {
        return this.shortNameEnglish;
    }

    public void setShortNameEnglish(String shortNameEnglish) {
        this.shortNameEnglish = shortNameEnglish;
    }

    public String getShortNameFrench() {
        return this.shortNameFrench;
    }

    public void setShortNameFrench(String shortNameFrench) {
        this.shortNameFrench = shortNameFrench;
    }

    public String getToolBar() {
        return this.toolBar;
    }

    public void setToolBar(String toolBar) {
        this.toolBar = toolBar;
    }

    public String getModuleName() {
        return this.moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof WebModul) ) return false;
        WebModul castOther = (WebModul) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
