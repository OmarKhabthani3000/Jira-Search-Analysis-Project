package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class ProgCommittee implements Serializable {

    /** identifier field */
    private hibernate.ProgCommitteePK comp_id;

    /** nullable persistent field */
    private String activeInd;

    /** persistent field */
    private Date createDate;

    /** persistent field */
    private String createUserId;

    /** persistent field */
    private Date changeDate;

    /** persistent field */
    private String changeUserId;

    /** full constructor */
    public ProgCommittee(hibernate.ProgCommitteePK comp_id, String activeInd, Date createDate, String createUserId, Date changeDate, String changeUserId) {
        this.comp_id = comp_id;
        this.activeInd = activeInd;
        this.createDate = createDate;
        this.createUserId = createUserId;
        this.changeDate = changeDate;
        this.changeUserId = changeUserId;
    }

    /** default constructor */
    public ProgCommittee() {
    }

    /** minimal constructor */
    public ProgCommittee(hibernate.ProgCommitteePK comp_id, Date createDate, String createUserId, Date changeDate, String changeUserId) {
        this.comp_id = comp_id;
        this.createDate = createDate;
        this.createUserId = createUserId;
        this.changeDate = changeDate;
        this.changeUserId = changeUserId;
    }

    public hibernate.ProgCommitteePK getComp_id() {
        return this.comp_id;
    }

    public void setComp_id(hibernate.ProgCommitteePK comp_id) {
        this.comp_id = comp_id;
    }

    public String getActiveInd() {
        return this.activeInd;
    }

    public void setActiveInd(String activeInd) {
        this.activeInd = activeInd;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof ProgCommittee) ) return false;
        ProgCommittee castOther = (ProgCommittee) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
