package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class PersonNot implements Serializable {

    /** identifier field */
    private Integer notesId;

    /** persistent field */
    private int cid;

    /** persistent field */
    private int noteType;

    /** nullable persistent field */
    private String note1;

    /** nullable persistent field */
    private String note2;

    /** nullable persistent field */
    private Integer applId;

    /** nullable persistent field */
    private Date changeDate;

    /** nullable persistent field */
    private String changeUserId;

    /** nullable persistent field */
    private Date createDate;

    /** nullable persistent field */
    private String createUserId;

    /** full constructor */
    public PersonNot(Integer notesId, int cid, int noteType, String note1, String note2, Integer applId, Date changeDate, String changeUserId, Date createDate, String createUserId) {
        this.notesId = notesId;
        this.cid = cid;
        this.noteType = noteType;
        this.note1 = note1;
        this.note2 = note2;
        this.applId = applId;
        this.changeDate = changeDate;
        this.changeUserId = changeUserId;
        this.createDate = createDate;
        this.createUserId = createUserId;
    }

    /** default constructor */
    public PersonNot() {
    }

    /** minimal constructor */
    public PersonNot(Integer notesId, int cid, int noteType) {
        this.notesId = notesId;
        this.cid = cid;
        this.noteType = noteType;
    }

    public Integer getNotesId() {
        return this.notesId;
    }

    public void setNotesId(Integer notesId) {
        this.notesId = notesId;
    }

    public int getCid() {
        return this.cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public int getNoteType() {
        return this.noteType;
    }

    public void setNoteType(int noteType) {
        this.noteType = noteType;
    }

    public String getNote1() {
        return this.note1;
    }

    public void setNote1(String note1) {
        this.note1 = note1;
    }

    public String getNote2() {
        return this.note2;
    }

    public void setNote2(String note2) {
        this.note2 = note2;
    }

    public Integer getApplId() {
        return this.applId;
    }

    public void setApplId(Integer applId) {
        this.applId = applId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("notesId", getNotesId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof PersonNot) ) return false;
        PersonNot castOther = (PersonNot) other;
        return new EqualsBuilder()
            .append(this.getNotesId(), castOther.getNotesId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getNotesId())
            .toHashCode();
    }

}
