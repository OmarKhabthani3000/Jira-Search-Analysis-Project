package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class OrganizationBase implements Serializable {

    /** identifier field */
    private Integer orgId;

    /** nullable persistent field */
    private Integer parentOrgId;

    /** persistent field */
    private int orgCategoryCode;

    /** persistent field */
    private String federallyFundedInd;

    /** nullable persistent field */
    private Integer countryCode;

    /** nullable persistent field */
    private String provinceStateCode;

    /** persistent field */
    private String nameEnglish;

    /** persistent field */
    private String nameFrench;

    /** persistent field */
    private String acronymEnglish;

    /** persistent field */
    private String acronymFrench;

    /** nullable persistent field */
    private String financeName;

    /** nullable persistent field */
    private String languageCode;

    /** nullable persistent field */
    private Integer fellowshipScheduleType;

    /** nullable persistent field */
    private Integer grantScheduleType;

    /** persistent field */
    private int orgStatusCode;

    /** nullable persistent field */
    private Short kilometersFromClosestUniv;

    /** persistent field */
    private String sigEligibilityInd;

    /** persistent field */
    private String publisherInd;

    /** nullable persistent field */
    private String keywords;

    /** persistent field */
    private String globalPaymentInd;

    /** nullable persistent field */
    private Short journalFoundedYear;

    /** nullable persistent field */
    private String journalSelfAdminInd;

    /** nullable persistent field */
    private Integer journalType;

    /** nullable persistent field */
    private String journalLanguageEnglishInd;

    /** nullable persistent field */
    private String journalLanguageFrenchInd;

    /** nullable persistent field */
    private String journalLanguageOtherInd;

    /** nullable persistent field */
    private String journalLanguageOtherName;

    /** nullable persistent field */
    private String createUserId;

    /** nullable persistent field */
    private Date createDate;

    /** nullable persistent field */
    private String changeUserId;

    /** nullable persistent field */
    private Date changeDate;

    /** full constructor */
    public OrganizationBase(Integer orgId, Integer parentOrgId, int orgCategoryCode, String federallyFundedInd, Integer countryCode, String provinceStateCode, String nameEnglish, String nameFrench, String acronymEnglish, String acronymFrench, String financeName, String languageCode, Integer fellowshipScheduleType, Integer grantScheduleType, int orgStatusCode, Short kilometersFromClosestUniv, String sigEligibilityInd, String publisherInd, String keywords, String globalPaymentInd, Short journalFoundedYear, String journalSelfAdminInd, Integer journalType, String journalLanguageEnglishInd, String journalLanguageFrenchInd, String journalLanguageOtherInd, String journalLanguageOtherName, String createUserId, Date createDate, String changeUserId, Date changeDate) {
        this.orgId = orgId;
        this.parentOrgId = parentOrgId;
        this.orgCategoryCode = orgCategoryCode;
        this.federallyFundedInd = federallyFundedInd;
        this.countryCode = countryCode;
        this.provinceStateCode = provinceStateCode;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.acronymEnglish = acronymEnglish;
        this.acronymFrench = acronymFrench;
        this.financeName = financeName;
        this.languageCode = languageCode;
        this.fellowshipScheduleType = fellowshipScheduleType;
        this.grantScheduleType = grantScheduleType;
        this.orgStatusCode = orgStatusCode;
        this.kilometersFromClosestUniv = kilometersFromClosestUniv;
        this.sigEligibilityInd = sigEligibilityInd;
        this.publisherInd = publisherInd;
        this.keywords = keywords;
        this.globalPaymentInd = globalPaymentInd;
        this.journalFoundedYear = journalFoundedYear;
        this.journalSelfAdminInd = journalSelfAdminInd;
        this.journalType = journalType;
        this.journalLanguageEnglishInd = journalLanguageEnglishInd;
        this.journalLanguageFrenchInd = journalLanguageFrenchInd;
        this.journalLanguageOtherInd = journalLanguageOtherInd;
        this.journalLanguageOtherName = journalLanguageOtherName;
        this.createUserId = createUserId;
        this.createDate = createDate;
        this.changeUserId = changeUserId;
        this.changeDate = changeDate;
    }

    /** default constructor */
    public OrganizationBase() {
    }

    /** minimal constructor */
    public OrganizationBase(Integer orgId, int orgCategoryCode, String federallyFundedInd, String nameEnglish, String nameFrench, String acronymEnglish, String acronymFrench, int orgStatusCode, String sigEligibilityInd, String publisherInd, String globalPaymentInd) {
        this.orgId = orgId;
        this.orgCategoryCode = orgCategoryCode;
        this.federallyFundedInd = federallyFundedInd;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.acronymEnglish = acronymEnglish;
        this.acronymFrench = acronymFrench;
        this.orgStatusCode = orgStatusCode;
        this.sigEligibilityInd = sigEligibilityInd;
        this.publisherInd = publisherInd;
        this.globalPaymentInd = globalPaymentInd;
    }

    public Integer getOrgId() {
        return this.orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public Integer getParentOrgId() {
        return this.parentOrgId;
    }

    public void setParentOrgId(Integer parentOrgId) {
        this.parentOrgId = parentOrgId;
    }

    public int getOrgCategoryCode() {
        return this.orgCategoryCode;
    }

    public void setOrgCategoryCode(int orgCategoryCode) {
        this.orgCategoryCode = orgCategoryCode;
    }

    public String getFederallyFundedInd() {
        return this.federallyFundedInd;
    }

    public void setFederallyFundedInd(String federallyFundedInd) {
        this.federallyFundedInd = federallyFundedInd;
    }

    public Integer getCountryCode() {
        return this.countryCode;
    }

    public void setCountryCode(Integer countryCode) {
        this.countryCode = countryCode;
    }

    public String getProvinceStateCode() {
        return this.provinceStateCode;
    }

    public void setProvinceStateCode(String provinceStateCode) {
        this.provinceStateCode = provinceStateCode;
    }

    public String getNameEnglish() {
        return this.nameEnglish;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public String getNameFrench() {
        return this.nameFrench;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    public String getAcronymEnglish() {
        return this.acronymEnglish;
    }

    public void setAcronymEnglish(String acronymEnglish) {
        this.acronymEnglish = acronymEnglish;
    }

    public String getAcronymFrench() {
        return this.acronymFrench;
    }

    public void setAcronymFrench(String acronymFrench) {
        this.acronymFrench = acronymFrench;
    }

    public String getFinanceName() {
        return this.financeName;
    }

    public void setFinanceName(String financeName) {
        this.financeName = financeName;
    }

    public String getLanguageCode() {
        return this.languageCode;
    }

    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }

    public Integer getFellowshipScheduleType() {
        return this.fellowshipScheduleType;
    }

    public void setFellowshipScheduleType(Integer fellowshipScheduleType) {
        this.fellowshipScheduleType = fellowshipScheduleType;
    }

    public Integer getGrantScheduleType() {
        return this.grantScheduleType;
    }

    public void setGrantScheduleType(Integer grantScheduleType) {
        this.grantScheduleType = grantScheduleType;
    }

    public int getOrgStatusCode() {
        return this.orgStatusCode;
    }

    public void setOrgStatusCode(int orgStatusCode) {
        this.orgStatusCode = orgStatusCode;
    }

    public Short getKilometersFromClosestUniv() {
        return this.kilometersFromClosestUniv;
    }

    public void setKilometersFromClosestUniv(Short kilometersFromClosestUniv) {
        this.kilometersFromClosestUniv = kilometersFromClosestUniv;
    }

    public String getSigEligibilityInd() {
        return this.sigEligibilityInd;
    }

    public void setSigEligibilityInd(String sigEligibilityInd) {
        this.sigEligibilityInd = sigEligibilityInd;
    }

    public String getPublisherInd() {
        return this.publisherInd;
    }

    public void setPublisherInd(String publisherInd) {
        this.publisherInd = publisherInd;
    }

    public String getKeywords() {
        return this.keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getGlobalPaymentInd() {
        return this.globalPaymentInd;
    }

    public void setGlobalPaymentInd(String globalPaymentInd) {
        this.globalPaymentInd = globalPaymentInd;
    }

    public Short getJournalFoundedYear() {
        return this.journalFoundedYear;
    }

    public void setJournalFoundedYear(Short journalFoundedYear) {
        this.journalFoundedYear = journalFoundedYear;
    }

    public String getJournalSelfAdminInd() {
        return this.journalSelfAdminInd;
    }

    public void setJournalSelfAdminInd(String journalSelfAdminInd) {
        this.journalSelfAdminInd = journalSelfAdminInd;
    }

    public Integer getJournalType() {
        return this.journalType;
    }

    public void setJournalType(Integer journalType) {
        this.journalType = journalType;
    }

    public String getJournalLanguageEnglishInd() {
        return this.journalLanguageEnglishInd;
    }

    public void setJournalLanguageEnglishInd(String journalLanguageEnglishInd) {
        this.journalLanguageEnglishInd = journalLanguageEnglishInd;
    }

    public String getJournalLanguageFrenchInd() {
        return this.journalLanguageFrenchInd;
    }

    public void setJournalLanguageFrenchInd(String journalLanguageFrenchInd) {
        this.journalLanguageFrenchInd = journalLanguageFrenchInd;
    }

    public String getJournalLanguageOtherInd() {
        return this.journalLanguageOtherInd;
    }

    public void setJournalLanguageOtherInd(String journalLanguageOtherInd) {
        this.journalLanguageOtherInd = journalLanguageOtherInd;
    }

    public String getJournalLanguageOtherName() {
        return this.journalLanguageOtherName;
    }

    public void setJournalLanguageOtherName(String journalLanguageOtherName) {
        this.journalLanguageOtherName = journalLanguageOtherName;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("orgId", getOrgId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof OrganizationBase) ) return false;
        OrganizationBase castOther = (OrganizationBase) other;
        return new EqualsBuilder()
            .append(this.getOrgId(), castOther.getOrgId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getOrgId())
            .toHashCode();
    }

}
