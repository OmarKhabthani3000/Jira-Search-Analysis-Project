package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class PersonPositionPrint implements Serializable {

    /** identifier field */
    private hibernate.PersonPositionPrintPK comp_id;

    /** persistent field */
    private String printInd;

    /** full constructor */
    public PersonPositionPrint(hibernate.PersonPositionPrintPK comp_id, String printInd) {
        this.comp_id = comp_id;
        this.printInd = printInd;
    }

    /** default constructor */
    public PersonPositionPrint() {
    }

    public hibernate.PersonPositionPrintPK getComp_id() {
        return this.comp_id;
    }

    public void setComp_id(hibernate.PersonPositionPrintPK comp_id) {
        this.comp_id = comp_id;
    }

    public String getPrintInd() {
        return this.printInd;
    }

    public void setPrintInd(String printInd) {
        this.printInd = printInd;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof PersonPositionPrint) ) return false;
        PersonPositionPrint castOther = (PersonPositionPrint) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
