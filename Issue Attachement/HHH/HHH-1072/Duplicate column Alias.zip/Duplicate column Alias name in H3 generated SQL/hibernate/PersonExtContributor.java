package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class PersonExtContributor implements Serializable {

    /** identifier field */
    private int contId;

    /** identifier field */
    private Integer roleCode;

    /** identifier field */
    private String familyName;

    /** identifier field */
    private String givenName;

    /** identifier field */
    private String initials;

    /** identifier field */
    private Integer countryCode;

    /** full constructor */
    public PersonExtContributor(int contId, Integer roleCode, String familyName, String givenName, String initials, Integer countryCode) {
        this.contId = contId;
        this.roleCode = roleCode;
        this.familyName = familyName;
        this.givenName = givenName;
        this.initials = initials;
        this.countryCode = countryCode;
    }

    /** default constructor */
    public PersonExtContributor() {
    }

    public int getContId() {
        return this.contId;
    }

    public void setContId(int contId) {
        this.contId = contId;
    }

    public Integer getRoleCode() {
        return this.roleCode;
    }

    public void setRoleCode(Integer roleCode) {
        this.roleCode = roleCode;
    }

    public String getFamilyName() {
        return this.familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getGivenName() {
        return this.givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getInitials() {
        return this.initials;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public Integer getCountryCode() {
        return this.countryCode;
    }

    public void setCountryCode(Integer countryCode) {
        this.countryCode = countryCode;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("contId", getContId())
            .append("roleCode", getRoleCode())
            .append("familyName", getFamilyName())
            .append("givenName", getGivenName())
            .append("initials", getInitials())
            .append("countryCode", getCountryCode())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof PersonExtContributor) ) return false;
        PersonExtContributor castOther = (PersonExtContributor) other;
        return new EqualsBuilder()
            .append(this.getContId(), castOther.getContId())
            .append(this.getRoleCode(), castOther.getRoleCode())
            .append(this.getFamilyName(), castOther.getFamilyName())
            .append(this.getGivenName(), castOther.getGivenName())
            .append(this.getInitials(), castOther.getInitials())
            .append(this.getCountryCode(), castOther.getCountryCode())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getContId())
            .append(getRoleCode())
            .append(getFamilyName())
            .append(getGivenName())
            .append(getInitials())
            .append(getCountryCode())
            .toHashCode();
    }

}
