package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class SystemProperty implements Serializable {

    /** identifier field */
    private Long systemPropertyId;

    /** persistent field */
    private String systemPropertyScope;

    /** persistent field */
    private String systemPropertyName;

    /** persistent field */
    private String systemPropertyValue;

    /** nullable persistent field */
    private String systemPropertyDescription;

    /** nullable persistent field */
    private Date lastUpdateDatetime;

    /** full constructor */
    public SystemProperty(Long systemPropertyId, String systemPropertyScope, String systemPropertyName, String systemPropertyValue, String systemPropertyDescription, Date lastUpdateDatetime) {
        this.systemPropertyId = systemPropertyId;
        this.systemPropertyScope = systemPropertyScope;
        this.systemPropertyName = systemPropertyName;
        this.systemPropertyValue = systemPropertyValue;
        this.systemPropertyDescription = systemPropertyDescription;
        this.lastUpdateDatetime = lastUpdateDatetime;
    }

    /** default constructor */
    public SystemProperty() {
    }

    /** minimal constructor */
    public SystemProperty(Long systemPropertyId, String systemPropertyScope, String systemPropertyName, String systemPropertyValue) {
        this.systemPropertyId = systemPropertyId;
        this.systemPropertyScope = systemPropertyScope;
        this.systemPropertyName = systemPropertyName;
        this.systemPropertyValue = systemPropertyValue;
    }

    public Long getSystemPropertyId() {
        return this.systemPropertyId;
    }

    public void setSystemPropertyId(Long systemPropertyId) {
        this.systemPropertyId = systemPropertyId;
    }

    public String getSystemPropertyScope() {
        return this.systemPropertyScope;
    }

    public void setSystemPropertyScope(String systemPropertyScope) {
        this.systemPropertyScope = systemPropertyScope;
    }

    public String getSystemPropertyName() {
        return this.systemPropertyName;
    }

    public void setSystemPropertyName(String systemPropertyName) {
        this.systemPropertyName = systemPropertyName;
    }

    public String getSystemPropertyValue() {
        return this.systemPropertyValue;
    }

    public void setSystemPropertyValue(String systemPropertyValue) {
        this.systemPropertyValue = systemPropertyValue;
    }

    public String getSystemPropertyDescription() {
        return this.systemPropertyDescription;
    }

    public void setSystemPropertyDescription(String systemPropertyDescription) {
        this.systemPropertyDescription = systemPropertyDescription;
    }

    public Date getLastUpdateDatetime() {
        return this.lastUpdateDatetime;
    }

    public void setLastUpdateDatetime(Date lastUpdateDatetime) {
        this.lastUpdateDatetime = lastUpdateDatetime;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("systemPropertyId", getSystemPropertyId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof SystemProperty) ) return false;
        SystemProperty castOther = (SystemProperty) other;
        return new EqualsBuilder()
            .append(this.getSystemPropertyId(), castOther.getSystemPropertyId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getSystemPropertyId())
            .toHashCode();
    }

}
