package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class ProgGrantType implements Serializable {

    /** identifier field */
    private hibernate.ProgGrantTypePK comp_id;

    /** nullable persistent field */
    private Integer dataEntryType;

    /** nullable persistent field */
    private String sigEligibleInd;

    /** persistent field */
    private String activeInd;

    /** full constructor */
    public ProgGrantType(hibernate.ProgGrantTypePK comp_id, Integer dataEntryType, String sigEligibleInd, String activeInd) {
        this.comp_id = comp_id;
        this.dataEntryType = dataEntryType;
        this.sigEligibleInd = sigEligibleInd;
        this.activeInd = activeInd;
    }

    /** default constructor */
    public ProgGrantType() {
    }

    /** minimal constructor */
    public ProgGrantType(hibernate.ProgGrantTypePK comp_id, String activeInd) {
        this.comp_id = comp_id;
        this.activeInd = activeInd;
    }

    public hibernate.ProgGrantTypePK getComp_id() {
        return this.comp_id;
    }

    public void setComp_id(hibernate.ProgGrantTypePK comp_id) {
        this.comp_id = comp_id;
    }

    public Integer getDataEntryType() {
        return this.dataEntryType;
    }

    public void setDataEntryType(Integer dataEntryType) {
        this.dataEntryType = dataEntryType;
    }

    public String getSigEligibleInd() {
        return this.sigEligibleInd;
    }

    public void setSigEligibleInd(String sigEligibleInd) {
        this.sigEligibleInd = sigEligibleInd;
    }

    public String getActiveInd() {
        return this.activeInd;
    }

    public void setActiveInd(String activeInd) {
        this.activeInd = activeInd;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof ProgGrantType) ) return false;
        ProgGrantType castOther = (ProgGrantType) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
