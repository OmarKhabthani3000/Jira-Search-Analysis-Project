package hibernate;

import java.io.*;
import java.util.*;

import org.apache.commons.lang.builder.*;

/** @author Hibernate CodeGenerator */
public class Country implements Serializable {

    /** identifier field */
    private Integer countryCode;

    /** persistent field */
    private String nameEnglish;

    /** persistent field */
    private String nameFrench;

    /** persistent field */
    private String activeInd;

    /** nullable persistent field */
    private String countryCodeIsoAlpha3;

    private Set organization = new HashSet();


    /** full constructor */
    public Country(Integer countryCode, String nameEnglish, String nameFrench, String activeInd, String countryCodeIsoAlpha3) {
        this.countryCode = countryCode;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.activeInd = activeInd;
        this.countryCodeIsoAlpha3 = countryCodeIsoAlpha3;
    }

    /** default constructor */
    public Country() {
    }

    /** minimal constructor */
    public Country(Integer countryCode, String nameEnglish, String nameFrench, String activeInd) {
        this.countryCode = countryCode;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.activeInd = activeInd;
    }

    public Integer getCountryCode() {
        return this.countryCode;
    }

    public void setCountryCode(Integer countryCode) {
        this.countryCode = countryCode;
    }

    public String getNameEnglish() {
        return this.nameEnglish;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public String getNameFrench() {
        return this.nameFrench;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    public String getActiveInd() {
        return this.activeInd;
    }

    public void setActiveInd(String activeInd) {
        this.activeInd = activeInd;
    }

    public String getCountryCodeIsoAlpha3() {
        return this.countryCodeIsoAlpha3;
    }

    public Set getOrganization() {
        return organization;
    }

    public void setCountryCodeIsoAlpha3(String countryCodeIsoAlpha3) {
        this.countryCodeIsoAlpha3 = countryCodeIsoAlpha3;
    }

    public void setOrganization(Set organization) {
        this.organization = organization;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("countryCode", getCountryCode())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof Country) ) return false;
        Country castOther = (Country) other;
        return new EqualsBuilder()
            .append(this.getCountryCode(), castOther.getCountryCode())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getCountryCode())
            .toHashCode();
    }

}
