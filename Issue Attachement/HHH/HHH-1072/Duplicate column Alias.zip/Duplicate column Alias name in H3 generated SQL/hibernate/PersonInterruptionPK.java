package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class PersonInterruptionPK implements Serializable {

    /** identifier field */
    private Integer cid;

    /** identifier field */
    private Date fromDate;

    /** full constructor */
    public PersonInterruptionPK(Integer cid, Date fromDate) {
        this.cid = cid;
        this.fromDate = fromDate;
    }

    /** default constructor */
    public PersonInterruptionPK() {
    }

    public Integer getCid() {
        return this.cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public Date getFromDate() {
        return this.fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("cid", getCid())
            .append("fromDate", getFromDate())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof PersonInterruptionPK) ) return false;
        PersonInterruptionPK castOther = (PersonInterruptionPK) other;
        return new EqualsBuilder()
            .append(this.getCid(), castOther.getCid())
            .append(this.getFromDate(), castOther.getFromDate())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getCid())
            .append(getFromDate())
            .toHashCode();
    }

}
