package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class PersonExtParticipant implements Serializable {

    /** identifier field */
    private int extSupportId;

    /** identifier field */
    private Integer roleCode;

    /** identifier field */
    private String familyName;

    /** identifier field */
    private String givenName;

    /** identifier field */
    private String initials;

    /** identifier field */
    private Integer countryCode;

    /** full constructor */
    public PersonExtParticipant(int extSupportId, Integer roleCode, String familyName, String givenName, String initials, Integer countryCode) {
        this.extSupportId = extSupportId;
        this.roleCode = roleCode;
        this.familyName = familyName;
        this.givenName = givenName;
        this.initials = initials;
        this.countryCode = countryCode;
    }

    /** default constructor */
    public PersonExtParticipant() {
    }

    public int getExtSupportId() {
        return this.extSupportId;
    }

    public void setExtSupportId(int extSupportId) {
        this.extSupportId = extSupportId;
    }

    public Integer getRoleCode() {
        return this.roleCode;
    }

    public void setRoleCode(Integer roleCode) {
        this.roleCode = roleCode;
    }

    public String getFamilyName() {
        return this.familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getGivenName() {
        return this.givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getInitials() {
        return this.initials;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public Integer getCountryCode() {
        return this.countryCode;
    }

    public void setCountryCode(Integer countryCode) {
        this.countryCode = countryCode;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("extSupportId", getExtSupportId())
            .append("roleCode", getRoleCode())
            .append("familyName", getFamilyName())
            .append("givenName", getGivenName())
            .append("initials", getInitials())
            .append("countryCode", getCountryCode())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof PersonExtParticipant) ) return false;
        PersonExtParticipant castOther = (PersonExtParticipant) other;
        return new EqualsBuilder()
            .append(this.getExtSupportId(), castOther.getExtSupportId())
            .append(this.getRoleCode(), castOther.getRoleCode())
            .append(this.getFamilyName(), castOther.getFamilyName())
            .append(this.getGivenName(), castOther.getGivenName())
            .append(this.getInitials(), castOther.getInitials())
            .append(this.getCountryCode(), castOther.getCountryCode())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getExtSupportId())
            .append(getRoleCode())
            .append(getFamilyName())
            .append(getGivenName())
            .append(getInitials())
            .append(getCountryCode())
            .toHashCode();
    }

}
