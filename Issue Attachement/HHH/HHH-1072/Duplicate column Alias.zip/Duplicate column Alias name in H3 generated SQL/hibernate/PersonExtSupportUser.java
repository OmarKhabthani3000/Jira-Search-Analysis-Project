package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class PersonExtSupportUser implements Serializable {

    /** identifier field */
    private Integer extSupportId;

    /** identifier field */
    private Integer orgCategoryCode;

    /** full constructor */
    public PersonExtSupportUser(Integer extSupportId, Integer orgCategoryCode) {
        this.extSupportId = extSupportId;
        this.orgCategoryCode = orgCategoryCode;
    }

    /** default constructor */
    public PersonExtSupportUser() {
    }

    public Integer getExtSupportId() {
        return this.extSupportId;
    }

    public void setExtSupportId(Integer extSupportId) {
        this.extSupportId = extSupportId;
    }

    public Integer getOrgCategoryCode() {
        return this.orgCategoryCode;
    }

    public void setOrgCategoryCode(Integer orgCategoryCode) {
        this.orgCategoryCode = orgCategoryCode;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("extSupportId", getExtSupportId())
            .append("orgCategoryCode", getOrgCategoryCode())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof PersonExtSupportUser) ) return false;
        PersonExtSupportUser castOther = (PersonExtSupportUser) other;
        return new EqualsBuilder()
            .append(this.getExtSupportId(), castOther.getExtSupportId())
            .append(this.getOrgCategoryCode(), castOther.getOrgCategoryCode())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getExtSupportId())
            .append(getOrgCategoryCode())
            .toHashCode();
    }

}
