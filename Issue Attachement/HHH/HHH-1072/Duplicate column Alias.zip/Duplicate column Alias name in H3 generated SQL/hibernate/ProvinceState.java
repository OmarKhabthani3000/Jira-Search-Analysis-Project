package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class ProvinceState implements Serializable {

    /** identifier field */
    private String provinceStateCode;

    /** persistent field */
    private String nameEnglish;

    /** persistent field */
    private String nameFrench;

    /** nullable persistent field */
    private Integer sequenceNumber;

    /** persistent field */
    private String activeInd;

    /** full constructor */
    public ProvinceState(String provinceStateCode, String nameEnglish, String nameFrench, Integer sequenceNumber, String activeInd) {
        this.provinceStateCode = provinceStateCode;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.sequenceNumber = sequenceNumber;
        this.activeInd = activeInd;
    }

    /** default constructor */
    public ProvinceState() {
    }

    /** minimal constructor */
    public ProvinceState(String provinceStateCode, String nameEnglish, String nameFrench, String activeInd) {
        this.provinceStateCode = provinceStateCode;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.activeInd = activeInd;
    }

    public String getProvinceStateCode() {
        return this.provinceStateCode;
    }

    public void setProvinceStateCode(String provinceStateCode) {
        this.provinceStateCode = provinceStateCode;
    }

    public String getNameEnglish() {
        return this.nameEnglish;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public String getNameFrench() {
        return this.nameFrench;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    public Integer getSequenceNumber() {
        return this.sequenceNumber;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String getActiveInd() {
        return this.activeInd;
    }

    public void setActiveInd(String activeInd) {
        this.activeInd = activeInd;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("provinceStateCode", getProvinceStateCode())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof ProvinceState) ) return false;
        ProvinceState castOther = (ProvinceState) other;
        return new EqualsBuilder()
            .append(this.getProvinceStateCode(), castOther.getProvinceStateCode())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getProvinceStateCode())
            .toHashCode();
    }

}
