package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class CodesCategory implements Serializable {

    /** identifier field */
    private hibernate.CodesCategoryPK comp_id;

    /** nullable persistent field */
    private Integer sequenceNumber;

    /** nullable persistent field */
    private Date createDate;

    /** nullable persistent field */
    private String createUserId;

    /** nullable persistent field */
    private Date changeDate;

    /** nullable persistent field */
    private String changeUserId;

    /** full constructor */
    public CodesCategory(hibernate.CodesCategoryPK comp_id, Integer sequenceNumber, Date createDate, String createUserId, Date changeDate, String changeUserId) {
        this.comp_id = comp_id;
        this.sequenceNumber = sequenceNumber;
        this.createDate = createDate;
        this.createUserId = createUserId;
        this.changeDate = changeDate;
        this.changeUserId = changeUserId;
    }

    /** default constructor */
    public CodesCategory() {
    }

    /** minimal constructor */
    public CodesCategory(hibernate.CodesCategoryPK comp_id) {
        this.comp_id = comp_id;
    }

    public hibernate.CodesCategoryPK getComp_id() {
        return this.comp_id;
    }

    public void setComp_id(hibernate.CodesCategoryPK comp_id) {
        this.comp_id = comp_id;
    }

    public Integer getSequenceNumber() {
        return this.sequenceNumber;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof CodesCategory) ) return false;
        CodesCategory castOther = (CodesCategory) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
