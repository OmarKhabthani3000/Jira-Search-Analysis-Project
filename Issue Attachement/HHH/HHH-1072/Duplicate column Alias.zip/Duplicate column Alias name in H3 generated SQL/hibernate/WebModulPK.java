package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class WebModulPK implements Serializable {

    /** identifier field */
    private Integer sequenceNumber;

    /** identifier field */
    private hibernate.WebSubsystem webSubsystem;

    /** full constructor */
    public WebModulPK(Integer sequenceNumber, hibernate.WebSubsystem webSubsystem) {
        this.sequenceNumber = sequenceNumber;
        this.webSubsystem = webSubsystem;
    }

    /** default constructor */
    public WebModulPK() {
    }

    public Integer getSequenceNumber() {
        return this.sequenceNumber;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public hibernate.WebSubsystem getWebSubsystem() {
        return this.webSubsystem;
    }

    public void setWebSubsystem(hibernate.WebSubsystem webSubsystem) {
        this.webSubsystem = webSubsystem;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("sequenceNumber", getSequenceNumber())
            .append("webSubsystem", getWebSubsystem())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof WebModulPK) ) return false;
        WebModulPK castOther = (WebModulPK) other;
        return new EqualsBuilder()
            .append(this.getSequenceNumber(), castOther.getSequenceNumber())
            .append(this.getWebSubsystem(), castOther.getWebSubsystem())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getSequenceNumber())
            .append(getWebSubsystem())
            .toHashCode();
    }

}
