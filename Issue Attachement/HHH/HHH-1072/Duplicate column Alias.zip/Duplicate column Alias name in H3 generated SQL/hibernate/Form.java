package hibernate;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;

import org.apache.commons.lang.builder.*;

/** @author Hibernate CodeGenerator */
public class Form implements Serializable {

    /** identifier field */
    private Long formId;

    /** identifier field */
    private Integer cid;

    /** persistent field */
    private String formLanguage;

    /** persistent field */
    private String formStatus;

    /** nullable persistent field */
    private Date transferredToAmisDate;

    /** nullable persistent field */
    private String transferredToAmisIndicator;

    /** persistent field */
    private String createUserId;

    /** persistent field */
    private Date createDate;

    /** persistent field */
    private String changeUserId;

    /** persistent field */
    private Date changeDate;

    /** persistent field */
    private hibernate.Application application;

    /** persistent field */
    private hibernate.WebSubsystem webSubsystem;

    /** persistent field */
    private Person person;


    /** full constructor */
    public Form(Long formId, String formLanguage, String formStatus, Date transferredToAmisDate,
                String transferredToAmisIndicator, String createUserId, Date createDate, String changeUserId,
                Date changeDate, hibernate.Application application, hibernate.WebSubsystem webSubsystem, hibernate.Person person) {
        this.formId = formId;
        this.formLanguage = formLanguage;
        this.formStatus = formStatus;
        this.transferredToAmisDate = transferredToAmisDate;
        this.transferredToAmisIndicator = transferredToAmisIndicator;
        this.createUserId = createUserId;
        this.createDate = createDate;
        this.changeUserId = changeUserId;
        this.changeDate = (Timestamp) changeDate;
        this.application = application;
        this.webSubsystem = webSubsystem;
        this.person = person;
    }

    /** default constructor */
    public Form() {
    }

    /** minimal constructor */
    public Form(Long formId, String formLanguage, String formStatus, String createUserId,
                Date createDate, String changeUserId, Date changeDate, hibernate.Application application,
                hibernate.WebSubsystem webSubsystem) {
        this.formId = formId;
        this.formLanguage = formLanguage;
        this.formStatus = formStatus;
        this.createUserId = createUserId;
        this.createDate = createDate;
        this.changeUserId = changeUserId;
        this.changeDate = (Timestamp) changeDate;
        this.application = application;
        this.webSubsystem = webSubsystem;
    }

    public Long getFormId() {
        return this.formId;
    }

    public void setFormId(Long formId) {
        this.formId = formId;
    }

    public String getFormLanguage() {
        return this.formLanguage;
    }

    public void setFormLanguage(String formLanguage) {
        this.formLanguage = formLanguage;
    }

    public String getFormStatus() {
        return this.formStatus;
    }

    public void setFormStatus(String formStatus) {
        this.formStatus = formStatus;
    }

    public Date getTransferredToAmisDate() {
        return this.transferredToAmisDate;
    }

    public void setTransferredToAmisDate(Date transferredToAmisDate) {
        this.transferredToAmisDate = transferredToAmisDate;
    }

    public String getTransferredToAmisIndicator() {
        return this.transferredToAmisIndicator;
    }

    public void setTransferredToAmisIndicator(String transferredToAmisIndicator) {
        this.transferredToAmisIndicator = transferredToAmisIndicator;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = (Timestamp) changeDate;
    }

    public hibernate.Application getApplication() {
        return this.application;
    }

    public void setApplication(hibernate.Application application) {
        this.application = application;
    }

    public hibernate.WebSubsystem getWebSubsystem() {
        return this.webSubsystem;
    }

    public Person getPerson() {
        return person;
    }

    public Integer getCid() {
        return cid;
    }

    public void setWebSubsystem(hibernate.WebSubsystem webSubsystem) {
        this.webSubsystem = webSubsystem;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public String toString() {
        return new ToStringBuilder(this)
                .append("formId", getFormId())
                .toString();
    }

    public boolean equals(Object other) {
        if (!(other instanceof Form)) {
            return false;
        }
        Form castOther = (Form) other;
        return new EqualsBuilder()
                .append(this.getFormId(), castOther.getFormId())
                .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
                .append(getFormId())
                .toHashCode();
    }

}
