package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class WebModuleBeanClassPK implements Serializable {

    /** identifier field */
    private hibernate.WebSubsystem webSubsystem;

    /** identifier field */
    private String moduleName;

    /** identifier field */
    private String beanClassName;

    /** full constructor */
    public WebModuleBeanClassPK(hibernate.WebSubsystem webSubsystem, String moduleName, String beanClassName) {
        this.webSubsystem = webSubsystem;
        this.moduleName = moduleName;
        this.beanClassName = beanClassName;
    }

    /** default constructor */
    public WebModuleBeanClassPK() {
    }

    public hibernate.WebSubsystem getWebSubsystem() {
        return this.webSubsystem;
    }

    public void setWebSubsystem(hibernate.WebSubsystem webSubsystem) {
        this.webSubsystem = webSubsystem;
    }

    public String getModuleName() {
        return this.moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String getBeanClassName() {
        return this.beanClassName;
    }

    public void setBeanClassName(String beanClassName) {
        this.beanClassName = beanClassName;
    }

    public String toString() {
        return new ToStringBuilder(this).append("webSubsystem", getWebSubsystem()).append("moduleName",
                getModuleName()).append("beanClassName", getBeanClassName()).toString();
    }

    public boolean equals(Object other) {
        if (!(other instanceof WebModuleBeanClassPK)) {
            return false;
        }
        WebModuleBeanClassPK castOther = (WebModuleBeanClassPK) other;
        return new EqualsBuilder().append(this.getWebSubsystem(),
                castOther.getWebSubsystem()).append(this.getModuleName(),
                castOther.getModuleName()).append(this.getBeanClassName(), castOther.getBeanClassName())
                .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
                .append(getWebSubsystem())
                .append(getModuleName())
                .append(getBeanClassName())
                .toHashCode();
    }

}
