package hibernate;

import java.io.*;
import java.util.*;

import org.apache.commons.lang.builder.*;

/** @author Hibernate CodeGenerator */
public class PersonPosition implements Serializable {

    /** identifier field */
    private Integer positionId;

    /** persistent field */
    private Integer cid;

    /** nullable persistent field */
    private OrgDeptLocation orgDeptLocation;

    /** nullable persistent field */
    private Cod positionNumber;

    /** nullable persistent field */
    private Integer positionType;

    /** nullable persistent field */
    private String primaryOrgInd;

    /** nullable persistent field */
    private String salariedInd;

    /** nullable persistent field */
    private Integer employmentType;

    /** nullable persistent field */
    private String leaveOfAbsenceInd;

    /** nullable persistent field */
    private Short positionStartYear;

    /** nullable persistent field */
    private Short positionEndYear;

    /** nullable persistent field */
    private String otherOrgName;

    /** nullable persistent field */
    private String otherDepartmentName;

    /** nullable persistent field */
    private String otherPositionName;

    /** nullable persistent field */
    private String addressTitleLine2;

    /** nullable persistent field */
    private String phoneCountryCode;

    /** nullable persistent field */
    private String phoneAreaCode;

    /** nullable persistent field */
    private String phoneNumber;

    /** nullable persistent field */
    private String phoneExtension;

    /** nullable persistent field */
    private String faxCountryCode;

    /** nullable persistent field */
    private String faxAreaCode;

    /** nullable persistent field */
    private String faxNumber;

    /** nullable persistent field */
    private String faxPhoneExtension;

    /** nullable persistent field */
    private String emailAddress;

    /** nullable persistent field */
    private String scndEmailAddress;

    /** nullable persistent field */
    private Date dateAppointed;

    /** nullable persistent field */
    private String personInd;

    /** nullable persistent field */
    private String scndPhoneCountryCode;

    /** nullable persistent field */
    private String scndPhoneAreaCode;

    /** nullable persistent field */
    private String scndPhoneNumber;

    /** nullable persistent field */
    private String scndPhoneExtension;

    /** nullable persistent field */
    private String scndFaxCountryCode;

    /** nullable persistent field */
    private String scndFaxPhoneAreaCode;

    /** nullable persistent field */
    private String scndFaxPhoneNumber;

    /** nullable persistent field */
    private String scndFaxPhoneExtension;

    /** nullable persistent field */
    private String createUserId;

    /** nullable persistent field */
    private Date createDate;

    /** nullable persistent field */
    private String changeUserId;

    /** nullable persistent field */
    private Date changeDate;

    /** nullable persistent field */
    private Organization organization;

    /** nullable persistent field */
    private String notCurrentlyRegistered;

    /** nullable persistent field */
    private String positionStartMonth;

    /** nullable persistent field */
    private String positionEndMonth;

    /** nullable persistent field */
    private Integer originalOrgDeptLocId;

    /** nullable persistent field */
    private Integer originalOrgId;

    /** full constructor */
    public PersonPosition(Integer positionId, Integer cid, OrgDeptLocation orgDeptLocation, Cod positionNumber, Integer positionType, String primaryOrgInd, String salariedInd, Integer employmentType, String leaveOfAbsenceInd, Short positionStartYear, Short positionEndYear, String otherOrgName, String otherDepartmentName, String otherPositionName, String addressTitleLine2, String phoneCountryCode, String phoneAreaCode, String phoneNumber, String phoneExtension, String faxCountryCode, String faxAreaCode, String faxNumber, String faxPhoneExtension, String emailAddress, String scndEmailAddress, Date dateAppointed, String personInd, String scndPhoneCountryCode, String scndPhoneAreaCode, String scndPhoneNumber, String scndPhoneExtension, String scndFaxCountryCode, String scndFaxPhoneAreaCode, String scndFaxPhoneNumber, String scndFaxPhoneExtension, String createUserId, Date createDate, String changeUserId, Date changeDate, Organization organization, String notCurrentlyRegistered, String positionStartMonth, String positionEndMonth, Integer originalOrgId, Integer originalOrgDeptLocId) {
        this.positionId = positionId;
        this.cid = cid;
        this.orgDeptLocation = orgDeptLocation;
        this.positionNumber = positionNumber;
        this.positionType = positionType;
        this.primaryOrgInd = primaryOrgInd;
        this.salariedInd = salariedInd;
        this.employmentType = employmentType;
        this.leaveOfAbsenceInd = leaveOfAbsenceInd;
        this.positionStartYear = positionStartYear;
        this.positionEndYear = positionEndYear;
        this.otherOrgName = otherOrgName;
        this.otherDepartmentName = otherDepartmentName;
        this.otherPositionName = otherPositionName;
        this.addressTitleLine2 = addressTitleLine2;
        this.phoneCountryCode = phoneCountryCode;
        this.phoneAreaCode = phoneAreaCode;
        this.phoneNumber = phoneNumber;
        this.phoneExtension = phoneExtension;
        this.faxCountryCode = faxCountryCode;
        this.faxAreaCode = faxAreaCode;
        this.faxNumber = faxNumber;
        this.faxPhoneExtension = faxPhoneExtension;
        this.emailAddress = emailAddress;
        this.scndEmailAddress = scndEmailAddress;
        this.dateAppointed = dateAppointed;
        this.personInd = personInd;
        this.scndPhoneCountryCode = scndPhoneCountryCode;
        this.scndPhoneAreaCode = scndPhoneAreaCode;
        this.scndPhoneNumber = scndPhoneNumber;
        this.scndPhoneExtension = scndPhoneExtension;
        this.scndFaxCountryCode = scndFaxCountryCode;
        this.scndFaxPhoneAreaCode = scndFaxPhoneAreaCode;
        this.scndFaxPhoneNumber = scndFaxPhoneNumber;
        this.scndFaxPhoneExtension = scndFaxPhoneExtension;
        this.createUserId = createUserId;
        this.createDate = createDate;
        this.changeUserId = changeUserId;
        this.changeDate = changeDate;
        this.organization = organization;
        this.notCurrentlyRegistered = notCurrentlyRegistered;
        this.positionStartMonth = positionStartMonth;
        this.positionEndMonth = positionEndMonth;
        this.originalOrgDeptLocId = originalOrgDeptLocId;
        this.originalOrgId = originalOrgId;
    }

    /** default constructor */
    public PersonPosition() {
    }

    /** minimal constructor */
    public PersonPosition(Integer positionId, Integer cid) {
        this.positionId = positionId;
        this.cid = cid;
    }

    public Integer getPositionId() {
        return this.positionId;
    }

    public void setPositionId(Integer positionId) {
        this.positionId = positionId;
    }

    public Integer getCid() {
        return this.cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public OrgDeptLocation getOrgDeptLocation() {
        if (null == this.orgDeptLocation) {
            return new OrgDeptLocation();
        } else {
            return this.orgDeptLocation;
        }
    }

    public void setOrgDeptLocation(OrgDeptLocation orgDeptLocation) {
        this.orgDeptLocation = orgDeptLocation;
    }

    public Cod getPositionNumber() {
        if (null == this.positionNumber) {
            return new Cod();
        } else {
            return this.positionNumber;
        }
    }

    public void setPositionNumber(Cod positionNumber) {
        this.positionNumber = positionNumber;
    }

    public Integer getPositionType() {
        return this.positionType;
    }

    public void setPositionType(Integer positionType) {
        this.positionType = positionType;
    }

    public String getPrimaryOrgInd() {
        return this.primaryOrgInd;
    }

    public void setPrimaryOrgInd(String primaryOrgInd) {
        this.primaryOrgInd = primaryOrgInd;
    }

    public String getSalariedInd() {
        return this.salariedInd;
    }

    public void setSalariedInd(String salariedInd) {
        this.salariedInd = salariedInd;
    }

    public Integer getEmploymentType() {
        return this.employmentType;
    }

    public void setEmploymentType(Integer employmentType) {
        this.employmentType = employmentType;
    }

    public String getLeaveOfAbsenceInd() {
        return this.leaveOfAbsenceInd;
    }

    public void setLeaveOfAbsenceInd(String leaveOfAbsenceInd) {
        this.leaveOfAbsenceInd = leaveOfAbsenceInd;
    }

    public Short getPositionStartYear() {
        return this.positionStartYear;
    }

    public void setPositionStartYear(Short positionStartYear) {
        this.positionStartYear = positionStartYear;
    }

    public Short getPositionEndYear() {
        return this.positionEndYear;
    }

    public void setPositionEndYear(Short positionEndYear) {
        this.positionEndYear = positionEndYear;
    }

    public String getOtherOrgName() {
        return this.otherOrgName;
    }

    public void setOtherOrgName(String otherOrgName) {
        this.otherOrgName = otherOrgName;
    }

    public String getOtherDepartmentName() {
        return this.otherDepartmentName;
    }

    public void setOtherDepartmentName(String otherDepartmentName) {
        this.otherDepartmentName = otherDepartmentName;
    }

    public String getOtherPositionName() {
        return this.otherPositionName;
    }

    public void setOtherPositionName(String otherPositionName) {
        this.otherPositionName = otherPositionName;
    }

    public String getAddressTitleLine2() {
        return this.addressTitleLine2;
    }

    public void setAddressTitleLine2(String addressTitleLine2) {
        this.addressTitleLine2 = addressTitleLine2;
    }

    public String getPhoneCountryCode() {
        return this.phoneCountryCode;
    }

    public void setPhoneCountryCode(String phoneCountryCode) {
        this.phoneCountryCode = phoneCountryCode;
    }

    public String getPhoneAreaCode() {
        return this.phoneAreaCode;
    }

    public void setPhoneAreaCode(String phoneAreaCode) {
        this.phoneAreaCode = phoneAreaCode;
    }

    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPhoneExtension() {
        return this.phoneExtension;
    }

    public void setPhoneExtension(String phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public String getFaxCountryCode() {
        return this.faxCountryCode;
    }

    public void setFaxCountryCode(String faxCountryCode) {
        this.faxCountryCode = faxCountryCode;
    }

    public String getFaxAreaCode() {
        return this.faxAreaCode;
    }

    public void setFaxAreaCode(String faxAreaCode) {
        this.faxAreaCode = faxAreaCode;
    }

    public String getFaxNumber() {
        return this.faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public String getFaxPhoneExtension() {
        return this.faxPhoneExtension;
    }

    public void setFaxPhoneExtension(String faxPhoneExtension) {
        this.faxPhoneExtension = faxPhoneExtension;
    }

    public String getEmailAddress() {
        return this.emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getScndEmailAddress() {
        return this.scndEmailAddress;
    }

    public void setScndEmailAddress(String scndEmailAddress) {
        this.scndEmailAddress = scndEmailAddress;
    }

    public Date getDateAppointed() {
        return this.dateAppointed;
    }

    public void setDateAppointed(Date dateAppointed) {
        this.dateAppointed = dateAppointed;
    }

    public String getPersonInd() {
        return this.personInd;
    }

    public void setPersonInd(String personInd) {
        this.personInd = personInd;
    }

    public String getScndPhoneCountryCode() {
        return this.scndPhoneCountryCode;
    }

    public void setScndPhoneCountryCode(String scndPhoneCountryCode) {
        this.scndPhoneCountryCode = scndPhoneCountryCode;
    }

    public String getScndPhoneAreaCode() {
        return this.scndPhoneAreaCode;
    }

    public void setScndPhoneAreaCode(String scndPhoneAreaCode) {
        this.scndPhoneAreaCode = scndPhoneAreaCode;
    }

    public String getScndPhoneNumber() {
        return this.scndPhoneNumber;
    }

    public void setScndPhoneNumber(String scndPhoneNumber) {
        this.scndPhoneNumber = scndPhoneNumber;
    }

    public String getScndPhoneExtension() {
        return this.scndPhoneExtension;
    }

    public void setScndPhoneExtension(String scndPhoneExtension) {
        this.scndPhoneExtension = scndPhoneExtension;
    }

    public String getScndFaxCountryCode() {
        return this.scndFaxCountryCode;
    }

    public void setScndFaxCountryCode(String scndFaxCountryCode) {
        this.scndFaxCountryCode = scndFaxCountryCode;
    }

    public String getScndFaxPhoneAreaCode() {
        return this.scndFaxPhoneAreaCode;
    }

    public void setScndFaxPhoneAreaCode(String scndFaxPhoneAreaCode) {
        this.scndFaxPhoneAreaCode = scndFaxPhoneAreaCode;
    }

    public String getScndFaxPhoneNumber() {
        return this.scndFaxPhoneNumber;
    }

    public void setScndFaxPhoneNumber(String scndFaxPhoneNumber) {
        this.scndFaxPhoneNumber = scndFaxPhoneNumber;
    }

    public String getScndFaxPhoneExtension() {
        return this.scndFaxPhoneExtension;
    }

    public void setScndFaxPhoneExtension(String scndFaxPhoneExtension) {
        this.scndFaxPhoneExtension = scndFaxPhoneExtension;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Organization getOrganization() {
        if (null == this.organization) {
            return new Organization();
        } else {
            return this.organization;
        }
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public String getNotCurrentlyRegistered() {
        return this.notCurrentlyRegistered;
    }

    public void setNotCurrentlyRegistered(String notCurrentlyRegistered) {
        this.notCurrentlyRegistered = notCurrentlyRegistered;
    }

    public String getPositionStartMonth() {
        return this.positionStartMonth;
    }

    public void setPositionStartMonth(String positionStartMonth) {
        this.positionStartMonth = positionStartMonth;
    }

    public String getPositionEndMonth() {
        return this.positionEndMonth;
    }

    public void setPositionEndMonth(String positionEndMonth) {
        this.positionEndMonth = positionEndMonth;
    }

    public Integer getOriginalOrgDeptLocId() {
        return this.originalOrgDeptLocId;
    }

    public Integer getOriginalOrgId() {
        return originalOrgId;
    }

    public void setOriginalOrgDeptLocId(Integer originalOrgDeptLocId) {
        this.originalOrgDeptLocId = originalOrgDeptLocId;
    }

    public void setOriginalOrgId(Integer originalOrgId) {
        this.originalOrgId = originalOrgId;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("positionId", getPositionId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof PersonPosition) ) return false;
        PersonPosition castOther = (PersonPosition) other;
        return new EqualsBuilder()
            .append(this.getPositionId(), castOther.getPositionId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getPositionId())
            .toHashCode();
    }

}
