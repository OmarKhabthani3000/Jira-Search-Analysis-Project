package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class MessagePK implements Serializable {

    /** identifier field */
    private Integer messageId;

    /** identifier field */
    private String language;

    /** full constructor */
    public MessagePK(Integer messageId, String language) {
        this.messageId = messageId;
        this.language = language;
    }

    /** default constructor */
    public MessagePK() {
    }

    public Integer getMessageId() {
        return this.messageId;
    }

    public void setMessageId(Integer messageId) {
        this.messageId = messageId;
    }

    public String getLanguage() {
        return this.language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("messageId", getMessageId())
            .append("language", getLanguage())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof MessagePK) ) return false;
        MessagePK castOther = (MessagePK) other;
        return new EqualsBuilder()
            .append(this.getMessageId(), castOther.getMessageId())
            .append(this.getLanguage(), castOther.getLanguage())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getMessageId())
            .append(getLanguage())
            .toHashCode();
    }

}
