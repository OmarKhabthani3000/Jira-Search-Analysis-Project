package hibernate;

import java.io.Serializable;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class MainDiscipline implements Serializable {

    /** identifier field */
    private Integer mainDisciplineCode;

    /** persistent field */
    private String nameEnglish;

    /** persistent field */
    private String nameFrench;

    /** persistent field */
    private String activeInd;


    /** full constructor */
    public MainDiscipline(Integer mainDisciplineCode, String nameEnglish, String nameFrench, String activeInd) {
        this.mainDisciplineCode = mainDisciplineCode;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.activeInd = activeInd;
    }

    /** default constructor */
    public MainDiscipline() {
    }

    public Integer getMainDisciplineCode() {
        return this.mainDisciplineCode;
    }

    public void setMainDisciplineCode(Integer mainDisciplineCode) {
        this.mainDisciplineCode = mainDisciplineCode;
    }

    public String getNameEnglish() {
        return this.nameEnglish;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public String getNameFrench() {
        return this.nameFrench;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    public String getActiveInd() {
        return this.activeInd;
    }

    public void setActiveInd(String activeInd) {
        this.activeInd = activeInd;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("mainDisciplineCode", getMainDisciplineCode())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof MainDiscipline) ) return false;
        MainDiscipline castOther = (MainDiscipline) other;
        return new EqualsBuilder()
            .append(this.getMainDisciplineCode(), castOther.getMainDisciplineCode())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getMainDisciplineCode())
            .toHashCode();
    }

}
