package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class WebSubsystemCrossrefPK implements Serializable {

    /** identifier field */
    private hibernate.WebSubsystem bySubsystemId;

    /** identifier field */
    private hibernate.WebSubsystem byPortfolioSubsystemId;

    /** full constructor */
    public WebSubsystemCrossrefPK(hibernate.WebSubsystem bySubsystemId, hibernate.WebSubsystem byPortfolioSubsystemId) {
        this.bySubsystemId = bySubsystemId;
        this.byPortfolioSubsystemId = byPortfolioSubsystemId;
    }

    /** default constructor */
    public WebSubsystemCrossrefPK() {
    }

    public hibernate.WebSubsystem getBySubsystemId() {
        return this.bySubsystemId;
    }

    public void setBySubsystemId(hibernate.WebSubsystem bySubsystemId) {
        this.bySubsystemId = bySubsystemId;
    }

    public hibernate.WebSubsystem getByPortfolioSubsystemId() {
        return this.byPortfolioSubsystemId;
    }

    public void setByPortfolioSubsystemId(hibernate.WebSubsystem byPortfolioSubsystemId) {
        this.byPortfolioSubsystemId = byPortfolioSubsystemId;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("bySubsystemId", getBySubsystemId())
            .append("byPortfolioSubsystemId", getByPortfolioSubsystemId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof WebSubsystemCrossrefPK) ) return false;
        WebSubsystemCrossrefPK castOther = (WebSubsystemCrossrefPK) other;
        return new EqualsBuilder()
            .append(this.getBySubsystemId(), castOther.getBySubsystemId())
            .append(this.getByPortfolioSubsystemId(), castOther.getByPortfolioSubsystemId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getBySubsystemId())
            .append(getByPortfolioSubsystemId())
            .toHashCode();
    }

}
