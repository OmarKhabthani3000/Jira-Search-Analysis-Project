package hibernate;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class ProgCommitteeOldPK implements Serializable {

    /** identifier field */
    private Integer programId;

    /** identifier field */
    private Integer committeeId;

    /** full constructor */
    public ProgCommitteeOldPK(Integer programId, Integer committeeId) {
        this.programId = programId;
        this.committeeId = committeeId;
    }

    /** default constructor */
    public ProgCommitteeOldPK() {
    }

    public Integer getProgramId() {
        return this.programId;
    }

    public void setProgramId(Integer programId) {
        this.programId = programId;
    }

    public Integer getCommitteeId() {
        return this.committeeId;
    }

    public void setCommitteeId(Integer committeeId) {
        this.committeeId = committeeId;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("programId", getProgramId())
            .append("committeeId", getCommitteeId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof ProgCommitteeOldPK) ) return false;
        ProgCommitteeOldPK castOther = (ProgCommitteeOldPK) other;
        return new EqualsBuilder()
            .append(this.getProgramId(), castOther.getProgramId())
            .append(this.getCommitteeId(), castOther.getCommitteeId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getProgramId())
            .append(getCommitteeId())
            .toHashCode();
    }

}
