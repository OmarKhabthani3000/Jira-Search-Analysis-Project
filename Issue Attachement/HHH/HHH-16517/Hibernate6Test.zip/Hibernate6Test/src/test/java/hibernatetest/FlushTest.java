package hibernatetest;

import static org.junit.Assert.assertEquals;

import java.io.Serializable;
import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.junit.jupiter.api.Test;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.PrimaryKeyJoinColumn;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
class BaseEntity implements Serializable {
    private static final long serialVersionUID = -5412503864464287451L;

    @Id long id;
    @Column(name = "VAL") int val;
}

@Entity
@PrimaryKeyJoinColumn(name = "ID")
class FooEntity extends BaseEntity {
    private static final long serialVersionUID = 6681665021507587925L;

    @Column(name = "NAME") String name;

    FooEntity() {}

    FooEntity(long id) {
        this.id = id;
    }
}

@Entity
class SingleTableEntity implements Serializable {
    private static final long serialVersionUID = -5412503864464287451L;

    @Id long id;
    @Column(name = "NAME") String name;

    SingleTableEntity() {}

    SingleTableEntity(long id) {
        this.id = id;
    }
}

public class FlushTest {

    @Test
    public void test() {
        Transaction txn = null;
        try (final Session session = newSessionFactory().openSession()) {
            txn = session.beginTransaction();
            final FooEntity foo = new FooEntity(1L);
            session.persist(foo);
            session.flush();
            session.clear();

            FooEntity fetched = session.get(FooEntity.class, 1L);
            fetched.name = "string";
            session.flush();
            session.clear();
            fetched = session.get(FooEntity.class, 1L);
            fetched.name = "string2";
            // This flush does not generate update, and it should
            session.flush();
            session.clear();
            fetched = session.get(FooEntity.class, 1L);
            assertEquals("string2", fetched.name);
            txn.rollback();
        }
    }

    @Test
    public void testSingleTable() {
        Transaction txn = null;
        try (final Session session = newSessionFactory().openSession()) {
            txn = session.beginTransaction();
            final SingleTableEntity foo = new SingleTableEntity(1L);
            session.persist(foo);
            session.flush();
            session.clear();

            SingleTableEntity fetched = session.get(SingleTableEntity.class, 1L);
            fetched.name = "string";
            session.flush();
            session.clear();
            fetched = session.get(SingleTableEntity.class, 1L);
            fetched.name = "string2";
            session.flush();
            session.clear();
            fetched = session.get(SingleTableEntity.class, 1L);
            assertEquals("string2", fetched.name);
            txn.rollback();
        }
    }

    protected SessionFactory newSessionFactory() {
        final Properties properties = new Properties();
        // log settings
        properties.put("hibernate.hbm2ddl.auto", "create");
        properties.put("hibernate.show_sql", "true");
        // driver settings
        properties.put("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        properties.put("hibernate.connection.driver_class", "org.hsqldb.jdbc.JDBCDriver");
        properties.put("hibernate.connection.url", "jdbc:hsqldb:mem:test");
        properties.put("hibernate.connection.username", "sa");
        properties.put("hibernate.connection.password", "");
        properties.put("hibernate.jdbc.batch_size", "2");

        return new Configuration().addProperties(properties)
                                  .addAnnotatedClass(BaseEntity.class)
                                  .addAnnotatedClass(FooEntity.class)
                                  .addAnnotatedClass(SingleTableEntity.class)
                                  .buildSessionFactory(new StandardServiceRegistryBuilder().applySettings(properties).build());
    }
}
