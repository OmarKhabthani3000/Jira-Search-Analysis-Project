
package testhibernateinner;

import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

public class TestInner extends TestCase
{

   private SessionFactory sessionFactory;

   private ConfigurableApplicationContext applicationContext;

   private PlatformTransactionManager transactionManager;

   private HibernateTemplate ht;


   protected void setUp() throws Exception
   {
      applicationContext = new ClassPathXmlApplicationContext("testhibernateinner/testContext.xml");
      sessionFactory = (SessionFactory) applicationContext.getBean("sessionFactory");
      transactionManager = (PlatformTransactionManager) applicationContext.getBean("transactionManager");

      ht = new HibernateTemplate(sessionFactory);

      createData();
   }

   protected void tearDown() throws Exception
   {
      applicationContext.close();
   }

   public void testInnerTwoClasses()
   {
      final TransactionStatus tx = transactionManager.getTransaction(new DefaultTransactionDefinition(
            TransactionDefinition.PROPAGATION_REQUIRES_NEW));
      
      // Find all members of family "Smith" with an event on the same day as their specified datevalue

      DetachedCriteria c = DetachedCriteria.forClass(Person.class, "a");
      c.add(Restrictions.eq("lastname", "Smith"));

      DetachedCriteria sub = DetachedCriteria.forClass(Event.class);
      sub.setProjection(Projections.property("id"));
      sub.add(Restrictions.eqProperty("datevalue", "a.datevalue"));

      c.add(Subqueries.exists(sub));

      List persons = ht.findByCriteria(c);

      // exactly one result expected: Mary Smith

      assertEquals(1, persons.size());
      
      Person p = (Person) persons.get(0);
      assertEquals("Mary", p.getFirstname());

      transactionManager.commit(tx);
   }

   public void testInnerSameClass()
   {
      final TransactionStatus tx = transactionManager.getTransaction(new DefaultTransactionDefinition(
            TransactionDefinition.PROPAGATION_REQUIRES_NEW));

      // Find member of familiy "Smith" with oldest datevalue 
      
      DetachedCriteria c = DetachedCriteria.forClass(Person.class, "a");
      c.add(Restrictions.eq("lastname", "Smith"));

      DetachedCriteria sub = DetachedCriteria.forClass(Person.class);
      sub.setProjection(Projections.property("id"));
      sub.add(Restrictions.eqProperty("lastname", "a.lastname"));
      sub.add(Restrictions.gtProperty("datevalue", "a.datevalue"));

      c.add(Subqueries.exists(sub));

      List persons = ht.findByCriteria(c);
      
      // exactly one result expected: John Smith

      assertEquals(1, persons.size());

      Person p = (Person) persons.get(0);
      assertEquals("John", p.getFirstname());

      transactionManager.commit(tx);
   }

   private void createData()
   {
      final TransactionStatus tx = transactionManager.getTransaction(new DefaultTransactionDefinition(
            TransactionDefinition.PROPAGATION_REQUIRES_NEW));

      ht.deleteAll(ht.findByCriteria(DetachedCriteria.forClass(Person.class)));
      ht.deleteAll(ht.findByCriteria(DetachedCriteria.forClass(Event.class)));

      Person a = new Person();
      a.setLastname("Smith");
      a.setFirstname("John");
      a.setDatevalue(new Date(1972 - 1900, 10 - 1, 19 - 1));
      ht.saveOrUpdate(a);

      Person b = new Person();
      b.setLastname("Smith");
      b.setFirstname("Mary");
      b.setDatevalue(new Date(1975 - 1900, 5 - 1, 9 - 1));
      ht.saveOrUpdate(b);

      Person c = new Person();
      c.setLastname("Peter");
      c.setFirstname("Miller");
      c.setDatevalue(new Date(1970 - 1900, 6 - 1, 24 - 1));
      ht.saveOrUpdate(c);

      Event x = new Event();
      x.setMessage("Something happened");
      x.setDatevalue(new Date(1975 - 1900, 5 - 1, 9 - 1));
      ht.saveOrUpdate(x);

      transactionManager.commit(tx);
   }

}
