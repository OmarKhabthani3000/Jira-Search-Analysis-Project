
package testhibernateinner;

import java.util.Date;

public class Event
{
   private Long id;

   private String message;

   private Date datevalue;

   public Long getId()
   {
      return id;
   }

   public void setId(Long id)
   {
      this.id = id;
   }

   public String getMessage()
   {
      return message;
   }

   public void setMessage(String message)
   {
      this.message = message;
   }

   public Date getDatevalue()
   {
      return datevalue;
   }

   public void setDatevalue(Date date)
   {
      this.datevalue = date;
   }

   
}
