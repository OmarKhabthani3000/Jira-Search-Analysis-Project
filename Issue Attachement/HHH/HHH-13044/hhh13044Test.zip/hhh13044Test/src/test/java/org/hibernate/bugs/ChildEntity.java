package org.hibernate.bugs;

import javax.persistence.*;

@Entity(name="ChildEntity")
@Table(name="Child")
public class ChildEntity {

    @Id
    private Long id;

    @MapsId
    @ManyToOne(optional = false, targetEntity = ParentEntity.class)
    private ParentEntity parent;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ParentEntity getParent() {
        return parent;
    }

    public void setParent(ParentEntity parent) {
        this.parent = parent;
    }
}
