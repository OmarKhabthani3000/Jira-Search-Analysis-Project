package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void hhh13044Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		entityManager.setFlushMode(FlushModeType.COMMIT); // Only fails for flushMode commit

		ParentEntity parent = new ParentEntity();
		ChildEntity child = new ChildEntity(); // Child uses mapsId on parent
		child.setParent(parent);
		parent.addChild(child);

		entityManager.persist(parent);
		entityManager.persist(child);

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
