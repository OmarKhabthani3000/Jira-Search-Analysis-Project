package org.fgaule;

import org.hamcrest.CoreMatchers;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TestCase {

    private EntityManager entityManager;
    private EntityManagerFactory entityManagerFactory;
    private EntityTransaction transaction;

    @Before
    public void setup() {
        System.out.println("Creating entity manager and persistence unit.");
        this.entityManagerFactory = Persistence.createEntityManagerFactory("test-jpa-converters");
        this.entityManager = this.entityManagerFactory.createEntityManager();
        this.transaction = this.entityManager.getTransaction();
        System.out.println("Done creating entity manager and persistence unit.");

        persistEntity();
    }

    @Test
    public void criteria_isMember_fails() {

        this.transaction.begin();

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();

        CriteriaQuery<MyEntity> q = cb.createQuery(MyEntity.class);
        Root<MyEntity> c = q.from(MyEntity.class);

        q.where(cb.isMember("CAI", c.<Set<String>>get("teams")));
        //java.lang.IllegalArgumentException: unknown collection expression type [org.hibernate.jpa.criteria.path.SingularAttributePath]

        List<MyEntity> resultList = entityManager.createQuery(q).getResultList();

        this.transaction.commit();

        Assert.assertThat(resultList, CoreMatchers.notNullValue());
        Assert.assertThat(resultList.size(), CoreMatchers.is(1));

        System.out.println(resultList);

    }

    @Test
    public void criteria_equalToSet_return1Element() {

        this.transaction.begin();

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();

        CriteriaQuery<MyEntity> q = cb.createQuery(MyEntity.class);
        Root<MyEntity> c = q.from(MyEntity.class);

        Set<String> a = new HashSet<String>();
        a.add("CAI");
        q.where(cb.equal(c.get("teams"), a));
        // java.lang.ClassCastException: java.lang.String cannot be cast to java.util.Set


        List<MyEntity> resultList = entityManager.createQuery(q).getResultList();

        this.transaction.commit();

        Assert.assertThat(resultList, CoreMatchers.notNullValue());
        Assert.assertThat(resultList.size(), CoreMatchers.is(1));

        System.out.println(resultList);

    }

    @Test
    public void criteria_equalToString_return1Element() {

        this.transaction.begin();

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();

        CriteriaQuery<MyEntity> q = cb.createQuery(MyEntity.class);
        Root<MyEntity> c = q.from(MyEntity.class);


        q.where(cb.equal(c.get("teams"), "CAI"));
        // java.lang.IllegalArgumentException: Parameter value [CAI] did not match expected type [java.util.Set (n/a)]

        List<MyEntity> resultList = entityManager.createQuery(q).getResultList();

        this.transaction.commit();

        Assert.assertThat(resultList, CoreMatchers.notNullValue());
        Assert.assertThat(resultList.size(), CoreMatchers.is(1));

        System.out.println(resultList);

    }

    private void persistEntity() {
        this.transaction.begin();

        Set<String> myTeams = new HashSet<String>();
        myTeams.add("CAI");

        MyEntity entity = new MyEntity();
        entity.setTeams(myTeams);
        this.entityManager.persist(entity);

        this.transaction.commit();
    }

    @After
    public void shutDown() throws SQLException {
        System.out.println("Closing persistence unit.");
        this.transaction = null;

        if (this.entityManager != null && this.entityManager.isOpen()) {
            this.entityManager.close();
        }

        if (this.entityManagerFactory != null && this.entityManagerFactory.isOpen()) {
            this.entityManagerFactory.close();
        }
        System.out.println("Persistence unit closed.");

    }

}
