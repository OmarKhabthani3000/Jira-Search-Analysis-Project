package org.fgaule;

import javax.annotation.Generated;
import javax.persistence.*;
import java.util.Set;

/**
 * Created by Edward Nygma on 27/7/2015.
 */
@Entity
public class MyEntity {


    private Long id;

    private Set<String> teams;

    public MyEntity() {
    }

    public MyEntity(Set<String> teams) {
        this.teams = teams;
    }

    @Id
    @GeneratedValue
    @Column(name="ID")
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Convert(converter = TeamsConverter.class)
    @Column(name = "MY_ENTITY_FIELDS")
    public Set<String> getTeams() {
        return teams;
    }

    public void setTeams(Set<String> teams) {
        this.teams = teams;
    }
}
