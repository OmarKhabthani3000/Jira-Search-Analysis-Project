package org.fgaule;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Set;

/**
 * Created by Edward Nygma on 27/7/2015.
 */
@Entity
public class MyEntity {


    private Long id;

    private Set<String> teams;

    private Set<String> foes;

    public MyEntity() {
    }

    public MyEntity(Set<String> teams) {
        this.teams = teams;
    }

    @Id
    @GeneratedValue
    @Column(name="ID")
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Convert(converter = TeamsConverter.class)
    @Column(name = "MY_ENTITY_FIELDS")
    public Set<String> getTeams() {
        return teams;
    }

    public void setTeams(Set<String> teams) {
        this.teams = teams;
    }

    @Column(name = "MY_ENTITY_FOES")
    @Type( type = "org.fgaule.TeamUserType" )
    public Set<String> getFoes() {
        return foes;
    }

    public MyEntity setFoes(Set<String> foes) {
        this.foes = foes;
        return this;
    }
}
