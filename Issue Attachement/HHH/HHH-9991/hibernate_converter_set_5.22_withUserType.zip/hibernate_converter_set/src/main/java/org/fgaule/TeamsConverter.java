package org.fgaule;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Edward Nygma on 27/7/2015.
 */
@Converter
public class TeamsConverter implements AttributeConverter<Set, String> {
    public String convertToDatabaseColumn(Set set) {
        return set == null ? null : String.join("|", set);
    }

    public Set convertToEntityAttribute(String s) {
        HashSet set = new HashSet();
        if (s != null) {
            for (String splitted : s.split("|")) {
                set.add(splitted);
            }
        }
        return set;

    }
}
