/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.hibernate.bugs;

import ac.simons.entities.A;
import ac.simons.entities.AB;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;
import org.junit.Test;

/**
 *
 * @author Michael J. Simons, 2015-12-09
 */
public class HHH8886Test {

    
    @Test
    public void f() {
	final EntityManagerFactory emf = Persistence.createEntityManagerFactory("HHH-8886");
	final EntityManager em = emf.createEntityManager();
	final CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
	CriteriaQuery<A> query = criteriaBuilder.createQuery(A.class);
	final Root<A> root = query.from(A.class);

	final Subquery<String> subquery = query.subquery(String.class);

	final Root<AB> subqueryRoot = subquery.from(AB.class);

	// Additional restrictions are missing and would be present in production code
	// Expected query is something like
	/*
	SELECT a.*
	FROM   a  
	WHERE  EXISTS (SELECT '' 
		       FROM   ab intersection 
		       WHERE  intersection.a_id = a.id 
			 AND  intersection.foobar_id = a.foobar_id) 
	*/
	// The query will be correctly generated if you rename A#id to something else...	
	List<A> a1s = em.createQuery(
		query.select(root).where(criteriaBuilder.exists(
		subquery.select(criteriaBuilder.literal("")).where(
		criteriaBuilder.equal(subqueryRoot.get("a1"), root)
	)
	))
	).getResultList();
    }

}
