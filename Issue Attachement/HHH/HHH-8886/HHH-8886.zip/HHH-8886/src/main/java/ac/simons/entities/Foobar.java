package ac.simons.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Foobar implements Serializable {

    private static final long serialVersionUID = -1590584730789764160L;

    @Id    
    private Integer id;

    @Column(name = "ref_date")
    @Temporal(TemporalType.DATE)
    private Date refDate;

    protected Foobar() {
    }

    public Foobar(Date refDate) {
	this.refDate = refDate;
    }

    public Integer getId() {
	return id;
    }

    public Date getRefDate() {
	return refDate;
    }

    @Override
    public int hashCode() {
	int hash = 7;
	hash = 67 * hash + Objects.hashCode(this.refDate);
	return hash;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj) {
	    return true;
	}
	if (obj == null) {
	    return false;
	}
	if (getClass() != obj.getClass()) {
	    return false;
	}
	final Foobar other = (Foobar) obj;
	if (!Objects.equals(this.refDate, other.refDate)) {
	    return false;
	}
	return true;
    }

}
