package ac.simons.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
public class A implements Serializable {

    private static final long serialVersionUID = -3998987427422042724L;

    @Id
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "foobar_id")
    @Fetch(FetchMode.JOIN)
    private Foobar foobar;

    @Id
    @Column(name = "id")
    // Rename attribute to something different, database column name can be the same
    private Long id;

    protected A() {
    }

    public A(Foobar foobar, Long id) {
	this.foobar = foobar;
	this.id = id;
    }

    public Foobar getFoobar() {
	return foobar;
    }

    public Long getId() {
	return id;
    }

    @Override
    public int hashCode() {
	int hash = 7;
	hash = 47 * hash + Objects.hashCode(this.foobar);
	hash = 47 * hash + Objects.hashCode(this.id);
	return hash;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj) {
	    return true;
	}
	if (obj == null) {
	    return false;
	}
	if (getClass() != obj.getClass()) {
	    return false;
	}
	final A other = (A) obj;
	if (!Objects.equals(this.foobar, other.foobar)) {
	    return false;
	}
	return Objects.equals(this.id, other.id);
    }
}
