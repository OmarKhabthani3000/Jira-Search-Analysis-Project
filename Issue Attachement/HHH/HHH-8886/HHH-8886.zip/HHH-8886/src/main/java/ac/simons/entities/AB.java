package ac.simons.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
public class AB implements Serializable {

    private static final long serialVersionUID = 4572746570117233628L;

    @Id
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumns({
	@JoinColumn(name = "foobar_id", referencedColumnName = "foobar_id"),
	@JoinColumn(name = "a_id", referencedColumnName = "id")
    })
    private A a1;

    @Id
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "b_id")
    @Fetch(FetchMode.JOIN)
    private B b1;

    @Column(name = "lfdnr", nullable = true)
    private Integer lfdnr;

    protected AB() {
    }

    public AB(A a1, B b1, Integer lfdnr) {
	this.a1 = a1;
	this.b1 = b1;
	this.lfdnr = lfdnr;
    }

    public A getA1() {
	return a1;
    }

    public B getB1() {
	return b1;
    }

    public Integer getLfdnr() {
	return lfdnr;
    }

    public void setLfdnr(Integer lfdnr) {
	this.lfdnr = lfdnr;
    }

    @Override
    public int hashCode() {
	int hash = 7;
	hash = 83 * hash + Objects.hashCode(this.a1);
	hash = 83 * hash + Objects.hashCode(this.b1);
	return hash;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj) {
	    return true;
	}
	if (obj == null) {
	    return false;
	}
	if (getClass() != obj.getClass()) {
	    return false;
	}
	final AB other = (AB) obj;
	if (!Objects.equals(this.a1, other.a1)) {
	    return false;
	}
	return Objects.equals(this.b1, other.b1);
    }
}
