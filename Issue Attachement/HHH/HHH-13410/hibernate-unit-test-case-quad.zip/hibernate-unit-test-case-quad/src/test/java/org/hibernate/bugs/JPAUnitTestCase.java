package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.magneto.entities.geo.GeoCountry;
import com.magneto.entities.geo.GeoDistrict;
import com.magneto.entities.geo.GeoDistrictDetail;
import com.magneto.entities.geo.GeoNation;
/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
/**
 * @author akarsh.jain
 *
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}
	
	/* ========================================================
	 * 
	 * 						Quad Test
	 * 
	 * ========================================================*/
	
	// Reported case
	@Test
	public void InsertQuadTest1() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		GeoCountry gc = new GeoCountry();
		GeoDistrict gd1 = new GeoDistrict();
		gd1.setDistrictName("Corncob");
		GeoDistrictDetail gdDetail = new GeoDistrictDetail();
		gd1.setGeoDistrictDetail(gdDetail);
		GeoNation gn = new GeoNation();
		gn.setNationName("Cornfield");
		gc.setCountryName("Cornranch");

		entityManager.persist(gc);
		List<GeoDistrict> gdList = new ArrayList<>();
		gd1.setCountryId(gc.getId());
		gdList.add(gd1);
		gc.setDistricts(gdList);
		entityManager.persist(gd1);
		
		entityManager.persist(gn);
		
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
}
