package com.main;

public class MainMethod {

	public static void main(String[] args) {
		System.out.println("lulz");
	}

}
