package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import org.example.entity.Property;

public class PropertyDao {

    private final EntityManagerFactory emf;

    private boolean saved;

    public PropertyDao() {
        emf = Persistence.createEntityManagerFactory("default");
    }

    public void create(Property property) {
        try (EntityManager em = emf.createEntityManager()) {
            EntityTransaction transaction = em.getTransaction();
            transaction.begin();
            em.persist(property);
            transaction.commit();
        }
    }

    public void update(Property property) {
        try (EntityManager em = emf.createEntityManager()) {
            EntityTransaction transaction = em.getTransaction();
            transaction.begin();
            em.merge(property);
            transaction.commit();
        }
    }

    public Property get(Property.Key key) {
        try (EntityManager em = emf.createEntityManager()) {
            return em.find(Property.class, key);
        }
    }
}