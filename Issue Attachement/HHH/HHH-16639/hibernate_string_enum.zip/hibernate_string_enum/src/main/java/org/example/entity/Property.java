package org.example.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;

@Entity
public class Property {

    public enum Key {
        KEY1,
        KEY2,
        KEY3
    }

    public Property() {
    }

    public Property(Key key, String value) {
        this.key = key;
        this.value = value;
    }

    @Id
    @Enumerated(EnumType.STRING)
    private Key key;

    @Column
    private String value;

    public Key getKey() {
        return key;
    }

    public void setKey(Key key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
