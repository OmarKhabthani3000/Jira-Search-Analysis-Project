package org.example;

import org.example.entity.Property;
import org.example.entity.Property.Key;
import org.junit.jupiter.api.Test;

public class PropertyDaoTest {

    private PropertyDao propertyDao = new PropertyDao();

    @Test
    public void test() {
        propertyDao.create(new Property(Key.KEY1, "value1"));
        propertyDao.create(new Property(Key.KEY2, "value2"));

        Property property = propertyDao.get(Key.KEY1);
        property.setValue("value1 updated");
        propertyDao.update(property);

        Property property2 = propertyDao.get(Key.KEY2);
        property2.setValue("value2 updated");
        propertyDao.update(property2);
    }
}
