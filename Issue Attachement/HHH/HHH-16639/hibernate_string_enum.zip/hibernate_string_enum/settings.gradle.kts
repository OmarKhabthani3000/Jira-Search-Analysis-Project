rootProject.name = "hibernate_string_enum"

