package org.projpa2.chapter9;

import org.junit.Before;
import org.junit.Test;
import org.projpa2.chapter9.model.Employee;
import org.projpa2.chapter9.model.Project;
import org.projpa2.chapter9.model.QualityProject;

import javax.persistence.*;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * Created by cuneyt.tuna on 3/27/2015.
 */
public class QualityProjectTest {

    private static EntityManagerFactory entityManagerFactory;

    @Before
    public void setUp()
    {
        entityManagerFactory = Persistence.createEntityManagerFactory("persistenceUnit");
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        // Enable transactions

        Employee employee = new Employee().setId(1).setName("John");
        Project qp1 = new QualityProject().setQualityRating(4).setId(1).setName("QP-1");
        Project qp2 = new QualityProject().setQualityRating(6).setId(2).setName("QP-2");
        employee.addProject(qp1);
        employee.addProject(qp2);

        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();
        entityManager.persist(employee);
        transaction.commit();
        entityManager.close();
    }

    @Test
    public void testTreat() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Employee> cq = cb.createQuery(Employee.class);
        Root<Employee> emp = cq.from(Employee.class);
        Join<Object, QualityProject> project = cb.treat(emp.join("projects"), QualityProject.class);
        cq.select(emp)
                .where(cb.gt(project.<Integer>get("qualityRating"), 5));

        TypedQuery<Employee> typedQuery = entityManager.createQuery(cq);
        List<Employee> employees = typedQuery.getResultList();
        Collection<Project> actual = employees.get(0).getProjects();

        Collection<Project> expected = Arrays.asList(new QualityProject().setQualityRating(6).setId(2).setName("QP-2"));

        assertThat(actual, is(expected));
    }
}