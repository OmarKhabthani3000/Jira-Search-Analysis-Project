package org.projpa2.chapter9.model;

import javax.persistence.Entity;
import javax.persistence.DiscriminatorValue;

@Entity
@DiscriminatorValue("QP")
public class QualityProject extends Project {
    public Integer getQualityRating() {
        return qualityRating;
    }

    public QualityProject setQualityRating(Integer qualityRating) {
        this.qualityRating = qualityRating;
        return this;
    }

    private Integer qualityRating;

}
