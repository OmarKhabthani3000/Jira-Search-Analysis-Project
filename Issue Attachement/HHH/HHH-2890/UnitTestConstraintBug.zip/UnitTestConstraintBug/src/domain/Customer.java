package domain;

public class Customer
{
	private String name;

	private String firstName;

	private Long id;

	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	public void setName(String nom)
	{
		this.name = nom;
	}

	public String getName()
	{
		return name;
	}

	public void setFirstName(String prenom)
	{
		this.firstName = prenom;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public String toString()
	{
		return "(" + getId() + "," + name + "," + firstName + ")";
	}
}
