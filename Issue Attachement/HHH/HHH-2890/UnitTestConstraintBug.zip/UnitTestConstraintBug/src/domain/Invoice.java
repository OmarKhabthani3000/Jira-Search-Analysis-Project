package domain;

import java.util.Date;

public class Invoice
{
	private Long id;

	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	private Date invoiceDate;

	private Customer customer;

	public Customer getCustomer()
	{
		return customer;
	}

	public Date getInvoiceDate()
	{
		return invoiceDate;
	}

	public void setCustomer(Customer client)
	{
		this.customer = client;
	}

	public void setInvoiceDate(Date dateFacture)
	{
		this.invoiceDate = dateFacture;
	}
}
