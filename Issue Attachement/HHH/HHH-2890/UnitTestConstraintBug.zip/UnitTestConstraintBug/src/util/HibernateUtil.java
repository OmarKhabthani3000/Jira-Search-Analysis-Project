package util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil
{
	private static Log log = LogFactory.getLog(HibernateUtil.class);

	private static org.hibernate.Session session;

	private static final SessionFactory sessionFactory;

	static
	{
		try
		{
			// Create the SessionFactory
			sessionFactory = new Configuration().configure().buildSessionFactory();
		}
		catch (Throwable ex)
		{
			log.error("Initial SessionFactory creation failed.", ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static Session currentSession() throws HibernateException
	{
		session = sessionFactory.getCurrentSession();
		return session;
	}

	public static void closeSession() throws HibernateException
	{
		if (session != null && session.isOpen())
		{
			session.close();
		}
		session = null;
	}
	
	public static void beginTransaction()
	{
//		if(session.getTransaction()!=null)
//		{
//			throw new IllegalStateException("Transaction d�j� en cours");
//		}
		session.beginTransaction();
	}
	
	public static void commit()
	{
		if(session.getTransaction()==null)
		{
			throw new IllegalStateException();
		}
		session.getTransaction().commit();
	}
}
