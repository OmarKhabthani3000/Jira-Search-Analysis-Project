package test;

import java.util.Date;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;

import util.HibernateUtil;
import domain.Customer;
import domain.Invoice;

public class ConstraintTest extends TestCase
{
	public void testDeletion()
	{
		// Let's create a client that is referenced by an invoice
		Session session = HibernateUtil.currentSession();
		HibernateUtil.beginTransaction();

		Customer c = new Customer();
		c.setName("The one");
		c.setFirstName("his firstname");

		Invoice f = new Invoice();
		f.setCustomer(c);
		f.setInvoiceDate(new Date());

		session.save(c);
		session.save(f);
		HibernateUtil.commit();

		// Try to delete the client, but not the invoice
		try
		{
			Session session2 = HibernateUtil.currentSession();
			assertNotSame(session, session2);
			HibernateUtil.beginTransaction();

			session2.delete(c);
			HibernateUtil.commit();
		}
		catch (ConstraintViolationException e)
		{
			// OK
		}
	}
}
