package de.reproducer.persistence;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import lombok.Data;

import java.math.BigDecimal;
import java.util.UUID;


@Data
@Entity
@IdClass(ChildPrimaryKey.class)
public class MyEntity {

    @Id
    private UUID parentId;

    @Id()
    private UUID childId;

}
