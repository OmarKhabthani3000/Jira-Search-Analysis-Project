package test.dom4j;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * @author psheldon
 * 
 * Created on Apr 27, 2005
 */
public class Ethnicity implements java.io.Serializable {

	private long id;

	private String descriptor;

	public Ethnicity() {

	}

	public Ethnicity(long id, String desc) {
		this.id = id;
		this.descriptor = desc;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!this.getClass().equals(obj.getClass())) {
            return false;
        }
        boolean result = false;
        if (obj instanceof Ethnicity) {
			Ethnicity castOther = (Ethnicity) obj;
            result = new EqualsBuilder()
                .append(this.getId(), castOther.getId())
                .append(this.getDescriptor(), castOther.getDescriptor())
                .isEquals();
        }
        return result;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(getId()).append(getDescriptor()).toHashCode();
    }
}
