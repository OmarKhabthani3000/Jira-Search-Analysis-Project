package test.dom4j;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentFactory;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.hibernate.EntityMode;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import junit.framework.TestCase;

/**
 * This class tests that the XML output is correct.
 * Hibernate v3.0.1 was working correctly for set one-to-many mappings but
 * Hibernate v3.0.2 was creating two instances of the imbedded set results.
 * 
 * @author psheldon
 * 
 * Created on Apr 27, 2005
 */
public class Dom4JSetTest extends TestCase {

	/** The single instance of hibernate SessionFactory */
	private static SessionFactory sessionFactory;

	/**
	 * This method always returns successful but display the XML output.
	 * @throws Exception
	 */
	public void testDom4JSetMapping() throws Exception {

		XMLWriter writer = new XMLWriter(System.out, OutputFormat
				.createPrettyPrint());
		Document doc = DocumentFactory.getInstance().createDocument();
		doc.addElement("people");
		Session session = getSession().getSession(EntityMode.DOM4J);
		List results = session.createQuery("from Person person").list();
		
		for (Iterator i = results.iterator(); i.hasNext();) {
			Element e = (Element) i.next();
			doc.getRootElement().add(e);
		}
		getSession().close();

		//Write out the XML Document
		writer.write(doc);
		writer.close();
	}

	protected void setUp() throws Exception {
		super.setUp();

		Session session = getSession();
		Transaction trans = session.beginTransaction();

		//Create RaceDmgr reference data
		Race race1 = new Race(1, "White");
		session.save(race1);
		Race race2 = new Race(2, "Asian");
		session.save(race2);

		//Create EthnicityDmgr reference data
		Ethnicity eth1 = new Ethnicity(1, "Cuban");
		session.save(eth1);
		Ethnicity eth2 = new Ethnicity(2, "Puerto Rican");
		session.save(eth2);
		trans.commit();
		session.close();

		// Create a Person object containing two sets (races, ethnicities)
		session = getSession();
		trans = session.beginTransaction();
		Person person = new Person();
		person.setPersonName("Test Person 1");
		person.addPersonRace(race1);
		person.addPersonRace(race2);
		person.addPersonEthnicity(eth1);
		person.addPersonEthnicity(eth2);

		session.save(person);
		trans.commit();
		session.close();
	}

	private Session getSession() {

		Session session = null;
		if (sessionFactory == null) {
			Configuration cfg = new Configuration();
			cfg.configure("/hibernate.cfg.xml");
			sessionFactory = cfg.buildSessionFactory();
		}
		return sessionFactory.openSession();
	}

}
