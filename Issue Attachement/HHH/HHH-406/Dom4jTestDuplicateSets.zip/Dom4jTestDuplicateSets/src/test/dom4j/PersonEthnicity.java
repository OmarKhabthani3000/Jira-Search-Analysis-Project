package test.dom4j;

import java.io.Serializable;

/**
 * @author psheldon
 * 
 * Created on Apr 27, 2005
 */
public class PersonEthnicity implements Serializable {

    protected Long personEthnicityId;

    private Person person;

    private Ethnicity ethnicity;

    /** default constructor */
    public PersonEthnicity() {
    }

    public Long getPersonEthnicityId() {
        return this.personEthnicityId;
    }

    public void setPersonEthnicityId(Long personEthnicityId) {
        this.personEthnicityId = personEthnicityId;
    }

    public Person getPerson() {
        return this.person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Ethnicity getEthnicity() {
        return this.ethnicity;
    }

    public void setEthnicity(Ethnicity ethnicity) {
        this.ethnicity = ethnicity;
    }
}