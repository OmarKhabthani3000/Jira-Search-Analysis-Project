package test.dom4j;

import java.io.Serializable;
/**
 * @author psheldon
 * 
 * Created on Apr 27, 2005
 */
public class PersonRace implements Serializable {

    protected Long personRaceId;

    private Person person;

    private Race race;

    /** default constructor */
    public PersonRace() {
    }

    public Long getPersonRaceId() {
        return this.personRaceId;
    }

    public void setPersonRaceId(Long personRaceId) {
        this.personRaceId = personRaceId;
    }

    public Person getPerson() {
        return this.person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Race getRace() {
        return this.race;
    }

    public void setRace(Race race) {
        this.race = race;
    }

}