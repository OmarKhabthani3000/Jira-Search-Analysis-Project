package org.hibernate.bugs;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.Collection;
import java.util.Collections;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

  private EntityManagerFactory entityManagerFactory;

  @Before
  public void init() {
    entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
  }

  @After
  public void destroy() {
    entityManagerFactory.close();
  }

  @Test
  public void in_predicate_ok_only_one_in_value() throws Exception {
    EntityManager entityManager = entityManagerFactory.createEntityManager();
    entityManager.getTransaction().begin();

    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<EntityA> q = criteriaBuilder.createQuery(EntityA.class);
    Root<EntityA> caseRoot = q.from(EntityA.class);

    Expression<String> fct =
        criteriaBuilder.function("replace", String.class, criteriaBuilder.literal("a"), criteriaBuilder.literal("b"));

    Predicate equal = caseRoot.get("name").in(fct);

    q.where(equal);
    entityManager.createQuery(q).getResultList();

    entityManager.getTransaction().commit();
    entityManager.close();
  }

  @Test
  public void in_predicate_ok_with_array_of_expression() throws Exception {
    EntityManager entityManager = entityManagerFactory.createEntityManager();
    entityManager.getTransaction().begin();

    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<EntityA> q = criteriaBuilder.createQuery(EntityA.class);
    Root<EntityA> caseRoot = q.from(EntityA.class);

    Expression<String> fct =
        criteriaBuilder.function("replace", String.class, criteriaBuilder.literal("a"), criteriaBuilder.literal("b"));

    Collection<Expression<String>> collection = Collections.singleton(fct);

    Predicate equal = caseRoot.get("name").in(collection.toArray(new Expression[0]));

    q.where(equal);
    entityManager.createQuery(q).getResultList();

    entityManager.getTransaction().commit();
    entityManager.close();
  }

  @Test
  public void in_predicate_not_ok_with_collection_of_expression() throws Exception {
    EntityManager entityManager = entityManagerFactory.createEntityManager();
    entityManager.getTransaction().begin();

    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<EntityA> q = criteriaBuilder.createQuery(EntityA.class);
    Root<EntityA> caseRoot = q.from(EntityA.class);

    Expression<String> fct =
        criteriaBuilder.function("replace", String.class, criteriaBuilder.literal("a"), criteriaBuilder.literal("b"));

    Collection<Expression<String>> collection = Collections.singleton(fct);

    Predicate equal = caseRoot.get("name").in(collection);

    q.where(equal);
    entityManager.createQuery(q).getResultList();

    entityManager.getTransaction().commit();
    entityManager.close();
  }


}
