package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.AfterClass;
import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;

public class MessageTest {

    private static EntityManagerFactory emf;

    private static EntityManager em;

    private static final String PERSISTENCE_UNIT_NAME = "testcasePu";

    @BeforeClass
    public static void setUpClass() {
        emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        em = emf.createEntityManager();
    }

    @AfterClass
    public static void tearDownClass() {
        em.close();
        emf.close();
    }

    @Test
    public void test() {
        // prepare data
        em.getTransaction().begin();
        User user = new User(1, "Roger", "Suen");
        em.persist(user);
        Message message = new Message(1, "foo", "bar", user);
        em.persist(message);
        em.getTransaction().commit();
        
        // start with an empty context
        em.clear();

        Message entityMessage = em.find(Message.class, 1);
        User proxyUser = entityMessage.getUser();
        assertNotNull(entityMessage);
        assertNotNull(proxyUser);
        assertFalse(emf.getPersistenceUnitUtil().isLoaded(proxyUser));

        // make proxyUser a detached, uninitialized proxy.
        em.clear();
        
        // load the User object with the same id into the context
        User entityUser = em.find(User.class, 1);
        assertNotNull(entityUser);
        
        // try to persist a new message with reference to the proxy
        em.getTransaction().begin();
        Message transientMessage = new Message(2, "foo", "bar", proxyUser);

        // throw org.hibernate.LazyInitializationException: could not initialize proxy - no Session
        em.persist(transientMessage); 
        em.getTransaction().commit();
    }
}
