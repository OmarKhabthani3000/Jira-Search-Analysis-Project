package org.hibernate.bugs;

import javax.persistence.Query;
import javax.persistence.TemporalType;

import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Test case for HHH-11875: 
 * Incorrect parameter binding for java.util.Date and TemporalType
 * 
 * @see <a href='https://hibernate.atlassian.net/browse/HHH-11875'>HHH-11875</a>
 */
public class Hhh11875JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	/**
	 * Test method for HHH-11875: 
	 * Incorrect parameter binding for java.util.Date and TemporalType
	 */
	@Test
	public void hhh11875Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		// Do stuff...
		Query query = entityManager.createNativeQuery("SELECT :param FROM dual");
		query.setParameter("param", new java.util.Date(123), TemporalType.DATE);
		Object result = query.getSingleResult();
		assertEquals("1970-01-01", result.toString());
		
		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
