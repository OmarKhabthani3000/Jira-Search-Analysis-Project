package support.hibernate.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Task {
	@Id
	@SequenceGenerator(name = "ID_GENERATOR", sequenceName = "TASK_SEQ", initialValue= 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ID_GENERATOR")
	private long id;

	private String name;

	public Task(String name) {
		this();
		setName(name);
	}

	public long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	protected Task() {
		// this form used by Hibernate
	}

	protected void setId(long id) {
		this.id = id;
	}

	protected void setName(String name) {
		this.name = name;
	}

	public int hashCode() {
		if (name != null) {
			return name.hashCode();
		} else {
			return 0;
		}
	}

	public boolean equals(Object o) {
		if (this == o) {
			return true;
		} else if (o instanceof Task) {
			Task other = Task.class.cast(o);
			if (name != null) {
				return getName().equals(other.getName()) /* && getId() == other.getId() */;
			} else {
				return other.getName() == null;
			}
		} else {
			return false;
		}
	}
}
