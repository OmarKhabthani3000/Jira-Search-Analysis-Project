package support.hibernate.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Version;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
public class Employee {
	@Id
	private String name;

	@Version
	private long oca;

	private String title;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "owner_name")
	@Fetch(FetchMode.SUBSELECT)
//	@Fetch(FetchMode.SELECT)
	private List<Task> tasks;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "contrib_name")
	@Fetch(FetchMode.SUBSELECT)
//	@Fetch(FetchMode.SELECT)
	private List<Task> sharedTasks;

	public Employee(String name, String title) {
		this();
		setName(name);
		setTitle(title);
	}

	public String getName() {
		return name;
	}

	public long getOca() {
		return oca;
	}

	public String getTitle() {
		return title;
	}

	public List<Task> getTasks() {
		return tasks;
	}

	public List<Task> getSharedTasks() {
		return sharedTasks;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void addTask(Task task, boolean shared) {
		if (!shared) {
			if (getTasks() == null) {
				setTasks(new ArrayList<Task>());
			}
			tasks.add(task);
			// task.setEmployee(this);
		} else {
			if (getSharedTasks() == null) {
				setSharedTasks(new ArrayList<Task>());
			}
			sharedTasks.add(task);
			// task.setEmployee(this);
		}
	}

	protected Employee() {
		// this form used by Hibernate
	}

	protected void setName(String name) {
		this.name = name;
	}

	protected void setOca(long oca) {
		this.oca = oca;
	}

	protected void setTasks(List<Task> tasks) {
		this.tasks = tasks;
	}

	protected void setSharedTasks(List<Task> tasks) {
		this.sharedTasks = tasks;
	}
}
