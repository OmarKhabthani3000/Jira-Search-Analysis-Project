package support.hibernate.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import support.hibernate.util.AutoCloser;

import org.apache.log4j.Logger;

import org.junit.Test;
import org.junit.BeforeClass;
import org.junit.AfterClass;

public class TestHibernate {
	private static Logger log = Logger.getLogger(TestHibernate.class.getCanonicalName());

	private static EntityManager entityManager;

	private static final AutoCloser m_closer = new AutoCloser();

	@BeforeClass
	public static void setUp() throws Exception {
		try {
			// Configures settings from annotations + persistence.xml
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("TEST");
			m_closer.push(emf);
			entityManager = emf.createEntityManager();
			m_closer.push(entityManager);
		} catch (Throwable t) {
			log.warn("Setup failure", t);
		}
	}

	@AfterClass
	public static void tearDown() throws Exception {
		if (entityManager != null) {
			try {
				m_closer.close();
			} finally {
				entityManager = null;
				m_closer.clear();
			}
		}
	}

	@Test
	public void test() throws java.io.IOException, InterruptedException {
		log.info("---> test started.");
		EntityTransaction transaction = entityManager.getTransaction();
		try {
			transaction.begin();
			{
				for (int i = 0 ; i < 200 ; i++) {
				Employee e = new Employee("John Smith " + i, "Engineer");
				log.info("------> Persisting entity('" + e.getName() + "', '" + e.getTitle() + "')");
				e.addTask(new Task("private task"), false);
				e.addTask(new Task("shared task"), true);
				entityManager.persist(e);
				}
			}
			transaction.commit();

			List<TypedQuery<Employee>> queries = new ArrayList<TypedQuery<Employee>>();
			queries.add(buildQuery(true)); // HQL
			queries.add(buildQuery(false)); // CriteriaQuery

			for (TypedQuery<Employee> query : queries) {
				entityManager.clear();

//				log.info("Sleeping 20 seconds before starting HQL entity load ... ");
//				Thread.sleep(20*1000);

				transaction.begin();

				int entityCount = 0;

				log.info("------> Starting entity load ...");
				for (Employee e : query.getResultList()) {
					entityCount += 1;
					entityCount += e.getTasks().size();
					entityCount += e.getSharedTasks().size();
				}
				log.info("------> Loaded " + entityCount + " entities");

//				log.info("Sleeping 20 seconds before commiting transaction ... ");
//				Thread.sleep(20*1000);

				transaction.commit();
			}
		} finally {
			if (transaction.isActive()) {
				try {
					transaction.rollback();
				} catch (Throwable t) {
					log.warn("Rollback failure", t);
				}
			}
			log.info("---> test completed.");
		}
	}

	private TypedQuery<Employee> buildQuery(boolean useHql) {
		if (useHql) {
			return entityManager.createQuery("from Employee e", Employee.class);
		} else {
			return entityManager.createQuery(buildCriteriaQuery());
		}
	}

	private CriteriaQuery<Employee> buildCriteriaQuery(Long... unused) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Employee> cq = cb.createQuery(Employee.class);
		Root<Employee> root = cq.from(Employee.class);
		cq.where(
//			cb.and(
				cb.equal(root.get("title"),"Engineer")/*,
				cb.equal(root.join("tasks").get("name"), "private task"),
				cb.equal(root.join("sharedTasks").get("name"), "shared task")
			)*/
		);
		return cq;
	}
}
