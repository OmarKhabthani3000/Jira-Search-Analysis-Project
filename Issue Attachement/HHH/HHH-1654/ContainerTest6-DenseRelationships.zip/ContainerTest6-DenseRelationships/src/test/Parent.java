
package test;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * @author Jeff Schnitzer
 */
@Entity
@Cache(usage=CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Parent
{
	/** */
	@Id
	@GeneratedValue
	public Long id;

	/** */
	@OneToMany(cascade=CascadeType.ALL, mappedBy="parent")
	public Set<Child> children;
	
	/** */
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="defaultChildId", nullable=false)
	Child defaultChild;
	
	/** */
	public Parent() {}

	/** */
	public Child getDefaultChild() { return this.defaultChild; }
	public void setDefaultChild(Child value) { this.defaultChild = value; }
	
	/** */
	public Set<Child> getChildren() { return this.children; }
	public void setChildren(Set<Child> value) { this.children = value; }
}
