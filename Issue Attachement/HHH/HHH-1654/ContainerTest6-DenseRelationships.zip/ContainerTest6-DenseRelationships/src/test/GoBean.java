
package test;

import java.util.HashSet;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.jboss.annotation.ejb.Service;

/**
 * @author Jeff Schnitzer
 */
@Service(objectName="test:service=Go")
public class GoBean implements Go
{
	/** */
	@PersistenceContext EntityManager em;
	
	/** */
	public void go()
	{
		Parent p = new Parent();
		p.setChildren(new HashSet<Child>());
		
		Child ch = new Child(p);
		p.getChildren().add(ch);
		p.setDefaultChild(ch);
		
		this.em.persist(p);
	}
}
