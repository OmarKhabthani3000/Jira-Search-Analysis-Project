
package test;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * @author Jeff Schnitzer
 */
@Entity
@Cache(usage=CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Child
{
	/** */
	@Id
	@GeneratedValue
	public Long id;

	/** */
	@ManyToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name="parentId", nullable=false)
	Parent parent;
	
	/** */
	public Child() {}
	
	/** */
	public Child(Parent p)
	{
		this.parent = p;
	}
	
	/** */
	public Parent getParent() { return this.parent; }
	public void setParent(Parent value) { this.parent = value; }
}
