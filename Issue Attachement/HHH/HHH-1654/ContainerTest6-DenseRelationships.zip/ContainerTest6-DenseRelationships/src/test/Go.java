
package test;

import org.jboss.annotation.ejb.Management;

/**
 * @author Jeff Schnitzer
 */
@Management
public interface Go
{
	/**
	 */
	public void go();
}
