package tests;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.junit.Test;

import entities.Address;
import entities.Person;
import junit.framework.Assert;

public class Tests {
	EntityManager em;
	
	@Test
    public void test() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("TEST");
        em = emf.createEntityManager();

        String personName = "Person 1";
        Person p = new Person();
        p.setName(personName);
        
        Address a1 = new Address();
        a1.setCity("City 1");
        a1.setStreet("Street 1");
        
        Address a2 = new Address();
        a2.setCity("City 2");
        a2.setStreet("Street 2");
        
        p.getAddresses().add(a1);
        p.getAddresses().add(a2);

        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        em.persist(p);
        
        tx.commit();
        em.clear();
        
        Person p1 = readPerson(personName);
        Person p2 = readPerson(personName); 
        Assert.assertNotSame(p1, p2);
        Assert.assertTrue("Versions should be the same", p1.getVersion() == p2.getVersion());
        
        Person p3 = readPersonWithTx(personName);   // Hibernate deletes and reinserts embeddables -> version is incremented
        Person p4 = readPersonWithTx(personName); 
        Assert.assertNotSame(p3, p4);
        Assert.assertTrue("Versions should be the same", p3.getVersion() == p4.getVersion());
    }
	
	private Person readPerson(String name) {
		em.clear();
		TypedQuery<Person> q = em.createQuery("select p from Person p where p.name = :name", Person.class);
		q.setParameter("name", name);
		
		Person p = q.getSingleResult();
		return p;
	}
	
	private Person readPersonWithTx(String name) {
		em.clear();
		EntityTransaction tx = em.getTransaction();
        tx.begin();
        
		TypedQuery<Person> q = em.createQuery("select p from Person p where p.name = :name", Person.class);
		q.setParameter("name", name);
		
		Person p = q.getSingleResult();
		
		tx.commit();
		return p;
	}
}
