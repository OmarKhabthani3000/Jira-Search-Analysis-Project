package entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.persistence.JoinColumn;

@Entity
@Table(name = "TEST_EC_PERSON")
public class Person {
	@Id
	@GeneratedValue
	private long id;

	@Version
	private long version;

	@Column(name = "NAME", length = 100)
	private String name;

	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name = "TEST_EC_ADDRESS", joinColumns=@JoinColumn(name="person_id"))
	private Set<Address> addresses = new HashSet<Address>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getId() {
		return id;
	}

	public long getVersion() {
		return version;
	}

	public Set<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(Set<Address> addresses) {
		this.addresses = addresses;
	}

}
