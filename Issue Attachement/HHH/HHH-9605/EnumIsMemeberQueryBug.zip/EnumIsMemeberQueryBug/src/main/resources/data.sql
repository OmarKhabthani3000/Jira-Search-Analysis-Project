insert into person (id, name, oneenum) values (1, 'Lastname', 'A');

insert into person_enum(person_id, simple_enum) values (1, 'A');