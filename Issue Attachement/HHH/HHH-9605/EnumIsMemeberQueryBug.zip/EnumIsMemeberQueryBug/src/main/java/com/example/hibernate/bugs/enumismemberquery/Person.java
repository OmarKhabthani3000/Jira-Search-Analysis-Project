package com.example.hibernate.bugs.enumismemberquery;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;

/**
 */
@Entity
@Access(AccessType.PROPERTY)
public class Person {

    private Long id;
    private String name;
    private SimpleEnum oneEnum;
    private Set<SimpleEnum> enumCollection = new HashSet<>();

    @Id
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Enumerated(EnumType.STRING)
    public SimpleEnum getOneEnum() {
        return oneEnum;
    }

    public void setOneEnum(SimpleEnum oneEnum) {
        this.oneEnum = oneEnum;
    }

    @Enumerated(EnumType.STRING)
    @ElementCollection(targetClass = SimpleEnum.class, fetch = FetchType.LAZY)
    @JoinTable(name = "person_enum",
            joinColumns = { @JoinColumn(name = "person_id") })
    @Column(name = "simple_enum", nullable = false)
    public Set<SimpleEnum> getEnumCollection() {
        return enumCollection;
    }

    public void setEnumCollection(Set<SimpleEnum> enumCollection) {
        this.enumCollection = enumCollection;
    }
}
