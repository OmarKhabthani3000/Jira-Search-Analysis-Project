package com.example.hibernate.bugs.enumismemberquery;

public enum SimpleEnum {
    A;
}
