package com.example.hibernate.bugs.enumismemberquery;

import static java.lang.System.out;

import java.util.Collection;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class EnumIsMemeberQueryTestCase {

    private static EntityManagerFactory emf;
    private static EntityManager em;

	@BeforeClass
	public static void setup() {
        emf = Persistence.createEntityManagerFactory("test-nd");
        em = emf.createEntityManager();
	}

    @AfterClass
    public static void tearDown() {
        if (em != null) {
            em.close();
        }
        if (emf != null) {
            emf.close();
        }
    }

    @Test
    public void test1() {
        out.println("firstTest 1");

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Person> cq = cb.createQuery(Person.class);
        Root<Person> root = cq.from(Person.class);
        // Quering a single enum field; everything is okay; passing an enum as parameter
        cq.where(cb.equal(root.get(Person_.oneEnum), SimpleEnum.A));
        for (Person p : em.createQuery(cq).getResultList()) {
            logPerson(p);
        }

    }

    @Test
    public void test2Okay() {
        out.println("test2Okay");

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Person> cq = cb.createQuery(Person.class);
        Root<Person> root = cq.from(Person.class);

        // Here tricking hibernate, telling that it is a collection of strings and passsing a string argument.
        Expression<Collection<String>> simpleEnums = root.get("enumCollection");

        cq.where(cb.isMember("A", simpleEnums));
        for (Person p : em.createQuery(cq).getResultList()) {
            logPerson(p);
        }
    }

    @Test
    public void test3Failure() {
        out.println("test3Failure");

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Person> cq = cb.createQuery(Person.class);
        Root<Person> root = cq.from(Person.class);
        Expression<Set<SimpleEnum>> simpleEnums = root.get( Person_.enumCollection);

        // Using the correct collection of enums and an enum parameter
        cq.where(cb.isMember(SimpleEnum.A, simpleEnums));

        for (Person p : em.createQuery(cq).getResultList()) {
            logPerson(p);
        }

    }

    private void logPerson(Person p) {
        out.println("" + p.getId() + ": " + p.getName() + "; " + p.getOneEnum());
    }
}
