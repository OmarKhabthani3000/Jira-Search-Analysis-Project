USE Apollo_AR;
GO

BEGIN TRANSACTION;
    IF NOT EXISTS(SELECT *
                  FROM INFORMATION_SCHEMA.SCHEMATA
                  WHERE  schema_name = 'JpaTest')
    BEGIN
        EXEC('CREATE SCHEMA JpaTest;'); 
    END
COMMIT TRANSACTION;
GO

BEGIN TRANSACTION;
    IF OBJECT_ID('JpaTest.ParentOwnerJoinTable',   'U') IS NOT NULL DROP TABLE JpaTest.ParentOwnerJoinTable;
    IF OBJECT_ID('JpaTest.Parent',                 'U') IS NOT NULL DROP TABLE JpaTest.Parent;
    IF OBJECT_ID('JpaTest.ChildOne',               'U') IS NOT NULL DROP TABLE JpaTest.ChildOne;
    IF OBJECT_ID('JpaTest.ChildTwo',               'U') IS NOT NULL DROP TABLE JpaTest.ChildTwo;
    IF OBJECT_ID('JpaTest.Owner',                  'U') IS NOT NULL DROP TABLE JpaTest.Owner;
COMMIT TRANSACTION;
GO

BEGIN TRANSACTION;
    CREATE TABLE JpaTest.Parent
    (
        id                          varchar(36)         NOT NULL,

        CONSTRAINT Parent_PK
        PRIMARY KEY NONCLUSTERED
        (id)
    );

    CREATE TABLE JpaTest.ChildOne
    (
        id                          varchar(36)         NOT NULL,

        CONSTRAINT ChildOne_PK
        PRIMARY KEY NONCLUSTERED
        (id)
    );

    CREATE TABLE JpaTest.ChildTwo
    (
        id                          varchar(36)         NOT NULL,

        CONSTRAINT ChildTwo_PK
        PRIMARY KEY NONCLUSTERED
        (id)
    );

    CREATE TABLE JpaTest.Owner
    (
        id                          varchar(36)         NOT NULL,

        CONSTRAINT Owner_PK
        PRIMARY KEY NONCLUSTERED
        (id)
    );

    CREATE TABLE JpaTest.ParentOwnerJoinTable
    (
        owner_id                    varchar(36)         NOT NULL,
        parent_id                   varchar(36)         NOT NULL,

        CONSTRAINT LT_OWNER_FK
        FOREIGN KEY (owner_id)
        REFERENCES JpaTest.Owner (id),

        CONSTRAINT LT_PARENT_FK
        FOREIGN KEY (parent_id)
        REFERENCES JpaTest.Parent (id)
    );
COMMIT TRANSACTION;
GO
