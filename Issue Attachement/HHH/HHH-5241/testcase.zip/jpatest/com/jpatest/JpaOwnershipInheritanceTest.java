package com.jpatest;

import java.util.List;

import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class JpaOwnershipInheritanceTest extends JpaTestBase
{
    
    public static void main(String[] args) throws Exception
    {
        createDatabaseConnection();
        
        writeEntity();
        readEntity();
    }

    public static void writeEntity()
    {
        final EntityManager entityManager = createEntityManager();
        entityManager.getTransaction().begin();
        
        final Owner owner = new Owner();
        owner.setId("OwnerId");
        
        final ChildOne childOne = new ChildOne();
        childOne.setId("ChildOneId");
        childOne.setOwner(owner);

        final ChildTwo childTwo = new ChildTwo();
        childTwo.setId("ChildTwoId");
        childTwo.setOwner(owner);
        
        entityManager.persist(owner);
        entityManager.persist(childOne);
        entityManager.persist(childTwo);

        entityManager.getTransaction().commit();
        closeEntityManagerAndFactory(entityManager);
    }
   
    public static void readEntity()
    {
        final EntityManager entityManager = createEntityManager();
        entityManager.getTransaction().begin();

        final CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        final CriteriaQuery<Parent> criteria = cb.createQuery(Parent.class);

        criteria.from(Parent.class);

        final TypedQuery<Parent> query = entityManager.createQuery(criteria);
        final List<Parent> resultList = query.getResultList();
        
        for (Parent parent : resultList)
        {
            System.out.printf("%s\n", parent.getId());
        }
    }
    
}
