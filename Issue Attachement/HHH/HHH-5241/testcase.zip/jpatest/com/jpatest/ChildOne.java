package com.jpatest;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "ChildOne", schema = "JpaTest")
public class ChildOne extends Parent
{
    public ChildOne()
    {
    }
}
