package com.jpatest;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.spi.InitialContextFactory;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import net.sourceforge.jtds.jdbcx.JtdsDataSource;
import org.jmock.Expectations;
import org.jmock.Mockery;

public class JpaTestBase
{
    protected static void createDatabaseConnection() throws NamingException
    {
        final String username = "banksy";
        final String password = username;
        
        final JtdsDataSource dataSource = new JtdsDataSource();
        dataSource.setAppName("Apollo Tests");
        dataSource.setServerName("localhost");
        dataSource.setUser(username);
        dataSource.setPassword(password);        
        dataSource.setDatabaseName("Apollo_AR");
        
        System.setProperty("java.naming.factory.initial",
            MockInitialContextFactory.class.getName());
    
        final Mockery mockery = new Mockery();
        final Context mockContext = mockery.mock(Context.class);               
        
        mockery.checking(new Expectations()
        {
            {
                allowing(mockContext).lookup("java:comp/env/ds/analyticalRepository");
                will(returnValue(dataSource));
                allowing(mockContext).rebind(with(any(String.class)), with(anything()));
            }
        });
        
        MockInitialContextFactory.setMockContext(mockContext);
    }

    protected static final EntityManager createEntityManager()
    {
        final EntityManagerFactory entityManagerFactory =
            Persistence.createEntityManagerFactory("ApolloDataAccessLayer");
        return entityManagerFactory.createEntityManager();
    }
    
    protected static final void closeEntityManagerAndFactory(EntityManager entityManager)
    {
        entityManager.close();
        entityManager.getEntityManagerFactory().close();
    }
    
    public static final class MockInitialContextFactory implements InitialContextFactory
    {
        private static Context sMockContext;
        
        public static void setMockContext(Context mockContext)
        {
            sMockContext = mockContext;
        }
        
        public Context getInitialContext(Hashtable<?, ?> ignored)
        {
            return sMockContext;
        }
    }

}
