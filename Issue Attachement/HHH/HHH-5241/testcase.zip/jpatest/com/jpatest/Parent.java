package com.jpatest;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Parent", schema = "JpaTest")
@Inheritance(strategy = InheritanceType.JOINED)
public class Parent
{
    private String mId;
    private Owner mOwner;
    
    public Parent()
    {
    }
    
    @Id
    @Column(name = "id", nullable = false)
    public String getId()
    {
        return mId;
    }

    public void setId(String id)
    {
        mId = id;
    }
    
    @ManyToOne
    @JoinTable(schema = "JpaTest", name = "ParentOwnerJoinTable", 
        joinColumns = {@JoinColumn(name = "parent_id", nullable = true) }, 
        inverseJoinColumns = {@JoinColumn(name = "owner_id", nullable = true) })
    public Owner getOwner()
    {
        return mOwner;
    }
    
    public void setOwner(Owner owner)
    {
        mOwner = owner;
    }
}
