package com.jpatest;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "ChildTwo", schema = "JpaTest")
public class ChildTwo extends Parent
{
    public ChildTwo()
    {
    }
}
