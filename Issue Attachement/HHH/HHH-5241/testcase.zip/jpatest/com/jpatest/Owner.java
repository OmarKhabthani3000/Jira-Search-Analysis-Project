package com.jpatest;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Owner", schema = "JpaTest")
public class Owner
{
    private String mId;
    
    public Owner()
    {
    }
    
    @Id
    @Column(name = "id", nullable = false)
    public String getId()
    {
        return mId;
    }

    public void setId(String id)
    {
        mId = id;
    }
    
    
 
}
