From hibernate-3.2.5.ga.zip, hibernate-annotations-3.3.0.GA.zip and hibernate-entitymanager-3.3.1.GA.zip, please, add the files below in directory lib

antlr-2.7.6.jar
c3p0-0.9.1.jar
commons-collections-2.1.1.jar
commons-logging-1.0.4.jar
dom4j-1.6.1.jar
ehcache-1.2.3.jar
ejb3-persistence.jar
hibernate3.jar
hibernate-annotations.jar
hibernate-commons-annotations.jar
hibernate-entitymanager.jar
hibernate-validator.jar
javassist.jar
jboss-archive-browsing.jar
jdbc2_0-stdext.jar
jta.jar
log4j-1.2.11.jar
xml-apis.jar

From Mysql site, please add the java connector below in directory lib
mysql-connector-java-5.0.6-bin.jar