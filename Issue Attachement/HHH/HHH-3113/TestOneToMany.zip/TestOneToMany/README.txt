Please, create in Mysql:

database: one
username: one
password: 123

host: 127.0.0.1
port: 3306


If you prefer, you can modify the file src/META-INF/persistence.xml
Please, read the file lib/README.txt. You must to add jars of Hibernate in lib directory. 
Please, execute the class test.Test

In execution, take a look in two System.out.println of Test.class:

System.out.println("**************************** User before add the second phone: "+resp);
System.out.println("**************************** User after add the second phone: "+resp);

At second call of addPhone(Phone p), the hashCode of the first Phone is changed, because
his main attribute change (the hashCode consider main attribute). The Hibernate then execute this two inserts:

1297 [main] DEBUG org.hibernate.SQL  - 
    insert 
    into
        User_Phone
        (User_id, phones_id) 
    values
        (?, ?)
1297 [main] DEBUG org.hibernate.type.LongType  - binding '1' to parameter: 1
1297 [main] DEBUG org.hibernate.type.LongType  - binding '2' to parameter: 2
1297 [main] DEBUG org.hibernate.SQL  - 
    insert 
    into
        User_Phone
        (User_id, phones_id) 
    values
        (?, ?)
1297 [main] DEBUG org.hibernate.type.LongType  - binding '1' to parameter: 1
1297 [main] DEBUG org.hibernate.type.LongType  - binding '1' to parameter: 2
1313 [main] WARN  org.hibernate.util.JDBCExceptionReporter  - SQL Error: 1062, SQLState: 23000
1313 [main] ERROR org.hibernate.util.JDBCExceptionReporter  - Duplicate entry '1-1' for key 1


But the last insert (insert into User_Phone (User_id, phones_id) values (1,1)) has been execute before in first addPhone(Phone p).
When the last insert is executed, I got Duplicate entry '1-1' for key 1. 
It seems be a bug. The Hibernate should execute only one insert (insert into User_Phone (User_id, phones_id) values (1,2)), because
in second addPhone(Phone p) I add only one new Phone.

If you try comment section equals and hashCode in Phone class, the code run successful, but I need overwrite this two methods.
Any questions, please contact claudior@buscape-inc.com







