package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.Phone;
import com.User;


public class Test {
	
	private EntityManagerFactory emf = Persistence.createEntityManagerFactory("one");
	
	public User mergeUser(User u){
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = null;
		try {
		    tx = em.getTransaction();
		    tx.begin();
		    u = em.merge(u);
		    tx.commit();
		    return u;
		}
		catch (RuntimeException e) {
		    if ((tx != null) && (tx.isActive())) tx.rollback();
		    throw e;
		}
		finally {
		    em.close();
		}
	}
	
	
	public static void main(String[] args) {
		Test t = new Test();
		
		User u = new User();
		
		// First Phone
		Phone p1 = new Phone();
		p1.setNumber("11111111");
		p1.setMain(true);
		
		u.addPhone(p1);
		
		User resp = t.mergeUser(u);
		
		// Second Phone
		Phone p2 = new Phone();
		p2.setNumber("22222222");
		p2.setMain(true);
		
		System.out.println("**************************** User before add the second phone: "+resp);
		resp.addPhone(p2);
		System.out.println("**************************** User after add the second phone: "+resp);
		
		User resp2 = t.mergeUser(resp);
	}

}
