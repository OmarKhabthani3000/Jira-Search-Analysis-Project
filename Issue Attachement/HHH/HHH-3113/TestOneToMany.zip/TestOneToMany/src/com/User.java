package com;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class User implements Serializable {
	
	private static final long serialVersionUID = 0L;
	private Long id;
	private Set<Phone> phones = new HashSet<Phone>();
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	@OneToMany(cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	public Set<Phone> getPhones() {
		return phones;
	}
	
	public void setPhones(Set<Phone> phones) {
		this.phones = phones;
	}
	
	public void addPhone(Phone p){
		if (phones.size()==0) {
			// Assert the first phone is main phone
			p.setMain(true);
		}
		else {
			// There are others phone
			if (p.isMain()){
				// Remove the main of others phones
				for(Phone temp : phones){
					temp.setMain(false);
				}
			}
		}
		phones.add(p);
	}
	
	public String toString(){
		return "User - Set Phones: "+phones;
	}

}
