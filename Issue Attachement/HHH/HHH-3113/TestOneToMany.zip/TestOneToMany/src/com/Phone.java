package com;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Phone implements Serializable {
	
	private static final long serialVersionUID = 0L;
	private Long id;
	private String number;
	private boolean main;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getNumber() {
		return number;
	}
	
	public void setNumber(String number) {
		this.number = number;
	}
	
	public boolean isMain() {
		return main;
	}
	
	public void setMain(boolean main) {
		this.main = main;
	}
	
	// Overwrite equals
	public boolean equals(Object o){
		if (this == o) return true;
		if (!(o instanceof Phone)) return false;
		Phone temp = (Phone)o;
		
		if (!number.equals(temp.getNumber())) return false;
		if (main != temp.isMain()) return false;
		
		return true;
	}
	
	// Overwrite hashCode
	public int hashCode(){
		return 29 * number.hashCode() + 29 * (main?1:0);
	}

}
