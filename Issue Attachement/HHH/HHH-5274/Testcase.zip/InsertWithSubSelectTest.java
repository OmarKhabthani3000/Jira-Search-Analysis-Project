package org.hibernate.test.insertwithsubselect;

import junit.framework.Test;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;

/**
 * @author Bj�rn Moritz
 */
public class InsertWithSubSelectTest extends FunctionalTestCase {

	public InsertWithSubSelectTest(String x) {
		super(x);
	}

	public String[] getMappings() {
		return new String[] { "insertwithsubselect/A.hbm.xml" };
	}

	public static Test suite() {
		return new FunctionalTestClassTestSuite(InsertWithSubSelectTest.class);
	}

	public void testInsert() throws Exception {
		Session s;
		Transaction tx;

		s = openSession();
		tx = s.beginTransaction();
		String hql = "insert into C (id) select a.id from A a where exists (select 1 from B b where b.id = a.id)";
		Query query = s.createQuery(hql);
		query.executeUpdate();
		tx.commit();
		s.close();
	}

	public void testSelect() throws Exception {
		Session s;
		Transaction tx;

		s = openSession();
		tx = s.beginTransaction();
		String hql = "select a.id from A a where exists (select 1 from B b where b.id = a.id)";
		Query query = s.createQuery(hql);
		query.list();
		tx.commit();
		s.close();
	}
}
