package org.hibernate.test;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

/**
 * This test case contains two simple tests for demonstrating the patch applied to hibernate 3.6.1.<br/>
 * One test method should always work, the other one will only work with a patched hibernate version.
 * 
 * @author bjoern.moritz
 */
public class InsertWithSubSelectTest extends BaseCoreFunctionalTestCase {

    @Override
    public String[] getMappings() {
        return new String[] { "A.hbm.xml" };
    }

    /**
     * Test insert with select and subselect. This test will only work with a patched hibernate 3.6.1 version.
     */
    @Test
    public void testInsert() throws Exception {
        Session s;
        Transaction tx;

        s = openSession();
        tx = s.beginTransaction();
        String hql = "insert into C (id) select a.id from A a where exists (select 1 from B b where b.id = a.id)";
        Query query = s.createQuery(hql);
        query.executeUpdate();
        tx.commit();
        s.close();
    }

    /**
     * Test select with subselect. This test will work always, even with the unpatched hibernate version.
     */
    @Test
    public void testSelect() throws Exception {
        Session s;
        Transaction tx;

        s = openSession();
        tx = s.beginTransaction();
        String hql = "select a.id from A a where exists (select 1 from B b where b.id = a.id)";
        Query query = s.createQuery(hql);
        query.list();
        tx.commit();
        s.close();
    }
}
