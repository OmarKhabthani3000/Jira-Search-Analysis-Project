package cz.vitek.gsospg.elearning.service.resource;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToMany;
import javax.persistence.MappedSuperclass;

import cz.vitek.gsospg.elearning.service.term.Term;

/**
 * 
 * @author Richard Vítek
 */
@MappedSuperclass
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class StaticResourceBundle<R extends AbstractResource<R>> extends AbstractResourceBundle<R> {

	private static final long serialVersionUID = 1L;

	@ManyToMany
	private Set<Term> terms;

	private String qualifier;

	@Override
	protected Set<Term> doGetTerms() {
		return terms;
	}

	@Override
	protected void doSetTerms(final Collection<Term> terms) {
		if (terms != null) {
			if (this.terms == null) {
				this.terms = new HashSet<Term>();
			} else {
				this.terms.clear();
			}
			this.terms.addAll(terms);
		} else {
			if (this.terms != null) {
				this.terms.clear();
			}
		}
	}

	public String getQualifier() {
		return qualifier;
	}

	void setQualifier(final String qualifier) {
		this.qualifier = qualifier;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof StaticResourceBundle)) {
			return false;
		}
		StaticResourceBundle<?> other = (StaticResourceBundle<?>) obj;
		if (qualifier == null) {
			if (other.qualifier != null) {
				return false;
			}
		} else if (!qualifier.equals(other.qualifier)) {
			return false;
		}
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((qualifier == null) ? 0 : qualifier.hashCode());
		return result;
	}

	public static enum Type {
		IMAGE(ImageResourceBundle.class);

		// PRESENTATION(PresentationResourceBundle.class);

		private final Class<? extends StaticResourceBundle<?>> resourceBundleClazz;

		private Type(final Class<? extends StaticResourceBundle<?>> clazz) {
			this.resourceBundleClazz = clazz;
		}

		public Class<? extends StaticResourceBundle<?>> getResourceBundleClazz() {
			return resourceBundleClazz;
		}
	}
}
