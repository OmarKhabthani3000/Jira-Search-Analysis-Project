package cz.vitek.gsospg.elearning.service.resource;


import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.AssociationOverride;
import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;

import cz.vitek.gsospg.Configuration;

import org.apache.commons.lang.Validate;

/**
 * 
 * @author Richard Vítek
 */
@Entity
@AttributeOverride(
		name=AbstractResourceBundle.ID_PROPERTY,
		column=@Column(name="imrb_id")
)
// TODO DEV: this just DOESN'T WORK
//https://forum.hibernate.org/viewtopic.php?p=2443799
//- probably caused by typo in org.hibernate.cfg.AbstractPropertyHolder.buildHierarchyColumnOverride(XClass)
@AssociationOverride(
		name = "terms",
		joinTable = @JoinTable(
				name = "image_resource_bundle2term",
				joinColumns = @JoinColumn(name = "imrb_id", referencedColumnName="imrb_id"),
				inverseJoinColumns = @JoinColumn(name = "term_id", referencedColumnName="term_id")
		)
)
public class ImageResourceBundle extends StaticResourceBundle<ImageResource> {

	private static final long serialVersionUID = 1L;

	public static final Dimension countSmallDimension(final ImageResource imageResource) {
		Validate.notNull(imageResource);

		double widthRatio = (double) imageResource.getWidth() / Configuration.IMAGE_SMALL_MAX_DIMENSION.width;
		double heightRatio = (double) imageResource.getHeight() / Configuration.IMAGE_SMALL_MAX_DIMENSION.height;
		double scaleRatio = Math.max(widthRatio, heightRatio);
		return new Dimension((int) (imageResource.getWidth() / scaleRatio), (int) (imageResource.getHeight() / scaleRatio));
	}

	//TODO DEV: docasne, az budou vygenerovane obrazky podle max. velikosti v konfiguraci, odkomentovat
	public ImageResource getLargeResource() {
		List<ImageResource> resources = getResourcesSortedByDimension();
		return resources.size() == 3 ? resources.get(2) : resources.get(1);
		//		return getResourceByDimension(Configuration.IMAGE_MEDIUM_MAX_DIMENSION, Configuration.IMAGE_LARGE_MAX_DIMENSION);
	}

	public ImageResource getMediumResource() {
		List<ImageResource> resources = getResourcesSortedByDimension();
		return resources.size() == 3 ? resources.get(1) : resources.get(0);
		//		return getResourceByDimension(Configuration.IMAGE_SMALL_MAX_DIMENSION, Configuration.IMAGE_MEDIUM_MAX_DIMENSION);
	}

	// public ImageResource getSmallResource() {
	// return getResourceByDimension(ZERO_DIMENSION, Configuration.IMAGE_SMALL_MAX_DIMENSION);
	// }

	private List<ImageResource> getResourcesSortedByDimension() {
		List<ImageResource> sortedResources = new ArrayList<ImageResource>(getResources());
		Collections.sort(sortedResources, ImageResource.DIMENSION_COMPARATOR);
		//		Validate.isTrue(sortedResources.size() >= 2 && sortedResources.size() < 3, "Spatny pocet obrazku pro jeden obrazkovy bundle");
		return sortedResources;
	}

	private ImageResource getResourceByDimension(final Dimension minDimension, final Dimension maxDimension) {
		for (ImageResource resource : getResources()) {
			if (resource.getWidth() > minDimension.width && resource.getHeight() > minDimension.height && resource.getWidth() <= maxDimension.width
					&& resource.getHeight() <= maxDimension.height) {
				return resource;
			}
		}
		return null;
	}
}
