package cz.vitek.gsospg.elearning.service.resource;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;
import javax.validation.constraints.Size;

import cz.vitek.gsospg.elearning.service.term.Term;
import cz.vitek.lib.service.NamedEntity;
import cz.vitek.lib.validation.constraints.NotBlank;

import org.apache.commons.lang.Validate;

/**
 * 
 * @author Richard Vítek
 * @see http://blog.eyallupu.com/2010/06/hibernate-exception-simultaneously.html
 */
@MappedSuperclass
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class AbstractResourceBundle<R extends AbstractResource<R>> implements NamedEntity<Integer> {

	private static final long serialVersionUID = 1L;
	public static final String ID_PROPERTY = "id";
	public static final String NAME_PROPERTY = "name";
	public static final String TERMS_PROPERTY = "terms";
	public static final String RESOURCES_PROPERTY = "resources";

	@Id
	@GeneratedValue
	private Integer id;
	@NotBlank
	private String name;
	@OneToMany(mappedBy = "resourceBundle", cascade = CascadeType.ALL)
	@Size(min=1)
	private Set<R> resources;

	@Override
	public Integer getId() {
		return id;
	}

	@Override
	public String getName() {
		return name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public Set<Term> getTerms() {
		return doGetTerms();
	}

	protected abstract Set<Term> doGetTerms();

	public void setTerms(final Collection<Term> terms) {
		doSetTerms(terms);
	}

	protected abstract void doSetTerms(Collection<Term> terms);

	public Set<R> getResources() {
		return resources;
	}

	public void setResources(final Collection<R> resources) {
		Validate.noNullElements(resources);

		this.resources = new HashSet<R>(resources.size());
		for (R resource : resources) {
			resource.setResourceBundle(this);
			this.resources.add(resource);
		}
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AbstractResourceBundle)) {
			return false;
		}
		AbstractResourceBundle<?> other = (AbstractResourceBundle<?>) obj;
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return name;
	}
}
