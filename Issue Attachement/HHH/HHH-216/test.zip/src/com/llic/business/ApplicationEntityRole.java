package com.llic.business;


/**
 * <!-- ApplicationEntityRole -->  
 * 
 * This class is a container for Entity objects when they are stored in an 
 * Application object. This class manages the relationship between the 
 * Application and the Entity objects associated with that Application.
 * 
 * @author		Todd Nine
 * @version 2.0
 * 
 */
public class ApplicationEntityRole  implements LaserBusiness{

	/** Table key field - cannot be changed */
	private Long id;

	/** Table key field - cannot be changed */
	private Long entityRoleSubType;

	private Long entityId;
	/**
	 * @return Returns the entityId.
	 */
	public Long getEntityId() {
		return entityId;
	}
	/**
	 * @param entityId The entityId to set.
	 */
	public void setEntityId(Long entityId) {
		this.entityId = entityId;
	}
//	private Entity entity;
//
//	private EntityRoleType entityRoleType;
//
//	private RelationshipToInsured relationshipToInsured;

	protected ApplicationEntityRole() {
	}
	

	
	/**
	 * @return Returns the entityRoleTypeType.
	 */
	public Long getEntityRoleSubType() {
		return entityRoleSubType;
	}
	/**
	 * @param entityRoleTypeType The entityRoleTypeType to set.
	 */
	public void setEntityRoleSubType(Long entityRoleTypeType) {
		this.entityRoleSubType = entityRoleTypeType;
	}
	/**
	 * @return Returns the id.
	 */
	public Long getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 
	 * @return 
	 * @author 
	 */
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("ApplicationEntityRole[");
		buffer.append("entityId = ").append(entityId);
		buffer.append(" entityRoleSubType = ").append(entityRoleSubType);
		buffer.append(" id = ").append(id);
		buffer.append("]");
		return buffer.toString();
	}}