package com.llic.business;

import java.util.ArrayList;
import java.util.Date;
import java.util.Set;

/**
 * 
 * <!-- Application -->
 * 
 * Application is the business object class that extends the Document class to
 * represent the added criteria required to be classified as an application.
 * 
 * @author M. Bryant
 * @version 1.0
 * 
 * <pre>
 * 
 *  
 *   Modifications:
 *     Date      Programmer	Ver		Description
 *   ----------  ----------	---		-----------
 *   09/15/2003  M. Bryant	1.0		Original release
 *   
 *  
 * </pre>
 * 
 * 
 */
public class Application extends Document implements LaserBusiness {
	// final public static String APPLICATION_CLASSIFICATION_APPLICATION =
	// "Application";
	// final public static String APPLICATION_CLASSIFICATION_LIFE_APPLICATION =
	// "LifeApplication";
	// final public static String APPLICATION_CLASSIFICATION_ANNUITY_APPLICATION
	// =
	// "AnnuityApplication";

	protected Long applicationId;

	protected ArrayList relatedDocs;

	// protected ApplicationChecklist applicationChecklist;
	//
	// protected Product product;
	protected long productID;

	// protected EUWS euws;

	protected Date policyDate;

	protected String applicationClassification;

	// protected State issueState;
	// protected long issueStateID;

	// protected LineOfBusiness lineOfBusiness;
	// protected long lineOfBusinessID;

	protected boolean ownerSameAsInsured;

	protected boolean benfrySameAsOwner;

	protected ArrayList owners;

	protected ArrayList beneficiaries;

	// protected ApplicationStatus applicationStatus;
	// protected long applicationStatusID;

	// protected Premium premium;
	// protected long premiumID;

	protected double cashWithApplication;

	protected Date dateCashWithApplicationReceived;

	// protected boolean w9Received;

	// protected ApplicationType applicationType;
	// protected long applicationTypeID;

	// protected BillingInformation billingInformation;
	// protected long billingInformationID;

	protected String dividendOption;

	// protected ArrayList otherParties;
	//
	// protected ArrayList agentPolicyInformation;
	//
	// protected ArrayList associatedPolicies;
	//
	// protected String qmIDNumber;

	// protected ApplicationEntityRole primaryIndividualAppRole;

	protected Date applicationDate;

	protected Set appEntityRoles; 
	// protected List electedCoverages;


	/**
	 * @return Returns the applicationClassification.
	 */
	public String getApplicationClassification() {
		return applicationClassification;
	}
	/**
	 * @param applicationClassification The applicationClassification to set.
	 */
	public void setApplicationClassification(String applicationClassification) {
		this.applicationClassification = applicationClassification;
	}
	/**
	 * @return Returns the applicationDate.
	 */
	public Date getApplicationDate() {
		return applicationDate;
	}
	/**
	 * @param applicationDate The applicationDate to set.
	 */
	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}
	/**
	 * @return Returns the applicationId.
	 */
	public Long getApplicationId() {
		return applicationId;
	}
	/**
	 * @param applicationId The applicationId to set.
	 */
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	/**
	 * @return Returns the beneficiaries.
	 */
	public ArrayList getBeneficiaries() {
		return beneficiaries;
	}
	/**
	 * @param beneficiaries The beneficiaries to set.
	 */
	public void setBeneficiaries(ArrayList beneficiaries) {
		this.beneficiaries = beneficiaries;
	}
	/**
	 * @return Returns the benfrySameAsOwner.
	 */
	public boolean isBenfrySameAsOwner() {
		return benfrySameAsOwner;
	}
	/**
	 * @param benfrySameAsOwner The benfrySameAsOwner to set.
	 */
	public void setBenfrySameAsOwner(boolean benfrySameAsOwner) {
		this.benfrySameAsOwner = benfrySameAsOwner;
	}
	/**
	 * @return Returns the cashWithApplication.
	 */
	public double getCashWithApplication() {
		return cashWithApplication;
	}
	/**
	 * @param cashWithApplication The cashWithApplication to set.
	 */
	public void setCashWithApplication(double cashWithApplication) {
		this.cashWithApplication = cashWithApplication;
	}
	/**
	 * @return Returns the dateCashWithApplicationReceived.
	 */
	public Date getDateCashWithApplicationReceived() {
		return dateCashWithApplicationReceived;
	}
	/**
	 * @param dateCashWithApplicationReceived The dateCashWithApplicationReceived to set.
	 */
	public void setDateCashWithApplicationReceived(
			Date dateCashWithApplicationReceived) {
		this.dateCashWithApplicationReceived = dateCashWithApplicationReceived;
	}
	/**
	 * @return Returns the dividendOption.
	 */
	public String getDividendOption() {
		return dividendOption;
	}
	/**
	 * @param dividendOption The dividendOption to set.
	 */
	public void setDividendOption(String dividendOption) {
		this.dividendOption = dividendOption;
	}
	/**
	 * @return Returns the owners.
	 */
	public ArrayList getOwners() {
		return owners;
	}
	/**
	 * @param owners The owners to set.
	 */
	public void setOwners(ArrayList owners) {
		this.owners = owners;
	}
	/**
	 * @return Returns the ownerSameAsInsured.
	 */
	public boolean isOwnerSameAsInsured() {
		return ownerSameAsInsured;
	}
	/**
	 * @param ownerSameAsInsured The ownerSameAsInsured to set.
	 */
	public void setOwnerSameAsInsured(boolean ownerSameAsInsured) {
		this.ownerSameAsInsured = ownerSameAsInsured;
	}
	/**
	 * @return Returns the policyDate.
	 */
	public Date getPolicyDate() {
		return policyDate;
	}
	/**
	 * @param policyDate The policyDate to set.
	 */
	public void setPolicyDate(Date policyDate) {
		this.policyDate = policyDate;
	}
	/**
	 * @return Returns the productID.
	 */
	public long getProductID() {
		return productID;
	}
	/**
	 * @param productID The productID to set.
	 */
	public void setProductID(long productID) {
		this.productID = productID;
	}
	/**
	 * @return Returns the relatedDocs.
	 */
	public ArrayList getRelatedDocs() {
		return relatedDocs;
	}
	/**
	 * @param relatedDocs The relatedDocs to set.
	 */
	public void setRelatedDocs(ArrayList relatedDocs) {
		this.relatedDocs = relatedDocs;
	}
	/**
	 * @return Returns the appEntityRoles.
	 */
	public Set getAppEntityRoles() {
		return appEntityRoles;
	}
	/**
	 * @param appEntityRoles The appEntityRoles to set.
	 */
	public void setAppEntityRoles(Set appEntityRoles) {
		this.appEntityRoles = appEntityRoles;
	}
	/**
	 * 
	 * @return 
	 * @author 
	 */
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("Application[");
		buffer.append("appEntityRoles = ").append(appEntityRoles);
		buffer.append(" applicationClassification = ").append(
				applicationClassification);
		buffer.append(" applicationDate = ").append(applicationDate);
		buffer.append(" applicationId = ").append(applicationId);
		buffer.append(" beneficiaries = ").append(beneficiaries);
		buffer.append(" benfrySameAsOwner = ").append(benfrySameAsOwner);
		buffer.append(" cashWithApplication = ").append(cashWithApplication);
		buffer.append(" dateCashWithApplicationReceived = ").append(
				dateCashWithApplicationReceived);
		buffer.append(" dividendOption = ").append(dividendOption);
		buffer.append(" owners = ").append(owners);
		buffer.append(" ownerSameAsInsured = ").append(ownerSameAsInsured);
		buffer.append(" policyDate = ").append(policyDate);
		buffer.append(" productID = ").append(productID);
		buffer.append(" relatedDocs = ").append(relatedDocs);
		buffer.append("]");
		return buffer.toString();
	}}