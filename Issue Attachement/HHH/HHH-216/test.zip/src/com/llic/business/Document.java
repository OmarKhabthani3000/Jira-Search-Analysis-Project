package com.llic.business;

import java.util.Date;

/**
 * 
 * <!-- Document -->
 * 
 * Business object used to represent Document.
 * 
 * @author Todd Nine
 */
public class Document implements LaserBusiness {

	private String contentMgrUniqueKey;

	private Date dateReceived;

	private PolicyNumber policyNumber;
	// private long policyNumberID;
	//
	// private DocumentType documentType;
	//
	// private User assignedNBA;
	// protected long assignedNBAID;
	//
	// private User assignedUW;
	// protected long assignedUWID;
	//
	// private DocumentSubType documentSubType;
	// protected long documentSubTypeID;
	//
	// private Application parent;
	// protected long parentID;

	protected Long id;

	private String nbaNotificationStatus;

	private String uwNotificationStatus;

	private String scanPacketNumber;

	private Date nbaNotificationDate;

	private Date uwNotificationDate;

	private long grouping;

	/**
	 * @return Returns the contentMgrUniqueKey.
	 */
	public String getContentMgrUniqueKey() {
		return contentMgrUniqueKey;
	}

	/**
	 * @param contentMgrUniqueKey
	 *            The contentMgrUniqueKey to set.
	 */
	public void setContentMgrUniqueKey(String contentMgrUniqueKey) {
		this.contentMgrUniqueKey = contentMgrUniqueKey;
	}

	/**
	 * @return Returns the dateReceived.
	 */
	public Date getDateReceived() {
		return dateReceived;
	}

	/**
	 * @param dateReceived
	 *            The dateReceived to set.
	 */
	public void setDateReceived(Date dateReceived) {
		this.dateReceived = dateReceived;
	}

	/**
	 * @return Returns the grouping.
	 */
	public long getGrouping() {
		return grouping;
	}

	/**
	 * @param grouping
	 *            The grouping to set.
	 */
	public void setGrouping(long grouping) {
		this.grouping = grouping;
	}

	/**
	 * @return Returns the id.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            The id to set.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return Returns the nbaNotificationDate.
	 */
	public Date getNbaNotificationDate() {
		return nbaNotificationDate;
	}

	/**
	 * @param nbaNotificationDate
	 *            The nbaNotificationDate to set.
	 */
	public void setNbaNotificationDate(Date nbaNotificationDate) {
		this.nbaNotificationDate = nbaNotificationDate;
	}

	/**
	 * @return Returns the nbaNotificationStatus.
	 */
	public String getNbaNotificationStatus() {
		return nbaNotificationStatus;
	}

	/**
	 * @param nbaNotificationStatus
	 *            The nbaNotificationStatus to set.
	 */
	public void setNbaNotificationStatus(String nbaNotificationStatus) {
		this.nbaNotificationStatus = nbaNotificationStatus;
	}

	/**
	 * @return Returns the scanPacketNumber.
	 */
	public String getScanPacketNumber() {
		return scanPacketNumber;
	}

	/**
	 * @param scanPacketNumber
	 *            The scanPacketNumber to set.
	 */
	public void setScanPacketNumber(String scanPacketNumber) {
		this.scanPacketNumber = scanPacketNumber;
	}

	/**
	 * @return Returns the uwNotificationDate.
	 */
	public Date getUwNotificationDate() {
		return uwNotificationDate;
	}

	/**
	 * @param uwNotificationDate
	 *            The uwNotificationDate to set.
	 */
	public void setUwNotificationDate(Date uwNotificationDate) {
		this.uwNotificationDate = uwNotificationDate;
	}

	/**
	 * @return Returns the uwNotificationStatus.
	 */
	public String getUwNotificationStatus() {
		return uwNotificationStatus;
	}

	/**
	 * @param uwNotificationStatus
	 *            The uwNotificationStatus to set.
	 */
	public void setUwNotificationStatus(String uwNotificationStatus) {
		this.uwNotificationStatus = uwNotificationStatus;
	}

	/**
	 * 
	 * @return 
	 * @author 
	 */
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("Document[");
		buffer.append("contentMgrUniqueKey = ").append(contentMgrUniqueKey);
		buffer.append(" dateReceived = ").append(dateReceived);
		buffer.append(" grouping = ").append(grouping);
		buffer.append(" id = ").append(id);
		buffer.append(" nbaNotificationDate = ").append(nbaNotificationDate);
		buffer.append(" nbaNotificationStatus = ")
				.append(nbaNotificationStatus);
		buffer.append(" scanPacketNumber = ").append(scanPacketNumber);
		buffer.append(" uwNotificationDate = ").append(uwNotificationDate);
		buffer.append(" uwNotificationStatus = ").append(uwNotificationStatus);
		buffer.append("]");
		return buffer.toString();
	}	/**
	 * @return Returns the policyNumber.
	 */
	public PolicyNumber getPolicyNumber() {
		return policyNumber;
	}
	/**
	 * @param policyNumber The policyNumber to set.
	 */
	public void setPolicyNumber(PolicyNumber policyNumber) {
		this.policyNumber = policyNumber;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object arg0) {
		if(arg0 == null)
		{
			return false;
		}
		
		//not the same class
		if(!(this.getClass().equals(arg0.getClass())))
		{
			return false;
		}
		
		//point to same instance (this should check for null as well)
		if(id == ((LaserBusiness)arg0).getId() )
		{
			return true;
		}
		//both aren't null, return
		else if(id == null || ((LaserBusiness)arg0).getId() == null)
		{
			return false;
		}
		
		//check that pk's are equal
		return id.equals(((Document)arg0).getId());
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return (this.getClass().getName().hashCode() + this.id.intValue());
	}
}