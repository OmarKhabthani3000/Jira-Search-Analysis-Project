/*
 * Created on Feb 28, 2005
 *
 */
package com.llic.business;

/**
 * @author Todd Nine
 * Generic class that marks a class for JDO access
 */
public interface LaserBusiness {
    
    /**
     * Return the implementing objects primary key
     * @return
     */
    public Long getId();

}
