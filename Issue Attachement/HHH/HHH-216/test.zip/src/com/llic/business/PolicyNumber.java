/*
 * Created on Mar 8, 2005
 *
 */
package com.llic.business;

/**
 * @author Todd Nine
 * 
 */
public class PolicyNumber implements LaserBusiness {

	private Long id;
	
	private String policyPrefix;
	private String policyBase;
	private String policySuffix;
	
	
	
	
	/**
	 * 
	 */
	public PolicyNumber() {
		super();
	}
	/**
	 * @param id
	 */
	public PolicyNumber(Long id) {
		super();
		this.id = id;
	}
	
	/**
	 * @param id
	 * @param policyBase
	 */
	public PolicyNumber(Long id, String policyBase) {
		super();
		this.id = id;
		this.policyBase = policyBase;
	}
	/**
	 * @return Returns the policyBase.
	 */
	public String getPolicyBase() {
		return policyBase;
	}
	/**
	 * @param policyBase The policyBase to set.
	 */
	public void setPolicyBase(String policyBase) {
		this.policyBase = policyBase;
	}
	/**
	 * @return Returns the policyPrefix.
	 */
	public String getPolicyPrefix() {
		return policyPrefix;
	}
	/**
	 * @param policyPrefix The policyPrefix to set.
	 */
	public void setPolicyPrefix(String policyPrefix) {
		this.policyPrefix = policyPrefix;
	}
	/**
	 * @return Returns the policySuffix.
	 */
	public String getPolicySuffix() {
		return policySuffix;
	}
	/**
	 * @param policySuffix The policySuffix to set.
	 */
	public void setPolicySuffix(String policySuffix) {
		this.policySuffix = policySuffix;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/* (non-Javadoc)
	 * @see com.llic.business.LaserBusiness#getId()
	 */
	public Long getId() {
		return null;
	}

}
