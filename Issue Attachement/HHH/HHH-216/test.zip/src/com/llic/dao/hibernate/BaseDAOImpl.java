/*
 * Created on Feb 28, 2005
 *
 */
package com.llic.dao.hibernate;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;




import com.llic.business.LaserBusiness;
import com.llic.dao.BaseDAO;
import com.llic.dao.exception.DataAccessException;

/**
 * @author Todd Nine Generic Base DAO
 */
public abstract class BaseDAOImpl extends HibernateDaoSupport implements
        BaseDAO {

    /*
     * (non-Javadoc)
     * 
     * @see com.llic.dao.BaseDAO#findById(java.lang.Long)
     */
    public LaserBusiness findById(Long id) throws DataAccessException {
        if (id == null) {
            throw new NullPointerException("id cannot be null");
        }

        String hql = "from " + getBusinessClass() + " a where a.id=?";

        
        List results = getHibernateTemplate().findByNamedQuery(hql, id);

        return (LaserBusiness) ((results != null && results.size() > 0) ? results
                .get(0)
                : null);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.llic.dao.BaseDAO#saveOrUpdate(com.llic.laser.business.LaserBusiness)
     */
    public LaserBusiness saveOrUpdate(LaserBusiness obj)
            throws DataAccessException {
        if (obj == null) {
            throw new NullPointerException("obj cannot be null");
        }

        return (LaserBusiness) getHibernateTemplate().merge(obj);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.llic.dao.BaseDAO#selectAll()
     */
    public List selectAll() throws DataAccessException {
        String hql = " from " + getBusinessClass();

        return getHibernateTemplate().find(hql);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.llic.dao.BaseDAO#delete(com.llic.laser.business.LaserBusiness)
     */
    public void delete(LaserBusiness obj) throws DataAccessException {
        if (obj == null) {
            throw new NullPointerException("obj cannot be null");
        }

        getHibernateTemplate().delete(obj);

    }

}