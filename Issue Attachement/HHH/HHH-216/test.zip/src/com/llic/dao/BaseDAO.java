/*
 * Created on Feb 28, 2005
 *
 */
package com.llic.dao;

import java.util.List;


import com.llic.business.LaserBusiness;
import com.llic.dao.exception.DataAccessException;

/**
 * @author Todd Nine Basic DAO operations
 */
public interface BaseDAO {

    /**
     * Find by the <code>LaserBusiness</code> object with the given primary key.
     * 
     * @param id
     * @return <code>null</code> if the object was not found.
     * @throws DataAccessException
     */
    public LaserBusiness findById(Long id) throws DataAccessException;

    /**
     * Saves or updates the given <code>LaserBusiness</code> Object
     * @param obj
     * @return The updated object with database values
     * @throws DataAccessException
     */
    public LaserBusiness saveOrUpdate(LaserBusiness obj)
            throws DataAccessException;

    /**
     * Deletes the given <code>LaserBusiness</code> Object
     * @param obj
     * @throws DataAccessException
     */
    public void delete(LaserBusiness obj) throws DataAccessException;

    /**
     * Retrieves a List of <code>LaserBusiness</code> objects for the given
     * business class.
     * @return <code>null</code> if the object was not found.
     * @throws DataAccessException
     */
    public List selectAll() throws DataAccessException;
    
    
    /**
     * Return the fully qualified classname of the business object in the DAO.
     * @return
     */
    public String getBusinessClass();
}