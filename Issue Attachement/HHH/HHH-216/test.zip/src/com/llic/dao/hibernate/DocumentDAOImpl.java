/*
 * Created on Feb 28, 2005
 *
 */
package com.llic.dao.hibernate;

import java.util.List;

import com.llic.business.Document;
import com.llic.dao.DocumentDAO;
import com.llic.dao.exception.DataAccessException;

/**
 * @author Todd Nine
 *
 */
public class DocumentDAOImpl extends BaseDAOImpl implements DocumentDAO {
 
    

    /* (non-Javadoc)
     * @see com.llic.dao.DocumentDAO#getAllDocuments()
     */
    public List getAllDocuments() throws DataAccessException {
       return selectAll();
    }

    /* (non-Javadoc)
     * @see com.llic.dao.DocumentDAO#getDocumentsWithPolicyNumber()
     */
    public List getDocumentsWithPolicyNumber(Long policyNumberId) throws DataAccessException {
       String hql = "from " + getBusinessClass() + " as document where document.policyNumber.id = :id";
       
       return getHibernateTemplate().findByNamedParam(hql, "id",  policyNumberId);
    }

    /* (non-Javadoc)
     * @see com.llic.dao.DocumentDAO#getDocumentWithContentManagerKey(java.lang.String)
     */
    public Document getDocumentWithContentManagerKey(String key) throws DataAccessException {
    	//TODO Auto-generated method stub
    	return null;
    }

    /* (non-Javadoc)
     * @see com.llic.dao.DocumentDAO#getDocumentNotificiationsForUWUser(long)
     */
    public List getDocumentNotificiationsForUWUser(long userId) throws DataAccessException {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see com.llic.dao.DocumentDAO#getDocumentNotificationsForNBAUser(long)
     */
    public List getDocumentNotificationsForNBAUser(long userId) throws DataAccessException {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see com.llic.dao.DocumentDAO#getMailDocumentsData()
     */
    public List getMailDocumentsData() throws DataAccessException {
        // TODO Auto-generated method stub
        return null;
    }
    
    
    /* (non-Javadoc)
     * @see com.llic.dao.BaseDAO#getBusinessClass()
     */
    public String getBusinessClass() {
        return Document.class.getName();
    }

}
