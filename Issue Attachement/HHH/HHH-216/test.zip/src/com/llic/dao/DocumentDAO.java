/*
 * Created on Feb 28, 2005
 *
 */
package com.llic.dao;

import java.util.List;

import com.llic.business.Document;
import com.llic.dao.exception.DataAccessException;

/**
 * @author Todd Nine
 * Document Data Access Methods
 */
public interface DocumentDAO extends BaseDAO {

    /**
     * Returns a List of all Documents in Laser
     * @return <code>null</code> if the objects were not found.
     * @deprecated Use selectAll instead
     */
    public List getAllDocuments() throws DataAccessException;
    
    /**
     * Retrieve a <code>Document<code> with the given policy number 
     * @return <code>null</code> if the objects were not found.
     * @throws DataAccessException
     */
    public List getDocumentsWithPolicyNumber(Long policyNumberId) throws DataAccessException;
    
    /**
     * Retrieve the <code>Document</code> with the given Content Manager Unique Key
     * @param key
     * @return <code>null</code> if the object was not found.
     * @throws DataAccessException
     */
    public Document getDocumentWithContentManagerKey(String key) throws DataAccessException;
    
    
    /**
     * Return a List of <code>Documents</code> for the given UW User
     * @param userId
     * @return <code>null</code> if the objects were not found.
     * @throws DataAccessException
     */
    public List getDocumentNotificiationsForUWUser(long userId) throws DataAccessException;
    
    /**
     * Return a List of <code>Documents</code> for the given NBA User
     * @param userId
     * @return <code>null</code> if the objects were not found.
     * @throws DataAccessException
     */
    public List getDocumentNotificationsForNBAUser(long userId) throws DataAccessException;
    
    /**
     * Return a List of <code>Documents</code> that have no policy number or have not
     * been assigned to an NBA
     * @return <code>null</code> if the objects were not found.
     * @throws DataAccessException
     */
    public List getMailDocumentsData() throws DataAccessException;
    
    
    
    
}
