/*
 * Created on Mar 1, 2005
 *
 */
package com.llic.dao;

import java.util.Date;

import com.llic.business.Document;

/**
 * @author Todd Nine Tests for the <code>DocuemntDAO</code> methods.
 * Note, we want to make sure to compare with .equals since Hibernate
 * will compare with that.  It needs to be implemented in every
 * Business Object.
 */
public class DocumentDAOTest extends HibernateTest {

	private Document globalDoc;
	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		globalDoc = new Document();
		//set all not null properties
		globalDoc.setContentMgrUniqueKey("testKey");
		globalDoc.setDateReceived(new Date());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
	
	}

//	/**
//	 * Test for querying by policy number
//	 * 
//	 * @throws Exception
//	 */
//	public void testGetDocumentsWithPolicyNumber() throws Exception {
//		fail("Unimplemented");
//
//	}
//
//	public void testGetDocumentWithContentManagerKey() throws Exception {
//		fail("Unimplemented");
//	}
//
//	public void testGetDocumentNotificiationsForUWUser() throws Exception {
//		fail("Unimplemented");
//	}
//
//	public void testGetDocumentNotificationsForNBAUser() throws Exception {
//		fail("Unimplemented");
//	}
//
//	public void testGetMailDocumentsData() throws Exception {
//		fail("Unimplemented");
//	}
//
//	public void testFindById() throws Exception {
//		fail("Unimplemented");
//	}

	public void testSave() throws Exception {
//		DocumentDAO dao = (DocumentDAO) ctx.getBean("DocumentDAO");
//		
//		//update pk
//		globalDoc = (Document) dao.saveOrUpdate(globalDoc);
//		
//		Document newDoc = (Document) dao.findById(globalDoc.getId());
//		
//		assertTrue("Saved and retreived", newDoc.equals(globalDoc));
	}

//	public void testUpdate() throws Exception {
//		fail("Unimplemented");
//	}

	public void testDelete() throws Exception {
		fail("Unimplemented");
	}

	// TODO do we need to test select alls? It take a lot of time.
	// /**
	// * Tests for querying all document
	// *
	// */
	// public void testGetAllDocuments() throws Exception{
	// DocumentDAO docDAO = (DocumentDAO) context.getBean("DocumentDAO");
	// List result = docDAO.getAllDocuments();
	//        
	// assertTrue(result.size() > 0);
	// }
	//    
	// public void testSelectAll() throws Exception{
	// }
}
