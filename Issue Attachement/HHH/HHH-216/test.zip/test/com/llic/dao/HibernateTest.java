/*
 * Created on Mar 14, 2005
 *
 */
package com.llic.dao;

import junit.framework.TestCase;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * @author Todd Nine
 * Add global setup methods here.
 */
public abstract class HibernateTest extends TestCase {

	/**
	 * Default Application Context
	 */
	//protected static final ApplicationContext ctx = new ClassPathXmlApplicationContext("LaserContext.xml");
	
	protected static final SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();

	
	
	
}
