/*
 * Created on Mar 14, 2005
 *
 */
package com.llic.dao.exception;

/**
 * @author Todd Nine
 * Exception thrown when a test case was not properly executed.
 */
public class InvalidTestCaseException extends Exception {

	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	public InvalidTestCaseException() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param arg0
	 */
	public InvalidTestCaseException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param arg0
	 * @param arg1
	 */
	public InvalidTestCaseException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param arg0
	 */
	public InvalidTestCaseException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
}
