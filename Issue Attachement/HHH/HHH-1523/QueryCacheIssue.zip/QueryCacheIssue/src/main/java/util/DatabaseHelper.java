package util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.hsqldb.HsqlProperties;
import org.hsqldb.Server;
import org.hsqldb.ServerConstants;


/**
 *   Author: <a href="mailto:vikas.sasidharan@tavant.com">Vikas Sasidharan</a>
 *   Date: Feb 24, 2006 5:50:21 PM
 */
public class DatabaseHelper {

    /**
     * 
     */
    public DatabaseHelper() {
        super();
    }

    /**
     * 
     */
    public static Server startDBServer(String serverProperties) {
        System.out.println("\n****************** Starting In-Memory Database " +
                "Server ... ******************\n");
    
        final Server dbServer = new Server();
    
        final ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
        final InputStream resourceAsStream = 
            contextClassLoader.getResourceAsStream(serverProperties);
    
        Properties props = new Properties();
    
        try {
            props.load(resourceAsStream);
        } catch (IOException e) {
            // Don't start jumping up and down ! Just set default properties.
            props.put("server.database.0", "mem:refAppDb");
            props.put("server.silent", "true");
        }
    
        HsqlProperties serverProps = new HsqlProperties(props);
    
        dbServer.setProperties(serverProps);
    
        dbServer.start();

        return dbServer;
    }

    /**
     * @param dbServer
     */
    public static void stopDbServer(Server dbServer) {
        System.out.println("\n****************** Stopping In-Memory Database " +
        "Server ... ******************\n");            
        if ((dbServer != null) && 
             (dbServer.getState() == ServerConstants.SERVER_STATE_ONLINE)) {
            dbServer.stop();
        }
    }

}
