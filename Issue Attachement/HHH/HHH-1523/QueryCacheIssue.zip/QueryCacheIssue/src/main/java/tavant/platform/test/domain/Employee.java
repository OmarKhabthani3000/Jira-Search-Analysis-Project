/*
 *   Author: <a href="mailto:vikas.sasidharan@tavant.com">Vikas Sasidharan</a>
 *   Date: Feb 21, 2006 3:41:16 PM
 */

package tavant.platform.test.domain;

public class Employee {
	private Long id;

	private String name;

	private Department department;
	
	public Employee() {
	}
	
	public Employee(Long id) {
		this.id = id;
	}
	
	public Long getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public String toString() {
		return "[Id : " + id + ", name : " + name + "]";
	}

}