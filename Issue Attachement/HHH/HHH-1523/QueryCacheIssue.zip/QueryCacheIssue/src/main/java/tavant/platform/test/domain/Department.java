/*
 *   Author: <a href="mailto:vikas.sasidharan@tavant.com">Vikas Sasidharan</a>
 *   Date: Feb 21, 2006 3:41:16 PM
 */

package tavant.platform.test.domain;

import java.util.ArrayList;
import java.util.List;

public class Department {
	private Long id;
	
	private String name;
	
	private List employees = new ArrayList(0);
	
	public Department() {
		
	}
	
	public Department(Long id) {
		this.id = id;
	}

	public List getEmployees() {
		return employees;
	}

	public void setEmployees(List employees) {
		this.employees = employees;
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void addEmployee(Employee emp) {
		this.employees.add(emp);
		emp.setDepartment(this);
	}
	
	public String toString() {
		return "[Id : " + id + ", name : " + name + "]";
	}

}
