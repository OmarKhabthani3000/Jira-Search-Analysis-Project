/*
 *   Author: <a href="mailto:vikas.sasidharan@tavant.com">Vikas Sasidharan</a>
 *   Date: Feb 21, 2006 3:41:16 PM
 */
package tavant.platform.test.client;


import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hsqldb.Server;

import tavant.platform.test.domain.Department;
import tavant.platform.test.domain.Employee;
import util.DatabaseHelper;

/**
 * @author vikas.sasidharan
 */
public class TestPrefetchRelationWithQueryCacheEnabled {

    /**
     * 
     */
    private static final String DB_SERVER_PROPERTIES = "dbServer.properties";

    private static final String EMPLOYEE_NAME = "testEmployee";

    private static final String DEPARTMENT_NAME = "testDepartment";

    private SessionFactory sessionFactory = null;
    private static Logger logger = 
        LogManager.getLogger(TestPrefetchRelationWithQueryCacheEnabled.class);

    public TestPrefetchRelationWithQueryCacheEnabled() {
        sessionFactory = new Configuration().configure().buildSessionFactory();
    }

    public void save(Object objectToSave) {
        Session session = null;
        Transaction txn = null;
        try {
            session = sessionFactory.openSession();
            txn = session.beginTransaction();
            session.save(objectToSave);
            txn.commit();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }

    public Employee getEmployeeWithDepartment(String empName) {
        Session session = null;
        Employee emp = null;

        try {
            session = sessionFactory.openSession();
            emp = (Employee) session.createQuery(
                    "from Employee e join fetch e.department where e.name = :name")
                    .setString("name", empName)
                    .setCacheable(true)
                    .uniqueResult();
            // If I uncomment the next line, this works (even without
            // firing an extra query)
            // Hibernate.initialize(emp.getDepartment());
        } finally {
            if (session != null) {
                session.close();
            }
        }

        return emp;
    }

    public void populateDb() {
        Employee emp = new Employee();
        emp.setName(EMPLOYEE_NAME);

        Department dep = new Department();
        dep.setName(DEPARTMENT_NAME);
        dep.addEmployee(emp);

        save(dep);
    }

    public static void main(String[] args) {
        Server dbServer = DatabaseHelper.startDBServer(DB_SERVER_PROPERTIES);
        
        TestPrefetchRelationWithQueryCacheEnabled test = 
            new TestPrefetchRelationWithQueryCacheEnabled();

        try {
            logAndPrintToConsole("Starting Test Case");
            logAndPrintToConsole("Before insert...");
            test.populateDb();

            logAndPrintToConsole("Before first read...");
            Employee emp = test.getEmployeeWithDepartment(EMPLOYEE_NAME);

            logAndPrintToConsole("Before first print...");
            System.out.println("Employee : " + emp + ", Employee.Department : "
                    + emp.getDepartment());

            logAndPrintToConsole("Before second read...");
            emp = test.getEmployeeWithDepartment(EMPLOYEE_NAME);

            logAndPrintToConsole("Before second print...");
            System.out.println("Employee : " + emp + ", Employee.Department : "
                    + emp.getDepartment());
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            DatabaseHelper.stopDbServer(dbServer);            
        }
    }

    private static void logAndPrintToConsole(String message) {
        logger.debug(message);
        System.out.println("\n### " + message + " ###");
    }
}