package cz.ladicek.tinyJpaServlet;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

@ApplicationScoped
public class MyService {
    @PersistenceContext
    private EntityManager em;

    @Transactional
    public void create(String first, String last) {
        MyEntity myEntity = new MyEntity();
        myEntity.setMyAttribute(new MyAttribute(first, last));
        em.persist(myEntity);
    }

    @Transactional
    public String find() {
        return em.find(MyEntity.class, 1).toString();
    }
}
