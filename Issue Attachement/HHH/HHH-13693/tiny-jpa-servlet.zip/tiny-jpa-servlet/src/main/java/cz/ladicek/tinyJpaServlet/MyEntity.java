package cz.ladicek.tinyJpaServlet;

import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class MyEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    //@Convert(converter = MyAttributeConverter.class)
    private MyAttribute myAttribute;

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public MyAttribute getMyAttribute() {
        return myAttribute;
    }

    public void setMyAttribute(MyAttribute myAttribute) {
        this.myAttribute = myAttribute;
    }

    @Override
    public String toString() {
        return "MyEntity{" +
                "id=" + id +
                ", myAttribute=" + myAttribute +
                '}';
    }
}
