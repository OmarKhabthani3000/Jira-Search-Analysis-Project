package cz.ladicek.tinyJpaServlet;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/")
public class MyServlet extends HttpServlet {
    @Inject
    private MyService myService;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        myService.create("Albert", "Einstein");

        resp.getWriter().println(myService.find());
    }
}
