package org.example.eagerfetchbug;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
//import javax.persistence.EntityManager;
//import javax.persistence.EntityManagerFactory;
//import javax.persistence.Persistence;
import org.hibernate.Session;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class EagerFetchBugTest {

  private EntityManagerFactory entityManagerFactory;
  private Long thingId;

  @BeforeEach
  public void init() {
    entityManagerFactory = Persistence.createEntityManagerFactory("eagerFetchBug");
    thingId = saveNewThingWithParent();
  }

  @Test
  void shouldLoadEagerAssociationsInNativeQueryWithEntityAliasNotInBraces() {
    EntityManager entityManager = entityManagerFactory.createEntityManager();

    Thing thing = (Thing) entityManager
        .unwrap(Session.class)
        .createNativeQuery("select t.* from Thing t where t.id = :id")
        .addEntity("t", Thing.class)
        .setParameter("id", thingId)
        .getSingleResult();

    entityManager.close();

    assertDoesNotThrow(() ->
        assertEquals("parent 1", thing.getParent().getName())
    );
  }

  @Test
  void shouldLoadEagerAssociationsInNativeQueryWithEntityAliasInBraces() {
    EntityManager entityManager = entityManagerFactory.createEntityManager();

    Thing thing = (Thing) entityManager
        .unwrap(Session.class)
        .createNativeQuery("select {t.*} from Thing t where t.id = :id")
        .addEntity("t", Thing.class)
        .setParameter("id", thingId)
        .getSingleResult();

    entityManager.close();

    assertDoesNotThrow(() ->
        assertEquals("parent 1", thing.getParent().getName())
    );
  }

  private Long saveNewThingWithParent() {
    EntityManager entityManager = entityManagerFactory.createEntityManager();
    entityManager.getTransaction().begin();

    ParentThing parent = new ParentThing("parent 1");
    entityManager.persist(parent);

    Thing thing = new Thing("thing 1", parent);
    entityManager.persist(thing);

    entityManager.getTransaction().commit();
    entityManager.close();

    return thing.getId();
  }

  @AfterEach
  public void destroy() {
    entityManagerFactory.close();
  }
}
