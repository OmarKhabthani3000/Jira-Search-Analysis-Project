/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(schema = "public", name = "t_tertiary")
public class Tertiary implements Serializable {

    @Id
    private Integer id;
    private Integer secondaryFk;
    private String name;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSecondaryFk() {
        return secondaryFk;
    }

    public void setSecondaryFk(Integer secondaryFk) {
        this.secondaryFk = secondaryFk;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tertiary tertiary = (Tertiary) o;
        return Objects.equals(id, tertiary.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
