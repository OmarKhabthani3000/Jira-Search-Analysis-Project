/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package org.hibernate.bugs;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(schema = "public", name = "t_primary")
public class Primary implements Serializable {

    @Id
    private int id;
    @Column(name = "secondaryFk")
    private int secondaryFk;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSecondaryFk() {
        return secondaryFk;
    }

    public void setSecondaryFk(int secondaryFk) {
        this.secondaryFk = secondaryFk;
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Primary primary = (Primary) o;
        return id == primary.id;
    }

    @Override public int hashCode() {
        return Objects.hash(id);
    }
}
