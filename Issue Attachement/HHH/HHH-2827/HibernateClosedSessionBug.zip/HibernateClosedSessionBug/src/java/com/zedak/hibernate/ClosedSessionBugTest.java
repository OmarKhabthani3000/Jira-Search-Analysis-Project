/*
 * @(#)ClosedSessionBugTest
 *
 * 1.0.0.1
 *
 * Copyright (C) 2007 Zedak Corp. All Rights Reserved.
 */

package com.zedak.hibernate;

import junit.framework.TestCase;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * @author Mihai Danila
 */
public class ClosedSessionBugTest extends TestCase {
    public ClosedSessionBugTest() {
    }

    public void testSuccessfulRollback() {
        // Set up Hibernate session factory, using a thread local session context.
        Configuration cfg = new Configuration();
        cfg.setProperty("hibernate.connection.provider_class", DummyConnectionProvider1.class.getName());
        cfg.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        cfg.setProperty("hibernate.current_session_context_class", "thread");
        SessionFactory fx = cfg.buildSessionFactory();
        // Run the test.
        openSessionTwice(fx);
    }

    public void testSqlExceptionOnRollback() {
        // Set up Hibernate session factory, using a thread local session context.
        Configuration cfg = new Configuration();
        cfg.setProperty("hibernate.connection.provider_class", DummyConnectionProvider2.class.getName());
        cfg.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        cfg.setProperty("hibernate.current_session_context_class", "thread");
        SessionFactory fx = cfg.buildSessionFactory();
        // Run the test.
        openSessionTwice(fx);
    }

    public void testNonSqlExceptionOnRollback() {
        // Set up Hibernate session factory, using a thread local session context.
        Configuration cfg = new Configuration();
        cfg.setProperty("hibernate.connection.provider_class", DummyConnectionProvider3.class.getName());
        cfg.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        cfg.setProperty("hibernate.current_session_context_class", "thread");
        SessionFactory fx = cfg.buildSessionFactory();
        // Run the test.
        openSessionTwice(fx);
    }

    /**
     * Exposes a Hibernate bug by attempting to open a session twice on the
     * current thread.
     *
     * @param fx the session factory source of Hibernate sessions
     */
    private void openSessionTwice(SessionFactory fx) {
        // Attempt to open a session.
        try {
            openAndCloseASession(fx);
        } catch (Throwable t) {
            // Ignore this error.
        }

        // Attempt to open another session. If Hibernate fails to clean up its
        // thread local session context, it will end up with a closed session
        // and the current thread cannot use Hibernate sessions originating
        // from the current session factory.
        openAndCloseASession(fx);
    }

    /**
     * Forces the current thread local session context to create and cache a
     * session. The session must then be cleaned up even if <tt>rollback</tt>
     * fails. If the session is not cleaned up, Hibernate will refuse any more
     * uses of sessions by the current thread.
     *
     * @param fx the session factory for which to open a session
     */
    private static void openAndCloseASession(SessionFactory fx) {
        // Cause a session to be associated with the current thread and attempt
        // to close it.
        Session s = null;
        try {
            s = fx.getCurrentSession();
            s.beginTransaction();
        } finally {
            if (s != null) {
                try {
                    s.getTransaction().rollback();
                } catch (Throwable t) {
                    // Ignore this error.
                }
            }
        }
    }
}
