/*
 * @(#)DummyConnectionProvider3
 *
 * 1.0.0.1
 *
 * Copyright (C) 2007 Zedak Corp. All Rights Reserved.
 */

package com.zedak.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.connection.ConnectionProvider;

import java.util.Properties;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * @author Mihai Danila
 */
public class DummyConnectionProvider3 implements ConnectionProvider {
    public DummyConnectionProvider3() {
    }

    public void configure(Properties props) throws HibernateException {
        // Ignore.
    }

    public Connection getConnection() throws SQLException {
        return new DummyConnection3();
    }

    public void closeConnection(Connection conn) throws SQLException {
        conn.close();
    }

    public void close() throws HibernateException {
        // Ignore.
    }

    public boolean supportsAggressiveRelease() {
        return false;
    }

    public static class DummyConnection3 extends DummyConnection {
        public DummyConnection3() {
        }

        public void rollback() throws SQLException {
            throw new RuntimeException();
        }
    }
}
