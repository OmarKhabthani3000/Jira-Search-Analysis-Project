/*
 * @(#)DummyConnectionProvider1
 *
 * 1.0.0.1
 *
 * Copyright (C) 2007 Zedak Corp. All Rights Reserved.
 */

package com.zedak.hibernate;

import org.hibernate.connection.ConnectionProvider;
import org.hibernate.HibernateException;

import java.util.Properties;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * This provider returns connections that do not raise exceptions when rolled
 * back.
 *
 * @author Mihai Danila
 */
public class DummyConnectionProvider1 implements ConnectionProvider {
    public DummyConnectionProvider1() {
    }

    public void configure(Properties props) throws HibernateException {
        // Ignore.
    }

    public Connection getConnection() throws SQLException {
        return new DummyConnection1();
    }

    public void closeConnection(Connection conn) throws SQLException {
        conn.close();
    }

    public void close() throws HibernateException {
        // Ignore.
    }

    public boolean supportsAggressiveRelease() {
        return false;
    }

    public static class DummyConnection1 extends DummyConnection {
        public DummyConnection1() {
        }

        public void rollback() throws SQLException {
            // Do nothing.
        }
    }
}
