import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.classic.Session;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

/**
 * @author cedric.thiebault
 */
@RunWith(BlockJUnit4ClassRunner.class)
public class BugTest {

	private final SessionFactory sessionFactory;

	public BugTest() {
		sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
	}

	@Test
	public void test() {
		Parent parent = new Parent();
		Child child = new Child();
		parent.addChild(child);

		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		session.saveOrUpdate(child);
		transaction.commit();
	}
}
