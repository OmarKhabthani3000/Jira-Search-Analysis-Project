
package net.rhuanrocha;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;


/**
 * @author rhuanrocha
 */


@ApplicationPath("/")
public class JAXRSConfiguration extends Application {

}