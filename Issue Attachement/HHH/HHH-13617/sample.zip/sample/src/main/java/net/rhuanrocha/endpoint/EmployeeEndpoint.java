package net.rhuanrocha.endpoint;

import net.rhuanrocha.business.EmployeeBusiness;
import net.rhuanrocha.entity.Employee;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Path("employee")
public class EmployeeEndpoint {

    @Inject
    private EmployeeBusiness employeeBusiness;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response findAll(){

        return Response
                .ok(employeeBusiness.findAll())
                .build();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response save(Employee employee){

        if(Objects.nonNull(employee)) {
            employee = employeeBusiness.save(employee);

            return Response
                    .created(URI.create(String.format("/%s/%s", "employee", employee.getId())))
                    .build();
        }

        List<Employee> employees = new ArrayList<>();

        for(int i =1; i<= 2; i++){
            Employee employee1 = new Employee();
            employee1.setName("Name "+i);
            employee1.setRole("Role "+i);
            employees.add(employee1);
        }

        employeeBusiness.save(employees);

        return Response.created(URI.create(String.format("/%s", "employee"))).build();

    }
}
