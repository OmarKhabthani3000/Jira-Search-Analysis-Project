package net.rhuanrocha.business;

import net.rhuanrocha.entity.Employee;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class EmployeeBusiness {

    @PersistenceContext
    private EntityManager entityManager;

    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public Employee save (Employee employee){

        entityManager.persist(employee);

        return employee;

    }

    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public List<Employee> save (List<Employee> employees){

        for(Employee employee: employees) {
            entityManager.persist(employee);
        }
        return employees;

    }

    public List<Employee> findAll(){

        return entityManager.createQuery("select e from Employee e").getResultList();

    }
}
