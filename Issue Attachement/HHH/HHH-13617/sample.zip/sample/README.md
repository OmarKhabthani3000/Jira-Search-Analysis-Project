
### JBoss EAP Configurations

##### Using Postgres

Adding postgres module

`module add --name=com.postgresql --resources=/path/to/postgresql-9.3-1102.jdbc4.jar --dependencies=javax.api,javax.transaction.api`

Configuring the JDBC Driver

`/subsystem=datasources/jdbc-driver=postgresql:add(driver-name=postgresql,driver-module-name=org.postgresql,driver-xa-datasource-class-name=org.postgresql.xa.PGXADataSource)`

Configuring DataSource

`data-source add --name=PostgresDS --jndi-name=java:/jdbc/MyDataSource --driver-name=postgresql --connection-url=jdbc:postgresql://localhost:5432/testdb --user-name=admin --password=admin --validate-on-match=true --background-validation=false --valid-connection-checker-class-name=org.jboss.jca.adapters.jdbc.extensions.postgres.PostgreSQLValidConnectionChecker --exception-sorter-class-name=org.jboss.jca.adapters.jdbc.extensions.postgres.PostgreSQLExceptionSorter`

##### Starting Postgres via Docker Compose

`cd docker-compose`

`docker-compose up`

##### Compiling the Application

`mvn clean package`

##### Accessing the Application

POST: `localhost:8080/employee`

GET: `localhost:8080/employee`

Obs: In Resquest POST you should to send a JSON like 

`{
	"name":"MyName",
	"role":"MyRole"
}`