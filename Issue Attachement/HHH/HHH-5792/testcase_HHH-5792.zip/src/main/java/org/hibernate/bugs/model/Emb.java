package org.hibernate.bugs.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Embeddable;
import javax.persistence.OneToMany;

@Access(AccessType.FIELD)
@Embeddable
public class Emb {

    @OneToMany(targetEntity = Stuff.class)
    Set<Stuff> stuffs = new HashSet<Stuff>();

}
