/*
 * Created on 09.06.2020.
 *
 * Copyright(c) 1995 - 2020 
 * T-Systems Multimedia Solutions GmbH
 * Riesaer Str. 5, 01129 Dresden
 * All rights reserved.
 */
package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Convert;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class MyEntity {

    @Id
    @GeneratedValue
    private Long id;

    @Convert(converter = MyConverter.class)
    private String fieldWithConverter;

    @ElementCollection
    private List<MyOuterEmbeddable> collection = new ArrayList<>();

    /**
     * Gibt den Wert von {@link #id} zurück.
     *
     * @return id
     */
    public Long getId() {
        return id;
    }

    /**
     * Gibt den Wert von {@link #fieldWithConverter} zurück.
     *
     * @return fieldWithConverter
     */
    public String getFieldWithConverter() {
        return fieldWithConverter;
    }

    /**
     * Setzt den Wert von {@link #fieldWithConverter} auf fieldWithConverter.
     *
     * @param fieldWithConverter neuer Wert für fieldWithConverter
     */
    public void setFieldWithConverter(String fieldWithConverter) {
        this.fieldWithConverter = fieldWithConverter;
    }

    /**
     * Gibt den Wert von {@link #collection} zurück.
     *
     * @return collection
     */
    public List<MyOuterEmbeddable> getCollection() {
        return collection;
    }

    /**
     * Setzt den Wert von {@link #collection} auf collection.
     *
     * @param collection neuer Wert für collection
     */
    public void setCollection(List<MyOuterEmbeddable> collection) {
        this.collection = collection;
    }

}
