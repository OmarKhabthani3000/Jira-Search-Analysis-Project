/*
 * Created on 09.06.2020.
 *
 * Copyright(c) 1995 - 2020 
 * T-Systems Multimedia Solutions GmbH
 * Riesaer Str. 5, 01129 Dresden
 * All rights reserved.
 */
package org.hibernate.bugs;

import javax.persistence.Convert;
import javax.persistence.Embeddable;

@Embeddable
// This will fix it:
// @Access(AccessType.FIELD)
public class MyNestedEmbeddable {

    @Convert(converter = MyConverter.class)
    private String nestedEmbFieldWithConverter;

    private String nestedEmbFieldOther;

    /**
     * Gibt den Wert von {@link #nestedEmbFieldWithConverter} zurück.
     *
     * @return nestedEmbFieldWithConverter
     */
    public String getNestedEmbFieldWithConverter() {
        return nestedEmbFieldWithConverter;
    }

    /**
     * Setzt den Wert von {@link #nestedEmbFieldWithConverter} auf nestedEmbFieldWithConverter.
     *
     * @param nestedEmbFieldWithConverter neuer Wert für nestedEmbFieldWithConverter
     */
    public void setNestedEmbFieldWithConverter(String nestedEmbFieldWithConverter) {
        this.nestedEmbFieldWithConverter = nestedEmbFieldWithConverter;
    }

    /**
     * Gibt den Wert von {@link #nestedEmbFieldOther} zurück.
     *
     * @return nestedEmbFieldOther
     */
    public String getNestedEmbFieldOther() {
        return nestedEmbFieldOther;
    }

    /**
     * Setzt den Wert von {@link #nestedEmbFieldOther} auf nestedEmbFieldOther.
     *
     * @param nestedEmbFieldOther neuer Wert für nestedEmbFieldOther
     */
    public void setNestedEmbFieldOther(String nestedEmbFieldOther) {
        this.nestedEmbFieldOther = nestedEmbFieldOther;
    }

}
