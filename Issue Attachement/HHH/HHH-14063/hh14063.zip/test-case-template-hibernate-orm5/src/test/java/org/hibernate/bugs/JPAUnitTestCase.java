package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh14063Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        MyEntity myEntity = new MyEntity();

        myEntity.setFieldWithConverter("12345");

        MyOuterEmbeddable emb = new MyOuterEmbeddable();
        emb.setEmbFieldWithConverter("56789");

        MyNestedEmbeddable nestedEmb = new MyNestedEmbeddable();
        nestedEmb.setNestedEmbFieldWithConverter("098765");

        emb.setNestedEmbeddable(nestedEmb);

        myEntity.getCollection().add(emb);

        entityManager.persist(myEntity);

        entityManager.getTransaction().commit();
        entityManager.close();

        // Load in new EM
        entityManager = entityManagerFactory.createEntityManager();
        MyEntity myEntityReloaded = entityManager.find(MyEntity.class, myEntity.getId());

        Assert.assertNotNull(myEntityReloaded);
        Assert.assertNotEquals(myEntity, myEntityReloaded);

        // Convert on Entity field works
        Assert.assertEquals("foobar", myEntityReloaded.getFieldWithConverter());

        // Convert on outer Embeddable field works
        Assert.assertEquals("foobar", myEntityReloaded.getCollection().get(0).getEmbFieldWithConverter());

        // Convert on outer Embeddable field works
        Assert.assertEquals("foobar", myEntityReloaded.getCollection().get(0).getNestedEmbeddable().getNestedEmbFieldWithConverter());

        entityManager.close();
    }

}
