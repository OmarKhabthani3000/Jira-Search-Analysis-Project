/*
 * Created on 09.06.2020.
 *
 * Copyright(c) 1995 - 2020 
 * T-Systems Multimedia Solutions GmbH
 * Riesaer Str. 5, 01129 Dresden
 * All rights reserved.
 */
package org.hibernate.bugs;

import javax.persistence.Convert;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;

@Embeddable
// @Access(AccessType.FIELD)
public class MyOuterEmbeddable {

    @Embedded
    private MyNestedEmbeddable nestedEmbeddable = new MyNestedEmbeddable();

    @Convert(converter = MyConverter.class)
    private String embFieldWithConverter;

    /**
     * Gibt den Wert von {@link #nestedEmbeddable} zurück.
     *
     * @return nestedEmbeddable
     */
    public MyNestedEmbeddable getNestedEmbeddable() {
        return nestedEmbeddable;
    }

    /**
     * Setzt den Wert von {@link #nestedEmbeddable} auf nestedEmbeddable.
     *
     * @param nestedEmbeddable neuer Wert für nestedEmbeddable
     */
    public void setNestedEmbeddable(MyNestedEmbeddable nestedEmbeddable) {
        this.nestedEmbeddable = nestedEmbeddable;
    }

    /**
     * Gibt den Wert von {@link #embFieldWithConverter} zurück.
     *
     * @return embFieldWithConverter
     */
    public String getEmbFieldWithConverter() {
        return embFieldWithConverter;
    }

    /**
     * Setzt den Wert von {@link #embFieldWithConverter} auf embFieldWithConverter.
     *
     * @param embFieldWithConverter neuer Wert für embFieldWithConverter
     */
    public void setEmbFieldWithConverter(String embFieldWithConverter) {
        this.embFieldWithConverter = embFieldWithConverter;
    }

}
