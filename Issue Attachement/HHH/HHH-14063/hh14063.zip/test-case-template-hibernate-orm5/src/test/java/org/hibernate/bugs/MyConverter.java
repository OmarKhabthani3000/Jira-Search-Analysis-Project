/*
 * Created on 09.06.2020.
 *
 * Copyright(c) 1995 - 2020 
 * T-Systems Multimedia Solutions GmbH
 * Riesaer Str. 5, 01129 Dresden
 * All rights reserved.
 */
package org.hibernate.bugs;

import javax.persistence.AttributeConverter;

/**
 * Converter that always converts to "foobar" when writing to DB.
 *
 */
public class MyConverter implements AttributeConverter<String, String> {

    /** {@inheritDoc} */
    @Override
    public String convertToDatabaseColumn(String attribute) {
        return "foobar";
    }

    /** {@inheritDoc} */
    @Override
    public String convertToEntityAttribute(String dbData) {
        return dbData;
    }

}
