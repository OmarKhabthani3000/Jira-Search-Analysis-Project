import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Application {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("infinite_finances");
		emf.close();
	}
}
