package foo;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;

@Entity
@Audited
public class AuditedEntity {
		private long id;
		@GeneratedValue @Id public long getId() {
	        return id;
	    }

		private String name;
		/**
		 * @return the name
		 */
		public String getName() {
			return name;
		}

		/**
		 * @param name the name to set
		 */
		public void setName(String name) {
			this.name = name;
		}

		/**
		 * @param id the id to set
		 */
		public void setId(long id) {
			this.id = id;
		}
		
		private NonAuditedEntity nonAuditedEntity;
		/**
		 * @return the nonAuditedEntity
		 */
		@JoinColumn
	    @ManyToOne
	    public NonAuditedEntity getNonAuditedEntity() {
			return nonAuditedEntity;
		}

		/**
		 * @param nonAuditedEntity the nonAuditedEntity to set
		 */
		public void setNonAuditedEntity(NonAuditedEntity nonAuditedEntity) {
			this.nonAuditedEntity = nonAuditedEntity;
		}
		
}
