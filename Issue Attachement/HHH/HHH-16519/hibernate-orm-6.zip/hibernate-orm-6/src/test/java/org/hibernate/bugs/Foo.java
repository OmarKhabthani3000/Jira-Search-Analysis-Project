package org.hibernate.bugs;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "CS_FOO")
public class Foo {

	private Long id;
	private List<FooItem> items;

	@Id
	@SequenceGenerator(name = "CS_SEQ", sequenceName = "CS_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CS_SEQ")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@OneToMany(
			fetch = FetchType.LAZY,
			cascade = {CascadeType.PERSIST, CascadeType.MERGE},
			mappedBy = "foo",
			orphanRemoval = true
	)
	public List<FooItem> getItems() {
		return items;
	}

	public void setItems(List<FooItem> items) {
		this.items = items;
	}
}
