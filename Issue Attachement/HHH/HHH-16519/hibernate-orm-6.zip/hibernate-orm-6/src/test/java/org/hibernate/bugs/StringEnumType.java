package org.hibernate.bugs;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.usertype.EnhancedUserType;
import org.hibernate.usertype.ParameterizedType;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public abstract class StringEnumType<E extends Enum<E>> implements EnhancedUserType<E>, ParameterizedType {

	private static final String NULL_VALUE = "null";
	private static final String CASE_SENSITIVE = "caseSensitive";
	private static final String CONSTANT_PREFIX = "const.";

	private final Class<E> enumType;
	private Map<String, E> nameMap;
	private Map<E, String> valueMap;
	private E nullValue;
	private boolean caseSensitive;

	protected StringEnumType(Class<E> enumType) {
		this.enumType = enumType;
	}

	// ParameterizedType

	@Override
	public void setParameterValues(Properties parameters) {
		caseSensitive = "true".equalsIgnoreCase(parameters.getProperty(CASE_SENSITIVE));

		nameMap = new HashMap<>();
		valueMap = new HashMap<>();
		for (E constant : enumType.getEnumConstants()) {
			String name = caseSensitive
					? constant.name()
					: constant.name().toUpperCase();
			nameMap.put(name, constant);
			valueMap.put(constant, name);
		}

		for (Map.Entry<?, ?> e : parameters.entrySet()) {
			String constName = (String) e.getKey();
			if (constName.startsWith(CONSTANT_PREFIX)) {
				constName = constName.substring(CONSTANT_PREFIX.length());
				E constant = Enum.valueOf(enumType, constName);
				String name = caseSensitive
						? (String) e.getValue()
						: ((String) e.getValue()).toUpperCase();
				nameMap.put(name, constant);
				valueMap.put(constant, name);
			}
		}

		String nullName = parameters.getProperty(NULL_VALUE);
		if (nullName != null) {
			nullValue = Enum.valueOf(enumType, nullName);
		}
	}

	// UserType

	@Override
	public int getSqlType() {
		return Types.VARCHAR;
	}

	@Override
	public Class<E> returnedClass() {
		return enumType;
	}

	@Override
	public boolean equals(E obj1, E obj2) {
		return obj1 == obj2;
	}

	@Override
	public int hashCode(E obj) {
		return obj == null ? 0 : obj.hashCode();
	}

	@Override
	public E nullSafeGet(ResultSet result, int position, SharedSessionContractImplementor sessionImplementor, Object o) throws HibernateException, SQLException {
		String name = result.getString(position);
		return valueOf(result.wasNull() ? null : name);
	}

	@Override
	public void nullSafeSet(PreparedStatement stmt, E value, int index, SharedSessionContractImplementor sessionImplementor) throws HibernateException, SQLException {
		if (value == null) {
			stmt.setNull(index, Types.VARCHAR);
		} else {
			stmt.setString(index, toString(value));
		}
	}

	@Override
	public E deepCopy(E value) {
		return value;
	}

	@Override
	public boolean isMutable() {
		return false;
	}

	@Override
	public Serializable disassemble(E value) {
		return value;
	}

	@SuppressWarnings("unchecked")
	@Override
	public E assemble(Serializable cached, Object owner) {
		return (E) cached;
	}

	@Override
	public E replace(E original, E target, Object owner) {
		return original;
	}

	// EnhancedUserType
	@Override
	public String toSqlLiteral(E value) {
		return "'" + toString(value) + "'";
	}

	@Override
	public E fromStringValue(CharSequence sequence) throws HibernateException {
		return valueOf(sequence);
	}

	@Override
	public String toString(E value) throws HibernateException {
		return valueMap.get(value == null ? nullValue : value);
	}

	// Privates

	private E valueOf(CharSequence name) {
		if (name == null)
			return nullValue;
		String str = name.toString();
		if (caseSensitive) {
			str = str.toUpperCase();
		}
		E value = nameMap.get(str);
		return value == null ? nullValue : value;
	}

}
