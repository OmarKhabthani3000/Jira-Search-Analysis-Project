package org.hibernate.bugs;

import jakarta.persistence.*;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "CS_FOO_ITEM")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type_id", discriminatorType = DiscriminatorType.INTEGER)
public abstract class FooItem {

	private Long id;
	private Foo foo;

	@Id
	@SequenceGenerator(name = "CS_SEQ", sequenceName = "CS_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CS_SEQ")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FOO_ID")
	public Foo getFoo() {
		return foo;
	}

	public void setFoo(Foo foo) {
		this.foo = foo;
	}

	@Entity
	@DiscriminatorValue("1")
	public static class StringItem extends FooItem {

		private String sort;

		@Column(name = "SORT")
		public String getSort() {
			return sort;
		}

		public void setSort(String sort) {
			this.sort = sort;
		}
	}

	@Entity
	@DiscriminatorValue("2")
	public static class IntItem extends FooItem {

		private Integer sort;

		@Column(name = "SORT")
		public Integer getSort() {
			return sort;
		}

		public void setSort(Integer sort) {
			this.sort = sort;
		}
	}

	@Entity
	@DiscriminatorValue("3")
	public static class EnumItem extends FooItem {

		private SortType sort;

		@Column(name = "SORT")
		@Type(
				value = SortType.Type.class,
				parameters = {
						@org.hibernate.annotations.Parameter(name = "const.ASC", value = "0"),
						@org.hibernate.annotations.Parameter(name = "const.DESC", value = "1")
				}
		)
		public SortType getSort() {
			return sort;
		}

		public void setSort(SortType sort) {
			this.sort = sort;
		}
	}

	public enum SortType {
		ASC,
		DESC;

		public static class Type extends StringEnumType<SortType> {
			public Type() {
				super(SortType.class);
			}
		}
	}
}
