/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import org.hibernate.Session;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.testing.orm.junit.DomainModel;
import org.hibernate.testing.orm.junit.ServiceRegistry;
import org.hibernate.testing.orm.junit.SessionFactory;
import org.hibernate.testing.orm.junit.SessionFactoryScope;
import org.hibernate.testing.orm.junit.Setting;
import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 * <p>
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
@DomainModel(
		annotatedClasses = {
			ORMUnitTestCase.Toy.class,
			ORMUnitTestCase.Color.class,
			ORMUnitTestCase.Family.class,
			ORMUnitTestCase.Person.class,
			ORMUnitTestCase.Child.class,
			ORMUnitTestCase.Man.class,
			ORMUnitTestCase.Woman.class
		},
		// If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
		xmlMappings = {
				// "org/hibernate/test/Foo.hbm.xml",
				// "org/hibernate/test/Bar.hbm.xml"
		}
)
@ServiceRegistry(
		// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
		settings = {
				// For your own convenience to see generated queries:
				@Setting(name = AvailableSettings.SHOW_SQL, value = "true"),
				@Setting(name = AvailableSettings.FORMAT_SQL, value = "true"),
				// @Setting( name = AvailableSettings.GENERATE_STATISTICS, value = "true" ),

				// Add your own settings that are a part of your quarkus configuration:
				// @Setting( name = AvailableSettings.SOME_CONFIGURATION_PROPERTY, value = "SOME_VALUE" ),
		}
)
@SessionFactory
class ORMUnitTestCase {

	@Test
	public void itShouldGetPersons(SessionFactoryScope scope) throws Exception {
		// This case fails because it adds an alias of "type1_1_0_" to the "TYPE" column of the Person table, but after retrieving the ResultSet
		// it tries to find a column named "TYPE" instead of the alias
		//
		// Note that this only fails on databases with a strict JDBC driver such as PostgreSQL. If you change the hibernate.properties to use a database
		// with a more lenient JDBC driver such as H2 or HSQL it will "work". This is because when you search for the "TYPE" column, even though it is
		// aliased, and technically shouldn't be available the JDBC driver will fall back and find it because it was the name of the column in the table schema
		scope.inTransaction( session -> {
			session.markForRollbackOnly();
			loadData(session);
			var results = session.createNativeQuery("select {p.*} from person p").addEntity("p", Person.class).list();
			assertThat( results.size(), is( familyMembers.size() ) );
		} );
	}

	@Test
	public void itShouldGetFamilyMembers(SessionFactoryScope scope) throws Exception {
		// This case works because it does not add an alias to the TYPE column when retrieving the family members (Person table)
		scope.inTransaction( session -> {
			session.markForRollbackOnly();
			loadData(session);
			var results = session.createNativeQuery("select {f.*} from family f").addEntity("f", Family.class).list();
			Family family = (Family)results.get(0);
			List<Person> members = family.getMembers();
			assertThat( members.size(), is( familyMembers.size() ) );
		} );
	}

	private Toy marioToy;
	private Toy fidgetSpinner;
	private Man john;
	private Woman jane;
	private Child susan;
	private Child mark;
	private Family family;
	private List<Child> children;
	private List<Person> familyMembers;

	public void loadData(Session session) {

		marioToy = new Toy(1L, "Super Mario retro Mushroom");
		fidgetSpinner = new Toy(2L, "Fidget Spinner");
		john = new Man( "John", "Riding Roller Coasters" );
		jane = new Woman( "Jane", "Hippotherapist" );
		susan = new Child( "Susan", marioToy );
		mark = new Child( "Mark", fidgetSpinner );
		family = new Family( "McCloud" );
		children = new ArrayList<>( Arrays.asList( susan, mark ) );
		familyMembers = Arrays.asList( john, jane, susan, mark );
		
		
		session.persist(marioToy);
		session.persist(fidgetSpinner);

		jane.setColor(new Color("pink"));
		jane.setHusband( john );
		jane.setChildren( children );

		john.setColor(new Color("blue"));
		john.setWife( jane );
		john.setChildren( children );

		for ( Child child : children ) {
			child.setFather( john );
			child.setMother( jane );
		}

		for ( Person person : familyMembers ) {
			family.add( person );
		}

		session.persist( family );

		session.flush();
		session.clear();
	}


	@Embeddable
	public static class Color {
//		@JdbcTypeCode(SqlTypes.JSON)
//		@Column(name = "color", columnDefinition = "json")
		@Column(name = "color")
		private String attributes;

		public Color() {
		}

		public Color(final String attributes) {
			this.attributes = attributes;
		}

		public String getAttributes() {
			return attributes;
		}

		public void setAttributes(final String attributes) {
			this.attributes = attributes;
		}
	}

	@Entity(name = "Family")
	public static class Family {

		@Id
		private String name;

		@OneToMany(mappedBy = "familyName", cascade = CascadeType.ALL, orphanRemoval = true)
		private List<Person> members = new ArrayList<>();

		public Family() {
		}

		public Family(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public List<Person> getMembers() {
			return members;
		}

		public void setMembers(List<Person> members) {
			this.members = members;
		}

		public void add(Person person) {
			person.setFamilyName( this );
			members.add( person );
		}

		@Override
		public String toString() {
			return "Family [name=" + name + "]";
		}
	}

	@Entity(name = "Person")
	@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
	@DiscriminatorColumn(name = "TYPE", discriminatorType = DiscriminatorType.STRING)
	public static class Person {

		@Id
		private String name;

		@ManyToOne
		private Family familyName;

		public Person() {
		}

		public Person(String name) {
			this.name = name;
		}


		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Family getFamilyName() {
			return familyName;
		}

		public void setFamilyName(Family familyName) {
			this.familyName = familyName;
		}

		@Override
		public String toString() {
			return name;
		}
	}


	@Entity(name = "Toy")
	public static class Toy {

		@Id
		private Long id;

		private String name;

//		@OneToMany(mappedBy = "favoriteThing", cascade = CascadeType.ALL, orphanRemoval = true)
//		List<Child> favorite = new ArrayList<>();

		public Toy() {
		}

		public Toy(final Long id, final String name) {
			this.id = id;
			this.name = name;
		}

		public Long getId() {
			return id;
		}

		public void setId(final Long id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(final String name) {
			this.name = name;
		}
	}

	@Entity(name = "Child")
	@DiscriminatorValue("CHILD")
	public static class Child extends Person {

		@ManyToOne
		@JoinColumn(name="fav_toy")
		private Toy favoriteThing;

		@ManyToOne
		private Woman mother;

		@ManyToOne
		private Man father;

		public Child() {
		}

		public Child(String name, Toy favouriteThing) {
			super( name );
			this.favoriteThing = favouriteThing;
		}

		public Toy getFavoriteThing() {
			return favoriteThing;
		}

		public void setFavoriteThing(Toy favouriteThing) {
			this.favoriteThing = favouriteThing;
		}

		public Man getFather() {
			return father;
		}

		public void setFather(Man father) {
			this.father = father;
		}

		public Woman getMother() {
			return mother;
		}

		public void setMother(Woman mother) {
			this.mother = mother;
		}
	}

	@Entity(name = "Man")
	@DiscriminatorValue("MAN")
	public static class Man extends Person {

		private Color color;

		@Column(name="fav_hobby")
		private String favoriteThing;

		@OneToOne
		private Woman wife;

		@OneToMany(mappedBy = "father")
		private List<Child> children = new ArrayList<>();

		public Man() {
		}

		public Man(String name, String favoriteThing) {
			super( name );
			this.favoriteThing = favoriteThing;
		}

		public String getFavoriteThing() {
			return favoriteThing;
		}

		public void setFavoriteThing(String favoriteThing) {
			this.favoriteThing = favoriteThing;
		}

		public Woman getWife() {
			return wife;
		}

		public void setWife(Woman wife) {
			this.wife = wife;
		}

		public List<Child> getChildren() {
			return children;
		}

		public void setChildren(List<Child> children) {
			this.children = children;
		}

		public Color getColor() {
			return color;
		}

		public void setColor(final Color color) {
			this.color = color;
		}
	}

	@Entity(name = "Woman")
	@DiscriminatorValue("WOMAN")
	public static class Woman extends Person {

		private Color color;

		private String job;

		@OneToOne
		private Man husband;

		@OneToMany(mappedBy = "mother")
		private List<Child> children = new ArrayList<>();

		public Woman() {
		}

		public Woman(String name, String job) {
			super( name );
			this.job = job;
		}


		public String getJob() {
			return job;
		}

		public void setJob(String job) {
			this.job = job;
		}

		public Man getHusband() {
			return husband;
		}

		public void setHusband(Man husband) {
			this.husband = husband;
		}

		public List<Child> getChildren() {
			return children;
		}

		public void setChildren(List<Child> children) {
			this.children = children;
		}

		public Color getColor() {
			return color;
		}

		public void setColor(final Color color) {
			this.color = color;
		}
	}

}
