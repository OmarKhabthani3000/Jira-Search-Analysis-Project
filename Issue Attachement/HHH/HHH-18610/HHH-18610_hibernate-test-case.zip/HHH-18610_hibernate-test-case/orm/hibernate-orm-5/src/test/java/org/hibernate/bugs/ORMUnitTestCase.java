/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 *
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
			ORMUnitTestCase.Toy.class,
			ORMUnitTestCase.Color.class,
			ORMUnitTestCase.Family.class,
			ORMUnitTestCase.Person.class,
			ORMUnitTestCase.Child.class,
			ORMUnitTestCase.Man.class,
			ORMUnitTestCase.Woman.class
		};
	}

	// If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
	@Override
	protected String[] getMappings() {
		return new String[] {
//				"Foo.hbm.xml",
//				"Bar.hbm.xml"
		};
	}
	// If those mappings reside somewhere other than resources/org/hibernate/test, change this.
	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/test/";
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );

		configuration.setProperty( AvailableSettings.SHOW_SQL, Boolean.TRUE.toString() );
		configuration.setProperty( AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString() );
		//configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, "true" );
	}

	@Test
	public void itShouldGetPersons() {
		// In Hibernate 5 this works properly, retrieving the "type1_1_0_" alias for the discriminator
		try (Session session = openSession()) {
			Transaction tx = session.beginTransaction();
			try {
				loadData(session);
				List<Object> results = session.createNativeQuery("select {p.*} from person p").addEntity("p", Person.class).list();
				assertThat(results.size(), is(familyMembers.size()));
			}
			finally {
				tx.rollback();
			}
		}
	}

	@Test
	public void itShouldGetFamilyMembers() {
		// This also works properly in Hibernate 5 using the "type1_1_1_" alias for the discriminator
		try (Session session = openSession()) {
			Transaction tx = session.beginTransaction();
			try {
				loadData(session);
				List<Object> results = session.createNativeQuery("select {f.*} from family f").addEntity("f", Family.class).list();
				Family family = (Family) results.get(0);
				List<Person> members = family.getMembers();
				assertThat(members.size(), is(familyMembers.size()));
			}
			finally {
				tx.rollback();
			}
		}
	}



	private Toy marioToy;
	private Toy fidgetSpinner;
	private Man john;
	private Woman jane;
	private Child susan;
	private Child mark;
	private Family family;
	private List<Child> children;
	private List<Person> familyMembers;

	public void loadData(Session session) {

		marioToy = new Toy(1L, "Super Mario retro Mushroom");
		fidgetSpinner = new Toy(2L, "Fidget Spinner");
		john = new Man( "John", "Riding Roller Coasters" );
		jane = new Woman( "Jane", "Hippotherapist" );
		susan = new Child( "Susan", marioToy );
		mark = new Child( "Mark", fidgetSpinner );
		family = new Family( "McCloud" );
		children = new ArrayList<>( Arrays.asList( susan, mark ) );
		familyMembers = Arrays.asList( john, jane, susan, mark );


		session.persist(marioToy);
		session.persist(fidgetSpinner);

		jane.setColor(new Color("pink"));
		jane.setHusband( john );
		jane.setChildren( children );

		john.setColor(new Color("blue"));
		john.setWife( jane );
		john.setChildren( children );

		for ( Child child : children ) {
			child.setFather( john );
			child.setMother( jane );
		}

		for ( Person person : familyMembers ) {
			family.add( person );
		}

		session.persist( family );

		session.flush();
		session.clear();
	}

	@Embeddable
	public static class Color {
		@Column(name = "color")
		private String attributes;

		public Color() {
		}

		public Color(final String attributes) {
			this.attributes = attributes;
		}

		public String getAttributes() {
			return attributes;
		}

		public void setAttributes(final String attributes) {
			this.attributes = attributes;
		}
	}

	@Entity(name = "Family")
	public static class Family {

		@Id
		private String name;

		@OneToMany(mappedBy = "familyName", cascade = CascadeType.ALL, orphanRemoval = true)
		private List<Person> members = new ArrayList<>();

		public Family() {
		}

		public Family(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public List<Person> getMembers() {
			return members;
		}

		public void setMembers(List<Person> members) {
			this.members = members;
		}

		public void add(Person person) {
			person.setFamilyName( this );
			members.add( person );
		}

		@Override
		public String toString() {
			return "Family [name=" + name + "]";
		}
	}

	@Entity(name = "Person")
	@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
	@DiscriminatorColumn(name = "TYPE", discriminatorType = DiscriminatorType.STRING)
	public static class Person {

		@Id
		private String name;

		@ManyToOne
		private Family familyName;

		public Person() {
		}

		public Person(String name) {
			this.name = name;
		}


		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Family getFamilyName() {
			return familyName;
		}

		public void setFamilyName(Family familyName) {
			this.familyName = familyName;
		}

		@Override
		public String toString() {
			return name;
		}
	}


	@Entity(name = "Toy")
	public static class Toy {

		@Id
		private Long id;

		private String name;

		//		@OneToMany(mappedBy = "favoriteThing", cascade = CascadeType.ALL, orphanRemoval = true)
		//		List<Child> favorite = new ArrayList<>();

		public Toy() {
		}

		public Toy(final Long id, final String name) {
			this.id = id;
			this.name = name;
		}

		public Long getId() {
			return id;
		}

		public void setId(final Long id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(final String name) {
			this.name = name;
		}
	}

	@Entity(name = "Child")
	@DiscriminatorValue("CHILD")
	public static class Child extends Person {

		@ManyToOne
		@JoinColumn(name="fav_toy")
		private Toy favoriteThing;

		@ManyToOne
		private Woman mother;

		@ManyToOne
		private Man father;

		public Child() {
		}

		public Child(String name, Toy favouriteThing) {
			super( name );
			this.favoriteThing = favouriteThing;
		}

		public Toy getFavoriteThing() {
			return favoriteThing;
		}

		public void setFavoriteThing(Toy favouriteThing) {
			this.favoriteThing = favouriteThing;
		}

		public Man getFather() {
			return father;
		}

		public void setFather(Man father) {
			this.father = father;
		}

		public Woman getMother() {
			return mother;
		}

		public void setMother(Woman mother) {
			this.mother = mother;
		}
	}

	@Entity(name = "Man")
	@DiscriminatorValue("MAN")
	public static class Man extends Person {

		private Color color;

		@Column(name="fav_hobby")
		private String favoriteThing;

		@OneToOne
		private Woman wife;

		@OneToMany(mappedBy = "father")
		private List<Child> children = new ArrayList<>();

		public Man() {
		}

		public Man(String name, String favoriteThing) {
			super( name );
			this.favoriteThing = favoriteThing;
		}

		public String getFavoriteThing() {
			return favoriteThing;
		}

		public void setFavoriteThing(String favoriteThing) {
			this.favoriteThing = favoriteThing;
		}

		public Woman getWife() {
			return wife;
		}

		public void setWife(Woman wife) {
			this.wife = wife;
		}

		public List<Child> getChildren() {
			return children;
		}

		public void setChildren(List<Child> children) {
			this.children = children;
		}

		public Color getColor() {
			return color;
		}

		public void setColor(final Color color) {
			this.color = color;
		}
	}

	@Entity(name = "Woman")
	@DiscriminatorValue("WOMAN")
	public static class Woman extends Person {

		private Color color;

		private String job;

		@OneToOne
		private Man husband;

		@OneToMany(mappedBy = "mother")
		private List<Child> children = new ArrayList<>();

		public Woman() {
		}

		public Woman(String name, String job) {
			super( name );
			this.job = job;
		}


		public String getJob() {
			return job;
		}

		public void setJob(String job) {
			this.job = job;
		}

		public Man getHusband() {
			return husband;
		}

		public void setHusband(Man husband) {
			this.husband = husband;
		}

		public List<Child> getChildren() {
			return children;
		}

		public void setChildren(List<Child> children) {
			this.children = children;
		}

		public Color getColor() {
			return color;
		}

		public void setColor(final Color color) {
			this.color = color;
		}
	}

}
