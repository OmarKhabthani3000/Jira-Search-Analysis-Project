package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.OptimisticLockException;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * <p>
 * This template demonstrates how to develop a test case for Hibernate ORM,
 * using the Java Persistence API.
 * </p>
 * <p>
 * About HHH10501:Why NonBatchingBatcher doesn�t re-throw a
 * StaleObjectStateException.
 * 
 * {@code NonBatchingBatcher#addToBatch()} doesn�t re-throw a
 * StaleObjectStateException with entity information wrapped in it even though
 * it calls same {@code Expectation#verifyOutcome()} as in
 * {@code AbstractEntityPersister#check()}. Currently the
 * OptimisticLockException is thrown without the entity in it for Hibernate
 * versions. See
 * {@link https://hibernate.atlassian.net/browse/HHH-10501|HHH-10501}
 * </p>
 * 
 * @author John Mathew (reporting)
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		// Entities are auto-discovered, so just add them anywhere on class-path
		// Add your tests, using standard JUnit.
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	/**
	 * Test to create a simple person and later update with an invalid version.
	 * Assert that entity information IS NOT wrapped up in the
	 * OptimisticLockException.
	 * 
	 * @throws Exception
	 */
	@Test
	public void hhh10501TestWithBatchVersionedDataIsTrue() throws Exception {
		// Assign entity manager.
		//Batch versioned data is set to true explicitly in templatePUOne.
		entityManagerFactory = Persistence.createEntityManagerFactory("templatePUOne");
		EntityManager em = entityManagerFactory.createEntityManager();

		// Persist a simple person
		Person person = new Person();
		em.getTransaction().begin();
		person.setPersonId(100L);
		person.setFirstName("James");
		person.setLastName("Bond");
		em.persist(person);
		em.flush();
		em.getTransaction().commit();

		// Let's check and see few things as expected
		Assert.assertEquals("James", person.getFirstName());
		Assert.assertNull(person.getMiddleName());
		Assert.assertEquals(Long.valueOf(0), person.getUpdateCount());

		// Try updating the middle name.
		em.getTransaction().begin();
		person.setMiddleName("007");
		em.flush();
		em.getTransaction().commit();

		// Check middle name and version count after update.
		Assert.assertEquals("007", person.getMiddleName());
		Assert.assertEquals(Long.valueOf(1), person.getUpdateCount());

		// Let's create a version mismatch here
		em.getTransaction().begin();
		em.createQuery("UPDATE Person p SET p.updateCount = 7 WHERE p.personId = :personId")
				.setParameter("personId", 100L).executeUpdate();
		em.getTransaction().commit();

		// Try to update the middle name again. It should fail because the
		// version has been altered.
		try {
			em.getTransaction().begin();
			person.setMiddleName("Fleming");
			em.flush();
			em.getTransaction().commit();
		} catch (OptimisticLockException e) {
			em.getTransaction().rollback();
			e.printStackTrace();
			// **************************************************************
			// Assert that entity information if not wrapped in the exception.
			// **************************************************************
			Assert.assertNull(e.getEntity());
		}
		em.close();
	}

	/**
	 * Test to create a simple person and later update with an invalid version.
	 * Assert that entity information IS wrapped up in the
	 * OptimisticLockException.
	 * 
	 * @throws Exception
	 */
	@Test
	public void hhh10501TestWithBatchVersionedDataIsFalse() throws Exception {
		// Assign entity manager.
		//Batch versioned data is set to false explicitly in templatePUTwo.
		entityManagerFactory = Persistence.createEntityManagerFactory("templatePUTwo");
		EntityManager em = entityManagerFactory.createEntityManager();

		// Persist another simple person
		Person person = new Person();
		em.getTransaction().begin();
		person.setPersonId(101L);
		person.setFirstName("John");
		person.setLastName("Mathew");
		em.persist(person);
		em.flush();
		em.getTransaction().commit();

		// Let's check and see few things as expected
		Assert.assertEquals("John", person.getFirstName());
		Assert.assertNull(person.getMiddleName());
		Assert.assertEquals(Long.valueOf(0), person.getUpdateCount());

		// Try updating the middle name.
		em.getTransaction().begin();
		person.setMiddleName("X");
		em.flush();
		em.getTransaction().commit();

		// Check middle name and version count after update.
		Assert.assertEquals("X", person.getMiddleName());
		Assert.assertEquals(Long.valueOf(1), person.getUpdateCount());

		// Let's create a version mismatch here
		em.getTransaction().begin();
		em.createQuery("UPDATE Person p SET p.updateCount = 7 WHERE p.personId = :personId")
				.setParameter("personId", 101L).executeUpdate();
		em.getTransaction().commit();

		// Try to update the middle name again. It should fail because the
		// version has been altered.
		try {
			em.getTransaction().begin();
			person.setMiddleName("Y");
			em.flush();
			em.getTransaction().commit();
		} catch (OptimisticLockException e) {
			em.getTransaction().rollback();
			e.printStackTrace();
			// **************************************************************
			// Assert that entity information is wrapped in the exception.
			// **************************************************************
			Assert.assertNotNull(e.getEntity());
			Assert.assertEquals("John", ((Person)e.getEntity()).getFirstName());
		}
		em.close();
	}
}
