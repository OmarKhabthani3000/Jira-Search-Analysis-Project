package pkg;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.Test;

public class PersonTest {

    @Test
    public void identityTest() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("TestPU");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();

        tx.begin();
        try {
        	Country c1 = new Country();
        	c1.setCountryCode("US");
        	c1.setCountryName("United States");
        	Country c2 = new Country();
        	c2.setCountryCode("CA");
        	c2.setCountryName("Canada");
        	Country c3 = new Country();
        	c3.setCountryCode("MX");
        	c3.setCountryName("Mexico");
        	
        	ArrayList<Country> cList1 = new ArrayList<Country>();
        	cList1.add(c2);
        	cList1.add(c3);
        	
        	Person p1 = new Person();
        	p1.setId(1);
        	p1.setPersonName("John Doe");
        	p1.setValidVisas(cList1);
        	Person p2 = new Person();
        	p2.setId(2);
        	p2.setPersonName("Jane Doe");
        	Person p3 = new Person();
        	p3.setId(3);
        	p3.setPersonName("John Smith");
        	
        	Group g1 = new Group();
        	g1.setId(1);
        	g1.setGroupName("Doe family");
        	g1.setGroupLeader(p1);
        	
            em.persist(c1);
            em.persist(c2);
            em.persist(c3);
            em.persist(p1);
            em.persist(p2);
            em.persist(p3);
            em.persist(g1);
            em.flush();
            em.clear();
            emf.getCache().evictAll();
            
    		CriteriaBuilder cb = emf.getCriteriaBuilder();
    		
    		CriteriaQuery<Group> groupQuery = cb.createQuery(Group.class);
    		Root<Group> gRoot = groupQuery.from(Group.class);
    		//Get all groups whose leader's name is John, and has a valid visa for Canada
    		groupQuery.where(cb.and(
    				cb.like(gRoot.get(Group_.groupLeader)
    						.get(Person_.personName), "%John%"),
    				cb.isMember(c2,
        					gRoot.get(Group_.groupLeader)
        					.get(Person_.validVisas)
        					)
        			));
    		
    		List<Group> groupList = em.createQuery(groupQuery).getResultList();
    		Assert.assertEquals(groupList.size(), 1);
    		Assert.assertTrue(groupList.contains(g1));
        } finally {
            tx.rollback();
        }
        em.close();
        emf.close();
    }
}
