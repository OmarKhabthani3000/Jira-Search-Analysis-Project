package pkg;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 * The persistent class for the PERSON database table.
 */
@Entity
public class Group implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	private int id;
	
	@Basic
	private String groupName;
	
	@ManyToOne
	private Person groupLeader;
	
	/**
	 * Default no-argument constructor.
	 */
	public Group() {}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Person getGroupLeader() {
		return groupLeader;
	}

	public void setGroupLeader(Person groupLeader) {
		this.groupLeader = groupLeader;
	}

	/**
	 * Tests equality of the natural key, name
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Group other = (Group) obj;
		if (groupName == null) {
			if (other.groupName != null)
				return false;
		} else if (!groupName.equals(other.groupName))
			return false;
		return true;
	}
	
	/**
	 * Gets a hash code for the pairing that is compatible with the equals
	 * method.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((groupName == null) ? 0 : groupName.hashCode());
		return result;
	}
	
	@Override
	public String toString() {
		return groupName;
	}
}
