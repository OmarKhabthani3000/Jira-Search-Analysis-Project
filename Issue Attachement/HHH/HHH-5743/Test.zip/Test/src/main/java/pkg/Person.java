package pkg;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;

/**
 * The persistent class for the PERSON database table.
 */
@Entity
public class Person implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	private int id;
	
	@Basic
	private String personName;
	
	@OneToMany
	@OrderBy(value="countryCode")
	private List<Country> validVisas;
	
	/**
	 * Default no-argument constructor.
	 */
	public Person() {}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public List<Country> getValidVisas() {
		return validVisas;
	}

	public void setValidVisas(List<Country> validVisas) {
		this.validVisas = validVisas;
	}

	/**
	 * Tests equality of the natural key, name
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		if (personName == null) {
			if (other.personName != null)
				return false;
		} else if (!personName.equals(other.personName))
			return false;
		return true;
	}
	
	/**
	 * Gets a hash code for the pairing that is compatible with the equals
	 * method.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((personName == null) ? 0 : personName.hashCode());
		return result;
	}
	
	@Override
	public String toString() {
		return personName;
	}
}
