package org.hibernate.bugs.model;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;

@Entity
@DiscriminatorValue(value="B")
public class DocumentB extends BaseDocument
{
	private List<DocumentLineB> lines = new LinkedList<>();
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="document", cascade=CascadeType.ALL, orphanRemoval=true)
	public List<DocumentLineB> getLines()
	{
		return lines;
	}
	public void setLines(List<DocumentLineB> lines)
	{
		this.lines = lines;
	}
}
