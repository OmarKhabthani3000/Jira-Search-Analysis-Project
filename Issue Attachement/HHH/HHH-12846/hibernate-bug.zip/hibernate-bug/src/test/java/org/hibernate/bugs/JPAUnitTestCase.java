package org.hibernate.bugs;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;

import org.hibernate.bugs.model.DocumentA;
import org.hibernate.bugs.model.DocumentLineA;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void when_flushMode_is_commit_then_exception() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		
		persistDocument(entityManager, FlushModeType.COMMIT);
		
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	@Test
	public void when_flushMode_is_auto_then_no_exception() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		
		persistDocument(entityManager, FlushModeType.AUTO);
		
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	private void persistDocument(EntityManager entityManager, FlushModeType flushMode)
	{
		entityManager.setFlushMode(flushMode);
		
		DocumentA doc = new DocumentA();
		
		doc.setNumber("1");
		doc.setDate(new Date());
		
		entityManager.persist(doc);
		
		doc.addLine( new DocumentLineA("line1") );
		
		entityManager.merge(doc);
	}
}
