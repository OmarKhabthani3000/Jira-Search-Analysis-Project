package org.hibernate.bugs.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class DocumentLineB extends BaseDocumentLine
{
	private DocumentB document;
	
	private Long number;
	
	public DocumentLineB()
	{
		super();
	}

	public DocumentLineB(String text, Long number)
	{
		super(text);
		this.number = number;
	}

	@ManyToOne(fetch = FetchType.LAZY, optional=false)
	@JoinColumn(updatable=false, insertable=true, nullable=false)
	public DocumentB getDocument()
	{
		return document;
	}

	public void setDocument(DocumentB document)
	{
		this.document = document;
	}

	public Long getNumber()
	{
		return number;
	}

	public void setNumber(Long number)
	{
		this.number = number;
	}
}
