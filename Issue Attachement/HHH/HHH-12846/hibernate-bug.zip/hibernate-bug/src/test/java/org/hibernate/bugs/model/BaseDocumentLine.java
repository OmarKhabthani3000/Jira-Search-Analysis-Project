package org.hibernate.bugs.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class BaseDocumentLine extends AbstractEntity
{
	private String text;
	
	public BaseDocumentLine()
	{
		super();
	}

	public BaseDocumentLine(String text)
	{
		super();
		this.text = text;
	}

	@Column(nullable=false)
	public String getText()
	{
		return text;
	}

	public void setText(String text)
	{
		this.text = text;
	}
}
