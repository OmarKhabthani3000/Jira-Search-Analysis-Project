package org.hibernate.bugs.model;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;

@Entity
@DiscriminatorValue(value="A")
public class DocumentA extends BaseDocument
{
	private List<DocumentLineA> lines = new LinkedList<>();
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="document", cascade=CascadeType.ALL, orphanRemoval=true)
	public List<DocumentLineA> getLines()
	{
		return lines;
	}
	public void setLines(List<DocumentLineA> lines)
	{
		this.lines = lines;
	}
	
	public DocumentA addLine(DocumentLineA line)
	{
		if (line != null)
		{
			line.setDocument(this);
			getLines().add(line);
		}
		
		return this;
	}
}
