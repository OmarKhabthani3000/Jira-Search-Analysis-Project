package sample.entities;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

@Access(AccessType.PROPERTY)
@Entity
@Table (name = "DUP_TEST_B")
public class B extends A {

    private double id = Math.random();
    private long version;
    private String testB;

    @Id
    public double getId() {
        return id;
    }

    public void setId(double id) {
        this.id = id;
    }

    @Version
    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }

    public String getTestB() {
        return testB;
    }

    public void setTestB(String testB) {
        this.testB = testB;
    }

    // Causes duplicate Property
    public String getTestA() {
        return super.getTestA();
    }
}
