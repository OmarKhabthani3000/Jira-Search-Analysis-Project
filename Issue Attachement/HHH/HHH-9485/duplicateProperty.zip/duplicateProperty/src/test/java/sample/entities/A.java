package sample.entities;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class A {

    private String testA;

    public String getTestA() {
        return testA;
    }

    public void setTestA(String test) {
        this.testA = test;
    }
        
}
