package bug;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("BugContext");
		EntityManager em = emf.createEntityManager();
		
		em.find(Child1.class, Long.valueOf(1));
	}

}
