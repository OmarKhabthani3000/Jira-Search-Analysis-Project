package test;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.EnableLoadTimeWeaving;
import org.springframework.context.annotation.EnableLoadTimeWeaving.AspectJWeaving;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TestTransaction;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = HibernatetesterApplication.class)
@EnableLoadTimeWeaving(aspectjWeaving = AspectJWeaving.ENABLED)
@EnableAspectJAutoProxy
public class HibernatetesterApplicationTests
		extends AbstractTransactionalJUnit4SpringContextTests {

	@Autowired
	private UserRepository userRepository;

	@Before
    public void setup() {
    }

	@Test
	public void test() throws Exception {
		User user = userRepository.findOne("user");
		assertThat(user.getRole().getPermissions(), hasSize(1));

		TestTransaction.flagForCommit();
		TestTransaction.end();

		TestTransaction.start();

		user = userRepository.findOne("user");
		assertThat(user.getRole().getPermissions(), hasSize(1));

		TestTransaction.end();
	}

}
