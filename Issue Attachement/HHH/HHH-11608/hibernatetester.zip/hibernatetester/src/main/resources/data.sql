Insert into GNRL_PRIV (PRIV_ID,PRIV_NAME) values (1,'1');
Insert into GNRL_PRIV (PRIV_ID,PRIV_NAME) values (2,'2');
Insert into GNRL_PRIV (PRIV_ID,PRIV_NAME) values (3,'3');
Insert into GNRL_PRIV (PRIV_ID,PRIV_NAME) values (4,'4');
Insert into GNRL_PRIV (PRIV_ID,PRIV_NAME) values (5,'5');
Insert into GNRL_PRIV (PRIV_ID,PRIV_NAME) values (6,'6');
Insert into GNRL_PRIV (PRIV_ID,PRIV_NAME) values (7,'7');
Insert into GNRL_PRIV (PRIV_ID,PRIV_NAME) values (8,'8');
Insert into GNRL_PRIV (PRIV_ID,PRIV_NAME) values (9,'9');
Insert into GNRL_PRIV (PRIV_ID,PRIV_NAME) values (10,'10');

Insert into GNRL_ROLE (ROLE_ID,ROLE_NAME) values (1,'1');

Insert into GNRL_ROLE_PRIV (ROLE_ID,PRIV_ID) values (1,1);

Insert into GNRL_USER (USER_NAME,ROLE_ID,ACTV,LAST_USER,USER_DESC) values ('user',1,'y',null,'User');
