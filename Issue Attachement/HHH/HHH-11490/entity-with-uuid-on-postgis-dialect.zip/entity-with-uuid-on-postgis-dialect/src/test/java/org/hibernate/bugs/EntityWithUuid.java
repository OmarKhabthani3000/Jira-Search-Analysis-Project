package org.hibernate.bugs;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.Type;

@Entity
public class EntityWithUuid {
	
	@Id
	@GeneratedValue
	private Long id;
	
	@Type(type="pg-uuid")
	private UUID uid = UUID.randomUUID();
	
	public UUID getUid() {
		return uid;
	}

	public Long getId() {
		return id;
	}
}
