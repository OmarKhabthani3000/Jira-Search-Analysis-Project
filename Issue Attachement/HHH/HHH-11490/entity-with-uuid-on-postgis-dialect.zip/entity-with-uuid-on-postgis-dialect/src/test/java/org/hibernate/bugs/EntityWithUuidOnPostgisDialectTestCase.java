/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import java.util.UUID;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;
import static org.junit.Assert.*;

public class EntityWithUuidOnPostgisDialectTestCase extends BaseCoreFunctionalTestCase {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
			EntityWithUuid.class
		};
	}

	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/bugs/";
	}

	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );

		/* Must create a database named 'db1' with 'postgis' extension
		 * --
		 *   psql -U postgres -W postgres -c "CREATE DATABASE db1 WITH OWNER = postgres ENCODING = 'UTF8';"
		 *   psql -U postgres -W postgres -c -d db1 -c "CREATE EXTENSION postgis;"
		 * --
		 */
		configuration.setProperty(AvailableSettings.DIALECT, "org.hibernate.spatial.dialect.postgis.PostgisPG95Dialect");
		//configuration.setProperty(AvailableSettings.DIALECT, "org.hibernate.dialect.PostgreSQL95Dialect");
		configuration.setProperty(AvailableSettings.DRIVER, "org.postgresql.Driver");
		configuration.setProperty(AvailableSettings.URL, "jdbc:postgresql:db1");
		configuration.setProperty(AvailableSettings.USER, "postgres");
		configuration.setProperty(AvailableSettings.PASS, "postgres");

		configuration.setProperty( AvailableSettings.SHOW_SQL, Boolean.TRUE.toString() );
		configuration.setProperty( AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString() );
		//configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, "true" );
	}

	@Test
	public void hhh123Test() throws Exception {
		Session s1 = openSession();
		Transaction tx1 = s1.beginTransaction();

		EntityWithUuid baseEntity = new EntityWithUuid();
		UUID baseEntityUid = baseEntity.getUid();

		s1.persist(baseEntity);
		tx1.commit();
		s1.close();
		
		Session s2 = openSession();
		Transaction tx2 = s2.beginTransaction();
		
		EntityWithUuid loadEntity = s2.find(EntityWithUuid.class, baseEntity.getId());
		UUID loadEntityUid = loadEntity.getUid();
		assertEquals(baseEntityUid, loadEntityUid);

		tx2.commit();
		s2.close();
	}
}
