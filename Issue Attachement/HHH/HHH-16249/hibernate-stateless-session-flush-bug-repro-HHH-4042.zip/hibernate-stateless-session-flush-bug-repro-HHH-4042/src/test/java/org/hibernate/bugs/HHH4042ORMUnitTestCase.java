/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

public class HHH4042ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
				TestEntity.class
		};
	}

	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/test/";
	}

	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );
		configuration.setProperty( AvailableSettings.SHOW_SQL, Boolean.TRUE.toString() );
		configuration.setProperty( AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString() );

		// If this is set to anything greater than 1, all operations within a stateless session that are beyond
		// a multiple of the batch size will be lost.
		configuration.setProperty( "hibernate.jdbc.batch_size", "2" );
	}

	@Test
	public void hhh4042Test_FAILURE() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();

		session.doWork(connection -> {
			try (StatelessSession statelessSession = session.getSessionFactory().openStatelessSession(connection)) {
				// default batch size is configured to be 2, so the third entity is lost with the bug present
				statelessSession.insert(new TestEntity(1));
				statelessSession.insert(new TestEntity(2));
				statelessSession.insert(new TestEntity(3));
			}
		});
		session.flush();
		List<TestEntity> entities = session.createQuery("select t from TestEntity t", TestEntity.class).getResultList();
		Assert.assertEquals("All 3 entities were persisted", 3, entities.size());

		tx.rollback(); // no actual commit required for test
		s.close();
	}

	@Test
	public void hhh4042Test_SUCCESS_WORKAROUND_JDBC_SIZE_1() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();

		session.doWork(connection -> {
			try (StatelessSession statelessSession = session.getSessionFactory().openStatelessSession(connection)) {
				statelessSession.setJdbcBatchSize(1);
				statelessSession.insert(new TestEntity(1));
				statelessSession.insert(new TestEntity(2));
				statelessSession.insert(new TestEntity(3));
			}
		});
		session.flush();
		var entities = session.createQuery("select t from TestEntity t", TestEntity.class).getResultList();
		Assert.assertEquals("All 3 entities were persisted", 3, entities.size());

		tx.rollback(); // no actual commit required for test
		s.close();
	}

	@Test
	public void hhh4042Test_SUCCESS_WORKAROUND_MANUAL_FLUSH() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();

		session.doWork(connection -> {
			try (StatelessSession statelessSession = session.getSessionFactory().openStatelessSession(connection)) {
				statelessSession.insert(new TestEntity(1));
				statelessSession.insert(new TestEntity(2));
				statelessSession.insert(new TestEntity(3));
				((SharedSessionContractImplementor) statelessSession).getJdbcCoordinator().executeBatch();
			}
		});
		session.flush();
		var entities = session.createQuery("select t from TestEntity t", TestEntity.class).getResultList();
		Assert.assertEquals("All 3 entities were persisted", 3, entities.size());

		tx.rollback(); // no actual commit required for test
		s.close();
	}
}
