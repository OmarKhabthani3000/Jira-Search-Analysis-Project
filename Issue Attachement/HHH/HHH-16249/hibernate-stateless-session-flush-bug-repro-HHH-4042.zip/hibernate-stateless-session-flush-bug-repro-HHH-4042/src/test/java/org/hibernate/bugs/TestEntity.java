package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import net.bytebuddy.asm.Advice;

@Entity
public class TestEntity {
    @Id int id;

    public TestEntity() {
    }

    public TestEntity(int id) {
        this.id = id;
    }
}
