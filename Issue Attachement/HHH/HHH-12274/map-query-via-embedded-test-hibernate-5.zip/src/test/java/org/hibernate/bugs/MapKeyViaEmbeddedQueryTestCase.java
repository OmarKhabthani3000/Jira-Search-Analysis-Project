package org.hibernate.bugs;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.MapJoin;
import javax.persistence.criteria.Root;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MapKeyViaEmbeddedQueryTestCase {
	private EntityManagerFactory entityManagerFactory;
	
	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
	}
	
	@After
	public void destroy() {
		entityManagerFactory.close();
	}
	
	@Test
	public void mapKeyViaEmbeddedQueryTest() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		String mapKey = "myKey";
		String mapValue = "myValue";
		MyEntity myEntity = new MyEntity();
		myEntity.getMyEmbeddable().getMap().put(mapKey, mapValue);
		entityManager.persist(myEntity);
		
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<MyEntity> root = criteriaQuery.from(MyEntity.class);
		MapJoin<?, String, String> mapJoin = root.join("myEmbeddable").joinMap("map");
		
		criteriaQuery
			.select(mapJoin.value())
			.where(criteriaBuilder.equal(mapJoin.key(), mapKey));
		
		List<String> resultList = entityManager.createQuery(criteriaQuery).getResultList();
		assertEquals(1, resultList.size());
		assertEquals(mapValue, resultList.get(0));
		
		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
