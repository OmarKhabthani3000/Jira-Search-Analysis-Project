/*
 * $HeadURL$
 * 
 * (c) 2018 IIZUKA Software Technologies Ltd.  All rights reserved.
 */
package org.hibernate.bugs;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;

@Embeddable
public class MyEmbeddable implements Serializable {
	@ElementCollection
	private Map<String, String> map = new HashMap<>();
	
	public Map<String, String> getMap() {
		return map;
	}
}
