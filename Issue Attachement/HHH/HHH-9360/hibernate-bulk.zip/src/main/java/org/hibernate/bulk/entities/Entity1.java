package org.hibernate.bulk.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "entity_1")
@SuppressWarnings("serial")
public class Entity1 implements Serializable {

    @Id
    @GeneratedValue
    private Long id;

    private String title;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "entity2_id")
    private Entity2 entity2;

    @OneToMany(mappedBy = "entity1", fetch = FetchType.LAZY)
    private List<Entity2> entities;

    public Long getId() {
        return this.id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(final String title) {
        this.title = title;
    }

    public Entity2 getEntity2() {
        return this.entity2;
    }

    public void setEntity2(final Entity2 entity2) {
        this.entity2 = entity2;
    }

    public List<Entity2> getEntities() {
        return this.entities;
    }

    public void setEntities(final List<Entity2> entities) {
        this.entities = entities;
    }
}
