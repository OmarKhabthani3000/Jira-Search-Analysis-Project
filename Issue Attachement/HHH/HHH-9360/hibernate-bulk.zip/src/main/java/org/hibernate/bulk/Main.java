package org.hibernate.bulk;

import java.util.Properties;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.bulk.entities.Entity1;
import org.hibernate.bulk.entities.Entity2;
import org.hibernate.cfg.Configuration;
import org.hibernate.dialect.H2Dialect;
import org.hsqldb.jdbc.JDBCDriver;

public class Main {

    private static final int BULK_SIZE = 1000;

    @SuppressWarnings("unchecked")
    public static void main(final String[] args) {
        final Properties properties = new Properties();
        properties.put("hibernate.dialect", H2Dialect.class.getName());
        properties.put("hibernate.hbm2ddl.auto", "update");
        properties.put("hibernate.connection.driver_class", JDBCDriver.class.getName());
        properties.put("hibernate.connection.url", "jdbc:hsqldb:mem:test");
        properties.put("hibernate.connection.username", "sa");
        properties.put("hibernate.connection.password", "");

        final Configuration configuration = new Configuration();
        configuration.addAnnotatedClass(Entity1.class);
        configuration.addAnnotatedClass(Entity2.class);
        configuration.setProperties(properties);

        final StandardServiceRegistryBuilder serviceRegistryBuilder = new StandardServiceRegistryBuilder()
                .applySettings(configuration.getProperties());
        final SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistryBuilder.build());

        final Session session = sessionFactory.openSession();

        for (int i = 0; i < 10000; i++) {
            final Entity1 entity1 = new Entity1();
            session.persist(entity1);

            final Entity2 entity2 = new Entity2();
            session.persist(entity2);

            // session.flush();

            final Criteria criteria = session.createCriteria(Entity2.class);
            entity1.setEntities(criteria.list());

            if (i % BULK_SIZE == 0) {
                session.flush();
            }
        }

        sessionFactory.close();
    }
}
