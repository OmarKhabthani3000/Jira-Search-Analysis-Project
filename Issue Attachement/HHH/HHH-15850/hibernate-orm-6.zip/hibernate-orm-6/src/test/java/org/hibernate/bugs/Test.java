package org.hibernate.bugs;

public interface Test {
    String getName();
}
