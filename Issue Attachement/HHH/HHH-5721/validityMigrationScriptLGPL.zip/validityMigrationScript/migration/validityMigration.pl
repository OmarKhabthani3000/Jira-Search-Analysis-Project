#!/usr/bin/perl
use strict;    # turn on compiler restrictions
#
# updates tables to use validity audit strategy (envers)
#
#
# Global variables
use vars qw($dry_run);
$dry_run=1;
#
#
# Load libraries
#
my $LIB = "../lib";
#
#
require "$LIB/sql_lib.pl";
require "$LIB/config.pl";
require "$LIB/tableConfig.pl";
require "$LIB/loging.pl";

# storing ids and revs of current and last row
my $last_id = "";
my $last_rev = "";

my $current_id = "";
my $current_rev = "";


print "\nStart envers migration script:\n\n";

# Database configuration
my $configuration = read_config("./config.properties");

# Read tables
my %tables = read_tables("./tables.properties");

# Create database handler
print "\n";
my $source_dbh = create_source_dbhandler($configuration);
print "\n";

# process each table
foreach my $table (keys %tables){   
  #print $table . "\n";
  
  # get table keys
  my $keys;
  foreach (@{$tables{$table}}) {
    #print "\t$_\n";	
    $keys = $keys . $_ . ", ";
  }
  $keys = substr $keys, 0, -2;
  #print "keys: " . $keys . "..";
  # perform select to get entries
  print "\n\n\n";
  my $entries = getTableContentAsArrayOfHashes($source_dbh, $table, "select " . $keys . ", rev, revtype from " . $table . " order by " . $keys . ", rev");

  #log_array_of_hashes($entries, 0);

  #
  #now go over each entry and create update statements
  #

  my $row={};
  my $row_name="";

  #variables
  my $current_id = "";
  my $current_rev = "";
  my $current_revtype = "";
  my $last_id = "";
  my $last_rev = "";
  my $last_revtype = "";
    
  print "\n";
  
  #loop for rows of current table
  for $row ( @{$entries} ) {
	
    $last_id = $current_id;
    $last_rev = $current_rev;
    $last_revtype = $current_revtype;

    $current_id = "";
    $current_rev = "";
    $current_revtype = "";

    for $row_name ( keys %{$row} ) {	
      #loging("      $row_name=$row->{$row_name} \n",0);      
      #print "row: " . $row_name . "\n";

      # do nothing if revtype = 2 (delete)
      if ($row_name eq "rev") {
	$current_rev = $row->{$row_name};
      } elsif ($row_name eq "revtype") {
	$current_revtype = $row->{$row_name};
      } else {
	#id fields
	$current_id = $current_id . $row_name . " = '" . $row->{$row_name} . "' AND ";
      }
    }
    $current_id = substr $current_id, 0, -6;
    #print "rev: " . $current_rev . "\n";
    #print "id: " . $current_id . "\n";
        
    #build update statement
    # check if name is equal
      if (lc $current_id eq lc $last_id) {
	#print $first_name . " to " . $second_name ."\n";
	  
	#print $last_revtype;
  
	#set revs
	if ($last_revtype ne "2") {
	  my $updateStatement = "update " . $table ." set revend = '" . $current_rev . "' where " . $last_id . "' AND rev = '" . $last_rev . "';";
	  print $updateStatement;	  
	  runSqlStatement($source_dbh, $updateStatement);
	  print "\n";	 
	}
      }
  }
}

print "finished\n";

exit;

