#!/usr/bin/perl
#
#
#
#
# PERL MODULES WE WILL BE USING
use DBI;
use strict;
use vars qw($dry_run);

#
#
#
sub db_connect
{
  my ($database,$host,$port,$user,$pw,$loglevel)=@_;
  if (!defined($loglevel)) { $loglevel=0;}
  my $db_dsn = "DBI:Pg:dbname=$database;host=$host;port=$port";
  #
  # Source...
  # PERL DBI CON
  my $db_handle = DBI->connect($db_dsn, $user, $pw);
  if ($db_handle)
  {
     loging("Connected to db: $database\@$host\n");
  } else {
     print "Cannot connect to Postgres server: $DBI::errstr\n";
     print " db connection failed\n";
     die "Error!";
  }
  return $db_handle;
}
#
#
#
sub create_source_dbhandler
{
  my ($configuration,$loglevel)=@_;
  if (!defined($loglevel)) { $loglevel=0;}
  return db_connect(
    $configuration->{'database'},
    $configuration->{'host'},
    $configuration->{'port'},
    $configuration->{'user'},
    $configuration->{'pw'},
    $loglevel
  );
}
#
#
#
sub create_target_dbhandler
{
  my ($configuration,$loglevel)=@_;
  if (!defined($loglevel)) { $loglevel=0;}
  return db_connect(
    $configuration->{'target_database'},
    $configuration->{'target_host'},
    $configuration->{'port'},
    $configuration->{'target_user'},
    $configuration->{'target_pw'},
    $loglevel
  );
}

#
#
#
sub create_targetmanagement_dbhandler
{
  my ($configuration,$loglevel)=@_;
  if (!defined($loglevel)) { $loglevel=0;}
  return db_connect(
    $configuration->{'target_management_database'},
    $configuration->{'target_host'},
    $configuration->{'port'},
    $configuration->{'target_user'},
    $configuration->{'target_pw'},
    $loglevel
  );
}

#
#
#
sub getTableContentAsArrayOfHashes
{
   my ($db_handle, $table_name, $sql_statement,$loglevel)=@_;
   if (!defined($loglevel)) { $loglevel=0;}
   #
   # Get all rows from the source table
   #
   my $query = "select * from $table_name";


   # loging("SQL: (".$query.")(".$sql_statement.")\n",0);
   if (defined($sql_statement) && length($sql_statement)>0)
   {
     $query = $sql_statement;
   }
   loging ("      Fetch content of table AS AoH: \t$table_name\n         ($query): ", $loglevel);
   #
   #
   #
   my $prepared_statement= $db_handle->prepare($query);
   if (!defined($prepared_statement))
   {
      print "Cannot prepare SELECT $query $DBI::errstr\n";
      die("Compilation of $query failed");
   }
   $prepared_statement->execute;
   my $rows = $prepared_statement->fetchall_arrayref({});
   if (!defined($rows) || (@{$rows}<=0))
   {
      loging ("         (NO VALUES TO MIGRATE)\n", $loglevel);
      return ();
   }
   $prepared_statement->finish;
   loging("Done\n", $loglevel);
   return $rows;
}

#
#
#
sub getTableContentAsHashOfHashes
{
   my ($db_handle,$table_name, $sql_statement, $keyrow, $loglevel)=@_;
   if (!defined($loglevel)) { $loglevel=0;}
   #
   # Get all rows from the source table
   #
   my $query = "select * from $table_name";
   if (defined($sql_statement) && length($sql_statement)>0)
   {
     $query = $sql_statement;
   }
   loging ("    Fetch content of table: \t$table_name\n         ($query):\n", $loglevel);
   #
   #
   #
   my $result_hash = $db_handle->selectall_hashref($query,$keyrow);
   if (!defined($result_hash) || (keys(%{$result_hash})<=0))
   {
      loging ("         (NO VALUES TO MIGRATE)\n", $loglevel);
      return {};
   }
   return $result_hash;
}

#
#
#
sub getTableColumn
{
   my ($db_handle,$table_name, $sql_statement, $loglevel)=@_;
   if (!defined($loglevel)) { $loglevel=0;}
   #
   # Get all rows from the source table
   #
   my $query = "select * from $table_name";
   if (defined($sql_statement) && length($sql_statement)>0)
   {
     $query = $sql_statement;
   }
   loging ("    Fetch content of table: \t$table_name\n         ($query):\n", 0);
   #
   #
   #
   my $prepared_statement= $db_handle->prepare($query);
   if (!defined($prepared_statement))
   {
      print "Cannot prepare SELECT $query $DBI::errstr\n";
      die("Compilation of $query failed");
   }
   $prepared_statement->execute;
   my $source_rows = $prepared_statement->fetchall_arrayref({});
   if (!defined($source_rows) || (@{$source_rows}<=0))
   {
      loging ("         (NO VALUES TO MIGRATE)\n",0);
      return ();
   }
   $prepared_statement->finish;
   return $source_rows;
   my ($db_handle,$table_name, $sql_statement)=@_;


}
#
#
#
sub runSelectStatement
{
    my ($db_handler, $sql_statement, $comment, $loglevel)=@_;
    if (!defined($loglevel)) { $loglevel=0;}
    my $resultarray=();
    my @vector=();
    my $field;
    my $select_handler = $db_handler->prepare($sql_statement);
    if (!defined($select_handler))
    {
                 print "Cannot prepare SELECT $comment $DBI::errstr\n";
    }
    if (!$select_handler->execute)
    {
                  print "Cannot execute SELECT $comment FOR PATH $DBI::errstr\n";
    }
    while (@vector = $select_handler->fetchrow)
    {
        foreach $field (@vector)
        {
            push(@{$resultarray},$field);
        }
    }
    $select_handler->finish;
    return $resultarray;
}
#
# USED for delete statement to make dryrun functionality easier
#
sub runSqlStatement
{
   my ($db_handler,$sql_statement,$comment,$error_comment, $loglevel)=@_;
   if (!defined($loglevel)) { $loglevel=0;}
   #
   #
   #
   loging("  $comment: ", $loglevel);
   if (1==$dry_run)
   {
       my $prepared_stmt = $db_handler->prepare($sql_statement);
       if (!defined($prepared_stmt))
       {
           die "Cannot prepare $error_comment $DBI::errstr\n";
       }
       if (!$prepared_stmt->execute)
       {
           die "$error_comment: Cannot execute ($sql_statement) Resaon: $DBI::errstr\n";
       }
       $prepared_stmt->finish;
   }
   loging("Done\n", $loglevel);
}

#
# execute the complete content of an sql files
#
sub executeSqlFile
{
   my ($db_handler,$filename,$loglevel)=@_;
   if (!defined($loglevel)) { $loglevel=0;}
   my $sql_line="";
   my $line_count=0;
   open (SQL_FILE, $filename);
   loging ("  Executing $filename: ",$loglevel);
   #
   #
   #
   while (<SQL_FILE>)
   {
      $line_count++;
      s/\-\-.*//;         # ignore comments by erasing them
      next if /^(\s)*$/;  # skip blank lines
      chomp;
      $sql_line=$sql_line." ".$_;
      if (/^.*\;$/)
      {
        loging ("$sql_line\n",2);
        runSqlStatement($db_handler,$sql_line,"","SQL Error on line: $line_count of $filename",1);
        $sql_line="";
      }
      if (($line_count % 30)==0)
      {
        loging(".", $loglevel);
      }
   }
   #
   #
   #
   close (SQL_FILE);
   loging(" Done\n",$loglevel);
}
#
#
#
sub writeContentIntoTable
{
   my ($db_handler, $table_name, $content_array_of_hashes, $loglevel, $key_array)=@_;
   if (!defined($content_array_of_hashes)) {return;};
   if (!defined($loglevel)) { $loglevel=0;}
   my @target_row_list=@{$content_array_of_hashes};
   my @fields =();
   my $target_keys={};
   my $insert_query="";
   my $row_counter=0;
   
   loging("      Write AoH into ($table_name): ",$loglevel);

   my $part=1;
   if ((@target_row_list/10)>=1)
   {
      $part=@target_row_list/10;
   }
                  
   if ($#target_row_list>=0)
   {
      #
      # if no key_array is specified all keys are persisted 
      #
      if (!defined($key_array)) 
      {
         loging("\n          key_array NOT DEFINED!!\n", 1);
         $target_keys=@{$content_array_of_hashes}[0];
         @fields = keys %{$target_keys};
      }
      else
      {
         @fields=@{$key_array};
      };


      my $field_list=join ", ", @fields;
      my $field_placeholders=join ", ", map {'?'} @fields;
      my $insert_query= qq{insert into $table_name ( $field_list ) values ( $field_placeholders ) };
      loging("          INSERTSTATEMENT: $insert_query :",1);
      my $insert_prepared_statement=$db_handler->prepare($insert_query);
      #
      # Insert the mapped rows with the prepared statement
      #
      my $counter=0;
      for(@{$content_array_of_hashes})
      {
        $insert_prepared_statement->execute(@{$_} {@fields});
        if (($row_counter % $part) ==0)
        {
          loging(".", $loglevel);
        }
        $row_counter++;
      }
      $insert_prepared_statement->finish;
   }
   loging(" Done\n",$loglevel);
}
#
#
#
sub copyTable
{
   my ($source_dbh, $source_table, $destination_dbh, $destination_table, $sql_statement, $row_mapping, $loglevel)=@_;
   if (!defined($loglevel)) { $loglevel=0;}
   loging("    Copy table: \t$source_table\tto\tDestination: $destination_table\n", $loglevel);
   my $source_rows=getTableContentAsArrayOfHashes($source_dbh, $source_table, $sql_statement,$loglevel);
   #
   #
   #
   if (!defined($source_rows) || (@{$source_rows}<=0))
   {
       return;
   }
   #
   # Create all rows for the target table
   #
   my $target_list=();
   #
   # Output
   #
   my $source_row;
   my $source_row_name;
   my $row_counter=0;
   my $part=1;
   if ((@{$source_rows}/10)>=1)
   {
      $part=@{$source_rows}/10;
   }
   loging ("         (".@{$source_rows}.")\t: ",$loglevel);
   #
   # Mapping of rows
   #
   for $source_row ( @{$source_rows} )
   {
      my $rec = {};
      loging("    { \n",1);
      for $source_row_name ( keys %$source_row )
      {
        loging("      $source_row_name=$source_row->{$source_row_name} ",1);
        my $target_key=$source_row_name;
        if (defined(%{$row_mapping}->{$source_row_name}))
        {
              loging("-> (".%{$row_mapping}->{$source_row_name}.")",1);
              $target_key=%{$row_mapping}->{$source_row_name};
        }
        $rec->{$target_key} =$source_row->{$source_row_name};
        loging ("\n",1);
      }
      loging("    }\n",1);
      #
      #
      #
      push(@{$target_list}, $rec);
      if (($row_counter % $part) ==0)
      {
        loging(".",$loglevel);
      }
      $row_counter++;
   }
   loging(" Done\n",$loglevel);
   #
   #
   #
   writeContentIntoTable($destination_dbh,$destination_table,$target_list,$loglevel);
}
#
#
#
sub copyAllTablesFromFile
{
   my ($source_dbh, $target_dbh, $filename)=@_;
   open (TABLE_FILE, $filename);
   loging ("  Simple Table Copy: $filename ...\n",0);
   #
   #
   #
   while (<TABLE_FILE>)
   {
      s/\#.*//;         # ignore comments by erasing them
      next if /^(\s)*$/;  # skip blank lines
      chomp;
      if (/^.*$/)
      {
        my @tablenames = split(/\t/, $_);
        my $sql_statement = "";
        if (@tablenames>2)
        {
           $sql_statement=@tablenames[2];
        }
        copyTable($source_dbh,@tablenames[0],$target_dbh,@tablenames[1],$sql_statement,{},0);
      }
   }
   #
   #
   #
   close(TABLE_FILE);
   loging ("  Done\n",0);
}
#
#
#
1;
