#!/usr/bin/perl
#
#
#
#
# PERL MODULES WE WILL BE USING
use DBI;
use strict;
use vars qw($LIB);
require "$LIB/sql_lib.pl";
#
#
#
sub init_target_db
{
   my ($configuration)=@_;
   my $target_database=$configuration->{'target_database'};
   my $target_host=$configuration->{'target_host'};
   my $target_user=$configuration->{'target_user'};
   #
   # Connect to management database
   #
   my $target_management_dbh=create_targetmanagement_dbhandler($configuration);
   #
   # Drop target database
   #
   runSqlStatement($target_management_dbh, "DROP DATABASE \"$target_database\";","Deleting $target_database\@$target_host", "ERROR during initialization",0);
   #
   # create statements
   #
   runSqlStatement($target_management_dbh, "CREATE DATABASE\"$target_database\" WITH OWNER = \"$target_user\" ENCODING = \'UTF8\';","Creating $target_database\@$target_host", "ERROR during initialization",0);
   #
   # disconect from management database
   #
   $target_management_dbh->disconnect();
   #
   # connect to fresh database
   #
   my $new_target_dbh=create_target_dbhandler($configuration);
   #
   # create schema
   #
   executeSqlFile($new_target_dbh,$configuration->{'init_script'} );
   #
   #
   #
   $new_target_dbh->disconnect();
}


#
#
#
1;
