*********************************************************
** Envers migration script for validity audit strategy **
**                                                     **
** Stephan Pabinger, libs by Gernot Stocker            **
**                                                     **
** License: lgpl-2.1                                   **
**                                                     **
*********************************************************


This script performs database updates to convert data to the new audit strategy.
It connects to the specified database, performs selects on the tables, and updates the REVEND column.

Configuration steps:

1) backup database
2) alter database configuration in migration/config.properties
3) alter tables in migration/tables.properties
4) execute perl script: perl validityMigration.pl

