#!/usr/bin/perl
#
#
#
use strict;
# Force immediate flushing of output
$| = 1;
#
#
#
#
use vars qw($debug_level); 
sub loging
{
   my ($message, $level)=@_;
   if ($debug_level>=$level)
   {
       print $message;
   }
}
#
#
#
sub log_array
{
   my ($source_array,$loglevel)=@_;
   if (!defined($loglevel)) { $loglevel=0; }
   loging("  { \n",$loglevel);
   
   my $source_value="";
   for $source_value ( @{$source_array} )
   {
        loging("      $source_value\n",$loglevel);
   }
   loging("  }\n",$loglevel);
}
#
#
#
sub log_hash
{
   my ($source_row,$loglevel)=@_;
   my $source_row_name="";
   my $source_key="";
   if (!defined($loglevel)) { $loglevel=0; }
   loging("  { \n",$loglevel);
   
   for $source_row_name ( keys %{$source_row} )
   {
     loging("      $source_row_name=$source_row->{$source_row_name} \n",$loglevel);
   }
   loging("  }\n ",$loglevel);
}
#
#
#
sub log_array_of_hashes
{
   my ($source_rows,$loglevel)=@_;
   my $source_row={};
   my $source_row_name="";
   if (!defined($loglevel)) { $loglevel=0;}
   loging("  { \n",$loglevel);
   for $source_row ( @{$source_rows} )
   {
      loging("    {\n",$loglevel);
      for $source_row_name ( keys %{$source_row} )
      {	
        loging("      $source_row_name=$source_row->{$source_row_name} \n",$loglevel);
      }
      loging("     }\n ",$loglevel);
   }
   loging("  }\n",$loglevel);
}
#
#
#
sub log_hash_of_hashes
{
   my ($source_rows,$loglevel)=@_;
   my $source_row={};
   my $source_row_name="";
   my $source_key="";
   if (!defined($loglevel)) { $loglevel=0; }
   loging("  { \n",$loglevel);
   
   for $source_key ( keys(%{$source_rows}) )
   {
      loging("    ($source_key)\n    {\n",$loglevel);
      $source_row=%{$source_rows}->{$source_key};
      for $source_row_name ( keys %{$source_row} )
      {
        loging("      $source_row_name=$source_row->{$source_row_name} \n",$loglevel);
      }
      loging("     }\n ",$loglevel);
   }
   loging("  }\n",$loglevel);
}
#
#
#
1;
