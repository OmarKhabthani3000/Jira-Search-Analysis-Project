#!/usr/bin/perl
#
#
#
use strict;
#
#
#
sub read_config
{
   my ($filename)=@_;
   my $config_hash={};
   open (CONFIG_FILE, $filename);
   loging ("Reading configuration from $filename ...",0);
   #
   #
   #
   while (<CONFIG_FILE>)
   {
      s/\#.*//;         # ignore comments by erasing them
      next if /^(\s)*$/;  # skip blank lines
      chomp;
      if (/^.*$/)
      {
        my @config_line = split(/\=/, $_);
        $config_hash->{$config_line[0]}=$config_line[1];
      }
   }
   #
   #
   #
   close(CONFIG_FILE);
   loging ("  Done\n",0);
   return $config_hash;
}
#
#
#
1;
