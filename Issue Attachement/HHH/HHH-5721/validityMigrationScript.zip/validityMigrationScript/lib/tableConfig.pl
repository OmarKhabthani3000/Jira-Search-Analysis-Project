#!/usr/bin/perl
#
#
#
use strict;
#
#
#
sub read_tables
{
   my ($filename) = @_;
   my %tables = ();
   open (CONFIG_FILE, $filename);
   loging ("Reading table configuration from $filename ...",0);
   #
   #
   #
   while (<CONFIG_FILE>)
   {
      s/\#.*//;         # ignore comments by erasing them
      next if /^(\s)*$/;  # skip blank lines
      chomp;
      my @line = split(/\,/, $_);
      #
      if (@line > 1) {
	push(@{$tables{$line[0]}}, @line[1,2]);
      } else {
	push(@{$tables{$line[0]}}, 'id');
	#$tables{$line[0]} = "id";
      }
      #add table name to array
      #push(@tables, $_);
      #push($tables, @line);            
   }
   #
   #
   close(CONFIG_FILE);
   loging ("  Done\n",0);
   return %tables;
}
#
#
#
1;
