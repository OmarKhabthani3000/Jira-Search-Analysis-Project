package hibernate.bug;

import hibernate.bug.model.Person;
import hibernate.bug.model.PersonId;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p = new Person(new PersonId("123", "abc"));
        
        em.persist(p);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        
        List<Object[]> l = em.createQuery(
                "SELECT p FROM Person p WHERE p.id <> :id")
                .setParameter("id", new PersonId("123", "def"))
                .getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
}
