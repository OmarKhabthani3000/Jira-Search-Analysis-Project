package hibernate.bug.model;

import javax.persistence.EmbeddedId;

import javax.persistence.Entity;

@Entity
public class Person {

    private PersonId id;
    
    public Person() {
    }

    public Person(PersonId id) {
        this.id = id;
    }

    @EmbeddedId
    public PersonId getId() {
        return id;
    }

    public void setId(PersonId id) {
        this.id = id;
    }
}
