package test1;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity
@Table(name = "TEST_ENTITY")
@Audited
@SequenceGenerator(allocationSize = 1, name = "SEQ_GEN", sequenceName = "SELF_ID_SEQ")
public class SelfReferenceEntity {

	@Id
	@Column(name = "ID")
	@GeneratedValue(generator = "SEQ_GEN", strategy = GenerationType.SEQUENCE)
	private Long id;

	@OneToMany(mappedBy = "golbalData", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@NotAudited
	private Set<SelfReferenceEntity> referencingProductContainers = new HashSet<>();

	@ManyToOne
	@JoinColumn(nullable = true, name = "REFERENCE")
	@Audited
	private SelfReferenceEntity golbalData;

	public SelfReferenceEntity getGolbalData() {
		return golbalData;
	}

	public void setGolbalData(SelfReferenceEntity golbalData) {
		this.golbalData = golbalData;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Set<SelfReferenceEntity> getReferencingProductContainers() {
		return referencingProductContainers;
	}

	public void setReferencingProductContainers(Set<SelfReferenceEntity> referencingProductContainers) {
		this.referencingProductContainers = referencingProductContainers;
	}

}
