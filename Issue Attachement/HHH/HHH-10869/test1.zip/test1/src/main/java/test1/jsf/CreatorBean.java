package test1.jsf;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import test1.EjbTest;

@ViewScoped
@Named
public class CreatorBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Inject	
	EjbTest test;
	
	private Long parentId;
	
	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public Long getChildId() {
		return childId;
	}

	public void setChildId(Long childId) {
		this.childId = childId;
	}

	private Long childId;
	
	public void call() {
		test.bindOneToAnother(parentId, childId);
	}
	
	public void callCreate() {
		test.createNewUnassigned();
	}
	
	
	
}
