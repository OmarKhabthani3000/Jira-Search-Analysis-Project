package test1;

import java.util.Arrays;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class EjbTest {

	
	@PersistenceContext(unitName = "test1")
	private
	EntityManager em;
	
	public void createNewUnassigned() {
//		SelfReferenceEntity selfReferenceEntity = new SelfReferenceEntity();
//		getEm().persist(selfReferenceEntity);
//		System.err.println("Created entity with id: " + selfReferenceEntity.getId());
		
		SelfReferenceEntity b1 = new SelfReferenceEntity();
		SelfReferenceEntity b2 = new SelfReferenceEntity();
		SelfReferenceEntity a1 = new SelfReferenceEntity();
		b1.setGolbalData(a1);
		b2.setGolbalData(a1);
		
		a1.getReferencingProductContainers().addAll(Arrays.asList(b1, b2));
		
		em.persist(a1);
		System.err.println("Created entity with id: " + a1.getId());
	}
	
	public void bindOneToAnother(long parent, long child) {
		SelfReferenceEntity parentEnt = getEm().find(SelfReferenceEntity.class, parent);
		SelfReferenceEntity childEnt = getEm().find(SelfReferenceEntity.class, child);
		System.err.println("Assigining to " + childEnt.getId() + " to " + parentEnt.getId());
		childEnt.setGolbalData(parentEnt);
	}

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}
	
}
