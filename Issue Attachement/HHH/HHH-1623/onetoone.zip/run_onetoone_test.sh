mysql -u root CompanyDB < initdb.sql

CP=.:class:lib/mysql-connector-java-3.1.12-bin.jar:lib/antlr-2.7.6rc1.jar:lib/cglib-2.1.3.jar:lib/asm.jar:lib/asm-attrs.jar:lib/commons-collections-2.1.1.jar:lib/commons-logging-1.0.4.jar:lib/dom4j-1.6.1.jar:lib/jta.jar

java -cp $CP com.zappware.hibernatetest.relations.onetoone.OneToOneTest