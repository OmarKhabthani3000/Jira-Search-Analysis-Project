package com.zappware.hibernatetest.relations.onetoone;

import com.zappware.hibernatetest.relations.onetoone.data.*;
import com.zappware.hibernatetest.util.*;

import java.util.logging.*;

import org.hibernate.*;

public class OneToOneTest
{
	private static void fillDatabase()
	{
		System.out.println("Filling the database, if needed.");
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		
		Employee employee = (Employee)session.get(Employee.class, new Integer(1));
		if(employee == null)
		{
			employee = new Employee(1, "John", "Doe");
			session.save(employee);
		}
		
		Address address = (Address)session.get(Address.class, new Integer(1));
		if(address == null)
		{
			address = new Address(1, "MyStreet", "MyCity");
			session.save(address);
		}
		
		if(employee.getAddress() == null)
			employee.setAddress(address);
		
		session.getTransaction().commit();
		
		System.out.println("Finished filling the database.");
	}
	
	private static void deleteAddress()
	{
		System.out.println("Deleting the Address.");
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		
		Address address = (Address)session.get(Address.class, new Integer(1));
		session.delete(address);
		
		session.getTransaction().commit();
		
		System.out.println("Finished deleting the Address.");
	}
	
	private static void getAddressFromEmployee()
	{
		System.out.println("Getting the Address from the Employee.");
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		
		Employee employee = (Employee)session.get(Employee.class, new Integer(1));
		Address address = employee.getAddress();
		System.out.println("The employee lives in " + address.getCity());
		
		System.out.println("Finished getting the Address from the Employee.");
	}
	
	public static void main(String[] args)
	{
		Logger logger = Logger.getLogger("org.hibernate");
		logger.setLevel(Level.WARNING);
		try
		{
			System.out.println("Starting the test.");
			fillDatabase();
			deleteAddress();
			getAddressFromEmployee();
			
			System.out.println("Finished the test.");
		}
		catch(Exception e)
		{
			System.out.println("Exception caught: " + e);
			e.printStackTrace();
		}
		finally
		{
			HibernateUtil.getSessionFactory().getCurrentSession().close();
			HibernateUtil.getSessionFactory().close();
		}
	}
}
