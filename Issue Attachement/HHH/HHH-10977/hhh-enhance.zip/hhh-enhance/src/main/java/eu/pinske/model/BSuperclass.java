package eu.pinske.model;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class BSuperclass {

}
