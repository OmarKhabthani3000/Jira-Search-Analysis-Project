package eu.pinske.test;

import org.hibernate.engine.spi.ManagedEntity;
import org.junit.Assert;
import org.junit.Test;

import eu.pinske.model.AEntity;
import eu.pinske.model.CEntity;

public class EnhanceTest {

    @Test
    public void test() {
        Assert.assertTrue("A not enhanced", ManagedEntity.class.isAssignableFrom(AEntity.class));
        Assert.assertTrue("C not enhanced", ManagedEntity.class.isAssignableFrom(CEntity.class));
    }

}
