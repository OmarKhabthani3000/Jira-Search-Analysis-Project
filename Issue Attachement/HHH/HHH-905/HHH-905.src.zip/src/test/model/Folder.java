/*
 * Created on Nov 23, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package test.model;

import java.util.Collection;

/**
 * @author masf
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Folder extends PersistentObject {
	private static final long serialVersionUID = 3257568390934573110L;
	
	String name;
	Collection<Folder> subFolders = null;
	Folder parent = null;
	User owner = null;

	protected Folder() {}
	
	public String getName() { return name; }
	public void setName( String newName ) { name = newName; }

	public Folder getParent() { return parent; }
	public void setParent( Folder parent ) {	this.parent = parent; }

	public Collection<Folder> getSubFolders() { return subFolders; }
	public void setSubFolders( Collection<Folder> subFolders ) {
		this.subFolders = subFolders;
	}
	public User getOwner() {
		return owner;
	}
	public void setOwner( User owner ) {
		this.owner = owner;
	}

}
