/*
 * Created on Nov 16, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package test.model;

import java.io.Serializable;

/**
 * @author masf
 *
 * Base interface for all objects which (potentially) can be saved to persistent storage
 * Derived objects can be in one of 3 states as follows:
 * 	Transient			- no ID, for example object was just created and not yet persisted
 *  Persistent			- object stored in persistent storage, have persistent ID
 *  Temporary			- object stored in temporary storage, have temporary ID (T bit set)
 */
public interface IPersistentObject extends Serializable {
	
	/**
	 * Returns 0 for transient objects or ID for persistent/temporary objects
	 * ID is a 64bit word and has following structure:
	 * +------------------------------+
	 * | T--- | CCCC |       ID       |
	 * | 4bit | 4bit |      56bit     |
	 * +------+------+----------------+
	 * where:
	 * 	CCCC is object class (1-15), 0 has special meaning: PA compatible 32 bit ID structure
	 *  T	 Temporary flag
	 *  3bit reserved for future use (either class space can be extended or new flags introduced)
	 * @return object ID or 0 for transient objects
	 */
	long getId();
	void setId( long id );
}
