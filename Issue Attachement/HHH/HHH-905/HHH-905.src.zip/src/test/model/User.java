/*
 * Created on 23.07.2004
 *
 */
package test.model;


/**
 * @author dmax
 *
 */
public class User extends PersistentObject  {
	private static final long serialVersionUID = -4512858513928511654L;

	private String username = null;
	private String password = null;
	
	public String getName() { return username; }
	public void setName(String name) { username = name; }
	
	public String getPassword() { return password; }
	public void setPassword(String password) { this.password = password; }
	
	public String toString() { return getName();	}

}
