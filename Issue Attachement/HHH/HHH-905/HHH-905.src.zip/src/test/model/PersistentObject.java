/*
 * Created on Nov 16, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package test.model;

import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * @author masf
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public abstract class PersistentObject implements IPersistentObject {
	
	protected long	id = 0;
	
	public PersistentObject() {}
	
	/**
	 * Copy constructor
	 * @param po
	 */
	public PersistentObject( IPersistentObject po ) {
		// Never copy ID, it will be 0 (transient) in clone
		this.id = 0;
	}

	/**
	 * @return id of the object
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id
	 */
	public void setId( long id ) {
		this.id = id;
	}

	@Override public boolean equals( Object obj ) {
		if( getId() == 0 && ((IPersistentObject)obj).getId() == 0 )
			return super.equals( obj );
		else
			return getId() == ((IPersistentObject)obj).getId();
	}
	@Override public int hashCode() {
		if( getId() == 0 )
			return super.hashCode();
		else
			return new HashCodeBuilder().append( getId() ).toHashCode();
	}

}
