/*
 * Copyright � 2004, 2005, Property of Columbia Ultimate, Inc., Vancouver,
 * Washington. All rights reserved.
 * 
 * All software source code contained herein, and any computer executable
 * code resulting from the use or compilation thereof, are the exclusive
 * and proprietary materials constituting the intellectual property of
 * Columbia Ultimate, Inc. Dissemination, disclosure, reproduction,
 * copying, or any other form of communication by or to any parties outside
 * of Columbia Ultimate, Inc., is strictly forbidden without the express
 * prior written permission of an authorized Officer of Columbia Ultimate,
 * Inc.
 * 
 * Alteration, modification, or the creation of derivative works of any
 * type from the software source code contained herein is strictly
 * prohibited. Decompilation, disassembly, or otherwise reverse engineering
 * any part of the Software, or engagement in any other activities to
 * obtain underlying information in or about the Software that is not
 * visible to the user in connection with normal use of the Software, is
 * forbidden.
 *  
 */
package test.test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

    protected SessionFactory factory = null;

    protected void init() {
        Configuration config = new Configuration();
        config = config.configure();
        factory = config.buildSessionFactory();
    }
    
    protected void fini() {
        factory.close();
    }
    
    protected void test() {
        Session session = factory.openSession();
        
        Transaction tx = null;
        
        try {
            tx = session.beginTransaction();
            
            session.enableFilter( "VisibleObjects" ).setParameter( "userid", 1L );
            Query q = session.createQuery( "FROM Folder obj WHERE obj.parent is null" );
            List objList = q.list(); 
            
            System.out.println(objList.size());
            
            session.flush();
            tx.commit();
        } catch (Throwable t) {
            t.printStackTrace(System.out);
            tx.rollback();
        } finally{
            session.close();
        }
    }

    public static void main(String[] args) {
        Test test = new Test();
        test.init();
        test.test();
        test.fini();
    }

}

