package com.example;

import javax.persistence.*;
import java.util.HashMap;
import java.util.Map;

@Entity
public class Book {

    public enum BookType {

        PAPER(1), INTERNET(2);

        private int code;
        private static Map<Integer, BookType> typesByCode = new HashMap<>();
        static {
            for (BookType type : BookType.values()) {
                typesByCode.put(type.code, type);
            }
        }
        BookType(int code) {
            this.code = code;
        }
        public int getCode() {
            return this.code;
        }
        public static BookType fromCode(int code) {
            return typesByCode.get(code);
        }
    }

    @Converter(autoApply = true)
    public static class BookTypeConverter implements AttributeConverter<BookType, Integer> {
        @Override
        public Integer convertToDatabaseColumn(BookType attribute) {
            return attribute == null ? null : attribute.getCode();
        }
        @Override
        public BookType convertToEntityAttribute(Integer dbData) {
            return dbData == null ? null : BookType.fromCode(dbData);
        }
    }

    @Id
    @GeneratedValue
    private Long id;

    @Column(nullable = false)
    private BookType type;

    @Basic
    private String name;

    public Book() {}

    public Book(String name, BookType type) {
        this.name = name;
        this.type = type;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BookType getType() {
        return type;
    }

    public void setType(BookType type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return this.getId() + ". " + this.getName() + " (" + this.getType() + ")";
    }
}
