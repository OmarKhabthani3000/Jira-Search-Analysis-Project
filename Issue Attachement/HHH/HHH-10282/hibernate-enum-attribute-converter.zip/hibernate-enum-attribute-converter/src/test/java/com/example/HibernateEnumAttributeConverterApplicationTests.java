package com.example;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = HibernateEnumAttributeConverterApplication.class)
public class HibernateEnumAttributeConverterApplicationTests {

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private TransactionTemplate transactionTemplate;

    @Before
    public void setUp() throws Exception {
        createBooks();
    }

    @After
    public void tearDown() throws Exception {
        deleteAllBooks();
    }

    @Test
	public void contextLoads() {
	}

	@Test
	public void findPaperBooksUsingFullyQualifiedEnumName() {
		List<Book> paperBooks = entityManager
                .createQuery("SELECT b FROM Book b WHERE b.type = com.example.Book$BookType.PAPER", Book.class)
                .getResultList();
		System.out.println("Found (using FQN) " + paperBooks.size() + " paper books: " + paperBooks);
        assertEquals(2, paperBooks.size());
	}

    @Test
    public void findPaperBooksUsingShortEnumName() {
        List<Book> paperBooks = entityManager
                .createQuery("SELECT b FROM Book b WHERE b.type = Book$BookType.PAPER", Book.class)
                .getResultList();
        System.out.println("Found (using short enum name) " + paperBooks.size() + " paper books: " + paperBooks);
        assertEquals(2, paperBooks.size());
    }

    private void createBooks() {
        transactionTemplate.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                Book book1 = new Book("Java in Action", Book.BookType.PAPER);
                Book book2 = new Book("Groovy in Action", Book.BookType.PAPER);
                Book book3 = new Book("Node.js E-book", Book.BookType.INTERNET);

                entityManager.persist(book1);
                entityManager.persist(book2);
                entityManager.persist(book3);
            }
        });
    }

    private void deleteAllBooks() {
        transactionTemplate.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                entityManager.createQuery("DELETE FROM Book b").executeUpdate();
            }
        });
    }

}
