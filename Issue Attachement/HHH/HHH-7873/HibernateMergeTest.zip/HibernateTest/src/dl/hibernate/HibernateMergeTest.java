package dl.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cache.ehcache.SingletonEhCacheRegionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.junit.Test;

public class HibernateMergeTest {

	@Test
	public void test() {
		@SuppressWarnings("deprecation")
		SessionFactory sessionFactory = buildConfig().buildSessionFactory();

		// create simple object graph (just one node - root node)
		Long mappingId = session1(sessionFactory);

		// add new node to graph and connect with root node
		session2(sessionFactory, mappingId);
	}

	private Long session1(SessionFactory sessionFactory) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction();

		// create new graph
		ObjectGraph graph = new ObjectGraph();
		GraphNode root = new SomeGraphNode();
		// each node (including root) must be added to nodes collection
		graph.addNode(root);
		// set this node as root node
		graph.setRoot(root);

		session.save(graph);
		tran.commit();
		session.close();

		return graph.id;
	}

	private void session2(SessionFactory sessionFactory, Long mappingId) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction();

		// retrive graph from db
		ObjectGraph graph = (ObjectGraph) session.load(ObjectGraph.class, mappingId);
		// acces root node via node collection (graph.getRoot() works)
		GraphNode root = graph.getNodes().iterator().next();

		// create new node
		SomeGraphNode anotherNode = new SomeGraphNode();
		// add to mapping
		graph.addNode(anotherNode);

		// connect this two nodes with each other
		root.getIncoming().add(anotherNode);
		anotherNode.getOutgoing().add(root);

		// try to merge
		session.merge(graph); // <--- Exception here!

		tran.commit();
		session.close();
	}

	// if runned as Java program prints schema to console
	public static void main(String[] args) {
		Configuration config = buildConfig();
		SchemaExport export = new SchemaExport(config);
		export.setFormat(true);
		export.create(true, false);
	}

	private static Configuration buildConfig() {
		Configuration config = new Configuration();
		config.setProperty("hibernate.format_sql", "true");
		config.setProperty("javax.persistence.validation.mode", "none");
		config.setProperty("hibernate.cache.region.factory_class", SingletonEhCacheRegionFactory.class.getCanonicalName());
		config.setProperty("hibernate.cache.use_query_cache", "true");
		config.addAnnotatedClass(ObjectGraph.class);
		config.addAnnotatedClass(GraphNode.class);
		config.addAnnotatedClass(SomeGraphNode.class);

		return config.configure();
	}

}
