package dl.hibernate;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "t_node")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING)
public abstract class GraphNode {

	public void setGraph(ObjectGraph graph) {
		this.graph = graph;
	}

	public Set<GraphNode> getIncoming() {
		return incoming;
	}

	public Set<GraphNode> getOutgoing() {
		return outgoing;
	}

	@ManyToOne(optional = false, fetch = FetchType.LAZY)
	@JoinColumn(name = "graph_id")
	ObjectGraph graph;

	@ManyToMany(mappedBy = "outgoing")
	@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
	Set<GraphNode> incoming = new HashSet<GraphNode>();

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "t_connections", joinColumns = { @JoinColumn(name = "in_id", nullable = false) }, inverseJoinColumns = { @JoinColumn(name = "out_id", nullable = false) })
	@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
	Set<GraphNode> outgoing = new HashSet<GraphNode>();

	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name = "increment", strategy = "increment")
	Long id;
}
