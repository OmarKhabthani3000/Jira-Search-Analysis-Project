package dl.hibernate;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "t_graph")
public class ObjectGraph {

	public void addNode(GraphNode node) {
		this.nodes.add(node);
		node.setGraph(this);
	}

	public GraphNode getRoot() {
		return root;
	}

	public void setRoot(GraphNode root) {
		this.root = root;
	}

	public Set<GraphNode> getNodes() {
		return this.nodes;
	}

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "graph")
	@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
	Set<GraphNode> nodes = new HashSet<GraphNode>();

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	GraphNode root;

	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name = "increment", strategy = "increment")
	Long id;
}
