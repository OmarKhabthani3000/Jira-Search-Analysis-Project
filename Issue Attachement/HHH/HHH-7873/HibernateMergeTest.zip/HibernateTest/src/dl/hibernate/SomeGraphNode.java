package dl.hibernate;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "some")
public class SomeGraphNode extends GraphNode {
	// nothing special here...
}
