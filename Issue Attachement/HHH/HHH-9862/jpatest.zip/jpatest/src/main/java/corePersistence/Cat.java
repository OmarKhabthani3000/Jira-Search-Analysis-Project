package corePersistence;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@PrimaryKeyJoinColumn(name = "ID", referencedColumnName = "ID")
public class Cat extends Pet {
    private String felineProperty;

    public String getFelineProperty() {
        return felineProperty;
    }

    public void setFelineProperty(String felineProperty) {
        this.felineProperty = felineProperty;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((felineProperty == null) ? 0 : felineProperty.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Cat other = (Cat) obj;
        if (felineProperty == null) {
            if (other.felineProperty != null)
                return false;
        } else if (!felineProperty.equals(other.felineProperty))
            return false;
        return true;
    }
}
