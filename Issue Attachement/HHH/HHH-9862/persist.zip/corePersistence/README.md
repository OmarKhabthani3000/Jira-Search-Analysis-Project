corePersistence
===============
