package corePersistence;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:hsql-context.xml")
public class TreatTest {
    @PersistenceContext
    EntityManager entityManager;

    @Before
    public void setup() {
        Cat cat = new Cat();
        cat.setId("cat_id");
        cat.setName("cat");
        cat.setFelineProperty("meow");
        entityManager.persist(cat);

        Dog dog = new Dog();
        dog.setId("dog_id");
        dog.setName("dog");
        dog.setCanineProperty("bowwow");
        entityManager.persist(dog);
    }

    @Test
    public void testTreatQuery() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Object[]> query = cb.createQuery(Object[].class);
        Root<Pet> root = query.from(Pet.class);
        query.multiselect(
                root.get("id"),
                root.get("name"),
                cb.treat(root, Cat.class).get("felineProperty"),
                cb.treat(root, Dog.class).get("canineProperty"));
        List<Object[]> results = entityManager.createQuery(query).getResultList();

        Assert.assertEquals(2, results.size());
    }
}
