package corePersistence;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@PrimaryKeyJoinColumn(name = "ID", referencedColumnName = "ID")
public class Bunny extends Pet {
    private String bunnyProperty;

    public String getBunnyProperty() {
        return bunnyProperty;
    }

    public void setBunnyProperty(String bunnyProperty) {
        this.bunnyProperty = bunnyProperty;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((bunnyProperty == null) ? 0 : bunnyProperty.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Bunny other = (Bunny) obj;
        if (bunnyProperty == null) {
            if (other.bunnyProperty != null)
                return false;
        } else if (!bunnyProperty.equals(other.bunnyProperty))
            return false;
        return true;
    }
}
