package corePersistence;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@PrimaryKeyJoinColumn(name = "ID", referencedColumnName = "ID")
public class Dog extends Pet {
    private String canineProperty;

    public String getCanineProperty() {
        return canineProperty;
    }

    public void setCanineProperty(String canineProperty) {
        this.canineProperty = canineProperty;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((canineProperty == null) ? 0 : canineProperty.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Dog other = (Dog) obj;
        if (canineProperty == null) {
            if (other.canineProperty != null)
                return false;
        } else if (!canineProperty.equals(other.canineProperty))
            return false;
        return true;
    }
}
