
DROP TABLE IF EXISTS `test`.`esk_case`;
CREATE TABLE  `test`.`esk_case` (
  `GUID` bigint(20) NOT NULL AUTO_INCREMENT,
  `OPTLOCK` int(11) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `creationUser` varchar(255) DEFAULT NULL,
  `modificationDate` datetime DEFAULT NULL,
  `modificationUser` varchar(255) DEFAULT NULL,
  `description` text,
  `shortDescription` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`GUID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `test`.`esk_history`;
CREATE TABLE  `test`.`esk_history` (
  `DTYPE` varchar(31) NOT NULL,
  `GUID` bigint(20) NOT NULL AUTO_INCREMENT,
  `OPTLOCK` int(11) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `creationUser` varchar(255) DEFAULT NULL,
  `modificationDate` datetime DEFAULT NULL,
  `modificationUser` varchar(255) DEFAULT NULL,
  `description` text,
  `ESCALATIONCASE` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`GUID`),
  KEY `FKB41B7792FF338497` (`ESCALATIONCASE`),
  CONSTRAINT `FKB41B7792FF338497` FOREIGN KEY (`ESCALATIONCASE`) REFERENCES `esk_case` (`GUID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
