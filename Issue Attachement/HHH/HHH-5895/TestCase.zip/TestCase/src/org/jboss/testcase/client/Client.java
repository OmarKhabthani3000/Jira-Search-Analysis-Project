package org.jboss.testcase.client;

import java.util.Hashtable;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.jboss.testcase.EscalationCaseImpl;
import org.jboss.testcase.StoreManager;

public class Client {
	private static String jnpURL = null;

	private Hashtable<String,String> env = new Hashtable<String,String>();
	private InitialContext ic = null;
	private final String objName = "SOEscalationCaseService/remote";

	private StoreManager storeManager = null;
	private List<EscalationCaseImpl> escCases = null;
	private static String hostName = null;
	
	
	public Client() {
		
		jnpURL="jnp://" + hostName +":1099";
		env.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
        env.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
        
        env.put(Context.PROVIDER_URL, jnpURL);
        
        try {
        	
        	ic = new InitialContext(env);
        	
        	storeManager = ( StoreManager) ic.lookup(objName);
        	
        } catch (NamingException nEx){
        	
        	System.err.println("Got Exception - " + nEx);
        	
        	System.exit(1);
        }
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		hostName = System.getProperty("hostName", "localhost");
		
		System.out.println("Connecting to host - " + hostName);
		
		Client client = new Client();
		
		client.runMe();

		System.exit(0);
	}
	
	public void runMe(){
		
		escCases = storeManager.findEscalations();
		
		System.out.println("Got the escaltion list . . .");
		
		for (EscalationCaseImpl c : escCases){
			System.out.println(c);
		}
		
		return;
	}

}
