
package org.jboss.testcase;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@javax.persistence.Entity
@javax.persistence.Table(name = "esk_case")
@Inheritance(strategy = InheritanceType.JOINED)
@javax.persistence.NamedQuery(name = "EscalationCaseImpl.findAll", query = "select escalationCaseImpl from EscalationCaseImpl AS escalationCaseImpl")
public class EscalationCaseImpl extends TraceablePersistentLongImpl {

	private static final long serialVersionUID = 3813479297709413597L;

	// ----------- Attribute Definitions ------------

	@Column(length = 4000)
	private String description;
	
	private String shortDescription;
	
	// --------- Relationship Definitions -----------

	@OneToMany(targetEntity = EscalationCaseHistoryImpl.class, mappedBy = "escalationCase", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@Fetch(FetchMode.SUBSELECT)
	@OrderBy("creationDate")
	private List<EscalationCaseHistoryImpl> escalationCaseHistories = null;

	// ---- Manageable Display Attributes (Transient) -----

	// --------------- Constructors -----------------

	/**
	 * Default empty constructor.
	 */
	public EscalationCaseImpl() {
	}

	// -------- GETTER SETTER ----------

	/**
	 * {@inheritDoc}
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * {@inheritDoc}
	 */
	public void setDescription(String value) {
		this.description = value;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getShortDescription() {
		return shortDescription;
	}

	/**
	 * {@inheritDoc}
	 */
	public void setShortDescription(String value) {
		this.shortDescription = value;
	}

	// ------------- Relations ------------------

	/**
	 * @see com.giag.fo.escalation.model.EscalationCase#getEscalationCaseHistories()
	 * @return a list of escaltionCaseHistories
	 */
	public List<EscalationCaseHistoryImpl> getEscalationCaseHistories() {
		return this.escalationCaseHistories;
	}

	/**
	 * @param escalationCaseHistory a list of EscalationCaseHistories
	 * @see com.giag.fo.escalation.model.EscalationCase#setEscalationCaseHistories(java.util.List)
	 */
	public void setEscalationCaseHistories(List<EscalationCaseHistoryImpl> escalationCaseHistories) {
		this.escalationCaseHistories = escalationCaseHistories;
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public void addEscalationCaseHistory(EscalationCaseHistoryImpl escalationCaseHistory) {

		if (this.escalationCaseHistories == null) {
			escalationCaseHistories = new ArrayList<EscalationCaseHistoryImpl>();
		}
		escalationCaseHistory.setEscalationCase(this);
		escalationCaseHistories.add(escalationCaseHistory);

	}

}
