package org.jboss.testcase;

import java.util.Locale;

@javax.persistence.Entity
@javax.persistence.DiscriminatorValue("E")
@javax.persistence.Table(name = "ESK_CASE_HISTORY")
@javax.persistence.NamedQuery(name = "EscalationCaseHistoryImpl.findAll", query = "select escalationCaseHistoryImpl from EscalationCaseHistoryImpl AS escalationCaseHistoryImpl")
public class EscalationCaseHistoryImpl extends EscalationHistoryImpl {

	private static final long serialVersionUID = 7858708400730259159L;

	// --------- Relationship Definitions -----------

	@javax.persistence.ManyToOne(targetEntity = EscalationCaseImpl.class)
	@javax.persistence.JoinColumn(name = "ESCALATIONCASE")
	private EscalationCaseImpl escalationCase;

	// --------------- Constructors -----------------

	/**
	 * Default empty constructor
	 */
	public EscalationCaseHistoryImpl() {
	}

	// ------------- Relations ------------------
	/**
	 * @see com.giag.fo.escalation.model.EscalationCaseDocument#getEscalationCase()
	 * @return the escalationCase
	 */
	public EscalationCaseImpl getEscalationCase() {
		return this.escalationCase;
	}

	/**
	 * @param escalationCase the escalationCase to set
	 */
	public void setEscalationCase(EscalationCaseImpl escalationCase) {
		this.escalationCase = escalationCase;
	}

	// -------- Common Methods -----------

	public String getDescriptionByLocale(Locale locale) {
		return "GET DESCRIPTION BY LOCALE";
	}

}
