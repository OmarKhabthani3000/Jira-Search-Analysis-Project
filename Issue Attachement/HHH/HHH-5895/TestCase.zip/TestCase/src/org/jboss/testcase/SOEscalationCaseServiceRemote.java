package org.jboss.testcase;

import javax.ejb.Remote;

@Remote
public interface SOEscalationCaseServiceRemote extends StoreManager {

}
