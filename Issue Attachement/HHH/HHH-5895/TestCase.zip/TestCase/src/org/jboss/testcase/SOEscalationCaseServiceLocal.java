package org.jboss.testcase;

import javax.ejb.Local;

@Local
public interface SOEscalationCaseServiceLocal extends StoreManager{

}
