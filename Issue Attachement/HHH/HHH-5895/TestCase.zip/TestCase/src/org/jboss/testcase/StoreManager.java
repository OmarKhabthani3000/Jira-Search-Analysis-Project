package org.jboss.testcase;

import java.util.List;

public interface StoreManager {
	public List<EscalationCaseImpl> findEscalations();
}
