package org.jboss.testcase;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceUnit;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
//import org.jboss.ejb3.annotation.LocalBinding;
//import org.jboss.ejb3.annotation.RemoteBinding;
import org.jboss.annotation.ejb.LocalBinding;
import org.jboss.annotation.ejb.RemoteBinding;
import org.apache.log4j.Logger;

/**
 * Session Bean implementation class SOEscalationCaseServiceBean
 */
@Stateless(mappedName = "SOEscalationCaseService")
@Local(SOEscalationCaseServiceLocal.class)
@Remote(SOEscalationCaseServiceRemote.class)

@LocalBinding(jndiBinding="SOEscalationCaseService/local")
@RemoteBinding(jndiBinding="SOEscalationCaseService/remote")

public class SOEscalationCaseServiceBean implements SOEscalationCaseServiceRemote, SOEscalationCaseServiceLocal {
	private static Logger log = Logger.getLogger(SOEscalationCaseServiceBean.class);
	
	@PersistenceContext(unitName = "DbStore")
	private EntityManager em;
    /**
     * Default constructor. 
     */
    public SOEscalationCaseServiceBean() {
        log.info("Initializing SOEscalationCaseServiceBean . . .");
    }

    
    public List<EscalationCaseImpl> findEscalations() {
    	List<EscalationCaseImpl> result = null;
    	
    	log.info("findEscalations() method called . . .");
    	
    	StringBuilder sb = new StringBuilder();
    
    	sb.append("SELECT escalation from EscalationCaseImpl AS Escalation");
    	
    	Query query = em.createQuery(sb.toString());
    	
    	try {
    		
    		result = (List<EscalationCaseImpl>) query.getResultList();
    		
    	} catch (Exception ex){
    		
    	}
    	
    	return result;
    }
}
