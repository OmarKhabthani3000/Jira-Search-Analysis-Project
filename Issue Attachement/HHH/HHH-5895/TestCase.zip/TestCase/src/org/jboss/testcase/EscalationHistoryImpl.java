package org.jboss.testcase;

import javax.persistence.Column;

@javax.persistence.Entity
@javax.persistence.DiscriminatorValue("E")
@javax.persistence.Table(name = "esk_history")
@javax.persistence.NamedQuery(name = "EscalationHistoryImpl.findAll", query = "select escalationHistoryImpl from EscalationHistoryImpl AS escalationHistoryImpl")
public class EscalationHistoryImpl extends TraceablePersistentLongImpl {

	private static final long serialVersionUID = -3108995694783125419L;

	// ----------- Attribute Definitions ------------

	@Column(length = 4000)
	private String description;

	// --------------- Constructors -----------------

	/**
	 * Default empty constructor.
	 */
	public EscalationHistoryImpl() {
	}

	// -------- Attribute Accessors ----------

	/**
	 * @see com.giag.fo.escalation.model.EscalationHistory#getDescription()
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param value the description
	 * @see com.giag.fo.escalation.model.EscalationHistory#setDescription(java.lang.String)
	 */
	public void setDescription(String value) {
		this.description = value;
	}

}
