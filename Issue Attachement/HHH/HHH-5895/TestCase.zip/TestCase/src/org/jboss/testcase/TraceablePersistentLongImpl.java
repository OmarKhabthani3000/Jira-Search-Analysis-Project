package org.jboss.testcase;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

@MappedSuperclass
public class TraceablePersistentLongImpl implements Serializable {

	/**
	 * ID of entity
	 */
	@Id
	@Column(name = "GUID")
	@GeneratedValue(strategy = GenerationType.AUTO) 
	private Long guid;
	
	/**
	 * optimistic lock Version
	 */
	@Version
	@Column(name = "OPTLOCK")
	private Integer version;
	
	/** The creation date. */
    private Date creationDate;
    
    /**
     * Instantiates a new traceable persistent impl.
     */
    public TraceablePersistentLongImpl() {
    }

    /**
     * ----------------- GETTER SETTER --------------------------.
     */

    /**
     * @return the creation date
     * @see com.giag.fo.core.model.TraceablePersistent#getCreationDate()
     */
    public Date getCreationDate() {
            return creationDate;
    }

    /**
     * Sets the creation date.
     * 
     * @param creationDate the creation date
     * 
     * @see com.giag.fo.core.model.TraceablePersistent#setCreationDate(java.util.Date)
     */
    public void setCreationDate(Date creationDate) {
            this.creationDate = creationDate;
    }

    /**
	 * @return opt lock version
	 */
	public Integer getVersion() {
		return this.version;
	}

	/**
	 * @param version actual Version
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}

	/**
	 * @see com.highqit.base.model.enity.Persistent#getGuid()
	 */
	public Object getGuid() {		
		return guid;
	}
	
	/**
	 * @see com.highqit.base.model.enity.Persistent#setGuid(java.lang.Object)
	 */
	public void setGuid(Object guid) {	
		if(guid instanceof Long) {
			this.guid = (Long) guid;
		}
	}
}
