Test Case for JIRA 5895 - Readme
================================


To use this test case you must have an instance of JBoss 4.3 CP08 or CP09 running.
The variable JBOSS_HOME must be set in shell environment.
MySql server must be up and running. I used version 5.1.52
To see the error is best to set the JBoss log level to debug. 

The file build.properties contains project's properties. You have to update this file to reflect your setup.
The resource directory contains sql script that creates two tables in the database server.
The tables must contain few rows each so you will have to insert some data into them.

Run "ant" command to build the project. 
Run "ant deploy" to deploy the project.
Run "ant run" to execute the sql query.

You should see the following error:

09:55:32,610 WARN  [JDBCExceptionReporter] SQL Error: 1054, SQLState: 42S22
09:55:32,610 ERROR [JDBCExceptionReporter] Unknown column 'esk_history.creationDate' in 'order clause'





