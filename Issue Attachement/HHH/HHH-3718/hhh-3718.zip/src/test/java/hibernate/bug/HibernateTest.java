package hibernate.bug;

import hibernate.bug.model.A;
import hibernate.bug.model.B;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.hibernate.Hibernate;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    private int aId;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        A a = new A();
        B b = new B("b");
        em.persist(a);
        em.persist(b);
        
        aId = a.getId();
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        A a = em.getReference(A.class, aId);
        em.close();
        
        Assert.assertFalse(Hibernate.isInitialized(a));
        Assert.assertEquals(aId, a.getId());
    }
}
