import java.util.HashSet;
import java.util.Set;

public class Entity1 {

	private int id;

	private Set<Entity2> entity2s;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void addEntity2(Entity2 entity2) {
		if (entity2s == null) {
			entity2s = new HashSet();
		}
		entity2s.add(entity2);
	}

	public Set<Entity2> getEntity2s() {
		return entity2s;
	}

	public void setEntity2s(Set<Entity2> entity2s) {
		this.entity2s = entity2s;
	}
	
	public String toString() {
		return "[Entity1: " + id + " " + entity2s + "]";
	}
}
