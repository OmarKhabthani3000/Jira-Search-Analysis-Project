public class Entity2 {

	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String toString() {
		return "[Entity2: " + id + "]";
	}
}
