import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {
	private static Log log = LogFactory.getLog(Test.class);

	public static void main(String[] args) throws Exception {

		// Create session factory
		Configuration configuration = new Configuration();
		configuration.configure();
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		// Create two Entity1 and two Entity2
		int entity1Id_1;
		int entity2Id_1;
		int entity2Id_2;
		{
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			//
			Entity1 entity1 = new Entity1();
			//
			Entity2 entity2 = new Entity2();
			session.save(entity2);
			entity1.addEntity2(entity2);
			entity2Id_1 = entity2.getId();
			//
			entity2 = new Entity2();
			session.save(entity2);
			entity1.addEntity2(entity2);
			entity2Id_2 = entity2.getId();
			//
			session.save(entity1);
			entity1Id_1 = entity1.getId();
			log.info(entity1.toString()); // Expected: [Entity1: 1 [[Entity2: 2], [Entity2: 1]]]
			// 
			tx.commit();
			session.close();
		}
		{
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			session.enableFilter("testfilter").setParameter("idParameter", new Integer(entity2Id_1));
			Entity1 entity1 = new Entity1();
			session.load(entity1, entity1Id_1);
			log.info(entity1.toString()); // Expected: [Entity1: 1 [[Entity2: 1]]] >>ERROR!!<<
			tx.commit();
			session.close();
		}
	}
}
