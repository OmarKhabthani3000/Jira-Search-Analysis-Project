package ch.lakepoint.test;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;
import javax.persistence.Version;

import org.hibernate.envers.Audited;

/*******************************************************************************
 *
 * Copyright (c) 2009, 2012  LakePoint AG, Switzerland. All rights reserved.
 *
 * Redistribution and use of this software in source or binary forms,
 * with or without modifications, are prohibited without specific prior 
 * written permission of LakePoint AG, Switzerland.
 *
 *******************************************************************************/

/**
 * @author tmaeder
 *
 */
@Entity
@Audited
@Inheritance(strategy= InheritanceType.JOINED)
public abstract class Super {
	@Id
	@GeneratedValue()
	private Integer id; 

	@Version
	private int version; 

	private String stringValue; 
	
	@ManyToOne(optional = false)
	private Super underlier;
	
	public Super() {
		this.underlier= this;
	}

	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public int getVersion() {
		return version;
	}
	
	public void setVersion(int version) {
		this.version = version;
	}
	
	public String getStringValue() {
		return stringValue;
	}
	
	public void setStringValue(String stringValue) {
		this.stringValue = stringValue;
	}
	
	public Super getUnderlier() {
		return underlier;
	}
	
	public void setUnderlier(Super underlier) {
		this.underlier = underlier;
	}
}
