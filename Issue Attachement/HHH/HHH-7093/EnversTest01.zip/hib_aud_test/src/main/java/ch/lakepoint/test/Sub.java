/*******************************************************************************
 *
 * Copyright (c) 2009, 2012  LakePoint AG, Switzerland. All rights reserved.
 *
 * Redistribution and use of this software in source or binary forms,
 * with or without modifications, are prohibited without specific prior 
 * written permission of LakePoint AG, Switzerland.
 *
 *******************************************************************************/
package ch.lakepoint.test;

import javax.persistence.Entity;

import org.hibernate.envers.Audited;

/**
 * @author tmaeder
 *
 */
@Entity
@Audited
public class Sub extends Super {
}
