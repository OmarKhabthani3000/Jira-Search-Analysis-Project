/*******************************************************************************
 *
 * Copyright (c) 2009, 2012  LakePoint AG, Switzerland. All rights reserved.
 *
 * Redistribution and use of this software in source or binary forms,
 * with or without modifications, are prohibited without specific prior 
 * written permission of LakePoint AG, Switzerland.
 *
 *******************************************************************************/
package ch.lakepoint.test;

import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.hibernate.ejb.HibernatePersistence;

/**
 * @author tmaeder
 *
 */
public class Test {
	public static void main(String[] args) {
		HibernatePersistence hibernatePersistence = new HibernatePersistence();
		EntityManagerFactory emf = hibernatePersistence.createEntityManagerFactory("test", new Properties());
		try {
			EntityManager em = emf.createEntityManager();
			try {
				em.getTransaction().begin();
				
				Sub sub = new Sub();
				sub.setStringValue("some string");
				em.persist(sub);
				
				Sub2 sub2= new Sub2();
				em.persist(sub2);
				
				em.getTransaction().commit();
				
				em.getTransaction().begin();
				
				em.refresh(sub2);
				em.refresh(sub);
				sub2.setUnderlier(sub);
				sub2.setDoubleValue(50);
				sub2.setStringValue("foobar");
				
				em.getTransaction().commit();
				
				em.getTransaction().begin();
				Sub2 result = em.createQuery("from Sub2 s where s.doubleValue = 50", Sub2.class).getSingleResult();
				System.out.println("result");
				result.setStringValue("blabla");
				em.getTransaction().commit();
				
			} finally {
				em.close();
			}
		} finally {
			emf.close();
		}
	}
}
