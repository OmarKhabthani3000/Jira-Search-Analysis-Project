package org.hibernate.test.cache;

import java.io.Serializable;

/**
 * @author Juan Osuna
 */
public class ComplexItemPK implements Serializable {

    private Item item;

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ComplexItemPK that = (ComplexItemPK) o;

        if (!item.getId().equals(that.item.getId())) return false;

        return true;
    }

    public int hashCode() {
        return item.getId().hashCode();
    }
}
