package org.hibernate.test.cache;

/**
 * @author Juan Osuna
 */
public class ComplexItem {

    private ComplexItemPK id;

    private String name;
	private String description;

	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public ComplexItemPK getId() {
		return id;
	}
	public void setId(ComplexItemPK id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
