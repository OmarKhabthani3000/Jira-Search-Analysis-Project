package org.hibernate.test.cache;

import net.sf.ehcache.hibernate.SingletonEhCacheProvider;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.HSQLDialect;
import org.hibernate.test.cache.model.ComplexItem;
import org.hibernate.test.cache.model.Item;
import org.hsqldb.jdbcDriver;
import org.junit.Test;

public class CacheTest {
	// these two strings have the same hashCode()
	private static final String TWO = "Od";
	private static final String ONE = "PE";

	// arbitrary string key for ComplexType
	private static final String SOMESTRING = "test";

	private final SessionFactory sf = new Configuration().
		setProperty(Environment.DIALECT, HSQLDialect.class.getName()).
	    setProperty(Environment.DRIVER, jdbcDriver.class.getName()).
	    setProperty(Environment.URL, "jdbc:hsqldb:mem:test").
	    setProperty(Environment.USER, "sa").
	    setProperty(Environment.PASS, "").
	    setProperty(Environment.POOL_SIZE, "1").
	    setProperty(Environment.AUTOCOMMIT, "false").
	    setProperty(Environment.CACHE_PROVIDER, SingletonEhCacheProvider.class.getName()).
	    setProperty(Environment.HBM2DDL_AUTO, "create-drop").
	    setProperty(Environment.SHOW_SQL, "true").
	    addClass(ComplexItem.class).
	    addClass(Item.class).
	    buildSessionFactory();

	private Session s;
	private Transaction t;

	private void close() {
		t.commit();
		s.close();
	}

	private void open() {
		s = sf.openSession();
		t = s.beginTransaction();
	}

	@Test
	public void testCache() throws Exception {
		open();

		/*
		 * create and insert first entities into db
		 */
		Item i = new Item();
		i.setId(ONE);

		s.save(i);

		ComplexItem ci = new ComplexItem();
		ci.setId(i);
		ci.setQualifier(SOMESTRING);

		s.save(ci);

		close();

		/*
		 * ensure entities aren't in 2nd level cache
		 */
		sf.evict(ComplexItem.class);
		sf.evict(Item.class);

		open();

		/*
		 * get lazy (uninitialized) proxy Item instance
		 */
		i = (Item) s.load(Item.class, ONE);

		ci = new ComplexItem();
		ci.setId(i); // populate key-many-to-one property with proxy
		ci.setQualifier(SOMESTRING);

		/*
		 * get ComplexItem instance, causing value to be cached in the 2nd level
		 * cache with proxy-containing instance as cache key; at this point the
		 * ComplexyType cache region (maxElementsInMemory="1") is full
		 */
		ci = (ComplexItem) s.get(ComplexItem.class, ci);

		close();
		open();

		/*
		 * create and insert ComplexType (and Item) into db, causing a put()
		 * into a full cache region with a CacheKey hashCode() collision and
		 * thereby forcing an equals() comparison, which unsuccessfully tries to
		 * initialize the proxy
		 */
		i = new Item();
		i.setId(TWO);

		s.save(i);

		ci = new ComplexItem();
		ci.setId(i);
		ci.setQualifier(SOMESTRING);

		s.save(ci);

		close();
	}
}
