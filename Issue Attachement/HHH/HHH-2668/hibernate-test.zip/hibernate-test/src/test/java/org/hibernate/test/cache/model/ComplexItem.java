package org.hibernate.test.cache.model;

import java.io.Serializable;

import org.hibernate.util.EqualsHelper;

public class ComplexItem implements Serializable{
	private static final long serialVersionUID = 6791190901106169876L;

	private Item id;
    private String qualifier;
    private String name;

	public Item getId() {
		return id;
	}
	public void setId(Item id) {
		this.id = id;
	}

	public String getQualifier() {
		return qualifier;
	}
	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public boolean equals(Object other) {
		return other instanceof ComplexItem
			&& (this == other
				|| EqualsHelper.equals(getId(), ((ComplexItem) other).getId())
					&& EqualsHelper.equals(getQualifier(), ((ComplexItem) other).getQualifier()));
	}

	@Override
	public int hashCode() {
		return ((17 * 37) + getId().hashCode()) * 37 + getQualifier().hashCode();
		//return 1;
	}
}
