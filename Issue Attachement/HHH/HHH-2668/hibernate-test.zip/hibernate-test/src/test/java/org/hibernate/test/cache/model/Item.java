package org.hibernate.test.cache.model;

import java.io.Serializable;

import org.hibernate.util.EqualsHelper;

public class Item implements Serializable {
	private static final long serialVersionUID = 548199327574459654L;

	private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
	public boolean equals(Object o) {
    	return o instanceof Item
    		&& (this == o
    			|| EqualsHelper.equals(this.getId(), ((Item) o).getId()));
    }

    @Override
	public int hashCode() {
        return id.hashCode();
    	//return 1;
    }
}
