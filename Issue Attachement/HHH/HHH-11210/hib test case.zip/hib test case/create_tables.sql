create table parent_entity (
    parent_entity_id number(14) not null,
    record_version timestamp(9) not null
);

create table multi_child_entity (
    parent_entity_id number(14) not null,
    multi_child_entity_id number(14) not null,
    record_version timestamp(9) not null
);


