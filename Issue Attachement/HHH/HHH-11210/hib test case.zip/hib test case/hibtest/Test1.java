package hibtest;

import java.util.Arrays;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

@Startup
@Singleton
public class Test1 {

    public static final String SCHEMA = "hibtest";
    @PersistenceContext
    private EntityManager em;

    @PostConstruct
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    private void init() {

        //
        // Clear table records.
        //
        for (final String tableName : Arrays.asList("parent_entity", "multi_child_entity")) {
            em.createNativeQuery("delete from " + tableName).executeUpdate();
        }

        //
        // Insert test data
        //
        {
            final ParentEntity pe = new ParentEntity();

            final MultiChildEntity mce1 = new MultiChildEntity();
            {
                mce1.setMultiChildEntityId(201L);
                mce1.setParentEntity(pe);
                pe.getMultiChildEntitys().add(mce1);
            }

            final MultiChildEntity mce2 = new MultiChildEntity();
            {
                mce2.setMultiChildEntityId(202L);
                mce2.setParentEntity(pe);
                pe.getMultiChildEntitys().add(mce2);
            }

            pe.setParentEntityId(2L);

            //
            // Fails with ConcurrentModificationExeption if bytecode instrumentation is present.
            // Failure occurs after Cascade.cascadeProperty has propagated the parent entity id
            // to the first MultiChildEntity. The bytecode wrapper on the setter of MultiChildEntity
            // appears to mutate the Set<MultiChildEntity> in ParentEntity.
            //
            em.persist(pe);
        }

        //
        // Query back test data
        //
        final TypedQuery<ParentEntity> q = em.createQuery(
            "select distinct pe from ParentEntity pe"
            + " left outer join fetch pe.multiChildEntitys",
            ParentEntity.class);

        for (final ParentEntity pe : q.getResultList()) {
            System.out.println("ParentEntity id=" + pe.getParentEntityId());
            System.out.println("   # multi child entities present=" + pe.getMultiChildEntitys().size());
        }
    }
}
