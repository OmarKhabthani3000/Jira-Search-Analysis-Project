package hibtest;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;
@Entity
@Table(name="parent_entity", schema=Test1.SCHEMA)

public class ParentEntity {

    private Long parentEntityId;
	private java.sql.Timestamp recordVersion;

    private Set<MultiChildEntity> multiChildEntitys = new HashSet<>();
    @Basic(fetch=FetchType.LAZY) // bug occurs regardless of whether this is here
    @OneToMany(mappedBy="parentEntity", cascade=CascadeType.ALL, fetch=FetchType.LAZY, orphanRemoval=true)
    public Set<MultiChildEntity> getMultiChildEntitys() {
        return multiChildEntitys;
    }

    public void setMultiChildEntitys(final Set<MultiChildEntity> multiChildEntitys) {
        this.multiChildEntitys = multiChildEntitys;
    }


	@Id
	@Column(name="parent_entity_id")
	public Long getParentEntityId() {
		return parentEntityId;
	}

	public void setParentEntityId(final Long parentEntityId) {
		this.parentEntityId = parentEntityId;
	}

	@Version
	@Column(name="record_version")

	public java.sql.Timestamp getRecordVersion() {
		return recordVersion;
	}

	public void setRecordVersion(final java.sql.Timestamp a_recordVersion) {
		this.recordVersion = a_recordVersion;
	}


	// No-arg constructor
	public ParentEntity() {}

	@Override
	public boolean equals(final Object o) {
		return o != null && o instanceof ParentEntity && (o == this || (this.parentEntityId != null && this.parentEntityId.equals(((ParentEntity) o).getParentEntityId())));
	}

	@Override
	public int hashCode() {
		return this.parentEntityId != null ? this.parentEntityId.hashCode() : super.hashCode();
	}
}
