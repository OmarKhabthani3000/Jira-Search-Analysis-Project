package hibtest;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;
@Entity
@Table(name="multi_child_entity", schema=Test1.SCHEMA)

public class MultiChildEntity {

	private ParentEntity parentEntity;
    private Long parentEntityId;
    private Long multiChildEntityId;
	private java.sql.Timestamp recordVersion;

	@Basic(fetch=FetchType.LAZY)  // bug occurs regardless of whether this is here
    @ManyToOne(targetEntity=ParentEntity.class, cascade=CascadeType.REFRESH, fetch=FetchType.LAZY)
    @JoinColumn(name="parent_entity_id", referencedColumnName="parent_entity_id", insertable=false, updatable=false)
    public ParentEntity getParentEntity() {
        return parentEntity;
    }


	public void setParentEntity(final ParentEntity parentEntity) {
		this.parentEntity = parentEntity;
	}

	@Id
	@Column(name="multi_child_entity_id", unique=true)

	public Long getMultiChildEntityId() {
		return multiChildEntityId;
	}

	public void setMultiChildEntityId(final Long multiChildEntityId) {
		this.multiChildEntityId = multiChildEntityId;
	}

    @Column(name="parent_entity_id")

    public Long getParentEntityId() {
        return parentEntityId == null && getParentEntity() != null ? getParentEntity().getParentEntityId() : parentEntityId;
    }

    public void setParentEntityId(final Long parentEntityId) {
        this.parentEntityId = parentEntityId;
    }

	@Version
	@Column(name="record_version")

	public java.sql.Timestamp getRecordVersion() {
		return recordVersion;
	}

	public void setRecordVersion(final java.sql.Timestamp a_recordVersion) {
		this.recordVersion = a_recordVersion;
	}


	// No-arg constructor
	public MultiChildEntity() {}

	@Override
	public boolean equals(final Object o) {
		return o != null && o instanceof MultiChildEntity && (o == this || (this.multiChildEntityId != null && this.multiChildEntityId.equals(((MultiChildEntity) o).getMultiChildEntityId())));
	}

	@Override
	public int hashCode() {
		return this.multiChildEntityId != null ? this.multiChildEntityId.hashCode() : super.hashCode();
	}
}
