package foo.bar;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Created by IntelliJ IDEA.
 * User: phartmann
 * Date: Apr 23, 2010
 * Time: 9:31:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class Main {
// --------------------------- main() method ---------------------------

    public static void main(String[] args) {
        updateAnAHiberSessionStyle();
//        updateAnAEntityManagerStyle();
    }

    private static void updateAnAEntityManagerStyle() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("persistenceUnit");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        A myA = em.find(A.class, 1l);
        myA.setTextA("changed:" + System.currentTimeMillis());
        em.getTransaction().commit();
        em.close();
        emf.close();
    }

    private static void updateAnAHiberSessionStyle() {
        Transaction tx = null;
        Session session = getCurrentSession();
        try {
            tx = session.beginTransaction();
            A myA = (A) session.load(A.class, 1l);
            myA.setTextA("changed:" + System.currentTimeMillis());
            tx.commit();
        } catch (RuntimeException e) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    e1.printStackTrace();
                }
                throw e;
            }
        }
    }

    private static Session getCurrentSession() {
        return new AnnotationConfiguration().configure().buildSessionFactory().getCurrentSession();
    }
}
