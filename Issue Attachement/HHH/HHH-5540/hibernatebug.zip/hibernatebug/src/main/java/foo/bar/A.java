package foo.bar;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.validation.constraints.NotNull;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 *
 * @autor jviaccava
 * created 08.09.2010
 */
@Entity
public class A {
// ------------------------------ FIELDS ------------------------------

    @Id
    private long id;

    private String textA;

    @ManyToMany
    @NotNull
    private Set<B> b;

// --------------------- GETTER / SETTER METHODS ---------------------

    public Set<B> getB() {
        return b;
    }

    public void setB(Set<B> b) {
        this.b = b;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTextA() {
        return textA;
    }

    public void setTextA(String textA) {
        this.textA = textA;
    }
}
