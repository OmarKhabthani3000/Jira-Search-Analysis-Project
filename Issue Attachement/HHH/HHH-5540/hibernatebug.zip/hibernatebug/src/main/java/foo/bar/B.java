package foo.bar;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 *
 * @autor jviaccava
 * created 08.09.2010
 */
@Entity
public class B {
// ------------------------------ FIELDS ------------------------------

     @Id
    private long id;

    private String textB;

    @ManyToMany
    private Set<C> c;

// --------------------- GETTER / SETTER METHODS ---------------------

    public Set<C> getC() {
        return c;
    }

    public void setC(Set<C> c) {
        this.c = c;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTextB() {
        return textB;
    }

    public void setTextB(String textB) {
        this.textB = textB;
    }
}
