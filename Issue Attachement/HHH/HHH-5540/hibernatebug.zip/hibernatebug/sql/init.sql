create table A (
id number(5) primary key,
textA varchar2(60)
);

create table B (
id number(5) primary key,
textB varchar2(60)
);

create table C (
id number(5) primary key,
textC varchar2(60)
);

create table A_B(
a_id number(5) references a(id),
b_id number(5) references b(id),
primary key (a_id,b_id)
);

create table B_C(
b_id number(5) references b(id),
c_id number(5) references c(id),
primary key (b_id,c_id)
);

insert into a values (1,'this is a A');

insert into b values (2,'this is B1');
insert into b values (3,'this is B2');
insert into b values (4,'this is B3');

insert into c values (5,'this is C1');

insert into B_C values (2,5);
insert into B_C values (3,5);
insert into B_C values (4,5);

insert into A_B values (1,2);
insert into A_B values (1,3);
insert into A_B values (1,4);
