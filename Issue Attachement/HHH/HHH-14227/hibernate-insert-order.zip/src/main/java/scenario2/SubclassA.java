package scenario2;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

@Entity
public class SubclassA extends BaseClass {

    @OneToOne(cascade = CascadeType.ALL)
    private SubclassB referenceB;

    public void setReferenceB(SubclassB referenceB) {
        this.referenceB = referenceB;
    }
}
