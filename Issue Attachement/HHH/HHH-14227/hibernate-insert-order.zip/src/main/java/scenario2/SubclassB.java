package scenario2;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

@Entity
public class SubclassB extends BaseClass {

    @ManyToOne(fetch = FetchType.LAZY)
    private SubclassA referenceA;

    public void setReferenceA(SubclassA referenceA) {
        this.referenceA = referenceA;
    }
}
