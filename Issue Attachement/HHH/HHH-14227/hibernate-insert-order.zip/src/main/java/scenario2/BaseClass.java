package scenario2;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class BaseClass {

    @Id
    @GeneratedValue
    private Long id;
}
