package scenario1;

import javax.persistence.Entity;

@Entity
public class Placeholder extends AbstractEntity {

}
