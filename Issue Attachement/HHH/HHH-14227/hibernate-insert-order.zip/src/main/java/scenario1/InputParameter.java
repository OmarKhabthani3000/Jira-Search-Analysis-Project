package scenario1;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.SortNatural;
import org.hibernate.annotations.Where;


@Entity
@DiscriminatorValue("INPUT")
public class InputParameter extends Parameter {

    @ManyToOne(fetch = FetchType.LAZY)
    private InputParameter parent;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "parent")
    @SortNatural
    @Where(clause = "TYPE = 'INPUT'")
    @Fetch(FetchMode.SUBSELECT)
    private List<InputParameter> children = new ArrayList<>();
}
