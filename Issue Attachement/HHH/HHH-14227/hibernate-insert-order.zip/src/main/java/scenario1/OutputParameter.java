package scenario1;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.SortNatural;
import org.hibernate.annotations.Where;

@Entity
@DiscriminatorValue("OUTPUT")
public class OutputParameter extends Parameter {

    @ManyToOne(fetch = FetchType.LAZY)
    private OutputParameter parent;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "parent")
    @SortNatural
    @Where(clause = "TYPE = 'OUTPUT'")
    @Fetch(FetchMode.SUBSELECT)
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    private List<OutputParameter> children = new ArrayList<>();

    public void setParent(OutputParameter parent) {
        this.parent = parent;
    }

    public List<OutputParameter> getChildren() {
        return children;
    }

    public void addChild(OutputParameter child) {
        getChildren().add(child);
        child.setParent(this);
    }
}
