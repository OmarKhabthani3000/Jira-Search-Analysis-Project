import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import scenario1.InputParameter;
import scenario1.OutputParameter;
import scenario1.Parameter;
import scenario1.Placeholder;
import scenario2.BaseClass;
import scenario2.SubclassA;
import scenario2.SubclassB;


public class InsertOrderTest {

    private SessionFactory sessionFactory;

    private Session getSession() throws HibernateException {
        return sessionFactory.openSession();
    }

    @Before
    public void init() {
        Configuration configuration = new Configuration();

        configuration.setProperty(AvailableSettings.ORDER_INSERTS, "true");
        configuration.setProperty(AvailableSettings.USE_SECOND_LEVEL_CACHE, "false");

        configuration.setProperty(AvailableSettings.DIALECT, "org.hibernate.dialect.H2Dialect");
        configuration.setProperty(AvailableSettings.DRIVER, "org.h2.Driver");
        configuration.setProperty(AvailableSettings.URL, "jdbc:h2:mem:db1");
        configuration.setProperty(AvailableSettings.USER, "sa");
        configuration.setProperty(AvailableSettings.ORDER_INSERTS, "true");
        configuration.setProperty(AvailableSettings.HBM2DDL_AUTO, "create");
        configuration.setProperty(AvailableSettings.SHOW_SQL, "true");

        configuration.addAnnotatedClass(Placeholder.class);
        configuration.addAnnotatedClass(Parameter.class);
        configuration.addAnnotatedClass(OutputParameter.class);
        configuration.addAnnotatedClass(InputParameter.class);
        configuration.addAnnotatedClass(BaseClass.class);
        configuration.addAnnotatedClass(SubclassA.class);
        configuration.addAnnotatedClass(SubclassB.class);

        sessionFactory = configuration.buildSessionFactory();
    }

    @After
    public void destroy() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }

    @Test
    public void testReferenceItself() {
        final Session session = getSession();

        try {
            Transaction transaction = session.beginTransaction();

           Placeholder placeholder = new Placeholder();
           session.save(placeholder);

            OutputParameter outputParameter1 = new OutputParameter();

            OutputParameter childOutputParameter = new OutputParameter();
            outputParameter1.addChild(childOutputParameter);

            session.save(outputParameter1);

            Placeholder placeholder2 = new Placeholder();
            session.save(placeholder2);

            InputParameter inputParameter = new InputParameter();
            session.save(inputParameter);

            OutputParameter outputParameter2 = new OutputParameter();
            session.save(outputParameter2);

            transaction.commit();
        } finally {
            session.close();
        }
    }

    @Test
    public void testReferenceDifferentSubclass(){
        final Session session = getSession();

        try {
            Transaction transaction = session.beginTransaction();

            SubclassA subclassA1 = new SubclassA();
            SubclassB subclassB1 = new SubclassB();

            SubclassA subclassA2 = new SubclassA();
            SubclassB subclassB2 = new SubclassB();

            subclassA1.setReferenceB(subclassB2);
            subclassB2.setReferenceA(subclassA2);

            subclassA2.setReferenceB(subclassB1);

            session.save(subclassA1);
            session.save(subclassA2);

            transaction.commit();

       } finally {
            session.close();
        }
    }
}
