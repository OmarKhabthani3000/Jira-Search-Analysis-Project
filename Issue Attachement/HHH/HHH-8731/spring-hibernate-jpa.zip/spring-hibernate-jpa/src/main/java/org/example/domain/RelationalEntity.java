package org.example.domain;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

/**
 * Represents an entity that can be persisted to a relational data store.
 */
@MappedSuperclass
public abstract class RelationalEntity extends Entity<Long> {
	@Generated(GenerationTime.INSERT)
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	private Long id;

	@Column(name = "version")
	@Version
	protected Long version;

	/**
	 * Gets the unique identifier for this entity instance.
	 *
	 * @return The unique identifier for this entity instance.
	 */
	public Long getID() {
		return this.id;
	}

	/**
	 * Gets the current version for this entity instance.
	 *
	 * @return The current version for this entity instance.
	 */
	public Long getVersion() {
		return this.version;
	}
}
