package org.example.domain.profile;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.example.domain.RelationalEntity;
import org.example.domain.geography.District;

/**
 * Represents a mailing address.
 */
@Entity
@Table(name = "address")
public class Address extends RelationalEntity {
	@Column(name = "apartment")
	@NotNull
	@Size(max = 100)
	private String apartment;

	@Column(name = "building")
	@Size(max = 100)
	private String building;

	@JoinColumn(name = "district_id")
	@ManyToOne(fetch = FetchType.LAZY)
	@NotNull
	private District district;

	@Column(name = "locality")
	@Size(max = 100)
	private String locality;

	@Column(name = "post_code")
	@NotNull
	@Size(max = 12)
	private String postCode;

	@Column(name = "street")
	@Size(max = 100)
	private String street;

	@Column(name = "town")
	@NotNull
	@Size(max = 50)
	private String town;

	/**
	 * Gets the apartment or suite name or number for the address.
	 *
	 * @return The apartment or suite name or number for the address.
	 */
	public String getApartment() {
		return this.apartment;
	}

	/**
	 * Gets the building name or number for the address.
	 *
	 * @return The building name or number for the address.
	 */
	public String getBuilding() {
		return this.building;
	}

	/**
	 * Gets the district in which the address lies.
	 *
	 * @return The district in which the address lies.
	 */
	public District getDistrict() {
		return this.district;
	}

	/**
	 * Gets the locality for the address.
	 *
	 * @return The locality for the address.
	 */
	public String getLocality() {
		return this.locality;
	}

	/**
	 * Gets the postal code for the address.
	 *
	 * @return The postal code for the address.
	 */
	public String getPostCode() {
		return this.postCode;
	}

	/**
	 * Gets the address street name or number.
	 *
	 * @return The address street name or number.
	 */
	public String getStreet() {
		return this.street;
	}

	/**
	 * Gets the town for the address.
	 *
	 * @return The town for the address.
	 */
	public String getTown() {
		return this.town;
	}

	/**
	 * Sets the apartment or suite name or number for the address.
	 *
	 * @param apartment
	 *            The apartment or suite name or number for the address.
	 */
	public void setApartment(final String apartment) {
		this.apartment = apartment;
	}

	/**
	 * Sets the building name or number for the address.
	 *
	 * @param building
	 *            The building name or number for the address.
	 */
	public void setBuilding(final String building) {
		this.building = building;
	}

	/**
	 * Sets the district in which the address lies.
	 *
	 * @param district
	 *            The district in which the address lies.
	 */
	public void setDistrict(final District district) {
		this.district = district;
	}

	/**
	 * Sets the locality for the address.
	 *
	 * @param locality
	 *            The locality for the address.
	 */
	public void setLocality(final String locality) {
		this.locality = locality;
	}

	/**
	 * Sets the postal code for the address.
	 *
	 * @param postCode
	 *            The postal code for the address.
	 */
	public void setPostCode(final String postCode) {
		this.postCode = postCode;
	}

	/**
	 * Sets the address street name or number.
	 *
	 * @param street
	 *            The address street name or number.
	 */
	public void setStreet(final String street) {
		this.street = street;
	}

	/**
	 * Sets the town for the address.
	 *
	 * @param town
	 *            The town for the address.
	 */
	public void setTown(final String town) {
		this.town = town;
	}
}
