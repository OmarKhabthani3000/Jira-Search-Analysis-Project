package org.example.domain.profile;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.example.domain.RelationalEntity;

/**
 * Represents an organization.
 */
@Entity
@Table(name = "organization")
public class Organization extends RelationalEntity {
	@JoinColumn(name = "mailing_address_id", updatable = false)
	@ManyToOne
	@NotNull
	private Address mailingAddress;

	@Column(insertable = false, name = "name", updatable = false)
	@NotNull
	@Size(max = 100)
	private String name;

	@JoinColumn(name = "registered_address_id", updatable = false)
	@ManyToOne
	@NotNull
	private Address registeredAddress;

	/**
	 * Gets the mailing address for the organization.
	 *
	 * @return The mailing address for the organization.
	 */
	public Address getMailingAddress() {
		return this.mailingAddress;
	}

	/**
	 * Gets the organization name.
	 *
	 * @return The organization name.
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Gets the registered address for the organization.
	 *
	 * @return The registered address for the organization.
	 */
	public Address getRegisteredAddress() {
		return this.registeredAddress;
	}

	/**
	 * Sets the organization name.
	 *
	 * @param name
	 *            The organization name.
	 */
	public void setName(final String name) {
		this.name = name;
	}

	/**
	 * Sets the mailing address for the organization.
	 *
	 * @param address
	 *            The mailing address for the organization.
	 */
	public void setMailingAddress(final Address address) {
		this.mailingAddress = address;
	}

	/**
	 * Sets the registered address for the organization.
	 *
	 * @param address
	 *            The registered address for the organization.
	 */
	public void setRegisteredAddress(final Address address) {
		this.registeredAddress = address;
	}
}
