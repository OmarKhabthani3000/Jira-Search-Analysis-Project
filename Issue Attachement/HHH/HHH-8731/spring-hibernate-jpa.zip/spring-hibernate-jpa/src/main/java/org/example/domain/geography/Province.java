package org.example.domain.geography;

import java.util.Collections;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Immutable;

/**
 * Represents a province or state within a country.
 */
@Entity
@Immutable
@Table(name = "province")
public class Province extends Location {
	@JoinColumn(insertable = false, name = "country_id", updatable = false)
	@ManyToOne
	@NotNull
	private Country country;

	@Immutable
	@OneToMany(mappedBy = "province")
	private Set<District> districts;

	/**
	 * Gets the country to which the province belongs.
	 *
	 * @return The country to which the province belongs.
	 */
	public Country getCountry() {
		return this.country;
	}

	/**
	 * Gets the districts within this province.
	 *
	 * @return A {@link Set} of {@link District}s.
	 */
	public Set<District> getDistricts() {
		return Collections.unmodifiableSet(this.districts);
	}
}
