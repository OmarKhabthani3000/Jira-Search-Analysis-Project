package org.example.data.profile;

import org.example.data.IRelationalEntityRepository;
import org.example.domain.profile.Organization;

/**
 * Contract for data access operations on {@link Organization}s.
 */
public interface IOrganizationRepository extends
		IRelationalEntityRepository<Organization> {
}
