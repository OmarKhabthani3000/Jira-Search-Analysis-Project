package org.example.data;

import org.example.domain.RelationalEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * Contract for data access operations on {@link RelationalEntity}s.
 */
@NoRepositoryBean
public interface IRelationalEntityRepository<T extends RelationalEntity>
		extends JpaRepository<T, Long> {
}
