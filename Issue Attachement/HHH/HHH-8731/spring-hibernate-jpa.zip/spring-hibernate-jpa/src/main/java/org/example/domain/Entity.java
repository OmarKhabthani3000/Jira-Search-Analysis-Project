package org.example.domain;

import java.io.Serializable;

import javax.persistence.MappedSuperclass;

/**
 * Represents a domain entity.
 *
 * @param <K>
 *            The type of the primary key for the entity.
 */
@MappedSuperclass
public abstract class Entity<K extends Serializable> {
	/**
	 * Gets the unique identifier for this entity instance.
	 *
	 * @return The unique identifier for this entity instance.
	 */
	public abstract K getID();

	/**
	 * Gets the current version for this entity instance.
	 *
	 * @return The current version for this entity instance.
	 */
	public abstract Long getVersion();

	/**
	 * Gets whether this is a newly created entity instance. Checks the unique
	 * identifier to see if the identifier is {@code null}.
	 *
	 * @return {@code true} if this is a newly created instance.
	 */
	public boolean isNew() {
		return this.getID() == null;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(final Object o) {
		return (o != null) && (o instanceof Entity<?>)
				&& (this.getID() != null) && (((Entity<?>) o).getID() != null)
				&& this.getID().equals(((Entity<?>) o).getID());
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return this.getID() != null ? this.getID().hashCode() : super
				.hashCode();
	}

	/**
	 * Gets whether an entity instance was created before another one.
	 *
	 * @param first
	 *            The first entity instance to be compared.
	 * @param second
	 *            The second entity instance to be compared.
	 * @return {@code 1} if {@code first.id} is lesser than {@code second.id},
	 *         {@code 0} if {@code first.id} is equal to {@code second.id},
	 *         {@code -1} otherwise.
	 */
	protected static <K extends Comparable<K> & Serializable> int compareTo(
			final Entity<K> first, final Entity<K> second) {
		int result = 1;

		if ((first != null) && (first.getID() != null) && (second != null)
				&& (second.getID() != null)) {
			result = first.getID().compareTo(second.getID());
		} else if ((first != null) && (first.getID() != null)) {
			result = -1;
		}

		return result;
	}
}
