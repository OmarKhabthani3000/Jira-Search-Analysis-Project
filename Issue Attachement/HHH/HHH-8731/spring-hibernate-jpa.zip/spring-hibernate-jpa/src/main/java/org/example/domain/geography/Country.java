package org.example.domain.geography;

import java.util.Collections;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Immutable;

/**
 * Represents a country.
 */
@Entity
@Immutable
@Table(name = "country")
public class Country extends Location {
	@Column(insertable = false, name = "independent")
	@NotNull
	private boolean independent;

	@Immutable
	@OneToMany(mappedBy = "country")
	private Set<Province> provinces;

	/**
	 * Gets the provinces within this country.
	 *
	 * @return A {@link Set} of {@link Province}s.
	 */
	public Set<Province> getProvinces() {
		return Collections.unmodifiableSet(this.provinces);
	}

	/**
	 * Gets whether this is an independent country (or under control or
	 * occupation of another country).
	 *
	 * @return Whether this is an independent country.
	 */
	public boolean isIndependent() {
		return this.independent;
	}
}
