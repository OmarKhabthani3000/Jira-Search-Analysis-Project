package org.example.domain.geography;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Immutable;

/**
 * Represents a district or county within a province or state.
 */
@Entity
@Immutable
@Table(name = "district")
public class District extends Location {
	@JoinColumn(insertable = false, name = "province_id", updatable = false)
	@ManyToOne
	@NotNull
	private Province province;

	/**
	 * Gets the province to which the district belongs.
	 *
	 * @return The province to which the district belongs.
	 */
	public Province getProvince() {
		return this.province;
	}
}
