package org.example.domain.geography;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.example.domain.RelationalEntity;

/**
 * Represents a geographic location.
 */
@MappedSuperclass
abstract class Location extends RelationalEntity {
	@Column(name = "code", updatable = false)
	private String code;

	@Column(insertable = false, name = "name", updatable = false)
	@NotNull
	@Size(max = 100)
	private String name;

	/**
	 * Gets the location code.
	 *
	 * @return The location code.
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Gets the location name.
	 *
	 * @return The location name.
	 */
	public String getName() {
		return this.name;
	}
}
