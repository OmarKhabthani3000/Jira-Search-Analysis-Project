package org.example.service.profile;

import java.util.Collection;

import org.example.data.profile.IOrganizationRepository;
import org.example.domain.profile.Organization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Business logic operations on {@link Organization}s.
 */
@Service
public class OrganizationService {
	@Autowired
	IOrganizationRepository organizationRepository;

	/**
	 * Gets all available organizations.
	 *
	 * @return A {@link Collection} of {@link Organization}s.
	 */
	public Collection<Organization> getAll() {
		return this.organizationRepository.findAll();
	}
}
