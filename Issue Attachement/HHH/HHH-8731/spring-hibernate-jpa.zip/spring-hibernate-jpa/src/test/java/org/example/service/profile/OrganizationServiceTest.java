package org.example.service.profile;

import java.util.Collection;

import org.example.domain.profile.Organization;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Unit tests for {@link OrganizationService}s.
 */
@ContextConfiguration(locations = "classpath:springContext.xml")
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
@TransactionConfiguration(defaultRollback = true)
public class OrganizationServiceTest {
	@Autowired
	OrganizationService service;

	/**
	 * Tests that organizations can be retrieved sucessfully.
	 */
	@Test
	public void testGetAll() {
		final Collection<Organization> organizations = this.service.getAll();

		for (final Organization organization : organizations) {
			Assert.assertNotNull(organization);
			Assert.assertNotNull(organization.getName());
			Assert.assertNotNull(organization.getMailingAddress());
			Assert.assertNotNull(organization.getMailingAddress().getApartment());
			Assert.assertNotNull(organization.getMailingAddress().getDistrict());
			Assert.assertNotNull(organization.getMailingAddress().getDistrict().getName());
			Assert.assertNotNull(organization.getMailingAddress().getDistrict().getProvince());
			Assert.assertNotNull(organization.getMailingAddress().getDistrict().getProvince().getName());
			Assert.assertNotNull(organization.getMailingAddress().getDistrict().getProvince().getCountry());
			Assert.assertNotNull(organization.getMailingAddress().getDistrict().getProvince().getCountry().getName());
			Assert.assertNotNull(organization.getMailingAddress().getPostCode());
			Assert.assertNotNull(organization.getMailingAddress().getTown());
			Assert.assertNotNull(organization.getRegisteredAddress());
			Assert.assertNotNull(organization.getRegisteredAddress().getApartment());
			Assert.assertNotNull(organization.getRegisteredAddress().getDistrict());
			Assert.assertNotNull(organization.getRegisteredAddress().getDistrict().getName());
			Assert.assertNotNull(organization.getRegisteredAddress().getDistrict().getProvince());
			Assert.assertNotNull(organization.getRegisteredAddress().getDistrict().getProvince().getName());
			Assert.assertNotNull(organization.getRegisteredAddress().getDistrict().getProvince().getCountry());
			Assert.assertNotNull(organization.getRegisteredAddress().getDistrict().getProvince().getCountry().getName());
			Assert.assertNotNull(organization.getRegisteredAddress().getPostCode());
			Assert.assertNotNull(organization.getRegisteredAddress().getTown());
		}
	}
}
