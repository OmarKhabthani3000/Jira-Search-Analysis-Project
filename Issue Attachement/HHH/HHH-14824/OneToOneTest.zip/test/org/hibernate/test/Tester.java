package org.hibernate.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.Test;

public class Tester {

    @Test
    public void test1() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("TESTPU");
        EntityManager entityManager = factory.createEntityManager();
        entityManager.getTransaction().begin();

        A a = new A();
        a.setId("String1");
        entityManager.persist(a);
        entityManager.flush();

        B b = new B();
        b.setField1(1);
        b.setField2(2);
        entityManager.persist(b);
        entityManager.flush();

        a.setB(b);
        b.setA(a);
        entityManager.flush();
        entityManager.getTransaction().rollback();
    }
}
