package org.hibernate.test;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class A implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;

    @OneToOne(mappedBy = "a", cascade = CascadeType.ALL)
    private B b;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public B getB() {
        return b;
    }

    public void setB(B b) {
        this.b = b;
    }

}
