package petclinic.domain;

import java.util.Date;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Pet {
    public void setId(Long id) {
        this.id = id;
    }
    public Long getId() {
        return id;
    }
    public boolean isNew() {
        return (this.id == null);
    }
    public Long getVersion() {
        return version;
    }
    public void setVersion(Long version) {
        this.version = version;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return this.name;
    }

    private String name;

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }
    public Date getBirthDate() {
        return this.birthDate;
    }
    public void setType(PetType type) {
        this.type = type;
    }
    public PetType getType() {
        return type;
    }
    public void setOwner(Owner owner) {
        this.owner = owner;
    }
    public Owner getOwner() {
        return owner;
    }
    public boolean equals(final Object other) {
        if (!(other instanceof Pet)) {
            return false;
        }
        Pet castOther = (Pet) other;
        return new EqualsBuilder().append(getName(), castOther.getName()).isEquals();
    }
    public int hashCode() {
        return new HashCodeBuilder().append(getName()).toHashCode();
    }
    public String toString() {
        // Pet�̏o��
        StringBuffer sb = new ToStringBuilder(this).
            append("id",        getId()).
//            append("owner", "@"+Integer.toHexString(System.identityHashCode(owner))).
            append("version",   getVersion()).
            append("name",      getName()).
            append("birthDate", getBirthDate()).
//            append("type", getType()).
            getStringBuffer();
        
        // PetType�̏o��
        sb.append(System.getProperty("line.separator"));
        sb.append("    ");
        sb.append(getType());
        
        return sb.toString();
    }

    private Long id;
    private Long version;
    private Date birthDate;
    private PetType type;
    private Owner owner;
}
