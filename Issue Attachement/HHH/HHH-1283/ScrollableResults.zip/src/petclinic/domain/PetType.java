package petclinic.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class PetType {
    public void setId(Long id) {
        this.id = id;
    }
    public Long getId() {
        return id;
    }
    public boolean isNew() {
        return (this.id == null);
    }
    public Long getVersion() {
        return version;
    }
    public void setVersion(Long version) {
        this.version = version;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return this.name;
    }
    public boolean equals(final Object other) {
        if (!(other instanceof PetType)) {
            return false;
        }
        PetType castOther = (PetType) other;
        return new EqualsBuilder().append(getName(), castOther.getName()).isEquals();
    }
    public int hashCode() {
        return new HashCodeBuilder().append(getName()).toHashCode();
    }
    public String toString() {
        return new ToStringBuilder(this).
            append("id", getId()).
            append("version", getVersion()).
            append("name", getName()).
            toString();
    }
    

    private Long id;
    private Long version;
    private String name;
}
