package petclinic.domain;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


public class Owner {
    public void setId(Long id) {
        this.id = id;
    }
    public Long getId() {
        return id;
    }
    public boolean isNew() {
        return (this.id == null);
    }
    public Long getVersion() {
        return version;
    }
    public void setVersion(Long version) {
        this.version = version;
    }
    public String getFirstName() {
        return this.firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return this.lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getAddress() {
        return this.address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getCity() {
        return this.city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getTelephone() {
        return this.telephone;
    }
    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }
    public Set getPets() {
        return pets;
    }
    public void setPets(Set pets) {
        this.pets = pets;
    }

    public void addPet(Pet pet) {
        pet.setOwner(this);
        pets.add(pet);
    }
    public void removePet(Pet pet) {
        pets.remove(pet);
        pet.setOwner(null);
    }
    public boolean equals(final Object other) {
        if (!(other instanceof Owner))
            return false;
        Owner castOther = (Owner) other;
        return new EqualsBuilder().append(getFirstName(), castOther.getFirstName())
                .append(getLastName(), castOther.getLastName()).isEquals();
    }
    public int hashCode() {
        return new HashCodeBuilder().append(getFirstName()).append(getLastName())
                .toHashCode();
    }
    public String toString() {
        StringBuffer sb =
            new ToStringBuilder(this).
                append("id",        getId()).
                append("version",   getVersion()).
                append("firstName", getFirstName()).
                append("lastName",  getLastName()).
                append("address",   getAddress()).
                append("city",      getCity()).
                append("telephone", getTelephone()).
                getStringBuffer();
        
        for (Iterator iter = pets.iterator(); iter.hasNext();) {
            Pet pet = (Pet) iter.next();
            sb.append(System.getProperty("line.separator"));
            sb.append("  ");
            sb.append(pet);
        }
        
        return sb.toString();
    }

    private Long id;
    private Long version;
    private String firstName;
    private String lastName;
    private String address;
    private String city;
    private String telephone;
    private Set pets = new LinkedHashSet(); 
}
