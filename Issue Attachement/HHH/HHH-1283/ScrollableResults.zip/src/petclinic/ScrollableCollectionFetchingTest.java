package petclinic;

import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import petclinic.domain.Owner;

public class ScrollableCollectionFetchingTest extends TestCase {

	public void testScrollingJoinFetchesForward() {
        Session s = null;
        Transaction tx = null;
        try {
            Configuration config = new Configuration();
            SessionFactory factory = config.configure().buildSessionFactory();

            s = factory.openSession();
            tx = s.beginTransaction();
            
//            String hqlJoinFetchTest = "from Owner owner"; // this set pets collection correctly 
            String hqlJoinFetchTest = 
                "from Owner owner " +
                "left outer join fetch owner.pets as pets " +
                "left outer join fetch pets.type " +
                "order by owner.firstName, owner.lastName";
            
            Query query = s.createQuery(hqlJoinFetchTest);
            
            ScrollableResults cursor = query.scroll();
//            ScrollableResults cursor = query.scroll(ScrollMode.FORWARD_ONLY); // next() throw Exception!!
            
            int counter = 0;
            while ( cursor.next() ) {
                counter++;
                Owner owner = (Owner)cursor.get(0);
                System.out.println(owner);
                checkResult( owner );
            }
            assertEquals( "unexpected result count", 2, counter );

            tx.commit();
        } finally {
            s.close();
        }
	}
	private void checkResult(Owner owner) {
		if ( "Betty".equals( owner.getFirstName() ) ) {
			assertEquals( "Betty did not contain 2 children", 2, owner.getPets().size() );
		}
		else if ( "Eduardo".equals( owner.getFirstName() ) ) {
			assertEquals( "Eduardo did not contain 3 children", 3, owner.getPets().size() );
		}
	}
}
