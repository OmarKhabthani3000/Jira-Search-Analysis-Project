package hibernate.bug.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

@Entity
public class PolymorphicSub1 extends PolymorphicBase {
    private static final long serialVersionUID = 1L;

    private IntIdEntity relation1;

    public PolymorphicSub1() {
    }

    public PolymorphicSub1(IntIdEntity relation1) {
        this.relation1 = relation1;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public IntIdEntity getRelation1() {
        return relation1;
    }

    public void setRelation1(IntIdEntity relation1) {
        this.relation1 = relation1;
    }
}
