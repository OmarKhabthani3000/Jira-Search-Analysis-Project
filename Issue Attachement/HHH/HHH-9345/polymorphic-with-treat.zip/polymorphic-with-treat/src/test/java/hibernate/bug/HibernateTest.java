package hibernate.bug;

import hibernate.bug.model.IntIdEntity;
import hibernate.bug.model.PolymorphicPropertySub1;
import hibernate.bug.model.PolymorphicPropertySub2;
import hibernate.bug.model.PolymorphicSub1;
import hibernate.bug.model.PolymorphicSub2;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        IntIdEntity iie1 = new IntIdEntity("a");
        PolymorphicSub1 ps1 = new PolymorphicSub1(iie1);
        PolymorphicPropertySub1 pps1 = new PolymorphicPropertySub1(ps1);
        
        IntIdEntity iie2 = new IntIdEntity("b");
        PolymorphicSub2 ps2 = new PolymorphicSub2(iie2);
        PolymorphicPropertySub2 pps2 = new PolymorphicPropertySub2(ps2);
        
        em.persist(iie1);
        em.persist(ps1);
        em.persist(pps1);
        
        em.persist(iie2);
        em.persist(ps2);
        em.persist(pps2);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testTreat1() {
        EntityManager em = emf.createEntityManager();
        
        List<IntIdEntity> l = em.createQuery(
                "SELECT relation1_1 "
                + "FROM PolymorphicPropertyBase propBase "
                + "LEFT JOIN TREAT(TREAT(propBase AS PolymorphicPropertySub1).base AS PolymorphicSub1) base_1 "
                + "LEFT JOIN base_1.relation1 relation1_1 "
                + "WHERE relation1_1.name = :param_0")
                .setParameter("param_0", "a")
                .getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
    
    @Test
    public void testTreat2() {
        EntityManager em = emf.createEntityManager();
        
        List<IntIdEntity> l = em.createQuery(
                "SELECT relation2_1 "
                + "FROM PolymorphicPropertyBase propBase "
                + "LEFT JOIN TREAT(TREAT(propBase AS PolymorphicPropertySub2).base AS PolymorphicSub2) base_1 "
                + "LEFT JOIN base_1.relation2 relation2_1 "
                + "WHERE relation2_1.name = :param_0")
                .setParameter("param_0", "b")
                .getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
}
