package hibernate.bug.model;

import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class PolymorphicPropertyMapBase<T extends PolymorphicBase> extends PolymorphicPropertyBase {
    
    private static final long serialVersionUID = 1L;

    private T base;

    public PolymorphicPropertyMapBase() {
    }

    public PolymorphicPropertyMapBase(T base) {
        this.base = base;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public T getBase() {
        return base;
    }

    public void setBase(T base) {
        this.base = base;
    }
}
