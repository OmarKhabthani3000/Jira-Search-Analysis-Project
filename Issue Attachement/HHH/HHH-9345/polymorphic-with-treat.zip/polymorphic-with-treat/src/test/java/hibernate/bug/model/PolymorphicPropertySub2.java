package hibernate.bug.model;

import javax.persistence.AssociationOverride;
import javax.persistence.AssociationOverrides;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;

@Entity
@AssociationOverrides({
    @AssociationOverride(name = "base", joinColumns = @JoinColumn(name = "base_sub_2"))
})
public class PolymorphicPropertySub2 extends PolymorphicPropertyMapBase<PolymorphicSub2> {
    private static final long serialVersionUID = 1L;

    public PolymorphicPropertySub2() {
    }

    public PolymorphicPropertySub2(PolymorphicSub2 base) {
        super(base);
    }
}
