/**
 * $Id$
 */
package com.xxxx.pricing.model;

import java.io.Serializable;
import java.util.Date;


public interface ModelBase extends Serializable {
	public Long getId();
	public Long getVersion();
	public Date getCreated();
	public Date getUpdated();
}
