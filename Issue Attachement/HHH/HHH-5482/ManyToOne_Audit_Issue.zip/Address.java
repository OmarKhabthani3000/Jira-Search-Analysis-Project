/**
 *
 */
package com.xxxxx.pricing.model.impl;

import java.util.List;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;


@Entity(name="Address")
@Table(name = "Address")
@AttributeOverrides(
		{
			@AttributeOverride(name = "id", column = @Column(name = "address_id"))
		}
	)
@Audited
public class Address extends ModelBaseImpl {

	@Column(name = "street_number", nullable = true, length = 10)
	private String streetNumber;

	@Column(name = "street_name", nullable = true, length = 50)
	private String streetName;

	@Column(name = "city", nullable = true, length = 50)
	private String city;

/*
	@OneToMany(fetch = FetchType.LAZY, cascade = { CascadeType.REFRESH }, targetEntity = Person.class)
	@JoinTable(name = "PersonAddress", joinColumns = { @JoinColumn(name = "address_id") }, inverseJoinColumns = { @JoinColumn(name = "person_id") })
	@AuditJoinTable(name="PersonAddress_Audit", inverseJoinColumns= {@JoinColumn(name="person_id")})
	private Set<Person> persons;

	public Set<Person> getPersons() {
		return persons;
	}

	public void setPersons(Set<Person> persons) {
		this.persons = persons;
	}
	*/


	public String getStreetNumber() {
		return streetNumber;
	}

	public void setStreetNumber(String streetNumber) {
		this.streetNumber = streetNumber;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
