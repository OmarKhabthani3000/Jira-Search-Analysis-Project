/**
 *
 */
package com.xxxx.pricing.model.impl;


import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;



@Entity(name="Person")
@Table(name = "Person")
@AttributeOverrides(
		{
			@AttributeOverride(name = "id", column = @Column(name = "person_id"))
		}
	)
@Audited
public class Person extends ModelBaseImpl{

	@Column(name = "first_name", nullable = true, length = 50)
	private String firstName;

	@Column(name = "last_name", nullable = true, length = 50)
	private String lastName;



	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.REFRESH }, targetEntity = Address.class)
	@JoinTable(name = "PersonAddress", joinColumns = { @JoinColumn(name = "person_id") }, inverseJoinColumns = { @JoinColumn(name = "address_id") })
	@AuditJoinTable(name="PersonAddress_Audit", inverseJoinColumns= {@JoinColumn(name="address_id")})
	private Address residentialAddress;


	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Address getResidentialAddress() {
		return residentialAddress;
	}

	public void setResidentialAddress(Address residentialAddress) {
		this.residentialAddress = residentialAddress;
	}




}
