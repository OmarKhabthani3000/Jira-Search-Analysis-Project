package test;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import datasource.Person;

public class TestForeignKeyJoin {

	public static void main(String[] args) throws Exception 
	{
		new TestForeignKeyJoin().startTest();

	}
	
	public void startTest() throws Exception
	{
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		List<Person> persons = session.createCriteria(Person.class)
			.createCriteria("id.family")
			.add(Restrictions.eq("familyName", "whatever"))
			.list();
		System.out.println("SUCCESS");
	}

}
