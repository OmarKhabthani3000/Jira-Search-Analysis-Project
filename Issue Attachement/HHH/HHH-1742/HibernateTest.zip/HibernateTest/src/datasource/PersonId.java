package datasource;

import java.io.Serializable;

public class PersonId implements Serializable
{
	public Family family;
	public String personName;
	
	public PersonId() {}
}
