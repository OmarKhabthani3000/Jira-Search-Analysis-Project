package datasource;

import java.io.Serializable;

public class Family implements Serializable 
{
	public String familyName;
	
	public String familyProperty;
	
	public Family() {}
}
