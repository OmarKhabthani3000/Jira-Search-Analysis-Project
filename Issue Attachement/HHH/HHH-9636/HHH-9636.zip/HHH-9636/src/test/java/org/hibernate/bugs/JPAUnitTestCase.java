package org.hibernate.bugs;

import java.util.Collections;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.LockModeType;
import javax.persistence.Persistence;
import javax.persistence.PessimisticLockScope;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh9636Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		Person person = new Person("John Doe");
		entityManager.persist(person);
		Phone home = new Phone( "123-456-7890" );
		Phone office = new Phone( "098-765-4321" );
		person.getPhones().add( home );
		person.getPhones().add( office );
		entityManager.persist(person);

		entityManager.getTransaction().commit();
		entityManager.close();

		entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		Long id = 1L;
		person = entityManager.find( Person.class, id, LockModeType.PESSIMISTIC_WRITE,
			Collections.singletonMap( "javax.persistence.lock.scope", PessimisticLockScope.EXTENDED));

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
