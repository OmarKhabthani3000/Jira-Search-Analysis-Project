package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * <code>Phone</code> -
 *
 * @author Vlad Mihalcea
 */
@Embeddable
public class Phone {

	@Column
	private String mobile;

	public Phone() {}

	public Phone(String mobile) {
		this.mobile = mobile;
	}
}
