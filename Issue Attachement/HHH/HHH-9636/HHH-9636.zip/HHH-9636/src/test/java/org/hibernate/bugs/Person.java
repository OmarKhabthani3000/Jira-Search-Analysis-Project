package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;

/**
 * <code>Person</code> -
 *
 * @author Vlad Mihalcea
 */
@Entity
public class Person {

	@Id
	@GeneratedValue
	private Long id;

	@Column(name = "`name`")
	private String name;

	@ElementCollection
	@JoinTable(name = "person_phone", joinColumns = @JoinColumn(name = "person_id"))
	private List<Phone> phones = new ArrayList<>();

	public Person() {
	}

	public Person(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public List<Phone> getPhones() {
		return phones;
	}
}