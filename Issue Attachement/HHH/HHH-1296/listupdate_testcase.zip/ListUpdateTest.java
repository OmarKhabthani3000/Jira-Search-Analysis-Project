import junit.framework.TestCase;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.HSQLDialect;
import org.hibernate.dialect.MySQLDialect;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class ListUpdateTest extends TestCase {
    
    AnnotationConfiguration conf;
    SessionFactory sessionFactory;
    TestDAO testDAO = new TestDAO();
    
    public void testListUpdate() {
        
        // create object with list containing 4 elements
        ContainsList object = new ContainsList("Object containing list");
        object.getList().add(new Element("1"));
        object.getList().add(new Element("2"));
        object.getList().add(new Element("3"));
        object.getList().add(new Element("4"));
        
        testDAO.save(object);
        
        assertEquals("list.size", object.getList().size(), 4);
        assertEquals("e2.name", object.getList().get(2).getName(), "3");
        
        // remove second element of list
        object.getList().remove(1);
        
        // try to merge
        testDAO.merge(object);
        
        assertEquals("list.size", object.getList().size(), 3);
        assertEquals("e2.name", object.getList().get(2).getName(), "4");

    }
    
    public void testElementInTwoLists(){
        
        ContainsList firstObject = new ContainsList("First Object with list"); 
        ContainsList secondObject = new ContainsList("Second Object with list");
        Element e = new Element("1");
        
        // add element to first object's list
        firstObject.getList().add(e);
        
        testDAO.save(firstObject);
        
        assertEquals("list.size", firstObject.getList().size(), 1);
        assertEquals("e.name", firstObject.getList().get(0).getName(), "1");

        // add element to second object's list
        secondObject.getList().add(e);
        
        testDAO.save(secondObject);
        
        assertEquals("list.size", secondObject.getList().size(), 1);
        assertEquals("e.name", secondObject.getList().get(0).getName(), "1");

    }

    protected void setUp() throws Exception {

        conf = new AnnotationConfiguration();
        
        // DB properties
        
        // hsqldb
        /*

        conf.setProperty(Environment.DRIVER,"org.hsqldb.jdbcDriver");
        conf.setProperty(Environment.URL,"jdbc:hsqldb:mem:ListUpdateTest");
        conf.setProperty(Environment.USER, "sa");
        conf.setProperty(Environment.DIALECT,HSQLDialect.class.getName());

         */
        
        // mysql
        conf.setProperty(Environment.DRIVER,"com.mysql.jdbc.Driver");
        conf.setProperty(Environment.URL,"jdbc:mysql://localhost/test");
        conf.setProperty(Environment.USER, "root");
        conf.setProperty(Environment.PASS, "passwort");
        conf.setProperty(Environment.DIALECT, MySQLDialect.class.getName());

        conf.setProperty(Environment.SHOW_SQL, "true");
        conf.setProperty(Environment.HBM2DDL_AUTO, "create");
        conf.addAnnotatedClass(ContainsList.class);
        conf.addAnnotatedClass(Element.class);

        sessionFactory = conf.buildSessionFactory();
        
        testDAO.setHibernateTemplate(new HibernateTemplate(sessionFactory));
    }
    
    protected void tearDown(){
        sessionFactory.close();
    }
    
    class TestDAO {
        private HibernateTemplate hibernateTemplate;

        public void save(ContainsList a) {
            hibernateTemplate.save(a);
        }

        public void merge(ContainsList a) {
            hibernateTemplate.merge(a);
        }
        
        public ContainsList get(long id) {
            return (ContainsList) hibernateTemplate.get(ContainsList.class, new Long(id));
        }

        public void setHibernateTemplate (HibernateTemplate hibernateTemplate) {
            this.hibernateTemplate = hibernateTemplate;
        }
    }

}
