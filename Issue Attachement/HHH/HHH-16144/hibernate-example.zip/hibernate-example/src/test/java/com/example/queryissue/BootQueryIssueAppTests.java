package com.example.queryissue;

import static org.assertj.core.api.Assertions.assertThat;

import com.example.queryissue.model.Data;
import com.example.queryissue.model.EntityData;
import com.example.queryissue.model.EntityData.Type;
import com.example.queryissue.model.OrganizationEntity;
import com.example.queryissue.model.TimeWindow;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class BootQueryIssueAppTests {

    @Autowired
    private DataSource dataSource;
    @Autowired
    private OrganizationRepository organizationRepository;
    @Autowired
    private EntityDataRepository entityDataRepository;
    @Autowired
    private PlatformTransactionManager transactionManager;

    @Test
    public void hibernateParsesQueriesAndOperates() {
        assertThat(dataSource).isNotNull();

        OrganizationEntity oe = new OrganizationEntity(null, UUID.randomUUID(), "Organization");

        Data data = new Data();
        data.setDatum("Interesting data");

        Type type = new Type();
        type.setName("Top Secret!");

        Instant asOf = Instant.now();
        EntityData entityData = new EntityData();
        entityData.setData(data);
        entityData.setType(type);
        entityData.setWindow(TimeWindow.of(asOf));

        oe.addData(entityData);
        organizationRepository.save(oe);

        TransactionStatus ts = null;
        try {
            ts = transactionManager.getTransaction(TransactionDefinition.withDefaults());
            List<EntityData> entityDataList =
                    entityDataRepository.findByActiveData("Top Secret!", "Interesting data", asOf);
            assertThat(entityDataList).hasSize(1);
            EntityData fromDb = entityDataList.get(0);
            assertThat(fromDb).usingRecursiveComparison().isEqualTo(entityData);

            EntityData fromDbById = entityDataRepository.findById(fromDb.getId()).orElse(null);
            assertThat(fromDbById).isNotNull();
        } catch (Exception e) {
            if (null != ts && !ts.isCompleted()) {
                transactionManager.rollback(ts);
            }
        }
    }
}
