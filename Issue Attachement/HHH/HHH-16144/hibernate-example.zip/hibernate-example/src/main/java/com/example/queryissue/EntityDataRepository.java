package com.example.queryissue;

import com.example.queryissue.model.EntityData;
import java.time.Instant;
import java.util.List;
import lombok.NonNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 * A JPA repository for {@link EntityData} objects.
 */
public interface EntityDataRepository extends JpaRepository<EntityData, Long>,
        TypedRepository<EntityData,Long> {

    /**
     * Returns all data that are associated with the entity.
     *
     * @param entityId The owning entity's ID
     * @return A List of associated data
     */
    List<EntityData> findByEntity_Id(Long entityId);

    @Query("select e from EntityData e join e.data a where a.id = :id")
    List<EntityData> findByDataId(Long id);

    /**
     * Return all data that are associated with the entity that are of the requested type.
     *
     * @param entityId The owning entity's ID
     * @param type The type of data to find
     * @return A {@link List} of associated data.
     */
    List<EntityData> findByEntity_IdAndType_Name(Long entityId, String type);

    /**
     * Find all EntityData that match the type and are in an active time window.
     *
     * @param type The type of data to search for
     * @param datum The datum value to search for
     * @param asOf The instant as of which the data should be active
     * @return All {@link EntityData}s that have an active matching datum.
     */
    @Query("select eae from EntityData eae join eae.entity e join e.data ea join ea.data as data join ea.type as t "
            + "where t.name = :type "
            + "and ea.window.begin <= :asOf and (ea.window.end is null or ea.window.end > :asOf) "
            + "and lower(regexp_replace(data.datum, '[., ]', '', 'i')) = lower(regexp_replace(:datum, '[., ]', '', 'i'))")
    List<EntityData> findByActiveData(
            @NonNull String type,
            @NonNull String datum,
            @NonNull Instant asOf
    );
}
