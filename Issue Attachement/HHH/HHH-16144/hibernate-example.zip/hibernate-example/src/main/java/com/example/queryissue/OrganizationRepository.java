package com.example.queryissue;

import com.example.queryissue.model.OrganizationEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * A repository for Organizations.
 */
public interface OrganizationRepository extends JpaRepository<OrganizationEntity, Long> {

    /**
     * Look up all OrganizationEntities for a particular name.
     *
     * @param name The organization name
     * @return List of OrganizationEntities
     */
    List<OrganizationEntity> getAllByName(String name);

    /**
     * Look up an organization by ID.
     *
     * @param id The organization ID.
     * @return Optional the corresponding OrganizationEntity
     */
    Optional<OrganizationEntity> findById(Long id);

    /**
     * Return all organizations that match the #name.
     *
     * @param name The name
     * @return A {@link List} of organizations that match the criteria.
     */
    List<OrganizationEntity> findByName(String name);
}
