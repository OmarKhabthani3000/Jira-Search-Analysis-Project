package com.example.queryissue;

import com.example.queryissue.WindowedDataTransferService;
import java.util.List;
import java.util.Optional;

/**
 * A repository that can be used by the {@link WindowedDataTransferService} implementation.
 *
 * @param <T> The type of entity that is returned
 * @param <ID> The type of the ID of the entity that is returned
 */
public interface TypedRepository<T, ID> {

    /**
     * Search by the ID.
     *
     * @param id The ID.
     * @return An optional containing the matching entity or empty.
     */
    Optional<T> findById(ID id);

    /**
     * Search by the data ID.
     *
     * @param id The data ID
     * @return A list of matching entities.
     */
    List<T> findByDataId(Long id);

    /**
     * Search for all entities by their owning entity's ID.
     *
     * @param entityId The owning entity's ID
     * @return A List of associated entities.
     */
    List<T> findByEntity_Id(Long entityId);

    /**
     * Search for all entities by their owning entity's ID and their type name.
     *
     * @param entityId The owning entity's ID
     * @param typeName The type name
     * @return A list of all matching entities.
     */
    List<T> findByEntity_IdAndType_Name(Long entityId, String typeName);

    /**
     * Save the object to the data store.
     *
     * @param entity The entity to save
     * @return The saved entity
     */
    T save(T entity);
}
