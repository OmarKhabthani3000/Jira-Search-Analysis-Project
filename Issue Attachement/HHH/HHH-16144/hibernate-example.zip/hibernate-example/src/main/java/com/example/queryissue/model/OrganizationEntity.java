package com.example.queryissue.model;

import java.util.UUID;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * An organization is any set of users in the Supernova network.
 *
 * <h2>Relationship to RPPS Client</h2>
 *
 * <p>An RPPS client is a subset of Organizations. When an organization wants to
 * use the RPPS (White-Dwarf) functionality a method will be called that will set
 * up the RPPS client and relate it to the client's root Organization entry for
 * Supernova (their instance of this object).  For security to be maintained,
 * the RPPS Client record must have a reference to the Organization's UUID.</p>
 *
 * @author David Wolff
 */
@NoArgsConstructor
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = true)
@jakarta.persistence.Entity
@Table(name = "organization")
public class OrganizationEntity extends Entity {

    private String name;

    /**
     * A constructor with convenience parameters to set the ID, UUID, and name.
     *
     * @param id The organization ID.
     * @param uuid The organization's UUID.  If null the default value will be the field's initialized value
     *             (a random UUID).
     * @param name The organization name.
     */
    @Builder
    public OrganizationEntity(
            Long id,
            UUID uuid,
            String name
    ) {
        this.id = id;
        if (null != uuid) {
            this.uuid = uuid;
        }
        this.name = name;
    }
}
