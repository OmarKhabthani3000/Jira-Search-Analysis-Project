package com.example.queryissue.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * A base class for all entities whether Person or OrganizationEntity.
 */
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@lombok.Data
@EqualsAndHashCode(of = {"uuid"})
@JsonInclude(Include.NON_NULL)
@Table(name = "entity")
@jakarta.persistence.Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Entity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    protected Long id;

    @Version
    protected Long version;

    /**
     * The uuid is used for equivalence and hashCode operations on entities.  As such, it must never be changed once
     * stored in a collection (or persisted).
     */
    @Column(name = "uuid", columnDefinition = "uuid", nullable = false, unique = true)
    protected UUID uuid = UUID.randomUUID();

    @OneToMany(mappedBy = "entity",
            cascade = {CascadeType.ALL})
    @OrderBy("window.begin, window.end desc")
    @Setter(AccessLevel.NONE)
    private List<EntityData> data = new ArrayList<>();

    /**
     * Add data to the entity and update the bidirectional relationship.
     *
     * @param data The {@link Data} to add
     * @return true
     */
    public boolean addData(EntityData data) {
        if (null == data.getEntity() || !data.getEntity().equals(this)) {
            data.setEntity(this);
        }
        return this.data.add(data);
    }

    /**
     * Remove the {@link EntityData} from this entity's data list.
     *
     * @param data The {@link EntityData} to remove.
     * @return Whether the data was removed from the collection.
     */
    public boolean removeData(EntityData data) {
        return this.data.remove(data);
    }

    /**
     * Get an unmodifiable list of data.
     *
     * @return An unmodifiable list of {@link Data} objects.
     */
    public List<EntityData> getData() {
        return Collections.unmodifiableList(data);
    }
}
