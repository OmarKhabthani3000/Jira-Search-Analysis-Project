package com.example.queryissue.model;

/**
 * An interface indicating the implementing object conforms to a {@link TimeWindow} life span.
 */
public interface Windowed {

    /**
     * Get the {@link TimeWindow} of the object.
     *
     * @return A {@link TimeWindow}
     */
    TimeWindow getWindow();

    /**
     * Set the {@link TimeWindow} on the object.
     *
     * @param window A {@link TimeWindow}
     */
    void setWindow(TimeWindow window);
}
