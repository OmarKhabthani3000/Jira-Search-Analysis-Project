package com.example.queryissue.model;

import com.example.queryissue.WindowedDataTransferService.Named;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * A superclass of Type JPA entities.
 */
@NoArgsConstructor
@Data
@ToString(of = {"name"})
@EqualsAndHashCode(of = {"name"})
@MappedSuperclass
public class Type implements Named {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    @Setter(AccessLevel.PACKAGE)
    private Integer id;
    private String name;
}
