package com.example.queryissue.model;

import com.example.queryissue.WindowedDataTransferService.WindowedAndTypedAndOwned;
import java.time.Instant;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Embedded;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MappedSuperclass;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * A superclass of typed and windowed entities owned by an {@link Entity}.
 * See {@link EntityData}.
 * @param <T> The class type of the JPA entity's type
 * @param <D> The class type of the data of T
 */
@Data
@EqualsAndHashCode(exclude = "id")
@MappedSuperclass
public class EntityWindowedData<T,D extends Identifiable<Long>> implements WindowedAndTypedAndOwned<T, D> {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER,
            cascade = {CascadeType.ALL})
    D data;

    @ManyToOne(fetch = FetchType.EAGER, optional = false, cascade = {CascadeType.ALL})
    private T type;

    @ManyToOne(fetch = FetchType.EAGER,
            cascade = {CascadeType.ALL})
    @JoinColumn(name = "entity_id")
    Entity entity;

    @Embedded
    private TimeWindow window = new TimeWindow(Instant.now());

    /**
     * Return the ID of the windowed data.
     * @return the data ID
     */
    public Long getDataId() {
        return data.getId();
    }
}
