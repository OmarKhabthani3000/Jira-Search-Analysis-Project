package com.example.queryissue.model;

/**
 * An interface for objects with an ID.
 * @param <T> the ID type
 */
public interface Identifiable<T> {
    /**
     * Return the ID of the object.
     *
     * @return the object ID
     */
    T getId();
}
