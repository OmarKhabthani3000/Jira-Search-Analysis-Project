package com.example.queryissue;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@Slf4j
@SpringBootApplication
public class BootQueryIssueApp {
    /**
     * Run the Boot Application.
     *
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        log.info("Firing up!!");
        SpringApplication.run(BootQueryIssueApp.class, args);
    }
}
