package com.example.queryissue;

import com.example.queryissue.model.Entity;
import com.example.queryissue.model.Identifiable;
import com.example.queryissue.model.TimeWindow;
import com.example.queryissue.model.Windowed;
import java.util.List;
import java.util.Map;

/**
 * A data transfer service for objects with {@link TimeWindow}.
 * The interface has been designed around the idea that there can only be a single active windowed data
 * for every data type.
 *
 * @param <T> The DTO type
 */
public interface WindowedDataTransferService<T> {

    /**
     * Find current data for the entity.
     *
     * @param entityId The entity to search for.
     * @return A {@link Map} of present data types and the current data associated with that type.
     */
    Map<String, T> findByEntityId(Long entityId);

    /**
     * Find all data for the entity, both historical and current.
     *
     * @param entityId The entity to search for.
     * @return A {@link Map} of present data types and the current data associated with that type.
     */
    Map<String, List<T>> findHistoryByEntityId(Long entityId);

    /**
     * Saves the data to the entity with the given ID.
     *
     * @param ownerId The entity to associate the DTO to
     * @param dto The data to save
     * @return The data which may contain a new ID value.
     */
    T save(Long ownerId, T dto);

    /**
     * Expire the windowed data.
     *
     * @param id The ID of the windowed data to expire
     * @throws IllegalArgumentException If an invalid ID is encountered
     */
    void expire(Long id);

    /**
     * An interface for named types.
     */
    interface Named {

        /**
         * Get the name.
         *
         * @return the name
         */
        String getName();

        /**
         * Set the name.
         *
         * @param name the name
         */
        void setName(String name);
    }

    /**
     * An interface for objects that have types.
     *
     * @param <T> The class type of the Type
     */
    interface Typed<T> {

        /**
         * Get the ID of the object.
         *
         * @return The ID
         */
        Long getId();

        /**
         * Get the type.
         *
         * @return The type
         */
        T getType();

        /**
         * Set the type.
         *
         * @param type The type
         */
        void setType(T type);
    }

    /**
     * An interface for objects that are owned by an {@link Entity}.
     */
    interface Owned {

        /**
         * Set the owner of the object.
         *
         * @param entity The owner
         */
        void setEntity(Entity entity);

        /**
         * Get the owner of the object.
         *
         * @return  entity The owner
         */
        Entity getEntity();
    }

    /**
     * A combination interface.
     *
     * @param <T> The class type of the JPA entity's type
     * @param <D> The class type of the windowed data of T
     */
    interface WindowedAndTypedAndOwned<T,D> extends Windowed, Typed<T>, Owned, Identifiable<Long> {
        /**
         * Return the windowed data.
         *
         * @return the windowed data
         */
        D getData();

        /**
         * Set the value of the windowed data object.
         *
         * @param windowedData the value to set
         */
        void setData(D windowedData);
    }
}
