package com.example.queryissue.model;

import jakarta.persistence.AssociationOverride;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * An entity data JPA entity.
 */
@lombok.Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Table(name = "entity_values")
@jakarta.persistence.Entity
@AssociationOverride(name = "data",
                joinColumns = @JoinColumn(name = "data_id"))
@AttributeOverride(name = "dataId", column = @Column(name = "data_id"))
public class EntityData extends EntityWindowedData<EntityData.Type, Data> {

    /**
     * The type of data.
     */
    @Embeddable
    @jakarta.persistence.Entity
    @Table(name = "data_type")
    public static class Type extends com.example.queryissue.model.Type {
    }
}
