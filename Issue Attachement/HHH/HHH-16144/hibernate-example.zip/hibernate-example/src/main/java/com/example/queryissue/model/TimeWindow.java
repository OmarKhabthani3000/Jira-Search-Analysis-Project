package com.example.queryissue.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Objects;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.util.Assert;

/**
 * Utility to identify a time window with up to microsecond precision.  A time window encompasses the start time
 * (inclusive) through the end time (exclusive).  A <code>null</code> end time indicates that the window has no end.
 * In general the start and end times will not be equal.  In practice there is a special case where a change happens so
 * quickly that the start and end times will be equal, this signifies that the TimeWindow is essentially void and has
 * zero length.
 *
 * <p>This class is embeddable into Hibernate entities.</p>
 */
@Embeddable
@NoArgsConstructor
@Data
public class TimeWindow implements Comparable<TimeWindow> {
    @Column(name = "begin_time")
    @NonNull
    private Instant begin;
    @Column(name = "end_time")
    @Nullable
    private Instant end;

    /**
     * Construct an instance with the given start time and ending at <code>null</code>.
     *
     * @param begin The start date.
     */
    public TimeWindow(@NonNull Instant begin) {
        this.begin = format(begin);
    }

    /**
     * Construct a TimeWindow with the given start time and an end date that is equal to the duration plus one
     * microsecond which means the window encompasses the entire Duration.
     *
     * @param begin The start time.
     * @param duration The duration that the TimeWindow encompasses.
     */
    public TimeWindow(@NonNull Instant begin, @NonNull Duration duration) {
        Assert.isTrue(!duration.isNegative(), "The duration must be either zero or a positive value");
        this.begin = format(begin);
        this.end = this.begin.plus(duration).plus(1L, ChronoUnit.MICROS);
    }

    /**
     * Construct an instance with the given start and end times.
     *
     * @param begin The start time.
     * @param end The end time.
     */
    public TimeWindow(@NonNull Instant begin, @Nullable Instant end) {
        assertStartAndEndAreCoherent(begin, end);
        this.begin = format(begin);
        this.end = format(end);
    }

    /**
     * A static factory method for a {@link TimeWindow} with no end time.
     *
     * @param begin The begin time.
     * @return A {@link TimeWindow} beginning at #begin
     */
    public static TimeWindow of(@NonNull Instant begin) {
        return new TimeWindow(begin, (Instant) null);
    }

    /**
     * A static factory method.
     *
     * @param begin The begin time.
     * @param end The end time (nullable).
     * @return A {@link TimeWindow} of the values.
     */
    public static TimeWindow of(@NonNull Instant begin, @Nullable Instant end) {
        return new TimeWindow(begin, end);
    }

    /**
     * Set the begin property.
     *
     * @param begin An instant
     */
    public void setBegin(@NonNull Instant begin) {
        begin = format(begin);
        assertStartAndEndAreCoherent(begin, end);
        this.begin = begin;
    }

    /**
     * Set the end property.
     *
     * @param end An instant
     */
    public void setEnd(@Nullable Instant end) {
        end = format(end);
        assertStartAndEndAreCoherent(begin, end);
        this.end = end;
    }

    private void assertStartAndEndAreCoherent(Instant start, Instant end) {
        if (null != start && null != end) {
            Assert.isTrue(start.equals(end) || start.isBefore(end),
                    String.format("Start and end times must be coherent.  Invalid Start [%s], End [%s]", start, end));
        }
    }

    /**
     * Test the {@link Instant} to see if it is within this time window.  Specifically, test that the given time
     * is greater than or equal the start time and less than the end time.
     *
     * @param test The time to be checked.
     * @return true if the time is within the window.
     */
    public boolean contains(@NonNull Instant test) {
        assertWindowHasStart();
        return (test.isAfter(begin) || test.equals(begin)) && (null == end || test.isBefore(end));
    }

    /**
     * Check that the time window precedes the given time.
     *
     * @param test The time to be checked.
     * @return true if the end time of the time window is less than or equal to the given time.
     */
    public boolean isBefore(@NonNull Instant test) {
        assertWindowHasStart();
        return end != null && (end.isBefore(test) || end.equals(test));
    }

    /**
     * Check that the time window succeeds the given time.
     *
     * @param test The time to be checked.
     * @return true if the start date of the time window is greater than the given time.
     */
    public boolean isAfter(@NonNull Instant test) {
        assertWindowHasStart();
        return begin.isAfter(test);
    }

    /**
     * The natural sort for time window is in ascending order by begin time.  {@code null} begin times will end up at
     * the top of the sort.
     *
     * @param o The TimeWindow to compare to
     * @return An int
     */
    @Override
    public int compareTo(@NonNull TimeWindow o) {
        int result;
        if (Objects.equals(this.getBegin(), o.getBegin()) && Objects.equals(this.getEnd(), o.getEnd())) {
            // This handles the case for all equality, including nulls
            result = 0;
        } else if (this.getBegin() == null && o.getBegin() != null) {
            result = -1;
        } else if (this.getBegin() != null && o.getBegin() == null) {
            result = 1;
        } else {
            // This cannot produce an NPE because all null scenarios have been covered.
            result = this.getBegin().compareTo(o.getBegin());
        }
        return result;
    }

    private void assertWindowHasStart() {
        if (null == begin) {
            throw new IllegalStateException("A start instant is required");
        }
    }

    private Instant format(Instant instant) {
        if (null == instant) {
            return null;
        }
        return instant.truncatedTo(ChronoUnit.MICROS);
    }
}
