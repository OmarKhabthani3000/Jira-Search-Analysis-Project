package com.example.queryissue;

import com.example.queryissue.model.Data;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * A JPA repository for {@link Data} objects.
 */
public interface DataRepository extends JpaRepository<Data, Long> {
}
