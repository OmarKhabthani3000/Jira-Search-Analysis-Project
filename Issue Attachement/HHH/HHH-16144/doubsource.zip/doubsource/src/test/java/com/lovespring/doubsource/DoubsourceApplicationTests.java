package com.lovespring.doubsource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoubsourceApplicationTests {

	@Test
	void contextLoads() {
	}

}
