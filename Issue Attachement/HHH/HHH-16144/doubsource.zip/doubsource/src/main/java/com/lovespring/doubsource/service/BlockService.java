package com.lovespring.doubsource.service;

import com.lovespring.doubsource.repository.block.BlockAuditNodeLivingRepository;
import org.springframework.stereotype.Service;

@Service
public class BlockService {
    private final BlockAuditNodeLivingRepository blockAuditNodeLivingRepository;

    public BlockService(BlockAuditNodeLivingRepository blockAuditNodeLivingRepository) {
        this.blockAuditNodeLivingRepository = blockAuditNodeLivingRepository;
    }


}
