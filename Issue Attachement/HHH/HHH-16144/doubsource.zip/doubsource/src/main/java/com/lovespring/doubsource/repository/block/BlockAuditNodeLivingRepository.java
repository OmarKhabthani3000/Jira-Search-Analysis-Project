package com.lovespring.doubsource.repository.block;

import com.lovespring.doubsource.domain.block.Block;
import com.lovespring.doubsource.domain.block.BlockAuditNode;
import com.lovespring.doubsource.domain.block.BlockAuditNodeLiving;
import com.lovespring.doubsource.repository.base.AuditNodeLivingRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface BlockAuditNodeLivingRepository extends AuditNodeLivingRepository<Block, BlockAuditNode, BlockAuditNodeLiving> {

}
