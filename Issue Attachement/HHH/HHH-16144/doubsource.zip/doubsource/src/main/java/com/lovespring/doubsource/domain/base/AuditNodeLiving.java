package com.lovespring.doubsource.domain.base;

import jakarta.persistence.MappedSuperclass;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@MappedSuperclass
@Data
public  class AuditNodeLiving<Origin, Node extends  AuditNode<Origin>> extends  ObjectLiving<Node> {

}
