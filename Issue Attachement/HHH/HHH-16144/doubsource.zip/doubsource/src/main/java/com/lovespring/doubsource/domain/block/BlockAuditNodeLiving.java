package com.lovespring.doubsource.domain.block;

import com.lovespring.doubsource.domain.base.AuditNodeLiving;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table
public class BlockAuditNodeLiving extends AuditNodeLiving<Block, BlockAuditNode> {
    @Id
    private Long id;

}
