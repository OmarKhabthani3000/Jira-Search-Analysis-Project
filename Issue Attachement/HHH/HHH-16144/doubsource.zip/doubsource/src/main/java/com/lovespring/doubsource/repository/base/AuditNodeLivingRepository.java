package com.lovespring.doubsource.repository.base;

import com.lovespring.doubsource.domain.base.AuditNode;
import com.lovespring.doubsource.domain.base.AuditNodeLiving;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.List;

@NoRepositoryBean
public interface AuditNodeLivingRepository<Origin, Node extends AuditNode<Origin>,Living extends AuditNodeLiving<Origin,Node>>
    extends JpaRepository<Living,Long>,  JpaSpecificationExecutor<Living>
{
    List<Living> findBySource(Node node);

    List<Living> findBySourceRingIndex(Integer ringIndex);

}
