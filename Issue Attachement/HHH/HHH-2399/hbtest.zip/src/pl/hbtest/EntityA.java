package pl.hbtest;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "entity_a")
public class EntityA {

	private Long id;
	private String something;
	
	public EntityA() {
		
	}
	
	public EntityA(Long id, String something) {
		this.id = id;
		this.something = something;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "entity_a_id")
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	@Column(name = "something")
	@Index(name="idx_something_in_a")
	public String getSomething() {
		return something;
	}
	public void setSomething(String something) {
		this.something = something;
	}
}
