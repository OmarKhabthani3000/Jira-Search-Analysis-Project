package pl.hbtest;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.hibernate.FlushMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Main {

	private SessionFactory factory;
	
	public static void main(String[] args) {
		new Main();			
	}
		
	
	public Main() {
		factory = HibernateTestUtil.getSessionFactory();
//		populateDatabase();
		
//		checkConstructorTime();
//		checkSimpleLoadTime();
//		checkCachedLoadTime();		
//		checkLargeSession();
//		checkCachedLargeSession();
		checkCachedPreparedLargeSession();

//		checkSqlLoadTime();
//		checkSqlLoadTimeLargeSession();
//		checkSqlLoadTimePrepared();
		
	}
	


	private void cleanDatabase() {
		System.out.println("cleaning database...");
		
		Session session = factory.getCurrentSession(); 
		session.beginTransaction();
		
		Query q1 = session.createQuery("delete from " + EntityA.class.getName());
		q1.executeUpdate();		
		Query q2 = session.createQuery("delete from " + EntityB.class.getName());
		q2.executeUpdate();		
		
		session.getTransaction().commit();		

		System.out.println("done");

	}

	private void populateDatabase() {
		System.out.println("populating database with some data...");
		
		Session session = factory.getCurrentSession(); 
		session.beginTransaction();
		
		for (int i = 0; i < 10000; i++) {
			EntityA a = new EntityA();
			a.setSomething("somethingA_" + i);
			session.save(a);
			EntityB b = new EntityB();
			b.setSomething("somethingB_" + i);
			session.save(b);					
		}
		session.getTransaction().commit();
		
		System.out.println("done");
	}
	
	
	private void checkSimpleLoadTime() {		
		Session session = factory.getCurrentSession(); 
		session.beginTransaction();
		
		
		
		for (int i = 0; i < 1000; i++) {
			long start = System.nanoTime();
			
			Query q = session.createQuery("FROM " + EntityA.class.getName() + " WHERE something = :str");
			q.setString("str", "somethingA_500");
			EntityA a = (EntityA) q.uniqueResult();
			if (a == null)
				System.out.println("not found");
			
			double duration = (System.nanoTime() - start) / 1000000.0;
			System.out.println("simpleLoadTime: " + duration + " ms");
		}
		
		session.getTransaction().commit();		
	}
	
	
	private void checkCachedLoadTime() {		
		Session session = factory.getCurrentSession(); 
		session.beginTransaction();
		
		for (int i = 0; i < 1000; i++) {
			long start = System.nanoTime();
			
			Query q = session.createQuery("FROM " + EntityA.class.getName() + " WHERE something = :str");
			q.setCacheable(true);
			q.setString("str", "somethingA_500");
			EntityA a = (EntityA) q.uniqueResult();
			if (a == null)
				System.out.println("not found");
			
			double duration = (System.nanoTime() - start) / 1000000.0;
			System.out.println("cachedLoadTime: " + duration + " ms");
		}
		
		session.getTransaction().commit();		
	}
	
	private void checkConstructorTime() {
		Session session = factory.getCurrentSession(); 
		session.beginTransaction();
		
		for (int i = 0; i < 1000; i++) {
			long start = System.nanoTime();
									
			Query q = session.createQuery(
					"SELECT new pl.hbtest.EntityA(id, something) FROM pl.hbtest.EntityA WHERE something = 'somethingA_500'");
			EntityA a = (EntityA) q.uniqueResult();
			if (a == null)
				System.out.println("not found");
			
			double duration = (System.nanoTime() - start) / 1000000.0;
			System.out.println("constructorLoadTime: " + duration + " ms");
		}
		
		session.getTransaction().commit();
	}	
		
	
	
	private void checkSqlLoadTime() {
		Session session = factory.getCurrentSession(); 
		session.beginTransaction();
		
		for (int i = 0; i < 1000; i++) {
			long start = System.nanoTime();			
			
			try {
				PreparedStatement statement = session.connection().prepareStatement(
						"SELECT a.entity_a_id, a.something FROM entity_a a WHERE a.something = 'somethingA_500'");
				ResultSet result = statement.executeQuery();
				if (!result.next()) 
					System.out.println("not found");
				else {
					EntityA a = new EntityA(result.getLong(1), result.getString(2));
					if (a.getSomething() == null)
						System.out.println("error - column read failed");   
				}								
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			double duration = (System.nanoTime() - start) / 1000000.0;
			System.out.println("sqlLoadTime: " + duration + " ms");
		}
		
		session.getTransaction().commit();
	}
	
	
	private void checkSqlLoadTimeLargeSession() {
		Session session = factory.getCurrentSession(); 
		session.beginTransaction();
	
		Query q = session.createQuery("FROM " + EntityB.class.getName());
		q.setMaxResults(10000);
		List l = q.list();
		System.out.println("number of b items: " + l.size());			
		
		for (int i = 0; i < 1000; i++) {
			long start = System.nanoTime();			
			
			try {
				PreparedStatement statement = session.connection().prepareStatement(
						"SELECT a.entity_a_id, a.something FROM entity_a a WHERE a.something = 'somethingA_500'");
				ResultSet result = statement.executeQuery();
				if (!result.next()) 
					System.out.println("not found");
				else {
					EntityA a = new EntityA(result.getLong(1), result.getString(2));
					if (a.getSomething() == null)
						System.out.println("error - column read failed");   
				}								
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			double duration = (System.nanoTime() - start) / 1000000.0;
			System.out.println("sqlLoadTime: " + duration + " ms");
		}
		
		session.getTransaction().commit();
	}
	
	
	private void checkSqlLoadTimePrepared() {
		Session session = factory.getCurrentSession(); 
		session.beginTransaction();

		PreparedStatement statement = null;
		
		try {
			statement = session.connection().prepareStatement(
					"SELECT a.entity_a_id, a.something FROM entity_a a WHERE a.something = 'somethingA_500'");
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		for (int i = 0; i < 1000; i++) {
			long start = System.nanoTime();			
			
			try {
				ResultSet result = statement.executeQuery();
				if (!result.next()) 
					System.out.println("not found");
				else {
					EntityA a = new EntityA(result.getLong(1), result.getString(2));
					if (a.getSomething() == null)
						System.out.println("error - column read failed");   
				}								
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			double duration = (System.nanoTime() - start) / 1000000.0;
			System.out.println("sqlLoadTimePrepared: " + duration + " ms");
		}
		
		session.getTransaction().commit();		
	}
		
	
	
	private void checkLargeSession() {		
		Session session = factory.getCurrentSession(); 
		session.beginTransaction();
		
		Query q = session.createQuery("FROM " + EntityB.class.getName());
		q.setMaxResults(10000);
		List l = q.list();
		System.out.println("number of b items: " + l.size());		
		
		for (int i = 0; i < 1000; i++) {
			long start = System.nanoTime();
			
			q = session.createQuery("FROM " + EntityA.class.getName() + " WHERE something = :str");
			q.setString("str", "somethingA_500");
			EntityA a = (EntityA) q.uniqueResult();
			if (a == null)
				System.out.println("not found");
			
			double duration = (System.nanoTime() - start) / 1000000.0;
			System.out.println("largeSessionLoadTime: " + duration + " ms");
		}
		
		session.getTransaction().commit();		
	}
	

	private void checkCachedLargeSession() {		
		Session session = factory.getCurrentSession(); 
		session.beginTransaction();
		
		Query q = session.createQuery("FROM " + EntityB.class.getName());
		q.setMaxResults(10000);
		List l = q.list();
		System.out.println("number of b items: " + l.size());		
		
		for (int i = 0; i < 1000; i++) {
			long start = System.nanoTime();
			
			q = session.createQuery("FROM " + EntityA.class.getName() + " WHERE something = :str");
			q.setCacheable(true);
			q.setString("str", "somethingA_500");
			EntityA a = (EntityA) q.uniqueResult();
			if (a == null)
				System.out.println("not found");
			
			double duration = (System.nanoTime() - start) / 1000000.0;
			System.out.println("cachedLargeSessionLoadTime: " + duration + " ms");
		}
		
		session.getTransaction().commit();		
	}


	private void checkCachedPreparedLargeSession() {		
		Session session = factory.getCurrentSession(); 
		session.beginTransaction();
		
		session.setFlushMode(FlushMode.COMMIT);
		Query q = session.createQuery("FROM " + EntityB.class.getName());
		q.setMaxResults(10000);
		List l = q.list();
		System.out.println("number of b items: " + l.size());		
		
		q = session.createQuery("FROM " + EntityA.class.getName() + " WHERE something = :str");
		q.setCacheable(true);
		q.setString("str", "somethingA_500");

		for (int i = 0; i < 10000; i++) {
			long start = System.nanoTime();			
			EntityA a = (EntityA) q.uniqueResult();
			if (a == null)
				System.out.println("not found");
			
			double duration = (System.nanoTime() - start) / 1000000.0;
			System.out.println("cachedPreparedLargeSessionLoadTime: " + duration + " ms");
		}
		
		session.getTransaction().commit();		
	}

	
}
