package pl.hbtest;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HibernateTestUtil {

	public static SessionFactory factory;	
	
	public static SessionFactory getSessionFactory() {
		
		if (factory != null)
			return factory;		
				
		
		try {										
			AnnotationConfiguration cfg = new AnnotationConfiguration();
			cfg.addAnnotatedClass(EntityA.class);
			cfg.addAnnotatedClass(EntityB.class);
			
			Properties properties = new Properties();
			properties.load(ClassLoader.getSystemResourceAsStream("pl/hbtest/test-hibernate.properties"));
			cfg.addProperties(properties);
		    
			factory = cfg.buildSessionFactory();
			return factory;
			
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}	
}
