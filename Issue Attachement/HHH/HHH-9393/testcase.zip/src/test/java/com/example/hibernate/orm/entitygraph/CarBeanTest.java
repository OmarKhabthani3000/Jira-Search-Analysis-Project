/*
 */

package com.example.hibernate.orm.entitygraph;

import java.util.List;
import org.hibernate.Hibernate;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 * The test class of CarBean class.
 *
 * @author Ondřej Fibich <ondrej.fibich@gmail.com>
 */
public class CarBeanTest {
    
    private final CarBean carBean;
    
    public CarBeanTest() {
        this.carBean = new CarBean();
    }

    /**
     * Test of getCars method, of class CarBean.
     */
    @Test
    public void testGetCars() {
        List<Car> cars = carBean.getCars();
        assertNotNull(cars);
        assertFalse(cars.isEmpty());
        assertNotNull(cars.get(0));
        assertTrue("should be initialized using JPA entity graph",
                Hibernate.isInitialized(cars.get(0).getProducer()));
        assertNotNull(cars.get(0).getProducer());
        assertEquals("Skoda", cars.get(0).getProducer().getName());
    }

    /**
     * Test of getCarsWith method, of class CarBean.
     */
    @org.junit.Test
    public void testGetCarsWith() {
        List<Car> cars = carBean.getCarsWith("Skoda");
        assertNotNull(cars);
        assertFalse(cars.isEmpty());
        assertNotNull(cars.get(0));
        assertTrue("should be initialized using JPA entity graph",
                Hibernate.isInitialized(cars.get(0).getProducer()));
        assertNotNull(cars.get(0).getProducer());
        assertEquals("Skoda", cars.get(0).getProducer().getName());
    }
    
}
