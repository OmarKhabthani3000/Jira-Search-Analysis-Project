INSERT INTO PRODUCER (id, name) VALUES (1, 'Skoda');

INSERT INTO CAR (id, type_id) VALUES (1, 1);
INSERT INTO CAR (id, type_id) VALUES (2, 1);

INSERT INTO TRAIN (id, type_id) VALUES (1, 1);
