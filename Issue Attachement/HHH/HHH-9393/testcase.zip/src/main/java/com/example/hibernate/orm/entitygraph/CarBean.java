/*
 */

package com.example.hibernate.orm.entitygraph;

import java.util.List;
import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Ondřej Fibich <ondrej.fibich@gmail.com>
 */
public class CarBean {
    
    public List<Car> getCars() {
        EntityManagerFactory emf = null;
        EntityManager em = null;
        try {
            emf = Persistence.createEntityManagerFactory("test-nd");
            em = emf.createEntityManager();
            // entity graph
            final EntityGraph eg = em.createEntityGraph("carWithProducer");
            // query, THIS PART IS DIFFERENT:
            return em.createQuery("SELECT c FROM Car c")
                    .setHint("javax.persistence.fetchgraph", eg)
                    .getResultList();
        } finally {
            if (em != null) {
                em.close();
            }
            if (emf != null) {
                emf.close();
            }
        }
    }
    
    public List<Car> getCarsWith(String producerName) {
        EntityManagerFactory emf = null;
        EntityManager em = null;
        try {
            emf = Persistence.createEntityManagerFactory("test-nd");
            em = emf.createEntityManager();
            // entity graph
            final EntityGraph eg = em.createEntityGraph("carWithProducer");
            // query, THIS PART IS DIFFERENT:
            return em.createQuery("SELECT c FROM Car c "
                    + "WHERE c.producer.name = :p")
                    .setHint("javax.persistence.fetchgraph", eg)
                    .setParameter("p", producerName)
                    .getResultList();
        } finally {
            if (em != null) {
                em.close();
            }
            if (emf != null) {
                emf.close();
            }
        }
    }
    
}
