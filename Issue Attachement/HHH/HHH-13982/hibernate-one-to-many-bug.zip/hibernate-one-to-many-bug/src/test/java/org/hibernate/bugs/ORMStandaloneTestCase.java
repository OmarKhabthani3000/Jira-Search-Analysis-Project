package org.hibernate.bugs;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.bugs.entities.ChildBase;
import org.hibernate.bugs.entities.FirstChild;
import org.hibernate.bugs.entities.Parent;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * This template demonstrates how to develop a standalone test case for Hibernate ORM.  Although this is perfectly
 * acceptable as a reproducer, usage of ORMUnitTestCase is preferred!
 */
public class ORMStandaloneTestCase {

    private SessionFactory sf;
    private Metadata metadata;

    @Before
    public void setup() {
        StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
                // Add in any settings that are specific to your test. See resources/hibernate.properties for the defaults.
                .applySetting("hibernate.show_sql", "true")
                .applySetting("hibernate.format_sql", "true")
                .applySetting("hibernate.hbm2ddl.auto", "update");

        metadata = new MetadataSources(srb.build())
                // Add your entities here.
                .addAnnotatedClass(Parent.class)
                .addAnnotatedClass(ChildBase.class)
                .addAnnotatedClass(FirstChild.class)
                .buildMetadata();

        sf = metadata.buildSessionFactory();
    }

    // Add your tests, using standard JUnit.

    @Test
    public void metadataTest() throws Exception {
        int numberOfColumns = metadata.getEntityBinding("org.hibernate.bugs.entities.FirstChild").getTable().getColumnSpan();
        //Generated table must have only two columns: uuid and firstChildField.
        //But it ends up also having parent_uuid, which hibernate then uses,
        //ignoring correct column in ChildBase table
        assertEquals(2, numberOfColumns);
    }

}
