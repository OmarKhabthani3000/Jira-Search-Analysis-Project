package org.hibernate.bugs;

import org.hibernate.bugs.entities.FirstChild;
import org.hibernate.bugs.entities.Parent;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import static org.junit.Assert.assertEquals;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    public void createAndLoadTest() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        Parent parent = createParent(entityManager);
        entityManager.clear();

        entityManager.getTransaction().begin();

        //Check that we are able to read our saved data
        Parent persisted = entityManager.find(Parent.class, parent.getUuid());
        assertEquals(1, persisted.getFirstChildren().size());

        entityManager.getTransaction().commit();

        entityManager.close();
    }

    private Parent createParent(EntityManager entityManager) {
        entityManager.getTransaction().begin();

        Parent parent = new Parent();
        entityManager.persist(parent);

        FirstChild child = new FirstChild();
        child.setParent(parent);
        entityManager.persist(child);

        entityManager.getTransaction().commit();
        return parent;
    }

}
