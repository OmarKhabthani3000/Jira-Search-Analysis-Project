package org.hibernate.bugs.entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(ChildBase.DISCRIMINATOR_FIRST)
public class FirstChild extends ChildBase {

    private String firstChildField;

    public String getFirstChildField() {
        return firstChildField;
    }

    public void setFirstChildField(String firstChildField) {
        this.firstChildField = firstChildField;
    }

}
