package org.hibernate.bugs.entities;


import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.Set;

@Entity
public class Parent {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String uuid;
    @OneToMany(mappedBy = "parent")
    private Set<FirstChild> firstChildren;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public Set<FirstChild> getFirstChildren() {
        return firstChildren;
    }

    public void setFirstChildren(Set<FirstChild> firstChildren) {
        this.firstChildren = firstChildren;
    }

}
