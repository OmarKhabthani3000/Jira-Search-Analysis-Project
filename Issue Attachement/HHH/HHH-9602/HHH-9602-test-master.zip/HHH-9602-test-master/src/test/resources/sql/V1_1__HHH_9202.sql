DROP MATERIALIZED VIEW IF EXISTS base_entities_mvw;
CREATE MATERIALIZED VIEW base_entities_mvw
AS
  SELECT
    '1' :: TEXT    AS id,
    'test' :: TEXT AS name;

DROP VIEW IF EXISTS base_entities_vw;
CREATE VIEW base_entities_vw
AS
  SELECT
    '1' :: TEXT    AS id,
    'test' :: TEXT AS name;

DROP TABLE IF EXISTS base_entities;
CREATE TABLE base_entities (
  id   TEXT PRIMARY KEY,
  name TEXT
);

INSERT INTO base_entities (id, name) VALUES (1, 'test');