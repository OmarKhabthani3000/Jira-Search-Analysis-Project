package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by dionis on 06/02/15.
 */
@Entity
@Table(name = "base_entities")
public class TableBasedEntity {
    @Id
    @Column(name = "id")
    String id;
    @Column(name = "name")
    String name;
}
