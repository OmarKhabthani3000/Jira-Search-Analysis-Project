import com.googlecode.flyway.core.Flyway;
import entity.MaterializedViewBasedEntity;
import entity.TableBasedEntity;
import entity.ViewBasedEntity;
import org.apache.commons.dbcp.BasicDataSource;
import org.hibernate.cfg.Configuration;
import org.hibernate.dialect.PostgreSQL9Dialect;
import org.hibernate.tool.hbm2ddl.SchemaValidator;
import org.junit.*;
import org.postgresql.Driver;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by dionis on 06/02/15.
 */
public class HHH_9602_Test {

    private static BasicDataSource dataSource;

    @BeforeClass
    public static void setUpClass() throws Exception {
        dataSource = new BasicDataSource();
        dataSource.setUrl("jdbc:postgresql://localhost:5432/test_gisdb");
        dataSource.setUsername("gis");
        dataSource.setPassword("password");
        dataSource.setDriverClassName(Driver.class.getName());
        Flyway flyway = new Flyway();
        flyway.setInitOnMigrate(true);
        flyway.setTable("hhh_9602_tests_schema_version");
        flyway.setValidateOnMigrate(true);
        flyway.setLocations("sql");
        flyway.setDataSource(dataSource);
        flyway.migrate();
        flyway.validate();
    }

    @Before
    public void setUp() throws Exception {
        checkSchemas();
    }

    @Test
    public void validationShouldNotFailForMaterializedView() throws Exception {
        Configuration cfg = getBaseConfiguration();
        cfg.addAnnotatedClass(MaterializedViewBasedEntity.class);

        new SchemaValidator(cfg).validate();
    }

    @Test
    public void validationShouldNotFailForView() throws Exception {
        Configuration cfg = getBaseConfiguration();

        cfg.addAnnotatedClass(ViewBasedEntity.class);
        new SchemaValidator(cfg).validate();

    }

    @Test
    public void validationShouldNotFailForTables() throws Exception {
        Configuration cfg = getBaseConfiguration();

        cfg.addAnnotatedClass(TableBasedEntity.class);
        new SchemaValidator(cfg).validate();

    }

    @AfterClass
    public static void tearDown() throws Exception {
        executeStatement("DROP MATERIALIZED VIEW IF EXISTS base_entities_mvw");
        executeStatement("DROP VIEW IF EXISTS base_entities_vw");
        executeStatement("DROP VIEW IF EXISTS base_entities");
        executeStatement("DROP TABLE IF EXISTS hhh_9602_tests_schema_version");

        dataSource.close();
    }

    private Configuration getBaseConfiguration() {
        Configuration cfg = new Configuration();

        cfg.setProperty("hibernate.connection.url", dataSource.getUrl());
        cfg.setProperty("hibernate.connection.username", dataSource.getUsername());
        cfg.setProperty("hibernate.connection.password", dataSource.getPassword());
        cfg.setProperty("hibernate.connection.driver_class", dataSource.getDriverClassName());
        cfg.setProperty("hibernate.connection.autocommit", String.valueOf(dataSource.getDefaultAutoCommit()));

        cfg.setProperty("hibernate.dialect", PostgreSQL9Dialect.class.getName());
        cfg.setProperty("hibernate.hbm2ddl.auto", "validate");
        return cfg;
    }

    private void checkSchemas() throws SQLException {
        Connection connection = getConnection();
        try {
            Assert.assertTrue("Table does not exists", checkMaterializedViewOrViewExists("SELECT * FROM base_entities", connection));
            Assert.assertTrue("View does not exists", checkMaterializedViewOrViewExists("SELECT * FROM base_entities_vw", connection));
            Assert.assertTrue("Materialized view does not exists", checkMaterializedViewOrViewExists("SELECT * FROM base_entities_mvw", connection));
        } finally {
            connection.close();
        }
    }

    private boolean checkMaterializedViewOrViewExists(String sql, Connection connection) throws SQLException {
        ResultSet rs = connection.prepareStatement(sql).executeQuery();
        boolean hasResult = false;
        try {
            while (rs.next()) {
                hasResult = true;
                String id = rs.getString("id");
                Assert.assertEquals("1", id);
                String name = rs.getString("name");
                Assert.assertEquals("test", name);
            }
        } finally {
            rs.close();
        }
        return hasResult;
    }

    private static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    private static void executeStatement(String statement) {
        Connection connection = null;
        try {
            connection = getConnection();
            connection.prepareStatement(statement).executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception ignore) {
                }
            }
        }
    }

}
