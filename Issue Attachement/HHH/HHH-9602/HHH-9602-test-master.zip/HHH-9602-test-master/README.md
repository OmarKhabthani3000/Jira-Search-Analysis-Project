# HHH-9602-test
Test case for reproducing bug HHH-9602.

Prerequisites:

    PostgreSQL 9.3+
    JDK 1.7+

In order to run it locally you need to perform some modifications:

In class HHH_9602_Test.java modify following lines:

    dataSource.setUrl("jdbc:postgresql://localhost:5432/test_gisdb");
    dataSource.setUsername("gis");
    dataSource.setPassword("password");

Set appropariate JDBC url/username/password.

Run tests:

        ./gradlew clean test
    
Result:

      One failed test:
        HHH_9602_Test > validationShouldNotFailForMaterializedView FAILED
Expected:

        All tests passed.
  
In order to run it in IntelliJ:

        ./gradlew cleanIdea idea

In order to run it in Eclipse:

        ./gradlew cleanEclipse eclipse
