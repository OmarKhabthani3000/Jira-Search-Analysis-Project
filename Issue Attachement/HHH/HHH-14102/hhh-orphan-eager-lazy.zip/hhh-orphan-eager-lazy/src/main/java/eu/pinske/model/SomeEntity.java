package eu.pinske.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class SomeEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@OneToMany(mappedBy = "someEntity", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<TestEntity> otherChildren;

	@OneToMany(mappedBy = "someEntity", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<TestEntity> listChildren;

	public Long getId() {
		return id;
	}

	public Set<TestEntity> getOtherChildren() {
		if (otherChildren == null) {
			otherChildren = new HashSet<>();
		}
		return otherChildren;
	}

	public List<TestEntity> getListChildren() {
		if (listChildren == null) {
			listChildren = new ArrayList<>();
		}
		return listChildren;
	}

}
