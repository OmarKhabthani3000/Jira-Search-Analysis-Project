package eu.pinske.test;

import static org.junit.Assert.assertEquals;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;

import org.junit.Test;

import eu.pinske.model.SomeEntity;
import eu.pinske.model.SomeEntity_;
import eu.pinske.model.TestEntity;

public class ThingTest {

	@Test
	public void testHHH14102() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");

		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		SomeEntity se = new SomeEntity();
		em.persist(se);
		em.flush();
		em.getTransaction().commit();
		em.clear();
		em.close();

		em = emf.createEntityManager();
		em.getTransaction().begin();

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<SomeEntity> q = cb.createQuery(SomeEntity.class);
		Root<SomeEntity> from = q.from(SomeEntity.class);
		from.fetch(SomeEntity_.listChildren, JoinType.LEFT);
		q.where(cb.equal(from.get(SomeEntity_.id), se.getId()));
		SomeEntity singleResult = em.createQuery(q).getSingleResult();

		TestEntity c1 = new TestEntity();
		c1.setSomeEntity(singleResult);
		TestEntity c2 = new TestEntity();
		c2.setSomeEntity(singleResult);
		TestEntity c3 = new TestEntity();
		c3.setSomeEntity(singleResult);

		em.persist(c1);
		em.persist(c2);
		em.persist(c3);

		singleResult.getListChildren().add(c1);
		singleResult.getListChildren().add(c2);
		singleResult.getListChildren().add(c3);

		Set<TestEntity> toRemove = new HashSet<>();
		for (TestEntity child : singleResult.getListChildren()) {
			toRemove.add(child);
			break;
		}
		singleResult.getListChildren().removeAll(toRemove);
		// assertEquals(2, singleResult.getListChildren().size());
		em.flush();
		em.getTransaction().commit();
		em.clear();

		em.getTransaction().begin();
		singleResult = em.find(SomeEntity.class, singleResult.getId());
		assertEquals(2, singleResult.getListChildren().size());
		emf.close();
	}

	@Test
	public void testHHH14102_1() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");

		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		SomeEntity se = new SomeEntity();
		em.persist(se);
		em.flush();
		em.getTransaction().commit();
		em.clear();
		em.close();

		em = emf.createEntityManager();
		em.getTransaction().begin();

		SomeEntity singleResult = em.find(SomeEntity.class, se.getId());

		TestEntity c1 = new TestEntity();
		c1.setSomeEntity(singleResult);
		TestEntity c2 = new TestEntity();
		c2.setSomeEntity(singleResult);
		TestEntity c3 = new TestEntity();
		c3.setSomeEntity(singleResult);

		em.persist(c1);
		em.persist(c2);
		em.persist(c3);

		singleResult.getListChildren().add(c1);
		singleResult.getListChildren().add(c2);
		singleResult.getListChildren().add(c3);

		Set<TestEntity> toRemove = new HashSet<>();
		for (TestEntity child : singleResult.getListChildren()) {
			toRemove.add(child);
			break;
		}
		singleResult.getListChildren().removeAll(toRemove);
		// assertEquals(2, singleResult.getListChildren().size());
		em.flush();
		em.getTransaction().commit();
		em.clear();

		em.getTransaction().begin();
		singleResult = em.find(SomeEntity.class, singleResult.getId());
		assertEquals(2, singleResult.getListChildren().size());
		emf.close();
	}

}
