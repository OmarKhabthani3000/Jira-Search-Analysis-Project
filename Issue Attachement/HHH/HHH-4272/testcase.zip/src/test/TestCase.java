package test;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static junit.framework.Assert.*;

public class TestCase {

    Session session;
    Logger logger = LoggerFactory.getLogger(getClass());
    

    @Before
    public void setUp() throws Exception {
        SessionFactory sessionFactory;
        try {
            Configuration config = new AnnotationConfiguration().configure("hibernate-test.cfg.xml");
            sessionFactory = config.buildSessionFactory();
            session = sessionFactory.getCurrentSession();
            session.beginTransaction();
        } catch (Throwable ex) {
            logger.error("Error in initializer.", ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    @After
    public void tearDown() {
        session.getTransaction().rollback();
    }

    @Test
    public void test() {
        TestObject o = new TestObject();
        session.save(o);
        assertNotNull(o.getId());
        session.flush();
        session.clear();
        o = (TestObject) session.load(TestObject.class, o.getId());
        assertNotNull(o.getId2());
        assertNotNull(o.getA());
    }
}
