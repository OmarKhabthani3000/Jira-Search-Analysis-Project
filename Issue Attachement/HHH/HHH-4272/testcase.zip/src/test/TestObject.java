package test;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.Formula;

@Entity
public class TestObject {

    @GeneratedValue(strategy=GenerationType.AUTO)
    @Id private Long id;

    @Formula(" id ")
    private Long id2;

    @Formula(" 'A' ")
    private String a;

    public Long getId() {
        return id;
    }

    public Long getId2() {
        return id2;
    }

    public String getA() {
        return a;
    }

}
