package jboss;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.classic.Session;

public class Sample {
	private static Logger logger = Logger.getLogger(Sample.class);
	
	public static void main(String[] args) {
		SessionFactory buildSessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
		Session session = buildSessionFactory.openSession();
		session.beginTransaction();
		Customer customer = new Customer();
		Table table = new Table();
		customer.setTable(table);
		session.save(customer);
		session.save(table);
		session.getTransaction().commit();
		session.close();
		
		session = buildSessionFactory.openSession();
		session.beginTransaction();
		
		Person person = new  Person();
		person.setName("Erik-Berndt");
		table.setPerson(person);
		person.setTable(table);
		session.save(person);
		session.update(table);
		
		logger.debug("before criteria");
		session.createCriteria(Customer.class).list();
		logger.debug("after criteria (we did not get the flush)");
		session.getTransaction().commit();
		
		session.close();
		
		
		
	}
	
	
}
