package test;


public class NaturalIdResolutionCacheNPEEntity {

  private long id;
  private String naturalId1;
  private String naturalId2;
  private String someotherproperty;
  
  public long getId() {
    return id;
  }
  
  public void setId(long id) {
    this.id = id;
  }
  
  public String getNaturalId1() {
    return naturalId1;
  }
  
  public void setNaturalId1(String naturalId1) {
    this.naturalId1 = naturalId1;
  }
  
  public String getNaturalId2() {
    return naturalId2;
  }
  
  public void setNaturalId2(String naturalId2) {
    this.naturalId2 = naturalId2;
  }
  
  public String getSomeotherproperty() {
    return someotherproperty;
  }
  
  public void setSomeotherproperty(String someotherproperty) {
    this.someotherproperty = someotherproperty;
  }
  

}
