package test;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class NaturalIdResolutionCacheNPETest extends TestCase {
  
  public void testNaturalIdResolutionCacheNPE() {
    Session s = NaturalIdResolutionCacheNPETestSetup.openSession();
    Transaction t = s.beginTransaction();

    NaturalIdResolutionCacheNPEEntity entity = new NaturalIdResolutionCacheNPEEntity();
    entity.setNaturalId1("a");
    entity.setNaturalId2("b");
    entity.setSomeotherproperty("c");
    
    s.save(entity);

    t.commit();
    s.close();
  }
  
  public static Test suite() {
    return new NaturalIdResolutionCacheNPETestSetup(new TestSuite(NaturalIdResolutionCacheNPETest.class));
  }

}
