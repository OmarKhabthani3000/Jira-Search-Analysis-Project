package test;

import junit.extensions.TestSetup;
import junit.framework.Test;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

public class NaturalIdResolutionCacheNPETestSetup extends TestSetup {
  
  public NaturalIdResolutionCacheNPETestSetup(Test test) {
    super(test);
  }
  
  private static SessionFactory sessionFactory;
  
  public static Session openSession() throws HibernateException {
    return sessionFactory.openSession();
  }
  
  @Override
  protected void setUp() throws Exception {
    Configuration cfg = new Configuration();
    cfg.setProperty(Environment.HBM2DDL_AUTO, "create");
    cfg.setProperty(Environment.SHOW_SQL, "true");
    cfg.setProperty(Environment.FORMAT_SQL, "true");
    cfg.addResource("test/naturalidresolutioncachenpe.hbm.xml", NaturalIdResolutionCacheNPETestSetup.class.getClassLoader());
    cfg.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
    cfg.setProperty("hibernate.connection.username", "sa");
    cfg.setProperty("hibernate.connection.password", "");
    cfg.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:testdb");
    cfg.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
    sessionFactory = cfg.buildSessionFactory();
  }
  
  @Override
  protected void tearDown() throws Exception {
    final Session s = openSession();
    s.createSQLQuery("SHUTDOWN").executeUpdate();
    s.close();
    sessionFactory.close();
  }

}
