package hibernate.bug.model;

public class B {

    private A a;

    public B(A a) {
        this.a = a;
    }
    
    public A getA() {
        return a;
    }

}
