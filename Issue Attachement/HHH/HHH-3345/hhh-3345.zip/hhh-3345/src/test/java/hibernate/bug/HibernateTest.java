package hibernate.bug;

import hibernate.bug.model.A;
import hibernate.bug.model.B;
import hibernate.bug.model.C;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.hibernate.usertype.DynamicParameterizedType.ParameterType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        A a = new A();
        C c = new C("d");
        em.persist(a);
        em.persist(c);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        
        List<B> l = em.createQuery(
                "SELECT NEW hibernate.bug.model.B(a) FROM A a LEFT JOIN FETCH a.c")
                .getResultList();
        em.close();
        
        Assert.assertEquals(1, l.size());
        Assert.assertEquals("d", l.get(0).getA().getC().getD());
    }
}
