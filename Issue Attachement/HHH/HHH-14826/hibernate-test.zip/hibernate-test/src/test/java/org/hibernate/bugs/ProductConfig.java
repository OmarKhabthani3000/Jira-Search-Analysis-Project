package org.hibernate.bugs;

import javax.persistence.*;

@Entity
@Cacheable
public class ProductConfig {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRODUCT_CONFIG_SEQ")
    @SequenceGenerator(name = "PRODUCT_CONFIG_SEQ", sequenceName = "PRODUCT_CONFIG_SEQ", allocationSize = 1)
    private Long id;

    @Version
    private Integer version;

    @Column(unique = true, nullable = false)
    private String name;

    @OneToOne(fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    private Product product;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
}
