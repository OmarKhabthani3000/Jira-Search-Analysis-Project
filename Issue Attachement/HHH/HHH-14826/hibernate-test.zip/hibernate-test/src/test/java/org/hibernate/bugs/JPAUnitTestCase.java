package org.hibernate.bugs;

import javax.persistence.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cache.internal.EnabledCaching;
import org.hibernate.jpa.QueryHints;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	private void doInJPA(Consumer<EntityManager> task) {
		EntityManager em = entityManagerFactory.createEntityManager();
		EntityTransaction txn = em.getTransaction();
		txn.begin();
		try {
			task.accept(em);
			if (txn.getRollbackOnly()) {
				txn.rollback();
			} else {
				txn.commit();
			}
		} catch (Throwable t) {
			if (txn.isActive()) {
				txn.rollback();
			}
			throw t;
		} finally {
			em.close();
		}
	}

	@Test
	public void hhh14826Test() throws Exception {
		final AtomicLong pid = new AtomicLong();

		// create Product
		doInJPA(em -> {
			Product product = new Product();
			product.setName("Some Product");
			em.persist(product);
			pid.set(product.getId());
		});

		// create config and associate with a product
		doInJPA(em -> {
			Product product = em.find(Product.class, pid.get());
			ProductConfig config = new ProductConfig();
			config.setName("Some Config");
			config.setProduct(product);
			em.persist(config);
		});

		// now fetch the product again
		doInJPA(em -> {
			Product product = em.find(Product.class, pid.get());
			// this should not fail
			Assert.assertNotNull(product.getConfig());
		});
	}
}