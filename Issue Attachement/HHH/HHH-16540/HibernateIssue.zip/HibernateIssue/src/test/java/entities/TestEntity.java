package entities;

import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class TestEntity {

	private ScaledImagesMap images = new ScaledImagesMap();
	private int id;

	@Embedded
	public ScaledImagesMap getImages() {
		return images;
	}
	public void setImages(ScaledImagesMap images) {
		this.images = images;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Id
	public int getId() {
		return id;
	}
}
