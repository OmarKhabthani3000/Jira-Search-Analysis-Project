package entities;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Basic;
import jakarta.persistence.Embeddable;

@Embeddable
@Access( AccessType.FIELD )
public class ImageKey {

	public ImageKey() {

	}
	public ImageKey(int imageKey) {
		this.imageKey = imageKey;
	}
	public int getImageKey() {
		return imageKey;
	}
	public void setImageKey(int imageKey) {
		this.imageKey = imageKey;
	}
	@Basic
	private int imageKey;


}
