package entities;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Basic;
import jakarta.persistence.Embeddable;
import jakarta.persistence.MappedSuperclass;

@Embeddable
@MappedSuperclass
@Access( AccessType.PROPERTY )
public class ImageFile {

	public ImageFile() {
		this.fileName = fileName;
	}

	public ImageFile(String fileName) {
		this.fileName = fileName;
	}
	@Basic
	private String fileName;

	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
}
