package org.hibernate.test;

import entities.ScaledImagesMap;
import entities.TestEntity;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.MapJoin;
import java.util.HashMap;
import entities.ImageFile;
import entities.ImageKey;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class HibernateBugTest {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void handleQueryResult() {
		var entityManager = entityManagerFactory.createEntityManager();

		entityManager.getTransaction().begin();

		var testEntity = new TestEntity();

		var scaledImagesMap = new ScaledImagesMap();
		var imageMap = new HashMap<ImageKey,ImageFile>();
		var imageKey = new ImageKey(1);
		var imageFile= new ImageFile("testImage");
		imageMap.put(imageKey, imageFile);
		scaledImagesMap.setScaledImages( imageMap );

		testEntity.setId( 1 );
		testEntity.setImages( scaledImagesMap );
		entityManager.persist( testEntity );

		entityManager.getTransaction().commit();

		var cb = entityManager.getCriteriaBuilder();
		final var cq = cb.createQuery( ImageFile.class );

		final var root = cq.from( TestEntity.class );

		final MapJoin<Object,Object,ImageFile> selection = root.join( "images" ).joinMap( "scaledImages" );

		cq.select( selection );

		var query = entityManager.createQuery( cq );
		assertNotNull(query.setMaxResults( 1 ).getSingleResult());

		entityManager.close();
	}
}
