package entities;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embeddable;
import jakarta.persistence.FetchType;
import java.util.HashMap;
import java.util.Map;

@Embeddable
@Access( AccessType.PROPERTY )
public class ScaledImagesMap {

	private Map<ImageKey,ImageFile> scaledImages;

	@ElementCollection( fetch = FetchType.LAZY )
	public Map<ImageKey,ImageFile> getScaledImages() {
		if( scaledImages == null ){
			scaledImages = new HashMap<ImageKey,ImageFile>();
		}

		return scaledImages;
	}
	public void setScaledImages(Map<ImageKey,ImageFile> scaledImages) {
		this.scaledImages = scaledImages;
	}
}
