package org.hibernate;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.Predicate;
import org.hibernate.entities.example.ExampleEmbedded;
import org.hibernate.entities.example.ExampleEmbedded_;
import org.hibernate.entities.example.ExampleEntity;
import org.hibernate.entities.example.ExampleEntity_;
import org.hibernate.entities.example.User;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class RunHibernateTest {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void handleQueryResult() {
		var entityManager = entityManagerFactory.createEntityManager();

		entityManager.getTransaction().begin();

		var testEntity = new ExampleEntity();
		var testEmbedded = new ExampleEmbedded<>();
		var user = new User();
		user.setName( "testUser" );
		user.setCompany( "testCompany" );

		entityManager.persist( user );

		testEmbedded.setUser( user );

		testEntity.setExampleEmbedded( testEmbedded );

		entityManager.persist( testEntity );

		entityManager.getTransaction().commit();

		var cb = entityManager.getCriteriaBuilder();

		var cq = cb.createQuery( ExampleEntity.class );
		var root = cq.from( ExampleEntity.class );

		cq.select( root );

		Predicate conjunction;

		var join = root.join( ExampleEntity_.exampleEmbedded );
		conjunction = cb.and(
				cb.equal( root.get( ExampleEntity_.id ), testEntity.getId() ),
				cb.equal( join.get( ExampleEmbedded_.user ), user ) );
		cq.where( conjunction );
		var query = entityManager.createQuery( cq );
		assertNotNull( query.setMaxResults( 1 ).getSingleResult() );

		entityManager.close();
	}

}
