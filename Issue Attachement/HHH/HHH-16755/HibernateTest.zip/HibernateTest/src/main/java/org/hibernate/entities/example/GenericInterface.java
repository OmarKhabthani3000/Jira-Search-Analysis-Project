package org.hibernate.entities.example;


public interface GenericInterface<TGeneric extends GenericInterface<TGeneric>>  {

}