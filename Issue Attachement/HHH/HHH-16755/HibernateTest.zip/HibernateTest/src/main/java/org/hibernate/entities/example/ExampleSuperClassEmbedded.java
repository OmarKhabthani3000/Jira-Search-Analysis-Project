package org.hibernate.entities.example;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.FetchType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MappedSuperclass;
import java.util.Objects;

@MappedSuperclass
@Access( AccessType.PROPERTY )
public class ExampleSuperClassEmbedded<TGeneric extends GenericInterface<TGeneric>> {

	private User user;

	@ManyToOne( fetch = FetchType.LAZY )
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public boolean equals(Object obj) {
		return this == obj
				|| obj instanceof ExampleSuperClassEmbedded<?> other
				&& Objects.equals( user, other.user );
	}

}
