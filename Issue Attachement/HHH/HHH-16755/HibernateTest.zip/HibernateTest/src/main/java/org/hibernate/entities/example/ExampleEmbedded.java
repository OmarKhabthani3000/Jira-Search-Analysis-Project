package org.hibernate.entities.example;

import jakarta.persistence.Embeddable;

@Embeddable
public class ExampleEmbedded<TGeneric extends GenericInterface<TGeneric>> extends ExampleSuperClassEmbedded<TGeneric> {

}