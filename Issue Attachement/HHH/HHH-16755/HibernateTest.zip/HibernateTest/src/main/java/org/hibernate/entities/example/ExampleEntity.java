package org.hibernate.entities.example;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ExampleEntity {

	private int id;
	private ExampleEmbedded<?> exampleEmbedded;

	public void setId(int id) {
		this.id = id;
	}

	@Id
	@GeneratedValue( strategy = GenerationType.AUTO )
	public int getId() {
		return id;
	}

	public ExampleEmbedded<?> getExampleEmbedded() {
		return exampleEmbedded;
	}
	public void setExampleEmbedded(ExampleEmbedded<?> exampleEmbedded) {
		this.exampleEmbedded = exampleEmbedded;
	}
}
