/*
 * (c) Copyright 2004 BODET S.A. 
 * All Rights Reserved. 
 * 
 * $Log: $ 
 */ 
package test;


public class Address
{
    private String location;
    private City city;
    
    public City getCity()
    {
        return city;
    }
    public void setCity(City city)
    {
        this.city = city;
    }
    
    public String getLocation()
    {
        return location;
    }
    
    public void setLocation(String location)
    {
        this.location = location;
    }
}
