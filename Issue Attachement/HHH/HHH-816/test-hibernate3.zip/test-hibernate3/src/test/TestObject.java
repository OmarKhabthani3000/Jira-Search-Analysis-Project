package test;

import java.util.ArrayList;
import java.util.List;

public class TestObject
{
    private Integer id;
    private String name;
    private List myBag;

    public Integer getId()
    {
        return id;
    }
    public void setId(Integer id)
    {
        this.id = id;
    }
    public List getMyBag()
    {
        if (myBag == null)
        {
            myBag = new ArrayList();
        }
        return myBag;
    }
    public void setMyBag(List myBag)
    {
        this.myBag = myBag;
    }
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
}
