import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/*
 * (c) Copyright 2004 BODET S.A. 
 * All Rights Reserved. 
 * 
 * $Log: $ 
 */

/** 
 * TODO Commentaire de la classe 
 *
 * Date de cr�ation : 25 f�vr. 2005 
 * Derni�re modif : $Date:$ par $Author:$ 
 * @author cesbrons 
 * @version $Revision: $ 
 */
public class TestHibernate
{
    public static void main(String[] args)
    {
        try
        {
            Configuration cfg = new Configuration();
            cfg.configure();
            SessionFactory sessionFactory = cfg.buildSessionFactory();
            Session session = sessionFactory.openSession();
            Transaction tx = session.beginTransaction();
            session.createQuery("from Person p where p.address.city.id is null").list();
            tx.commit();
            session.close();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
