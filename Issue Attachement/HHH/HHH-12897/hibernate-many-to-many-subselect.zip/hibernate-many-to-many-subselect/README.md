# Example to illustrate Hibernate Subselect fetching problems with EntityGraphs

Illustrate the problems from https://hibernate.atlassian.net/browse/HHH-12897

# Setup

Setup your DB of choice using the supplied SQL script. Modify
PersistenceJPAConfig#datasource() to point to your DB.

If you need a local Postgres, I suggest

    mkdir -p $HOME/docker/volumes/postgres
    docker run --rm --name test_postgres -e POSTGRES_PASSWORD=docker -d -v $HOME/docker/volumes/postgres:/var/lib/postgresql/data -p 5432:5432 postgres:12.2

# Running

If you run the main class, you will see two outputs. First, the problematic
SQL with a cartesian product, because an Entity Graph is used.

    2020-04-30 09:33:53.836 DEBUG 6145 --- [           main] org.hibernate.SQL                        :
    SELECT entitya0_.id      AS id1_0_0_,
           entityb2_.id      AS id1_2_1_,
           entitya0_.att1    AS att2_0_0_,
           entityb2_.att2    AS att2_2_1_,
           entityblis1_.a_id AS a_id1_1_0__,
           entityblis1_.b_id AS b_id2_1_0__
    FROM   test.a entitya0_
           LEFT OUTER JOIN test.a_b entityblis1_
                        ON entitya0_.id = entityblis1_.a_id
           LEFT OUTER JOIN test.b entityb2_
                        ON entityblis1_.b_id = entityb2_.id
    WHERE  entitya0_.id <> 10

Next, the way it should work: with a subselect. But unfortunately this is
without the Entity Graph.

    2020-04-30 09:33:53.915 DEBUG 6145 --- [           main] org.hibernate.SQL                        :
    SELECT entitya0_.id   AS id1_0_,
           entitya0_.att1 AS att2_0_
    FROM   test.a entitya0_
    WHERE  entitya0_.id <> 10

    2020-04-30 09:33:53.925 DEBUG 6145 --- [           main] org.hibernate.SQL                        :
    SELECT entityblis0_.a_id AS a_id1_1_1_,
           entityblis0_.b_id AS b_id2_1_1_,
           entityb1_.id      AS id1_2_0_,
           entityb1_.att2    AS att2_2_0_
    FROM   test.a_b entityblis0_
           INNER JOIN test.b entityb1_
                   ON entityblis0_.b_id = entityb1_.id
    WHERE  entityblis0_.a_id IN (SELECT entitya0_.id
                                 FROM   test.a entitya0_
                                 WHERE  entitya0_.id <> 10)