--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2 (Debian 12.2-2.pgdg100+1)
-- Dumped by pg_dump version 12.2 (Debian 12.2-2.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: test; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA test;


ALTER SCHEMA test OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: a; Type: TABLE; Schema: test; Owner: postgres
--

CREATE TABLE test.a (
    id integer NOT NULL,
    att1 character varying(50)
);


ALTER TABLE test.a OWNER TO postgres;

--
-- Name: a_b; Type: TABLE; Schema: test; Owner: postgres
--

CREATE TABLE test.a_b (
    id integer NOT NULL,
    a_id integer NOT NULL,
    b_id integer NOT NULL
);


ALTER TABLE test.a_b OWNER TO postgres;

--
-- Name: b; Type: TABLE; Schema: test; Owner: postgres
--

CREATE TABLE test.b (
    id integer NOT NULL,
    att2 character varying(50)
);


ALTER TABLE test.b OWNER TO postgres;

--
-- Data for Name: a; Type: TABLE DATA; Schema: test; Owner: postgres
--

COPY test.a (id, att1) FROM stdin;
1	Test1
2	Test2
3	Test3
4	Test4
5	Test5
\.


--
-- Data for Name: a_b; Type: TABLE DATA; Schema: test; Owner: postgres
--

COPY test.a_b (id, a_id, b_id) FROM stdin;
1	1	10
2	1	11
3	1	12
4	1	13
5	2	10
6	3	11
7	3	12
8	3	13
\.


--
-- Data for Name: b; Type: TABLE DATA; Schema: test; Owner: postgres
--

COPY test.b (id, att2) FROM stdin;
10	Test10
11	Test11
12	Test12
13	Test13
\.


--
-- Name: a_b a_b_pkey; Type: CONSTRAINT; Schema: test; Owner: postgres
--

ALTER TABLE ONLY test.a_b
    ADD CONSTRAINT a_b_pkey PRIMARY KEY (id);


--
-- Name: a a_pkey; Type: CONSTRAINT; Schema: test; Owner: postgres
--

ALTER TABLE ONLY test.a
    ADD CONSTRAINT a_pkey PRIMARY KEY (id);


--
-- Name: b b_pkey; Type: CONSTRAINT; Schema: test; Owner: postgres
--

ALTER TABLE ONLY test.b
    ADD CONSTRAINT b_pkey PRIMARY KEY (id);


--
-- Name: a_b a_b_a_id_fkey; Type: FK CONSTRAINT; Schema: test; Owner: postgres
--

ALTER TABLE ONLY test.a_b
    ADD CONSTRAINT a_b_a_id_fkey FOREIGN KEY (a_id) REFERENCES test.a(id);


--
-- Name: a_b a_b_b_id_fkey; Type: FK CONSTRAINT; Schema: test; Owner: postgres
--

ALTER TABLE ONLY test.a_b
    ADD CONSTRAINT a_b_b_id_fkey FOREIGN KEY (b_id) REFERENCES test.b(id);


--
-- PostgreSQL database dump complete
--

