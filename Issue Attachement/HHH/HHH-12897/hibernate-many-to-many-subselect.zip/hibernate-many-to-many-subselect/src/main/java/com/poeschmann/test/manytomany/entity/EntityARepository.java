package com.poeschmann.test.manytomany.entity;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional(readOnly = true)
public interface EntityARepository extends JpaRepository<EntityA, Integer>, JpaSpecificationExecutor<EntityA> {

    @EntityGraph(attributePaths = {EntityA_.ENTITY_BLIST})
    @Query(value = "select a from EntityA a where a.id <> 0")
    List<EntityA> findEntitiesWithEntityGraph();

    @Query(value = "select a from EntityA a where a.id <> 0")
    List<EntityA> findEntitesWithoutEntityGraph();

}
