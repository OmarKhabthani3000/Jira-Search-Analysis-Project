package com.poeschmann.test.manytomany;

import com.poeschmann.test.manytomany.entity.EntityA;
import com.poeschmann.test.manytomany.entity.EntityARepository;
import com.poeschmann.test.manytomany.entity.EntityB;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
@Slf4j
public class TestService {

    @Autowired
    private EntityARepository entityARepository;

    public void findAEntitiesWithEntityGraph() {
        log.debug("test --> findEntitiesWithEntityGraph");
        logAEntities(entityARepository.findEntitiesWithEntityGraph());
    }

    public void findAEntitiesWithoutEntityGraph() {
        log.debug("test --> findAEntitiesWithoutEntityGraph");
        logAEntities(entityARepository.findEntitesWithoutEntityGraph());
    }

    private void logAEntities(List<EntityA> entities) {
        entities.forEach(a -> {
            log.debug("{} {}", a.getId(), a.getAtt1());
            logBEntities(a.getEntityBList());
        });
    }

    private void logBEntities(List<EntityB> entities) {
        entities.forEach(b -> log.debug("\t {}  {}", b.getId(), b.getAtt2()));
    }

}
