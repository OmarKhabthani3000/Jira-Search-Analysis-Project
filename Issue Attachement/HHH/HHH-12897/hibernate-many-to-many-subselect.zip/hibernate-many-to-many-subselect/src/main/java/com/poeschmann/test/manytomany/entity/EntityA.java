package com.poeschmann.test.manytomany.entity;

import lombok.Data;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(schema = "test", name = "a")
@Data
public class EntityA {

    @Id
    @Column(name = "id")
    private Integer id;

    private String att1;

    @Fetch(FetchMode.SUBSELECT)
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            schema = "test",
            name = "a_b",
            joinColumns = @JoinColumn(name = "a_id"),
            inverseJoinColumns = @JoinColumn(name = "b_id"))
    private List<EntityB> entityBList;

}
