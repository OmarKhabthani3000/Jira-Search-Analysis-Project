package com.poeschmann.test.manytomany.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(schema = "test", name = "b")
@Data
public class EntityB {

    @Id
    @Column(name = "id")
    private Integer id;

    private String att2;

    @ManyToMany(fetch = FetchType.LAZY, mappedBy = "entityBList")
    private List<EntityA> entityAList;

}
