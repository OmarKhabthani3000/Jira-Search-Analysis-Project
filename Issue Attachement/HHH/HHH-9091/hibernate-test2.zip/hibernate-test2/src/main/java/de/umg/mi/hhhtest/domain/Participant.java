package de.umg.mi.hhhtest.domain; /**
 *
 */

import lombok.Data;

import javax.persistence.*;

/**
 * TODO
 *
 * @author Martin Puffe
 * @version 1.0.0-SNAPSHOT
 * @since 1.7
 */
@Data
@Entity
@Table(name = "participant")
public class Participant extends Persistable {

    @Column(name = "name")
    private String name;

    @OneToOne ( mappedBy = "participant", orphanRemoval = true, cascade = CascadeType.ALL)
    private Custodian custodian;
}
