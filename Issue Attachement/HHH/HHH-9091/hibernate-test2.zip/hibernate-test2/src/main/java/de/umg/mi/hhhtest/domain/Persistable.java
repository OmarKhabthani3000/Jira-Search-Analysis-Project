/**
 *
 */
package de.umg.mi.hhhtest.domain;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * TODO
 *
 * @author Martin Puffe
 * @version 1.0.0-SNAPSHOT
 * @since 1.7
 */
@MappedSuperclass
@Data
public class Persistable {

    @Id
    @GeneratedValue
    private Long id;
}
