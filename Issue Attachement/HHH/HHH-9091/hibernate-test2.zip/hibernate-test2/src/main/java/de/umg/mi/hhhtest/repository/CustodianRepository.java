/**
 *
 */
package de.umg.mi.hhhtest.repository;

import de.umg.mi.hhhtest.domain.Custodian;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * TODO
 *
 * @author Martin Puffe
 * @version 1.0.0-SNAPSHOT
 * @since 1.7
 */
public interface CustodianRepository extends JpaRepository<Custodian, Long> {
}
