/**
 *
 */
package de.umg.mi.hhhtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * TODO
 *
 * @author Martin Puffe
 * @version 1.0.0-SNAPSHOT
 * @since 1.7
 */
@Configuration
@ComponentScan
@EnableAutoConfiguration
public class TestConfiguration {

    public static void main (String[] args) {
        SpringApplication.run(TestConfiguration.class, args);
    }
}
