package de.umg.mi.hhhtest.domain; /**
 *
 */

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * TODO
 *
 * @author Martin Puffe
 * @version 1.0.0-SNAPSHOT
 * @since 1.7
 */
@Data
@Entity
@Table(name = "address")
public class Address extends Persistable {

    @Column(name = "address")
    private String address;

}
