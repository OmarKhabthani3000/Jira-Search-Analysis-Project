/**
 *
 */
package de.umg.mi.hhhtest.test;

import de.umg.mi.hhhtest.TestConfiguration;
import de.umg.mi.hhhtest.domain.Address;
import de.umg.mi.hhhtest.domain.Custodian;
import de.umg.mi.hhhtest.domain.Participant;
import de.umg.mi.hhhtest.repository.CustodianRepository;
import de.umg.mi.hhhtest.repository.ParticipantRepository;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * TODO
 *
 * @author Martin Puffe
 * @version 1.0.0-SNAPSHOT
 * @since 1.7
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = TestConfiguration.class)
public class ParticipantRepositoryTest {

    @Autowired
    private ParticipantRepository participantRepository;

    @Autowired
    private CustodianRepository custodianRepository;

    @Test
    public void deleteCustodianTest() {

        Participant participant = new Participant();
        participant.setName("Hans Dampf");

        Custodian custodian = new Custodian();
        custodian.setParticipant(participantRepository.saveAndFlush(participant));
        custodian.setName("Susanne Dampf");

        Address address = new Address();
        address.setAddress("Kurze Str. 10\nDE-37073 Göttingen");

        custodian.getAddressses().add(address);

        participant.setCustodian(custodian);

        participant = participantRepository.saveAndFlush(participant);

        Long custodianId = participant.getCustodian().getId();

        participant.setCustodian(null);

        participantRepository.saveAndFlush(participant);

        Assert.assertNull(custodianRepository.findOne(custodianId));
    }
}
