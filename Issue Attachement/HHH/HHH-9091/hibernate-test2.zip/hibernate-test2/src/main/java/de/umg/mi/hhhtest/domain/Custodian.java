package de.umg.mi.hhhtest.domain; /**
 *
 */

import com.sun.istack.internal.NotNull;
import lombok.Data;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * TODO
 *
 * @author Martin Puffe
 * @version 1.0.0-SNAPSHOT
 * @since 1.7
 */
@Data
@Entity
@Table(name = "custodian")
public class Custodian extends Persistable{

    @NotNull
    @OneToOne (optional = false)
    @JoinColumn(name = "participant_id", nullable = false, referencedColumnName = "id", updatable = true, unique = true)
    private Participant participant;

    @Column(name = "name")
    private String name;

    @OneToMany( fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinTable( name = "custodian_to_address", joinColumns = @JoinColumn(name = "custodian_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name="address_id", referencedColumnName = "id"))
    private Set<Address> addressses = new HashSet<Address>();
}
