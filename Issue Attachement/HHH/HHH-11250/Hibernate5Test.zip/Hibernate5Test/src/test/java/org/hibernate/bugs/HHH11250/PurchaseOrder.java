package org.hibernate.bugs.HHH11250;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.FilterDefs;
import org.hibernate.annotations.Filters;
import org.hibernate.annotations.ParamDef;

@Entity
@FilterDefs({
		@FilterDef(name = "customerIdFilter", parameters = @ParamDef(name = "customerId", type = "long")),
		@FilterDef(name = "PurchaseOrder.customerIdFilter", parameters = @ParamDef(name = "customerId", type = "long")),
		@FilterDef(name = "itemIdFilter", parameters = @ParamDef(name = "itemId", type = "long")),
		@FilterDef(name = "PurchaseOrder.itemIdFilter", parameters = @ParamDef(name = "itemId", type = "long"))
})
@Filters({
		@Filter(name = "customerIdFilter", condition = "customerId = :customerId"),
		@Filter(name = "PurchaseOrder.customerIdFilter", condition = "customerId = :customerId")
})
public class PurchaseOrder implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	private Long purchaseOrderId;
	private Long customerId;
	private Long totalAmount;
	
	@OneToMany(mappedBy = "purchaseOrder", cascade = CascadeType.PERSIST)
	@Filters({
		@Filter(name = "itemIdFilter", condition = "itemId = :itemId"),
		@Filter(name = "PurchaseOrder.itemIdFilter", condition = "itemId = :itemId")
	})
	private Set<PurchaseItem> purchaseItems;

	public PurchaseOrder() {
	}
	
	public PurchaseOrder(Long purchaseOrderId, Long customerId, Long totalAmount) {
		this.purchaseOrderId = purchaseOrderId;
		this.customerId = customerId;
		this.totalAmount = totalAmount;
	}

	public Long getPurchaseOrderId() {
		return purchaseOrderId;
	}

	public void setPurchaseOrderId(Long purchaseOrderId) {
		this.purchaseOrderId = purchaseOrderId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Long getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Long totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Set<PurchaseItem> getPurchaseItems() {
		return purchaseItems;
	}

	public void setPurchaseItems(Set<PurchaseItem> purchaseItems) {
		this.purchaseItems = purchaseItems;
	}

}
