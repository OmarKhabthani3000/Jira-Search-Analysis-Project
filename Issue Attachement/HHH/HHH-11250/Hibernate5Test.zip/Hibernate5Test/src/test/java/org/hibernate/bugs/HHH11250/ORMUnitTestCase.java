/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs.HHH11250;

import static org.junit.Assert.assertEquals;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Before;
import org.junit.Test;

public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	@Override
	protected Class<?>[] getAnnotatedClasses() {
		return new Class<?>[] {
			PurchaseOrder.class,
			PurchaseItem.class
		};
	}
	
	@Before
	public void prepare() {
		Session s = openSession();
		try {
			s.beginTransaction();
			
			{
				s.createQuery("delete from PurchaseItem").executeUpdate();
				s.createQuery("delete from PurchaseOrder").executeUpdate();
				s.flush();
			}
			
			{
				PurchaseOrder purchaseOrder = new PurchaseOrder(1L, 10L, 1000L);
				Set<PurchaseItem> purchaseItems = new HashSet<>();
				purchaseItems.add(new PurchaseItem(1L, 100L, purchaseOrder));
				purchaseItems.add(new PurchaseItem(2L, 200L, purchaseOrder));
				purchaseOrder.setPurchaseItems(purchaseItems);
				s.persist(purchaseOrder);
			}

			{
				PurchaseOrder purchaseOrder = new PurchaseOrder(2L, 20L, 1000L);
				Set<PurchaseItem> purchaseItems = new HashSet<>();
				purchaseItems.add(new PurchaseItem(3L, 100L, purchaseOrder));
				purchaseItems.add(new PurchaseItem(4L, 200L, purchaseOrder));
				purchaseOrder.setPurchaseItems(purchaseItems);
				s.persist(purchaseOrder);
			}

			s.getTransaction().commit();
			
		} catch (Exception e) {
			s.getTransaction().rollback();
			throw e;
		} finally {
			s.close();
		}
	}

	@Test
	public void testEntityFilter1() {
		Session s = openSession();
		try {
			s.enableFilter("customerIdFilter").setParameter("customerId", 10L);
			s.beginTransaction();
			
			List<PurchaseOrder> purchaseOrders = s.createQuery("from PurchaseOrder", PurchaseOrder.class).getResultList();
			assertEquals(1, purchaseOrders.size());
			
			s.getTransaction().commit();
			
		} catch (Exception e) {
			s.getTransaction().rollback();
			throw e;
		} finally {
			s.close();
		}
	}
	
	@Test
	public void testEntityFilter2() {
		Session s = openSession();
		try {
			s.enableFilter("PurchaseOrder.customerIdFilter").setParameter("customerId", 20L);
			s.beginTransaction();
			
			List<PurchaseOrder> purchaseOrders = s.createQuery("from PurchaseOrder", PurchaseOrder.class).getResultList();
			assertEquals(1, purchaseOrders.size());
			
			s.getTransaction().commit();
			
		} catch (Exception e) {
			s.getTransaction().rollback();
			throw e;
		} finally {
			s.close();
		}
	}
	
	@Test
	public void testCollectionFilter1() {
		Session s = openSession();
		try {
			s.enableFilter("itemIdFilter").setParameter("itemId", 100L);
			s.beginTransaction();
			
			PurchaseOrder purchaseOrder = s.get(PurchaseOrder.class, 1L);
			assertEquals(1, purchaseOrder.getPurchaseItems().size());
			
			s.getTransaction().commit();
			
		} catch (Exception e) {
			s.getTransaction().rollback();
			throw e;
		} finally {
			s.close();
		}
	}
	
	@Test
	public void testCollectionFilter2() {
		Session s = openSession();
		try {
			s.enableFilter("PurchaseOrder.itemIdFilter").setParameter("itemId", 100L);
			s.beginTransaction();
			
			PurchaseOrder purchaseOrder = s.get(PurchaseOrder.class, 1L);
			assertEquals(1, purchaseOrder.getPurchaseItems().size());
			
			s.getTransaction().commit();
			
		} catch (Exception e) {
			s.getTransaction().rollback();
			throw e;
		} finally {
			s.close();
		}
	}
}
