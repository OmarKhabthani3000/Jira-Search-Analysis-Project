package org.hibernate.bugs.HHH11250;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class PurchaseItem {
	
	@Id
	private Long purchaseItemId;
	private Long itemId;
	
	@ManyToOne
	@JoinColumn(name = "purchaseOrderId")
	private PurchaseOrder purchaseOrder;
	
	public PurchaseItem() {
	}

	public PurchaseItem(Long purchaseItemId, Long itemId, PurchaseOrder purchaseOrder) {
		this.purchaseItemId = purchaseItemId;
		this.itemId = itemId;
		this.purchaseOrder = purchaseOrder;
	}

	public Long getPurchaseItemId() {
		return purchaseItemId;
	}

	public void setPurchaseItemId(Long purchaseItemId) {
		this.purchaseItemId = purchaseItemId;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public PurchaseOrder getPurchaseOrder() {
		return purchaseOrder;
	}

	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

}
