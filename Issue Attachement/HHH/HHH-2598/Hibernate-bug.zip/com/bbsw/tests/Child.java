package com.bbsw.tests;


/**
 * @hibernate.class
 *  table="CHILD"
 *  schema="hibernate_tests"
 *  mutable="true"
 *  polymorphism="explicit"
 *  dynamic-update="true"
 */
public class Child {

	Long id;

	String text;

	private ParentA parentA;

	private ParentB parentB;
	/**
	 * @hibernate.many-to-one
	 *  column="PARENTB_ID"
	 *  class="com.bbsw.tests.ParentB"
	 *  not-null="false"
	 *  lazy="false"
	 *  insert="false"
	 *  update="false"
	 * @return
	 */
	public ParentB getParentB() {
		return parentB;
	}

	public void setParentB(ParentB parentB) {
		this.parentB = parentB;
	}
	/**
	 * @hibernate.many-to-one
	 *  column="PARENTA_ID"
	 *  class="com.bbsw.tests.ParentA"
	 *  not-null="false"
	 *  lazy="false"
	 *  insert="false"
	 *  update="false"
	 * @return
	 */
	public ParentA getParentA() {
		return parentA;
	}

	public void setParentA(ParentA parentA) {
		this.parentA = parentA;
	}

	/**
	 * @hibernate.id
	 *  unsaved-value="null"
	 *  column="ID_CHILD"
	 *  @hibernate.generator class="sequence"
	 * @hibernate.param
	 *  name="sequence"
	 *  value="hibernate_tests.child_id_seq"  
	 *  @return Long
	 */
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @hibernate.property
	 *  column="TEXT"
	 *  type="string"
	 *  not-null="false"
	 *  unique="false"
	 * @return String
	 */
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}
