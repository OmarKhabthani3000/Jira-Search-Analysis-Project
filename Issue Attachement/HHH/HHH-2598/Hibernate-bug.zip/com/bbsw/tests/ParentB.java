package com.bbsw.tests;

import java.util.List;
/**
 * @hibernate.class
 *  table="PARENT_B"
 *  schema="hibernate_tests"
 *  mutable="true"
 *  polymorphism="explicit"
 *  dynamic-update="true"
 */
public class ParentB {

	Long id;

	String text;

	List<Child> children;

	/**
	 * @hibernate.list
	 *  name="children"
	 *  cascade="persist,all-delete-orphan"
	 *  lazy="true"
	 *  inverse="false"
	 *  	 
	 * @hibernate.key 
	 * element-id="children-key"
	 * update="false"
	 * not-null="true"
	 * 
	 * @hibernate.column
	 * parent-element="children-key"
	 * name="PARENTB_ID"
	 * not-null="true"
	 *  
	 * @hibernate.list-index
	 *  column="PARENTB_LISTINDEX"
	 *
	 * @hibernate.one-to-many
	 *  class="com.bbsw.tests.Child"
	 * @return
	 */
	public List<Child> getChildren() {
		return children;
	}

	public void setChildren(List<Child> children) {
		this.children = children;
	}

	/**
	 * @hibernate.id
	 *  unsaved-value="null"
	 *  column="ID_PARENTB"
	 *  @hibernate.generator class="sequence"
	 * @hibernate.param
	 *  name="sequence"
	 *  value="hibernate_tests.parentb_id_seq"  
	 *  @return Long
	 */
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @hibernate.property
	 *  column="TEXT"
	 *  type="string"
	 *  not-null="false"
	 *  unique="false"
	 * @return String
	 */
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
