import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bbsw.tests.Child;
import com.bbsw.tests.ParentA;
import com.bbsw.tests.ParentB;


public class HBTest {
	public static void main(String args[]) {
		Configuration cfg = new Configuration();
		SessionFactory sf = cfg.configure().buildSessionFactory();
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		ParentA pa = new ParentA();
		pa.setText("I'm parent A");
		ParentB pb = new ParentB();
		pb.setText("I'm parent B");
		List<Child> la = new ArrayList<Child>();
		List<Child> lb = new ArrayList<Child>();
		pa.setChildren(la);
		pb.setChildren(lb);
		s.persist(pa);
		s.persist(pb);
		for(int n = 0; n < 100; n++) {
			Child c = new Child();
			c.setText("I'm child nr "+n);
			c.setParentA(pa);
			c.setParentB(pb);
			
			la.add(c);
			lb.add(c);
		}
		t.commit();
		s.close();
	}
}
