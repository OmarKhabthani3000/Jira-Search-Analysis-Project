/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernateapp;

import org.hibernate.Session;

/**
 *
 * @author dlatorre
 */
public class HibernateApp {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		
		Session ses = NewHibernateUtil.getSessionFactory().openSession();
		try {
			System.out.println(
					ses.createQuery(" select distinct prod.supplier from " + Products.class.getName() + " prod "
					+ " order by  prod.supplier.supplierName ").list());
		} finally {
			ses.close();
		}
		
	}
}
