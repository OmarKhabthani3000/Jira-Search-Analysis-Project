/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 *
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	private Foo detachedDeletedFoo;

	@Before
	public void prepare() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		Foo foo = new Foo();
		session.persist(foo);
		tx.commit();
		s.close();

		s = openSession();
		tx = s.beginTransaction();
		detachedDeletedFoo = session.load(Foo.class, foo.getId());
		session.delete(detachedDeletedFoo);
		tx.commit();
		s.close();
	}

	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
			Foo.class,
		};
	}

	@Test(expected = Exception.class)
	public void hhh1661Test() throws Exception {
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		Number count = (Number) session.createQuery("select count(foo.id) from Foo foo").uniqueResult();
		assertEquals(0, count.intValue());

		session.merge(detachedDeletedFoo);

		count = (Number) session.createQuery("select count(foo.id) from Foo foo").uniqueResult();
		if (count.intValue() > 0) {
			System.out.println("**********");
			System.out.println("The detached, deleted entity has been inserted. It shouldn't have been");
			System.out.println("**********");
		}

		tx.commit();
		s.close();
	}
}
