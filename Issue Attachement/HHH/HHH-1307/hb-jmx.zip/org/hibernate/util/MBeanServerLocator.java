package org.hibernate.util;

import java.util.ArrayList;

import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;

/**
 * 
 * @author fxmagdaleno
 *
 */
public class MBeanServerLocator {

	private MBeanServerLocator(){
		
	}
	
	public static MBeanServer locateMBeanServer() {
		return locateMBeanServer(null);
	}
	
    public static MBeanServer locateMBeanServer(String agentID) {
		ArrayList servers = MBeanServerFactory.findMBeanServer(agentID);
		MBeanServer server = (MBeanServer) servers.iterator().next();
		return server;
	}

}
