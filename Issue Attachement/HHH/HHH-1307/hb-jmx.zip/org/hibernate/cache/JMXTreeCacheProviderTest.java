package org.hibernate.cache;

import java.lang.management.ManagementFactory;
import java.util.Properties;

import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.jboss.cache.TreeCache;

import junit.framework.TestCase;

public class JMXTreeCacheProviderTest extends TestCase {

	
	JMXTreeCacheProvider provider;
	
	public void testCacheProvider(){
		Properties props = new Properties();
		props.put("hibernate.cache.jmx_name","psis:service=treeCache");
		provider.start(props);
		Cache cache = provider.buildCache("psisRegion",null);
		assertNotNull(cache);
		assertEquals("psisRegion",cache.getRegionName());
	}
	
	
	protected void setUp() throws Exception {
	   //register
	   MBeanServer server = ManagementFactory.getPlatformMBeanServer();
	   TreeCache cache = new TreeCache();
	   ObjectName objName = ObjectName.getInstance("psis","service","treeCache");
	   server.registerMBean(cache,objName);
	   //provider
	   provider = new JMXTreeCacheProvider();
	}

	protected void tearDown() throws Exception {
		provider.stop();
	}

}
