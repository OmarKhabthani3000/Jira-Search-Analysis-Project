package org.hibernate.cache;

import java.util.Properties;

import javax.management.MBeanServer;
import javax.management.MBeanServerInvocationHandler;
import javax.management.ObjectName;
import javax.transaction.TransactionManager;

import org.hibernate.transaction.TransactionManagerLookup;
import org.hibernate.transaction.TransactionManagerLookupFactory;
import org.hibernate.util.MBeanServerLocator;
import org.jboss.cache.TreeCacheMBean;

/**
 * <p>This cache provider is able to locate a TreeCache registered in a JMX MBean Server.
 *    In this sense, provides us a way to manage the TreeCache using a JMX Console.
 * </p>
 * 
 * @author <a href="fme@nextret.net">Francesc Xavier Magdaleno Escar</a>
 * @see org.hibernate.cache.TreeCacheProvider
 */
public class JMXTreeCacheProvider implements CacheProvider {

	private org.jboss.cache.TreeCache treeCache;
	
	
	public Cache buildCache(String regionName, Properties properties)
			throws CacheException {
		//TreeCache
		TreeCache cache =new TreeCache(treeCache,regionName,treeCache.getTransactionManager());
		return cache;
	}

	public long nextTimestamp() {
		return System.currentTimeMillis() / 100;
	}

	public void start(Properties properties) throws CacheException {
		try {
			MBeanServer server = MBeanServerLocator.locateMBeanServer();
			String strObjName = properties.getProperty("hibernate.cache.jmx_name");
			if(strObjName==null){
				//default value
				throw new CacheException("No JMX name provided");
			}
			ObjectName objName = ObjectName.getInstance(strObjName); 
			TreeCacheMBean cacheMBean = 
				(TreeCacheMBean) MBeanServerInvocationHandler.newProxyInstance(server,objName,TreeCacheMBean.class,false);
			//retrieve the JBoss TreeCache
			this.treeCache = cacheMBean.getInstance();
			//TM
			TransactionManager tm = this.treeCache.getTransactionManager();
			//not provided. Just provide a way to register it!!
			if(tm==null){
				//
				TransactionManagerLookup transactionManagerLookup = TransactionManagerLookupFactory.getTransactionManagerLookup(properties);
				if (transactionManagerLookup!=null) {
					treeCache.setTransactionManagerLookup( new TMLookupAdaptor(transactionManagerLookup, properties) );
				}
			}
			/*
			 * check state in order to start or not the application.
			 * Warning Provide a modification in your TreeCache in order to avoid
			 * dependences with org.jboss.system.ServiceController [TreeCache 
			 * extends org.jboss.system.ServiceMBeanSupport and org.jboss.system.ServiceController 
			 * manages its lifecycle and supposes this object to be register
			 * in our JMX MBeanServer]
	         */  
			int state = treeCache.getState();
			switch(state){
			case org.jboss.cache.TreeCache.UNREGISTERED:
			case org.jboss.cache.TreeCache.REGISTERED:
			case  org.jboss.cache.TreeCache.CREATED:  treeCache.start();break;
			case org.jboss.cache.TreeCache.STARTED: break;
			default : break;
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	public void stop() {
		/*
		 * check state in order to start or not the application.
		 * See the comments above.
		 */
		if(this.treeCache!=null){
			int state = treeCache.getState();
			switch(state){
			case org.jboss.cache.TreeCache.UNREGISTERED:
			case org.jboss.cache.TreeCache.REGISTERED:
			case  org.jboss.cache.TreeCache.CREATED: 
			case org.jboss.cache.TreeCache.STARTED:treeCache.stop();
			case org.jboss.cache.TreeCache.STOPPED: break;
			default : break;
			}
		}
		

	}

	public boolean isMinimalPutsEnabledByDefault() {
		return true;
	}
	
	static class TMLookupAdaptor  implements org.jboss.cache.TransactionManagerLookup{

		private Properties props;
		
		private TransactionManagerLookup lookup;
		
	    TMLookupAdaptor(TransactionManagerLookup transactionManagerLookup, Properties properties) {
			this.lookup = transactionManagerLookup;
			this.props = properties;
		}
		
		public TransactionManager getTransactionManager() throws Exception {
			return lookup.getTransactionManager(props);
		}
	}

}
