package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class FirstLevelReferencedEntity {

    @Id
    private Long id;

    @ManyToOne
    private SecondLevelReferencedEntityA secondLevelReferenceA;

    @ManyToOne
    private SecondLevelReferencedEntityB secondLevelReferenceB;

}
