package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class RootEntity {

    @Id
    private Long id;

    @ManyToOne
    private FirstLevelReferencedEntity firstLevelReference;

}
