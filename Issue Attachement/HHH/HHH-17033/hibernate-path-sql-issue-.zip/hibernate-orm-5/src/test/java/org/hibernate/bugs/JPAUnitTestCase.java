package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        entityManager.createQuery("select r.id, flr.id, ur1.id, ur2.id, ur3.id from RootEntity r "
                + "inner join r.firstLevelReference as flr "
                + "left join UnrelatedEntity ur1 on ur1.id = flr.secondLevelReferenceA.id "
                + "left join UnrelatedEntity ur2 on ur2.id = flr.secondLevelReferenceB.id "
                + "left join UnrelatedEntity ur3 on ur3.id = flr.secondLevelReferenceB.thirdLevelReference.id "
        ).getResultList();

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
