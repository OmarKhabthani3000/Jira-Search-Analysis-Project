package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class UnrelatedEntity {

    @Id
    private Long id;

}
