package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class ThirdLevelReferencedEntity {

    @Id
    private Long id;

}
