package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class SecondLevelReferencedEntityA {

    @Id
    private Long id;

}
