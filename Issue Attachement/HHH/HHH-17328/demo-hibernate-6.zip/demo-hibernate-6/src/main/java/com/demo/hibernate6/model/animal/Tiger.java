package com.demo.hibernate6.model.animal;

import com.demo.hibernate6.model.Zoo;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import java.math.BigDecimal;

@Entity
@DiscriminatorValue("Tiger")
public class Tiger extends Animal {

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "ZOO_ID")
  private Zoo zoo;

  public Tiger() {
    super();
  }

  public Tiger(Long id, Integer sequenceNumber, BigDecimal weight) {
    super(id, sequenceNumber, weight);
  }

  public Zoo getZoo() {
    return zoo;
  }

  public void setZoo(Zoo zoo) {
    this.zoo = zoo;
  }

  public static TigerBuilder tigerBuilder() {
    return new TigerBuilder();
  }

  public static class TigerBuilder {
    private Long id;
    private Integer sequenceNumber;
    private BigDecimal weight;

    public TigerBuilder id(Long id) {
      this.id = id;
      return this;
    }

    public TigerBuilder sequenceNumber(Integer sequenceNumber) {
      this.sequenceNumber = sequenceNumber;
      return this;
    }

    public TigerBuilder weight(BigDecimal weight) {
      this.weight = weight;
      return this;
    }

    public Tiger build() {
      Tiger tiger = new Tiger(id, sequenceNumber, weight);
      return tiger;
    }
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    if (!super.equals(o)) return false; // Check the superclass equality first

    return true; // No additional fields to compare
  }

  @Override
  public int hashCode() {
    return super.hashCode(); // Only include fields from the superclass
  }

  @Override
  public String toString() {
    return "Tiger{"
        + "id="
        + getId()
        + ", sequenceNumber="
        + getSequenceNumber()
        + ", weight="
        + getWeight()
        +
        // Exclude the Zoo field from the toString method
        '}';
  }
}
