package com.demo.hibernate6;

import com.demo.hibernate6.model.Zoo;
import com.demo.hibernate6.model.animal.Elephant;
import com.demo.hibernate6.model.animal.Tiger;
import jakarta.persistence.EntityGraph;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.math.BigDecimal;

public class App {

  private static final String LOAD_GRAPH = "jakarta.persistence.loadgraph";

  public static void main(String[] args) {

    EntityManagerFactory entityManagerFactory =
        Persistence.createEntityManagerFactory("templatePU");
    EntityManager entityManager = entityManagerFactory.createEntityManager();

    entityManager.getTransaction().begin();
    Zoo zoo = Zoo.builder().name("The Great Calcutta Zoo").build();

    entityManager.persist(zoo);

    // Persisting tiger
    Tiger tiger = Tiger.tigerBuilder().sequenceNumber(0).weight(BigDecimal.ONE).build();
    tiger.setZoo(zoo);
    entityManager.persist(tiger);

    entityManager.flush();
    entityManager.clear();

    entityManager.getTransaction().commit();

    // Persisting first Elephant
    entityManager.getTransaction().begin();
    Elephant elephant1 =
        Elephant.elephantBuilder().sequenceNumber(1).weight(BigDecimal.TEN).build();
    elephant1.setZoo(zoo);
    entityManager.persist(elephant1);

    entityManager.flush();
    entityManager.clear();
    entityManager.getTransaction().commit();

    // fetch using entity graph
    entityManager.getTransaction().begin();
    EntityGraph<?> entityGraph = entityManager.getEntityGraph("get-zoo-with-all-animals");
    Zoo zooFetchedUsingGraph =
        entityManager
            .createQuery("select zoo from Zoo zoo where zoo.id=:zooId", Zoo.class)
            .setHint(LOAD_GRAPH, entityGraph)
            .setParameter("zooId", zoo.getId())
            .getSingleResult();
    System.out.println("zoo: " + zooFetchedUsingGraph);
    System.out.println("zoo Id:" + zooFetchedUsingGraph.getId());
    System.out.println("zoo name:" + zooFetchedUsingGraph.getName());
    System.out.println(
        "number of elephants:"
            + zooFetchedUsingGraph.getElephants().size()); // still not fixed, size should be 1

    System.out.println(
        "is elephant instance of Elephant: "
            + (zooFetchedUsingGraph.getElephants().get(0) instanceof Elephant));

    System.out.println("zoo elephant:" + zooFetchedUsingGraph.getElephants().get(0));
    System.out.println(zooFetchedUsingGraph.getElephants().get(0).getClass().getName());
    System.out.println("zoo elephant Id:" + zooFetchedUsingGraph.getElephants().get(0).getId());

    System.out.println(
        "is tiger instance of Tiger: " + (zooFetchedUsingGraph.getTiger() instanceof Tiger));
    System.out.println("zoo tiger:" + zooFetchedUsingGraph.getTiger());
    System.out.println(zooFetchedUsingGraph.getTiger().getClass().getName());
    System.out.println("zoo tiger id:" + zooFetchedUsingGraph.getTiger().getId());
    entityManager.getTransaction().commit();
  }
}
