/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Calendar;
import java.util.GregorianCalendar;



/**
 *
 * @author LabHiber
 */

public class Person implements Serializable{
  
    private int id;
    private String firstName;
    private String secondName;
    private GregorianCalendar birthDate;


    public Person() {
    }
    public Person(String firstName, String secondName) {
        this.firstName = firstName;
        this.secondName = secondName;
    }

    public Person(String firstName, String secondName, GregorianCalendar birthDate) {
        this.firstName = firstName;
        this.secondName = secondName;
        this.birthDate = birthDate;
    }

    @Override
    public String toString() {
      return (getFirstName() + " "+getSecondName() + " ur. " + getBirthDateS());
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public GregorianCalendar getBirthDate() {
        return birthDate;
    }
    public String getBirthDateS(){
        return(birthDate.get(Calendar.YEAR)+"-"+(birthDate.get(Calendar.MONTH)+1)
                +"-"+birthDate.get(Calendar.DAY_OF_MONTH));
    }

    public void setBirthDate(GregorianCalendar birthDate) {
        this.birthDate = birthDate;
    }
    public int getAge(){
         if (birthDate != null) {
             return(Calendar.getInstance().get(Calendar.YEAR)-birthDate.get(Calendar.YEAR));
         }
         else {
             return(0);
         } 
    }
    
}
