/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.GregorianCalendar;

/**
 *
 * @author LabHiber
 */

public class Child extends Person implements Serializable{

    private Address address;

    public Child() {
    }

    public Child(String firstName, String seconname) {
        super(firstName, seconname);
    }

    public Child(String firstName, String secondName, GregorianCalendar birthDate) {
        super(firstName, secondName, birthDate);
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
    

}
