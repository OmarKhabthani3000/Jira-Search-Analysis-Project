/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;



/**
 *
 * @author LabHiber
 */

public class Address implements Serializable{
  
    private int id;
    private String postalCode;
    private String city;
    private String street;
    private String houseNo;
    private String apartmentNo;

    public Address() {
    }

    public Address(String postalCode, String city, String street, String houseNo, String apartmentNo) {
        this.postalCode = postalCode;
        this.city = city;
        this.street = street;
        this.houseNo = houseNo;
        this.apartmentNo = apartmentNo;
    }

  

    @Override
    public String toString() {
        return (" "+postalCode + " " + city + " ul." + street + " " + houseNo + "/" + apartmentNo+" ");
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getHouseNo() {
        return houseNo;
    }

    public void setHouseNo(String houseNo) {
        this.houseNo = houseNo;
    }

    public String getApartmentNo() {
        return apartmentNo;
    }

    public void setApartmentNo(String apartmentNo) {
        this.apartmentNo = apartmentNo;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

}
