/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import org.hibernate.annotations.Cascade;

/**
 *
 * @author LabHiber
 */

public class Project implements Serializable {

    private int id;
    private String name;
    private GregorianCalendar startDate;
    private GregorianCalendar endDate;

    private Set<Employee> employees = new HashSet<Employee>(10);

    public Project() {
    }

    public Project(String name, GregorianCalendar startDate, GregorianCalendar endDate) {
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public GregorianCalendar getStartDate() {
        return startDate;
    }

    public void setStartDate(GregorianCalendar startDate) {
        this.startDate = startDate;
    }

    public GregorianCalendar getEndDate() {
        return endDate;
    }

    public void setEndDate(GregorianCalendar endDate) {
        this.endDate = endDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(Set<Employee> employees) {
        this.employees = employees;
    }

    public String getDates() {
        return startDate.get(GregorianCalendar.YEAR)
                + "-"
                + (startDate.get(GregorianCalendar.MONTH) + 1)
                + "-"
                + startDate.get(GregorianCalendar.DAY_OF_MONTH) 
                + " "
                + endDate.get(GregorianCalendar.YEAR) 
                + "-" 
                + (endDate.get(GregorianCalendar.MONTH) + 1)
                + "-" 
                + endDate.get(GregorianCalendar.DAY_OF_MONTH);
    }

    @Override
    public String toString() {
        return ("Projekt: " + getName() + " Okres: "
                + getDates());
    }
}
