/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.ForeignKey;



/**
 *
 * @author LabHiber
 */

public class Employee extends Person implements Serializable{

 private Address address;
 private String position;
 private Department department;
 private Set<Child> children = new HashSet<Child>(3);
 private Set<Project> projects = new HashSet<Project>(3);

    public Employee() {
    }

    public Employee(String firstName, String secondName, GregorianCalendar birthDate) {
       super(firstName, secondName, birthDate);
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Set<Child> getChildren() {
        return children;
    }

    public void setChildren(Set<Child> children) {
        this.children = children;
    }

    public Set<Project> getProjects() {
        return projects;
    }

    public void setProjects(Set<Project> projects) {
        this.projects = projects;
    }
@Override
    public String toString() {
      return (super.getFirstName() + " "
              +super.getSecondName() + " ur. " + super.getBirthDateS()
              +" stanowisko: "+ position);
    }
}
