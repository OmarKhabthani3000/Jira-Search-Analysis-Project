/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.util.GregorianCalendar;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;



/**
 *
 * @author Gubi
 */

public class Manager extends Employee{
    private double benefit;

    public Manager() {
    }

    public Manager(String firstName, String secondName, GregorianCalendar birthDate) {
        super(firstName, secondName, birthDate);
    }

    public double getBenefit() {
        return benefit;
    }

    public void setBenefit(double benefit) {
        this.benefit = benefit;
    }
    

 
}
