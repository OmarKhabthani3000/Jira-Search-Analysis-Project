package org.hibernate.bugs;

import javax.persistence.*;
import java.util.*;

@Entity
public class ParentWithOptimisticLocking {

    @Id
    @Column
    private UUID id;

    @Column
    private String name;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "parent_id", nullable = false, updatable = false)
    @OrderColumn(name = "child_index", nullable = false)
    private List<Child2> children = new ArrayList<>();

    @Version
    @Column(name = "VERSION")
    private Integer version;

    private ParentWithOptimisticLocking() {
    }

    public ParentWithOptimisticLocking(String name, List<Child2> children) {
        this(UUID.randomUUID(), name, children, null);
    }

    public ParentWithOptimisticLocking(UUID id, String name, List<Child2> children, Integer version) {
        this.id = id;
        this.name = name;
        this.children = children;
        this.version = version;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ParentWithOptimisticLocking simple = (ParentWithOptimisticLocking) o;
        return Objects.equals(id, simple.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Child2> getChildren() {
        return Collections.unmodifiableList(children);
    }

    @Override
    public String toString() {
        return String.format("Parent{id=%s, name='%s', children=%s}", id, name, children);
    }

    public Integer getVersion() {
        return version;
    }
}
