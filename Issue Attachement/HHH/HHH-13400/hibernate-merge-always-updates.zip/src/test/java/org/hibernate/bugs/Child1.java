package org.hibernate.bugs;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Objects;
import java.util.UUID;

@Entity
public class Child1 {

    @Id
    @Column
    private UUID id;

    @Column
    private String name;

    private Child1() {
    }

    public Child1(String name) {
        this(UUID.randomUUID(), name);
    }

    public Child1(UUID id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Child1 child = (Child1) o;
        return Objects.equals(id, child.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return String.format("Child{id=%s, name='%s'}", id, name);
    }
}
