package org.hibernate.bugs;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Objects;
import java.util.UUID;

@Entity
public class Child2 {

    @Id
    @Column
    private UUID id;

    @Column
    private String name;

    private Child2() {
    }

    public Child2(String name) {
        this(UUID.randomUUID(), name);
    }

    public Child2(UUID id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Child2 child = (Child2) o;
        return Objects.equals(id, child.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return String.format("Child{id=%s, name='%s'}", id, name);
    }
}
