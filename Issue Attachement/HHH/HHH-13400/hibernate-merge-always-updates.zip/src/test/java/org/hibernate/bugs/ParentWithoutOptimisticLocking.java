package org.hibernate.bugs;

import javax.persistence.*;
import java.util.*;

@Entity
public class ParentWithoutOptimisticLocking {

    @Id
    @Column
    private UUID id;

    @Column
    private String name;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "parent_id", nullable = false, updatable = false)
    @OrderColumn(name = "child_index", nullable = false)
    //@OptimisticLock(excluded = false)
    private List<Child1> children = new ArrayList<>();

//    @Version
    @Column(name = "VERSION")
    private Integer version;

    private ParentWithoutOptimisticLocking() {
    }

    public ParentWithoutOptimisticLocking(String name, List<Child1> children) {
        this(UUID.randomUUID(), name, children, null);
    }

    public ParentWithoutOptimisticLocking(UUID id, String name, List<Child1> children, Integer version) {
        this.id = id;
        this.name = name;
        this.children = children;
        this.version = version;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ParentWithoutOptimisticLocking simple = (ParentWithoutOptimisticLocking) o;
        return Objects.equals(id, simple.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Child1> getChildren() {
        return Collections.unmodifiableList(children);
    }

    @Override
    public String toString() {
        return String.format("Parent{id=%s, name='%s', children=%s}", id, name, children);
    }

    public Integer getVersion() {
        return version;
    }
}
