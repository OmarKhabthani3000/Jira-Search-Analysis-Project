/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 *
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {
    private final String jdbcUrl = String.format("jdbc:h2:file:%s;DB_CLOSE_DELAY=-1;AUTO_SERVER=TRUE", new File("target/h2data").getAbsolutePath().replaceAll("\\\\", "/"));

	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
				ParentWithoutOptimisticLocking.class,
                Child1.class,
                ParentWithOptimisticLocking.class,
				Child2.class
		};
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );

		configuration.setProperty( AvailableSettings.SHOW_SQL, Boolean.TRUE.toString() );
		configuration.setProperty( AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString() );
		configuration.setProperty(AvailableSettings.FORMAT_SQL, Boolean.FALSE.toString());
        configuration.setProperty("hibernate.connection.url", jdbcUrl);
	}

	@Test
	public void parentWITHOUTOptimisticLockingShouldNotBeUpdatedIfNothingHasChanged() throws Exception {

        ParentWithoutOptimisticLocking parent = new ParentWithoutOptimisticLocking( "barry", Arrays.asList(new Child1("one"), new Child1("two")));
        doOperation(session -> {
            System.out.println("******** SAVE session.save()");
            session.save(parent);
        });
        printActualParentWithoutOptimisticLockingTable("Parent table after save");

        System.out.println("******** SAVE OR UPDATE THAT DOESN'T UPDATE");
        doOperation(session -> {
            session.saveOrUpdate(detached(parent));
        });
        assertEquals("Version should not have changed", parent.getVersion(), loadParentById1(parent.getId()).getVersion());

        System.out.println("******** MERGE THAT DOESN'T UPDATE");
        doOperation(session -> {
            session.merge(detached(parent));
        });

        printActualParentWithoutOptimisticLockingTable("Unchanged");
        assertEquals("Version should not have changed", parent.getVersion(), loadParentById1(parent.getId()).getVersion());
    }

	@Test
	public void parentWITHOptimisticLockingShouldNotBeUpdatedIfNothingHasChanged() throws Exception {

        ParentWithOptimisticLocking parent = new ParentWithOptimisticLocking( "barry", Arrays.asList(new Child2("one"), new Child2("two")));
        doOperation(session -> {
            System.out.println("******** SAVE session.save()");
            session.save(parent);
        });
        printActualParentWithOptimisticLockingTable("Parent table after save");

        System.out.println("******** SAVE OR UPDATE THAT DOESN'T UPDATE");
        doOperation(session -> {
            session.saveOrUpdate(detached(parent));
        });
        assertEquals("Version should not have changed", parent.getVersion(), loadParentById2(parent.getId()).getVersion());

        System.out.println("******** MERGE THAT SHOULDN'T UPDATE");
        doOperation(session -> {
            session.merge(detached(parent));
        });

        printActualParentWithOptimisticLockingTable("The version appears to have updated");
        assertEquals("Version should not have changed", parent.getVersion(), loadParentById2(parent.getId()).getVersion());
    }

	public interface Operation {
        void perform(Session session);
    }

    private void doOperation(Operation operation) {
        Session session = openSession();
        Transaction tx = session.beginTransaction();
        // Do stuff...
        operation.perform(session);

        tx.commit();
        session.close();
    }

    private ParentWithoutOptimisticLocking detached(ParentWithoutOptimisticLocking parent) {
        return new ParentWithoutOptimisticLocking(parent.getId(), parent.getName(), detached1(parent.getChildren()), parent.getVersion());
    }

    private ParentWithOptimisticLocking detached(ParentWithOptimisticLocking parent) {
        return new ParentWithOptimisticLocking(parent.getId(), parent.getName(), detached2(parent.getChildren()), parent.getVersion());
    }

    private List<Child1> detached1(List<Child1> children) {
	    return children.stream().map(this::detached).collect(Collectors.toList());
    }

    private Child1 detached(Child1 child) {
        return new Child1(child.getId(), child.getName());
    }

    private List<Child2> detached2(List<Child2> children) {
	    return children.stream().map(this::detached).collect(Collectors.toList());
    }

    private Child2 detached(Child2 child) {
        return new Child2(child.getId(), child.getName());
    }

    private void printActualParentWithOptimisticLockingTable(String message) throws SQLException {
        printActualTable(message, "ParentWithOptimisticLocking");
    }

    private void printActualParentWithoutOptimisticLockingTable(String message) throws SQLException {
        printActualTable(message, "ParentWithoutOptimisticLocking");
    }

    private void printActualTable(String message, String tableName) throws SQLException {
        Connection connection = DriverManager.getConnection(jdbcUrl, "sa", "");
        ResultSet resultSet = connection.createStatement().executeQuery("select * from " + tableName);
        System.out.println("=================================================");
        System.out.println(message);
        System.out.println("=================================================");
        System.out.println("ID                               NAME  VERSION");
        while (resultSet.next()) {
            String id = resultSet.getString("id");
            String name = resultSet.getString("name");
            int version = resultSet.getInt("VERSION");
            System.out.println(String.format("%s %s       %s", id, name, version));
        }
        System.out.println("=================================================");
    }

    private ParentWithoutOptimisticLocking loadParentById1(UUID id) {
        ParentWithoutOptimisticLocking[] parent = new ParentWithoutOptimisticLocking[1];
        doOperation(session -> {
            System.out.println("******** GET BY ID");
            parent[0] = session.get(ParentWithoutOptimisticLocking.class, id);
        });
        return parent[0];
    }

    private ParentWithOptimisticLocking loadParentById2(UUID id) {
        ParentWithOptimisticLocking[] parent = new ParentWithOptimisticLocking[1];
        doOperation(session -> {
            System.out.println("******** GET BY ID");
            parent[0] = session.get(ParentWithOptimisticLocking.class, id);
        });
        return parent[0];
    }
}
