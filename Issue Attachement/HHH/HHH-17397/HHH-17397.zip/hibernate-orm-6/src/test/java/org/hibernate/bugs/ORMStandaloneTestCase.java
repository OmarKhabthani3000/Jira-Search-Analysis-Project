package org.hibernate.bugs;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * This template demonstrates how to develop a standalone test case for Hibernate ORM.  Although this is perfectly
 * acceptable as a reproducer, usage of ORMUnitTestCase is preferred!
 */
public class ORMStandaloneTestCase {

	private SessionFactory sf;

	@Before
	public void setup() {
		StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
			// Add in any settings that are specific to your test. See resources/hibernate.properties for the defaults.
			.applySetting( "hibernate.show_sql", "true" )
			.applySetting( "hibernate.format_sql", "true" )
			.applySetting( "hibernate.hbm2ddl.auto", "update" );

		Metadata metadata = new MetadataSources( srb.build() )
		// Add your entities here.
		//	.addAnnotatedClass( Foo.class )
                .addAnnotatedClass(Main.class)
                .addAnnotatedClass(Related.class)
			.buildMetadata();

		sf = metadata.buildSessionFactory();
	}

	// Add your tests, using standard JUnit.

	@Test
	public void hhh17397Test() throws Exception {
        Session session = sf.openSession();
        Transaction tx = session.beginTransaction();
        Main main = new Main();
        Related related1 = new Related();
        Related related2 = new Related();

        main.setRelated(related1);

        session.persist(main);
        session.persist(related1);
        session.persist(related2);
        session.flush();
        tx.commit();
        session.clear();
        Transaction newTx = session.beginTransaction();
        Long relatedCount = session.createQuery(
                "select count(related) from Related as related", Long.class).getSingleResult();
        // This assertion passes
        assertEquals(2, relatedCount);

        Long actualCount = session.createQuery(
                "select count(related) from Main m right join m.related as related",
                Long.class).getSingleResult();
        // This assertion fails
        assertEquals(2, actualCount);
        newTx.commit();
        session.close();
	}
}
