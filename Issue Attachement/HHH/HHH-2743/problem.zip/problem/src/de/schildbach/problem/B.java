package de.schildbach.problem;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * @author Andreas Schildbach
 */
@Entity
@DiscriminatorValue("b")
public class B extends Base
{
	private int b;

	protected B()
	{
	}

	public void setB(int b)
	{
		this.b = b;
	}

	@Column(nullable = false)
	public int getB()
	{
		return b;
	}
}
