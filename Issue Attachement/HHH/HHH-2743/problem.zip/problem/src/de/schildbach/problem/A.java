package de.schildbach.problem;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * @author Andreas Schildbach
 */
@Entity
@DiscriminatorValue("a")
public class A extends Base
{
	private int a;

	protected A()
	{
	}

	public void setA(int a)
	{
		this.a = a;
	}

	@Column(nullable = false)
	public int getA()
	{
		return a;
	}
}
