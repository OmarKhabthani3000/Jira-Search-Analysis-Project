package de.schildbach.problem;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.classic.Session;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author Andreas Schildbach
 */
public class TestProblem
{
	private static SessionFactory sessionFactory;

	@BeforeClass
	public static final void setupDatabase()
	{
		sessionFactory = new AnnotationConfiguration().configure("/de/schildbach/problem/hibernate.cfg.xml").buildSessionFactory();
	}

	@Test
	public void test()
	{
		Session session = sessionFactory.openSession();

		A a = new A();
		a.setA(10);

		session.save(a);

		session.close();
	}
}
