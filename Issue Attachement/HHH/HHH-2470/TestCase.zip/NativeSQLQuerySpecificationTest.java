package test;

import edu.emory.mathcs.backport.java.util.concurrent.ExecutorService;
import edu.emory.mathcs.backport.java.util.concurrent.Executors;
import junit.framework.TestCase;
import org.apache.commons.collections.LRUMap;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.SQLQuery;
import org.hibernate.cfg.Configuration;
import org.hibernate.engine.query.NativeSQLQuerySpecification;
import org.hibernate.loader.custom.SQLQueryReturn;
import org.hibernate.loader.custom.SQLQueryRootReturn;
import org.hibernate.loader.custom.SQLQueryScalarReturn;

import java.util.Collections;

/**
 * Test of NativeSQLQuerySpecification, memory leak, and additional threading issues with
 * LRUMap.
 * Has beeen tested with Hibernate 3.1.3, but as far as I can see from the source-code, 
 * the problem also exists in 3.2GA.
 * <p/>
 * </br>
 *
 * @author Bj�rn Bjerkeli
 */
public class NativeSQLQuerySpecificationTest extends TestCase {
    private static final int SIZE = 128;
    private SessionFactory sessionFactory;
    private static final String QUERY = "select si.* from simpledomainobject si";

    protected void setUp() throws Exception {
        //T�DO replace with something useful for you own environment.
        Configuration cfg = new Configuration()
                .addResource("test/SimpleDomainObject.xml")
                .setProperty("hibernate.hbm2ddl.auto", "create-drop")
                .setProperty("hibernate.show_sql", "true")
                .setProperty("hibernate.dialect", "org.hibernate.dialect.Oracle9Dialect")
                .setProperty("hibernate.connection.driver_class", "oracle.jdbc.driver.OracleDriver")
                .setProperty("hibernate.connection.url", "jdbc:oracle:thin:@10.100.108.19:1521:u1ut1")
                .setProperty("hibernate.connection.username", "int4")
                .setProperty("hibernate.connection.password", "int4");

        sessionFactory = cfg.buildSessionFactory();
    }


    //If this is executed with a -Xmx20m it will quickly it the max limit
    //and throw OutOfMemoryError
    public void testMemoryLeak() throws InterruptedException {
        ExecutorService service = Executors.newFixedThreadPool(3);
        service.submit(new SQLQueryService());
        service.submit(new SQLQueryService());
        service.submit(new SQLQueryService());
        while (true) {
            Thread.sleep(1000);
        }
    }

    /**
     * NativeSQLQuerySpecification is used as a key for caching
     * NativeSQLQueryPlan instances, it is therefore vital that it obeys basic
     * rules regarding hashCode and equals ......say no more!
     */
    public void testEquals() {
        NativeSQLQuerySpecification query1 = createQuery();
        NativeSQLQuerySpecification query2 = createQuery();

        assertEquals(query1.hashCode(), query2.hashCode());
        assertEquals(query1, query2);
    }

    private NativeSQLQuerySpecification createQuery() {
        return new NativeSQLQuerySpecification("" +
                QUERY,
                new SQLQueryReturn[]{new SQLQueryRootReturn("si", "SimpleDomainObject", LockMode.READ)},
                new SQLQueryScalarReturn[0], Collections.EMPTY_LIST);

    }

    /**
     * Test single-threaded use of LRUMap.
     *
     * @throws InterruptedException
     */
    public void testLRUMapSingleThread() throws InterruptedException {
        doTest(1);
    }

    /**
     * Test multithreaded update of LRUMap.
     *
     * @throws InterruptedException
     */
    public void testLRUMapMultithreaded() throws InterruptedException {
        doTest(3);
    }

    private void doTest(int numThreads) throws InterruptedException {
        ExecutorService service = Executors.newFixedThreadPool(3);
        final LRUMap lruMap = new LRUMap(SIZE);
        for (int i = 0; i < numThreads; i++) {
            service.submit(createUpdateThread(lruMap));
        }

        final int numAttempts = 10;
        for (int i = 0; i < numAttempts; i++) {
            int size = lruMap.size();
            assertTrue("Was [" + size + "]", size <= SIZE);
            Thread.sleep(500);
        }
    }

    private Runnable createUpdateThread(final LRUMap lruMap) throws InterruptedException {
        return new Runnable() {

            public void run() {
                while (true) {
                    for (int i = 0; i < 70; i++) {
                        lruMap.put(createQuery(), "bug");
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
    }

    private final class SQLQueryService implements Runnable {
        public void run() {
            while (true) {


                Session session = null;
                try {
                    session = sessionFactory.openSession();
                    SQLQuery sqlQuery = session.createSQLQuery(QUERY);
                    sqlQuery.addEntity("si", no.bbs.core.proxy.stability.SimpleDomainObject.class);
                    sqlQuery.list();
                } finally {
                    if (session != null) {
                        session.close();
                    }
                }
                try {
                    Thread.sleep(30);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

