package test;

import java.io.Serializable;

/**
 * Simple domain object for test.
 *
 * @author Bj�rn Bjerkeli.
 */
public class SimpleDomainObject implements Serializable {
    private Long id;
    private String name;

    private  SimpleDomainObject() {
    }

    public SimpleDomainObject(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    private void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }
}
