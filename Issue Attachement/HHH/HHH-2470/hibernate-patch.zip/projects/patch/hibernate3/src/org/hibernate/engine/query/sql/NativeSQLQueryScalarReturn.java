package org.hibernate.engine.query.sql;

import org.hibernate.type.Type;

/**
 * Describes a scalar return in a native SQL query.
 *
 * @author gloegl
 */
public class NativeSQLQueryScalarReturn implements NativeSQLQueryReturn {
	private Type type;
	private String columnAlias;
	private final int hashCode;

	public NativeSQLQueryScalarReturn(String alias, Type type) {
		this.type = type;
		this.columnAlias = alias;
		
		// pre-determine and cache the hashcode
		int hashCode = type.getClass().getName().hashCode();
		
		if (columnAlias != null) {
			hashCode = hashCode = 29 * hashCode + columnAlias.hashCode();
		}
		
		this.hashCode = hashCode;
	}

	public String getColumnAlias() {
		return columnAlias;
	}

	public Type getType() {
		return type;
	}
	
	public boolean equals(Object o) {
		if ( this == o ) {
			return true;
		}
		if ( o == null || getClass() != o.getClass() ) {
			return false;
		}

		final NativeSQLQueryScalarReturn that = ( NativeSQLQueryScalarReturn ) o;
		
		return this.type.getClass() == that.type.getClass()
			&& ((this.columnAlias == null && that.columnAlias == null) || (this.columnAlias != null && this.columnAlias.equals(that.columnAlias))); 
	}


	public int hashCode() {
		return hashCode;
	}
}
