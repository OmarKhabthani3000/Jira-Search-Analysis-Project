/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


/**
 *
 * @author walkotte
 */
@Entity
public class Detail {
    @Id @GeneratedValue
    private Integer id;

    @ManyToOne(optional = false)
    private Master master;

    public Detail(Master master) {
        this.master = master;
    }
}
