package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh12492Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
        // prepare
		entityManager.getTransaction().begin();
        Master m1 = new Master();
        entityManager.persist(m1);
        Detail d11 = new Detail(m1);
        entityManager.persist(d11);
        Detail d12 = new Detail(m1);
        entityManager.persist(d12);

        Master m2 = new Master();
        entityManager.persist(m2);
        entityManager.getTransaction().commit();

		entityManager.getTransaction().begin();
        // depending on the generated ids above this delete removes all masters or nothing
        // removal of all masters results in foreign key constraint violation
        // removal of nothing is incoorect since 2nd master does not have any details
        String d = "delete from Master m where not exists (select d from Detail d where d.master=m)";
        Query del = entityManager.createQuery(d);
        del.executeUpdate();

        // so check for exacly one master after deletion
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Master> query = builder.createQuery(Master.class);
        query.select(query.from(Master.class));
        Assert.assertEquals(1, entityManager.createQuery(query).getResultList().size());
        entityManager.getTransaction().commit();

        entityManager.close();
    }
}
