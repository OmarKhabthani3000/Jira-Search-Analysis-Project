package org.hibernate.test.envers;

import java.util.List;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.junit.Test;

public class EnversTest extends TestCase {
  @SuppressWarnings("deprecation")
  private final SessionFactory sessionFactory = new AnnotationConfiguration()
  .addAnnotatedClass(EntityWithCollection.class)
  .setProperty("hibernate.hbm2ddl.auto", "create-drop")
  .setProperty("hibernate.connection.url", "jdbc:h2:mem:test")
  .setProperty("hibernate.connection.user", "sa")
  .setProperty("hibernate.connection.password", "")
  .buildSessionFactory();

  private void executeInTransaction(HibernateCallback callback) throws Exception {
    Session sess = sessionFactory.openSession();
    Transaction tx = sess.beginTransaction();

    try {
      callback.execute(sess);
      tx.commit();
    } catch (Exception e) {
      tx.rollback();
      throw e;
    } finally {
      sess.close();
    }
  }

  private void update(final Object e) throws Exception {
    executeInTransaction(new HibernateCallback() {
      @Override
      public void execute(Session sess) {
        sess.saveOrUpdate(e);
      }
    });
  }

  @Test
  public void testHistory() throws Exception {
    final EntityWithCollection e = new EntityWithCollection();
    update(e);
    Component c1 = new Component();
    c1.setName("c1");
    e.getList().add(c1);
    update(e);

    executeInTransaction(new HibernateCallback() {
      @Override
      public void execute(Session sess) {
        AuditReader reader = AuditReaderFactory.get(sess);
        List<Number> revs = reader.getRevisions(EntityWithCollection.class, e.getId());
        assertEquals(2, revs.size());
        assertEquals(0, reader.find(EntityWithCollection.class, e.getId(), revs.get(0)).getList().size());
        assertEquals(1, reader.find(EntityWithCollection.class, e.getId(), revs.get(1)).getList().size());
      }
    });
  }
}
