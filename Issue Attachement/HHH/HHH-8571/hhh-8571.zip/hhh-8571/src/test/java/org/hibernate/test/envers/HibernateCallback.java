package org.hibernate.test.envers;

import org.hibernate.Session;

public interface HibernateCallback {
  public void execute(Session sess);
}
