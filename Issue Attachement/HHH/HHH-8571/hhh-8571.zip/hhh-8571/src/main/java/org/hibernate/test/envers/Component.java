package org.hibernate.test.envers;

import javax.persistence.Embeddable;

@Embeddable
public class Component {
  private Boolean flag;
  private String name;

  public Boolean getFlag() {
    return flag;
  }

  public void setFlag(Boolean flag) {
    this.flag = flag;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}