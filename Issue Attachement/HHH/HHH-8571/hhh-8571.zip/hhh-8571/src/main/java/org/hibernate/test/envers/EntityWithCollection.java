package org.hibernate.test.envers;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OrderColumn;

import org.hibernate.envers.Audited;

@Entity
@Audited
public class EntityWithCollection {
  private String id;
  private List<Component> list = new ArrayList<Component>();

  @Id
  @GeneratedValue
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  @ElementCollection
  @OrderColumn
  public List<Component> getList() {
    return list;
  }

  public void setList(List<Component> list) {
    this.list = list;
  }
}
