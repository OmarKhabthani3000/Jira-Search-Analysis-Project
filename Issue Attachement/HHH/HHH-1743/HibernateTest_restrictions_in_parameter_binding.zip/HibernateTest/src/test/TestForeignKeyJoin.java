package test;

import java.util.List;
import java.util.Vector;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import datasource.Person;
import datasource.PersonId;

public class TestForeignKeyJoin {

	public static void main(String[] args) throws Exception 
	{
		new TestForeignKeyJoin().startTest();

	}
	
	public void startTest() throws Exception
	{
		Logger root = Logger.getRootLogger();
		root.removeAllAppenders();
		root.addAppender(new ConsoleAppender(new PatternLayout("%d{HH:mm:ss,SSS} %-5p [%c{1}] %m%n")));

		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		List<PersonId> ids = new Vector<PersonId>();
		ids.add(new PersonId("SLAVA1", 10L));
		ids.add(new PersonId("SLAVA2", 20L));
		ids.add(new PersonId("SLAVA3", 30L));
		List<Person> persons = session.createCriteria(Person.class)
			.add(Restrictions.in("id", ids))
			.list();
		System.out.println("SUCCESS");
	}

}
