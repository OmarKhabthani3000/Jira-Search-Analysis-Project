package datasource;

import java.io.Serializable;

public class Person implements Serializable
{
	public PersonId id; 
	
	public Person() {}
}
