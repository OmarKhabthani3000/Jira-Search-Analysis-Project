package datasource;

import java.io.Serializable;

public class PersonId implements Serializable
{
	public String family;
	public Long number;
	
	public PersonId(String family, Long number) 
	{
		this.family = family;
		this.number = number;
	}
	
	public PersonId() {}
}
