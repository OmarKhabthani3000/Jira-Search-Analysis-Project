package org.hibernate.bugs;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class B {

    @Id
    private Integer id;

    private String specialId;

    private String otherData;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSpecialId() {
        return specialId;
    }

    public void setSpecialId(String specialId) {
        this.specialId = specialId;
    }

    public String getOtherData() {
        return otherData;
    }

    public void setOtherData(String otherData) {
        this.otherData = otherData;
    }
}
