package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void testValidateReturnType() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        init(entityManager);

        entityManager.getTransaction().begin();

        boolean exceptionThrown = false;
        try {
            // wrong return type A, should be Result
            List<A> aList = entityManager.createQuery("""
                    select new org.hibernate.bugs.Result(a, b) from A a
                    join B b ON a.bSpecialId = b.specialId
                    """, A.class).getResultList();
        } catch (Exception e) {
            exceptionThrown = true;
            // This is the message that Hibernate 5.6.15 throws
            Assert.assertEquals("Mismatch in requested result type [org.hibernate.bugs.A] and actual result type [org.hibernate.bugs.Result]", e.getMessage());
        } finally {
            entityManager.getTransaction().commit();
            entityManager.close();
        }
        Assert.assertTrue(exceptionThrown);
    }

    private void init(EntityManager entityManager) {
        entityManager.getTransaction().begin();
        entityManager.createNativeQuery("insert into a (id, bSpecialId) values (1, '123')").executeUpdate();
        entityManager.createNativeQuery("insert into b (id, specialId, otherData) values (1, '123', 'otherData')").executeUpdate();
        entityManager.getTransaction().commit();
    }
}
