package org.hibernate.bugs;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class A {

    @Id
    private Integer id;

    private String bSpecialId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer i) {
        this.id = i;
    }

    public String getbSpecialId() {
        return bSpecialId;
    }

    public void setbSpecialId(String bSpecialId) {
        this.bSpecialId = bSpecialId;
    }
}
