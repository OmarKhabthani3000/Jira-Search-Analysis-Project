package hibernate.bug.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("S")
public class SmallProject extends Project<JuniorProjectLeader> {

    private static final long serialVersionUID = 1L;

}
