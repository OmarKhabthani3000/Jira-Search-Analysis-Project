package hibernate.bug.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("J")
public class JuniorProjectLeader extends ProjectLeader<SmallProject> {

    private static final long serialVersionUID = 1L;

}
