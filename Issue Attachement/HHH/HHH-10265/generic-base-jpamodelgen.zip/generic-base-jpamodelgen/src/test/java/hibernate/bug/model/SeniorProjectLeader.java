package hibernate.bug.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("S")
public class SeniorProjectLeader extends ProjectLeader<LargeProject> {

    private static final long serialVersionUID = 1L;

}
