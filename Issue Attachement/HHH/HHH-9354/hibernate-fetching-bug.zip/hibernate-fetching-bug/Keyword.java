package org.jpp.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Transient;

import org.apache.logging.log4j.LogManager;import org.apache.logging.log4j.Logger;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.jpp.domain.quicksearch.KeywordQS;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

@Entity(name = "keywords")
// make a use of secondary for firstName, lastName)
// @SecondaryTable(name = "user", pkJoinColumns = @PrimaryKeyJoinColumn(name =
// "id", referencedColumnName = "CREATOR_ID"))
// @NamedQuery(name = "Person.findByName", query =
// "SELECT u FROM org.jpp.domain.User p WHERE p.id = ?1)")
// @JsonIgnoreProperties({ "sub" ,"supers"})
public class Keyword implements NameAndDescription, Auditing, Mergeable<Keyword> {
	private static final Logger LOGGER = LogManager.getLogger(Keyword.class);

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "KEYWORD_ID")
	private long id; // seems like spring's jpa has issue hanlde "_" between the
						// words

	@Column(name = "NAME", nullable = false)
	private String name;

	@Column(name = "DESCRIPTION", nullable = false)
	private String description;

	
//	
//    
//	
	

	/*
	 * status is set the decide if this realy new object or this object allready
	 * has been created in old system: if status == -1 this objected has just
	 * been created and wont be in the search till someone will edit it. this
	 * happens because the way the old system creates new object after the user
	 * click "add new XXXX" the system creates new object XXXX and then let the
	 * user edit this object
	 * 
	 * i think to change this field to version. and set id of this entity as
	 * keword_id + version this way the system will be able to save draft and
	 * more over to act as version control.
	 */

	@Column(name = "status", nullable = false)
	private Integer status;

	/*
	 * 
	 * 0.2 is a default value of keyword. seems like the old system did some
	 * kind of calculation of how many keyword related to a person using the
	 * wieght field this field doesnt get update in any place in the old system!
	 */

	@Column(name = "weight", nullable = false)
	private double weight;

	@CreatedDate
	@Column(name = "CREATION_DATE", nullable = false)
	private Date creationDate;

	@LastModifiedDate
	@Column(name = "LAST_MODIFIED", nullable = false)
	private Date lastModified;

	@CreatedBy
	@JsonIgnore
	@ManyToOne(optional = true)
	@JoinColumn(name = "CREATOR_ID", referencedColumnName = "ID")
	private User createdBy;

	@LastModifiedBy
	@JsonIgnore
	@ManyToOne(optional = true)
	@JoinColumn(name = "MODIFIER_ID", referencedColumnName = "ID")
	private User modifiedBy;

	
	
	@JsonIgnore
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "keywords_graph", joinColumns = { @JoinColumn(name = "keyword_id2", referencedColumnName = "KEYWORD_ID") }, inverseJoinColumns = { @JoinColumn(name = "keyword_id1", referencedColumnName = "KEYWORD_ID") })
	private Set<Keyword> parents ;
	
	@JsonIgnore
	@ManyToMany(mappedBy = "parents",fetch = FetchType.LAZY)
	private Set<Keyword> childs;

	@JsonIgnore
	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "keywords")
	private Set<Report> reports;

	@JsonIgnore
	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "keywords")
	private Set<Person> persons;

	@Transient
	private Long parentId;


	@JsonIgnore
	public Set<Keyword> getSubKeywords() {
		return childs;
	}

	public void setSubKeywords(Set<Keyword> subKeywords) {
		this.childs = subKeywords;
	}

	public void addSubKeywords(Set<Keyword> subKeywords) {
		if (this.childs == null)
			this.setSubKeywords(subKeywords);
		else
			this.childs.addAll(subKeywords);

		/* keep bi directional relation */ 
		for (Keyword k:subKeywords) {
			k.addParent(this);
			
		}
	}

	@Override
	public Long getModifierId() {
		// TODO Auto-generated method stub
		return this.modifiedBy.getId();
	}

	@Override
	public Long getCreatorId() {
		// TODO Auto-generated method stub
		return this.createdBy.getId();
	}

	/**
	 * @return the keywordId
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param keywordId
	 *            the keywordId to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	/**
	 * @return the weight
	 */
	public double getWeight() {
		return weight;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Keyword other = (Keyword) obj;
		if ((this.name == null) ? (other.name != null) : !this.name
				.equals(other.name)) {
			return false;
		}
		if (!this.lastModified.equals(other.getLastModified())) {
			return false;
		}

		if (!this.creationDate.equals(other.getCreationDate())) {
			return false;
		}

		if (!this.description.equals(other.getDescription())) {
			return false;
		}
		return true;
	}

	/**
	 * @param weight
	 *            the weight to set
	 */
	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	public void setModifiedBy(User modifier) {
		modifiedBy = modifier;

	}

	public void setCreatedBy(User creator) {
		createdBy = creator;

	}

	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @return the lastModified
	 */
	public Date getLastModified() {
		return lastModified;
	}

	/**
	 * @param lastModified
	 *            the lastModified to set
	 */
	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate
	 *            the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the lastNameModifier
	 */
	public String getModifierName() {
		return modifiedBy.getFirstName() + " " + modifiedBy.getLastName();
	}

	/**
	 * @return the firstNameCreator
	 */
	public String getCreatorName() {
		return createdBy.getFirstName() + " " + createdBy.getLastName();
	}

	/**
	 * merge this into entity
	 * 
	 * @return the result of the merge
	 */
	public Keyword mergeInto(Keyword entity, Logger log) {
		// TODO Auto-generated method stub

		
		/* merge description */
		entity.setDescription(entity.getDescription() + "\n[---- description of merged keyword: " + id  + " ----]\n" +  description);
		
		/* merge keywords */
		
//		entity.addSubKeywords(this.getSubKeywords());
		
		for (Keyword  keyword : this.getSubKeywords()) {
			keyword.addParent(entity);

		}
		/* merge reports */

		for (Report report : this.getReports()) {
			report.addKeyword(entity);
			log.debug("report number  " + report.getId());

		}

		/* merge persons */

		for (Person person : this.getPersons()) {
			person.addKeyword(entity);

		}

		return entity;
	}

	public Set<Report> getReports() {
		return reports;
	}

	public void setReports(Set<Report> reports) {
		this.reports = reports;
	}

	public void addReports(Set<Report> reports) {

		if (this.reports == null)
			this.setReports(reports);
		else
			this.reports.addAll(reports);

	}

	public void addReport(Report report) {

		if (this.getReports() == null)
			this.setReports(new HashSet<Report>());

		if (this.getReports().contains(report))
			return;

		this.getReports().add(report);

	}

	public Set<Person> getPersons() {
		return persons;
	}

	public void setPersons(Set<Person> persons) {
		this.persons = persons;
	}

	public void addPerson(Person person) {

		if (this.getPersons() == null)
			this.setPersons(new HashSet<Person>());
		if (this.getPersons().contains(person))
			return;
		this.getPersons().add(person);

		//
	}

	public void addPersons(Set<Person> persons) {

		if (this.getPersons() == null)
			this.setPersons(persons);
		else
			this.getPersons().addAll(persons);

	}
	
	@JsonIgnore
	public ParentKeyword getParentKeyword(){
		if (null == this.getParents())
				return null;
		if (0 == this.getParents().size())
				
			return null;
		Keyword parent = this.getParents().iterator().next();
		return new ParentKeyword(parent.getId(),parent.getName());
		
						
	}
	
	
	
	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public Set<Keyword> getParents() {
		return parents;
	}

	public void setParents(Set<Keyword> parents) {
		this.parents = parents;
		
		
	}
	public void addParent(Keyword keyword) {
		if (this.parents == null)
			this.parents = new HashSet<Keyword>();
		
		this.parents.add(keyword);
		keyword.addChild(this);
	}
	public void addChild(Keyword keyword) {
		if (this.childs == null)
			this.childs = new HashSet<Keyword>();
		if (this.childs.contains(keyword))
				return;
		this.childs.add(keyword);
	}


}
