package org.jpp.specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.metamodel.PluralAttribute;

import org.jpp.domain.quicksearch.ReportQS_;
import org.springframework.data.jpa.domain.Specification;

public class DomainSpecification {

	public static <T> Specification<T> eager() {

	    return new Specification<T>() {

	        @Override
	        public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
	            for (PluralAttribute<? super T, ?, ?> fetch : root.getModel().getPluralAttributes()) {
	                root.fetch(fetch, JoinType.LEFT);
	            }
	            query.distinct(true);
	            return null;
	        }

	    };
	}
	
	public static <T> Specification<T> idIsEqual(final Long id) {

	    return new Specification<T>() {

	        @Override
	        public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
	        	
	        				return cb.equal(root.get("id"),id);
	        
	        }

	    };
	}
}
