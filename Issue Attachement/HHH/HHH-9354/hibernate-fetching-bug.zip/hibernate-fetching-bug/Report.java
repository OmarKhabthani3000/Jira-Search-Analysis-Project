/**
 * 
 */
package org.jpp.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

import org.jsoup.Jsoup;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

/**
 * @author oak
 * 
 */
@Entity(name = "reports")
public class Report implements Serializable, Auditing,JppDbObject {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "REPORT_ID", unique = true, nullable = false)
	private Long id;

	@JsonIgnore
	@OneToOne(cascade = CascadeType.ALL, mappedBy = "report")
	private ReportId report;
	/*
	 * this here for updating the reports_ids table.
	 * 
	 * set json ignore over this field.
	 */

	@Column(name = "txt", nullable = false)
	private String txt;
	
	@Column(name = "cleanTxt")
	private String cleanTxt;

	@CreatedDate
	@Column(name = "CREATION_DATE", nullable = false)
	private Date creationDate;

	@LastModifiedDate
	@Column(name = "LAST_MODIFIED", nullable = false)
	private Date lastModified;

	@Column(name = "status", nullable = false)
	private Integer status;
	
	@CreatedBy
	@JsonIgnore
    @ManyToOne(optional = true)
    @JoinColumn(name="CREATOR_ID", referencedColumnName = "ID")
    private User createdBy;
    
	@LastModifiedBy
    @ManyToOne(optional = true)
    @JoinColumn(name="MODIFIER_ID", referencedColumnName = "ID")
    private User modifiedBy;

	@JsonIgnore
	@OneToMany(mappedBy="reportCommented")
	//TODO make sure comments works good with lazy. @OneToMany(fetch=FetchType.EAGER, mappedBy="reportCommented")
	private Set<ReportComment> comments;

	@JsonIgnore
	@ManyToMany
	@JoinTable(
	      name="reports_projects",
	      joinColumns={@JoinColumn(name="report_id", referencedColumnName="REPORT_ID")},
	      inverseJoinColumns={@JoinColumn(name="project", referencedColumnName="CODE")})
	private List<Project> projects;

	@JsonIgnore
	@ManyToMany
	@JoinTable(
			name="reports_keywords",
			joinColumns={@JoinColumn(name="report_id", referencedColumnName="REPORT_ID")},
			inverseJoinColumns={@JoinColumn(name="keyword_id", referencedColumnName="keyword_id")})
	private Set<Keyword> keywords;
	
	
	@JsonIgnore
	@ManyToMany
	@JoinTable(name = "reports_periods", joinColumns = { @JoinColumn(name = "report_id", referencedColumnName = "REPORT_ID") }, inverseJoinColumns = { @JoinColumn(name = "period_id", referencedColumnName = "PERIOD_ID") })
	private Set<Period> periods;
	
	@JsonIgnore
	@ManyToMany
	@JoinTable(name = "reports_places", joinColumns = { @JoinColumn(name = "report_id", referencedColumnName = "REPORT_ID") }, inverseJoinColumns = { @JoinColumn(name = "place_id", referencedColumnName = "PLACE_ID") })
	private Set<Place> places;
	
	@JsonIgnore
	@ManyToMany
	@JoinTable(name = "reports_tribes", joinColumns = { @JoinColumn(name = "report_id", referencedColumnName = "REPORT_ID") }, inverseJoinColumns = { @JoinColumn(name = "tribe_id", referencedColumnName = "TRIBE_ID") })
	private Set<Tribe> tribes;
	
//	@JsonIgnore
//	@ManyToMany
//	@JoinTable(name = "reports_sources", joinColumns = { @JoinColumn(name = "report_id", referencedColumnName = "REPORT_ID") }, inverseJoinColumns = { @JoinColumn(name = "source_id", referencedColumnName = "SOURCE_ID") })
//	private Set<Source> sources;
	
	
	@OneToMany(mappedBy = "report",cascade = {CascadeType.ALL})//,fetch=FetchType.EAGER)
	private Set<ReportSourceGraph> sources;
	
	
	@JsonIgnore
	@ManyToMany
	@JoinTable(
			name="persons_reports",
			joinColumns={@JoinColumn(name="report_id", referencedColumnName="REPORT_ID")},
			inverseJoinColumns={@JoinColumn(name="person_id", referencedColumnName="person_id")})
	private Set<Person> persons;

	public Set<Keyword> getKeywords() {
		return keywords;
	}

	public void setKeywords(Set<Keyword> keywords) {
		this.keywords = keywords;
	
	}
	public void addKeyword(Keyword keyword) {
		if (this.keywords == null)
			this.keywords = new HashSet<Keyword>();
		
		this.keywords.add(keyword);
		keyword.addReport(this);
	}
	public void addPerson(Person person) {
		if (this.persons == null)
			this.persons = new HashSet<Person>();
		
		this.persons.add(person);
		person.addReport(this);
	}

	public Set<ReportComment> getComments() {
		return comments;
	}

	public void setComments(Set<ReportComment> comments) {
		this.comments = comments;
	}
	
	// @ManyToMany
	// @JoinTable(
	// name="EMP_PROJ",
	// joinColumns={@JoinColumn(name="EMP_ID", referencedColumnName="ID")},
	// inverseJoinColumns={@JoinColumn(name="PROJ_ID",
	// referencedColumnName="ID")})
	// private List<Project> projects;
	/*
	 * those fields are here for output to user in a nice way:)
	 */
	@Transient
	private String creatorName;

	@Transient
	private String modifierName;
	
	/**
	 * @return the lastNameModifier
	 */
	public String getModifierName() {
		if (modifiedBy == null) {
			return "";
		}
		return modifiedBy.getFirstName() + " " + modifiedBy.getLastName();
	}

	/**
	 * @param lastNameModifier
	 *            the lastNameModifier to set
	 */
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	/**
	 * @param lastNameCreator
	 *            the lastNameCreator to set
	 */
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	/**
	 * @return the firstNameCreator
	 */

	public String getCreatorName() {
		if (createdBy == null) {
			return "";
		}
		return createdBy.getFirstName() + " " + createdBy.getLastName();
	}
	
	@Override
	public Long getModifierId() {
		// TODO Auto-generated method stub
		if (modifiedBy == null) {
			return 0L;
		}
		return this.modifiedBy.getId();
	}

	@Override
	public Long getCreatorId() {
		// TODO Auto-generated method stub
		if (createdBy == null) {
			return 0L;
		}
		return this.createdBy.getId();
	}


	/**
	 * @return the id
	 */

	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the txt
	 */

	public String getTxt() {
		return txt;
	}

	/**
	 * @param txt
	 *            the txt to set
	 */
	public void setTxt(String txt) {
		this.txt = txt;
		setCleanTxt(Jsoup.parse(txt).text());
	}

	/**
	 * @return the creationDate
	 */

	public Date getCreationDate() {
		return creationDate;
	}
	
	public String getCleanTxt() {
		return cleanTxt;
	}

	public void setCleanTxt(String cleanTxt) {
		this.cleanTxt = cleanTxt;
	}

	/**
	 * @param creationDate
	 *            the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the lastModified
	 */

	public Date getLastModified() {
		return lastModified;
	}

	/**
	 * @param lastModified
	 *            the lastModified to set
	 */
	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}

	/**
	 * @return the status
	 */

	public Integer getStatus() {
		return status;
	}

	/**
	 * @param status 0 is default? public? What -1 is .. ?!!
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	public ReportId getReport() {
		return report;
	}

	public void setReport(ReportId report) {
		this.report = report;
		report.setReport(this);
	}

	public void setModifiedBy(User modifier) {
		modifiedBy = modifier;
		
	}

	public void setCreatedBy(User creator) {
		createdBy = creator;
		
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public List<Project> getProjects() {
		return projects;
	}

	public void setProjects(List<Project> projects) {
		this.projects = projects;
	}

	public Set<Person> getPersons() {
		return persons;
	}

	public void setPersons(Set<Person> persons) {
		this.persons = persons;
	}

	public Set<Period> getPeriods() {
		return periods;
	}

	public void setPeriods(Set<Period> periods) {
		this.periods = periods;
	}

	public Set<Place> getPlaces() {
		return places;
	}

	public void setPlaces(Set<Place> places) {
		this.places = places;
	}

	public Set<Tribe> getTribes() {
		return tribes;
	}

	public void setTribes(Set<Tribe> tribes) {
		this.tribes = tribes;
	}

	
	 public ReportSourceGraph addSource(Source source,String volume,String page,String line){
		    ReportSourceGraph rp = ReportSourceGraph.createNewRelation().withReport(this)
		    		.withSource(source)
		    		.withVolume(volume)
		    		.withPage(page)
		    		.withLine(line);

		 
		    this.sources.add(rp);
		    return rp;
		    //TODO check if this link can be NON bi directional.
//		    employee.getProjects().add(association);
		  }
	 
	public Set<ReportSourceGraph> getSources() {
		return sources;
	}

	public void setSources(Set<ReportSourceGraph> sources) {
		this.sources = sources;
	}
	
	
	
	/*

	@Override
	public long getModifierId() {
		// TODO Auto-generated method stub
		return modifiedBy.getId();
	}
	*/

}