package org.jpp.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import org.jpp.domain.security.ProjectPermission;
import org.springframework.data.annotation.CreatedDate;

@Entity(name = "projects")
public class Project implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PROJECT_ID")
	private long id;

	@Column(name = "CODE", nullable = false)
	private String code;
	
	@Column(name = "DESCRIPTION", nullable = false)
	private String description;
	
	@CreatedDate
	@Column(name = "CREATION_DATE", nullable = false)
	private Date creationDate;

	@JsonIgnore
	@OneToMany(mappedBy = "id.proj", cascade = {CascadeType.ALL}, orphanRemoval=true)
	private List<ProjectPermission> permissions;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public List<ProjectPermission> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<ProjectPermission> permissions) {
		this.permissions = permissions;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

}
