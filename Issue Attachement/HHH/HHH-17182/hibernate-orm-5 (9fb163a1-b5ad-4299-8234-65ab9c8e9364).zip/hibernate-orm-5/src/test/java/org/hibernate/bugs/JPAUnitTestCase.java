package org.hibernate.bugs;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import static org.junit.Assert.assertNotNull;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh17182Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		final Post post = new Post();
		post.setTitle("Post");
		post.addPostDetails(new PostDetails("Test"));

		entityManager.persist(post);
		entityManager.getTransaction().commit();

		final Object[] result =
				entityManager
						.createQuery("select 1 as scalar, p.postDetails as entity from Post p", Object[].class).getSingleResult();
		assertNotNull("Get PostDetails using association", result[1]);

		final Object[] result2 =
				entityManager
						.createQuery("select 1 as scalar, pd as entity from Post p join p.postDetails pd", Object[].class)
						.getSingleResult();
		assertNotNull("Get PostDetails using join", result2[1]);

		final Object[] result3 =
				entityManager
						.createQuery("select 1 as scalar, pd.post as entity from PostDetails pd", Object[].class).getSingleResult();
		assertNotNull("Get Post using association", result3[1]);

		final Object[] result4 =
				entityManager
						.createQuery("select 1 as scalar, p as entity from PostDetails pd join pd.post p", Object[].class)
						.getSingleResult();
		assertNotNull("Get Post using join", result4[1]);

		entityManager.close();
	}
}
