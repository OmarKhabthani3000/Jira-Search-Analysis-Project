package org.hibernate.test;

import java.util.List;
import javax.persistence.*;
import junit.framework.Assert;
import org.junit.Test;

public class UnitTest {
	private static EntityManager em;
	private static EntityManagerFactory factory;
	
	public static final String DIVISION_CODE = "AA";
	public static final Long PRODUCT_ID = 1L;
	public static final String RETAILER_CODE = "K43A";
	public static final String SEPARATOR = "********************************************************************************";
	
	@Test
	@SuppressWarnings( "unchecked" )
	public void testHhhXxxx( ) {
		boolean success = false;
		
		try {
			/*
			 *  Case 1:  the HQL query relies on a "join" clause which causes Hibernate 
			 *  to generate SQL with an inner join.  The paramters bound are entity objects, 
			 *  one of which has a compound primary key.  For this entity, the SQL is 
			 *  generated with the columns in one order while the parameter values are 
			 *  bound in a different order.  Since the two fields in the compound key 
			 *  are both strings, this does not cause an error but it does leave us with 
			 *  an empty result set.
			 */
			Query query = em.createQuery( "from Retailer where retailerCode = '" + UnitTest.RETAILER_CODE + "' and divisionCode = '" + UnitTest.DIVISION_CODE + "'" );
			org.hibernate.test.Retailer retailer = ( org.hibernate.test.Retailer )query.getSingleResult( );
			
			query = em.createQuery( "from Product where productId = " + UnitTest.PRODUCT_ID );
			org.hibernate.test.Product product = ( org.hibernate.test.Product )query.getSingleResult( );
			
			query = em.createNamedQuery( "MarketArea1.testCase1" );
			query.setParameter( "retailer", retailer );
			query.setParameter( "product", product );
			
			System.out.println( UnitTest.SEPARATOR );
			System.out.println( "Test Case 1:" );
			List<org.hibernate.test.MarketArea1> results1 = query.getResultList( );
			System.out.println( UnitTest.SEPARATOR );
			
			success = ( results1.size( ) > 0 );
			
			/*
			 *  Case 2:  the HQL query was changed to force the query translator to build 
			 *  the join in the where clause.  Now you will notice that the columns of the 
			 *  parent and child are mismatched.
			 */			
			query = em.createNamedQuery( "MarketArea1.testCase2" );
			query.setParameter( "retailerCode", retailer.getRetailerCode( ) );
			query.setParameter( "product", product );
			
			System.out.println( UnitTest.SEPARATOR );
			System.out.println( "Test Case 2:" );
			List<org.hibernate.test.MarketArea1> results2 = query.getResultList( );
			System.out.println( UnitTest.SEPARATOR );
			
			success = success && ( results2.size( ) > 0 );
			
			/*
			 *  Case 3:  this is the same as case 1 except that it explicitly sets the 
			 *  referenceColumName field of the @JoinColumn annotation.  This workaround 
			 *  proved successful for Oracle but does not alter how the query translator 
			 *  builds for MySQL.
			 */
			query = em.createNamedQuery( "MarketArea2.testCase1" );
			query.setParameter( "retailer", retailer );
			query.setParameter( "product", product );
			
			System.out.println( UnitTest.SEPARATOR );
			System.out.println( "Test Case 3:" );
			List<org.hibernate.test.MarketArea2> results3 = query.getResultList( );
			System.out.println( UnitTest.SEPARATOR );
			
			success = success && ( results3.size( ) > 0 );
		} catch( Exception e ) {
			e.printStackTrace( );
		}
		
		Assert.assertTrue( success );
	}
	
	static {
		factory = Persistence.createEntityManagerFactory( "test" );
		em = factory.createEntityManager( );
	}
}
