package org.hibernate.test;

import javax.persistence.*;

@Entity
@Table( name = "PRODUCT" )
public class Product {
	@Id
	@Column( name = "PRODUCT_ID" )
	private Long productId;
	public Long getProductId( ) { return this.productId; }
	public void setProductId( Long value ) { this.productId = value; }
	
	@Column( name = "NAME" )
	private String name;
	public String getName( ) { return this.name; }
	public void setName( String value ) { this.name = value; }
}
