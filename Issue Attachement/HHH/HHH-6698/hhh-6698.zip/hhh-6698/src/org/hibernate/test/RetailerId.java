package org.hibernate.test;

import java.io.Serializable;
import javax.persistence.*;

@Embeddable
public class RetailerId implements Serializable {
	private static final long serialVersionUID = -7236415867149059556L;
	
	@Column( name = "RETAILER_CODE", length = 4 )
	private String retailerCode;
	public String getRetailerCode( ) { return this.retailerCode; }
	public void setRetailerCode( String value ) { this.retailerCode = value; }
	
	@Column( name = "DIVISION_CODE", length = 2 )
	private String divisionCode;
	public String getDivisionCode( ) { return this.divisionCode; }
	public void setDivisionCode( String value ) { this.divisionCode = value; }
	
	@Override
	public int hashCode( ) {
		return this.toString( ).hashCode( );
	}
	
	@Override
	public boolean equals( Object obj ) {
		if( obj == null ) return false;
		if( !( obj instanceof RetailerId ) ) return false;
		if( this.getDivisionCode( ) == null ) return false;
		if( this.getRetailerCode( ) == null ) return false;
		
		RetailerId id = ( RetailerId )obj;
		
		return ( this.getDivisionCode( ).equals( id.getDivisionCode( ) ) && 
				 this.getRetailerCode( ).equals( id.getRetailerCode( ) ) );
	}
	
	@Override
	public String toString( ) {
		StringBuffer buf = new StringBuffer( this.getClass( ).getSimpleName( ) );
		buf.append( "[retailerCode:" );
		buf.append( ( this.getRetailerCode( ) == null ) ? "null" : this.getRetailerCode( ) );
		buf.append( ";divisionCode:" );
		buf.append( ( this.getDivisionCode( ) == null ) ? null : this.getDivisionCode( ) );
		buf.append( "]" );
		
		return buf.toString( );
	}
}
	
