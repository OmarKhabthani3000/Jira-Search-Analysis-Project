package org.hibernate.test;

import java.util.List;
import javax.persistence.*;

@Entity
@Table( name = "MARKET_AREA" )
@NamedQueries( {
	@NamedQuery(
		name = "MarketArea2.testCase1",
		query = "select " + 
				"m " + 
				"from " + 
				"MarketArea2 m " + 
				" join m.retailerProducts rp " + 
				"where " + 
				"rp.retailer = :retailer and " + 
				"rp.product = :product"
	)
} )
public class MarketArea2 {
	@Id
	@Column( name = "MARKET_AREA_ID" )
	private Long marketAreaId;
	public Long getMarketAreaId( ) { return this.marketAreaId; }
	public void setMarketAreaId( Long value ) { this.marketAreaId = value; }
	
	@Column( name = "NAME", length = 50 )
	private String name;
	public String getName( ) { return this.name; }
	public void setName( String value ) { this.name = value; }
	
	@OneToMany( cascade = CascadeType.ALL, mappedBy = "marketArea" )
	List<RetailerProduct2> retailerProducts;
	public List<RetailerProduct2> getRetailerProducts( ) { return this.retailerProducts; }
	public void setRetailerProducts( List<RetailerProduct2> value ) { this.retailerProducts = value; }
}
