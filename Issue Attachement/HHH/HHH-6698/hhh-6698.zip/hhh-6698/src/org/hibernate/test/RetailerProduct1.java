package org.hibernate.test;

import javax.persistence.*;

@Entity
@Table( name = "RETAILER_PRODUCT" )
@IdClass( org.hibernate.test.RetailerProductId1.class )
public class RetailerProduct1 {
	@Id
	private Retailer retailer;
	public Retailer getRetailer( ) { return this.retailer; }
	public void setRetailer( Retailer value ) { this.retailer = value; }
	
	@Id
	private Product product;
	public Product getProduct( ) { return this.product; }
	public void setProduct( Product value ) { this.product = value; }
	
	@ManyToOne
	@JoinColumn( name = "MARKET_AREA_ID", insertable = false, updatable = false )
	private MarketArea1 marketArea;
	public MarketArea1 getMarketArea( ) { return this.marketArea; }
	public void setMarketArea( MarketArea1 value ) { this.marketArea = value; }
}
