package org.hibernate.test;

import javax.persistence.*;

@Entity
@Table( name = "RETAILER" )
@IdClass( org.hibernate.test.RetailerId.class )
public class Retailer {
	@Id
	private String retailerCode;
	public String getRetailerCode( ) { return this.retailerCode; }
	public void setRetailerCode( String value ) { this.retailerCode = value; }
	
	@Id
	private String divisionCode;
	public String getDivisionCode( ) { return this.divisionCode; }
	public void setDivisionCode( String value ) { this.divisionCode = value; }
	
	@Column( name = "NAME" )
	private String name;
	public String getName( ) { return this.name; }
	public void setName( String value ) { this.name = value; }
}
