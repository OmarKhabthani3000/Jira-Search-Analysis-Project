package org.hibernate.test;

import java.util.List;
import javax.persistence.*;

@Entity
@Table( name = "MARKET_AREA" )
@NamedQueries( {
	@NamedQuery(
		name = "MarketArea1.testCase1",
		query = "select " + 
				"m " + 
				"from " + 
				"MarketArea1 m " + 
				" join m.retailerProducts rp " + 
				"where " + 
				"rp.retailer = :retailer and " + 
				"rp.product = :product"
	),
	@NamedQuery(
			name = "MarketArea1.testCase2",
			query = "select " + 
					"m " + 
					"from " + 
					"MarketArea1 m " + 
					" join m.retailerProducts rp " + 
					"where " + 
					"rp.retailer.retailerCode = :retailerCode and " + 
					"rp.product = :product"
		)
} )
public class MarketArea1 {
	@Id
	@Column( name = "MARKET_AREA_ID" )
	private Long marketAreaId;
	public Long getMarketAreaId( ) { return this.marketAreaId; }
	public void setMarketAreaId( Long value ) { this.marketAreaId = value; }
	
	@Column( name = "NAME", length = 50 )
	private String name;
	public String getName( ) { return this.name; }
	public void setName( String value ) { this.name = value; }
	
	@OneToMany( cascade = CascadeType.ALL, mappedBy = "marketArea" )
	List<RetailerProduct1> retailerProducts;
	public List<RetailerProduct1> getRetailerProducts( ) { return this.retailerProducts; }
	public void setRetailerProducts( List<RetailerProduct1> value ) { this.retailerProducts = value; }
}
