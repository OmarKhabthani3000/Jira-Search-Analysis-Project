package org.hibernate.test;

import java.io.Serializable;
import javax.persistence.*;

@Embeddable
public class RetailerProductId1 implements Serializable {
	private static final long serialVersionUID = -8995046346525962546L;
	
	@ManyToOne
	@JoinColumns( {
		@JoinColumn( name = "RETAILER_CODE", insertable = false, updatable = false ), 
		@JoinColumn( name = "DIVISION_CODE", insertable = false, updatable = false )
	} )
	private Retailer retailer;
	public Retailer getRetailer( ) { return this.retailer; }
	public void setRetailer( Retailer value ) { this.retailer = value; }
	
	@ManyToOne
	@JoinColumn( name = "PRODUCT_ID", insertable = false, updatable = false )
	private Product product;
	public Product getProduct( ) { return this.product; }
	public void setProduct( Product value ) { this.product = value; }
	
	@Override
	public int hashCode( ) {
		return this.toString( ).hashCode( );
	}
	
	@Override
	public boolean equals( Object obj ) {
		if( obj == null ) return false;
		if( !( obj instanceof RetailerProductId1 ) ) return false;
		if( this.getProduct( ) == null ) return false;
		if( this.getRetailer( ) == null ) return false;
		
		RetailerProductId1 id = ( RetailerProductId1 )obj;
		
		return ( this.getProduct( ).equals( id.getProduct( ) ) && 
				 this.getRetailer( ).equals( id.getRetailer( ) ) );
	}
	
	@Override
	public String toString( ) {
		StringBuffer buf = new StringBuffer( this.getClass( ).getSimpleName( ) );
		buf.append( "[retailerCode:" );
		buf.append( ( this.getRetailer( ) == null || this.getRetailer( ).getRetailerCode( ) == null ) ? "null" : this.getRetailer( ).getRetailerCode( ) );
		buf.append( ";divisionCode:" );
		buf.append( ( this.getRetailer( ) == null || this.getRetailer( ).getDivisionCode( ) == null ) ? "null" : this.getRetailer( ).getDivisionCode( ) );
		buf.append( ";productId:" );
		buf.append( ( this.getProduct( ) == null || this.getProduct( ).getProductId( ) == null ) ? "null" : this.getProduct( ).getProductId( ) );
		buf.append( "]" );
		
		return buf.toString( );
	}
}
