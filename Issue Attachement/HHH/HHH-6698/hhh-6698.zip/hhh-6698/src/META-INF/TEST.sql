--  Test case for MySQL
create database TEST;
use TEST;

create table MARKET_AREA (
    MARKET_AREA_ID integer not null, 
    NAME varchar( 30 ), 
    constraint PK_MARKET_AREA primary key( MARKET_AREA_ID ) 
);

insert into MARKET_AREA( MARKET_AREA_ID, NAME ) values( 1, 'Area #1' );
insert into MARKET_AREA( MARKET_AREA_ID, NAME ) values( 2, 'Area #2' );
insert into MARKET_AREA( MARKET_AREA_ID, NAME ) values( 3, 'Area #3' );

create table RETAILER (
    RETAILER_CODE char( 4 ), 
    DIVISION_CODE char( 2 ), 
    NAME varchar( 50 ), 
    constraint PK_RETAILER primary key( RETAILER_CODE, DIVISION_CODE ) 
);

insert into RETAILER( RETAILER_CODE, DIVISION_CODE, NAME ) values( 'K43A', 'AA', 'Really Big Co.' );
insert into RETAILER( RETAILER_CODE, DIVISION_CODE, NAME ) values( 'M39V', 'AA', 'Enormous Stores, Inc.' );
insert into RETAILER( RETAILER_CODE, DIVISION_CODE, NAME ) values( 'OS8W', 'BB', 'Gigantic Comglomerate, Ltd.' );

create table PRODUCT ( 
    PRODUCT_ID integer not null, 
    NAME varchar( 50 ) not null, 
    constraint PK_PRODUCT primary key( PRODUCT_ID ) 
);

insert into PRODUCT( PRODUCT_ID, NAME ) values( 1, 'Widget' );
insert into PRODUCT( PRODUCT_ID, NAME ) values( 2, 'Super Widget' );
insert into PRODUCT( PRODUCT_ID, NAME ) values( 3, 'Mini Widget' );
insert into PRODUCT( PRODUCT_ID, NAME ) values( 4, 'Micro Widget' );
insert into PRODUCT( PRODUCT_ID, NAME ) values( 5, 'Widget Cleaner' );
insert into PRODUCT( PRODUCT_ID, NAME ) values( 6, 'Widget Repair Kit' );
insert into PRODUCT( PRODUCT_ID, NAME ) values( 7, 'Widget Cover' );

create table RETAILER_PRODUCT ( 
    RETAILER_CODE char( 4 ) not null, 
    DIVISION_CODE char( 2 ) not null, 
    PRODUCT_ID integer not null, 
    MARKET_AREA_ID integer not null, 
    constraint PK_MARKET_AREA_RETAILER_PRODUCT primary key( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID ), 
    constraint FK_MARKET_AREA_RETAILER_PRODUCT_MARKET_AREA foreign key( MARKET_AREA_ID ) references MARKET_AREA( MARKET_AREA_ID ), 
    constraint FK_MARKET_AREA_RETAILER_PRODUCT_RETAILER foreign key( RETAILER_CODE, DIVISION_CODE ) references RETAILER( RETAILER_CODE, DIVISION_CODE ), 
    constraint FK_MARKET_AREA_RETAILER_PRODUCT_PRODUCT foreign key( PRODUCT_ID ) references PRODUCT( PRODUCT_ID ) 
);

insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'K43A', 'AA', 1, 1 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'K43A', 'AA', 2, 1 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'K43A', 'AA', 3, 1 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'K43A', 'AA', 4, 1 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'K43A', 'AA', 5, 2 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'K43A', 'AA', 6, 2 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'K43A', 'AA', 7, 2 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'M39V', 'AA', 1, 1 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'M39V', 'AA', 2, 1 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'M39V', 'AA', 3, 1 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'M39V', 'AA', 4, 2 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'M39V', 'AA', 5, 2 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'M39V', 'AA', 6, 3 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'M39V', 'AA', 7, 3 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'OS8W', 'BB', 1, 3 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'OS8W', 'BB', 2, 3 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'OS8W', 'BB', 3, 3 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'OS8W', 'BB', 4, 1 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'OS8W', 'BB', 5, 1 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'OS8W', 'BB', 6, 2 );
insert into RETAILER_PRODUCT( RETAILER_CODE, DIVISION_CODE, PRODUCT_ID, MARKET_AREA_ID ) values( 'OS8W', 'BB', 7, 2 );

commit;
