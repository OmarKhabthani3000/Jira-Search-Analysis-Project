package org.hibernate.bugs.activity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import java.io.Serializable;


@Entity
class FileAttributeViewItem implements Serializable {

    @Id 
    Long userId;

    
    Long attributeId;

}
