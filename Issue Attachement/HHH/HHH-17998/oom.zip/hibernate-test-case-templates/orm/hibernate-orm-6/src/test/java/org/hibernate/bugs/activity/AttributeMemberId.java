package org.hibernate.bugs.activity;

import jakarta.persistence.Embeddable;
import jakarta.persistence.FetchType;
import jakarta.persistence.ManyToOne;

import java.io.Serializable;

@Embeddable
public class AttributeMemberId implements Serializable {
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Member member;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Attribute attribute;
}
