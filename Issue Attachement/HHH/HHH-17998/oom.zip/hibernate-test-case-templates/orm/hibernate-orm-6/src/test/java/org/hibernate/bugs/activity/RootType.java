package org.hibernate.bugs.activity;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;

@Entity


public class RootType {

    @EmbeddedId
    private RootTypeId id;


}
