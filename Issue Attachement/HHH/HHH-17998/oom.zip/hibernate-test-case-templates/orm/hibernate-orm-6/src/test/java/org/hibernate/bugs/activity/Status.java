package org.hibernate.bugs.activity;

public enum Status {

    A(null),

    B(A);

    private final Status previous;

    Status(Status previous) {
        this.previous = previous;
    }


}
