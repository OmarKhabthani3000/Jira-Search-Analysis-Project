package org.hibernate.bugs.activity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.hibernate.annotations.Immutable;

@Entity

@Immutable
public class AttributeMember  {

    @Id
    private AttributeMemberId id;

    
    private String memberName;

}
