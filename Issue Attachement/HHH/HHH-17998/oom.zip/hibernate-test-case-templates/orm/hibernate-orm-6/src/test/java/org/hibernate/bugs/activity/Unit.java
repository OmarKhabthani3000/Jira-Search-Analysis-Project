package org.hibernate.bugs.activity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import java.io.Serializable;

@Entity
public class Unit implements Serializable {

    @Id
    Long orgStructureId;

    Long ancestorId;

}
