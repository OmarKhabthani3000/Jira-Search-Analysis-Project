package org.hibernate.bugs.activity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import java.io.Serializable;

@Entity
public class FolderTypeAttributeViewItem implements Serializable {

    @Id 
    Long userId;

    
    Long attributeId;

    
    Long orgStructureId;

    
    Long typeId;
}
