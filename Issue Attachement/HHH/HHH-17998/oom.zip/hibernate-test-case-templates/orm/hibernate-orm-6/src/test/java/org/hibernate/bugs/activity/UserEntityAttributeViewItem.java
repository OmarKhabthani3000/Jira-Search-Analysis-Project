package org.hibernate.bugs.activity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import java.io.Serializable;
import java.util.UUID;


@Entity
class UserEntityAttributeViewItem implements Serializable {

    @Id 
    Long userId;

    
    Long attributeId;

    
    UUID entityIdUuid;

    
    String entityIdText;

    
    String entityModule;

    
    String entityType;
}
