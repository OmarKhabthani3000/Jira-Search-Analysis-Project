package org.hibernate.bugs.activity;

import jakarta.persistence.*;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import java.util.Collection;
import java.util.UUID;

@Entity
public class Root {

    @Id

    private UUID id;

    
    private int key;

    
    private String type;

    @Enumerated(EnumType.STRING)
    private Status status;


    private Long creatorOrganizationId;




    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true, mappedBy = "id.activity")
    @Fetch(FetchMode.SELECT)
    private Collection<RootType> types;

    
    






















    
    



}
