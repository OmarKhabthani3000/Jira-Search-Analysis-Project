package org.hibernate.bugs.activity;

import jakarta.persistence.Embeddable;
import jakarta.persistence.FetchType;
import jakarta.persistence.ManyToOne;

import java.io.Serializable;


@Embeddable
public class RootTypeId implements Serializable {

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Root activity;

    
    private Long type;


}
