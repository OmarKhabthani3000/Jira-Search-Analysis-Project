package org.hibernate.bugs.activity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import java.io.Serializable;


@Entity
class FileTypeAttributeViewItem implements Serializable {

    @Id 
    Long userId;

    
    Long attributeId;

    
    Long typeId;
}
