/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing members and
 * limitations under the License.
 */
package org.hibernate.bugs;

import jakarta.persistence.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.bugs.activity.Root;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 *
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	public static <T> Class<T> getClass(String className) {
		try {
			return (Class<T>) Class.forName(className, false, Thread.currentThread().getContextClassLoader());
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	public static URL getResource(String name) {
		return Thread.currentThread().getContextClassLoader().getResource(name);
	}

	public static List<Class> getClassesByPackage(String packageName) {
		List<Class> classes = new ArrayList<>();

		try {
			final String packagePath = packageName.replace('.', File.separatorChar);
			final String javaClassExtension = ".class";
			try (Stream<Path> allPaths = Files.walk(Paths.get(getResource(packagePath).toURI()))) {
				allPaths.filter(Files::isRegularFile).forEach(file -> {
					final String path = file.toString().replace(File.separatorChar, '.');
					final String name = path.substring(
							path.indexOf(packageName),
							path.length() - javaClassExtension.length()
					);
					classes.add(getClass(name));
				});
			}
		} catch (URISyntaxException | IOException e) {
			throw new IllegalArgumentException(e);
		}

		return classes;
	}
	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		List<Class> entityClasses= getClassesByPackage(Root.class.getPackageName());
		return entityClasses.toArray(new Class[0]);
	}

	// If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
	@Override
	protected String[] getMappings() {
		return new String[] {
//				"Foo.hbm.xml",
//				"Bar.hbm.xml"
		};
	}
	// If those mappings reside somewhere other than resources/org/hibernate/test, change this.
	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/test/";
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );

		configuration.setProperty( AvailableSettings.SHOW_SQL, Boolean.TRUE.toString() );
		configuration.setProperty( AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString() );
		//configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, "true" );
	}

	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		// BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		Query query = s.createQuery("""
                select count(root)
                from Root root
                where root.type = ?1 and root.status <> ?2 and (exists (select 1
                from FileAttributeViewItem fileAttributeViewItem
                where fileAttributeViewItem.userId = ?3 and exists (select 1
                from AttributeMember attributeMember
                where attributeMember.id.attribute.id = fileAttributeViewItem.attributeId and attributeMember.memberName = ?4)) or exists (select 1
                from FileTypeAttributeViewItem fileTypeAttributeViewItem
                where fileTypeAttributeViewItem.userId = ?5 and exists (select 1
                from AttributeMember attributeMember
                where attributeMember.id.attribute.id = fileTypeAttributeViewItem.attributeId and attributeMember.memberName = ?6) and exists (select 1
                from FlatType flatType
                where exists (select 1
                from root.types as root_types_0
                where flatType.typeId = root_types_0.id.type) and flatType.ancestorId = fileTypeAttributeViewItem.typeId)) or (exists (select 1
                from FolderAttributeViewItem folderAttributeViewItem
                where folderAttributeViewItem.userId = ?7 and exists (select 1
                from AttributeMember attributeMember
                where attributeMember.id.attribute.id = folderAttributeViewItem.attributeId and attributeMember.memberName = ?8) and exists (select 1
                from Unit unit
                where unit.orgStructureId = root.creatorOrganizationId and unit.ancestorId = folderAttributeViewItem.orgStructureId)) or exists (select 1
                from FolderTypeAttributeViewItem folderTypeAttributeViewItem
                where folderTypeAttributeViewItem.userId = ?9 and exists (select 1
                from AttributeMember attributeMember
                where attributeMember.id.attribute.id = folderTypeAttributeViewItem.attributeId and attributeMember.memberName = ?10) and exists (select 1
                from Unit unit
                where unit.orgStructureId = root.creatorOrganizationId and unit.ancestorId = folderTypeAttributeViewItem.orgStructureId) and exists (select 1
                from FlatType flatType
                where exists (select 1
                from root.types as root_types_0
                where flatType.typeId = root_types_0.id.type) and flatType.ancestorId = folderTypeAttributeViewItem.typeId))) or exists (select 1
                from UserEntityAttributeViewItem userEntityAttributeViewItem
                where userEntityAttributeViewItem.userId = ?11 and exists (select 1
                from AttributeMember attributeMember
                where attributeMember.id.attribute.id = userEntityAttributeViewItem.attributeId and attributeMember.memberName = ?12) and (userEntityAttributeViewItem.entityType = ?13 and userEntityAttributeViewItem.entityModule = ?14 and userEntityAttributeViewItem.entityIdUuid = root.id)) or (exists (select 1
                from FileAttributeViewItem fileAttributeViewItem
                where fileAttributeViewItem.userId = ?15 and exists (select 1
                from AttributeMember attributeMember
                where attributeMember.id.attribute.id = fileAttributeViewItem.attributeId and attributeMember.memberName = concat(concat(?16,?17),root.type))) or exists (select 1
                from FileTypeAttributeViewItem fileTypeAttributeViewItem
                where fileTypeAttributeViewItem.userId = ?18 and exists (select 1
                from AttributeMember attributeMember
                where attributeMember.id.attribute.id = fileTypeAttributeViewItem.attributeId and attributeMember.memberName = concat(concat(?19,?20),root.type)) and exists (select 1
                from FlatType flatType
                where exists (select 1
                from root.types as root_types_0
                where flatType.typeId = root_types_0.id.type) and flatType.ancestorId = fileTypeAttributeViewItem.typeId)) or (exists (select 1
                from FolderAttributeViewItem folderAttributeViewItem
                where folderAttributeViewItem.userId = ?21 and exists (select 1
                from AttributeMember attributeMember
                where attributeMember.id.attribute.id = folderAttributeViewItem.attributeId and attributeMember.memberName = concat(concat(?22,?23),root.type)) and exists (select 1
                from Unit unit
                where unit.orgStructureId = root.creatorOrganizationId and unit.ancestorId = folderAttributeViewItem.orgStructureId)) or exists (select 1
                from FolderTypeAttributeViewItem folderTypeAttributeViewItem
                where folderTypeAttributeViewItem.userId = ?24 and exists (select 1
                from AttributeMember attributeMember
                where attributeMember.id.attribute.id = folderTypeAttributeViewItem.attributeId and attributeMember.memberName = concat(concat(?25,?26),root.type)) and exists (select 1
                from Unit unit
                where unit.orgStructureId = root.creatorOrganizationId and unit.ancestorId = folderTypeAttributeViewItem.orgStructureId) and exists (select 1
                from FlatType flatType
                where exists (select 1
                from root.types as root_types_0
                where flatType.typeId = root_types_0.id.type) and flatType.ancestorId = folderTypeAttributeViewItem.typeId))) or exists (select 1
                from UserEntityAttributeViewItem userEntityAttributeViewItem
                where userEntityAttributeViewItem.userId = ?27 and exists (select 1
                from AttributeMember attributeMember
                where attributeMember.id.attribute.id = userEntityAttributeViewItem.attributeId and attributeMember.memberName = concat(concat(?28,?29),root.type)) and (userEntityAttributeViewItem.entityType = ?30 and userEntityAttributeViewItem.entityModule = ?31 and userEntityAttributeViewItem.entityIdUuid = root.id))))
                                """);

		tx.commit();
		s.close();
	}
}
