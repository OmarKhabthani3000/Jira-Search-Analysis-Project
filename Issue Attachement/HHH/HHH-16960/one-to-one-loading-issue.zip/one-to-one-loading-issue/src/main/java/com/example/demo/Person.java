package com.example.demo;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Person {

    @Id
    private Long id;

    private String name;

    @ManyToOne
    private Person parent;

    @OneToOne(mappedBy = "person", orphanRemoval = true, cascade = CascadeType.ALL)
    private PersonContact personContact;

    @OneToMany(mappedBy = "parent")
    private Set<Person> children = new HashSet<>(0);

    public Person() {
    }

    public Person(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public PersonContact getPersonContact() {
        return personContact;
    }

    public void setPersonContact(PersonContact personContact) {
        this.personContact = personContact;
    }

    public Person getParent() {
        return parent;
    }

    public void setParent(Person parent) {
        this.parent = parent;
    }

    public Set<Person> getChildren() {
        return children;
    }

    public void setChildren(Set<Person> children) {
        this.children = children;
    }
}
