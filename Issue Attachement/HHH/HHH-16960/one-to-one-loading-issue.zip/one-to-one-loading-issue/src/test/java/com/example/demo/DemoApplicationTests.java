package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import jakarta.persistence.EntityGraph;
import jakarta.persistence.EntityManager;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
class DemoApplicationTests {

	@Autowired
	private EntityManager entityManager;

	@Test
	@Transactional
	void contextLoads() {
		Person person = new Person(1L, "test");

		Person child1 = new Person(2L, "child1");
		Person child2 = new Person(2L, "child2");
		child1.setParent(person);
		child2.setParent(person);
		person.getChildren().add(child1);
		person.getChildren().add(child2);
		entityManager.persist(person);
		entityManager.flush();
		entityManager.clear();

		EntityGraph<?> personGraph = entityManager.createEntityGraph(Person.class);
		personGraph.addAttributeNodes("children");
		Person loadedPerson = entityManager.find(Person.class, person.getId(), Map.of("javax.persistence.fetchgraph", personGraph));

		assertNull(loadedPerson.getPersonContact());
	}

}
