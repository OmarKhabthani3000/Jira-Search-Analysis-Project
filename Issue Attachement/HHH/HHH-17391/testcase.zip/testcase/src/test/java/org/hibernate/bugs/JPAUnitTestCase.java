package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import jakarta.persistence.Tuple;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.setExtractBareNamePropertyMethods;
import org.hibernate.Session;
import org.hibernate.query.criteria.JpaCriteriaQuery;
import org.hibernate.query.criteria.JpaDerivedJoin;
import org.hibernate.query.criteria.JpaDerivedRoot;
import org.hibernate.query.criteria.JpaRoot;
import org.hibernate.query.criteria.JpaSubQuery;
import org.hibernate.query.criteria.JpaWindow;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private static final Logger LOGGER = LogManager.getLogger();
	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh17391Test() throws Exception {
		try(EntityManager entityManager = entityManagerFactory.createEntityManager()) {
			entityManager.getTransaction().begin();
			//given
			persistData(entityManager);
			var cb = entityManager.unwrap(Session.class).getCriteriaBuilder();
			JpaWindow window = cb.createWindow();
			JpaCriteriaQuery<Tuple> query = cb.createTupleQuery();
			JpaRoot<Primary> root = query.from(Primary.class);
			window.partitionBy(root.get("id")).orderBy(cb.asc(root.get("id")));
			query.multiselect(
					root.get("id").alias("id"),
					cb.rowNumber(window).alias("index")
			).groupBy(
					root.get("id")
			);
			List<Tuple> tuples = entityManager.createQuery(query).getResultList();
			assertThat(tuples).hasSize(2);
		} catch (Throwable t) {
			LOGGER.error(t.getMessage(), t);
			throw t;
		}
	}

	private void persistData(EntityManager em) {
		Stream.of(
				createPrimary(1, 10),
				createPrimary(2, 5)
		).forEach(em::persist);
		em.flush();
		em.clear();
	}

	private Primary createPrimary(int id, Integer capacity) {
		var entity = new Primary();
		entity.setId(id);
		entity.setCapacity(capacity);
		return entity;
	}
}
