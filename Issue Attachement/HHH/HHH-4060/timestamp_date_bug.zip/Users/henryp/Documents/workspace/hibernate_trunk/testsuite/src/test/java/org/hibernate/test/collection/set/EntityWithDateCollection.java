package org.hibernate.test.collection.set;

import java.util.Date;
import java.util.Set;

public class EntityWithDateCollection {
	
	private String name;
	
	private Set<Date> dates;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Date> getDates() {
		return dates;
	}

	public void setDates(Set<Date> dates) {
		this.dates = dates;
	}

}
