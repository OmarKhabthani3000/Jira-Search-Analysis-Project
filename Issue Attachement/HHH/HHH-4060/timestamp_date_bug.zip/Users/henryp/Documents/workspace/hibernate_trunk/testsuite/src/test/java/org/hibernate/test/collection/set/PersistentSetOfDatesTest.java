package org.hibernate.test.collection.set;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.junit.functional.FunctionalTestCase;

public class PersistentSetOfDatesTest extends FunctionalTestCase {
	
	private static final String CONTAINER_NAME = "container_name";
	Session session;

	public PersistentSetOfDatesTest(String string) {
		super(string);
	}

	public String[] getMappings() {
		return new String[] { "collection/set/EntityWithDateCollectionMappings.hbm.xml" };
	}

	public void testDateToTimestampConversionConfusesDirtyComparison() throws Exception {
		Set<Date> dates = createDateSet();
		
		EntityWithDateCollection container = new EntityWithDateCollection();
		container.setName(CONTAINER_NAME);
		container.setDates(dates);
		
		startDbConversation();
		endDbConversation(container);
		
		startDbConversation();
		EntityWithDateCollection entityFromDb = getEntityFromDb();
		
		// this is the interesting bit:
		entityFromDb.getDates().clear();
		entityFromDb.getDates().addAll(dates);
		// all we did was basically put the dates we started with back into the collection, right?
		
		endDbConversation(entityFromDb);
			
		makeSetAssertions(dates);
	}
	
	private EntityWithDateCollection makeSetAssertions(Set<Date> dates) {
		startDbConversation();
		
		EntityWithDateCollection entityFromDb = getEntityFromDb();
		assertNotNull(entityFromDb);
		Set<Date> datesFromDb = entityFromDb.getDates();
        assertEquals("" + datesFromDb, dates.size(), datesFromDb.size());
		
		endDbConversation();
		
		return entityFromDb;
	}

	private EntityWithDateCollection getEntityFromDb() {
		EntityWithDateCollection entityFromDb = (EntityWithDateCollection) session.get(EntityWithDateCollection.class, CONTAINER_NAME);
		return entityFromDb;
	}

	private Set<Date> createDateSet() {
		Date date1 = new Date(0);
		Date date2 = new Date(3600 * 24 * 100); // 100 days later
		Set<Date> dates = new HashSet<Date>();
		dates.add(date1);
		dates.add(date2);
		return dates;
	}

	private void endDbConversation(EntityWithDateCollection container) {
		session.save( container );
		endDbConversation();
	}

	private void endDbConversation() {
		session.getTransaction().commit();
		session.close();
	}

	private void startDbConversation() {
		session = openSession();
		session.beginTransaction();
	}
	
}
