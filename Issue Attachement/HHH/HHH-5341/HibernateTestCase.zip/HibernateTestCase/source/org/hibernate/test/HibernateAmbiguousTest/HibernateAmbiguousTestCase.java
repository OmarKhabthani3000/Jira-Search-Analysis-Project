package org.hibernate.test.HibernateAmbiguousTest;

import java.util.Properties;

import junit.framework.Test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;

public class HibernateAmbiguousTestCase extends TestCase {

	public HibernateAmbiguousTestCase(String string) {
		super(string);
	}

	public static Test suite() {
		return new FunctionalTestClassTestSuite(
				HibernateAmbiguousTestCase.class);
	}

	public void testAmbiguousTestCase() {

		Session session = openSession();
		Invoice invoice = new Invoice("OrderValue");
		Item item = new Item("ItemValue");
		invoice.setItem(item);
		Transaction tx = session.beginTransaction();
		session.persist(item);
		session.persist(invoice);
		tx.commit();
		session.close();

		session = openSession();
		tx = session.beginTransaction();
		try {
			Invoice loadedOrder = (Invoice) session.get(Invoice.class, invoice
					.getDBId());
		} catch (ConstraintViolationException e) {
			e.printStackTrace();
			//Column '_value' in field list is ambiguous
			fail();
		}
		session.close();
	}

	protected Class<?>[] getAnnotatedClasses() {
		return new Class[]{
				Invoice.class, Item.class
		};
		}

}
