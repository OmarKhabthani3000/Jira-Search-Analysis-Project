import static org.junit.Assert.*;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.DefaultComponentSafeNamingStrategy;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.impl.SessionImpl;
import org.junit.Test;

public class HibernateAmbiguousTest
{
    private static SessionFactory buildSessionFactory()
    {
        final AnnotationConfiguration configuration = new AnnotationConfiguration();
        configuration.addAnnotatedClass(Item.class);
        configuration.addAnnotatedClass(Invoice.class);
        Properties properties = new Properties();
        properties.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
        properties.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
        properties.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/hibernateTest");
        properties.put("hibernate.connection.username", "root");
        properties.put("hibernate.connection.password", "root");
        properties.put("hibernate.connection.isolation", "2");
        properties.put("hibernate.show_sql", "true");
        properties.put("hibernate.hbm2ddl.auto", "create");
        configuration.addProperties(properties);
        configuration.setNamingStrategy(DefaultComponentSafeNamingStrategy.INSTANCE);
        configuration.buildMappings();
        return configuration.buildSessionFactory();
    }

    @Test
    public void testAmbiguous() throws Exception
    {
        SessionFactory _sessionFactory = buildSessionFactory();

        SessionImpl session = (SessionImpl) _sessionFactory.openSession();
        Invoice invoice = new Invoice("OrderValue");
        Item item = new Item("ItemValue");
        invoice.setItem(item);
        Transaction tx = session.beginTransaction();
        session.persist(item);
        session.persist(invoice);
        tx.commit();
        session.close();
        session = (SessionImpl) _sessionFactory.openSession();
        tx = session.beginTransaction();
        try
        {
            Invoice loadedOrder = (Invoice) session.get(Invoice.class, invoice.getDBId());
        }
        catch (ConstraintViolationException e)
        {
            e.printStackTrace();
            fail();
        }
        session.close();
    }
}
