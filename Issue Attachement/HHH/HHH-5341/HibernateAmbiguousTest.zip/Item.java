import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.search.annotations.DocumentId;

@Entity
@Table(name = "item")
public class Item
{
    @Id
    @GeneratedValue(generator = "seqStyleGenerator")
    @GenericGenerator(name = "seqStyleGenerator", strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator", parameters = {
            @Parameter(name = "increment_size", value = "200"), @Parameter(name = "optimizer", value = "pooled"),
            @Parameter(name = "force_table_use", value = "true")})
    @DocumentId
    private long _dbID;

    @Version
    private Integer _version; // Hibernate

    private String _value;

    public Item()
    {
        _value = null;
    }

    public Item(final String value)
    {
        _value = value;
    }

    public String getValue()
    {
        return _value;
    }

    public void setValue(final String value)
    {
        _value = value;
    }

    public long getDBId()
    {
        return _dbID;
    }

}
