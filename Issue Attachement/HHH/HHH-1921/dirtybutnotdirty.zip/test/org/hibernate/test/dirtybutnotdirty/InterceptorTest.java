//$Id: InterceptorTest.java 9912 2006-05-08 22:41:00Z max.andersen@jboss.com $
package org.hibernate.test.dirtybutnotdirty;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.TestCase;

/**
 * @author Josh Moore (copied from org.hibernate.test.interceptor)
 */
public class InterceptorTest extends TestCase {
	
	public InterceptorTest(String str) {
		super(str);
	}
	
	public void testPropertyIntercept() {
		Session s = openSession( new PropertyInterceptor() );
		Transaction t = s.beginTransaction();
		User u = new User("Josh", "test");
		s.persist(u);
		u.setPassword("nottest");
		t.commit();
		s.close();
		
		s = openSession();
		t = s.beginTransaction();
		u = (User) s.get(User.class, "Josh");
		assertEquals("test", u.getPassword());
		s.delete(u);
		t.commit();
		s.close();
	}	
	
	protected String[] getMappings() {
		return new String[] { "dirtybutnotdirty/User.hbm.xml" };
	}

	public static Test suite() {
		return new TestSuite(InterceptorTest.class);
	}

}

