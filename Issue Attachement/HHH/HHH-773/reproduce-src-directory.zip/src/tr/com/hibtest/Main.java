package tr.com.hibtest;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	private SessionFactory factory;
	
	 //  for username, finds how many user existing in DB
	public int searchByUserName(String username) throws Exception {
		Session s = factory.openSession();
		Transaction tx=null;
		int result = 0;
		try {
			tx = s.beginTransaction();
			List user = s.createQuery(
				" select user.userName  from User as user "
				+ " where user.userName = '" + username + "'")
				.setMaxResults(10).list();
			result = user.size();
			tx.commit();
		}
		catch (Exception e) {
			if (tx!=null) tx.rollback();
			throw e;
		}
		finally {
			s.close();
		}
		return result;
	}
    
    // For name parameter, save a new User. 
	public void createUserNamed(String name) throws Exception {
		Session s = factory.openSession();
		Transaction tx = null;
		try {
			tx = s.beginTransaction();

			User freshman = new User();
			freshman.setUserName(name);
			s.save(freshman);
			tx.commit();
		}
		catch (Exception e) {
			if (tx!=null) tx.rollback();
			throw e;
		}
		finally {
			s.close();
		}	
	}

	private  void saveAndSearhUser(String name) {
		//Save user
		try {
			createUserNamed(name);
			System.out.println(name + " saved");
		} catch (Exception e) {
			System.out.println("SAVE ERROR : User " + name + " couldnt save");
			e.printStackTrace();
		}
		//Search user
		try {
			int result = searchByUserName(name);
			if(result < 1)
				System.out.println("  SEARH FAILED for  " + name + ", at least 1 expected");
			else
				System.out.println("  found  " + name + " , total:" + result );	
		} catch (Exception e) {
			System.out.println("SEARCH ERROR");
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		final Main test = new Main();
		Configuration cfg = new Configuration()
			.addClass(User.class);		

		test.factory = cfg.buildSessionFactory();
		
		test.saveAndSearhUser("Agetha");
		// ********
		// Turkish word "Kapal�"  the last character is dottless i
		// and it is written in unicode below
		test.saveAndSearhUser("Kapal\u0131");

		test.factory.close();
	}
}