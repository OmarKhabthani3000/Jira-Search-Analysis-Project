package com.demo.hibernate6;

import com.demo.hibernate6.model.Zoo;
import com.demo.hibernate6.model.animal.Elephant;
import com.demo.hibernate6.model.animal.Tiger;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.math.BigDecimal;

public class App {

  public static void main(String[] args) {

    EntityManagerFactory entityManagerFactory =
        Persistence.createEntityManagerFactory("templatePU");
    EntityManager entityManager = entityManagerFactory.createEntityManager();

    entityManager.getTransaction().begin();
    Zoo zoo = Zoo.builder().name("The Great Calcutta Zoo").build();

    entityManager.persist(zoo);

    Tiger tiger = Tiger.tigerBuilder().sequenceNumber(0).weight(BigDecimal.ZERO).build();
    tiger.setZoo(zoo);
    entityManager.persist(tiger);

    entityManager.flush();
    entityManager.clear();

    entityManager.getTransaction().commit();

    // Inserting first Elephant
    entityManager.getTransaction().begin();
    Elephant elephant1 =
        Elephant.elephantBuilder().sequenceNumber(1).weight(BigDecimal.ONE).build();
    elephant1.setZoo(zoo);
    entityManager.persist(elephant1);

    entityManager.flush();
    entityManager.clear();
    entityManager.getTransaction().commit();

    entityManager.getTransaction().begin();
    // fetch zoo, now you will see the issue
    Zoo zooById = entityManager.find(Zoo.class, zoo.getId());

    System.out.println("zoo:" + zooById.getId());
    System.out.println("zoo name:" + zooById.getName());

    System.out.println(zooById.getTiger() instanceof Tiger);
    System.out.println("zoo tiger:" + zooById.getTiger());
    System.out.println("zoo tiger id:" + zooById.getTiger().getId());

    System.out.println(zooById.getElephants().size());

    System.out.println(zooById.getElephants().get(0) instanceof Elephant); // The issue

    System.out.println("zoo elephant:" + zooById.getElephants().get(0));
    System.out.println(zooById.getElephants().get(0).getClass().getName());
    System.out.println("zoo elephant Id:" + zooById.getElephants().get(0).getId());
    entityManager.getTransaction().commit();
  }
}
