package com.demo.hibernate6.model.animal;

import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "ANIMAL")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "ANIMAL_TYPE")
@org.hibernate.annotations.DiscriminatorOptions(force = true)
public class Animal {
  @GeneratedValue(generator = "ANIMAL_SEQ")
  @SequenceGenerator(name = "ANIMAL_SEQ", sequenceName = "ANIMAL_SEQ")
  @Id
  private Long id;

  private Integer sequenceNumber;

  private BigDecimal weight;

  public Animal() {
    super();
  }

  public Animal(Long id, Integer sequenceNumber, BigDecimal weight) {
    super();
    this.id = id;
    this.sequenceNumber = sequenceNumber;
    this.weight = weight;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Integer getSequenceNumber() {
    return sequenceNumber;
  }

  public void setSequenceNumber(Integer sequenceNumber) {
    this.sequenceNumber = sequenceNumber;
  }

  public BigDecimal getWeight() {
    return weight;
  }

  public void setWeight(BigDecimal weight) {
    this.weight = weight;
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, sequenceNumber, weight);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null) return false;
    if (getClass() != obj.getClass()) return false;
    Animal other = (Animal) obj;
    return Objects.equals(id, other.id)
        && Objects.equals(sequenceNumber, other.sequenceNumber)
        && Objects.equals(weight, other.weight);
  }

  @Override
  public String toString() {
    return "Animal [id=" + id + ", sequenceNumber=" + sequenceNumber + ", weight=" + weight + "]";
  }
}
