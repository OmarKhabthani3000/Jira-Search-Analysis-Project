/**
 * Copyright(c) 2011-2014 by YouCredit Inc.
 * All Rights Reserved
 */
package cn.youcredit.test.db;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author jay
 */
@Repository
@Transactional
public class UserService {
    @Autowired
    private SessionFactory sessionFactory;

    public void addUsers(int count) {
        for (int i = 0; i < count; i++) {
            User user = new User();
            this.sessionFactory.getCurrentSession().save(user);
        }
    }

    public List<User> getUsers() {
        return this.sessionFactory.getCurrentSession().createQuery("from User")
            .list();
    }

    public List<User> getUsersBySQL() {
        return this.sessionFactory.getCurrentSession()
            .createSQLQuery("select * from user as u where u.id>0").list();
    }
}
