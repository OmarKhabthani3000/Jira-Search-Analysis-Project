/**
 * Copyright(c) 2011-2014 by YouCredit Inc.
 * All Rights Reserved
 */
package cn.youcredit.test.db;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author jay
 */
@Transactional
@ContextConfiguration("/spring.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class UserServiceTest {
    @Autowired
    private UserService service;

    @Test
    public void testAddUsers() {
        this.service.addUsers(10);
    }

    @Test
    public void testGetUsers() {
        this.service.getUsers();
    }

    @Test
    public void testGetUsersBySQL() {
        this.service.getUsersBySQL();
    }

}
