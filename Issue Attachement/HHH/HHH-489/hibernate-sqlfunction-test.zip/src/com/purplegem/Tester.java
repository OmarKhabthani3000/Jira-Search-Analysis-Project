package com.purplegem;

import java.util.Iterator;

import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.Query;
import org.apache.log4j.Logger;

/**
 *
 */

public class Tester {

  public static final Logger logger = Logger.getLogger(Tester.class);

  public void test() {

    SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

    Session session = sessionFactory.openSession();

    Query query = session.createQuery("select colour from Colour as colour where bitwise_and(colour.bitmask, 1) > 0");
    for (Iterator it = query.iterate(); it.hasNext();) {
      Colour colour = (Colour) it.next();
      logger.debug("Found Colour: " + colour.getName() );
    }

    session.close();

  }

  public static void main(String[] args) {

    Tester tester = new Tester();
    tester.test();

  }

}
