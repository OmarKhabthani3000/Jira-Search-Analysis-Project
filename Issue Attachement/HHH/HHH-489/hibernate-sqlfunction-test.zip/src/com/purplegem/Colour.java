package com.purplegem;

/**
 * Simple class representing a colour with a bit-mask.
 */

public class Colour {

  private int id;
  private String name;
  private int bitmask;

  public Colour() {
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getBitmask() {
    return bitmask;
  }

  public void setBitmask(int bitmask) {
    this.bitmask = bitmask;
  }

}
