package com.purplegem;

import java.util.List;

import org.hibernate.dialect.function.StandardSQLFunction;
import org.hibernate.type.Type;

/**
 *
 */

public class MySQLBitwiseAndSQLFunction extends StandardSQLFunction {

  public MySQLBitwiseAndSQLFunction(String name) {
    super(name);

  }

  public MySQLBitwiseAndSQLFunction(String name, Type typeValue) {
    super(name, typeValue);
  }

  public String render(List args) {

    if (args.size() != 2) {
      throw new IllegalArgumentException("MySQLBitwiseAndSQLFunction requires 2 arguments!");
    }
    StringBuffer buffer = new StringBuffer(args.get(0).toString());
    buffer.append(" & ").append(args.get(1));
    return buffer.toString();
  }

}
