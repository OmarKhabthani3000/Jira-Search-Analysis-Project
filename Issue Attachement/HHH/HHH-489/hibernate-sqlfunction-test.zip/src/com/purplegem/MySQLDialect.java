package com.purplegem;

import org.hibernate.Hibernate;

/**
 *
 */
public class MySQLDialect extends org.hibernate.dialect.MySQLDialect {

  public MySQLDialect() {
    super();
    registerFunction("bitwise_and", new MySQLBitwiseAndSQLFunction("bitwise_and", Hibernate.INTEGER));
  }

}
