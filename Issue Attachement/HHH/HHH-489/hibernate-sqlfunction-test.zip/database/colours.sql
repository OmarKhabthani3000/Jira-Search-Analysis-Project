#
# Table structure for table `colours`
#

CREATE TABLE colours (
  id int(11) NOT NULL auto_increment,
  name varchar(20) NOT NULL default '',
  bitmask int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table `colours`
#

INSERT INTO colours VALUES (1, 'Red', 1);
INSERT INTO colours VALUES (2, 'Green', 2);
INSERT INTO colours VALUES (3, 'Blue', 4);
INSERT INTO colours VALUES (4, 'Cyan', 3);
INSERT INTO colours VALUES (5, 'Magenta', 5);
INSERT INTO colours VALUES (6, 'Yellow', 6);
INSERT INTO colours VALUES (7, 'White', 7);