package net.dbyrne.hibernate;

public class GoodHibernateTestCase extends AbstractHibernateTestCase {
	
	public GoodHibernateTestCase(){
		onlyDifference = "hibernate.cfg.xml";
	}
}
