package net.dbyrne.hibernate;

import junit.framework.TestCase;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.auction.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.hsqldb.Server;

public abstract class AbstractHibernateTestCase extends TestCase {
	private static Log log = LogFactory.getLog(AbstractHibernateTestCase.class);
	protected Configuration conf;
	protected SessionFactory sessionFactory;
	private static Server server;
	private static String SERVER_PROPS = "database.0=mem:test";
	
	private Long auctionItemId ;
	private Integer userId = new Integer(99);
	private String email = "dennis@dbyrne.net";
	private String userName = "dennis";
	private String firstName = "dennis";
	private String password = "foo";
	private Character mi = 'C';
	private String lastName = "byrne";
	
	protected String onlyDifference ;
	
    protected void setUp() {
        server = new Server();
        server.putPropertiesFromString(SERVER_PROPS);
        server.start();
		conf = new Configuration().configure(onlyDifference);
		sessionFactory = conf.buildSessionFactory();
    	SchemaExport schemaExport = new SchemaExport(conf);
    	schemaExport.create(true, true);
    	
    	Session session = sessionFactory.openSession();
    	Transaction trans = session.beginTransaction();
    	User user = getTransientUser();
    	session.save(user);
    	trans.commit();
    	session.close();
    	log.info("finished creating test data");
    }
    
	protected void tearDown() throws Exception {
		sessionFactory.close();
		sessionFactory = null;
		server.stop();
		server = null;
		super.tearDown();
	}

	public void testUpdate(){
		
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		User user = getTransientUser();
		user.setPassword(user.getPassword() + " changed");
    	
    	session.update(user);
		tx.commit();
		session.close();
	}
	
	private User getTransientUser(){
    	User user = new User();
    	user.setMyUserId(userId);
    	user.setEmail(email);
    	user.setFirstName(firstName);
    	user.setInitial(mi);
    	user.setLastName(lastName);
    	user.setPassword(password);
    	user.setUserName(userName);
    	user.setVersion(new Integer(1));
    	return user;
	}
}

