package net.dbyrne.hibernate;

public class BadHibernateTestCase extends AbstractHibernateTestCase {

	public BadHibernateTestCase(){
		onlyDifference = "hibernate.npe.xml";
	}
	
}
