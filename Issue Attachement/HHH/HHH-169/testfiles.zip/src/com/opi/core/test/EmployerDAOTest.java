/*
 * Created by IntelliJ IDEA.
 * User: jdunne
 * Date: Mar 2, 2005
 * Time: 9:19:21 AM
 */
package com.opi.core.test;

import junit.framework.TestCase;
import com.opi.core.dao.EmployerDAO;
import com.opi.core.util.HibernateUtil;
import com.opi.core.domain.Employer;

public class EmployerDAOTest extends TestCase{

    public void testFetchEmployer() {
        EmployerDAO dao = new EmployerDAO();
        Employer employer = dao.getEmployerById(new Long(1));

        //note: If the employer.toString() is taken out - test runs
        System.out.println(employer.toString());

        HibernateUtil.commitTransaction();
        HibernateUtil.closeSession();
    }
}