/*
 * Created on Feb 25, 2005
 *
 */
package com.opi.core.domain;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.type.TimestampType;
import org.hibernate.usertype.UserType;

/**
 * @author jdunne
 *
 */
public class AuditInfoType implements UserType {
    private static final int[] SQL_TYPES = new int[]{
        Types.TIMESTAMP,
        Types.TIMESTAMP,
        Types.VARCHAR,
        Types.VARCHAR
    };

    public int[] sqlTypes() {
        return SQL_TYPES;
    }

    public boolean isMutable() {
        return true;
    }

    public Class returnedClass() {
        return AuditInfo.class;
    }

    public boolean equals(Object x, Object y) {
        if( x == y ) return true;
        if( x == null || y == null ) return false;
        AuditInfo aix = (AuditInfo) x;
        AuditInfo aiy = (AuditInfo) y;
        try {
            return Hibernate.TIMESTAMP.isEqual(aix.getDateModified(), aiy.getDateModified()) &&
                    Hibernate.TIMESTAMP.isEqual(aix.getDateCreated(), aiy.getDateCreated()) &&
                    Hibernate.STRING.isEqual(aix.getModifiedBy(), aiy.getModifiedBy()) &&
                    Hibernate.STRING.isEqual(aix.getCreatedBy(), aiy.getCreatedBy());
        } catch( HibernateException e ) {
            return false;
        }
    }

    public Object deepCopy(Object value) {
        if( value == null ) return null;
        AuditInfo ai = (AuditInfo) value;
        AuditInfo result = new AuditInfo();
        try {
            if (ai.getDateModified()==null) {
                result.setDateModified(null);
            } else {
                result.setDateModified((Timestamp) ((TimestampType)Hibernate.TIMESTAMP).deepCopyNotNull(ai.getDateModified()));
            }

            if (ai.getDateCreated()==null) {
                result.setDateCreated(null);
            } else {
                result.setDateCreated((Timestamp) ((TimestampType)Hibernate.TIMESTAMP).deepCopyNotNull(ai.getDateCreated()));
            }
            result.setModifiedBy(ai.getModifiedBy());
            result.setCreatedBy(ai.getCreatedBy());
            return result;
        } catch( HibernateException e ) {
            e.printStackTrace();
            return result;
        }
    }

    public Object nullSafeGet(ResultSet rs, String[] names, Object owner)
            throws HibernateException, SQLException {

        //AuditInfo can't be null
        AuditInfo ai = new AuditInfo();
        ai.setDateModified((java.sql.Timestamp) Hibernate.TIMESTAMP.nullSafeGet(rs, names[0]));
        ai.setDateCreated((java.sql.Timestamp) Hibernate.TIMESTAMP.nullSafeGet(rs, names[1]));
        ai.setModifiedBy((String) Hibernate.STRING.nullSafeGet(rs, names[2]));
        ai.setCreatedBy((String) Hibernate.STRING.nullSafeGet(rs, names[3]));
        return ai;
    }

    public void nullSafeSet(PreparedStatement st, Object value, int index)
            throws HibernateException, SQLException {

        //AuditInfo can't be null
        AuditInfo ai = (AuditInfo) value;
        Hibernate.TIMESTAMP.nullSafeSet(st, ai.getDateModified(), index);
        Hibernate.TIMESTAMP.nullSafeSet(st, ai.getDateCreated(), index + 1);
        Hibernate.STRING.nullSafeSet(st, ai.getModifiedBy(), index + 2);
        Hibernate.STRING.nullSafeSet(st, ai.getCreatedBy(), index + 3);
    }

    /* (non-Javadoc)
     * @see org.hibernate.usertype.UserType#hashCode(java.lang.Object)
     */
    public int hashCode(Object x) throws HibernateException {

        return x.hashCode();
    }

    /* (non-Javadoc)
     * @see org.hibernate.usertype.UserType#disassemble(java.lang.Object)
     */
    public Serializable disassemble(Object value) throws HibernateException {

        return null;
    }

    /* (non-Javadoc)
     * @see org.hibernate.usertype.UserType#assemble(java.io.Serializable, java.lang.Object)
     */
    public Object assemble(Serializable cached, Object owner) throws HibernateException {

        return null;
    }

    /* (non-Javadoc)
     * @see org.hibernate.usertype.UserType#replace(java.lang.Object, java.lang.Object, java.lang.Object)
     */
    public Object replace(Object original, Object target, Object owner) throws HibernateException {

        return null;
    }
}
