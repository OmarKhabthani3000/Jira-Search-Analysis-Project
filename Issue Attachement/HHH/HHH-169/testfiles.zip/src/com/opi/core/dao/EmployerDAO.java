/*
 * Created by IntelliJ IDEA.
 * User: jdunne
 * Date: Mar 2, 2005
 * Time: 9:00:08 AM
 */
package com.opi.core.dao;

import com.opi.core.util.InfrastructureException;
import com.opi.core.util.HibernateUtil;
import com.opi.core.domain.Employer;
import org.hibernate.Session;
import org.hibernate.HibernateException;

public class EmployerDAO {

    public EmployerDAO() {
        HibernateUtil.beginTransaction();
    }

    public Employer getEmployerById(Long id)
            throws InfrastructureException {

        Session session = HibernateUtil.getSession();
        Employer employer = null;
        try {
            employer = (Employer) session.load(Employer.class, id);
        }  catch (HibernateException ex) {
            throw new InfrastructureException(ex);
        }
        return employer;
    }

}