/*
 * Created on Feb 25, 2005
 *
 */
package com.opi.core.domain;

/**
 * @author jdunne
 *
 */
public interface AuditInterface {

    /**
     * Instances must always return a non-null instance of AuditInfo
     */
    public AuditInfo getAuditInfo();

}
