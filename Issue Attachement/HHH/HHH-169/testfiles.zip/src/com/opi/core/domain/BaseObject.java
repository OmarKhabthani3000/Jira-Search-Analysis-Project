package com.opi.core.domain;

import java.io.Serializable;

public abstract class BaseObject implements AuditInterface, Serializable
{
    private java.lang.Long id;
    private Long version;
    private AuditInfo auditInfo;

    public BaseObject() {
    }

    /**
	 * @return Returns the id.
	 */
	public java.lang.Long getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	protected void setId(java.lang.Long id) {
		this.id = id;
	}

    public Long getVersion() {
    	return version;
    }

    private void setVersion(Long version) {
    	this.version = version;
    }

    public AuditInfo getAuditInfo() {
        if (this.auditInfo==null) {
            this.auditInfo = new AuditInfo();
        }
        return this.auditInfo;
    }

    private void setAuditInfo(AuditInfo info) {
        this.auditInfo = info;
    }

}
