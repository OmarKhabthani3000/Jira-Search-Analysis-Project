/*
 * Created on Feb 25, 2005
 *
 */
package com.opi.core.domain;

/**
 * @author jdunne
 *
 */
public class Address implements java.io.Serializable {

    private java.lang.String CountryCode;
    private java.lang.String Addr1;
    private java.lang.String Addr2;
    private java.lang.String Addr3;
    private java.lang.String Addr4;
    private java.lang.String Addr5;
    private java.lang.String Addr6;
    private java.lang.String Latitude;
    private java.lang.String Longitude;
    private java.lang.String City;
    private java.lang.String State;
    private java.lang.String PostalCode;
    private java.lang.String FipsCode;

    public Address() {
    }

    public java.lang.String getAddr1() {
        return Addr1;
    }
    public void setAddr1(java.lang.String addr1) {
        Addr1 = addr1;
    }
    public java.lang.String getAddr2() {
        return Addr2;
    }
    public void setAddr2(java.lang.String addr2) {
        Addr2 = addr2;
    }
    public java.lang.String getAddr3() {
        return Addr3;
    }
    public void setAddr3(java.lang.String addr3) {
        Addr3 = addr3;
    }
    public java.lang.String getAddr4() {
        return Addr4;
    }
    public void setAddr4(java.lang.String addr4) {
        Addr4 = addr4;
    }
    public java.lang.String getAddr5() {
        return Addr5;
    }
    public void setAddr5(java.lang.String addr5) {
        Addr5 = addr5;
    }
    public java.lang.String getAddr6() {
        return Addr6;
    }
    public void setAddr6(java.lang.String addr6) {
        Addr6 = addr6;
    }
    public java.lang.String getCity() {
        return City;
    }
    public void setCity(java.lang.String city) {
        City = city;
    }
    public java.lang.String getCountryCode() {
        return CountryCode;
    }
    public void setCountryCode(java.lang.String countryCode) {
        CountryCode = countryCode;
    }
    public java.lang.String getFipsCode() {
        return FipsCode;
    }
    public void setFipsCode(java.lang.String fipsCode) {
        FipsCode = fipsCode;
    }
    public java.lang.String getLatitude() {
        return Latitude;
    }
    public void setLatitude(java.lang.String latitude) {
        Latitude = latitude;
    }
    public java.lang.String getLongitude() {
        return Longitude;
    }
    public void setLongitude(java.lang.String longitude) {
        Longitude = longitude;
    }
    public java.lang.String getPostalCode() {
        return PostalCode;
    }
    public void setPostalCode(java.lang.String postalCode) {
        PostalCode = postalCode;
    }
    public java.lang.String getState() {
        return State;
    }
    public void setState(java.lang.String state) {
        State = state;
    }

    public String toString() {
        final StringBuffer buf = new StringBuffer();
        buf.append("Address");
        buf.append("{CountryCode=").append(CountryCode);
        buf.append(",Addr1=").append(Addr1);
        buf.append(",Addr2=").append(Addr2);
        buf.append(",Addr3=").append(Addr3);
        buf.append(",Addr4=").append(Addr4);
        buf.append(",Addr5=").append(Addr5);
        buf.append(",Addr6=").append(Addr6);
        buf.append(",Latitude=").append(Latitude);
        buf.append(",Longitude=").append(Longitude);
        buf.append(",City=").append(City);
        buf.append(",State=").append(State);
        buf.append(",PostalCode=").append(PostalCode);
        buf.append(",FipsCode=").append(FipsCode);
        buf.append('}');
        return buf.toString();
    }
}
