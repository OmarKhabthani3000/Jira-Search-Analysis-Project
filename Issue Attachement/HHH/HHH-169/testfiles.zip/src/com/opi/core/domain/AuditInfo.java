/*
 * Created on Feb 25, 2005
 *
 */
package com.opi.core.domain;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author jdunne
 *
 */
public class AuditInfo implements Serializable {

    private Timestamp dateModified;
    private Timestamp dateCreated;
    private String modifiedBy;
    private String createdBy;

    public String getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    public Timestamp getDateCreated() {
        return dateCreated;
    }
    public void setDateCreated(Timestamp dateCreated) {
        this.dateCreated = dateCreated;
    }
    public Timestamp getDateModified() {
        return dateModified;
    }
    public void setDateModified(Timestamp dateModified) {
        this.dateModified = dateModified;
    }
    public String getModifiedBy() {
        return modifiedBy;
    }
    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }
}
