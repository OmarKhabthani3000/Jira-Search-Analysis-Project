/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package testhib;

import java.beans.PropertyChangeListener;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

/**
 *
 * @author rac
 */
@Entity
public class Detail implements Serializable {

    public Detail() {
    }

    public Detail(Master master, String code) {
        this.master = master;
        this.code = code;
    }

    

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @ManyToOne
    private Master master;
    // <editor-fold defaultstate="collapsed" desc=" Property: master ">

    /**
     * Get the value of master
     *
     * @return the value of master
     */
    public Master getMaster() {
        return master;
    }

    /**
     * Set the value of master
     *
     * @param stage new value of master
     */
    public void setMaster(Master newValue) {
        Master oldValue = this.master;
        this.master = newValue;
        propertyChangeSupport.firePropertyChange("master", oldValue, newValue);
    }// </editor-fold>

    private String code;
    // <editor-fold defaultstate="collapsed" desc=" Property: code ">

    /**
     * Get the value of code
     *
     * @return the value of code
     */
    public String getCode() {
        return code;
    }

    /**
     * Set the value of code
     *
     * @param stage new value of code
     */
    public void setCode(String newValue) {
        String oldValue = this.code;
        this.code = newValue;
        propertyChangeSupport.firePropertyChange("code", oldValue, newValue);
    }// </editor-fold>

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Detail)) {
            return false;
        }
        Detail other = (Detail) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "testhib.Detail[id=" + id + "]";
    }

    @Transient protected final java.beans.PropertyChangeSupport propertyChangeSupport = new java.beans.PropertyChangeSupport(this);
    public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }
    public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }
    public synchronized void removePropertyChangeListener(String propertyName, PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(propertyName, listener);
    }
    public synchronized void addPropertyChangeListener(String propertyName, PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(propertyName, listener);
    }
}
