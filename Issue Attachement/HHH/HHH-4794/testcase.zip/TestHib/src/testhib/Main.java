/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package testhib;

import java.util.HashMap;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import org.hibernate.ejb.EntityManagerImpl;
import org.hibernate.ejb.QueryImpl;
import org.hibernate.engine.query.HQLQueryPlan;
import org.hibernate.impl.SessionImpl;

/**
 *
 * @author rac
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        EntityManager em = em();

        em.getTransaction().begin();
        em.createQuery("Delete from Detail T").executeUpdate();
        em.createQuery("Delete from Master T").executeUpdate();
        populate(em);
        em.getTransaction().commit();
        em.clear();

        dump(em, "All",
            "Select T from Master T");
        dump(em, "With Details",
            "Select T from Master T, in(T.details) D where D is empty");
    }

    private static void populate(EntityManager em) {
        for(int i=0; i<10;i++) {
            Master m = new Master("Master "+(i+1));
            em.persist(m);
            if(i%2==0) {
                Detail d = new Detail(m, "Detail "+(i+1));
                d.setMaster(m);
                em.persist(d);
            }
        }
    }


    private static EntityManager em() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("TestHibPU");
        EntityManager em = emf.createEntityManager();
        return em;
    }

    private static void dump(EntityManager em, String caption, String jpql) {
        System.out.println(caption);
        
        Query q = em.createQuery(jpql);

        EntityManagerImpl emi = (EntityManagerImpl) em;
        SessionImpl s = (SessionImpl) emi.getSession();
        HQLQueryPlan hqp = s.getFactory().getQueryPlanCache().getHQLQueryPlan(jpql, false, new HashMap());
        String[] ss = hqp.getSqlStrings();

        StringBuffer sb = new StringBuffer();
        for (String sql : ss) {
            sb.append(sql);
            sb.append(";\n\n");
        }
        System.out.println(sb);

        for ( Master m : (List<Master>)q.getResultList()) {
            System.out.println(String.format("  %s containing %d details", m.getName(), m.getDetails()==null?0:m.getDetails().size()));
        }
    }

}
