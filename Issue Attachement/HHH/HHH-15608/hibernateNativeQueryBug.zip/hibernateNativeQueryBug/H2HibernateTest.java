package org.hibernate.bugs;

import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.NativeQuery;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class H2HibernateTest {

    private static SessionFactory sessionFactory = null;
    private Session session = null;

    @BeforeClass
    public static void setup(){
        try {
            StandardServiceRegistry standardRegistry
                    = new StandardServiceRegistryBuilder()
                    .configure("hibernate-h2-test.cfg.xml")
                    .build();

            Metadata metadata = new MetadataSources(standardRegistry)
                    .addAnnotatedClass(ZBook.class)
                    .addAnnotatedClass(ZPublisher.class)
                    .getMetadataBuilder()
                    .build();

            sessionFactory = metadata
                    .getSessionFactoryBuilder().build();

        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    @Before
    public void setupThis(){
        session = sessionFactory.openSession();
        session.beginTransaction();
    }

    @After
    public void tearThis(){
        session.getTransaction().commit();
    }

    @AfterClass
    public static void tear(){
        sessionFactory.close();
    }

    @Test
    public void testNativeQueryWithEntity() {

        var dodoBooks = new ZPublisher();
        dodoBooks.setDescription("Dodo Books");
        session.persist(dodoBooks);
        assertNotNull(dodoBooks.getPk());
        var guide = new ZBook();
        guide.setTitle("Birdwatchers Guide to Dodos");
        guide.setDescription("A complete guide to watching the modern Dodo");
        guide.setPublisher(dodoBooks);
        session.persist(guide);
        assertNotNull(dodoBooks.getPk());

        NativeQuery query = session.createNativeQuery("select /* findExampleBooks */  {book.*}  from zbook_t book");
        query.addEntity("book", ZBook.class);
        List<ZBook> results = query.list();

        assertEquals(1, results.size());
        var first = results.get(0);
        assertEquals(first.getPublisherFk(), first.getPublisher().getPk());

    }
}
