import java.util.Date;
import java.util.List;
import java.util.Set;


public class OrderHead {

	private int id;
	private String orderDescription;
	private Date orderDate;
	public Date getOrderDate() {
		return orderDate;
	}
	
	public OrderHead(){}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	private Person person;
	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public int getId() {
		return id;
	}
	
	public OrderHead(String name) {
		super();
		this.orderDescription = name;		
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getOrderDescription() {
		return orderDescription;
	}
	public void setOrderDescription(String name) {
		this.orderDescription = name;
	}
		
	public List orderLinesLink;
	private long hibernateVersion;
}
