/*
 * Copyright 2009-2010, 2020-2023 Sven Strickroth <email@cs-ware.de>
 */

package testing;

import jakarta.persistence.LockModeType;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.query.Query;

/**
 * Data Access Object implementation for the UserDAOIf
 * @author Sven Strickroth
 */
public class UserDAO {
	Session session;
	
	public UserDAO(Session session) {
		this.session = session;
	}

	private User getUserByUsername(String username, boolean locked) {
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<User> criteria = builder.createQuery(User.class);
		Root<User> root = criteria.from(User.class);
		criteria.select(root);
		criteria.where(builder.equal(root.get(User_.username), username));
		Query<User> query = session.createQuery(criteria);
		if (locked) {
			query.setLockMode(LockModeType.PESSIMISTIC_WRITE);
		}
		return query.uniqueResult();
	}

	public User createUser(String username, String email, String firstName, String lastName) {
		User user = getUserByUsername(username, true);
		if (user == null) {
			user = new User();
			user.setUsername(username);
			user.setFirstName(firstName);
			user.setLastName(lastName);
			user.setEmail(email);
			session.persist(user);
			session.refresh(user); // make sure all fields are populated from DB
		}
		return user;
	}
}
