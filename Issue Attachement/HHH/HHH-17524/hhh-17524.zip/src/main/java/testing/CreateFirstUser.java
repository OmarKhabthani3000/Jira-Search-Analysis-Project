/*
 * Copyright 2009, 2020-2022 Sven Strickroth <email@cs-ware.de>
 */

package testing;

import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

/**
 * Tool for creating a user
 * @author Sven Strickroth
 */
public class CreateFirstUser {
	/**
	 * @param args loginname, mailaddress, firstname, lastname
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder().configure().build();
		MetadataSources metadataSources = new MetadataSources(standardRegistry);
		metadataSources.addAnnotatedClass(User.class);
		Metadata metadata = metadataSources.getMetadataBuilder().build();
		var sessionFactory = metadata.getSessionFactoryBuilder().build();
		Session session = sessionFactory.openSession();
		UserDAO userDAO = new UserDAO(session);
		Transaction tx = session.beginTransaction();
		userDAO.createUser(args[0], args[1], args[2], args[3]);
		tx.commit();
		System.out.println("User created.");
		session.close();
		sessionFactory.close();
	}
}
