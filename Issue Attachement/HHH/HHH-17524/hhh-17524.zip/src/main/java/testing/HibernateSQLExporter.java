/*
 * Copyright 2009, 2020-2023 Sven Strickroth <email@cs-ware.de>
 */

package testing;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.EnumSet;

import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.hibernate.tool.hbm2ddl.SchemaExport.Action;
import org.hibernate.tool.schema.TargetType;

import com.sun.jna.platform.win32.Netapi32Util.User;

/**
 * Hibernate DDL-definition to SQL-exporter
 * @author Sven Strickroth
 */
public class HibernateSQLExporter {
	public static final String FILENAME = "db-schema.sql";

	public static void main(String[] fdf) throws FileNotFoundException, IOException {
		try (FileOutputStream fos = new FileOutputStream(new File(FILENAME), false)) {
			// clear file
		}

		StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder().configure().build();
		MetadataSources metadataSources = new MetadataSources(standardRegistry);
		metadataSources.addAnnotatedClass(User.class);
		Metadata metadata = metadataSources.getMetadataBuilder().build();

		EnumSet<TargetType> enumSet = EnumSet.of(TargetType.SCRIPT);
		SchemaExport schemaExport = new SchemaExport();
		schemaExport.setOutputFile(FILENAME);
		schemaExport.execute(enumSet, Action.CREATE, metadata);

		standardRegistry.close();
	}
}
