package aluna;

import java.io.Serializable;


public class PK implements Serializable{

	public String first;
	public String second;
	
	public String getFirst() {
		return first;
	}
	public void setFirst(String first) {
		this.first = first;
	}
	public String getSecond() {
		return second;
	}
	public void setSecond(String second) {
		this.second = second;
	}
}
