package aluna;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

@Entity
public class Animal {
	@EmbeddedId
	PK pk = new PK();
	
	@ManyToOne
	@JoinColumns( { @JoinColumn(name = "first",referencedColumnName="first",insertable=false,updatable=false)
		, @JoinColumn(name = "second",referencedColumnName="second",insertable=false,updatable=false) })
	Owner owner;
}
