package aluna;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class Owner {
	@EmbeddedId
	PK pk = new PK();

}
