package aluna;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;
import javax.persistence.Version;

@Entity
public class Permission {
	private static int counter = 0;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int id;
	
	@Column
	public int name;
	
	@Version
	int version;
	
	@ManyToOne()
	@JoinColumn(name="user_fk")
	public User user;
}
