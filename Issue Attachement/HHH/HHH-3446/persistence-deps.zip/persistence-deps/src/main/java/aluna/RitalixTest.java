package aluna;

import java.util.Iterator;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class RitalixTest {

	public static void main(String[] args) {

		// Start EntityManagerFactory
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("nexperience");

		// First unit of work
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		User u = new User();

		for (int i = 1; i < 5; i++) {
			Permission p = new Permission();
			p.user = u;
			p.name = i;
			u.permissions.add(p);
		}
		u = em.merge(u);
		tx.commit();
		em.close();

		// second unit of work
		EntityManager em2 = emf.createEntityManager();
		EntityTransaction tx2 = em2.getTransaction();
		tx2.begin();
		
		
		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

		Permission perToDelete = null;
		for (Iterator iterator = u.permissions.iterator(); iterator.hasNext();) {
			Permission permission = (Permission) iterator.next();

			if (permission.id == 2) {
				  permission.user = null;
				  iterator.remove();
			}

		}

		u = em2.merge(u);
		tx2.commit();
		em2.close();

		emf.close();
	}

}
