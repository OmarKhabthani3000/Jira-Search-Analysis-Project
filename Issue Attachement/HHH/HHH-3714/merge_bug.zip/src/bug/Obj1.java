package bug;

import javax.persistence.*;

/**
 * @author Tihomir Totev
 */
@Entity
@Table(name="test1")
public class Obj1 {
    private Integer id;
    private Obj2 t2;

    public Obj1() {
    }

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    public Integer getId() {
        return id;
    }

    protected void setId(Integer id) {
        this.id = id;
    }

    @OneToOne(
            fetch= FetchType.LAZY,
            cascade={CascadeType.MERGE}
    )
    @JoinColumn(name="test2_id")
    public Obj2 getT2() {
        return t2;
    }

    public void setT2(Obj2 t2) {
        this.t2 = t2;
    }
}
