package bug;

import javax.persistence.*;

/**
 * @author Tihomir Totev
 */
@Entity
@Table(name="test2")
public class Obj2 {
    private Integer id;
    private Obj1 t1;

    public Obj2() {
    }

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    public Integer getId() {
        return id;
    }

    protected void setId(Integer id) {
        this.id = id;
    }

    @OneToOne(
            fetch=FetchType.LAZY, 
            cascade = {CascadeType.MERGE},
            mappedBy="t2"
    )
    public Obj1 getT1() {
        return t1;
    }

    public void setT1(Obj1 t1) {
        this.t1 = t1;
    }
}
