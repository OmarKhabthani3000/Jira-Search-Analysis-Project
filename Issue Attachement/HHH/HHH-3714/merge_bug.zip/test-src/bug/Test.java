package bug;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Environment;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Assert;

import java.util.TimeZone;

/**
 * @author Tihomir Totev
 */
public class Test {

    private static SessionFactory sessionFactory = null;
    private static Session session = null;

    @BeforeClass
    public static void initRPXProperties(){
        Configuration cfg = new AnnotationConfiguration().configure("hibernate.cfg.xml");
        sessionFactory = cfg.buildSessionFactory();
        session = sessionFactory.openSession();
    }

    @AfterClass
    public static void closeSession() {
        session.clear();
        session.disconnect();
        session.close();
        sessionFactory.close();
    }

    @org.junit.Test
    public void test1Merge() {
        Obj1 t1 = new Obj1();
        Obj2 t2 = new Obj2();

        t1.setT2(t2);
        t2.setT1(t1);

        t1 = (Obj1) merge(t1);
        t2 = t1.getT2();

        session.clear();

        t2 = (Obj2) session.get(Obj2.class, t2.getId());

        Assert.assertNotNull(t1.getT2());
    }

    @org.junit.Test
    public void test2Merge() {
        Obj1 t1 = new Obj1();
        Obj2 t2 = new Obj2();

        t1.setT2(t2);
        t2.setT1(t1);

        t2 = (Obj2) merge(t2);
        t1 = t2.getT1();

        session.clear();

        t1 = (Obj1) session.get(Obj1.class, t1.getId());

        Assert.assertNotNull(t2.getT1());
    }

    public static Object merge(Object object) {

        session.getTransaction().begin();

        Object merged = null;
        try {
            merged = session.merge(object);

            session.getTransaction().commit();

        } catch (RuntimeException e) {
            e.printStackTrace();
            session.getTransaction().rollback();
            throw e;
        }

        return merged;

    }
}
