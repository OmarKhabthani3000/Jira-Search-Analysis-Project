import java.util.List;

import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Subgraph;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestInheritedGraphs {

  private static EntityManager em;
  private static EntityManagerFactory emf;
  
  @BeforeClass
  public static void init() {
    emf = Persistence.createEntityManagerFactory("memory");
    em = emf.createEntityManager();
    
  }
  
  @AfterClass
  public static void destroy() {
    if(em != null) {
      em.close();
    }
    if (emf != null) {
      emf.close();
    }
  }
  
  @Before
  public void setup() {
    em.clear();
  }
  
    @Test
    public void companyWithManagerAttributes() {
      
      // entity graph
      final EntityGraph<Company> eg = em.createEntityGraph(Company.class);
      eg.addAttributeNodes("name");
      final Subgraph<Manager> sg = eg.addSubgraph("managers");
      sg.addAttributeNodes("name", "loan");

      @SuppressWarnings("unchecked")
      List<Company> result = em.createQuery("SELECT c FROM Company c")
              .setHint("javax.persistence.fetchgraph", eg)
              .getResultList();
              
      printCompany(result);
    }
    
    @Test
    public void companyWithManagerRelations() {
      
      // entity graph
      final EntityGraph<Company> eg = em.createEntityGraph(Company.class);
      eg.addAttributeNodes("name");
      
      final Subgraph<Manager> sg = eg.addSubgraph("managers");
      sg.addAttributeNodes("name", "loan");
      sg.addSubgraph("managers").addAttributeNodes("name");

      @SuppressWarnings("unchecked")
      List<Company> result = em.createQuery("SELECT c FROM Company c")
              .setHint("javax.persistence.fetchgraph", eg)
              .getResultList();
              
      printCompany(result);
    }
    
    @Test
    public void managerWithAttributes() {
      
      // entity graph
      final EntityGraph<Manager> eg = em.createEntityGraph(Manager.class);
      eg.addAttributeNodes("name", "loan");
      
      @SuppressWarnings("unchecked")
      List<Manager> result = em.createQuery("SELECT c FROM Manager c")
              .setHint("javax.persistence.fetchgraph", eg)
              .getResultList();
              
      printManager(result);

      
    }
    
    @Test
    public void managerWithRelations() {
      
      // entity graph
      final EntityGraph<Manager> eg = em.createEntityGraph(Manager.class);
      eg.addAttributeNodes("name", "loan");
      final Subgraph<Manager> sg = eg.addSubgraph("managers", Manager.class);
      sg.addAttributeNodes("name");

      @SuppressWarnings("unchecked")
      List<Manager> result = em.createQuery("SELECT c FROM Manager c")
              .setHint("javax.persistence.fetchgraph", eg)
              .getResultList();
              
      printManager(result);
    }
    
    public static void printCompany(List<Company> list) {
      for (Company company : list) {
        System.out.println("Company " + company.name + ":");
        if (company.managers != null) {
          System.out.println("\tManagers:");
          for (Manager m : company.managers) {
            System.out.println("\t\t" + m.name + " - " + m.loan);
          }
        }
      }
    }
    
    public static void printManager(List<Manager> list) {
      System.out.println("\tManagers:");
      for (Manager m : list) {
        System.out.println("\t\t" + m.name + " - " + m.loan);
      }
    }
}