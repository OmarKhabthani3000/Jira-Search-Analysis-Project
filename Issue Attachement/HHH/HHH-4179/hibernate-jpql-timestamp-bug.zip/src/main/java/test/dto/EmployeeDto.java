package test.dto;

import java.sql.Timestamp;

/**
 * Data transfer object for reporting purposes.
 */
public class EmployeeDto {

    private String name;
    private Timestamp lastUpdated;

    /**
     * Create an EmployeeDto instance.
     * The number and order of parameters must match the JPQL constructor query.
     * @param name the name
     * @param lastUpdated lastUpdated
     */
    public EmployeeDto(String name, Timestamp lastUpdated) {
        this.name = name;
        this.lastUpdated = lastUpdated;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

	public Timestamp getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Timestamp lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

}
