package test;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import test.dto.EmployeeDto;
import test.entities.Employee;


public class ConstructorQueryTest {

	private EntityManagerFactory emFactory;
    private EntityManager em;

    private Employee e1;
    private Employee e2;

    @Before
    public void setUpEntityManagerAndTestData() throws Exception {
        try {
            emFactory = Persistence.createEntityManagerFactory("SamplePU_TEST");
            em = emFactory.createEntityManager();
        } catch (Exception ex) {
            ex.printStackTrace();
            Assert.fail("Exception during JPA EntityManager instantiation.");
        }
        
        em.getTransaction().begin();
        
        e1 = new Employee();
        e1.setName("employee1");
        e1.setLastUpdated(new Timestamp(System.currentTimeMillis()));
        em.persist(e1);
        e2 = new Employee();
        e2.setName("employee2");
        e2.setLastUpdated(new Timestamp(System.currentTimeMillis()));
        em.persist(e2);
    }

    @After
    public void tearDownTransaction() throws Exception {
    	if (em != null) {
    		em.getTransaction().rollback();
    	}
    }
    
    @SuppressWarnings("unchecked")
	@Test
    public void testEmployeesQuery() {
    	String query =
    		"SELECT new test.dto.EmployeeDto(e.name, e.lastUpdated) " +
          	"FROM Employee e ORDER BY e.name";
    	
        List<EmployeeDto> reportList = em.createQuery(query).getResultList();
        
        Assert.assertNotNull(reportList);
        Assert.assertEquals(2, reportList.size());
        Assert.assertEquals("employee1", reportList.get(0).getName());
        Assert.assertEquals("employee2", reportList.get(1).getName());
    }

}
