package tests;

import org.junit.Test;

import example.TestDBAccess;
import example.dao.ParentTableHibDAO;
import example.types.OneToOneTableEntry;
import example.types.PrimaryTableEntry;

public class TestCreation
{

    @Test 
    public void test()
    {
        TestDBAccess dbAccess = new TestDBAccess( Config.getConfig() ); 
        dbAccess.createSchema();
        
        
        PrimaryTableEntry primaryTableEntry = new PrimaryTableEntry();
        OneToOneTableEntry oneToOneEntry = new OneToOneTableEntry();
        primaryTableEntry.setComment( "Test" );
        primaryTableEntry.setOneToOneEntry( oneToOneEntry );
        oneToOneEntry.setPrimaryTableEntry( primaryTableEntry );        
        
        
        dbAccess.beginTransaction();
        ParentTableHibDAO dao = dbAccess.getTestDAOFactory().getParentTableDAO();
        dao.save( primaryTableEntry );        
        dbAccess.commitTransaction();
        
        System.out.println( "*****TestCreation complete.");
    }

}
