package tests;

import example.db.DBConfig;

public class Config
{
    public static DBConfig getConfig()
    {
        // Prepare the database.
        DBConfig dbConfig = new DBConfig();
        dbConfig.SERVER_ADDRESS = "";
        dbConfig.SCHEMA = "";
        dbConfig.USERNAME = "";
        dbConfig.PASSWORD = "";
        return dbConfig;
    }
}
