package tests;

import java.util.List;

import org.junit.Test;

import example.TestDBAccess;
import example.dao.ParentTableHibDAO;
import example.types.PrimaryTableEntry;

public class TestUpdate
{
    @Test 
    public void test()
    {
        TestDBAccess dbAccess = new TestDBAccess( Config.getConfig() ); 

        dbAccess.beginTransaction();
        ParentTableHibDAO dao = dbAccess.getTestDAOFactory().getParentTableDAO();
        List<PrimaryTableEntry> retrievedEntries = dao.findAll( 0, 5 );
        retrievedEntries.get( 0 ).setComment( "Changed" );
        dao.bulkSave( retrievedEntries );
        dbAccess.commitTransaction();
        
        System.out.println( "*****TestUpdate complete.");
    }
}
