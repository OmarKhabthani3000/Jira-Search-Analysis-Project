package example.dao;

import example.db.HibernateEngine;

public class HibernateDAOFactory
{
    public HibernateDAOFactory( HibernateEngine engine )
    {
        m_engine = engine;
    }
    
    public ParentTableHibDAO getParentTableDAO()
    {
        return new ParentTableHibDAO( getEngine() );
    }    
    
    public HibernateEngine getEngine() { return m_engine; }
    
    private HibernateEngine m_engine = null;
}
