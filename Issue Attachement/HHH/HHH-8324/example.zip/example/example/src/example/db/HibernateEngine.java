package example.db;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.hibernate.tool.hbm2ddl.SchemaExport;



public class HibernateEngine implements PersistenceEngine
{
    public HibernateEngine( DBConfig cfg, List<Class<?>> annotations )
    {
        m_config = initConfig( cfg, annotations );
        // Call this to remove the overhead of the initial factory creation
        // during construction.
        getSession();
    }

    @Override
    public void createSchema()
    {
        new SchemaExport( m_config ).create( true, true );
    }
    
    @Override
    public void beginTransaction()
    {
        getSession().beginTransaction();
    }
    
    @Override
    public void commitTransaction()
    {
        getSession().getTransaction().commit();
    }
    
    @Override
    public void rollbackTransaction()
    {
        getSession().getTransaction().rollback();
    }    

    public Session getSession()
    {
        if( m_factory == null )
        {
            ServiceRegistryBuilder serviceRegistryBuilder 
            = new ServiceRegistryBuilder().applySettings(m_config.getProperties());    
            ServiceRegistry registry 
                                = serviceRegistryBuilder.buildServiceRegistry();
            m_factory = m_config.buildSessionFactory( registry );
        }
        return m_factory.getCurrentSession();
    }
    
    public StatelessSession getStatelessSession()
    {
        if( m_factory == null )
        {
            ServiceRegistryBuilder serviceRegistryBuilder 
            = new ServiceRegistryBuilder().applySettings(m_config.getProperties());    
            ServiceRegistry registry 
                                = serviceRegistryBuilder.buildServiceRegistry();
            m_factory = m_config.buildSessionFactory( registry );
        }
        return m_factory.openStatelessSession();        
    }    

    public void closeSession()
    {
        m_factory.getCurrentSession().close();
    }
    
    
    /**
     * Should only be run once...
     * @return
     */
    private Configuration initConfig( DBConfig cfg,
                                      List<Class<?>> annotations )
    {
        Configuration config = new Configuration();
        
        if( !cfg.CONFIG_FILE.isEmpty() )
            config.addResource( cfg.CONFIG_FILE );
        
        if( !cfg.SERVER_ADDRESS.isEmpty() && 
            !cfg.SCHEMA.isEmpty() )
        {
            String url =  String.format( URL, 
                cfg.SERVER_ADDRESS,
                cfg.SCHEMA );
            config.setProperty(SERVER_PROP, url );
        }
            
        if( !cfg.USERNAME.isEmpty() )
            config.setProperty(USER_PROP, cfg.USERNAME );
        
        if( !cfg.PASSWORD.isEmpty() )
            config.setProperty(PASS_PROP, cfg.PASSWORD ); 
        
        for( Class<?> annotatedClass : annotations )
        {
            config.addAnnotatedClass( annotatedClass );
        }
        
        config.configure();
        
        return config;
    }    
    
    
    private SessionFactory m_factory = null;
    private Configuration m_config = null;
    
    // Hibernate specific properites.
    private final static String URL = "jdbc:mysql://%s/%s";
    private final static String SERVER_PROP =  "hibernate.connection.url";
    private final static String USER_PROP =  "hibernate.connection.username";
    private final static String PASS_PROP =  "hibernate.connection.password";
}
