package example.db;

import java.util.ArrayList;
import java.util.List;

import example.types.OneToOneTableEntry;
import example.types.PrimaryTableEntry;

public class DBAnnotatedClasses
{
    public DBAnnotatedClasses()
    {
        m_annotatedClasses = new ArrayList<Class<?>>();
        m_annotatedClasses.add( PrimaryTableEntry.class );
        m_annotatedClasses.add( OneToOneTableEntry.class );

    }
    
    public List<Class<?>> getAnnotations()
    {
        return m_annotatedClasses;
    }
    
    private List<Class<?>> m_annotatedClasses = null; 
}
