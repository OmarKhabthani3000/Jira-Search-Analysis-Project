/*******************************************************************************
 * File:    DBConfig.java
 *
 * @author  Clint McLaughlin
 *
 * Copyright 2013 Rockwell Collins All rights reserved. 
 * Rockwell Collins PROPRIETARY/CONFIDENTIAL. Contents shall not be disclosed, 
 * disseminated, copied, or used except for purposes expressly authorized in 
 * writing by Rockwell Collins
 *
 * The technical data in this file is controlled for export under the
 * International Traffic in Arms Regulations (ITAR), 22 CFR 120-130. Violations
 * of these export laws may be subject to fines and penalties under the Arms
 * Export Control Act (22 U.S.C. 2778).
 *
 ******************************************************************************/
package example.db;



public class DBConfig
{
    //Allows programmatic specification of the location of the persistence engine config file.
    public String CONFIG_FILE = new String();
    
    // Allows programmatic specification of the server address
    public String SERVER_ADDRESS = new String();
    
    // Allows programmatic specification of the server address
    public String SCHEMA = new String();
    
    // Allows programmatic specification of the username
    public String USERNAME = new String();
    
    // Allows programmatic specification of the password
    public String PASSWORD = new String();

}
