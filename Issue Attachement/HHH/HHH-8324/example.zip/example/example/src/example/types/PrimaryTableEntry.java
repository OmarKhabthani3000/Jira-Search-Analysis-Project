package example.types;

import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity 
@Table( name="RCPRIMARY")
public class PrimaryTableEntry
{
    @Id
    @GeneratedValue(generator="id_gen")
    @GenericGenerator( name="id_gen", strategy="uuid2" )
    @Column(name="RCID", nullable=false)
    public UUID getID() { return this.id; }
    public void setID( UUID id ) { this.id = id; }
    
    @Column(name="RCCOMMENT", nullable=false, length=45)
    public String getComment() { return this.comment; }
    public void setComment( String name ) { this.comment = name; }    
    
    @OneToOne(cascade=CascadeType.ALL, fetch=FetchType.EAGER,
              targetEntity=OneToOneTableEntry.class)
    @PrimaryKeyJoinColumn
    public OneToOneTableEntry getOneToOneEntry() { return this.oneToOneEntry; }
    public void setOneToOneEntry( OneToOneTableEntry entry ) { this.oneToOneEntry = entry; }
    
    public boolean equals(Object obj)
    {
        if( !(obj instanceof PrimaryTableEntry) )
            return false;
        
        PrimaryTableEntry entry = (PrimaryTableEntry)obj;
        boolean result = true;
        result &= ( this.id.equals( entry.id ) );
        result &= ( this.comment.equals( entry.comment ) );
        result &= ( this.oneToOneEntry.equals( entry.oneToOneEntry ) );
        return result;
    }      
    
    private UUID id;
    private String comment;
    private OneToOneTableEntry oneToOneEntry;
}
