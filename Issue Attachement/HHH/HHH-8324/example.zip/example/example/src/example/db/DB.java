package example.db;



public class DB
{
    protected DB( DBConfig config, DBAnnotatedClasses annotatedClasses )
    {
        m_persistenceEngine 
          = new HibernateEngine( config, annotatedClasses.getAnnotations());
    }
    
    public void createSchema()
    {
        m_persistenceEngine.createSchema();
    }
    
    public void beginTransaction()
    {
        m_persistenceEngine.beginTransaction();
    }
    
    public void commitTransaction()
    {
        m_persistenceEngine.commitTransaction();
    }
    
    public void rollbackTransaction()
    {
        m_persistenceEngine.rollbackTransaction();
    }
    
    protected PersistenceEngine m_persistenceEngine;
}
