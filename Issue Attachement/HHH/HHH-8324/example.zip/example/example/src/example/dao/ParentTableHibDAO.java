package example.dao;


import example.db.HibernateEngine;
import example.types.PrimaryTableEntry;

public class ParentTableHibDAO extends HibernateDAO<PrimaryTableEntry, Long>
{
    public ParentTableHibDAO( HibernateEngine engine )
    {
        super( engine, PrimaryTableEntry.class );
    }
}
