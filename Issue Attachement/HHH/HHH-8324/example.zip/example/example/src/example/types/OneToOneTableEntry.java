package example.types;

import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity 
@Table( name="RCONETOONE")
public class OneToOneTableEntry
{
    @Id
    @Column(name="RCOTOID")
    @GeneratedValue(generator="gen")
    @GenericGenerator(name="gen", 
                      strategy="foreign", 
                      parameters={ @Parameter(name="property", value="primaryTableEntry") })
    public UUID getID() { return id; }
    public void setID( UUID id ) { this.id = id; }
    
    @OneToOne(mappedBy="oneToOneEntry", targetEntity=PrimaryTableEntry.class,
              cascade=CascadeType.ALL,fetch=FetchType.EAGER)    
    public PrimaryTableEntry getPrimaryTableEntry() 
    { 
        return this.primaryTableEntry; 
    }
    
    public void setPrimaryTableEntry( PrimaryTableEntry primaryTableEntry ) 
    { 
        this.primaryTableEntry = primaryTableEntry; 
    }  

    
    public boolean equals(Object obj)
    {
        if( !(obj instanceof OneToOneTableEntry) )
            return false;
        
        OneToOneTableEntry entry = (OneToOneTableEntry)obj;
        boolean result = true;
        result &= ( this.id.equals( entry.id ) );
        return result;
    }    
    
    private UUID id;
    private PrimaryTableEntry primaryTableEntry;    
}
