package example.db;

public enum PERSISTENCE_ENGINE
{
    HIBERNATE;
}
