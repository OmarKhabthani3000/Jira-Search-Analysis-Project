/*******************************************************************************
 * File:    HibernateDAO.java
 *
 * @author  Clint McLaughlin
 *
 * Copyright 2013 Rockwell Collins All rights reserved. 
 * Rockwell Collins PROPRIETARY/CONFIDENTIAL. Contents shall not be disclosed, 
 * disseminated, copied, or used except for purposes expressly authorized in 
 * writing by Rockwell Collins
 *
 * The technical data in this file is controlled for export under the
 * International Traffic in Arms Regulations (ITAR), 22 CFR 120-130. Violations
 * of these export laws may be subject to fines and penalties under the Arms
 * Export Control Act (22 U.S.C. 2778).
 *
 ******************************************************************************/
package example.dao;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Example;

import example.db.HibernateEngine;

public abstract class HibernateDAO<T, ID extends Serializable>
                                                        implements DAO<T,ID>
{
    public HibernateDAO( HibernateEngine engine, Class<?> persistenceClass )
    {
        m_engine = engine;
        m_persistenceClass = persistenceClass;
    }
    
    
    @Override
    public T save( T entity )
    {
        m_engine.getSession().save( entity );
        return entity;
    }
    
    @Override
    public void bulkSave( List<T> list )
    {
        Session session = m_engine.getSession();
        int count = 0;
        Iterator<T> iterator = list.iterator();
        while( iterator.hasNext() )
        {
            session.save( iterator.next() );
            // Every BATCH_SIZE items clear the cache. 
            //(On purpose this matches the hibernate batch size in the hibernate.cfg.xml file.)
            if( ( ++count % BATCH_SIZE ) == 0 )
            {
                session.flush();
                session.clear();
            }
        }
    }    
    
    @Override
    public void delete( T entity ) 
    {
        m_engine.getSession().delete( entity );
    }
    
    @Override
    @SuppressWarnings( "unchecked" )
    public T findByPrimaryKey( ID id, boolean lazyLoad )
    {
        if( lazyLoad )
            return (T)m_engine.getSession().load( m_persistenceClass, id );
        else
            return (T)m_engine.getSession().get( m_persistenceClass, id );
    }
    
    @Override
    @SuppressWarnings( "unchecked" )
    public List<T> findAll( int startIdx, int fetchSize )
    {
        
        Criteria crit = m_engine.getSession()
                                     .createCriteria( m_persistenceClass );
        crit.setFirstResult( startIdx );
        crit.setFetchSize( fetchSize );
        crit.setCacheable( true );
        return crit.list();
        
        /*Query query = m_engine.getSession().createQuery( "from TrackImpl" );
        return query.list();*/
    }
    
    @Override
    @SuppressWarnings( "unchecked" )
    public List<T> findByExample( T exampleInstance, String[] excludeProperty )
    {
        Criteria crit = m_engine.getSession()
                                     .createCriteria( m_persistenceClass );
        Example example = Example.create( exampleInstance );
        if( excludeProperty != null )
        {
            for( int i = 0; i < excludeProperty.length; i++ )
            {
                example.excludeProperty( excludeProperty[i] );
            }
        }
        crit.add(  example  );
        return crit.list();
    }
    
    protected HibernateEngine m_engine = null;
    
    private final int BATCH_SIZE = 20;
    private Class<?> m_persistenceClass = null;
}
