package example.db;

public interface PersistenceEngine
{
    public void createSchema();
    
    public void beginTransaction();
    public void commitTransaction();
    public void rollbackTransaction();
}
