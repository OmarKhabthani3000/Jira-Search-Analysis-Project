/*******************************************************************************
 * File:    DAO.java
 *
 * @author  Clint McLaughlin
 *
 * Copyright 2013 Rockwell Collins All rights reserved. 
 * Rockwell Collins PROPRIETARY/CONFIDENTIAL. Contents shall not be disclosed, 
 * disseminated, copied, or used except for purposes expressly authorized in 
 * writing by Rockwell Collins
 *
 * The technical data in this file is controlled for export under the
 * International Traffic in Arms Regulations (ITAR), 22 CFR 120-130. Violations
 * of these export laws may be subject to fines and penalties under the Arms
 * Export Control Act (22 U.S.C. 2778).
 *
 ******************************************************************************/
package example.dao;

import java.io.Serializable;
import java.util.List;

/**
 * All DAO interfaces should inherit from this interface.  The concrete
 * classes will inherit from their associated persistence engine's parent
 * generic DAO implementation.
 * 
 * @author cwmclaug
 *
 * @param <T>   The data type to be saved.
 * @param <ID>  The primary key.
 */
public interface DAO<T, ID extends Serializable>
{
    // Modify operations
    T save( T entity );
    void bulkSave( List<T> list );
    void delete( T entity );
    
    // Search operations
    T findByPrimaryKey( ID id, boolean lazyLoad );
    List<T> findAll( int startIdx, int fetchSize );
    List<T> findByExample( T exampleInstance, String[] excludeProperty );
}
