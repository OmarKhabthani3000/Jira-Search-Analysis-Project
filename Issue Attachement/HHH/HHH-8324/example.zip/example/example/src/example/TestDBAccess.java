package example;


import example.dao.HibernateDAOFactory;
import example.db.DB;
import example.db.DBAnnotatedClasses;
import example.db.DBConfig;
import example.db.HibernateEngine;

public class TestDBAccess extends DB
{
    public TestDBAccess( DBConfig config )
    {
        super( config, new DBAnnotatedClasses() );
        HibernateEngine engine = (HibernateEngine)m_persistenceEngine;
        m_testFactory = new HibernateDAOFactory( engine );
    }    

    
    public HibernateDAOFactory getTestDAOFactory()
    {
        return m_testFactory;
    }
  
    private HibernateDAOFactory m_testFactory = null;

}
