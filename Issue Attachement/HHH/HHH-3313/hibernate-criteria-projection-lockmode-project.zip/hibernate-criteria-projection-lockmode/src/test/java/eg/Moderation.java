package eg;

import java.util.Date;

public class Moderation {

    private Long id;
    private boolean approved = false;
    private Date approvalDate;

    public Long getId() {
        return id;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
        if (approved) {
            setApprovalDate(new Date());
        }
    }

    public Date getApprovalDate() {
        return approvalDate;
    }

    public void setApprovalDate(Date approvalDate) {
        this.approvalDate = approvalDate;
    }
}
