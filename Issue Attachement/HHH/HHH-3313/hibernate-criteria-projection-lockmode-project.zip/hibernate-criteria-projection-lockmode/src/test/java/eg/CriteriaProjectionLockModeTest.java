package eg;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.List;

public class CriteriaProjectionLockModeTest {

    private static SessionFactory sessionFactory;

    private Session session;
    private Transaction transaction;

    @BeforeClass
    public static void configureHibernate() {
        sessionFactory = new Configuration().configure().buildSessionFactory();

        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.save(new Article("Lakes frozen by unusually cold seasons", false));
        session.save(new Article("Migration patterns of Artic Polar Bears", false));
        session.save(new Article("The frozen ice shelves of the Antarctic", true));
        session.save(new Article("Salmon return to their birth place to spawn", true));
        transaction.commit();
    }

    @AfterClass
    public static void shutdownHibernate() {
        sessionFactory.close();
        sessionFactory = null;
    }

    @Before
    public void setup() {
        session = sessionFactory.getCurrentSession();
        transaction = session.getTransaction();
    }

    @Test
    public void queryUsingHQL() {
        transaction.begin();

        Query query = session.createQuery("select m from Article a, Moderation m where a.moderation = m and a.title like :title and m.approved = true");
        query.setParameter("title", "%frozen%");
        query.setLockMode("m", LockMode.UPGRADE);
        assertions(query.list());

        transaction.commit();
    }

    @Test
    public void queryUsingCriteriaWithoutLockMode() {
        transaction.begin();

        Criteria criteria = session.createCriteria(Article.class).add(Restrictions.like("title", "%frozen%"));
        criteria.createCriteria("moderation").add(Restrictions.eq("approved", true));
        criteria.setProjection(Projections.property("moderation"));
        assertions(criteria.list());

        transaction.commit();
    }

    @Test
    public void queryUsingCriteriaWithLockModeReadUsingAlias() {
        transaction.begin();

        Criteria criteria = session.createCriteria(Article.class).add(Restrictions.ilike("title", "%frozen%"));
        criteria.createCriteria("moderation", "m").add(Restrictions.eq("approved", true));
        criteria.setProjection(Projections.property("moderation"));
        criteria.setLockMode("m", LockMode.READ);
        assertions(criteria.list());

        transaction.commit();
    }

    @Test
    public void queryUsingCriteriaWithLockModeUpgradeUsingAlias() {
        transaction.begin();

        Criteria criteria = session.createCriteria(Article.class).add(Restrictions.ilike("title", "%frozen%"));
        criteria.createCriteria("moderation", "m").add(Restrictions.eq("approved", true));
        criteria.setProjection(Projections.property("moderation"));
        criteria.setLockMode("m", LockMode.UPGRADE);
        assertions(criteria.list());

        transaction.commit();
    }

    @Test
    public void queryUsingCriteriaWithLockModeUpgradeOnSubCriteria() {
        transaction.begin();

        Criteria criteria = session.createCriteria(Article.class).add(Restrictions.ilike("title", "%frozen%"));
        Criteria moderationCriteria = criteria.createCriteria("moderation").add(Restrictions.eq("approved", true));
        criteria.setProjection(Projections.property("moderation"));
        moderationCriteria.setLockMode(LockMode.UPGRADE);
        assertions(criteria.list());

        transaction.commit();
    }

    private void assertions(List list) {
        assertEquals(1, list.size());
        for (Object moderation : list) {
            assertTrue(moderation instanceof Moderation);
        }
    }
}
