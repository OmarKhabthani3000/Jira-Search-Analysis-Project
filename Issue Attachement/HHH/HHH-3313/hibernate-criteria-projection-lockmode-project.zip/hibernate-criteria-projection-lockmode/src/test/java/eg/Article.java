package eg;

public class Article {

    private Long id;
    private String title;
    private Moderation moderation = new Moderation();

    public Article() {
    }

    public Article(String title, boolean approved) {
        this.title = title;
        this.moderation.setApproved(approved);
    }

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Moderation getModeration() {
        return moderation;
    }
}
