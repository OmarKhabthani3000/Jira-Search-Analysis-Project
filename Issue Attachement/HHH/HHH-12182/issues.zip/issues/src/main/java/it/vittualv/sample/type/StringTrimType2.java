package it.vittualv.sample.type;

import org.hibernate.type.AbstractSingleColumnStandardBasicType;

/**
 * Immutable
 *
 */
public class StringTrimType2 extends AbstractSingleColumnStandardBasicType<String> {

    public StringTrimType2() {
        super(StringTrimSqlTypeDescriptor.INSTANCE, new StringTrimTypeDescriptor());
}


    @Override
    public String getName() {
        return "string-trim";
    }
}
