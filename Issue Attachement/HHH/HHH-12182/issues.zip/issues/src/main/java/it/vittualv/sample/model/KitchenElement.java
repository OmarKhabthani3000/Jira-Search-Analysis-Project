package it.vittualv.sample.model;

import org.hibernate.annotations.Immutable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;

@Immutable
@Embeddable
public class KitchenElement {

    @Embedded
    @AttributeOverrides(value = {
            @AttributeOverride(name = "name", column = @Column(name = "name", columnDefinition = "char(10)", nullable = false))
    })
    private KitchenElementName name;

    @Embedded
    @AttributeOverrides(value = {
            @AttributeOverride(name = "description", column = @Column(name = "description", columnDefinition = "char(50)", nullable = false))
    })
    private KitchenElementDescription description;

    @Embedded
    @AttributeOverrides(value = {
            @AttributeOverride(name = "description", column = @Column(name = "long_description", columnDefinition = "char(200)", nullable = false))
    })
    private KitchenElementLongDescription longDescription;

    public KitchenElement() { }

    public KitchenElement(KitchenElementName name,
                          KitchenElementDescription description,
                          KitchenElementLongDescription longDescription) {
        this.name = name;
        this.description = description;
        this.longDescription = longDescription;
    }

    public KitchenElementName getName() {
        return name;
    }

    public void setName(KitchenElementName name) {
        this.name = name;
    }

    public KitchenElementDescription getDescription() {
        return description;
    }

    public void setDescription(KitchenElementDescription description) {
        this.description = description;
    }

    public KitchenElementLongDescription getLongDescription() {
        return longDescription;
    }

    public void setLongDescription(KitchenElementLongDescription longDescription) {
        this.longDescription = longDescription;
    }

}
