package it.vittualv.sample.type;


import org.hibernate.type.AbstractSingleColumnStandardBasicType;

/**
 *
 */
public class TrimmedStringType extends AbstractSingleColumnStandardBasicType<TrimmedString> {

    public TrimmedStringType() {
        super(TrimmedStringSqlTypeDescriptor.INSTANCE, new TrimmedStringTypeDescriptor());
    }

    @Override
    public String getName() {
        return "trimmed-string";
    }

}
