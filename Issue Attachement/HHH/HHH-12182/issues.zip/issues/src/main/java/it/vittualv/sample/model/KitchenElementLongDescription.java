package it.vittualv.sample.model;

import com.google.common.base.Objects;
import it.vittualv.sample.type.TrimmedStringType;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.Embeddable;

@Immutable
@Embeddable
@TypeDefs(value = {
        @TypeDef(name = "trimmed-string", typeClass = TrimmedStringType.class),
})
public class KitchenElementLongDescription {

    public final static KitchenElementLongDescription DRAWER_LONG_DESCRIPTION = new KitchenElementLongDescription("drawer long description");


    /*
    Could not determine type for: it.vittualv.sample.type.TrimmedString, at table: kitchen_element, for columns: [org.hibernate.mapping.Column(long_description)]
    @Column
    @Type(type = "trimmed-string")
    private TrimmedString description;*/

    @Type(type = "string-trim")
    private String description;

    public KitchenElementLongDescription() {

    }

    public KitchenElementLongDescription(String description) {
        //this.description = new TrimmedString(description);
        setDescription(description);
    }

    /*public TrimmedString getDescription()  {
        return description;
    }

    private void setDescription(TrimmedString description) {
        this.description = description;
    }*/


    public String getDescription(){
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof KitchenElementLongDescription)) {
            return false;
        }

        KitchenElementLongDescription that = (KitchenElementLongDescription) obj;

        return getDescription() != null && Objects.equal(getDescription(), that.getDescription());
    }

    @Override
    public int hashCode() {
        return 31;
    }


    @Override
    public String toString() {
        return getDescription().toString();
    }
}
