package it.vittualv.sample.model;

import com.google.common.base.Objects;
import it.vittualv.sample.type.StringTrimType;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.Embeddable;

@Immutable
@Embeddable
@TypeDefs(value = {
        @TypeDef(name = "string-trim", typeClass = StringTrimType.class),
})
public class KitchenName {

    public final static KitchenName TRIM = new KitchenName("Trim");

    @Type(type = "string-trim")
    private String name;

    public KitchenName() {

    }

    public KitchenName(String name) {
        this.name = name;
    }

    public String getName()  {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof KitchenName)) {
            return false;
        }

        KitchenName that = (KitchenName) obj;

        return getName() != null && Objects.equal(getName(), that.getName());
    }

    @Override
    public int hashCode() {
        return 31;
    }


    @Override
    public String toString() {
        return getName();
    }
}

