package it.vittualv.sample.model;

import com.google.common.base.Objects;
import it.vittualv.sample.type.StringTrimType;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.Embeddable;

@Immutable
@Embeddable
@TypeDefs(value = {
        @TypeDef(name = "string-trim", typeClass = StringTrimType.class),
})
public class KitchenElementName {

    public final static KitchenElementName DRAWER_NAME = new KitchenElementName("drawer");

    @Type(type = "string-trim")
    private String name;

    public KitchenElementName() {

    }

    public KitchenElementName(String name) {
        this.name = name;
    }

    public String getName()  {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof KitchenElementName)) {
            return false;
        }

        KitchenElementName that = (KitchenElementName) obj;

        return getName() != null && Objects.equal(getName(), that.getName());
    }

    @Override
    public int hashCode() {
        return 31;
    }


    @Override
    public String toString() {
        return getName();
    }
}
