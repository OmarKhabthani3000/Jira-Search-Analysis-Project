package it.vittualv.sample.type;

import org.hibernate.type.descriptor.WrapperOptions;
import org.hibernate.type.descriptor.java.AbstractTypeDescriptor;
import org.hibernate.type.descriptor.java.ImmutableMutabilityPlan;
import org.hibernate.type.descriptor.java.MutabilityPlan;

/**
 * Immutable
 */
public class StringTrimTypeDescriptor extends AbstractTypeDescriptor<String> {

    public StringTrimTypeDescriptor() {
        super( String.class );
    }

    @Override
    public <X> X unwrap(String value, Class<X> type, WrapperOptions options) {
        return (X) fromString(( value));
    }

    @Override
    public <X> String wrap(X value, WrapperOptions options) {
        return toString((String) value);
    }

    @Override
    public String fromString(String string) {
        return string.trim();
    }

    @Override
    public String toString(String value) {
        return ((String) value).trim();
    }

    @Override
    @SuppressWarnings({ "unchecked" })
    public MutabilityPlan<String> getMutabilityPlan() {
        return ImmutableMutabilityPlan.INSTANCE;
    }
}
