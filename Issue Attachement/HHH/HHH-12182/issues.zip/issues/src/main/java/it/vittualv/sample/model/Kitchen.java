package it.vittualv.sample.model;

import it.vittualv.sample.type.StringTrimType;
import it.vittualv.sample.type.StringTrimType2;
import it.vittualv.sample.type.TrimmedStringType;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import java.util.HashSet;
import java.util.Set;

@Entity
@TypeDefs(value = {
        @TypeDef(name = "string-trim", typeClass = StringTrimType.class),
        @TypeDef(name = "string-trim2", typeClass = StringTrimType2.class),
        @TypeDef(name = "trimmed-string", typeClass = TrimmedStringType.class),
})
public class Kitchen {

    @Id
    protected Long id;

    @Embedded
    @AttributeOverrides(value = {
            @AttributeOverride(name = "name", column = @Column(name = "name", columnDefinition = "char(10)", nullable = false))
    })
    KitchenName name;

    @Fetch(FetchMode.SUBSELECT)
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "kitchen_element", joinColumns=@JoinColumn(name="kitchen_id"))
    protected Set<KitchenElement> elements = new HashSet<>();

    public Kitchen() {}

    public Kitchen(final Long anId,
                   final KitchenName aName) {
        setId(anId);
        setName(aName);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long anId) {
        this.id = anId;
    }

    public KitchenName getName() {
        return name;
    }

    public void setName(KitchenName name) {
        this.name = name;
    }

    public Set<KitchenElement> getElements() {
        return elements;
    }

    public void addElement(KitchenElement anElement) {
        elements.add(anElement);
    }
}
