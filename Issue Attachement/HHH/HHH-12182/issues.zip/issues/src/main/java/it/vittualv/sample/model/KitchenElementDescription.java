package it.vittualv.sample.model;

import com.google.common.base.Objects;
import it.vittualv.sample.type.StringTrimType2;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.Embeddable;

@Immutable
@Embeddable
@TypeDefs(value = {
        @TypeDef(name = "string-trim2", typeClass = StringTrimType2.class),
})
public class KitchenElementDescription {

    public final static KitchenElementDescription DRAWER_DESCRIPTION = new KitchenElementDescription("drawer description");

    @Type(type = "string-trim")
    private String description;

    public KitchenElementDescription() {

    }

    public KitchenElementDescription(String description) {
        this.description = description;
    }

    public String getDescription()  {
        return description;
    }

    private void setDescription(String description) {
        this.description = description;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof KitchenElementDescription)) {
            return false;
        }

        KitchenElementDescription that = (KitchenElementDescription) obj;

        return getDescription() != null && Objects.equal(getDescription(), that.getDescription());
    }

    @Override
    public int hashCode() {
        return 31;
    }


    @Override
    public String toString() {
        return getDescription();
    }
}
