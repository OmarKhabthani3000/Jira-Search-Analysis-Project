package it.vittualv.sample.type;


import com.google.common.base.Objects;
import org.hibernate.annotations.Immutable;

/**
 * @author A. Vitturi - Electrolux IT
 */
@Immutable
public class TrimmedString {

    private final String trimmed;

    public TrimmedString(final String trimmed){
        this.trimmed = trimmed.trim();
    }

    public String getValue() {
        return trimmed.trim();
    }

    @Override
    public String toString() {
        return getValue().toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof TrimmedString)) {
            return false;
        }

        TrimmedString that = (TrimmedString) obj;

        return getValue() != null && Objects.equal(getValue(), that.getValue());
    }

    @Override
    public int hashCode() {
        return 31;
    }
}
