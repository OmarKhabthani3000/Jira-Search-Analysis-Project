package it.vittualv.sample.type;

import org.hibernate.type.descriptor.WrapperOptions;
import org.hibernate.type.descriptor.java.AbstractTypeDescriptor;
import org.hibernate.type.descriptor.java.ImmutableMutabilityPlan;
import org.hibernate.type.descriptor.java.MutabilityPlan;

/**
 *
 */
public class TrimmedStringTypeDescriptor extends AbstractTypeDescriptor<TrimmedString> {

    public TrimmedStringTypeDescriptor() {
        super( TrimmedString.class );
    }

    @Override
    public <X> X unwrap(TrimmedString value, Class<X> type, WrapperOptions options) {
        return (X) value.getValue();
    }

    @Override
    public <X> TrimmedString wrap(X value, WrapperOptions options) {
        return fromString((String) value);
    }

    @Override
    public TrimmedString fromString(String string) {
        return new TrimmedString(string);
    }

    @Override
    public String toString(TrimmedString value) {
        return value.getValue();
    }

    @Override
    @SuppressWarnings({ "unchecked" })
    public MutabilityPlan<TrimmedString> getMutabilityPlan() {
        return ImmutableMutabilityPlan.INSTANCE;
    }
}

