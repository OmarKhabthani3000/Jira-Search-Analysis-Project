package it.vittualv.sample.type.test;

import it.vittualv.sample.model.Kitchen;
import it.vittualv.sample.model.KitchenElement;
import it.vittualv.sample.model.KitchenElementDescription;
import it.vittualv.sample.model.KitchenElementLongDescription;
import it.vittualv.sample.model.KitchenElementName;
import it.vittualv.sample.model.KitchenName;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;


public class StringTrimType2Test extends BaseEntityManagerFunctionalTestCase  {


    @Test
    public void testTypeOnCollectionOfEmbeddable() {
        EntityManager em = getOrCreateEntityManager();
        em.getTransaction().begin();

        Long anId = 1l;

        Kitchen kitchen = em.find(Kitchen.class, anId);

        if(kitchen==null) {
            KitchenElement kitchenElement = new KitchenElement(KitchenElementName.DRAWER_NAME,
                    KitchenElementDescription.DRAWER_DESCRIPTION,
                    KitchenElementLongDescription.DRAWER_LONG_DESCRIPTION);

            kitchen = new Kitchen(anId, KitchenName.TRIM);

            kitchen.addElement(kitchenElement);

            em.persist(kitchen);
        }

        em.getTransaction().commit();
        em.close();


        em = getOrCreateEntityManager();
        em.getTransaction().begin();

        kitchen = em.find(Kitchen.class, anId);

        for(KitchenElement element: kitchen.getElements()) {
            assertEquals("Must be the same", element.getDescription(), KitchenElementDescription.DRAWER_DESCRIPTION );
        }


        em.getTransaction().commit();
        em.close();
    }

    @Override
    public Class[] getAnnotatedClasses() {
        return new Class[]{
                Kitchen.class
        };
    }
}
