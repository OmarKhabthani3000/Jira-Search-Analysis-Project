package org.hibernate.bugs;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Persistence;
import java.util.List;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	/**
	 * This entity will be loaded directly while it's member lazilyLoaded will
	 * not. It will be loaded during debug printing, resulting in the ConcurrentModificationException.
	 */
	@Entity
	public static final class TestEntity {

		@Id
		@GeneratedValue
		private Integer id;

		@ManyToOne(fetch = FetchType.LAZY) // Required to ensure lazy loading!
		private LazyilyLoaded lazilyLoaded;
	}

	/**
	 * This class must be lazily loaded during the test in order to exhibit the bug
	 */
	@Entity
	public static class LazyilyLoaded {

		@Id
		@GeneratedValue
		private Integer id;
	}

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		// First create and persist one LazyilyLoaded loaded entity which we'll require later
		LazyilyLoaded lazyilyLoaded = new LazyilyLoaded();
		entityManager.persist(lazyilyLoaded);

		// We require at least 2 testEntities, otherwise the bug will not appear,
		// because the "iterator" in EntityPrinter::toString() :109 will only be called once
		// and the second "Iterator::next()" call is necessary in order to exhibit the ConcurrentModificationException
		TestEntity testEntity1 = new TestEntity();
		testEntity1.lazilyLoaded = lazyilyLoaded;
		entityManager.persist(testEntity1);

		TestEntity testEntity2 = new TestEntity();
		testEntity2.lazilyLoaded = lazyilyLoaded;
		entityManager.persist(testEntity2);

		// Begin with a clean slate, cleared cache etc.
		entityManager.getTransaction().commit();
		entityManager.close();
		entityManagerFactory.getCache().evictAll();
		entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.clear();

		// Query both test entities in order to fill the map with at least 2 entries in order to trigger the Exception.
		final List<TestEntity> queriedEntities = entityManager.createQuery("select t from JPAUnitTestCase$TestEntity t", TestEntity.class).getResultList();

		// And finally, during the flush in here the exception will exhibit itself
		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
