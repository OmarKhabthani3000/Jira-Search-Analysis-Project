package stalequerycache;

import java.io.Serializable;
import java.util.concurrent.CountDownLatch;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

public class DelayLoadOperations extends EmptyInterceptor {

    private volatile CountDownLatch blockLatch;
    private volatile CountDownLatch waitLatch;
    
    @Override
    public boolean onLoad(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {

        // Synchronize load and update activities
        try {
            if (waitLatch != null) {
                waitLatch.countDown();
                waitLatch = null;
            }
            if (blockLatch != null) {
                blockLatch.await();
                blockLatch = null;
            }
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return true;
    }

    public void blockOnLoad() {
        blockLatch = new CountDownLatch(1); 
        waitLatch = new CountDownLatch(1); 
    }

    public void waitOnLoad() throws InterruptedException {
        waitLatch.await();
        
    }

    public void unblockOnLoad() {
        if (blockLatch != null) {
            blockLatch.countDown();
        }
    }


}
