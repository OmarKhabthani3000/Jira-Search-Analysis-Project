package stalequerycache;

import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.log4j.BasicConfigurator;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.junit.Before;
import org.junit.Test;

import com.iontrading.stalequerycache.Contact;

import junit.framework.Assert;

public class QueryCacheTest {
    private SessionFactory sessionFactory;
    
    private ExecutorService executor = Executors.newFixedThreadPool(4);

    private DelayLoadOperations interceptor = new DelayLoadOperations();
    
    @Before
    public void before() {
        BasicConfigurator.configure();
        sessionFactory = new Configuration().setInterceptor(interceptor)
            .addAnnotatedClass(Contact.class)
            .configure()
            .buildSessionFactory();
    }

    @Test
    public void test() throws InterruptedException, ExecutionException {
        // Insert cities as in 1992
        final Contact contact1 = new Contact();
        contact1.setName("Bill Clinton");
        contact1.setCity("Washington");
        insertContact(contact1);

        final Contact contact2 = new Contact();
        contact2.setName("Barack Obama");
        contact2.setCity("Chicago");
        insertContact(contact2);

        // Now let's amend situation as in 2012, and query who lives in
        // Washington concurrently
        interceptor.blockOnLoad();
        
        Future<Contact> fetchedContact = executor.submit(new Callable<Contact>() {
            public Contact call() throws Exception {
                return findContactByCity("Washington");
            }
        });

        // wait for the onLoad listener to be called
        interceptor.waitOnLoad();

        // Let's amend addresses as in 2012

        // "Bill Clinton" moves to New York
        contact1.setCity("New York");
        updateContact(contact1);

        // "Barak Obama" moves to Washington
        contact2.setCity("Washington");
        updateContact(contact2);

        interceptor.unblockOnLoad();
        
        // the concurrent query was executed before the data was amended so
        // let's expect "Bill Clinton" to be returned as living in Washington
        Contact fetched = fetchedContact.get();
        Assert.assertEquals("Bill Clinton", fetched.getName());

        // Query again: now "Barack Obama" is expected to live in Washington
        fetched = findContactByCity("Washington");
        Assert.assertEquals("Barack Obama", fetched.getName());

    }

    private void updateContact(Contact toInsert) {
        Session s = sessionFactory.openSession();
        try {
            Transaction t = s.beginTransaction();
            s.update(toInsert);
            t.commit();
        } finally {
            s.close();
        }
    }

    private void insertContact(Contact toInsert) {
        Session s = sessionFactory.openSession();
        try {
            Transaction t = s.beginTransaction();
            s.save(toInsert);
            t.commit();
        } finally {
            s.close();
        }
    }

    private Contact findContactByCity(String address) {
        Contact fetched;
        Session s = sessionFactory.openSession();
        try {
            fetched = (Contact) s.createCriteria(Contact.class)
                .setCacheable(true)
                .setReadOnly(true)
                .add(Restrictions.eq("city", address))
                .uniqueResult();

        } finally {
            s.close();
        }
        return fetched;
    }

}
