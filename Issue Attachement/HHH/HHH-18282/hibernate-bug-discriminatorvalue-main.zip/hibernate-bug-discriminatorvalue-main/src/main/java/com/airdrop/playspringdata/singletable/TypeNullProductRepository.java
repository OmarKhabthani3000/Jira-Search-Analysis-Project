package com.airdrop.playspringdata.singletable;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TypeNullProductRepository extends JpaRepository<TypeNullProduct, Long> {
}
