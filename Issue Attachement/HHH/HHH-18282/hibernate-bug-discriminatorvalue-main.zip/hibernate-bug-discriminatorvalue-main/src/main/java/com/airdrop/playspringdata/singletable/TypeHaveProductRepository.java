package com.airdrop.playspringdata.singletable;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TypeHaveProductRepository extends JpaRepository<TypeHaveProduct, Long> {
}
