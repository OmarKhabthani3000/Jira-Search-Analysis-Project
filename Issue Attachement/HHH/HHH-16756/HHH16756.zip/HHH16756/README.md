# HHH16756
Testcase for Hibernate ticket [HHH-16756](https://hibernate.atlassian.net/browse/HHH-16756).
