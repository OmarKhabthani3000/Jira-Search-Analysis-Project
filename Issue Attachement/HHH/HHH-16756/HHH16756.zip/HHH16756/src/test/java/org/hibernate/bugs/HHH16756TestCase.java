package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.bugs.entity.Entity1;
import org.hibernate.bugs.entity.Entity2;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertNull;


/**
 * @author Jeroen Gremmen
 */
public class HHH16756TestCase extends BaseCoreFunctionalTestCase
{
  private int id;


  @Override
  protected Class<?>[] getAnnotatedClasses()
  {
    return new Class<?>[] {
        Entity1.class,
        Entity2.class
    };
  }


  @Before
  public void initDb()
  {
    Session s = openSession();
    Transaction tx = s.beginTransaction();

    Entity1 e1 = new Entity1();
    Entity2 e2 = new Entity2();

    e1.setChild(e2);

    e2.setCaseNumber("TEST");
    e2.setParent(e1);

    id = (int)session.save(e1);

    tx.commit();
    s.close();
  }


  @Test
  public void hhh16756Test()
  {
    Session s = openSession();
    Transaction tx = s.beginTransaction();

    Entity1 e1 = session.byId(Entity1.class).load(id);
    e1.setChild(null);

    session.flush();

    // entity 2 should be gone...
    assertNull(session.byId(Entity2.class).load(id));

    tx.commit();
    s.close();
  }
}
