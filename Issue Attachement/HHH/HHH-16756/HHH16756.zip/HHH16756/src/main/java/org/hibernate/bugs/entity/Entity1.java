package org.hibernate.bugs.entity;

import org.hibernate.annotations.*;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.*;
import java.io.Serializable;

import static javax.persistence.CascadeType.ALL;
import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.IDENTITY;
import static org.hibernate.annotations.FetchMode.SELECT;
import static org.hibernate.annotations.LazyToOneOption.NO_PROXY;


/**
 * @author Jeroen Gremmen
 */
@Entity
@Table(name = "entity1")
@DynamicInsert
@DynamicUpdate
public class Entity1 implements Serializable
{
  @Id @GeneratedValue(strategy = IDENTITY)
  @Column(name = "id", unique = true, nullable = false, updatable = false, columnDefinition = "smallint")
  protected int id;

  @Version @Column(name = "lock_version", nullable = false, columnDefinition = "smallint")
  protected int lockVersion;

  @OneToOne(fetch = LAZY, cascade = ALL, orphanRemoval = true, mappedBy = "parent")
  @LazyToOne(NO_PROXY) @LazyGroup("group2")
  @Fetch(SELECT)
  protected Entity2 child;


  public void setChild(Entity2 child) {
    this.child = child;
  }
}
