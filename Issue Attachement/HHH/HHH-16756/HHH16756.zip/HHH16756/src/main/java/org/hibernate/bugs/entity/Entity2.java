package org.hibernate.bugs.entity;

import org.hibernate.annotations.*;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.*;
import java.io.Serializable;

import static javax.persistence.FetchType.LAZY;
import static org.hibernate.annotations.FetchMode.SELECT;
import static org.hibernate.annotations.LazyToOneOption.NO_PROXY;


/**
 * @author Jeroen Gremmen
 */
@Entity
@Table(name = "entity2")
@DynamicInsert
@DynamicUpdate
public class Entity2 implements Serializable
{
  @Id
  @OneToOne(fetch = LAZY, optional = false)
  @LazyToOne(NO_PROXY) @LazyGroup("owner")
  @JoinColumn(name = "parentid", nullable = false, updatable = false, columnDefinition = "smallint")
  @Fetch(SELECT)
  protected Entity1 parent;

  @Column(name = "case_number", columnDefinition = "char(10)")
  protected String caseNumber;


  public void setParent(Entity1 parent) {
    this.parent = parent;
  }


  public void setCaseNumber(String caseNumber) {
    this.caseNumber = caseNumber;
  }
}
