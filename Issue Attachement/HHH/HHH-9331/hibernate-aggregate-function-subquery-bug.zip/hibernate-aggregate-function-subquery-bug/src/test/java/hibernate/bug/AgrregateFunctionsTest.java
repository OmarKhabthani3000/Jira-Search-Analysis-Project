package hibernate.bug;

import hibernate.bug.model.Document;
import hibernate.bug.model.Person;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class AgrregateFunctionsTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p1 = new Person();
        Person p2 = new Person();
        Document d = new Document();
        
        p1.getLocalized().put(1, "p1.1");
        p1.getLocalized().put(2, "p1.2");
        p2.getLocalized().put(1, "p2.1");
        p2.getLocalized().put(2, "p2.2");
        
        d.getContacts().put(1, p1);
        d.getContacts().put(2, p2);
        
        em.persist(p1);
        em.persist(p2);
        em.persist(d);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testSum() {
        EntityManager em = emf.createEntityManager();
       
        List l = em.createQuery("SELECT d.id, SUM((SELECT COUNT(localized) FROM Person p LEFT JOIN p.localized localized WHERE p.id = c.id)) AS localizedCount FROM Document d LEFT JOIN d.contacts c GROUP BY d.id").getResultList();
        Assert.assertEquals(2, l.size());
    }
    
    @Test
    public void testMin() {
        EntityManager em = emf.createEntityManager();
       
        List l = em.createQuery("SELECT d.id, MIN((SELECT COUNT(localized) FROM Person p LEFT JOIN p.localized localized WHERE p.id = c.id)) AS localizedCount FROM Document d LEFT JOIN d.contacts c GROUP BY d.id").getResultList();
        Assert.assertEquals(2, l.size());
    }
    
    @Test
    public void testMax() {
        EntityManager em = emf.createEntityManager();
       
        List l = em.createQuery("SELECT d.id, MAX((SELECT COUNT(localized) FROM Person p LEFT JOIN p.localized localized WHERE p.id = c.id)) AS localizedCount FROM Document d LEFT JOIN d.contacts c GROUP BY d.id").getResultList();
        Assert.assertEquals(2, l.size());
    }
    
    @Test
    public void testAvg() {
        EntityManager em = emf.createEntityManager();
       
        List l = em.createQuery("SELECT d.id, AVG((SELECT COUNT(localized) FROM Person p LEFT JOIN p.localized localized WHERE p.id = c.id)) AS localizedCount FROM Document d LEFT JOIN d.contacts c GROUP BY d.id").getResultList();
        Assert.assertEquals(2, l.size());
    }
    
    @Test
    public void testCount() {
        EntityManager em = emf.createEntityManager();
       
        List l = em.createQuery("SELECT d.id, COUNT((SELECT COUNT(localized) FROM Person p LEFT JOIN p.localized localized WHERE p.id = c.id)) AS localizedCount FROM Document d LEFT JOIN d.contacts c GROUP BY d.id").getResultList();
        Assert.assertEquals(2, l.size());
    }
}
