insert into acme.users (id, name, password, version) values (1, 'admin', 'admin', 0);
insert into acme.user_roles (user_id, role) values (1, 'ADMIN');
insert into acme.user_roles (user_id, role) values (1, 'USER');

insert into acme.users (id, name, password, version) values (2, 'user', 'user', 0);
insert into acme.user_roles (user_id, role) values (2, 'USER');

insert into acme.users (id, name, password, version) values (3, 'adminonly', 'admin', 0);
insert into acme.user_roles (user_id, role) values (3, 'ADMIN');
