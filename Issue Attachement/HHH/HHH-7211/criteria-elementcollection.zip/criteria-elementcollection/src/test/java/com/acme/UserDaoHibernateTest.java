package com.acme;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

@RunWith( SpringJUnit4ClassRunner.class )
@ContextConfiguration( { "classpath*:/META-INF/spring/acme*context.xml" } )
@TestExecutionListeners( DependencyInjectionTestExecutionListener.class )
public class UserDaoHibernateTest
{
    @Resource( name = "dao.UserDao" )
    private IUserDao userDao;

    @Test
    public void countWithHQL()
    {
        int count = this.userDao.countWithHQL( "ADMIN" );
        assertThat( count, is( 2 ) );
    }

    @Test
    public void countWithCriteria()
    {
        int count = this.userDao.countWithCriteria( "ADMIN" );
        assertThat( count, is( 2 ) );
    }
}
