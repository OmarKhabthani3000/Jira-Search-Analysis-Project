package com.acme;

public interface IUserDao
{
    int countWithCriteria( String... roles );

    int countWithHQL( String... roles );
}
