/**
 * Contains DAO interfaces and implementations and additional support classes like Hibernate user types.
 *
 * @author Lars Heller
 * @version $Id: package-info.java 5785 2012-01-04 13:18:56Z lhe $
 */
@TypeDefs( { @TypeDef( name = "joda-localdatetime", typeClass = org.jadira.usertype.dateandtime.joda.PersistentLocalDateTime.class ) } )
package com.acme;

import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

