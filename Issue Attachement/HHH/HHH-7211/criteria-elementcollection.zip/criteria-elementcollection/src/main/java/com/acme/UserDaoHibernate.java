package com.acme;

import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

@Repository( "dao.UserDao" )
public class UserDaoHibernate
    implements IUserDao
{
    @Resource( name = "sessionFactory" )
    private SessionFactory sessionFactory;

    @Override
    public int countWithCriteria( String... roles )
    {
        Criteria criteria = currentSession().createCriteria( User.class, "u" );
        criteria.createAlias( "roles", "r", JoinType.INNER_JOIN );
        criteria.add( Restrictions.in( "roles", roles ) );

        criteria.setProjection( Projections.countDistinct( "id" ) );

        return ( (Number) criteria.uniqueResult() ).intValue();
    }

    @Override
    public int countWithHQL( String... roles )
    {
        String qs = "select count(distinct u) from User u join u.roles r where r in (:roles)";
        Query q = currentSession().createQuery( qs );
        q.setParameterList( "roles", roles );
        return ( (Number) q.uniqueResult() ).intValue();
    }

    private Session currentSession()
    {
        return this.sessionFactory.getCurrentSession();
    }
}
