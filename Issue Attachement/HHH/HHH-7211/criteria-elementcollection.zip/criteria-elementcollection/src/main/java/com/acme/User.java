package com.acme;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDateTime;

@Entity
@Table( name = "users" )
public class User
    implements Serializable
{
    private static final long serialVersionUID = 1L;

    private Long id;

    private String name;

    private String password;

    private Set<String> roles = new HashSet<String>();

    private Integer version;

    private LocalDateTime lastLogin;

    /**
     * Answer the technical entity id of this user.
     */
    @Id
    @SequenceGenerator( name = "user_seq", sequenceName = "user_seq", initialValue = 1000 )
    @GeneratedValue( strategy = GenerationType.AUTO, generator = "user_seq" )
    @Column( name = "id", nullable = false, precision = 19, scale = 0 )
    public Long getId()
    {
        return this.id;
    }

    public void setId( Long id )
    {
        this.id = id;
    }

    /**
     * Answer the login name of this user.
     */
    @Column( name = "name", length = 50, unique = true, nullable = false )
    public String getName()
    {
        return this.name;
    }

    public void setName( String name )
    {
        this.name = name;
    }

    /**
     * Answer the user's password. The user itself doesn't know if the password is hashed or not. This is completely up
     * to the business logic.
     */
    @Column( name = "password", length = 256, nullable = false )
    public String getPassword()
    {
        return this.password;
    }

    public void setPassword( String password )
    {
        this.password = password;
    }

    /**
     * Answer the user's {@link Role}s.
     */
    @ElementCollection( fetch = FetchType.EAGER )
    @CollectionTable( name = "user_roles", joinColumns = @JoinColumn( name = "user_id" ) )
    @Column( name = "role", length = 20 )
    @Fetch( FetchMode.SELECT )
    public Set<String> getRoles()
    {
        return this.roles;
    }

    /**
     * Answer the user's last sign-in date-time.
     */
    @Column( name = "last_login_at" )
    @Type( type = "joda-localdatetime" )
    public LocalDateTime getLastLogin()
    {
        return this.lastLogin;
    }

    public void setLastLogin( LocalDateTime lastLogin )
    {
        this.lastLogin = lastLogin;
    }

    public void setRoles( Set<String> roles )
    {
        this.roles = roles;
    }

    @Column( name = "version", precision = 10, scale = 0 )
    @Version
    public Integer getVersion()
    {
        return this.version;
    }

    public void setVersion( Integer version )
    {
        this.version = version;
    }
}
