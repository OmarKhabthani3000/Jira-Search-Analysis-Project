package com.example.demo.repos;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.DemoApplication.Author;

public interface AuthorRepository extends CrudRepository<Author, Long> {
    
}
