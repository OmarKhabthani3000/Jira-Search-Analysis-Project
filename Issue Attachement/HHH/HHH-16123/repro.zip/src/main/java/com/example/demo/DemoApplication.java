package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.example.demo.repos.AuthorParticipationRepository;
import com.example.demo.repos.AuthorRepository;
import com.example.demo.repos.PublicationRepository;
import com.example.demo.repos.ShortBookRepository;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@EnableTransactionManagement
@RequiredArgsConstructor
@SpringBootApplication
public class DemoApplication implements CommandLineRunner {

    private final PublicationRepository publicationRepository;
    private final AuthorRepository authorRepository;
    private final ShortBookRepository shortBookRepository;
    private final AuthorParticipationRepository authorParticipationRepository;

    @Transactional
    @Override
    public void run(String... args) throws Exception {
        final var JOHN = "John Doe";
        
        var author = new Author();
        author.setName(JOHN);
        authorRepository.save(author);

        var shortBook = new ShortBook();
        shortBook.setTitle("Book 1");
        shortBookRepository.save(shortBook);

        var authorParticipation = new AuthorParticipation();
        authorParticipation.setAuthor(author);
        authorParticipation.setBook(shortBook);
        authorParticipationRepository.save(authorParticipation);

        publicationRepository.findAll(
                (root, query, criteriaBuilder) -> {
                    var asBook = criteriaBuilder.treat(root, Book.class);
                    var joinAuthors = asBook.join("participations");

                    return criteriaBuilder.equal(
                            joinAuthors
                                    .get("author")
                                    .get("name"),
                            JOHN);
                });
    }

    @Getter
    @Setter
    @MappedSuperclass
    public class BaseEntity {

        @Id
        @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hibernate_sequence")
        @Column(name = "id", nullable = false, updatable = false)
        private long id;

    }

    @Entity
    @Table
    @Getter
    @Setter
    @NoArgsConstructor
    public class Author extends BaseEntity {

        @Column(name = "name")
        private String name;

    }

    @Entity
    @Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
    @Getter
    @Setter
    public abstract class Publication extends BaseEntity {

        @Column(name = "title")
        private String title;

    }

    @Entity
    @Table
    @Getter
    @Setter
    @NoArgsConstructor
    public class Article extends Publication {}

    @Entity
    @Getter
    @Setter
    @NoArgsConstructor
    public abstract class Book extends Publication {

        @OneToMany(mappedBy = "book", cascade = CascadeType.REMOVE)
        private List<AuthorParticipation> participations = new ArrayList<>();

    }

    @Entity
    @Table
    @Getter
    @Setter
    @NoArgsConstructor
    public class LongBook extends Book {}

    @Entity
    @Table
    @Getter
    @Setter
    @NoArgsConstructor
    public class ShortBook extends Book {}

    @Entity
    @Table
    @Getter
    @Setter
    @NoArgsConstructor
    public class AuthorParticipation extends BaseEntity {

        @ManyToOne
        @JoinColumn(name = "id_author", nullable = false)
        private Author author;

        @ManyToOne
        @JoinColumn(name = "id_book", nullable = false)
        private Book book;

    }

    public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

}
