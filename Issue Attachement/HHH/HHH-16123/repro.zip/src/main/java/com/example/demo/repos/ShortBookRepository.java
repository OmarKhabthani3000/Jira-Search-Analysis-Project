package com.example.demo.repos;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.DemoApplication.ShortBook;

public interface ShortBookRepository extends CrudRepository<ShortBook, Long> {
    
}
