package com.example.demo.repos;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.DemoApplication.Publication;

public interface PublicationRepository extends CrudRepository<Publication, Long>, JpaSpecificationExecutor<Publication> {

}
