package org.hibernate.test.hbmbinder;

import java.util.HashMap;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.engine.FilterDefinition;
import org.hibernate.test.TestCase;

public class HbmBinderTest extends TestCase
{

	// This throws a NPE unless the filter definition is included.
	protected void addMappings(String[] files, Configuration cfg) {
//		cfg.addFilterDefinition( new FilterDefinition(
//				"securityFilter","true",new HashMap()) );
		super.addMappings(files, cfg);
	}
	
	public void testAnything() throws Exception {
		// this will never be reached.
	}
	
    // unimportant ---------------
    
	protected String[] getMappings()
    {
        return new String[]{
          "hbmbinder/Experimenter.hbm.xml",
        };
    }
    
    public HbmBinderTest(String str) {
        super(str);
    }

    public static Test suite() {
        return new TestSuite(HbmBinderTest.class);
    }
}
