package com.example.demo;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface MyUserRepository extends JpaRepository<MyUser, Integer> {

    @Query("select r from MyUser r where r.firstname = :firstname and r.lastname = :lastname")
    List<MyUser> getRechnungsstellung(@Param("firstname") String firstname, @Param("lastname") String lastname);
}
