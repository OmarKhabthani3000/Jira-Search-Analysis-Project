package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

/**
 * @author jorth
 */
@ExtendWith(SpringExtension.class)
@SpringBootTest
public class MyUserTest {
    @Autowired
    public MyUserRepository repo;

    @Test
    public void getRechnungsstellung1() {
        List<MyUser> l = repo.getRechnungsstellung(null, null);
        assertEquals(1, l.size());
    }
}
