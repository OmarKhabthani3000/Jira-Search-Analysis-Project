package com.example.demo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Entity
//@Table(name = "MY_USER", catalog = "vertrag", schema = "dbo")
@Table(name = "MY_USER")
@Getter
@Setter
@EqualsAndHashCode
public class MyUser {

    @Id
    @Column(name = "MY_USER_ID", unique = true, nullable = false)
    private Integer myUserId;
    
    @Column(name = "FIRSTNAME")
    private String firstname;
    
    @Column(name = "LASTNAME")
    private boolean lastname;
}
