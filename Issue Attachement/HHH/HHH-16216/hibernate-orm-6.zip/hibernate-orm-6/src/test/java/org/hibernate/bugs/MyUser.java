package org.hibernate.bugs;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
//@Table(name = "MY_USER", catalog = "vertrag", schema = "dbo")
@Table(name = "MY_USER")
public class MyUser {

    @Id
    @Column(name = "MY_USER_ID", unique = true, nullable = false)
    private Integer myUserId;
    
    @Column(name = "FIRSTNAME")
    private String firstname;
    
    @Column(name = "LASTNAME")
    private boolean lastname;

    public Integer getMyUserId() {
        return myUserId;
    }

    public void setMyUserId(Integer myUserId) {
        this.myUserId = myUserId;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public boolean isLastname() {
        return lastname;
    }

    public void setLastname(boolean lastname) {
        this.lastname = lastname;
    }
}
