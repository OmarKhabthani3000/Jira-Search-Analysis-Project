package org.hibernate.bugs.entity;

import java.math.BigDecimal;
import java.math.BigInteger;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class MyEntity
{
    @Id
    @Column
    public BigInteger id;
    
    @Column
    public BigDecimal dec;
    
    public MyEntity()
    {
        // Default constructor
    }
    
    public MyEntity(int id)
    {
        this.id = BigInteger.valueOf(id);
        this.dec = BigDecimal.valueOf(id);
    }
}
