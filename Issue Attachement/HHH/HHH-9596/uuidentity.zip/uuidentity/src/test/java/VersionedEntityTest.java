import at.uuidentity.Application;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.ManagedType;
import javax.persistence.metamodel.SingularAttribute;
import java.util.HashSet;
import java.util.Set;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = Application.class)
public class VersionedEntityTest {
    private EntityManager entityManager;

    @PersistenceContext
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Test
    public void testVersionAvailableForEntity() {
        Set<String> entitiesWithoutVersion = new HashSet<>();
        Set<String> entitiesWithVersion = new HashSet<>();
        Set<EntityType<?>> entities = entityManager.getMetamodel().getEntities();
        for (EntityType<?> entity : entities) {
            SingularAttribute<?, ?> versionAttribute = findVersionAttribute(entity);
            if (versionAttribute == null) {
                entitiesWithoutVersion.add(entity.getName());
            } else {
                entitiesWithVersion.add(entity.getName());
            }
        }

        // output is:
        // java.lang.AssertionError: Version is null for entities: DummyEntity,DummyEntity2
        // but available for entities: DummyEntityCopy
        // -> if a @MappedSuperclass with @Version is subclassed more than once, then the version attribute is not
        // handled correctly

        Assert.assertTrue("Version is null for entities: " + String.join(",", entitiesWithoutVersion)
                        + "\n but available for entities: " + String.join(",", entitiesWithVersion),
                entitiesWithoutVersion.isEmpty());
    }

    // 1:1 copy from org.springframework.data.jpa.repository.support.JpaMetamodelEntityInformation
    private static <T> SingularAttribute<? super T, ?> findVersionAttribute(ManagedType<T> type) {

        Set<SingularAttribute<? super T, ?>> attributes = type.getSingularAttributes();

        for (SingularAttribute<? super T, ?> attribute : attributes) {
            if (attribute.isVersion()) {
                return attribute;
            }
        }

        return null;
    }
}
