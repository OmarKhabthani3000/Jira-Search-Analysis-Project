package at.uuidentity.domain;

import javax.persistence.Entity;

@Entity
public class DummyEntity2 extends DistributedEntity {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }
}
