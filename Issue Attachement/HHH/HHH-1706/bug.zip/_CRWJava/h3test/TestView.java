package h3test;

import java.io.Serializable;
import java.util.Date;

public class TestView implements Serializable {
    private Long id;
	private String value1;
	private String value2;

    public TestView(Long id, String value1, String value2) {
        this.id = id;
        this.value1 = value1;
        this.value2 = value2;
    }

    public TestView() { }

    public TestView(Long id) {
        this.id = id;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

	public String getValue1() {
		return value1;
	}

	public void setValue1(String string) {
		value1 = string;
	}

	public String getValue2() {
		return value2;
	}

	public void setValue2(String string) {
		value2 = string;
	}

}
