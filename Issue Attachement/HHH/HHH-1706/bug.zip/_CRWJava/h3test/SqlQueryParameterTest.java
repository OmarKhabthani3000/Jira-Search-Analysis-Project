/*
 ****************************************************************!
 *                                                               !
 *               Confidentiality Information:                    !
 *                                                               !
 *                                                               !
 * This module contains confidential and proprietary information !
 * of Rentway, Inc.; it is not to be copied, reproduced, or      !
 * transmitted in any form, by any means, in whole or in part,   !
 * nor is it to be used for any purpose other than for the       !
 * automated operation of Rentway operations or administrative   !
 * Corporate functions.                                          !
 *                                                               !
 * Copyright (c) 2004 - 2005  Rentway, Inc. All Rights Reserved. !
 ****************************************************************!
 */
package h3test;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.rentway.common.util.DateUtil;

import junit.framework.TestCase;

public class SqlQueryParameterTest extends TestCase {

	public SqlQueryParameterTest(String arg0) {
		super(arg0);
	}

	public void test1() throws Exception {
		List results;
		SessionFactory sessFactory = null;
		Session sess = null;
		try {
			Configuration config = new Configuration().configure("/test.cfg.xml");
	
			sessFactory = config.buildSessionFactory();
			assertNotNull(sessFactory);
			System.out.println("^^^ Got SessionFactory ...");
	
			sess = sessFactory.openSession();
			assertNotNull(sess);
			System.out.println("^^^ Got Session ...");

			System.out.println("^^^ Test query1");
			results =
					sess
						.getNamedQuery("query1")
						.setParameter("p1", "value1", Hibernate.STRING)
						.setParameter("p2", "value2", Hibernate.STRING)
						.list();
			assertNotNull(results);
			assertEquals(results.size(), 1);

		} finally {
			if (sess != null) { sess.close(); sess = null; }
			if (sessFactory != null) { sessFactory.close(); sessFactory = null; }
		}
	}

	public void test2() throws Exception {
		List results;
		SessionFactory sessFactory = null;
		Session sess = null;
		try {
			Configuration config = new Configuration().configure("/test.cfg.xml");
	
			sessFactory = config.buildSessionFactory();
			assertNotNull(sessFactory);
			System.out.println("^^^ Got SessionFactory ...");
	
			sess = sessFactory.openSession();
			assertNotNull(sess);
			System.out.println("^^^ Got Session ...");

			System.out.println("^^^ Test query2");
			results =
					sess
						.getNamedQuery("query2")
						.setParameter("p1", "value1", Hibernate.STRING)
						.setParameter("p2", "value2", Hibernate.STRING)
						.list();
			assertNotNull(results);
			assertEquals(results.size(), 1);

		} finally {
			if (sess != null) { sess.close(); sess = null; }
			if (sessFactory != null) { sessFactory.close(); sessFactory = null; }
		}
	}

}
