Test case for https://hibernate.atlassian.net/browse/HHH-8109

HOWTO
-----

Run with
$ mvn clean package

The unit test is expecting an exception which is not thrown in Hibernate 4.2.0.Final

To see regression, change the Hibernate version in pom.xml


hibernate.hbm2ddl.auto and Hibernate version
--------------------------------------------

Test always runs fine with hibernate.hbm2ddl.auto=create

Test runs fine with Hibernate 4.1.9.Final AND hibernate.hbm2ddl.auto=update

Test fails with Hibernate 4.2.0.Final AND hibernate.hbm2ddl.auto=update
