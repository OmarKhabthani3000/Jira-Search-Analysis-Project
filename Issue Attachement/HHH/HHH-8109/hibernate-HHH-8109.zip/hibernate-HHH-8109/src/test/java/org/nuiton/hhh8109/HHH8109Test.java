package org.nuiton.hhh8109;

/*
 * #%L
 * Test case for HHH-8109
 * %%
 * Copyright (C) 2013 Code Lutin
 * %%
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as 
 * published by the Free Software Foundation, either version 3 of the 
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Lesser Public License for more details.
 * 
 * You should have received a copy of the GNU General Lesser Public 
 * License along with this program.  If not, see
 * <http://www.gnu.org/licenses/lgpl-3.0.html>.
 * #L%
 */

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import java.util.UUID;

public class HHH8109Test {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void setUp() throws Exception {
        entityManagerFactory = Persistence.createEntityManagerFactory("org.nuiton.hhh8109");
    }

    @After
    public void tearDown() throws Exception {
        entityManagerFactory.close();
    }

    @Test
    public void testCreateDuplicateEntry() {

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        // Create and persist a user instance
        User user = new User();
        user.setId(UUID.randomUUID().toString());
        user.setLogin("arno");
        user.setFirstName("Arnaud");
        user.setLastName("Thimel");
        entityManager.persist(user);

        // Create and persist a thread instance
        Thread thread = new Thread();
        thread.setId(UUID.randomUUID().toString());
        thread.setNaturalId("Whatever thread");
        entityManager.persist(thread);

        entityManager.getTransaction().commit();
        entityManager.close();


        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        // Create a first association class between "user" and "thread"
        ThreadUserAssociation threadUserAssociation01 = new ThreadUserAssociation();
        threadUserAssociation01.setId(UUID.randomUUID().toString());
        threadUserAssociation01.setUser(user);
        threadUserAssociation01.setThread(thread);
        threadUserAssociation01.setNbMessage(3);

        // Create a second association class between "user" and "thread" (should not be possible because of unique constraint)
        ThreadUserAssociation threadUserAssociation02 = new ThreadUserAssociation();
        threadUserAssociation02.setId(UUID.randomUUID().toString());
        threadUserAssociation02.setUser(user);
        threadUserAssociation02.setThread(thread);
        threadUserAssociation02.setNbMessage(1);

        // Persist the 2 association classes
        entityManager.persist(threadUserAssociation01);
        entityManager.persist(threadUserAssociation02);

        try {
            // Should fail during flush because of unique constraint in ThreadUserAssociation
            entityManager.getTransaction().commit();
            Assert.fail("2 association classes created against unique constraint");
        } catch (PersistenceException pe) {
            // This is the expected behavior
        }
        entityManager.close();
    }

}
