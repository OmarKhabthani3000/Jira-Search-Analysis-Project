package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "simple_entity")
public class SimpleEntity {

	@Id
	public long id;
	
	public SimpleEntity(long id) {
		this.id = id;
	}
}
