package hhh8602;

import java.text.DateFormat;
import java.util.Locale;
import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Property;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.query.AuditEntity;
import org.hibernate.envers.query.AuditQuery;

public class HHH8602
{
	private final SessionFactory sessionFactory;

	private HHH8602()
	{
		sessionFactory = setupDatabase();
	}

	private SessionFactory setupDatabase()
	{
		Properties properties = new Properties();
		Configuration configuration = new Configuration();

		properties.put("hibernate.connection.driver_class", "org.hsqldb.jdbc.JDBCDriver");
		properties.put("hibernate.connection.url", "jdbc:hsqldb:mem:hhh8602");
		properties.put("hibernate.connection.username", "sa");
		properties.put("hibernate.connection.password", "");
		properties.put("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
		properties.put("hibernate.cache.use_second_level_cache", "false");
		properties.put("hibernate.hbm2ddl.auto", "create");
		properties.put("hibernate.show_sql", "true");
		properties.put("hibernate.format_sql", "true");
		properties.put("hibernate.default_schema", "PUBLIC");

		configuration.setProperties(properties);
		configuration.addAnnotatedClass(Calendar.class);
		configuration.addAnnotatedClass(Holiday.class);
		configuration.addPackage(Calendar.class.getPackage().getName());

		return configuration.buildSessionFactory();
	}

	private void insertData()
	{
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();

		Calendar calendar = new Calendar();
		calendar.setName("HHH8602");
		calendar.setCountry("DE");
		calendar.setProvince("BW");
		calendar.setValidityYear(2013);

		Holiday holiday = new Holiday();
		holiday.setName("Christmas Eve");
		holiday.setCalendar(calendar);
		holiday.setDay(java.util.Calendar.getInstance());
		holiday.getDay().set(2013, java.util.Calendar.DECEMBER, 24, 0, 0, 0);
		calendar.getHolidays().add(holiday);

		holiday = new Holiday();
		holiday.setName("Christmas");
		holiday.setCalendar(calendar);
		holiday.setDay(java.util.Calendar.getInstance());
		holiday.getDay().set(2013, java.util.Calendar.DECEMBER, 25, 0, 0, 0);
		calendar.getHolidays().add(holiday);

		holiday = new Holiday();
		holiday.setName("St.Stephen's Day");
		holiday.setCalendar(calendar);
		holiday.setDay(java.util.Calendar.getInstance());
		holiday.getDay().set(2013, java.util.Calendar.DECEMBER, 26, 0, 0, 0);
		calendar.getHolidays().add(holiday);

		session.save(calendar);

		transaction.commit();
		session.close();
	}

	private void printData()
	{
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.FULL, Locale.US);
		Calendar calendar;
		AuditReader auditReader;
		AuditQuery query;

		calendar = (Calendar) session.createCriteria(Calendar.class).add(Property.forName(Calendar.PROPERTY_NAME).eq("HHH8602")).uniqueResult();

		System.out.println("=============================================");
		System.out.println("Calendar loaded via plain criteria:");
		System.out.println(calendar);
		for (Holiday holiday : calendar.getHolidays())
		{
			System.out.println(holiday.getName() + ": " + dateFormat.format(holiday.getDay().getTime()));
		}
		System.out.println("=============================================");

		// same thing via audit query
		auditReader = AuditReaderFactory.get(session);

		// return getAuditReader().find(p_class, p_id, p_revision);
		query = auditReader.createQuery().forRevisionsOfEntity(Calendar.class, true, true);
		query.add(AuditEntity.id().eq(calendar.getId()));

		for (Object auditCalendar : query.getResultList())
		{
			calendar = (Calendar) auditCalendar;
			System.out.println("=============================================");
			System.out.println("Calendar loaded via audit query:");
			System.out.println(calendar);
			for (Holiday holiday : calendar.getHolidays())
			{
				System.out.println(holiday.getName() + ": " + dateFormat.format(holiday.getDay().getTime()));
			}
			System.out.println("=============================================");
		}

		transaction.commit();
		session.close();
	}

	public static void main(final String[] args)
	{
		HHH8602 test = new HHH8602();

		test.insertData();

		test.printData();
	}
}
