@TypeDefs({ 
	@TypeDef(defaultForType = java.util.Calendar.class, 
			name = "calendar", 
			typeClass = UTCCalendarType.class, 
			parameters = { @Parameter(name = UTCCalendarType.PROPERTY_NAME_TIMEZONE_ID,	value = "UTC") }),
	@TypeDef(defaultForType = java.util.Calendar.class, 
			name = "calendar_date", 
			typeClass = UTCCalendarType.class, 
			parameters = { @Parameter(name = UTCCalendarType.PROPERTY_NAME_TIMEZONE_ID, value = "UTC") })
})
package hhh8602;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
