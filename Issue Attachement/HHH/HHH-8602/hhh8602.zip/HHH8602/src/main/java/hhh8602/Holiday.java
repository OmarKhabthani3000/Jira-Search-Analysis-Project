package hhh8602;

import java.util.UUID;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.envers.Audited;

@Entity
@Table(name = "Holiday")
@Audited
@TypeDef(name = "hibernate_calendar_date", typeClass = org.hibernate.type.CalendarDateType.class)
public class Holiday
{
	public static final String PROPERTY_ID = "id";
	public static final String PROPERTY_VERSION = "version";
	public static final String PROPERTY_NAME = "name";
	public static final String PROPERTY_DAY = "day";
	public static final String PROPERTY_CALENDAR = "calendar";

	/*
	 * Changed id creation strategy from hibernate-generated value to assigned value. This has some very nice features
	 * including that equals() and hashcode() implementations of this class are sufficient for all entities. For more
	 * details read http://onjava.com/pub/a/onjava/2006/09/13/dont-let-hibernate -steal-your-identity.html?page=1
	 */
	@Id
	@Access(AccessType.PROPERTY)
	// 128bit UUID => 16 Byte => as Hex-String 32 chars + four '-' chars
	@Column(name = PROPERTY_ID, length = 36, nullable = false)
	// private final String id = IdGenerator.generateId();
	private String id = UUID.randomUUID().toString();

	@Version
	@Column(name = PROPERTY_VERSION)
	private final Integer version = null;

	@Column(length = 60, name = "name", nullable = false)
	private String name;

	@Column(name = "day", nullable = false)
	@Type(type = "hibernate_calendar_date")
	private java.util.Calendar day = java.util.Calendar.getInstance();

	@ManyToOne(fetch = FetchType.LAZY)
	@Fetch(FetchMode.SELECT)
	@JoinColumn(name = "calendarId", updatable = false, nullable = false)
	private Calendar calendar;

	public String getId()
	{
		return id;
	}

	public void setId(final String p_id)
	{
		id = p_id;
	}

	public Integer getVersion()
	{
		return version;
	}

	public String getName()
	{
		return name;
	}

	public void setName(final String p_name)
	{
		name = p_name;
	}

	public java.util.Calendar getDay()
	{
		return day;
	}

	public void setDay(final java.util.Calendar p_day)
	{
		day = p_day;
	}

	public Calendar getCalendar()
	{
		return calendar;
	}

	public void setCalendar(final Calendar calendar)
	{
		this.calendar = calendar;
	}

	@Override
	public String toString()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("Holiday [id=");
		builder.append(id);
		builder.append(", version=");
		builder.append(version);
		builder.append(", name=");
		builder.append(name);
		builder.append(", day=");
		builder.append(day);
		builder.append(", calendar=");
		builder.append(calendar != null ? calendar.getId() : null);
		builder.append("]");
		return builder.toString();
	}
}
