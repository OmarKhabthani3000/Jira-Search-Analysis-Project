package hhh8602;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.envers.Audited;

@Entity
@Table(name = "Calendar")
@Audited
public class Calendar
{
	public final static String PROVINCE_IMPORT = "!IMPORTED!";

	public static final String PROPERTY_ID = "id";
	public static final String PROPERTY_VERSION = "version";
	public final static String PROPERTY_NAME = "name";
	public final static String PROPERTY_VALIDITY_YEAR = "validityYear";
	public final static String PROPERTY_COUNTRY = "country";
	public final static String PROPERTY_PROVINCE = "province";
	public final static String PROPERTY_HOLIDAY = "holidays";

	/*
	 * Changed id creation strategy from hibernate-generated value to assigned value. This has some very nice features
	 * including that equals() and hashcode() implementations of this class are sufficient for all entities. For more
	 * details read http://onjava.com/pub/a/onjava/2006/09/13/dont-let-hibernate -steal-your-identity.html?page=1
	 */
	@Id
	@Access(AccessType.PROPERTY)
	// 128bit UUID => 16 Byte => as Hex-String 32 chars + four '-' chars
	@Column(name = PROPERTY_ID, length = 36, nullable = false)
	// private final String id = IdGenerator.generateId();
	private String id = UUID.randomUUID().toString();

	@Version
	@Column(name = PROPERTY_VERSION)
	private Integer version = null;

	@Column(length = 60, name = "name", nullable = false)
	private String name;

	@Column(name = "validityYear")
	private Integer validityYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);

	@Column(name = "country", length = 10, nullable = false)
	private String country = "DE";

	@Column(name = "province", length = 10)
	private String province;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "calendar", cascade = CascadeType.ALL)
	@Fetch(FetchMode.SUBSELECT)
	private final Set<Holiday> holidays = new HashSet<Holiday>();

	public String getId()
	{
		return id;
	}

	public void setId(final String p_id)
	{
		id = p_id;
	}

	public Integer getVersion()
	{
		return version;
	}

	public void setVersion(final Integer p_version)
	{
		version = p_version;
	}

	public String getName()
	{
		return name;
	}

	public void setName(final String p_name)
	{
		name = p_name;
	}

	public String getCountry()
	{
		return country;
	}

	public void setCountry(final String p_country)
	{
		country = p_country;
	}

	public String getProvince()
	{
		return province;
	}

	public void setProvince(final String p_province)
	{
		province = p_province;
	}

	public Integer getValidityYear()
	{
		return validityYear;
	}

	public void setValidityYear(final Integer p_validityYear)
	{
		validityYear = p_validityYear;
	}

	public Set<Holiday> getHolidays()
	{
		return holidays;
	}

	@Override
	public String toString()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("Calendar [id=");
		builder.append(id);
		builder.append(", version=");
		builder.append(version);
		builder.append(", name=");
		builder.append(name);
		builder.append(", validityYear=");
		builder.append(validityYear);
		builder.append("]");
		return builder.toString();
	}
}
