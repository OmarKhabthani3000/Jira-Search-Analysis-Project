package hhh8602;

import java.util.Calendar;
import java.util.TimeZone;

public class DateUtil
{
	/**
	 * <p>
	 * If the given {@link Calendar} is not in the {@link TimeZone} given, then its time is converted into the desired time zone by subtracting the
	 * offsets defined in that time zone.
	 * </p>
	 *
	 * @param p_calendar
	 *            the target {@link Calendar} which remains untouched
	 * @param p_timeZone
	 *            the desired {@link TimeZone}
	 * @return a clone of the given {@link Calendar} applied with the target timezone settings
	 */
	public static Calendar convertToTimeZone(final Calendar p_calendar, final TimeZone p_timeZone)
	{
		Calendar calendar = p_calendar;

		if (calendar != null)
		{
			calendar = (Calendar) calendar.clone();

			TimeZone currentTimeZone = calendar.getTimeZone();
			if (!currentTimeZone.equals(p_timeZone))
			{
				int currentOffset = currentTimeZone.getOffset(calendar.getTimeInMillis());
				int targetOffset = p_timeZone.getOffset(calendar.getTimeInMillis());
				int offset = currentOffset - targetOffset;
				calendar.add(Calendar.MILLISECOND, -offset);
				calendar.setTimeZone(p_timeZone);
			}
		}

		return calendar;
	}
}
