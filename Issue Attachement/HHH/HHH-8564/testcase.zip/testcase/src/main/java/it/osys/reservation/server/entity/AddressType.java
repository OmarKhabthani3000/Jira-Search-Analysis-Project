package it.osys.reservation.server.entity;

public enum AddressType {

	OFFICE, HOME, BILLING

}
