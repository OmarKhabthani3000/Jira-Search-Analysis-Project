package it.osys.reservation.server.entity;

import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Embeddable
public class Address {

	@ElementCollection(fetch = FetchType.EAGER)
	@Enumerated(EnumType.STRING)
	private Set<AddressType> type;

	@NotNull
	@Size(min = 3, max = 200)
	private String street;

	@NotNull
	@Pattern(regexp = "[0-9]{5}")
	private String zipcode;

	@NotNull
	@Size(min = 3, max = 60)
	private String city;

	@NotNull
	@Size(min = 3, max = 60)
	private String state;

}