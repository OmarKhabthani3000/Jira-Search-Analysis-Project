#!/bin/sh

mvn clean compile hibernate4:export
