/*
 * Created on Oct 3, 2006
 * Copyright 2006 by Patrick Moore
 */
package hibernatetests.testemptyone2one;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import junit.framework.TestCase;

public class TestEmptyOneToOne extends TestCase {

    private Configuration configuration;
    public TestEmptyOneToOne(String arg0) {
        super(arg0);
    }

    protected void setUp() throws Exception {
        super.setUp();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }
    public void testEmptyOneToOneNativeNative() throws Exception {
        runTest("ENTITY1");
    }
    public void testEmptyOneToOneNativeForeign() throws Exception {
        runTest("ENTITY2");
    }
    public void testEmptyOneToOneNativeConstrained() throws Exception {
        runTest("ENTITY3");
    }
    private void runTest(String entityNames) throws Exception {
        configuration = new Configuration().configure("/hibernatetests/testemptyone2one/TestEmptyOneToOne.cfg.xml");
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.getCurrentSession();
        session.beginTransaction();
        Primary p1 = new Primary();
        Secondary s1 = null;
        session.save(entityNames, p1);
        
        Primary p2 = new Primary();
        Secondary s2 = new Secondary();
        p2.secondary = s2;
        s2.primary = p2;
        session.save(entityNames, p2);
        session.getTransaction().commit();
        
        session = sessionFactory.getCurrentSession();
        session.beginTransaction();
        Primary p1prime = (Primary) session.get(entityNames, p1.entityId);
        Primary p2prime = (Primary) session.get(entityNames, p2.entityId);
        assertNull(p1prime.secondary);
        assertNotNull(p2prime.secondary);
    }

}
