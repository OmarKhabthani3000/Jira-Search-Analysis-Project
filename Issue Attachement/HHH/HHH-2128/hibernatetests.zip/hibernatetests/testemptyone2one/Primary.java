/*
 * Created on Oct 3, 2006
 * Copyright 2006 by Patrick Moore
 */
package hibernatetests.testemptyone2one;

public class Primary {
    public Long entityId;
    public Secondary secondary;
}
