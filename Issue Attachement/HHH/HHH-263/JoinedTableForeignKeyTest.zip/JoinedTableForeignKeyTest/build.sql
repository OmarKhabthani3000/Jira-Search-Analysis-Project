create table department (
   id number(18),
   name varchar2(30),
   constraint pk_department primary key (id)
)
/

create table person (
   id number(18),
   name varchar2(30),
   constraint pk_person primary key (id)
)
/

create table employee (
   person_id number(18),
   department_id number(18),
   title varchar2(30),
   constraint pk_employee primary key(person_id),
   constraint fk_emp_person foreign key (person_id) references person(id),
   constraint fk_emp_dept foreign key (department_id) references department(id)
)
/

insert into department values(1,'Human Resources')
/

insert into person values(1,'Jane Doe')
/

insert into employee values(1,1,'Manager')
/

