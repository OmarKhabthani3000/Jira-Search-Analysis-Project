package test;

import java.util.Set;
import java.util.HashSet;

public class Department {

    private Long id;
    private String name;
    private Set employees = new HashSet();

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setEmployees(Set employees) {
        this.employees = employees;
    }

    public Set getEmployees() {
        return employees;
    }

}
