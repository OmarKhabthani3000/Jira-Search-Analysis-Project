package test;

import org.hibernate.*;
import org.hibernate.cfg.*;
import org.hibernate.type.*;

import java.sql.*;
import java.util.Properties;
import java.util.Iterator;
import java.io.FileInputStream;
import java.math.BigDecimal;

public class Test {
    public static void main(String[] argv) {
        Session sess = null;

        try {

            Configuration cfg = new Configuration();
            cfg.addFile("mapping.xml");
            cfg.addProperties(loadProperties());
            SessionFactory fact = cfg.buildSessionFactory();
            sess = fact.openSession();

            Department dept = (Department)sess.get(Department.class,new Long(1));
            for (Iterator empIter = dept.getEmployees().iterator();empIter.hasNext();) {
                System.out.println("Loaded employee: " + empIter.next());
            }
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
        finally {
            if (sess != null) sess.close();
        }
    }

    private static Properties loadProperties() throws Exception {
        Properties props = new Properties();
        FileInputStream propStream = new FileInputStream("test.properties");
        props.load(propStream);
        propStream.close();
        return props;
    }
}
