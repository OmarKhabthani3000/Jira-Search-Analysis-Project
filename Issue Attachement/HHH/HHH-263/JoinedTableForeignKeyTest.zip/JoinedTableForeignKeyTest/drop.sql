drop table employee
/

drop table person
/

drop table department
/

