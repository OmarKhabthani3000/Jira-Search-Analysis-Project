package org.hibernate.bugs.model;

import lombok.Getter;

/**
 * <p>This is a derived enum (not persisted) that represents the state of a {@link TransactionEntity}.</p>
 * <p>Depending on the type of transaction, it may have differing criteria for determining whether
 * it is ready to be processed or not. Therefore, this abstraction exists to make it easier to determine the status a
 * transaction without having to implement transaction-type-specific logic all throughout the application.</p>
 */
@Getter
public enum TransactionStatus {

    /**
     * The transaction has been processed in an {@link BillingPeriodEntity}.
     */
    BILLED,

    /**
     * The transaction is awaiting processing.
     */
    READY,

    /**
     * The {@link Payment} that this transaction is linked to reached a failure status.
     */
    FAILED,

    /**
     * The transaction is awaiting a payment status change.
     */
    PENDING;

    public boolean isBilled() {
        return this == BILLED;
    }

    public boolean isReady() {
        return this == READY;
    }

    public boolean isFailed() {
        return this == FAILED;
    }

    public boolean isPending() {
        return this == PENDING;
    }

}
