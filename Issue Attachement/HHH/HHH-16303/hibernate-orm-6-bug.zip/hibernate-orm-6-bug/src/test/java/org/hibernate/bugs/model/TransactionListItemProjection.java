package org.hibernate.bugs.model;

import java.util.UUID;

public interface TransactionListItemProjection {

    UUID getId();

    String getReference();

    TransactionType getType();

}
