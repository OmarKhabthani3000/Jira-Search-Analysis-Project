package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.*;
import org.hibernate.bugs.model.BillingPeriodEntity;
import org.hibernate.bugs.model.TransactionEntity;
import org.hibernate.bugs.model.TransactionSearchQuery;
import org.hibernate.bugs.model.TransactionSearchResultItem;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.time.ZonedDateTime;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh16303Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        // region custom code
        final TransactionSearchQuery query = TransactionSearchQuery.builder()
            .reference(null)
            .type(null)
            .isFinalized(false)
            .finalizedResult(null)
            .finalizedFromIncl(null)
            .finalizedUntilExcl(null)
            .matchEitherBillingPeriodIdOrFinalizationWindow(false)
            .billingPeriodId(null)
            .isBilled(null)
            .createdOnFromIncl(null)
            .createdOnUntilExcl(null)
//            .createdOnUntilExcl(ZonedDateTime.parse("2023-03-10T15:12:17.397715400+01:00[Europe/Amsterdam]"))
            .draw(0)
            .start(0)
            .length(0)
            .sortColumn(null)
            .sortAscending(false)
            .build();

        final CriteriaBuilder builder = entityManagerFactory.getCriteriaBuilder();

        final CriteriaQuery<TransactionSearchResultItem> itemQuery =
            builder.createQuery(TransactionSearchResultItem.class);

        final Root<TransactionEntity> transactions = itemQuery.from(TransactionEntity.class);
        transactions.alias("results"); // Important for counting!

        // Try to join the billing period to get the name.
        final Join<TransactionEntity, BillingPeriodEntity> billingPeriodEntityJoin =
            transactions.join("billingPeriod", JoinType.LEFT);

        // Select the columns from the primary table.
        itemQuery.multiselect(
            transactions.get("id"),
            transactions.get("reference"),
            transactions.get("type"),
            transactions.get("finalizedResult"),
            transactions.get("finalizedAt"),
            transactions.get("billingPeriodId"),
            billingPeriodEntityJoin.get("name").alias("billingPeriodName"),
            transactions.get("billedAt"),
            transactions.get("paymentId"),
            transactions.get("createdOn"));

        // Join all conditions, defaulting to a 1=1 check to make it easier on ourselves.
        Expression<Boolean> where = builder.equal(builder.literal(1), 1);

        /*
            COMMON
         */
        if (query.getReference() != null) {
            where = builder.and(where, builder.like(builder.lower(transactions.get("reference")),
                "%" + query.getReference().toLowerCase() + "%"));
        }
        if (query.getType() != null) {
            where = builder.and(where, builder.equal(transactions.get("type"), query.getType()));
        }

        /*
            CREATED ON
         */
        if (query.getCreatedOnFromIncl() != null) {
            where = builder.and(where, builder.greaterThanOrEqualTo(transactions.get("createdOn"),
                builder.literal(query.getCreatedOnFromIncl())));
        }
        if (query.getCreatedOnUntilExcl() != null) {
            where = builder.and(where,
                builder.lessThan(transactions.get("createdOn"), builder.literal(query.getCreatedOnUntilExcl())));
        }

        /*
            FINALIZED
         */
        if (query.getIsFinalized() != null) {
            if (query.getIsFinalized()) {
                where = builder.and(where, transactions.get("finalizedResult").isNotNull());
            } else {
                where = builder.and(where, transactions.get("finalizedResult").isNull());
            }
        }
        if (query.getFinalizedResult() != null) {
            where = builder.and(where, builder.equal(transactions.get("finalizedResult"), query.getFinalizedResult()));
        }

        /*
            BILLING
         */

        if (query.getIsBilled() != null) {
            if (query.getIsBilled()) {
                where = builder.and(where, transactions.get("billingPeriodId").isNotNull());
            } else {
                where = builder.and(where, transactions.get("billingPeriodId").isNull());
            }
        }

        // See description of this field for an explanation.
        final boolean matchBillingPeriodOrRange = query.isMatchEitherBillingPeriodIdOrFinalizationWindow();
        final boolean hasPeriodId = query.getBillingPeriodId() != null;
        final boolean hasPeriodRange = query.getFinalizedFromIncl() != null && query.getFinalizedUntilExcl() != null;

        if (matchBillingPeriodOrRange && hasPeriodId && hasPeriodRange) {
            /*
                If the billingPeriodId and billingPeriod time window are both specified, they become an OR operation
                instead of an AND.
             */
            where = builder.and(
                where,
                builder.or(
                    builder.equal(transactions.get("billingPeriodId"), query.getBillingPeriodId()),
                    builder.and(
                        builder.isNull(transactions.get("billingPeriodId")),
                        builder.lessThan(transactions.get("finalizedAt"), query.getFinalizedUntilExcl())
                    )
                )
            );
        } else {
            if (query.getBillingPeriodId() != null) {
                where =
                    builder.and(where, builder.equal(transactions.get("billingPeriodId"), query.getBillingPeriodId()));
            }
            if (query.getFinalizedFromIncl() != null) {
                where = builder.and(where,
                    builder.greaterThanOrEqualTo(transactions.get("finalizedAt"), query.getFinalizedFromIncl()));
            }
            if (query.getFinalizedUntilExcl() != null) {
                where = builder.and(where,
                    builder.lessThan(transactions.get("finalizedAt"), query.getFinalizedUntilExcl()));
            }
        }
        itemQuery.where(where);

        // Add sorting if specified.
        if (query.getSortColumn() != null) {
            itemQuery.orderBy(query.isSortAscending()
                              ? builder.asc(transactions.get(query.getSortColumn()))
                              : builder.desc(transactions.get(query.getSortColumn())));
        }

        // Count our results in a separate query that uses the same conditions.
        final CriteriaQuery<Long> countQuery = builder.createQuery(Long.class);
        final Root<?> countRoot = countQuery.from(transactions.getJavaType());
        countRoot.alias("results"); // Must be equal to the other alias!
        countQuery.select(builder.count(countRoot));
        countQuery.where(where);

        final long count = entityManager.createQuery(countQuery).getSingleResult();
        assertEquals(1, count);

        // end region
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    private void assertEquals(final int i, final long count) {
    }
}
