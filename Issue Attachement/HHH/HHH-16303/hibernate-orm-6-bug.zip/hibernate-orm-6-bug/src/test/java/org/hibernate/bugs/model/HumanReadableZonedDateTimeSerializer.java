package org.hibernate.bugs.model;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Serializes a {@link ZonedDateTime} in the human-readable format: <code>yyyy-MM-dd HH:mm:ss</code>.
 * Null-values are passed through unaffected.
 */
public class HumanReadableZonedDateTimeSerializer extends StdSerializer<ZonedDateTime> {

    protected HumanReadableZonedDateTimeSerializer() {
        super(ZonedDateTime.class);
    }

    @Override
    public void serialize(final ZonedDateTime value,
                          final JsonGenerator gen,
                          final SerializerProvider provider) throws IOException {
        if (value == null) {
            return;
        }

        gen.writeString(value.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
    }

}
