package org.hibernate.bugs.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.jetbrains.annotations.Nullable;

import java.time.ZonedDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionSearchResultItem implements TransactionListItemProjection {

    private UUID id;

    private String reference;
    private TransactionType type;

    private Boolean finalizedResult;
    @JsonSerialize(using = HumanReadableZonedDateTimeSerializer.class)
    private ZonedDateTime finalizedAt;

    private @Nullable UUID billingPeriodId;
    private @Nullable String billingPeriodName;
    private @Nullable ZonedDateTime billedAt;

    private UUID paymentId;

    @JsonSerialize(using = HumanReadableZonedDateTimeSerializer.class)
    private ZonedDateTime createdOn;

    public TransactionStatus getStatus() {
        // Null-safe boolean check. DO NOT SIMPLIFY.
        // Failed status has higher priority than a "Billed" status. Failed transactions are also linked to periods.
        if (Boolean.FALSE.equals(getFinalizedResult())) {
            return TransactionStatus.FAILED;
        }

        // If a billing period is linked, the transaction was billed.
        if (getBillingPeriodId() != null) {
            return TransactionStatus.BILLED;
        }

        // If no payment status exists yet, it is blocked.
        if (getFinalizedResult() == null) {
            return TransactionStatus.PENDING;
        }

        // Otherwise, map the payment status to a transaction status.
        return getFinalizedResult() ? TransactionStatus.READY : TransactionStatus.FAILED;
    }

}
