package org.hibernate.bugs.model;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.util.Optional;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
public class DataTableQuery {

    /**
     * Sequentially incrementing ID to prevent out-of-order responses from messing up results.
     */
    private int draw;

    /**
     * Index of the first returned item (result offset).
     */
    private int start;

    /**
     * Amount of items to return.
     */
    private int length;

    /**
     * The column to sort by.
     */
    private String sortColumn;

    /**
     * Whether to sort the column ascending (true) or descending (false).
     */
    private boolean sortAscending;

    @JsonSetter("sortDirection")
    public void setSortDirection(final String sortDirection) {
        sortAscending = Optional.ofNullable(sortDirection)
            .map(str -> switch (str) {
                case "asc", "ascending" -> true;
                case "desc", "descending" -> false;
                default -> throw new IllegalArgumentException(sortDirection);
            })
            .orElse(false);
    }

}
