package org.hibernate.bugs.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import org.jetbrains.annotations.Nullable;

import java.time.ZonedDateTime;
import java.util.UUID;

/**
 * Represents a single transaction search query, usually from the transaction list page.
 */
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionSearchQuery extends DataTableQuery {

    /**
     * If set, filters to {@link TransactionEntity#getReference()} being similar (case insensitive).
     */
    private String reference;

    /**
     * If set, only transactions of the given type are returned.
     */
    private TransactionType type;

    /*
        FINALIZATION
     */

    /**
     * If set to a non-null value, filters: <code>(transaction.finalizedResult IS NOT NULL) = isFinalized</code>.
     */
    private @Nullable Boolean isFinalized;

    /**
     * If set, filters to transactions that have {@link TransactionEntity#getFinalizedAt()} equal to the given value.
     */
    private @Nullable Boolean finalizedResult;

    /**
     * If set, filters: <code>transaction.finalizedAt >= finalizedFromIncl</code>.
     */
    private @Nullable ZonedDateTime finalizedFromIncl;

    /**
     * If set, filters: <code>transaction.finalizedAt < finalizedUntilExcl</code>.
     */
    private @Nullable ZonedDateTime finalizedUntilExcl;

    /*
        BILLING
     */

    /**
     * If set to true, the {@link #billingPeriodId} is and {@link #finalizedFromIncl} to {@link #finalizedUntilExcl}
     * time range are matched as an <b>OR</b> operation instead of an <b>AND</b> operation. This is useful when trying
     * to match all transactions belonging to a billing period, either by time frame or by {@link #billingPeriodId}.
     */
    private boolean matchEitherBillingPeriodIdOrFinalizationWindow;

    /**
     * Works in conjunction with {@link #finalizedFromIncl} and {@link #finalizedUntilExcl}. Transactions are
     * matched if either of these conditions are true:
     * <ul>
     *     <li><b>This value</b> is specified and matches {@link TransactionEntity#getBillingPeriodId()};</li>
     *     <li>The {@link TransactionEntity#getFinalizedAt()} falls between {@link #finalizedFromIncl} and {@link #finalizedUntilExcl}.</li>
     * </ul>
     * matches <b>either</b> this billing period ID, or intersects with the time
     * window specified in {@link #finalizedFromIncl} and {@link #finalizedUntilExcl}.
     */
    private @Nullable UUID billingPeriodId;

    /**
     * If set to a non-null value, filters: <code>(transaction.billingPeriodId IS NOT NULL) = isBilled</code>.
     */
    private @Nullable Boolean isBilled;

    /*
        CREATED ON
     */

    /**
     * If set, filters: <code>transaction.createdOn >= createdOnFromIncl</code>.
     */
    private @Nullable ZonedDateTime createdOnFromIncl;

    /**
     * If set, filters: <code>transaction.createdOn < createdOnUntilExcl</code>.
     */
    private @Nullable ZonedDateTime createdOnUntilExcl;

}
