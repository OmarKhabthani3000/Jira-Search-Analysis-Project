package org.hibernate.bugs.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.Hibernate;

import java.time.ZonedDateTime;
import java.util.Objects;
import java.util.UUID;

/**
 * The {@link TransactionEntity} entity represents a single financial transaction.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@Table(name = "finance_transactions")
@Entity
public class TransactionEntity {

    @Id
    private UUID id;

    @Column(name = "parent_id")
    private UUID parentId;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id", referencedColumnName = "id", insertable = false, updatable = false)
    private TransactionEntity parent;

    @Column(name = "initiator_member_id")
    private UUID initiatorMemberId;

    @Enumerated(EnumType.STRING)
    private TransactionType type;

    private String reference;

    private String description;

    @Column(name = "payment_id")
    private UUID paymentId;

    @Column(name = "billing_period_id")
    private UUID billingPeriodId;

    @ToString.Exclude
    @Setter(AccessLevel.NONE)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "billing_period_id", referencedColumnName = "id", insertable = false, updatable = false)
    private BillingPeriodEntity billingPeriod;

    @Column(updatable = false)
    private ZonedDateTime createdOn;

    private ZonedDateTime finalizedAt;
    private Boolean finalizedResult;

    private ZonedDateTime billedAt;

    @Transient
    @JsonIgnore
    public TransactionStatus getStatus() {
        if (billingPeriodId != null) {
            return TransactionStatus.BILLED;
        }
        if (finalizedAt != null) {
            return finalizedResult ? TransactionStatus.READY : TransactionStatus.FAILED;
        }
        return TransactionStatus.PENDING;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) {
            return false;
        }
        final TransactionEntity that = (TransactionEntity) o;
        return id != null && Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }

}
