package org.hibernate.bugs.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@Entity
@ToString
@Table(name = "finance_billing_periods")
public class BillingPeriodEntity {

    @Id
    private UUID id;

    @Column(nullable = false)
    private String name;

    @OneToMany(mappedBy = "billingPeriod")
    private List<TransactionEntity> transactionEntities;

    @Column(nullable = false)
    private ZonedDateTime fromIncl;
    @Column(nullable = false)
    private ZonedDateTime untilExcl;

    private ZonedDateTime billedAt;

    @CreationTimestamp
    @Column(nullable = false, insertable = false, updatable = false)
    private ZonedDateTime createdOn;

    @UpdateTimestamp
    @Column(nullable = false, insertable = false, updatable = false)
    private ZonedDateTime modifiedOn;

}
