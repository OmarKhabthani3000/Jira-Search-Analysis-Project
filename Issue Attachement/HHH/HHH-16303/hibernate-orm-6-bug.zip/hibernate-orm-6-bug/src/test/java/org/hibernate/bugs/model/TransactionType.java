package org.hibernate.bugs.model;

import one.util.streamex.StreamEx;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public enum TransactionType {
    ORDER_PAYMENT,
    ORDER_REFUND,

    PURCHASE_PAYMENT,
    PURCHASE_REFUND,

    CORRECTION,
    PAYOUT;

    public boolean isOrder() {
        return this == ORDER_PAYMENT || this == ORDER_REFUND;
    }

    public boolean isOrderPayment() {
        return this == ORDER_PAYMENT;
    }

    public boolean isOrderRefund() {
        return this == ORDER_REFUND;
    }

    public boolean isPurchase() {
        return this == PURCHASE_PAYMENT || this == PURCHASE_REFUND;
    }

    public boolean isPurchasePayment() {
        return this == PURCHASE_PAYMENT;
    }

    public boolean isPurchaseRefund() {
        return this == PURCHASE_REFUND;
    }

    public boolean isPayout() {
        return this == PAYOUT;
    }

    public boolean isCorrection() {
        return this == CORRECTION;
    }

    public String getAbbreviation() {
        return switch (this) {
            case ORDER_PAYMENT -> "ord";
            case ORDER_REFUND -> "rfd";
            case PURCHASE_PAYMENT -> "prc";
            case PURCHASE_REFUND -> "pfd";
            case CORRECTION -> "cor";
            case PAYOUT -> "pyt";
        };
    }

    public static Map<Archetype, List<TransactionType>> valuesPerArchetype() {
        return StreamEx.of(values())
            .groupingBy(TransactionType::getArchetype, LinkedHashMap::new, Collectors.toList());
    }

    public Archetype getArchetype() {
        return switch (this) {
            case ORDER_PAYMENT, ORDER_REFUND -> Archetype.ORDER;
            case PURCHASE_PAYMENT, PURCHASE_REFUND -> Archetype.PURCHASE;
            case CORRECTION, PAYOUT -> Archetype.OTHER;
        };
    }

    public enum Archetype {
        ORDER,
        PURCHASE,
        OTHER;

        public boolean isOrder() {
            return this == ORDER;
        }

        public boolean isPurchase() {
            return this == PURCHASE;
        }

        public boolean isOther() {
            return this == OTHER;
        }
    }

}
