--
-- PostgreSQL database dump
--

-- Dumped from database version 13.5
-- Dumped by pg_dump version 13.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: finance_billing_periods; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.finance_billing_periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    from_incl timestamp with time zone NOT NULL,
    until_excl timestamp with time zone NOT NULL,
    billed_at timestamp with time zone,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    modified_on timestamp with time zone DEFAULT now() NOT NULL
);

--
-- Name: finance_transactions; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.finance_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    initiator_member_id uuid NOT NULL,
    type character varying(255) NOT NULL,
    reference character varying(255) NOT NULL,
    finalized_at timestamp with time zone,
    finalized_result boolean,
    billed_at timestamp with time zone,
    payment_id uuid,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    billing_period_id uuid,
    parent_id uuid,
    description character varying(2048)
);

--
-- Data for Name: finance_billing_periods; Type: TABLE DATA; Schema: public; Owner: user
--

--
-- Data for Name: finance_transactions; Type: TABLE DATA; Schema: public; Owner: user
--


--
-- Name: finance_billing_periods finance_billing_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.finance_billing_periods
    ADD CONSTRAINT finance_billing_periods_pkey PRIMARY KEY (id);


--
-- Name: finance_transactions pk_finance_transactions; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT pk_finance_transactions PRIMARY KEY (id);


--
-- Name: finance_transactions ui_finance_transactions_reference; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT ui_finance_transactions_reference UNIQUE (reference);


--
-- Name: finance_transactions_i_initiator_member_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX finance_transactions_i_initiator_member_id ON public.finance_transactions USING btree (initiator_member_id);


--
-- Name: i_finance_transactions_parent_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX i_finance_transactions_parent_id ON public.finance_transactions USING btree (parent_id);


--
-- Name: finance_transactions fk_finance_transactions_parent_id; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT fk_finance_transactions_parent_id FOREIGN KEY (parent_id) REFERENCES public.finance_transactions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: finance_transactions fk_transactions_billing_period_id; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT fk_transactions_billing_period_id FOREIGN KEY (billing_period_id) REFERENCES public.finance_billing_periods(id);


--
-- PostgreSQL database dump complete
--

