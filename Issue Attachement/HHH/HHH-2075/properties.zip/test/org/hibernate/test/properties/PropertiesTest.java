package org.hibernate.test.properties;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.TestCase;

/**
org.hibernate.PropertyValueException: not-null property references a null or transient value: org.hibernate.test.properties.Pixels.sizeC
at org.hibernate.engine.Nullability.checkNullability(Nullability.java:72)
at org.hibernate.event.def.AbstractSaveEventListener.performSaveOrReplicate(AbstractSaveEventListener.java:284)
*/
public class PropertiesTest extends TestCase
{
	
	/** this fails during the nullability check for an *Integer* which is clearly
	 * set in the test case
	 */
    public void testNullConstraintCheckOnTransient() throws Exception {
        Image i = new Image();
    	
    	Pixels p = new Pixels();
        p.setSizeC(new Integer(2));
        p.setImage(i); 				// This calls i.getPixels().add(p)
        // i.setPixels(null);		// This makes it work.
        
        Session s = openSession();
        Transaction t = s.beginTransaction();
        // s.merge(i);				// This makes it work.
        p = (Pixels) s.merge(p); 	// This fails with the exception above.
        t.commit();
        s.close();
    
        assertData();
        cleanup();
    
    }
    
    private void assertData() throws Exception {
    	Session s;
		Transaction t;
		s = openSession();
        t = s.beginTransaction();
        
        Long i = (Long)
        s.createQuery( "select count(*) from Pixels" ).uniqueResult();
        assertEquals( new Long(1), i );
        
        i = (Long)
        s.createQuery( "select count(*) from Pixels" ).uniqueResult();
        assertEquals( new Long(1), i );
        
        t.commit();
        s.close();
    }
    
	private void cleanup() {
		Session s;
		Transaction t;
		s = openSession();
        t = s.beginTransaction();
        s.createQuery( "delete Pixels" ).executeUpdate();
        s.createQuery( "delete Image" ).executeUpdate();
        t.commit();
        s.close();
	}
    
    protected String[] getMappings()
    {
        return new String[]{
          "properties/Image.hbm.xml",
          "properties/Pixels.hbm.xml"
        };
    }
	private static final Log LOG = LogFactory.getLog("org.hibernate.test.properties");
	    
    public PropertiesTest(String str) {
        super(str);
    }

    public static Test suite() {
        return new TestSuite(PropertiesTest.class);
    }
	
}
