package org.hibernate.test.properties;

import java.util.*;

public class Image  
{

     private Long id;
     private Set pixels = new HashSet(0);
     private Pixels defaultPixels;


	// Allow overriding of getter and setter logic.
	
	protected void preGetter( String field )
	{
		errorIfUnloaded();
	}
	
	protected void postGetter( String field ) {}
	
	protected void preSetter( String field, Object value )
	{
		errorIfUnloaded();
	}
	
	protected void postSetter( String field, Object value ) {}

	protected void throwNullCollectionException(String propertyName)
	{
		throw new RuntimeException(
			"Error updating collection:" + propertyName +"\n"+
			"Collection is currently null. This can be seen\n"+
			"by testing \"sizeOf"+ propertyName +" < 0\". This implies\n"+
			"that this collection was unloaded. Please refresh this object\n"+
			"in order to update this collection.\n"
			);
	}
	
	// Property accessors
    /**       
     *      *               The DB unique identifier for this object. You are not responsible for
     *               setting the id; however, it can be useful for creating "unloaded" 
     *               versions of your objects.            
     *             
     */

    public Long getId() {
		return this.id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }


	/** 
	 * returns pixels . You should not modify this Set unless you
	 * know what you are doing. Use the iterate method instead.
	 */
    protected Set getPixels() {

		try {
			preGetter( PIXELS );
			return this.pixels;
		} finally {
			postGetter( PIXELS );
		}
        
    }
	
	/** 
	 * setter for pixels should be avoided. Does not fulfill normal semantics.
	 */
    protected void setPixels(Set pixels) {
		
		try {
			preSetter( PIXELS, pixels );
			this.pixels = pixels;
		} finally {
			postSetter( PIXELS, pixels);
		}
        
    }

	/**
	 * returns the size of pixels. If less than zero, the Set was null.
	 */
	public int sizeOfPixels() {

		try {
			preGetter( PIXELS );
			return this.pixels == null ? -1 : this.pixels.size();
		} finally {
			postGetter( PIXELS );
		}
			
	}

	/**
	 * should be used rather than accessing the pixels set directly.
	 * This method will never return null, but rather will return an instance
	 * of {@link ome.util.EmptyIterator}. To test for a null collection,
	 * see of {@link #sizeOfPixels()} is less than zero.
	 */ 
	public Iterator iteratePixels() {
		
		try {
		
			preGetter( PIXELS );
		
    		if ( getPixels() == null )
    		{
    			return new Iterator(){
    				public boolean hasNext() {
    					return false;
    				}
    				public Object next() {
    					throw new UnsupportedOperationException();
    				}
    				public void remove() {
	    				throw new UnsupportedOperationException();	
    				}
    			};
    		}
    		return getPixels().iterator();

		} finally {
			postGetter( PIXELS );
		}
			
	}

	
	/** 
	 * use instead of setPixels . Makes the necessary
	 * call on ome.model.core.Pixels as well.
	 */
	public void addPixels(Pixels target) {
		
		try {
			preSetter( PIXELS, target );
		
    		if ( getPixels() == null )
				throwNullCollectionException("Pixels");
				
    		getPixels().add( target );
    		target.setImage ( this );
			
		} finally {
			postSetter( PIXELS, target );
		}
		
	}

	/** 
	 * use like addPixels. 
	 */
	public void addPixelsSet(Set targets) {
		
		try {
			preSetter( PIXELS, targets );

			if ( getPixels() == null )
				throwNullCollectionException("Pixels");

    		getPixels().addAll( targets );
    		Iterator it = targets.iterator();
    		while ( it.hasNext() )
    		{
    		  Pixels target = (Pixels) it.next();
    		  target.setImage ( this );
    		}
		
		} finally {
			postSetter( PIXELS, targets );
		}
		
	}
	
	/**
	 * removes a single element from this set and makes the inverse call on ome.model.core.Pixels 
	 */
	public void removePixels(Pixels target) {
		
		try {
			preSetter( PIXELS, target );

			if ( getPixels() == null )
				throwNullCollectionException("Pixels");

   			getPixels().remove( target );
    		target.setImage ( null );
			
		} finally {
			postSetter( PIXELS, target );
		}
		
	}

	/**
	 * use like removePixels
	 */
	public void removePixelsSet( Set targets ) {
		
		try {
			preSetter( PIXELS, targets );

			if ( getPixels() == null )
				throwNullCollectionException("Pixels");

   			getPixels().removeAll( targets );
    		Iterator it = targets.iterator();
    		while ( it.hasNext() ) 
    		{
    			Pixels target = (Pixels) it.next();
    			target.setImage ( null );
    		}
    			
		} finally {
			postSetter( PIXELS, targets );
		}
		
	}
	
	/**
	 * clears the set. 
	 */
	public void clearPixels() {
	
		try {
			preSetter( PIXELS, null );

			if ( getPixels() == null )
				throwNullCollectionException("Pixels");
			
			getPixels().clear();
    		Iterator it = iteratePixels();
    		while ( it.hasNext() )
    		{
    			Pixels target = (Pixels) it.next();
    			target.setImage ( null );
    		}
    		
		} finally {
			postSetter( PIXELS, null );
		}
			
	}
	
    public Pixels getDefaultPixels() {
		try {
			preGetter( DEFAULTPIXELS );
			return this.defaultPixels;
		} finally {
			postGetter( DEFAULTPIXELS );
		}
			
    }
    
    protected void setDefaultPixels(Pixels defaultPixels) {
		try {
			preSetter( DEFAULTPIXELS, defaultPixels );
	        this.defaultPixels = defaultPixels;
		} finally {
			postSetter( DEFAULTPIXELS, defaultPixels);
		}			
    }
	
   





  // The following is extra code specified in the hbm.xml files

          public final static String OWNER_FILTER = "image_owner_filter";
          public final static String GROUP_FILTER = "image_group_filter";
          public final static String EVENT_FILTER = "image_event_filter";
          public final static String PERMS_FILTER = "image_perms_filter";  
          public final static String OWNER_FILTER_CATEGORYLINKS = "image_owner_filter_CATEGORYLINKS";
          public final static String GROUP_FILTER_CATEGORYLINKS = "image_group_filter_CATEGORYLINKS";
          public final static String EVENT_FILTER_CATEGORYLINKS = "image_event_filter_CATEGORYLINKS";
          public final static String PERMS_FILTER_CATEGORYLINKS = "image_perms_filter_CATEGORYLINKS";  
          public final static String OWNER_FILTER_PIXELS = "image_owner_filter_PIXELS";
          public final static String GROUP_FILTER_PIXELS = "image_group_filter_PIXELS";
          public final static String EVENT_FILTER_PIXELS = "image_event_filter_PIXELS";
          public final static String PERMS_FILTER_PIXELS = "image_perms_filter_PIXELS";  
          public final static String OWNER_FILTER_DATASETLINKS = "image_owner_filter_DATASETLINKS";
          public final static String GROUP_FILTER_DATASETLINKS = "image_group_filter_DATASETLINKS";
          public final static String EVENT_FILTER_DATASETLINKS = "image_event_filter_DATASETLINKS";
          public final static String PERMS_FILTER_DATASETLINKS = "image_perms_filter_DATASETLINKS";  
          public final static String OWNER_FILTER_ANNOTATIONS = "image_owner_filter_ANNOTATIONS";
          public final static String GROUP_FILTER_ANNOTATIONS = "image_group_filter_ANNOTATIONS";
          public final static String EVENT_FILTER_ANNOTATIONS = "image_event_filter_ANNOTATIONS";
          public final static String PERMS_FILTER_ANNOTATIONS = "image_perms_filter_ANNOTATIONS";  
          public final static String OWNER_FILTER_DEFAULTPIXELS = "image_owner_filter_DEFAULTPIXELS";
          public final static String GROUP_FILTER_DEFAULTPIXELS = "image_group_filter_DEFAULTPIXELS";
          public final static String EVENT_FILTER_DEFAULTPIXELS = "image_event_filter_DEFAULTPIXELS";
          public final static String PERMS_FILTER_DEFAULTPIXELS = "image_perms_filter_DEFAULTPIXELS";  
       
/* These values are defined in dsl/resources/ome/dsl/mapping.vm:
 * -------------------------------------------------------------
 * Explanation of serialVersionUID ex 0000000 03 00 00 01 03 01 L;
 * 1-7   : currently unused
 * 8-9   : major part (3.x.x)
 * 10-11 : minor part (x.0.x)
 * 12-13 : patch part (x.x.0)
 * 14-15 : release type   (M)
 * 16-17 : release number (2)
 * 18-19 : increment per delta // any changes to the dsl or mapping files
 */ 
          private static final long serialVersionUID = 0000000030000010301L;                     
	
  // end of extra code specified in the hbm.xml files


  public String toString(){
	return "Image"+(getId()==null ? ":Hash_"+this.hashCode() : ":Id_"+getId());
  }
  
  // FIELD-FIELDS
  
  	public Set fields()
    {
	    return Image.FIELDS;
    }
  
	public final static String ID = "Image_id";
	public final static String DETAILS = "Image_details";
	public final static String VERSION = "Image_version";
	public final static String NAME = "Image_name";
	public final static String DESCRIPTION = "Image_description";
	public final static String ACQUISITION = "Image_acquisition";
	public final static String CONDITION = "Image_condition";
	public final static String CATEGORYLINKS = "Image_categoryLinks";
	public final static String SETUP = "Image_setup";
	public final static String POSITION = "Image_position";
	public final static String PIXELS = "Image_pixels";
	public final static String CONTEXT = "Image_context";
	public final static String DATASETLINKS = "Image_datasetLinks";
	public final static String ANNOTATIONS = "Image_annotations";
	public final static String DEFAULTPIXELS = "Image_defaultPixels";
 	public final static Set FIELDS;
	static {
	   Set raw = new HashSet();
	   raw.add(ID);
	   raw.add(DETAILS);
	   raw.add(VERSION);
	   raw.add(NAME);
	   raw.add(DESCRIPTION);
	   raw.add(ACQUISITION);
	   raw.add(CONDITION);
	   raw.add(CATEGORYLINKS);
	   raw.add(SETUP);
	   raw.add(POSITION);
	   raw.add(PIXELS);
	   raw.add(CONTEXT);
	   raw.add(DATASETLINKS);
	   raw.add(ANNOTATIONS);
	   raw.add(DEFAULTPIXELS);
 	   FIELDS = java.util.Collections.unmodifiableSet( raw );
	}
	
	
	// Dynamic Getter/Setter
	protected Map _dynamicFields;
	public Object retrieve(String field)
	{
		if (field == null)
		{
			return null;
		}
		else if (field.equals(ID)) 		{
			return getId();
		}
		else if (field.equals(PIXELS)) 		{
			return getPixels();
		}
		else if (field.equals(DEFAULTPIXELS)) 		{
			return getDefaultPixels();
 		} else {
			if (_dynamicFields != null)
			{
				return _dynamicFields.get(field);
			}
			return null;
		}
	}
	
	public void putAt(String field, Object value)
	{
		if (field == null)
		{
			return;
 		}
		else if (field.equals(ID))
		{
			setId((Long)value);
 		}
    	else if (field.equals(PIXELS))
		{
			setPixels((Set)value);
 		}
		else if (field.equals(DEFAULTPIXELS))
		{
			setDefaultPixels((Pixels)value);
 		} else {
			if (_dynamicFields == null)
				_dynamicFields = new HashMap();
			
			_dynamicFields.put(field,value);
		}
	}

	protected boolean _loaded = true;
	public boolean isLoaded()
	{
		return _loaded;
	}
	
	public void unload()
	{
		_loaded = false;
 		this.pixels = null;
		this.defaultPixels = null;
  
 	}
	
	protected void errorIfUnloaded()
	{
		if ( ! _loaded )
			throw new IllegalStateException("Object unloaded:"+this);
	}
	
	// SERIALIZATION
	/** the serialVersionID constant is set by mapping.vm */
	private void readObject(java.io.ObjectInputStream s)
    throws java.io.IOException, ClassNotFoundException
    {
        s.defaultReadObject();  
    }





}
