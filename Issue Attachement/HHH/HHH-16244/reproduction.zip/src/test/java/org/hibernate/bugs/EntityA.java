package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;

public class EntityA
{
	public int id;
	
	/**
	 * one-to-one relationship to {@link EntityB}.
	 */
	public EntityB selectedEntityB;
	
	/**
	 * Bidirectional one-to-many relationship to {@link EntityB}.
	 */
	public List<EntityB> listOfEntityB = new ArrayList<>();
}