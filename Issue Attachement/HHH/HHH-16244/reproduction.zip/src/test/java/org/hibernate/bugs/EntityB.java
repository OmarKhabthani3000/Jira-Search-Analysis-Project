package org.hibernate.bugs;

public class EntityB
{
	public int id;
	
	public EntityA entityA;
}