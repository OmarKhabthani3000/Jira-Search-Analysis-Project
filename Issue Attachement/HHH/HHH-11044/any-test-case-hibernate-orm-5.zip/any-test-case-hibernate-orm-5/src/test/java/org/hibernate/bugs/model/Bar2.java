package org.hibernate.bugs.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bar")
public class Bar2 implements BarInt{

	@Id
	private Integer id;
	private String bar2;
	private String barType;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getBar2() {
		return bar2;
	}
	public void setBar2(String bar2) {
		this.bar2 = bar2;
	}
	public String getBarType() {
		return barType;
	}
	public void setBarType(String barType) {
		this.barType = barType;
	}
	
	
}
