package org.hibernate.bugs.model;

public interface BarInt {

	String getBarType();
}
