package org.hibernate.bugs.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;

import org.hibernate.annotations.Any;
import org.hibernate.annotations.AnyMetaDef;
import org.hibernate.annotations.MetaValue;

@Embeddable
public class FooGroup {

	@AnyMetaDef(idType = "integer", metaType = "string", metaValues = {
			@MetaValue( value = "1", targetEntity = Bar1.class ),
			@MetaValue( value = "2", targetEntity = Bar2.class )
	})
	@Any(metaColumn = @Column(name = "bar_type"))
	@JoinColumn(name = "bar_id")
	private BarInt foogrp;

	public BarInt getFoogrp() {
		return foogrp;
	}

	public void setFoogrp(BarInt foogrp) {
		this.foogrp = foogrp;
	}

	
}
