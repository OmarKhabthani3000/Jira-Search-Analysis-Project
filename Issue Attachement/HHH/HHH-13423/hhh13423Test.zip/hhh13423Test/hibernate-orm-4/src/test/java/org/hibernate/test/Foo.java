package org.hibernate.test;

import java.util.HashMap;
import java.util.Map;

public class Foo {
	private int id;
	private Map<Integer, Bar> orderedMap;

	public Foo() {

	}

	public Foo(int id) {
		this.id = id;
		this.orderedMap = new HashMap<>();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Map<Integer, Bar> getOrderedMap() {
		return orderedMap;
	}

	public void setOrderedMap(Map<Integer, Bar> orderedMap) {
		this.orderedMap = orderedMap;
	}
}
