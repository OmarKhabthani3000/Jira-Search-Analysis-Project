package com.dna2.db.domain;


import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.junit.BeforeClass;
import org.junit.Test;


public class DomainTest {
	protected static SessionFactory _sessionFactory;
	protected static ValidatorFactory factory = null;
	protected static Validator validator = null;

	
	@BeforeClass
	public static void setUp() {
		try {
			_sessionFactory = new AnnotationConfiguration()
				.configure().buildSessionFactory();

		} catch (Throwable ex) {
			ex.printStackTrace();
			throw new ExceptionInInitializerError(ex);
		}
		
		factory = Validation.buildDefaultValidatorFactory();
		validator = factory.getValidator();
	}

	/**
	 * Creates a new session
	 * @return Session
	 * @throws HibernateException
	 */
	public static Session getSession() throws HibernateException {
		return _sessionFactory.openSession();
	}
	
	/**
	 * Gets the currently opened session
	 * @return Session
	 * @throws HibernateException
	 */
	public static Session getCurrentSession() throws HibernateException {
		return _sessionFactory.getCurrentSession();
	}
	
	public static void save(Object obj) throws Exception {
		Session session = getSession();
		Transaction tx = session.beginTransaction();
		
		session.save(obj);
		tx.commit();		
	}
}
