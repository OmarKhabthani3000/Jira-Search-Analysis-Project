package com.dna2.db.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.junit.Before;
import org.junit.Test;


public class TemplateTest extends DomainTest {
	List<String> sequences = new ArrayList<String>();
	private static boolean setupAlready = false;
	
	public TemplateTest() {
		super();
	}
	
	@Before
	public void init() {
		if(!setupAlready) {
			Session session = getSession();
			Transaction tx = session.beginTransaction();		
			
			Template t = new Template();
			t.setSequence("ASDFASDFASDFASDFASDFASDFDAS");
			sequences.add(t.getSequence());
			
			Oligo o  = new Oligo();
			o.setSequence("ASDFASDFASDFASDFASDFFGGGGG");
			sequences.add(o.getSequence());
			
			SequencingRead sr = new SequencingRead();
			sr.setSequence("BWRTBTUFFBV");
			sequences.add(sr.getSequence());
			sr.setTemplate(t);
			sr.setOligo(o);
			
			Shipment shipment = new Shipment();
			shipment.setDateCreated(new Date());
			shipment.setTrackingDataCreationDate(new Date());
			shipment.setTrackingData("my shipment for today");
			sr.setShipment(shipment);
			
			session.save(sr);
			
			System.out.println("1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n1234\n");
			
			
			tx.commit();
			setupAlready = true;
		}
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void insertTemplate() {
		Criteria crit = getSession().createCriteria(DNA.class);
		List<DNA> dnas = crit.list();
		
		if(!CollectionUtils.isEmpty(dnas)) {
			Assert.assertTrue(dnas.size() > 0);
		} else {
			Assert.fail();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void sequenceQuery() {
		Criteria crit = getSession().createCriteria(DNA.class);
		crit.add(Restrictions.ilike("sequence", "GG", MatchMode.ANYWHERE));
		
		List<DNA> dnas = crit.list();
		
		if(!CollectionUtils.isEmpty(dnas)) {
			Assert.assertTrue(dnas.size() > 0);
		} else {
			Assert.fail();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void oligoQuery() {
		Criteria crit = getSession().createCriteria(Oligo.class);
		
		List<DNA> dnas = crit.list();
		
		if(!CollectionUtils.isEmpty(dnas)) {
			Assert.assertTrue(dnas.size() > 0);
		} else {
			Assert.fail();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void shipmentQuery() {
		Criteria crit = getSession().createCriteria(Shipment.class);
		crit.add(Restrictions.isNotEmpty("dnas"));
		
		List<Shipment> shipments = crit.list();
		
		if(!CollectionUtils.isEmpty(shipments)) {
			Assert.assertTrue(shipments.size() > 0);
		} else {
			Assert.fail();
		}
	}
	
	
}
