package com.dna2.db.domain;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.*;


@Entity
public class Oligo extends DNA implements Serializable {

	private static final long serialVersionUID = 2710833784997415106L;
	private Set<SequencingRead> sequencingReads;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "oligo")
	public Set<SequencingRead> getSequencingReads() {
		return this.sequencingReads;
	}

	public void setSequencingReads(Set<SequencingRead> sequencingreads) {
		this.sequencingReads = sequencingreads;
	}
}
