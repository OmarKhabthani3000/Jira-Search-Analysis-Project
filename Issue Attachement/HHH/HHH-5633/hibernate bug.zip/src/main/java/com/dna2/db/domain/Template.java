package com.dna2.db.domain;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;

@Entity
public class Template extends DNA implements Serializable {

	private static final long serialVersionUID = 3603863759952437981L;
	
	// instance variables
	private Set<SequencingRead> sequencingReads;
	// end instance variables
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "template")
	public Set<SequencingRead> getSequencingReads() {
		return this.sequencingReads;
	}

	public void setSequencingReads(Set<SequencingRead> sequencingreads) {
		this.sequencingReads = sequencingreads;
	}
}
