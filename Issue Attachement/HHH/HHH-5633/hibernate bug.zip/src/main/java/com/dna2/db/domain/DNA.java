package com.dna2.db.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.*;

@Entity
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)

public abstract class DNA implements Serializable {
	private long id;
	private String sequence;
	private Shipment shipment;

	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "seqhilo")
	@Id
	@SequenceGenerator(name = "seqhilo", allocationSize=1, sequenceName="seqhilo")
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	public Shipment getShipment() {
		return shipment;
	}

	public void setShipment(Shipment shipment) {
		this.shipment = shipment;
	}
	
	
}
