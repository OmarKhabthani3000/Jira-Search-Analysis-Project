package com.dna2.db.domain;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

@Entity
public class SequencingRead extends DNA implements Serializable {

	private static final long serialVersionUID = -4230586155376660707L;
	
	// instance variables
	private Template template;
	private Oligo oligo;

	// end instance variables


	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	public Template getTemplate() {
		return template;
	}
	
	public void setTemplate(Template template) {
		this.template = template;
	}
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	public Oligo getOligo() {
		return oligo;
	}
	
	public void setOligo(Oligo oligo) {
		this.oligo = oligo;
	}
}
