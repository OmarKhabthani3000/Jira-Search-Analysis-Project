package com.dna2.db.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Shipment implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3238086142330048592L;
	private int id;
	private Date dateCreated;
	private String trackingData;
	private Date trackingDataCreationDate;
	private List<DNA> dnas;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Temporal(TemporalType.TIMESTAMP)
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date date) {
		this.dateCreated = date;
	}
	
	public String getTrackingData() {
		return trackingData;
	}

	public void setTrackingData(String trackingData) {
		this.trackingData = trackingData;
	}
	@Temporal(TemporalType.TIMESTAMP)
	public Date getTrackingDataCreationDate() {
		return trackingDataCreationDate;
	}

	public void setTrackingDataCreationDate(Date trackingDataCreationDate) {
		this.trackingDataCreationDate = trackingDataCreationDate;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "shipment")
	public List<DNA> getDnas() {
		return dnas;
	}

	public void setDnas(List<DNA> dnas) {
		this.dnas = dnas;
	}
	
	
}
