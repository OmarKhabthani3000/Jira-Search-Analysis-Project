package school;
import java.util.List;

import org.hibernate.Session;

import util.HibernateUtil;

public class StudentManager {

    public static void main(String[] args) {
        StudentManager mgr = new StudentManager();

        mgr.createAndStoreStudent("Test01", "Desc test01");
        mgr.createAndStoreStudent("Test02", "Desc test02");

        List students = mgr.listStudents();
        for (int i = 0; i < students.size(); i++) {
            Student theStudent = (Student) students.get(i);
            // TypeA and TypeB should not be null!
            System.out.println("Student: " + theStudent.getName() +
                    " TypeA: " + theStudent.getStudentInfo().getTypeA() +
                    " TypeB: " + theStudent.getStudentInfo().getTypeB() +
                    " Description: " + theStudent.getStudentInfo().getDescription());
        }
        
        HibernateUtil.getSessionFactory().close();
    }

    private Long createAndStoreStudent(String name, String description) {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();

        Student theStudent = new Student();
        theStudent.setName(name);
        theStudent.getStudentInfo().setDescription(description);

        session.save(theStudent);

        session.getTransaction().commit();

        return theStudent.getId();
    }

    private List listStudents() {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();

        List result = session.createQuery("from Student").list();

        session.getTransaction().commit();

        return result;
    }

}