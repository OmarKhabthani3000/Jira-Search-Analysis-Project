package school;

public class Student {

    private Long id;
    private String name;
    private StudentInfo studentInfo;
    
    public Student() {
        String type = SchoolHelper.lookupType("C");
        studentInfo = new StudentInfo(type);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public StudentInfo getStudentInfo() {
        return studentInfo;
    }

    public void setStudentInfo(StudentInfo studentInfo) {
        this.studentInfo = studentInfo;
    }
}
