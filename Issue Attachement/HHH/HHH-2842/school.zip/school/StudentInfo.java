package school;

public class StudentInfo {

    private String description;
    private transient String typeA;
    private transient String typeB;
    
    public StudentInfo() {
    }
    
    public StudentInfo(String type) {
        this.typeA = SchoolHelper.getTypeA(type);
        this.typeB = SchoolHelper.getTypeB(type);
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTypeA() {
        return typeA;
    }

    public void setTypeA(String typeA) {
        this.typeA = typeA;
    }

    public String getTypeB() {
        return typeB;
    }

    public void setTypeB(String typeB) {
        this.typeB = typeB;
    }
}
