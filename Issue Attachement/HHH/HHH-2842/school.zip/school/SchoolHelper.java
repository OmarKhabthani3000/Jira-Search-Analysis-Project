package school;

public class SchoolHelper {

    public static String lookupType(String type) {
        // soom complicated logic here
        return "FT";
    }
    
    public static String getTypeA(String type) {
        // soom complicated logic here
        return "A";
    }

    public static String getTypeB(String type) {
        // soom complicated logic here
        return "B";
    }
}
