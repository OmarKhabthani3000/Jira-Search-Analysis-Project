package org.jboss.as.quickstart.hibernate4.controller;

import java.math.BigInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.type.BigIntegerType;
import org.jboss.as.quickstart.hibernate4.model.Member;
import org.jboss.as.quickstart.hibernate4.service.MemberRegistration;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
@Model
/* modification: 
 * - added named query with scalar result
 * - added MemberController.getCount() method
 * - added MemberController.executeQuerySingleResult() method
 * - added outputLabel in index.html (line 50)
 * - added 2nd level cache in persistence.xml
 * 
 * @Author: Henrik Hoffmann, PC-Soft GmbH (Germany)
 *  
 * FIXME: when caching is enabled an NPE will be thrown!
 * FIXME: SqlQuery.addScalar(..); will ever throw an UnsupportedOperationException when using named query declared by Annotation
 */
public class MemberController
{

	@Inject
	private FacesContext facesContext;

	@Inject
	private MemberRegistration memberRegistration;

	@Inject
	private Logger log;

	@Inject
	private EntityManager entityManager;

	private Member newMember;


	@Produces
	@Named
	public Member getNewMember()
	{
		return newMember;
	}


	public String getCount()
	{
		log.info("start getCount()");
		String result = "NULL";
		try
		{
			final BigInteger mCount = executeQuerySingleResult(Member.COUNT_MEMBER_QUERY, BigInteger.class);
			if(mCount != null)
			{
				log.info("memberCount = " + mCount.intValue());
				result = mCount.toString();
			}
		}
		catch(final Throwable t)
		{
			result = t.toString();
			log.log(Level.SEVERE, "FIXME: Error while executing namedQuery! ", t);
		}
		return result;
	}


	private <T> T executeQuerySingleResult(final String name, final Class<? extends T> resultType)
	{
		final Session session = (Session) entityManager.getDelegate();

		log.info("executing query = " + name);
		final Query namedQuery = session.getNamedQuery(name);
		final SQLQuery sqlQuery = (SQLQuery) namedQuery;

		// FIXME: this will cause an UnsupportedOperationException unless query cache is enabled or disabled!
		sqlQuery.addScalar("mCount", BigIntegerType.INSTANCE);

		return (T) namedQuery.uniqueResult();
	}


	public void register()
	{
		try
		{
			memberRegistration.register(newMember);
			facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registered!", "Registration successful"));
			initNewMember();
		}
		catch(final Exception e)
		{
			final String errorMessage = getRootErrorMessage(e);
			facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, errorMessage, "Registration unsuccessful"));
		}
	}


	@PostConstruct
	public void initNewMember()
	{
		newMember = new Member();
	}


	private String getRootErrorMessage(final Exception e)
	{
		// Default to general error message that registration failed.
		String errorMessage = "Registration failed. See server log for more information";
		if(e == null)
		{
			// This shouldn't happen, but return the default messages
			return errorMessage;
		}

		// Start with the exception and recurse to find the root cause
		Throwable t = e;
		while(t != null)
		{
			// Get the message from the Throwable class instance
			errorMessage = t.getLocalizedMessage();
			t = t.getCause();
		}
		// This is the root cause message
		return errorMessage;
	}

}
