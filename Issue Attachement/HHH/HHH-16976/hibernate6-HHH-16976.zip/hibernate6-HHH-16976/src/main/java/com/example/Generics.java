/*
 * Copyright (C) Onyx Tech Pty Ltd - All Rights Reserved.
 *
 * Unauthorised copying, distribution, or use of this file is strictly prohibited.
 */

package com.example;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

public abstract class Generics {

  private Generics() {
    // utility class
  }

  /**
   * Extract the specified reified parameter from a generic class, if available
   *
   * @param <T> the type of the parameter
   * @param genericType
   * @param parameter zero based parameter position in the parameter type list.
   * @return the extracted type
   * @throws IllegalArgumentException if the parameter cannot be extracted
   */
  public static <T> Class<T> reify(Class<?> genericType, int parameter) {
    return getParameter(genericType.getGenericSuperclass(), parameter);
  }

  /**
   * Extract the specified parameter from a generic class field, if available.
   *
   * @param generic The generic type to fetch a parameter from.
   * @param parameter Zero based parameter position in the parameter type list.
   * @return The extracted type.
   * @throws IllegalArgumentException If the parameter cannot be extracted.
   */
  public static <T> Class<T> getParameter(Type generic, int parameter) {
    @SuppressWarnings("unchecked") // This is really just a hack to get around the type system
    var out = (Class<T>) getParameterType(generic, parameter);
    return out;
  }

  /**
   * Extract the specified parameter from a generic class field, if available.
   *
   * @param field The generic field to pull a parameter from.
   * @param parameter Zero based parameter position in the parameter type list.
   * @return The extracted type.
   * @throws IllegalArgumentException If the parameter cannot be extracted.
   */
  public static Type getGenericFieldParameter(Field field, int parameter) {
    return getParameterType(field.getGenericType(), parameter);
  }
  
  public static List<Type> getParameterTypes(Field field) {
	  if (field.getGenericType() instanceof ParameterizedType generic) {
	    return getParametersFromJavaType(generic);
	  }
	  return List.of();
  }

  private static Type getParameterType(Type generic, int parameter) {
    if (generic instanceof ParameterizedType) {
      return getParameterFromJavaType((ParameterizedType) generic, parameter);
    }

    throw new IllegalArgumentException(String.format("Type %s is not generic", generic.getTypeName()));
  }

  private static Type getParameterFromJavaType(ParameterizedType type, int parameter) {
    var actualTypeArguments = type.getActualTypeArguments();

    if (parameter >= actualTypeArguments.length) {
      throw new IllegalArgumentException(String.format("Parameter %d out of bounds, only %d parameters found on type", parameter, actualTypeArguments.length));
    }

    var parameterType = actualTypeArguments[parameter];
    if (parameterType instanceof Class<?>) {
      return parameterType;
    }

    if (parameterType instanceof ParameterizedType) {
      return parameterType;
    }

    throw new IllegalArgumentException(String.format("Failed to get generic parameter from type %s", type.getTypeName()));
  }
  
  private static List<Type> getParametersFromJavaType(ParameterizedType type) {
	return Stream.of(type.getActualTypeArguments())
			.map(Generics::getParameter)
			.filter(Objects::nonNull)
			.toList();  
  }
  
  private static Type getParameter(Type parameterType) {
    if (parameterType instanceof Class<?>) {
        return parameterType;
      }

      if (parameterType instanceof ParameterizedType) {
        return parameterType;
      }

      return null;
  }

  public static boolean isParameterized(Field field) {
    return field != null && field.getGenericType() instanceof ParameterizedType;
  }
}
