package com.example.demo.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Instant;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureTestEntityManager;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@SpringBootTest
@AutoConfigureTestEntityManager
public class MarketValueTest {
	@Autowired
	private TestEntityManager entityManager;

	@Test
	void test() {
		Instant now = Instant.now();
		
		var value = new MarketValue(now, "test");

		entityManager.persistAndFlush(value);

		entityManager.clear();

		var persisted = entityManager.find(MarketValue.class, now);
		assertThat(persisted).isNotNull();
	}

}
