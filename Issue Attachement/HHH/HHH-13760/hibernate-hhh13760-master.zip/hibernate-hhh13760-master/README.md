# hibernate-hhh13760 (https://hibernate.atlassian.net/browse/HHH-13760)
