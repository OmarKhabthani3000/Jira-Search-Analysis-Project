package hibernate;

import hibernate.entity.Lazy;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class HHH7573Main {

    public static void main(final String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("lazy");

        EntityManager em = factory.createEntityManager();

        // insert new entity
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        Lazy stuff = new Lazy();
        stuff.setLazyData(new byte[] { 0x13, 0x37 });
        em.merge(stuff);
        tx.commit();
        em.close();

        // reload the entity
        em = factory.createEntityManager();
        TypedQuery<Lazy> query = em.createQuery("select b from Lazy b", Lazy.class);
        Lazy reloaded = query.getSingleResult();
        System.out.println(reloaded.getId() + ": " + reloaded.getLazyData().length);

        // detach it
        em.detach(reloaded);

        // merge it back into the persistence context
        tx = em.getTransaction();
        tx.begin();
        reloaded = em.merge(reloaded); // Crash occurs here
        tx.commit();
        em.close();

        factory.close();
    }
}
