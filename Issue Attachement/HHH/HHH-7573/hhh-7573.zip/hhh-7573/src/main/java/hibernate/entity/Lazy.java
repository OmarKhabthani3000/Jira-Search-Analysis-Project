package hibernate.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Version;

@Entity
public class Lazy {
    @Id
    @GeneratedValue
    @Column (name = "ID")
    private Long id;

    @Basic (fetch = FetchType.LAZY)
    @Column (name = "LAZY_DATA", columnDefinition = "VARBINARY")
    private byte[] lazyData;

    @Version
    private long version;

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public byte[] getLazyData() {
        return lazyData;
    }

    public void setLazyData(final byte[] lazyData) {
        this.lazyData = lazyData;
    }

    public long getVersion() {
        return version;
    }

    public void setVersion(final long version) {
        this.version = version;
    }
}
