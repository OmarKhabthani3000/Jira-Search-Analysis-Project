package hibernatebug;

import org.testng.annotations.Test;

import javax.persistence.Persistence;

public class HibernateTest {
    @Test
    public void createEntityManager() {
        Persistence.createEntityManagerFactory(getClass().getPackage().getName());
    }
}
