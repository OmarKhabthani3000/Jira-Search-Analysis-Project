package hibernatebug;

import java.io.Serializable;

public class PersonId implements Serializable {
    String firstName;
    String lastName;
}
