package hibernatebug;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.OneToOne;

@Entity
@IdClass(PersonId.class)
public class MedicalHistory {
    @Id @OneToOne Person patient;
    String foobar;
}
