package testH5;

import javax.persistence.Persistence;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.jpa.HibernateEntityManagerFactory;

import testH5.entities.Table1;

public class TestH5 {

	public static void main(String[] args) {
		try {
			SessionFactory sf = ((HibernateEntityManagerFactory) Persistence.createEntityManagerFactory("TestPU")).getSessionFactory();
			Session s = sf.getCurrentSession();
			
			s.beginTransaction();
			try {
				s.createSQLQuery("delete from Table1").executeUpdate(); // cleanup
				
				s.createCriteria(Table1.class).list(); // this works
				s.createSQLQuery("select * from Table1").list(); // this does not work (even if table is empty)
				
				s.getTransaction().commit();
			}
			catch (Exception ex) {
				s.getTransaction().rollback();
				throw ex;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
