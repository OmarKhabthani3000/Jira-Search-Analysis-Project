package com.mycompany.web.ressources;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.mycompany.domain.dao.interfaces.ProductDao;
import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.enterprise.context.RequestScoped;
import javax.ws.rs.POST;

/**
 * REST Web Service
 *
 * @author cbu
 */
// http://localhost:8080/Glassfish4-Hibernate-web/webresources/products
@Path("products")
@RequestScoped
public class ProductsRessource {

    @Context
    private UriInfo context;

    @EJB
    private ProductDao productDao;

    /**
     * Creates a new instance of ProductsRessource
     */
    public ProductsRessource() {
    }

    /**
     * Retrieves representation of an instance of
     * com.mycompany.web.ProductsRessource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces("text/plain")
    public String getText() {
        List<String> names = productDao.getAllProductItemNames();
        StringBuilder s = new StringBuilder();
        for (String name : names) {
            s.append(name).append("\n");
        }
        return s.toString();
    }

    @POST
    @Produces("text/plain")
    public String persistProductItems() {
        productDao.createProductItems();
        return "Items sucessfully created";
    }

}
