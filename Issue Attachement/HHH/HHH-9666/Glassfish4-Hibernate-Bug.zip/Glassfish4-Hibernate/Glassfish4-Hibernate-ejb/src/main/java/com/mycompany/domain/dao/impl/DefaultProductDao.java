/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.domain.dao.impl;

import com.mycompany.domain.dao.interfaces.ProductDao;
import com.mycompany.domain.model.ProductItem;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author cbu
 */
@Stateless
public class DefaultProductDao implements ProductDao {

    @PersistenceContext(name = "myPersistenceUnit" )
    private EntityManager entityManager;
    
    @Override
    public List<String> getAllProductItemNames() {
        final TypedQuery<ProductItem> q = getEntityManager().createQuery("select p from ProductItem p", ProductItem.class);
        final List resultList = q.getResultList();
        List<String> names = new ArrayList<>();

        if (!resultList.isEmpty()) {
            Class c1 = ProductItem.class;
            Class c2 = resultList.get(0).getClass();
            ClassLoader cl1 = c1.getClassLoader();
            ClassLoader cl2 = c2.getClassLoader();
            System.out.println("Class 1: " + c1.getCanonicalName());
            System.out.println("Class 2: " + c2.getCanonicalName());
            System.out.println("Classloader 1: " + getClassLoaderString(cl1));
            System.out.println("Classloader 2: " + getClassLoaderString(cl2));
        }

        for (Object o : resultList) {
            // this class cast fails:
            // java.lang.ClassCastException: com.mycompany.domain.model.ProductItem cannot be cast to com.mycompany.domain.model.ProductItem
            ProductItem p = (ProductItem) o;
            names.add(p.getName());
        }
        return names;
    }

    private EntityManager getEntityManager() {
        if (entityManager == null) {
            EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myPersistenceUnit");
            entityManager = entityManagerFactory.createEntityManager();
        }
        return entityManager;
    }

    @Override
    public void createProductItems() {
        for (int i = 0; i < 10; i++) {
            ProductItem p = new ProductItem();
            p.setName("Item " + i + " - generated " + new Date());
            p.setPrice(i * 42.27);
            getEntityManager().persist(p);
        }
    }

    private String getClassLoaderString(ClassLoader cl) {
        return "Hash: " + System.identityHashCode(cl) + " - Loader: " + cl.toString();
    }

}
