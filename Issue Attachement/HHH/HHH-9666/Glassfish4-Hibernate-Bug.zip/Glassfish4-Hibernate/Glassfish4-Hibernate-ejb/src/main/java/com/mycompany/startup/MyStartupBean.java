/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.startup;

import com.mycompany.domain.dao.interfaces.ProductDao;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.LocalBean;
import javax.ejb.Startup;

/**
 *
 * @author cbu
 */
@Singleton
@LocalBean
@Startup
public class MyStartupBean {

    @EJB
    private ProductDao productDao;

//    @PostConstruct
    public void testHibernateJpa() {
        List<String> products = tryRetrieveProducts();
        if (products.isEmpty()) {
            System.out.println("No Products found. Creating...");
            tryCreateProducts();
        }
        tryRetrieveProducts();
    }

    private List<String> tryRetrieveProducts() {
        System.out.println("Trying to retrieve Products...");
        try {
            List<String> names = productDao.getAllProductItemNames();
            System.out.println("Successfully retrieved " + names.size() + " Products.");
            return names;
        } catch (Exception ex) {
            throw new RuntimeException("Failed to retrieve Products", ex);
        }
    }

    private void tryCreateProducts() {
        try {
            productDao.createProductItems();
            System.out.println("Successfully created ProductItems.");
        } catch (Exception ex) {
            throw new RuntimeException("Failed to crate ProductItems", ex);
        }
    }
}
