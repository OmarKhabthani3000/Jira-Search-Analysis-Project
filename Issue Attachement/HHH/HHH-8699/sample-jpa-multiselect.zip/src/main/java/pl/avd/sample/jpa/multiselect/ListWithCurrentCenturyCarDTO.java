package pl.avd.sample.jpa.multiselect;

public class ListWithCurrentCenturyCarDTO {
  
  private Long id;
  private String model;
  private String brand;
  private Boolean currentCentury;
  
  public ListWithCurrentCenturyCarDTO() {
  }
  
  public ListWithCurrentCenturyCarDTO(Long id, String model, String brand, Boolean currentCentury) {
    setId(id);
    setModel(model);
    setBrand(brand);
    setCurrentCentury(currentCentury);
  }
  
  public Long getId() {
    return id;
  }
  
  public void setId(Long id) {
    this.id = id;
  }
  
  public String getModel() {
    return model;
  }
  
  public void setModel(String model) {
    this.model = model;
  }
  
  public String getBrand() {
    return brand;
  }
  
  public void setBrand(String brand) {
    this.brand = brand;
  }
  
  public Boolean getCurrentCentury() {
    return currentCentury;
  }
  
  public void setCurrentCentury(Boolean currentCentury) {
    this.currentCentury = currentCentury;
  }

  @Override
  public String toString() {
    return String.format("ListWithCurrentCenturyCarDTO [id=%s, model=%s, brand=%s, currentCentury=%s]", id, model,
        brand, currentCentury);
  }
}
