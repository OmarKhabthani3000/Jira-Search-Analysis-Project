package pl.avd.sample.jpa.multiselect;

public class ListWithHasVinCarDTO {
  
  private Long id;
  private String model;
  private String brand;
  private Boolean hasVin;
  
  public ListWithHasVinCarDTO() {
  }
  
  public ListWithHasVinCarDTO(Long id, String model, String brand, Boolean hasVin) {
    setId(id);
    setModel(model);
    setBrand(brand);
    setHasVin(hasVin);
  }
  
  public Long getId() {
    return id;
  }
  
  public void setId(Long id) {
    this.id = id;
  }
  
  public String getModel() {
    return model;
  }
  
  public void setModel(String model) {
    this.model = model;
  }
  
  public String getBrand() {
    return brand;
  }
  
  public void setBrand(String brand) {
    this.brand = brand;
  }
  
  public Boolean getHasVin() {
    return hasVin;
  }
  
  public void setHasVin(Boolean hasVin) {
    this.hasVin = hasVin;
  }

  @Override
  public String toString() {
    return String.format("ListWithHasVinCarDTO [id=%s, model=%s, brand=%s, hasVin=%s]", id, model, brand, hasVin);
  }
}
