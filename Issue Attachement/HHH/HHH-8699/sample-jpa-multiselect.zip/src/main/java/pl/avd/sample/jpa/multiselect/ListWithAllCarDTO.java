package pl.avd.sample.jpa.multiselect;

public class ListWithAllCarDTO {
  
  private Long id;
  private String model;
  private String brand;
  private String all;
  
  public ListWithAllCarDTO() {
  }
  
  public ListWithAllCarDTO(Long id, String model, String brand, String all) {
    setId(id);
    setModel(model);
    setBrand(brand);
    setAll(all);
  }
  
  public Long getId() {
    return id;
  }
  
  public void setId(Long id) {
    this.id = id;
  }
  
  public String getModel() {
    return model;
  }
  
  public void setModel(String model) {
    this.model = model;
  }
  
  public String getBrand() {
    return brand;
  }
  
  public void setBrand(String brand) {
    this.brand = brand;
  }
  
  public String getAll() {
    return all;
  }
  
  public void setAll(String all) {
    this.all = all;
  }

  @Override
  public String toString() {
    return String.format("ListWithAllCarDTO [id=%s, model=%s, brand=%s, all=%s]", id, model, brand, all);
  }
}
