package pl.avd.sample.jpa.multiselect;

public enum Color {

  BLUE, GREEN, GRAY
}
