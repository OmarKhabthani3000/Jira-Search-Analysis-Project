package pl.avd.sample.jpa.multiselect;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@NamedQuery(name = CarEntity.QUERY_REMOVE_ALL, query = "DELETE FROM CarEntity c")
public class CarEntity implements Serializable {
  
  public static final String QUERY_REMOVE_ALL = "CarEntity.removeAll";
  
  private static final long serialVersionUID = 722999323350032937L;
  

  @Id
  @GeneratedValue
  private Long id;
  
  private String model;
  
  @Enumerated(EnumType.STRING)
  private Color color;
  
  private String vin;
  
  private String brand;
  
  @Temporal(TemporalType.DATE)
  private Date produced;

  public CarEntity() {
  }
  
  public Long getId() {
    return id;
  }
  
  public void setId(Long id) {
    this.id = id;
  }
  
  public String getModel() {
    return model;
  }
  
  public void setModel(String model) {
    this.model = model;
  }
  
  public Color getColor() {
    return color;
  }
  
  public void setColor(Color color) {
    this.color = color;
  }
  
  public String getVin() {
    return vin;
  }
  
  public void setVin(String vin) {
    this.vin = vin;
  }
  
  public String getBrand() {
    return brand;
  }
  
  public void setBrand(String brand) {
    this.brand = brand;
  }
  
  public Date getProduced() {
    return produced;
  }
  
  public void setProduced(Date produced) {
    this.produced = produced;
  }
}
