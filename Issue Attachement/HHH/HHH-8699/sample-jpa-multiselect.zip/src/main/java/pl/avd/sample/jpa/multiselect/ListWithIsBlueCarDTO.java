package pl.avd.sample.jpa.multiselect;

public class ListWithIsBlueCarDTO {
  
  private Long id;
  private String model;
  private String brand;
  private Boolean isBlue;
  
  public ListWithIsBlueCarDTO() {
  }
  
  public ListWithIsBlueCarDTO(Long id, String model, String brand, Boolean isBlue) {
    setId(id);
    setModel(model);
    setBrand(brand);
    setIsBlue(isBlue);
  }
  
  public Long getId() {
    return id;
  }
  
  public void setId(Long id) {
    this.id = id;
  }
  
  public String getModel() {
    return model;
  }
  
  public void setModel(String model) {
    this.model = model;
  }
  
  public String getBrand() {
    return brand;
  }
  
  public void setBrand(String brand) {
    this.brand = brand;
  }
  
  public Boolean getIsBlue() {
    return isBlue;
  }
  
  public void setIsBlue(Boolean isBlue) {
    this.isBlue = isBlue;
  }

  @Override
  public String toString() {
    return String.format("ListWithIsBlueCarDTO [id=%s, model=%s, brand=%s, isBlue=%s]", id, model, brand, isBlue);
  }
}
