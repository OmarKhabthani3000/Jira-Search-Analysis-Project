package pl.avd.sample.jpa.multiselect;

public class ListCarDTO {

  private Long id;
  private String model;
  private String brand;
  
  public ListCarDTO() {
  }
  
  public ListCarDTO(Long id, String model, String brand) {
    setId(id);
    setModel(model);
    setBrand(brand);
  }
  
  public Long getId() {
    return id;
  }
  
  public void setId(Long id) {
    this.id = id;
  }
  
  public String getModel() {
    return model;
  }
  
  public void setModel(String model) {
    this.model = model;
  }
  
  public String getBrand() {
    return brand;
  }
  
  public void setBrand(String brand) {
    this.brand = brand;
  }

  @Override
  public String toString() {
    return String.format("ListCarDTO [id=%s, model=%s, brand=%s]", id, model, brand);
  }
}
