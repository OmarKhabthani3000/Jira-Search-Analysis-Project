package pl.avd.sample.jpa.multiselect;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

public class CarService {
  
  private static EntityManagerFactory factory = Persistence.createEntityManagerFactory("manager");
  
  public void create(CarEntity car) {
    EntityManager em = factory.createEntityManager();
    
    EntityTransaction tx = em.getTransaction();
    
    try {
      tx.begin();
      
      em.persist(car);
      
      tx.commit();
    } catch (Throwable e) {
      e.printStackTrace();
      tx.rollback();
    } finally {
      em.close();
    }
  }
  
  public void remove(Long id) {
    EntityManager em = factory.createEntityManager();
    
    CarEntity car = em.find(CarEntity.class, id);
    
    EntityTransaction tx = em.getTransaction();
    
    try {
      tx.begin();
      
      em.remove(car);
      
      tx.commit();
    } catch (Throwable e) {
      e.printStackTrace();
      tx.rollback();
    } finally {
      em.close();
    }
  }
  
  public void removeAll() {
    EntityManager em = factory.createEntityManager();
    
    EntityTransaction tx = em.getTransaction();
    
    try {
      tx.begin();
      
      Query q = em.createNamedQuery(CarEntity.QUERY_REMOVE_ALL);
      q.executeUpdate();
      
      tx.commit();
    } catch (Throwable e) {
      e.printStackTrace();
      tx.rollback();
    } finally {
      em.close();
    }
  }

  public List<ListCarDTO> list() {
    EntityManager em = factory.createEntityManager();
    
    try {
      CriteriaBuilder cb = em.getCriteriaBuilder();
      
      CriteriaQuery<ListCarDTO> cq = cb.createQuery(ListCarDTO.class);
      Root<CarEntity> r = cq.from(CarEntity.class);
      
//      cq.multiselect(r.get(CarEntity_.id), r.get(CarEntity_.model), r.get(CarEntity_.brand));
      cq.multiselect(r.get("id"), r.get("model"), r.get("brand"));
      
      TypedQuery<ListCarDTO> tq = em.createQuery(cq);
      return tq.getResultList();
    } finally {
      em.close();
    }
  }
  
  public List<ListWithHasVinCarDTO> listWithHasVin() {
    EntityManager em = factory.createEntityManager();
    
    try {
      CriteriaBuilder cb = em.getCriteriaBuilder();
      
      CriteriaQuery<ListWithHasVinCarDTO> cq = cb.createQuery(ListWithHasVinCarDTO.class);
      Root<CarEntity> r = cq.from(CarEntity.class);
      
//      Predicate hasVin = cb.isNotNull(r.get(CarEntity_.vin));
      Predicate hasVin = cb.isNotNull(r.get("vin"));
//      cq.multiselect(r.get(CarEntity_.id), r.get(CarEntity_.model), r.get(CarEntity_.brand), hasVin);
      cq.multiselect(r.get("id"), r.get("model"), r.get("brand"), hasVin);
      
      TypedQuery<ListWithHasVinCarDTO> tq = em.createQuery(cq);
      return tq.getResultList();
    } finally {
      em.close();
    }
  }
  
  public List<ListWithIsBlueCarDTO> listWithIsBlue() {
    EntityManager em = factory.createEntityManager();
    
    try {
      CriteriaBuilder cb = em.getCriteriaBuilder();
      
      CriteriaQuery<ListWithIsBlueCarDTO> cq = cb.createQuery(ListWithIsBlueCarDTO.class);
      Root<CarEntity> r = cq.from(CarEntity.class);
      
//      Predicate hasColor = cb.equal(r.get(CarEntity_.color), Color.BLUE);
      Predicate isBlue = cb.equal(r.get("color"), Color.BLUE);
//      cq.multiselect(r.get(CarEntity_.id), r.get(CarEntity_.model), r.get(CarEntity_.brand), isBlue);
      cq.multiselect(r.get("id"), r.get("model"), r.get("brand"), isBlue);
      
      TypedQuery<ListWithIsBlueCarDTO> tq = em.createQuery(cq);
      return tq.getResultList();
    } finally {
      em.close();
    }
  }
  
  public List<ListWithCurrentCenturyCarDTO> listWithCurrentCentury() {
    EntityManager em = factory.createEntityManager();
    
    try {
      CriteriaBuilder cb = em.getCriteriaBuilder();
      
      CriteriaQuery<ListWithCurrentCenturyCarDTO> cq = cb.createQuery(ListWithCurrentCenturyCarDTO.class);
      Root<CarEntity> r = cq.from(CarEntity.class);
      
      Calendar cal = Calendar.getInstance();
      cal.set(2000, 1, 1);
      Date date = cal.getTime();
      
//      Predicate currentCentury = cb.greaterThan(r.get(CarEntity_.produced), date);
      Predicate currentCentury = cb.greaterThan(r.<Date> get("produced"), date);
//      cq.multiselect(r.get(CarEntity_.id), r.get(CarEntity_.model), r.get(CarEntity_.brand), currentCentury);
      cq.multiselect(r.get("id"), r.get("model"), r.get("brand"), currentCentury);
      
      TypedQuery<ListWithCurrentCenturyCarDTO> tq = em.createQuery(cq);
      return tq.getResultList();
    } finally {
      em.close();
    }
  }
  
  public List<ListWithAllCarDTO> listWithAll() {
    EntityManager em = factory.createEntityManager();
    
    try {
      CriteriaBuilder cb = em.getCriteriaBuilder();
      
      CriteriaQuery<ListWithAllCarDTO> cq = cb.createQuery(ListWithAllCarDTO.class);
      Root<CarEntity> r = cq.from(CarEntity.class);
      
      Expression<String> all = cb.concat(cb.concat(r.<String> get("model"), " "), r.<String> get("brand"));
      cq.multiselect(r.get("id"), r.get("model"), r.get("brand"), all);
      
      TypedQuery<ListWithAllCarDTO> tq = em.createQuery(cq);
      return tq.getResultList();
    } finally {
      em.close();
    }
  }
}
