package pl.avd.sample.jpa.multiselect;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class CarServiceTest {
  
  private CarService service;

  private Logger log = LoggerFactory.getLogger(getClass());
  
  @BeforeClass
  public void setUp() {
    service = new CarService();
    
    fillTestData();
  }
  
  @AfterClass
  public void tearDown() {
    removeTestData();
    
    service = null;
  }

  @Test
  public void listTest() {
    List<ListCarDTO> list = service.list();
    
    Assert.assertNotNull(list);
    Assert.assertEquals(list.size(), 3);
    
    for (ListCarDTO dto : list) {
      log.info("- dto: {}", dto);
    }
  }
  
  @Test
  public void listWithHasVinTest() {
    List<ListWithHasVinCarDTO> list = service.listWithHasVin();
    
    Assert.assertNotNull(list);
    Assert.assertEquals(list.size(), 3);
    
    for (ListWithHasVinCarDTO dto : list) {
      log.info("- dto: {}", dto);
    }
  }
  
  @Test
  public void listWithIsBlueTest() {
    List<ListWithIsBlueCarDTO> list = service.listWithIsBlue();
    
    Assert.assertNotNull(list);
    Assert.assertEquals(list.size(), 3);
    
    for (ListWithIsBlueCarDTO dto : list) {
      log.info("- dto: {}", dto);
    }
  }
  
  @Test
  public void listWithCurrentCenturyTest() {
    List<ListWithCurrentCenturyCarDTO> list = service.listWithCurrentCentury();
    
    Assert.assertNotNull(list);
    Assert.assertEquals(list.size(), 3);
    
    for (ListWithCurrentCenturyCarDTO dto : list) {
      log.info("- dto: {}", dto);
    }
  }
  
  @Test
  public void listWithAllTest() {
    List<ListWithAllCarDTO> list = service.listWithAll();
    
    Assert.assertNotNull(list);
    Assert.assertEquals(list.size(), 3);
    
    for (ListWithAllCarDTO dto : list) {
      log.info("- dto: {}", dto);
    }
  }
  
  private void fillTestData() {
    CarEntity car = new CarEntity();
    car.setModel("Carisma");
    car.setBrand("Mitsubishi");
    car.setColor(Color.BLUE);
    car.setVin("1234567890");
    car.setProduced(getDate(2003, 11, 1));
    
    service.create(car);
    
    car = new CarEntity();
    car.setModel("Carisma");
    car.setBrand("Mitsubishi");
    car.setColor(Color.GRAY);
    car.setProduced(getDate(1998, 5, 1));
    
    service.create(car);
    
    car = new CarEntity();
    car.setModel("A6");
    car.setBrand("Audi");
    car.setColor(Color.GREEN);
    car.setProduced(getDate(1997, 8, 1));
    
    service.create(car);
  }
  
  private Date getDate(int year, int month, int day) {
    Calendar cal = Calendar.getInstance();
    cal.set(year, month, day);
    return cal.getTime();
  }
  
  private void removeTestData() {
    service.removeAll();
  }
}
