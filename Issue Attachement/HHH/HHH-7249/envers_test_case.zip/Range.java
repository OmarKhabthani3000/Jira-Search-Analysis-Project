package org.hibernate.envers.test.integration.inheritance.single;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.apache.commons.collections.functors.TruePredicate;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

/**
 * @author x11sct
 * @since 19.01.2012
 */
@Audited
@Entity
@Table( name = "T_DIM_BEREICH", 
		uniqueConstraints = @UniqueConstraint(columnNames =  { "BEREICH", "BEREICH_TYP" })) // "STATUS", 
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "BEREICH_TYP", discriminatorType = DiscriminatorType.CHAR, length = 1)
@DiscriminatorValue(Range.DISCRIMINATOR_AGGREGATE)
public class Range implements Serializable {
	private static final long serialVersionUID = -6686896936859019645L;
	
	public static final String DISCRIMINATOR_AGGREGATE = "A";
	public static final String DISCRIMINATOR_AWARD = "P";
	
	private long rangeId = -1L;
	
	private Integer optimisticLocking = null;
	
	private String range = null;
	
	private String type;
	
	private Set<CriterionTargetAbstract> criterionTarget = null;
	
	private Set<RangeAward> rangeAward = null;
		
    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="BEREICH_ID")
	public long getRangeId() {
		return rangeId;
	}

	public void setRangeId(long rangeId) {
		this.rangeId = rangeId;
	}		

	@Column(name = "BEREICH", length = 255)
	public String getRange() {
		return range;
	}

	public void setRange(String range) {
		this.range = range;
	}
		
	// TODO: https://community.jboss.org/message/725505#725505
	// @NotAudited
	@OneToMany(mappedBy = "range")
	public Set<CriterionTargetAbstract> getCriterionTarget() {
		return criterionTarget;
	}
	
	@Transient
	public void addCriterionTarget(CriterionTargetAbstract entity) {
		if (entity != null && criterionTarget != null) {
			for (CriterionTargetAbstract current : criterionTarget) {
				if (current.equals(entity))
					return; // If in set already we don't add entity again.
			}			
			// if not in set we add entity
			criterionTarget.add(entity);
			entity.addRange(this);
		}
	}
	
	@Transient
	public void removeCriterionTarget(CriterionTargetAbstract entity) {
		if (entity != null && criterionTarget != null && criterionTarget.size() > 0) {
			CriterionTargetAbstract[] arr = criterionTarget.toArray(new CriterionTargetAbstract[0]);
			for (int i = 0; i <arr.length; i++) {
				if (arr[i].equals(entity)) {
					criterionTarget.remove(arr[i]);
					arr[i].removeRange(this);
					break;
				}					
			}
		}
	}	
	
	public void setCriterionTarget(Set<CriterionTargetAbstract> criterionTarget) {
		this.criterionTarget = criterionTarget;
	}
	
	@Version
	@Column(name = "OPTIMISTISCHE_SPERRE", length = 10, nullable = false, columnDefinition = "Number(10,0) default '0'")
	public Integer getOptimisticLocking() {
		return optimisticLocking;
	}

	public void setOptimisticLocking(Integer optimisticLocking) {
		this.optimisticLocking = optimisticLocking;
	}

	@Column(name = "BEREICH_TYP", insertable = false, updatable = false, nullable = false, length = 1)
	// @Column(name = "BEREICH_TYP")
	public String getType() {
		return type;
	}
	
	@OneToMany(mappedBy = "parentRange")
	public Set<RangeAward> getRangeAward() {
		return rangeAward;
	}

	public void setRangeAward(Set<RangeAward> rangeAward) {
		this.rangeAward = rangeAward;
	}	

	public void setType(String type) {
		if (type != null && type.length() > 1)
			throw new RuntimeException("Zu lang!!!!!!");
		this.type = type;
	}
	
	@Transient
	public RangeType getRangeType() {
		if (this instanceof RangeAward)
			return RangeType.AWARD;
		else 
			return RangeType.AGGREGATE;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((range == null) ? 0 : range.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Range other = (Range) obj;
		
		// Wenn schon gespeichert wurde, reicht ein Vergleich der PKs
		if (rangeId >= 0L && rangeId == other.rangeId)
			return true;
		
		if (range == null) {
			if (other.range != null)
				return false;
		} else if (!range.equals(other.range))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}

}
