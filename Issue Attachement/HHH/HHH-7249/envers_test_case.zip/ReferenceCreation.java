/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2008, Red Hat Middleware LLC or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Middleware LLC.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.envers.test.integration.inheritance.single;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;

import org.junit.Test;

import org.hibernate.ejb.Ejb3Configuration;
import org.hibernate.envers.query.AuditEntity;
import org.hibernate.envers.query.AuditQuery;
import org.hibernate.envers.test.AbstractEntityTest;
import org.hibernate.envers.test.Priority;
import static org.junit.Assert.*;

/**
 * @author Thomas Schmid
 */
public class ReferenceCreation extends AbstractEntityTest {
	public static final String CREATION_USER = "Thomas";
    private Long idRangeAward;
    private Long idCriterionTarget;
    private Long idCrit;

    public void configure(Ejb3Configuration cfg) {
        cfg.addAnnotatedClass(Range.class);
        cfg.addAnnotatedClass(RangeAward.class);
        cfg.addAnnotatedClass(CriterionTargetAbstract.class);
        cfg.addAnnotatedClass(CriterionTargetBasis.class);
    }

    /**
     * We will create two objects with bidirectional reference here. Both inherit from a parent class: 
     *   Range        CriterionTargetAbstract
     *     ^                    ^
     *     |                    |
     * RangeAward <--> CriterionTargetBasis
     * 
     * After that we will delete object CriterionTargetBasis.
     * 
     * Problem is in the revision object of RangeAward: 
     * Wrong DiscriminatorValue is saved for last revision. The value from parent is used. 
     * 
     */    
    @Test
    @Priority(10)
    public void initData() {
        EntityManager em = getEntityManager();

        // Create and save RangeAward
        em.getTransaction().begin();
        RangeAward ra = new RangeAward();        
        ra.setRange("Foo");
        em.persist(ra);
        idRangeAward = ra.getRangeId();
        em.getTransaction().commit();
        em.clear();

        // Closing EntityManager is essential for this test case but it does not lead to an error here
        // when adding a reference...
        newEntityManager();
        em = getEntityManager();
        
        Range abstractRange = em.find(Range.class, idRangeAward);
        
        CriterionTargetBasis cb = new CriterionTargetBasis();        
        cb.setRange(abstractRange); // <-- creating reference works fine. Revision object has DiscriminatorValue "P" wich is correct
        em.getTransaction().begin();
        em.persist(cb);
        idCriterionTarget = cb.getCriterionTargetId();
        em.getTransaction().commit();
        em.clear();
                
        abstractRange = em.find(Range.class, idRangeAward);        
        // ... but herre: 
        // Error only occours when EntityManager is closed at this point. 
        // I'm in an EJB environment using stateless session beans to access the db from web client 
        // using CMP and not closing the EM at any point in the backend.        
        newEntityManager();
        em = getEntityManager();
        em.getTransaction().begin();
        CriterionTargetAbstract ca = em.find(CriterionTargetAbstract.class, idCriterionTarget);        
        em.remove(ca); // <-- deleting causes error: when referenced entity is deleted or reference set to null value wrong type is stored in Range object.
        // ca.setRange(null); // same error when setting null value...
        em.getTransaction().commit();
        em.clear();
        abstractRange = em.find(Range.class, idRangeAward);
    }

    @SuppressWarnings("unused")
	@Test
    public void testRevisionsCounts() {
    	List<Number> listRange = getAuditReader().getRevisions(Range.class, idRangeAward);     
    	assertTrue(Arrays.asList(1, 2, 3).equals(listRange));
        List<Number> listCrit = getAuditReader().getRevisions(CriterionTargetAbstract.class, idCriterionTarget);
        assertTrue(Arrays.asList(2, 3).equals(listCrit));
        
		AuditQuery query = getAuditReader().createQuery().forRevisionsOfEntity(Range.class, false, true);
		query.add(AuditEntity.id().eq(idRangeAward));					
		@SuppressWarnings("unchecked")
		List<Object[]> revList = query.getResultList();
		
        // Now let's check the type value (discriminator column) 
		// last revision has wrong type "A" that belongs to the parent...
        assertEquals(Range.DISCRIMINATOR_AWARD, getAuditReader().find(Range.class, idRangeAward, 1).getType());
        assertEquals(Range.DISCRIMINATOR_AWARD, getAuditReader().find(Range.class, idRangeAward, 2).getType());
        assertEquals(Range.DISCRIMINATOR_AWARD, getAuditReader().find(Range.class, idRangeAward, 3).getType());  // <--- Error here
    }
}
