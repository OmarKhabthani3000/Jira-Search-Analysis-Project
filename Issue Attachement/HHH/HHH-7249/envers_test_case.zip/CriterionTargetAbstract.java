package org.hibernate.envers.test.integration.inheritance.single;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;


/**
 * 
 * @author X11SCT
 * @since 25.01.2012
 *
 */
@Audited
@Entity
@Table(	name = "T_DIM_KRITERIUM_ZIEL", 
		uniqueConstraints = @UniqueConstraint(columnNames =  { "BEREICH_ID" })) // "KRIT_ID", , "AGGREGAT_ID"
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "TYP", discriminatorType = DiscriminatorType.STRING, length = 6)
public abstract class CriterionTargetAbstract implements Serializable, Comparable<CriterionTargetAbstract> {
	
	private static final long serialVersionUID = 8804570315181150337L;
	
	private long criterionTargetId = -1L;
	
	private Range range = null;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="KRITERIUM_ZIEL_ID")
	public long getCriterionTargetId() {
		return criterionTargetId;
	}

	public void setCriterionTargetId(long criterionTargetId) {
		this.criterionTargetId = criterionTargetId;
	}	

	// TODO: https://community.jboss.org/message/725505#725505
	// @NotAudited
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BEREICH_ID")
	public Range getRange() {
		return range;
	}

	public void setRange(Range range) {
		this.range = range;
	}
		
	@Transient
	public void addRange(Range entity) {
		if (entity == null) throw new RuntimeException("parameter entity");
		
		if (range != null) {
			if (range.equals(entity))
				return; // If equal => nothing to do
			
			range.removeCriterionTarget(this);
			entity.addCriterionTarget(this);
		}
		range = entity;
	}
	
	@Transient
	public void removeRange(Range entity) {
		if (entity == null) throw new RuntimeException("parameter entity");
		
		if (range != null) {
			if (range.equals(entity)) {
				range = null;
				entity.removeCriterionTarget(this);
			}					
		}
	}	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ (int) (criterionTargetId ^ (criterionTargetId >>> 32));		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CriterionTargetAbstract other = (CriterionTargetAbstract) obj;

		// Wenn schon gespeichert wurde, reicht ein Vergleich der PKs
		if (criterionTargetId >= 0L && criterionTargetId == other.criterionTargetId)
			return true;
		
		return true;
	}

    @Override
    public int compareTo(CriterionTargetAbstract that) {    	
      if (that == null) throw new NullPointerException();
      if (that.criterionTargetId == 0L && this.criterionTargetId == 0L) {
    	  return 0;
      }
      
      if (that.criterionTargetId == 0L) {    	  
    	  return 1;
      }
      else if (this.criterionTargetId == 0L) {
    	  return -1;
      }
      
      Long thisLong = this.criterionTargetId;
      Long thatLong = that.criterionTargetId;
      
      return thisLong.compareTo(thatLong); 
    }	
	
}
