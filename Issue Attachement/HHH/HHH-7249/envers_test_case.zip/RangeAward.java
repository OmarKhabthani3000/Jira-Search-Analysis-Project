package org.hibernate.envers.test.integration.inheritance.single;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;

@Audited
@Entity
// @Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorValue(Range.DISCRIMINATOR_AWARD) // Prämie
public class RangeAward extends Range {

	private static final long serialVersionUID = 4953674778122811565L;
	
	private Range parentRange = null;	
	
	@ManyToOne(optional = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "UEBERGEORDNETER_BEREICH")
	public Range getParentRange() {
		return parentRange;
	}

	public void setParentRange(Range parentRange) {
		this.parentRange = parentRange;
	}		

}
