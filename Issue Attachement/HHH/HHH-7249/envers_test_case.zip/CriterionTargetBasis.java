package org.hibernate.envers.test.integration.inheritance.single;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

import org.hibernate.envers.Audited;

@Audited
@Entity
@DiscriminatorValue("BASIS")
public class CriterionTargetBasis extends CriterionTargetAbstract {

	private static final long serialVersionUID = -6573898021743161704L;
	
}
