package org.hibernate.envers.test.integration.inheritance.single;

public enum RangeType {
	AGGREGATE, AWARD;
	
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return this.name;
	}
	
	public String getIndex() {
		return super.toString();
	}
}
