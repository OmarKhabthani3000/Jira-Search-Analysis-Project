import hhh7438.beans.Request;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;
import org.junit.Test;

import java.util.List;

import static junit.framework.Assert.assertEquals;

/**
 * User: Andremoniy
 * Date: 09.07.12
 * Time: 12:25
 */
public class TestRowCount {

    @Test
    public void rowCountTester() {

        // !!!
        // create tables USER and REQUESTS
        // fill table REQUESTS with two types of rows:
        // 1. rows, which contains NULL in USER_ID (this emulatates situation, when there are old rows in table)
        // 2. rows, which don't contains NULL in USER_ID

        SessionFactory sessionFactory = new Configuration()
                .configure()
                .buildSessionFactory();

        Session session = sessionFactory.openSession();

        Criteria criteria1 = session.createCriteria(Request.class);
        criteria1.setProjection(Projections.rowCount());
        Number result = (Number) criteria1.uniqueResult();

        Criteria criteria2 = session.createCriteria(Request.class);
        List list = criteria2.list();

        assertEquals(result.intValue(), list.size());

        session.close();

    }

}

