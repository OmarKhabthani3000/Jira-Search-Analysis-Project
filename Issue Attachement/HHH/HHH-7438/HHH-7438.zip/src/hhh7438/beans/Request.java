package hhh7438.beans;

import javax.persistence.*;

/**
 * User: Andremoniy
 * Date: 09.07.12
 * Time: 12:22
 */
@Entity
@Table(name = "REQUEST")
public class Request {
    @Id
    @GeneratedValue
    public Long id;

    @ManyToOne
    @JoinColumn(name = "USER_ID", nullable = false)
    public User user;
}