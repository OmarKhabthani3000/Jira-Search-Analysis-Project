package hhh7438.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * User: Andrmeoniy
 * Date: 09.07.12
 * Time: 12:21
 */

@Entity
@Table(name = "USER")
public class User {

    @Id
    @GeneratedValue
    public Long id;

}
