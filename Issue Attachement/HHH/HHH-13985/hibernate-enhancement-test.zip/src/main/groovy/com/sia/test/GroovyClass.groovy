package com.sia.test

class GroovyClass {

    EntityInGroovySourceSet entity
    JavaClass javaClass
}
