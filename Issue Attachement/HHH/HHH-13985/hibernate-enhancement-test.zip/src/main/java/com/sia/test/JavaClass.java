package com.sia.test;

public class JavaClass {

    GroovyClass groovyClass;
}
