package com.offia.test.testHibernate;

import java.util.List;

import org.hibernate.SQLQuery.FetchReturn;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.junit.Test;

import com.offia.domain.Book;
import com.offia.domain.BookDetail;

public class TestFetchWithTextField {

	@SuppressWarnings("unchecked")
	@Test
	public void testHibernateSqlQueryWithSessionCache(){
		Configuration cfg = new Configuration().configure();
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
				.applySettings(cfg.getProperties()).buildServiceRegistry();
		SessionFactory sf = cfg.buildSessionFactory(serviceRegistry);
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		List<Book> booklist = session.createSQLQuery("select {b.*},{bd.*} from Book as b left outer join BookDetail as bd on bd.book_id = b.id where b.id in (1,2,3)")//
								.addEntity("b",Book.class)//
								//.addEntity("bd",BookDetail.class)
								.addJoin("bd", "b", "detail")
								.list();
		Book book = (Book)booklist.get(0);
		System.out.println(session.contains(book));
		tx.commit();
		session.close();
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testHibernateQueryWithSessionCache(){
		Configuration cfg = new Configuration().configure();
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
				.applySettings(cfg.getProperties()).buildServiceRegistry();
		SessionFactory sf = cfg.buildSessionFactory(serviceRegistry);
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		List<Object[]> objlist = session.createQuery("select b from Book b where b.id in (1,2,3)")//
								.list();
		tx.commit();
		session.close();
	}

}
