package hibernate.bug;

import hibernate.bug.model.Document;
import hibernate.bug.model.Person;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p1 = new Person("t1");
        Person p2 = new Person("t2");
        Document d1 = new Document(p1);
        Document d2 = new Document(p2);
        
        em.persist(p1);
        em.persist(p2);
        
        em.persist(d1);
        em.persist(d2);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testIssue() throws Throwable {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        try {
            int updated = em.createQuery("DELETE Document d WHERE d.owner.text = :param")
                    .setParameter("param", "t1")
                    .executeUpdate();
            Assert.assertEquals(1, updated);
            tx.commit();
        } catch (Throwable t) {
            tx.rollback();
            throw t;
        } finally {
            em.close();
        }
    }
    
}
