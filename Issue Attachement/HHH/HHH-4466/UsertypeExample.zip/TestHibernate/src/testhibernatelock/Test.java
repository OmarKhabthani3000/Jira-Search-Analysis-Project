/**
 * 
 */
package testhibernatelock;

import java.util.HashMap;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import testhibernatelock.bo.Client;
import testhibernatelock.bo.Maison;
import testhibernatelock.dao.ClietDAORemote;

/**
 * @author xjodoin
 * 
 */
public class Test
{

	/**
	 * @param args
	 * @throws NamingException
	 */
	public static void main(String[] args) throws NamingException
	{
		Object lookup = new InitialContext().lookup("ClientDAOBean/remote");

		if (lookup instanceof ClietDAORemote)
		{
			ClietDAORemote daoRemote = (ClietDAORemote) lookup;

			Client client = new Client();
			client.setName("mon nom");
			client.setValue("sduper ma valeur 2");

			// persist
			client = (Client) daoRemote.merge(client);

			// client.getAddresses().get(0).setDetail("un update");
			// client.setName("test update");
			// client.setValue("test");
			// update sans changement
			Maison maison = new Maison();
			maison.setPerson(client);
			Maison merge = (Maison) daoRemote.merge(maison);

			Maison byID = (Maison) daoRemote.getByID(Maison.class, merge.getId());
			System.out.println(byID);

			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("id", byID.getId());

			String hql = "select person from Maison maison, Person person where maison.id = :id and person.id = maison.person.person_id";

			System.out.println(daoRemote.executeQuery(hql, parameters));
			
			Object executeQuery = daoRemote.executeQuery("from Maison maison", new HashMap<String, Object>());
			
			System.out.println(executeQuery);
			

		}

	}

}
