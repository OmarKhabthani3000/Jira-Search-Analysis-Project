package testhibernatelock.bo;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.proxy.HibernateProxy;
import org.hibernate.type.Type;

public class PersonType implements org.hibernate.usertype.CompositeUserType
{

	public static final String TYPE_NAME = "testhibernatelock.bo.PersonType";

	private static final int[] SQL_TYPES = { Types.VARCHAR, Types.VARCHAR };

	public int[] sqlTypes()
	{
		return SQL_TYPES;
	}

	public Object assemble(Serializable cached, SessionImplementor session, Object owner) throws HibernateException
	{
		return cached;
	}

	public Object deepCopy(Object value)
	{
		return value;
	}

	public Serializable disassemble(Object value, SessionImplementor session) throws HibernateException
	{
		return (Serializable) value;
	}

	public boolean equals(Object x, Object y)
	{
		if (x == y)
		{
			return true;
		}

		if (x == null || y == null)
		{
			return false;
		}

		return x.equals(y);
	}

	public String[] getPropertyNames()
	{
		return new String[] { "person_type", "person_id" }; //$NON-NLS-1$ //$NON-NLS-2$
	}

	public Type[] getPropertyTypes()
	{
		return new Type[] { Hibernate.STRING, Hibernate.STRING };
	}

	public Object getPropertyValue(Object component, int property)
	{
		Person period = (Person) component;
		return period;
	}

	public int hashCode(Object x)
	{
		return x.hashCode();
	}

	public boolean isMutable()
	{
		return false;
	}

	public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object owner) throws HibernateException, SQLException
	{
		String className = rs.getString(names[0]);
		String id = rs.getString(names[1]);

		Object load = ((Session) session).load(className, id);
		return load;
	}

	public void nullSafeSet(PreparedStatement st, Object value, int index, SessionImplementor session) throws HibernateException, SQLException
	{
		if (value == null)
		{
			st.setNull(index, Types.VARCHAR);
			st.setNull(++index, Types.VARCHAR);
		}
		else
		{
			Person period = (Person) value;

			if (value instanceof HibernateProxy && !Hibernate.isInitialized(value))
			{
				String entityName = ((HibernateProxy) value).getHibernateLazyInitializer().getEntityName();
				Serializable identifier = ((HibernateProxy) value).getHibernateLazyInitializer().getIdentifier();

				st.setString(index++, entityName);
				st.setString(index, identifier.toString());
			}
			else
			{
				st.setString(index++, Hibernate.getClass(period).getName());
				st.setString(index, period.getId().toString());
			}
		}
	}

	public Object replace(Object original, Object target, SessionImplementor session, Object owner)
	{
		return original;
	}

	public Class<Person> returnedClass()
	{
		return Person.class;
	}

	public void setPropertyValue(Object component, int property, Object value)
	{
		throw new UnsupportedOperationException("Immutable!"); //$NON-NLS-1$
	}

}
