package testhibernatelock.bo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.Columns;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

@Entity
public class Maison implements Serializable
{
	private String id;
	private Person person;

	public void setId(String id)
	{
		this.id = id;
	}

	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	public String getId()
	{
		return id;
	}

	public void setPerson(Person person)
	{
		this.person = person;
	}

	@Type(type = PersonType.TYPE_NAME)
	@Columns(columns = { @Column(name = "person_type"), @Column(name = "person_id") })
	public Person getPerson()
	{
		return person;
	}
}
