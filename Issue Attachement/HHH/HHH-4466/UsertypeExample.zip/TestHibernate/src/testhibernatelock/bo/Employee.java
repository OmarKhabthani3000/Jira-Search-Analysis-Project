package testhibernatelock.bo;

import javax.persistence.Entity;

@Entity
public class Employee extends Person
{

	private String name;

	public void setName(String name)
	{
		this.name = name;
	}

	public String getName()
	{
		return name;
	}
}
