package testhibernatelock.dao;

import java.io.Serializable;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class ClientDAOBean implements ClietDAORemote
{
	@PersistenceContext
	private EntityManager manager;

	@Override
	public Object merge(Object object)
	{
		Object merge = manager.merge(object);

		return merge;
	}

	@Override
	public Object getByID(Class class1, Serializable id)
	{
		return manager.find(class1, id);
	}

	@Override
	public Object executeQuery(String hql, Map<String, Object> parameters)
	{
		Query createQuery = manager.createQuery(hql);

		for (Map.Entry<String, Object> entry : parameters.entrySet())
		{
			createQuery.setParameter(entry.getKey(), entry.getValue());
		}

		return createQuery.getResultList();
	}

}
