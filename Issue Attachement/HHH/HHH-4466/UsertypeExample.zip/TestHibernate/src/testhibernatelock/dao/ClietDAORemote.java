package testhibernatelock.dao;

import java.io.Serializable;
import java.util.Map;

import javax.ejb.Remote;

import testhibernatelock.bo.Client;

@Remote
public interface ClietDAORemote
{

	Object merge(Object client);
	
	public Object getByID(Class class1 ,Serializable id);

	Object executeQuery(String hql, Map<String, Object> parameters);

}
