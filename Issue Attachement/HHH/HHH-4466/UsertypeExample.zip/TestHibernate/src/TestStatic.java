
public class TestStatic
{
	private static Integer value;

	public static void setValue(Integer value)
	{
		TestStatic.value = value;
	}

	public static Integer getValue()
	{
		return value;
	}
	
}
