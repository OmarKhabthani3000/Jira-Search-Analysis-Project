import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;

public class TestStaticMain
{
	public static void main(String[] args) throws MalformedURLException, URISyntaxException, ClassNotFoundException, IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException, NoSuchMethodException
	{
		URLClassLoader urlClassLoader1 = new URLClassLoader(new URL[]{TestStaticMain.class.getResource("/").toURI().toURL()},null);
		URLClassLoader urlClassLoader2 = new URLClassLoader(new URL[]{TestStaticMain.class.getResource("/").toURI().toURL()},null);
		
		Class<?> class1  = urlClassLoader1.loadClass(TestStatic.class.getName());
		Class<?> class2  = urlClassLoader2.loadClass(TestStatic.class.getName());
		
		if(class1 != class2 && class1.getName().equals(class2.getName()))
		{
			class1.getMethod("setValue", Integer.class).invoke(null, 10);
			System.out.println(class2.getMethod("getValue").invoke(null));
			System.out.println(class1.getMethod("getValue").invoke(null));
		}
		
	}
}
