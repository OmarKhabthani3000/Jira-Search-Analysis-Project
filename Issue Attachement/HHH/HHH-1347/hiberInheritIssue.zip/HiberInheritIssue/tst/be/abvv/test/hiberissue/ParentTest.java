/*
 * Created on 9-jan-2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package be.abvv.test.hiberissue;

import java.util.List;

import junit.framework.TestCase;

/**
 *
 */
public class ParentTest extends TestCase {

	public void testFind() {
		String msgPrefix = null;
		Parent found = null;
		List foundList = null;
		
		Parent crit = new Parent();
		crit.setFoo(1L);
		
		// find
		msgPrefix = "find failed: ";
		try {
			foundList = Parent.find(crit);  
			assertTrue( msgPrefix + "null returned", foundList != null);
			assertTrue( msgPrefix + "zero items found", !foundList.isEmpty());
		} catch (RuntimeException e) {
			e.printStackTrace();
			assertTrue(msgPrefix + e.getMessage(), false);
		} finally {
			HibernateUtil.closeAndCommitAllSessions();  // close session in any case
		}
		
	}

}
