/*
 * Created on 9-jan-2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package be.abvv.test.hiberissue;

import java.util.List;

import junit.framework.TestCase;

/**
 *
 */
public class ChildTest extends TestCase {

	public void testFind() {
		String msgPrefix = null;
		Child found = null;
		List foundList = null;
		
		Child crit = new Child();
		crit.setBar(1L);
		
		// find
		msgPrefix = "find failed: ";
		try {
			foundList = Child.find(crit);  
			assertTrue( msgPrefix + "null returned", foundList != null);
			assertTrue( msgPrefix + "zero items found", !foundList.isEmpty());
		} catch (RuntimeException e) {
			e.printStackTrace();
			assertTrue(msgPrefix + e.getMessage(), false);
		} finally {
			HibernateUtil.closeAndCommitAllSessions();  // close session in any case
		}
		
	}

}
