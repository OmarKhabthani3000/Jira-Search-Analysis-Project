package be.abvv.test.hiberissue;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Utility class for hibernate. Enables configuration and session caching. By
 * using the thread local pattern it ensures that session are not shared across
 * threads.
 */
public class HibernateUtil {
    /**
     * Hibernate config file. Is static and shared across threads
     */
    public static final String CONFIG_FILE = "/hibernate.cfg.xml";

    /**
     * Session factory holds the configuration data loaded by the config file
     */
    private static SessionFactory internalSessionFactory;

    /**
     * Static variable linked to a thread holds the transaction
     */
    private static final ThreadLocal transactionCache = new ThreadLocal();

    /**
     * Static variable linked to the thread holds the session.
     */
    private static final ThreadLocal sessionCache = new ThreadLocal();

    /**
     * gets a hibernate session using the class defaults to initializes the
     * session. When creating a session a transaction will also be started. To close
     * the session and commit the transaction use <code>closeAndCommitAllSessions</code> when
     * needed you can also use <code>closeAndRollbackAllSessions</code>
     * 
     * @return Session to the database
     */
    public static Session getCurrentSession() {
        return getCurrentSession(internalSessionFactory);
    }

    /**
     * Returns a hibernate session. First checks the cache, if nothing is found
     * in the cache creates a new session. When creating a session a transaction will also be started. To close
     * the session and commit the transaction use <code>closeAndCommitAllSessions</code> when
     * needed you can also use <code>closeAndRollbackAllSessions</code>
     * 
     * @param sessionFactory
     *            SessionFacrtory to be used when creating the session.
     * @return Session to the database
     */
    public static Session getCurrentSession(SessionFactory sessionFactory) {
        try {
            
            
            //Retrieves the session from the "thread cache"
            Session s = (Session) sessionCache.get();
            if (s == null || !s.isOpen()) {
                //Checks if the factory was initialized
                if (sessionFactory == null) {
                    //Initializes the factory with the configuration file
                    sessionFactory = new Configuration().configure(CONFIG_FILE).buildSessionFactory();
                    internalSessionFactory=sessionFactory;
                }
                //Cache was empty or session was closed.Creating new session
                s = sessionFactory.openSession();
                Transaction t = s.beginTransaction();
                //Stores the session and the transaction in the cache
                sessionCache.set(s);
                transactionCache.set(t);
            }

            return s;
        } catch (Exception e) {
            throw new RuntimeException("Unable to retrieve Hibernate Session:" + e.getMessage());
        }
    }

    /**
     * returns a new session based on the SessionFactory provided
     * 
     * @param factory SessionFactry that is used to create the session
     */
    public static Session getSession(SessionFactory factory) {
        try {
            return factory.openSession();
        } catch (HibernateException e) {
            throw new RuntimeException("Unable to create Hibernate Session:" + e.getMessage());
        }
    }

    /**
     * Closes the transaction with a commit and hibernate session which will
     * invalidate the cache
     */
    public static void closeAndCommitAllSessions() {
        try {
            //Check if a transaction was cached if so commit the transaction
            if (transactionCache.get() != null) {
                ((Transaction) transactionCache.get()).commit();
            }
            //Check if a session was cached if so close the session
            if (sessionCache.get() != null) {
                Session s = (Session) sessionCache.get();
                //This ensures that all "hanging" database statements are send
                // to the db.
                s.flush();
                //Closes the session
                s.close();
            }
        } catch (HibernateException e) {
            throw new RuntimeException("Unable to close an commit the transaction:" + e.getMessage());
        }
    }

    /**
     * closes and commits the session and the transaction provided to this
     * method
     * 
     * @param s
     *            Session to be closed
     * @param t
     *            Transaction to be committed
     */
    public static void closeAndCommit(Session s, Transaction t) {
        try {
            t.commit();
            //s.flush();
            s.close();
        } catch (HibernateException e) {
            throw new RuntimeException("Unable to close an commit the transaction:" + e.getMessage());
        }
    }

    /**
     * closes and rollbacks the transaction provided to this method
     * 
     * @param s
     *            Session to be close
     * @param t
     *            Transaction to be rollbacked
     */
    public static void closeAndRollback(Session s, Transaction t) {
        try {
            t.rollback();
            s.flush();
            s.close();
        } catch (HibernateException e) {
            throw new RuntimeException("Unable to close an rollback the transaction:" + e.getMessage());
        }
    }

    /**
     * Closes the transaction with a rollback and hibernate session which will
     * invalidate the cache
     */
    public static void closeAndRollbackAllSessions() {
        try {
            //Check if a transaction was cached if so roolback the transaction
            if (transactionCache.get() != null) {
                ((Transaction) transactionCache.get()).rollback();
            }
            //Check if a session was cached if so close the session
            if (sessionCache.get() != null) {
                Session s = (Session) sessionCache.get();
                //This ensures that all "hanging" database statements are send
                // to the db.
                s.flush();
                //Closes the session
                s.close();
            }
        } catch (HibernateException e) {
            e.printStackTrace();
        }
    }

}