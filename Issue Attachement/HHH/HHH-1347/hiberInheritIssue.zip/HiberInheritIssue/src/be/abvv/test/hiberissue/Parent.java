package be.abvv.test.hiberissue;

// default package

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.MatchMode;

/**
 * Parent sample Java Hibernate class
 * @hibernate.class 
 * 		table = "PARENT"
 */

public class Parent extends GrandPa {


     /** default constructor */
    public Parent() {
    }
    
    /** constructor with id */
    public Parent(ParentKey id) {
        this.id = id;
    }

    
	private ParentKey id;
    private long foo;

   
    // Property accessors

    /**
     * @hibernate.composite-id 
     */
    public ParentKey getId() {
        return this.id;
    }
    
    public void setId(ParentKey id) {
        this.id = id;
    }

    /**
     * @hibernate.property 
     * 		not-null="true" 
     * 		type = "long"
     */
    public long getFoo() {
        return this.foo;
    }
    
    public void setFoo(long linr) {
        this.foo = linr;
    }

    public static Parent findById(Parent  searchData) {
        try {
            return (Parent)HibernateUtil.getCurrentSession().get(searchData.getClass(),searchData.getIdentifier());
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Unable to find"+ searchData.getName()+" with id:"+searchData.getIdentifier()+" error:"+e+"-"+e.getMessage());
        }
    }
    
    public static List find(Parent searchData) {
    	// Finder methods are the only type of method where you will need to think about the implementation 
    	
        // hibernate QBE
        Criteria crit = HibernateUtil.getCurrentSession().createCriteria(searchData.getClass());
        Example exampleQBE = Example.create(searchData);

        exampleQBE.ignoreCase();                   // for strings, ignore case 
        exampleQBE.enableLike(MatchMode.ANYWHERE); // for strings, this will give "like '%foo%'"
        exampleQBE.excludeZeroes();  // do not add java nulls as search criteria
        exampleQBE.excludeProperty("id");  // You need to exclude the PROPERTY of the primary key, 
        
        // add the rest of the query criteria  
        crit.add(exampleQBE);
        
        try {
            return crit.list();
        } catch (HibernateException e) {
            throw new RuntimeException("Unable to perform find:"+e+"-"+e.getMessage());
        }
    }

    
    public void update(Parent newData) {
     
    	// compare all properties, except the primary key 
    	
        if ( this.getFoo() != newData.getFoo() ) {
        	this.setFoo(newData.getFoo());  // primitive type
        }
        
    }

    public static final String name = "Parent";
    String getName() {
        return name;
    }
    
    /* (non-Javadoc)
     * @see be.msp.administratie.server.BusinessObject#getIdentifier()
     */
    Serializable getIdentifier() {
        return new ParentKey(getId());
    }
    





}