package be.abvv.test.hiberissue;

import java.io.Serializable;

/**
 * ParentKey Composite primary key class for Parent
 */

public class ParentKey  implements Serializable {


    /**
	 * 
	 */
	private static final long serialVersionUID = 3021203085569252295L;
	
	// Fields    

     private long nn;


    // Constructors

    /** default constructor */
    public ParentKey() {
    }
    
    public ParentKey(ParentKey id) {
		this.setNn(id.getNn());
	}

	public ParentKey(long nn) {
		this.nn = nn;
	}

	// Property accessors

    public long getNn() {
        return this.nn;
    }
    
    public void setNn(long nn) {
        this.nn = nn;
    }


    /**
     * Brief equals() implementation heavily based on boolean logic.
     */
   public boolean equals(Object other) {
         if ( (this == other ) ) { 
        	 return true;
         }
		 if ( (other == null ) ) {
			 return false;
		 }
		 if ( !(other instanceof ParentKey) ) {
			 return false;
		 }
		 ParentKey castOther = ( ParentKey ) other; 
         
		 return (  
				 	(this.getNn()==castOther.getNn())
		 		);
   }
   
   /**
    * hashCode() implementation based on "secret ingredient".
    */
   public int hashCode() {
         int result = 17;
         
         result = 37 * result + (int)getNn() ;
         return result;
   }   

}