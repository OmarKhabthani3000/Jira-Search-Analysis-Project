/*
 * Created on 9-jan-2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package be.abvv.test.hiberissue;

import java.io.Serializable;

import org.hibernate.HibernateException;

/**
 *
 */
public abstract class GrandPa {

	abstract String getName();
	abstract Serializable getIdentifier();

    public void save() {
        try {
        	HibernateUtil.getCurrentSession().save(this);
        } catch (HibernateException e) {
            throw new RuntimeException("Unable to save "+getName()+" "+e +"/n"+e.getMessage());
        }
        
    }
    
	public void update() {
        try {
        	HibernateUtil.getCurrentSession().update(this);
        } catch (HibernateException e) {
            throw new RuntimeException("Unable to update "+getName()+" "+e +"/n"+e.getMessage());
        }
        
    }

    public void delete() {
        try {
        	HibernateUtil.getCurrentSession().delete(this);
        } catch (Exception e) {
            throw new RuntimeException("Unable to find "+getName()+" with id:"+this.getIdentifier()+" error:"+e+"-"+e.getMessage());
        }
    }

}
