package be.abvv.test.hiberissue;

// default package

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.MatchMode;

/**
 * Parent sample Java Hibernate class
 * @hibernate.class 
 * 		table = "CHILD"
 */

public class Child extends Parent {


     /** default constructor */
    public Child() {
    }
    
    /** constructor with id */
    public Child(ParentKey id) {
        super(id);
    }

    
    private long bar;

   
    // Property accessors

    /**
     * @hibernate.property 
     * 		not-null="true" 
     * 		type = "long"
     */
    public long getBar() {
        return this.bar;
    }
    
    public void setBar(long linr) {
        this.bar = linr;
    }

    public static Child findById(Child  searchData) {
        try {
            return (Child)HibernateUtil.getCurrentSession().get(searchData.getClass(),searchData.getIdentifier());
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Unable to find"+ searchData.getName()+" with id:"+searchData.getIdentifier()+" error:"+e+"-"+e.getMessage());
        }
    }
    
    public static List find(Child searchData) {
    	// Finder methods are the only type of method where you will need to think about the implementation 
    	
        // hibernate QBE
        Criteria crit = HibernateUtil.getCurrentSession().createCriteria(searchData.getClass());
        Example exampleQBE = Example.create(searchData);

        exampleQBE.ignoreCase();                   // for strings, ignore case 
        exampleQBE.enableLike(MatchMode.ANYWHERE); // for strings, this will give "like '%bar%'"
        exampleQBE.excludeZeroes();  // do not add java nulls as search criteria
        exampleQBE.excludeProperty("id");  // You need to exclude the PROPERTY of the primary key, 
        
        // add the rest of the query criteria  
        crit.add(exampleQBE);
        
        try {
            return crit.list();
        } catch (HibernateException e) {
            throw new RuntimeException("Unable to perform find:"+e+"-"+e.getMessage());
        }
    }

    
    public void update(Child newData) {
     
    	// compare all properties, except the primary key 
    	
        if ( this.getBar() != newData.getBar() ) {
        	this.setBar(newData.getBar());  // primitive type
        }
        
        super.update(this);
        
    }

    public static final String name = "Child";
    String getName() {
        return name;
    }
    
    /* (non-Javadoc)
     * @see be.msp.administratie.server.BusinessObject#getIdentifier()
     */
    Serializable getIdentifier() {
        return new ParentKey(getId());
    }

}