package com.test;

public class Stock implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private Integer stockId;
	private String stockName;

	ComponentPart componentPart;

	public Stock() {
	}

	public Integer getStockId() {
		return this.stockId;
	}

	public void setStockId(Integer stockId) {
		this.stockId = stockId;
	}

	public String getStockName() {
		return this.stockName;
	}

	public void setStockName(String stockName) {
		this.stockName = stockName;
	}

	public ComponentPart getComponentPart() {
		return componentPart;
	}

	public void setComponentPart(ComponentPart componentPart) {
		this.componentPart = componentPart;
	}

}
