package com.test;

import java.util.Date;

import org.hibernate.Session;

public class Launch {
	public enum Placement {
		MAIN, WPS;
	}

	public static void main(String[] args) {
		System.out.println("Maven + Hibernate + MySQL");
		Session session = HibernateUtil.getSessionFactory().openSession();

		session.beginTransaction();

		// stock.setStockName("GENM"+ new Random().nextInt(100000));
		Stock stock = new Stock();
		ComponentPart part = new ComponentPart();
		part.setName("test" + (new Date()).getTime());
		part.setAge("10" + (new Date()).getTime());
		stock.setStockName("name" + (new Date()).getTime());
		stock.setComponentPart(part);
		session.save(stock);
		session.flush();
		session.getTransaction().commit();
		session.close();

		session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Stock ss = (Stock) session.load(Stock.class, stock.getStockId());
		ss.setStockName("name" + (new Date()).getTime());
		ss.getComponentPart().setName("name" + (new Date()).getTime());
		ss.getComponentPart().setAge("10" + (new Date()).getTime());
		session.saveOrUpdate(ss);
		session.getTransaction().commit();
	}

}
