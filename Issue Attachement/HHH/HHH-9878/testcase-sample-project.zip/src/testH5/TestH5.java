package testH5;

import javax.persistence.Persistence;

public class TestH5 {

	public static void main(String[] args) {
		try {
			
			Persistence.createEntityManagerFactory("TestPU");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
