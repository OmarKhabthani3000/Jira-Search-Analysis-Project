package persons;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Person {

	private Long id;
	private String name;

	public Person() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static void main(String[] args) {

		SessionFactory sessionFactory = new Configuration().configure()
				.buildSessionFactory();

		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();

		Person thePerson = new Person();
		thePerson.setName("Foo Bar");

		session.save(thePerson);

		session.getTransaction().commit();

		Long personId = thePerson.getId();
		System.out.println("Added person " + personId);

		sessionFactory.close();
	}
}