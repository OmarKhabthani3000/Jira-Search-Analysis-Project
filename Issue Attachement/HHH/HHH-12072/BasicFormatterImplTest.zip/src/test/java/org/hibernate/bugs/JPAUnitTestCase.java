package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    private static final String SQL = "(SELECT p.id, p.name FROM Person WHERE p.name LIKE 'A%') " +
            "UNION " +
            "(SELECT p.id, p.name FROM Person WHERE p.name LIKE 'B%')";

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    public void isFunctionNameNpeTest() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.createNativeQuery(SQL, Person.class).getResultList();
        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
