/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs.HHH9739;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.hibernate.CacheMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.stat.Statistics;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	// Add your entities here.
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
			PurchaseOrder.class
		};
	}

	// If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
	@Override
	protected String[] getMappings() {
		return new String[] {
			// "PurchaseOrder.hbm.xml",
		};
	}
	// If those mappings reside somewhere other than resources/org/hibernate/test, change this.
	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/test/";
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );
		configuration.setProperty(AvailableSettings.USE_SECOND_LEVEL_CACHE, "true");
		configuration.setProperty(AvailableSettings.USE_QUERY_CACHE, "true");
		configuration.setProperty(AvailableSettings.GENERATE_STATISTICS, "true");
	}

	// Add your tests, using standard JUnit.
	@Test
	public void hhh9739Test() throws Exception {
		// Test that there is no interaction with cache except for invalidation when using CacheMode.IGNORE
		// From API Doc : CacheMode.IGNORE -> The session will never interact with the cache, except to invalidate cache items when updates occur.
		Session s;
		Transaction t;
		SessionFactory sessionFactory;
		Statistics statistics;
		
		// ----------------------------------------------------------------------------------------------
		// insert
		s = openSession();
		s.setCacheMode(CacheMode.IGNORE);
		sessionFactory = s.getSessionFactory();
		sessionFactory.getCache().evictAllRegions();
		statistics = sessionFactory.getStatistics();
		statistics.clear();
		t = s.beginTransaction();
		
		PurchaseOrder purchaseOrder = new PurchaseOrder(1L, 2L, 1000L);
		s.persist(purchaseOrder);

		t.commit();
		s.close();

		assertEquals(0L, statistics.getSecondLevelCacheHitCount());
		assertEquals(0L, statistics.getSecondLevelCacheMissCount());
		assertEquals(0L, statistics.getSecondLevelCachePutCount());
		assertFalse(sessionFactory.getCache().containsEntity(PurchaseOrder.class, 1L));
		
		// ----------------------------------------------------------------------------------------------
		// update
		s = openSession();
		s.setCacheMode(CacheMode.IGNORE);
		sessionFactory = s.getSessionFactory();
		sessionFactory.getCache().evictAllRegions();
		statistics = sessionFactory.getStatistics();
		statistics.clear();
		t = s.beginTransaction();
		
		PurchaseOrder result = (PurchaseOrder)s.get(PurchaseOrder.class, 1L);
		result.setTotalAmount(2000L);
		
		t.commit();
		s.close();
		
		assertEquals(0, statistics.getSecondLevelCacheHitCount());
		assertEquals(0, statistics.getSecondLevelCacheMissCount());
		assertEquals(0, statistics.getSecondLevelCachePutCount());
		assertFalse(sessionFactory.getCache().containsEntity(PurchaseOrder.class, 1L));
	}
}
