package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import jakarta.persistence.EntityManager;
import java.util.Iterator;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
class DemoApplicationTests {

	@Autowired
	private EntityManager entityManager;

	@Test
	@Transactional
	void contextLoads() {
		Dog dog1 = new Dog("harry", "jack-russel-terrier");
		Dog dog2 = new Dog("dumbledore", "shepherd");
		Person person = new Person(1L, List.of(dog1, dog2));
		person.setId(1L);
		entityManager.persist(person);
		entityManager.flush();
		entityManager.clear();

		Person loadedPerson = entityManager.find(Person.class, person.getId());
		assertNotNull(loadedPerson);
		Iterator<Dog> iterator = loadedPerson.getDogs().iterator();
		assertEquals(dog1, iterator.next());
		assertEquals(dog2, iterator.next());
	}

}
