package com.example.demo;

import static com.fasterxml.jackson.databind.DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT;
import static org.springframework.util.StringUtils.hasText;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import jakarta.persistence.AttributeConverter;
import java.io.IOException;
import java.util.List;

public abstract class ObjectJsonListConverter<T> implements AttributeConverter<List<T>, String> {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper()
        .findAndRegisterModules()
        .enable(ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    private final Class<T> clazz;

    public ObjectJsonListConverter(Class<T> clazz) {
        this.clazz = clazz;
    }

    @Override
    public String convertToDatabaseColumn(List<T> obj) {
        if (obj == null) {
            return null;
        }
        try {
            return OBJECT_MAPPER.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<T> convertToEntityAttribute(String dbData) {
        if (dbData == null || !hasText(dbData)) {
            return null;
        }
        try {
            CollectionType collectionType =
                OBJECT_MAPPER.getTypeFactory().constructCollectionType(List.class, clazz);
//            if (dbData.startsWith(
//                "\"")) { // this is needed for the integration tests concerning h2 JSON escaping
//                dbData = StringEscapeUtils.unescapeJson(dbData);
//                dbData = dbData.substring(1, dbData.length() - 1);
//            }
            List<T> result = OBJECT_MAPPER.readValue(dbData, collectionType);
            return result;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
