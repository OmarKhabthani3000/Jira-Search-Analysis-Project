package com.example.demo;

import static org.springframework.util.StringUtils.hasText;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import jakarta.persistence.AttributeConverter;
import java.io.IOException;
import java.util.List;

public class DogListConverter implements AttributeConverter<List<Dog>, String> {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Override
    public String convertToDatabaseColumn(List<Dog> obj) {
        if (obj == null) {
            return null;
        }
        try {
            return OBJECT_MAPPER.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Dog> convertToEntityAttribute(String dbData) {
        if (dbData == null || !hasText(dbData)) {
            return null;
        }
        try {
            CollectionType collectionType =
                OBJECT_MAPPER.getTypeFactory().constructCollectionType(List.class, Dog.class);
            List<Dog> result = OBJECT_MAPPER.readValue(dbData, collectionType);
            return result;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
