package com.example.demo;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Entity
public class Person {

    @Id
    private Long id;

    @Column
    @Convert(converter = DogListConverter.class)
    // Change declaration to List<Dog> to make the test pass
    private Collection<Dog> dogs = new ArrayList<>(0);

    public Person() {
    }

    public Person(Long id, List<Dog> dogs) {
        this.id = id;
        this.dogs = dogs;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Collection<Dog> getDogs() {
        return dogs;
    }

    public void setDogs(List<Dog> dogs) {
        this.dogs = dogs;
    }
}
