package be.test;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.springframework.transaction.PlatformTransactionManager;
import org.testng.Assert;
import org.testng.annotations.Test;

@Test
@ContextConfiguration(classes = EvictTestConfiguration.class)
public class EvictTest extends AbstractTransactionalTestNGSpringContextTests {

	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * Just here to prove configuration is OK (this test should succeed)
	 */
	public void testBasicWorkingScenario() {
		Parent parent = new Parent();
		parent.getChildren().add(new Child());
		sessionFactory.getCurrentSession().save("parent",parent);

		//Flush & clear session so we can cleanly check if everything has been saved to database
		sessionFactory.getCurrentSession().flush();
		sessionFactory.getCurrentSession().clear();

		Parent freshParent = (Parent) sessionFactory.getCurrentSession().get("parent", parent.getId());

		Assert.assertNotNull(freshParent);
		Assert.assertEquals(freshParent.getChildren().size(), 1);
	}

	/**
	 * Proves the exception: java.lang.IllegalArgumentException: Non-entity object instance passed to evict : be.test.Child
	 * When the "entity-name" is removed from the XML, the test works as expected
	 */
	public void testTheEvictIssueWitHibernate433Final() {
		Parent parent = new Parent();
		sessionFactory.getCurrentSession().save("parent",parent);

		Child child = new Child();
		parent.getChildren().add(child);

		//This throws java.lang.IllegalArgumentException: Non-entity object instance passed to evict : be.test.Chil
		sessionFactory.getCurrentSession().evict(parent);
	}
}


class EvictTestConfiguration {

	@Autowired
	private SessionFactory sessionFactory;


	@Bean
	public EmbeddedDatabase embeddedDatabase() {
		EmbeddedDatabaseBuilder builder = new EmbeddedDatabaseBuilder();
		builder.setType(EmbeddedDatabaseType.H2);
		return builder.build();
	}

	@Bean
	public PlatformTransactionManager transactionManager() {
		return new HibernateTransactionManager(sessionFactory);
	}

	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean bean = new LocalSessionFactoryBean();
		bean.setDataSource(embeddedDatabase());
		bean.setMappingResources("/mapping.hbm.xml");

		Properties properties = new Properties();
		properties.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		properties.put("hibernate.hbm2ddl.auto", "create");
		bean.setHibernateProperties(properties);

		return bean;
	}
}
