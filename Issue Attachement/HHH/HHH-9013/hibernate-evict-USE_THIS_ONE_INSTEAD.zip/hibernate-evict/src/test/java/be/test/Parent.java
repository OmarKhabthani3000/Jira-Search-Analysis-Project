package be.test;

import java.util.ArrayList;
import java.util.List;

public class Parent {

	private Long id;
	private final List<Child> children = new ArrayList<>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<Child> getChildren() {
		return children;
	}
}
