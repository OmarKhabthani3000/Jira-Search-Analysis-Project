//$Id: PropertyInterceptor.java 7700 2005-07-30 05:02:47Z oneovthafew $
package org.hibernate.test.nullcomponentinterceptor;

import java.io.Serializable;
import java.util.Calendar;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

public class DetailsInterceptor extends EmptyInterceptor {

	boolean onSaveCalled = false;	
	
	@Override
	public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
		state[0] = new Details();
		onSaveCalled = true;
		return true;
	}

}
