//$Id$
package org.hibernate.test.nullcomponentinterceptor;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.TestCase;


/**
 * @author Josh Moore
 */
public class NullComponentInterceptorTest extends TestCase {
	
	public NullComponentInterceptorTest(String str) {
		super(str);
	}
	
	public void testInterceptorCanUnnullComponent() {
		
		DetailsInterceptor pi = new DetailsInterceptor();
		
		Session s = openSession( pi );
		Transaction t = s.beginTransaction();
		Image i = new Image();
		i.setName("compincomp");

		// the interceptor does the equivalent of:
		//
		//		i.setDetails( new Details() ); 
		//
		// which when uncommented makes this test pass.
		//
		// without that line, the null details gets copied back to the result
		// on merge causing the following on commit:
		/*
org.hibernate.PropertyValueException: not-null property references a null or transient value: org.hibernate.test.compincomp.Image.details
	at org.hibernate.engine.Nullability.checkNullability(Nullability.java:72)
	at org.hibernate.event.def.DefaultFlushEntityEventListener.scheduleUpdate(DefaultFlushEntityEventListener.java:263)
	at org.hibernate.event.def.DefaultFlushEntityEventListener.onFlushEntity(DefaultFlushEntityEventListener.java:121)
	at org.hibernate.event.def.AbstractFlushingEventListener.flushEntities(AbstractFlushingEventListener.java:195)
	at org.hibernate.event.def.AbstractFlushingEventListener.flushEverythingToExecutions(AbstractFlushingEventListener.java:76)
	at org.hibernate.event.def.DefaultFlushEventListener.onFlush(DefaultFlushEventListener.java:26)
	at org.hibernate.impl.SessionImpl.flush(SessionImpl.java:1000)
		*/

		s.merge(i);
		assertTrue( pi.onSaveCalled );
		t.commit();
		s.close();
	}
	
	protected String[] getMappings() {
		return new String[] { "nullcomponentinterceptor/Image.hbm.xml" };
	}

	public static Test suite() {
		return new TestSuite(NullComponentInterceptorTest.class);
	}

}

