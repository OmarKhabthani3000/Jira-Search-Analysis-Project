package test;

import org.hibernate.loader.custom.EntityFetchReturn;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Created by IntelliJ IDEA.
 * User: nardonep
 * Date: 09/06/11
 * Time: 13:38
 * To change this template use File | Settings | File Templates.
 */
public class Test {

    private EntityManagerFactory  emf;

    @BeforeMethod
    public void setUp() throws Exception {
        emf = Persistence.createEntityManagerFactory("library");

    }


    @AfterMethod
    public void tearDown() throws Exception {
        emf.close();
    }

    @org.testng.annotations.Test
    public void testTestSystem() throws Exception {
        EntityManager entityManager=emf.createEntityManager();

        BookID bid=new BookID();
        Library lib=new Library();

        entityManager.persist(bid);
        entityManager.persist(lib);


        BookVersion bv= new BookVersion();
        bv.setBookID(bid);
        bv.setLibrary(lib);

        entityManager.persist(bv);

        entityManager.close();


        entityManager=emf.createEntityManager();

        bv.setName("New Book");
        bv.setDescription("New Book");

        entityManager.merge(bv);

        emf.close();




    }
}
