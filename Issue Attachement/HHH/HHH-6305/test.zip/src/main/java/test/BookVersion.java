package test;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: nardonep
 * Date: 09/06/11
 * Time: 13:36
 * To change this template use File | Settings | File Templates.
 */
@Entity
//@IdClass(value = BookVersionPK.class)
public class BookVersion implements Serializable{

    private BookID bookID;

    private Library library;
    private String name;
    private String description;

    @Id
    @ManyToOne(cascade = CascadeType.ALL)
    public BookID getBookID() {
        return bookID;
    }

    public void setBookID(BookID bookID) {
        this.bookID = bookID;
    }


    @Id
    @ManyToOne(cascade = CascadeType.ALL)
    public Library getLibrary() {
        return library;
    }

    public void setLibrary(Library library) {
        this.library = library;
    }

    @Basic
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
