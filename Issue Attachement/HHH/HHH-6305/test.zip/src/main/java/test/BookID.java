package test;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: nardonep
 * Date: 09/06/11
 * Time: 13:36
 * To change this template use File | Settings | File Templates.
 */
@Entity
public class BookID implements Serializable {


     private Long identity;


    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    public Long getIdentity() {
        return identity;
    }

    public void setIdentity(Long identity) {
        this.identity = identity;
    }


}
