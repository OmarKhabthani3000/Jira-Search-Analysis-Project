package org.headlesspigs.domainmodel;


public class Invoice {
	private Long id;
	private int version;
	private String number;
	private Person receiver;
	private Person emitter;

	public Invoice() {
		super();
	}

	public Invoice(String number, Person receiver, Person emitter) {
		super();
		this.number = number;
		this.receiver = receiver;
		this.emitter = emitter;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public Person getReceiver() {
		return receiver;
	}

	public void setReceiver(Person receiver) {
		this.receiver = receiver;
	}

	public Person getEmitter() {
		return emitter;
	}

	public void setEmitter(Person emitter) {
		this.emitter = emitter;
	}

}
