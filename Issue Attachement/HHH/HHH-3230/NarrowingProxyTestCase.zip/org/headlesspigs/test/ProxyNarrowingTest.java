package org.headlesspigs.test;

import org.headlesspigs.domainmodel.Invoice;
import org.headlesspigs.domainmodel.WorkingPerson;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.TransientObjectException;
import org.hibernate.junit.functional.FunctionalTestCase;

public class ProxyNarrowingTest extends FunctionalTestCase {

	public ProxyNarrowingTest(String string) {
		super(string);
	}

	public String[] getMappings() {
		return new String[] { "Person.hbm.xml", "Invoice.hbm.xml" };
	}

	public String getBaseForMappings() {
		return "org/headlesspigs/domainmodel/";
	}

	public boolean createSchema() {
		return false;
	}

	public void testNarrowingProxy() throws Exception {
		Session s = null;
		Transaction tx = null;
		WorkingPerson p1 = null;
		WorkingPerson p2 = null;
		Invoice inv = null;
		try {
			s = this.openSession();
			tx = s.beginTransaction();
			p1 = new WorkingPerson("Adrian");
			p2 = new WorkingPerson("Batista", p1);
			inv = new Invoice("A-462", p1, p2);
			s.save(inv);
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			throw e;
		} finally {
			if (s != null) {
				s.close();
			}
		}

		try {
			s = this.openSession();
			tx = s.beginTransaction();
			inv = (Invoice) s.load(Invoice.class, inv.getId());
			assertEquals("A-462", inv.getNumber());

			// The following line causes the proxy to the emitter Person to be
			// initialized. During this initialization, a proxy to
			// the referee person is found but its type is Person and not
			// WorkingPerson as needed, so Hibernate creates another proxy to
			// the referee, this time of type WorkingPerson, replacing the old
			// one.
			assertEquals("Batista", inv.getEmitter().getName());
			try {
				s.getEntityName(inv.getReceiver());
				fail("It should have thrown TransientObjectException");
			} catch (TransientObjectException e) {
				e.printStackTrace(System.err);
			}
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			throw e;
		} finally {
			if (s != null) {
				s.close();
			}
		}
	}
}
