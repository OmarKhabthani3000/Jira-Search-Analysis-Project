package org.headlesspigs.domainmodel;

public class WorkingPerson extends Person {
	private WorkingPerson referee;

	public WorkingPerson() {
	}

	public WorkingPerson(String name) {
		super(name);
	}

	public WorkingPerson(String name, WorkingPerson referee) {
		this(name);
		this.referee = referee;
	}

	public WorkingPerson getReferee() {
		return referee;
	}

	public void setReferee(WorkingPerson referee) {
		this.referee = referee;
	}

}
