-- Hibernate test tables
CREATE TABLE ONE (
    o_id_pk   NUMBER(10) NOT NULL,
    o_val     VARCHAR2(20) NOT NULL
);

CREATE TABLE TWO (
	t_id_pk		NUMBER(10) NOT NULL,
	t_val		VARCHAR2(20) NOT NULL
);

INSERT INTO TWO (t_id_pk, t_val) VALUES (1, 'a');
INSERT INTO TWO (t_id_pk, t_val) VALUES (2, 'b');
INSERT INTO TWO (t_id_pk, t_val) VALUES (3, 'a');
INSERT INTO ONE (o_id_pk, o_val) VALUES (1, 'a');
INSERT INTO ONE (o_id_pk, o_val) VALUES (2, 'a');
