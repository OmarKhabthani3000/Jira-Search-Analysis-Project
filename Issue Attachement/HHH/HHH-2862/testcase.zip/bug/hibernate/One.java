/**
 * Copyright(c) 2007, Interactive Data
 */
package bug.hibernate;

import java.util.Set;

/**
 * @author pandrews
 *
 */
public class One {
	int id;
	String value;
	Set twos;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the twos
	 */
	public Set getTwos() {
		return twos;
	}
	/**
	 * @param twos the twos to set
	 */
	public void setTwos(Set twos) {
		this.twos = twos;
	}
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
}
