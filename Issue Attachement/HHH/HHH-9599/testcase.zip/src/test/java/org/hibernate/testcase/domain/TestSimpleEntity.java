package org.hibernate.testcase.domain;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestSimpleEntity {
	
	private static EntityManager entityManager;
	
	@BeforeClass
	public static void init() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("persistence");
		entityManager = emf.createEntityManager();
	}
	
	@AfterClass
	public static void destroy() {
		if(entityManager != null) {
			entityManager.close();
		}
	}
	
	/**
	 * Converter should have no affect on the stored value.
	 */
	@Test
	public void testConverterWithNonNullNonBlankValue() {			
		Long id = insertEntity("Named");
		Assert.assertTrue(id != null);
		
		SimpleEntity entity = findById(id);
		Assert.assertTrue(entity != null);
		Assert.assertTrue("Named".equals(entity.getName()));	
		Assert.assertTrue("Named".equals(entity.getRawName()));
	}

	// TODO: This particular case does not work as the AttributeConverter<X,Y> is not
	// invoked when the property actually is literally null.
	//
	//	/**
	//	 * Converter should translate the null value to ' ' in the database, which
	//	 * should be what the rawName property should hold upon being queried.
	//	 */
	//	@Test
	//	public void testConverterWithNullValue() {
	//		Long id = insertEntity(null);
	//		Assert.assertTrue(id != null);
	//		
	//		SimpleEntity entity = findById(id);
	//		Assert.assertTrue(entity != null);
	//		Assert.assertTrue(entity.getName() == null);
	//		Assert.assertTrue(" ".equals(entity.getRawName()));
	//	}
	
	/**
	 * Converter will take the blank and store it as-is but return the converted
	 * value as null while the rawName property should have the ' ' value.
	 */
	@Test
	public void testConverterWithBlankValue() {
		Long id = insertEntity(" ");
		Assert.assertTrue(id != null);
		
		SimpleEntity entity = findById(id);
		Assert.assertTrue(entity != null);
		Assert.assertTrue(entity.getName() == null);
		Assert.assertTrue(" ".equals(entity.getRawName()));
	}
	
	private Long insertEntity(String name) {
		System.out.println("Inserting entity with name [" + name + "].");
		EntityTransaction tx = entityManager.getTransaction();
		Long id = null;
		try {
			tx.begin();
			SimpleEntity entity = new SimpleEntity();
			entity.setName(name);
			entityManager.persist(entity);
			tx.commit();
			id = entity.getId();
			System.out.println("Record ID = " + id);
		}
		catch(Exception ex) {
			if(tx != null && tx.isActive()) {
				System.out.println("Performing rollback.");
				tx.rollback();
			}
		}
		finally {
			System.out.println("Clearing EntityManager.");
			entityManager.clear();
		}
		return id;
	}
	
	private SimpleEntity findById(Long id) {
		return entityManager.find(SimpleEntity.class, id);		
	}	
}
