package org.hibernate.testcase.domain;

import javax.persistence.AttributeConverter;

public class SapEmptyStringConverter implements AttributeConverter<String, String> {

	private static final String BLANK = " ";
	
	/**
	 * Translates {@literal null} into a single space character.
	 */
	@Override
	public String convertToDatabaseColumn(String attribute) {
		if(attribute == null || " ".equals(attribute)) {
			return BLANK;
		}
		return attribute;
	}

	/**
	 * Translates a single space character string to {@literal null}.
	 */
	@Override
	public String convertToEntityAttribute(String dbData) {
		if(dbData != null && " ".equals(dbData)) {
			return null;
		}
		return dbData;
	}

}
