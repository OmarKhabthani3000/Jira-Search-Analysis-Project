
package hibernate.bug.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by Naveen Kumar Gupta on 12/8/14.
 */
@Entity
@Table(name = "SUBJECT")
public class Subject implements Serializable{
    @Id
    @Column(name = "SUBJECT_ID")
    private int subjectId;
    @Column(name = "NAME")
    private String name;

    public Subject() {
    }

    public int getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(int subjectId) {
        this.subjectId = subjectId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Subject{" +
                "subjectId=" + subjectId +
                ", name='" + name + '\'' +
                '}';
    }
}
