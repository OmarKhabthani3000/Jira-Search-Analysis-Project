package hibernate.bug.model;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by Naveen Kumar Gupta on 12/8/14.
 */

@Entity
@Table(name = "STUDENT_MARKS_DATA")
public class StudentMarksData implements Serializable {
    @Id
    @Column(name = "ID")
    private int id;
    @Column(name = "STUDENT_ID")
    private int studentId;
    @Column(name = "SUBJECT_ID")
    private int subjectId;
    @Column(name = "MARKS")
    private short marks;

    @OneToOne(fetch= FetchType.EAGER,cascade = CascadeType.REFRESH)
    @JoinColumn(name="SUBJECT_ID", referencedColumnName = "SUBJECT_ID",insertable = false,updatable = false)
    private Subject subject;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public int getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(int subjectId) {
        this.subjectId = subjectId;
    }

    public short getMarks() {
        return marks;
    }

    public void setMarks(short marks) {
        this.marks = marks;
    }

    public Subject getSubject() {
        return subject;
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
    }
}
