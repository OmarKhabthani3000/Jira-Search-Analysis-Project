package hibernate.bug;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
//        EntityManager em = emf.createEntityManager();
//        EntityTransaction tx = em.getTransaction();
//        tx.begin();
//        
//        TypeInterface ti = new TypeInterface("ti1");
//        InterfaceInstance ii = new InterfaceInstance(ti);
//        ParameterType pt = new ParameterType(ti);
//        ParameterValue pv = new ParameterValue(pt, ii);
//        
//        em.persist(ti);
//        em.persist(ii);
//        em.persist(pt);
//        em.persist(pv);
//        
//        ii.getParameterValues().add(pv);
//        
//        em.flush();
//        tx.commit();
//        em.close();
    }
    
    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        
        List<Object[]> l = em.createQuery(
                "SELECT "
                        + "student.studentId, "
                        + "student.firstName, "
                        + "student.lastName, "
                        + "ms.name, "
                        + "math.marks, "
                        + "cs.name, "
                        + "computer.marks, "
                        + "ss.name, "
                        + "sanskrit.marks, "
                        + "hs.name, "
                        + "hindi.marks "
                + "FROM Student student "
                + "LEFT JOIN student.mathematics math ON math.subjectId = 1 "
                + "LEFT JOIN math.subject ms "
                + "LEFT JOIN student.computer computer ON computer.subjectId = 2 "
                + "LEFT JOIN computer.subject cs "
                + "LEFT JOIN student.sanskrit sanskrit ON sanskrit.subjectId = 3 "
                + "LEFT JOIN sanskrit.subject ss "
                + "LEFT JOIN student.hindi hindi ON hindi.subjectId = 4 "
                + "LEFT JOIN hindi.subject hs"
        )
                .getResultList();
        Assert.assertEquals(0, l.size());
        
        em.close();
    }
}
