
package hibernate.bug.model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

/**
 * Created by Naveen Kumar Gupta on 12/8/14.
 */
@Entity
@Table(name = "STUDENT")
public class Student implements Serializable{
    @Id
    @Column(name = "STUDENT_ID")
    private int studentId;

    @Column(name = "FIRST_NAME")
    private String firstName;

    @Column(name = "LAST_NAME")
    private String lastName;

    @Column(name = "REMARKS")
    private String remarks;

    @OneToMany(fetch= FetchType.EAGER,cascade = CascadeType.REFRESH)
    @JoinColumn(name="STUDENT_ID", referencedColumnName = "STUDENT_ID",insertable = false,updatable = false)
    private Set<StudentMarksData> mathematics;

    @OneToMany(fetch= FetchType.EAGER,cascade = CascadeType.REFRESH)
    @JoinColumn(name="STUDENT_ID", referencedColumnName = "STUDENT_ID",insertable = false,updatable = false)
    private Set<StudentMarksData> computer;

    @OneToMany(fetch= FetchType.EAGER,cascade = CascadeType.REFRESH)
    @JoinColumn(name="STUDENT_ID", referencedColumnName = "STUDENT_ID",insertable = false,updatable = false)
    private Set<StudentMarksData> sanskrit;

    @OneToMany(fetch= FetchType.EAGER,cascade = CascadeType.REFRESH)
    @JoinColumn(name="STUDENT_ID", referencedColumnName = "STUDENT_ID",insertable = false,updatable = false)
    private Set<StudentMarksData> hindi;


    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Set<StudentMarksData> getMathematics() {
        return mathematics;
    }

    public void setMathematics(Set<StudentMarksData> mathematics) {
        this.mathematics = mathematics;
    }

    public Set<StudentMarksData> getComputer() {
        return computer;
    }

    public void setComputer(Set<StudentMarksData> computer) {
        this.computer = computer;
    }

    public Set<StudentMarksData> getSanskrit() {
        return sanskrit;
    }

    public void setSanskrit(Set<StudentMarksData> sanskrit) {
        this.sanskrit = sanskrit;
    }

    public Set<StudentMarksData> getHindi() {
        return hindi;
    }

    public void setHindi(Set<StudentMarksData> hindi) {
        this.hindi = hindi;
    }
}