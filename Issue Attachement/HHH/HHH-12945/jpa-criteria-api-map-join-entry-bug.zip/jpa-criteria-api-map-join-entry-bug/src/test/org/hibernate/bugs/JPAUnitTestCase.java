package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.MapJoin;
import javax.persistence.criteria.Root;



import demo.example.Customer;
import demo.example.Customer_;
import demo.example.Order;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import java.util.List;
import java.util.Map;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory emf;

	@Before
	public void init() {
		emf = Persistence.createEntityManagerFactory( "example-unit" );
       persistEntity();
	}

	@After
	public void destroy() {
		emf.close();
	}

    @Test
    public void testJPQLMapJoinEntryTest() {
        EntityManager em = emf.createEntityManager();
        TypedQuery<Map.Entry> query =
                em.createQuery("SELECT ENTRY(c.orderMap) FROM Customer c", Map.Entry.class);
        List<Map.Entry> resultList = query.getResultList();

        Assert.assertTrue(resultList.size()==1);
        Assert.assertEquals("online", resultList.get(0).getKey());
    }


    @Test
    public void testCriteriaMapJoinEntryTest() {
        EntityManager entityManager = emf.createEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Map.Entry> query = criteriaBuilder.createQuery(Map.Entry.class);
        Root<Customer> customer = query.from(Customer.class);
        MapJoin<Customer, String, Order> orderMap = customer.join(Customer_.orderMap);
        query.select(orderMap.entry());
        TypedQuery<Map.Entry> typedQuery = entityManager.createQuery(query);
        List<Map.Entry> resultList = typedQuery.getResultList();
        Assert.assertTrue(resultList.size()==1);
        Assert.assertEquals("online", resultList.get(0).getKey());

    }


    private void persistEntity() {
        EntityManager em = emf.createEntityManager();
        Customer customer = new Customer();
        customer.setName("Morgan Philips");
        customer.addOrder("online", "AA Glass Cleaner", 3);

        em.getTransaction().begin();
        em.persist(customer);
        em.getTransaction().commit();
        em.close();
   }
}