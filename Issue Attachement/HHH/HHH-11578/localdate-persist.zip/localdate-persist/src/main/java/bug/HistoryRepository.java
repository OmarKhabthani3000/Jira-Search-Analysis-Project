package bug;

import java.time.LocalDate;

import org.springframework.data.repository.CrudRepository;

public interface HistoryRepository extends CrudRepository<History, LocalDate> {
}