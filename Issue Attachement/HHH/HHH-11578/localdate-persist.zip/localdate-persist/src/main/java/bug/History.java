package bug;

import java.time.LocalDate;

import javax.persistence.*;

@Entity
@Table(name = "history")
public class History {
    @Id
    @Column(nullable = false)
    private LocalDate date;

    @Column(nullable = false)
    private short count;

    protected History()
    {
    }

    public History(LocalDate date)
    {
        setDate(date);
    }

    public void setDate(LocalDate date)
    {
        if (this.date != null)
            throw new IllegalArgumentException("date cannot be changed");
        if (date == null)
            throw new NullPointerException("date cannot be null");
        this.date = date;
    }

    public LocalDate getDate()
    {
        return date;
    }

    public void setCount(int count)
    {
        this.count = (short) count;
    }

    public int getCount()
    {
        return count;
    }
}