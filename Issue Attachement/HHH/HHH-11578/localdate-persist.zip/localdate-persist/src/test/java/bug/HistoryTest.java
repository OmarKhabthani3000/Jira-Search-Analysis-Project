package bug;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@SpringBootTest(classes={PersistenceContext.class})
@DataJpaTest
@AutoConfigureTestDatabase(replace=AutoConfigureTestDatabase.Replace.NONE)
public class HistoryTest extends AbstractTestNGSpringContextTests {
    @Autowired
    private HistoryRepository history;

    @DataProvider
    public static Object[][] getRecords()
    {
        return new Object[][] {
                {LocalDate.of(2017, 3, 1), 301},
                {LocalDate.of(2017, 3, 2), 302},
                {LocalDate.of(2017, 3, 3), 303},
                {LocalDate.of(2017, 3, 4), 304},
                {LocalDate.of(2017, 3, 5), 305},
                {LocalDate.of(2017, 3, 6), 306},
                {LocalDate.of(2017, 3, 7), 307},
                {LocalDate.of(2017, 3, 8), 308},
                {LocalDate.of(2017, 3, 9), 309},
                {LocalDate.of(2017, 3, 10), 310},
                {LocalDate.of(2017, 3, 11), 311},
                {LocalDate.of(2017, 3, 12), 312},
                {LocalDate.of(2017, 3, 13), 313},
                {LocalDate.of(2017, 3, 14), 314},
                {LocalDate.of(2017, 3, 15), 315},
                {LocalDate.of(2017, 3, 16), 316},
                {LocalDate.of(2017, 3, 17), 317},
                {LocalDate.of(2017, 3, 18), 318},
                {LocalDate.of(2017, 3, 19), 319},
                {LocalDate.of(2017, 3, 20), 320},
                {LocalDate.of(2017, 3, 21), 321},
                {LocalDate.of(2017, 3, 22), 322},
                {LocalDate.of(2017, 3, 23), 323},
                {LocalDate.of(2017, 3, 24), 324},
                {LocalDate.of(2017, 3, 25), 325},
                {LocalDate.of(2017, 3, 26), 326},
                {LocalDate.of(2017, 3, 27), 327},
                {LocalDate.of(2017, 3, 28), 328},
                {LocalDate.of(2017, 3, 29), 329},
                {LocalDate.of(2017, 3, 30), 330},
                {LocalDate.of(2017, 3, 31), 331},
        };
    }

    @Test(dataProvider="getRecords")
    public void testWrite(LocalDate date, Integer count)
    {
        History record = new History(date);
        record.setCount(count);
        history.save(record);
    }

    @Test(dataProvider="getRecords", dependsOnMethods={"testWrite"})
    public void testRead(LocalDate date, Integer count)
    {
        History record = history.findOne(date);
        boolean matched = (record != null) && (record.getCount() == count);
        String message = String.format("expected count [%d] but found [%d]",
                count, record != null ? record.getCount() : null);
        if (!matched)
            System.out.println("HistoryTest.testRead(" + date.toString() + "," + count.toString() + "): " + message);
        assert matched : message;
    }
}