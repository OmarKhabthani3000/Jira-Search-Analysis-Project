package namedquery;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.SequenceGenerator;

@MappedSuperclass
public abstract class AbstractIdentifier<T> {

    @Id
    @SequenceGenerator(name = "AbstractIdentifier", sequenceName = "identifier_id")
    @GeneratedValue(generator="AbstractIdentifier")
    private int id;

    @ManyToOne(optional=false)
    private T entity;

    private String identifier;

    public int getId () {
        return id;
    }

    public void setId (final int id) {
        this.id = id;
    }

    public String getIdentifier () {
        return identifier;
    }

    public void setIdentifier (final String identifier) {
        this.identifier = identifier;
    }

    protected T getEntity () {
        return entity;
    }

    protected void setEntity (final T entity) {
        this.entity = entity;
    }
}
