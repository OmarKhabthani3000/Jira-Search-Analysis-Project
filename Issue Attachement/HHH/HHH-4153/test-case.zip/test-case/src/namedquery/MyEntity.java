package namedquery;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class MyEntity {
	
	 @Id
	 @SequenceGenerator(name = "myEntity", sequenceName = "myEntity_id")
	 @GeneratedValue(generator="myEntity")
	 private int id;
	 
	 private String name;
	
	 @OneToMany(mappedBy="entity")
	 private List<Identifier> identifiers;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Identifier> getIdentifiers() {
		return identifiers;
	}

	public void setIdentifiers(List<Identifier> identifiers) {
		this.identifiers = identifiers;
	}

}
