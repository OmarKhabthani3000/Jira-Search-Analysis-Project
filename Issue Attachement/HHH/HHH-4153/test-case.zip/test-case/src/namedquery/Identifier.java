package namedquery;

import javax.persistence.AssociationOverride;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;


@Entity
@AssociationOverride(name="entity", joinColumns=@JoinColumn(name="myEntity"))
@NamedQueries( {
        @NamedQuery(name = "myquery", query = "select idf.myEntity from Identifier idf where idf.identifier = :identifier")})
public class Identifier extends AbstractIdentifier<MyEntity> {

    public MyEntity getMyEntity () {
        return super.getEntity();
    }

    public void setMyEntity (final MyEntity myEntity) {
        super.setEntity(myEntity);
    }
}
