package notWorking;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("E")
public class ExcludedGroupUser extends GroupUser {
	
}
