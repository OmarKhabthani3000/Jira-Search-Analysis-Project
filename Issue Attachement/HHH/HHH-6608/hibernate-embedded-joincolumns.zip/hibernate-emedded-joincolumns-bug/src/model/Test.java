package model;

import org.hibernate.cfg.AnnotationConfiguration;

public class Test {

	public static void main(String[] args) {
		AnnotationConfiguration conf = new AnnotationConfiguration();
		conf.addAnnotatedClass(EmbeddedEntity.class);
		conf.addAnnotatedClass(MainEntity.class);
		conf.addAnnotatedClass(ReferencedEntity.class);
		conf.buildSessionFactory();
	}
	
}

