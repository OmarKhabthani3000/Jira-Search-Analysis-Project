package model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ReferencedEntity {

	@Id
	private Long id;
	
	private String testRef;
	
	private String test2Ref;
	
}
