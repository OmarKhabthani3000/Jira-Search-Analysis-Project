package model;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

@Embeddable
public class EmbeddedEntity implements Serializable {

	@ManyToOne
	@JoinColumns({
			@JoinColumn(name="test", referencedColumnName="testRef"),
			@JoinColumn(name="test2", referencedColumnName="test2Ref")
	})
	private ReferencedEntity referencedEntity;
	
}
