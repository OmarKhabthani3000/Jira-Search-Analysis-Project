package model;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MainEntity {

	@Id
	private Long id;
	
	@Embedded
	private EmbeddedEntity embeddedEntity;
	
	
}
