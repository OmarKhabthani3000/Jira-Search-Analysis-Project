import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class StudentPK implements Serializable {

	private String studentName;

	private String fatherName;

	@Override
	public int hashCode() {
		String str = "" + this.studentName.hashCode()
				+ this.fatherName.hashCode();
		return Integer.parseInt(str);
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof StudentPK)) {
			return false;
		} else {
			StudentPK studentPK = (StudentPK) obj;

			return this.studentName.equals(studentPK.studentName)
					&& this.fatherName.equals(studentPK.fatherName);
		}
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	// private String motherName;

}
