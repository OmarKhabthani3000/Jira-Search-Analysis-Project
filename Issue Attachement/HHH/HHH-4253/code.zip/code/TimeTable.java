import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="TIME_TABLE")
public class TimeTable {
	
	@Id
	@Column(name="TIME_TABLE_ID")
	private int timeTableId;
	
	@Column(name="CLASS_ID")
	private int classId;

	public int getTimeTableId() {
		return timeTableId;
	}

	public void setTimeTableId(int timeTableId) {
		this.timeTableId = timeTableId;
	}

	public int getClassId() {
		return classId;
	}

	public void setClassId(int classId) {
		this.classId = classId;
	}
}
