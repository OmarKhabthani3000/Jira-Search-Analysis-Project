import java.io.Serializable;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "STUDENT")
public class Student implements Serializable{
	@Id
	@AttributeOverrides( {
			@AttributeOverride(name = "studentName", column = @Column(name = "STUDENT_NAME")),
			@AttributeOverride(name = "fatherName", column = @Column(name = "FATHER_NAME")) })
	private StudentPK studentPK;

	@Column(name = "CLASS_ID")
	private int classId;

	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "CLASS_ID", referencedColumnName = "CLASS_ID")
	Set<TimeTable> timeTable;

	public StudentPK getStudentPK() {
		return studentPK;
	}

	public void setStudentPK(StudentPK studentPK) {
		this.studentPK = studentPK;
	}

	public int getClassId() {
		return classId;
	}

	public void setClassId(int classId) {
		this.classId = classId;
	}

	public Set<TimeTable> getTimeTable() {
		return timeTable;
	}

	public void setTimeTable(Set<TimeTable> timeTable) {
		this.timeTable = timeTable;
	}

}
