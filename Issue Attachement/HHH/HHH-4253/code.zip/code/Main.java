import org.hibernate.Session;



public class Main {
	public static void main(String[] args) {
		Session session = null;//Get the current session for example HibernateUtility.getCurrentSession();
		session.createQuery(" FROM Student").list();
	}

}
