package com.novaordis.HHH3163;

/**
 * @author <a href="mailto:ovidiu@feodorov.com">Ovidiu Feodorov</a>
 *
 * @version <tt>$Revision$</tt>
 *
 * $Id$
 */
public interface TestServiceMBean
{
    void start() throws Exception;
    void stop();
}
