package com.novaordis.HHH3163.model;

public class Item
{
    // Constants -----------------------------------------------------------------------------------

    // Static --------------------------------------------------------------------------------------

    // Attributes ----------------------------------------------------------------------------------

    private long id;

    private String name;

    private Record record;

    // Constructors --------------------------------------------------------------------------------

    Item()
    {
    }

    public Item(String name)
    {
        this.name = name;
    }

    // Public --------------------------------------------------------------------------------------

    public String getName()
    {
        return name;
    }

    public Record getRecord()
    {
        return record;
    }

    @Override
    public String toString()
    {
        return name;
    }

    // Package protected ---------------------------------------------------------------------------

    long getId()
    {
        return id;
    }

    void setRecord(Record record)
    {
        this.record = record;
    }

    // Protected -----------------------------------------------------------------------------------

    // Private -------------------------------------------------------------------------------------

    private void setId(long id)
    {
        this.id = id;
    }

    private void setName(String name)
    {
        this.name = name;
    }

    // Inner classes -------------------------------------------------------------------------------
}
