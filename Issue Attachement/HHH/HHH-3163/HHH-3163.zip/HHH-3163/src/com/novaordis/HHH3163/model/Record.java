package com.novaordis.HHH3163.model;

import java.util.Set;
import java.util.HashSet;

public class Record extends AbstractRecord
{
    // Constants -----------------------------------------------------------------------------------

    // Static --------------------------------------------------------------------------------------

    // Attributes ----------------------------------------------------------------------------------

    private Set<Item> items;

    // Constructors --------------------------------------------------------------------------------

    Record()
    {
        super();
        items = new HashSet<Item>();
    }

    public Record(String content)
    {
        super(content);
        items = new HashSet<Item>();
    }

    // Public --------------------------------------------------------------------------------------

    public Set<Item> getItems()
    {
        return items;
    }

    public void addItem(Item item)
    {
        items.add(item);
        item.setRecord(this);
    }

    public String toString()
    {
        return "Record[" + getContent() + "]" + getItems();
    }

    // Package protected ---------------------------------------------------------------------------

    // Protected -----------------------------------------------------------------------------------

    // Private -------------------------------------------------------------------------------------

    private void setItems(Set<Item> items)
    {
        this.items = items;
    }
    
    // Inner classes -------------------------------------------------------------------------------
}
