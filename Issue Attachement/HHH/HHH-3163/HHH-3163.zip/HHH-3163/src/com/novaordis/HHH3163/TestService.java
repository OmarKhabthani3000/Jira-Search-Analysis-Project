package com.novaordis.HHH3163;

import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.Query;
import org.hibernate.cfg.Configuration;

import java.util.List;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import com.novaordis.HHH3163.model.Record;
import com.novaordis.HHH3163.model.Item;

/**
 * @author <a href="mailto:ovidiu@feodorov.com">Ovidiu Feodorov</a>
 *
 * @version <tt>$Revision$</tt>
 *
 * $Id$
 */
public class TestService implements TestServiceMBean
{
    // Constants -----------------------------------------------------------------------------------

    // Static --------------------------------------------------------------------------------------

    // Attributes ----------------------------------------------------------------------------------

    private SessionFactory sessionFactory;

    // Constructors --------------------------------------------------------------------------------

    // TestServiceMBean implementation -------------------------------------------------------------

    public void start() throws Exception
    {
        System.out.println("starting TestService ...");

        initializeSessionFactory();

        loadTestData();

        deleteTestData();

        System.out.println("TestService started");
    }

    public void stop()
    {
        System.out.println("stoping TestService");
    }

    // Public --------------------------------------------------------------------------------------

    // Package protected ---------------------------------------------------------------------------

    // Protected -----------------------------------------------------------------------------------

    // Private -------------------------------------------------------------------------------------

    private void initializeSessionFactory() throws Exception
    {
        if (sessionFactory != null)
        {
            return;
        }

        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        sessionFactory = cfg.buildSessionFactory();
    }

    private void loadTestData() throws Exception
    {
        Session session = null;

        try
        {
            session = sessionFactory.openSession();

            Transaction tx = session.beginTransaction();

            String s = "select id, content from Record";
            Query query = session.createQuery(s);

            List list = query.list();

            tx.commit();

            int existentRecords = list.size();

            if (existentRecords == 1)
            {
                // the service is expected to only insert a row, so if that row is already in the
                // database, it means the data was already loaded

                Object[] a = (Object[])list.get(0);
                System.out.println("Test data already loaded: " + a[0] + " " + a[1]);
            }
            else if (existentRecords > 1)
            {
                // if we find more than one row, something is wrong

                throw new Exception("Corrupted test data: no more than one record expected in the database");
            }
            else
            {
                // no test data found, loading it ...

                Record record = new Record("GENERIC_RECORD_ONE");
                Item item = new Item("GENERIC_ITEM_ONE");
                record.addItem(item);

                session = sessionFactory.openSession();

                tx = session.beginTransaction();

                session.save(record);
                session.save(item);

                tx.commit();

                System.out.println("Test data loaded");
            }
        }
        finally
        {
            if (session != null)
            {
                session.close();
            }
        }

    }

    public void deleteTestData() throws Exception
    {
        int recordCountBeforeDelete = 0;

        Session session = sessionFactory.openSession();;

        // "taint" the session, this and the fact that the session is not closed will cause all
        // the confusion.
        Connection conn = session.connection() ;

        Statement statement = conn.createStatement() ;
        ResultSet result = statement.executeQuery("SELECT ID FROM Record");
        while(result.next())
        {
            recordCountBeforeDelete ++;
        }

        System.out.println("RECORDS BEFORE DELETE: " + recordCountBeforeDelete);

//        session.close();
//        session = sessionFactory.openSession();;

        int deletedRecordsCount = 0;

        try
        {
            String s = "delete from Record r where r.id between :from and :to";
            Query query = session.createQuery(s);

            Transaction tx = session.beginTransaction();

            query.setParameter("from", -100000l);
            query.setParameter("to", 100000l);

            deletedRecordsCount = query.executeUpdate();

            tx.commit();
        }
        finally
        {
            if (session != null)
            {
                session.close();
            }
        }

        System.out.println("SUCCESSFULLY DELETED " + deletedRecordsCount + " RECORDS, THE TABLE " +
                           "APPARENTLY HAS " + (recordCountBeforeDelete - deletedRecordsCount) +
                           " RECORDS LEFT");

        // actual records left in table

        try
        {
            session = sessionFactory.openSession();

            String s = "select id from Record";
            Query query = session.createQuery(s);
            Transaction tx = session.beginTransaction();
            List list = query.list();
            int actualRecordsInTable = list.size();
            tx.commit();

            System.out.println("THE TABLE ACTUALLY CONTAINS " + actualRecordsInTable  + " RECORDS");


            if (actualRecordsInTable != (recordCountBeforeDelete - deletedRecordsCount))
            {
                throw new Exception("TEST FAILED: expected " +
                                    (recordCountBeforeDelete - deletedRecordsCount) +
                                    " records in table, but found " + actualRecordsInTable);
            }
        }
        finally
        {
            if (session != null)
            {
                session.close();
            }
        }
    }

    // Inner classes -------------------------------------------------------------------------------
}
