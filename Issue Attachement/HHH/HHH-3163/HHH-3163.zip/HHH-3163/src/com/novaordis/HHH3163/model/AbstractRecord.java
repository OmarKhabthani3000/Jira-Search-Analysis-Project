package com.novaordis.HHH3163.model;

/**
 * @author <a href="mailto:ovidiu@feodorov.com">Ovidiu Feodorov</a>
 *
 * @version <tt>$Revision$</tt>
 *
 * $Id$
 */
public abstract class AbstractRecord
{
    // Constants -----------------------------------------------------------------------------------

    // Static --------------------------------------------------------------------------------------

    // Attributes ----------------------------------------------------------------------------------

    private long id;
    private String content;

    // Constructors --------------------------------------------------------------------------------

    public AbstractRecord()
    {
    }
    
    public AbstractRecord(String content)
    {
        this.content = content;
    }

    // Public --------------------------------------------------------------------------------------

    public String getContent()
    {
        return content;
    }

    // Package protected ---------------------------------------------------------------------------

    long getId()
    {
        return id;
    }

    // Protected -----------------------------------------------------------------------------------

    // Private -------------------------------------------------------------------------------------

    private void setId(long id)
    {
        this.id = id;
    }

    private void setContent(String content)
    {
        this.content = content;
    }

    // Inner classes -------------------------------------------------------------------------------
}
