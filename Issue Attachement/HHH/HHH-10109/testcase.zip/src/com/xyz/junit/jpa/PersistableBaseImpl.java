package com.xyz.junit.jpa;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.FilterDefs;
import org.hibernate.annotations.Filters;
import org.hibernate.annotations.ParamDef;

@MappedSuperclass
@FilterDefs( { @FilterDef( name = "aliveOnly", parameters = { @ParamDef( name = "aliveTimestamp", type = "timestamp" ) }, defaultCondition = "`DeletionTimestamp` = :aliveTimestamp" ) } )
@Filters( { @Filter( name = "aliveOnly", condition = "`DeletionTimestamp` = :aliveTimestamp" ) } )
public class PersistableBaseImpl
{
  @Column( name = "`DeletionTimestamp`" )
  protected Timestamp deletionTimestamp;

  public Timestamp getDeletionTimestamp()
  {
    return this.deletionTimestamp;
  }

  public void setDeletionTimestamp( Timestamp deletionTimestamp )
  {
    this.deletionTimestamp = removePrecision( deletionTimestamp );
  }

  protected Timestamp removePrecision( Timestamp timestamp )
  {
    Timestamp result = timestamp;
    if ( timestamp != null )
    {
      long time = timestamp.getTime();
      time = ( time / 10l ) * 10l;
      result = new Timestamp( time );
    }
    return result;
  }
}
