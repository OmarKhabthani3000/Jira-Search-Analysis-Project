package support.redhat.entity.inheritance;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import support.redhat.util.AutoCloser;
import junit.framework.TestCase;

public class TestHibernate extends TestCase {
	private EntityManager entityManager;

	private final AutoCloser m_closer = new AutoCloser();

	@Override
	protected void setUp() throws Exception {
		try {
			// Configures settings from annotations + persistence.xml
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("TEST");
			m_closer.push(emf);
			entityManager = emf.createEntityManager();
			m_closer.push(entityManager);
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	@Override
	protected void tearDown() throws Exception {
		if (entityManager != null) {
			m_closer.close();
			entityManager = null;
		}
	}

	public void test() {
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		{
			Cat cat = new Cat("0123456789", "Wampus");
			// entityManager.persist(emp1);
			// entityManager.persist(emp2);
			entityManager.persist(cat);
		}
		transaction.commit();

		transaction.begin();
		{
System.out.println("========= deleting cat =========");
			entityManager.createQuery("delete from Cat").executeUpdate();
		}
		transaction.commit();
	}
}
