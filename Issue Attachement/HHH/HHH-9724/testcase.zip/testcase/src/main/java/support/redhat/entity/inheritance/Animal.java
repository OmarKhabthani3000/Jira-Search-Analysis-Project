package support.redhat.entity.inheritance;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy=InheritanceType.JOINED)
public class Animal {
	@Id
	private String serial;

	public Animal(String serial) {
		this();
		setSerial(serial);
	}

	public String getSerial() {
		return this.serial;
	}

	protected Animal() {
		// Hibernate
	}

	private void setSerial(String serial) {
		this.serial = serial;
	}
}
