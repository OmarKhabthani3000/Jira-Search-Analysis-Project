package support.redhat.entity.inheritance;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@PrimaryKeyJoinColumn(name="serial")
public class Cat extends Animal {
	private String name;

	public Cat(String serial, String name) {
		super(serial);
		setName(name);
	}

	public String getName() {
		return this.name;
	}

	protected Cat() {
		// Hibernate
	}

	private void setName(String name) {
		this.name = name;
	}
}
