To easily manage the path, add Oracle to your Maven repository:
- mvn install:install-file -Dfile="ojdbc6.jar" -DgroupId="com.oracle" -DartifactId="ojdbc6" -Dversion="11" -Dpackaging="jar"
- The pom.xml assumes you've done this - easier than specifying a hard coded path for the jar

You will need to modify the following properties in ./src/test/resources/META-INF/persistence.xml for your Oracle database:
- connection.url
- connection.username
- connection.password

Note that log4j.logger.org.hibernate.hql.spi.TemporaryTableBulkIdStrategy=TRACE

Results:
- Starting with the second run you will see the test output something like the below (also in the database server logs):

[2015-04-02 15:04:44] DEBUG [org.hibernate.hql.spi.TemporaryTableBulkIdStrategy$TemporaryTableCreationWork] unable to create temporary id table [ORA-00955: name is already used by an existing object
]
