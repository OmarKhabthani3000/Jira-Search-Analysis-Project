package demo;

import demo.domain.Order;
import demo.domain.OrderLine;
import demo.utils.HibernateTemplate;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.junit.Test;

public class AppTest {

    @Test
    public void shouldFailToResolveEntityName() {
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");
        ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
                .applySettings(configuration.getProperties()).build();
        SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
        
        new HibernateTemplate(sessionFactory).execute(new HibernateTemplate.Executor() {

            @Override
            public void doWithinTransaction(Session sess) {
                Order order = new Order();
                order.setReference("123456");
                sess.persist(order);
                
                OrderLine orderLine = new OrderLine();
                orderLine.setItem("The Lord of the Rings");
                orderLine.setQuantity(1);
                orderLine.setOrder(order);
                sess.persist(orderLine);
            }

        });

        new HibernateTemplate(sessionFactory).execute(new HibernateTemplate.Executor() {

            @Override
            public void doWithinTransaction(Session sess) {
                List<OrderLine> orderLines = sess.createCriteria(OrderLine.class).list();
                for (OrderLine orderLine : orderLines) {
                    System.out.println(orderLine.getOrder());
                }
            }

        });

        if (sessionFactory != null) {
            sessionFactory.close();
        }
        if (serviceRegistry != null) {
            StandardServiceRegistryBuilder.destroy(serviceRegistry);
        }
    }

}
