package demo.utils;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class HibernateTemplate {

    private SessionFactory sessionFactory;
    
    public HibernateTemplate(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
    public void execute(Executor executor) {
        Session sess = null;
        Transaction tx = null;
        try {
            sess = sessionFactory.openSession();
            tx = sess.beginTransaction();
            executor.doWithinTransaction(sess);
            tx.commit();
        } catch (RuntimeException re) {
            if (tx != null) {
                tx.rollback();
            }
            throw re;
        } finally {
            if (sess != null) {
                sess.close();
            }
        }
    }

    public static interface Executor {
        
        void doWithinTransaction(Session sess);
        
    }

}
