package com.acme;

import static junit.framework.Assert.*;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class FooTest {
    protected static EntityManagerFactory emf;

    protected EntityManager em;

    @BeforeClass
    public static void createEntityManagerFactory() {
        emf = Persistence.createEntityManagerFactory("TestPu");
    }

    @AfterClass
    public static void closeEntityManagerFactory() {
        emf.close();
    }

    @Before
    public void beginTransaction() {
        em = emf.createEntityManager();
        em.getTransaction().begin();
    }

    @After
    public void rollbackTransaction() {

        if ( em.getTransaction().isActive() ) {
            em.getTransaction().rollback();
        }

        if ( em.isOpen() ) {
            em.close();
        }
    }

    @Test
    public void testInsertFooAndBarWithDerivedId() {
        Bar bar = new Bar();
        bar.setDetails("Some details");
        Foo foo = new Foo();
        foo.setBar(bar);
        bar.setFoo(foo);
        em.persist(foo);
        em.flush();
        assertNotNull(foo.getId());
        assertEquals(foo.getId(), bar.getFoo().getId());

        em.clear();
        Bar newBar = (Bar) em.createQuery("SELECT b FROM Bar b WHERE b.foo.id = :id")
            .setParameter("id", foo.getId())
            .getSingleResult();
        assertNotNull(newBar);
        assertEquals("Some details", newBar.getDetails());

    }
}
