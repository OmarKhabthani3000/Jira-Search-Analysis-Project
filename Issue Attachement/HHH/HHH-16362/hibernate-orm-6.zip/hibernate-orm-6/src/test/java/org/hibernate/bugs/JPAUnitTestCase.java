package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;
import java.util.UUID;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	private UUID imageLogUuid = UUID.randomUUID();

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		UUID lateralUuid = UUID.randomUUID();
		UUID companyUuid = UUID.randomUUID();

		Company company = new Company();
		company.setId(100L);
		company.setName("TEST-COMPANY");
		entityManager.persist(company);

		Project project = new Project();
		project.setId(3L);
		project.setUuid(companyUuid);
		project.setCompany(company);
		entityManager.persist(project);

		Lateral lateral = new Lateral();
		lateral.setId(2L);
		lateral.setUuid(lateralUuid);
		lateral.setProject(project);
		entityManager.persist(lateral);

		ImageLog imageLog = new ImageLog();
		imageLog.setId(1L);
		imageLog.setUuid(imageLogUuid);
		imageLog.setLateral(lateral);
		entityManager.persist(imageLog);

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	@After
	public void destroy() {

		entityManagerFactory.close();
	}

	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		String hql = "SELECT ilog.`lateral`.project FROM ImageLog ilog JOIN FETCH ilog.`lateral`.project.company WHERE ilog.uuid = ?1";
		Query query = entityManager.createQuery(hql);
		query.setParameter(1, imageLogUuid);
		Project project = (Project) query.getSingleResult();
		String companyName = project.company.getName();


		Assert.assertEquals("TEST-COMPANY", companyName);

		entityManager.getTransaction().commit();
		entityManager.close();

		System.out.printf("==============================END=============================");
	}
}
