package org.hibernate.bugs.domain;

public class Job {

	private JobExecution jobExecution;

	public JobExecution getJobExecution() {
		return jobExecution;
	}

	public void setJobExecution(JobExecution jobExecution) {
		this.jobExecution = jobExecution;
	}
}
