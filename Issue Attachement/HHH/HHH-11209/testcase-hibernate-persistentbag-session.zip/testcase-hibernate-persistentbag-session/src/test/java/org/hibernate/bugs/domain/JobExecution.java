package org.hibernate.bugs.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class JobExecution {

	@Id
	@GeneratedValue
	private long id;

	@ManyToOne(fetch=FetchType.LAZY)
	private JobExecution parentJob;

	@OneToMany(mappedBy = "jobExecution")
	private List<JobLogMessage> jobLogMessages = new ArrayList<>();

	private int stats = 0;

	public List<JobLogMessage> getJobLogMessages() {
		return jobLogMessages;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getStats() {
		return stats;
	}

	public void setStats(int stats) {
		this.stats = stats;
	}

	public JobExecution getParentJob() {
		return parentJob;
	}

	public void setParentJob(JobExecution parentJob) {
		this.parentJob = parentJob;
	}
}
