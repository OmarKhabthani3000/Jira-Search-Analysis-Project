package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.bugs.domain.Job;
import org.hibernate.bugs.domain.JobExecution;
import org.hibernate.bugs.domain.JobLogMessage;
import org.hibernate.testing.TestForIssue;
import org.hibernate.testing.transaction.TransactionUtil;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
@TestForIssue(jiraKey = "XXXXXX")
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	public EntityManagerFactory getEntityManagerFactory() {
		return entityManagerFactory;
	}

	/**
	 * PersistentBag (OneToMany attribute) throws {@link NullPointerException} after several Transactions with
	 * {@link EntityManager#merge(Object)}
	 */
	@Test
	public void hhhxxxxxTest() {
		Job job = new Job();
		JobLogMessage message = new JobLogMessage("Error somewhere");
		// Create JobExecution
		TransactionUtil.doInJPA(this::getEntityManagerFactory, entityManager -> {
			JobExecution execution = new JobExecution();
			job.setJobExecution(execution);
			entityManager.persist(execution);
		});
		// Create Message for JobExecution
		TransactionUtil.doInJPA(this::getEntityManagerFactory, entityManager -> {
			JobExecution execution = entityManager.merge(job.getJobExecution());
			job.setJobExecution(execution);
			message.setJobExecution(execution);
			entityManager.persist(message);

			// Note: Important step! Initialize the PersistentBag, so the message gets put in PersistentBag.bag
			execution.getJobLogMessages().size();
			execution.getJobLogMessages().add(message);
		});

		TransactionUtil.doInJPA(this::getEntityManagerFactory, entityManager -> {
			// Note: merge() now puts the PersistentBag.bag entries in PersistentBag.operationQueue as it isn't initialized yet (lazy fetching)
			JobExecution parent = entityManager.merge(job.getJobExecution());
			job.setJobExecution(parent);
		});

		TransactionUtil.doInJPA(this::getEntityManagerFactory, entityManager -> {
			// NPE in Entity.replace. CollectionType.replace()
			entityManager.merge(job.getJobExecution());
		});
	}

}
