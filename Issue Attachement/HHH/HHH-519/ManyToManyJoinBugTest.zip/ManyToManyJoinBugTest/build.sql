create table department (
    dept_id  number(10),
    dept_name varchar2(50),
    constraint pk_dept primary key (dept_id)
)
/

create table employee (
    emp_id number(10),
    emp_name varchar2(50),
    constraint pk_emp primary key (emp_id)
)
/

create table emp_dept (
    dept_id number(10),
    emp_id number(10),
    constraint pk_emp_dept primary key (dept_id, emp_id),
    constraint fk_emp_dept_dept foreign key (dept_id) references department(dept_id),
    constraint fk_emp_dept_emp foreign key (emp_id) references employee(emp_id)
)
/

create table employee_properties (
    emp_id number(10),
    property_name varchar2(50),
    property_value varchar2(50),
    constraint pk_emp_prop primary key (emp_id,property_name),
    constraint fk_emp_prop_emp foreign key (emp_id) references employee(emp_id)
)
/
