drop table employee_properties
/

drop table emp_dept
/

drop table employee
/

drop table department
/

