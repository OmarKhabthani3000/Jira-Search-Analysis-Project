package test;

import org.hibernate.*;
import org.hibernate.cfg.*;
import org.hibernate.type.*;

import java.sql.*;
import java.util.Properties;
import java.util.List;
import java.io.FileInputStream;
import java.math.BigDecimal;

public class Test {
    public static void main(String[] argv) {
        Session sess = null;

        try {

            Configuration cfg = new Configuration();
            cfg.addFile("mapping.xml");
            cfg.addProperties(loadProperties());
            SessionFactory fact = cfg.buildSessionFactory();
            sess = fact.openSession();

            // This one works:
            Query q1 = sess.createQuery("select d from Employee e join e.departments d");
            List l = q1.list();

            // This one blows up:
            Query q2 = sess.createQuery("select d from Department d join d.employees e");
            l = q2.list();
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
        finally {
            if (sess != null) sess.close();
        }
    }

    private static Properties loadProperties() throws Exception {
        Properties props = new Properties();
        FileInputStream propStream = new FileInputStream("test.properties");
        props.load(propStream);
        propStream.close();
        return props;
    }
}
