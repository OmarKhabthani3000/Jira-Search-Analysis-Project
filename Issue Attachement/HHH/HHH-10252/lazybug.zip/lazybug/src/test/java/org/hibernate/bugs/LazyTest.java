package org.hibernate.bugs;

import static org.junit.Assert.assertEquals;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

public class LazyTest extends BaseCoreFunctionalTestCase {

    @Override
    protected Class[] getAnnotatedClasses() {
        return new Class[] {
                Parent.class,
                Child.class
        };
    }

    @Test
    public void lazyIssue() throws Exception {
        createFamily();

        getChildrenAndLazy();

        getLazyAndChildren();
    }

    private void createFamily() {
        // Create a Parent with one Child
        Session s = openSession();
        s.beginTransaction();

        Parent p = new Parent();
        p.setName("PARENT");
        p.setLazy("LAZY");

        Child child = p.makeChild();
        s.persist(p);

        s.getTransaction().commit();
        s.close();
    }

    private void getChildrenAndLazy() {
        Parent p = null;
        Session s = openSession();
        s.beginTransaction();
        p = (Parent) s.createQuery("SELECT p FROM Parent p WHERE name=:name")
                        .setParameter("name", "PARENT").uniqueResult();
        assertEquals(1, p.getChildren().size());
        assertEquals("LAZY", p.getLazy());
        s.getTransaction().commit();
        s.close();
    }

    private void getLazyAndChildren() {
        Parent p = null;
        Session s = openSession();
        s.beginTransaction();
        p = (Parent) s.createQuery("SELECT p FROM Parent p WHERE name=:name")
                        .setParameter("name", "PARENT").uniqueResult();
        assertEquals(1, p.getChildren().size());
        assertEquals("LAZY", p.getLazy());
        s.getTransaction().commit();
        s.close();
    }
}
