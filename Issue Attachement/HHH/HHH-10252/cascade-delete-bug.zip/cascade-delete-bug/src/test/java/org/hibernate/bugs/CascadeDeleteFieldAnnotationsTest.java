package org.hibernate.bugs;

import static org.junit.Assert.fail;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

public class CascadeDeleteFieldAnnotationsTest extends BaseCoreFunctionalTestCase {

    @Override
    protected Class[] getAnnotatedClasses() {
        return new Class[] {
                Parent.class,
                Child.class
        };
    }

    @Test
    public void cascadeDeleteFail() throws Exception {
        // Create a Parent with one Child
        Session s = openSession();
        s.beginTransaction();

        Parent p = new Parent();
        p.setName("BAD");

        final Child child = p.makeChild();
        s.persist(p);

        s.getTransaction().commit();
        s.close();

        // Delete the Parent
        s = openSession();
        s.beginTransaction();
        Parent loadedParent =
                (Parent) s.createQuery("SELECT p FROM Parent p WHERE name=:name")
                        .setParameter("name", "BAD").uniqueResult();
        s.delete(loadedParent);
        s.getTransaction().commit();
        s.close();
    }
}
