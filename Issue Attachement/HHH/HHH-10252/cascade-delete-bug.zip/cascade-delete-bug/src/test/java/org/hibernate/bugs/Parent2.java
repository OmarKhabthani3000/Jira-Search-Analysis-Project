package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Parent2 {
	private Long id;
	private String name;
	private List<Child2> children = new ArrayList<Child2>();

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@OneToMany(mappedBy = "parent", cascade = {CascadeType.PERSIST, CascadeType.MERGE,
			CascadeType.REFRESH, CascadeType.REMOVE},
			fetch = FetchType.LAZY)
	public List<Child2> getChildren() {
		return children;
	}

	public void setChildren(List<Child2> children) {
		this.children = children;
	}

	Child2 makeChild() {
		final Child2 c = new Child2();
		c.setParent( this );
		this.children.add( c );
		return c;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
