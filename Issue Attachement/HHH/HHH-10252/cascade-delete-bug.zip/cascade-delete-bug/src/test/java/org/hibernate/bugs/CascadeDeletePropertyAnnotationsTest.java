package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

public class CascadeDeletePropertyAnnotationsTest extends BaseCoreFunctionalTestCase {

    @Override
    protected Class[] getAnnotatedClasses() {
        return new Class[] {
                Parent2.class,
                Child2.class
        };
    }

    @Test
    public void cascadeDeleteOK() throws Exception {
        // Create a Parent with one Child
        Session s = openSession();
        s.beginTransaction();

        Parent2 p = new Parent2();
        p.setName("OK");

        final Child2 child = p.makeChild();
        s.persist( p );

        s.getTransaction().commit();
        s.close();

        // Delete the Parent
        s = openSession();
        s.beginTransaction();
        Parent2 loadedParent =
                (Parent2) s.createQuery("SELECT p FROM Parent2 p WHERE name=:name")
                        .setParameter("name", "OK").uniqueResult();
        s.delete(loadedParent);
        s.getTransaction().commit();
        s.close();
    }
}
