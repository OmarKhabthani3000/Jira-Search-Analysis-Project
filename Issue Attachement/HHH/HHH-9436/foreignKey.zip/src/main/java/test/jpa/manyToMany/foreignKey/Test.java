package test.jpa.manyToMany.foreignKey;

import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class Test {
	public static void main(String[] args) {
		SchemaExport schemaExport = new SchemaExport(init());
		schemaExport.setDelimiter(";");
		schemaExport.setHaltOnError(false);
		schemaExport.create(true, true);
	}

	public static Configuration init() {
		Configuration configuration = new Configuration();

		configuration
				.setProperty(Environment.USER, "")
				.setProperty(Environment.PASS, "")
				.setProperty(Environment.URL,
						"jdbc:h2:mem:db;DB_CLOSE_DELAY=-1;MODE=Oracle")
				.setProperty(Environment.DIALECT,
						"org.hibernate.dialect.Oracle10gDialect")
				.setProperty(Environment.DRIVER, "org.h2.Driver")
				.setProperty(Environment.HBM2DDL_AUTO, "create")
				.setProperty(Environment.SHOW_SQL, "true");

		configuration.addAnnotatedClass(Pojo.class).addAnnotatedClass(
				Subpojo.class);

		return configuration;
	}

}
