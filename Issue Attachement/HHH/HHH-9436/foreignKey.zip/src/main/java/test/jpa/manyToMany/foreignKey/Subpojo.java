package test.jpa.manyToMany.foreignKey;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SUB_POJO")
public class Subpojo {

	@Id
	Long id;

	@Column(length = 100)
	String data;

}
