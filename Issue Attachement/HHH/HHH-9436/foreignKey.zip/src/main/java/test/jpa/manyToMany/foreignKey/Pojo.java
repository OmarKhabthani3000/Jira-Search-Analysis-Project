package test.jpa.manyToMany.foreignKey;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Cascade;

@Entity
@Table(name = "POJO")
public class Pojo {

	Long id;
	List<Subpojo> data;

	@Id
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@OneToMany(cascade = CascadeType.ALL)
	@Cascade(org.hibernate.annotations.CascadeType.ALL)
	//@org.hibernate.annotations.ForeignKey(name = "SPL_FK_POJO", inverseName = "SPL_FK_SUB_POJO")
	@JoinTable(name = "SPL", //
	joinColumns = @JoinColumn(name = "SPL_POJO_ID", foreignKey = @javax.persistence.ForeignKey(name = "SPL_FK_POJO")), //
	inverseJoinColumns = @JoinColumn(name = "SPL_SUB_POJO_ID", foreignKey = @ForeignKey(name = "SPL_FK_SUB_POJO")), //
	uniqueConstraints = @UniqueConstraint(name = "SPL_UK", columnNames = "SPL_SUB_POJO_ID"))
	@OrderColumn(name = "SPL_ORDER")
	public List<Subpojo> getData() {
		return data;
	}

	public void setData(List<Subpojo> data) {
		this.data = data;
	}

}
