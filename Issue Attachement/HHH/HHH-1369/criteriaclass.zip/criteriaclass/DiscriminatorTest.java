package org.hibernate.test.criteriaclass;

import java.util.Iterator;
import java.util.List;

import junit.framework.Test;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;

/**
 * @author Gavin King
 */
public class DiscriminatorTest extends FunctionalTestCase {

	public DiscriminatorTest(String str) {
		super(str);
	}

	public String[] getMappings() {
		return new String[] { "criteriaclass/Person.hbm.xml" };
	}

	public static Test suite() {
		return new FunctionalTestClassTestSuite( DiscriminatorTest.class );
	}

	public void testDiscriminatorSubclass() {
		Session s = openSession();
		Transaction t = s.beginTransaction();

		Employee mark = new Employee();
		mark.setName("Mark");
		mark.setTitle("internal sales");
		mark.setSex('M');

		Customer joe = new Customer();
		joe.setName("Joe");
		joe.setComments("Very demanding");
		joe.setSex('M');
		joe.setSalesperson(mark);

		Person yomomma = new Person();
		yomomma.setName("mum");
		yomomma.setSex('F');

		s.save(yomomma);
		s.save(mark);
		s.save(joe);

		assertEquals( s.createCriteria(java.io.Serializable.class).list().size(), 0 );

		assertEquals( s.createCriteria(Person.class).list().size(), 3 );
		assertEquals( s.createCriteria(Customer.class).list().size(), 1 );
		assertEquals( s.createCriteria(Person.class).add(Restrictions.eq("class", "P")).list().size(), 1 );
		assertEquals( s.createCriteria(Person.class).add(Restrictions.eq("class", "C")).list().size(), 1 );
		assertEquals( s.createCriteria(Person.class).add(Restrictions.eq("class", Customer.class)).list().size(), 1 );
		assertEquals( s.createCriteria(Person.class).add(Restrictions.eq("class", Person.class)).list().size(), 1 );
		s.clear();

		List customers = s.createQuery("from Customer c left join fetch c.salesperson").list();
		for ( Iterator iter = customers.iterator(); iter.hasNext(); ) {
			Customer c = (Customer) iter.next();
			assertTrue( Hibernate.isInitialized( c.getSalesperson() ) );
			assertEquals( c.getSalesperson().getName(), "Mark" );
		}
		assertEquals( customers.size(), 1 );
		s.clear();

		customers = s.createQuery("from Customer").list();
		for ( Iterator iter = customers.iterator(); iter.hasNext(); ) {
			Customer c = (Customer) iter.next();
			assertFalse( Hibernate.isInitialized( c.getSalesperson() ) );
			assertEquals( c.getSalesperson().getName(), "Mark" );
		}
		assertEquals( customers.size(), 1 );
		s.clear();


		mark = (Employee) s.get( Employee.class, new Long( mark.getId() ) );
		joe = (Customer) s.get( Customer.class, new Long( joe.getId() ) );

		assertEquals( s.createQuery("from Person p where p.address.zip = '30306'").list().size(), 1 );
		s.delete(mark);
		s.delete(joe);
		s.delete(yomomma);
		assertTrue( s.createQuery("from Person").list().isEmpty() );
		t.commit();
		s.close();
	}


}

