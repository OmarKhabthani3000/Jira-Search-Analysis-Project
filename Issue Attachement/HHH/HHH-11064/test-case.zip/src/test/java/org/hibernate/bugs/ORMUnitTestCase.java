/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 *
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
				Student.class,
				Slacker.class,
				SchoolClass.class
		};
	}

	// If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
	@Override
	protected String[] getMappings() {
		return new String[] {
		};
	}
	// If those mappings reside somewhere other than resources/org/hibernate/test, change this.
	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/test/";
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );

		configuration.setProperty( AvailableSettings.SHOW_SQL, Boolean.TRUE.toString() );
		configuration.setProperty( AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString() );

		configuration.setProperty( AvailableSettings.DIALECT, "org.hibernate.dialect.MySQLDialect" );
		configuration.setProperty( AvailableSettings.DRIVER, "com.mysql.jdbc.Driver" );
		configuration.setProperty( AvailableSettings.URL, "jdbc:mysql://localhost/h5test" );
		configuration.setProperty( AvailableSettings.USER, "db1" );
		configuration.setProperty( AvailableSettings.PASS, "db1" );
	}


	/**
	 * Tests whether a record inserted with @DiscriminatorValue("App\\Models\\Slacker") will result
	 * in a record with the discriminator column set to 'App\Models\Slacker'
	 * @throws Exception
     */
	@Test
	public void hhh11064TestInsertion() throws Exception {
		// BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		// Do stuff...

		SchoolClass c = new SchoolClass();
		c.setName("Class 1");
		s.save(c);

		Slacker slacker = new Slacker();
		slacker.setName("John Doe");
		slacker.setSchoolClass(c);
		s.save(slacker);

		s.flush();
		s.evict(c);
		s.evict(slacker);

		s.refresh(slacker);
		Assert.assertEquals("Check if Discriminator was inserted correctly.", "App\\Models\\Slacker", slacker.getStudentType());

		tx.commit();
		s.close();
	}

	/**
	 * Tests whether a record inserted with Discriminator value 'App\Models\Slacker' will correctly be selected
	 * by a query based on a class annotated with @DiscriminatorValue("App\\Models\\Slacker")
	 *
	 * @throws Exception
	 */
	@Test
	public void hhh11064TestSelection() throws Exception {
		// BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		// Do stuff...

		SchoolClass c = new SchoolClass();
		c.setName("Class 3");
		s.save(c);

		s.flush();
		s.evict(c);

		s.createNativeQuery("INSERT INTO students (id, name, class_id, student_type) VALUES (30, 'Jane Doe', "+c.getId()+", 'App\\\\Models\\\\Slacker')").executeUpdate();

		List<Slacker> results = s.createQuery("SELECT s FROM Slacker s", Slacker.class).getResultList();
		Assert.assertEquals("Check if discriminator-based querying works (Result size == 1)", 1, results.size());

		tx.commit();
		s.close();
	}

	@Test
	public void hhh11064TestMatchingOfHHHInsertedDiscriminator() throws Exception {
		// BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		// Do stuff...

		SchoolClass c = new SchoolClass();
		c.setName("Class 4");
		s.save(c);

		Slacker slacker = new Slacker();
		slacker.setName("John Doe 4");
		slacker.setSchoolClass(c);
		s.save(slacker);

		s.flush();
		s.evict(c);
		s.evict(slacker);

		List<SchoolClass> classes = s.createQuery("SELECT c FROM SchoolClass c", SchoolClass.class).getResultList();
		Assert.assertEquals(1, classes.size());
		Assert.assertEquals(1, classes.get(0).getStudents().size());
		Assert.assertEquals("Check for correct Discriminator", "App\\Models\\Slacker", classes.get(0).getStudents().get(0).getStudentType());
		Assert.assertEquals("Check for correct Class derivation", Slacker.class, classes.get(0).getStudents().get(0).getClass());

		tx.commit();
		s.close();
	}

	/**
	 * Check whether the Class selection based on a correctly inserted record is correct.
	 * That is,
	 *
	 * 'App\Models\Slacker' from the database, should match class with @DiscriminatorValue("App\\Models\\Slacker")
	 *
	 * @throws Exception
     */
	@Test
	public void hhh11064TestMatchingOfRawDiscriminator() throws Exception {
		// BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		// Do stuff...

		SchoolClass c = new SchoolClass();
		c.setName("Class 2");
		s.save(c);

		s.flush();
		s.evict(c);

		// note the double escapes, one for Java, one for MySQL.
		s.createNativeQuery("INSERT INTO students (id, name, class_id, student_type) VALUES (31, 'Jane Doe', "+c.getId()+", 'App\\\\Models\\\\Slacker')").executeUpdate();

		List<SchoolClass> classes = s.createQuery("SELECT c FROM SchoolClass c", SchoolClass.class).getResultList();
		Assert.assertEquals(1, classes.size());
		Assert.assertEquals(1, classes.get(0).getStudents().size());
		Assert.assertEquals("Check for correct Discriminator", "App\\Models\\Slacker", classes.get(0).getStudents().get(0).getStudentType());
		Assert.assertEquals("Check for correct Class derivation", Slacker.class, classes.get(0).getStudents().get(0).getClass());

		tx.commit();
		s.close();
	}
}
