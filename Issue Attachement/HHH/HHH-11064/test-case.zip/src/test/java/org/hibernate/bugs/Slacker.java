package org.hibernate.bugs;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "students")
@DiscriminatorValue("App\\Models\\Slacker")
public class Slacker extends Student {
}
