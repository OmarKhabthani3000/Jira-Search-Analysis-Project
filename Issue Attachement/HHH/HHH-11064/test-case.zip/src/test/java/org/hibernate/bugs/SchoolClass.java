package org.hibernate.bugs;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "classes")
public class SchoolClass {

    private int id;
    private String name;
    private List<Student> students;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.AUTO)
    public int getId(){
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "name")
    public String getName(){
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @OneToMany(mappedBy = "schoolClass")
    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }
}
