package org.hibernate.bugs;

import javax.persistence.*;

@Entity
@Table(name = "students")
@Inheritance
@DiscriminatorColumn(name="student_type")
public class Student {

    private int id;
    private String name;
    private SchoolClass schoolClass;
    private String studentType;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.AUTO)
    public int getId(){
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "name")
    public String getName(){
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "student_type", updatable = false, insertable = false)
    public String getStudentType(){
        return studentType;
    }

    public void setStudentType(String studentType) {
        this.studentType = studentType;
    }

    @ManyToOne(optional = false)
    @JoinColumn(name="class_id")
    public SchoolClass getSchoolClass() {
        return schoolClass;
    }

    public void setSchoolClass(SchoolClass schoolClass) {
        this.schoolClass = schoolClass;
    }
}
