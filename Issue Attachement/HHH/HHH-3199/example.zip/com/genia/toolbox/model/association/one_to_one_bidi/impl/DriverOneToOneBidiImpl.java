package com.genia.toolbox.model.association.one_to_one_bidi.impl;

/**
 * implementation of {@link com.genia.toolbox.model.association.one_to_one_bidi.DriverOneToOneBidi}.<p>WARNING: This file is auto-generated. All modifications will be lost. All modifications must
 * be done on the UML model.</p>
 */
public class DriverOneToOneBidiImpl
  implements com.genia.toolbox.model.association.one_to_one_bidi.DriverOneToOneBidi
{

  /**
   * car associated.
   */
  private com.genia.toolbox.model.association.one_to_one_bidi.CarOneToOneBidi carInternal = null;

  /**
   * the object identifier.
   */
  private Long identifier = null;

  /**
   * getter for the identifier property.
   *
   * @return the identifier property.
   */
  public Long getIdentifier()
  {
    return identifier;
  }



  /**
   * setter for the identifier property.
   *
   * @param identifier the identifier property.
   */
  public void setIdentifier(final Long identifier)
  {
    this.identifier = identifier;
  }



  /**
   * getter for the carInternal property.
   *
   * @return the carInternal property.
   */
  public com.genia.toolbox.model.association.one_to_one_bidi.CarOneToOneBidi getCarInternal()
  {
    return carInternal;
  }



  /**
   * setter for the carInternal property.
   *
   * @param carInternal the carInternal property.
   */
  public void setCarInternal(final com.genia.toolbox.model.association.one_to_one_bidi.CarOneToOneBidi carInternal)
  {
    this.carInternal = carInternal;
  }



  /**
   * getter for the car property.
   *
   * @return the car property.
   */
  public com.genia.toolbox.model.association.one_to_one_bidi.CarOneToOneBidi getCar()
  {
    return getCarInternal();
  }



  /**
   * setter for the car property.
   *
   * @param car the car property.
   */
  public void setCar(final com.genia.toolbox.model.association.one_to_one_bidi.CarOneToOneBidi car)
  {
    if(getCarInternal() == car)
    {
      return;
    }

    if(getCarInternal() != null)
    {
      getCarInternal()
        .setDriver(null);
    }

    if(car != null)
    {
      car.setDriver(this);
    }
  }



}
