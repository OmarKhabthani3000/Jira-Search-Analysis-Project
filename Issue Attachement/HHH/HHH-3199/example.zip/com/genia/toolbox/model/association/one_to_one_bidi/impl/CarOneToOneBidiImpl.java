package com.genia.toolbox.model.association.one_to_one_bidi.impl;

/**
 * implementation of {@link com.genia.toolbox.model.association.one_to_one_bidi.CarOneToOneBidi}.<p>WARNING: This file is auto-generated. All modifications will be lost. All modifications must be
 * done on the UML model.</p>
 */
public class CarOneToOneBidiImpl
  implements com.genia.toolbox.model.association.one_to_one_bidi.CarOneToOneBidi
{
  /**
   * driver associated.
   */
  private com.genia.toolbox.model.association.one_to_one_bidi.DriverOneToOneBidi driverInternal = null;

  /**
   * the identifier of the car.
   */
  private Long identifier = null;

  /**
   * getter for the identifier property.
   *
   * @return the identifier property.
   */
  public Long getIdentifier()
  {
    return identifier;
  }



  /**
   * setter for the identifier property.
   *
   * @param identifier the identifier property.
   */
  public void setIdentifier(final Long identifier)
  {
    this.identifier = identifier;
  }



  /**
   * getter for the driverInternal property.
   *
   * @return the driverInternal property.
   */
  public com.genia.toolbox.model.association.one_to_one_bidi.DriverOneToOneBidi getDriverInternal()
  {
    return driverInternal;
  }



  /**
   * setter for the driverInternal property.
   *
   * @param driverInternal the driverInternal property.
   */
  public void setDriverInternal(final com.genia.toolbox.model.association.one_to_one_bidi.DriverOneToOneBidi driverInternal)
  {
    this.driverInternal = driverInternal;
  }



  /**
   * getter for the driver property.
   *
   * @return the driver property.
   */
  public com.genia.toolbox.model.association.one_to_one_bidi.DriverOneToOneBidi getDriver()
  {
    return getDriverInternal();
  }



  /**
   * setter for the driver property.
   *
   * @param driver the driver property.
   */
  public void setDriver(final com.genia.toolbox.model.association.one_to_one_bidi.DriverOneToOneBidi driver)
  {
    if(getDriverInternal() ==  driver)
    {
      return;
    }

    if(getDriverInternal() != null)
    {
      getDriverInternal()
        .setCarInternal(null);
    }

    setDriverInternal(driver);

    if(driver != null)
    {
      driver.setCarInternal(this);
    }
  }




}
