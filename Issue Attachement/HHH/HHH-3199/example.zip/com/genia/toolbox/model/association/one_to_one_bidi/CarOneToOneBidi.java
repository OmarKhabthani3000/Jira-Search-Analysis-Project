package com.genia.toolbox.model.association.one_to_one_bidi;

/**
 * test class for association.
 * <p>WARNING: This file is auto-generated. All modifications will be lost. All modifications must be done on the UML model.
 */
public interface CarOneToOneBidi
{


  /**
   * getter for the identifier property.
   *
   * @return the identifier property.
   */
  public Long getIdentifier();



  /**
   * setter for the identifier property.
   *
   * @param identifier the identifier property.
   */
  public void setIdentifier(final Long identifier);



  /**
   * getter for the driverInternal property.
   *
   * @return the driverInternal property.
   */
  public com.genia.toolbox.model.association.one_to_one_bidi.DriverOneToOneBidi getDriverInternal();



  /**
   * setter for the driverInternal property.
   *
   * @param driverInternal the driverInternal property.
   */
  public void setDriverInternal(final com.genia.toolbox.model.association.one_to_one_bidi.DriverOneToOneBidi driverInternal);



  /**
   * getter for the driver property.
   *
   * @return the driver property.
   */
  public com.genia.toolbox.model.association.one_to_one_bidi.DriverOneToOneBidi getDriver();



  /**
   * setter for the driver property.
   *
   * @param driver the driver property.
   */
  public void setDriver(final com.genia.toolbox.model.association.one_to_one_bidi.DriverOneToOneBidi driver);
}
