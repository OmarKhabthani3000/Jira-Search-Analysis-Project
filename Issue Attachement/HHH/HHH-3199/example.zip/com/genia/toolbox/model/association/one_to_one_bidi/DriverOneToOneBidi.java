package com.genia.toolbox.model.association.one_to_one_bidi;

/**
 * test class for association one to tone bidi.
 * <p>WARNING: This file is auto-generated. All modifications will be lost. All modifications must be done on the UML model.
 */
public interface DriverOneToOneBidi
{
  /**
   * getter for the identifier property.
   *
   * @return the identifier property.
   */
  public Long getIdentifier();



  /**
   * setter for the identifier property.
   *
   * @param identifier the identifier property.
   */
  public void setIdentifier(final Long identifier);



  /**
   * getter for the carInternal property.
   *
   * @return the carInternal property.
   */
  public com.genia.toolbox.model.association.one_to_one_bidi.CarOneToOneBidi getCarInternal();



  /**
   * setter for the carInternal property.
   *
   * @param carInternal the carInternal property.
   */
  public void setCarInternal(final com.genia.toolbox.model.association.one_to_one_bidi.CarOneToOneBidi carInternal);



  /**
   * getter for the car property.
   *
   * @return the car property.
   */
  public com.genia.toolbox.model.association.one_to_one_bidi.CarOneToOneBidi getCar();



  /**
   * setter for the car property.
   *
   * @param car the car property.
   */
  public void setCar(final com.genia.toolbox.model.association.one_to_one_bidi.CarOneToOneBidi car);
}
