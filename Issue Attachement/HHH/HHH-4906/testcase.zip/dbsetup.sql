create user hibernatetest identified by hibernatetest;
grant connect, resource to hibernatetest;

create table CHILD
(
  PK        NUMBER(15),
  CID       NUMBER(15),
  FK_PARENT NUMBER(15)
);

create table PARENT
(
  PK  NUMBER(15),
  CID NUMBER(15)
);

insert into parent values (1,1003);
insert into child values (1,1002,1);
insert into child values (2,1002,1);
insert into child values (3,1002,1);

commit;