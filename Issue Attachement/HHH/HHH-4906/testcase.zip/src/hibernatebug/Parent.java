package hibernatebug;

import java.util.List;

public class Parent {
	
	private Long pk;
	private Integer cid;
	private List<Child> fieldChildren;

	public Long getPK() {
		return pk;
	}

	public void setPK(Long pk) {
		this.pk = pk;
	}

	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public List<Child> getChildren() {
		return fieldChildren;
	}

	public void setChildren(List<Child> fieldChildren) {
		this.fieldChildren = fieldChildren;
	}

}
