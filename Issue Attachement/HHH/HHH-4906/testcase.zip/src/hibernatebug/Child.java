package hibernatebug;

public class Child {

	private Long pk;
	private Integer cid;

	public Long getPK() {
		return pk;
	}

	public void setPK(Long pk) {
		this.pk = pk;
	}

	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}
	
}
