package hibernatebug;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;

public class Test {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure(Test.class.getClassLoader().getResource("hibernatebug/cfg.xml"));
		cfg.addClass(Parent.class);
		cfg.addClass(Child.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		
		// test1: left_joined child with restriction
		Parent parent = (Parent) s.createCriteria(Parent.class)
			.createCriteria("children", Criteria.LEFT_JOIN)
			.add(Restrictions.eq("PK", 2L))
			.uniqueResult();
		
		System.out.println("size of 'children' collection: " + parent.getChildren().size() + " (expected 3)");
		
		// test2: selecting the parent only
		Parent parent2 = (Parent) s.createCriteria(Parent.class)
			.uniqueResult();
		
		System.out.println("size of 'children' collection: " + parent2.getChildren().size() + " (expected 3)");
		
		// test3: selecting the parent only after evicting collection cache
		s.evict(parent2);
		Parent parent3 = (Parent) s.createCriteria(Parent.class)
			.uniqueResult();
		parent3.getChildren().get(0); // called for side-effect of loading the collection
		
		System.out.println("size of 'children' collection: " + parent3.getChildren().size() + " (expected 3)");
		
		// in another session
	}
	
}
