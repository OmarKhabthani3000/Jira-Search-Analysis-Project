package hibernate;

import java.util.List;

public class B
{
  protected long id;
  protected int b;
  protected List list;
}
