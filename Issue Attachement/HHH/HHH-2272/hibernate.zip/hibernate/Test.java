package hibernate;

import java.util.ArrayList;
import java.util.HashMap;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test
{
  public static void main (String[] args)
  {
    try
    {
      Configuration config = new Configuration();
      config.configure("hibernate/hibernate.cfg.xml");
      SessionFactory factory = config.buildSessionFactory();
      Session session = factory.openSession();
      Transaction tx = session.beginTransaction();
      
      A a = new A();
      a.a = -1;
      a.map = new HashMap();
      for (int i = 0; i < 10000; i++)
      {
        B b = new B();
        b.b = i;
        b.list = new ArrayList();
        for (int j = 0; j < 10; j++)
        {
          C c = new C();
          c.c = j * 1000000;
          b.list.add(c);
        }
        a.map.put(new Integer(i), b);
      }
      long time = System.currentTimeMillis();
      session.save(a);
      System.out.println("Save took " + ((System.currentTimeMillis() - time) / 60000) + " minutes");
      
      tx.commit();
      session.close();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}
