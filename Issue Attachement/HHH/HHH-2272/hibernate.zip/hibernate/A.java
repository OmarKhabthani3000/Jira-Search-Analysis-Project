package hibernate;

import java.util.Map;

public class A
{
  protected long id;
  protected int a;
  protected Map map;
}
