package hibernate;

import java.util.ArrayList;
import java.util.HashMap;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class SavePerfTest {

    /**
     * Make 5510 objects on database
     */
    public void testSaveSession() {
        Session session = initSession();
        Transaction tx = session.beginTransaction();
        long timeTotal = System.currentTimeMillis();
        for (int x = 0; x < 10; x++) {
            makeObjects(session);
        }
        session.flush();
        tx.commit();
        session.close();
        System.out.println("Total took " + ((System.currentTimeMillis() - timeTotal)) + " ms");
    }
    
    private Session initSession() {
        Configuration config = new Configuration();
        config.configure("hibernate/hibernate.cfg.xml");
        SessionFactory factory = config.buildSessionFactory();
        return factory.openSession();
    }

    /**
     * Make 551 new objects
     * 
     * @param session
     */
    private void makeObjects(Session session) {
        A a = new A();
        a.a = -1;
        a.map = new HashMap();
        for (int i = 0; i < 50; i++) {
            B b = new B();
            b.b = i;
            b.list = new ArrayList();
            a.map.put(new Integer(i), b);
            for (int j = 0; j < 10; j++) {
                C c = new C();
                c.c = j * 1000000;
                b.list.add(c);
            }
        }
        long time = System.currentTimeMillis();
        session.save(a);
        System.out.println("Save took " + ((System.currentTimeMillis() - time)) + " ms");
        time = System.currentTimeMillis();
    }

    public static void main(String[] args) {
        try {
            SavePerfTest savePerfTest = new SavePerfTest();
            savePerfTest.testSaveSession();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
