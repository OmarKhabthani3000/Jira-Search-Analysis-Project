package hibernate;

public class C
{
  protected long id;
  protected int c;
}
