package org.example;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.HashSet;
import java.util.List;

public class HibernateTest {
    private static SessionFactory sessionFactory = null;

    @BeforeClass
    public static void setUp() throws Exception
    {
        sessionFactory = new Configuration().configure().buildSessionFactory();

    }

    @AfterClass
    public static void tearDown() throws Exception
    {
        sessionFactory.close();
    }

    @Test
    public void alles(){
        Portalnutzer p1=new Portalnutzer();
        p1.setTitel("benutzer");

        Nachricht n1 = new Nachricht();
        n1.setTitel("eine nachricht");
        n1.setSender(p1);
        HashSet<Nachricht> nset=new HashSet<>();
        nset.add(n1);
        p1.setGesendeteNachrichten(nset);

        Session session = sessionFactory.openSession();
        session.beginTransaction();

        session.save( p1 );
        session.save( n1 );

        session.getTransaction().commit();
        session.beginTransaction();
        Query query = session.createQuery("update Nachricht set titel='abc' where sender.id=:pnutzerid ");
        query.setParameter("pnutzerid", p1.getId());
        int i = query.executeUpdate();
        System.out.println(i);

        session.flush();
        session.getTransaction().commit();
        session.close();


        Session session2 = sessionFactory.openSession();
        session2.beginTransaction();
        Query from_nachricht = session2.createQuery("from Nachricht");
        List list = from_nachricht.list();
        System.out.println(list);
        session2.getTransaction().commit();
        session2.close();
        System.out.println( "testSaveOperation ends ......." );



    }
}
