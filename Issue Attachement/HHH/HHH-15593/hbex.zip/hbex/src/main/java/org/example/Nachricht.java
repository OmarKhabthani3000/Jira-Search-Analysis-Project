package org.example;

import java.util.Objects;

public class Nachricht {

    private Long id;

    private String titel;

    private Portalnutzer sender;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitel() {
        return titel;
    }

    public void setTitel(String titel) {
        this.titel = titel;
    }

    public Portalnutzer getSender() {
        return sender;
    }

    public void setSender(Portalnutzer sender) {
        this.sender = sender;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Nachricht nachricht = (Nachricht) o;
        return Objects.equals(id, nachricht.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
