package querycache.bug;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

public class QueryCacheBug {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		try {
			// 1st Query, not in the cache
			Query query = session.createQuery("from User where id = :id");
			query.setCacheable(true);
		    query.setParameter("id", 1);
		    query.uniqueResult();
			
			// 2nd Query, hit the cache
			query = session.createQuery("from User where id = :id");
			query.setCacheable(true);
		    query.setParameter("id", 1);
		    query.uniqueResult();
			
			// Insert new object
		    User user = new User();
		    user.setUserName("userName");
		    session.beginTransaction();
		    session.save(user);
		    session.getTransaction().commit();
			
			// 3rd Query, cache is not up-to-date, results should be re-cached
			query = session.createQuery("from User where id = :id");
			query.setCacheable(true);
		    query.setParameter("id", 1);
		    query.uniqueResult();
			
			// 4rd Query, cache is still reported not up-to-date
			query = session.createQuery("from User where id = :id");
			query.setCacheable(true);
		    query.setParameter("id", 1);
		    query.uniqueResult();
		}
		finally {
			session.close();
		}
	}

}
