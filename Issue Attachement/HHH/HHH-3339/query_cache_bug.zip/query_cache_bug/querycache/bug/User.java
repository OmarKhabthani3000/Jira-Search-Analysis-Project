package querycache.bug;

public class User {
	Integer id;
	String userName;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String name) {
		this.userName = userName;
	}
	public User() {
		super();
	}
}
