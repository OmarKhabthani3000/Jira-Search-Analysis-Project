package jpa2;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNot.not;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertThat;

public class DeptProjTest {

    private static EntityManagerFactory factory;

    private EntityManager entityManager;
    private EntityTransaction transaction;

    @BeforeClass
    public static void setUpClass() {
        factory = Persistence.createEntityManagerFactory("testPersistenceUnit");
    }

    @Before
    public void setUp() {
        entityManager = factory.createEntityManager();
        transaction = entityManager.getTransaction();
        transaction.begin();
        transaction.setRollbackOnly();
    }

    @After
    public void tearDown() {
        transaction.rollback();
    }

    @Test
    public void test1() {
        final Department d1 = new Department(new DeptId(1, 44));
        final Project p1 = new Project(new ProjectId(d1.getId(), "proj1"));
        final Project p2 = new Project(new ProjectId(d1.getId(), "proj2"));

        d1.addProject(p1);
        d1.addProject(p2);

        entityManager.persist(d1);
        entityManager.persist(p1);
        entityManager.persist(p2);

        entityManager.flush();
        entityManager.clear();

        final List<Department> found = entityManager.createQuery(
                "select d from Department d where id = :deptId",
                Department.class)
                .setParameter("deptId", d1.getId())
                .getResultList();

        assertThat(found, is(not(nullValue())));
        assertThat(found.size(), is(1));
        assertThat(found.get(0).getProjects(), is(not(nullValue())));
        assertThat(found.get(0).getProjects().size(), is(2));

        for (final Project p : found.get(0).getProjects()) {
            assertThat(p.getId().getDept().getCountry(),
                    is(d1.getId().getCountry()));
            assertThat(p.getId().getDept().getNumber(),
                    is(d1.getId().getNumber()));
        }
    }
}
