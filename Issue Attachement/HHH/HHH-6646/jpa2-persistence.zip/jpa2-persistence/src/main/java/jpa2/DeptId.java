package jpa2;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import java.io.Serializable;

@Embeddable
public class DeptId implements Serializable {

    @Column(name = "CTRY")
    private int country;

    @Column(name = "NUM")
    private int number;

    public DeptId() {
    }

    public DeptId(final int country, final int number) {
        this.country = country;
        this.number = number;
    }

    public int getCountry() {
        return country;
    }

    public int getNumber() {
        return number;
    }

    public void setCountry(final int country) {
        this.country = country;
    }

    public void setNumber(final int number) {
        this.number = number;
    }
}
