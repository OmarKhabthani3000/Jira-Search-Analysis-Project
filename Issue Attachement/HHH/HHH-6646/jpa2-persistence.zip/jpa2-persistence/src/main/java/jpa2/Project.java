package jpa2;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

@Entity
public class Project {

    @MapsId("dept")
    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "DEPT_NUM", referencedColumnName = "NUM",
                    updatable = false, insertable = false),
            @JoinColumn(name = "DEPT_CTRY", referencedColumnName = "CTRY",
                    updatable = false, insertable = false)
    })
    private Department department;

    @EmbeddedId
    private ProjectId id;

    public Project() {
    }

    public Project(final ProjectId id) {
        this.id = id;
    }

    public Department getDepartment() {
        return department;
    }

    public ProjectId getId() {
        return id;
    }

    public void setDepartment(final Department department) {
        this.department = department;
    }

    public void setId(final ProjectId id) {
        this.id = id;
    }
}
