package jpa2;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Department {

    @EmbeddedId
    private DeptId id;

    @OneToMany(mappedBy = "department")
    private List<Project> projects = new ArrayList<Project>();

    public Department() {
    }

    public Department(final DeptId id) {
        this.id = id;
    }

    public DeptId getId() {
        return id;
    }

    public List<Project> getProjects() {
        return projects;
    }

    public void setId(final DeptId id) {
        this.id = id;
    }

    public void setProjects(final List<Project> projects) {
        this.projects = projects;
    }

    public void addProject(final Project project) {
        projects.add(project);
        project.setDepartment(this);
    }

    public void removeProject(final Project project) {
        if (projects.remove(project)) {
            project.setDepartment(null);
        }
    }
}
