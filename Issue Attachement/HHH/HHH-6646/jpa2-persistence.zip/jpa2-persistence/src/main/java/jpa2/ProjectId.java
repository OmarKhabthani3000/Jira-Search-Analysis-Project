package jpa2;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;

import java.io.Serializable;

@Embeddable
public class ProjectId implements Serializable {

    @Embedded
    private DeptId dept;

    @Column(name = "P_NAME")
    private String name;

    public ProjectId() {
    }

    public ProjectId(final DeptId dept, final String name) {
        this.dept = dept;
        this.name = name;
    }

    public DeptId getDept() {
        return dept;
    }

    public String getName() {
        return name;
    }

    public void setDept(final DeptId dept) {
        this.dept = dept;
    }

    public void setName(final String name) {
        this.name = name;
    }
}
