Karol.Bienkowski@syncron.com 2009-09-24

1. Open in Eclipse
2. Add stardard Hibernate and H2 jars the classpath
3. Execute hhh4459.HHH4459Test with JUnit runner