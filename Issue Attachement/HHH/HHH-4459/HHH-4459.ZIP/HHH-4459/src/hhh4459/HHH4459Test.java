package hhh4459;

import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Tests http://opensource.atlassian.com/projects/hibernate/browse/HHH-xxxx
 * 
 * @author karol.bienkowski@syncron.com on 23 Sep 2009
 */
public class HHH4459Test {

	private static final CompositeKey PK = new CompositeKey(1, 2);

	private EntityManager em;

	@Before
	public void before() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("testH2");
		em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(new EntityWithCompositeKey(PK));
		em.flush();
	}

	@After
	public void after() {
		em.getTransaction().rollback();
		em.close();
	}

	// this test fails on 3.3.2.GA (but is OK on 3.3.1.GA)
	@Test
	public void testGetByCompositeId() {
		Query query = em.createQuery("FROM EntityWithCompositeKey e WHERE e.pk = :pk");
		query.setHint("org.hibernate.cacheable", true);
		query.setParameter("pk", PK);
		assertEquals(1, query.getResultList().size());
	}

	// this test passes as there is no caching
	@Test
	public void testGetByCompositeIdNoCache() {
		Query query = em.createQuery("FROM EntityWithCompositeKey e WHERE e.pk = :pk");
		query.setParameter("pk", PK);
		assertEquals(1, query.getResultList().size());
	}

	// this test passes as the comparison is performed on the whole entity
	@Test
	public void testGetByEntityIself() {
		Query query = em.createQuery("FROM EntityWithCompositeKey e WHERE e = :ent");
		query.setParameter("ent", new EntityWithCompositeKey(PK));
		assertEquals(1, query.getResultList().size());
	}

}
