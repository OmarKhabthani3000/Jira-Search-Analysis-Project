package hibe;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "Employee", uniqueConstraints = { @UniqueConstraint(columnNames = "ID"),
        @UniqueConstraint(columnNames = "EMAIL") })
public class EmployeeEntity implements Serializable {

    private static final long serialVersionUID = -2946504889227038261L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private Integer           employeeId;

    @Column(name = "EMAIL", unique = true, nullable = false, length = 100)
    private String            email;


    @OneToMany(targetEntity = LinkEntity.class, mappedBy= "employee")
    final Set<LinkEntity> folderLink = new HashSet<>();

    public Collection<LinkEntity> getFolderLink(){
        return folderLink;
    }

    public void setFolderLink(Collection<LinkEntity> folderLink){
        final HashSet<LinkEntity> changed = new HashSet<>(folderLink);
        changed.removeAll(this.folderLink);
        changed.forEach(added -> added.setEmployee(this));
        changed.clear();
        changed.addAll(this.folderLink);
        changed.removeAll(folderLink);
        changed.forEach(removed -> removed.setEmployee(null));
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}