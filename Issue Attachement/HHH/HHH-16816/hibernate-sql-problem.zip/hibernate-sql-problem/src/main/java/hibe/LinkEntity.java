package hibe;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.OptimisticLockType;
import org.hibernate.annotations.OptimisticLocking;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity @OptimisticLocking(type = OptimisticLockType.DIRTY) @DynamicUpdate
@Table(name = "Link")
public class LinkEntity {

    @Id
    @Column(name = "EMPLOYEE_ID")
    private Integer employeeId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "EMPLOYEE_ID", insertable = false, updatable = false)
    EmployeeEntity  employee;

    public EmployeeEntity getEmployee(){return employee;}
    public void setEmployee(EmployeeEntity realFolder){
        this.employee = realFolder;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }
    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

}
