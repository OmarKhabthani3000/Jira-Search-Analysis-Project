package hibe;

import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.junit.Test;

public class HibernateTest {

	@Test
	public void testMain() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();

		EmployeeEntity emp = new EmployeeEntity();
		emp.setEmail("demo-user@mail.com");
		session.save(emp);

		LinkEntity linkEntity = new LinkEntity();
//		linkEntity.setEmployee(emp);
		linkEntity.setEmployeeId(emp.getEmployeeId());
		session.save(linkEntity);
		Set<LinkEntity> link = Set.of(linkEntity);
		emp.setFolderLink(link);
		session.save(emp);

		emp = new EmployeeEntity();
		emp.setEmail("demo-user2@mail.com");
		session.save(emp);

		session.getTransaction().commit();
		
		session.beginTransaction();
		// get all employees
		List<EmployeeEntity> all = session.createQuery("FROM EmployeeEntity", EmployeeEntity.class).list();
		for (EmployeeEntity e : all) {
			String email = e.getEmail();
			System.out.println(email);
			// remove first employee
			if ("demo-user@mail.com".equals(email)) {
				List<LinkEntity> links = session.createQuery("FROM LinkEntity", LinkEntity.class).list();
				for (LinkEntity l : links) {
					if (l.getEmployeeId().equals(e.getEmployeeId())) {
						System.out.println("will delete links first: " + l);
						session.remove(l);
					}
				}
				session.remove(e);
			}
		}

		session.getTransaction().commit();
		
		// get all employees
		all = session.createQuery("FROM EmployeeEntity", EmployeeEntity.class).list();
		for (EmployeeEntity e : all) {
			System.out.println(e.getEmail());
		}
		
		HibernateUtil.shutdown();
	}
}