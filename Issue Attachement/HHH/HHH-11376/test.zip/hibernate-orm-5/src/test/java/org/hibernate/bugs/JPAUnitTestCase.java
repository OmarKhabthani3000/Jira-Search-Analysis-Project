package org.hibernate.bugs;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.LockModeType;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Root;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void selectForUpdateTest() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
            selectForUpdate(entityManager, 1L);
		entityManager.getTransaction().commit();
		entityManager.close();
	}

    private Person selectForUpdate(EntityManager em, Long id) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Person> criteria = builder.createQuery(Person.class);
		Root<Person> personRoot = criteria.from(Person.class);
		ParameterExpression<Long> personIdParameter = builder.parameter(Long.class);

		// Eagerly fetch the parent
		personRoot.fetch("parent", JoinType.LEFT);

		criteria
			.select(personRoot)
			.where(builder.equal(personRoot.get("id"), personIdParameter));

		List<Person> persons = em.createQuery(criteria)
			.setParameter(personIdParameter, id)
			.setLockMode(LockModeType.PESSIMISTIC_WRITE)
			.getResultList();

		return persons.isEmpty() ? null : persons.get(0);
	}
}
