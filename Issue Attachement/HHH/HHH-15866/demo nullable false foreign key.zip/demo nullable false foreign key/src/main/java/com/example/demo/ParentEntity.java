package com.example.demo;

import jakarta.persistence.CascadeType;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Table(name = "parent_entity")
@NoArgsConstructor
@Getter
class ParentEntity {
    @EmbeddedId
    private ParentEntityId id;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "parent_entity_id", referencedColumnName = "id", nullable = false)
    private List<ChildEntity> childEntities;

    ParentEntity(List<ChildEntity> childEntities) {
        this.childEntities = childEntities;
    }
}
