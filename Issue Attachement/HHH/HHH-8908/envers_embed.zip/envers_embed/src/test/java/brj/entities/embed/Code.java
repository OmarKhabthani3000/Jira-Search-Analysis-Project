package brj.entities.embed;

import javax.persistence.Embeddable;

@Embeddable
public class Code extends AbstractCode {
 
    private String codeArt;
    
    public Code(int code, String codeArt) {
        super(code);
        this.codeArt = codeArt;
    }

    // Needed for @Embeddable
    protected Code() {
        this (UNDEFINED, null);
    }

    @Override
    public String getCodeart() {
        return codeArt;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((codeArt == null) ? 0 : codeArt.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Code other = (Code) obj;
        if (codeArt == null) {
            if (other.codeArt != null)
                return false;
        } else if (!codeArt.equals(other.codeArt))
            return false;
        return true;
    }
       
}
