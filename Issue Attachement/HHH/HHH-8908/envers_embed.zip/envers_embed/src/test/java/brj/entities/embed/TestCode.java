package brj.entities.embed;

import javax.persistence.Embeddable;
import javax.persistence.Transient;

@Embeddable
public class TestCode extends AbstractCode {

    public static final int _TEST = 1;
   
    public static final TestCode TEST = new TestCode(_TEST);
 
    public TestCode(int code) {
        super(code);
    }

    // Needed for @Embeddable
    protected TestCode() {
        super(UNDEFINED);
    }

    @Override
    @Transient
    public String getCodeart() {
        return "TestCode";
    }
}
