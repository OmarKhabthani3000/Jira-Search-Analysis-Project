package brj.entities.embed;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
@Access(AccessType.FIELD)
public abstract class AbstractCode {

    /** Initial Value */
    protected static final int UNDEFINED = -1;

    private int code = UNDEFINED;


    protected AbstractCode() {
        this(UNDEFINED);
    }

    /**
     * Constructor with code
     */
    public AbstractCode(int code) {
        this.code = code;
    }

    public abstract String getCodeart();

    public int getCode() {
        return code;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + code;
        return result;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AbstractCode other = (AbstractCode) obj;
        if (code != other.code)
            return false;
        return true;
    }
}
