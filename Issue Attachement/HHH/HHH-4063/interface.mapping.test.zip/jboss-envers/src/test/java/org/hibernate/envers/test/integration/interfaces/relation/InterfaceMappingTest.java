package org.hibernate.envers.test.integration.interfaces.relation;

import javax.persistence.PersistenceException;

import junit.framework.TestCase;

import org.hibernate.ejb.Ejb3Configuration;
import org.hibernate.envers.event.AuditEventListener;
import org.hibernate.event.PostCollectionRecreateEventListener;
import org.hibernate.event.PostDeleteEventListener;
import org.hibernate.event.PostInsertEventListener;
import org.hibernate.event.PostUpdateEventListener;
import org.hibernate.event.PreCollectionRemoveEventListener;
import org.hibernate.event.PreCollectionUpdateEventListener;

public class InterfaceMappingTest extends TestCase {

  private void initListeners(Ejb3Configuration cfg) {
    AuditEventListener listener = new AuditEventListener();
    cfg.getEventListeners().setPostInsertEventListeners(
        new PostInsertEventListener[] {
          listener
        });
    cfg.getEventListeners().setPostUpdateEventListeners(
        new PostUpdateEventListener[] {
          listener
        });
    cfg.getEventListeners().setPostDeleteEventListeners(
        new PostDeleteEventListener[] {
          listener
        });
    cfg.getEventListeners().setPreCollectionUpdateEventListeners(
        new PreCollectionUpdateEventListener[] {
          listener
        });
    cfg.getEventListeners().setPreCollectionRemoveEventListeners(
        new PreCollectionRemoveEventListener[] {
          listener
        });
    cfg.getEventListeners().setPostCollectionRecreateEventListeners(
        new PostCollectionRecreateEventListener[] {
          listener
        });
  }

  public InterfaceMappingTest(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    super.setUp();
  }

  public void testConfigureString() throws Exception {
    Ejb3Configuration cfg = new Ejb3Configuration();
    this.initListeners(cfg);
    try {
      cfg.configure("hibernate.test.cfg.xml");
      cfg.addResource("interfacemapping.hbm.xml");
      cfg.buildEntityManagerFactory();
    } catch (PersistenceException e) {
      e.printStackTrace();
      fail("It should be possible to audit an interface, Hibernate supports interface mapping");
    }
  }

}
