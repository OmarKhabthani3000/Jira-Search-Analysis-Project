package org.hibernate.envers.test.integration.interfaces.relation;

import org.hibernate.envers.Audited;

@Audited
public interface MyInterface {

  void setId(long id);

  long getId();

  String getData();

  void setData(String data);
}
