package hibernatetest.a80980;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.io.File;

public class HibernateUtil
{
    private static SessionFactory sessionFactory;

    private static final Configuration configuration = new Configuration();

    static {
        try {
            // Create the SessionFactory from hibernate.cfg.xml
            
            File cfg = new File("hibernatetest\\a80980\\hibernate.cfg.xml");
            configuration.configure(cfg);
        } catch (Throwable ex) {
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

   public static SessionFactory getSessionFactory() {
       if(sessionFactory == null)
           sessionFactory = configuration.buildSessionFactory();
       return sessionFactory;
   }

    public static Configuration getConfiguration()
    {
        return configuration;
    }
}
