package hibernatetest.a80980;

import java.util.Date;

public class Audit
{
    private int auditId;
    private Date auditDateTime;
    private String template;
    private String detail;
    private String ipAddress;

    public int getAuditId()
    {
        return auditId;
    }

    public void setAuditId(int auditId)
    {
        this.auditId = auditId;
    }

    public Date getAuditDateTime()
    {
        return auditDateTime;
    }

    public void setAuditDateTime(Date auditDateTime)
    {
        this.auditDateTime = auditDateTime;
    }

    public String getTemplate()
    {
        return template;
    }

    public void setTemplate(String template)
    {
        this.template = template;
    }

    public String getDetail()
    {
        return detail;
    }

    public void setDetail(String detail)
    {
        this.detail = detail;
    }

    public String getIpAddress()
    {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress)
    {
        this.ipAddress = ipAddress;
    }
}
