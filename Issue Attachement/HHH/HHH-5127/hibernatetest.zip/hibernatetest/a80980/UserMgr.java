
package hibernatetest.a80980;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.event.EventListeners;
import org.hibernate.event.PostInsertEventListener;
import org.hibernate.event.PostInsertEvent;

import java.util.Date;

public class UserMgr
{
    public static void main(String[] args) throws Exception
    {
        Configuration configuration = HibernateUtil.getConfiguration();
        setupListener(configuration);
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

        Session session = sessionFactory.getCurrentSession();
        session.beginTransaction();
        User user = new User();
        user.setUsername("Andrews");
        user.setPassword("pass");
        session.save(user);
        session.flush();
        session.getTransaction().commit();

        sessionFactory.close();
    }

    private static void setupListener(Configuration configuration)
    {
        EventListeners eventListeners = configuration.getEventListeners();
        PostInsertEventListener myListener = new PostInsertEventListener()
        {
            public void onPostInsert(PostInsertEvent event)
            {
                //todo
                SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
                Session session = sessionFactory.getCurrentSession();
                Audit audit = new Audit();
                audit.setAuditDateTime(new Date());
                audit.setDetail("Some audit");
                audit.setTemplate("what template");
                session.save(audit);
                session.flush();
            }
        };

        PostInsertEventListener[] oldListeners = eventListeners.getPostInsertEventListeners();
        PostInsertEventListener[] newListeners = new PostInsertEventListener[oldListeners.length + 1];
        System.arraycopy(oldListeners, 0, newListeners, 0, oldListeners.length);
        newListeners[oldListeners.length] = myListener;
        eventListeners.setPostInsertEventListeners(newListeners);
    }
}
