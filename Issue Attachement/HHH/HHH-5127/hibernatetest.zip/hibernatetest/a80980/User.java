
package hibernatetest.a80980;

public class User
{
    private String username;
    private String password;
    private boolean deleted;

    public String getUsername()
    {
        return username;
    }

    public void setUsername(String usernamr)
    {
        this.username = usernamr;
    }

    public String getPassword()
    {
        return password;
    }

    public void setPassword(String password)
    {
        this.password = password;
    }

    public boolean isDeleted()
    {
        return deleted;
    }

    public void setDeleted(boolean deleted)
    {
        this.deleted = deleted;
    }
}
