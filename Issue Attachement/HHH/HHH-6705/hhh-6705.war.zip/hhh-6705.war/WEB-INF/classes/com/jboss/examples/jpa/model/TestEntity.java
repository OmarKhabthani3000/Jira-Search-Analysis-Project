/**
 * 
 */
package com.jboss.examples.jpa.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author bmaxwell
 *
 */
@Entity
@Table(name="TestEntity")
public class TestEntity implements Serializable 
{

	private @Id @GeneratedValue @Column(name="Id") Long id;
	private @Column(name="BoolObject") Boolean boolObject;
	private @Column(name="BoolPrim") boolean boolPrim;
	
	public Long getId() 
	{
		return id;
	}
	public void setId(Long id) 
	{
		this.id = id;
	}


	public Boolean getBoolObject() 
	{
		return boolObject;
	}
	public void setBoolObject(Boolean boolObject) 
	{
		this.boolObject = boolObject;
	}

	public boolean isBoolPrim() 
	{
		return boolPrim;
	}
	public void setBoolPrim(boolean boolPrim) 
	{
		this.boolPrim = boolPrim;
	}

}
