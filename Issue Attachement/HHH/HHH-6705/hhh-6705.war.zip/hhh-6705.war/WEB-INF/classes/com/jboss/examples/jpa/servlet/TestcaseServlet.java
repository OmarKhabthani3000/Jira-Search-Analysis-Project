package com.jboss.examples.jpa.servlet;

import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.ServletConfig;

import com.jboss.examples.jpa.model.TestEntity;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestcaseServlet extends HttpServlet
{
	private Logger log = Logger.getLogger(this.getClass().getName());

  private EntityManagerFactory emf;
  private EntityManager em;

	public void init (ServletConfig config) throws ServletException 
	{
			log.info("init(ServletConfig) - calling doTestcase()");
    	usePersistenceDatasource();
      doTestcase();
  }

   @Override
   public void init() throws ServletException
   {    
      super.init();
      
			log.info("init() - calling doTestcase()");
      doTestcase();
   }

   private void doTestcase()
   {
      TestEntity entity = new TestEntity();
			entity.setBoolObject(new Boolean(true));
			entity.setBoolPrim(true);

      log.info("Trying to addEntity: " + entity);
      addEntity(entity);

      long id = entity.getId();
      log.info("Trying to getEntity: " + id);
      entity = getEntity(id);

      log.info(entity);
   }
   
   private void addEntity ( TestEntity entity )
   {
     em.getTransaction().begin();
     em.persist(entity);
     em.getTransaction().commit();
   }

   private TestEntity getEntity ( Long id )
   {
     return em.find( TestEntity.class, id );
   }

	private void usePersistenceDatasource() 
	{
    EntityManagerFactory programmaticEmf = Persistence.createEntityManagerFactory("hhh-6705");
    this.emf = programmaticEmf;
    this.em = emf.createEntityManager();
  }

	public void close() 
	{
    this.em.close();
    this.emf.close();
  }

}
