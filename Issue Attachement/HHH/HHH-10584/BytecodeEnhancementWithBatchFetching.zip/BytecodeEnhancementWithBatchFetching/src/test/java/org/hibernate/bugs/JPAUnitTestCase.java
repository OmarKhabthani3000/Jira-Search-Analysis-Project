package org.hibernate.bugs;

import java.lang.reflect.Field;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.test.entities.Member;
import com.test.entities.Team;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
		
		/* Loads Test Data*/
		EntityManager em = entityManagerFactory.createEntityManager();
		em.getTransaction().begin();
		for (int i = 0; i < 10; i++) {
			Team team = new Team();
			em.persist(team);
			for (int j = 0; j < 5; j++) {
				Member member = new Member();
				member.setName("Member "+j+" Team "+i);
				member.setTeam(team);
				em.persist(member);
			}
		}
		em.getTransaction().commit();
		em.close();
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager em = entityManagerFactory.createEntityManager();

		List<Team> teams = em.createQuery("from Team").getResultList();
		
		/* Batch fetch members from all teams */
		teams.get(0).getMembers().get(0).getName();
		
		Field f = Team.class.getDeclaredField("members");
		f.setAccessible(true);
		
		/* Should be fetched */
		Assert.assertNotNull(f.get(teams.get(1)));
		
		em.close();
	}
}