package hhh16;

import java.util.HashSet;
import java.util.Set;

public class Order {
  
  private Integer id;
  
  private Integer total;

  private Customer customer;
  
  private Set<OrderItem> items = new HashSet<>();

  public Integer getId() {
    return id;
  }
  
  public void setId(Integer id) {
    this.id = id;
  }

  public Customer getCustomer() {
    return customer;
  }
  
  public void setCustomer(Customer customer) {
    this.customer = customer;
  }
  
  public Set<OrderItem> getItems() {
    return items;
  }
  
  public void setItems(Set<OrderItem> items) {
    this.items = items;
  }
  
  public Integer getTotal() {
    return total;
  }
  
  public void setTotal(Integer total) {
    this.total = total;
  }
  
  @Override
  public String toString() {
    return customer.toString() + " - " + id;
  }
}
