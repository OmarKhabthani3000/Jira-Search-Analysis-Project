package hhh16;

public class OrderItem {

  private Integer id;

  private Order order;
  
  private Integer count = 1;
  
  public Integer getId() {
    return id;
  }
  
  public void setId(Integer id) {
    this.id = id;
  }
  
  public Order getOrder() {
    return order;
  }
  
  public void setOrder(Order order) {
    this.order = order;
  }
  
  public Integer getCount() {
    return count;
  }
  
  public void setCount(Integer count) {
    this.count = count;
  }
}
