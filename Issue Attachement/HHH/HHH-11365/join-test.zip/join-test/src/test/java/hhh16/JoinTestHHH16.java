package hhh16;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Tests joins on unrelated classes using HQL described in HHH-16, HHH-11365 and HHH-10503.
 * 
 * @author Vit Novak
 * @version $Revision$
 */
public class JoinTestHHH16 {
  private static SessionFactory sessionFactory;
  
  @BeforeClass
  public static void setup() {
    sessionFactory = new Configuration().configure().buildSessionFactory();
    
    Session session = sessionFactory.openSession();
    try {
      Customer chris = new Customer();
      chris.setName("Chris");
      chris.setId(1);
      
      Order chrisOrder = new Order();
      chrisOrder.setCustomer(chris);
      chrisOrder.setId(1);
      
      OrderItem tv = new OrderItem();
      tv.setId(1);
      tv.setOrder(chrisOrder);
      
      session.persist(chris);
      session.persist(chrisOrder);
      session.persist(tv);
      
      session.flush();
    } finally {
      session.close();
    }
  }
  
  /**
   * Tests single unrelated join, implemented by HHH-16.
   */
  @Test
  public void testSingleUnrelatedJoin() throws Exception {
    Session session = sessionFactory.openSession();
    try {
      session.createQuery("select c.id, o.id "
              + "from Customer c "
              + "left join Order o on c.id = o.customer.id "
      ).list();
    } finally {
      session.close();
    }
  }
  
  /**
   * Tests two unrelated joins, implemented by HHH-16, also workaround for HHH-11365 and HHH-10503.
   */
  @Test
  public void testDoubleUnrelatedJoin() throws Exception {
    Session session = sessionFactory.openSession();
    try {
      session.createQuery("select c.id, o.id, i.id "
              + "from Customer c "
              + "left join Order o on c.id = o.customer.id "
              + "left join OrderItem i on i.order.id = o.id ").list();
    } finally {
      session.close();
    }
  }
  
  /**
   * Tests mixed joins - unrelated {@code Customer} -> {@code Order} using {@code ON}, second is
   * using assosiation {@code o.items}. This should be fixed by HHH-11365.
   */
  @Test
  public void testMixedExplicitJoin() throws Exception {
    Session session = sessionFactory.openSession();
    try {
      session.createQuery("select c.id, o.id, i.id "
              + "from Customer c "
              + "left join Order o on c.id = o.customer.id "
              + "left join o.items i ").list();
    } finally {
      session.close();
    }
  }
  
  /**
   * Tests mixed join - unrelated join and implicit join by assosiation {@code o.customer}.
   */
  @Test
  public void testMixedImplicitJoin() throws Exception {
    Session session = sessionFactory.openSession();
    try {
      session.createQuery("select o.customer.name, o.id, i.id "
              + "from OrderItem i "
              + "left join Order o on o.id = i.order.id ").list();
    } finally {
      session.close();
    }
  }
  
}
