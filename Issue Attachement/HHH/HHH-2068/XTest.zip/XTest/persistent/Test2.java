// **************************************************************************
/**
 * \file  \brief
 *
 * \author Ale� PROCH�ZKA \author (C) 2006, EXADEV, Pie��any
 *
 * \date 23.8.2006 Description, history :
 *
 * \version 1 vytvorenie
 *
 */
// ****************************************************************************
package persistent;

import java.util.ArrayList;
import java.util.List;

// GEN-BEGIN:CLASS
public class Test2 extends Test
// GEN-END:CLASS
{
    // GEN-BEGIN:ATTRIBS
    // attributes
    private String fieldpokusStr;
    public static final String pokusStr="pokusStr";
    private Double fieldpokusDouble;
    public static final String pokusDouble="pokusDouble";

    // FK associations
    private Test3 fieldtest3;
    public static final String test3="test3";

    // LNK associations
    private List<Test3> fieldtestLnk3 = new ArrayList<Test3>();
    public static final String testLnk3="testLnk3";

    // attributes
    public String getPokusStr() {
        return this.fieldpokusStr;
    }

    public void setPokusStr(String pokusStr) {
        this.fieldpokusStr = pokusStr;
    }

    public Double getPokusDouble() {
        return this.fieldpokusDouble;
    }

    public void setPokusDouble(Double pokusDouble) {
        this.fieldpokusDouble = pokusDouble;
    }

    // FK associations
    public Test3 getTest3() {
        return this.fieldtest3;
    }

    public void setTest3(Test3 test3) {
        this.fieldtest3 = test3;
    }

    public void setFkTest3(Test3 test3) {
        if (this.fieldtest3 != null) {
            if (test3 == null || !test3.equals(this.fieldtest3))
                this.fieldtest3.getTests2().remove(this);
        }
        if (test3 != null && !test3.getTests2().contains(this) )
            test3.getTests2().add(this);
        this.fieldtest3 = test3;
    }


    // LNK associations
    public List<Test3> getTestLnk3() {
        return this.fieldtestLnk3;
    }

    public void setTestLnk3(List<Test3> testLnk3) {
        this.fieldtestLnk3 = testLnk3;
    }

    public void addToTestLnk3(Test3 obj) {
        if (!this.fieldtestLnk3.contains(obj)) {
            this.fieldtestLnk3.add(obj);
        if (!obj.getTestLnk2().contains(this))
            obj.getTestLnk2().add(this);
        }
    }

    public void removeFromTestLnk3(Test3 obj) {
        if (this.fieldtestLnk3.contains(obj)) {
            this.fieldtestLnk3.remove(obj);
            obj.getTestLnk2().remove(this);
        }
    }


    // GEN-END:ATTRIBS

// GEN-BEGIN:END_OF_CLASS Test2
}
// GEN-END:END_OF_CLASS Test2
