// **************************************************************************
/**
 * \file  \brief
 *
 * \author Ale� PROCH�ZKA \author (C) 2006, EXADEV, Pie��any
 *
 * \date 22.8.2006 Description, history :
 *
 * \version 1 vytvorenie
 *
 */
// ****************************************************************************
package persistent;


// GEN-BEGIN:CLASS
public class Test5 extends Test4
// GEN-END:CLASS
{
    // GEN-BEGIN:ATTRIBS

    // attributes
    private java.util.Date fielddateTime;
    public static final String dateTime="dateTime";
    private Boolean fieldboolPokus;
    public static final String boolPokus="boolPokus";

    // attributes
    public java.util.Date getDateTime() {
        return this.fielddateTime;
    }

    public void setDateTime(java.util.Date dateTime) {
        this.fielddateTime = dateTime;
    }

    public Boolean getBoolPokus() {
        return this.fieldboolPokus;
    }

    public void setBoolPokus(Boolean boolPokus) {
        this.fieldboolPokus = boolPokus;
    }

    // GEN-END:ATTRIBS

// GEN-BEGIN:END_OF_CLASS Test5
}
// GEN-END:END_OF_CLASS Test5
