package utils;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

public class KTechnology {
	
	private static Configuration cfg;
	
	private static SessionFactory factory = null;
	
	
	public static void initialize(Configuration cfg) {
		if (cfg == null) 
			throw new NullPointerException();

		KTechnology.cfg = cfg;
		
		cfg.setProperty(Environment.CURRENT_SESSION_CONTEXT_CLASS, "managed");
		//cfg.setProperty(Environment.TRANSACTION_MANAGER_STRATEGY, "org.hibernate.transaction.JBossTransactionManagerLookup");
	}
	
	public static SessionFactory getSessionFactory() {
		if (cfg == null) 
			throw new NullPointerException();
		if (factory == null)
			factory = cfg.buildSessionFactory();
		
		return factory;
		/*
		if (session == null) {
			session = factory.openSession();
		}
		return session;
		*/				
	}
	
	public static Configuration getConfiguration() {
		return cfg;
	}

}
