package testcdi;

public class NotLoggedInException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3747475770973107982L;

	public NotLoggedInException() {
	}
}
