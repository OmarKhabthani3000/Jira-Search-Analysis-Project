package testcdi;

import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;

public class Databases {
	@Produces @PersistenceContext(unitName="UserData")
	@Users EntityManager userDatabaseEntityManager;
	
	/*
	@Produces @PersistenceUnit(unitName="UserData")
	@Users EntityManagerFactory userDatabaseEntityManagerFactory;
	*/
	/*
	@Produces @PersistenceContext(unitName="DocumentData")
	@Documents EntityManager docDatabaseEntityManager;
	*/

}
