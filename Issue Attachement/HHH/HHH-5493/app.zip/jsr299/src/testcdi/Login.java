package testcdi;

import java.io.Serializable;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Parameter;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

@SessionScoped
@Model
public class Login implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject Credentials credentials;
	
	@Inject	@Users EntityManager userDatabase;
	private CriteriaQuery<User> query;
	private Parameter<String> usernameParam;
	private Parameter<String> passwordParam;
	private User user;

	@Inject
	void initQuery(/*@Users EntityManagerFactory emf*/) {
		//CriteriaBuilder cb = emf.getCriteriaBuilder();
		CriteriaBuilder cb = userDatabase.getCriteriaBuilder();
		usernameParam = cb.parameter(String.class);
		passwordParam = cb.parameter(String.class);
		query = cb.createQuery(User.class);
		Root<User> u = query.from(User.class);
		query.select(u);
		query.where(cb.equal(u.get(User_.username), usernameParam),
				cb.equal(u.get(User_.password), passwordParam));
	}

	public void login() {
//		TypedQuery<User> tq = userDatabase.createQuery(query);
//		tq.setP
		List<User> results = userDatabase.createQuery(query)
				.setParameter(usernameParam, credentials.getUsername())
				.setParameter(passwordParam, credentials.getPassword())
				.getResultList();
		if (!results.isEmpty()) {
			user = results.get(0);
		}
	}

	public void logout() {
		user = null;
	}

	public boolean isLoggedIn() {
		return user != null;
	}

	@Produces
	@LoggedIn
	User getCurrentUser() {
		if (user == null) {
			throw new NotLoggedInException();
		} else {
			return user;
		}
	}
}