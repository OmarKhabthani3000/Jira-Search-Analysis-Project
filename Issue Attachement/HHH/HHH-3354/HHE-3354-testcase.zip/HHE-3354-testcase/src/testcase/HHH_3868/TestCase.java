package testcase.HHH_3868;

import org.hibernate.*;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.HashSet;

import static org.junit.Assert.assertEquals;

public class TestCase {

    private SessionFactory sessionFactory;

    @Before
    public void before() {
        Configuration configuration = new Configuration().configure();
        configuration.addClass(Parent.class);
        configuration.addClass(Child.class);
        configuration.addClass(SomeEntity.class);
        StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().
        applySettings(configuration.getProperties());
        sessionFactory = configuration.buildSessionFactory(builder.build());
//        sessionFactory = configuration.buildSessionFactory();
    }

    @After
    public void after() {
        sessionFactory.close();
    }

    @Test
    public void test() {
        Parent parent;
        {
            Session session = sessionFactory.openSession();
            Transaction tx = session.beginTransaction();
            // Create initial data
            parent = new Parent();
            parent.setChildren(new HashSet<Child>());
            parent.getChildren().add( new Child("1") );
            parent.getChildren().add( new Child("2") );
            parent.getChildren().add( new Child("3") );
            parent.getChildren().add( new Child("4") );
            session.save(parent);
            tx.commit();
            session.close();
        }
        // parent is now detached entity


//        Logger.getLogger("org.hibernate.SQL").setLevel(Level.ALL);

        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        // Reattach detached order and put a record lock, parent will be persisted upon transaction commit
        session.buildLockRequest(new LockOptions(LockMode.PESSIMISTIC_WRITE)).lock("Parent", parent);

        // Now replace 4 children collection content with new 2 entries
        parent.getChildren().clear();
        parent.getChildren().add(new Child("5"));
        parent.getChildren().add(new Child("6"));
        // if we call session.flush(); the problem will disappear. This seems to ba a workaround

        // auto-flushes here: 2 children records inserted, but Parent.children collection snapshot still has 4 old items
        session.createQuery("from SomeEntity").list(); // flushReallyNeeded = false

        // If we execute a query on Parent there would be full flash and bug wouldn't appear
        // Persistence.getSession().createQuery("from Parent").list(); // flushReallyNeeded = true

        parent.getChildren().clear();
        parent.getChildren().add(new Child("7"));
        parent.getChildren().add(new Child("8"));
        parent.getChildren().add(new Child("9"));

        tx.commit(); // 2 more POLs inserted only 4 POLs deleted
        session.close();

        // There should be 3 children - "7", "8" and "9".
        session = sessionFactory.openSession();
        tx = session.beginTransaction();
        Parent reloadedParent = (Parent)session.get(Parent.class,parent.getId());
        assertEquals(3, reloadedParent.getChildren().size());
        tx.commit();
        session.close();


    }


}
