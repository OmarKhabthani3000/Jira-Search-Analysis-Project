package testcase.HHH_3868;

public class SomeEntity {

    long id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
