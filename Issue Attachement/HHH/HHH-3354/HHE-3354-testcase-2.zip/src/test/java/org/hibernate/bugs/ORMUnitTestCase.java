/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import java.util.HashSet;

import static org.junit.Assert.assertEquals;


/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 *
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	// If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
	@Override
	protected String[] getMappings() {
		return new String[] {
				"Parent.hbm.xml",
				"Child.hbm.xml",
				"SomeEntity.hbm.xml"
		};
	}
	// If those mappings reside somewhere other than resources/org/hibernate/test, change this.
	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/bugs/";
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );

//		configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, "true" );
	}

	@Test
	public void hhh3354Test() throws Exception {
		
        Parent parent;
        {
            Session session = openSession();
            Transaction tx = session.beginTransaction();
            // Create initial data
            parent = new Parent();
            parent.setChildren(new HashSet<Child>());
            parent.getChildren().add( new Child("1") );
            parent.getChildren().add( new Child("2") );
            parent.getChildren().add( new Child("3") );
            parent.getChildren().add( new Child("4") );
            session.save(parent);
            tx.commit();
            session.close();
        }
        // parent is now detached entity


//        Logger.getLogger("org.hibernate.SQL").setLevel(Level.ALL);

        Session session = openSession();
        Transaction tx = session.beginTransaction();

        // Reattach detached order and put a record lock, parent will be persisted upon transaction commit
        session.buildLockRequest(new LockOptions(LockMode.PESSIMISTIC_WRITE)).lock("Parent", parent);

        // Now replace 4 children collection content with new 2 entries
        parent.getChildren().clear();
        parent.getChildren().add(new Child("5"));
        parent.getChildren().add(new Child("6"));
        // if we call session.flush(); the problem will disappear. This seems to ba a workaround

        // auto-flushes here: 2 children records inserted, but Parent.children collection snapshot still has 4 old items
        session.createQuery("from SomeEntity").list(); // flushReallyNeeded = false

        // If we execute a query on Parent there would be full flash and bug wouldn't appear
        // Persistence.getSession().createQuery("from Parent").list(); // flushReallyNeeded = true

        parent.getChildren().clear();
        parent.getChildren().add(new Child("7"));
        parent.getChildren().add(new Child("8"));
        parent.getChildren().add(new Child("9"));

        tx.commit(); // 2 more POLs inserted only 4 POLs deleted
        session.close();

        // There should be 3 children - "7", "8" and "9".
        session = openSession();
        tx = session.beginTransaction();
        Parent reloadedParent = (Parent)session.get(Parent.class,parent.getId());
        assertEquals(3, reloadedParent.getChildren().size());
        tx.commit();
        session.close();
		
	}
}