package org.hibernate.hhh9257;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.hibernate.hhh9257.FilterNames.FILTER_SOFT_DELETES;

public class FilterTest {

    private SessionFactory sessionFactory;

    public static SessionFactory initSessionFactory(final String pathToHibernateCfgXml) {
        AnnotationConfiguration hibernateConfiguration = new AnnotationConfiguration();
        hibernateConfiguration.configure(pathToHibernateCfgXml);
        return hibernateConfiguration.buildSessionFactory();
    }

    @Before
    public void before() {
        sessionFactory = initSessionFactory("hibernate.cfg.xml");
    }

    @After
    public void after() {
        if (sessionFactory.getCurrentSession().isOpen()) {
            sessionFactory.getCurrentSession().close();
        }
    }

    // Generates the following SQL (Session.get() does not apply filters):
    // SELECT person0_.id AS id1_0_0_, person0_1_.deleted AS deleted2_0_0_
    //   FROM    public.person person0_
    //        INNER JOIN
    //           public.legal_entity person0_1_
    //        ON person0_.id = person0_1_.id
    //  WHERE person0_.id = 4;
    @Test
    public void testGet() {
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = session.beginTransaction();
        session.enableFilter(FILTER_SOFT_DELETES);
        try {
            session.get(Person.class, 4L);
        } finally {
            tx.rollback();
        }
    }

    // Generates the following SQL (notice this_.deleted = 0 AND this_1_.deleted = 0)
    // SELECT this_.id AS id1_0_0_, this_1_.deleted AS deleted2_0_0_
    //   FROM    public.person this_
    //        INNER JOIN
    //           public.legal_entity this_1_
    //        ON this_.id = this_1_.id
    //  WHERE this_.deleted = 0 AND this_1_.deleted = 0 AND this_.id = 4;
    @Test
    public void testCriteria() {
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = session.beginTransaction();
        session.enableFilter(FILTER_SOFT_DELETES);
        try {
            session.createCriteria(Person.class).add(Restrictions.idEq(4L)).list();
        } finally {
            tx.rollback();
        }
    }

    // Generates the following SQL (notice  person0_.deleted = 0 AND person0_1_.deleted = 0):
    // SELECT person0_.id AS id1_0_, person0_1_.deleted AS deleted2_0_
    //   FROM    public.person person0_
    //        INNER JOIN
    //           public.legal_entity person0_1_
    //        ON person0_.id = person0_1_.id
    //  WHERE person0_.deleted = 0 AND person0_1_.deleted = 0 AND person0_.id = 4;
    @Test
    public void testHql() {
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = session.beginTransaction();
        session.enableFilter(FILTER_SOFT_DELETES);
        try {
            Query q = session.createQuery("select p from Person p where id=:id");
            q.setLong("id", 4L);
            q.list();
        } finally {
            tx.rollback();
        }
    }
}
