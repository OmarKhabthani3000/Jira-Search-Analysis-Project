package org.hibernate.hhh9257;

public abstract class FilterNames {

    public static final String FILTER_SOFT_DELETES = "filterSoftDeletes";
}
