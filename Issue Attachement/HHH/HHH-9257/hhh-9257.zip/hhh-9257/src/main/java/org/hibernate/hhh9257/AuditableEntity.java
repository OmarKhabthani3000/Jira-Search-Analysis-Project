package org.hibernate.hhh9257;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;

import javax.persistence.*;
import static org.hibernate.hhh9257.FilterNames.*;
@MappedSuperclass
@FilterDef(name = FILTER_SOFT_DELETES, defaultCondition = "deleted = 0", parameters = {})
@Filter(name = FILTER_SOFT_DELETES)
public class AuditableEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "deleted", nullable = false, columnDefinition = "numeric(1,0) default 0")
    private boolean deleted = false;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }
}
