package org.hibernate.hhh9257;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "person")
public class Person extends LegalEntity {
}
