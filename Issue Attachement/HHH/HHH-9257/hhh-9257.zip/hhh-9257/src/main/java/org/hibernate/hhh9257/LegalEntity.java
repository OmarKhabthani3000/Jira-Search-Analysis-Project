package org.hibernate.hhh9257;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "legal_entity")
public class LegalEntity extends AuditableEntity {
}
