package br.com.capesesp.controleacesso.dominio;

import java.util.Date;

import br.com.capesesp.jkernel.dominio.GenericEntity;

public class HorarioAreaTemporario extends GenericEntity {
	private static final long serialVersionUID = 1L;

	private Integer id;
	private Area area;		
	private String horaIni;
	private String horaFim;
	private String fimSemana;	
	private Date dataIniVigencia;
	private Date dataFimVigencia;
	private Date dataCriacao;
	
	public Area getArea() {
		return area;
	}
	public void setArea(Area area) {
		this.area = area;
	}
	public Date getDataCriacao() {
		return dataCriacao;
	}
	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}
	public Date getDataFimVigencia() {
		return dataFimVigencia;
	}
	public void setDataFimVigencia(Date dataFimVigencia) {
		this.dataFimVigencia = dataFimVigencia;
	}
	public Date getDataIniVigencia() {
		return dataIniVigencia;
	}
	public void setDataIniVigencia(Date dataIniVigencia) {
		this.dataIniVigencia = dataIniVigencia;
	}
	public String getFimSemana() {
		return fimSemana;
	}
	public void setFimSemana(String fimSemana) {
		this.fimSemana = fimSemana;
	}
	public String getHoraFim() {
		return horaFim;
	}
	public void setHoraFim(String horaFim) {
		this.horaFim = horaFim;
	}
	public String getHoraIni() {
		return horaIni;
	}
	public void setHoraIni(String horaIni) {
		this.horaIni = horaIni;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final HorarioAreaTemporario other = (HorarioAreaTemporario) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
