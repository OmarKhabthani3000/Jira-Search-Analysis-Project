package br.com.capesesp.controleacesso.dominio;

import br.com.capesesp.jkernel.dominio.GenericEntity;

public class HorarioAreaPadrao extends GenericEntity {
	private static final long serialVersionUID = 1L;

	private Integer id;
	private Area area;
	private String horaIni;
	private String horaFim;
	private String fimSemana;	

	public Area getArea() {
		return area;
	}
	public void setArea(Area area) {
		this.area = area;
	}
	public String getFimSemana() {
		return fimSemana;
	}
	public void setFimSemana(String fimSemana) {
		this.fimSemana = fimSemana;
	}
	public String getHoraFim() {
		return horaFim;
	}
	public void setHoraFim(String horaFim) {
		this.horaFim = horaFim;
	}
	public String getHoraIni() {
		return horaIni;
	}
	public void setHoraIni(String horaIni) {
		this.horaIni = horaIni;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final HorarioAreaPadrao other = (HorarioAreaPadrao) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
