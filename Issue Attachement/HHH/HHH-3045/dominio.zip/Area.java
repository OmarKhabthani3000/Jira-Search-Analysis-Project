package br.com.capesesp.controleacesso.dominio;

import br.com.capesesp.sistemas.dominio.Local;

public class Area extends Local {
	private static final long serialVersionUID = 1L;

	private HorarioAreaPadrao horarioPadrao;
	private HorarioAreaTemporario horarioTemporario;
	
	public HorarioAreaPadrao getHorarioPadrao() {
		return horarioPadrao;
	}
	
	public void setHorarioPadrao(HorarioAreaPadrao horarioPadrao) {
		this.horarioPadrao = horarioPadrao;
	}
	
	public HorarioAreaTemporario getHorarioTemporario() {
		return horarioTemporario;
	}
	
	public void setHorarioTemporario(HorarioAreaTemporario horarioTemporario) {
		this.horarioTemporario = horarioTemporario;
	}	
}
