package ann438;

import junit.framework.TestCase;

import org.apache.log4j.BasicConfigurator;
import org.hibernate.cfg.AnnotationConfiguration;

public class MinimalTestCase extends TestCase {

    public void testAnn438() throws Exception {
        BasicConfigurator.configure();

        new AnnotationConfiguration()
            .configure("ann438/hibernate.cfg.xml")
            .buildSessionFactory();
    }
}
