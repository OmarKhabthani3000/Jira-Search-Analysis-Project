package test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

import persistence.Lesson;
import persistence.LessonOrder;

/**
 * HQL query test.
 */
public class HQLTest {
	
	private static final String LESSON_STATE_N = "N";
	private static final String LESSON_STATE_Y = "Y";
	private static final String LESSON_STATE_OTHER = "OTHER";
	
	// this is not correctly translated from hql to sql:
	private static final String INCORRECT_HQL = String.format(
			"UPDATE Lesson e SET e.state = '%s' WHERE EXISTS (SELECT 1 FROM LessonOrder lso WHERE lso.lesson = e)", 
			LESSON_STATE_N);
	// this would be correctly translated from hql to sql:
	private static final String CORRECT_HQL = String.format( 
			"UPDATE Lesson e SET e.state = '%s' WHERE EXISTS (SELECT 1 FROM LessonOrder lso WHERE lso.lesson.id = e.id)",
			LESSON_STATE_N); 
			
	private Map<String, Integer> statesCountMap(int nCount, int yCount, int otherCount) {
		HashMap<String, Integer> toReturn = new HashMap<String, Integer>();
		toReturn.put(LESSON_STATE_N, nCount);
		toReturn.put(LESSON_STATE_Y, yCount);
		toReturn.put(LESSON_STATE_OTHER, otherCount);
		return toReturn;
	}
	
	private Map<String, Integer> countStates(List<Lesson> lessons) {
		Map<String, Integer> toReturn = statesCountMap(0, 0, 0);
		for (Lesson lesson : lessons) {
			if (!lesson.getState().equals(LESSON_STATE_N) && !lesson.getState().equals(LESSON_STATE_Y)) {
				toReturn.put(LESSON_STATE_OTHER, toReturn.get(LESSON_STATE_OTHER) + 1);
			}
			else { 
				toReturn.put(lesson.getState(), toReturn.get(lesson.getState()) + 1);
			}
		}
		return toReturn;
	}
	
	@Test
	public void test() throws Exception {
		@SuppressWarnings("deprecation")
		SessionFactory sessionFactory =
				new Configuration().configure().buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		Lesson lesson1 = new Lesson(LESSON_STATE_Y);
		Lesson lesson2 = new Lesson(LESSON_STATE_Y);
		
		LessonOrder lessonOrder1 = new LessonOrder(lesson1);
		LessonOrder lessonOrder2 = new LessonOrder(lesson1);
		
		session.save(lesson1);
		session.save(lesson2);
		session.save(lessonOrder1);
		session.save(lessonOrder2);
		
		Query incorrectQuery = session.createQuery(INCORRECT_HQL);
		incorrectQuery.executeUpdate();

		/*Query correctQuery = session.createQuery(CORRECT_HQL);
		correctQuery.executeUpdate();*/

		session.clear();
	
		Query checkQuery = session.createQuery("from Lesson");
		List<?> results = checkQuery.list();
		
		session.getTransaction().commit();
		session.close();
		
		@SuppressWarnings("unchecked")
		List<Lesson> lessons = (List<Lesson>) results;

		Map<String, Integer> expectedStatesCount = statesCountMap(1, 1, 0);
		Map<String, Integer> observedStatesCount = countStates(lessons); 
		
		if (!expectedStatesCount.equals(observedStatesCount)) {
			throw new Exception(String.format("expected one row with 'N' and one with 'Y', got: %s", observedStatesCount));
		}
		
		sessionFactory.close();
	}
}
