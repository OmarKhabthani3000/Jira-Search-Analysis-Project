package persistence;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LESSON")
public class Lesson {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "lsn_id")
	private int id;
	
	@Column(name = "lsn_state")
	private String state;

	public Lesson(String state) {
		this.state = state;
	}
	
	public Lesson() {}
	
	public String getState() {
		return state;
	}

	public String toString() {
		return String.format("(%s, %s)", id, state);
	}
	
}
