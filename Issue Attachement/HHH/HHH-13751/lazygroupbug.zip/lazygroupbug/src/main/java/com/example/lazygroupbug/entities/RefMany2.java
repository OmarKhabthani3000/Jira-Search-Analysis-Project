package com.example.lazygroupbug.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "REF_MANY_2")
public class RefMany2 {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "refMany2Seq")
	@SequenceGenerator(name = "refMany2Seq", sequenceName = "REF_MANY_2_SEQ", allocationSize = 1)
	@Column(name = "REF_MANY_2ID")
	private Long id;
	
	@Column(name = "LABEL")
	private String label;
	
	@OneToMany(mappedBy = "refMany2")
	private List<BugLazyGrp> bugLazyGrps;
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public List<BugLazyGrp> getBugLazyGrps() {
		return bugLazyGrps;
	}

	public void setBugLazyGrps(List<BugLazyGrp> bugLazyGrps) {
		this.bugLazyGrps = bugLazyGrps;
	}


}
