package com.example.lazygroupbug.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="REF_MANY_1")
public class RefMany1 {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "refMany1Seq")
	@SequenceGenerator(name = "refMany1Seq", sequenceName = "REF_MANY_1_SEQ", allocationSize = 1)
	@Column(name="REF_MANY_1ID")
	private Long id;
	
	@Column(name="DESCRIPTION")
	private String description;

	@OneToMany(mappedBy = "refMany1")
	private List<BugLazyGrp> bugLazyGrps;
	
	public Long getId() {
		return id;
	}

	public String getDescription() {
		return description;
	}

	public void setId(Long id) {
		this.id = id;
	}


	public void setDescription(String description) {
		this.description = description;
	}

	public List<BugLazyGrp> getBugLazyGrps() {
		return bugLazyGrps;
	}

	public void setBugLazyGrps(List<BugLazyGrp> bugLazyGrps) {
		this.bugLazyGrps = bugLazyGrps;
	}


}
