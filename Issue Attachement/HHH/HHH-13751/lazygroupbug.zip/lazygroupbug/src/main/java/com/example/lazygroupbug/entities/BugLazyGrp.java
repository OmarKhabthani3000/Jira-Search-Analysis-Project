package com.example.lazygroupbug.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.LazyGroup;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

@Entity
@Table(name = "BUG_LAZY_GRP")
public class BugLazyGrp {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bugLazyGrpSeq")
	@SequenceGenerator(name = "bugLazyGrpSeq", sequenceName = "BUG_LAZY_GRP_SEQ", allocationSize = 1)
	@Column(name = "BUG_LAZY_GRP_ID")
	private Long id;
	
	@Column(name = "REFERENCE")
	private String reference;
	
	@LazyGroup(value = "bugLazyGrp_refmany1")
	@LazyToOne(value = LazyToOneOption.NO_PROXY)
	@ManyToOne(fetch=FetchType.LAZY, optional = false)
	@JoinColumn(name = "REF_MANY_1ID")
	private RefMany1 refMany1;
	
	@LazyGroup(value = "bugLazyGrp_refmany2")
	@LazyToOne(value = LazyToOneOption.NO_PROXY)
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "REF_MANY_2ID")
	private RefMany2 refMany2;
	
	
	@LazyGroup(value = "bugLazyGrp_refone")
	@LazyToOne(value = LazyToOneOption.NO_PROXY)
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "bugLazyGrp")
	private RefOne refOne;


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getReference() {
		return reference;
	}


	public void setReference(String reference) {
		this.reference = reference;
	}

	public RefMany1 getRefMany1() {
		return refMany1;
	}


	public void setRefMany1(RefMany1 refMany1) {
		this.refMany1 = refMany1;
	}


	public RefMany2 getRefMany2() {
		return refMany2;
	}


	public void setRefMany2(RefMany2 refMany2) {
		this.refMany2 = refMany2;
	}


	public RefOne getRefOne() {
		return refOne;
	}


	public void setRefOne(RefOne refOne) {
		this.refOne = refOne;
	}
	
	
}
