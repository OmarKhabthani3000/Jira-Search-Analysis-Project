package org.hibernate.model;

import javax.persistence.*;

@Entity
public class SmallObject extends BaseObject {

    @Column(name = "second_name", nullable = false)
    private String secondName;

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }
}
