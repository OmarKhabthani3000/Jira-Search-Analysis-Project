package org.hibernate.model;

import java.util.List;
import javax.persistence.*;

@Entity
public class BigObject extends BaseObject {

    @Column(name = "second_name", nullable = false)
    private String secondName;
    @ManyToMany
    @JoinTable(
            name = "small_object_assignment",
            joinColumns = @JoinColumn(name = "ukey1", referencedColumnName = "ukey"),
            inverseJoinColumns = @JoinColumn(name = "ukey2", referencedColumnName = "ukey")
    )
    
    private List<SmallObject> objects;

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }
}
