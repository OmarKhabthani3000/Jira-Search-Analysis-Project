package org.hibernate.bugs;

import org.junit.Test;

import javax.persistence.Persistence;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    @Test
    public void hhh123Test() throws Exception {
        Persistence.createEntityManagerFactory("templatePU").close();
    }
}
