package org.hibernate.bugs.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class Thing {
    @Id
    @Column(name = "THING_PK")
    Long pk;

    @OneToOne(targetEntity = ThingStats.class, fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "THING_PK")
    private ThingStats thingStats;

    public Long getPk() {
        return pk;
    }

    public void setPk(Long pk) {
        this.pk = pk;
    }

    public void setThingStats(ThingStats thingStats) {
        this.thingStats = thingStats;
    }

    public ThingStats getThingStats() {
        return thingStats;
    }
}
