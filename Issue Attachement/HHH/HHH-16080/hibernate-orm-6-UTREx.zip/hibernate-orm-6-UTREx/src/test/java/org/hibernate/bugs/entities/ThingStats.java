package org.hibernate.bugs.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
public class ThingStats {
    @Id @Column(name = "THING_FK", nullable = false)
    private Long thingPk;

    @Column(name = "COUNT", nullable = false)
    private long count;

    @Column(name = "REJECTED_COUNT", nullable = false)
    private long rejectedCount;

    public Long getThingPk() {
        return thingPk;
    }
    public void setThingPk(Long thingPk) {
        this.thingPk = thingPk;
    }
    public long getCount() {
        return count;
    }
    public void setCount(long sopCount) {
        this.count = sopCount;
    }
    public long getRejectedCount() {
        return rejectedCount;
    }
    public void setRejectedCount(long rejectedCount) {
        this.rejectedCount = rejectedCount;
    }

}
