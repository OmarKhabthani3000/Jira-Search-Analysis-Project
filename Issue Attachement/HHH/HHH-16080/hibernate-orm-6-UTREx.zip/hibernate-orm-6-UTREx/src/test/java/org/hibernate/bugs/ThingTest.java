package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.bugs.entities.Thing;
import org.hibernate.bugs.entities.ThingStats;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ThingTest {
    static Logger logger = LogManager.getLogger();

    private EntityManagerFactory entityManagerFactory;
    private EntityManager em;

    private static final long THING1_ID = 1000L;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
        em = entityManagerFactory.createEntityManager();

        // Set up data:
        em.getTransaction().begin();

        Thing thing = new Thing();
        thing.setPk(THING1_ID);

        ThingStats stats = new ThingStats();
        stats.setThingPk(thing.getPk());
        stats.setCount(10);
        stats.setRejectedCount(5);

        thing.setThingStats(stats);

        em.persist(thing);
        em.persist(stats);
        em.getTransaction().commit();
        em.close();
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    public void testThingStats() {
        em = entityManagerFactory.createEntityManager();

        // This is all good:
        Thing s = em.find(Thing.class, THING1_ID);
        assertNotNull(s);  // << this works
        assertNotNull(s.getThingStats()); // <<-- This works
        assertEquals((Long) THING1_ID, s.getThingStats().getThingPk());

        // But this fails with:
        // jakarta.persistence.PersistenceException: Converting `org.hibernate.sql.ast.tree.from.UnknownTableReferenceException` to JPA `PersistenceException` : Unable to determine TableReference (`Thing`) for `org.hibernate.bugs.entities.Thing(thing).thingStats(thingStats)`
        String ql = "select thing from Thing thing"
                + " left join thing.thingStats thingStats "
                + " where thingStats is null or thingStats.rejectedCount = 0";

        TypedQuery<Thing> q = em.createQuery(ql, Thing.class);
        List<Thing> results = q.getResultList();  // <<---  Throws PersistenceException
    }
}
