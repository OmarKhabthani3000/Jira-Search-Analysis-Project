package org.hibernate.bugs;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "test_table")
public class TestEntity implements Serializable {

    private Integer id;
    private String name;
    private Integer refId;
    private List<SubEntity> subs;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Column(name = "name",columnDefinition = "char(255)")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "ref_id")
    public Integer getRefId() {
        return refId;
    }

    public void setRefId(Integer refId) {
        this.refId = refId;
    }

    @OneToMany(mappedBy = "main", orphanRemoval = true, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    public List<SubEntity> getSubs() {
        return subs;
    }

    public void setSubs(List<SubEntity> subs) {
        this.subs = subs;
    }
}
