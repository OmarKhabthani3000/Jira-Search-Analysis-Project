/**
 * Created by IntelliJ IDEA.
 * User: jo
 * Date: 6-sep-2007
 * Time: 20:13:47
 * To change this template use File | Settings | File Templates.
 */
public class SearchClass {
    private String name;
    private Class type;
    private long id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Class getType() {
        return type;
    }

    public void setType(Class type) {
        this.type = type;
    }
}
