/**
 * Created by IntelliJ IDEA.
 * User: jo
 * Date: 6-sep-2007
 * Time: 20:14:45
 * To change this template use File | Settings | File Templates.
 */
public class ClassWithNoMapping {
    private String name;
    private long        id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}