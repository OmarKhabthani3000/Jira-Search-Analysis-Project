import org.hibernate.HibernateException;
import org.hibernate.Transaction;
import org.hibernate.Criteria;
import org.hibernate.engine.TypedValue;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.CriteriaQuery;
import org.hibernate.criterion.SimpleExpression;
import org.hibernate.criterion.Restrictions;
import org.hibernate.classic.Session;
import org.hibernate.mapping.List;

import java.util.Iterator;


/**
 * Created by IntelliJ IDEA.
 * User: jo
 * Date: 6-sep-2007
 * Time: 20:31:55
 * To change this template use File | Settings | File Templates.
 */
public class Test {
        /**
         * @param args
         */
        public static void main(String[] args) {
            list();
        }

        private static void list() {
            Transaction tx = null;
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();
            try {
                tx = session.beginTransaction();
                Criteria l = session.createCriteria(SearchClass.class);
                l.add(Restrictions.eq("type", ClassWithNoMapping.class));
                java.util.List result = l.list();
                l = session.createCriteria(SearchClass.class);
                l.add(Restrictions.eq("type", ClassWithMapping.class));
                result = l.list();
                tx.commit();
            } catch (HibernateException e) {
                e.printStackTrace();
                if (tx != null && tx.isActive())
                    tx.rollback();
            }
        }
}
