package test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.query.AuditEntity;
import org.hibernate.envers.query.AuditQueryCreator;
import org.jboss.logging.Logger;
import org.junit.Test;
import test.model.NameInfo;
import test.model.Person;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.notNullValue;

public class PersistAndFetchHistoricallyWithEmbeddableTest {

  private static final Logger logger = Logger.getLogger(PersistAndFetchHistoricallyWithEmbeddableTest.class);
  private static final String TEST_USERNAME = "testUsername";

  @Test
  public void testScenario() {
    EntityManager em = Persistence.createEntityManagerFactory("TestPU").createEntityManager();
    EntityTransaction tx = em.getTransaction();

    NameInfo nameInfo = new NameInfo("first", "last");

    createPerson(em, tx, nameInfo);

    verifyPersonExists(em, tx);

    verifyPersonCanBeQueriedUsingEmbeddable(em, tx, nameInfo);

    verifyHistoricPersonCanBeQueried(em, tx);

    verifyHistoricPersonCanBeQueriedWithNonEmbeddedArgument(em, tx, nameInfo);

    verifyHistoricPersonCanBeQueriedWithEmbeddable(em, tx, nameInfo);
  }

  private void verifyHistoricPersonCanBeQueriedWithNonEmbeddedArgument(EntityManager em, EntityTransaction tx,
                                                                       NameInfo nameInfo) {
    tx.begin();
    AuditQueryCreator auditQueryWithParameter = AuditReaderFactory.get(em).createQuery();

    List<Person> historicPersonsWithArgument = auditQueryWithParameter.forEntitiesAtRevision(Person.class, 1)
        .add(AuditEntity.property("username").eq(TEST_USERNAME)).getResultList();

    logger.info("Found historic persons with test username: " + historicPersonsWithArgument.size());
    assertThat(historicPersonsWithArgument.size(), is(1));

    tx.commit();
  }

  private void verifyHistoricPersonCanBeQueriedWithEmbeddable(EntityManager em, EntityTransaction tx,
                                                              NameInfo nameInfo) {
    tx.begin();
    AuditQueryCreator auditQueryWithParameter = AuditReaderFactory.get(em).createQuery();

    List<Person> historicPersonsWithArgument = auditQueryWithParameter.forEntitiesAtRevision(Person.class, 1)
        .add(AuditEntity.property("nameInfo").eq(nameInfo)).getResultList();

    logger.info("Found historic persons with name info: " + historicPersonsWithArgument.size());
    assertThat(historicPersonsWithArgument.size(), is(1));

    tx.commit();
  }

  private void verifyHistoricPersonCanBeQueried(EntityManager em, EntityTransaction tx) {
    tx.begin();
    AuditQueryCreator auditQuery = AuditReaderFactory.get(em).createQuery();

    List<Person> historicPersons = auditQuery.forEntitiesAtRevision(Person.class, 1).getResultList();

    logger.info("Found historic persons for revision 1: " + historicPersons.size());
    assertThat(historicPersons.size(), is(1));

    tx.commit();
  }

  private void verifyPersonCanBeQueriedUsingEmbeddable(EntityManager em, EntityTransaction tx, NameInfo nameInfo) {
    tx.begin();
    List<Person> personsByNameInfo =
        em.createQuery("FROM Person p WHERE p.nameInfo = :ni")
            .setParameter("ni", nameInfo).getResultList();
    logger.info("Found persons with name info: " + personsByNameInfo.size());
    assertThat(personsByNameInfo.size(), is(1));
    tx.commit();
  }

  private void verifyPersonExists(EntityManager em, EntityTransaction tx) {
    tx.begin();
    List<Person> persons = em.createQuery("FROM Person").getResultList();
    logger.info("Found persons: " + persons.size());
    assertThat(persons.size(), is(1));
    tx.commit();
  }

  private void createPerson(EntityManager em, EntityTransaction tx, NameInfo nameInfo) {
    tx.begin();
    Person person = new Person();
    person.setNameInfo(nameInfo);
    person.setUsername(TEST_USERNAME);
    em.persist(person);
    logger.info("Created person with id: " + person.getId());
    assertThat(person.getId(), notNullValue());
    tx.commit();
  }
}
