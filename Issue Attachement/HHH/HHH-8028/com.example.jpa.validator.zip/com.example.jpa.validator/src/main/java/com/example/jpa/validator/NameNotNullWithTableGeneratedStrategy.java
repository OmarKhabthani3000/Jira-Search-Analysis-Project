package com.example.jpa.validator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.TableGenerator;
import javax.validation.constraints.NotNull;

@Entity
public class NameNotNullWithTableGeneratedStrategy {

    @GeneratedValue(strategy = GenerationType.TABLE,
            generator = "NAME_MUST_NOT_BE_NULL_ID_GENERATOR")
    @TableGenerator(name = "NAME_MUST_NOT_BE_NULL_ID_GENERATOR")

    @Id @NotNull private Long id;

    @Column(nullable=false) @NotNull public String name;

    public NameNotNullWithTableGeneratedStrategy() {}

}