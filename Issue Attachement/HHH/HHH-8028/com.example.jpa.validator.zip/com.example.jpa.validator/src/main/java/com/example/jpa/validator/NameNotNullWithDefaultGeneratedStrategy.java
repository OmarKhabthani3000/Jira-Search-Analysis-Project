package com.example.jpa.validator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class NameNotNullWithDefaultGeneratedStrategy {

    @Id @GeneratedValue private Long id;

    @Column(nullable=false) @NotNull public String name;

    public NameNotNullWithDefaultGeneratedStrategy() {}
}