package com.example.jpa.validator;

import org.junit.Assert;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.RollbackException;

public class ConstraintViolationExceptionTest {

    @Test
    public void testEntityWithDefaultIgGeneratedStrategy() {
        testPersistWithNullName(new NameNotNullWithDefaultGeneratedStrategy());
    }

    @Test
    public void testEntityWithTableGeneratedIdStrategy() {
        testPersistWithNullName(new NameNotNullWithTableGeneratedStrategy());
        //this test fail with :
        //java.lang.AssertionError: Expecting a javax.validation.ConstraintViolationException, but persist() succeed !
    }

    private void testPersistWithNullName(Object entity){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
        EntityManager entityManager = emf.createEntityManager();
        try {
            final EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            try {
                try {
                    entityManager.persist(entity);
                    Assert.fail("Expecting a javax.validation.ConstraintViolationException, but persist() succeed !");
                } catch (javax.validation.ConstraintViolationException cve) {
                    //That's expected
                    Assert.assertTrue("According JPA specs transaction must be flagged as rollback only",transaction.getRollbackOnly());
                } catch (Exception e) {
                    Assert.assertTrue("According JPA specs transaction must be flagged as rollback only",transaction.getRollbackOnly());
                    e.printStackTrace();
                    Assert.fail("Expecting a javax.validation.ConstraintViolationException, but got " + e.getClass());
                }
                transaction.commit();
                Assert.fail("persisted with null name !!!");
            } catch (RollbackException e) {
                //That's expected
            }  catch (Exception e) {
                e.printStackTrace();
                Assert.fail("Unexpected exception :"+e.getMessage());
            }
        } finally {
            entityManager.close();
        }
    }
}
