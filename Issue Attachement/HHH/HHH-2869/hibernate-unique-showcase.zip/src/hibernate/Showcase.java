package hibernate;

import java.util.Date;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaUpdate;

import test.Container;
import test.Value;

public class Showcase {
    private SessionFactory sessionFactory;
    
    public static void main(String args[]) {
        Showcase showcase = new Showcase();
        
        // init the database object
        Container init = showcase.getInitState();
        showcase.insert(init);

        // interweaving hibernate code 'correctly' allows updates
        showcase.workingUpdate(init);
        
        // but POJO-alike coding with separated object logic and persistence logic fails.
        Container modified = showcase.getUpdatedState(init);
        showcase.update(modified);  // ORA-00001: unique constraint (SHOWCASE.SYS_C0036093) violated
    }
        
    public Container getInitState() {
        Container main = new Container();
        main.setName("Container created at " + new Date());
        
        Set<Value> set = new HashSet<Value>();
        set.add( new Value ("X"));
        
        main.setValues(set);
        
        return main;
    }
    
    public void workingUpdate(Container m) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        
        m.setName("Container updated correctly at " + new Date());
        Set<Value> set = m.getValues();
        set.clear();
        
        session.update(m);
        session.flush();
        
        set.add( new Value("X"));
        session.update(m);
        
        tx.commit();
        session.close();
    }
    
    public Container getUpdatedState(Container m) {
        m.setName("Container updated correctly at " + new Date());
        Set<Value> set = m.getValues();
        set.clear();
        set.add( new Value("X"));

        return m;
    }
    
    public void insert(Object m) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(m);
        tx.commit();
        session.close();
    }

    public void update(Container modified) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.update(modified);
        tx.commit();
        session.close();
    }
    
    public Showcase() {
        Configuration cfg = new Configuration();
        cfg.addResource("test/Container.hbm.xml");
        cfg.addResource("test/Value.hbm.xml");
        
        Properties dbProps = new Properties();
        dbProps.put("hibernate.show_sql", "true");
        dbProps.put("hibernate.format_sql", "true");
        dbProps.put("hibernate.dialect", "org.hibernate.dialect.Oracle9Dialect");
        dbProps.put("hibernate.hbm2ddl.auto", "create-drop");
        dbProps.put("hibernate.connection.username", "showcase");
        dbProps.put("hibernate.connection.password", "showcase");
        dbProps.put("hibernate.connection.driver_class", "oracle.jdbc.driver.OracleDriver");
        dbProps.put("hibernate.connection.url", "jdbc:oracle:thin:@localhost:1521:XE");

        cfg.addProperties(dbProps);
        cfg.addProperties(System.getProperties());
        
        SchemaUpdate schemaUpdate = new SchemaUpdate(cfg);
        schemaUpdate.execute(true, true);
        sessionFactory = cfg.buildSessionFactory();
    }

}
