package test;

public class Value {
    private Long   id;
    private String str;
    
    public Value(String str) { this.str = str;}
    public void setStr(String str) { this.str = str; }
    public String getStr() { return str; }
}
