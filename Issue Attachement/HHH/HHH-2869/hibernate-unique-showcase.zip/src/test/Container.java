package test;

import java.util.Set;

public class Container {
    private Long       id;
    private Set<Value> values;
    private String     name;
    
    public void setName(String str) { name = str; }
    public String getName() { return name; }
    public void setValues(Set<Value> values) { this.values = values; } 
    public Set<Value> getValues() { return values; }
}
