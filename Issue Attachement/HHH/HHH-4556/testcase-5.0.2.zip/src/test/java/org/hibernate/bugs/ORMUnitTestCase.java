/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import static org.junit.Assert.assertFalse;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 *
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
			A.class, B.class
		};
	}

	/**
	 * This test should pass, but doesn't
	 */
	@Test
	public void testWithoutManualFlush() throws Exception {
		doTest(false);
	}

	/**
	 * This test passes, because a manual flush is added before the query
	 */
	@Test
	public void testWithManualFlush() throws Exception {
		doTest(true);
	}

	private void doTest(boolean flushManuallyBeforeQuery) {
		Session session = openSession();
		Transaction tx = session.beginTransaction();
		try {
			A a1 = createA(session, 1);

			Criteria criteria = session.createCriteria(A.class);
			DetachedCriteria detached = DetachedCriteria.forClass(B.class, "b");
			detached.add(Restrictions.eq("b.name", "b1_1"));
			detached.setProjection(Projections.property("b.a.id"));

			criteria.add(Property.forName("id").in(detached));

			if (flushManuallyBeforeQuery) {
				session.flush();
			}

			List result = criteria.list();
			assertFalse(result.isEmpty());
		} finally {
			tx.rollback();
			session.close();
		}
	}

	private A createA(Session session, int index) {
		// create A and flush the session
		A a = new A();
		a.setName("a" + index);
		session.persist(a);
		session.flush();

		// create Bs, linked to created A, and don't flush after
		B b1 = new B();
		b1.setName("b" + index + "_1");
		b1.setA(a);
		B b2 = new B();
		b2.setName("b" + index + "_2");
		b2.setA(a);
		session.persist(b1);
		session.persist(b2);

		return a;
	}
}
