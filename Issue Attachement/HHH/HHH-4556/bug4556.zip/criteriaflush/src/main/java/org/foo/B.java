package org.foo;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="B")
@SequenceGenerator(
    name="ENTITY_SEQ",
    sequenceName="B_SEQ",
    allocationSize=1
)
public class B extends BaseEntity {

    @ManyToOne()
    @JoinColumn(name = "a_id")
    private A a;

    public A getA() {
        return a;
    }

    public void setA(A a) {
        this.a = a;
    }
}

