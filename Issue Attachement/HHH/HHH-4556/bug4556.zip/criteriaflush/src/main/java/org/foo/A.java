package org.foo;

import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity()
@Table(name="A")
@SequenceGenerator(
    name="ENTITY_SEQ",
    sequenceName="A_SEQ",
    allocationSize=1
)
public class A extends BaseEntity {
}
