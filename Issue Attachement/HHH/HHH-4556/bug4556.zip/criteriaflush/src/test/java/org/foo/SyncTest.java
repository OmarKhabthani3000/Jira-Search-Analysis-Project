package org.foo;

import junit.framework.TestCase;
import org.hibernate.Criteria;
import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;

import java.util.List;

public class SyncTest extends TestCase {

    private SessionFactory sessionFactory;
    private Session session;

    @Override
    protected void setUp() throws Exception {
        Configuration cfg = new Configuration();
        cfg.configure();
        ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(cfg.getProperties()).build();
        sessionFactory = cfg.buildSessionFactory(serviceRegistry);
        session = sessionFactory.openSession();
        session.setFlushMode(FlushMode.AUTO);
    }

    @Override
    protected void tearDown() throws Exception {
        session.close();
        sessionFactory.close();
    }

    /**
     * This test should pass, but doesn't
     */
    public void testWithoutManualFlush() throws Exception {
        doTest(false);
    }

    /**
     * This test passes, because a manual flush is added before the query
     */
    public void testWithManualFlush() throws Exception {
        doTest(true);
    }
    
    private void doTest(boolean flushManuallyBeforeQuery) {
        Transaction tx = session.beginTransaction();
        try {
            A a1 = createA(1);

            Criteria criteria = session.createCriteria(A.class);
            DetachedCriteria detached = DetachedCriteria.forClass(B.class, "b");
            detached.add(Restrictions.eq("b.name", "b1_1"));
            detached.setProjection(Projections.property("b.a.id"));
            
            criteria.add(Property.forName("id").in(detached));
            
            if (flushManuallyBeforeQuery) {
                session.flush();
            }
            
            List result = criteria.list();
            assertFalse(result.isEmpty());
        } finally {
            tx.rollback();
        }
    }
    
    private A createA(int index) {
        // create A and flush the session
        A a = new A();
        a.setName("a" + index);
        session.persist(a);
        session.flush();
        
        // create Bs, linked to created A, and don't flush after
        B b1 = new B();
        b1.setName("b" + index + "_1");
        b1.setA(a);
        B b2 = new B();
        b2.setName("b" + index + "_2");
        b2.setA(a);
        session.persist(b1);
        session.persist(b2);

        return a;
    }
}
