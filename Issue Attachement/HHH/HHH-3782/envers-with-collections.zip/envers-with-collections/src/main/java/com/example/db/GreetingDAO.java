package com.example.db;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class GreetingDAO {

	private SessionFactory sessionFactory;

	public Long create(GreetingPO persistentObject) {
		Session session = sessionFactory.getCurrentSession();
		return (Long) session.save(persistentObject);
	}

	public GreetingPO findByGreeting(String greeting) {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from GreetingPO where greeting=:greeting");
		query.setParameter("greeting", greeting);
		return (GreetingPO) query.uniqueResult();
	}

	public void deleteAll() {
		new DaoUtils<GreetingPO>(GreetingPO.class, sessionFactory).deleteAll();
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

}
