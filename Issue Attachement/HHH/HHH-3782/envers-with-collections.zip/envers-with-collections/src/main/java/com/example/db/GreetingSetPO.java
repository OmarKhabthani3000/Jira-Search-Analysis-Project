package com.example.db;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.jboss.envers.Versioned;

@Entity
@Table
@Versioned
public class GreetingSetPO {

	private Long id;
	private String name;
	private Set<GreetingPO> members = new HashSet<GreetingPO>();;

	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "greetingSet")
	public Set<GreetingPO> getMembers() {
		return members;
	}

	public void setMembers(Set<GreetingPO> members) {
		this.members = members;
	}

	@Column
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
