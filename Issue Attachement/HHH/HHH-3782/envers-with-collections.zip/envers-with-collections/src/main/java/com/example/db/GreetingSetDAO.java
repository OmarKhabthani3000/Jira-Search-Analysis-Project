package com.example.db;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class GreetingSetDAO {

	private SessionFactory sessionFactory;

	public Long create(GreetingSetPO persistentObject) {
		Session session = sessionFactory.getCurrentSession();
		return (Long) session.save(persistentObject);
	}

	public GreetingSetPO findByName(String name) {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from GreetingSetPO where name=:name");
		query.setParameter("name", name);
		return (GreetingSetPO) query.uniqueResult();
	}

	public void deleteAll() {
		new DaoUtils<GreetingSetPO>(GreetingSetPO.class, sessionFactory).deleteAll();
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

}
