/*
 * @(#) $Id: DaoUtils.java 28951 2009-02-24 17:25:06Z danielm $
 *
 * Copyright 2009 Ontario Systems, LLC.
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS"
 * BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

package com.example.db;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;

/**
 * @author danielm
 * @version $Author: danielm $ $Revision: 28951 $ $Date: 2009-02-24 12:25:06 -0500 (Tue, 24 Feb 2009) $
 */
public class DaoUtils<PO> {

	private Class<?> poclass;
	private SessionFactory sessionFactory;

	/**
	 * @param poclass
	 * @param sessionFactory
	 */
	public DaoUtils(Class<?> poclass, SessionFactory sessionFactory) {
		this.poclass = poclass;
		this.sessionFactory = sessionFactory;
	}

	public void delete(PO item) {
		sessionFactory.getCurrentSession().delete(item);
	}

	@SuppressWarnings("unchecked")
	public List<PO> findAll() {
		Criteria crit = sessionFactory.getCurrentSession().createCriteria(poclass);
		return crit.list();
	}

	public void deleteAll() {
		List<PO> list = findAll();
		for (PO item : list) {
			delete(item);
		}
	}

}
