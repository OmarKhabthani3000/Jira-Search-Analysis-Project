package com.example.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.jboss.envers.Versioned;

@Entity
@Table
@Versioned
public class GreetingPO {

	private Long id;

	private String theGreeting;
	private GreetingSetPO greetingSet;

	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column
	public String getGreeting() {
		return theGreeting;
	}

	public void setGreeting(String greeting) {
		this.theGreeting = greeting;
	}

	@ManyToOne
	@JoinColumn
	public GreetingSetPO getGreetingSet() {
		return greetingSet;
	}

	public void setGreetingSet(GreetingSetPO greetingSet) {
		this.greetingSet = greetingSet;
	}

}
