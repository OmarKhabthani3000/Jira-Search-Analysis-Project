/*
 * @(#) $Id: RevisionEntityPO.java 28951 2009-02-24 17:25:06Z danielm $
 *
 * Copyright 2008 Ontario Systems, LLC.
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS"
 * BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
package com.example.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.jboss.envers.RevisionEntity;
import org.jboss.envers.RevisionNumber;
import org.jboss.envers.RevisionTimestamp;

/**
 * This object represents the envers revision-entity table. This table is a special table used by Envers to store information
 * about a particular database transaction. Envers has its own DefaultRevisionEntity that it will use if we don't provide one of
 * our own. We provide our own entity for several reasons. First, we may want to add additional fields in the future. Second, we
 * want to control the name of the database table and fields.
 * 
 * @author keiths
 * @author chrisel
 * @version $Author: danielm $ $Revision: 28951 $ $Date: 2009-02-24 12:25:06 -0500 (Tue, 24 Feb 2009) $
 */
@Entity
@RevisionEntity
@Table(name = "REV_ENT")
public class RevisionEntityPO {

	private Integer id;

	private Long timestamp;

	/**
	 * @see #setId(Integer)
	 */
	@Id
	@GeneratedValue
	@RevisionNumber
	@Column(name = "ID")
	public Integer getId() {
		return id;
	}

	/**
	 * This field is the primary key of the revision entity table. Envers requires the <code>@RevisionNumber</code> field to be a strictly-increasing sequence of numbers and recommends using an auto-generated
	 *                 database-assigned primary id.
	 * 
	 * @param id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @see #setTimestamp(Long)
	 */
	@RevisionTimestamp
	@Column(name = "TMSTMP")
	public Long getTimestamp() {
		return timestamp;
	}

	/**
	 * This field is the timestamp for when the revision entity record was created. This field is automatically set by envers.
	 * 
	 * @param timestamp
	 */
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

}
