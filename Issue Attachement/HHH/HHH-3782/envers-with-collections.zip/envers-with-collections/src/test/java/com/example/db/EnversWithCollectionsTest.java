package com.example.db;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bitronix.tm.TransactionManagerServices;

public class EnversWithCollectionsTest {

	private ClassPathXmlApplicationContext applicationContext;
	private GreetingDAO greetingDao;
	private GreetingSetDAO greetingSetDao;
	private static boolean firstTime = true;

	@BeforeClass
	public static void beforeClass() {
		TransactionManagerServices.getTransactionManager();
	}

	@AfterClass
	public static void afterClass() {
		if (TransactionManagerServices.isTransactionManagerRunning()) {
			TransactionManagerServices.getTransactionManager().shutdown();
		}
	}

	@Before
	public void setUp() {
		applicationContext = new ClassPathXmlApplicationContext("spring-beans.xml");
		greetingDao = (GreetingDAO) applicationContext.getBean("greetingDAO");
		greetingSetDao = (GreetingSetDAO) applicationContext.getBean("greetingSetDAO");

		if (firstTime) {
			greetingDao.deleteAll();
			greetingSetDao.deleteAll();
			firstTime = false;
		}
	}

	@After
	public void tearDown() {
		if (applicationContext != null) {
			applicationContext.close();
		}
	}

	@Test
	public void testEmptySet() {
		final String setName = "Empty set";
		assertNull(greetingSetDao.findByName(setName));

		GreetingSetPO greetingSet = new GreetingSetPO();
		greetingSet.setName(setName);
		greetingSetDao.create(greetingSet);

		assertNotNull(greetingSetDao.findByName(setName));
	}

	/**
	 * This test commits an empty greeting set, then commits a new greeting to the set. The envers versioning works.
	 */
	@Test
	public void testSimpleCreate() {
		final String greeting = "Hola";
		assertNull(greetingDao.findByGreeting(greeting));

		// Save the set first, with no greetings in it
		final String setName = "Saludos";
		GreetingSetPO greetingSet = new GreetingSetPO();
		greetingSet.setName(setName);
		greetingSetDao.create(greetingSet);

		// Pull the saved set id back from disk and save the greeting
		GreetingPO greetingPO = new GreetingPO();
		greetingPO.setGreeting(greeting);
		greetingPO.setGreetingSet(greetingSetDao.findByName(setName));
		Long greetingId = greetingDao.create(greetingPO);

		GreetingPO greetingId2 = greetingDao.findByGreeting(greeting);
		assertEquals(greetingId, greetingId2.getId());
	}

	/**
	 * This test creates a transient greeting set and a transient greeting, points them to each other, and then commits the
	 * set-with-the-greeting-in-it. This blows up.
	 */
	@Test
	public void testComplexCreate() {
		final String greeting = "Quid est nomen tibi?";
		final String setName = "Latin greetings";
		assertNull(greetingSetDao.findByName(setName));
		assertNull(greetingDao.findByGreeting(greeting));

		GreetingSetPO greetingSetPO = new GreetingSetPO();
		greetingSetPO.setName(setName);

		GreetingPO greetingPO = new GreetingPO();
		greetingPO.setGreeting(greeting);

		// Point the GreetingPO to its GreetingSetPO
		greetingPO.setGreetingSet(greetingSetPO);

		// Point the GreetingSetPO to the GreetingPO
		greetingSetPO.getMembers().add(greetingPO);

		// Create the greeting set AND the greeting it points to
		greetingDao.create(greetingPO);

		assertNotNull(greetingSetDao.findByName(setName));
		assertNotNull(greetingDao.findByGreeting(greeting));
	}

}
