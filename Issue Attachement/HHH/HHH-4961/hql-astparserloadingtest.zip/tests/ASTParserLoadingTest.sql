drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
create table Animal (id bigint not null, description varchar(255) with null, body_weight float with null, mother_id bigint with null, father_id bigint with null, zoo_id bigint with null, serialNumber varchar(255) with null, primary key (id))\p\g
create table CRAZY_ID_NODE (ID bigint not null, name varchar(255) with null, primary key (ID))\p\g
create table CRAZY_ID_TOP (ID bigint not null, name varchar(255) with null, heresAnotherCrazyIdFieldName bigint with null, primary key (ID))\p\g
create table Cat (mammal bigint not null, primary key (mammal))\p\g
create table Customer (customerId varchar(10) not null, name varchar(100) not null, address varchar(200) not null, primary key (customerId))\p\g
create table CustomerOrder (customerId varchar(10) not null, orderNumber integer not null, orderDate ansidate not null, primary key (customerId, orderNumber))\p\g
create table Dog (mammal bigint not null, primary key (mammal))\p\g
create table DomesticAnimal (mammal bigint not null, owner bigint with null, primary key (mammal))\p\g
create table HQL_COMP_CONT (ID bigint not null, STREET_ADDR varchar(255) with null, CITY_ADDR varchar(255) with null, STATE_ADDR varchar(255) with null, ZIP_CODE_ADDR integer with null, ZIP_PLUS4_ADDR integer with null, primary key (ID))\p\g
create table Human (mammal bigint not null, name_first varchar(255) with null, name_initial char(1) with null, name_last varchar(255) with null, nickName varchar(255) with null, height_centimeters float not null, intValue integer with null, floatValue float with null, bigDecimalValue decimal(19, 2) with null, bigIntegerValue decimal(19, 2) with null, primary key (mammal))\p\g
create table JOINED (ID bigint not null, joinedName varchar(255) with null, primary key (ID))\p\g
create table Joiner (id bigint not null, name varchar(255) with null, primary key (id))\p\g
create table LineItem (customerId varchar(10) not null, orderNumber integer not null, productId varchar(10) not null, quantity integer with null, primary key (customerId, orderNumber, productId))\p\g
create table Lizard (reptile bigint not null, primary key (reptile))\p\g
create table MANY_TO_MANY (IN_ID bigint not null, OUT_ID bigint not null, primary key (IN_ID, OUT_ID))\p\g
create table MARECM (MCLINK bigint not null, MCOMPR varchar(1) with null, MCOMME varchar(30) with null, primary key (MCLINK))\p\g
create table MARELO (MLMAG integer not null, MLOCA varchar(11) not null, MLINK bigint with null, MLART varchar(13) with null, MLIDO bigint with null, MLDTC timestamp(9) with time zone with null, MLTOP varchar(10) with null, MLRAG varchar(2) with null, MLROP smallint with null, MLCOM bigint with null, MATRI varchar(14) with null, SOCOD varchar(10) with null, primary key (MLMAG, MLOCA))\p\g
create table Mammal (animal bigint not null, pregnant tinyint with null, birthdate ansidate with null, mammalZoo_id bigint with null, name varchar(255) with null, primary key (animal))\p\g
create table Model (modelId varchar(32) not null, name varchar(25) not null, description varchar(200) not null, productId varchar(32) not null, primary key (modelId))\p\g
create table Product (productId varchar(10) not null, description varchar(200) not null, cost decimal(19, 2) with null, numberAvailable integer with null, primary key (productId))\p\g
create table ProductLine (productId varchar(32) not null, description varchar(200) not null, primary key (productId))\p\g
create table Reptile (animal bigint not null, bodyTemperature float with null, primary key (animal))\p\g
create table SIMPLE_1 (ID bigint not null, NAME varchar(255) with null, negated_num integer with null, primary key (ID))\p\g
create table SIMPLE_2 (ID bigint not null, NAME varchar(255) with null, SIMPLE_1_ID bigint with null, primary key (ID))\p\g
create table StateProvince (id bigint not null, name varchar(255) with null, isoCode varchar(255) with null, primary key (id))\p\g
create table T_CHAR_PROP (ID bigint not null, VAL varchar(255) not null, primary key (ID))\p\g
create table T_COMPLEX_PROP (ID bigint not null, primary key (ID))\p\g
create table T_COMPLEX_SUB_PROPS (PROP_ID bigint not null, SUB_PROP_VAL varchar(255) with null, SUB_PROP_NAME varchar(255) not null, primary key (PROP_ID, SUB_PROP_NAME))\p\g
create table T_GEN_PROPS (PROP_SET_ID bigint not null, PROP_TYPE varchar(255) with null, PROP_ID bigint with null, GEN_PROP_NAME varchar(255) not null, primary key (PROP_SET_ID, GEN_PROP_NAME))\p\g
create table T_NUM_PROP (ID bigint not null, VAL integer not null, primary key (ID))\p\g
create table T_PROP_SET (ID bigint not null, NAME varchar(255) with null, S_S_PROP_TYPE varchar(255) with null, S_S_PROP_ID bigint with null, primary key (ID))\p\g
create table VariousKeywordPropertyEntity (id bigint not null, type varchar(255) with null, value varchar(255) with null, key varchar(255) with null, entry varchar(255) with null, primary key (id))\p\g
create table Zoo (id bigint not null, zooType char(1) not null, name varchar(255) with null, classification tinyint with null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, primary key (id))\p\g
create table "User" (id bigint not null, userName varchar(255) with null, primary key (id))\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, bar_string varchar(24) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table addresses (human bigint not null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, type varchar(255) not null, primary key (human, type))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table family (human1 bigint not null, human2 bigint not null, relationship varchar(255) not null, primary key (human1, relationship))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table friends (human1 bigint not null, human2 bigint not null)\p\g
create table human_nick_names (human bigint not null, nick_name varchar(255) not null, primary key (human, nick_name))\p\g
create table image (id bigint not null, name varchar(255) with null, size_mb float with null, primary key (id))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, primary key (many_key))\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, primary key (one_key))\p\g
create table permissions (userId bigint not null, permissionName varchar(255) with null, permissionId integer not null, primary key (userId, permissionId))\p\g
alter table Animal add constraint FK752A7A1C4B485C79 foreign key (zoo_id) references Zoo\p\g
alter table Animal add constraint FK752A7A1C1F3964B4 foreign key (mother_id) references Animal\p\g
alter table Animal add constraint FK752A7A1C6309E77B foreign key (father_id) references Animal\p\g
alter table CRAZY_ID_TOP add constraint FK1AA9579F73113F33 foreign key (heresAnotherCrazyIdFieldName) references CRAZY_ID_NODE\p\g
alter table Cat add constraint FK107B66D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table CustomerOrder add constraint FKAEF781F06153C9DD foreign key (customerId) references Customer\p\g
alter table Dog add constraint FK10D1C6D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table DomesticAnimal add constraint FKE02638DA1733655F foreign key (mammal) references Mammal\p\g
alter table DomesticAnimal add constraint FKE02638DA6C03411F foreign key (owner) references Human\p\g
alter table Human add constraint FK42D710D1733655F foreign key (mammal) references Mammal\p\g
alter table JOINED add constraint FK82C23B49534E0F13 foreign key (ID) references Joiner\p\g
alter table LineItem add constraint FK4AAEE947EDAE41F3 foreign key (productId) references Product\p\g
alter table LineItem add constraint FK4AAEE947CB8F4618 foreign key (customerId, orderNumber) references CustomerOrder\p\g
alter table Lizard add constraint FK87B0E2B6EE398315 foreign key (reptile) references Reptile\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C3E0DF2A91 foreign key (OUT_ID) references SIMPLE_1\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C322C9695A foreign key (IN_ID) references SIMPLE_1\p\g
alter table MARELO add constraint FK871F728AE624DD92 foreign key (MLCOM) references MARECM\p\g
alter table Mammal add constraint FK88EF417FEFA9D699 foreign key (animal) references Animal\p\g
alter table Mammal add constraint FK88EF417FCE6EEE98 foreign key (mammalZoo_id) references Zoo\p\g
alter table Model add constraint FK4710B0921C08435 foreign key (productId) references ProductLine\p\g
alter table Reptile add constraint FKA4790CABEFA9D699 foreign key (animal) references Animal\p\g
alter table SIMPLE_2 add constraint FK4B988CE5C81DD13B foreign key (SIMPLE_1_ID) references SIMPLE_1\p\g
alter table T_COMPLEX_SUB_PROPS add constraint FK5470D25725D7CC5B foreign key (PROP_ID) references T_COMPLEX_PROP\p\g
alter table T_GEN_PROPS add constraint FK65C7C556AA2002A9 foreign key (PROP_SET_ID) references T_PROP_SET\p\g
alter table Zoo add constraint FK15FBA55106523 foreign key (state_prov_id) references StateProvince\p\g
alter table "User" add constraint FK285FEB65AF5B87 foreign key (id) references Human\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table addresses add constraint FK34207BA255106523 foreign key (state_prov_id) references StateProvince\p\g
alter table addresses add constraint FK34207BA26B9FAF99 foreign key (human) references Human\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table family add constraint FKB3985B641DCB1311 foreign key (human2) references Human\p\g
alter table family add constraint FKB3985B641DCB1310 foreign key (human1) references Human\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table friends add constraint FKDC3B49951DCB1311 foreign key (human2) references Human\p\g
alter table friends add constraint FKDC3B49951DCB1310 foreign key (human1) references Human\p\g
alter table human_nick_names add constraint FK8718E1BE6B9FAF99 foreign key (human) references Human\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table permissions add constraint FK4392F484F2810CD2 foreign key (userId) references "User"\p\g
create sequence hibernate_sequence\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end=6\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where type(animal0_.id)=6\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
create table Animal (id bigint not null, description varchar(255) with null, body_weight float with null, mother_id bigint with null, father_id bigint with null, zoo_id bigint with null, serialNumber varchar(255) with null, primary key (id))\p\g
create table CRAZY_ID_NODE (ID bigint not null, name varchar(255) with null, primary key (ID))\p\g
create table CRAZY_ID_TOP (ID bigint not null, name varchar(255) with null, heresAnotherCrazyIdFieldName bigint with null, primary key (ID))\p\g
create table Cat (mammal bigint not null, primary key (mammal))\p\g
create table Customer (customerId varchar(10) not null, name varchar(100) not null, address varchar(200) not null, primary key (customerId))\p\g
create table CustomerOrder (customerId varchar(10) not null, orderNumber integer not null, orderDate ansidate not null, primary key (customerId, orderNumber))\p\g
create table Dog (mammal bigint not null, primary key (mammal))\p\g
create table DomesticAnimal (mammal bigint not null, owner bigint with null, primary key (mammal))\p\g
create table HQL_COMP_CONT (ID bigint not null, STREET_ADDR varchar(255) with null, CITY_ADDR varchar(255) with null, STATE_ADDR varchar(255) with null, ZIP_CODE_ADDR integer with null, ZIP_PLUS4_ADDR integer with null, primary key (ID))\p\g
create table Human (mammal bigint not null, name_first varchar(255) with null, name_initial char(1) with null, name_last varchar(255) with null, nickName varchar(255) with null, height_centimeters float not null, intValue integer with null, floatValue float with null, bigDecimalValue decimal(19, 2) with null, bigIntegerValue decimal(19, 2) with null, primary key (mammal))\p\g
create table JOINED (ID bigint not null, joinedName varchar(255) with null, primary key (ID))\p\g
create table Joiner (id bigint not null, name varchar(255) with null, primary key (id))\p\g
create table LineItem (customerId varchar(10) not null, orderNumber integer not null, productId varchar(10) not null, quantity integer with null, primary key (customerId, orderNumber, productId))\p\g
create table Lizard (reptile bigint not null, primary key (reptile))\p\g
create table MANY_TO_MANY (IN_ID bigint not null, OUT_ID bigint not null, primary key (IN_ID, OUT_ID))\p\g
create table MARECM (MCLINK bigint not null, MCOMPR varchar(1) with null, MCOMME varchar(30) with null, primary key (MCLINK))\p\g
create table MARELO (MLMAG integer not null, MLOCA varchar(11) not null, MLINK bigint with null, MLART varchar(13) with null, MLIDO bigint with null, MLDTC timestamp(9) with time zone with null, MLTOP varchar(10) with null, MLRAG varchar(2) with null, MLROP smallint with null, MLCOM bigint with null, MATRI varchar(14) with null, SOCOD varchar(10) with null, primary key (MLMAG, MLOCA))\p\g
create table Mammal (animal bigint not null, pregnant tinyint with null, birthdate ansidate with null, mammalZoo_id bigint with null, name varchar(255) with null, primary key (animal))\p\g
create table Model (modelId varchar(32) not null, name varchar(25) not null, description varchar(200) not null, productId varchar(32) not null, primary key (modelId))\p\g
create table Product (productId varchar(10) not null, description varchar(200) not null, cost decimal(19, 2) with null, numberAvailable integer with null, primary key (productId))\p\g
create table ProductLine (productId varchar(32) not null, description varchar(200) not null, primary key (productId))\p\g
create table Reptile (animal bigint not null, bodyTemperature float with null, primary key (animal))\p\g
create table SIMPLE_1 (ID bigint not null, NAME varchar(255) with null, negated_num integer with null, primary key (ID))\p\g
create table SIMPLE_2 (ID bigint not null, NAME varchar(255) with null, SIMPLE_1_ID bigint with null, primary key (ID))\p\g
create table StateProvince (id bigint not null, name varchar(255) with null, isoCode varchar(255) with null, primary key (id))\p\g
create table T_CHAR_PROP (ID bigint not null, VAL varchar(255) not null, primary key (ID))\p\g
create table T_COMPLEX_PROP (ID bigint not null, primary key (ID))\p\g
create table T_COMPLEX_SUB_PROPS (PROP_ID bigint not null, SUB_PROP_VAL varchar(255) with null, SUB_PROP_NAME varchar(255) not null, primary key (PROP_ID, SUB_PROP_NAME))\p\g
create table T_GEN_PROPS (PROP_SET_ID bigint not null, PROP_TYPE varchar(255) with null, PROP_ID bigint with null, GEN_PROP_NAME varchar(255) not null, primary key (PROP_SET_ID, GEN_PROP_NAME))\p\g
create table T_NUM_PROP (ID bigint not null, VAL integer not null, primary key (ID))\p\g
create table T_PROP_SET (ID bigint not null, NAME varchar(255) with null, S_S_PROP_TYPE varchar(255) with null, S_S_PROP_ID bigint with null, primary key (ID))\p\g
create table VariousKeywordPropertyEntity (id bigint not null, type varchar(255) with null, value varchar(255) with null, key varchar(255) with null, entry varchar(255) with null, primary key (id))\p\g
create table Zoo (id bigint not null, zooType char(1) not null, name varchar(255) with null, classification tinyint with null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, primary key (id))\p\g
create table "User" (id bigint not null, userName varchar(255) with null, primary key (id))\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, bar_string varchar(24) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table addresses (human bigint not null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, type varchar(255) not null, primary key (human, type))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table family (human1 bigint not null, human2 bigint not null, relationship varchar(255) not null, primary key (human1, relationship))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table friends (human1 bigint not null, human2 bigint not null)\p\g
create table human_nick_names (human bigint not null, nick_name varchar(255) not null, primary key (human, nick_name))\p\g
create table image (id bigint not null, name varchar(255) with null, size_mb float with null, primary key (id))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, primary key (many_key))\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, primary key (one_key))\p\g
create table permissions (userId bigint not null, permissionName varchar(255) with null, permissionId integer not null, primary key (userId, permissionId))\p\g
alter table Animal add constraint FK752A7A1C4B485C79 foreign key (zoo_id) references Zoo\p\g
alter table Animal add constraint FK752A7A1C1F3964B4 foreign key (mother_id) references Animal\p\g
alter table Animal add constraint FK752A7A1C6309E77B foreign key (father_id) references Animal\p\g
alter table CRAZY_ID_TOP add constraint FK1AA9579F73113F33 foreign key (heresAnotherCrazyIdFieldName) references CRAZY_ID_NODE\p\g
alter table Cat add constraint FK107B66D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table CustomerOrder add constraint FKAEF781F06153C9DD foreign key (customerId) references Customer\p\g
alter table Dog add constraint FK10D1C6D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table DomesticAnimal add constraint FKE02638DA1733655F foreign key (mammal) references Mammal\p\g
alter table DomesticAnimal add constraint FKE02638DA6C03411F foreign key (owner) references Human\p\g
alter table Human add constraint FK42D710D1733655F foreign key (mammal) references Mammal\p\g
alter table JOINED add constraint FK82C23B49534E0F13 foreign key (ID) references Joiner\p\g
alter table LineItem add constraint FK4AAEE947EDAE41F3 foreign key (productId) references Product\p\g
alter table LineItem add constraint FK4AAEE947CB8F4618 foreign key (customerId, orderNumber) references CustomerOrder\p\g
alter table Lizard add constraint FK87B0E2B6EE398315 foreign key (reptile) references Reptile\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C3E0DF2A91 foreign key (OUT_ID) references SIMPLE_1\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C322C9695A foreign key (IN_ID) references SIMPLE_1\p\g
alter table MARELO add constraint FK871F728AE624DD92 foreign key (MLCOM) references MARECM\p\g
alter table Mammal add constraint FK88EF417FEFA9D699 foreign key (animal) references Animal\p\g
alter table Mammal add constraint FK88EF417FCE6EEE98 foreign key (mammalZoo_id) references Zoo\p\g
alter table Model add constraint FK4710B0921C08435 foreign key (productId) references ProductLine\p\g
alter table Reptile add constraint FKA4790CABEFA9D699 foreign key (animal) references Animal\p\g
alter table SIMPLE_2 add constraint FK4B988CE5C81DD13B foreign key (SIMPLE_1_ID) references SIMPLE_1\p\g
alter table T_COMPLEX_SUB_PROPS add constraint FK5470D25725D7CC5B foreign key (PROP_ID) references T_COMPLEX_PROP\p\g
alter table T_GEN_PROPS add constraint FK65C7C556AA2002A9 foreign key (PROP_SET_ID) references T_PROP_SET\p\g
alter table Zoo add constraint FK15FBA55106523 foreign key (state_prov_id) references StateProvince\p\g
alter table "User" add constraint FK285FEB65AF5B87 foreign key (id) references Human\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table addresses add constraint FK34207BA255106523 foreign key (state_prov_id) references StateProvince\p\g
alter table addresses add constraint FK34207BA26B9FAF99 foreign key (human) references Human\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table family add constraint FKB3985B641DCB1311 foreign key (human2) references Human\p\g
alter table family add constraint FKB3985B641DCB1310 foreign key (human1) references Human\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table friends add constraint FKDC3B49951DCB1311 foreign key (human2) references Human\p\g
alter table friends add constraint FKDC3B49951DCB1310 foreign key (human1) references Human\p\g
alter table human_nick_names add constraint FK8718E1BE6B9FAF99 foreign key (human) references Human\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table permissions add constraint FK4392F484F2810CD2 foreign key (userId) references "User"\p\g
create sequence hibernate_sequence\p\g
select max(ID) from HQL_COMP_CONT\p\g
insert into HQL_COMP_CONT (STREET_ADDR, CITY_ADDR, STATE_ADDR, ZIP_CODE_ADDR, ZIP_PLUS4_ADDR, ID) values ('123 Main', 'Anywhere', 'USA', 12345, 6789, 1)\p\g
select componentc0_.STREET_ADDR as col_0_0_, componentc0_.CITY_ADDR as col_0_1_, componentc0_.STATE_ADDR as col_0_2_, componentc0_.ZIP_CODE_ADDR as col_0_3_, componentc0_.ZIP_PLUS4_ADDR as col_0_4_ from HQL_COMP_CONT componentc0_\p\g
select componentc0_.ZIP_CODE_ADDR as col_0_0_, componentc0_.ZIP_PLUS4_ADDR as col_0_1_ from HQL_COMP_CONT componentc0_\p\g
select componentc0_.ZIP_CODE_ADDR as col_0_0_, componentc0_.ZIP_PLUS4_ADDR as col_0_1_ from HQL_COMP_CONT componentc0_\p\g
select componentc0_.ZIP_CODE_ADDR as col_0_0_ from HQL_COMP_CONT componentc0_\p\g
delete from HQL_COMP_CONT where ID=1\p\g
select variouskey0_.id as id31_, variouskey0_.type as type31_, variouskey0_.value as value31_, variouskey0_.key as key31_, variouskey0_.entry as entry31_ from VariousKeywordPropertyEntity variouskey0_ where variouskey0_.type=''something''\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
create table Animal (id bigint not null, description varchar(255) with null, body_weight float with null, mother_id bigint with null, father_id bigint with null, zoo_id bigint with null, serialNumber varchar(255) with null, primary key (id))\p\g
create table CRAZY_ID_NODE (ID bigint not null, name varchar(255) with null, primary key (ID))\p\g
create table CRAZY_ID_TOP (ID bigint not null, name varchar(255) with null, heresAnotherCrazyIdFieldName bigint with null, primary key (ID))\p\g
create table Cat (mammal bigint not null, primary key (mammal))\p\g
create table Customer (customerId varchar(10) not null, name varchar(100) not null, address varchar(200) not null, primary key (customerId))\p\g
create table CustomerOrder (customerId varchar(10) not null, orderNumber integer not null, orderDate ansidate not null, primary key (customerId, orderNumber))\p\g
create table Dog (mammal bigint not null, primary key (mammal))\p\g
create table DomesticAnimal (mammal bigint not null, owner bigint with null, primary key (mammal))\p\g
create table HQL_COMP_CONT (ID bigint not null, STREET_ADDR varchar(255) with null, CITY_ADDR varchar(255) with null, STATE_ADDR varchar(255) with null, ZIP_CODE_ADDR integer with null, ZIP_PLUS4_ADDR integer with null, primary key (ID))\p\g
create table Human (mammal bigint not null, name_first varchar(255) with null, name_initial char(1) with null, name_last varchar(255) with null, nickName varchar(255) with null, height_centimeters float not null, intValue integer with null, floatValue float with null, bigDecimalValue decimal(19, 2) with null, bigIntegerValue decimal(19, 2) with null, primary key (mammal))\p\g
create table JOINED (ID bigint not null, joinedName varchar(255) with null, primary key (ID))\p\g
create table Joiner (id bigint not null, name varchar(255) with null, primary key (id))\p\g
create table LineItem (customerId varchar(10) not null, orderNumber integer not null, productId varchar(10) not null, quantity integer with null, primary key (customerId, orderNumber, productId))\p\g
create table Lizard (reptile bigint not null, primary key (reptile))\p\g
create table MANY_TO_MANY (IN_ID bigint not null, OUT_ID bigint not null, primary key (IN_ID, OUT_ID))\p\g
create table MARECM (MCLINK bigint not null, MCOMPR varchar(1) with null, MCOMME varchar(30) with null, primary key (MCLINK))\p\g
create table MARELO (MLMAG integer not null, MLOCA varchar(11) not null, MLINK bigint with null, MLART varchar(13) with null, MLIDO bigint with null, MLDTC timestamp(9) with time zone with null, MLTOP varchar(10) with null, MLRAG varchar(2) with null, MLROP smallint with null, MLCOM bigint with null, MATRI varchar(14) with null, SOCOD varchar(10) with null, primary key (MLMAG, MLOCA))\p\g
create table Mammal (animal bigint not null, pregnant tinyint with null, birthdate ansidate with null, mammalZoo_id bigint with null, name varchar(255) with null, primary key (animal))\p\g
create table Model (modelId varchar(32) not null, name varchar(25) not null, description varchar(200) not null, productId varchar(32) not null, primary key (modelId))\p\g
create table Product (productId varchar(10) not null, description varchar(200) not null, cost decimal(19, 2) with null, numberAvailable integer with null, primary key (productId))\p\g
create table ProductLine (productId varchar(32) not null, description varchar(200) not null, primary key (productId))\p\g
create table Reptile (animal bigint not null, bodyTemperature float with null, primary key (animal))\p\g
create table SIMPLE_1 (ID bigint not null, NAME varchar(255) with null, negated_num integer with null, primary key (ID))\p\g
create table SIMPLE_2 (ID bigint not null, NAME varchar(255) with null, SIMPLE_1_ID bigint with null, primary key (ID))\p\g
create table StateProvince (id bigint not null, name varchar(255) with null, isoCode varchar(255) with null, primary key (id))\p\g
create table T_CHAR_PROP (ID bigint not null, VAL varchar(255) not null, primary key (ID))\p\g
create table T_COMPLEX_PROP (ID bigint not null, primary key (ID))\p\g
create table T_COMPLEX_SUB_PROPS (PROP_ID bigint not null, SUB_PROP_VAL varchar(255) with null, SUB_PROP_NAME varchar(255) not null, primary key (PROP_ID, SUB_PROP_NAME))\p\g
create table T_GEN_PROPS (PROP_SET_ID bigint not null, PROP_TYPE varchar(255) with null, PROP_ID bigint with null, GEN_PROP_NAME varchar(255) not null, primary key (PROP_SET_ID, GEN_PROP_NAME))\p\g
create table T_NUM_PROP (ID bigint not null, VAL integer not null, primary key (ID))\p\g
create table T_PROP_SET (ID bigint not null, NAME varchar(255) with null, S_S_PROP_TYPE varchar(255) with null, S_S_PROP_ID bigint with null, primary key (ID))\p\g
create table VariousKeywordPropertyEntity (id bigint not null, type varchar(255) with null, value varchar(255) with null, key varchar(255) with null, entry varchar(255) with null, primary key (id))\p\g
create table Zoo (id bigint not null, zooType char(1) not null, name varchar(255) with null, classification tinyint with null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, primary key (id))\p\g
create table "User" (id bigint not null, userName varchar(255) with null, primary key (id))\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, bar_string varchar(24) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table addresses (human bigint not null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, type varchar(255) not null, primary key (human, type))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table family (human1 bigint not null, human2 bigint not null, relationship varchar(255) not null, primary key (human1, relationship))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table friends (human1 bigint not null, human2 bigint not null)\p\g
create table human_nick_names (human bigint not null, nick_name varchar(255) not null, primary key (human, nick_name))\p\g
create table image (id bigint not null, name varchar(255) with null, size_mb float with null, primary key (id))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, primary key (many_key))\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, primary key (one_key))\p\g
create table permissions (userId bigint not null, permissionName varchar(255) with null, permissionId integer not null, primary key (userId, permissionId))\p\g
alter table Animal add constraint FK752A7A1C4B485C79 foreign key (zoo_id) references Zoo\p\g
alter table Animal add constraint FK752A7A1C1F3964B4 foreign key (mother_id) references Animal\p\g
alter table Animal add constraint FK752A7A1C6309E77B foreign key (father_id) references Animal\p\g
alter table CRAZY_ID_TOP add constraint FK1AA9579F73113F33 foreign key (heresAnotherCrazyIdFieldName) references CRAZY_ID_NODE\p\g
alter table Cat add constraint FK107B66D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table CustomerOrder add constraint FKAEF781F06153C9DD foreign key (customerId) references Customer\p\g
alter table Dog add constraint FK10D1C6D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table DomesticAnimal add constraint FKE02638DA1733655F foreign key (mammal) references Mammal\p\g
alter table DomesticAnimal add constraint FKE02638DA6C03411F foreign key (owner) references Human\p\g
alter table Human add constraint FK42D710D1733655F foreign key (mammal) references Mammal\p\g
alter table JOINED add constraint FK82C23B49534E0F13 foreign key (ID) references Joiner\p\g
alter table LineItem add constraint FK4AAEE947EDAE41F3 foreign key (productId) references Product\p\g
alter table LineItem add constraint FK4AAEE947CB8F4618 foreign key (customerId, orderNumber) references CustomerOrder\p\g
alter table Lizard add constraint FK87B0E2B6EE398315 foreign key (reptile) references Reptile\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C3E0DF2A91 foreign key (OUT_ID) references SIMPLE_1\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C322C9695A foreign key (IN_ID) references SIMPLE_1\p\g
alter table MARELO add constraint FK871F728AE624DD92 foreign key (MLCOM) references MARECM\p\g
alter table Mammal add constraint FK88EF417FEFA9D699 foreign key (animal) references Animal\p\g
alter table Mammal add constraint FK88EF417FCE6EEE98 foreign key (mammalZoo_id) references Zoo\p\g
alter table Model add constraint FK4710B0921C08435 foreign key (productId) references ProductLine\p\g
alter table Reptile add constraint FKA4790CABEFA9D699 foreign key (animal) references Animal\p\g
alter table SIMPLE_2 add constraint FK4B988CE5C81DD13B foreign key (SIMPLE_1_ID) references SIMPLE_1\p\g
alter table T_COMPLEX_SUB_PROPS add constraint FK5470D25725D7CC5B foreign key (PROP_ID) references T_COMPLEX_PROP\p\g
alter table T_GEN_PROPS add constraint FK65C7C556AA2002A9 foreign key (PROP_SET_ID) references T_PROP_SET\p\g
alter table Zoo add constraint FK15FBA55106523 foreign key (state_prov_id) references StateProvince\p\g
alter table "User" add constraint FK285FEB65AF5B87 foreign key (id) references Human\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table addresses add constraint FK34207BA255106523 foreign key (state_prov_id) references StateProvince\p\g
alter table addresses add constraint FK34207BA26B9FAF99 foreign key (human) references Human\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table family add constraint FKB3985B641DCB1311 foreign key (human2) references Human\p\g
alter table family add constraint FKB3985B641DCB1310 foreign key (human1) references Human\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table friends add constraint FKDC3B49951DCB1311 foreign key (human2) references Human\p\g
alter table friends add constraint FKDC3B49951DCB1310 foreign key (human1) references Human\p\g
alter table human_nick_names add constraint FK8718E1BE6B9FAF99 foreign key (human) references Human\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table permissions add constraint FK4392F484F2810CD2 foreign key (userId) references "User"\p\g
create sequence hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 0.0, null, null, null, null, 1)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 1)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('Joe', null, 'Ebersole', null, 0.0 * 2.54, 0, 0.0, null, null, 1)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 0.0, null, null, null, null, 2)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 2)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values (null, null, null, null, 0.0 * 2.54, 0, 0.0, null, null, 2)\p\g
insert into family (human1, relationship, human2) values (1, 'son', 2)\p\g
select family1_.relationship as col_0_0_, family1_.human2 as col_1_0_, human2_2_.description as col_1_1_, human2_2_.body_weight as col_1_2_, human2_2_.mother_id as col_1_3_, human2_2_.father_id as col_1_4_, human2_2_.zoo_id as col_1_5_, human2_2_.serialNumber as col_1_6_, human2_1_.pregnant as col_1_7_, human2_1_.birthdate as col_1_8_, human2_.name_first as col_1_9_, human2_.name_initial as col_1_10_, human2_.name_last as col_1_11_, human2_.nickName as col_1_12_, human2_.height_centimeters / 2.54 as col_1_13_, human2_.intValue as col_1_14_, human2_.floatValue as col_1_15_, human2_.bigDecimalValue as col_1_16_, human2_.bigIntegerValue as col_1_17_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id, family family1_, Human human2_ inner join Mammal human2_1_ on human2_.mammal=human2_1_.animal inner join Animal human2_2_ on human2_.mammal=human2_2_.id where human0_.mammal=family1_.human1 and family1_.human2=human2_.mammal\p\g
select human0_.mammal as id0_0_, human0_2_.description as descript2_0_0_, human0_2_.body_weight as body3_0_0_, human0_2_.mother_id as mother4_0_0_, human0_2_.father_id as father5_0_0_, human0_2_.zoo_id as zoo6_0_0_, human0_2_.serialNumber as serialNu7_0_0_, human0_1_.pregnant as pregnant3_0_, human0_1_.birthdate as birthdate3_0_, human0_.name_first as name2_7_0_, human0_.name_initial as name3_7_0_, human0_.name_last as name4_7_0_, human0_.nickName as nickName7_0_, human0_.height_centimeters / 2.54 as height6_7_0_, human0_.intValue as intValue7_0_, human0_.floatValue as floatValue7_0_, human0_.bigDecimalValue as bigDecim9_7_0_, human0_.bigIntegerValue as bigInte10_7_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where human0_.mammal=2\p\g
select nicknames0_.human as human0_, nicknames0_.nick_name as nick2_0_ from human_nick_names nicknames0_ where nicknames0_.human=2\p\g
select distinct relationship as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id, family family1_, Human human2_ inner join Mammal human2_1_ on human2_.mammal=human2_1_.animal inner join Animal human2_2_ on human2_.mammal=human2_2_.id where human0_.mammal=family1_.human1 and family1_.human2=human2_.mammal\p\g
update Animal set mother_id=null where mother_id=1\p\g
delete from friends where human1=1\p\g
delete from human_nick_names where human=1\p\g
delete from addresses where human=1\p\g
update Animal set mother_id=null where mother_id=2\p\g
delete from friends where human1=2\p\g
delete from family where human1=2\p\g
delete from human_nick_names where human=2\p\g
delete from addresses where human=2\p\g
delete from family where human1=1\p\g
delete from Human where mammal=1\p\g
delete from Mammal where animal=1\p\g
delete from Animal where id=1\p\g
delete from Human where mammal=2\p\g
delete from Mammal where animal=2\p\g
delete from Animal where id=2\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 0.0, null, null, null, null, 3)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 3)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('Steve', null, 'Ebersole', null, 0.0 * 2.54, 0, 0.0, null, null, 3)\p\g
select customer0_.customerId as customerId34_, customer0_.name as name34_, customer0_.address as address34_ from Customer customer0_\p\g
select many0_.many_key as many1_23_, many0_.x as x23_ from many many0_\p\g
select morecrazyi0_.ID as ID28_, morecrazyi0_.name as name28_, morecrazyi0_.heresAnotherCrazyIdFieldName as heresAno3_28_ from CRAZY_ID_TOP morecrazyi0_\p\g
select integerpro0_.ID as ID41_, integerpro0_.VAL as VAL41_ from T_NUM_PROP integerpro0_\p\g
select joiner0_.id as id16_, joiner0_.name as name16_, joiner0_1_.joinedName as joinedName17_ from Joiner joiner0_ inner join JOINED joiner0_1_ on joiner0_.id=joiner0_1_.ID\p\g
select simpleenti0_.ID as ID24_, simpleenti0_.NAME as NAME24_, -simpleenti0_.negated_num as negated3_24_ from SIMPLE_1 simpleenti0_\p\g
select propertyse0_.ID as ID38_, propertyse0_.NAME as NAME38_, propertyse0_.S_S_PROP_TYPE as S3_38_, propertyse0_.S_S_PROP_ID as S4_38_ from T_PROP_SET propertyse0_\p\g
select productlin0_.productId as productId32_, productlin0_.description as descript2_32_ from ProductLine productlin0_\p\g
select user0_.id as id12_, userName as userName12_ from "User" user0_\p\g
select stateprovi0_.id as id15_, stateprovi0_.name as name15_, stateprovi0_.isoCode as isoCode15_ from StateProvince stateprovi0_\p\g
select product0_.productId as productId37_, product0_.description as descript2_37_, product0_.cost as cost37_, product0_.numberAvailable as numberAv4_37_, ( select sum(li.quantity) from LineItem li where li.productId = product0_.productId ) as formula2_ from Product product0_\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
create table Animal (id bigint not null, description varchar(255) with null, body_weight float with null, mother_id bigint with null, father_id bigint with null, zoo_id bigint with null, serialNumber varchar(255) with null, primary key (id))\p\g
create table CRAZY_ID_NODE (ID bigint not null, name varchar(255) with null, primary key (ID))\p\g
create table CRAZY_ID_TOP (ID bigint not null, name varchar(255) with null, heresAnotherCrazyIdFieldName bigint with null, primary key (ID))\p\g
create table Cat (mammal bigint not null, primary key (mammal))\p\g
create table Customer (customerId varchar(10) not null, name varchar(100) not null, address varchar(200) not null, primary key (customerId))\p\g
create table CustomerOrder (customerId varchar(10) not null, orderNumber integer not null, orderDate ansidate not null, primary key (customerId, orderNumber))\p\g
create table Dog (mammal bigint not null, primary key (mammal))\p\g
create table DomesticAnimal (mammal bigint not null, owner bigint with null, primary key (mammal))\p\g
create table HQL_COMP_CONT (ID bigint not null, STREET_ADDR varchar(255) with null, CITY_ADDR varchar(255) with null, STATE_ADDR varchar(255) with null, ZIP_CODE_ADDR integer with null, ZIP_PLUS4_ADDR integer with null, primary key (ID))\p\g
create table Human (mammal bigint not null, name_first varchar(255) with null, name_initial char(1) with null, name_last varchar(255) with null, nickName varchar(255) with null, height_centimeters float not null, intValue integer with null, floatValue float with null, bigDecimalValue decimal(19, 2) with null, bigIntegerValue decimal(19, 2) with null, primary key (mammal))\p\g
create table JOINED (ID bigint not null, joinedName varchar(255) with null, primary key (ID))\p\g
create table Joiner (id bigint not null, name varchar(255) with null, primary key (id))\p\g
create table LineItem (customerId varchar(10) not null, orderNumber integer not null, productId varchar(10) not null, quantity integer with null, primary key (customerId, orderNumber, productId))\p\g
create table Lizard (reptile bigint not null, primary key (reptile))\p\g
create table MANY_TO_MANY (IN_ID bigint not null, OUT_ID bigint not null, primary key (IN_ID, OUT_ID))\p\g
create table MARECM (MCLINK bigint not null, MCOMPR varchar(1) with null, MCOMME varchar(30) with null, primary key (MCLINK))\p\g
create table MARELO (MLMAG integer not null, MLOCA varchar(11) not null, MLINK bigint with null, MLART varchar(13) with null, MLIDO bigint with null, MLDTC timestamp(9) with time zone with null, MLTOP varchar(10) with null, MLRAG varchar(2) with null, MLROP smallint with null, MLCOM bigint with null, MATRI varchar(14) with null, SOCOD varchar(10) with null, primary key (MLMAG, MLOCA))\p\g
create table Mammal (animal bigint not null, pregnant tinyint with null, birthdate ansidate with null, mammalZoo_id bigint with null, name varchar(255) with null, primary key (animal))\p\g
create table Model (modelId varchar(32) not null, name varchar(25) not null, description varchar(200) not null, productId varchar(32) not null, primary key (modelId))\p\g
create table Product (productId varchar(10) not null, description varchar(200) not null, cost decimal(19, 2) with null, numberAvailable integer with null, primary key (productId))\p\g
create table ProductLine (productId varchar(32) not null, description varchar(200) not null, primary key (productId))\p\g
create table Reptile (animal bigint not null, bodyTemperature float with null, primary key (animal))\p\g
create table SIMPLE_1 (ID bigint not null, NAME varchar(255) with null, negated_num integer with null, primary key (ID))\p\g
create table SIMPLE_2 (ID bigint not null, NAME varchar(255) with null, SIMPLE_1_ID bigint with null, primary key (ID))\p\g
create table StateProvince (id bigint not null, name varchar(255) with null, isoCode varchar(255) with null, primary key (id))\p\g
create table T_CHAR_PROP (ID bigint not null, VAL varchar(255) not null, primary key (ID))\p\g
create table T_COMPLEX_PROP (ID bigint not null, primary key (ID))\p\g
create table T_COMPLEX_SUB_PROPS (PROP_ID bigint not null, SUB_PROP_VAL varchar(255) with null, SUB_PROP_NAME varchar(255) not null, primary key (PROP_ID, SUB_PROP_NAME))\p\g
create table T_GEN_PROPS (PROP_SET_ID bigint not null, PROP_TYPE varchar(255) with null, PROP_ID bigint with null, GEN_PROP_NAME varchar(255) not null, primary key (PROP_SET_ID, GEN_PROP_NAME))\p\g
create table T_NUM_PROP (ID bigint not null, VAL integer not null, primary key (ID))\p\g
create table T_PROP_SET (ID bigint not null, NAME varchar(255) with null, S_S_PROP_TYPE varchar(255) with null, S_S_PROP_ID bigint with null, primary key (ID))\p\g
create table VariousKeywordPropertyEntity (id bigint not null, type varchar(255) with null, value varchar(255) with null, key varchar(255) with null, entry varchar(255) with null, primary key (id))\p\g
create table Zoo (id bigint not null, zooType char(1) not null, name varchar(255) with null, classification tinyint with null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, primary key (id))\p\g
create table "User" (id bigint not null, userName varchar(255) with null, primary key (id))\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, bar_string varchar(24) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table addresses (human bigint not null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, type varchar(255) not null, primary key (human, type))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table family (human1 bigint not null, human2 bigint not null, relationship varchar(255) not null, primary key (human1, relationship))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table friends (human1 bigint not null, human2 bigint not null)\p\g
create table human_nick_names (human bigint not null, nick_name varchar(255) not null, primary key (human, nick_name))\p\g
create table image (id bigint not null, name varchar(255) with null, size_mb float with null, primary key (id))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, primary key (many_key))\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, primary key (one_key))\p\g
create table permissions (userId bigint not null, permissionName varchar(255) with null, permissionId integer not null, primary key (userId, permissionId))\p\g
alter table Animal add constraint FK752A7A1C4B485C79 foreign key (zoo_id) references Zoo\p\g
alter table Animal add constraint FK752A7A1C1F3964B4 foreign key (mother_id) references Animal\p\g
alter table Animal add constraint FK752A7A1C6309E77B foreign key (father_id) references Animal\p\g
alter table CRAZY_ID_TOP add constraint FK1AA9579F73113F33 foreign key (heresAnotherCrazyIdFieldName) references CRAZY_ID_NODE\p\g
alter table Cat add constraint FK107B66D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table CustomerOrder add constraint FKAEF781F06153C9DD foreign key (customerId) references Customer\p\g
alter table Dog add constraint FK10D1C6D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table DomesticAnimal add constraint FKE02638DA1733655F foreign key (mammal) references Mammal\p\g
alter table DomesticAnimal add constraint FKE02638DA6C03411F foreign key (owner) references Human\p\g
alter table Human add constraint FK42D710D1733655F foreign key (mammal) references Mammal\p\g
alter table JOINED add constraint FK82C23B49534E0F13 foreign key (ID) references Joiner\p\g
alter table LineItem add constraint FK4AAEE947EDAE41F3 foreign key (productId) references Product\p\g
alter table LineItem add constraint FK4AAEE947CB8F4618 foreign key (customerId, orderNumber) references CustomerOrder\p\g
alter table Lizard add constraint FK87B0E2B6EE398315 foreign key (reptile) references Reptile\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C3E0DF2A91 foreign key (OUT_ID) references SIMPLE_1\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C322C9695A foreign key (IN_ID) references SIMPLE_1\p\g
alter table MARELO add constraint FK871F728AE624DD92 foreign key (MLCOM) references MARECM\p\g
alter table Mammal add constraint FK88EF417FEFA9D699 foreign key (animal) references Animal\p\g
alter table Mammal add constraint FK88EF417FCE6EEE98 foreign key (mammalZoo_id) references Zoo\p\g
alter table Model add constraint FK4710B0921C08435 foreign key (productId) references ProductLine\p\g
alter table Reptile add constraint FKA4790CABEFA9D699 foreign key (animal) references Animal\p\g
alter table SIMPLE_2 add constraint FK4B988CE5C81DD13B foreign key (SIMPLE_1_ID) references SIMPLE_1\p\g
alter table T_COMPLEX_SUB_PROPS add constraint FK5470D25725D7CC5B foreign key (PROP_ID) references T_COMPLEX_PROP\p\g
alter table T_GEN_PROPS add constraint FK65C7C556AA2002A9 foreign key (PROP_SET_ID) references T_PROP_SET\p\g
alter table Zoo add constraint FK15FBA55106523 foreign key (state_prov_id) references StateProvince\p\g
alter table "User" add constraint FK285FEB65AF5B87 foreign key (id) references Human\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table addresses add constraint FK34207BA255106523 foreign key (state_prov_id) references StateProvince\p\g
alter table addresses add constraint FK34207BA26B9FAF99 foreign key (human) references Human\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table family add constraint FKB3985B641DCB1311 foreign key (human2) references Human\p\g
alter table family add constraint FKB3985B641DCB1310 foreign key (human1) references Human\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table friends add constraint FKDC3B49951DCB1311 foreign key (human2) references Human\p\g
alter table friends add constraint FKDC3B49951DCB1310 foreign key (human1) references Human\p\g
alter table human_nick_names add constraint FK8718E1BE6B9FAF99 foreign key (human) references Human\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table permissions add constraint FK4392F484F2810CD2 foreign key (userId) references "User"\p\g
create sequence hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 0.0, null, null, null, null, 1)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 1)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('Johnny', 'B', 'Goode', null, 0.0 * 2.54, 0, 0.0, null, null, 1)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 0.0, null, null, null, null, 2)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 2)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('Steve', null, 'Ebersole', null, 0.0 * 2.54, 0, 0.0, null, null, 2)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 0.0, null, null, null, null, 3)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 3)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('Bono', null, null, null, 0.0 * 2.54, 0, 0.0, null, null, 3)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 0.0, null, null, null, null, 4)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 4)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values (null, null, null, null, 0.0 * 2.54, 0, 0.0, null, null, 4)\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where (human0_.name_first is null) and (human0_.name_initial is null) and (human0_.name_last is null)\p\g
select nicknames0_.human as human0_, nicknames0_.nick_name as nick2_0_ from human_nick_names nicknames0_ where nicknames0_.human=4\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where human0_.name_first is not null or human0_.name_initial is not null or human0_.name_last is not null\p\g
select nicknames0_.human as human0_, nicknames0_.nick_name as nick2_0_ from human_nick_names nicknames0_ where nicknames0_.human=3\p\g
select nicknames0_.human as human0_, nicknames0_.nick_name as nick2_0_ from human_nick_names nicknames0_ where nicknames0_.human=2\p\g
select nicknames0_.human as human0_, nicknames0_.nick_name as nick2_0_ from human_nick_names nicknames0_ where nicknames0_.human=1\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where null is null\p\g
declare global temporary table session.HT_Human (mammal bigint not null) on commit preserve rows with norecovery\p\g
insert into session.HT_Human select human0_.mammal as mammal from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
delete from Human where (mammal) IN (select mammal from session.HT_Human)\p\g
delete from Mammal where (animal) IN (select mammal from session.HT_Human)\p\g
delete from Animal where (id) IN (select mammal from session.HT_Human)\p\g
drop table session.HT_Human\p\g
select animal0_.id as id0_0_, offspring1_.id as id0_1_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_, offspring1_.description as descript2_0_1_, offspring1_.body_weight as body3_0_1_, offspring1_.mother_id as mother4_0_1_, offspring1_.father_id as father5_0_1_, offspring1_.zoo_id as zoo6_0_1_, offspring1_.serialNumber as serialNu7_0_1_, offspring1_1_.bodyTemperature as bodyTemp2_1_1_, offspring1_3_.pregnant as pregnant3_1_, offspring1_3_.birthdate as birthdate3_1_, offspring1_4_.owner as owner4_1_, offspring1_7_.name_first as name2_7_1_, offspring1_7_.name_initial as name3_7_1_, offspring1_7_.name_last as name4_7_1_, offspring1_7_.nickName as nickName7_1_, offspring1_7_.height_centimeters / 2.54 as height6_7_1_, offspring1_7_.intValue as intValue7_1_, offspring1_7_.floatValue as floatValue7_1_, offspring1_7_.bigDecimalValue as bigDecim9_7_1_, offspring1_7_.bigIntegerValue as bigInte10_7_1_, case when offspring1_2_.reptile is not null then 2 when offspring1_5_.mammal is not null then 5 when offspring1_6_.mammal is not null then 6 when offspring1_4_.mammal is not null then 4 when offspring1_7_.mammal is not null then 7 when offspring1_1_.animal is not null then 1 when offspring1_3_.animal is not null then 3 when offspring1_.id is not null then 0 end as clazz_1_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal inner join Animal offspring1_ on animal0_.id=offspring1_.mother_id left outer join Reptile offspring1_1_ on offspring1_.id=offspring1_1_.animal left outer join Lizard offspring1_2_ on offspring1_.id=offspring1_2_.reptile left outer join Mammal offspring1_3_ on offspring1_.id=offspring1_3_.animal left outer join DomesticAnimal offspring1_4_ on offspring1_.id=offspring1_4_.mammal left outer join Cat offspring1_5_ on offspring1_.id=offspring1_5_.mammal left outer join Dog offspring1_6_ on offspring1_.id=offspring1_6_.mammal left outer join Human offspring1_7_ on offspring1_.id=offspring1_7_.mammal where offspring1_.description=''xyz''\p\g
select animal0_.id as id0_0_, offspring1_.id as id0_1_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_, offspring1_.description as descript2_0_1_, offspring1_.body_weight as body3_0_1_, offspring1_.mother_id as mother4_0_1_, offspring1_.father_id as father5_0_1_, offspring1_.zoo_id as zoo6_0_1_, offspring1_.serialNumber as serialNu7_0_1_, offspring1_1_.bodyTemperature as bodyTemp2_1_1_, offspring1_3_.pregnant as pregnant3_1_, offspring1_3_.birthdate as birthdate3_1_, offspring1_4_.owner as owner4_1_, offspring1_7_.name_first as name2_7_1_, offspring1_7_.name_initial as name3_7_1_, offspring1_7_.name_last as name4_7_1_, offspring1_7_.nickName as nickName7_1_, offspring1_7_.height_centimeters / 2.54 as height6_7_1_, offspring1_7_.intValue as intValue7_1_, offspring1_7_.floatValue as floatValue7_1_, offspring1_7_.bigDecimalValue as bigDecim9_7_1_, offspring1_7_.bigIntegerValue as bigInte10_7_1_, case when offspring1_2_.reptile is not null then 2 when offspring1_5_.mammal is not null then 5 when offspring1_6_.mammal is not null then 6 when offspring1_4_.mammal is not null then 4 when offspring1_7_.mammal is not null then 7 when offspring1_1_.animal is not null then 1 when offspring1_3_.animal is not null then 3 when offspring1_.id is not null then 0 end as clazz_1_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal inner join Animal offspring1_ on animal0_.id=offspring1_.mother_id left outer join Reptile offspring1_1_ on offspring1_.id=offspring1_1_.animal left outer join Lizard offspring1_2_ on offspring1_.id=offspring1_2_.reptile left outer join Mammal offspring1_3_ on offspring1_.id=offspring1_3_.animal left outer join DomesticAnimal offspring1_4_ on offspring1_.id=offspring1_4_.mammal left outer join Cat offspring1_5_ on offspring1_.id=offspring1_5_.mammal left outer join Dog offspring1_6_ on offspring1_.id=offspring1_6_.mammal left outer join Human offspring1_7_ on offspring1_.id=offspring1_7_.mammal cross join Animal animal2_ where offspring1_.father_id=animal2_.id and animal2_.description=''xyz''\p\g
select animal0_.id as id0_0_, offspring1_.id as id0_1_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_, offspring1_.description as descript2_0_1_, offspring1_.body_weight as body3_0_1_, offspring1_.mother_id as mother4_0_1_, offspring1_.father_id as father5_0_1_, offspring1_.zoo_id as zoo6_0_1_, offspring1_.serialNumber as serialNu7_0_1_, offspring1_1_.bodyTemperature as bodyTemp2_1_1_, offspring1_3_.pregnant as pregnant3_1_, offspring1_3_.birthdate as birthdate3_1_, offspring1_4_.owner as owner4_1_, offspring1_7_.name_first as name2_7_1_, offspring1_7_.name_initial as name3_7_1_, offspring1_7_.name_last as name4_7_1_, offspring1_7_.nickName as nickName7_1_, offspring1_7_.height_centimeters / 2.54 as height6_7_1_, offspring1_7_.intValue as intValue7_1_, offspring1_7_.floatValue as floatValue7_1_, offspring1_7_.bigDecimalValue as bigDecim9_7_1_, offspring1_7_.bigIntegerValue as bigInte10_7_1_, case when offspring1_2_.reptile is not null then 2 when offspring1_5_.mammal is not null then 5 when offspring1_6_.mammal is not null then 6 when offspring1_4_.mammal is not null then 4 when offspring1_7_.mammal is not null then 7 when offspring1_1_.animal is not null then 1 when offspring1_3_.animal is not null then 3 when offspring1_.id is not null then 0 end as clazz_1_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal inner join Animal offspring1_ on animal0_.id=offspring1_.mother_id left outer join Reptile offspring1_1_ on offspring1_.id=offspring1_1_.animal left outer join Lizard offspring1_2_ on offspring1_.id=offspring1_2_.reptile left outer join Mammal offspring1_3_ on offspring1_.id=offspring1_3_.animal left outer join DomesticAnimal offspring1_4_ on offspring1_.id=offspring1_4_.mammal left outer join Cat offspring1_5_ on offspring1_.id=offspring1_5_.mammal left outer join Dog offspring1_6_ on offspring1_.id=offspring1_6_.mammal left outer join Human offspring1_7_ on offspring1_.id=offspring1_7_.mammal order by offspring1_.description\p\g
select animal0_.id as id0_0_, offspring1_.id as id0_1_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_, offspring1_.description as descript2_0_1_, offspring1_.body_weight as body3_0_1_, offspring1_.mother_id as mother4_0_1_, offspring1_.father_id as father5_0_1_, offspring1_.zoo_id as zoo6_0_1_, offspring1_.serialNumber as serialNu7_0_1_, offspring1_1_.bodyTemperature as bodyTemp2_1_1_, offspring1_3_.pregnant as pregnant3_1_, offspring1_3_.birthdate as birthdate3_1_, offspring1_4_.owner as owner4_1_, offspring1_7_.name_first as name2_7_1_, offspring1_7_.name_initial as name3_7_1_, offspring1_7_.name_last as name4_7_1_, offspring1_7_.nickName as nickName7_1_, offspring1_7_.height_centimeters / 2.54 as height6_7_1_, offspring1_7_.intValue as intValue7_1_, offspring1_7_.floatValue as floatValue7_1_, offspring1_7_.bigDecimalValue as bigDecim9_7_1_, offspring1_7_.bigIntegerValue as bigInte10_7_1_, case when offspring1_2_.reptile is not null then 2 when offspring1_5_.mammal is not null then 5 when offspring1_6_.mammal is not null then 6 when offspring1_4_.mammal is not null then 4 when offspring1_7_.mammal is not null then 7 when offspring1_1_.animal is not null then 1 when offspring1_3_.animal is not null then 3 when offspring1_.id is not null then 0 end as clazz_1_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal inner join Animal offspring1_ on animal0_.id=offspring1_.mother_id left outer join Reptile offspring1_1_ on offspring1_.id=offspring1_1_.animal left outer join Lizard offspring1_2_ on offspring1_.id=offspring1_2_.reptile left outer join Mammal offspring1_3_ on offspring1_.id=offspring1_3_.animal left outer join DomesticAnimal offspring1_4_ on offspring1_.id=offspring1_4_.mammal left outer join Cat offspring1_5_ on offspring1_.id=offspring1_5_.mammal left outer join Dog offspring1_6_ on offspring1_.id=offspring1_6_.mammal left outer join Human offspring1_7_ on offspring1_.id=offspring1_7_.mammal cross join Animal animal2_ where offspring1_.father_id=animal2_.id order by animal2_.description\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where human0_.nickName=(''1''+''ov''+''tha''+''few'')\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where abs(animal0_.body_weight-1)<2.0\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where abs(1-animal0_.body_weight)<2.0\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where abs(1-1)<2.0\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where lower(upper('foo')) like ''f%''\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where abs(abs(animal0_.body_weight-1.0+1)*abs(length(''ffobar'')-3))=3.0\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where lower((upper(''foo'')+upper('xyz'))) like ''f%''\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where abs(cast(1 as float)-cast(1 as float))=1.0\p\g
select max(ID) from CRAZY_ID_NODE\p\g
select max(ID) from CRAZY_ID_TOP\p\g
insert into CRAZY_ID_NODE (name, ID) values ('next', 1)\p\g
insert into CRAZY_ID_TOP (name, heresAnotherCrazyIdFieldName, ID) values ('top', 1, 1)\p\g
insert into CRAZY_ID_TOP (name, heresAnotherCrazyIdFieldName, ID) values ('other', null, 2)\p\g
select heresanoth1_.ID as ID27_, heresanoth1_.name as name27_ from CRAZY_ID_TOP morecrazyi0_ inner join CRAZY_ID_NODE heresanoth1_ on morecrazyi0_.heresAnotherCrazyIdFieldName=heresanoth1_.ID where morecrazyi0_.heresAnotherCrazyIdFieldName is not null\p\g
select morecrazyi0_.heresAnotherCrazyIdFieldName as col_0_0_ from CRAZY_ID_TOP morecrazyi0_ where morecrazyi0_.heresAnotherCrazyIdFieldName is not null\p\g
select heresanoth1_.ID as ID27_, heresanoth1_.name as name27_ from CRAZY_ID_TOP morecrazyi0_ inner join CRAZY_ID_NODE heresanoth1_ on morecrazyi0_.heresAnotherCrazyIdFieldName=heresanoth1_.ID\p\g
select morecrazyi0_.heresAnotherCrazyIdFieldName as col_0_0_ from CRAZY_ID_TOP morecrazyi0_, CRAZY_ID_NODE heresanoth1_ where morecrazyi0_.heresAnotherCrazyIdFieldName=heresanoth1_.ID\p\g
delete from CRAZY_ID_TOP where ID=1\p\g
delete from CRAZY_ID_NODE where ID=1\p\g
delete from CRAZY_ID_TOP where ID=2\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into SIMPLE_2 (NAME, SIMPLE_1_ID, ID) values ('thing one', null, 5)\p\g
insert into SIMPLE_2 (NAME, SIMPLE_1_ID, ID) values ('thing two', null, 6)\p\g
insert into SIMPLE_1 (NAME, negated_num, ID) values ('owner', 0 - null, 7)\p\g
update SIMPLE_2 set NAME='thing one', SIMPLE_1_ID=7 where ID=5\p\g
select simpleenti1_.ID as ID24_, simpleenti1_.NAME as NAME24_, -simpleenti1_.negated_num as negated3_24_ from SIMPLE_2 simpleasso0_ inner join SIMPLE_1 simpleenti1_ on simpleasso0_.SIMPLE_1_ID=simpleenti1_.ID\p\g
select simpleasso0_.SIMPLE_1_ID as col_0_0_ from SIMPLE_2 simpleasso0_, SIMPLE_1 simpleenti1_ where simpleasso0_.SIMPLE_1_ID=simpleenti1_.ID\p\g
select simpleasso0_.ID as col_0_0_, simpleasso0_.SIMPLE_1_ID as col_1_0_, simpleenti1_.ID as ID24_, simpleenti1_.NAME as NAME24_, -simpleenti1_.negated_num as negated3_24_ from SIMPLE_2 simpleasso0_ inner join SIMPLE_1 simpleenti1_ on simpleasso0_.SIMPLE_1_ID=simpleenti1_.ID\p\g
select simpleasso0_.ID as col_0_0_, simpleasso0_.SIMPLE_1_ID as col_1_0_ from SIMPLE_2 simpleasso0_, SIMPLE_1 simpleenti1_ where simpleasso0_.SIMPLE_1_ID=simpleenti1_.ID\p\g
select simpleasso0_.ID as ID26_, simpleasso0_.NAME as NAME26_, simpleasso0_.SIMPLE_1_ID as SIMPLE3_26_ from SIMPLE_2 simpleasso0_ order by simpleasso0_.SIMPLE_1_ID\p\g
select simpleasso0_.ID as col_0_0_ from SIMPLE_2 simpleasso0_ order by simpleasso0_.SIMPLE_1_ID\p\g
select simpleasso0_.SIMPLE_1_ID as col_0_0_, count(*) as col_1_0_ from SIMPLE_2 simpleasso0_ group by simpleasso0_.SIMPLE_1_ID\p\g
select simpleasso0_.SIMPLE_1_ID as col_0_0_, count(*) as col_1_0_ from SIMPLE_2 simpleasso0_ group by simpleasso0_.SIMPLE_1_ID\p\g
delete from SIMPLE_2 where ID=5\p\g
delete from SIMPLE_2 where ID=6\p\g
delete from SIMPLE_1 where ID=7\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into SIMPLE_2 (NAME, SIMPLE_1_ID, ID) values ('thing one', null, 8)\p\g
insert into SIMPLE_2 (NAME, SIMPLE_1_ID, ID) values ('thing two', null, 9)\p\g
insert into SIMPLE_1 (NAME, negated_num, ID) values ('owner', 0 - null, 10)\p\g
update SIMPLE_2 set NAME='thing one', SIMPLE_1_ID=10 where ID=8\p\g
select simpleasso0_.ID as col_0_0_, simpleasso0_.SIMPLE_1_ID as col_1_0_, simpleenti1_.ID as ID24_, simpleenti1_.NAME as NAME24_, -simpleenti1_.negated_num as negated3_24_ from SIMPLE_2 simpleasso0_ inner join SIMPLE_1 simpleenti1_ on simpleasso0_.SIMPLE_1_ID=simpleenti1_.ID\p\g
select simpleasso0_.ID as col_0_0_, simpleasso0_.SIMPLE_1_ID as col_1_0_ from SIMPLE_2 simpleasso0_, SIMPLE_1 simpleenti1_ where simpleasso0_.SIMPLE_1_ID=simpleenti1_.ID\p\g
delete from SIMPLE_2 where ID=8\p\g
delete from SIMPLE_2 where ID=9\p\g
delete from SIMPLE_1 where ID=10\p\g
select commento0_.MCLINK as MCLINK44_, commento0_.MCOMPR as MCOMPR44_, commento0_.MCOMME as MCOMME44_ from MARECM commento0_ cross join MARELO marelo1_ cross join MARECM commento2_ where commento0_.MCLINK=marelo1_.MLCOM and marelo1_.MLCOM=commento2_.MCLINK and (commento2_.MCOMPR is null)\p\g
select commento0_.MCLINK as col_0_0_ from MARECM commento0_ cross join MARELO marelo1_ cross join MARECM commento2_ where commento0_.MCLINK=marelo1_.MLCOM and marelo1_.MLCOM=commento2_.MCLINK and (commento2_.MCOMPR is null)\p\g
select commento0_.MCLINK as MCLINK44_, commento0_.MCOMPR as MCOMPR44_, commento0_.MCOMME as MCOMME44_ from MARECM commento0_ cross join MARELO marelo1_ cross join MARECM commento2_ where commento0_.MCLINK=marelo1_.MLCOM and marelo1_.MLCOM=commento2_.MCLINK and (commento2_.MCOMPR is null)\p\g
select zoo0_.id as id14_, zoo0_.name as name14_, zoo0_.classification as classifi4_14_, zoo0_.street as street14_, zoo0_.city as city14_, zoo0_.postalCode as postalCode14_, zoo0_.country as country14_, zoo0_.state_prov_id as state9_14_, zoo0_.zooType as zooType14_ from Zoo zoo0_ where zoo0_.zooType=''P''\p\g
select zoo0_.id as col_0_0_ from Zoo zoo0_ where zoo0_.zooType=''P''\p\g
select zoo0_.id as id14_, zoo0_.name as name14_, zoo0_.classification as classifi4_14_, zoo0_.street as street14_, zoo0_.city as city14_, zoo0_.postalCode as postalCode14_, zoo0_.country as country14_, zoo0_.state_prov_id as state9_14_, zoo0_.zooType as zooType14_ from Zoo zoo0_ where zoo0_.zooType=''P''\p\g
select animal0_.description as col_0_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end=3\p\g
select animal0_.description as col_0_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end=3\p\g
select animal0_.description as col_0_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end=3\p\g
select case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as col_0_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal\p\g
select case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as col_0_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal\p\g
select case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as col_0_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal\p\g
select domestican0_.mammal as id0_, domestican0_2_.description as descript2_0_, domestican0_2_.body_weight as body3_0_, domestican0_2_.mother_id as mother4_0_, domestican0_2_.father_id as father5_0_, domestican0_2_.zoo_id as zoo6_0_, domestican0_2_.serialNumber as serialNu7_0_, domestican0_1_.pregnant as pregnant3_, domestican0_1_.birthdate as birthdate3_, domestican0_.owner as owner4_, case when domestican0_3_.mammal is not null then 5 when domestican0_4_.mammal is not null then 6 when domestican0_.mammal is not null then 4 end as clazz_ from DomesticAnimal domestican0_ inner join Mammal domestican0_1_ on domestican0_.mammal=domestican0_1_.animal inner join Animal domestican0_2_ on domestican0_.mammal=domestican0_2_.id left outer join Cat domestican0_3_ on domestican0_.mammal=domestican0_3_.mammal left outer join Dog domestican0_4_ on domestican0_.mammal=domestican0_4_.mammal where case when domestican0_3_.mammal is not null then 5 when domestican0_4_.mammal is not null then 6 when domestican0_.mammal is not null then 4 end=6\p\g
select domestican0_.mammal as col_0_0_ from DomesticAnimal domestican0_ inner join Mammal domestican0_1_ on domestican0_.mammal=domestican0_1_.animal inner join Animal domestican0_2_ on domestican0_.mammal=domestican0_2_.id left outer join Cat domestican0_3_ on domestican0_.mammal=domestican0_3_.mammal left outer join Dog domestican0_4_ on domestican0_.mammal=domestican0_4_.mammal where case when domestican0_3_.mammal is not null then 5 when domestican0_4_.mammal is not null then 6 when domestican0_.mammal is not null then 4 end=6\p\g
select domestican0_.mammal as id0_, domestican0_2_.description as descript2_0_, domestican0_2_.body_weight as body3_0_, domestican0_2_.mother_id as mother4_0_, domestican0_2_.father_id as father5_0_, domestican0_2_.zoo_id as zoo6_0_, domestican0_2_.serialNumber as serialNu7_0_, domestican0_1_.pregnant as pregnant3_, domestican0_1_.birthdate as birthdate3_, domestican0_.owner as owner4_, case when domestican0_3_.mammal is not null then 5 when domestican0_4_.mammal is not null then 6 when domestican0_.mammal is not null then 4 end as clazz_ from DomesticAnimal domestican0_ inner join Mammal domestican0_1_ on domestican0_.mammal=domestican0_1_.animal inner join Animal domestican0_2_ on domestican0_.mammal=domestican0_2_.id left outer join Cat domestican0_3_ on domestican0_.mammal=domestican0_3_.mammal left outer join Dog domestican0_4_ on domestican0_.mammal=domestican0_4_.mammal where case when domestican0_3_.mammal is not null then 5 when domestican0_4_.mammal is not null then 6 when domestican0_.mammal is not null then 4 end=6\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end=6\p\g
select animal0_.id as col_0_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end=6\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end=6\p\g
select zoo0_.id as id14_, zoo0_.name as name14_, zoo0_.classification as classifi4_14_, zoo0_.street as street14_, zoo0_.city as city14_, zoo0_.postalCode as postalCode14_, zoo0_.country as country14_, zoo0_.state_prov_id as state9_14_, zoo0_.zooType as zooType14_ from Zoo zoo0_ where zoo0_.zooType=''P''\p\g
select zoo0_.id as col_0_0_ from Zoo zoo0_ where zoo0_.zooType=''P''\p\g
select zoo0_.id as id14_, zoo0_.name as name14_, zoo0_.classification as classifi4_14_, zoo0_.street as street14_, zoo0_.city as city14_, zoo0_.postalCode as postalCode14_, zoo0_.country as country14_, zoo0_.state_prov_id as state9_14_, zoo0_.zooType as zooType14_ from Zoo zoo0_ where zoo0_.zooType=''P''\p\g
select animal0_.description as col_0_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end=3\p\g
select animal0_.description as col_0_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end=3\p\g
select animal0_.description as col_0_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end=3\p\g
select domestican0_.mammal as id0_, domestican0_2_.description as descript2_0_, domestican0_2_.body_weight as body3_0_, domestican0_2_.mother_id as mother4_0_, domestican0_2_.father_id as father5_0_, domestican0_2_.zoo_id as zoo6_0_, domestican0_2_.serialNumber as serialNu7_0_, domestican0_1_.pregnant as pregnant3_, domestican0_1_.birthdate as birthdate3_, domestican0_.owner as owner4_, case when domestican0_3_.mammal is not null then 5 when domestican0_4_.mammal is not null then 6 when domestican0_.mammal is not null then 4 end as clazz_ from DomesticAnimal domestican0_ inner join Mammal domestican0_1_ on domestican0_.mammal=domestican0_1_.animal inner join Animal domestican0_2_ on domestican0_.mammal=domestican0_2_.id left outer join Cat domestican0_3_ on domestican0_.mammal=domestican0_3_.mammal left outer join Dog domestican0_4_ on domestican0_.mammal=domestican0_4_.mammal where case when domestican0_3_.mammal is not null then 5 when domestican0_4_.mammal is not null then 6 when domestican0_.mammal is not null then 4 end=6\p\g
select domestican0_.mammal as col_0_0_ from DomesticAnimal domestican0_ inner join Mammal domestican0_1_ on domestican0_.mammal=domestican0_1_.animal inner join Animal domestican0_2_ on domestican0_.mammal=domestican0_2_.id left outer join Cat domestican0_3_ on domestican0_.mammal=domestican0_3_.mammal left outer join Dog domestican0_4_ on domestican0_.mammal=domestican0_4_.mammal where case when domestican0_3_.mammal is not null then 5 when domestican0_4_.mammal is not null then 6 when domestican0_.mammal is not null then 4 end=6\p\g
select domestican0_.mammal as id0_, domestican0_2_.description as descript2_0_, domestican0_2_.body_weight as body3_0_, domestican0_2_.mother_id as mother4_0_, domestican0_2_.father_id as father5_0_, domestican0_2_.zoo_id as zoo6_0_, domestican0_2_.serialNumber as serialNu7_0_, domestican0_1_.pregnant as pregnant3_, domestican0_1_.birthdate as birthdate3_, domestican0_.owner as owner4_, case when domestican0_3_.mammal is not null then 5 when domestican0_4_.mammal is not null then 6 when domestican0_.mammal is not null then 4 end as clazz_ from DomesticAnimal domestican0_ inner join Mammal domestican0_1_ on domestican0_.mammal=domestican0_1_.animal inner join Animal domestican0_2_ on domestican0_.mammal=domestican0_2_.id left outer join Cat domestican0_3_ on domestican0_.mammal=domestican0_3_.mammal left outer join Dog domestican0_4_ on domestican0_.mammal=domestican0_4_.mammal where case when domestican0_3_.mammal is not null then 5 when domestican0_4_.mammal is not null then 6 when domestican0_.mammal is not null then 4 end=6\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end=6\p\g
select animal0_.id as col_0_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end=6\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end=6\p\g
select zoo0_.id as col_0_0_, mammals1_.animal as col_1_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal where mammals1_5_.name_first=''John''\p\g
select zoo0_.id as id14_0_, mammals1_.animal as id0_1_, zoo0_.name as name14_0_, zoo0_.classification as classifi4_14_0_, zoo0_.street as street14_0_, zoo0_.city as city14_0_, zoo0_.postalCode as postalCode14_0_, zoo0_.country as country14_0_, zoo0_.state_prov_id as state9_14_0_, zoo0_.zooType as zooType14_0_, mammals1_1_.description as descript2_0_1_, mammals1_1_.body_weight as body3_0_1_, mammals1_1_.mother_id as mother4_0_1_, mammals1_1_.father_id as father5_0_1_, mammals1_1_.zoo_id as zoo6_0_1_, mammals1_1_.serialNumber as serialNu7_0_1_, mammals1_.pregnant as pregnant3_1_, mammals1_.birthdate as birthdate3_1_, mammals1_2_.owner as owner4_1_, mammals1_5_.name_first as name2_7_1_, mammals1_5_.name_initial as name3_7_1_, mammals1_5_.name_last as name4_7_1_, mammals1_5_.nickName as nickName7_1_, mammals1_5_.height_centimeters / 2.54 as height6_7_1_, mammals1_5_.intValue as intValue7_1_, mammals1_5_.floatValue as floatValue7_1_, mammals1_5_.bigDecimalValue as bigDecim9_7_1_, mammals1_5_.bigIntegerValue as bigInte10_7_1_, case when mammals1_3_.mammal is not null then 5 when mammals1_4_.mammal is not null then 6 when mammals1_2_.mammal is not null then 4 when mammals1_5_.mammal is not null then 7 when mammals1_.animal is not null then 3 end as clazz_1_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal where mammals1_.pregnant=0\p\g
select zoo0_.id as col_0_0_, mammals1_.animal as col_1_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id where mammals1_.pregnant=0\p\g
select zoo0_.id as id14_0_, mammals1_.animal as id0_1_, zoo0_.name as name14_0_, zoo0_.classification as classifi4_14_0_, zoo0_.street as street14_0_, zoo0_.city as city14_0_, zoo0_.postalCode as postalCode14_0_, zoo0_.country as country14_0_, zoo0_.state_prov_id as state9_14_0_, zoo0_.zooType as zooType14_0_, mammals1_1_.description as descript2_0_1_, mammals1_1_.body_weight as body3_0_1_, mammals1_1_.mother_id as mother4_0_1_, mammals1_1_.father_id as father5_0_1_, mammals1_1_.zoo_id as zoo6_0_1_, mammals1_1_.serialNumber as serialNu7_0_1_, mammals1_.pregnant as pregnant3_1_, mammals1_.birthdate as birthdate3_1_, mammals1_2_.owner as owner4_1_, mammals1_5_.name_first as name2_7_1_, mammals1_5_.name_initial as name3_7_1_, mammals1_5_.name_last as name4_7_1_, mammals1_5_.nickName as nickName7_1_, mammals1_5_.height_centimeters / 2.54 as height6_7_1_, mammals1_5_.intValue as intValue7_1_, mammals1_5_.floatValue as floatValue7_1_, mammals1_5_.bigDecimalValue as bigDecim9_7_1_, mammals1_5_.bigIntegerValue as bigInte10_7_1_, case when mammals1_3_.mammal is not null then 5 when mammals1_4_.mammal is not null then 6 when mammals1_2_.mammal is not null then 4 when mammals1_5_.mammal is not null then 7 when mammals1_.animal is not null then 3 end as clazz_1_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal where mammals1_.pregnant=0\p\g
select mammals1_.pregnant as col_0_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id where mammals1_.pregnant=0\p\g
select mammals1_.pregnant as col_0_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id where mammals1_.pregnant=0\p\g
select mammals1_.pregnant as col_0_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id where mammals1_.pregnant=0\p\g
select zoo0_.id as id14_0_, mammals1_.animal as id0_1_, zoo0_.name as name14_0_, zoo0_.classification as classifi4_14_0_, zoo0_.street as street14_0_, zoo0_.city as city14_0_, zoo0_.postalCode as postalCode14_0_, zoo0_.country as country14_0_, zoo0_.state_prov_id as state9_14_0_, zoo0_.zooType as zooType14_0_, mammals1_1_.description as descript2_0_1_, mammals1_1_.body_weight as body3_0_1_, mammals1_1_.mother_id as mother4_0_1_, mammals1_1_.father_id as father5_0_1_, mammals1_1_.zoo_id as zoo6_0_1_, mammals1_1_.serialNumber as serialNu7_0_1_, mammals1_.pregnant as pregnant3_1_, mammals1_.birthdate as birthdate3_1_, mammals1_2_.owner as owner4_1_, mammals1_5_.name_first as name2_7_1_, mammals1_5_.name_initial as name3_7_1_, mammals1_5_.name_last as name4_7_1_, mammals1_5_.nickName as nickName7_1_, mammals1_5_.height_centimeters / 2.54 as height6_7_1_, mammals1_5_.intValue as intValue7_1_, mammals1_5_.floatValue as floatValue7_1_, mammals1_5_.bigDecimalValue as bigDecim9_7_1_, mammals1_5_.bigIntegerValue as bigInte10_7_1_, case when mammals1_3_.mammal is not null then 5 when mammals1_4_.mammal is not null then 6 when mammals1_2_.mammal is not null then 4 when mammals1_5_.mammal is not null then 7 when mammals1_.animal is not null then 3 end as clazz_1_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal where mammals1_1_.description=''tabby''\p\g
select zoo0_.id as col_0_0_, mammals1_.animal as col_1_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id where mammals1_1_.description=''tabby''\p\g
select zoo0_.id as id14_0_, mammals1_.animal as id0_1_, zoo0_.name as name14_0_, zoo0_.classification as classifi4_14_0_, zoo0_.street as street14_0_, zoo0_.city as city14_0_, zoo0_.postalCode as postalCode14_0_, zoo0_.country as country14_0_, zoo0_.state_prov_id as state9_14_0_, zoo0_.zooType as zooType14_0_, mammals1_1_.description as descript2_0_1_, mammals1_1_.body_weight as body3_0_1_, mammals1_1_.mother_id as mother4_0_1_, mammals1_1_.father_id as father5_0_1_, mammals1_1_.zoo_id as zoo6_0_1_, mammals1_1_.serialNumber as serialNu7_0_1_, mammals1_.pregnant as pregnant3_1_, mammals1_.birthdate as birthdate3_1_, mammals1_2_.owner as owner4_1_, mammals1_5_.name_first as name2_7_1_, mammals1_5_.name_initial as name3_7_1_, mammals1_5_.name_last as name4_7_1_, mammals1_5_.nickName as nickName7_1_, mammals1_5_.height_centimeters / 2.54 as height6_7_1_, mammals1_5_.intValue as intValue7_1_, mammals1_5_.floatValue as floatValue7_1_, mammals1_5_.bigDecimalValue as bigDecim9_7_1_, mammals1_5_.bigIntegerValue as bigInte10_7_1_, case when mammals1_3_.mammal is not null then 5 when mammals1_4_.mammal is not null then 6 when mammals1_2_.mammal is not null then 4 when mammals1_5_.mammal is not null then 7 when mammals1_.animal is not null then 3 end as clazz_1_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal where mammals1_1_.description=''tabby''\p\g
select mammals1_1_.description as col_0_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id where mammals1_1_.description=''tabby''\p\g
select mammals1_1_.description as col_0_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id where mammals1_1_.description=''tabby''\p\g
select mammals1_1_.description as col_0_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id where mammals1_1_.description=''tabby''\p\g
select zoo0_.id as id14_0_, mammals1_.animal as id0_1_, zoo0_.name as name14_0_, zoo0_.classification as classifi4_14_0_, zoo0_.street as street14_0_, zoo0_.city as city14_0_, zoo0_.postalCode as postalCode14_0_, zoo0_.country as country14_0_, zoo0_.state_prov_id as state9_14_0_, zoo0_.zooType as zooType14_0_, mammals1_1_.description as descript2_0_1_, mammals1_1_.body_weight as body3_0_1_, mammals1_1_.mother_id as mother4_0_1_, mammals1_1_.father_id as father5_0_1_, mammals1_1_.zoo_id as zoo6_0_1_, mammals1_1_.serialNumber as serialNu7_0_1_, mammals1_.pregnant as pregnant3_1_, mammals1_.birthdate as birthdate3_1_, mammals1_2_.owner as owner4_1_, mammals1_5_.name_first as name2_7_1_, mammals1_5_.name_initial as name3_7_1_, mammals1_5_.name_last as name4_7_1_, mammals1_5_.nickName as nickName7_1_, mammals1_5_.height_centimeters / 2.54 as height6_7_1_, mammals1_5_.intValue as intValue7_1_, mammals1_5_.floatValue as floatValue7_1_, mammals1_5_.bigDecimalValue as bigDecim9_7_1_, mammals1_5_.bigIntegerValue as bigInte10_7_1_, case when mammals1_3_.mammal is not null then 5 when mammals1_4_.mammal is not null then 6 when mammals1_2_.mammal is not null then 4 when mammals1_5_.mammal is not null then 7 when mammals1_.animal is not null then 3 end as clazz_1_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal where mammals1_5_.name_first=''John''\p\g
select zoo0_.id as col_0_0_, mammals1_.animal as col_1_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal where mammals1_5_.name_first=''John''\p\g
select zoo0_.id as id14_0_, mammals1_.animal as id0_1_, zoo0_.name as name14_0_, zoo0_.classification as classifi4_14_0_, zoo0_.street as street14_0_, zoo0_.city as city14_0_, zoo0_.postalCode as postalCode14_0_, zoo0_.country as country14_0_, zoo0_.state_prov_id as state9_14_0_, zoo0_.zooType as zooType14_0_, mammals1_1_.description as descript2_0_1_, mammals1_1_.body_weight as body3_0_1_, mammals1_1_.mother_id as mother4_0_1_, mammals1_1_.father_id as father5_0_1_, mammals1_1_.zoo_id as zoo6_0_1_, mammals1_1_.serialNumber as serialNu7_0_1_, mammals1_.pregnant as pregnant3_1_, mammals1_.birthdate as birthdate3_1_, mammals1_2_.owner as owner4_1_, mammals1_5_.name_first as name2_7_1_, mammals1_5_.name_initial as name3_7_1_, mammals1_5_.name_last as name4_7_1_, mammals1_5_.nickName as nickName7_1_, mammals1_5_.height_centimeters / 2.54 as height6_7_1_, mammals1_5_.intValue as intValue7_1_, mammals1_5_.floatValue as floatValue7_1_, mammals1_5_.bigDecimalValue as bigDecim9_7_1_, mammals1_5_.bigIntegerValue as bigInte10_7_1_, case when mammals1_3_.mammal is not null then 5 when mammals1_4_.mammal is not null then 6 when mammals1_2_.mammal is not null then 4 when mammals1_5_.mammal is not null then 7 when mammals1_.animal is not null then 3 end as clazz_1_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal where mammals1_5_.name_first=''John''\p\g
select mammals1_5_.name_first as col_0_0_, mammals1_5_.name_initial as col_0_1_, mammals1_5_.name_last as col_0_2_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal where mammals1_5_.name_first=''John''\p\g
select mammals1_5_.name_first as col_0_0_, mammals1_5_.name_initial as col_0_1_, mammals1_5_.name_last as col_0_2_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal where mammals1_5_.name_first=''John''\p\g
select mammals1_5_.name_first as col_0_0_, mammals1_5_.name_initial as col_0_1_, mammals1_5_.name_last as col_0_2_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal where mammals1_5_.name_first=''John''\p\g
select mammals1_.pregnant as col_0_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id\p\g
select mammals1_.pregnant as col_0_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id\p\g
select mammals1_.pregnant as col_0_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id\p\g
select mammals1_1_.description as col_0_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id\p\g
select mammals1_1_.description as col_0_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id\p\g
select mammals1_1_.description as col_0_0_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id\p\g
select mammals1_5_.name_first as col_0_0_, mammals1_5_.name_initial as col_0_1_, mammals1_5_.name_last as col_0_2_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal\p\g
select mammals1_5_.name_first as col_0_0_, mammals1_5_.name_initial as col_0_1_, mammals1_5_.name_last as col_0_2_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal\p\g
select mammals1_5_.name_first as col_0_0_, mammals1_5_.name_initial as col_0_1_, mammals1_5_.name_last as col_0_2_ from Zoo zoo0_ inner join Mammal mammals1_ on zoo0_.id=mammals1_.mammalZoo_id inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id left outer join DomesticAnimal mammals1_2_ on mammals1_.animal=mammals1_2_.mammal left outer join Cat mammals1_3_ on mammals1_.animal=mammals1_3_.mammal left outer join Dog mammals1_4_ on mammals1_.animal=mammals1_4_.mammal left outer join Human mammals1_5_ on mammals1_.animal=mammals1_5_.mammal\p\g
select domestican0_.mammal as id0_0_, human1_.mammal as id0_1_, domestican0_2_.description as descript2_0_0_, domestican0_2_.body_weight as body3_0_0_, domestican0_2_.mother_id as mother4_0_0_, domestican0_2_.father_id as father5_0_0_, domestican0_2_.zoo_id as zoo6_0_0_, domestican0_2_.serialNumber as serialNu7_0_0_, domestican0_1_.pregnant as pregnant3_0_, domestican0_1_.birthdate as birthdate3_0_, domestican0_.owner as owner4_0_, case when domestican0_3_.mammal is not null then 5 when domestican0_4_.mammal is not null then 6 when domestican0_.mammal is not null then 4 end as clazz_0_, human1_2_.description as descript2_0_1_, human1_2_.body_weight as body3_0_1_, human1_2_.mother_id as mother4_0_1_, human1_2_.father_id as father5_0_1_, human1_2_.zoo_id as zoo6_0_1_, human1_2_.serialNumber as serialNu7_0_1_, human1_1_.pregnant as pregnant3_1_, human1_1_.birthdate as birthdate3_1_, human1_.name_first as name2_7_1_, human1_.name_initial as name3_7_1_, human1_.name_last as name4_7_1_, human1_.nickName as nickName7_1_, human1_.height_centimeters / 2.54 as height6_7_1_, human1_.intValue as intValue7_1_, human1_.floatValue as floatValue7_1_, human1_.bigDecimalValue as bigDecim9_7_1_, human1_.bigIntegerValue as bigInte10_7_1_ from DomesticAnimal domestican0_ inner join Mammal domestican0_1_ on domestican0_.mammal=domestican0_1_.animal inner join Animal domestican0_2_ on domestican0_.mammal=domestican0_2_.id left outer join Cat domestican0_3_ on domestican0_.mammal=domestican0_3_.mammal left outer join Dog domestican0_4_ on domestican0_.mammal=domestican0_4_.mammal inner join Human human1_ on domestican0_.owner=human1_.mammal inner join Mammal human1_1_ on human1_.mammal=human1_1_.animal inner join Animal human1_2_ on human1_.mammal=human1_2_.id where human1_.nickName=''Gavin''\p\g
select domestican0_.mammal as col_0_0_, human1_.mammal as col_1_0_ from DomesticAnimal domestican0_ inner join Mammal domestican0_1_ on domestican0_.mammal=domestican0_1_.animal inner join Animal domestican0_2_ on domestican0_.mammal=domestican0_2_.id inner join Human human1_ on domestican0_.owner=human1_.mammal inner join Mammal human1_1_ on human1_.mammal=human1_1_.animal inner join Animal human1_2_ on human1_.mammal=human1_2_.id where human1_.nickName=''Gavin''\p\g
select domestican0_.mammal as id0_0_, human1_.mammal as id0_1_, domestican0_2_.description as descript2_0_0_, domestican0_2_.body_weight as body3_0_0_, domestican0_2_.mother_id as mother4_0_0_, domestican0_2_.father_id as father5_0_0_, domestican0_2_.zoo_id as zoo6_0_0_, domestican0_2_.serialNumber as serialNu7_0_0_, domestican0_1_.pregnant as pregnant3_0_, domestican0_1_.birthdate as birthdate3_0_, domestican0_.owner as owner4_0_, case when domestican0_3_.mammal is not null then 5 when domestican0_4_.mammal is not null then 6 when domestican0_.mammal is not null then 4 end as clazz_0_, human1_2_.description as descript2_0_1_, human1_2_.body_weight as body3_0_1_, human1_2_.mother_id as mother4_0_1_, human1_2_.father_id as father5_0_1_, human1_2_.zoo_id as zoo6_0_1_, human1_2_.serialNumber as serialNu7_0_1_, human1_1_.pregnant as pregnant3_1_, human1_1_.birthdate as birthdate3_1_, human1_.name_first as name2_7_1_, human1_.name_initial as name3_7_1_, human1_.name_last as name4_7_1_, human1_.nickName as nickName7_1_, human1_.height_centimeters / 2.54 as height6_7_1_, human1_.intValue as intValue7_1_, human1_.floatValue as floatValue7_1_, human1_.bigDecimalValue as bigDecim9_7_1_, human1_.bigIntegerValue as bigInte10_7_1_ from DomesticAnimal domestican0_ inner join Mammal domestican0_1_ on domestican0_.mammal=domestican0_1_.animal inner join Animal domestican0_2_ on domestican0_.mammal=domestican0_2_.id left outer join Cat domestican0_3_ on domestican0_.mammal=domestican0_3_.mammal left outer join Dog domestican0_4_ on domestican0_.mammal=domestican0_4_.mammal inner join Human human1_ on domestican0_.owner=human1_.mammal inner join Mammal human1_1_ on human1_.mammal=human1_1_.animal inner join Animal human1_2_ on human1_.mammal=human1_2_.id where human1_.nickName=''Gavin''\p\g
select animal2_.id as id0_, animal2_.description as descript2_0_, animal2_.body_weight as body3_0_, animal2_.mother_id as mother4_0_, animal2_.father_id as father5_0_, animal2_.zoo_id as zoo6_0_, animal2_.serialNumber as serialNu7_0_, animal2_1_.bodyTemperature as bodyTemp2_1_, animal2_3_.pregnant as pregnant3_, animal2_3_.birthdate as birthdate3_, animal2_4_.owner as owner4_, animal2_7_.name_first as name2_7_, animal2_7_.name_initial as name3_7_, animal2_7_.name_last as name4_7_, animal2_7_.nickName as nickName7_, animal2_7_.height_centimeters / 2.54 as height6_7_, animal2_7_.intValue as intValue7_, animal2_7_.floatValue as floatValue7_, animal2_7_.bigDecimalValue as bigDecim9_7_, animal2_7_.bigIntegerValue as bigInte10_7_, case when animal2_2_.reptile is not null then 2 when animal2_5_.mammal is not null then 5 when animal2_6_.mammal is not null then 6 when animal2_4_.mammal is not null then 4 when animal2_7_.mammal is not null then 7 when animal2_1_.animal is not null then 1 when animal2_3_.animal is not null then 3 when animal2_.id is not null then 0 end as clazz_ from DomesticAnimal domestican0_ inner join Mammal domestican0_1_ on domestican0_.mammal=domestican0_1_.animal inner join Animal domestican0_2_ on domestican0_.mammal=domestican0_2_.id inner join Human human1_ on domestican0_.owner=human1_.mammal inner join Mammal human1_1_ on human1_.mammal=human1_1_.animal inner join Animal human1_2_ on human1_.mammal=human1_2_.id inner join Animal animal2_ on domestican0_2_.father_id=animal2_.id left outer join Reptile animal2_1_ on animal2_.id=animal2_1_.animal left outer join Lizard animal2_2_ on animal2_.id=animal2_2_.reptile left outer join Mammal animal2_3_ on animal2_.id=animal2_3_.animal left outer join DomesticAnimal animal2_4_ on animal2_.id=animal2_4_.mammal left outer join Cat animal2_5_ on animal2_.id=animal2_5_.mammal left outer join Dog animal2_6_ on animal2_.id=animal2_6_.mammal left outer join Human animal2_7_ on animal2_.id=animal2_7_.mammal where human1_.nickName=''Gavin''\p\g
select domestican0_2_.father_id as col_0_0_ from DomesticAnimal domestican0_ inner join Mammal domestican0_1_ on domestican0_.mammal=domestican0_1_.animal inner join Animal domestican0_2_ on domestican0_.mammal=domestican0_2_.id inner join Human human1_ on domestican0_.owner=human1_.mammal inner join Mammal human1_1_ on human1_.mammal=human1_1_.animal inner join Animal human1_2_ on human1_.mammal=human1_2_.id, Animal animal2_ where domestican0_2_.father_id=animal2_.id and human1_.nickName=''Gavin''\p\g
select animal2_.id as id0_, animal2_.description as descript2_0_, animal2_.body_weight as body3_0_, animal2_.mother_id as mother4_0_, animal2_.father_id as father5_0_, animal2_.zoo_id as zoo6_0_, animal2_.serialNumber as serialNu7_0_, animal2_1_.bodyTemperature as bodyTemp2_1_, animal2_3_.pregnant as pregnant3_, animal2_3_.birthdate as birthdate3_, animal2_4_.owner as owner4_, animal2_7_.name_first as name2_7_, animal2_7_.name_initial as name3_7_, animal2_7_.name_last as name4_7_, animal2_7_.nickName as nickName7_, animal2_7_.height_centimeters / 2.54 as height6_7_, animal2_7_.intValue as intValue7_, animal2_7_.floatValue as floatValue7_, animal2_7_.bigDecimalValue as bigDecim9_7_, animal2_7_.bigIntegerValue as bigInte10_7_, case when animal2_2_.reptile is not null then 2 when animal2_5_.mammal is not null then 5 when animal2_6_.mammal is not null then 6 when animal2_4_.mammal is not null then 4 when animal2_7_.mammal is not null then 7 when animal2_1_.animal is not null then 1 when animal2_3_.animal is not null then 3 when animal2_.id is not null then 0 end as clazz_ from DomesticAnimal domestican0_ inner join Mammal domestican0_1_ on domestican0_.mammal=domestican0_1_.animal inner join Animal domestican0_2_ on domestican0_.mammal=domestican0_2_.id inner join Human human1_ on domestican0_.owner=human1_.mammal inner join Mammal human1_1_ on human1_.mammal=human1_1_.animal inner join Animal human1_2_ on human1_.mammal=human1_2_.id inner join Animal animal2_ on domestican0_2_.father_id=animal2_.id left outer join Reptile animal2_1_ on animal2_.id=animal2_1_.animal left outer join Lizard animal2_2_ on animal2_.id=animal2_2_.reptile left outer join Mammal animal2_3_ on animal2_.id=animal2_3_.animal left outer join DomesticAnimal animal2_4_ on animal2_.id=animal2_4_.mammal left outer join Cat animal2_5_ on animal2_.id=animal2_5_.mammal left outer join Dog animal2_6_ on animal2_.id=animal2_6_.mammal left outer join Human animal2_7_ on animal2_.id=animal2_7_.mammal where human1_.nickName=''Gavin''\p\g
select first 3 animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal offset 2\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where human0_.name_last in ('Doe' , 'Public')\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where human0_.name_first=human0_.name_first and human0_.name_initial=human0_.name_initial and human0_.name_last=human0_.name_last\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where human0_.name_first=null and human0_.name_initial=null and human0_.name_last=null\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where human0_.name_first=null and human0_.name_initial=null and human0_.name_last=null\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where null=human0_.name_first and null=human0_.name_initial and null=human0_.name_last\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where null<>human0_.name_first and null<>human0_.name_initial and null<>human0_.name_last\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where human0_.name_first=''John'' and human0_.name_initial=''X'' and human0_.name_last=''Doe''\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where ''John''=human0_.name_first and ''X''=human0_.name_initial and ''Doe''=human0_.name_last\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where ''John''<>human0_.name_first and ''X''<>human0_.name_initial and ''Doe''<>human0_.name_last\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where ''John''>=human0_.name_first and ''X''>=human0_.name_initial and ''Doe''>=human0_.name_last\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id order by human0_.name_first, human0_.name_initial, human0_.name_last\p\g
Parameter count mismatch 1387, 0,3
select order0_.customerId as customerId35_, order0_.orderNumber as orderNum2_35_, order0_.orderDate as orderDate35_, ( select sum(li.quantity*p.cost) from LineItem li, Product p where li.productId = p.productId and li.customerId = order0_.customerId and li.orderNumber = order0_.orderNumber ) as formula1_ from CustomerOrder order0_ cross join Customer customer1_ where order0_.customerId=customer1_.customerId and customer1_.name=? and order0_.customerId=? and order0_.orderNumber=?
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
create table Animal (id bigint not null, description varchar(255) with null, body_weight float with null, mother_id bigint with null, father_id bigint with null, zoo_id bigint with null, serialNumber varchar(255) with null, primary key (id))\p\g
create table CRAZY_ID_NODE (ID bigint not null, name varchar(255) with null, primary key (ID))\p\g
create table CRAZY_ID_TOP (ID bigint not null, name varchar(255) with null, heresAnotherCrazyIdFieldName bigint with null, primary key (ID))\p\g
create table Cat (mammal bigint not null, primary key (mammal))\p\g
create table Customer (customerId varchar(10) not null, name varchar(100) not null, address varchar(200) not null, primary key (customerId))\p\g
create table CustomerOrder (customerId varchar(10) not null, orderNumber integer not null, orderDate ansidate not null, primary key (customerId, orderNumber))\p\g
create table Dog (mammal bigint not null, primary key (mammal))\p\g
create table DomesticAnimal (mammal bigint not null, owner bigint with null, primary key (mammal))\p\g
create table HQL_COMP_CONT (ID bigint not null, STREET_ADDR varchar(255) with null, CITY_ADDR varchar(255) with null, STATE_ADDR varchar(255) with null, ZIP_CODE_ADDR integer with null, ZIP_PLUS4_ADDR integer with null, primary key (ID))\p\g
create table Human (mammal bigint not null, name_first varchar(255) with null, name_initial char(1) with null, name_last varchar(255) with null, nickName varchar(255) with null, height_centimeters float not null, intValue integer with null, floatValue float with null, bigDecimalValue decimal(19, 2) with null, bigIntegerValue decimal(19, 2) with null, primary key (mammal))\p\g
create table JOINED (ID bigint not null, joinedName varchar(255) with null, primary key (ID))\p\g
create table Joiner (id bigint not null, name varchar(255) with null, primary key (id))\p\g
create table LineItem (customerId varchar(10) not null, orderNumber integer not null, productId varchar(10) not null, quantity integer with null, primary key (customerId, orderNumber, productId))\p\g
create table Lizard (reptile bigint not null, primary key (reptile))\p\g
create table MANY_TO_MANY (IN_ID bigint not null, OUT_ID bigint not null, primary key (IN_ID, OUT_ID))\p\g
create table MARECM (MCLINK bigint not null, MCOMPR varchar(1) with null, MCOMME varchar(30) with null, primary key (MCLINK))\p\g
create table MARELO (MLMAG integer not null, MLOCA varchar(11) not null, MLINK bigint with null, MLART varchar(13) with null, MLIDO bigint with null, MLDTC timestamp(9) with time zone with null, MLTOP varchar(10) with null, MLRAG varchar(2) with null, MLROP smallint with null, MLCOM bigint with null, MATRI varchar(14) with null, SOCOD varchar(10) with null, primary key (MLMAG, MLOCA))\p\g
create table Mammal (animal bigint not null, pregnant tinyint with null, birthdate ansidate with null, mammalZoo_id bigint with null, name varchar(255) with null, primary key (animal))\p\g
create table Model (modelId varchar(32) not null, name varchar(25) not null, description varchar(200) not null, productId varchar(32) not null, primary key (modelId))\p\g
create table Product (productId varchar(10) not null, description varchar(200) not null, cost decimal(19, 2) with null, numberAvailable integer with null, primary key (productId))\p\g
create table ProductLine (productId varchar(32) not null, description varchar(200) not null, primary key (productId))\p\g
create table Reptile (animal bigint not null, bodyTemperature float with null, primary key (animal))\p\g
create table SIMPLE_1 (ID bigint not null, NAME varchar(255) with null, negated_num integer with null, primary key (ID))\p\g
create table SIMPLE_2 (ID bigint not null, NAME varchar(255) with null, SIMPLE_1_ID bigint with null, primary key (ID))\p\g
create table StateProvince (id bigint not null, name varchar(255) with null, isoCode varchar(255) with null, primary key (id))\p\g
create table T_CHAR_PROP (ID bigint not null, VAL varchar(255) not null, primary key (ID))\p\g
create table T_COMPLEX_PROP (ID bigint not null, primary key (ID))\p\g
create table T_COMPLEX_SUB_PROPS (PROP_ID bigint not null, SUB_PROP_VAL varchar(255) with null, SUB_PROP_NAME varchar(255) not null, primary key (PROP_ID, SUB_PROP_NAME))\p\g
create table T_GEN_PROPS (PROP_SET_ID bigint not null, PROP_TYPE varchar(255) with null, PROP_ID bigint with null, GEN_PROP_NAME varchar(255) not null, primary key (PROP_SET_ID, GEN_PROP_NAME))\p\g
create table T_NUM_PROP (ID bigint not null, VAL integer not null, primary key (ID))\p\g
create table T_PROP_SET (ID bigint not null, NAME varchar(255) with null, S_S_PROP_TYPE varchar(255) with null, S_S_PROP_ID bigint with null, primary key (ID))\p\g
create table VariousKeywordPropertyEntity (id bigint not null, type varchar(255) with null, value varchar(255) with null, key varchar(255) with null, entry varchar(255) with null, primary key (id))\p\g
create table Zoo (id bigint not null, zooType char(1) not null, name varchar(255) with null, classification tinyint with null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, primary key (id))\p\g
create table "User" (id bigint not null, userName varchar(255) with null, primary key (id))\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, bar_string varchar(24) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table addresses (human bigint not null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, type varchar(255) not null, primary key (human, type))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table family (human1 bigint not null, human2 bigint not null, relationship varchar(255) not null, primary key (human1, relationship))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table friends (human1 bigint not null, human2 bigint not null)\p\g
create table human_nick_names (human bigint not null, nick_name varchar(255) not null, primary key (human, nick_name))\p\g
create table image (id bigint not null, name varchar(255) with null, size_mb float with null, primary key (id))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, primary key (many_key))\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, primary key (one_key))\p\g
create table permissions (userId bigint not null, permissionName varchar(255) with null, permissionId integer not null, primary key (userId, permissionId))\p\g
alter table Animal add constraint FK752A7A1C4B485C79 foreign key (zoo_id) references Zoo\p\g
alter table Animal add constraint FK752A7A1C1F3964B4 foreign key (mother_id) references Animal\p\g
alter table Animal add constraint FK752A7A1C6309E77B foreign key (father_id) references Animal\p\g
alter table CRAZY_ID_TOP add constraint FK1AA9579F73113F33 foreign key (heresAnotherCrazyIdFieldName) references CRAZY_ID_NODE\p\g
alter table Cat add constraint FK107B66D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table CustomerOrder add constraint FKAEF781F06153C9DD foreign key (customerId) references Customer\p\g
alter table Dog add constraint FK10D1C6D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table DomesticAnimal add constraint FKE02638DA1733655F foreign key (mammal) references Mammal\p\g
alter table DomesticAnimal add constraint FKE02638DA6C03411F foreign key (owner) references Human\p\g
alter table Human add constraint FK42D710D1733655F foreign key (mammal) references Mammal\p\g
alter table JOINED add constraint FK82C23B49534E0F13 foreign key (ID) references Joiner\p\g
alter table LineItem add constraint FK4AAEE947EDAE41F3 foreign key (productId) references Product\p\g
alter table LineItem add constraint FK4AAEE947CB8F4618 foreign key (customerId, orderNumber) references CustomerOrder\p\g
alter table Lizard add constraint FK87B0E2B6EE398315 foreign key (reptile) references Reptile\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C3E0DF2A91 foreign key (OUT_ID) references SIMPLE_1\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C322C9695A foreign key (IN_ID) references SIMPLE_1\p\g
alter table MARELO add constraint FK871F728AE624DD92 foreign key (MLCOM) references MARECM\p\g
alter table Mammal add constraint FK88EF417FEFA9D699 foreign key (animal) references Animal\p\g
alter table Mammal add constraint FK88EF417FCE6EEE98 foreign key (mammalZoo_id) references Zoo\p\g
alter table Model add constraint FK4710B0921C08435 foreign key (productId) references ProductLine\p\g
alter table Reptile add constraint FKA4790CABEFA9D699 foreign key (animal) references Animal\p\g
alter table SIMPLE_2 add constraint FK4B988CE5C81DD13B foreign key (SIMPLE_1_ID) references SIMPLE_1\p\g
alter table T_COMPLEX_SUB_PROPS add constraint FK5470D25725D7CC5B foreign key (PROP_ID) references T_COMPLEX_PROP\p\g
alter table T_GEN_PROPS add constraint FK65C7C556AA2002A9 foreign key (PROP_SET_ID) references T_PROP_SET\p\g
alter table Zoo add constraint FK15FBA55106523 foreign key (state_prov_id) references StateProvince\p\g
alter table "User" add constraint FK285FEB65AF5B87 foreign key (id) references Human\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table addresses add constraint FK34207BA255106523 foreign key (state_prov_id) references StateProvince\p\g
alter table addresses add constraint FK34207BA26B9FAF99 foreign key (human) references Human\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table family add constraint FKB3985B641DCB1311 foreign key (human2) references Human\p\g
alter table family add constraint FKB3985B641DCB1310 foreign key (human1) references Human\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table friends add constraint FKDC3B49951DCB1311 foreign key (human2) references Human\p\g
alter table friends add constraint FKDC3B49951DCB1310 foreign key (human1) references Human\p\g
alter table human_nick_names add constraint FK8718E1BE6B9FAF99 foreign key (human) references Human\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table permissions add constraint FK4392F484F2810CD2 foreign key (userId) references "User"\p\g
create sequence hibernate_sequence\p\g
select max(ID) from T_PROP_SET\p\g
select max(ID) from T_CHAR_PROP\p\g
select max(ID) from T_NUM_PROP\p\g
insert into T_CHAR_PROP (VAL, ID) values ('red', 1)\p\g
insert into T_PROP_SET (NAME, S_S_PROP_TYPE, S_S_PROP_ID, ID) values ('my properties', 'S', 1, 1)\p\g
insert into T_CHAR_PROP (VAL, ID) values ('pina coladas', 2)\p\g
insert into T_NUM_PROP (VAL, ID) values (1, 1)\p\g
insert into T_CHAR_PROP (VAL, ID) values ('getting caught in the rain', 3)\p\g
insert into T_GEN_PROPS (PROP_SET_ID, GEN_PROP_NAME, PROP_TYPE, PROP_ID) values (1, 'i like', 'S', 2)\p\g
insert into T_GEN_PROPS (PROP_SET_ID, GEN_PROP_NAME, PROP_TYPE, PROP_ID) values (1, 'the lonliest number', 'I', 1)\p\g
insert into T_GEN_PROPS (PROP_SET_ID, GEN_PROP_NAME, PROP_TYPE, PROP_ID) values (1, 'i also like', 'S', 3)\p\g
select propertyse0_.ID as ID38_, propertyse0_.NAME as NAME38_, propertyse0_.S_S_PROP_TYPE as S3_38_, propertyse0_.S_S_PROP_ID as S4_38_ from T_PROP_SET propertyse0_ where propertyse0_.S_S_PROP_TYPE='S' and propertyse0_.S_S_PROP_ID=1\p\g
select propertyse0_.ID as ID38_, propertyse0_.NAME as NAME38_, propertyse0_.S_S_PROP_TYPE as S3_38_, propertyse0_.S_S_PROP_ID as S4_38_ from T_PROP_SET propertyse0_ where propertyse0_.S_S_PROP_ID is not null\p\g
select propertyse0_.ID as ID38_, propertyse0_.NAME as NAME38_, propertyse0_.S_S_PROP_TYPE as S3_38_, propertyse0_.S_S_PROP_ID as S4_38_ from T_PROP_SET propertyse0_ inner join T_GEN_PROPS generalpro1_ on propertyse0_.ID=generalpro1_.PROP_SET_ID where generalpro1_.PROP_ID is not null\p\g
select generalpro0_.PROP_SET_ID as PROP1_0_, generalpro0_.PROP_TYPE as PROP2_0_, generalpro0_.PROP_ID as PROP3_0_, generalpro0_.GEN_PROP_NAME as GEN4_0_ from T_GEN_PROPS generalpro0_ where generalpro0_.PROP_SET_ID=1\p\g
select stringprop0_.ID as ID40_0_, stringprop0_.VAL as VAL40_0_ from T_CHAR_PROP stringprop0_ where stringprop0_.ID=2\p\g
select integerpro0_.ID as ID41_0_, integerpro0_.VAL as VAL41_0_ from T_NUM_PROP integerpro0_ where integerpro0_.ID=1\p\g
select stringprop0_.ID as ID40_0_, stringprop0_.VAL as VAL40_0_ from T_CHAR_PROP stringprop0_ where stringprop0_.ID=3\p\g
select stringprop0_.ID as ID40_0_, stringprop0_.VAL as VAL40_0_ from T_CHAR_PROP stringprop0_ where stringprop0_.ID=1\p\g
delete from T_GEN_PROPS where PROP_SET_ID=1\p\g
delete from T_CHAR_PROP where ID=2\p\g
delete from T_NUM_PROP where ID=1\p\g
delete from T_CHAR_PROP where ID=3\p\g
delete from T_PROP_SET where ID=1\p\g
delete from T_CHAR_PROP where ID=1\p\g
select zoo0_.id as id14_, zoo0_.name as name14_, zoo0_.classification as classifi4_14_, zoo0_.street as street14_, zoo0_.city as city14_, zoo0_.postalCode as postalCode14_, zoo0_.country as country14_, zoo0_.state_prov_id as state9_14_, zoo0_.zooType as zooType14_ from Zoo zoo0_ where zoo0_.classification=1\p\g
Parameter count mismatch 1730, 0,1
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.description=?
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
create table Animal (id bigint not null, description varchar(255) with null, body_weight float with null, mother_id bigint with null, father_id bigint with null, zoo_id bigint with null, serialNumber varchar(255) with null, primary key (id))\p\g
create table CRAZY_ID_NODE (ID bigint not null, name varchar(255) with null, primary key (ID))\p\g
create table CRAZY_ID_TOP (ID bigint not null, name varchar(255) with null, heresAnotherCrazyIdFieldName bigint with null, primary key (ID))\p\g
create table Cat (mammal bigint not null, primary key (mammal))\p\g
create table Customer (customerId varchar(10) not null, name varchar(100) not null, address varchar(200) not null, primary key (customerId))\p\g
create table CustomerOrder (customerId varchar(10) not null, orderNumber integer not null, orderDate ansidate not null, primary key (customerId, orderNumber))\p\g
create table Dog (mammal bigint not null, primary key (mammal))\p\g
create table DomesticAnimal (mammal bigint not null, owner bigint with null, primary key (mammal))\p\g
create table HQL_COMP_CONT (ID bigint not null, STREET_ADDR varchar(255) with null, CITY_ADDR varchar(255) with null, STATE_ADDR varchar(255) with null, ZIP_CODE_ADDR integer with null, ZIP_PLUS4_ADDR integer with null, primary key (ID))\p\g
create table Human (mammal bigint not null, name_first varchar(255) with null, name_initial char(1) with null, name_last varchar(255) with null, nickName varchar(255) with null, height_centimeters float not null, intValue integer with null, floatValue float with null, bigDecimalValue decimal(19, 2) with null, bigIntegerValue decimal(19, 2) with null, primary key (mammal))\p\g
create table JOINED (ID bigint not null, joinedName varchar(255) with null, primary key (ID))\p\g
create table Joiner (id bigint not null, name varchar(255) with null, primary key (id))\p\g
create table LineItem (customerId varchar(10) not null, orderNumber integer not null, productId varchar(10) not null, quantity integer with null, primary key (customerId, orderNumber, productId))\p\g
create table Lizard (reptile bigint not null, primary key (reptile))\p\g
create table MANY_TO_MANY (IN_ID bigint not null, OUT_ID bigint not null, primary key (IN_ID, OUT_ID))\p\g
create table MARECM (MCLINK bigint not null, MCOMPR varchar(1) with null, MCOMME varchar(30) with null, primary key (MCLINK))\p\g
create table MARELO (MLMAG integer not null, MLOCA varchar(11) not null, MLINK bigint with null, MLART varchar(13) with null, MLIDO bigint with null, MLDTC timestamp(9) with time zone with null, MLTOP varchar(10) with null, MLRAG varchar(2) with null, MLROP smallint with null, MLCOM bigint with null, MATRI varchar(14) with null, SOCOD varchar(10) with null, primary key (MLMAG, MLOCA))\p\g
create table Mammal (animal bigint not null, pregnant tinyint with null, birthdate ansidate with null, mammalZoo_id bigint with null, name varchar(255) with null, primary key (animal))\p\g
create table Model (modelId varchar(32) not null, name varchar(25) not null, description varchar(200) not null, productId varchar(32) not null, primary key (modelId))\p\g
create table Product (productId varchar(10) not null, description varchar(200) not null, cost decimal(19, 2) with null, numberAvailable integer with null, primary key (productId))\p\g
create table ProductLine (productId varchar(32) not null, description varchar(200) not null, primary key (productId))\p\g
create table Reptile (animal bigint not null, bodyTemperature float with null, primary key (animal))\p\g
create table SIMPLE_1 (ID bigint not null, NAME varchar(255) with null, negated_num integer with null, primary key (ID))\p\g
create table SIMPLE_2 (ID bigint not null, NAME varchar(255) with null, SIMPLE_1_ID bigint with null, primary key (ID))\p\g
create table StateProvince (id bigint not null, name varchar(255) with null, isoCode varchar(255) with null, primary key (id))\p\g
create table T_CHAR_PROP (ID bigint not null, VAL varchar(255) not null, primary key (ID))\p\g
create table T_COMPLEX_PROP (ID bigint not null, primary key (ID))\p\g
create table T_COMPLEX_SUB_PROPS (PROP_ID bigint not null, SUB_PROP_VAL varchar(255) with null, SUB_PROP_NAME varchar(255) not null, primary key (PROP_ID, SUB_PROP_NAME))\p\g
create table T_GEN_PROPS (PROP_SET_ID bigint not null, PROP_TYPE varchar(255) with null, PROP_ID bigint with null, GEN_PROP_NAME varchar(255) not null, primary key (PROP_SET_ID, GEN_PROP_NAME))\p\g
create table T_NUM_PROP (ID bigint not null, VAL integer not null, primary key (ID))\p\g
create table T_PROP_SET (ID bigint not null, NAME varchar(255) with null, S_S_PROP_TYPE varchar(255) with null, S_S_PROP_ID bigint with null, primary key (ID))\p\g
create table VariousKeywordPropertyEntity (id bigint not null, type varchar(255) with null, value varchar(255) with null, key varchar(255) with null, entry varchar(255) with null, primary key (id))\p\g
create table Zoo (id bigint not null, zooType char(1) not null, name varchar(255) with null, classification tinyint with null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, primary key (id))\p\g
create table "User" (id bigint not null, userName varchar(255) with null, primary key (id))\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, bar_string varchar(24) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table addresses (human bigint not null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, type varchar(255) not null, primary key (human, type))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table family (human1 bigint not null, human2 bigint not null, relationship varchar(255) not null, primary key (human1, relationship))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table friends (human1 bigint not null, human2 bigint not null)\p\g
create table human_nick_names (human bigint not null, nick_name varchar(255) not null, primary key (human, nick_name))\p\g
create table image (id bigint not null, name varchar(255) with null, size_mb float with null, primary key (id))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, primary key (many_key))\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, primary key (one_key))\p\g
create table permissions (userId bigint not null, permissionName varchar(255) with null, permissionId integer not null, primary key (userId, permissionId))\p\g
alter table Animal add constraint FK752A7A1C4B485C79 foreign key (zoo_id) references Zoo\p\g
alter table Animal add constraint FK752A7A1C1F3964B4 foreign key (mother_id) references Animal\p\g
alter table Animal add constraint FK752A7A1C6309E77B foreign key (father_id) references Animal\p\g
alter table CRAZY_ID_TOP add constraint FK1AA9579F73113F33 foreign key (heresAnotherCrazyIdFieldName) references CRAZY_ID_NODE\p\g
alter table Cat add constraint FK107B66D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table CustomerOrder add constraint FKAEF781F06153C9DD foreign key (customerId) references Customer\p\g
alter table Dog add constraint FK10D1C6D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table DomesticAnimal add constraint FKE02638DA1733655F foreign key (mammal) references Mammal\p\g
alter table DomesticAnimal add constraint FKE02638DA6C03411F foreign key (owner) references Human\p\g
alter table Human add constraint FK42D710D1733655F foreign key (mammal) references Mammal\p\g
alter table JOINED add constraint FK82C23B49534E0F13 foreign key (ID) references Joiner\p\g
alter table LineItem add constraint FK4AAEE947EDAE41F3 foreign key (productId) references Product\p\g
alter table LineItem add constraint FK4AAEE947CB8F4618 foreign key (customerId, orderNumber) references CustomerOrder\p\g
alter table Lizard add constraint FK87B0E2B6EE398315 foreign key (reptile) references Reptile\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C3E0DF2A91 foreign key (OUT_ID) references SIMPLE_1\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C322C9695A foreign key (IN_ID) references SIMPLE_1\p\g
alter table MARELO add constraint FK871F728AE624DD92 foreign key (MLCOM) references MARECM\p\g
alter table Mammal add constraint FK88EF417FEFA9D699 foreign key (animal) references Animal\p\g
alter table Mammal add constraint FK88EF417FCE6EEE98 foreign key (mammalZoo_id) references Zoo\p\g
alter table Model add constraint FK4710B0921C08435 foreign key (productId) references ProductLine\p\g
alter table Reptile add constraint FKA4790CABEFA9D699 foreign key (animal) references Animal\p\g
alter table SIMPLE_2 add constraint FK4B988CE5C81DD13B foreign key (SIMPLE_1_ID) references SIMPLE_1\p\g
alter table T_COMPLEX_SUB_PROPS add constraint FK5470D25725D7CC5B foreign key (PROP_ID) references T_COMPLEX_PROP\p\g
alter table T_GEN_PROPS add constraint FK65C7C556AA2002A9 foreign key (PROP_SET_ID) references T_PROP_SET\p\g
alter table Zoo add constraint FK15FBA55106523 foreign key (state_prov_id) references StateProvince\p\g
alter table "User" add constraint FK285FEB65AF5B87 foreign key (id) references Human\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table addresses add constraint FK34207BA255106523 foreign key (state_prov_id) references StateProvince\p\g
alter table addresses add constraint FK34207BA26B9FAF99 foreign key (human) references Human\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table family add constraint FKB3985B641DCB1311 foreign key (human2) references Human\p\g
alter table family add constraint FKB3985B641DCB1310 foreign key (human1) references Human\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table friends add constraint FKDC3B49951DCB1311 foreign key (human2) references Human\p\g
alter table friends add constraint FKDC3B49951DCB1310 foreign key (human1) references Human\p\g
alter table human_nick_names add constraint FK8718E1BE6B9FAF99 foreign key (human) references Human\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table permissions add constraint FK4392F484F2810CD2 foreign key (userId) references "User"\p\g
create sequence hibernate_sequence\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
create table Animal (id bigint not null, description varchar(255) with null, body_weight float with null, mother_id bigint with null, father_id bigint with null, zoo_id bigint with null, serialNumber varchar(255) with null, primary key (id))\p\g
create table CRAZY_ID_NODE (ID bigint not null, name varchar(255) with null, primary key (ID))\p\g
create table CRAZY_ID_TOP (ID bigint not null, name varchar(255) with null, heresAnotherCrazyIdFieldName bigint with null, primary key (ID))\p\g
create table Cat (mammal bigint not null, primary key (mammal))\p\g
create table Customer (customerId varchar(10) not null, name varchar(100) not null, address varchar(200) not null, primary key (customerId))\p\g
create table CustomerOrder (customerId varchar(10) not null, orderNumber integer not null, orderDate ansidate not null, primary key (customerId, orderNumber))\p\g
create table Dog (mammal bigint not null, primary key (mammal))\p\g
create table DomesticAnimal (mammal bigint not null, owner bigint with null, primary key (mammal))\p\g
create table HQL_COMP_CONT (ID bigint not null, STREET_ADDR varchar(255) with null, CITY_ADDR varchar(255) with null, STATE_ADDR varchar(255) with null, ZIP_CODE_ADDR integer with null, ZIP_PLUS4_ADDR integer with null, primary key (ID))\p\g
create table Human (mammal bigint not null, name_first varchar(255) with null, name_initial char(1) with null, name_last varchar(255) with null, nickName varchar(255) with null, height_centimeters float not null, intValue integer with null, floatValue float with null, bigDecimalValue decimal(19, 2) with null, bigIntegerValue decimal(19, 2) with null, primary key (mammal))\p\g
create table JOINED (ID bigint not null, joinedName varchar(255) with null, primary key (ID))\p\g
create table Joiner (id bigint not null, name varchar(255) with null, primary key (id))\p\g
create table LineItem (customerId varchar(10) not null, orderNumber integer not null, productId varchar(10) not null, quantity integer with null, primary key (customerId, orderNumber, productId))\p\g
create table Lizard (reptile bigint not null, primary key (reptile))\p\g
create table MANY_TO_MANY (IN_ID bigint not null, OUT_ID bigint not null, primary key (IN_ID, OUT_ID))\p\g
create table MARECM (MCLINK bigint not null, MCOMPR varchar(1) with null, MCOMME varchar(30) with null, primary key (MCLINK))\p\g
create table MARELO (MLMAG integer not null, MLOCA varchar(11) not null, MLINK bigint with null, MLART varchar(13) with null, MLIDO bigint with null, MLDTC timestamp(9) with time zone with null, MLTOP varchar(10) with null, MLRAG varchar(2) with null, MLROP smallint with null, MLCOM bigint with null, MATRI varchar(14) with null, SOCOD varchar(10) with null, primary key (MLMAG, MLOCA))\p\g
create table Mammal (animal bigint not null, pregnant tinyint with null, birthdate ansidate with null, mammalZoo_id bigint with null, name varchar(255) with null, primary key (animal))\p\g
create table Model (modelId varchar(32) not null, name varchar(25) not null, description varchar(200) not null, productId varchar(32) not null, primary key (modelId))\p\g
create table Product (productId varchar(10) not null, description varchar(200) not null, cost decimal(19, 2) with null, numberAvailable integer with null, primary key (productId))\p\g
create table ProductLine (productId varchar(32) not null, description varchar(200) not null, primary key (productId))\p\g
create table Reptile (animal bigint not null, bodyTemperature float with null, primary key (animal))\p\g
create table SIMPLE_1 (ID bigint not null, NAME varchar(255) with null, negated_num integer with null, primary key (ID))\p\g
create table SIMPLE_2 (ID bigint not null, NAME varchar(255) with null, SIMPLE_1_ID bigint with null, primary key (ID))\p\g
create table StateProvince (id bigint not null, name varchar(255) with null, isoCode varchar(255) with null, primary key (id))\p\g
create table T_CHAR_PROP (ID bigint not null, VAL varchar(255) not null, primary key (ID))\p\g
create table T_COMPLEX_PROP (ID bigint not null, primary key (ID))\p\g
create table T_COMPLEX_SUB_PROPS (PROP_ID bigint not null, SUB_PROP_VAL varchar(255) with null, SUB_PROP_NAME varchar(255) not null, primary key (PROP_ID, SUB_PROP_NAME))\p\g
create table T_GEN_PROPS (PROP_SET_ID bigint not null, PROP_TYPE varchar(255) with null, PROP_ID bigint with null, GEN_PROP_NAME varchar(255) not null, primary key (PROP_SET_ID, GEN_PROP_NAME))\p\g
create table T_NUM_PROP (ID bigint not null, VAL integer not null, primary key (ID))\p\g
create table T_PROP_SET (ID bigint not null, NAME varchar(255) with null, S_S_PROP_TYPE varchar(255) with null, S_S_PROP_ID bigint with null, primary key (ID))\p\g
create table VariousKeywordPropertyEntity (id bigint not null, type varchar(255) with null, value varchar(255) with null, key varchar(255) with null, entry varchar(255) with null, primary key (id))\p\g
create table Zoo (id bigint not null, zooType char(1) not null, name varchar(255) with null, classification tinyint with null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, primary key (id))\p\g
create table "User" (id bigint not null, userName varchar(255) with null, primary key (id))\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, bar_string varchar(24) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table addresses (human bigint not null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, type varchar(255) not null, primary key (human, type))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table family (human1 bigint not null, human2 bigint not null, relationship varchar(255) not null, primary key (human1, relationship))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table friends (human1 bigint not null, human2 bigint not null)\p\g
create table human_nick_names (human bigint not null, nick_name varchar(255) not null, primary key (human, nick_name))\p\g
create table image (id bigint not null, name varchar(255) with null, size_mb float with null, primary key (id))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, primary key (many_key))\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, primary key (one_key))\p\g
create table permissions (userId bigint not null, permissionName varchar(255) with null, permissionId integer not null, primary key (userId, permissionId))\p\g
alter table Animal add constraint FK752A7A1C4B485C79 foreign key (zoo_id) references Zoo\p\g
alter table Animal add constraint FK752A7A1C1F3964B4 foreign key (mother_id) references Animal\p\g
alter table Animal add constraint FK752A7A1C6309E77B foreign key (father_id) references Animal\p\g
alter table CRAZY_ID_TOP add constraint FK1AA9579F73113F33 foreign key (heresAnotherCrazyIdFieldName) references CRAZY_ID_NODE\p\g
alter table Cat add constraint FK107B66D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table CustomerOrder add constraint FKAEF781F06153C9DD foreign key (customerId) references Customer\p\g
alter table Dog add constraint FK10D1C6D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table DomesticAnimal add constraint FKE02638DA1733655F foreign key (mammal) references Mammal\p\g
alter table DomesticAnimal add constraint FKE02638DA6C03411F foreign key (owner) references Human\p\g
alter table Human add constraint FK42D710D1733655F foreign key (mammal) references Mammal\p\g
alter table JOINED add constraint FK82C23B49534E0F13 foreign key (ID) references Joiner\p\g
alter table LineItem add constraint FK4AAEE947EDAE41F3 foreign key (productId) references Product\p\g
alter table LineItem add constraint FK4AAEE947CB8F4618 foreign key (customerId, orderNumber) references CustomerOrder\p\g
alter table Lizard add constraint FK87B0E2B6EE398315 foreign key (reptile) references Reptile\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C3E0DF2A91 foreign key (OUT_ID) references SIMPLE_1\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C322C9695A foreign key (IN_ID) references SIMPLE_1\p\g
alter table MARELO add constraint FK871F728AE624DD92 foreign key (MLCOM) references MARECM\p\g
alter table Mammal add constraint FK88EF417FEFA9D699 foreign key (animal) references Animal\p\g
alter table Mammal add constraint FK88EF417FCE6EEE98 foreign key (mammalZoo_id) references Zoo\p\g
alter table Model add constraint FK4710B0921C08435 foreign key (productId) references ProductLine\p\g
alter table Reptile add constraint FKA4790CABEFA9D699 foreign key (animal) references Animal\p\g
alter table SIMPLE_2 add constraint FK4B988CE5C81DD13B foreign key (SIMPLE_1_ID) references SIMPLE_1\p\g
alter table T_COMPLEX_SUB_PROPS add constraint FK5470D25725D7CC5B foreign key (PROP_ID) references T_COMPLEX_PROP\p\g
alter table T_GEN_PROPS add constraint FK65C7C556AA2002A9 foreign key (PROP_SET_ID) references T_PROP_SET\p\g
alter table Zoo add constraint FK15FBA55106523 foreign key (state_prov_id) references StateProvince\p\g
alter table "User" add constraint FK285FEB65AF5B87 foreign key (id) references Human\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table addresses add constraint FK34207BA255106523 foreign key (state_prov_id) references StateProvince\p\g
alter table addresses add constraint FK34207BA26B9FAF99 foreign key (human) references Human\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table family add constraint FKB3985B641DCB1311 foreign key (human2) references Human\p\g
alter table family add constraint FKB3985B641DCB1310 foreign key (human1) references Human\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table friends add constraint FKDC3B49951DCB1311 foreign key (human2) references Human\p\g
alter table friends add constraint FKDC3B49951DCB1310 foreign key (human1) references Human\p\g
alter table human_nick_names add constraint FK8718E1BE6B9FAF99 foreign key (human) references Human\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table permissions add constraint FK4392F484F2810CD2 foreign key (userId) references "User"\p\g
create sequence hibernate_sequence\p\g
select animal0_.id as col_0_0_, animal0_.description as col_1_0_ from Animal animal0_ left outer join Animal offspring1_ on animal0_.id=offspring1_.mother_id where animal0_.id in (select animal2_.id from Animal animal2_ left outer join Animal offspring3_ on animal2_.id=offspring3_.mother_id where animal2_.id=1)\p\g
select human0_.mammal as col_0_0_, human0_2_.description as col_1_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id left outer join friends friends1_ on human0_.mammal=friends1_.human1 left outer join Human human2_ on friends1_.human2=human2_.mammal left outer join Mammal human2_1_ on human2_.mammal=human2_1_.animal left outer join Animal human2_2_ on human2_.mammal=human2_2_.id where human0_.mammal in (select human3_.mammal from Human human3_ inner join Mammal human3_1_ on human3_.mammal=human3_1_.animal inner join Animal human3_2_ on human3_.mammal=human3_2_.id left outer join friends friends4_ on human3_.mammal=friends4_.human1 left outer join Human human5_ on friends4_.human2=human5_.mammal left outer join Mammal human5_1_ on human5_.mammal=human5_1_.animal left outer join Animal human5_2_ on human5_.mammal=human5_2_.id where human3_.mammal=1)\p\g
select human0_.mammal as col_0_0_, human0_2_.description as col_1_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id left outer join friends friends1_ on human0_.mammal=friends1_.human1 left outer join Human human2_ on friends1_.human2=human2_.mammal left outer join Mammal human2_1_ on human2_.mammal=human2_1_.animal left outer join Animal human2_2_ on human2_.mammal=human2_2_.id where human2_.mammal in (select human3_.mammal from Human human3_ inner join Mammal human3_1_ on human3_.mammal=human3_1_.animal inner join Animal human3_2_ on human3_.mammal=human3_2_.id left outer join friends friends4_ on human3_.mammal=friends4_.human1 left outer join Human human5_ on friends4_.human2=human5_.mammal left outer join Mammal human5_1_ on human5_.mammal=human5_1_.animal left outer join Animal human5_2_ on human5_.mammal=human5_2_.id where human0_.mammal=human5_.mammal)\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent', 0.0, null, null, null, null, 1)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent ', 0.0, null, null, null, null, 2)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent', 0.0, null, null, null, '123-0', 3)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent', 0.0, null, null, null, null, 4)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent ', 0.0, null, null, null, null, 5)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent', 0.0, null, null, null, '123-1', 6)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent', 0.0, null, null, null, null, 7)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent ', 0.0, null, null, null, null, 8)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent', 0.0, null, null, null, '123-2', 9)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent', 0.0, null, null, null, null, 10)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent ', 0.0, null, null, null, null, 11)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent', 0.0, null, null, null, '123-3', 12)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent', 0.0, null, null, null, null, 13)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent ', 0.0, null, null, null, null, 14)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent', 0.0, null, null, null, '123-4', 15)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent', 0.0, null, null, null, null, 16)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent ', 0.0, null, null, null, null, 17)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent', 0.0, null, null, null, '123-5', 18)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent', 0.0, null, null, null, null, 19)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent ', 0.0, null, null, null, null, 20)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent', 0.0, null, null, null, '123-6', 21)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent', 0.0, null, null, null, null, 22)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent ', 0.0, null, null, null, null, 23)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent', 0.0, null, null, null, '123-7', 24)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent', 0.0, null, null, null, null, 25)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent ', 0.0, null, null, null, null, 26)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent', 0.0, null, null, null, '123-8', 27)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent', 0.0, null, null, null, null, 28)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent ', 0.0, null, null, null, null, 29)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent', 0.0, null, null, null, '123-9', 30)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent1', 0.0, null, null, null, null, 31)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 1', 0.0, null, null, null, null, 32)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent1', 0.0, null, null, null, '123-10', 33)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent1', 0.0, null, null, null, null, 34)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 1', 0.0, null, null, null, null, 35)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent1', 0.0, null, null, null, '123-11', 36)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent1', 0.0, null, null, null, null, 37)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 1', 0.0, null, null, null, null, 38)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent1', 0.0, null, null, null, '123-12', 39)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent1', 0.0, null, null, null, null, 40)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 1', 0.0, null, null, null, null, 41)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent1', 0.0, null, null, null, '123-13', 42)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent1', 0.0, null, null, null, null, 43)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 1', 0.0, null, null, null, null, 44)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent1', 0.0, null, null, null, '123-14', 45)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent1', 0.0, null, null, null, null, 46)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 1', 0.0, null, null, null, null, 47)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent1', 0.0, null, null, null, '123-15', 48)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent1', 0.0, null, null, null, null, 49)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 1', 0.0, null, null, null, null, 50)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent1', 0.0, null, null, null, '123-16', 51)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent1', 0.0, null, null, null, null, 52)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 1', 0.0, null, null, null, null, 53)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent1', 0.0, null, null, null, '123-17', 54)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent1', 0.0, null, null, null, null, 55)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 1', 0.0, null, null, null, null, 56)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent1', 0.0, null, null, null, '123-18', 57)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent1', 0.0, null, null, null, null, 58)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 1', 0.0, null, null, null, null, 59)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent1', 0.0, null, null, null, '123-19', 60)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent2', 0.0, null, null, null, null, 61)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 2', 0.0, null, null, null, null, 62)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent2', 0.0, null, null, null, '123-20', 63)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent2', 0.0, null, null, null, null, 64)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 2', 0.0, null, null, null, null, 65)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent2', 0.0, null, null, null, '123-21', 66)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent2', 0.0, null, null, null, null, 67)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 2', 0.0, null, null, null, null, 68)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent2', 0.0, null, null, null, '123-22', 69)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent2', 0.0, null, null, null, null, 70)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 2', 0.0, null, null, null, null, 71)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent2', 0.0, null, null, null, '123-23', 72)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent2', 0.0, null, null, null, null, 73)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 2', 0.0, null, null, null, null, 74)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent2', 0.0, null, null, null, '123-24', 75)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent2', 0.0, null, null, null, null, 76)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 2', 0.0, null, null, null, null, 77)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent2', 0.0, null, null, null, '123-25', 78)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent2', 0.0, null, null, null, null, 79)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 2', 0.0, null, null, null, null, 80)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent2', 0.0, null, null, null, '123-26', 81)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent2', 0.0, null, null, null, null, 82)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 2', 0.0, null, null, null, null, 83)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent2', 0.0, null, null, null, '123-27', 84)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent2', 0.0, null, null, null, null, 85)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 2', 0.0, null, null, null, null, 86)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent2', 0.0, null, null, null, '123-28', 87)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child1 - parent2', 0.0, null, null, null, null, 88)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (child2 - parent 2', 0.0, null, null, null, null, 89)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('collection fetch distinction (parent2', 0.0, null, null, null, '123-29', 90)\p\g
update Animal set mother_id=3 where id=1\p\g
update Animal set mother_id=3 where id=2\p\g
update Animal set mother_id=6 where id=5\p\g
update Animal set mother_id=6 where id=4\p\g
update Animal set mother_id=9 where id=7\p\g
update Animal set mother_id=9 where id=8\p\g
update Animal set mother_id=12 where id=10\p\g
update Animal set mother_id=12 where id=11\p\g
update Animal set mother_id=15 where id=13\p\g
update Animal set mother_id=15 where id=14\p\g
update Animal set mother_id=18 where id=16\p\g
update Animal set mother_id=18 where id=17\p\g
update Animal set mother_id=21 where id=20\p\g
update Animal set mother_id=21 where id=19\p\g
update Animal set mother_id=24 where id=22\p\g
update Animal set mother_id=24 where id=23\p\g
update Animal set mother_id=27 where id=25\p\g
update Animal set mother_id=27 where id=26\p\g
update Animal set mother_id=30 where id=29\p\g
update Animal set mother_id=30 where id=28\p\g
update Animal set mother_id=33 where id=32\p\g
update Animal set mother_id=33 where id=31\p\g
update Animal set mother_id=36 where id=34\p\g
update Animal set mother_id=36 where id=35\p\g
update Animal set mother_id=39 where id=37\p\g
update Animal set mother_id=39 where id=38\p\g
update Animal set mother_id=42 where id=41\p\g
update Animal set mother_id=42 where id=40\p\g
update Animal set mother_id=45 where id=43\p\g
update Animal set mother_id=45 where id=44\p\g
update Animal set mother_id=48 where id=47\p\g
update Animal set mother_id=48 where id=46\p\g
update Animal set mother_id=51 where id=50\p\g
update Animal set mother_id=51 where id=49\p\g
update Animal set mother_id=54 where id=52\p\g
update Animal set mother_id=54 where id=53\p\g
update Animal set mother_id=57 where id=55\p\g
update Animal set mother_id=57 where id=56\p\g
update Animal set mother_id=60 where id=58\p\g
update Animal set mother_id=60 where id=59\p\g
update Animal set mother_id=63 where id=61\p\g
update Animal set mother_id=63 where id=62\p\g
update Animal set mother_id=66 where id=65\p\g
update Animal set mother_id=66 where id=64\p\g
update Animal set mother_id=69 where id=67\p\g
update Animal set mother_id=69 where id=68\p\g
update Animal set mother_id=72 where id=70\p\g
update Animal set mother_id=72 where id=71\p\g
update Animal set mother_id=75 where id=73\p\g
update Animal set mother_id=75 where id=74\p\g
update Animal set mother_id=78 where id=77\p\g
update Animal set mother_id=78 where id=76\p\g
update Animal set mother_id=81 where id=79\p\g
update Animal set mother_id=81 where id=80\p\g
update Animal set mother_id=84 where id=82\p\g
update Animal set mother_id=84 where id=83\p\g
update Animal set mother_id=87 where id=85\p\g
update Animal set mother_id=87 where id=86\p\g
update Animal set mother_id=90 where id=88\p\g
update Animal set mother_id=90 where id=89\p\g
select distinct animal0_.id as id0_0_, offspring1_.id as id0_1_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_, offspring1_.description as descript2_0_1_, offspring1_.body_weight as body3_0_1_, offspring1_.mother_id as mother4_0_1_, offspring1_.father_id as father5_0_1_, offspring1_.zoo_id as zoo6_0_1_, offspring1_.serialNumber as serialNu7_0_1_, offspring1_1_.bodyTemperature as bodyTemp2_1_1_, offspring1_3_.pregnant as pregnant3_1_, offspring1_3_.birthdate as birthdate3_1_, offspring1_4_.owner as owner4_1_, offspring1_7_.name_first as name2_7_1_, offspring1_7_.name_initial as name3_7_1_, offspring1_7_.name_last as name4_7_1_, offspring1_7_.nickName as nickName7_1_, offspring1_7_.height_centimeters / 2.54 as height6_7_1_, offspring1_7_.intValue as intValue7_1_, offspring1_7_.floatValue as floatValue7_1_, offspring1_7_.bigDecimalValue as bigDecim9_7_1_, offspring1_7_.bigIntegerValue as bigInte10_7_1_, case when offspring1_2_.reptile is not null then 2 when offspring1_5_.mammal is not null then 5 when offspring1_6_.mammal is not null then 6 when offspring1_4_.mammal is not null then 4 when offspring1_7_.mammal is not null then 7 when offspring1_1_.animal is not null then 1 when offspring1_3_.animal is not null then 3 when offspring1_.id is not null then 0 end as clazz_1_, offspring1_.mother_id as mother4_0__, offspring1_.id as id0__ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal inner join Animal offspring1_ on animal0_.id=offspring1_.mother_id left outer join Reptile offspring1_1_ on offspring1_.id=offspring1_1_.animal left outer join Lizard offspring1_2_ on offspring1_.id=offspring1_2_.reptile left outer join Mammal offspring1_3_ on offspring1_.id=offspring1_3_.animal left outer join DomesticAnimal offspring1_4_ on offspring1_.id=offspring1_4_.mammal left outer join Cat offspring1_5_ on offspring1_.id=offspring1_5_.mammal left outer join Dog offspring1_6_ on offspring1_.id=offspring1_6_.mammal left outer join Human offspring1_7_ on offspring1_.id=offspring1_7_.mammal order by offspring1_.father_id\p\g
select animal0_.id as id0_0_, offspring1_.id as id0_1_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_, offspring1_.description as descript2_0_1_, offspring1_.body_weight as body3_0_1_, offspring1_.mother_id as mother4_0_1_, offspring1_.father_id as father5_0_1_, offspring1_.zoo_id as zoo6_0_1_, offspring1_.serialNumber as serialNu7_0_1_, offspring1_1_.bodyTemperature as bodyTemp2_1_1_, offspring1_3_.pregnant as pregnant3_1_, offspring1_3_.birthdate as birthdate3_1_, offspring1_4_.owner as owner4_1_, offspring1_7_.name_first as name2_7_1_, offspring1_7_.name_initial as name3_7_1_, offspring1_7_.name_last as name4_7_1_, offspring1_7_.nickName as nickName7_1_, offspring1_7_.height_centimeters / 2.54 as height6_7_1_, offspring1_7_.intValue as intValue7_1_, offspring1_7_.floatValue as floatValue7_1_, offspring1_7_.bigDecimalValue as bigDecim9_7_1_, offspring1_7_.bigIntegerValue as bigInte10_7_1_, case when offspring1_2_.reptile is not null then 2 when offspring1_5_.mammal is not null then 5 when offspring1_6_.mammal is not null then 6 when offspring1_4_.mammal is not null then 4 when offspring1_7_.mammal is not null then 7 when offspring1_1_.animal is not null then 1 when offspring1_3_.animal is not null then 3 when offspring1_.id is not null then 0 end as clazz_1_, offspring1_.mother_id as mother4_0__, offspring1_.id as id0__ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal inner join Animal offspring1_ on animal0_.id=offspring1_.mother_id left outer join Reptile offspring1_1_ on offspring1_.id=offspring1_1_.animal left outer join Lizard offspring1_2_ on offspring1_.id=offspring1_2_.reptile left outer join Mammal offspring1_3_ on offspring1_.id=offspring1_3_.animal left outer join DomesticAnimal offspring1_4_ on offspring1_.id=offspring1_4_.mammal left outer join Cat offspring1_5_ on offspring1_.id=offspring1_5_.mammal left outer join Dog offspring1_6_ on offspring1_.id=offspring1_6_.mammal left outer join Human offspring1_7_ on offspring1_.id=offspring1_7_.mammal order by animal0_.id, offspring1_.father_id\p\g
declare global temporary table session.HT_Animal (id bigint not null) on commit preserve rows with norecovery\p\g
insert into session.HT_Animal select animal0_.id as id from Animal animal0_ where mother_id is not null\p\g
delete from Human where (mammal) IN (select id from session.HT_Animal)\p\g
delete from Dog where (mammal) IN (select id from session.HT_Animal)\p\g
delete from Cat where (mammal) IN (select id from session.HT_Animal)\p\g
delete from DomesticAnimal where (mammal) IN (select id from session.HT_Animal)\p\g
delete from Mammal where (animal) IN (select id from session.HT_Animal)\p\g
delete from Lizard where (reptile) IN (select id from session.HT_Animal)\p\g
delete from Reptile where (animal) IN (select id from session.HT_Animal)\p\g
delete from Animal where (id) IN (select id from session.HT_Animal)\p\g
drop table session.HT_Animal\p\g
declare global temporary table session.HT_Animal (id bigint not null) on commit preserve rows with norecovery\p\g
insert into session.HT_Animal select animal0_.id as id from Animal animal0_\p\g
delete from Human where (mammal) IN (select id from session.HT_Animal)\p\g
delete from Dog where (mammal) IN (select id from session.HT_Animal)\p\g
delete from Cat where (mammal) IN (select id from session.HT_Animal)\p\g
delete from DomesticAnimal where (mammal) IN (select id from session.HT_Animal)\p\g
delete from Mammal where (animal) IN (select id from session.HT_Animal)\p\g
delete from Lizard where (reptile) IN (select id from session.HT_Animal)\p\g
delete from Reptile where (animal) IN (select id from session.HT_Animal)\p\g
delete from Animal where (id) IN (select id from session.HT_Animal)\p\g
drop table session.HT_Animal\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Tiger', 0.0, null, null, null, null, 91)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 91)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Tiger''s mother', 4.0, null, null, null, null, 92)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 92)\p\g
insert into Zoo (name, classification, street, city, postalCode, country, state_prov_id, zooType, id) values ('Austin Zoo', null, null, null, null, null, null, ''Z'', 93)\p\g
update Zoo set name='Austin Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=93\p\g
update Animal set mother_id=92 where id=91\p\g
update Mammal set mammalZoo_id=93, name='tiger' where animal=91\p\g
select zoo0_.id as id14_, zoo0_.name as name14_, zoo0_.classification as classifi4_14_, zoo0_.street as street14_, zoo0_.city as city14_, zoo0_.postalCode as postalCode14_, zoo0_.country as country14_, zoo0_.state_prov_id as state9_14_, zoo0_.zooType as zooType14_ from Zoo zoo0_ cross join Mammal mammals1_ inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id cross join Animal animal2_ where zoo0_.id=mammals1_.mammalZoo_id and mammals1_.name = ''tiger'' and mammals1_1_.mother_id=animal2_.id and animal2_.body_weight>3.0\p\g
update Zoo set name='Austin Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=93\p\g
update Zoo set name='Austin Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=93\p\g
update Animal set mother_id=null where mother_id=91\p\g
update Animal set mother_id=null where mother_id=92\p\g
update Mammal set mammalZoo_id=null, name=null where mammalZoo_id=93\p\g
delete from Mammal where animal=91\p\g
delete from Animal where id=91\p\g
delete from Mammal where animal=92\p\g
delete from Animal where id=92\p\g
delete from Zoo where id=93\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_, nicknames1_.human as human0__, nicknames1_.nick_name as nick2_0__ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id inner join human_nick_names nicknames1_ on human0_.mammal=nicknames1_.human\p\g
select foo0_."foo_idcolumnname123" as foo1_18_, foo0_.version as version18_, foo0_.foo as foo18_, foo0_.long_ as long5_18_, foo0_."integer__" as integer6_18_, foo0_.float_ as float7_18_, foo0_.x as x18_, foo0_.double_ as double9_18_, foo0_.date_ as date10_18_, foo0_.timestamp_ as timestamp11_18_, foo0_.boolean_ as boolean12_18_, foo0_.bool_ as bool13_18_, foo0_.null_ as null14_18_, foo0_.short_ as short15_18_, foo0_.char_ as char16_18_, foo0_.zero_ as zero17_18_, foo0_.int_ as int18_18_, foo0_.string_ as string19_18_, foo0_.byte_ as byte20_18_, foo0_.yesno as yesno18_, foo0_.blobb_ as blobb22_18_, foo0_.nullBlob as nullBlob18_, foo0_.bin_ as bin24_18_, foo0_."localeayzabc123" as localea25_18_, foo0_.first_name as first26_18_, foo0_.surname as surname18_, foo0_.null_cmpnt_ as null28_18_, foo0_1_.joinedProp as joinedProp20_, foo0_.the_time as the29_18_, foo0_.bar_string as bar30_18_, foo0_.clazz as clazz18_, foo0_.gen_id as gen32_18_, foo0_2_.name_name as name2_21_, foo0_.int_/2 as formula0_, foo0_."foo_subclass_1234" as foo2_18_ from "foos" foo0_ inner join jointable foo0_1_ on foo0_."foo_idcolumnname123"=foo0_1_.fooid left outer join bar_join_table foo0_2_ on foo0_."foo_idcolumnname123"=foo0_2_.bar_id where foo0_."foo_subclass_1234" in (''F'', ''B'', ''T'') and foo0_.long_=1\p\g
select foo0_."foo_idcolumnname123" as foo1_18_, foo0_.version as version18_, foo0_.foo as foo18_, foo0_.long_ as long5_18_, foo0_."integer__" as integer6_18_, foo0_.float_ as float7_18_, foo0_.x as x18_, foo0_.double_ as double9_18_, foo0_.date_ as date10_18_, foo0_.timestamp_ as timestamp11_18_, foo0_.boolean_ as boolean12_18_, foo0_.bool_ as bool13_18_, foo0_.null_ as null14_18_, foo0_.short_ as short15_18_, foo0_.char_ as char16_18_, foo0_.zero_ as zero17_18_, foo0_.int_ as int18_18_, foo0_.string_ as string19_18_, foo0_.byte_ as byte20_18_, foo0_.yesno as yesno18_, foo0_.blobb_ as blobb22_18_, foo0_.nullBlob as nullBlob18_, foo0_.bin_ as bin24_18_, foo0_."localeayzabc123" as localea25_18_, foo0_.first_name as first26_18_, foo0_.surname as surname18_, foo0_.null_cmpnt_ as null28_18_, foo0_1_.joinedProp as joinedProp20_, foo0_.the_time as the29_18_, foo0_.bar_string as bar30_18_, foo0_.clazz as clazz18_, foo0_.gen_id as gen32_18_, foo0_2_.name_name as name2_21_, foo0_.int_/2 as formula0_, foo0_."foo_subclass_1234" as foo2_18_ from "foos" foo0_ inner join jointable foo0_1_ on foo0_."foo_idcolumnname123"=foo0_1_.fooid left outer join bar_join_table foo0_2_ on foo0_."foo_idcolumnname123"=foo0_2_.bar_id where foo0_."foo_subclass_1234" in (''F'', ''B'', ''T'') and foo0_.long_=-2147483648\p\g
select foo0_."foo_idcolumnname123" as foo1_18_, foo0_.version as version18_, foo0_.foo as foo18_, foo0_.long_ as long5_18_, foo0_."integer__" as integer6_18_, foo0_.float_ as float7_18_, foo0_.x as x18_, foo0_.double_ as double9_18_, foo0_.date_ as date10_18_, foo0_.timestamp_ as timestamp11_18_, foo0_.boolean_ as boolean12_18_, foo0_.bool_ as bool13_18_, foo0_.null_ as null14_18_, foo0_.short_ as short15_18_, foo0_.char_ as char16_18_, foo0_.zero_ as zero17_18_, foo0_.int_ as int18_18_, foo0_.string_ as string19_18_, foo0_.byte_ as byte20_18_, foo0_.yesno as yesno18_, foo0_.blobb_ as blobb22_18_, foo0_.nullBlob as nullBlob18_, foo0_.bin_ as bin24_18_, foo0_."localeayzabc123" as localea25_18_, foo0_.first_name as first26_18_, foo0_.surname as surname18_, foo0_.null_cmpnt_ as null28_18_, foo0_1_.joinedProp as joinedProp20_, foo0_.the_time as the29_18_, foo0_.bar_string as bar30_18_, foo0_.clazz as clazz18_, foo0_.gen_id as gen32_18_, foo0_2_.name_name as name2_21_, foo0_.int_/2 as formula0_, foo0_."foo_subclass_1234" as foo2_18_ from "foos" foo0_ inner join jointable foo0_1_ on foo0_."foo_idcolumnname123"=foo0_1_.fooid left outer join bar_join_table foo0_2_ on foo0_."foo_idcolumnname123"=foo0_2_.bar_id where foo0_."foo_subclass_1234" in (''F'', ''B'', ''T'') and foo0_.long_=2147483647\p\g
select foo0_."foo_idcolumnname123" as foo1_18_, foo0_.version as version18_, foo0_.foo as foo18_, foo0_.long_ as long5_18_, foo0_."integer__" as integer6_18_, foo0_.float_ as float7_18_, foo0_.x as x18_, foo0_.double_ as double9_18_, foo0_.date_ as date10_18_, foo0_.timestamp_ as timestamp11_18_, foo0_.boolean_ as boolean12_18_, foo0_.bool_ as bool13_18_, foo0_.null_ as null14_18_, foo0_.short_ as short15_18_, foo0_.char_ as char16_18_, foo0_.zero_ as zero17_18_, foo0_.int_ as int18_18_, foo0_.string_ as string19_18_, foo0_.byte_ as byte20_18_, foo0_.yesno as yesno18_, foo0_.blobb_ as blobb22_18_, foo0_.nullBlob as nullBlob18_, foo0_.bin_ as bin24_18_, foo0_."localeayzabc123" as localea25_18_, foo0_.first_name as first26_18_, foo0_.surname as surname18_, foo0_.null_cmpnt_ as null28_18_, foo0_1_.joinedProp as joinedProp20_, foo0_.the_time as the29_18_, foo0_.bar_string as bar30_18_, foo0_.clazz as clazz18_, foo0_.gen_id as gen32_18_, foo0_2_.name_name as name2_21_, foo0_.int_/2 as formula0_, foo0_."foo_subclass_1234" as foo2_18_ from "foos" foo0_ inner join jointable foo0_1_ on foo0_."foo_idcolumnname123"=foo0_1_.fooid left outer join bar_join_table foo0_2_ on foo0_."foo_idcolumnname123"=foo0_2_.bar_id where foo0_."foo_subclass_1234" in (''F'', ''B'', ''T'') and foo0_.long_=1\p\g
select foo0_."foo_idcolumnname123" as foo1_18_, foo0_.version as version18_, foo0_.foo as foo18_, foo0_.long_ as long5_18_, foo0_."integer__" as integer6_18_, foo0_.float_ as float7_18_, foo0_.x as x18_, foo0_.double_ as double9_18_, foo0_.date_ as date10_18_, foo0_.timestamp_ as timestamp11_18_, foo0_.boolean_ as boolean12_18_, foo0_.bool_ as bool13_18_, foo0_.null_ as null14_18_, foo0_.short_ as short15_18_, foo0_.char_ as char16_18_, foo0_.zero_ as zero17_18_, foo0_.int_ as int18_18_, foo0_.string_ as string19_18_, foo0_.byte_ as byte20_18_, foo0_.yesno as yesno18_, foo0_.blobb_ as blobb22_18_, foo0_.nullBlob as nullBlob18_, foo0_.bin_ as bin24_18_, foo0_."localeayzabc123" as localea25_18_, foo0_.first_name as first26_18_, foo0_.surname as surname18_, foo0_.null_cmpnt_ as null28_18_, foo0_1_.joinedProp as joinedProp20_, foo0_.the_time as the29_18_, foo0_.bar_string as bar30_18_, foo0_.clazz as clazz18_, foo0_.gen_id as gen32_18_, foo0_2_.name_name as name2_21_, foo0_.int_/2 as formula0_, foo0_."foo_subclass_1234" as foo2_18_ from "foos" foo0_ inner join jointable foo0_1_ on foo0_."foo_idcolumnname123"=foo0_1_.fooid left outer join bar_join_table foo0_2_ on foo0_."foo_idcolumnname123"=foo0_2_.bar_id where foo0_."foo_subclass_1234" in (''F'', ''B'', ''T'') and foo0_.long_=-9223372036854775807\p\g
select foo0_."foo_idcolumnname123" as foo1_18_, foo0_.version as version18_, foo0_.foo as foo18_, foo0_.long_ as long5_18_, foo0_."integer__" as integer6_18_, foo0_.float_ as float7_18_, foo0_.x as x18_, foo0_.double_ as double9_18_, foo0_.date_ as date10_18_, foo0_.timestamp_ as timestamp11_18_, foo0_.boolean_ as boolean12_18_, foo0_.bool_ as bool13_18_, foo0_.null_ as null14_18_, foo0_.short_ as short15_18_, foo0_.char_ as char16_18_, foo0_.zero_ as zero17_18_, foo0_.int_ as int18_18_, foo0_.string_ as string19_18_, foo0_.byte_ as byte20_18_, foo0_.yesno as yesno18_, foo0_.blobb_ as blobb22_18_, foo0_.nullBlob as nullBlob18_, foo0_.bin_ as bin24_18_, foo0_."localeayzabc123" as localea25_18_, foo0_.first_name as first26_18_, foo0_.surname as surname18_, foo0_.null_cmpnt_ as null28_18_, foo0_1_.joinedProp as joinedProp20_, foo0_.the_time as the29_18_, foo0_.bar_string as bar30_18_, foo0_.clazz as clazz18_, foo0_.gen_id as gen32_18_, foo0_2_.name_name as name2_21_, foo0_.int_/2 as formula0_, foo0_."foo_subclass_1234" as foo2_18_ from "foos" foo0_ inner join jointable foo0_1_ on foo0_."foo_idcolumnname123"=foo0_1_.fooid left outer join bar_join_table foo0_2_ on foo0_."foo_idcolumnname123"=foo0_2_.bar_id where foo0_."foo_subclass_1234" in (''F'', ''B'', ''T'') and foo0_.long_=9223372036854775807\p\g
select foo0_."foo_idcolumnname123" as foo1_18_, foo0_.version as version18_, foo0_.foo as foo18_, foo0_.long_ as long5_18_, foo0_."integer__" as integer6_18_, foo0_.float_ as float7_18_, foo0_.x as x18_, foo0_.double_ as double9_18_, foo0_.date_ as date10_18_, foo0_.timestamp_ as timestamp11_18_, foo0_.boolean_ as boolean12_18_, foo0_.bool_ as bool13_18_, foo0_.null_ as null14_18_, foo0_.short_ as short15_18_, foo0_.char_ as char16_18_, foo0_.zero_ as zero17_18_, foo0_.int_ as int18_18_, foo0_.string_ as string19_18_, foo0_.byte_ as byte20_18_, foo0_.yesno as yesno18_, foo0_.blobb_ as blobb22_18_, foo0_.nullBlob as nullBlob18_, foo0_.bin_ as bin24_18_, foo0_."localeayzabc123" as localea25_18_, foo0_.first_name as first26_18_, foo0_.surname as surname18_, foo0_.null_cmpnt_ as null28_18_, foo0_1_.joinedProp as joinedProp20_, foo0_.the_time as the29_18_, foo0_.bar_string as bar30_18_, foo0_.clazz as clazz18_, foo0_.gen_id as gen32_18_, foo0_2_.name_name as name2_21_, foo0_.int_/2 as formula0_, foo0_."foo_subclass_1234" as foo2_18_ from "foos" foo0_ inner join jointable foo0_1_ on foo0_."foo_idcolumnname123"=foo0_1_.fooid left outer join bar_join_table foo0_2_ on foo0_."foo_idcolumnname123"=foo0_2_.bar_id where foo0_."foo_subclass_1234" in (''F'', ''B'', ''T'') and foo0_."integer__"=-9223372036854775807\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight>1.000E-8\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight>1.000E-8\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight>100.001\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight>100.001\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight>100.001\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight>100.001\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight>0.001\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight>1.00E-8\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight>1E-12\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight>1E-38\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight=animal0_.body_weight\p\g
select animal0_.body_weight as col_0_0_ from Animal animal0_\p\g
select max(animal0_.body_weight) as col_0_0_ from Animal animal0_\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where human0_.name_first=''Gavin''\p\g
select human0_.name_first as col_0_0_, human0_.name_initial as col_0_1_, human0_.name_last as col_0_2_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
select upper(human0_.name_first) as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
select upper(human0_.name_first) as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal cross join Animal animal1_ where animal0_.mother_id=animal1_.id and animal1_.father_id=1\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.mother_id=null\p\g
select zoo0_.id as id14_, zoo0_.name as name14_, zoo0_.classification as classifi4_14_, zoo0_.street as street14_, zoo0_.city as city14_, zoo0_.postalCode as postalCode14_, zoo0_.country as country14_, zoo0_.state_prov_id as state9_14_, zoo0_.zooType as zooType14_ from Zoo zoo0_ cross join Mammal mammals1_ inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id where zoo0_.id=mammals1_.mammalZoo_id and mammals1_.name = ''dog'' and (mammals1_1_.description like ''%black%'')\p\g
select nextval for hibernate_sequence\p\g
insert into Zoo (name, classification, street, city, postalCode, country, state_prov_id, zooType, id) values ('Melbourne Zoo', null, null, null, null, null, null, ''Z'', 94)\p\g
update Zoo set name='Melbourne Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=94\p\g
select 2*2*2*2*2*2 as col_0_0_ from Zoo zoo0_\p\g
update Zoo set name='Melbourne Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=94\p\g
select 2/(1+1) as col_0_0_ from Zoo zoo0_\p\g
update Zoo set name='Melbourne Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=94\p\g
select 2-(1+1) as col_0_0_ from Zoo zoo0_\p\g
update Zoo set name='Melbourne Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=94\p\g
select 2-1+1 as col_0_0_ from Zoo zoo0_\p\g
update Zoo set name='Melbourne Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=94\p\g
select 2*(1-1) as col_0_0_ from Zoo zoo0_\p\g
update Zoo set name='Melbourne Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=94\p\g
select 4/(2*2) as col_0_0_ from Zoo zoo0_\p\g
update Zoo set name='Melbourne Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=94\p\g
select 4/2*2 as col_0_0_ from Zoo zoo0_\p\g
update Zoo set name='Melbourne Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=94\p\g
select 2*2/2 as col_0_0_ from Zoo zoo0_\p\g
update Zoo set name='Melbourne Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=94\p\g
select 2*(2/2+1) as col_0_0_ from Zoo zoo0_\p\g
update Zoo set name='Melbourne Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=94\p\g
delete from Zoo where id=94\p\g
select animal0_.id as id0_0_, offspring1_.id as id0_1_, offspring2_.id as id0_2_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_, offspring1_.description as descript2_0_1_, offspring1_.body_weight as body3_0_1_, offspring1_.mother_id as mother4_0_1_, offspring1_.father_id as father5_0_1_, offspring1_.zoo_id as zoo6_0_1_, offspring1_.serialNumber as serialNu7_0_1_, offspring1_1_.bodyTemperature as bodyTemp2_1_1_, offspring1_3_.pregnant as pregnant3_1_, offspring1_3_.birthdate as birthdate3_1_, offspring1_4_.owner as owner4_1_, offspring1_7_.name_first as name2_7_1_, offspring1_7_.name_initial as name3_7_1_, offspring1_7_.name_last as name4_7_1_, offspring1_7_.nickName as nickName7_1_, offspring1_7_.height_centimeters / 2.54 as height6_7_1_, offspring1_7_.intValue as intValue7_1_, offspring1_7_.floatValue as floatValue7_1_, offspring1_7_.bigDecimalValue as bigDecim9_7_1_, offspring1_7_.bigIntegerValue as bigInte10_7_1_, case when offspring1_2_.reptile is not null then 2 when offspring1_5_.mammal is not null then 5 when offspring1_6_.mammal is not null then 6 when offspring1_4_.mammal is not null then 4 when offspring1_7_.mammal is not null then 7 when offspring1_1_.animal is not null then 1 when offspring1_3_.animal is not null then 3 when offspring1_.id is not null then 0 end as clazz_1_, offspring1_.mother_id as mother4_0__, offspring1_.id as id0__, offspring2_.description as descript2_0_2_, offspring2_.body_weight as body3_0_2_, offspring2_.mother_id as mother4_0_2_, offspring2_.father_id as father5_0_2_, offspring2_.zoo_id as zoo6_0_2_, offspring2_.serialNumber as serialNu7_0_2_, offspring2_1_.bodyTemperature as bodyTemp2_1_2_, offspring2_3_.pregnant as pregnant3_2_, offspring2_3_.birthdate as birthdate3_2_, offspring2_4_.owner as owner4_2_, offspring2_7_.name_first as name2_7_2_, offspring2_7_.name_initial as name3_7_2_, offspring2_7_.name_last as name4_7_2_, offspring2_7_.nickName as nickName7_2_, offspring2_7_.height_centimeters / 2.54 as height6_7_2_, offspring2_7_.intValue as intValue7_2_, offspring2_7_.floatValue as floatValue7_2_, offspring2_7_.bigDecimalValue as bigDecim9_7_2_, offspring2_7_.bigIntegerValue as bigInte10_7_2_, case when offspring2_2_.reptile is not null then 2 when offspring2_5_.mammal is not null then 5 when offspring2_6_.mammal is not null then 6 when offspring2_4_.mammal is not null then 4 when offspring2_7_.mammal is not null then 7 when offspring2_1_.animal is not null then 1 when offspring2_3_.animal is not null then 3 when offspring2_.id is not null then 0 end as clazz_2_, offspring2_.mother_id as mother4_1__, offspring2_.id as id1__ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal left outer join Animal offspring1_ on animal0_.id=offspring1_.mother_id left outer join Reptile offspring1_1_ on offspring1_.id=offspring1_1_.animal left outer join Lizard offspring1_2_ on offspring1_.id=offspring1_2_.reptile left outer join Mammal offspring1_3_ on offspring1_.id=offspring1_3_.animal left outer join DomesticAnimal offspring1_4_ on offspring1_.id=offspring1_4_.mammal left outer join Cat offspring1_5_ on offspring1_.id=offspring1_5_.mammal left outer join Dog offspring1_6_ on offspring1_.id=offspring1_6_.mammal left outer join Human offspring1_7_ on offspring1_.id=offspring1_7_.mammal left outer join Animal offspring2_ on offspring1_.id=offspring2_.mother_id left outer join Reptile offspring2_1_ on offspring2_.id=offspring2_1_.animal left outer join Lizard offspring2_2_ on offspring2_.id=offspring2_2_.reptile left outer join Mammal offspring2_3_ on offspring2_.id=offspring2_3_.animal left outer join DomesticAnimal offspring2_4_ on offspring2_.id=offspring2_4_.mammal left outer join Cat offspring2_5_ on offspring2_.id=offspring2_5_.mammal left outer join Dog offspring2_6_ on offspring2_.id=offspring2_6_.mammal left outer join Human offspring2_7_ on offspring2_.id=offspring2_7_.mammal where animal0_.mother_id=1 order by animal0_.description, offspring1_.father_id, offspring2_.father_id\p\g
select zoo0_.id as id14_0_, animals1_.id as id0_1_, offspring2_.id as id0_2_, zoo0_.name as name14_0_, zoo0_.classification as classifi4_14_0_, zoo0_.street as street14_0_, zoo0_.city as city14_0_, zoo0_.postalCode as postalCode14_0_, zoo0_.country as country14_0_, zoo0_.state_prov_id as state9_14_0_, zoo0_.zooType as zooType14_0_, animals1_.description as descript2_0_1_, animals1_.body_weight as body3_0_1_, animals1_.mother_id as mother4_0_1_, animals1_.father_id as father5_0_1_, animals1_.zoo_id as zoo6_0_1_, animals1_.serialNumber as serialNu7_0_1_, animals1_1_.bodyTemperature as bodyTemp2_1_1_, animals1_3_.pregnant as pregnant3_1_, animals1_3_.birthdate as birthdate3_1_, animals1_4_.owner as owner4_1_, animals1_7_.name_first as name2_7_1_, animals1_7_.name_initial as name3_7_1_, animals1_7_.name_last as name4_7_1_, animals1_7_.nickName as nickName7_1_, animals1_7_.height_centimeters / 2.54 as height6_7_1_, animals1_7_.intValue as intValue7_1_, animals1_7_.floatValue as floatValue7_1_, animals1_7_.bigDecimalValue as bigDecim9_7_1_, animals1_7_.bigIntegerValue as bigInte10_7_1_, case when animals1_2_.reptile is not null then 2 when animals1_5_.mammal is not null then 5 when animals1_6_.mammal is not null then 6 when animals1_4_.mammal is not null then 4 when animals1_7_.mammal is not null then 7 when animals1_1_.animal is not null then 1 when animals1_3_.animal is not null then 3 when animals1_.id is not null then 0 end as clazz_1_, animals1_.zoo_id as zoo6_0__, animals1_.id as id0__, animals1_.serialNumber as serialNu7_0__, offspring2_.description as descript2_0_2_, offspring2_.body_weight as body3_0_2_, offspring2_.mother_id as mother4_0_2_, offspring2_.father_id as father5_0_2_, offspring2_.zoo_id as zoo6_0_2_, offspring2_.serialNumber as serialNu7_0_2_, offspring2_1_.bodyTemperature as bodyTemp2_1_2_, offspring2_3_.pregnant as pregnant3_2_, offspring2_3_.birthdate as birthdate3_2_, offspring2_4_.owner as owner4_2_, offspring2_7_.name_first as name2_7_2_, offspring2_7_.name_initial as name3_7_2_, offspring2_7_.name_last as name4_7_2_, offspring2_7_.nickName as nickName7_2_, offspring2_7_.height_centimeters / 2.54 as height6_7_2_, offspring2_7_.intValue as intValue7_2_, offspring2_7_.floatValue as floatValue7_2_, offspring2_7_.bigDecimalValue as bigDecim9_7_2_, offspring2_7_.bigIntegerValue as bigInte10_7_2_, case when offspring2_2_.reptile is not null then 2 when offspring2_5_.mammal is not null then 5 when offspring2_6_.mammal is not null then 6 when offspring2_4_.mammal is not null then 4 when offspring2_7_.mammal is not null then 7 when offspring2_1_.animal is not null then 1 when offspring2_3_.animal is not null then 3 when offspring2_.id is not null then 0 end as clazz_2_, offspring2_.mother_id as mother4_1__, offspring2_.id as id1__ from Zoo zoo0_ left outer join Animal animals1_ on zoo0_.id=animals1_.zoo_id left outer join Reptile animals1_1_ on animals1_.id=animals1_1_.animal left outer join Lizard animals1_2_ on animals1_.id=animals1_2_.reptile left outer join Mammal animals1_3_ on animals1_.id=animals1_3_.animal left outer join DomesticAnimal animals1_4_ on animals1_.id=animals1_4_.mammal left outer join Cat animals1_5_ on animals1_.id=animals1_5_.mammal left outer join Dog animals1_6_ on animals1_.id=animals1_6_.mammal left outer join Human animals1_7_ on animals1_.id=animals1_7_.mammal left outer join Animal offspring2_ on animals1_.id=offspring2_.mother_id left outer join Reptile offspring2_1_ on offspring2_.id=offspring2_1_.animal left outer join Lizard offspring2_2_ on offspring2_.id=offspring2_2_.reptile left outer join Mammal offspring2_3_ on offspring2_.id=offspring2_3_.animal left outer join DomesticAnimal offspring2_4_ on offspring2_.id=offspring2_4_.mammal left outer join Cat offspring2_5_ on offspring2_.id=offspring2_5_.mammal left outer join Dog offspring2_6_ on offspring2_.id=offspring2_6_.mammal left outer join Human offspring2_7_ on offspring2_.id=offspring2_7_.mammal where zoo0_.name=''MZ'' order by animals1_.description, offspring2_.father_id\p\g
select human0_.mammal as id0_0_, pets1_.mammal as id0_1_, offspring2_.id as id0_2_, human0_2_.description as descript2_0_0_, human0_2_.body_weight as body3_0_0_, human0_2_.mother_id as mother4_0_0_, human0_2_.father_id as father5_0_0_, human0_2_.zoo_id as zoo6_0_0_, human0_2_.serialNumber as serialNu7_0_0_, human0_1_.pregnant as pregnant3_0_, human0_1_.birthdate as birthdate3_0_, human0_.name_first as name2_7_0_, human0_.name_initial as name3_7_0_, human0_.name_last as name4_7_0_, human0_.nickName as nickName7_0_, human0_.height_centimeters / 2.54 as height6_7_0_, human0_.intValue as intValue7_0_, human0_.floatValue as floatValue7_0_, human0_.bigDecimalValue as bigDecim9_7_0_, human0_.bigIntegerValue as bigInte10_7_0_, pets1_2_.description as descript2_0_1_, pets1_2_.body_weight as body3_0_1_, pets1_2_.mother_id as mother4_0_1_, pets1_2_.father_id as father5_0_1_, pets1_2_.zoo_id as zoo6_0_1_, pets1_2_.serialNumber as serialNu7_0_1_, pets1_1_.pregnant as pregnant3_1_, pets1_1_.birthdate as birthdate3_1_, pets1_.owner as owner4_1_, case when pets1_3_.mammal is not null then 5 when pets1_4_.mammal is not null then 6 when pets1_.mammal is not null then 4 end as clazz_1_, pets1_.owner as owner0__, pets1_.mammal as mammal0__, offspring2_.description as descript2_0_2_, offspring2_.body_weight as body3_0_2_, offspring2_.mother_id as mother4_0_2_, offspring2_.father_id as father5_0_2_, offspring2_.zoo_id as zoo6_0_2_, offspring2_.serialNumber as serialNu7_0_2_, offspring2_1_.bodyTemperature as bodyTemp2_1_2_, offspring2_3_.pregnant as pregnant3_2_, offspring2_3_.birthdate as birthdate3_2_, offspring2_4_.owner as owner4_2_, offspring2_7_.name_first as name2_7_2_, offspring2_7_.name_initial as name3_7_2_, offspring2_7_.name_last as name4_7_2_, offspring2_7_.nickName as nickName7_2_, offspring2_7_.height_centimeters / 2.54 as height6_7_2_, offspring2_7_.intValue as intValue7_2_, offspring2_7_.floatValue as floatValue7_2_, offspring2_7_.bigDecimalValue as bigDecim9_7_2_, offspring2_7_.bigIntegerValue as bigInte10_7_2_, case when offspring2_2_.reptile is not null then 2 when offspring2_5_.mammal is not null then 5 when offspring2_6_.mammal is not null then 6 when offspring2_4_.mammal is not null then 4 when offspring2_7_.mammal is not null then 7 when offspring2_1_.animal is not null then 1 when offspring2_3_.animal is not null then 3 when offspring2_.id is not null then 0 end as clazz_2_, offspring2_.mother_id as mother4_1__, offspring2_.id as id1__ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id left outer join DomesticAnimal pets1_ on human0_.mammal=pets1_.owner left outer join Mammal pets1_1_ on pets1_.mammal=pets1_1_.animal left outer join Animal pets1_2_ on pets1_.mammal=pets1_2_.id left outer join Cat pets1_3_ on pets1_.mammal=pets1_3_.mammal left outer join Dog pets1_4_ on pets1_.mammal=pets1_4_.mammal left outer join Animal offspring2_ on pets1_.mammal=offspring2_.mother_id left outer join Reptile offspring2_1_ on offspring2_.id=offspring2_1_.animal left outer join Lizard offspring2_2_ on offspring2_.id=offspring2_2_.reptile left outer join Mammal offspring2_3_ on offspring2_.id=offspring2_3_.animal left outer join DomesticAnimal offspring2_4_ on offspring2_.id=offspring2_4_.mammal left outer join Cat offspring2_5_ on offspring2_.id=offspring2_5_.mammal left outer join Dog offspring2_6_ on offspring2_.id=offspring2_6_.mammal left outer join Human offspring2_7_ on offspring2_.id=offspring2_7_.mammal where human0_.name_first=''Gavin'' order by pets1_2_.description, offspring2_.father_id\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Platypus', 11.0, null, null, null, 'plat123', 95)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 95)\p\g
insert into Zoo (name, classification, street, city, postalCode, country, state_prov_id, zooType, id) values ('Melbourne Zoo', null, null, null, null, null, null, ''Z'', 96)\p\g
update Animal set description='Platypus', body_weight=11.0, mother_id=null, father_id=null, zoo_id=96, serialNumber='plat123' where id=95\p\g
update Zoo set name='Melbourne Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=96\p\g
update Mammal set mammalZoo_id=96, name='Platypus' where animal=95\p\g
select (select max(zoo1_.id) from Zoo zoo1_ where animal0_.zoo_id=zoo1_.id) as col_0_0_ from Animal animal0_\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
create table Animal (id bigint not null, description varchar(255) with null, body_weight float with null, mother_id bigint with null, father_id bigint with null, zoo_id bigint with null, serialNumber varchar(255) with null, primary key (id))\p\g
create table CRAZY_ID_NODE (ID bigint not null, name varchar(255) with null, primary key (ID))\p\g
create table CRAZY_ID_TOP (ID bigint not null, name varchar(255) with null, heresAnotherCrazyIdFieldName bigint with null, primary key (ID))\p\g
create table Cat (mammal bigint not null, primary key (mammal))\p\g
create table Customer (customerId varchar(10) not null, name varchar(100) not null, address varchar(200) not null, primary key (customerId))\p\g
create table CustomerOrder (customerId varchar(10) not null, orderNumber integer not null, orderDate ansidate not null, primary key (customerId, orderNumber))\p\g
create table Dog (mammal bigint not null, primary key (mammal))\p\g
create table DomesticAnimal (mammal bigint not null, owner bigint with null, primary key (mammal))\p\g
create table HQL_COMP_CONT (ID bigint not null, STREET_ADDR varchar(255) with null, CITY_ADDR varchar(255) with null, STATE_ADDR varchar(255) with null, ZIP_CODE_ADDR integer with null, ZIP_PLUS4_ADDR integer with null, primary key (ID))\p\g
create table Human (mammal bigint not null, name_first varchar(255) with null, name_initial char(1) with null, name_last varchar(255) with null, nickName varchar(255) with null, height_centimeters float not null, intValue integer with null, floatValue float with null, bigDecimalValue decimal(19, 2) with null, bigIntegerValue decimal(19, 2) with null, primary key (mammal))\p\g
create table JOINED (ID bigint not null, joinedName varchar(255) with null, primary key (ID))\p\g
create table Joiner (id bigint not null, name varchar(255) with null, primary key (id))\p\g
create table LineItem (customerId varchar(10) not null, orderNumber integer not null, productId varchar(10) not null, quantity integer with null, primary key (customerId, orderNumber, productId))\p\g
create table Lizard (reptile bigint not null, primary key (reptile))\p\g
create table MANY_TO_MANY (IN_ID bigint not null, OUT_ID bigint not null, primary key (IN_ID, OUT_ID))\p\g
create table MARECM (MCLINK bigint not null, MCOMPR varchar(1) with null, MCOMME varchar(30) with null, primary key (MCLINK))\p\g
create table MARELO (MLMAG integer not null, MLOCA varchar(11) not null, MLINK bigint with null, MLART varchar(13) with null, MLIDO bigint with null, MLDTC timestamp(9) with time zone with null, MLTOP varchar(10) with null, MLRAG varchar(2) with null, MLROP smallint with null, MLCOM bigint with null, MATRI varchar(14) with null, SOCOD varchar(10) with null, primary key (MLMAG, MLOCA))\p\g
create table Mammal (animal bigint not null, pregnant tinyint with null, birthdate ansidate with null, mammalZoo_id bigint with null, name varchar(255) with null, primary key (animal))\p\g
create table Model (modelId varchar(32) not null, name varchar(25) not null, description varchar(200) not null, productId varchar(32) not null, primary key (modelId))\p\g
create table Product (productId varchar(10) not null, description varchar(200) not null, cost decimal(19, 2) with null, numberAvailable integer with null, primary key (productId))\p\g
create table ProductLine (productId varchar(32) not null, description varchar(200) not null, primary key (productId))\p\g
create table Reptile (animal bigint not null, bodyTemperature float with null, primary key (animal))\p\g
create table SIMPLE_1 (ID bigint not null, NAME varchar(255) with null, negated_num integer with null, primary key (ID))\p\g
create table SIMPLE_2 (ID bigint not null, NAME varchar(255) with null, SIMPLE_1_ID bigint with null, primary key (ID))\p\g
create table StateProvince (id bigint not null, name varchar(255) with null, isoCode varchar(255) with null, primary key (id))\p\g
create table T_CHAR_PROP (ID bigint not null, VAL varchar(255) not null, primary key (ID))\p\g
create table T_COMPLEX_PROP (ID bigint not null, primary key (ID))\p\g
create table T_COMPLEX_SUB_PROPS (PROP_ID bigint not null, SUB_PROP_VAL varchar(255) with null, SUB_PROP_NAME varchar(255) not null, primary key (PROP_ID, SUB_PROP_NAME))\p\g
create table T_GEN_PROPS (PROP_SET_ID bigint not null, PROP_TYPE varchar(255) with null, PROP_ID bigint with null, GEN_PROP_NAME varchar(255) not null, primary key (PROP_SET_ID, GEN_PROP_NAME))\p\g
create table T_NUM_PROP (ID bigint not null, VAL integer not null, primary key (ID))\p\g
create table T_PROP_SET (ID bigint not null, NAME varchar(255) with null, S_S_PROP_TYPE varchar(255) with null, S_S_PROP_ID bigint with null, primary key (ID))\p\g
create table VariousKeywordPropertyEntity (id bigint not null, type varchar(255) with null, value varchar(255) with null, key varchar(255) with null, entry varchar(255) with null, primary key (id))\p\g
create table Zoo (id bigint not null, zooType char(1) not null, name varchar(255) with null, classification tinyint with null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, primary key (id))\p\g
create table "User" (id bigint not null, userName varchar(255) with null, primary key (id))\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, bar_string varchar(24) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table addresses (human bigint not null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, type varchar(255) not null, primary key (human, type))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table family (human1 bigint not null, human2 bigint not null, relationship varchar(255) not null, primary key (human1, relationship))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table friends (human1 bigint not null, human2 bigint not null)\p\g
create table human_nick_names (human bigint not null, nick_name varchar(255) not null, primary key (human, nick_name))\p\g
create table image (id bigint not null, name varchar(255) with null, size_mb float with null, primary key (id))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, primary key (many_key))\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, primary key (one_key))\p\g
create table permissions (userId bigint not null, permissionName varchar(255) with null, permissionId integer not null, primary key (userId, permissionId))\p\g
alter table Animal add constraint FK752A7A1C4B485C79 foreign key (zoo_id) references Zoo\p\g
alter table Animal add constraint FK752A7A1C1F3964B4 foreign key (mother_id) references Animal\p\g
alter table Animal add constraint FK752A7A1C6309E77B foreign key (father_id) references Animal\p\g
alter table CRAZY_ID_TOP add constraint FK1AA9579F73113F33 foreign key (heresAnotherCrazyIdFieldName) references CRAZY_ID_NODE\p\g
alter table Cat add constraint FK107B66D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table CustomerOrder add constraint FKAEF781F06153C9DD foreign key (customerId) references Customer\p\g
alter table Dog add constraint FK10D1C6D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table DomesticAnimal add constraint FKE02638DA1733655F foreign key (mammal) references Mammal\p\g
alter table DomesticAnimal add constraint FKE02638DA6C03411F foreign key (owner) references Human\p\g
alter table Human add constraint FK42D710D1733655F foreign key (mammal) references Mammal\p\g
alter table JOINED add constraint FK82C23B49534E0F13 foreign key (ID) references Joiner\p\g
alter table LineItem add constraint FK4AAEE947EDAE41F3 foreign key (productId) references Product\p\g
alter table LineItem add constraint FK4AAEE947CB8F4618 foreign key (customerId, orderNumber) references CustomerOrder\p\g
alter table Lizard add constraint FK87B0E2B6EE398315 foreign key (reptile) references Reptile\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C3E0DF2A91 foreign key (OUT_ID) references SIMPLE_1\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C322C9695A foreign key (IN_ID) references SIMPLE_1\p\g
alter table MARELO add constraint FK871F728AE624DD92 foreign key (MLCOM) references MARECM\p\g
alter table Mammal add constraint FK88EF417FEFA9D699 foreign key (animal) references Animal\p\g
alter table Mammal add constraint FK88EF417FCE6EEE98 foreign key (mammalZoo_id) references Zoo\p\g
alter table Model add constraint FK4710B0921C08435 foreign key (productId) references ProductLine\p\g
alter table Reptile add constraint FKA4790CABEFA9D699 foreign key (animal) references Animal\p\g
alter table SIMPLE_2 add constraint FK4B988CE5C81DD13B foreign key (SIMPLE_1_ID) references SIMPLE_1\p\g
alter table T_COMPLEX_SUB_PROPS add constraint FK5470D25725D7CC5B foreign key (PROP_ID) references T_COMPLEX_PROP\p\g
alter table T_GEN_PROPS add constraint FK65C7C556AA2002A9 foreign key (PROP_SET_ID) references T_PROP_SET\p\g
alter table Zoo add constraint FK15FBA55106523 foreign key (state_prov_id) references StateProvince\p\g
alter table "User" add constraint FK285FEB65AF5B87 foreign key (id) references Human\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table addresses add constraint FK34207BA255106523 foreign key (state_prov_id) references StateProvince\p\g
alter table addresses add constraint FK34207BA26B9FAF99 foreign key (human) references Human\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table family add constraint FKB3985B641DCB1311 foreign key (human2) references Human\p\g
alter table family add constraint FKB3985B641DCB1310 foreign key (human1) references Human\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table friends add constraint FKDC3B49951DCB1311 foreign key (human2) references Human\p\g
alter table friends add constraint FKDC3B49951DCB1310 foreign key (human1) references Human\p\g
alter table human_nick_names add constraint FK8718E1BE6B9FAF99 foreign key (human) references Human\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table permissions add constraint FK4392F484F2810CD2 foreign key (userId) references "User"\p\g
create sequence hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Platypus', 11.0, null, null, null, null, 1)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 1)\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal\p\g
update Animal set mother_id=null where mother_id=1\p\g
delete from Mammal where animal=1\p\g
delete from Animal where id=1\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Platypus', 11.0, null, null, null, 'plat123', 2)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 2)\p\g
insert into Zoo (name, classification, street, city, postalCode, country, state_prov_id, zooType, id) values ('The Zoo', null, null, null, null, null, null, ''Z'', 3)\p\g
update Animal set description='Platypus', body_weight=11.0, mother_id=null, father_id=null, zoo_id=3, serialNumber='plat123' where id=2\p\g
update Zoo set name='The Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=3\p\g
update Mammal set mammalZoo_id=3, name='Platypus' where animal=2\p\g
select distinct zoo1_.id as id14_, zoo1_.name as name14_, zoo1_.classification as classifi4_14_, zoo1_.street as street14_, zoo1_.city as city14_, zoo1_.postalCode as postalCode14_, zoo1_.country as country14_, zoo1_.state_prov_id as state9_14_, zoo1_.zooType as zooType14_ from Animal animal0_ inner join Zoo zoo1_ on animal0_.zoo_id=zoo1_.id where animal0_.zoo_id is not null\p\g
select mammals0_.mammalZoo_id as mammalZoo4_1_, mammals0_.animal as animal1_, mammals0_.name as name1_, mammals0_.animal as id0_0_, mammals0_1_.description as descript2_0_0_, mammals0_1_.body_weight as body3_0_0_, mammals0_1_.mother_id as mother4_0_0_, mammals0_1_.father_id as father5_0_0_, mammals0_1_.zoo_id as zoo6_0_0_, mammals0_1_.serialNumber as serialNu7_0_0_, mammals0_.pregnant as pregnant3_0_, mammals0_.birthdate as birthdate3_0_, mammals0_2_.owner as owner4_0_, mammals0_5_.name_first as name2_7_0_, mammals0_5_.name_initial as name3_7_0_, mammals0_5_.name_last as name4_7_0_, mammals0_5_.nickName as nickName7_0_, mammals0_5_.height_centimeters / 2.54 as height6_7_0_, mammals0_5_.intValue as intValue7_0_, mammals0_5_.floatValue as floatValue7_0_, mammals0_5_.bigDecimalValue as bigDecim9_7_0_, mammals0_5_.bigIntegerValue as bigInte10_7_0_, case when mammals0_3_.mammal is not null then 5 when mammals0_4_.mammal is not null then 6 when mammals0_2_.mammal is not null then 4 when mammals0_5_.mammal is not null then 7 when mammals0_.animal is not null then 3 end as clazz_0_ from Mammal mammals0_ inner join Animal mammals0_1_ on mammals0_.animal=mammals0_1_.id left outer join DomesticAnimal mammals0_2_ on mammals0_.animal=mammals0_2_.mammal left outer join Cat mammals0_3_ on mammals0_.animal=mammals0_3_.mammal left outer join Dog mammals0_4_ on mammals0_.animal=mammals0_4_.mammal left outer join Human mammals0_5_ on mammals0_.animal=mammals0_5_.mammal where mammals0_.mammalZoo_id=3\p\g
select animals0_.zoo_id as zoo6_1_, animals0_.id as id1_, animals0_.serialNumber as serialNu7_1_, animals0_.id as id0_0_, animals0_.description as descript2_0_0_, animals0_.body_weight as body3_0_0_, animals0_.mother_id as mother4_0_0_, animals0_.father_id as father5_0_0_, animals0_.zoo_id as zoo6_0_0_, animals0_.serialNumber as serialNu7_0_0_, animals0_1_.bodyTemperature as bodyTemp2_1_0_, animals0_3_.pregnant as pregnant3_0_, animals0_3_.birthdate as birthdate3_0_, animals0_4_.owner as owner4_0_, animals0_7_.name_first as name2_7_0_, animals0_7_.name_initial as name3_7_0_, animals0_7_.name_last as name4_7_0_, animals0_7_.nickName as nickName7_0_, animals0_7_.height_centimeters / 2.54 as height6_7_0_, animals0_7_.intValue as intValue7_0_, animals0_7_.floatValue as floatValue7_0_, animals0_7_.bigDecimalValue as bigDecim9_7_0_, animals0_7_.bigIntegerValue as bigInte10_7_0_, case when animals0_2_.reptile is not null then 2 when animals0_5_.mammal is not null then 5 when animals0_6_.mammal is not null then 6 when animals0_4_.mammal is not null then 4 when animals0_7_.mammal is not null then 7 when animals0_1_.animal is not null then 1 when animals0_3_.animal is not null then 3 when animals0_.id is not null then 0 end as clazz_0_ from Animal animals0_ left outer join Reptile animals0_1_ on animals0_.id=animals0_1_.animal left outer join Lizard animals0_2_ on animals0_.id=animals0_2_.reptile left outer join Mammal animals0_3_ on animals0_.id=animals0_3_.animal left outer join DomesticAnimal animals0_4_ on animals0_.id=animals0_4_.mammal left outer join Cat animals0_5_ on animals0_.id=animals0_5_.mammal left outer join Dog animals0_6_ on animals0_.id=animals0_6_.mammal left outer join Human animals0_7_ on animals0_.id=animals0_7_.mammal where animals0_.zoo_id=3\p\g
update Zoo set name='The Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=3\p\g
update Animal set mother_id=null where mother_id=2\p\g
update Mammal set mammalZoo_id=null, name=null where mammalZoo_id=3\p\g
delete from Mammal where animal=2\p\g
delete from Animal where id=2\p\g
delete from Zoo where id=3\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Platypus', 11.0, null, null, null, 'plat123', 4)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 4)\p\g
insert into Zoo (name, classification, street, city, postalCode, country, state_prov_id, zooType, id) values ('The Zoo', null, null, null, null, null, null, ''Z'', 5)\p\g
update Animal set description='Platypus', body_weight=11.0, mother_id=null, father_id=null, zoo_id=5, serialNumber='plat123' where id=4\p\g
update Zoo set name='The Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=5\p\g
update Mammal set mammalZoo_id=5, name='Platypus' where animal=4\p\g
select distinct animal0_.zoo_id as col_0_0_ from Animal animal0_, Zoo zoo1_ where animal0_.zoo_id=zoo1_.id and (animal0_.zoo_id is not null)\p\g
select zoo0_.id as id14_0_, zoo0_.name as name14_0_, zoo0_.classification as classifi4_14_0_, zoo0_.street as street14_0_, zoo0_.city as city14_0_, zoo0_.postalCode as postalCode14_0_, zoo0_.country as country14_0_, zoo0_.state_prov_id as state9_14_0_, zoo0_.zooType as zooType14_0_ from Zoo zoo0_ where zoo0_.id=5\p\g
select mammals0_.mammalZoo_id as mammalZoo4_1_, mammals0_.animal as animal1_, mammals0_.name as name1_, mammals0_.animal as id0_0_, mammals0_1_.description as descript2_0_0_, mammals0_1_.body_weight as body3_0_0_, mammals0_1_.mother_id as mother4_0_0_, mammals0_1_.father_id as father5_0_0_, mammals0_1_.zoo_id as zoo6_0_0_, mammals0_1_.serialNumber as serialNu7_0_0_, mammals0_.pregnant as pregnant3_0_, mammals0_.birthdate as birthdate3_0_, mammals0_2_.owner as owner4_0_, mammals0_5_.name_first as name2_7_0_, mammals0_5_.name_initial as name3_7_0_, mammals0_5_.name_last as name4_7_0_, mammals0_5_.nickName as nickName7_0_, mammals0_5_.height_centimeters / 2.54 as height6_7_0_, mammals0_5_.intValue as intValue7_0_, mammals0_5_.floatValue as floatValue7_0_, mammals0_5_.bigDecimalValue as bigDecim9_7_0_, mammals0_5_.bigIntegerValue as bigInte10_7_0_, case when mammals0_3_.mammal is not null then 5 when mammals0_4_.mammal is not null then 6 when mammals0_2_.mammal is not null then 4 when mammals0_5_.mammal is not null then 7 when mammals0_.animal is not null then 3 end as clazz_0_ from Mammal mammals0_ inner join Animal mammals0_1_ on mammals0_.animal=mammals0_1_.id left outer join DomesticAnimal mammals0_2_ on mammals0_.animal=mammals0_2_.mammal left outer join Cat mammals0_3_ on mammals0_.animal=mammals0_3_.mammal left outer join Dog mammals0_4_ on mammals0_.animal=mammals0_4_.mammal left outer join Human mammals0_5_ on mammals0_.animal=mammals0_5_.mammal where mammals0_.mammalZoo_id=5\p\g
select animals0_.zoo_id as zoo6_1_, animals0_.id as id1_, animals0_.serialNumber as serialNu7_1_, animals0_.id as id0_0_, animals0_.description as descript2_0_0_, animals0_.body_weight as body3_0_0_, animals0_.mother_id as mother4_0_0_, animals0_.father_id as father5_0_0_, animals0_.zoo_id as zoo6_0_0_, animals0_.serialNumber as serialNu7_0_0_, animals0_1_.bodyTemperature as bodyTemp2_1_0_, animals0_3_.pregnant as pregnant3_0_, animals0_3_.birthdate as birthdate3_0_, animals0_4_.owner as owner4_0_, animals0_7_.name_first as name2_7_0_, animals0_7_.name_initial as name3_7_0_, animals0_7_.name_last as name4_7_0_, animals0_7_.nickName as nickName7_0_, animals0_7_.height_centimeters / 2.54 as height6_7_0_, animals0_7_.intValue as intValue7_0_, animals0_7_.floatValue as floatValue7_0_, animals0_7_.bigDecimalValue as bigDecim9_7_0_, animals0_7_.bigIntegerValue as bigInte10_7_0_, case when animals0_2_.reptile is not null then 2 when animals0_5_.mammal is not null then 5 when animals0_6_.mammal is not null then 6 when animals0_4_.mammal is not null then 4 when animals0_7_.mammal is not null then 7 when animals0_1_.animal is not null then 1 when animals0_3_.animal is not null then 3 when animals0_.id is not null then 0 end as clazz_0_ from Animal animals0_ left outer join Reptile animals0_1_ on animals0_.id=animals0_1_.animal left outer join Lizard animals0_2_ on animals0_.id=animals0_2_.reptile left outer join Mammal animals0_3_ on animals0_.id=animals0_3_.animal left outer join DomesticAnimal animals0_4_ on animals0_.id=animals0_4_.mammal left outer join Cat animals0_5_ on animals0_.id=animals0_5_.mammal left outer join Dog animals0_6_ on animals0_.id=animals0_6_.mammal left outer join Human animals0_7_ on animals0_.id=animals0_7_.mammal where animals0_.zoo_id=5\p\g
update Zoo set name='The Zoo', classification=null, street=null, city=null, postalCode=null, country=null, state_prov_id=null where id=5\p\g
update Animal set mother_id=null where mother_id=4\p\g
update Mammal set mammalZoo_id=null, name=null where mammalZoo_id=5\p\g
delete from Mammal where animal=4\p\g
delete from Animal where id=4\p\g
delete from Zoo where id=5\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 0.0, null, null, null, null, 6)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 6)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('John', 'X', 'Jacob', null, 0.0 * 2.54, 0, 0.0, null, null, 6)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 0.0, null, null, null, null, 7)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 7)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('Jingleheimer', 'X', 'Schmidt', null, 0.0 * 2.54, 0, 0.0, null, null, 7)\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id order by human0_.name_first, human0_.name_initial, human0_.name_last\p\g
delete from Human where mammal=7\p\g
delete from Mammal where animal=7\p\g
delete from Animal where id=7\p\g
delete from Human where mammal=6\p\g
delete from Mammal where animal=6\p\g
delete from Animal where id=6\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into SIMPLE_1 (NAME, negated_num, ID) values (null, 0 - 1, 8)\p\g
insert into SIMPLE_1 (NAME, negated_num, ID) values (null, 0 - 2, 9)\p\g
select id from simple_1 order by negated_num\p\g
select simpleenti0_.ID as ID24_, simpleenti0_.NAME as NAME24_, -simpleenti0_.negated_num as negated3_24_ from SIMPLE_1 simpleenti0_ order by -simpleenti0_.negated_num\p\g
delete from SIMPLE_1 where ID=8\p\g
delete from SIMPLE_1 where ID=9\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into SIMPLE_1 (NAME, negated_num, ID) values ('simple', 0 - 5, 10)\p\g
insert into SIMPLE_1 (NAME, negated_num, ID) values ('simple', 0 - 10, 11)\p\g
insert into SIMPLE_1 (NAME, negated_num, ID) values ('complex', 0 - 20, 12)\p\g
select sum(-simpleenti0_.negated_num) as col_0_0_ from SIMPLE_1 simpleenti0_ group by simpleenti0_.NAME having sum(-simpleenti0_.negated_num)<20\p\g
delete from SIMPLE_1 where ID=10\p\g
delete from SIMPLE_1 where ID=11\p\g
delete from SIMPLE_1 where ID=12\p\g
select nextval for hibernate_sequence\p\g
insert into image (name, size_mb, id) values ('picture.gif', 1536.0 / 1024.0, 13)\p\g
select size_mb from image\p\g
select image_.id, image_.name as name29_, image_.size_mb * 1024.0 as size3_29_ from image image_ where image_.id=13\p\g
update image set name='picture.gif', size_mb=2048.0 / 1024.0 where id=13\p\g
select size_mb from image\p\g
delete from image where id=13\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('an animal', 12.4, null, null, null, null, 14)\p\g
select cast(animal0_.body_weight as integer) as col_0_0_ from Animal animal0_\p\g
select cast(animal0_.body_weight as decimal(19, 2)) as col_0_0_ from Animal animal0_\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
create table Animal (id bigint not null, description varchar(255) with null, body_weight float with null, mother_id bigint with null, father_id bigint with null, zoo_id bigint with null, serialNumber varchar(255) with null, primary key (id))\p\g
create table CRAZY_ID_NODE (ID bigint not null, name varchar(255) with null, primary key (ID))\p\g
create table CRAZY_ID_TOP (ID bigint not null, name varchar(255) with null, heresAnotherCrazyIdFieldName bigint with null, primary key (ID))\p\g
create table Cat (mammal bigint not null, primary key (mammal))\p\g
create table Customer (customerId varchar(10) not null, name varchar(100) not null, address varchar(200) not null, primary key (customerId))\p\g
create table CustomerOrder (customerId varchar(10) not null, orderNumber integer not null, orderDate ansidate not null, primary key (customerId, orderNumber))\p\g
create table Dog (mammal bigint not null, primary key (mammal))\p\g
create table DomesticAnimal (mammal bigint not null, owner bigint with null, primary key (mammal))\p\g
create table HQL_COMP_CONT (ID bigint not null, STREET_ADDR varchar(255) with null, CITY_ADDR varchar(255) with null, STATE_ADDR varchar(255) with null, ZIP_CODE_ADDR integer with null, ZIP_PLUS4_ADDR integer with null, primary key (ID))\p\g
create table Human (mammal bigint not null, name_first varchar(255) with null, name_initial char(1) with null, name_last varchar(255) with null, nickName varchar(255) with null, height_centimeters float not null, intValue integer with null, floatValue float with null, bigDecimalValue decimal(19, 2) with null, bigIntegerValue decimal(19, 2) with null, primary key (mammal))\p\g
create table JOINED (ID bigint not null, joinedName varchar(255) with null, primary key (ID))\p\g
create table Joiner (id bigint not null, name varchar(255) with null, primary key (id))\p\g
create table LineItem (customerId varchar(10) not null, orderNumber integer not null, productId varchar(10) not null, quantity integer with null, primary key (customerId, orderNumber, productId))\p\g
create table Lizard (reptile bigint not null, primary key (reptile))\p\g
create table MANY_TO_MANY (IN_ID bigint not null, OUT_ID bigint not null, primary key (IN_ID, OUT_ID))\p\g
create table MARECM (MCLINK bigint not null, MCOMPR varchar(1) with null, MCOMME varchar(30) with null, primary key (MCLINK))\p\g
create table MARELO (MLMAG integer not null, MLOCA varchar(11) not null, MLINK bigint with null, MLART varchar(13) with null, MLIDO bigint with null, MLDTC timestamp(9) with time zone with null, MLTOP varchar(10) with null, MLRAG varchar(2) with null, MLROP smallint with null, MLCOM bigint with null, MATRI varchar(14) with null, SOCOD varchar(10) with null, primary key (MLMAG, MLOCA))\p\g
create table Mammal (animal bigint not null, pregnant tinyint with null, birthdate ansidate with null, mammalZoo_id bigint with null, name varchar(255) with null, primary key (animal))\p\g
create table Model (modelId varchar(32) not null, name varchar(25) not null, description varchar(200) not null, productId varchar(32) not null, primary key (modelId))\p\g
create table Product (productId varchar(10) not null, description varchar(200) not null, cost decimal(19, 2) with null, numberAvailable integer with null, primary key (productId))\p\g
create table ProductLine (productId varchar(32) not null, description varchar(200) not null, primary key (productId))\p\g
create table Reptile (animal bigint not null, bodyTemperature float with null, primary key (animal))\p\g
create table SIMPLE_1 (ID bigint not null, NAME varchar(255) with null, negated_num integer with null, primary key (ID))\p\g
create table SIMPLE_2 (ID bigint not null, NAME varchar(255) with null, SIMPLE_1_ID bigint with null, primary key (ID))\p\g
create table StateProvince (id bigint not null, name varchar(255) with null, isoCode varchar(255) with null, primary key (id))\p\g
create table T_CHAR_PROP (ID bigint not null, VAL varchar(255) not null, primary key (ID))\p\g
create table T_COMPLEX_PROP (ID bigint not null, primary key (ID))\p\g
create table T_COMPLEX_SUB_PROPS (PROP_ID bigint not null, SUB_PROP_VAL varchar(255) with null, SUB_PROP_NAME varchar(255) not null, primary key (PROP_ID, SUB_PROP_NAME))\p\g
create table T_GEN_PROPS (PROP_SET_ID bigint not null, PROP_TYPE varchar(255) with null, PROP_ID bigint with null, GEN_PROP_NAME varchar(255) not null, primary key (PROP_SET_ID, GEN_PROP_NAME))\p\g
create table T_NUM_PROP (ID bigint not null, VAL integer not null, primary key (ID))\p\g
create table T_PROP_SET (ID bigint not null, NAME varchar(255) with null, S_S_PROP_TYPE varchar(255) with null, S_S_PROP_ID bigint with null, primary key (ID))\p\g
create table VariousKeywordPropertyEntity (id bigint not null, type varchar(255) with null, value varchar(255) with null, key varchar(255) with null, entry varchar(255) with null, primary key (id))\p\g
create table Zoo (id bigint not null, zooType char(1) not null, name varchar(255) with null, classification tinyint with null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, primary key (id))\p\g
create table "User" (id bigint not null, userName varchar(255) with null, primary key (id))\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, bar_string varchar(24) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table addresses (human bigint not null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, type varchar(255) not null, primary key (human, type))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table family (human1 bigint not null, human2 bigint not null, relationship varchar(255) not null, primary key (human1, relationship))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table friends (human1 bigint not null, human2 bigint not null)\p\g
create table human_nick_names (human bigint not null, nick_name varchar(255) not null, primary key (human, nick_name))\p\g
create table image (id bigint not null, name varchar(255) with null, size_mb float with null, primary key (id))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, primary key (many_key))\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, primary key (one_key))\p\g
create table permissions (userId bigint not null, permissionName varchar(255) with null, permissionId integer not null, primary key (userId, permissionId))\p\g
alter table Animal add constraint FK752A7A1C4B485C79 foreign key (zoo_id) references Zoo\p\g
alter table Animal add constraint FK752A7A1C1F3964B4 foreign key (mother_id) references Animal\p\g
alter table Animal add constraint FK752A7A1C6309E77B foreign key (father_id) references Animal\p\g
alter table CRAZY_ID_TOP add constraint FK1AA9579F73113F33 foreign key (heresAnotherCrazyIdFieldName) references CRAZY_ID_NODE\p\g
alter table Cat add constraint FK107B66D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table CustomerOrder add constraint FKAEF781F06153C9DD foreign key (customerId) references Customer\p\g
alter table Dog add constraint FK10D1C6D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table DomesticAnimal add constraint FKE02638DA1733655F foreign key (mammal) references Mammal\p\g
alter table DomesticAnimal add constraint FKE02638DA6C03411F foreign key (owner) references Human\p\g
alter table Human add constraint FK42D710D1733655F foreign key (mammal) references Mammal\p\g
alter table JOINED add constraint FK82C23B49534E0F13 foreign key (ID) references Joiner\p\g
alter table LineItem add constraint FK4AAEE947EDAE41F3 foreign key (productId) references Product\p\g
alter table LineItem add constraint FK4AAEE947CB8F4618 foreign key (customerId, orderNumber) references CustomerOrder\p\g
alter table Lizard add constraint FK87B0E2B6EE398315 foreign key (reptile) references Reptile\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C3E0DF2A91 foreign key (OUT_ID) references SIMPLE_1\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C322C9695A foreign key (IN_ID) references SIMPLE_1\p\g
alter table MARELO add constraint FK871F728AE624DD92 foreign key (MLCOM) references MARECM\p\g
alter table Mammal add constraint FK88EF417FEFA9D699 foreign key (animal) references Animal\p\g
alter table Mammal add constraint FK88EF417FCE6EEE98 foreign key (mammalZoo_id) references Zoo\p\g
alter table Model add constraint FK4710B0921C08435 foreign key (productId) references ProductLine\p\g
alter table Reptile add constraint FKA4790CABEFA9D699 foreign key (animal) references Animal\p\g
alter table SIMPLE_2 add constraint FK4B988CE5C81DD13B foreign key (SIMPLE_1_ID) references SIMPLE_1\p\g
alter table T_COMPLEX_SUB_PROPS add constraint FK5470D25725D7CC5B foreign key (PROP_ID) references T_COMPLEX_PROP\p\g
alter table T_GEN_PROPS add constraint FK65C7C556AA2002A9 foreign key (PROP_SET_ID) references T_PROP_SET\p\g
alter table Zoo add constraint FK15FBA55106523 foreign key (state_prov_id) references StateProvince\p\g
alter table "User" add constraint FK285FEB65AF5B87 foreign key (id) references Human\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table addresses add constraint FK34207BA255106523 foreign key (state_prov_id) references StateProvince\p\g
alter table addresses add constraint FK34207BA26B9FAF99 foreign key (human) references Human\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table family add constraint FKB3985B641DCB1311 foreign key (human2) references Human\p\g
alter table family add constraint FKB3985B641DCB1310 foreign key (human1) references Human\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table friends add constraint FKDC3B49951DCB1311 foreign key (human2) references Human\p\g
alter table friends add constraint FKDC3B49951DCB1310 foreign key (human1) references Human\p\g
alter table human_nick_names add constraint FK8718E1BE6B9FAF99 foreign key (human) references Human\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table permissions add constraint FK4392F484F2810CD2 foreign key (userId) references "User"\p\g
create sequence hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('an animal', 12.4, null, null, null, null, 1)\p\g
select 1+1 as col_0_0_ from Animal animal0_\p\g
select 1+1 as col_0_0_ from Animal animal0_\p\g
select 1+1 as col_0_0_ from Animal animal0_\p\g
select 1+1 as col_0_0_ from Animal animal0_\p\g
select 1+1 as col_0_0_ from Animal animal0_\p\g
select 1+1 as col_0_0_ from Animal animal0_\p\g
select 1+1 as col_0_0_ from Animal animal0_\p\g
select 1+1 as col_0_0_ from Animal animal0_\p\g
select 1-1 as col_0_0_ from Animal animal0_\p\g
select 1-1 as col_0_0_ from Animal animal0_\p\g
select 1-1 as col_0_0_ from Animal animal0_\p\g
select 1-1 as col_0_0_ from Animal animal0_\p\g
select 1-1 as col_0_0_ from Animal animal0_\p\g
select 1-1 as col_0_0_ from Animal animal0_\p\g
select 1-1 as col_0_0_ from Animal animal0_\p\g
select 1-1 as col_0_0_ from Animal animal0_\p\g
select 1*1 as col_0_0_ from Animal animal0_\p\g
select 1*1 as col_0_0_ from Animal animal0_\p\g
select 1*1 as col_0_0_ from Animal animal0_\p\g
select 1*1 as col_0_0_ from Animal animal0_\p\g
select 1*1 as col_0_0_ from Animal animal0_\p\g
select 1*1 as col_0_0_ from Animal animal0_\p\g
delete from Animal where id=1\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('an animal', 12.4, null, null, null, null, 2)\p\g
delete from Animal where id=2\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.description='something' and animal0_.body_weight=12345.0 or animal0_.body_weight=123.0\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.description='something' and animal0_.body_weight=123.0\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight in (999.0 , 123.0)\p\g
select zoo0_.id as id14_, zoo0_.name as name14_, zoo0_.classification as classifi4_14_, zoo0_.street as street14_, zoo0_.city as city14_, zoo0_.postalCode as postalCode14_, zoo0_.country as country14_, zoo0_.state_prov_id as state9_14_, zoo0_.zooType as zooType14_ from Zoo zoo0_ cross join Mammal mammals1_ inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id where zoo0_.id=mammals1_.mammalZoo_id and mammals1_.name = 'Walrus' and mammals1_.animal=123\p\g
select zoo0_.id as id14_, zoo0_.name as name14_, zoo0_.classification as classifi4_14_, zoo0_.street as street14_, zoo0_.city as city14_, zoo0_.postalCode as postalCode14_, zoo0_.country as country14_, zoo0_.state_prov_id as state9_14_, zoo0_.zooType as zooType14_ from Zoo zoo0_ cross join Mammal mammals1_ inner join Animal mammals1_1_ on mammals1_.animal=mammals1_1_.id where zoo0_.id=mammals1_.mammalZoo_id and mammals1_.name = 'Walrus' and mammals1_1_.body_weight>123.32\p\g
select zoo0_.id as id14_, zoo0_.name as name14_, zoo0_.classification as classifi4_14_, zoo0_.street as street14_, zoo0_.city as city14_, zoo0_.postalCode as postalCode14_, zoo0_.country as country14_, zoo0_.state_prov_id as state9_14_, zoo0_.zooType as zooType14_ from Zoo zoo0_ cross join Animal animals1_ cross join Animal animal2_ where zoo0_.id=animals1_.zoo_id and animals1_.serialNumber = 'ant-123' and animals1_.mother_id=animal2_.id and animal2_.body_weight<23.32\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Me', 74.0, null, null, null, null, 3)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 3)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('Gavin', 'A', 'King', 'Oney', 120.5 * 2.54, 0, 0.0, null, null, 3)\p\g
select sum(human0_2_.body_weight) as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
select avg(human0_.height_centimeters / 2.54) as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
select max(animal0_.id) as col_0_0_ from Animal animal0_\p\g
delete from Human where mammal=3\p\g
delete from Mammal where animal=3\p\g
delete from Animal where id=3\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Me', 74.0, null, null, null, null, 4)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 4)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('Gavin', 'A', 'King', 'Oney', 120.5 * 2.54, 0, 0.0, null, null, 4)\p\g
select case human0_.nickName when ''Oney'' then ''gavin'' when ''Turin'' then ''christian'' else human0_.nickName end as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
select case when human0_2_.body_weight>100 then ''fat'' else ''skinny'' end as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
delete from Human where mammal=4\p\g
delete from Mammal where animal=4\p\g
delete from Animal where id=4\p\g
insert into Product (description, cost, numberAvailable, productId) values ('My Product', 123, 10, '4321')\p\g
select customer0_.customerId as customerId34_, customer0_.name as name34_, customer0_.address as address34_ from Customer customer0_\p\g
select many0_.many_key as many1_23_, many0_.x as x23_ from many many0_\p\g
select morecrazyi0_.ID as ID28_, morecrazyi0_.name as name28_, morecrazyi0_.heresAnotherCrazyIdFieldName as heresAno3_28_ from CRAZY_ID_TOP morecrazyi0_\p\g
select integerpro0_.ID as ID41_, integerpro0_.VAL as VAL41_ from T_NUM_PROP integerpro0_\p\g
select joiner0_.id as id16_, joiner0_.name as name16_, joiner0_1_.joinedName as joinedName17_ from Joiner joiner0_ inner join JOINED joiner0_1_ on joiner0_.id=joiner0_1_.ID\p\g
select simpleenti0_.ID as ID24_, simpleenti0_.NAME as NAME24_, -simpleenti0_.negated_num as negated3_24_ from SIMPLE_1 simpleenti0_\p\g
select propertyse0_.ID as ID38_, propertyse0_.NAME as NAME38_, propertyse0_.S_S_PROP_TYPE as S3_38_, propertyse0_.S_S_PROP_ID as S4_38_ from T_PROP_SET propertyse0_\p\g
select productlin0_.productId as productId32_, productlin0_.description as descript2_32_ from ProductLine productlin0_\p\g
select user0_.id as id12_, userName as userName12_ from "User" user0_\p\g
select stateprovi0_.id as id15_, stateprovi0_.name as name15_, stateprovi0_.isoCode as isoCode15_ from StateProvince stateprovi0_\p\g
select product0_.productId as productId37_, product0_.description as descript2_37_, product0_.cost as cost37_, product0_.numberAvailable as numberAv4_37_, ( select sum(li.quantity) from LineItem li where li.productId = product0_.productId ) as formula2_ from Product product0_\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
create table Animal (id bigint not null, description varchar(255) with null, body_weight float with null, mother_id bigint with null, father_id bigint with null, zoo_id bigint with null, serialNumber varchar(255) with null, primary key (id))\p\g
create table CRAZY_ID_NODE (ID bigint not null, name varchar(255) with null, primary key (ID))\p\g
create table CRAZY_ID_TOP (ID bigint not null, name varchar(255) with null, heresAnotherCrazyIdFieldName bigint with null, primary key (ID))\p\g
create table Cat (mammal bigint not null, primary key (mammal))\p\g
create table Customer (customerId varchar(10) not null, name varchar(100) not null, address varchar(200) not null, primary key (customerId))\p\g
create table CustomerOrder (customerId varchar(10) not null, orderNumber integer not null, orderDate ansidate not null, primary key (customerId, orderNumber))\p\g
create table Dog (mammal bigint not null, primary key (mammal))\p\g
create table DomesticAnimal (mammal bigint not null, owner bigint with null, primary key (mammal))\p\g
create table HQL_COMP_CONT (ID bigint not null, STREET_ADDR varchar(255) with null, CITY_ADDR varchar(255) with null, STATE_ADDR varchar(255) with null, ZIP_CODE_ADDR integer with null, ZIP_PLUS4_ADDR integer with null, primary key (ID))\p\g
create table Human (mammal bigint not null, name_first varchar(255) with null, name_initial char(1) with null, name_last varchar(255) with null, nickName varchar(255) with null, height_centimeters float not null, intValue integer with null, floatValue float with null, bigDecimalValue decimal(19, 2) with null, bigIntegerValue decimal(19, 2) with null, primary key (mammal))\p\g
create table JOINED (ID bigint not null, joinedName varchar(255) with null, primary key (ID))\p\g
create table Joiner (id bigint not null, name varchar(255) with null, primary key (id))\p\g
create table LineItem (customerId varchar(10) not null, orderNumber integer not null, productId varchar(10) not null, quantity integer with null, primary key (customerId, orderNumber, productId))\p\g
create table Lizard (reptile bigint not null, primary key (reptile))\p\g
create table MANY_TO_MANY (IN_ID bigint not null, OUT_ID bigint not null, primary key (IN_ID, OUT_ID))\p\g
create table MARECM (MCLINK bigint not null, MCOMPR varchar(1) with null, MCOMME varchar(30) with null, primary key (MCLINK))\p\g
create table MARELO (MLMAG integer not null, MLOCA varchar(11) not null, MLINK bigint with null, MLART varchar(13) with null, MLIDO bigint with null, MLDTC timestamp(9) with time zone with null, MLTOP varchar(10) with null, MLRAG varchar(2) with null, MLROP smallint with null, MLCOM bigint with null, MATRI varchar(14) with null, SOCOD varchar(10) with null, primary key (MLMAG, MLOCA))\p\g
create table Mammal (animal bigint not null, pregnant tinyint with null, birthdate ansidate with null, mammalZoo_id bigint with null, name varchar(255) with null, primary key (animal))\p\g
create table Model (modelId varchar(32) not null, name varchar(25) not null, description varchar(200) not null, productId varchar(32) not null, primary key (modelId))\p\g
create table Product (productId varchar(10) not null, description varchar(200) not null, cost decimal(19, 2) with null, numberAvailable integer with null, primary key (productId))\p\g
create table ProductLine (productId varchar(32) not null, description varchar(200) not null, primary key (productId))\p\g
create table Reptile (animal bigint not null, bodyTemperature float with null, primary key (animal))\p\g
create table SIMPLE_1 (ID bigint not null, NAME varchar(255) with null, negated_num integer with null, primary key (ID))\p\g
create table SIMPLE_2 (ID bigint not null, NAME varchar(255) with null, SIMPLE_1_ID bigint with null, primary key (ID))\p\g
create table StateProvince (id bigint not null, name varchar(255) with null, isoCode varchar(255) with null, primary key (id))\p\g
create table T_CHAR_PROP (ID bigint not null, VAL varchar(255) not null, primary key (ID))\p\g
create table T_COMPLEX_PROP (ID bigint not null, primary key (ID))\p\g
create table T_COMPLEX_SUB_PROPS (PROP_ID bigint not null, SUB_PROP_VAL varchar(255) with null, SUB_PROP_NAME varchar(255) not null, primary key (PROP_ID, SUB_PROP_NAME))\p\g
create table T_GEN_PROPS (PROP_SET_ID bigint not null, PROP_TYPE varchar(255) with null, PROP_ID bigint with null, GEN_PROP_NAME varchar(255) not null, primary key (PROP_SET_ID, GEN_PROP_NAME))\p\g
create table T_NUM_PROP (ID bigint not null, VAL integer not null, primary key (ID))\p\g
create table T_PROP_SET (ID bigint not null, NAME varchar(255) with null, S_S_PROP_TYPE varchar(255) with null, S_S_PROP_ID bigint with null, primary key (ID))\p\g
create table VariousKeywordPropertyEntity (id bigint not null, type varchar(255) with null, value varchar(255) with null, key varchar(255) with null, entry varchar(255) with null, primary key (id))\p\g
create table Zoo (id bigint not null, zooType char(1) not null, name varchar(255) with null, classification tinyint with null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, primary key (id))\p\g
create table "User" (id bigint not null, userName varchar(255) with null, primary key (id))\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, bar_string varchar(24) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table addresses (human bigint not null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, type varchar(255) not null, primary key (human, type))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table family (human1 bigint not null, human2 bigint not null, relationship varchar(255) not null, primary key (human1, relationship))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table friends (human1 bigint not null, human2 bigint not null)\p\g
create table human_nick_names (human bigint not null, nick_name varchar(255) not null, primary key (human, nick_name))\p\g
create table image (id bigint not null, name varchar(255) with null, size_mb float with null, primary key (id))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, primary key (many_key))\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, primary key (one_key))\p\g
create table permissions (userId bigint not null, permissionName varchar(255) with null, permissionId integer not null, primary key (userId, permissionId))\p\g
alter table Animal add constraint FK752A7A1C4B485C79 foreign key (zoo_id) references Zoo\p\g
alter table Animal add constraint FK752A7A1C1F3964B4 foreign key (mother_id) references Animal\p\g
alter table Animal add constraint FK752A7A1C6309E77B foreign key (father_id) references Animal\p\g
alter table CRAZY_ID_TOP add constraint FK1AA9579F73113F33 foreign key (heresAnotherCrazyIdFieldName) references CRAZY_ID_NODE\p\g
alter table Cat add constraint FK107B66D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table CustomerOrder add constraint FKAEF781F06153C9DD foreign key (customerId) references Customer\p\g
alter table Dog add constraint FK10D1C6D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table DomesticAnimal add constraint FKE02638DA1733655F foreign key (mammal) references Mammal\p\g
alter table DomesticAnimal add constraint FKE02638DA6C03411F foreign key (owner) references Human\p\g
alter table Human add constraint FK42D710D1733655F foreign key (mammal) references Mammal\p\g
alter table JOINED add constraint FK82C23B49534E0F13 foreign key (ID) references Joiner\p\g
alter table LineItem add constraint FK4AAEE947EDAE41F3 foreign key (productId) references Product\p\g
alter table LineItem add constraint FK4AAEE947CB8F4618 foreign key (customerId, orderNumber) references CustomerOrder\p\g
alter table Lizard add constraint FK87B0E2B6EE398315 foreign key (reptile) references Reptile\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C3E0DF2A91 foreign key (OUT_ID) references SIMPLE_1\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C322C9695A foreign key (IN_ID) references SIMPLE_1\p\g
alter table MARELO add constraint FK871F728AE624DD92 foreign key (MLCOM) references MARECM\p\g
alter table Mammal add constraint FK88EF417FEFA9D699 foreign key (animal) references Animal\p\g
alter table Mammal add constraint FK88EF417FCE6EEE98 foreign key (mammalZoo_id) references Zoo\p\g
alter table Model add constraint FK4710B0921C08435 foreign key (productId) references ProductLine\p\g
alter table Reptile add constraint FKA4790CABEFA9D699 foreign key (animal) references Animal\p\g
alter table SIMPLE_2 add constraint FK4B988CE5C81DD13B foreign key (SIMPLE_1_ID) references SIMPLE_1\p\g
alter table T_COMPLEX_SUB_PROPS add constraint FK5470D25725D7CC5B foreign key (PROP_ID) references T_COMPLEX_PROP\p\g
alter table T_GEN_PROPS add constraint FK65C7C556AA2002A9 foreign key (PROP_SET_ID) references T_PROP_SET\p\g
alter table Zoo add constraint FK15FBA55106523 foreign key (state_prov_id) references StateProvince\p\g
alter table "User" add constraint FK285FEB65AF5B87 foreign key (id) references Human\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table addresses add constraint FK34207BA255106523 foreign key (state_prov_id) references StateProvince\p\g
alter table addresses add constraint FK34207BA26B9FAF99 foreign key (human) references Human\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table family add constraint FKB3985B641DCB1311 foreign key (human2) references Human\p\g
alter table family add constraint FKB3985B641DCB1310 foreign key (human1) references Human\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table friends add constraint FKDC3B49951DCB1311 foreign key (human2) references Human\p\g
alter table friends add constraint FKDC3B49951DCB1310 foreign key (human1) references Human\p\g
alter table human_nick_names add constraint FK8718E1BE6B9FAF99 foreign key (human) references Human\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table permissions add constraint FK4392F484F2810CD2 foreign key (userId) references "User"\p\g
create sequence hibernate_sequence\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where coalesce(human0_.nickName, human0_.name_first, human0_.name_last)=''max''\p\g
select nullif(human0_.nickName, ''1e1'') as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 123.45, null, null, null, null, 1)\p\g
select cast(animal0_.body_weight as char) as col_0_0_ from Animal animal0_ where cast(animal0_.body_weight as char) like ''%1%''\p\g
select cast(current_date as char) as col_0_0_ from Animal animal0_\p\g
select (cast(year(current_date) as char)+''-''+cast(month(current_date) as char)+''-''+cast(day(current_date) as char)) as col_0_0_ from Animal animal0_\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
create table Animal (id bigint not null, description varchar(255) with null, body_weight float with null, mother_id bigint with null, father_id bigint with null, zoo_id bigint with null, serialNumber varchar(255) with null, primary key (id))\p\g
create table CRAZY_ID_NODE (ID bigint not null, name varchar(255) with null, primary key (ID))\p\g
create table CRAZY_ID_TOP (ID bigint not null, name varchar(255) with null, heresAnotherCrazyIdFieldName bigint with null, primary key (ID))\p\g
create table Cat (mammal bigint not null, primary key (mammal))\p\g
create table Customer (customerId varchar(10) not null, name varchar(100) not null, address varchar(200) not null, primary key (customerId))\p\g
create table CustomerOrder (customerId varchar(10) not null, orderNumber integer not null, orderDate ansidate not null, primary key (customerId, orderNumber))\p\g
create table Dog (mammal bigint not null, primary key (mammal))\p\g
create table DomesticAnimal (mammal bigint not null, owner bigint with null, primary key (mammal))\p\g
create table HQL_COMP_CONT (ID bigint not null, STREET_ADDR varchar(255) with null, CITY_ADDR varchar(255) with null, STATE_ADDR varchar(255) with null, ZIP_CODE_ADDR integer with null, ZIP_PLUS4_ADDR integer with null, primary key (ID))\p\g
create table Human (mammal bigint not null, name_first varchar(255) with null, name_initial char(1) with null, name_last varchar(255) with null, nickName varchar(255) with null, height_centimeters float not null, intValue integer with null, floatValue float with null, bigDecimalValue decimal(19, 2) with null, bigIntegerValue decimal(19, 2) with null, primary key (mammal))\p\g
create table JOINED (ID bigint not null, joinedName varchar(255) with null, primary key (ID))\p\g
create table Joiner (id bigint not null, name varchar(255) with null, primary key (id))\p\g
create table LineItem (customerId varchar(10) not null, orderNumber integer not null, productId varchar(10) not null, quantity integer with null, primary key (customerId, orderNumber, productId))\p\g
create table Lizard (reptile bigint not null, primary key (reptile))\p\g
create table MANY_TO_MANY (IN_ID bigint not null, OUT_ID bigint not null, primary key (IN_ID, OUT_ID))\p\g
create table MARECM (MCLINK bigint not null, MCOMPR varchar(1) with null, MCOMME varchar(30) with null, primary key (MCLINK))\p\g
create table MARELO (MLMAG integer not null, MLOCA varchar(11) not null, MLINK bigint with null, MLART varchar(13) with null, MLIDO bigint with null, MLDTC timestamp(9) with time zone with null, MLTOP varchar(10) with null, MLRAG varchar(2) with null, MLROP smallint with null, MLCOM bigint with null, MATRI varchar(14) with null, SOCOD varchar(10) with null, primary key (MLMAG, MLOCA))\p\g
create table Mammal (animal bigint not null, pregnant tinyint with null, birthdate ansidate with null, mammalZoo_id bigint with null, name varchar(255) with null, primary key (animal))\p\g
create table Model (modelId varchar(32) not null, name varchar(25) not null, description varchar(200) not null, productId varchar(32) not null, primary key (modelId))\p\g
create table Product (productId varchar(10) not null, description varchar(200) not null, cost decimal(19, 2) with null, numberAvailable integer with null, primary key (productId))\p\g
create table ProductLine (productId varchar(32) not null, description varchar(200) not null, primary key (productId))\p\g
create table Reptile (animal bigint not null, bodyTemperature float with null, primary key (animal))\p\g
create table SIMPLE_1 (ID bigint not null, NAME varchar(255) with null, negated_num integer with null, primary key (ID))\p\g
create table SIMPLE_2 (ID bigint not null, NAME varchar(255) with null, SIMPLE_1_ID bigint with null, primary key (ID))\p\g
create table StateProvince (id bigint not null, name varchar(255) with null, isoCode varchar(255) with null, primary key (id))\p\g
create table T_CHAR_PROP (ID bigint not null, VAL varchar(255) not null, primary key (ID))\p\g
create table T_COMPLEX_PROP (ID bigint not null, primary key (ID))\p\g
create table T_COMPLEX_SUB_PROPS (PROP_ID bigint not null, SUB_PROP_VAL varchar(255) with null, SUB_PROP_NAME varchar(255) not null, primary key (PROP_ID, SUB_PROP_NAME))\p\g
create table T_GEN_PROPS (PROP_SET_ID bigint not null, PROP_TYPE varchar(255) with null, PROP_ID bigint with null, GEN_PROP_NAME varchar(255) not null, primary key (PROP_SET_ID, GEN_PROP_NAME))\p\g
create table T_NUM_PROP (ID bigint not null, VAL integer not null, primary key (ID))\p\g
create table T_PROP_SET (ID bigint not null, NAME varchar(255) with null, S_S_PROP_TYPE varchar(255) with null, S_S_PROP_ID bigint with null, primary key (ID))\p\g
create table VariousKeywordPropertyEntity (id bigint not null, type varchar(255) with null, value varchar(255) with null, key varchar(255) with null, entry varchar(255) with null, primary key (id))\p\g
create table Zoo (id bigint not null, zooType char(1) not null, name varchar(255) with null, classification tinyint with null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, primary key (id))\p\g
create table "User" (id bigint not null, userName varchar(255) with null, primary key (id))\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, bar_string varchar(24) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table addresses (human bigint not null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, type varchar(255) not null, primary key (human, type))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table family (human1 bigint not null, human2 bigint not null, relationship varchar(255) not null, primary key (human1, relationship))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table friends (human1 bigint not null, human2 bigint not null)\p\g
create table human_nick_names (human bigint not null, nick_name varchar(255) not null, primary key (human, nick_name))\p\g
create table image (id bigint not null, name varchar(255) with null, size_mb float with null, primary key (id))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, primary key (many_key))\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, primary key (one_key))\p\g
create table permissions (userId bigint not null, permissionName varchar(255) with null, permissionId integer not null, primary key (userId, permissionId))\p\g
alter table Animal add constraint FK752A7A1C4B485C79 foreign key (zoo_id) references Zoo\p\g
alter table Animal add constraint FK752A7A1C1F3964B4 foreign key (mother_id) references Animal\p\g
alter table Animal add constraint FK752A7A1C6309E77B foreign key (father_id) references Animal\p\g
alter table CRAZY_ID_TOP add constraint FK1AA9579F73113F33 foreign key (heresAnotherCrazyIdFieldName) references CRAZY_ID_NODE\p\g
alter table Cat add constraint FK107B66D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table CustomerOrder add constraint FKAEF781F06153C9DD foreign key (customerId) references Customer\p\g
alter table Dog add constraint FK10D1C6D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table DomesticAnimal add constraint FKE02638DA1733655F foreign key (mammal) references Mammal\p\g
alter table DomesticAnimal add constraint FKE02638DA6C03411F foreign key (owner) references Human\p\g
alter table Human add constraint FK42D710D1733655F foreign key (mammal) references Mammal\p\g
alter table JOINED add constraint FK82C23B49534E0F13 foreign key (ID) references Joiner\p\g
alter table LineItem add constraint FK4AAEE947EDAE41F3 foreign key (productId) references Product\p\g
alter table LineItem add constraint FK4AAEE947CB8F4618 foreign key (customerId, orderNumber) references CustomerOrder\p\g
alter table Lizard add constraint FK87B0E2B6EE398315 foreign key (reptile) references Reptile\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C3E0DF2A91 foreign key (OUT_ID) references SIMPLE_1\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C322C9695A foreign key (IN_ID) references SIMPLE_1\p\g
alter table MARELO add constraint FK871F728AE624DD92 foreign key (MLCOM) references MARECM\p\g
alter table Mammal add constraint FK88EF417FEFA9D699 foreign key (animal) references Animal\p\g
alter table Mammal add constraint FK88EF417FCE6EEE98 foreign key (mammalZoo_id) references Zoo\p\g
alter table Model add constraint FK4710B0921C08435 foreign key (productId) references ProductLine\p\g
alter table Reptile add constraint FKA4790CABEFA9D699 foreign key (animal) references Animal\p\g
alter table SIMPLE_2 add constraint FK4B988CE5C81DD13B foreign key (SIMPLE_1_ID) references SIMPLE_1\p\g
alter table T_COMPLEX_SUB_PROPS add constraint FK5470D25725D7CC5B foreign key (PROP_ID) references T_COMPLEX_PROP\p\g
alter table T_GEN_PROPS add constraint FK65C7C556AA2002A9 foreign key (PROP_SET_ID) references T_PROP_SET\p\g
alter table Zoo add constraint FK15FBA55106523 foreign key (state_prov_id) references StateProvince\p\g
alter table "User" add constraint FK285FEB65AF5B87 foreign key (id) references Human\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table addresses add constraint FK34207BA255106523 foreign key (state_prov_id) references StateProvince\p\g
alter table addresses add constraint FK34207BA26B9FAF99 foreign key (human) references Human\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table family add constraint FKB3985B641DCB1311 foreign key (human2) references Human\p\g
alter table family add constraint FKB3985B641DCB1310 foreign key (human1) references Human\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table friends add constraint FKDC3B49951DCB1311 foreign key (human2) references Human\p\g
alter table friends add constraint FKDC3B49951DCB1310 foreign key (human1) references Human\p\g
alter table human_nick_names add constraint FK8718E1BE6B9FAF99 foreign key (human) references Human\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table permissions add constraint FK4392F484F2810CD2 foreign key (userId) references "User"\p\g
create sequence hibernate_sequence\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where human0_.nickName like ''G%''\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where cast(animal0_.body_weight as varchar(255)) like ''1.%''\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where cast(animal0_.body_weight as integer)=1\p\g
select second(current_timestamp) as col_0_0_, minute(current_timestamp) as col_1_0_, hour(current_timestamp) as col_2_0_ from Mammal mammal0_ inner join Animal mammal0_1_ on mammal0_.animal=mammal0_1_.id\p\g
select day(mammal0_.birthdate) as col_0_0_, month(mammal0_.birthdate) as col_1_0_, year(mammal0_.birthdate) as col_2_0_ from Mammal mammal0_ inner join Animal mammal0_1_ on mammal0_.animal=mammal0_1_.id\p\g
select date_part(''second'', current_timestamp) as col_0_0_, date_part(''minute'', current_timestamp) as col_1_0_, date_part(''hour'', current_timestamp) as col_2_0_ from Mammal mammal0_ inner join Animal mammal0_1_ on mammal0_.animal=mammal0_1_.id\p\g
select date_part(''day'', mammal0_.birthdate) as col_0_0_, date_part(''month'', mammal0_.birthdate) as col_1_0_, date_part(''year'', mammal0_.birthdate) as col_2_0_ from Mammal mammal0_ inner join Animal mammal0_1_ on mammal0_.animal=mammal0_1_.id\p\g
insert into Product (description, cost, numberAvailable, productId) values ('My Product', 123, 10, '4321')\p\g
insert into Customer (name, address, customerId) values ('My customer', 'somewhere', '123456789')\p\g
insert into CustomerOrder (orderDate, customerId, orderNumber) values ('2010-03-01, java.util.GregorianCalendar[time=1267449546564,areFieldsSet=true,areAllFieldsSet=true,lenient=true,zone=sun.util.calendar.ZoneInfo[id="GMT-05:00",offset=-18000000,dstSavings=0,useDaylight=false,transitions=0,lastRule=null],firstDayOfWeek=1,minimalDaysInFirstWeek=1,ERA=1,YEAR=2010,MONTH=2,WEEK_OF_YEAR=10,WEEK_OF_MONTH=1,DAY_OF_MONTH=1,DAY_OF_YEAR=60,DAY_OF_WEEK=2,DAY_OF_WEEK_IN_MONTH=1,AM_PM=0,HOUR=8,HOUR_OF_DAY=8,MINUTE=19,SECOND=6,MILLISECOND=564,ZONE_OFFSET=-18000000,DST_OFFSET=0]', '123456789', 0)\p\g
insert into LineItem (quantity, customerId, orderNumber, productId) values (5, '123456789', 0, '4321')\p\g
Parameter count mismatch 4154, 0,1
select order0_.customerId as customerId35_, order0_.orderNumber as orderNum2_35_, order0_.orderDate as orderDate35_, ( select sum(li.quantity*p.cost) from LineItem li, Product p where li.productId = p.productId and li.customerId = order0_.customerId and li.orderNumber = order0_.orderNumber ) as formula1_ from CustomerOrder order0_ where order0_.customerId = ?
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
create table Animal (id bigint not null, description varchar(255) with null, body_weight float with null, mother_id bigint with null, father_id bigint with null, zoo_id bigint with null, serialNumber varchar(255) with null, primary key (id))\p\g
create table CRAZY_ID_NODE (ID bigint not null, name varchar(255) with null, primary key (ID))\p\g
create table CRAZY_ID_TOP (ID bigint not null, name varchar(255) with null, heresAnotherCrazyIdFieldName bigint with null, primary key (ID))\p\g
create table Cat (mammal bigint not null, primary key (mammal))\p\g
create table Customer (customerId varchar(10) not null, name varchar(100) not null, address varchar(200) not null, primary key (customerId))\p\g
create table CustomerOrder (customerId varchar(10) not null, orderNumber integer not null, orderDate ansidate not null, primary key (customerId, orderNumber))\p\g
create table Dog (mammal bigint not null, primary key (mammal))\p\g
create table DomesticAnimal (mammal bigint not null, owner bigint with null, primary key (mammal))\p\g
create table HQL_COMP_CONT (ID bigint not null, STREET_ADDR varchar(255) with null, CITY_ADDR varchar(255) with null, STATE_ADDR varchar(255) with null, ZIP_CODE_ADDR integer with null, ZIP_PLUS4_ADDR integer with null, primary key (ID))\p\g
create table Human (mammal bigint not null, name_first varchar(255) with null, name_initial char(1) with null, name_last varchar(255) with null, nickName varchar(255) with null, height_centimeters float not null, intValue integer with null, floatValue float with null, bigDecimalValue decimal(19, 2) with null, bigIntegerValue decimal(19, 2) with null, primary key (mammal))\p\g
create table JOINED (ID bigint not null, joinedName varchar(255) with null, primary key (ID))\p\g
create table Joiner (id bigint not null, name varchar(255) with null, primary key (id))\p\g
create table LineItem (customerId varchar(10) not null, orderNumber integer not null, productId varchar(10) not null, quantity integer with null, primary key (customerId, orderNumber, productId))\p\g
create table Lizard (reptile bigint not null, primary key (reptile))\p\g
create table MANY_TO_MANY (IN_ID bigint not null, OUT_ID bigint not null, primary key (IN_ID, OUT_ID))\p\g
create table MARECM (MCLINK bigint not null, MCOMPR varchar(1) with null, MCOMME varchar(30) with null, primary key (MCLINK))\p\g
create table MARELO (MLMAG integer not null, MLOCA varchar(11) not null, MLINK bigint with null, MLART varchar(13) with null, MLIDO bigint with null, MLDTC timestamp(9) with time zone with null, MLTOP varchar(10) with null, MLRAG varchar(2) with null, MLROP smallint with null, MLCOM bigint with null, MATRI varchar(14) with null, SOCOD varchar(10) with null, primary key (MLMAG, MLOCA))\p\g
create table Mammal (animal bigint not null, pregnant tinyint with null, birthdate ansidate with null, mammalZoo_id bigint with null, name varchar(255) with null, primary key (animal))\p\g
create table Model (modelId varchar(32) not null, name varchar(25) not null, description varchar(200) not null, productId varchar(32) not null, primary key (modelId))\p\g
create table Product (productId varchar(10) not null, description varchar(200) not null, cost decimal(19, 2) with null, numberAvailable integer with null, primary key (productId))\p\g
create table ProductLine (productId varchar(32) not null, description varchar(200) not null, primary key (productId))\p\g
create table Reptile (animal bigint not null, bodyTemperature float with null, primary key (animal))\p\g
create table SIMPLE_1 (ID bigint not null, NAME varchar(255) with null, negated_num integer with null, primary key (ID))\p\g
create table SIMPLE_2 (ID bigint not null, NAME varchar(255) with null, SIMPLE_1_ID bigint with null, primary key (ID))\p\g
create table StateProvince (id bigint not null, name varchar(255) with null, isoCode varchar(255) with null, primary key (id))\p\g
create table T_CHAR_PROP (ID bigint not null, VAL varchar(255) not null, primary key (ID))\p\g
create table T_COMPLEX_PROP (ID bigint not null, primary key (ID))\p\g
create table T_COMPLEX_SUB_PROPS (PROP_ID bigint not null, SUB_PROP_VAL varchar(255) with null, SUB_PROP_NAME varchar(255) not null, primary key (PROP_ID, SUB_PROP_NAME))\p\g
create table T_GEN_PROPS (PROP_SET_ID bigint not null, PROP_TYPE varchar(255) with null, PROP_ID bigint with null, GEN_PROP_NAME varchar(255) not null, primary key (PROP_SET_ID, GEN_PROP_NAME))\p\g
create table T_NUM_PROP (ID bigint not null, VAL integer not null, primary key (ID))\p\g
create table T_PROP_SET (ID bigint not null, NAME varchar(255) with null, S_S_PROP_TYPE varchar(255) with null, S_S_PROP_ID bigint with null, primary key (ID))\p\g
create table VariousKeywordPropertyEntity (id bigint not null, type varchar(255) with null, value varchar(255) with null, key varchar(255) with null, entry varchar(255) with null, primary key (id))\p\g
create table Zoo (id bigint not null, zooType char(1) not null, name varchar(255) with null, classification tinyint with null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, primary key (id))\p\g
create table "User" (id bigint not null, userName varchar(255) with null, primary key (id))\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, bar_string varchar(24) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table addresses (human bigint not null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, type varchar(255) not null, primary key (human, type))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table family (human1 bigint not null, human2 bigint not null, relationship varchar(255) not null, primary key (human1, relationship))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table friends (human1 bigint not null, human2 bigint not null)\p\g
create table human_nick_names (human bigint not null, nick_name varchar(255) not null, primary key (human, nick_name))\p\g
create table image (id bigint not null, name varchar(255) with null, size_mb float with null, primary key (id))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, primary key (many_key))\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, primary key (one_key))\p\g
create table permissions (userId bigint not null, permissionName varchar(255) with null, permissionId integer not null, primary key (userId, permissionId))\p\g
alter table Animal add constraint FK752A7A1C4B485C79 foreign key (zoo_id) references Zoo\p\g
alter table Animal add constraint FK752A7A1C1F3964B4 foreign key (mother_id) references Animal\p\g
alter table Animal add constraint FK752A7A1C6309E77B foreign key (father_id) references Animal\p\g
alter table CRAZY_ID_TOP add constraint FK1AA9579F73113F33 foreign key (heresAnotherCrazyIdFieldName) references CRAZY_ID_NODE\p\g
alter table Cat add constraint FK107B66D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table CustomerOrder add constraint FKAEF781F06153C9DD foreign key (customerId) references Customer\p\g
alter table Dog add constraint FK10D1C6D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table DomesticAnimal add constraint FKE02638DA1733655F foreign key (mammal) references Mammal\p\g
alter table DomesticAnimal add constraint FKE02638DA6C03411F foreign key (owner) references Human\p\g
alter table Human add constraint FK42D710D1733655F foreign key (mammal) references Mammal\p\g
alter table JOINED add constraint FK82C23B49534E0F13 foreign key (ID) references Joiner\p\g
alter table LineItem add constraint FK4AAEE947EDAE41F3 foreign key (productId) references Product\p\g
alter table LineItem add constraint FK4AAEE947CB8F4618 foreign key (customerId, orderNumber) references CustomerOrder\p\g
alter table Lizard add constraint FK87B0E2B6EE398315 foreign key (reptile) references Reptile\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C3E0DF2A91 foreign key (OUT_ID) references SIMPLE_1\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C322C9695A foreign key (IN_ID) references SIMPLE_1\p\g
alter table MARELO add constraint FK871F728AE624DD92 foreign key (MLCOM) references MARECM\p\g
alter table Mammal add constraint FK88EF417FEFA9D699 foreign key (animal) references Animal\p\g
alter table Mammal add constraint FK88EF417FCE6EEE98 foreign key (mammalZoo_id) references Zoo\p\g
alter table Model add constraint FK4710B0921C08435 foreign key (productId) references ProductLine\p\g
alter table Reptile add constraint FKA4790CABEFA9D699 foreign key (animal) references Animal\p\g
alter table SIMPLE_2 add constraint FK4B988CE5C81DD13B foreign key (SIMPLE_1_ID) references SIMPLE_1\p\g
alter table T_COMPLEX_SUB_PROPS add constraint FK5470D25725D7CC5B foreign key (PROP_ID) references T_COMPLEX_PROP\p\g
alter table T_GEN_PROPS add constraint FK65C7C556AA2002A9 foreign key (PROP_SET_ID) references T_PROP_SET\p\g
alter table Zoo add constraint FK15FBA55106523 foreign key (state_prov_id) references StateProvince\p\g
alter table "User" add constraint FK285FEB65AF5B87 foreign key (id) references Human\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table addresses add constraint FK34207BA255106523 foreign key (state_prov_id) references StateProvince\p\g
alter table addresses add constraint FK34207BA26B9FAF99 foreign key (human) references Human\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table family add constraint FKB3985B641DCB1311 foreign key (human2) references Human\p\g
alter table family add constraint FKB3985B641DCB1310 foreign key (human1) references Human\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table friends add constraint FKDC3B49951DCB1311 foreign key (human2) references Human\p\g
alter table friends add constraint FKDC3B49951DCB1310 foreign key (human1) references Human\p\g
alter table human_nick_names add constraint FK8718E1BE6B9FAF99 foreign key (human) references Human\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table permissions add constraint FK4392F484F2810CD2 foreign key (userId) references "User"\p\g
create sequence hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 0.0, null, null, null, null, 1)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 1)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('Steve', 'L', 'Ebersole', null, 0.0 * 2.54, 0, 0.0, null, null, 1)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 11.0, null, null, null, null, 2)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 2)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('John', 'Q', 'Doe', null, 0.0 * 2.54, 0, 0.0, null, null, 2)\p\g
insert into friends (human1, human2) values (1, 2)\p\g
insert into friends (human1, human2) values (2, 1)\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from friends friends1_ inner join Human human0_ on friends1_.human2=human0_.mammal inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where friends1_.human1 = 1\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from friends friends1_ inner join Human human0_ on friends1_.human2=human0_.mammal inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where friends1_.human1 = 1 and human0_2_.body_weight>10.0\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from friends friends1_ inner join Human human0_ on friends1_.human2=human0_.mammal inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where friends1_.human1 = 1 and human0_2_.body_weight<10.0\p\g
delete from friends where human1=1\p\g
delete from friends where human1=2\p\g
delete from Human where mammal=1\p\g
delete from Mammal where animal=1\p\g
delete from Animal where id=1\p\g
delete from Human where mammal=2\p\g
delete from Mammal where animal=2\p\g
delete from Animal where id=2\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 0.0, null, null, null, null, 3)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 3)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('Steve', 'L', 'Ebersole', null, 73.0 * 2.54, 0, 0.0, null, null, 3)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 0.0, null, null, null, null, 4)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 4)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('John', 'Q', 'Doe', null, 50.0 * 2.54, 0, 0.0, null, null, 4)\p\g
insert into friends (human1, human2) values (3, 4)\p\g
insert into friends (human1, human2) values (4, 3)\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from friends friends1_ inner join Human human0_ on friends1_.human2=human0_.mammal inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where friends1_.human1 = 3\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from friends friends1_ inner join Human human0_ on friends1_.human2=human0_.mammal inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where friends1_.human1 = 3 and human0_.height_centimeters / 2.54<51.0\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from friends friends1_ inner join Human human0_ on friends1_.human2=human0_.mammal inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where friends1_.human1 = 3 and human0_.height_centimeters / 2.54>51.0\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from friends friends1_ inner join Human human0_ on friends1_.human2=human0_.mammal inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where friends1_.human1 = 3 and (human0_.height_centimeters / 2.54 between 49 and 51)\p\g
select human0_.mammal as id0_, human0_2_.description as descript2_0_, human0_2_.body_weight as body3_0_, human0_2_.mother_id as mother4_0_, human0_2_.father_id as father5_0_, human0_2_.zoo_id as zoo6_0_, human0_2_.serialNumber as serialNu7_0_, human0_1_.pregnant as pregnant3_, human0_1_.birthdate as birthdate3_, human0_.name_first as name2_7_, human0_.name_initial as name3_7_, human0_.name_last as name4_7_, human0_.nickName as nickName7_, human0_.height_centimeters / 2.54 as height6_7_, human0_.intValue as intValue7_, human0_.floatValue as floatValue7_, human0_.bigDecimalValue as bigDecim9_7_, human0_.bigIntegerValue as bigInte10_7_ from friends friends1_ inner join Human human0_ on friends1_.human2=human0_.mammal inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where friends1_.human1 = 3 and (human0_.height_centimeters / 2.54 not between 49 and 51)\p\g
delete from friends where human1=3\p\g
delete from friends where human1=4\p\g
delete from Human where mammal=3\p\g
delete from Mammal where animal=3\p\g
delete from Animal where id=3\p\g
delete from Human where mammal=4\p\g
delete from Mammal where animal=4\p\g
delete from Animal where id=4\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #1', 11.0, null, null, null, null, 5)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 5)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #2', 9.0, 5, null, null, null, 6)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 6)\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 1.0, null, null, null, null, 7)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 7)\p\g
insert into Human (name_first, name_initial, name_last, nickName, height_centimeters, intValue, floatValue, bigDecimalValue, bigIntegerValue, mammal) values ('Gavin', 'A', 'King', 'Oney', 0.0 * 2.54, 0, 0.0, null, null, 7)\p\g
select ''found'' as col_0_0_, lower(human0_.name_first) as col_1_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where lower(human0_.name_first)=''gavin''\p\g
select ''found'' as col_0_0_, lower(human0_.name_first) as col_1_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where (human0_.name_first+'' ''+human0_.name_initial+'' ''+human0_.name_last)=''Gavin A King''\p\g
select ''found'' as col_0_0_, lower(human0_.name_first) as col_1_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id where (human0_.name_first+'' ''+human0_.name_initial+'' ''+human0_.name_last)=''Gavin A King''\p\g
select animal0_.body_weight+animal1_.body_weight as col_0_0_ from Animal animal0_ inner join Animal animal1_ on animal0_.mother_id=animal1_.id\p\g
select 2.0*(animal0_.body_weight+animal1_.body_weight) as col_0_0_ from Animal animal0_ inner join Animal animal1_ on animal0_.mother_id=animal1_.id\p\g
select sum(animal0_.body_weight+animal1_.body_weight) as col_0_0_ from Animal animal0_ inner join Animal animal1_ on animal0_.mother_id=animal1_.id\p\g
select sum(animal1_.body_weight*2.0) as col_0_0_ from Animal animal0_, Animal animal1_ where animal0_.mother_id=animal1_.id\p\g
select (human0_.name_first+'' ''+human0_.name_initial+'' ''+human0_.name_last) as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
select (human0_.name_first+'' ''+human0_.name_initial+'' ''+human0_.name_last) as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
select human0_.nickName as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
select lower(human0_.nickName) as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
select abs(human0_2_.body_weight*-1) as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
select upper((human0_.name_first+'' (''+human0_.nickName+'')'')) as col_0_0_ from Human human0_ inner join Mammal human0_1_ on human0_.mammal=human0_1_.animal inner join Animal human0_2_ on human0_.mammal=human0_2_.id\p\g
Parameter count mismatch 4538, 0,1
select abs(animal0_.body_weight-?) as col_0_0_ from Animal animal0_
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
create table Animal (id bigint not null, description varchar(255) with null, body_weight float with null, mother_id bigint with null, father_id bigint with null, zoo_id bigint with null, serialNumber varchar(255) with null, primary key (id))\p\g
create table CRAZY_ID_NODE (ID bigint not null, name varchar(255) with null, primary key (ID))\p\g
create table CRAZY_ID_TOP (ID bigint not null, name varchar(255) with null, heresAnotherCrazyIdFieldName bigint with null, primary key (ID))\p\g
create table Cat (mammal bigint not null, primary key (mammal))\p\g
create table Customer (customerId varchar(10) not null, name varchar(100) not null, address varchar(200) not null, primary key (customerId))\p\g
create table CustomerOrder (customerId varchar(10) not null, orderNumber integer not null, orderDate ansidate not null, primary key (customerId, orderNumber))\p\g
create table Dog (mammal bigint not null, primary key (mammal))\p\g
create table DomesticAnimal (mammal bigint not null, owner bigint with null, primary key (mammal))\p\g
create table HQL_COMP_CONT (ID bigint not null, STREET_ADDR varchar(255) with null, CITY_ADDR varchar(255) with null, STATE_ADDR varchar(255) with null, ZIP_CODE_ADDR integer with null, ZIP_PLUS4_ADDR integer with null, primary key (ID))\p\g
create table Human (mammal bigint not null, name_first varchar(255) with null, name_initial char(1) with null, name_last varchar(255) with null, nickName varchar(255) with null, height_centimeters float not null, intValue integer with null, floatValue float with null, bigDecimalValue decimal(19, 2) with null, bigIntegerValue decimal(19, 2) with null, primary key (mammal))\p\g
create table JOINED (ID bigint not null, joinedName varchar(255) with null, primary key (ID))\p\g
create table Joiner (id bigint not null, name varchar(255) with null, primary key (id))\p\g
create table LineItem (customerId varchar(10) not null, orderNumber integer not null, productId varchar(10) not null, quantity integer with null, primary key (customerId, orderNumber, productId))\p\g
create table Lizard (reptile bigint not null, primary key (reptile))\p\g
create table MANY_TO_MANY (IN_ID bigint not null, OUT_ID bigint not null, primary key (IN_ID, OUT_ID))\p\g
create table MARECM (MCLINK bigint not null, MCOMPR varchar(1) with null, MCOMME varchar(30) with null, primary key (MCLINK))\p\g
create table MARELO (MLMAG integer not null, MLOCA varchar(11) not null, MLINK bigint with null, MLART varchar(13) with null, MLIDO bigint with null, MLDTC timestamp(9) with time zone with null, MLTOP varchar(10) with null, MLRAG varchar(2) with null, MLROP smallint with null, MLCOM bigint with null, MATRI varchar(14) with null, SOCOD varchar(10) with null, primary key (MLMAG, MLOCA))\p\g
create table Mammal (animal bigint not null, pregnant tinyint with null, birthdate ansidate with null, mammalZoo_id bigint with null, name varchar(255) with null, primary key (animal))\p\g
create table Model (modelId varchar(32) not null, name varchar(25) not null, description varchar(200) not null, productId varchar(32) not null, primary key (modelId))\p\g
create table Product (productId varchar(10) not null, description varchar(200) not null, cost decimal(19, 2) with null, numberAvailable integer with null, primary key (productId))\p\g
create table ProductLine (productId varchar(32) not null, description varchar(200) not null, primary key (productId))\p\g
create table Reptile (animal bigint not null, bodyTemperature float with null, primary key (animal))\p\g
create table SIMPLE_1 (ID bigint not null, NAME varchar(255) with null, negated_num integer with null, primary key (ID))\p\g
create table SIMPLE_2 (ID bigint not null, NAME varchar(255) with null, SIMPLE_1_ID bigint with null, primary key (ID))\p\g
create table StateProvince (id bigint not null, name varchar(255) with null, isoCode varchar(255) with null, primary key (id))\p\g
create table T_CHAR_PROP (ID bigint not null, VAL varchar(255) not null, primary key (ID))\p\g
create table T_COMPLEX_PROP (ID bigint not null, primary key (ID))\p\g
create table T_COMPLEX_SUB_PROPS (PROP_ID bigint not null, SUB_PROP_VAL varchar(255) with null, SUB_PROP_NAME varchar(255) not null, primary key (PROP_ID, SUB_PROP_NAME))\p\g
create table T_GEN_PROPS (PROP_SET_ID bigint not null, PROP_TYPE varchar(255) with null, PROP_ID bigint with null, GEN_PROP_NAME varchar(255) not null, primary key (PROP_SET_ID, GEN_PROP_NAME))\p\g
create table T_NUM_PROP (ID bigint not null, VAL integer not null, primary key (ID))\p\g
create table T_PROP_SET (ID bigint not null, NAME varchar(255) with null, S_S_PROP_TYPE varchar(255) with null, S_S_PROP_ID bigint with null, primary key (ID))\p\g
create table VariousKeywordPropertyEntity (id bigint not null, type varchar(255) with null, value varchar(255) with null, key varchar(255) with null, entry varchar(255) with null, primary key (id))\p\g
create table Zoo (id bigint not null, zooType char(1) not null, name varchar(255) with null, classification tinyint with null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, primary key (id))\p\g
create table "User" (id bigint not null, userName varchar(255) with null, primary key (id))\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, bar_string varchar(24) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table addresses (human bigint not null, street varchar(255) with null, city varchar(255) with null, postalCode varchar(255) with null, country varchar(255) with null, state_prov_id bigint with null, type varchar(255) not null, primary key (human, type))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table family (human1 bigint not null, human2 bigint not null, relationship varchar(255) not null, primary key (human1, relationship))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table friends (human1 bigint not null, human2 bigint not null)\p\g
create table human_nick_names (human bigint not null, nick_name varchar(255) not null, primary key (human, nick_name))\p\g
create table image (id bigint not null, name varchar(255) with null, size_mb float with null, primary key (id))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, primary key (many_key))\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, primary key (one_key))\p\g
create table permissions (userId bigint not null, permissionName varchar(255) with null, permissionId integer not null, primary key (userId, permissionId))\p\g
alter table Animal add constraint FK752A7A1C4B485C79 foreign key (zoo_id) references Zoo\p\g
alter table Animal add constraint FK752A7A1C1F3964B4 foreign key (mother_id) references Animal\p\g
alter table Animal add constraint FK752A7A1C6309E77B foreign key (father_id) references Animal\p\g
alter table CRAZY_ID_TOP add constraint FK1AA9579F73113F33 foreign key (heresAnotherCrazyIdFieldName) references CRAZY_ID_NODE\p\g
alter table Cat add constraint FK107B66D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table CustomerOrder add constraint FKAEF781F06153C9DD foreign key (customerId) references Customer\p\g
alter table Dog add constraint FK10D1C6D384BBA foreign key (mammal) references DomesticAnimal\p\g
alter table DomesticAnimal add constraint FKE02638DA1733655F foreign key (mammal) references Mammal\p\g
alter table DomesticAnimal add constraint FKE02638DA6C03411F foreign key (owner) references Human\p\g
alter table Human add constraint FK42D710D1733655F foreign key (mammal) references Mammal\p\g
alter table JOINED add constraint FK82C23B49534E0F13 foreign key (ID) references Joiner\p\g
alter table LineItem add constraint FK4AAEE947EDAE41F3 foreign key (productId) references Product\p\g
alter table LineItem add constraint FK4AAEE947CB8F4618 foreign key (customerId, orderNumber) references CustomerOrder\p\g
alter table Lizard add constraint FK87B0E2B6EE398315 foreign key (reptile) references Reptile\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C3E0DF2A91 foreign key (OUT_ID) references SIMPLE_1\p\g
alter table MANY_TO_MANY add constraint FK8CF3D7C322C9695A foreign key (IN_ID) references SIMPLE_1\p\g
alter table MARELO add constraint FK871F728AE624DD92 foreign key (MLCOM) references MARECM\p\g
alter table Mammal add constraint FK88EF417FEFA9D699 foreign key (animal) references Animal\p\g
alter table Mammal add constraint FK88EF417FCE6EEE98 foreign key (mammalZoo_id) references Zoo\p\g
alter table Model add constraint FK4710B0921C08435 foreign key (productId) references ProductLine\p\g
alter table Reptile add constraint FKA4790CABEFA9D699 foreign key (animal) references Animal\p\g
alter table SIMPLE_2 add constraint FK4B988CE5C81DD13B foreign key (SIMPLE_1_ID) references SIMPLE_1\p\g
alter table T_COMPLEX_SUB_PROPS add constraint FK5470D25725D7CC5B foreign key (PROP_ID) references T_COMPLEX_PROP\p\g
alter table T_GEN_PROPS add constraint FK65C7C556AA2002A9 foreign key (PROP_SET_ID) references T_PROP_SET\p\g
alter table Zoo add constraint FK15FBA55106523 foreign key (state_prov_id) references StateProvince\p\g
alter table "User" add constraint FK285FEB65AF5B87 foreign key (id) references Human\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table addresses add constraint FK34207BA255106523 foreign key (state_prov_id) references StateProvince\p\g
alter table addresses add constraint FK34207BA26B9FAF99 foreign key (human) references Human\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table family add constraint FKB3985B641DCB1311 foreign key (human2) references Human\p\g
alter table family add constraint FKB3985B641DCB1310 foreign key (human1) references Human\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table friends add constraint FKDC3B49951DCB1311 foreign key (human2) references Human\p\g
alter table friends add constraint FKDC3B49951DCB1310 foreign key (human1) references Human\p\g
alter table human_nick_names add constraint FK8718E1BE6B9FAF99 foreign key (human) references Human\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table permissions add constraint FK4392F484F2810CD2 foreign key (userId) references "User"\p\g
create sequence hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 1.5, null, null, null, null, 1)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 0.0, null, null, null, null, 2)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values (null, 10.0, null, null, null, null, 3)\p\g
update Animal set mother_id=3 where id=2\p\g
update Animal set mother_id=3 where id=1\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal cross join Animal animal1_ where animal0_.mother_id=animal1_.id and (animal1_.body_weight<2.0 or animal1_.body_weight>9.0)\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal cross join Animal animal1_ where animal0_.mother_id=animal1_.id and animal1_.body_weight>2.0 and animal1_.body_weight>9.0\p\g
update Animal set mother_id=null where mother_id=3\p\g
delete from Animal where id=2\p\g
delete from Animal where id=1\p\g
delete from Animal where id=3\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #1', 11.0, null, null, null, null, 4)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 4)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #2', 9.0, 4, null, null, null, 5)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 5)\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal\p\g
update Animal set description='Mammal #2', body_weight=9.0, mother_id=null, father_id=null, zoo_id=null, serialNumber=null where id=5\p\g
update Animal set mother_id=null where mother_id=4\p\g
update Animal set mother_id=null where mother_id=5\p\g
delete from Mammal where animal=4\p\g
delete from Animal where id=4\p\g
delete from Mammal where animal=5\p\g
delete from Animal where id=5\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #1', 11.0, null, null, null, null, 6)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 6)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #2', 9.0, 6, null, null, null, 7)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 7)\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal\p\g
update Animal set description='Mammal #2', body_weight=9.0, mother_id=null, father_id=null, zoo_id=null, serialNumber=null where id=7\p\g
update Animal set mother_id=null where mother_id=6\p\g
update Animal set mother_id=null where mother_id=7\p\g
delete from Mammal where animal=6\p\g
delete from Animal where id=6\p\g
delete from Mammal where animal=7\p\g
delete from Animal where id=7\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #1', 11.0, null, null, null, null, 8)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 8)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #2', 9.0, 8, null, null, null, 9)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 9)\p\g
select animal1_.id as id0_, animal1_.description as descript2_0_, animal1_.body_weight as body3_0_, animal1_.mother_id as mother4_0_, animal1_.father_id as father5_0_, animal1_.zoo_id as zoo6_0_, animal1_.serialNumber as serialNu7_0_, animal1_1_.bodyTemperature as bodyTemp2_1_, animal1_3_.pregnant as pregnant3_, animal1_3_.birthdate as birthdate3_, animal1_4_.owner as owner4_, animal1_7_.name_first as name2_7_, animal1_7_.name_initial as name3_7_, animal1_7_.name_last as name4_7_, animal1_7_.nickName as nickName7_, animal1_7_.height_centimeters / 2.54 as height6_7_, animal1_7_.intValue as intValue7_, animal1_7_.floatValue as floatValue7_, animal1_7_.bigDecimalValue as bigDecim9_7_, animal1_7_.bigIntegerValue as bigInte10_7_, case when animal1_2_.reptile is not null then 2 when animal1_5_.mammal is not null then 5 when animal1_6_.mammal is not null then 6 when animal1_4_.mammal is not null then 4 when animal1_7_.mammal is not null then 7 when animal1_1_.animal is not null then 1 when animal1_3_.animal is not null then 3 when animal1_.id is not null then 0 end as clazz_ from Animal animal0_ inner join Animal animal1_ on animal0_.mother_id=animal1_.id left outer join Reptile animal1_1_ on animal1_.id=animal1_1_.animal left outer join Lizard animal1_2_ on animal1_.id=animal1_2_.reptile left outer join Mammal animal1_3_ on animal1_.id=animal1_3_.animal left outer join DomesticAnimal animal1_4_ on animal1_.id=animal1_4_.mammal left outer join Cat animal1_5_ on animal1_.id=animal1_5_.mammal left outer join Dog animal1_6_ on animal1_.id=animal1_6_.mammal left outer join Human animal1_7_ on animal1_.id=animal1_7_.mammal\p\g
select animal0_.id as id0_0_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.id=9\p\g
update Animal set description='Mammal #2', body_weight=9.0, mother_id=null, father_id=null, zoo_id=null, serialNumber=null where id=9\p\g
update Animal set mother_id=null where mother_id=8\p\g
update Animal set mother_id=null where mother_id=9\p\g
delete from Mammal where animal=8\p\g
delete from Animal where id=8\p\g
delete from Mammal where animal=9\p\g
delete from Animal where id=9\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #1', 11.0, null, null, null, null, 10)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 10)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #2', 9.0, 10, null, null, null, 11)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 11)\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight>10\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight<=10\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight between 0 and 10\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight not between 0 and 10\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where sqrt(animal0_.body_weight)/2>10\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.body_weight>10 and animal0_.body_weight<100 or animal0_.body_weight is null\p\g
update Animal set description='Mammal #2', body_weight=9.0, mother_id=null, father_id=null, zoo_id=null, serialNumber=null where id=11\p\g
update Animal set mother_id=null where mother_id=10\p\g
update Animal set mother_id=null where mother_id=11\p\g
delete from Mammal where animal=10\p\g
delete from Animal where id=10\p\g
delete from Mammal where animal=11\p\g
delete from Animal where id=11\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #1', 11.0, null, null, null, null, 12)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 12)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #2', 9.0, 12, null, null, null, 13)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 13)\p\g
select animal0_.id as id0_0_, animal1_.id as id0_1_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_, animal1_.description as descript2_0_1_, animal1_.body_weight as body3_0_1_, animal1_.mother_id as mother4_0_1_, animal1_.father_id as father5_0_1_, animal1_.zoo_id as zoo6_0_1_, animal1_.serialNumber as serialNu7_0_1_, animal1_1_.bodyTemperature as bodyTemp2_1_1_, animal1_3_.pregnant as pregnant3_1_, animal1_3_.birthdate as birthdate3_1_, animal1_4_.owner as owner4_1_, animal1_7_.name_first as name2_7_1_, animal1_7_.name_initial as name3_7_1_, animal1_7_.name_last as name4_7_1_, animal1_7_.nickName as nickName7_1_, animal1_7_.height_centimeters / 2.54 as height6_7_1_, animal1_7_.intValue as intValue7_1_, animal1_7_.floatValue as floatValue7_1_, animal1_7_.bigDecimalValue as bigDecim9_7_1_, animal1_7_.bigIntegerValue as bigInte10_7_1_, case when animal1_2_.reptile is not null then 2 when animal1_5_.mammal is not null then 5 when animal1_6_.mammal is not null then 6 when animal1_4_.mammal is not null then 4 when animal1_7_.mammal is not null then 7 when animal1_1_.animal is not null then 1 when animal1_3_.animal is not null then 3 when animal1_.id is not null then 0 end as clazz_1_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal inner join Animal animal1_ on animal0_.mother_id=animal1_.id left outer join Reptile animal1_1_ on animal1_.id=animal1_1_.animal left outer join Lizard animal1_2_ on animal1_.id=animal1_2_.reptile left outer join Mammal animal1_3_ on animal1_.id=animal1_3_.animal left outer join DomesticAnimal animal1_4_ on animal1_.id=animal1_4_.mammal left outer join Cat animal1_5_ on animal1_.id=animal1_5_.mammal left outer join Dog animal1_6_ on animal1_.id=animal1_6_.mammal left outer join Human animal1_7_ on animal1_.id=animal1_7_.mammal\p\g
select animal0_.id as id0_0_, animal1_.id as id0_1_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_, animal1_.description as descript2_0_1_, animal1_.body_weight as body3_0_1_, animal1_.mother_id as mother4_0_1_, animal1_.father_id as father5_0_1_, animal1_.zoo_id as zoo6_0_1_, animal1_.serialNumber as serialNu7_0_1_, animal1_1_.bodyTemperature as bodyTemp2_1_1_, animal1_3_.pregnant as pregnant3_1_, animal1_3_.birthdate as birthdate3_1_, animal1_4_.owner as owner4_1_, animal1_7_.name_first as name2_7_1_, animal1_7_.name_initial as name3_7_1_, animal1_7_.name_last as name4_7_1_, animal1_7_.nickName as nickName7_1_, animal1_7_.height_centimeters / 2.54 as height6_7_1_, animal1_7_.intValue as intValue7_1_, animal1_7_.floatValue as floatValue7_1_, animal1_7_.bigDecimalValue as bigDecim9_7_1_, animal1_7_.bigIntegerValue as bigInte10_7_1_, case when animal1_2_.reptile is not null then 2 when animal1_5_.mammal is not null then 5 when animal1_6_.mammal is not null then 6 when animal1_4_.mammal is not null then 4 when animal1_7_.mammal is not null then 7 when animal1_1_.animal is not null then 1 when animal1_3_.animal is not null then 3 when animal1_.id is not null then 0 end as clazz_1_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal inner join Animal animal1_ on animal0_.mother_id=animal1_.id left outer join Reptile animal1_1_ on animal1_.id=animal1_1_.animal left outer join Lizard animal1_2_ on animal1_.id=animal1_2_.reptile left outer join Mammal animal1_3_ on animal1_.id=animal1_3_.animal left outer join DomesticAnimal animal1_4_ on animal1_.id=animal1_4_.mammal left outer join Cat animal1_5_ on animal1_.id=animal1_5_.mammal left outer join Dog animal1_6_ on animal1_.id=animal1_6_.mammal left outer join Human animal1_7_ on animal1_.id=animal1_7_.mammal\p\g
update Animal set description='Mammal #2', body_weight=9.0, mother_id=null, father_id=null, zoo_id=null, serialNumber=null where id=13\p\g
update Animal set mother_id=null where mother_id=12\p\g
update Animal set mother_id=null where mother_id=13\p\g
delete from Mammal where animal=12\p\g
delete from Animal where id=12\p\g
delete from Mammal where animal=13\p\g
delete from Animal where id=13\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #1', 11.0, null, null, null, null, 14)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 14)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #2', 9.0, 14, null, null, null, 15)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 15)\p\g
select animal0_.id as id0_0_, offspring1_.id as id0_1_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_, offspring1_.description as descript2_0_1_, offspring1_.body_weight as body3_0_1_, offspring1_.mother_id as mother4_0_1_, offspring1_.father_id as father5_0_1_, offspring1_.zoo_id as zoo6_0_1_, offspring1_.serialNumber as serialNu7_0_1_, offspring1_1_.bodyTemperature as bodyTemp2_1_1_, offspring1_3_.pregnant as pregnant3_1_, offspring1_3_.birthdate as birthdate3_1_, offspring1_4_.owner as owner4_1_, offspring1_7_.name_first as name2_7_1_, offspring1_7_.name_initial as name3_7_1_, offspring1_7_.name_last as name4_7_1_, offspring1_7_.nickName as nickName7_1_, offspring1_7_.height_centimeters / 2.54 as height6_7_1_, offspring1_7_.intValue as intValue7_1_, offspring1_7_.floatValue as floatValue7_1_, offspring1_7_.bigDecimalValue as bigDecim9_7_1_, offspring1_7_.bigIntegerValue as bigInte10_7_1_, case when offspring1_2_.reptile is not null then 2 when offspring1_5_.mammal is not null then 5 when offspring1_6_.mammal is not null then 6 when offspring1_4_.mammal is not null then 4 when offspring1_7_.mammal is not null then 7 when offspring1_1_.animal is not null then 1 when offspring1_3_.animal is not null then 3 when offspring1_.id is not null then 0 end as clazz_1_, offspring1_.mother_id as mother4_0__, offspring1_.id as id0__ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal inner join Animal offspring1_ on animal0_.id=offspring1_.mother_id left outer join Reptile offspring1_1_ on offspring1_.id=offspring1_1_.animal left outer join Lizard offspring1_2_ on offspring1_.id=offspring1_2_.reptile left outer join Mammal offspring1_3_ on offspring1_.id=offspring1_3_.animal left outer join DomesticAnimal offspring1_4_ on offspring1_.id=offspring1_4_.mammal left outer join Cat offspring1_5_ on offspring1_.id=offspring1_5_.mammal left outer join Dog offspring1_6_ on offspring1_.id=offspring1_6_.mammal left outer join Human offspring1_7_ on offspring1_.id=offspring1_7_.mammal order by offspring1_.father_id\p\g
select animal0_.id as id0_0_, offspring1_.id as id0_1_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_, offspring1_.description as descript2_0_1_, offspring1_.body_weight as body3_0_1_, offspring1_.mother_id as mother4_0_1_, offspring1_.father_id as father5_0_1_, offspring1_.zoo_id as zoo6_0_1_, offspring1_.serialNumber as serialNu7_0_1_, offspring1_1_.bodyTemperature as bodyTemp2_1_1_, offspring1_3_.pregnant as pregnant3_1_, offspring1_3_.birthdate as birthdate3_1_, offspring1_4_.owner as owner4_1_, offspring1_7_.name_first as name2_7_1_, offspring1_7_.name_initial as name3_7_1_, offspring1_7_.name_last as name4_7_1_, offspring1_7_.nickName as nickName7_1_, offspring1_7_.height_centimeters / 2.54 as height6_7_1_, offspring1_7_.intValue as intValue7_1_, offspring1_7_.floatValue as floatValue7_1_, offspring1_7_.bigDecimalValue as bigDecim9_7_1_, offspring1_7_.bigIntegerValue as bigInte10_7_1_, case when offspring1_2_.reptile is not null then 2 when offspring1_5_.mammal is not null then 5 when offspring1_6_.mammal is not null then 6 when offspring1_4_.mammal is not null then 4 when offspring1_7_.mammal is not null then 7 when offspring1_1_.animal is not null then 1 when offspring1_3_.animal is not null then 3 when offspring1_.id is not null then 0 end as clazz_1_, offspring1_.mother_id as mother4_0__, offspring1_.id as id0__ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal inner join Animal offspring1_ on animal0_.id=offspring1_.mother_id left outer join Reptile offspring1_1_ on offspring1_.id=offspring1_1_.animal left outer join Lizard offspring1_2_ on offspring1_.id=offspring1_2_.reptile left outer join Mammal offspring1_3_ on offspring1_.id=offspring1_3_.animal left outer join DomesticAnimal offspring1_4_ on offspring1_.id=offspring1_4_.mammal left outer join Cat offspring1_5_ on offspring1_.id=offspring1_5_.mammal left outer join Dog offspring1_6_ on offspring1_.id=offspring1_6_.mammal left outer join Human offspring1_7_ on offspring1_.id=offspring1_7_.mammal order by offspring1_.father_id\p\g
update Animal set description='Mammal #2', body_weight=9.0, mother_id=null, father_id=null, zoo_id=null, serialNumber=null where id=15\p\g
update Animal set mother_id=null where mother_id=14\p\g
update Animal set mother_id=null where mother_id=15\p\g
delete from Mammal where animal=14\p\g
delete from Animal where id=14\p\g
delete from Mammal where animal=15\p\g
delete from Animal where id=15\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #1', 11.0, null, null, null, null, 16)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 16)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #2', 9.0, 16, null, null, null, 17)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 17)\p\g
select animal0_.mother_id as col_0_0_, max(animal0_.body_weight) as col_1_0_ from Animal animal0_ group by animal0_.mother_id\p\g
select animal0_.id as id0_0_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.id=16\p\g
select animal0_.id as id0_0_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.id=17\p\g
update Animal set description='Mammal #2', body_weight=9.0, mother_id=null, father_id=null, zoo_id=null, serialNumber=null where id=17\p\g
update Animal set mother_id=null where mother_id=16\p\g
update Animal set mother_id=null where mother_id=17\p\g
delete from Mammal where animal=16\p\g
delete from Animal where id=16\p\g
delete from Mammal where animal=17\p\g
delete from Animal where id=17\p\g
insert into Product (description, cost, numberAvailable, productId) values ('a product', 1, 0, 'abc123')\p\g
select current_time as col_0_0_, current_date as col_1_0_, current_timestamp as col_2_0_ from Product product0_\p\g
delete from Product where productId='abc123'\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #1', 11.0, null, null, null, null, 18)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 18)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #2', 9.0, 18, null, null, null, 19)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 19)\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_\p\g
select animal0_.id as id0_0_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.id=18\p\g
select animal0_.id as id0_0_, animal0_.description as descript2_0_0_, animal0_.body_weight as body3_0_0_, animal0_.mother_id as mother4_0_0_, animal0_.father_id as father5_0_0_, animal0_.zoo_id as zoo6_0_0_, animal0_.serialNumber as serialNu7_0_0_, animal0_1_.bodyTemperature as bodyTemp2_1_0_, animal0_3_.pregnant as pregnant3_0_, animal0_3_.birthdate as birthdate3_0_, animal0_4_.owner as owner4_0_, animal0_7_.name_first as name2_7_0_, animal0_7_.name_initial as name3_7_0_, animal0_7_.name_last as name4_7_0_, animal0_7_.nickName as nickName7_0_, animal0_7_.height_centimeters / 2.54 as height6_7_0_, animal0_7_.intValue as intValue7_0_, animal0_7_.floatValue as floatValue7_0_, animal0_7_.bigDecimalValue as bigDecim9_7_0_, animal0_7_.bigIntegerValue as bigInte10_7_0_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_0_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.id=19\p\g
update Animal set description='Mammal #2', body_weight=9.0, mother_id=null, father_id=null, zoo_id=null, serialNumber=null where id=19\p\g
update Animal set mother_id=null where mother_id=18\p\g
update Animal set mother_id=null where mother_id=19\p\g
delete from Mammal where animal=18\p\g
delete from Animal where id=18\p\g
delete from Mammal where animal=19\p\g
delete from Animal where id=19\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #1', 11.0, null, null, null, null, 20)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 20)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #2', 9.0, 20, null, null, null, 21)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 21)\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_ order by animal0_.body_weight desc\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_ order by animal0_.body_weight desc\p\g
select animal0_.description as col_0_0_, animal0_.body_weight as col_1_0_ from Animal animal0_ order by animal0_.body_weight desc\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal cross join Animal animal1_ order by animal0_.id\p\g
update Animal set description='Mammal #2', body_weight=9.0, mother_id=null, father_id=null, zoo_id=null, serialNumber=null where id=21\p\g
update Animal set mother_id=null where mother_id=20\p\g
update Animal set mother_id=null where mother_id=21\p\g
delete from Mammal where animal=20\p\g
delete from Animal where id=20\p\g
delete from Mammal where animal=21\p\g
delete from Animal where id=21\p\g
select nextval for hibernate_sequence\p\g
select nextval for hibernate_sequence\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #1', 11.0, null, null, null, null, 22)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 22)\p\g
insert into Animal (description, body_weight, mother_id, father_id, zoo_id, serialNumber, id) values ('Mammal #2', 9.0, 22, null, null, null, 23)\p\g
insert into Mammal (pregnant, birthdate, animal) values (false, null, 23)\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal order by animal0_.body_weight desc\p\g
select animal0_.id as col_0_0_ from Animal animal0_ order by animal0_.body_weight desc\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal order by animal0_.body_weight desc\p\g
update Animal set description='Mammal #2', body_weight=9.0, mother_id=null, father_id=null, zoo_id=null, serialNumber=null where id=23\p\g
update Animal set mother_id=null where mother_id=22\p\g
update Animal set mother_id=null where mother_id=23\p\g
delete from Mammal where animal=22\p\g
delete from Animal where id=22\p\g
delete from Mammal where animal=23\p\g
delete from Animal where id=23\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.description=((''1''+(''2''+''3'')+(''4''+''5''))+''0'')\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where substring(animal0_.description FROM 1 FOR 3)=''cat''\p\g
select substring(animal0_.description FROM 1 FOR 3) as col_0_0_ from Animal animal0_\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where lower(animal0_.description)=''cat''\p\g
select lower(animal0_.description) as col_0_0_ from Animal animal0_\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where upper(animal0_.description)=''CAT''\p\g
select upper(animal0_.description) as col_0_0_ from Animal animal0_\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where length(animal0_.description)=5\p\g
select length(animal0_.description) as col_0_0_ from Animal animal0_\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where locate(''abc'', animal0_.description)=2\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where locate(''abc'', animal0_.description)=2\p\g
select locate(''cat'', animal0_.description) as col_0_0_ from Animal animal0_\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where trim(trailing ''_'' from animal0_.description)=''cat''\p\g
select trim(trailing ''_'' from animal0_.description) as col_0_0_ from Animal animal0_\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where trim(leading ''_'' from animal0_.description)=''cat''\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where trim(both from animal0_.description)=''cat''\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where trim(animal0_.description)=''cat''\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where abs(animal0_.body_weight)=sqrt(animal0_.body_weight)\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where mod(16, 4)=4\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where octet_length(hex(animal0_.body_weight))*4=24\p\g
select octet_length(hex(animal0_.body_weight))*4 as col_0_0_ from Animal animal0_\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.description like ''%a%''\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.description not like ''%a%''\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where animal0_.description like ''x%ax%'' escape ''x''\p\g
select animal0_.id as id0_, animal0_.description as descript2_0_, animal0_.body_weight as body3_0_, animal0_.mother_id as mother4_0_, animal0_.father_id as father5_0_, animal0_.zoo_id as zoo6_0_, animal0_.serialNumber as serialNu7_0_, animal0_1_.bodyTemperature as bodyTemp2_1_, animal0_3_.pregnant as pregnant3_, animal0_3_.birthdate as birthdate3_, animal0_4_.owner as owner4_, animal0_7_.name_first as name2_7_, animal0_7_.name_initial as name3_7_, animal0_7_.name_last as name4_7_, animal0_7_.nickName as nickName7_, animal0_7_.height_centimeters / 2.54 as height6_7_, animal0_7_.intValue as intValue7_, animal0_7_.floatValue as floatValue7_, animal0_7_.bigDecimalValue as bigDecim9_7_, animal0_7_.bigIntegerValue as bigInte10_7_, case when animal0_2_.reptile is not null then 2 when animal0_5_.mammal is not null then 5 when animal0_6_.mammal is not null then 6 when animal0_4_.mammal is not null then 4 when animal0_7_.mammal is not null then 7 when animal0_1_.animal is not null then 1 when animal0_3_.animal is not null then 3 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join Reptile animal0_1_ on animal0_.id=animal0_1_.animal left outer join Lizard animal0_2_ on animal0_.id=animal0_2_.reptile left outer join Mammal animal0_3_ on animal0_.id=animal0_3_.animal left outer join DomesticAnimal animal0_4_ on animal0_.id=animal0_4_.mammal left outer join Cat animal0_5_ on animal0_.id=animal0_5_.mammal left outer join Dog animal0_6_ on animal0_.id=animal0_6_.mammal left outer join Human animal0_7_ on animal0_.id=animal0_7_.mammal where exists (select max(animal1_.body_weight) from Animal animal1_)\p\g
drop table Animal\p\g
drop table CRAZY_ID_NODE\p\g
drop table CRAZY_ID_TOP\p\g
drop table Cat\p\g
drop table Customer\p\g
drop table CustomerOrder\p\g
drop table Dog\p\g
drop table DomesticAnimal\p\g
drop table HQL_COMP_CONT\p\g
drop table Human\p\g
drop table JOINED\p\g
drop table Joiner\p\g
drop table LineItem\p\g
drop table Lizard\p\g
drop table MANY_TO_MANY\p\g
drop table MARECM\p\g
drop table MARELO\p\g
drop table Mammal\p\g
drop table Model\p\g
drop table Product\p\g
drop table ProductLine\p\g
drop table Reptile\p\g
drop table SIMPLE_1\p\g
drop table SIMPLE_2\p\g
drop table StateProvince\p\g
drop table T_CHAR_PROP\p\g
drop table T_COMPLEX_PROP\p\g
drop table T_COMPLEX_SUB_PROPS\p\g
drop table T_GEN_PROPS\p\g
drop table T_NUM_PROP\p\g
drop table T_PROP_SET\p\g
drop table VariousKeywordPropertyEntity\p\g
drop table Zoo\p\g
drop table "User"\p\g
drop table "foos"\p\g
drop table addresses\p\g
drop table bar_join_table\p\g
drop table family\p\g
drop table foobytes\p\g
drop table friends\p\g
drop table human_nick_names\p\g
drop table image\p\g
drop table jointable\p\g
drop table many\p\g
drop table one\p\g
drop table permissions\p\g
drop sequence hibernate_sequence restrict\p\g
