package org.hibernate.bugs;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.hibernate.bugs.entities.Role;
import org.hibernate.bugs.entities.User;
import org.hibernate.bugs.entities.UserRole;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM,
 * using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@BeforeEach
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
	}

	@AfterEach
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		try {
			entityManager.getTransaction().begin();
			Role role = new Role();
			role.setIdentifier("ADMIN");
			role = entityManager.merge(role);
			entityManager.flush();

			Role roleFromDb = entityManager.find(Role.class, role.getCodeObject());
			UserRole userRole = new UserRole();
			userRole.setRole(roleFromDb);

			User user = new User();
			user.setIdentifier("hzerai");
			user.setVersion(1);
			user.addUserRole(userRole);
			userRole.setUser(user);
			entityManager.merge(user);

			entityManager.flush();
			entityManager.clear();

			TypedQuery<UserRole> query = entityManager.createQuery("select a from userRole a", UserRole.class);
			List<UserRole> r = query.getResultList();
			assertEquals(1, r.size());
			
		} catch (Exception e) {
			e.printStackTrace();
			Logger.getLogger(JPAUnitTestCase.class).error(e);
		}

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
