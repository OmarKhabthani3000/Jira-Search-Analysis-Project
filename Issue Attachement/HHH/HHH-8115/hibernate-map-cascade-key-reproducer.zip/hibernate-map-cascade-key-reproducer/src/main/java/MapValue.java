import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="map_value")
public class MapValue {

    private Long id;
    private String name;

    public MapValue() {}
    public MapValue(String name) {
        this.name = name;
    }

    @Id
    @GeneratedValue
    @Column(name="id", unique=true, nullable=false)
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    @Column(name="name", unique=true, nullable=false)
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("MapValue [id=").append(getId()).append(", name=").append(getName()).append("]");
        return builder.toString();
    }

}
