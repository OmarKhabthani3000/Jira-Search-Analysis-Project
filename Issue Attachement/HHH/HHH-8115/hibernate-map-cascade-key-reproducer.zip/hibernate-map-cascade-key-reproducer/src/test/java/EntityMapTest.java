import java.util.HashMap;
import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Environment;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;



public class EntityMapTest {

    SessionFactory sessionFactory;
    Session session;
    Transaction tx;

    @Before
    public void setUp() throws Exception {
        // Let Spring set up an embedded database for us
    	LocalSessionFactoryBean sessionFactoryBean = new LocalSessionFactoryBean();
        sessionFactoryBean.setDataSource(new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.H2).build());
        // Add our annotated entity classes
        sessionFactoryBean.setAnnotatedClasses(new Class[]{MapKey.class,MapHolder.class,MapValue.class});
        Properties hibernateProperties = new Properties();
        // Show the SQL (you can see the deletes being issued)
        hibernateProperties.setProperty(Environment.SHOW_SQL, "true");
        // Create the schema automatically
        hibernateProperties.setProperty(Environment.HBM2DDL_AUTO, "update");
        sessionFactoryBean.setHibernateProperties(hibernateProperties);
        // Let Spring build us a SessionFactory
        sessionFactoryBean.afterPropertiesSet();
        sessionFactory = sessionFactoryBean.getObject();
    }

    @Test
    public void testInsertIntoMapExpicitKeySave() throws Exception {
        doInsertIntoMap(true);
    }
   
    @Test
    public void testInsertIntoMapRelyOnCascadeAll() throws Exception {
        doInsertIntoMap(false);
    }

	public void doInsertIntoMap(final boolean explicitKeySave) {
		// Session 1: Insert a value into the map
        beginSession();
        MapHolder mapHolder = new MapHolder();
        mapHolder.setMap(new HashMap<MapKey,MapValue>());
        addMapEntry(mapHolder, "A", "1", explicitKeySave );
        session.save(mapHolder);
        // Verify there are 1 entries in the map
        Assert.assertEquals(1, mapHolder.getMap().size());
        endSession();
	}

    private void addMapEntry(MapHolder mapHolder, String key, String value, boolean explicitKeySave) {
        System.out.println("Inserting ("+key+","+value+") into map");
        MapValue entityValue = new MapValue(value);
        MapKey entityKey = new MapKey(key);
        if( explicitKeySave) {
        	session.save(entityKey);
        }
        mapHolder.getMap().put(entityKey, entityValue);
    }

    private void beginSession() {
        System.out.println("--- session begin ---");
        session = sessionFactory.openSession();
        tx = session.beginTransaction();
    }

    private void endSession() {
        tx.commit();
        session.close();
        System.out.println("--- session end ---");
    }
}
