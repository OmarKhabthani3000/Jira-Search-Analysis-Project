package com.whatever.ejb;

import javax.ejb.LocalBean;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;

import com.whatever.jpa.Status;

@Singleton
@LocalBean
public class StatusScheduler {

  @PersistenceContext
  private EntityManager em;
  
  
  @SuppressWarnings("unchecked")
  @Schedule(second="*/10", minute="*", hour="*", persistent=true)
  public void testHHH10262() {
    em.unwrap(Session.class)
    .createCriteria(Status.class)
    .list()
    .forEach(System.out::println);
  }
}
