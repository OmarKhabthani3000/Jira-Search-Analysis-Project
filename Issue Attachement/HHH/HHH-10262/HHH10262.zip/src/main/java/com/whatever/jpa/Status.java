package com.whatever.jpa;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="status")
public class Status implements Serializable {

  private static final long serialVersionUID = 1L;
  
  private Organ organ;
  private boolean active;
  
  public Status() {
    // JPA
  }
  
  public Status(Organ organ, boolean active) {
    this.organ = organ;
    this.active = active;
  }
  
  
  @Id
  @GeneratedValue(generator="assignedGen")
  @GenericGenerator(name="assignedGen", strategy="assigned")
  @Enumerated(EnumType.STRING)
  @Column(name="organ", length=30, nullable=false)
  public Organ getOrgan() {
    return organ;
  }
  
  @Basic
  @Column(name="active", nullable=false)
  public boolean isActive() {
    return active;
  }
  
  
  public void setOrgan(Organ organ) {
    this.organ = organ;
  }
  public void setActive(boolean active) {
    this.active = active;
  }
 
  @Override
  public String toString() {
    return organ.name() + ": " + active;
  }

  @Override
  public int hashCode() {
    return organ.hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    return Objects.equals(organ, ((Status)obj).organ);
  }
}
