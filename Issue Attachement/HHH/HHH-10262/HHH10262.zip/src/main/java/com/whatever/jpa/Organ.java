package com.whatever.jpa;

public enum Organ {
  BACKOFFICE,
  MUSIC,
  CATALOG,
  CONTENT,
  ORDERING,
  SHOP,
  TEAM;
}
