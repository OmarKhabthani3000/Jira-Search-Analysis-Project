To get Derby to work on a JDK >= v1.7.0_51, you may have to edit %JAVA_HOME%\jre\lib\security\java.policy and add a line:
	permission java.net.SocketPermission "localhost:1527", "listen";

create the database: connect once with:
jdbc:derby://localhost:1527/sun-appserv-samples;create=true

to use the database afterwards, use:
jdbc:derby://localhost:1527/sun-appserv-samples;create=false

