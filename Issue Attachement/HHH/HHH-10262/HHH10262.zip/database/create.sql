CREATE schema HHH10262;
create table status (organ varchar(30) not null, active boolean not null, primary key (organ));

