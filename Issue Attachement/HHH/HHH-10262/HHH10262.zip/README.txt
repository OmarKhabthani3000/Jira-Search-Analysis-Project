Replace jboss-logging in payara41/glassfish/modules/ by jboss-logging-3.3.0.Final.jar


BTW for some reason I hit something similar to HHH-9446 when trying to build a Hibernate 4.3.11 example of this issue.
Hance the example is provided using Hibernate 5.0.2