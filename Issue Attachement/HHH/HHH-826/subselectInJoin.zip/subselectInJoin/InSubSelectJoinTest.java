package org.hibernate.test.subselectInJoin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.TestCase;

/**
 * <p>
 * Test for IN subselect left join HQL -> SQL translation error.
 * </p>
 * <p>
 * Problem occurs on HQL translation involving an 'in (select ... from x left
 * join ), whereby a comma is inserted between the table and the inner join
 * expression in the sub select. E.g. the HQL: <br>
 * select w.id FROM Work w WHERE w.id in (Select w2.id from Work w2 left join
 * w2.workDocTypes wdt2 WHERE wdt2.docDescription = 'Test type') gets translated
 * to: <br>
 * select work0_.BIB_ID as col_0_0_ from WORK work0_ where work0_.BIB_ID in
 * (select work1_.BIB_ID from WORK work1_, left outer join WORK_DOC_TYPE
 * workdoctyp2_ on work1_.BIB_ID=workdoctyp2_.WORK_ID_FK left outer join
 * DOC_TYPE doctype3_ on workdoctyp2_.DOC_TYPE_ID_FK=doctype3_.ID where
 * doctype3_.DOC_DESCRIPTION='Test type')
 * </p>
 * <p>
 * With a comma inserted after the WORK work1_, in the sub select clause.
 * </p>
 *  
 */
public class InSubSelectJoinTest extends TestCase {

	public InSubSelectJoinTest(String str) {
		super(str);

	}

	protected String[] getMappings() {
		return new String[] { "subselectInJoin/DocType.hbm.xml",
				"subselectInJoin/Work.hbm.xml" };
	}

	public static Test suite() {
		return new TestSuite(InSubSelectJoinTest.class);
	}

	public void testSubSelectInInnerJoinHql() {
		Session s = openSession();
		Transaction t = s.beginTransaction();
		DocType docType = new DocType(Integer.valueOf(1), "Test type");
		Work work = new Work();
		work.setId(Integer.valueOf(1));
		work.getWorkDocTypes().add(docType);

		s.persist(work);
		s.persist(docType);
		t.commit();
		s.close();

		s = openSession();

		getSessions().getStatistics().clear();

		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		connection = s.connection();
		String sql = "SELECT count(w.bib_id) FROM WORK w";
		System.out.println("Native query to run: " + sql);
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			resultSet.next();
			int i = resultSet.getInt(1);
			System.out.println("No of records via native sql: " + i);
			assertEquals(i, 1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
			} catch (SQLException e1) {
			}
			resultSet = null;
			try {
				statement.close();
			} catch (SQLException e2) {
			}
			statement = null;
		}
		s.close();
		s = openSession();

		Query query = s.createQuery("SELECT count(w.id) FROM Work w");

		int recordCount = ((Integer) query.uniqueResult()).intValue();
		System.out.println("No of records via HQL: " + recordCount);
		assertEquals(recordCount, 1);

		s.close();

		/*
		 * Sample Queries that fail
		 *  
		 */
		System.out.println("*******************************************");
		System.out.println("Sample queryies that fail");

		sql = "select w.BIB_ID from WORK w where w.BIB_ID in (select w1.BIB_ID from WORK w1 left outer join WORK_DOC_TYPE wdt on w1.BIB_ID=wdt.WORK_ID_FK left outer join DOC_TYPE dt on wdt.DOC_TYPE_ID_FK=dt.ID where dt.DOC_DESCRIPTION  = 'Test type')";
		System.out.println("SQL to run: " + sql);

		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			recordCount = 0;
			while (resultSet.next()) {
				int i = resultSet.getInt(1);
				System.out.println("Answer via native sql: " + i);
				recordCount++;
			}

			assertEquals(recordCount, 1);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
			} catch (SQLException e1) {
			}
			resultSet = null;
			try {
				statement.close();
			} catch (SQLException e2) {
			}
			statement = null;
		}

		s = openSession();
		String queryString = "select w.id FROM  Work w  WHERE w.id in (Select w2.id from Work w2 left join w2.workDocTypes  wdt2  WHERE  wdt2.docDescription =  'Test type')";
		//String queryString = "select w.id FROM Work w WHERE w.id in (Select
		// w2.id from Work w2 join w2.workDocTypes wdt2 WHERE
		// wdt2.docDescription = 'Test type')";
		System.out.println("HQL is: " + queryString);
		try {
			Query query2 = s.createQuery(queryString);
			List list = query2.list();
			System.out.println("No of records via HQL: " + list.size());
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				Integer element = (Integer) iter.next();
				System.out.println("Work id is " + element);
			}
			assertEquals(recordCount, 1);
		} catch (HibernateException e1) {
			e1.printStackTrace();
		}

		s.delete(s.load(DocType.class, Integer.valueOf(1)));
		s.delete(s.load(Work.class, Integer.valueOf(1)));

		t.commit();
		s.close();
	}
}