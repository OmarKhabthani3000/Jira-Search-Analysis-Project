package org.hibernate.test.subselectInJoin;
import java.io.Serializable;

/** @author Hibernate CodeGenerator */
public class DocType implements Serializable {

	/** identifier field */
	private Integer id;

	/** persistent field */
	private String docDescription;

	/**
	 * <p>
	 * Constructor for use in the named query 'doctype.getDocTypeByName'
	 * </p>
	 * 
	 * @param id
	 * @param docDescription
	 */
	public DocType(Integer id, String docDescription) {
		this.id = id;
		this.docDescription = docDescription;
	}


	/** default constructor */
	public DocType() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDocDescription() {
		return this.docDescription;
	}

	public void setDocDescription(String docDescription) {
		this.docDescription = docDescription;
	}
	
	
}