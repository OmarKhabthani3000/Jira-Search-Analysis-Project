package org.hibernate.test.subselectInJoin;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/** @author Hibernate CodeGenerator */
public class Work implements Serializable {

	/** identifier field */
	private Integer id;

	/** persistent field */
	private Set workDocTypes = new HashSet();

	/**
	 * @param bibId
	 * @param workDocTypes
	 */
	public Work(Integer id, Set workDocTypes) {
		this.id = id;
		this.workDocTypes = workDocTypes;
	}

	/** default constructor */
	public Work() {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Set getWorkDocTypes() {
		return workDocTypes;
	}

	public void setWorkDocTypes(Set workDocTypes) {
		this.workDocTypes = workDocTypes;
	}
}