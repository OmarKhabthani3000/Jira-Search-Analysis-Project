package hhh5168;

import org.hibernate.dialect.DB2Dialect;

/**
 * 
 *
 * @author GOL <grzegorz.oledzki@syncron.com> (created on 2010-04-29)
 */
public class MyDB2Dialect extends DB2Dialect {

	@Override
	public String getCrossJoinSeparator() {
		return ", ";
	}

	
}
