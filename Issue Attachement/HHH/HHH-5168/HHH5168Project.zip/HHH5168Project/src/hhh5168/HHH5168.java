package hhh5168;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class HHH5168 {

	private EntityManagerFactory emf;
	private EntityManager em;
	private String PERSISTENCE_UNIT_NAME = "hhh5168";

	public static void main(String[] args) {
		HHH5168 hello = new HHH5168();
		hello.initEntityManager();
		hello.read();
		hello.closeEntityManager();
	}

	private void initEntityManager() {
		emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		em = emf.createEntityManager();
	}

	private void closeEntityManager() {
		em.close();
		emf.close();
	}


	private void read() {
		Book b = (Book) em.createQuery("select b from Book b where b.category.name='a'").getSingleResult();
		System.out.println("Query returned: " + b);
	}
}
