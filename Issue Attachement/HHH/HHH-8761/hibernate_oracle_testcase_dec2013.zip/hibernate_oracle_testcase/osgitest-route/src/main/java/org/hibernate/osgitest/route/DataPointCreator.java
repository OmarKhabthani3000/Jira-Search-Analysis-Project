package org.hibernate.osgitest.route;

import org.hibernate.osgitest.service.DataPoint;
import org.hibernate.osgitest.service.DataPointService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


@Component
public class DataPointCreator {

    private int counter;

    @Autowired
    private DataPointService dataPointService;

    public void create() {
        DataPoint dp = new DataPoint();
        dp.setName("p" + (++counter));
        dataPointService.add(dp);
    }


}
