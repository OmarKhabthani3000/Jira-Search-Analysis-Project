package com.test;

public class MyBean2 {
	private String name;
	private String surname;	
	private MyBean1 myBean1;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public MyBean1 getMyBean1() {
		return myBean1;
	}
	public void setMyBean1(MyBean1 myBean1) {
		this.myBean1 = myBean1;
	}
	
	
	
}
