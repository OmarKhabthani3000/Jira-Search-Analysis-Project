/*
 * TestArchiveServlet.java
 *
 * Created on 19 avril 2007, 17:13
 */

package tests.entities;

import com.homeservices.model.ArchivableFacade;
import com.homeservices.model.impl.BasicPerson;
import java.io.*;
import java.net.*;
import javax.ejb.EJB;

import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author Zied Hamdi
 * @version
 */
public class TestArchiveServlet extends HttpServlet {
	
	@EJB
	private ArchivableFacade archivableFacadeStatelessBean;
	
	/** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
	 * @param request servlet request
	 * @param response servlet response
	 */
	protected void processRequest (HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		response.setContentType ("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter ();
		out.println ("<html>");
		out.println ("<head>");
		out.println ("<title>Servlet TestArchiveServlet</title>");
		out.println ("</head>");
		out.println ("<body>");
		out.println ("<h1>Servlet TestArchiveServlet at " + request.getContextPath () + "</h1>");
		BasicPerson performer = new BasicPerson();
		performer.setFirstName ("zied");
		performer.setId (3L);
		System.out.println(" preparing object insertion...<br> ");
		archivableFacadeStatelessBean.create ( performer, performer );
		System.out.println(" ok");
//		out.println ( archivableFacadeStatelessBean.findEntries (null, BasicPerson.class ) );
		out.println ("</body>");
		out.println ("</html>");
		out.close ();
	}
	
	// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
	/** Handles the HTTP <code>GET</code> method.
	 * @param request servlet request
	 * @param response servlet response
	 */
	protected void doGet (HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		processRequest (request, response);
	}
	
	/** Handles the HTTP <code>POST</code> method.
	 * @param request servlet request
	 * @param response servlet response
	 */
	protected void doPost (HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		processRequest (request, response);
	}
	
	/** Returns a short description of the servlet.
	 */
	public String getServletInfo () {
		return "Short description";
	}
	// </editor-fold>
}
