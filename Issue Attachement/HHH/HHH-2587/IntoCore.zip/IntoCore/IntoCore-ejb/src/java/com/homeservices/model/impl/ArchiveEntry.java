package com.homeservices.model.impl;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@IdClass(ArchiveId.class)
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class ArchiveEntry
		implements Serializable {
	protected Date								startDate, endDate;
	protected String							note;
	protected BasicPerson					entryPerformer;
	protected ArchiveEntry				originalEntry;
	protected List<ArchiveEntry>	revisions;
	protected long								id;
	protected long								revision;
	/**
	 * true ifaoif this element is the last in all revisions (optimizes reading
	 * from db)
	 */
	protected boolean							lastOccurence;

	/**
	 * Gets the id of this Client.
	 * 
	 * @return the id
	 */
	@Id
	public long getId() {
		return this.id;
	}

	/**
	 * Sets the id of this Client to the specified value.
	 * 
	 * @param id
	 *          the new id
	 */
	public void setId(long id) {
		this.id = id;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public long getRevision() {
		return revision;
	}

	public void setRevision(long revision) {
		this.revision = revision;
	}

	/**
	 * Returns a hash code value for the object. This implementation computes a
	 * hash code value based on the id fields in this object.
	 * 
	 * @return a hash code value for this object.
	 */
	@Override
	public int hashCode() {
		int hash = 0;
		hash += this.id ^ revision;
		return hash;
	}

	/**
	 * Determines whether another object is equal to this WorkTask. The result is
	 * <code>true</code> if and only if the argument is not null and is a
	 * WorkTask object that has the same id field values as this object.
	 * 
	 * @param object
	 *          the reference object with which to compare
	 * @return <code>true</code> if this object is the same as the argument;
	 *         <code>false</code> otherwise.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean equals(Object object) {
		if( !(object instanceof ArchiveEntry) ) {
			return false;
		}
		ArchiveEntry other = (ArchiveEntry) object;
		if( this.id != other.id )
			return false;
		if( this.revision != other.revision )
			return false;
		return true;
	}

	@Temporal(TemporalType.TIMESTAMP)
	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	@Temporal(TemporalType.TIMESTAMP)
	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	@ManyToOne(cascade = CascadeType.PERSIST)
	public BasicPerson getEntryPerformer() {
		return entryPerformer;
	}

	public void setEntryPerformer(BasicPerson entryPerformer) {
		this.entryPerformer = entryPerformer;
	}

	@ManyToOne
	@JoinColumns( {
			@JoinColumn(name = "id", referencedColumnName = "id"), @JoinColumn(name = "revision", referencedColumnName = "revision")
	})
	public ArchiveEntry getOriginalEntry() {
		return originalEntry;
	}

	public void setOriginalEntry(ArchiveEntry originalEntry) {
		this.originalEntry = originalEntry;
	}

	@OneToMany(mappedBy = "originalEntry")
	public List<ArchiveEntry> getRevisions() {
		return revisions;
	}

	public void setRevisions(List<ArchiveEntry> revisions) {
		this.revisions = revisions;
	}

	public boolean isLastOccurence() {
		return lastOccurence;
	}

	public void setLastOccurence(boolean lastOccurence) {
		this.lastOccurence = lastOccurence;
	}

}