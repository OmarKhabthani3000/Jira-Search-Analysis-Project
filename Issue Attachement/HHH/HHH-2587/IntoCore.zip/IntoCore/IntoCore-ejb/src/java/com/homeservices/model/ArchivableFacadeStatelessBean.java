package com.homeservices.model;

import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.homeservices.model.impl.Archivable;
import com.homeservices.model.impl.ArchiveEntry;
import com.homeservices.model.impl.ArchiveId;
import com.homeservices.model.impl.BasicPerson;
import com.homeservices.model.impl.BasicPersonArchiveEntry;
//import com.homeservices.model.impl.WorkPlanningContract;

/**
 * 
 * @author Zied Hamdi
 */
@Stateless
public class ArchivableFacadeStatelessBean implements ArchivableFacade {

	@PersistenceContext
	private EntityManager	em;

	/** Creates a new instance of ArchivableStatelessBean */
	public ArchivableFacadeStatelessBean() {
	}

	/* (non-Javadoc)
	 * @see com.homeservices.model.ArchivableFacade#create(com.homeservices.model.impl.BasicPerson, com.homeservices.model.impl.Archivable)
	 */
	public void create(BasicPerson performer, Archivable<?> archivable) {
		try {
		ArchiveEntry archiveEntry = getEntry( archivable );
		archiveEntry.setId( getNextSequence( archivable.getClass() ) );
//em.persist( performer );
		archiveEntry.setEntryPerformer( performer );
em.persist( archiveEntry );
		} catch ( Exception ex ) {
			System.out.println("ex:"+ ex);
			ex.printStackTrace ();
		}
	}

	@SuppressWarnings("unchecked")
	protected long getNextSequence(Class<? extends Archivable> tableClass) {
		return 4;
	}

	/* (non-Javadoc)
	 * @see com.homeservices.model.ArchivableFacade#edit(com.homeservices.model.impl.BasicPerson, com.homeservices.model.impl.Archivable)
	 */
	public void edit(BasicPerson performer, Archivable<?> archivable) {
		ArchiveEntry archiveEntry = getEntry( archivable );
		if( !archiveEntry.isLastOccurence() )
			throw new IllegalStateException( "only the current state of an archivable can be updated." );

		ArchiveEntry oldEntry = em.find( archiveEntry.getClass(), new ArchiveId( archiveEntry ) );
		Date timeStamp = new Date();
		oldEntry.setEndDate( timeStamp );
		oldEntry.setLastOccurence( false );
		em.merge( oldEntry );

		archiveEntry.setRevision( 0 );
		archiveEntry.setStartDate( timeStamp );
		archiveEntry.setLastOccurence( true );
		archiveEntry.setEntryPerformer( performer );
		em.persist( archiveEntry );
	}

	// public void destroy(Archivable<?> archivable) {
	// em.merge( archivable );
	// em.remove( archivable );
	// }
	//
	// public Archivable<?> find(ArchiveId pk) {
	// return (Archivable<?>) em.find( Archivable.class, pk );
	// }

	/* (non-Javadoc)
	 * @see com.homeservices.model.ArchivableFacade#findEntries(com.homeservices.model.impl.BasicPerson, java.lang.Class)
	 */
	@SuppressWarnings("unchecked")
	public List<ArchiveEntry> findEntries(BasicPerson performer, Class<?> entity) {
		return em.createQuery( "select e from BasicPersonArchiveEntry e LEFT JOIN FETCH e.archive where e.lastOccurence = true" ).getResultList();
	}

	protected static ArchiveEntry getEntry(Archivable archivable) {
		if( archivable instanceof BasicPerson ) {
			BasicPerson person = (BasicPerson) archivable;
			BasicPersonArchiveEntry entry = person.getArchiveEntry();
			if( entry == null ) {
				entry = new BasicPersonArchiveEntry();
				entry.setArchive( person );
				entry.setSource( person );
			}
			return entry;
//		} else if( archivable instanceof WorkPlanningContract ) {

		}
		throw new UnsupportedOperationException( archivable.getClass() + " not supported yet." );
	}

	protected static Archivable<?> getArchivable(ArchiveEntry archiveEntry) {
		if( archiveEntry instanceof BasicPersonArchiveEntry ) {
			return ((BasicPersonArchiveEntry) archiveEntry).getArchive();
		}
		throw new UnsupportedOperationException( archiveEntry.getClass() + " not supported yet." );
	}

}
