package com.homeservices.model;

import java.util.List;

import javax.ejb.Local;

import com.homeservices.model.impl.Archivable;
import com.homeservices.model.impl.ArchiveEntry;
import com.homeservices.model.impl.BasicPerson;

@Local
public interface ArchivableFacade {

	void create(BasicPerson performer, Archivable<?> archivable);

	void edit(BasicPerson performer, Archivable<?> archivable);

	List<ArchiveEntry> findEntries(BasicPerson performer, Class<?> entity);

}