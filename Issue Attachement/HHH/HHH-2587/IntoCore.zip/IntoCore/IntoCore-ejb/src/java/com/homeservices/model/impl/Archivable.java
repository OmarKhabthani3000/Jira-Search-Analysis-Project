package com.homeservices.model.impl;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
@IdClass(ArchiveId.class)
public abstract class Archivable<T extends ArchiveEntry> implements Serializable{
//	protected List						/* <ArchiveEntry<T>> */archiveEntries;
	protected Long								id;
	protected long								revision;

	/**
	 * Gets the id of this Client.
	 * 
	 * @return the id
	 */
	@Id
	@Column(name="revision", insertable=false, updatable=false, nullable=false)
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id of this Client to the specified value.
	 * 
	 * @param id
	 *          the new id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	@Id
	@Column(name="revision", insertable=false, updatable=false, nullable=false)
	public long getRevision() {
		return revision;
	}

	public void setRevision(long revision) {
		this.revision = revision;
	}

	/**
	 * Returns a hash code value for the object. This implementation computes a
	 * hash code value based on the id fields in this object.
	 * 
	 * @return a hash code value for this object.
	 */
	@Override
	public int hashCode() {
		int hash = 0;
		hash += (this.id != null ? this.id.hashCode() : 0) ^ revision;
		return hash;
	}

	/**
	 * Determines whether another object is equal to this WorkTask. The result is
	 * <code>true</code> if and only if the argument is not null and is a
	 * WorkTask object that has the same id field values as this object.
	 * 
	 * @param object
	 *          the reference object with which to compare
	 * @return <code>true</code> if this object is the same as the argument;
	 *         <code>false</code> otherwise.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean equals(Object object) {
		if( !(object instanceof Archivable) ) {
			return false;
		}
		Archivable other = (Archivable) object;
		if( this.id != other.id && (this.id == null || !this.id.equals( other.id )) )
			return false;
		if( this.revision != other.revision )
			return false;
		return true;
	}


//	public abstract T getArchiveEntry();

//	public abstract <R extends ArchiveEntry<T>> void setArchiveEntry(R archiveEntry);

//	public List/* <ArchiveEntry<T>> */getArchiveEntries() {
//		return archiveEntries;
//	}
//
//	public void setArchiveEntries(List<T> archiveEntries) {
//		this.archiveEntries = archiveEntries;
//	}
}