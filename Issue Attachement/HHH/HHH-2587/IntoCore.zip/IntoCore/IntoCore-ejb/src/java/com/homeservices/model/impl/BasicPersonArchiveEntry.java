package com.homeservices.model.impl;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.PrimaryKeyJoinColumns;

@Entity
public class BasicPersonArchiveEntry extends ArchiveEntry {
	protected BasicPerson	source, archive;

	@OneToOne(mappedBy="archiveEntry", cascade = CascadeType.PERSIST)
	@PrimaryKeyJoinColumns( {
			@PrimaryKeyJoinColumn(name = "id"), @PrimaryKeyJoinColumn(name = "revision")
	})
	public BasicPerson getArchive() {
		return archive;
	}

	@ManyToOne(cascade = CascadeType.REFRESH)
	public BasicPerson getSource() {
		return source;
	}

	public void setSource(BasicPerson source) {
		this.source = source;
	}

	public void setArchive(BasicPerson archive) {
		this.archive = archive;
	}

}