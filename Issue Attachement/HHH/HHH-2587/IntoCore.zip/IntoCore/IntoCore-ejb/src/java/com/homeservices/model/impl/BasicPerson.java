package com.homeservices.model.impl;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class BasicPerson extends Archivable<BasicPersonArchiveEntry> {
	protected String									firstName, lastName, note;
	protected Date										entryDate, exitDate;
//	protected List<String>						mails;
//	protected List<Sponsoring>				sponsoringChildren;
//	protected List<Adress>						adresses;
//	protected List<PhoneNumber>				phones;
	protected BasicPersonArchiveEntry	archiveEntry;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	@Temporal(TemporalType.TIMESTAMP)
	public Date getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}

	@Temporal(TemporalType.TIMESTAMP)
	public Date getExitDate() {
		return exitDate;
	}

	public void setExitDate(Date exitDate) {
		this.exitDate = exitDate;
	}

//	public List<String> getMails() {
//		return mails;
//	}
//
//	public void setMails(List<String> mails) {
//		this.mails = mails;
//	}
//
//	@OneToMany(mappedBy = "sponsor")
//	public List<Sponsoring> getSponsoringChildren() {
//		return sponsoringChildren;
//	}
//
//	public void setSponsoringChildren(List<Sponsoring> sponsoringChildren) {
//		this.sponsoringChildren = sponsoringChildren;
//	}
//
//	@OneToMany
//	public List<Adress> getAdresses() {
//		return adresses;
//	}
//
//	public void setAdresses(List<Adress> adresses) {
//		this.adresses = adresses;
//	}
//
//	@OneToMany
//	public List<PhoneNumber> getPhones() {
//		return phones;
//	}
//
//	public void setPhones(List<PhoneNumber> phones) {
//		this.phones = phones;
//	}
//
//	@Override
//	@OneToMany(targetEntity = BasicPersonArchiveEntry.class, mappedBy = "source")
//	public List/* <BasicPersonArchiveEntry> */getArchiveEntries() {
//		return super.getArchiveEntries();
//	}

	@OneToOne
	public BasicPersonArchiveEntry getArchiveEntry() {
		return archiveEntry;
	}

	public void setArchiveEntry(BasicPersonArchiveEntry archiveEntry) {
		this.archiveEntry = archiveEntry;
	}

}