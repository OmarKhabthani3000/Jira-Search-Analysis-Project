/*
 * Copyright ifb AG 2004-2005
 * Created by: Barthel Steckemetz, BST
 * 
 */
package com.ifbag.okular.base.hibernate.tst;

/**
 **/
public class HibSubSub extends HibSub {
	private String subSubString;
	
	public HibSubSub() {
		setKnz("3");
	}
	
	public void setSubSubString(String aSubSubString) {
		this.subSubString = aSubSubString;
	}
	public String getSubSubString() {
		return subSubString;
	}
}
