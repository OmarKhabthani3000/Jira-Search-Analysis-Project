/*
 * Copyright ifb AG 2004-2005
 * Created by: Barthel Steckemetz, BST
 * 
 */
package com.ifbag.okular.base.hibernate.tst;

/**
 **/
public class HibSub
	extends HibBase {
	private String subString;
	
	public HibSub() {
		setKnz("2");
	}
	
	public String getSubString() {
		return subString;
	}
	public void setSubString(String aSubString) {
		this.subString = aSubString;
	}

}
