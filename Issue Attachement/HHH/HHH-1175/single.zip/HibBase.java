/*
 * Copyright ifb AG 2004-2005
 * Created by: Barthel Steckemetz, BST
 * 
 */
package com.ifbag.okular.base.hibernate.tst;

/**
 **/
public class HibBase {
	private int id;
	private String knz;
	private String baseString;
	
	public HibBase() {
		setKnz("1");
	}
	
	public String getBaseString() {
		return baseString;
	}
	public void setBaseString(String aBaseString) {
		this.baseString = aBaseString;
	}
	public int getId() {
		return id;
	}
	public void setId(int aId) {
		this.id = aId;
	}
	public String getKnz() {
		return knz;
	}
	public void setKnz(String aKnz) {
		this.knz = aKnz;
	}
}
