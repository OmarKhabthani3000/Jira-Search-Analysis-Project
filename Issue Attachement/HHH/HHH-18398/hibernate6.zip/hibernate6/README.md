### Relevant Articles
- [Monitoring Hibernate Events With Java Flight Recorder](https://www.baeldung.com/java-flight-recorder-hibernate-events)
