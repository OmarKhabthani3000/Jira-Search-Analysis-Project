package com.baeldung.hibernatejfr.service;

import com.baeldung.hibernatejfr.HibernateJfrApplication;
import com.baeldung.hibernatejfr.entity.DocumentDomain;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(classes = HibernateJfrApplication.class)
@TestMethodOrder(MethodOrderer.MethodName.class)
class DocumentServiceUnitTest {

    @Autowired
    DocumentService documentService;

    Logger logger = LoggerFactory.getLogger(DocumentServiceUnitTest.class);


    @Test
    void whenIdExists_thenFindPersonById() {
        List<DocumentDomain> entity = documentService.findAllDocuments();
    }

}
