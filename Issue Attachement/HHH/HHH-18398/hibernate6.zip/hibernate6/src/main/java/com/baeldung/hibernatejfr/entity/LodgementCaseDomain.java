package com.baeldung.hibernatejfr.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import org.hibernate.annotations.AttributeAccessor;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.id.enhanced.SequenceStyleGenerator;
import org.hibernate.proxy.HibernateProxy;

import java.io.Serializable;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Entity class for lodgement.
 * <p>
 * <p>
 * Source Table = pxa_lodgements.
 */
@Entity(name = "Lodgement")
@Table(name = "pxa_lodgements")
public class LodgementCaseDomain
        implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name="lodgement_id")
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "LODGEMENT_SEQ")
    @SequenceGenerator(name = "LODGEMENT_SEQ", sequenceName = "LODGEMENT_SEQ", allocationSize = 100)
    private Long id;

    /**
     * Variable to hold version.
     */
    @Column(name = "version", nullable = false)
    @Version
    private Long version;

    /**
     * Variable to hold lodgementReceived.
     */
    @Column(name = "date1")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lodgementReceived;

    /**
     * Variable to when lodgement verification request was sent.
     */
    @Column(name = "verification_request_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date verificationRequestTime;

    @OneToMany(targetEntity = DocumentDomain.class, mappedBy = "lodgementCase", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<DocumentDomain> documents;

    /**
     * default constructor.
     */
    public LodgementCaseDomain() {

    }


    public Long getId() {

        return id;
    }

    public void setId(final Long i) {

        id = i;

    }

    public Long getVersion() {

        return version;
    }

    public void setVersion(final Long v) {

        version = v;

    }

    public Date getLodgementReceived() {

        return lodgementReceived;
    }

    public void setLodgementReceived(final Date lodgementReceived) {

        this.lodgementReceived = lodgementReceived;

    }


    public Date getVerificationRequestTime() {

        return verificationRequestTime;
    }

    public void setVerificationRequestTime(final Date verificationRequestTime) {

        this.verificationRequestTime = verificationRequestTime;
    }

    public List<DocumentDomain> getDocuments() {

        return documents;
    }

    public void setDocuments(List<DocumentDomain> documents) {

        this.documents = documents;
    }

}