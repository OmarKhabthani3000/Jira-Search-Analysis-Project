package com.baeldung.hibernatejfr.dao;

import com.baeldung.hibernatejfr.entity.DocumentDomain;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DocumentDao extends JpaRepository<DocumentDomain,Long> {

    @Query("SELECT d from Document d ")
    List<DocumentDomain> getAllDocuments();

   /* @Query("SELECT d from Document d join d.lodgementCase l where l.id = :lodgementCaseId  ")
    List<DocumentDomain> getAllDocumentsByLodgementId(@Param("lodgementCaseId") long lodgementCaseId);
*/
    @Query("SELECT d from Lodgement l join l.documents d where l.id = :lodgementCaseId  ")
    List<DocumentDomain> getAllDocumentsByLodgementId_2(@Param("lodgementCaseId") long lodgementCaseId);

    @Query("select d from Lodgement l join l.documents d")
    List<DocumentDomain> getAllDocumentsByLodgementId_3();
}
