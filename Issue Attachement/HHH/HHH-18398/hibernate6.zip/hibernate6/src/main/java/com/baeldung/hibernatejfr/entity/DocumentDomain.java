package com.baeldung.hibernatejfr.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import org.hibernate.Hibernate;
import org.hibernate.annotations.AttributeAccessor;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.id.enhanced.SequenceStyleGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

@Entity(name = "Document")
@Table(name = "pxa_documents")
public class DocumentDomain
        implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name="document_id")
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOCUMENT_SEQ")
    @SequenceGenerator(name = "DOCUMENT_SEQ", sequenceName = "DOCUMENT_SEQ", allocationSize = 100)
    private Long id;


    @ManyToOne(targetEntity = LodgementCaseDomain.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "lodgement_id")
    private LodgementCaseDomain lodgementCase;


    @Column(name = "dealing_number", nullable = true)
    private String dealingNo;


    public Long getId() {

        return id;
    }

    public void setId(final Long id) {

        this.id = id;

    }

    public LodgementCaseDomain getLodgementCase() {
        return lodgementCase;
    }

    public void setLodgementCase(final LodgementCaseDomain lodgementCase) {

        this.lodgementCase = lodgementCase;
    }

    public String getDealingNo() {

        return dealingNo;
    }

    public void setDealingNo(final String dealingNo) {

        this.dealingNo = dealingNo;

    }
}


