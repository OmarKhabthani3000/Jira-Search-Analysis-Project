package com.baeldung.hibernatejfr.service;

import com.baeldung.hibernatejfr.dao.DocumentDao;
import com.baeldung.hibernatejfr.entity.DocumentDomain;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class DocumentService {

    @Autowired
    private DocumentDao documentDao;

    @Transactional(propagation = Propagation.REQUIRED)
    public List<DocumentDomain> findAllDocuments(){
        documentDao.getAllDocumentsByLodgementId_3();
        return null;
    }
}
