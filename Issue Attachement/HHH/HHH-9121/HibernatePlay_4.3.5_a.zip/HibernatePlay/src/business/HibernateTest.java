package business;

import java.util.Collections;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import things.Club;
import things.Member;

public class HibernateTest
{
	public static void main(String[] args)
	{
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Club club = new Club(1L, "My Club");
		club.getMembers().add(new Member(1L, "Mr Man", Collections.singletonList("Red")));
		session.save(club);
		
		session.flush();
		session.getTransaction().commit();
		
		Query q = session.createQuery("FROM things.Club c WHERE EXISTS (SELECT 1 FROM c.members m WHERE EXISTS (SELECT 1 FROM m.favoriteColors fc WHERE fc='Red'))");
		List<?> result = q.list();
		System.out.println(result);
		for (int i=0; i<result.size(); i++)
		{
			Club c = (Club) result.get(i);
			System.out.println("Result " + i + ": " + c);
		}
		
		session.close();
	}
}
