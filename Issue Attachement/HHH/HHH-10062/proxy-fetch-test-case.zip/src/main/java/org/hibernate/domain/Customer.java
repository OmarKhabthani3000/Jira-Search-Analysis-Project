package org.hibernate.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity  
@Table(name = "customers")
public class Customer implements Serializable {
 
	private static final long serialVersionUID = 1587234973329775201L;

	@Id
	@GeneratedValue
	@Column(name = "CUSTOMER_ID", nullable = false, updatable = false)
	private Long id;
	
	@Column(name = "CUSTOMER_NAME", length = 80, nullable = false)
	private String name;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        return new HashCodeBuilder()
        	.append(id)
        	.toHashCode();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Customer)) return false;
        Customer other = (Customer) object;
        return new EqualsBuilder()
        	.append(id, other.id)
        	.isEquals();
    }
}
