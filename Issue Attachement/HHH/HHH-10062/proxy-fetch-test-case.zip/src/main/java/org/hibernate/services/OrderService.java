package org.hibernate.services;

import java.util.List;

import org.hibernate.domain.OrderLine;

public interface OrderService {

	List<OrderLine> findOrderLines(boolean useScrollables);
		
}
