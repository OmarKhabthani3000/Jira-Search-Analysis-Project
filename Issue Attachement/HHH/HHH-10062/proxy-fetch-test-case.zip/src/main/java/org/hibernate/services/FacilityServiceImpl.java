package org.hibernate.services;

import java.util.List;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.domain.Facility;
import org.springframework.transaction.annotation.Transactional;

@Named
class FacilityServiceImpl implements FacilityService {

	@PersistenceContext
	private EntityManager entityManager;
	
	/* (non-Javadoc)
	 * @see org.hibernate.services.FacilityService#getAll()
	 */
	@Override
	@Transactional(readOnly = true)
	public List<Facility> getAll() {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Facility> query = cb.createQuery(Facility.class);
		Root<Facility> root = query.from(Facility.class);
		
		query.select(root);
		return entityManager.createQuery(query.select(root)).getResultList();
	}
	
}
