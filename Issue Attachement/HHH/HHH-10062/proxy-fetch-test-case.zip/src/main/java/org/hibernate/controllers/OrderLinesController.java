package org.hibernate.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.hibernate.domain.OrderLine;
import org.hibernate.services.OrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderLinesController {
	
	private static final Logger LOG = LoggerFactory.getLogger(OrderLinesController.class);

	private OrderService orderService;
	
	@Inject
	public OrderLinesController(final OrderService orderService) {
		this.orderService = orderService;
	}
	
	@RequestMapping("/bad")
	public Map<String, Object> bad() {
		LOG.info("----------");
		Map<String, Object> results = new HashMap<>();		
		LOG.info("Populating site value based on plant identifiers.");
		results.put("sitesA", getValuesFromOrderLines(orderService.findOrderLines(true)));		
		return results;
	}
	
	@RequestMapping("/good")
	public Map<String, Object> good() {
		LOG.info("----------");
		Map<String, Object> results = new HashMap<>();		
		LOG.info("Populating site value based on full internal fetches");
		results.put("sitesB", getValuesFromOrderLines(orderService.findOrderLines(false)));
		return results;
	}
	
	/**
	 * @param lines
	 * @return
	 */
	protected List<String> getValuesFromOrderLines(List<OrderLine> lines) {
		List<String> values = new ArrayList<>();
		for(OrderLine line : lines) {
			try {
				values.add(line.getProduct().getFacility().getSite().getName());
			}
			catch(Exception ex) {
				LOG.warn("Exception when fetching value", ex);
				values.add(ex.getMessage());
			}
		}
		return values;
	}
	
}
