package org.hibernate.services;

import java.util.List;

import org.hibernate.domain.Facility;

public interface FacilityService {
	/**
	 * @return
	 */
	List<Facility> getAll();
}
