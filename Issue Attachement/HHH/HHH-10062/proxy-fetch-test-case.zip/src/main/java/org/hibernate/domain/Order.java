package org.hibernate.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name = "order_headers")
public class Order implements Serializable {

	private static final long serialVersionUID = -6996532046756807990L;

	@Id
	@GeneratedValue
	@Column(name = "ORDER_ID", nullable = false, updatable = false)
	private Long id;
	
	@Column(name = "ORDER_NUMBER", unique = true, nullable = false, updatable = false)
	private String number;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PURCHASE_ORG_ID", referencedColumnName = "PURCHASE_ORG_ID", nullable = false, updatable = false)
	private PurchaseOrg purchaseOrg;
	
	@OneToMany(mappedBy = "header", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<OrderLine> lines;
	
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number the number to set
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return the purchaseOrg
	 */
	public PurchaseOrg getPurchaseOrg() {
		return purchaseOrg;
	}

	/**
	 * @param purchaseOrg the purchaseOrg to set
	 */
	public void setPurchaseOrg(PurchaseOrg purchaseOrg) {
		this.purchaseOrg = purchaseOrg;
	}

	/**
	 * @return the lines
	 */
	public List<OrderLine> getLines() {
		return lines;
	}

	/**
	 * @param lines the lines to set
	 */
	public void setLines(List<OrderLine> lines) {
		this.lines = lines;
	}

	/**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        return new HashCodeBuilder()
        	.append(id)
        	.toHashCode();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Order)) return false;
        Order other = (Order) object;
        return new EqualsBuilder()
        	.append(id, other.id)
        	.isEquals();
    }
    
}
