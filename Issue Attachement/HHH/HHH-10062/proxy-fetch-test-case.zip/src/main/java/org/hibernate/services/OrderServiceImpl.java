package org.hibernate.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import org.hibernate.Query;
import org.hibernate.ScrollableResults;
import org.hibernate.domain.Facility_;
import org.hibernate.domain.Order;
import org.hibernate.domain.OrderLine;
import org.hibernate.domain.OrderLine_;
import org.hibernate.domain.Order_;
import org.hibernate.domain.Product;
import org.hibernate.domain.Product_;
import org.hibernate.domain.PurchaseOrg;
import org.springframework.transaction.annotation.Transactional;

@Named
class OrderServiceImpl implements OrderService {

	@PersistenceContext
	private EntityManager entityManager;
	private PurchaseOrgService purchaseOrgService;
	private DataService dataService;
	
	@Inject
	public OrderServiceImpl(PurchaseOrgService purchaseOrgService, DataService dataService) {
		this.purchaseOrgService = purchaseOrgService;
		this.dataService = dataService;
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<OrderLine> findOrderLines(boolean useScrollables) {		
		Set<PurchaseOrg> purchaseOrgs = new HashSet<>();
		purchaseOrgs.addAll(purchaseOrgService.getByFacilityId(dataService.getFacilityId()));
		return findOrderLinesByPurchaseOrgs(purchaseOrgs, useScrollables);	
	}
	
	/**
	 * @param purchaseOrgs
	 * @return
	 */
	protected List<OrderLine> findOrderLinesByPurchaseOrgs(Collection<PurchaseOrg> purchaseOrgs, boolean useScrollableImpl) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<OrderLine> query = cb.createQuery(OrderLine.class);
		Root<OrderLine> root = query.from(OrderLine.class);
		
		Join<OrderLine, Product> productJoin = (Join<OrderLine, Product>) root.fetch(OrderLine_.product);
		productJoin.fetch(Product_.facility).fetch(Facility_.site);
		
		Join<OrderLine, Order> headerJoin = (Join<OrderLine, Order>)root.fetch(OrderLine_.header);
		headerJoin.fetch(Order_.purchaseOrg);
		
		query.select(root).where(headerJoin.get(Order_.purchaseOrg).in(purchaseOrgs));
		if(!useScrollableImpl) {
			return entityManager.createQuery(query).getResultList();
		}
		else {
			TypedQuery<OrderLine> typedQuery = entityManager.createQuery(query);
			
			Query hibernateQuery = typedQuery.unwrap(Query.class);
			hibernateQuery.setReadOnly(true);
			hibernateQuery.setCacheable(false);
			
			List<OrderLine> lines = new ArrayList<>();
			
			ScrollableResults results = hibernateQuery.scroll();
			while(results.next()) {
				OrderLine line = OrderLine.class.cast(results.get(0));
				lines.add(line);
			}
			
			return lines;
		}
	}
	
}
