package org.hibernate.services;

import java.util.List;

import org.hibernate.domain.PurchaseOrg;

public interface PurchaseOrgService {
	
	/**
	 * @param id
	 * @return
	 */
	List<PurchaseOrg> getByFacilityId(Long id);
	
	/**
	 * @return
	 */
	List<PurchaseOrg> getAll();
	
	/**
	 * @return
	 */
	List<PurchaseOrg> getAllWithAssociations();
}
