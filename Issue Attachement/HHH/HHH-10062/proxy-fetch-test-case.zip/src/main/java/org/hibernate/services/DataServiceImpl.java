package org.hibernate.services;

import java.util.Arrays;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.domain.Customer;
import org.hibernate.domain.Facility;
import org.hibernate.domain.Order;
import org.hibernate.domain.OrderLine;
import org.hibernate.domain.Product;
import org.hibernate.domain.PurchaseOrg;
import org.hibernate.domain.Site;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

@Named
class DataServiceImpl implements DataService, ApplicationListener<ContextRefreshedEvent> {

	private static Logger LOG = LoggerFactory.getLogger(DataServiceImpl.class);
	
	@PersistenceContext
	private EntityManager entityManager;
	
	private Long facilityId;
	
	@Override
	public Long getFacilityId() {
		return facilityId;
	}
	
	@Override
	@Transactional
	public void onApplicationEvent(ContextRefreshedEvent arg0) {
		LOG.info("---- Populating the Database ----");
		
		Customer customer = new Customer();
		customer.setName("ACME INC.");
		entityManager.persist(customer);
				
		Site site = new Site();
		site.setName("NEW YORK");
		site.setCustomer(customer);
		entityManager.persist(site);
				
		Facility facility = new Facility();
		facility.setName("GRAND PLAZA HOTEL");
		facility.setCustomer(customer);
		facility.setSite(site);
		entityManager.persist(facility);
		facilityId = facility.getId();
		
		PurchaseOrg purchaseOrg = new PurchaseOrg();
		purchaseOrg.setCustomer(customer);
		purchaseOrg.setFacility(Arrays.asList(facility));
		purchaseOrg.setName("CENTRAL PURCHASING");
		entityManager.persist(purchaseOrg);
		
		Product product = new Product();
		product.setFacility(facility);
		product.setNumber("A739-A9381-99");
		product.setDescription("COPY PAPER");
		entityManager.persist(product);
		
		Order order = new Order();
		order.setNumber("123");
		order.setPurchaseOrg(purchaseOrg);
		
		OrderLine line = new OrderLine();
		line.setHeader(order);
		line.setProduct(product);
		
		order.setLines(Arrays.asList(line));
		entityManager.persist(order);
	}

	
}
