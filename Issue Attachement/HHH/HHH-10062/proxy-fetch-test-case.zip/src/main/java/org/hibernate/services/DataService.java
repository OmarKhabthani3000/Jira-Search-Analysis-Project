package org.hibernate.services;

public interface DataService {
	/**
	 * @return
	 */
	Long getFacilityId();
}
