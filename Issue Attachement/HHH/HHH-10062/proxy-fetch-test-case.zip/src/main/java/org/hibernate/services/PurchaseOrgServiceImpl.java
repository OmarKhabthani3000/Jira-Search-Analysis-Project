package org.hibernate.services;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Fetch;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;

import org.hibernate.domain.Facility;
import org.hibernate.domain.Facility_;
import org.hibernate.domain.PurchaseOrg;
import org.hibernate.domain.PurchaseOrg_;
import org.springframework.transaction.annotation.Transactional;

@Named
class PurchaseOrgServiceImpl implements PurchaseOrgService {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional(readOnly = true)
	public List<PurchaseOrg> getByFacilityId(Long id) {
		List<PurchaseOrg> purchaseOrgs = new ArrayList<>();
		for(PurchaseOrg purchaseOrg : getAll()) {
			for(Facility facility : purchaseOrg.getFacility()) {
				if(facility.getId().equals(id)) {
					purchaseOrgs.add(purchaseOrg);
					break;
				}
			}
		}
		return purchaseOrgs;
	}

	@Override
	@Transactional(readOnly = true)
	public List<PurchaseOrg> getAll() {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<PurchaseOrg> query = cb.createQuery(PurchaseOrg.class);
		Root<PurchaseOrg> root = query.from(PurchaseOrg.class);		
		return entityManager.createQuery(query.select(root)).getResultList();
	}

	@Override
	@Transactional(readOnly = true)
	public List<PurchaseOrg> getAllWithAssociations() {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<PurchaseOrg> query = cb.createQuery(PurchaseOrg.class);
		Root<PurchaseOrg> root = query.from(PurchaseOrg.class);
		
		root.fetch(PurchaseOrg_.customer);
		
		Fetch<PurchaseOrg, Facility> facilityFetch = root.fetch(PurchaseOrg_.facility, JoinType.LEFT);
		facilityFetch.fetch(Facility_.site, JoinType.LEFT);
		facilityFetch.fetch(Facility_.customer, JoinType.LEFT);
		
		return entityManager.createQuery(query.select(root)).getResultList();
	}

}
