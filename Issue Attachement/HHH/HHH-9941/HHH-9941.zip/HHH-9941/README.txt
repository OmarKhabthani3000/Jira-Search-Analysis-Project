HHH-9941
========

Simple test case.

It should be sufficient to run 'mvn test' and see that the last query logged is something like : 

Hibernate: select eventpayer0_.payer_id as payer_id3_0_0_, eventpayer0_.event_id \
as event_id1_0_0_, eventpayer0_.event_id as event_id1_0_1_, eventpayer0_1_.payer_id \
as payer_id2_1_1_ from event eventpayer0_ inner join event_payer eventpayer \                         
0_1_ on eventpayer0_.event_id=eventpayer0_1_.event_id where eventpayer0_.payer_id=?

Which corresponds to the problem reported originaly here : https://hibernate.atlassian.net/browse/HHH-1015
