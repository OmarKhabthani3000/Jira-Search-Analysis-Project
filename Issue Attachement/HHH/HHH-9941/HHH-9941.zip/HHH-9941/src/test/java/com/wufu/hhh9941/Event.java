package com.wufu.hhh9941;

public class Event {

	private Long id;

	public Long getId() {
		return id;
	}

	private void setId(Long id) {
		this.id = id;
	}

}