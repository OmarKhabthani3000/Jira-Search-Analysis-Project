package com.wufu.hhh9941;

import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import junit.framework.TestCase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HHH9941Test extends TestCase {

	private SessionFactory sessionFactory;

	Logger log = LoggerFactory.getLogger(getClass());

	@Override
	protected void setUp() throws Exception {

		final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.configure()
				.build();
		try {
			sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
		}
		catch (Exception e) {
			StandardServiceRegistryBuilder.destroy( registry );
		}
	}

	@Override
	protected void tearDown() throws Exception {
		if ( sessionFactory != null ) {
			sessionFactory.close();
		}
	}

	@SuppressWarnings("unchecked")
	public void testHHH9941() {

		Session session = sessionFactory.openSession();
		session.beginTransaction();

		Payer payer1 = new Payer();
		EventPayer eventPayer = new EventPayer();
		eventPayer.setPayer(payer1);

		session.save(payer1);
		session.save(eventPayer);
		session.getTransaction().commit();
		session.close();

		// now lets pull events from the database and list them
		session = sessionFactory.openSession();
        session.beginTransaction();
        List result = session.createQuery("from Payer").list();
		for ( Payer payer : (List<Payer>) result ) {
			Set<EventPayer> eps = payer.getEventPayers();
			/* ~~Generates the following SQL ~~~

			select 	eventpayer0_.payer_id as payer_id3_0_0_,
       				eventpayer0_.event_id as event_id1_0_0_,
       				eventpayer0_.event_id as event_id1_0_1_,
       				eventpayer0_1_.payer_id as payer_id2_1_1_
			from event eventpayer0_
			inner join event_payer eventpayer0_1_
			on eventpayer0_.event_id=eventpayer0_1_.event_id
			where eventpayer0_.payer_id=?

			 */
			for(EventPayer ep : eps){
				log.info(""+ep.getId());
			}
		}
        session.getTransaction().commit();
        session.close();
	}
}
