package com.wufu.hhh9941;

public class EventPayer extends Event {

	private Payer payer;

	public Payer getPayer() {
		return payer;
	}

	public void setPayer(Payer payer) {
		this.payer = payer;
	}
}
