/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToMany;
import javax.persistence.MappedSuperclass;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import com.sun.istack.internal.NotNull;

import static org.junit.Assert.assertEquals;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 *
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
            LocalDateEvent.class,
				UserEvents.class,
				ApplicationEvents.class
		};
	}

	// If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
	@Override
	protected String[] getMappings() {
		return new String[] {
//				"Foo.hbm.xml",
//				"Bar.hbm.xml"
		};
	}
	// If those mappings reside somewhere other than resources/org/hibernate/test, change this.
	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/test/";
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );

//		configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, "true" );
	}

	// Add your tests, using standard JUnit.
	@Test
	public void HHH10371Test() throws Exception {
		// BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
		Session session = openSession();
        Transaction transaction = session.beginTransaction();

        LocalDateEvent event1 = new LocalDateEvent();
		event1.startDate = LocalDate.of(1, 1, 1);
        session.persist(event1);

		LocalDateEvent event2 = new LocalDateEvent();
		event2.startDate = LocalDate.of(1, 1, 2);
		session.persist(event2);

		LocalDateEvent event3 = new LocalDateEvent();
		event3.startDate = LocalDate.of(1, 1, 3);
		session.persist(event3);

		UserEvents userEvents = new UserEvents();
		session.persist( userEvents );
		userEvents.getEvents().add( event1 );
		session.flush();
		userEvents.getEvents().add( event2 );
		session.flush();


		ApplicationEvents applicationEvents = new ApplicationEvents();
		session.persist( applicationEvents );
		applicationEvents.getEvents().add( event3 );

        transaction.commit();
        session.close();

        session = openSession();
		transaction = session.beginTransaction();

		assertEquals(2, session.get( UserEvents.class, userEvents.id ).getEvents().size());
		assertEquals(1, session.get( ApplicationEvents.class, applicationEvents.id ).getEvents().size());

		transaction.commit();
        session.close();
	}

	@Entity(name = "LocalDateEvent")
	public static class LocalDateEvent {

		@Id
		@GeneratedValue
		private Long id;

		@NotNull
		@Column(name = "START_DATE", nullable = false)
		private LocalDate startDate;
	}

	@MappedSuperclass
	public static abstract class AbstractEventsEntityModel {

		@ManyToMany(fetch = FetchType.LAZY )
		private List<LocalDateEvent> events = new ArrayList<>(  );

		public List<LocalDateEvent> getEvents() {
			return events;
		}
	}

	@Entity(name = "UserEvents")
	@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
	public static class UserEvents extends AbstractEventsEntityModel {

		@Id
		@GeneratedValue
		private Long id;

	}

	@Entity(name = "ApplicationEvents")
	@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
	public static class ApplicationEvents extends AbstractEventsEntityModel {

		@Id
		@GeneratedValue
		private Long id;

	}
}
