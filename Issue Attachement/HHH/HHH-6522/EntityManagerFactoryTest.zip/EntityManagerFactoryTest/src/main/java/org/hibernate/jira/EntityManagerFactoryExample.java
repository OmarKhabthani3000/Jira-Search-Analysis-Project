package org.hibernate.jira;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class EntityManagerFactoryExample {
    
    private EntityManagerFactory entityManagerFactory;
    
    private EntityManager entityManager;
    
    public EntityManager getEntityManager() {
        
        if ( entityManagerFactory == null ) {
            entityManagerFactory = Persistence.createEntityManagerFactory( "primary" );
        }
        if ( entityManager == null ) {
            entityManager = entityManagerFactory.createEntityManager();
        }
        
        return entityManager;
    }
    
}
