package org.hibernate.jira.test;

import static org.junit.Assert.assertNotNull;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.hibernate.jira.EntityManagerFactoryExample;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.logging.Logger;
import org.jboss.shrinkwrap.api.Archive;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith( Arquillian.class )
public class MemberRegistrationTest {
    
    @Deployment
    public static Archive<?> createTestArchive() {
        return ShrinkWrap
            .create( WebArchive.class, "test.war" ).addClasses( EntityManagerFactoryExample.class )
            .addAsResource( "META-INF/persistence.xml", "META-INF/persistence.xml" ).addAsWebInfResource( EmptyAsset.INSTANCE, "beans.xml" );
    }
    
    private EntityManagerFactoryExample emFacExample;
    
    @Before
    public void setUp() {
        emFacExample = new EntityManagerFactoryExample();
    }
    
    @Inject
    Logger log;
    
    @Test
    public void testGetEntityManager() {
        
        EntityManager entityManager = emFacExample.getEntityManager();
        assertNotNull( "entityManager could not be created.", entityManager );
        
    }
    
    @Produces
    public Logger produceLog( InjectionPoint injectionPoint ) {
        return Logger.getLogger( injectionPoint.getMember().getDeclaringClass() );
    }
    
}
