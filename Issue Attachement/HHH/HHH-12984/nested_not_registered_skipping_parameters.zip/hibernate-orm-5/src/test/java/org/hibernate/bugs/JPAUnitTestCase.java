package org.hibernate.bugs;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

  private EntityManagerFactory entityManagerFactory;

  @Before
  public void init() {
    entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
  }

  @After
  public void destroy() {
    entityManagerFactory.close();
  }

  @Test
  public void subtring_replace_with_registered_function_is_ok() throws Exception {
    EntityManager entityManager = entityManagerFactory.createEntityManager();
    entityManager.getTransaction().begin();
    entityManager.createQuery("Select e from EntityA e where substring(function('replace', e.name, 'a', 'b'), 1, 2) = 'test' ").getResultList();
    entityManager.getTransaction().commit();
    entityManager.close();
  }


  @Test
  public void subtring_replace_with_not_registered_function_produce_bad_sql() throws Exception {
    EntityManager entityManager = entityManagerFactory.createEntityManager();
    entityManager.getTransaction().begin();
    entityManager.createQuery("Select e from EntityA e where substring(function('replace_not_registered', e.name, 'a', 'b'), 1, 2) = 'test' ").getResultList();

    // This test will produce the following SQL.
    // select entitya0_.id as id1_0_, entitya0_.name as name2_0_ from EntityA entitya0_ where substring(replace_not_registered(entitya0_.name, 'a', 'b'))='test'
    //  For sure, replace_not_registered doesn't exist on H2 and will fail but the main issue is this part of the sql
    // substring(replace_not_registered(entitya0_.name, 'a', 'b')) -> this should be substring(replace_not_registered(entitya0_.name, 'a', 'b'), 1, 2)
    entityManager.getTransaction().commit();
    entityManager.close();
  }
}
