package org.hibernate.envers.bugs;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import org.hibernate.envers.Audited;

@Entity
@Audited
public class Parent implements Serializable {

    @Id
    private String id;

    @OneToMany(mappedBy = "id.parent")
    private List<Child> children;
}
