package org.hibernate.envers.bugs;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import org.hibernate.envers.Audited;

@Entity
@Audited
public class Child implements Serializable {

    @EmbeddedId
    private ChildId id;
}
