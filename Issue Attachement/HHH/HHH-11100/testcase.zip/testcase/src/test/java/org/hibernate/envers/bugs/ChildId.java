package org.hibernate.envers.bugs;

import java.io.Serializable;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

@Embeddable
public class ChildId implements Serializable {

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name = "parent_id", referencedColumnName = "id")
    })
    private Parent parent;

    private Integer number;
}
