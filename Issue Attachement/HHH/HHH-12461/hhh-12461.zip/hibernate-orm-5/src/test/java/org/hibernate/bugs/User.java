package org.hibernate.bugs;

import javax.persistence.*;

@Entity
public class User {

	@Id
	@GeneratedValue
	private Long id;

	@OneToOne(mappedBy = "user", fetch = FetchType.LAZY)
	private Detail detail;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Detail getDetail() {
		return detail;
	}

	public void setDetail(Detail detail) {
		this.detail = detail;
	}
}
