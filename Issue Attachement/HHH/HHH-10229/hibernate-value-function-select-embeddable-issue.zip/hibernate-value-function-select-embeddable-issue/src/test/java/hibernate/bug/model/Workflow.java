package hibernate.bug.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MapKeyColumn;

@Entity
public class Workflow implements Serializable {

    private Long id;
    private String name;
    private Map<String, Text> texts = new HashMap<String, Text>(0);

    public Workflow() {
    }

    public Workflow(String name) {
        this.name = name;
    }

    @Id
    @GeneratedValue
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @ElementCollection
    @CollectionTable(name = "workflow_texts")
    @MapKeyColumn(name = "key")
    public Map<String, Text> getTexts() {
        return texts;
    }

    public void setTexts(Map<String, Text> texts) {
        this.texts = texts;
    }
}
