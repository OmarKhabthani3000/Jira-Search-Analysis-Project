package hibernate.bug.model;

import java.io.Serializable;
import javax.persistence.Embeddable;

@Embeddable
public class Text implements Serializable {

    private String name;

    public Text() {
    }

    public Text(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
