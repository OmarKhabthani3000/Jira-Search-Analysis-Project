/*
 * $HeadURL$
 * 
 * (c) 2014 IIZUKA Software Technologies Ltd.  All rights reserved.
 */
package uk.co.iizuka.test.jpaconcatissue.model;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 
 * 
 * @author daiman patel
 * @version $Id$
 */
@Entity
public class AnotherBean
{
	@Id
	private Long id;
	
	private String value;
	
	// for hibernate
	AnotherBean()
	{
	}
	
	public AnotherBean(String value, Long id)
	{
		setValue(value);
		
		this.id = id;
	}
	
	public String getValue()
	{
		return value;
	}
	
	public void setValue(String value)
	{
		this.value = value;
	}
}
