/*
 * $HeadURL$
 * 
 * (c) 2014 IIZUKA Software Technologies Ltd.  All rights reserved.
 */
package uk.co.iizuka.test.jpaconcatissue;

/**
 * When using an HSQL database, issues occur when trying to construct the query; same also applies when using PostgreSQL.
 * Comments have been added to the ConcatTest class to explain these issues, and workarounds.
 * 
 * @author daiman patel
 * @version $Id$
 */
public class HSQLTest extends ConcatTest
{
	public HSQLTest()
	{
		super("hsqlPersistenceUnit");
	}
}
