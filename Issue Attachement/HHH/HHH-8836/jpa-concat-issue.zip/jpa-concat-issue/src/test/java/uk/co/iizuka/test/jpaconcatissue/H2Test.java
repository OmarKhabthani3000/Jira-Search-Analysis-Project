/*
 * $HeadURL$
 * 
 * (c) 2014 IIZUKA Software Technologies Ltd.  All rights reserved.
 */
package uk.co.iizuka.test.jpaconcatissue;

/**
 * ALL tests pass when using an H2 database.
 * 
 * @author daiman patel
 * @version $Id$
 */
public class H2Test extends ConcatTest
{
	public H2Test()
	{
		super("h2PersistenceUnit");
	}
}
