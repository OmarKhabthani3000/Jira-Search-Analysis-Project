package org.hibernate.bugs;

import java.sql.Date;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
class ShouldMapToSqlDateConverter implements AttributeConverter<ShouldMapToSqlDate, java.sql.Date>{
	
	@Override public Date convertToDatabaseColumn(ShouldMapToSqlDate attribute) {
		return new Date(1);
	}
	
	@Override public ShouldMapToSqlDate convertToEntityAttribute(Date dbData) {
		return new ShouldMapToSqlDate();
	}

}
