package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
class TestEntity {
	@Id Long id;
	ShouldMapToSqlDate shouldMapToSqlDate;
	java.sql.Date simpleSqlDate;
}
