package org.hibernate.bugs;

class ShouldMapToSqlDate {}
