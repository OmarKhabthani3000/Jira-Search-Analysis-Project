/*
 * $HeadURL: https://svn.iizuka.co.uk/people/daiman/jpa-concat-issue/src/test/java/uk/co/iizuka/test/jpaconcatissue/ConcatTest.java $
 * 
 * (c) 2014 IIZUKA Software Technologies Ltd.  All rights reserved.
 */
package uk.co.iizuka.test.treatissue;

import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import uk.co.iizuka.test.treatissue.model.TestBean;
import uk.co.iizuka.test.treatissue.model.TestSubBean;

/**
 * 
 * 
 * @author daiman patel
 * @version $Id: ConcatTest.java 116060 2014-01-06 17:04:27Z daiman@IIZUKA.CO.UK $
 */
public class TreatTest
{
	private static EntityManager entityManager;
	
	private EntityTransaction entityTransaction;
	
	@Before
	public void setUp()
	{
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("persistenceUnit");
		entityManager = entityManagerFactory.createEntityManager();
		
		// Enable transactions
		entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();

		// Setup domain
		TestSubBean testSubBean = new TestSubBean("string");
		
		entityManager.persist(testSubBean);
	}
	
	@After
	public void after()
	{
		if (entityTransaction != null)
		{
			entityTransaction.rollback();
		}
		
		entityTransaction = null;
		
		if (entityManager != null)
		{
			EntityManagerFactory entityManagerFactory = entityManager.getEntityManagerFactory();
			
			entityManager.close();
			
			entityManagerFactory.close();
		}
	}
	
	@Test
	public void testTreat()
	{
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<TestBean> root = criteriaQuery.from(TestBean.class);
		Root<TestSubBean> subroot = criteriaBuilder.treat(root, TestSubBean.class);
		
		// Performing this 'select' clause should be valid; however, it causes a NullPointerException
		criteriaQuery.select(subroot.<String>get("property"));
		
		TypedQuery<String> typedQuery = entityManager.createQuery(criteriaQuery);
		String result = typedQuery.getSingleResult();
		
		assertEquals("string", result);
	}
}
