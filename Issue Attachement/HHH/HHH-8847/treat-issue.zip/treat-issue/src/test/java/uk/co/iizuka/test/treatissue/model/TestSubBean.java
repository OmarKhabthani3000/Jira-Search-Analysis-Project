/*
 * $HeadURL: https://svn.iizuka.co.uk/people/daiman/jpa-concat-issue/src/test/java/uk/co/iizuka/test/jpaconcatissue/model/AnotherBean.java $
 * 
 * (c) 2014 IIZUKA Software Technologies Ltd.  All rights reserved.
 */
package uk.co.iizuka.test.treatissue.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * 
 * 
 * @author daiman patel
 * @version $Id: AnotherBean.java 116060 2014-01-06 17:04:27Z daiman@IIZUKA.CO.UK $
 */
@Entity
public class TestSubBean extends TestBean
{
	private String property;
	
	// for hibernate
	TestSubBean()
	{
	}
	
	public TestSubBean(String property)
	{
		setProperty(property);
	}

	public String getProperty()
	{
		return property;
	}

	public void setProperty(String property)
	{
		this.property = property;
	}
}
