package com.example.demo;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;

@SpringBootTest
@EnableAutoConfiguration
class DemoApplicationTests {

    @Autowired
    private ApiKeyRepository apiKeyRepository;
    @Autowired
    private RoleRepository roleRepository;

    @Test
    void hibernateUsesIncorrectJoin() {
        Role role1 = new Role("role A");
        roleRepository.save(role1);
        ApiKey apiKey1 = new ApiKey("key A", role1);
        apiKeyRepository.save(apiKey1);
        ApiKey apiKey2 = new ApiKey("key B", null);
        apiKeyRepository.save(apiKey2);

        Order order = new Order(Direction.ASC, "role.name");
        Pageable pageable = PageRequest.of(0, 10, Sort.by(order));
        Page<ApiKey> apiKeys = apiKeyRepository.find(pageable);
        // We expect both api keys, even though one of them has an empty role. This was the case in Spring Boot 3.1.0 but no
        // longer in Spring Boot 3.1.1
        // The reason is that Hibernate generates a regular JOIN, even though the repository defines a LEFT JOIN.
        assertThat(apiKeys.getContent().size(), is(equalTo(2)));
    }

}
