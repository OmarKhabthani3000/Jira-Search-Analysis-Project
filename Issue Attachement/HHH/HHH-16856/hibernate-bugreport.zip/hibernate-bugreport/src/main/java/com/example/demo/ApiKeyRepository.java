package com.example.demo;

import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ApiKeyRepository extends CrudRepository<ApiKey, UUID> {

    @Query("""
        SELECT ak FROM ApiKey ak
        LEFT JOIN ak.role r
        """)
    Page<ApiKey> find(Pageable pageable);


}
