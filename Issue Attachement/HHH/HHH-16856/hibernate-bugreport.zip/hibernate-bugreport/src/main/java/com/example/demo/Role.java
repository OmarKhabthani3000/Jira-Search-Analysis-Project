package com.example.demo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.util.UUID;

@Entity
public class Role {

    @Id
    private UUID id;

    public UUID getId() {
        return id;
    }

    protected void generateId() {
        this.id = UUID.randomUUID();
    }

    public Role() {

    }

    @Column(name = "project_id", updatable = false, insertable = false)
    private UUID projectId;

    @Column(nullable = false)
    private String name;

    public Role(String name) {
        generateId();
        this.name = name;
    }

}
