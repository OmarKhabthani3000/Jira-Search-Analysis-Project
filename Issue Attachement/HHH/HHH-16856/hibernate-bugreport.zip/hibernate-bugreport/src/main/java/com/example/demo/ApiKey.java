package com.example.demo;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import java.util.UUID;

@Entity
public class ApiKey {

    public ApiKey() {

    }

    protected void generateId() {
        this.id = UUID.randomUUID();
    }

    @Id
    private UUID id;


    @JoinColumn(foreignKey = @ForeignKey(name = "fk_role"))
    @ManyToOne(fetch = FetchType.LAZY)
    private Role role;

    @Column(nullable = false)
    private String name;


    public ApiKey(String name, Role role) {
        generateId();
        this.name = name;
        this.role = role;
    }

}
