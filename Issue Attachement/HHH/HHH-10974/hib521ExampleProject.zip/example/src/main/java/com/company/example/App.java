package com.company.example;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


/**
 * Hello world!
 *
 */
public class App 
{
//	private static Logger logger = LogManager.getLogger(App.class);
	
    public static void main( String[] args )
    {
    	@SuppressWarnings("unused")
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate5example");
        System.out.println( "Hello World!" );
    }
}
