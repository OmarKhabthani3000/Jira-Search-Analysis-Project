/*
 * 
 */
package com.hibernate.elephants;

import java.io.Serializable;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


@Repository
public class DAO  {
	
	private SessionFactory sessionFactory;
	
	public DAO() {
	}
	
	@Transactional(propagation=Propagation.MANDATORY)
	public Serializable save(Object entity) {
		return sessionFactory.getCurrentSession().save(entity);
	}
	
	public void setSessionFactory(SessionFactory s) {
		sessionFactory = s;
	}

	@Transactional(propagation=Propagation.MANDATORY)
 	public void update(Object entity) {
 		sessionFactory.getCurrentSession().saveOrUpdate(entity);
	}
	




}
