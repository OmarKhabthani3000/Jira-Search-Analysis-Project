package com.hibernate.elephants;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;

import com.serisys.java8.testing.DAO;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Test1 {
	
	public static AbstractApplicationContext CONTEXT;
	public static PlatformTransactionManager txManager;
	public static DAO dao;
	
	public static final boolean MY_SQL = false;
	
	@BeforeClass
	public static void setUp() {
		CONTEXT = new ClassPathXmlApplicationContext("com/hibernate/elephants/context.xml");
		txManager  = (PlatformTransactionManager) CONTEXT.getBean("txManager");
		dao = (DAO) CONTEXT.getBean("dao");		
	}
	
	
	@Test 
	public void test99() {
		TransactionStatus tstat = txManager.getTransaction(null);
		AddressBook e = new AddressBook();
		Address address1 = new Address(12, "High Street");
		Address address2 = new Address(12, "Park Avenue");
		e.getAddresses().add(address1);
		e.getAddresses().add(address2);
		dao.save(e);
		txManager.commit(tstat);
	}

}
