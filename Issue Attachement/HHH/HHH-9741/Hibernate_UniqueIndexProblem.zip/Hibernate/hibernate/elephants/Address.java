package com.hibernate.elephants;

import javax.persistence.Embeddable;

@Embeddable
public class Address {

	private int houseNumber = 0;
	private String streetName;
	
	public Address() {
		super();
	}

	public Address(int houseNumber, String road) {
		super();
		this.houseNumber = houseNumber;
		this.streetName = road;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Address) {
			Address other = (Address) obj;
			return houseNumber == other.houseNumber && streetName.equals(other.streetName);
		}
		return super.equals(obj);
	}
	@Override
	public int hashCode() {
		return houseNumber + streetName.hashCode();
	}
	
}
