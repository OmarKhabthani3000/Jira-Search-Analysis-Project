package com.hibernate.elephants;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class AddressBook {

	@Id
	@GeneratedValue
	private long id;
	
	@ElementCollection
	@CollectionTable(name = "ADDRESS_BOOK_SET")
	private Set<Address> addresses = new HashSet<Address>();

	public Set<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(Set<Address> addresses) {
		this.addresses = addresses;
	}
}
