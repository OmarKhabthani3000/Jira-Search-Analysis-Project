package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
@org.hibernate.annotations.DynamicUpdate
public class ParentEntity {

    @Id
    private String id;

    // 1st test case
    @OneToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "id_child")
    private ChildEntity child;

    // 2nd test case
    @OneToMany(cascade = CascadeType.PERSIST, targetEntity = ChildEntity.class)
    @JoinColumn(name = "id_parent2")
    private List<ChildEntity> childList = new ArrayList<>();

    public ChildEntity getChild() {
        return this.child;
    }

    public void setChild(ChildEntity child) {
        this.child = child;
    }

    public String getId() {
        return this.id;
    }

    public List<ChildEntity> getChildList() {
        return this.childList;
    }

    public void setChildList(List<ChildEntity> childList) {
        this.childList = childList;
    }

    public void setId(String id) {
        this.id = id;
    }

}
