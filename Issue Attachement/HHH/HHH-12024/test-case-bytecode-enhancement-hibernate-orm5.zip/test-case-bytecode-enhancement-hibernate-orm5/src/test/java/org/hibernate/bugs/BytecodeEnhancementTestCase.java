package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BytecodeEnhancementTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        this.entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        this.entityManagerFactory.close();
    }

    @Test
    public void testCascadePersistOneToOneRelationship() {
        EntityManager entityManager = this.entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        ParentEntity parent = new ParentEntity();
        parent.setId("test1");

        ChildEntity child = new ChildEntity();
        child.setId("test1");

        parent.setChild(child);

        entityManager.unwrap(Session.class).saveOrUpdate(parent);

        entityManager.getTransaction().commit();

        String childId =
            (String) entityManager
                .createNativeQuery("select id_child from ParentEntity where id = 'test1'")
                .setMaxResults(1).getSingleResult();

        org.junit.Assert.assertEquals("test1", childId);
    }

    @Test
    public void testCascadePersistOneToManyRelationship() {
        EntityManager entityManager = this.entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        ParentEntity parent = new ParentEntity();
        parent.setId("test2");

        ChildEntity child = new ChildEntity();
        child.setId("test2");

        parent.getChildList().add(child);

        // XXX we use here saveOrUpdate() instead of persist() for persistence
        entityManager.unwrap(Session.class).saveOrUpdate(parent);

        entityManager.getTransaction().commit();

        String childId =
            (String) entityManager
                .createNativeQuery("select id_parent2 from ChildEntity where id = 'test2'")
                .setMaxResults(1).getSingleResult();

        org.junit.Assert.assertEquals("test2", childId);
    }

    @Test
    public void testCascadePersistManyToOneRelationship() {
        EntityManager entityManager = this.entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        ChildEntity child = new ChildEntity();
        child.setId("test3");

        ParentEntity parent = new ParentEntity();
        parent.setId("test3");

        child.setParent3(parent);

        // XXX we use here saveOrUpdate() instead of persist() for persistence
        entityManager.unwrap(Session.class).saveOrUpdate(child);

        entityManager.getTransaction().commit();

        String childId =
            (String) entityManager
                .createNativeQuery("select id_parent3 from ChildEntity where id = 'test3'")
                .setMaxResults(1).getSingleResult();

        org.junit.Assert.assertEquals("test3", childId);
    }
}
