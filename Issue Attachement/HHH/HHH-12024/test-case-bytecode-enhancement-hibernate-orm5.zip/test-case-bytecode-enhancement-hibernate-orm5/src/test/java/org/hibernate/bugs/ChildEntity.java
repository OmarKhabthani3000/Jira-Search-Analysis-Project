package org.hibernate.bugs;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
@org.hibernate.annotations.DynamicUpdate
public class ChildEntity  {

    @Id
    private String id;

    // @OneToOne(mappedBy = "child", targetEntity = ParentEntity.class)
    // private ParentEntity parent;

    // 3d test case
    @ManyToOne(targetEntity = ParentEntity.class, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "id_parent3")
    private ParentEntity parent3;

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    // public ParentEntity getParent() {
    // return this.parent;
    // }
    //
    // public void setParent(ParentEntity parent) {
    // this.parent = parent;
    // }

    public ParentEntity getParent3() {
        return this.parent3;
    }

    public void setParent3(ParentEntity parent3) {
        this.parent3 = parent3;
    }


}
