package org.hibernate.bugs;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Version;

@Entity
@org.hibernate.annotations.Proxy(lazy = false)
@org.hibernate.annotations.DynamicUpdate
public class Bag {
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SEQ_GENERATOR")
	private long id;

	@Version
	private long version;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn
	private Set<Item> items = new HashSet<>();

	public void addItem(Item item) {
		items.add(item);
	}

	public Collection<Item> getItems() {
		return items;
	}
}
