package org.hibernate.bugs;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Version;

import org.hibernate.annotations.LazyToOneOption;

@Entity
@org.hibernate.annotations.Proxy(lazy = false)
@org.hibernate.annotations.DynamicUpdate
public class Feature {
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SEQ_GENERATOR")
	private long id;

	@Version
	private long version;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	@org.hibernate.annotations.LazyToOne(LazyToOneOption.NO_PROXY)
	private FeatureValue featureValue;

	public FeatureValue getFeatureValue() {
		return featureValue;
	}

	public void setFeatureValue(FeatureValue featureValue) {
		this.featureValue = featureValue;
	}
}
