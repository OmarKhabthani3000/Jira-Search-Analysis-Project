package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Version;

@Entity
@org.hibernate.annotations.Proxy(lazy = false)
@org.hibernate.annotations.DynamicUpdate
public class Item {
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SEQ_GENERATOR")
	private long id;

	@Version
	private long version;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn
	private Collection<Feature> features = new ArrayList<>();


	public void addFeature(Feature feature) {
		features.add(feature);
	}

	public Collection<Feature> getFeatures() {
		return features;
	}
}
