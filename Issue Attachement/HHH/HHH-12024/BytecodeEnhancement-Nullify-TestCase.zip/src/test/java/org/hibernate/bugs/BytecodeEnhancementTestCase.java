package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BytecodeEnhancementTestCase {
	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void shouldPostingValueNotBeNull() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Bag bag = new Bag();
		entityManager.persist(bag);
		Item item = new Item();
		entityManager.persist(item);
		bag.addItem(item);
		entityManager.getTransaction().commit();
		entityManager.clear();

		System.out.println("------------------------------------------------------");
		entityManager.getTransaction().begin();
		bag = entityManager
				.createQuery("select bag from Bag bag", Bag.class)
				.setMaxResults(1)
				.getSingleResult();
		item = entityManager
				.createQuery("select item from Item item", Item.class)
				.setMaxResults(1)
				.getSingleResult();
		Feature primaryFeature = new Feature();
		FeatureValue featureValue = new FeatureValue();
		primaryFeature.setFeatureValue(featureValue);
		Feature secondaryFeature = new Feature();
		secondaryFeature.setFeatureValue(featureValue);

		item.addFeature(primaryFeature);
		item.addFeature(secondaryFeature);
		featureValue.setBag(bag);

		entityManager.persist(primaryFeature);

 		entityManager.getTransaction().commit();
		System.out.println("------------------------------------------------------");

		entityManager.close();
	}
}
