package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class FooBarEntity {

    @Id
    private Long id;

    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    private FooBarEntity parent;

    protected FooBarEntity() {
    }

    public FooBarEntity(long id, String name, FooBarEntity parent) {
        this.id = id;
        this.parent = parent;
        this.name = name;
    }

    public FooBarEntity getParent() {
        return parent;
    }

    public Long getId() {
        return id;
    }

    /**
     * Gibt den Wert von {@link #name} zurück.
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    // !!!Workaround!!!
    // @Override
    // public int hashCode() {
    // return super.hashCode();
    // }

    // !!!Workaround!!!
    // @Override
    // public boolean equals(Object obj) {
    // return super.equals(Hibernate.unproxy(obj));
    // }

}
