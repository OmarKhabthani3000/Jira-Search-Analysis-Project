package org.hibernate.bugs;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh17330Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        // Create 3 entities A,B,C
        // B is "parent" of A and C

        FooBarEntity parent = new FooBarEntity(1l, "B", null);
        entityManager.persist(parent);

        FooBarEntity child1 = new FooBarEntity(2l, "A", parent);
        entityManager.persist(child1);

        FooBarEntity child2 = new FooBarEntity(3l, "C", parent);
        entityManager.persist(child2);

        entityManager.getTransaction().commit();
        entityManager.close();

        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        // Order by name to get A,B,C in the result list
        List<FooBarEntity> resultList = entityManager.createQuery("select f from FooBarEntity f order by f.name asc", FooBarEntity.class).getResultList();

        FooBarEntity parentReloaded = resultList.stream().filter(e -> e.getId().equals(1l)).findFirst().get();
        FooBarEntity childReloaded = resultList.stream().filter(e -> e.getId().equals(2l)).findFirst().get();
        FooBarEntity child2Reloaded = resultList.stream().filter(e -> e.getId().equals(3l)).findFirst().get();

        // resultList.forEach(g -> System.out.println(
        // g.getClass().getSimpleName()
        // + " " + g.getName()
        // + ((g.getParent() != null ? " , Parent: " + (g.getParent().getClass().getSimpleName()) + " " + g.getParent().getName() : ""))));

        // This succeeds, since both are a proxy of B
        assertEquals(parentReloaded, childReloaded.getParent());

        // This unexpectedly fails, since parentReloaded is a proxy, but child2Reloaded.getParent() is not
        assertEquals(parentReloaded, child2Reloaded.getParent());

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
