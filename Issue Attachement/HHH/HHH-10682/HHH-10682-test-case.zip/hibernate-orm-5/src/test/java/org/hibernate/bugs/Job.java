package org.hibernate.bugs;

import javax.persistence.*;
import java.util.Date;

@IdClass(JobPk.class)
@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class Job {
    @Id
    private String supplier;
    @Id
    private String originator;
    @Id
    private String datatype;
    @Id
    private String rfi;
    private String fileToRun;
    private Date createDate;

    public Job() {
    }

    public Job(Job job) {
        this(job.getSupplier(),job.getOriginator(),job.getDatatype(),job.getRfi(),job.getFileToRun(),job.getCreateDate());
    }

    public Job(String supplier, String originator, String datatype, String rfi, String fileToRun, Date createDate) {
        this.supplier = supplier;
        this.originator = originator;
        this.datatype = datatype;
        this.rfi = rfi;
        this.fileToRun = fileToRun;
        this.createDate = createDate;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public String getOriginator() {
        return originator;
    }

    public void setOriginator(String originator) {
        this.originator = originator;
    }

    public String getDatatype() {
        return datatype;
    }

    public void setDatatype(String datatype) {
        this.datatype = datatype;
    }

    public String getRfi() {
        return rfi;
    }

    public void setRfi(String rfi) {
        this.rfi = rfi;
    }

    public String getFileToRun() {
        return fileToRun;
    }

    public void setFileToRun(String fileToRun) {
        this.fileToRun = fileToRun;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getOriginatorDatatypeRfi() {
        return getOriginator() + "_" + getDatatype() + "_" + getRfi();
    }
}
