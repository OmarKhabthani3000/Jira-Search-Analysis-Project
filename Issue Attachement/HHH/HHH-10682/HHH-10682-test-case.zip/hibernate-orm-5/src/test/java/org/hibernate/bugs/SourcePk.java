package org.hibernate.bugs;

import java.io.Serializable;

public class SourcePk implements Serializable {
    private String supplier;
    private String originator;
    private String datatype;

    public SourcePk() { }

    public SourcePk(String supplier, String originator, String datatype) {
        this.supplier = supplier;
        this.originator = originator;
        this.datatype = datatype;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public String getOriginator() {
        return originator;
    }

    public void setOriginator(String originator) {
        this.originator = originator;
    }

    public String getDatatype() {
        return datatype;
    }

    public void setDatatype(String datatype) {
        this.datatype = datatype;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SourcePk sourcePk = (SourcePk) o;

        if (supplier != null ? !supplier.equals(sourcePk.supplier) : sourcePk.supplier != null) return false;
        if (originator != null ? !originator.equals(sourcePk.originator) : sourcePk.originator != null) return false;
        return datatype != null ? datatype.equals(sourcePk.datatype) : sourcePk.datatype == null;

    }

    @Override
    public int hashCode() {
        int result = supplier != null ? supplier.hashCode() : 0;
        result = 31 * result + (originator != null ? originator.hashCode() : 0);
        result = 31 * result + (datatype != null ? datatype.hashCode() : 0);
        return result;
    }
}
