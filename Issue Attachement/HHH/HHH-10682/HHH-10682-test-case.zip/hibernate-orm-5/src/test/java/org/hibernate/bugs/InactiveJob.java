package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "inactive_jobs")
public class InactiveJob extends Job{
    private boolean killed;
    private boolean failed;

    public InactiveJob() {
    }

    public InactiveJob(String supplier, String originator, String datatype, String rfi, String fileToRun, Date createDate) {
        super(supplier, originator, datatype, rfi, fileToRun, createDate);
    }

    public boolean isKilled() {
        return killed;
    }

    public void setKilled(boolean killed) {
        this.killed = killed;
    }

    public boolean isFailed() {
        return failed;
    }

    public void setFailed(boolean failed) {
        this.failed = failed;
    }
}
