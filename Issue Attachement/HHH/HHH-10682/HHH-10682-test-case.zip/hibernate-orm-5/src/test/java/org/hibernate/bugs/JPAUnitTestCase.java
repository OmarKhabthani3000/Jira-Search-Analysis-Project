package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.IdClass;
import javax.persistence.Persistence;

import org.junit.*;

import java.util.Date;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private static EntityManagerFactory entityManagerFactory;
	private EntityManager entityManager;

	@BeforeClass
	public static void initClass() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@Before
	public void init() {
		entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
	}

	@After
	public void destroy() throws InterruptedException {
		entityManager.getTransaction().rollback();
	}

	@AfterClass
	public static void destroyClass() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void persistDoesNotWorkForTwoEntitiesWithSamePrimaryKey() throws Exception {
		entityManager.persist(new ActiveJob("supplier", "originator", "datatype", "rfi", "file.txt", new Date(), ""));
		entityManager.persist(new InactiveJob("supplier", "originator", "datatype", "rfi", "file.txt", new Date()));
	}

	@Test
	public void workaroundForPersistTwoEntitiesWithSamePrimaryKey() throws Exception {
		entityManager.persist(new ActiveJob("supplier", "originator", "datatype", "rfi", "file.txt", new Date(), ""));
		entityManager.flush();
		entityManager.clear();
		entityManager.persist(new InactiveJob("supplier", "originator", "datatype", "rfi", "file.txt", new Date()));
		entityManager.flush();
		entityManager.clear();
	}

	@Test
	public void selectsDoNotWorkForMultipleEntitiesWithSamePrimaryKey() throws Exception {
		entityManager.persist(new ActiveJob("supplier", "originator", "datatype", "rfi", "file.txt", new Date(), ""));
		entityManager.flush();
		entityManager.clear();
		entityManager.persist(new InactiveJob("supplier", "originator", "datatype", "rfi", "file.txt", new Date()));
		entityManager.flush();
		entityManager.clear();


		entityManager.createNativeQuery("select * from ACTIVE_JOBS", ActiveJob.class).getResultList();
		entityManager.createNativeQuery("select * from INACTIVE_JOBS", InactiveJob.class).getResultList();
	}

	@Test
	public void workaroundForSelectingMultipleEntitiesWithSamePrimaryKey() throws Exception {
		entityManager.persist(new ActiveJob("supplier", "originator", "datatype", "rfi", "file.txt", new Date(), ""));
		entityManager.flush();
		entityManager.clear();
		entityManager.persist(new InactiveJob("supplier", "originator", "datatype", "rfi", "file.txt", new Date()));
		entityManager.flush();
		entityManager.clear();


		entityManager.createNativeQuery("select * from ACTIVE_JOBS", ActiveJob.class).getResultList();
		entityManager.clear();
		entityManager.createNativeQuery("select * from INACTIVE_JOBS", InactiveJob.class).getResultList();
	}
}
