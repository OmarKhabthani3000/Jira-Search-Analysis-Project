
public class JobPk extends SourcePk {
    private String rfi;

    public JobPk() { }

    public JobPk(String supplier, String originator, String datatype, String rfi) {
        super(supplier, originator, datatype);
        this.rfi = rfi;
    }

    public String getRfi() {
        return rfi;
    }

    public void setRfi(String rfi) {
        this.rfi = rfi;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        JobPk jobPk = (JobPk) o;

        return rfi != null ? rfi.equals(jobPk.rfi) : jobPk.rfi == null;

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (rfi != null ? rfi.hashCode() : 0);
        return result;
    }
}
