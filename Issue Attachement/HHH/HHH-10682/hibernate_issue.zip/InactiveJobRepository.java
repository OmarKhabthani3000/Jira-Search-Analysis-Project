
import com.carfax.majique.entity.InactiveJob;
import com.carfax.majique.entity.JobPk;
import org.springframework.data.repository.CrudRepository;

public interface InactiveJobRepository extends CrudRepository<InactiveJob, JobPk> {
}
