
import com.carfax.majique.repository.ActiveJobRepository;
import com.carfax.majique.repository.InactiveJobRepository;
import org.springframework.beans.factory.annotation.Autowired;

public class MultipleRepositoryUser {
    @Autowired
    ActiveJobRepository activeJobRepository;
    @Autowired
    InactiveJobRepository inactiveJobRepository;


    void thisFailsWithException() {
        activeJobRepository.findAll();
        inactiveJobRepository.findAll();
    }
}
