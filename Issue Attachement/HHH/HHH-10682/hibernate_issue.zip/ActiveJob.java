
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "active_jobs")
public class ActiveJob extends Job {
    private String mesosTaskId;

    public ActiveJob() { }

    public ActiveJob(String supplier, String originator, String datatype, String rfi, String fileToRun, Date createDate, String mesosTaskId) {
        super(supplier, originator, datatype, rfi, fileToRun, createDate);
        this.mesosTaskId = mesosTaskId;
    }

    public String getMesosTaskId() {
        return mesosTaskId;
    }

    public void setMesosTaskId(String mesosTaskId) {
        this.mesosTaskId = mesosTaskId;
    }
}
