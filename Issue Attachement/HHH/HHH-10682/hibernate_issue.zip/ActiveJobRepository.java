
import com.carfax.majique.entity.ActiveJob;
import com.carfax.majique.entity.JobPk;
import org.springframework.data.repository.CrudRepository;

public interface ActiveJobRepository extends CrudRepository<ActiveJob, JobPk> {
}
