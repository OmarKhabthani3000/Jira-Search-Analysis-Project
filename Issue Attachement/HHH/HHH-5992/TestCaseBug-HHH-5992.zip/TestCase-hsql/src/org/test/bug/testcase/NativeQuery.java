package org.test.bug.testcase;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import junit.framework.Assert;

import org.junit.Test;

public class NativeQuery {

    @Test
    @SuppressWarnings("rawtypes")
    public void nativeQuery() throws Exception {
    	System.out.println("<<< Starting test case >>>");
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("bank");
        EntityManager em = factory.createEntityManager();
        UserEty user1 = new UserEty();
        user1.setUsername("1");
        UserEty user2 = new UserEty();
        user2.setUsername("2");
        em.getTransaction().begin();
        em.persist(user1);
        em.persist(user2);
        em.flush();
        //em.getTransaction().commit();
        //em.getTransaction().begin();
        // this query works
        //Query query = em.createNativeQuery("select v1.username as name1, v2.username as name2 from user_ety v1, user_ety v2 where v1.username = '1' and v2.username = '2'");
        //this query fails
        Query query = em.createNativeQuery("select v1.username, v2.username from user_ety v1, user_ety v2 where v1.username = '1' and v2.username = '2'");
        List list = query.getResultList();
        Assert.assertEquals(1, list.size());
        Object[] row = (Object[]) list.get(0);
        String username1 = (String) row[0];
        String username2 = (String) row[1];
        Assert.assertEquals("invalid username1", "1", username1);
        Assert.assertEquals("invalid username2", "2", username2);
        em.getTransaction().commit();
        em.close();
    }

    
    //public static void main(String args[]) {
    //    org.junit.runner.JUnitCore.main(NativeQuery.class.getName());
    //}
    
}
