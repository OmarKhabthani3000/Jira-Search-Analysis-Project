package fr.texsys.hbtest;

import org.junit.Test;

public class AppTest {

  @Test
  public void testApp() {
    
    //EntityManagerFactory emf = Persistence.createEntityManagerFactory("main");
    //EntityManager entityManager = emf.createEntityManager();
    //entityManager.getTransaction().begin();

        //DigitalParameterType type = new DigitalParameterType();
        //type.setName("test_type");
        //type.setLabel("Hello world!");
        //entityManager.persist(type);
        //entityManager.flush();

        //DigitalParameterState state = new DigitalParameterState();
        //state.setLevel("OK");
        //state.setDescription("Some description");

        //Map<Integer, DigitalParameterState> states = new HashMap<>();
        //states.put(0, state);

        //type.setStates(states);

        //entityManager.flush();
    //System.out.println(type);
  }

}
