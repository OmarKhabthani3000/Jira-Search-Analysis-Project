package fr.texsys.hbtest.domain;

import java.util.Map;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.Table;

@Entity
@Table(name = "parameters")
public class Parameter {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  private String name;

  @ElementCollection
  @MapKeyColumn(name = "value")
  @CollectionTable(name = "states",
      joinColumns = @JoinColumn(name = "parameter_id"))
  protected Map<Integer, State> states;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Map<Integer, State> getStates() {
    return states;
  }

  public void setStates(Map<Integer, State> states) {
    this.states = states;
  }

}
