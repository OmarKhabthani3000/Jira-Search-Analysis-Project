package fr.texsys.hbtest.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class State {

  @Column(insertable = false, updatable = false)
  private Integer value;

  private String level;

  private String description;

  public Integer getValue() {
    return value;
  }

  public void setValue(Integer value) {
    this.value = value;
  }

  public String getLevel() {
    return level;
  }

  public void setLevel(String level) {
    this.level = level;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

}
