package fr.texsys.hbtest;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import fr.texsys.hbtest.domain.State;
import fr.texsys.hbtest.domain.Parameter;

public class App {
  public static void main(String[] args) {
      
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("main");
    EntityManager entityManager = emf.createEntityManager();
    entityManager.getTransaction().begin();

    Parameter type = new Parameter();
    type.setName("test_type");

    entityManager.persist(type);
    entityManager.flush();

    State state = new State();

    state.setLevel("OK");
    state.setDescription("Some description");

    Map<Integer, State> states = new HashMap<>();
    states.put(0, state);

    type.setStates(states);

    entityManager.flush();
    System.out.println(type);
  
  }
}
