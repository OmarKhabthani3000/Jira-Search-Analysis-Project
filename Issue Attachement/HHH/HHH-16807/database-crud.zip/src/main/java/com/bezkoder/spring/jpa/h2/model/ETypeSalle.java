/**
 * 
 */
package com.bezkoder.spring.jpa.h2.model;

/**
 * @author abarbe-ext
 *
 */
public enum ETypeSalle {
    toto
}
