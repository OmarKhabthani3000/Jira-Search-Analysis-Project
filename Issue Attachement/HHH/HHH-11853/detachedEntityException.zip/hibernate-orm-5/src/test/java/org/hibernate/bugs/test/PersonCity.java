package org.hibernate.bugs.test;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

@Entity
public class PersonCity {

    @EmbeddedId
    private PersonCityKey id = new PersonCityKey();

    @ManyToOne
    @MapsId("personId")
    private Person person;
    @ManyToOne
    @MapsId("cityId")
    private City city;

    private String additionalInfo;


    public PersonCity() {
    }


    public PersonCityKey getId() {
        return id;
    }
    public void setId(PersonCityKey id) {
        this.id = id;
    }

    public Person getPerson() {
        return person;
    }
    public void setPerson(Person person) {
        this.person = person;
    }

    public City getCity() {
        return city;
    }
    public void setCity(City city) {
        this.city = city;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }
    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }
}
