package org.hibernate.bugs.test;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Embeddable;

@Embeddable
public class PersonCityKey implements Serializable {

    private Long personId;
    private Long cityId;


    public PersonCityKey() {
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        PersonCityKey that = (PersonCityKey) o;
        return Objects.equals(personId, that.personId) &&
               Objects.equals(cityId, that.cityId);
    }
    @Override
    public int hashCode() {
        return Objects.hash(personId, cityId);
    }


    public Long getPersonId() {
        return personId;
    }
    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    public Long getCityId() {
        return cityId;
    }
    public void setCityId(Long cityId) {
        this.cityId = cityId;
    }
}
