package org.hibernate.bugs.test;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedEntityGraphs;
import javax.persistence.OneToMany;

@Entity
@NamedEntityGraphs({
        @NamedEntityGraph(
                name = City.EG_CITY_ALL,
                includeAllAttributes = true)
})
public class City {

    public static final String EG_CITY_ALL = "EG_CITY_ALL";

    @Id
    @GeneratedValue
    private Long id;
    private String name;

    @OneToMany(mappedBy = "city")
    private Set<PersonCity> personCitySet = new HashSet<>();


    public City() {
    }


    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public Set<PersonCity> getPersonCitySet() {
        return personCitySet;
    }
}
