package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.hibernate.bugs.test.City;
import org.hibernate.bugs.test.Person;
import org.hibernate.bugs.test.PersonCity;
import org.hibernate.jpa.QueryHints;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertFalse;

/**
 * This template demonstrates how to develop a org.hibernate.bugs.test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    /**
     * Reproduce PersistentObjectException when detaching an Entity that references another Entity which uses EmbeddedId.
     */
    @Test
    public void causesPersistentObjectException() throws Exception {
        // Create base entities
        City cityOne = new City();
        cityOne.setName("Somecity");

        Person personAndy = new Person();
        personAndy.setName("Andy");


        // 1st transaction
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        City mergedCity = em.merge(cityOne);
        Person mergedAndy = em.merge(personAndy);

        em.getTransaction().commit();
        em.close();


        // Change city
        mergedAndy.setName("Renamed City");
        // Create association
        PersonCity pc = new PersonCity();
        pc.setPerson(mergedAndy);
        pc.setCity(mergedCity);


        // 2nd transaction
        em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        assertFalse(em.contains(mergedCity));
        mergedCity = em.merge(mergedCity);

        assertFalse(em.contains(mergedAndy));
        mergedAndy.getPersonCitySet().add(pc);
        mergedAndy = em.merge(mergedAndy);

        mergedCity.getPersonCitySet().add(pc);

        em.getTransaction().commit();
        em.close();


        // 3rd transaction
        em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        assertFalse(em.contains(mergedAndy));
        assertFalse(em.contains(mergedCity));

        City fullyLoadedCity = findCityFull(mergedCity.getId(), em);
        em.detach(fullyLoadedCity); // <- Problem

        em.getTransaction().commit();
        em.close();
    }

    private City findCityFull(Long cityId, EntityManager em) {
        return em.createQuery("select c from City c where c.id = :id", City.class)
                .setParameter("id", cityId)
                .setHint(QueryHints.HINT_LOADGRAPH, em.getEntityGraph(City.EG_CITY_ALL))
                .getSingleResult();
    }
}
