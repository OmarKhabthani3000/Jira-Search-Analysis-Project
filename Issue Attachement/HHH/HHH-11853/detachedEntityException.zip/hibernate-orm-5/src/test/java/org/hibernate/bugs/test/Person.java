package org.hibernate.bugs.test;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedEntityGraphs;
import javax.persistence.OneToMany;

@Entity
@NamedEntityGraphs({
        @NamedEntityGraph(
                name = Person.EG_PERSON_ALL,
                includeAllAttributes = true)
})
public class Person {

    public static final String EG_PERSON_ALL = "EG_PERSON_ALL";

    @Id
    @GeneratedValue
    private Long id;
    private String name;

    @OneToMany(mappedBy = "person", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<PersonCity> personCitySet = new HashSet<>();


    public Person() {
    }


    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public Set<PersonCity> getPersonCitySet() {
        return personCitySet;
    }
}
