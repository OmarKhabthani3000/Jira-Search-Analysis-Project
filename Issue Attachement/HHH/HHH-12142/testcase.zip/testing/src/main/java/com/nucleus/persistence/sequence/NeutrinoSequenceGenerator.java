/**
 * This file and a proportion of its content is copyright of Nucleus Software Exports Limited - © 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * - you cannot print or download to a local hard disk extract contents either part or full for personal/ commercial/
 * academic or any other use
 * - you may not copy the content to individual/ third parties for any type of use, either as compiled or source format
 * without the knowledge and consent of Nucleus Software
 * - You may not, except with our express written permission, distribute or commercially exploit the content. Nor may you
 * transmit it or store it in any other web site or other form of electronic retrieval system.
 */
package com.nucleus.persistence.sequence;

import java.util.Properties;

import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.naming.ObjectNameNormalizer;
import org.hibernate.boot.model.relational.QualifiedName;
import org.hibernate.boot.model.relational.QualifiedNameImpl;
import org.hibernate.dialect.Dialect;
import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;
import org.hibernate.id.enhanced.SequenceStyleGenerator;
import org.hibernate.internal.util.config.ConfigurationHelper;

/**
 * This is an implementation of SequenceStyleGenerator which limits the name of  sequence/table (auto created for sequence generation)
 * to not exceed 30.
 * 
 */
public class NeutrinoSequenceGenerator extends SequenceStyleGenerator {

    public static final String ENTITY__TARGET_TABLE_NAME = "target_table";

    /**
     * Determine the name of the sequence to use. This method overrides the one provided by SequenceStyleGenerator
     *  and uses the target table name to determine the sequence name instead of the entity name.
     * <p/>
     *
     * @param params The params supplied in the generator config (plus some standard useful extras).
     * @param dialect The dialect in effect
     * @return The sequence name
     */
    @Override
    protected QualifiedName determineSequenceName(Properties params, Dialect dialect, JdbcEnvironment jdbcEnv) {
        String sequencePerEntitySuffix = ConfigurationHelper.getString(CONFIG_SEQUENCE_PER_ENTITY_SUFFIX, params,
                DEF_SEQUENCE_SUFFIX);
        // JPA_ENTITY_NAME value honors <class ... entity-name="..."> (HBM) and @Entity#name (JPA) overrides.
        String sequenceName = ConfigurationHelper.getBoolean(CONFIG_PREFER_SEQUENCE_PER_ENTITY, params, false) ? params
                .getProperty(ENTITY__TARGET_TABLE_NAME) + sequencePerEntitySuffix : DEF_SEQUENCE_NAME;
        sequenceName = DataBaseMappingUtil.abbreviateName(sequenceName);
        ObjectNameNormalizer normalizer = (ObjectNameNormalizer) params.get(IDENTIFIER_NORMALIZER);
        sequenceName = ConfigurationHelper.getString(SEQUENCE_PARAM, params, sequenceName);
       /* if (sequenceName.indexOf('.') < 0) {
            sequenceName = normalizer.normalizeIdentifierQuoting(sequenceName).getText();
            Identifier sequenceIdentifier = createIdentifier(sequenceName);
            Identifier schemaName = createIdentifier(jdbcEnv.getCurrentSchema().getText());//params.getProperty(SCHEMA);
            Identifier catalogName = createIdentifier(jdbcEnv.getCurrentCatalog().getText());//params.getProperty(CATALOG);
            sequenceName = jdbcEnv.getQualifiedObjectNameFormatter().format(new QualifiedSequenceName(catalogName, schemaName, sequenceIdentifier),dialect);
            //sequenceName = Table.qualify(dialect.quote(catalogName), dialect.quote(schemaName), dialect.quote(sequenceName));
        } else {
            // if already qualified there is not much we can do in a portable manner so we pass it
            // through and assume the user has set up the name correctly.
        }*/
       
        return new QualifiedNameImpl(jdbcEnv.getCurrentCatalog(), jdbcEnv.getCurrentSchema(), new Identifier(sequenceName,false));
    }
    
  

}
