package com.myapp.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;

import com.nucleus.core.annotations.Synonym;

/**
 * @author Nucleus Software Exports Limited
 * Information about a contact.
 */

@Entity
@Synonym(grant="ALL")
public class SimpleContactInfo extends BaseEntity {

    // ~ Static variables/initializers ==============================================================

    private static final long serialVersionUID = 52461;

    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private PhoneNumber       phoneNumber;

    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private PhoneNumber       mobileNumber;

    public PhoneNumber getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(PhoneNumber phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * @return the mobileNumber
     */
    public PhoneNumber getMobileNumber() {
        return mobileNumber;
    }

    /**
     * @param mobileNumber the mobileNumber to set
     */
    public void setMobileNumber(PhoneNumber mobileNumber) {
        this.mobileNumber = mobileNumber;
    }


}