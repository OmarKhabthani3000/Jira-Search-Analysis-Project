package com.nucleus.core.annotations;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Specifies that the class is a synonym. 
 * Possible values of grant attribute are ALL, SELECT 
 */
@Documented
@Target(TYPE)
@Retention(RUNTIME)
public @interface Synonym {
	
	/** Possible values are ALL, SELECT */
	String grant();
	
}
