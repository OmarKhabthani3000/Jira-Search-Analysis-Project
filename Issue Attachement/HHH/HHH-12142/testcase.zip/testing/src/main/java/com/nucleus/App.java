package com.nucleus;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nucleus.services.MyService;

public class App {
	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"/META-INF/spring/application.xml")) {
			MyService service = context.getBean(MyService.class);
			
			service.testConstraintViolationissue();
			

			
			
		}
	}
}
