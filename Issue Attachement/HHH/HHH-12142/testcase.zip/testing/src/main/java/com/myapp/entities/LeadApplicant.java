/**
 * This file and a proportion of its content is copyright of Nucleus Software Exports Limited - � 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * - you cannot print or download to a local hard disk extract contents either part or full for personal/ commercial/
 * academic or any other use
 * - you may not copy the content to individual/ third parties for any type of use, either as compiled or source format
 * without the knowledge and consent of Nucleus Software
 * - You may not, except with our express written permission, distribute or commercially exploit the content. Nor may you
 * transmit it or store it in any other web site or other form of electronic retrieval system.
 */
package com.myapp.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.nucleus.core.annotations.Synonym;

/**
 * @author Nucleus Software Exports Limited
 * 
 */
@Entity
@DynamicInsert
@DynamicUpdate
@Synonym(grant = "ALL")

public class LeadApplicant extends BaseEntity {

	private static final long serialVersionUID = 2992415488726745861L;

	public static final String TYPE_INDIVIDUAL = "individual";
	public static final String TYPE_NON_INDIVIDUAL = "non_individual";
	public static final int PRIMARY_LEAD_APPLICANT = 0;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "contact_info")
	private SimpleContactInfo contactInfo;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private PhoneNumber employeeMobileNumber;

	public SimpleContactInfo getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(SimpleContactInfo contactInfo) {
		this.contactInfo = contactInfo;
	}

	public LeadApplicant() {
		super();
	}

	public LeadApplicant(Long id, SimpleContactInfo contactInfo) {
		setId(id);
		this.contactInfo = contactInfo;
	}

	public PhoneNumber getEmployeeMobileNumber() {
		return employeeMobileNumber;
	}

	public void setEmployeeMobileNumber(PhoneNumber employeeMobileNumber) {
		this.employeeMobileNumber = employeeMobileNumber;
	}

}
