package com.myapp.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

import com.nucleus.core.annotations.Synonym;


@Indexed
@Entity
@DynamicUpdate
@DynamicInsert
@Synonym(grant="ALL")
public class Customer extends BaseEntity {
    @Transient
    private static final long              serialVersionUID    = 8654926557287673633L;

    public static final String             TYPE_INDIVIDUAL     = "individual";
    public static final String             TYPE_NON_INDIVIDUAL = "non_individual";
    public static final String             TYPE_OTHER          = "other";

    // associatedLoanAppId is required to associate a customer info with loan
    // for Global Customer.
    @Transient
    private String                         associatedLoanAppId;



    /** The contactPerson info. */
    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "customer_fk")
    private List<ContactPerson>            contactPerson;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @IndexedEmbedded
    @JoinColumn(name = "CONTACT_INFO")
    private DetailedContactInfo            contactInfo;


    public Customer() {
    }

    public List<ContactPerson> getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(List<ContactPerson> contactPerson) {
        this.contactPerson = contactPerson;
    }
     
    public DetailedContactInfo getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(DetailedContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }
}
