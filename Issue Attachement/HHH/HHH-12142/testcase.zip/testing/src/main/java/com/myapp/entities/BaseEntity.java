package com.myapp.entities;

import java.io.Serializable;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.DiscriminatorOptions;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.search.annotations.DocumentId;
@MappedSuperclass
@DiscriminatorOptions(force = true)
public abstract class BaseEntity implements Entity{

    /**
	 * 
	 */
	private static final long serialVersionUID = -5169955138930989381L;
	@Id
    @GenericGenerator(name = "sequencePerEntityGenerator", strategy = "com.nucleus.persistence.sequence.NeutrinoSequenceGenerator", parameters = {
            @Parameter(name = "prefer_sequence_per_entity", value = "true"),
            @Parameter(name = "sequence_per_entity_suffix", value = "_seq"),
            @Parameter(name = "initial_value", value = "5000000") })
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "sequencePerEntityGenerator")
    @DocumentId
	private Long id;
	
	@Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Serializable id) {
        if ((id != null) && (((Long) id).longValue() != 0)) {
            this.id = (Long) id;
        }
    }
	
}
