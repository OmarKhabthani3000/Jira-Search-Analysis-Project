package com.myapp.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.nucleus.core.annotations.Synonym;



@Entity
@DynamicUpdate
@DynamicInsert
@Synonym(grant="ALL")
@Table(indexes={
		@Index(name="cust_fk_index_contactPerson",columnList="customer_fk")})
public class ContactPerson extends BaseEntity {

    private static final long serialVersionUID = 5403797970677681766L;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "contact_person")
    private List<PhoneNumber> contactNumberList;






 

    public List<PhoneNumber> getContactNumberList() {
        return contactNumberList;
    }

    public void setContactNumberList(List<PhoneNumber> contactNumberList) {
        this.contactNumberList = contactNumberList;
    }

}
