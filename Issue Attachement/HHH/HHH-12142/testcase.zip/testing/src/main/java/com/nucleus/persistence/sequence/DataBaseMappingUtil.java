package com.nucleus.persistence.sequence;

import java.util.StringTokenizer;

public class DataBaseMappingUtil {

    public static final int DEFAULT_MAX_LENGTH = 30;

    public static String abbreviateName(String someName) {

        int maxLength = DEFAULT_MAX_LENGTH;
        if (someName.length() <= maxLength)
            return someName;

        String[] tokens = splitName(someName);
        shortenName(someName, tokens, maxLength);
        return assembleResults(tokens);
    }

    public static String abbreviateName(String someName, int maxLength) {
        if (someName.length() <= maxLength)
            return someName;

        String[] tokens = splitName(someName);
        shortenName(someName, tokens, maxLength);
        return assembleResults(tokens);
    }

    private static String[] splitName(String someName) {
        StringTokenizer toki = new StringTokenizer(someName, "_");
        String[] tokens = new String[toki.countTokens()];
        int i = 0;
        while (toki.hasMoreTokens()) {
            tokens[i] = toki.nextToken();
            i++;
        }
        return tokens;
    }

    private static void shortenName(String someName, String[] tokens, int maxLength) {
        int currentLength = someName.length();
        while (currentLength > maxLength) {
            int tokenIndex = getIndexOfLongest(tokens);
            String oldToken = tokens[tokenIndex];
            tokens[tokenIndex] = abbreviate(oldToken);
            currentLength -= oldToken.length() - tokens[tokenIndex].length();
        }
    }

    private static String abbreviate(String token) {
        final String VOWELS = "AEIOUaeiou";
        boolean vowelFound = false;
        for (int i = token.length() - 1 ; i >= 0 ; i--) {
            if (!vowelFound)
                vowelFound = VOWELS.contains(String.valueOf(token.charAt(i)));
            else if (!VOWELS.contains(String.valueOf(token.charAt(i))))
                return token.substring(0, i + 1);
        }
        return "";
    }

    private static int getIndexOfLongest(String[] tokens) {
        int maxLength = 0;
        int index = -1;
        for (int i = 0 ; i < tokens.length ; i++) {
            String string = tokens[i];
            if (maxLength < string.length()) {
                maxLength = string.length();
                index = i;
            }
        }
        return index;
    }

    private static String assembleResults(String[] tokens) {
        StringBuilder result = new StringBuilder(tokens[0]);
        for (int j = 1 ; j < tokens.length ; j++) {
            result.append("_").append(tokens[j]);
        }
        return result.toString();
    }

}
