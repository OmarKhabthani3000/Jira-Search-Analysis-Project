package com.myapp.entities;

import java.io.Serializable;

public interface Entity extends Serializable {
	
	public Serializable getId();

    public void setId(Serializable id);

}
