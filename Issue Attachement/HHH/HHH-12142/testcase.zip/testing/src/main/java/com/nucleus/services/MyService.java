package com.nucleus.services;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.myapp.entities.ContactPerson;
import com.myapp.entities.Customer;
import com.myapp.entities.DetailedContactInfo;
import com.myapp.entities.Entity;
import com.myapp.entities.Party;
import com.myapp.entities.PhoneNumber;
import com.myapp.entities.SimpleContactInfo;

@Service
public class MyService {

	@PersistenceContext
	private EntityManager entityManager;


	@Transactional
	public void testConstraintViolationissue() {

		
		PhoneNumber phoneNumber = new PhoneNumber();
		PhoneNumber mobileNumber = new PhoneNumber();
		phoneNumber.setPhoneNumber("");
		mobileNumber.setPhoneNumber("922");
		
		SimpleContactInfo simpleContactInfo = new SimpleContactInfo();
		simpleContactInfo.setPhoneNumber(phoneNumber);
		simpleContactInfo.setMobileNumber(mobileNumber);
		entityManager.persist(phoneNumber);
		entityManager.persist(mobileNumber);
		
		entityManager.flush();
		PhoneNumber employeeMobileNumber = new PhoneNumber();
		this.saveOrUpdate(employeeMobileNumber);
		Party party = new Party();
		
		
		Customer customer = new Customer();

		entityManager.persist(customer);
		entityManager.persist(party);
		DetailedContactInfo detailedContactInfo = new DetailedContactInfo(simpleContactInfo);
		this.saveOrHibernateUpdate(simpleContactInfo.getPhoneNumber());
		this.saveOrHibernateUpdate(simpleContactInfo.getMobileNumber());
		
		customer.setContactInfo(detailedContactInfo);

		List<ContactPerson> contactPersonList = new ArrayList<ContactPerson>();
		ContactPerson contactPerson = new ContactPerson();
		contactPerson.setContactNumberList(new ArrayList<PhoneNumber>());


		contactPerson.getContactNumberList().add(simpleContactInfo.getPhoneNumber());
		contactPerson.getContactNumberList().add(simpleContactInfo.getMobileNumber());

		
		contactPersonList.add(contactPerson);
		customer.setContactPerson(contactPersonList);
		party.setCustomer(customer);
        this.saveOrHibernateUpdate(party.getCustomer());
        
		

		System.out.println("**********TEST RAN SUCCESSFULLY**********");
	}

    public <T extends Entity> T saveOrUpdate(T entity) {
        T managedEntity = null;
        if (entity.getId() == null) {
            persist(entity);
            managedEntity = entity;
        } else {
            managedEntity = update(entity);
        }
        return managedEntity;
    }
    
    
    public <T extends Entity> T saveOrHibernateUpdate(T entity) {
        if (entity.getId() == null) {
            persist(entity);
        } else {
            getSession().update(entity);
        }
        return entity;
    }
    public void persist(Entity entity) {
    	entityManager.persist(entity);
    }
    
    public <T extends Entity> T update(T entity) {

            return entityManager.merge(entity);
    }
	
    private Session getSession() {

        Session s = (Session) entityManager.unwrap(Session.class);
        return s;
    }

}
