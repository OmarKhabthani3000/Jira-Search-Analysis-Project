package com.myapp.entities;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Transient;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;

import com.nucleus.core.annotations.Synonym;

/**
 *
 * @author Nucleus Software Exports Limited
 * Phone Number class
 *      Store std code, isd code, country code
 *      number type - mobile, landline
 */

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Indexed
@Synonym(grant="ALL")

public class PhoneNumber extends BaseEntity {

    public static final String STRIP_CHARS_REGEX = "[ -]";

    @Transient
    private static final long   serialVersionUID  = 1077720446849440270L;



    @Field(index = org.hibernate.search.annotations.Index.YES, analyze = Analyze.YES, store = Store.NO)
    private String              phoneNumber;


    /**
     * @return the phoneNumber
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * @param phoneNumber
     *            the phoneNumber to set
     */
    public void setPhoneNumber(String phoneNumber) {
        if (phoneNumber != null) {
            this.phoneNumber = phoneNumber.replaceAll(STRIP_CHARS_REGEX, "");
        } else {
            this.phoneNumber = phoneNumber;
        }
    }

}