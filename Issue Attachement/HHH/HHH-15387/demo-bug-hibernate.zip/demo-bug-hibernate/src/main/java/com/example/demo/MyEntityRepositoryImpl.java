package com.example.demo;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;


public class MyEntityRepositoryImpl implements MyEntityRepositoryCustom{

	@Autowired
	private EntityManager entityManager;

	@Override
	public MyEntity findByName(final String name) {
		// 1st level cache work with NaturalId and avoid query
		return entityManager.unwrap(Session.class)
				.bySimpleNaturalId(MyEntity.class)
				.load(name);
	}
}
