package com.example.demo;

public interface MyEntityRepositoryCustom {

	MyEntity findByName(String name);
}
