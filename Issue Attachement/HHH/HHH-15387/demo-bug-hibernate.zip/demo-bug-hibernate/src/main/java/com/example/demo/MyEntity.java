package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

import org.hibernate.annotations.NaturalId;

@Entity
@Table(name="TABLE_A")
@SecondaryTable(name="TABLE_B",pkJoinColumns = {
		@PrimaryKeyJoinColumn(name = "id_enfant", referencedColumnName = "id") })
public class MyEntity {

	@Id
	private Long id;
	
	@NaturalId
	@Column(name = "name", unique = true, table = "TABLE_B")
	private String name;
}
