package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;
import org.hibernate.entities.Event;
import org.hibernate.entities.EventType;
import org.hibernate.entities.EventTypeQuery;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase
{

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init()
    {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy()
    {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh18356Test() throws Exception
    {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        EventType eventType = new EventType();
        eventType.setName("eventType");
        entityManager.persist(eventType);

        Event event1 = new Event();
        event1.setEventType(eventType);
        entityManager.persist(event1);

        Event event2 = new Event();
        event2.setEventType(eventType);
        entityManager.persist(event2);

        try
        {
            Query query = entityManager.createQuery("FROM EventTypeQuery e", EventTypeQuery.class);
            List<EventTypeQuery> eventTypes = query.getResultList();

            assertEquals(1, eventTypes.size());
            assertEquals(2, eventTypes.get(0).getNbEvents());
        } finally
        {
            entityManager.getTransaction().commit();
            entityManager.close();
        }
    }

}
