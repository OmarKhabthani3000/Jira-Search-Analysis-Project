package org.hibernate.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.Formula;

@Entity
@Table(name = "EventType")
public class EventTypeQuery extends BaseEventType
{

    @Id
    @Column(nullable = false, insertable = false, updatable = false)
    private int id;

    @Formula("(SELECT COUNT(*) FROM Event e INNER JOIN EventType et ON e.eventTypeId = et.id WHERE et.id = id)")
    private long nbEvents;

    public EventTypeQuery()
    {

    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public long getNbEvents()
    {
        return nbEvents;
    }

    public void setNbEvents(long nbEvents)
    {
        this.nbEvents = nbEvents;
    }
}
