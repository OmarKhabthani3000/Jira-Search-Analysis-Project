package hibernatetest;

import java.io.Serializable;
import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.junit.jupiter.api.Test;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
class A implements Serializable {
    private static final long serialVersionUID = -5412503864464287451L;
    @Id @GeneratedValue long id;
    @ManyToOne B b;
}

@Entity
class B implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id @GeneratedValue long id;
    @ManyToOne C c;
}

@Entity
class C implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id @GeneratedValue long id;
}

public class BadQueryGenerationTest {
    @Test
    public void test() {
        Transaction txn = null;
        final SessionFactory sessionFactory = newSessionFactory();
        try (final Session session = sessionFactory.openSession()) {
            txn = session.beginTransaction();
            // Simplest non working query with exists
            final Query<A> q1 = session.createQuery("select a.id from A a where exists (select b.id from B b where a.b.c.id = 5)", A.class);
            q1.list();

            // Simplest non working query with in
            final Query<A> q2 = session.createQuery("select a.id from A a where a.id in (select b.id from B b where a.b.c.id > 5)", A.class);
            q2.list();

            // More realistic non working query
            final Query<A> q = session.createQuery("select a.id from A a where exists (select a2.id from A a2 where a.id<>a2.id and a.b.c.id = a2.b.c.id)", A.class);
            q.list();

            txn.rollback();
        }
    }

    protected SessionFactory newSessionFactory() {
        final Properties properties = new Properties();
        // log settings
        properties.put("hibernate.hbm2ddl.auto", "create");
        properties.put("hibernate.show_sql", "true");
        // driver settings
        properties.put("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        properties.put("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        properties.put("hibernate.connection.url", "jdbc:hsqldb:mem:tsg");
        properties.put("hibernate.connection.username", "sa");
        properties.put("hibernate.connection.password", "");

        return new Configuration().addProperties(properties)
                                  .addAnnotatedClass(A.class)
                                  .addAnnotatedClass(B.class)
                                  .addAnnotatedClass(C.class)
                                  .buildSessionFactory(new StandardServiceRegistryBuilder().applySettings(properties).build());
    }
}
