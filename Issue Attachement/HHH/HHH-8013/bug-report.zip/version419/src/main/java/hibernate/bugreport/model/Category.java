package hibernate.bugreport.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Category implements Serializable {
	private static final long serialVersionUID = 1L;
	private int id;
	@Id
	private String uuid;
	@Column(name="CatNam")
	private String categoryName;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="cid", referencedColumnName="id", nullable=false)
	private Set<Item> items = new HashSet<Item>();
	public int getId() {
		return id;
	}
	public String getUuid() {
		return uuid;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public Set<Item> getItems() {
		return items;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public void setItems(Set<Item> items) {
		this.items = items;
	}
}
