package hibernate.bugreport.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Item implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(insertable=false, updatable=false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int itemId;
	private String itemName;
	public int getItemId() {
		return itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	
}
