package hibernate.bugreport.repos.specs;

import hibernate.bugreport.model.Category;

import org.springframework.data.repository.CrudRepository;

public interface CategoryRepository extends CrudRepository<Category, String> {

}
