package hibernate.bugreport.tests;

import javax.sql.DataSource;

import hibernate.bugreport.model.Category;
import hibernate.bugreport.model.Item;
import hibernate.bugreport.repos.specs.CategoryRepository;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ContextConfiguration("classpath:test-context.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class ReferencedColumnNameTest {
	@Autowired
	private CategoryRepository categoryRepo;
	@Autowired
	private DataSource dataSource;
	@Test
	public void testScenario() {
		Category cat = new Category();
		cat.setCategoryName("CATEGORY ONE");
		cat.setId(100);
		cat.setUuid("someuuidvalue");
		Item one = new Item();
		one.setItemName("ITEM 1");
		cat.getItems().add(one);
		Item two = new Item();
		one.setItemName("ITEM 2");
		cat.getItems().add(two);
		Category saved = categoryRepo.save(cat);
		
	}
}
