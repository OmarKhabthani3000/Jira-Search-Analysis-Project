package org.hibernate.bugs.entities;

public enum ResourceTypeEnum
{

    RESOURCE("Risorsa"),

    FOLDER("Folder");

    private String value;

    private ResourceTypeEnum(String value)
    {
        this.value = value;
    }

    public String getValue()
    {
        return value;
    }

    public String getName()
    {
        return name();
    }
}
