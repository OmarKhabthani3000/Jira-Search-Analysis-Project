package org.hibernate.bugs.entities;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "WORKSPACE_RESOURCE")
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING)
public class Resource
{

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_WORKSPACE_RESOURCE")
    @GenericGenerator(name = "SEQ_WORKSPACE_RESOURCE", strategy = "sequence-identity", //
            parameters = {@Parameter(name = "sequence", value = "SEQ_WORKSPACE_RESOURCE")})
    @Column(name = "ID_WORKSPACE_RESOURCE", nullable = false, precision = 18)
    private Long id;

    @Column(name = "NAME", nullable = false, length = 256)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "RESOURCE_TYPE", nullable = false, length = 20)
    private ResourceTypeEnum type;

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public ResourceTypeEnum getType()
    {
        return type;
    }

    public void setType(ResourceTypeEnum type)
    {
        this.type = type;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode()
    {
        return new HashCodeBuilder(1635525453, 1528533943)
            .append(id)
            .append(name)
            .append(type)
            .toHashCode();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object object)
    {
        if (!(object instanceof Resource))
        {
            return false;
        }
        Resource rhs = (Resource) object;
        EqualsBuilder equalsBuilder = new EqualsBuilder()
            .append(id, rhs.id)
            .append(name, rhs.name)
            .append(type, rhs.type);
        return equalsBuilder.isEquals();
    }
}
