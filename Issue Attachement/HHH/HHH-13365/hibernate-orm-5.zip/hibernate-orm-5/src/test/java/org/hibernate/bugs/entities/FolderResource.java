package org.hibernate.bugs.entities;

import java.io.Serializable;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "WORKSPACE_RESOURCE_FOLDER")
@PrimaryKeyJoinColumn(name = "ID_WORKSPACE_RESOURCE_FOLDER")
@DiscriminatorValue("FOLDER")
public class FolderResource extends Resource implements Serializable
{

    private static final long serialVersionUID = 4423100311137510777L;

    public FolderResource()
    {
        super();
        setType(ResourceTypeEnum.FOLDER);
    }

}
