/**
 *
 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author sridhar
 *
 */
public class AppContext {
	private static AppContext appCtx = null;
	private static ClassPathXmlApplicationContext context = null;

	private AppContext() {
		context = new ClassPathXmlApplicationContext("applicationContext.xml");
	}

	public static ApplicationContext getContext() {
		if (appCtx == null) {
			appCtx = new AppContext();
		}
		return context;
	}
}
