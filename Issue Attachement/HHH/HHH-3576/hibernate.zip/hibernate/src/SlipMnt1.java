/**
 *
 */
import java.io.Serializable;

/**
 * @author sridhar
 *
 */
public class SlipMnt1 implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -3188364790573401027L;
	private	int		factsPin;
	private int		digitNo;
	private String	gender;
	private String	agencyID;
	private int		rows;
	private int		columns;
	private int		factsPinDigit;
	private	byte[]	mnt;
	private	int		mntSize;
	private	int		compressionFormat;
	/**
	 * @return the factsPin
	 */
	public int getFactsPin() {
		return factsPin;
	}
	/**
	 * @param factsPin the factsPin to set
	 */
	public void setFactsPin(int factsPin) {
		this.factsPin = factsPin;
	}
	/**
	 * @return the digitNo
	 */
	public int getDigitNo() {
		return digitNo;
	}
	/**
	 * @param digitNo the digitNo to set
	 */
	public void setDigitNo(int digitNo) {
		this.digitNo = digitNo;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the agencyID
	 */
	public String getAgencyID() {
		return agencyID;
	}
	/**
	 * @param agencyID the agencyID to set
	 */
	public void setAgencyID(String agencyID) {
		this.agencyID = agencyID;
	}
	/**
	 * @return the rows
	 */
	public int getRows() {
		return rows;
	}
	/**
	 * @param rows the rows to set
	 */
	public void setRows(int rows) {
		this.rows = rows;
	}
	/**
	 * @return the columns
	 */
	public int getColumns() {
		return columns;
	}
	/**
	 * @param columns the columns to set
	 */
	public void setColumns(int columns) {
		this.columns = columns;
	}
	/**
	 * @return the factsPinDigit
	 */
	public int getFactsPinDigit() {
		return factsPinDigit;
	}
	/**
	 * @param factsPinDigit the factsPinDigit to set
	 */
	public void setFactsPinDigit(int factsPinDigit) {
		this.factsPinDigit = factsPinDigit;
	}
	/**
	 * @return the mnt
	 */
	public byte[] getMnt() {
		return mnt;
	}
	/**
	 * @param mnt the mnt to set
	 */
	public void setMnt(byte[] mnt) {
		this.mnt = mnt;
	}
	/**
	 * @return the mntSize
	 */
	public int getMntSize() {
		return mntSize;
	}
	/**
	 * @param mntSize the mntSize to set
	 */
	public void setMntSize(int mntSize) {
		this.mntSize = mntSize;
	}
	/**
	 * @return the compressionFormat
	 */
	public int getCompressionFormat() {
		return compressionFormat;
	}
	/**
	 * @param compressionFormat the compressionFormat to set
	 */
	public void setCompressionFormat(int compressionFormat) {
		this.compressionFormat = compressionFormat;
	}


}
