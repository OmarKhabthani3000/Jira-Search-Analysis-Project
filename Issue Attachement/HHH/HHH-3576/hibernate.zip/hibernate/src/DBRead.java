import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;

import org.hibernate.HibernateException;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author sridhar
 *
 */
public class DBRead extends HibernateDaoSupport {

	private SessionFactory sessionFactory = null;
	private String mntFile = "./src/apsite_l_rp1.txt";

	@SuppressWarnings("unchecked")
	public void readOrclDB() {


		Timestamp start = new Timestamp(Calendar.getInstance()
				.getTimeInMillis());


		getHibernateTemplate().execute(new HibernateCallback(){
			@Override
			public Object doInHibernate(Session session)
					throws HibernateException, SQLException {
				SlipMnt slip = null;
				ScrollableResults results = session.createQuery("from SlipMnt").scroll(ScrollMode.SCROLL_INSENSITIVE);

				while(results.next()){
					slip = (SlipMnt)results.get(0);
					//session.evict(slip);
					session.clear();
				}
				return null;
			}

		});
		Timestamp end = new Timestamp(Calendar.getInstance().getTimeInMillis());
		System.out.println(start);
		System.out.println(end);
		System.out.println(end.getTime() - start.getTime());

	}


	private byte[] buildMnt() throws IOException {
		FileInputStream fis = null;

		byte[] mnt = null;
		fis = new FileInputStream(new File(mntFile));
		int avail = fis.available();
		mnt = new byte[avail];
		System.out.println(avail);
		fis.read(mnt);
		return mnt;
	}


	public void populateDB()throws Exception{

		byte[] mnt = buildMnt();

		SlipMnt1 slip1 = new SlipMnt1();
		slip1 = new SlipMnt1();
		slip1.setAgencyID("CMC");
		slip1.setColumns(100);
		slip1.setCompressionFormat(1);
		slip1.setDigitNo(21);
		slip1.setGender("M");
		slip1.setMnt(mnt);
		slip1.setMntSize(100);
		slip1.setFactsPinDigit(21);
		slip1.setRows(100);

		SlipMnt1 slip2 = new SlipMnt1();
		slip2 = new SlipMnt1();
		slip2.setAgencyID("CMC");
		slip2.setColumns(100);
		slip2.setCompressionFormat(1);
		slip2.setDigitNo(23);
		slip2.setGender("M");
		slip2.setMnt(mnt);
		slip2.setMntSize(100);
		slip2.setFactsPinDigit(23);
		slip2.setRows(100);

		for (int i = 9499; i <= 9848; i++) {

			slip1.setFactsPin(i);
			slip2.setFactsPin(i);

			getHibernateTemplate().save(slip1);
			getHibernateTemplate().save(slip2);

		}
	}
	public static void main(String[] args) throws Exception {
		final ApplicationContext ctx = AppContext.getContext();
		final DBRead dbread = (DBRead) ctx.getBean("dbread");
		dbread.populateDB();
		dbread.readOrclDB();
	}
}
