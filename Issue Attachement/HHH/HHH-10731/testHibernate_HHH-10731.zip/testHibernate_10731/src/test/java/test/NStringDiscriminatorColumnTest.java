package test;

import static org.junit.Assert.assertEquals;

import org.hibernate.Session;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.persister.entity.JoinedSubclassEntityPersister;
import org.hibernate.testing.TestForIssue;
import org.hibernate.testing.junit4.BaseNonConfigCoreFunctionalTestCase;
import org.hibernate.type.StringNVarcharType;
import org.junit.Test;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

/**
 * Test that String type discriminator column is nationalized
 */
public class NStringDiscriminatorColumnTest extends BaseNonConfigCoreFunctionalTestCase {

  @Override
  protected Class<?>[] getAnnotatedClasses() {
    return new Class[] { TestEntity.class, TestOneEntity.class };
  }

  @SuppressWarnings({ "rawtypes", "unchecked" })
  @Override
  protected void addSettings(Map settings) {
    settings.put(AvailableSettings.USE_NATIONALIZED_CHARACTER_DATA, true);
    // FIXME explicit connection settings are used for local testing
    settings.put(AvailableSettings.DRIVER, "com.microsoft.sqlserver.jdbc.SQLServerDriver");
    settings.put(AvailableSettings.URL,
        "jdbc:sqlserver://localhost:1433;databaseName=blueriq_runtime_10;instance=SQLEXPRESS");
    settings.put(AvailableSettings.USER, "blueriq10");
    settings.put(AvailableSettings.PASS, "Welcome");
  }

  @Test
  @TestForIssue(jiraKey = "HHH-10731")
  public void testForNationalizedStringDiscriminatorColumn() {
    Session session = openSession();

    JoinedSubclassEntityPersister testOneMetadata =
        (JoinedSubclassEntityPersister) session.getSessionFactory().getClassMetadata(TestOneEntity.class);
    // Expecting NVARCHAR because USE_NATIONALIZED_CHARACTER_DATA=true
    assertEquals(StringNVarcharType.INSTANCE, testOneMetadata.getPropertyType("testOtherString"));
    assertEquals(StringNVarcharType.INSTANCE, testOneMetadata.getPropertyType("testType"));
    // Expecting also NVARCHAR
    assertEquals(StringNVarcharType.INSTANCE, testOneMetadata.getDiscriminatorType());
  }

  @Entity
  @Table(name = "Test")
  @Inheritance(strategy = InheritanceType.JOINED)
  @DiscriminatorColumn(name = "testType", discriminatorType = DiscriminatorType.STRING, length = 10)
  public static abstract class TestEntity {
    @GeneratedValue
    @Id
    private Integer id;

    @Column(insertable = false, updatable = false)
    private String testType;
  }

  @Entity
  @Table(name = "TestType1")
  @DiscriminatorValue("type1")
  public static class TestOneEntity extends TestEntity {
    @Column
    private String testOtherString;
  }

}
