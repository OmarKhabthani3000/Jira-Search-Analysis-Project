package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "SIMPLE")
public class Simple {

	@Id
	@GeneratedValue
	private Integer id;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	private Integer maxRam;
	public Integer getMaxRam() { return maxRam;}
	public void setMaxRam(Integer maxRam) { this.maxRam = maxRam;}

}
