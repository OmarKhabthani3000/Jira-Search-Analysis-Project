package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void regressionSelect() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.createQuery("SELECT :ram FROM Simple s WHERE :ram < s.maxRam")
				.setParameter("ram", 2)
				.getResultList();
		entityManager.getTransaction().commit();
		entityManager.close();
	}

	@Test
	public void variantWorkingSelect() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.createQuery("SELECT s FROM Simple s WHERE :ram < s.maxRam")
				.setParameter("ram", 2)
				.getResultList();
		entityManager.createQuery("SELECT :ram FROM Simple s WHERE :ram2 < s.maxRam")
				.setParameter("ram", 2).setParameter("ram2", 2)
				.getResultList();
		entityManager.getTransaction().commit();
		entityManager.close();
	}}
