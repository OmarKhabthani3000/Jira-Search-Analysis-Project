package hhh10601;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Test;

public class HHH10601Test {

    @Test
    public void test() throws Exception {

        Map properties = new HashMap();

        properties.put("javax.persistence.transactionType", "RESOURCE_LOCAL");
        properties.put("javax.persistence.jtaDataSource", null);
        properties.put("javax.persistence.nonJtaDataSource", null);
        properties.put("javax.persistence.validation.mode", "NONE");

        properties.put("javax.persistence.jdbc.driver", "org.hsqldb.jdbcDriver");
        properties.put("javax.persistence.jdbc.url", "jdbc:hsqldb:mem:testdb");
        properties.put("javax.persistence.jdbc.user", "");
        properties.put("javax.persistence.jdbc.password", "");

        properties.put("javax.persistence.database-product-name", "HSQL Database Engine");
        properties.put("javax.persistence.database-major-version", "");
        properties.put("javax.persistence.database-minor-version", "");

        properties.put("javax.persistence.schema-generation.scripts.action", "drop-and-create");
        properties.put("javax.persistence.schema-generation.scripts.drop-target", "target/drop.sql");
        properties.put("javax.persistence.schema-generation.scripts.create-target", "target/create.sql");

        // hibernate delimiter
        properties.put("hibernate.hbm2ddl.delimiter", ";");

        Persistence.generateSchema("org.hibernate.test", properties);

        
        // check duplicated lines in the target/create.sql
        boolean hasDuplicate;
        String line = null;
        try (BufferedReader list = new BufferedReader(new FileReader("target/create.sql"))) {
            hasDuplicate = false;
            Set<String> lines = new HashSet<String>();
            while (!hasDuplicate && (line = list.readLine()) != null) {
                line.trim();
                System.out.println("Line:" + line);
                if (!line.isEmpty()) {
                    hasDuplicate = lines.contains(line);
                    if (hasDuplicate) {
                    }
                    lines.add(line);
                }
            }
        }
        Assert.assertFalse("The target/create.sql file containts two lines -> '" + line + "'", hasDuplicate);
       
        
    }

}
