package org.ginger.hiberevolvetest;

import org.ginger.hiberevolvetest.model.AnEntity;
import org.ginger.hiberevolvetest.model.AnotherEntity;
import org.ginger.hiberevolvetest.model.ThirdEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HiberEvolveTest {
	private static SessionFactory sessionFactory;
	
	public static void main(String[] args) {
		try {
			main();
		}
		finally {
			if (sessionFactory != null) {
				sessionFactory.close();
			}
		}
	}
	private static void main() {
		System.out.println("STARTING TEST ... LOADING SESSION FACTORY ...");
		
		sessionFactory = new Configuration().configure().buildSessionFactory();
		
		System.out.println("... SESSION FACTORY LOADED ...");

		Work work = new Work() {
			public void work(Session sess) {
				AnEntity anEnt = new AnEntity();
				AnotherEntity anoEnt = new AnotherEntity();
				ThirdEntity thrdEnt = new ThirdEntity();
				
				anEnt.setTitle("Mister");
				anEnt.setMyThirdEntity(thrdEnt);
				anoEnt.setOrderid("O00987");
				thrdEnt.setSessionid("s8dd9ujv89998y");
				thrdEnt.setMyAnEntity(anEnt);
				
				sess.save(anEnt);
				sess.save(anoEnt);
				sess.save(thrdEnt);

			}
		};
		transact(work);

		System.out.println("... ENTITIES CREATED ...");
		
		sessionFactory.close();
		
		System.out.println("... DONE!");
	}
	
	public static void transact(Work work) {
		Session sess = sessionFactory.openSession();
		Transaction tx = sess.beginTransaction();
		work.work(sess);
		tx.commit();
		sess.close();
	}
	
	
	interface Work {
		void work(Session sess);
	}
}
