package org.ginger.hiberevolvetest.model;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ANOENTITY")
@Access(AccessType.FIELD)
public class AnotherEntity {
	@Id
	@GeneratedValue
	private int entid;

	private String orderid;

	public AnotherEntity() {
		// TODO Auto-generated constructor stub
	}

	public int getEntid() {
		return entid;
	}

	public void setEntid(int entid) {
		this.entid = entid;
	}

	public String getOrderid() {
		return orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	
}
