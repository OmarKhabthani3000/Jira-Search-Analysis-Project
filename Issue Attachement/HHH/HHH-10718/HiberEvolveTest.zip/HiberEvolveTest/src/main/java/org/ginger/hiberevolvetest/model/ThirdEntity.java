package org.ginger.hiberevolvetest.model;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="ANOENTITY")
@Access(AccessType.FIELD)
public class ThirdEntity {
	@Id
	@GeneratedValue
	private int entid;

	private String sessionid;
	
	@OneToOne
	private AnEntity myAnEntity;

	public ThirdEntity() {
		// TODO Auto-generated constructor stub
	}

	public int getEntid() {
		return entid;
	}

	public void setEntid(int entid) {
		this.entid = entid;
	}

	public String getSessionid() {
		return sessionid;
	}

	public void setSessionid(String sessionid) {
		this.sessionid = sessionid;
	}

	public AnEntity getMyAnEntity() {
		return myAnEntity;
	}

	public void setMyAnEntity(AnEntity myAnEntity) {
		this.myAnEntity = myAnEntity;
	}
	
}
