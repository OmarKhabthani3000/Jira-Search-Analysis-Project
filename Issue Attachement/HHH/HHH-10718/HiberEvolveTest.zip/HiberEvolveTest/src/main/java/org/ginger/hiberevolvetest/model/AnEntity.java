package org.ginger.hiberevolvetest.model;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="AN_ENTITY")
@Access(AccessType.FIELD)
public class AnEntity {
	@Id
	@GeneratedValue
	private int entid;

	private String title;
	
	@OneToOne
	private ThirdEntity myThirdEntity;

	public AnEntity() {
		// TODO Auto-generated constructor stub
	}

	public int getEntid() {
		return entid;
	}

	public void setEntid(int entid) {
		this.entid = entid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public ThirdEntity getMyThirdEntity() {
		return myThirdEntity;
	}

	public void setMyThirdEntity(ThirdEntity myThirdEntity) {
		this.myThirdEntity = myThirdEntity;
	}
	
}
