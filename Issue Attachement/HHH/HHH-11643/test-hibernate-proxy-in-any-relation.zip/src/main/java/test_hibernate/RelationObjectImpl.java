package test_hibernate;

public class RelationObjectImpl
{
//    private AbstractGroup relation;
    private GroupImpl relation;

    private Long objectId;

    public Long getObjectId()
    {
        return objectId;
    }

    public void setObjectId(Long objectId)
    {
        this.objectId = objectId;
    }

    public GroupImpl getRelation()
    {
        return relation;
    }

    public void setRelation(GroupImpl relation)
    {
        this.relation = relation;
    }
}
