package test_hibernate;

public class RiskValidationImpl
{
    private AbstractGroup group;

    private Long objectId;

    public Long getObjectId()
    {
        return objectId;
    }

    public void setObjectId(Long objectId)
    {
        this.objectId = objectId;
    }

    public AbstractGroup getGroup()
    {
        return group;
    }

    public void setGroup(AbstractGroup group)
    {
        this.group = group;
    }
}
