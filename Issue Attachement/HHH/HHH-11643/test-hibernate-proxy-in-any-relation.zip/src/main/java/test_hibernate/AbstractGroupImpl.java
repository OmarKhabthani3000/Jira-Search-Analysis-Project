package test_hibernate;

public abstract class AbstractGroupImpl implements AbstractGroup
{
    private Long objectId;

    public Long getObjectId()
    {
        return objectId;
    }

    public void setObjectId(Long objectId)
    {
        this.objectId = objectId;
    }
}
