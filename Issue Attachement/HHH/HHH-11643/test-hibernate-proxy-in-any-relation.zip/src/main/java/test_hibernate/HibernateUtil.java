package test_hibernate;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateUtil
{
    private static SessionFactory sessionFactory;

    private static SessionFactory buildSessionFactoryFor_5_2_9()
    {
        // configure() configures settings from hibernate.cfg.xml
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure().build();
        try
        {
            if (sessionFactory == null)
            {
                sessionFactory = new MetadataSources(registry).buildMetadata().buildSessionFactory();
            }
            return sessionFactory;
        }
        catch (Exception e)
        {
            // The registry would be destroyed by the SessionFactory, but we had trouble building the SessionFactory
            // so destroy it manually.
            StandardServiceRegistryBuilder.destroy(registry);
            throw new ExceptionInInitializerError(e);
        }
    }

    public static SessionFactory getSessionFactoryFor_5_2_9()
    {
        buildSessionFactoryFor_5_2_9();
        return sessionFactory;
    }

    public static void shutdown()
    {
        sessionFactory.close();
        sessionFactory = null;
    }

    //    public static SessionFactory getSessionFactoryFor_4_3_11()
    //    {
    //        buildSessionFactoryFor_4_3_11();
    //        return sessionFactory;
    //    }

    //    private static SessionFactory buildSessionFactoryFor_4_3_11()
    //    {
    //        try
    //        {
    //            if (sessionFactory == null)
    //            {
    //                Configuration configuration = new Configuration().configure(HibernateUtil.class.getResource("/hibernate.cfg.xml"));
    //                StandardServiceRegistryBuilder serviceRegistryBuilder = new StandardServiceRegistryBuilder();
    //                serviceRegistryBuilder.applySettings(configuration.getProperties());
    //                ServiceRegistry serviceRegistry = serviceRegistryBuilder.build();
    //                sessionFactory = configuration.buildSessionFactory(serviceRegistry);
    //            }
    //            return sessionFactory;
    //        }
    //        catch (Throwable ex)
    //        {
    //            System.err.println("Initial SessionFactory creation failed." + ex);
    //            throw new ExceptionInInitializerError(ex);
    //        }
    //    }
}
