package test_hibernate;

public interface AbstractGroup
{
}
