package test_hibernate;

public class GroupImpl extends AbstractGroupImpl
{
}
