package test_hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.proxy.HibernateProxy;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;

public class RetrieveFromHibernateWithProxyObjectInEqualsCriterionInAnyRelationTest
{
    private SessionFactory sessionFactory;
    private Session session;

    @Before
    public void setUp()
    {
        sessionFactory = HibernateUtil.getSessionFactoryFor_5_2_9();
        session = sessionFactory.openSession();

        GroupImpl group = createAndPersistGroup();
        createAndPersistRiskValidation(group);
        createAndPersistRelationObject(group);

        session.close();
        session = sessionFactory.openSession();
    }

    private GroupImpl createAndPersistGroup()
    {
        GroupImpl group = new GroupImpl();
        group.setObjectId(1L);
        session.save(group);
        session.persist(group);
        return group;
    }

    private void createAndPersistRiskValidation(GroupImpl group)
    {
        RiskValidationImpl bwRiskValidation = new RiskValidationImpl();
        bwRiskValidation.setObjectId(1L);
        bwRiskValidation.setGroup(group);
        session.save(bwRiskValidation);
        session.persist(bwRiskValidation);
    }

    private void createAndPersistRelationObject(GroupImpl group)
    {
        RelationObjectImpl relationObject = new RelationObjectImpl();
        relationObject.setObjectId(1L);
        relationObject.setRelation(group);
        session.save(relationObject);
        session.persist(relationObject);
    }

    private AbstractGroup retrieveGroupFromRiskValidation()
    {
        return session.get(RiskValidationImpl.class, 1L).getGroup();
    }

    private DetachedCriteria createCriteriaToRetrieveRelationObjectByGroup(AbstractGroup group)
    {
        Criterion relationCriterion = Restrictions.eq("relation", group);
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(RelationObjectImpl.class);
        detachedCriteria.add(relationCriterion);
        return detachedCriteria;
    }

    @After
    public void tearDown()
    {
        session.close();
        HibernateUtil.shutdown();
    }

    @Test
    public void givenCriteriaWithEqualsCriterionContainingProxyAbstractGroup_whenList_thenResultIsValid()
    {
        // given a group in the criteria that is a proxy
        AbstractGroup proxyAbstractGroup = retrieveGroupFromRiskValidation();
        DetachedCriteria detachedCriteria = createCriteriaToRetrieveRelationObjectByGroup(proxyAbstractGroup);
        Criteria executableCriteria = detachedCriteria.getExecutableCriteria(session);

        // when
        List list = executableCriteria.list();

        // then this fails due to proxy object
        assertEquals(1, list.size());
    }

    @Test
    public void givenCriteriaWithEqualsCriterionContainingUnproxyAbstractGroup_whenList_thenResultIsValid()
    {
        // given a group in the criteria that is NOT a proxy
        AbstractGroup proxyAbstractGroup = retrieveGroupFromRiskValidation();
        DetachedCriteria detachedCriteria = createCriteriaToRetrieveRelationObjectByGroup(proxyAbstractGroup);
        Criteria executableCriteria = detachedCriteria.getExecutableCriteria(session);
        ((HibernateProxy)proxyAbstractGroup).getHibernateLazyInitializer().getImplementation(); // <- here we perform the unproxy

        // when
        List list = executableCriteria.list();

        // then
        assertEquals(1, list.size());
    }

    @Test
    public void givenCriteriaWithEqualsCriterionContainingGroupImpl_whenList_thenResultIsValid()
    {
        // given a group
        AbstractGroup group = session.get(GroupImpl.class, 1L);
        DetachedCriteria detachedCriteria = createCriteriaToRetrieveRelationObjectByGroup(group);
        Criteria executableCriteria = detachedCriteria.getExecutableCriteria(session);

        // when
        List list = executableCriteria.list();

        // then
        assertEquals(1, list.size());
    }
}
