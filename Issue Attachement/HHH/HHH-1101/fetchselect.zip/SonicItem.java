//$Id: $
package org.hibernate.test.annotations.emmanuel;

import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratorType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Proxy;

/**
 * @author Emmanuel Bernard
 */
@Entity(access = AccessType.FIELD)
@Table(
		name = "SONIC_ITEM"
)
@Proxy(lazy = false)
public class SonicItem {

	@Id(generate = GeneratorType.IDENTITY)
	@Column(name = "SONIC_ITEM_PK")
	private Integer id;

	@Column(name = "OPT_LOCK")
	private Integer version;

	public SonicItem() {

	}

	public Integer getId() {
		return id;
	}


	public Integer getVersion() {
		return version;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

}
