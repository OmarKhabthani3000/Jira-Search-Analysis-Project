//$Id: $
package org.hibernate.test.annotations.emmanuel;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.annotations.TestCase;

/**
 * @author Emmanuel Bernard
 */
public class SonicTest extends TestCase {

	public void testQuery() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		SonicItem sonicItem = new SonicItem();
		s.persist( sonicItem );
		OuItem item = new OuItem();
		item.setSonicItem( sonicItem );
		s.persist( item );
		tx.commit();
		s.close();
		s = openSession();
		tx = s.beginTransaction();
		String hql = new StringBuilder().
				append( "select sonicItem" ).
				append( " from OuItem oi " ).
				append( "    left join  fetch oi.sonicItem sonicItem " ).
				toString();
		Query query = s.createQuery( hql );
		List results = query.list();
		tx.commit();
		s.close();

	}

	protected Class[] getMappings() {
		return new Class[]{
				OuItem.class,
				SonicItem.class
		};
	}
}
