//$Id: $
package org.hibernate.test.annotations.emmanuel;

import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratorType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.Proxy;

/**
 * @author Emmanuel Bernard
 */
@Entity(access = AccessType.FIELD)
@Table(
		name = "OU_ITEM"
//		schema = "ifc"
)
@Proxy(lazy = false)
public class OuItem
		//implements GenericEntity<Integer>
{
// ------------------------------ FIELDS ------------------------------

	@Id(generate = GeneratorType.IDENTITY)
	@Column(name = "OU_ITEM_PK")
	private Integer id;

	@Column(name = "OPT_LOCK")
	@Version
	private Integer version = 0;


	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "SONIC_ITEM_FK", nullable = false)
	private SonicItem sonicItem;

// --------------------------- CONSTRUCTORS ---------------------------

	public OuItem() {
	}


	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getId() {
		return id;
	}


	public SonicItem getSonicItem() {
		return sonicItem;
	}

	public Integer getVersion() {
		return version;
	}

	public void setSonicItem(SonicItem sonicItem) {
		this.sonicItem = sonicItem;
	}


	public void setVersion(Integer version) {
		this.version = version;
	}


}