package com.example.h6sample.services;

import java.util.List;

import com.example.h6sample.domain.C1Set;
import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import org.hibernate.Session;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = true)
public class C1SetService
{
    private final EntityManager entityManager;

    public C1SetService(EntityManager entityManager)
    {
        this.entityManager = entityManager;
    }

    public List<C1Set> list()
    {
        Session session = entityManager.unwrap(Session.class);

        CriteriaBuilder cb = session.getCriteriaBuilder();

        CriteriaQuery<C1Set> cq = cb.createQuery(C1Set.class);

        Root<C1Set> root = cq.from(C1Set.class);

        cq.select(root);

        return session.createQuery(cq).list();
    }

    public C1Set get(String uuid)
    {
        return entityManager.unwrap(Session.class).get(C1Set.class, uuid);
    }
}
