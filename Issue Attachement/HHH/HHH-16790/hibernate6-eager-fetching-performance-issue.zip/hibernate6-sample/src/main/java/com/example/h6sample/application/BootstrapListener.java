package com.example.h6sample.application;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.example.h6sample.services.BootstrapService;

@Component
public class BootstrapListener
{
    private final BootstrapService bootstrapService;

    @Autowired
    public BootstrapListener(BootstrapService bootstrapService)
    {
        this.bootstrapService = bootstrapService;
    }

    @EventListener(ContextRefreshedEvent.class)
    public void onStartup()
    {
        bootstrapService.bootstrap();
    }
}
