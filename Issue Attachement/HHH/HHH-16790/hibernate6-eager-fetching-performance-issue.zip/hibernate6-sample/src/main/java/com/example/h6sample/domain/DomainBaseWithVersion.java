package com.example.h6sample.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.Version;

@MappedSuperclass
@SuppressWarnings("squid:S2160")
public class DomainBaseWithVersion extends DomainBase
{
    @Schema(title = "Version of this object", description = "The current version of this object in database", requiredMode = Schema.RequiredMode.REQUIRED)
    @Version
    @SuppressWarnings("unused")
    protected long version;

    @SuppressWarnings("unused")
    protected DomainBaseWithVersion()
    {
        version = 0;
    }

    @SuppressWarnings("unused")
    public long getVersion()
    {
        return version;
    }

    @SuppressWarnings("unused")
    public void setVersion(long version)
    {
        this.version = version;
    }
}
