package com.example.h6sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class H6SampleApplication
{
    public static void main(String[] args)
    {
        SpringApplication.run(H6SampleApplication.class, args);
    }
}
