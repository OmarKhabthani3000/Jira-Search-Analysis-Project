package com.example.h5sample.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

@MappedSuperclass
@SuppressWarnings("squid:S2160")
public class DomainBaseWithVersion extends DomainBase
{
    @Schema(title = "Version of this object", description = "The current version of this object in database", required = true)
    @Version
    @SuppressWarnings("unused")
    protected long version;

    @SuppressWarnings("unused")
    protected DomainBaseWithVersion()
    {
        version = 0;
    }

    @SuppressWarnings("unused")
    public long getVersion()
    {
        return version;
    }

    @SuppressWarnings("unused")
    public void setVersion(long version)
    {
        this.version = version;
    }
}
