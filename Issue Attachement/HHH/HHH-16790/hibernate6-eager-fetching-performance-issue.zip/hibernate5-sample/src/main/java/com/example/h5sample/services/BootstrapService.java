package com.example.h5sample.services;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashSet;

import com.example.h5sample.domain.C1;
import com.example.h5sample.domain.C1Set;
import com.example.h5sample.domain.Ca;
import com.example.h5sample.domain.Ca_;
import com.example.h5sample.domain.Cr;
import com.example.h5sample.domain.Kp;
import com.example.h5sample.domain.KpSet;
import com.example.h5sample.domain.Pk;
import com.example.h5sample.domain.Ra;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = true)
public class BootstrapService
{
    private static final Logger logger = LoggerFactory.getLogger(BootstrapService.class);

    private static final int NO_OF_C1SETS_TO_CREATE = 200;

    private final SecureRandom secureRandom = new SecureRandom();
    private final EntityManager entityManager;

    public BootstrapService(EntityManager entityManager)
    {
        this.entityManager = entityManager;
    }

    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
    public void bootstrap()
    {
        Session session = entityManager.unwrap(Session.class);

        CriteriaBuilder cb = session.getCriteriaBuilder();

        CriteriaQuery<String> cq = cb.createQuery(String.class);

        Root<Ca> root = cq.from(Ca.class);

        cq.select(root.get(Ca_.uuid));

        if (!session.createQuery(cq).setMaxResults(1).list().isEmpty())
        {
            return;
        }

        logger.info("Creating {} C1Sets ...", NO_OF_C1SETS_TO_CREATE);

        Ca[] cas = insertCas(session);
        Ra[] ras = insertRas(session, cas);
        KpSet[] kpSets = insertKpSets(session);
        insertC1Sets(session, cas, ras, kpSets);

        logger.info("{} C1Sets created", NO_OF_C1SETS_TO_CREATE);
    }

    private Ca[] insertCas(Session session)
    {
        Ca[] cas = new Ca[10];

        for (int i = 0; i < cas.length; ++i)
        {
            byte[] bytes = new byte[1000];

            secureRandom.nextBytes(bytes);

            var ca = new Ca();

            ca.setName("ca" + i);
            ca.setLob(Base64.getEncoder().encodeToString(bytes));

            session.persist(ca);

            cas[i] = ca;
        }

        return cas;
    }

    private Ra[] insertRas(Session session, Ca[] cas)
    {
        Ra[] ras = new Ra[5];

        for (int i = 0; i < ras.length; ++i)
        {
            var ra = new Ra();

            ra.setName("ra" + i);
            ra.setCa(new HashSet<>(2));

            ra.getCa().add(cas[2 * i]);
            ra.getCa().add(cas[2 * i + 1]);

            session.persist(ra);

            ras[i] = ra;
        }

        return ras;
    }

    private KpSet[] insertKpSets(Session session)
    {
        KpSet[] kpSets = new KpSet[NO_OF_C1SETS_TO_CREATE];

        for (int i = 0; i < kpSets.length; ++i)
        {
            KpSet kpSet = new KpSet();

            kpSet.setName("kpSet" + i);
            kpSet.setKps(new HashSet<>(3));

            for (int j = 0; j < 3; ++j)
            {
                byte[] bytes = new byte[200];

                secureRandom.nextBytes(bytes);

                Kp kp = new Kp();

                kp.setName("kpSet" + i + "kp" + j);
                kp.setPk(new Pk());

                kp.getPk().setName("kpSet" + i + "pk" + j);
                kp.getPk().setLob(Base64.getEncoder().encodeToString(bytes));
                kp.getPk().setKp(kp);

                kp.setKpSet(kpSet);

                kpSet.getKps().add(kp);
            }

            session.persist(kpSet);

            kpSets[i] = kpSet;
        }

        return kpSets;
    }

    private void insertC1Sets(Session session, Ca[] cas, Ra[] ras, KpSet[] kpSets)
    {
        for (int i = 0; i < kpSets.length; ++i)
        {
            KpSet kpSet = kpSets[i];

            Kp[] kps = kpSet.getKps().toArray(new Kp[0]);

            C1Set c1Set = new C1Set();

            c1Set.setName("c1Set" + i);
            c1Set.setCa(cas[i % cas.length]);
            c1Set.setKpSet(kpSet);
            c1Set.setC1s(new HashSet<>(3));

            byte[] bytes = new byte[3000];

            secureRandom.nextBytes(bytes);

            Cr cr = new Cr();

            cr.setRa(ras[i % ras.length]);
            cr.setLob(Base64.getEncoder().encodeToString(bytes));

            session.persist(cr);

            for (Kp kp : kps)
            {
                bytes = new byte[200];

                secureRandom.nextBytes(bytes);

                C1 c1 = new C1();

                c1.setLob(Base64.getEncoder().encodeToString(bytes));
                c1.setPk(kp.getPk());

                c1.getPk().setC1(c1);

                c1.getPk().setCr(cr);

                c1.setC1Set(c1Set);

                c1Set.getC1s().add(c1);
            }

            kpSet.setC1Set(c1Set);

            session.persist(c1Set);
        }
    }
}
