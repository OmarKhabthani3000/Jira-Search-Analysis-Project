package com.example.h5sample.controllers;

import java.util.List;

import com.example.h5sample.domain.C1Set;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.h5sample.services.C1SetService;

@RestController
@RequestMapping("/c1sets")
public class C1SetController
{
    private static final Logger logger = LoggerFactory.getLogger(C1SetController.class);

    private final C1SetService c1SetService;

    @Autowired
    public C1SetController(C1SetService c1SetService)
    {
        this.c1SetService = c1SetService;
    }

    @Operation(summary = "List all")
    @GetMapping(produces = "application/json")
    @SuppressWarnings("unused")
    public List<C1Set> listAll()
    {
        logger.info("Listing all C1Sets.");

        List<C1Set> c1Sets = c1SetService.list();

        logger.info("{} C1Sets found.", c1Sets.size());

        return c1Sets;
    }

    @Operation(summary = "Get one")
    @GetMapping(value = "/{uuid:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}}", produces = "application/json")
    @SuppressWarnings("unused")
    public C1Set get(@Parameter(description = "UUID of the requested C1Set object", required = true) @PathVariable("uuid") String uuid)
    {
        logger.info("Getting C1Set with uuid {}.", uuid);

        C1Set c1Set = c1SetService.get(uuid);

        logger.info("C1Set found: {}", c1Set);

        return c1Set;
    }
}
