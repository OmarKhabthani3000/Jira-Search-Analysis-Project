package org.hibernate.bugs;

import entity.Link;
import entity.Person;
import org.hibernate.Hibernate;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.HashMap;
import java.util.Map;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class EntityGraphTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		Person anna = createPerson("Anna");
		anna = entityManager.merge(anna);

		Person bob = createPerson("Bob");
		bob = entityManager.merge(bob);

		Person charlie = createPerson("Charlie");
		charlie = entityManager.merge(charlie);

		Person david = createPerson("David");
		david = entityManager.merge(david);

		addChild(bob, anna);
		addChild(charlie, bob);
		addChild(david, bob);

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		// find without entity graph'
		Person bob0 = getDetachedEntityById(Person.class, 2);
		Assert.assertFalse("Without Graph, parent links should not be loaded", Hibernate.isInitialized(bob0.getParents()));
		Assert.assertFalse("Without Graph, child links should not be loaded", Hibernate.isInitialized(bob0.getChildren()));

		// find using entity graph 'graph.Person.Ancestor'
		Person bob1 = getDetachedEntityByIdWithGraph(Person.class, 2, "graph.Person.Ancestor");
		for(Link link: bob1.getParents()) {
			Assert.assertTrue("With Graph.Person.Ancestor, parent should be loaded", Hibernate.isInitialized(link.getParent()));
			Assert.assertEquals("With Graph.Person.Ancestor, child of parent should be original object", link.getChild(), bob1);
		}

		// find using entity graph 'graph.Person.Descendant'
		Person bob2 = getDetachedEntityByIdWithGraph(Person.class, 2, "graph.Person.Descendant");
		for(Link link: bob2.getChildren()) {
			Assert.assertEquals("With Graph.Person.Descendant, parent of child should be original object", link.getParent(), bob2);
			Assert.assertTrue("With Graph.Person.Descendant, child should be loaded", Hibernate.isInitialized(link.getChild()));
		}

		// find using entity graph 'graph.Person'
		Person bob3 = getDetachedEntityByIdWithGraph(Person.class, 2, "graph.Person") ;
		for(Link link: bob3.getParents()) {
			Assert.assertTrue("With Graph.Person, parent in link should be loaded", Hibernate.isInitialized(link.getParent()));
			Assert.assertEquals("With Graph.Person, child of parent should be original object", link.getChild(), bob1);
		}
		for(Link link: bob3.getChildren()) {
			Assert.assertEquals("With Graph.Person, parent of child should be original object",link.getParent(), bob3);
			Assert.assertTrue("With Graph.Person, child in link should be loaded", Hibernate.isInitialized(link.getChild()));
		}

		entityManager.close();
	}

	// Helpers
	private Person createPerson(String name) {
		return new Person(name);
	}

	private Link addChild(Person child, Person parent) {
		Link link = new Link(parent, child);
		parent.getChildren().add(link);
		return link;
	}

	private <T> T getDetachedEntityById(Class<T> clazz, int id) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		T entity = entityManager.find(clazz, id);
		entityManager.detach(entity);

		entityManager.close();
		return entity;
	}

	private <T> T getDetachedEntityByIdWithGraph(Class<T> clazz, int id, String graphName) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		EntityGraph<?> graph = entityManager.getEntityGraph(graphName);
		Map<String, Object> hints = new HashMap<String, Object>();
		hints.put("javax.persistence.loadgraph", graph);
		T entity = entityManager.find(clazz, id, hints);
		entityManager.detach(entity);

		entityManager.close();
		return entity;
	}
}
