package entity;

import javax.persistence.*;

@Entity
public class Link {

    @Id
    @GeneratedValue
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    private Person parent;

    @ManyToOne(fetch = FetchType.LAZY)
    private Person child;

    // Constructors
    public Link() {
    }

    public Link(Person parent, Person child) {
        this.parent = parent;
        this.child = child;
    }

    // Accessors
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Person getParent() {
        return parent;
    }

    public void setParent(Person parent) {
        this.parent = parent;
    }

    public Person getChild() {
        return child;
    }

    public void setChild(Person child) {
        this.child = child;
    }
}
