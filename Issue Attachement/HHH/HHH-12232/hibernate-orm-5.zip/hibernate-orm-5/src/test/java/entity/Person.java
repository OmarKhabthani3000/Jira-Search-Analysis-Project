package entity;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@NamedEntityGraphs({
        @NamedEntityGraph(name = "graph.Person",
                attributeNodes = {
                        @NamedAttributeNode(value = "parents", subgraph = "parentGraph"),
                        @NamedAttributeNode(value = "children", subgraph = "childGraph")
                },
                subgraphs = {
                        @NamedSubgraph(name = "parentGraph", attributeNodes = {@NamedAttributeNode("parent"), @NamedAttributeNode("child")}),
                        @NamedSubgraph(name = "childGraph", attributeNodes = {@NamedAttributeNode("child"), @NamedAttributeNode("parent")}),
                }),
        @NamedEntityGraph(name = "graph.Person.Ancestor",
                attributeNodes = {
                        @NamedAttributeNode(value = "parents", subgraph = "parentGraph"),
                },
                subgraphs = {
                        @NamedSubgraph(name = "parentGraph", attributeNodes = {@NamedAttributeNode("parent"), @NamedAttributeNode("child")}),
                }),
        @NamedEntityGraph(name = "graph.Person.Descendant",
                attributeNodes = {
                        @NamedAttributeNode(value = "children", subgraph = "childGraph"),
                },
                subgraphs = {
                        @NamedSubgraph(name = "childGraph", attributeNodes = {@NamedAttributeNode("child"), @NamedAttributeNode("parent")}),
                })
})
public class Person {

    @Id
    @GeneratedValue
    private Integer id;

    private String name;

    @OneToMany(mappedBy = "child", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Link> parents = new HashSet<>();

    @OneToMany(mappedBy = "parent", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Link> children = new HashSet<>();

    // Constructors
    public Person() {
    }

    public Person(String name) {
        this.name = name;
    }

    // Accessors
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Link> getParents() {
        return parents;
    }

    public void setParents(Set<Link> parents) {
        this.parents = parents;
    }

    public Set<Link> getChildren() {
        return children;
    }

    public void setChildren(Set<Link> children) {
        this.children = children;
    }
}
