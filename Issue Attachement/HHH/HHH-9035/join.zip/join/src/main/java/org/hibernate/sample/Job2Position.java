package org.hibernate.sample;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

@Entity
@IdClass(Job2PositionId.class)
public class Job2Position {

    Long id;
    JobPositon pos;

    @Id
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Id
    @ManyToOne
    @JoinColumns({
        @JoinColumn(name = "`User+id`", referencedColumnName = "`User+id`", insertable = false, updatable = false),
        @JoinColumn(name = "`Position+id`", referencedColumnName = "`Position+id`", insertable = false, updatable = false),
        @JoinColumn(name = "`JobPositon+id`", referencedColumnName = "`JobPositon+id`", insertable = false, updatable = false),
    })
    public JobPositon getPos() {
        return this.pos;
    }

    public void setPos(JobPositon pos) {
        this.pos = pos;
    }

}
