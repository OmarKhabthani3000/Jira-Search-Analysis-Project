package org.hibernate.sample;

import java.io.Serializable;

public class Job2PositionId implements Serializable {

    private static final long serialVersionUID = 1L;
    Long id;
    JobPositionId pos;

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public JobPositionId getPos() {
        return this.pos;
    }

    public void setPos(JobPositionId pos) {
        this.pos = pos;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());
        result = prime * result + ((this.pos == null) ? 0 : this.pos.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Job2PositionId other = (Job2PositionId) obj;
        if (this.id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!this.id.equals(other.id)) {
            return false;
        }
        if (this.pos == null) {
            if (other.pos != null) {
                return false;
            }
        } else if (!this.pos.equals(other.pos)) {
            return false;
        }
        return true;
    }
}
