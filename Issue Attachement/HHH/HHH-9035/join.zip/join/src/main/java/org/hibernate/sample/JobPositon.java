package org.hibernate.sample;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "JOB+Position")
@IdClass(JobPositionId.class)
public class JobPositon {

    Long id;
    User user;
    Position2 position;

    Long positoinId;

    @Id
    @Column(name = "JobPositon+id")
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @ManyToOne
    @JoinColumn(name = "`User+id`", referencedColumnName = "`User+id`")
    @Id
    public User getUser() {
        return this.user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name = "`User+id`", referencedColumnName = "`User+id`", insertable = false, updatable = false),
        @JoinColumn(name = "`Position+id`", referencedColumnName = "`Position+id`", insertable = false, updatable = false),
    })
    public Position2 getPosition() {
        return this.position;
    }

    public void setPosition(Position2 position) {
        this.position = position;
    }

    /**
     * Mapping to go arround bug in hibernate
     * 
     * @return
     */
    @Id
    @Column(name = "Position+id")
    public Long getPositoinId() {
        return this.positoinId;
    }

    public void setPositoinId(Long positoinId) {
        this.positoinId = positoinId;
    }

}
