package org.hibernate.sample;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {

    private EntityManagerFactory emf;
    protected EntityManager em;

    @Before
    public void setUp() throws Exception {
        if (this.emf == null) {
            this.emf = Persistence.createEntityManagerFactory("test");
        }

        /*
        this.em = this.emf.createEntityManager();
                EntityTransaction eT = null;
                eT = this.em.getTransaction();
                eT.begin();
                Query q = this.em.createNativeQuery("ALTER CATALOG PUBLIC RENAME TO TSG");
                q.executeUpdate();
                eT.commit();

                // And also it seems I need to create the schema
                eT = this.em.getTransaction();
                eT.begin();
                q = this.em.createNativeQuery("CREATE SCHEMA TSG AUTHORIZATION DBA");
                q.executeUpdate();
                eT.commit();
                this.em.close();
                */
    }

    @Test
    public void simpleTest() {
        this.em = this.emf.createEntityManager();

        EntityTransaction et = this.em.getTransaction();
        et.begin();
        User user = new User();
        user.setId(1L);
        user.setName("User 1");

        this.em.persist(user);

        Position2 position = new Position2();
        position.setId(1L);
        position.setName("Posiotin 1");
        position.setUser(user);
        this.em.persist(position);

        et.commit();
        this.em.close();
    }
}
