package hb.hhh5964.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "wf_trans")
public class WfTransition {

    @Id
    @GeneratedValue
    private Long id;

    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private WfTask fromTask;

    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private WfTask toTask;

    public WfTask getFromTask() {
        return fromTask;
    }

    public Long getId() {
        return id;
    }

    public WfTask getToTask() {
        return toTask;
    }

    public void setFromTask(WfTask pFromTask) {
        fromTask = pFromTask;
    }

    public void setId(Long pId) {
        id = pId;
    }

    public void setToTask(WfTask pToTask) {
        toTask = pToTask;
    }

}
