package hb.hhh5964.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "task_inst")
public class TaskInstance {

    @Id
    @GeneratedValue
    private Long id;

    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private Task task;

    public Long getId() {
        return id;
    }

    public Task getTask() {
        return task;
    }

    public void setId(Long pId) {
        id = pId;
    }

    public void setTask(Task pMdd) {
        task = pMdd;
    }

}
