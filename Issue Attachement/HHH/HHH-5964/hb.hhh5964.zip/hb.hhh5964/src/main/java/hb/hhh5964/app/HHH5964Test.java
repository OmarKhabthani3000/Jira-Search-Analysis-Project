package hb.hhh5964.app;

import hb.hhh5964.entity.Task;
import hb.hhh5964.entity.TaskInstance;
import hb.hhh5964.entity.WfTask;
import hb.hhh5964.entity.WfTransition;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.Test;

public class HHH5964Test {

    @Test
    public void testHHH5964() throws Exception {
        final EntityManagerFactory emf = Persistence.createEntityManagerFactory("unit"); //$NON-NLS-1$

        {
            final EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();

            final WfTask task1 = new WfTask();
            task1.setId(1L);
            task1.setName("task1"); //$NON-NLS-1$
            em.persist(task1);

            final WfTask task2 = new WfTask();
            task2.setId(2L);
            task2.setName("task2"); //$NON-NLS-1$
            em.persist(task2);

            final WfTransition transition1_2 = new WfTransition();
            transition1_2.setFromTask(task1);
            transition1_2.setToTask(task2);
            em.persist(transition1_2);

            final TaskInstance task1i = new TaskInstance();
            task1i.setTask(task1);
            em.persist(task1i);

            em.getTransaction().commit();
            em.close();
        }

        {
            final EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();

            final List<TaskInstance> tiList = em
                    .createQuery("select ti from TaskInstance ti", TaskInstance.class).getResultList(); //$NON-NLS-1$
            for (final TaskInstance ti : tiList) {
                final Task task = ti.getTask();
                // "task" is of type WfTask, but we cannot cast because of the proxy - we do not want to initialize
                // because only the PK is needed
                em.createQuery("select wft from WfTransition wft where wft.fromTask=:task", WfTransition.class) //$NON-NLS-1$
                        .setParameter("task", task).getResultList(); //$NON-NLS-1$
            }

            em.getTransaction().commit();
            em.close();
        }

        emf.close();
    }
}
