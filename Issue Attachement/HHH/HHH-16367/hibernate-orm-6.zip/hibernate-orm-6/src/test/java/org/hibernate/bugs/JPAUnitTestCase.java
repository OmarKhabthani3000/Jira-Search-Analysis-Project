package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;
import java.util.UUID;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	private UUID uuid = UUID.randomUUID();

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		Lateral lateral = new Lateral();
		lateral.setId(1L);
		lateral.setDiameter(13L);
		lateral.setName("TEST");
		lateral.setUuid(uuid);

		entityManager.persist(lateral);

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		String hql = "from `Lateral` where uuid = ?1";
		Query query = entityManager.createQuery(hql);
		query.setParameter(1, uuid);
		Lateral lateral = (Lateral) query.getSingleResult();

		lateral.setName("TEST2");
		lateral.setName1("TEST12");

		String hql2 = "from Well where uuid = ?1";
		Query query2 = entityManager.createQuery(hql2);
		query2.setParameter(1, uuid);
		Object object = query2.getSingleResult();

		lateral.setDiameter(55L);
		lateral.setDiameter1(55L);
		lateral.setPaka1("PAKA1");
		lateral.setPaka1("PAKA2");
		lateral.setName("TEST3");
		lateral.setName1("TEST13");
		lateral.setName2("TEST23");
		lateral.setGui1(111L);
		lateral.setGui2(222L);

		entityManager.persist(lateral);
		entityManager.flush();

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
