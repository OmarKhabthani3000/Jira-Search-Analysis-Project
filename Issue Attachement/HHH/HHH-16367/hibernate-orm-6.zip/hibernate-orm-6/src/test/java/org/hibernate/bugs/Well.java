package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;
import java.util.UUID;
import lombok.Data;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicUpdate
@Data
@Table(name = "wells")
@Inheritance(strategy = InheritanceType.JOINED)
public class Well {
    @Id
    public UUID uuid;

    public String name;

    public String name1;

    public String name2;

    public long gui1;

    public long gui2;
}
