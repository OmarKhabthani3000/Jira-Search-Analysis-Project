package org.hibernate.bugs;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.io.Serializable;
import lombok.Data;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

@Entity
@DynamicUpdate
@Table(name = "laterals",
        uniqueConstraints = @UniqueConstraint(
                name = "laterals_id_unique",
                columnNames = {"id"}))
@Data
public class Lateral extends Well implements Serializable {

    @Column(name = "id", insertable = false, updatable = false, nullable = false, columnDefinition = "serial")
    @Generated(GenerationTime.INSERT)
    public Long id;

    public Long diameter;
    public Long diameter1;

    public String paka1;

    public String paka2;

}
