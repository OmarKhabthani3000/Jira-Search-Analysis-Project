package com.deamon.jpqlbug.test;

import com.deamon.jpqlbug.entity.EntityA;

import javax.persistence.*;

public class Main {

    public static void main(String[] args){

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("manager");

        EntityManager entityManager = emf.createEntityManager();
        String jpqlSelect =
            "Select a, b.size from EntityA a " +
            "left outer join a.entityBList b";

        EntityTransaction transaction = entityManager.getTransaction();
        Query query = entityManager.createQuery(jpqlSelect);

        transaction.begin();
        query.getResultList();
        transaction.commit();
    }
}
