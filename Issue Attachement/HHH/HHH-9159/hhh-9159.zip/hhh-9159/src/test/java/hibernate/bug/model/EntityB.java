package hibernate.bug.model;

import javax.persistence.*;

@Entity
@Table(name = "table_EntityB")
public class EntityB {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    private int entityBId;
    public int getEntityBId() {
        return entityBId;
    }
    public void setEntityBId(int entityBId) {
        this.entityBId = entityBId;
    }

    @ManyToOne(cascade = CascadeType.ALL)
    private EntityA entityA;
    public EntityA getEntityA() {
        return entityA;
    }
    public void setEntityB(EntityA entityA) {
        this.entityA = entityA;
    }
}
