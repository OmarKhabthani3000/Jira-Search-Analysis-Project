package hibernate.bug;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
    }
    
    @Test
    public void test1() {
        EntityManager em = emf.createEntityManager();
        
        // Parsing error
        List l = em.createQuery("SELECT a, SIZE(b) FROM EntityA a LEFT OUTER JOIN a.entityBList b").getResultList();
        Assert.assertNotNull(l);
        
        em.close();
    }
    
    @Test
    public void test2() {
        EntityManager em = emf.createEntityManager();
        
        // SQL query error
        List l = em.createQuery("SELECT a, SIZE(b) FROM EntityA a JOIN a.entityBList b").getResultList();
        Assert.assertNotNull(l);
        
        em.close();
    }
    
    @Test
    public void test3() {
        EntityManager em = emf.createEntityManager();
        
        // SQL query error
        List l = em.createQuery("SELECT a, SIZE(a.entityBList) FROM EntityA a LEFT OUTER JOIN a.entityBList b").getResultList();
        Assert.assertNotNull(l);
        
        em.close();
    }
    
    @Test
    public void test4() {
        EntityManager em = emf.createEntityManager();
        
        // SQL query error
        List l = em.createQuery("SELECT a, SIZE(a.entityBList) FROM EntityA a JOIN a.entityBList b").getResultList();
        Assert.assertNotNull(l);
        
        em.close();
    }
    
    @Test
    public void test5() {
        EntityManager em = emf.createEntityManager();
        
        // SQL query error
        List l = em.createQuery("SELECT a, SIZE(a.entityBList) FROM EntityA a").getResultList();
        Assert.assertNotNull(l);
        
        em.close();
    }
}
