package hibernate.bug.model;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "table_EntityA")
public class EntityA {
    @Id
    @GeneratedValue
    @Column(name = "id", nullable = false)
    private int entityAId;
    public int getEntityAId() {
        return entityAId;
    }
    public void setEntityAId(int entityAId) {
        this.entityAId = entityAId;
    }

    @OneToMany(mappedBy = "entityA")
    private List<EntityB> entityBList;
    public List<EntityB> getEntityBList() {
        return entityBList;
    }
    public void setEntityBList(List<EntityB> entityBList) {
        this.entityBList = entityBList;
    }
}
