package test.subclass.collections;

public class Client extends Person {

}
