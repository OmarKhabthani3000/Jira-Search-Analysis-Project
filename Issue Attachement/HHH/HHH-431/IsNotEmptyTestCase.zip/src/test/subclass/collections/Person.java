package test.subclass.collections;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;


/**
 * @author psheldon
 * 
 * Created on Apr 27, 2005
 */
public class Person implements Serializable {

	public static final String RACES = "races";
	
	private Long personId;

	private String personName;

	private Set races = new HashSet();

	/** default constructor */
	public Person() {
	}

	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long personId) {
		this.personId = personId;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String name) {
		this.personName = name;
	}
	
	public void addPersonRace(Race race) {
		PersonRace pr = new PersonRace();
		pr.setPerson(this);
		pr.setRaceId(race.getId());
		races.add(pr);
	}
	public Set getRaces() {
		return races;
	}

	public void setRaces(Set races) {
		this.races = races;
	}	

}
