package test.subclass.collections;

import java.io.Serializable;
/**
 * @author psheldon
 * 
 * Created on Apr 27, 2005
 */
public class PersonRace implements Serializable {

    protected Long personRaceId;

    private Person person;

    private Long raceId;

    /** default constructor */
    public PersonRace() {
    }

    public Long getPersonRaceId() {
        return this.personRaceId;
    }

    public void setPersonRaceId(Long personRaceId) {
        this.personRaceId = personRaceId;
    }

    public Person getPerson() {
        return this.person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Long getRaceId() {
        return this.raceId;
    }

    public void setRaceId(Long raceId) {
        this.raceId = raceId;
    }

}