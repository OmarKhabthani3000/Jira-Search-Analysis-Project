package test.subclass.collections;

public class Partner extends Person {

}
