package test.subclass.collections;

import java.util.Collection;
import java.util.Iterator;

import junit.framework.TestCase;

import org.apache.commons.collections.SetUtils;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class TestRestrictionsIsNotEmpty extends TestCase {
	
	
	/** The single instance of hibernate SessionFactory */
	static SessionFactory sessionFactory;	
	
	public static void main(String[] args) throws Exception {
		TestRestrictionsIsNotEmpty test = new TestRestrictionsIsNotEmpty();
		test.setUp();
		test.testIsNotEmpty();
		test.tearDown();
	}
	
	public void testIsNotEmpty() {

		Session session = getSession();
		
		// Test Query using superclass Person.class
		try {
			Collection results = session.createCriteria(Person.class).add(
					Restrictions.isNotEmpty(Person.RACES)).list();
			for (Iterator i = results.iterator(); i.hasNext();) {
				Person person = (Person) i.next();
				assertFalse(person.getRaces().size() == 0);
			}
		} catch (HibernateException e) {
			fail(e.getMessage());
		}		
		// Test Query using subclass Client.class
		try {
			Collection results = session.createCriteria(Client.class).add(
					Restrictions.isNotEmpty(Client.RACES)).list();
			for (Iterator i = results.iterator(); i.hasNext();) {
				Client client = (Client) i.next();
				assertFalse(client.getRaces().size() == 0);
			}
		} catch (HibernateException e) {
			fail(e.getMessage());
		}
		session.close();
	}

	protected void setUp() throws Exception {
		super.setUp();

		Session session = getSession();
		Transaction tx = session.beginTransaction();

		Race race1 = new Race(new Long(100), "White");
		session.save(race1);
		Race race2 = new Race(new Long(200), "Hispanic");
		session.save(race2);

		Client client = new Client();
		client.setPersonName("Test Client");
		client.addPersonRace(race1);
		client.addPersonRace(race2);
		session.save(client);
		
		Partner partner = new Partner();
		partner.setPersonName("Test Partner");
		partner.addPersonRace(race1);
		session.save(partner);
		
		tx.commit();
		session.close();
	}

	protected Session getSession() {

		Session session = null;
		if (sessionFactory == null) {
			Configuration cfg = new Configuration()
             .addClass(Person.class)
             .addClass(Client.class)
             .addClass(Partner.class)                 
		     .addClass(Race.class)
		     .addClass(PersonRace.class)
		     .setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver")
		     .setProperty("hibernate.connection.url","jdbc:hsqldb:C:\\hsql\\test")
		     .setProperty("hibernate.dialect","org.hibernate.dialect.HSQLDialect")
		     .setProperty("hibernate.jdbc.batch_size", "0")
		     .setProperty("hibernate.connection.username", "sa")
		     .setProperty("hibernate.connection.password", "")
		     .setProperty("hibernate.connection.autocommit", "false")
		     .setProperty("hibernate.show_sql", "true")  
		     .setProperty("hibernate.hbm2ddl.auto", "create-drop");

			sessionFactory = cfg.buildSessionFactory();
		}
		return sessionFactory.openSession();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		sessionFactory.close();
		sessionFactory = null;
	}	
	
}
