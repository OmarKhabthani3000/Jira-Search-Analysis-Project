/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package com.jpatest;

public class HibernateTest extends BaseJpaUnit {

    @Override protected String getPuName() {
        return "hibernate_pu";
    }


}
