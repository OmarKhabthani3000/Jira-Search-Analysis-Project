/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package com.jpatest;

public class EclipselinkTest extends BaseJpaUnit {

    @Override protected String getPuName() {
        return "eclipselink_pu";
    }
}
