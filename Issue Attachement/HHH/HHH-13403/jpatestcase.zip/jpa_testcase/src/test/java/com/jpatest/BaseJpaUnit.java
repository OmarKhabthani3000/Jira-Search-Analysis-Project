package com.jpatest;

import com.jpatest.db.SimpleEntity;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import static org.assertj.core.api.Assertions.assertThat;
import org.junit.Test;

public abstract class BaseJpaUnit {

    private EntityManagerFactory entityManagerFactory;
    private EntityManager entityManager;


    private void initJpa() {
        String puName = getPuName();
        Map properties = new HashMap<>();
        properties.put("javax.persistence.schema-generation.create-database-schemas", "true");
        properties.put("javax.persistence.schema-generation.database.action", "create");
        Persistence.generateSchema(puName, properties);
        entityManagerFactory = Persistence.createEntityManagerFactory(puName);
    }

    @Test
    public final void executeInsertAndSelect() throws Exception {
        initJpa();
        EntityManager em = lookupEm();
        em.getTransaction().begin();

        SimpleEntity entity = new SimpleEntity();
        entity.setId(1);
        em.persist(entity);
        em.flush();

        SimpleEntity loaded = em.find(SimpleEntity.class, entity.getId());
        assertThat(loaded.getId()).isEqualTo(entity.getId());

        em.getTransaction().rollback();
        em.close();
        this.entityManager = null;
        entityManagerFactory.close();
    }


    protected final EntityManager lookupEm() {
        if(Objects.isNull(entityManager)) {
            entityManager  = entityManagerFactory.createEntityManager();
        }
        return entityManager;
    }

    protected abstract String getPuName();

}
