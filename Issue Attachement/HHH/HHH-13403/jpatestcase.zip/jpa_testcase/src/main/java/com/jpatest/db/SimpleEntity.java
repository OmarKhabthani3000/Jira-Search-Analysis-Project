/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package com.jpatest.db;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "test", name = "simple_entity")
public class SimpleEntity implements Serializable {

    @Id
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SimpleEntity that = (SimpleEntity) o;
        return getId() == that.getId();
    }

    @Override public int hashCode() {
        return Objects.hash(getId());
    }
}
