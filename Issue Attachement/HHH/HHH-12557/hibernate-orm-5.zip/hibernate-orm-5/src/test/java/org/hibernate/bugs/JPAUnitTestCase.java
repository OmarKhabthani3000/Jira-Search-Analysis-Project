package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.bugs.models.Car;
import org.hibernate.bugs.models.Part;
import org.hibernate.bugs.models.SubPart;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		SubPart subPart1 = new SubPart();
		subPart1.setName("axle");
		subPart1.setId(1L);
		entityManager.persist(subPart1);
		Part part1 = new Part();
		part1.setSubParts(Collections.singleton(subPart1));
		part1.setId(1L);
		entityManager.persist(part1);

		SubPart subPart2 = new SubPart();
		subPart2.setName("wheel");
		subPart2.setId(2L);
		entityManager.persist(subPart2);
		Part part2 = new Part();
		part2.setSubParts(Collections.singleton(subPart2));
		part2.setId(2L);
		entityManager.persist(part2);

		Car car1 = new Car();
		car1.setParts(new HashSet<>(Arrays.asList(part1, part2)));
		car1.setId(1L);
		entityManager.persist(car1);

		Car car2 = new Car();
		car2.setParts(Collections.singleton(part1));
		car2.setId(2L);
		entityManager.persist(car2);

		Car car3 = new Car();
		car3.setId(3L);
		entityManager.persist(car3);

		//****** Should error or perhaps suggest you use c.parts instead of part *******
		List<Car> cars = entityManager.createQuery("select c from Car c left join c.parts part left join part.subParts subpart where (part is empty or subpart.name = 'axle')", Car.class).getResultList();

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
