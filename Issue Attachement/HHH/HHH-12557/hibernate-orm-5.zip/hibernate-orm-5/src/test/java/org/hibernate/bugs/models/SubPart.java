package org.hibernate.bugs.models;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "subpart", uniqueConstraints = {
	@UniqueConstraint(name = "uq_part_name", columnNames = {"name"}),
})
@SequenceGenerator(name = "default_gen", sequenceName = "part_id_seq", allocationSize = 1)
public class SubPart {

	@Id
	private Long id;

	@ManyToMany
	@JoinTable(name = "part_subpart_join_table",
		joinColumns = {@JoinColumn(name = "subpart_id", nullable = false)},
		inverseJoinColumns = {@JoinColumn(name = "part_id", nullable = false)})
	private Set<Part> parts;

	private String name;

	public Set<Part> getParts() {
		return parts;
	}

	public void setParts(Set<Part> parts) {
		this.parts = parts;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
