package org.hibernate.bugs.models;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "car")
@SequenceGenerator(name = "default_gen", sequenceName = "car_id_seq", allocationSize = 1)
public class Car {

	@Id
	private Long id;

	@ManyToMany
	@JoinTable(name = "car_parts_join_table",
		joinColumns = {@JoinColumn(name = "car_id", nullable = false)},
		inverseJoinColumns = {@JoinColumn(name = "part_id", nullable = false)})
	private Set<Part> parts;

	public Set<Part> getParts() {
		return parts;
	}

	public void setParts(Set<Part> parts) {
		this.parts = parts;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
