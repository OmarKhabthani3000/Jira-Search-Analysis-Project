package com.slavastap;

import static org.junit.Assert.assertTrue;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.Test;

import com.slavastap.entities.Client;
import com.slavastap.entities.Customer_;

public class AppTest {

    @Test
    public void shouldAnswerWithTrue() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.slavastap.unit");
        EntityManager em = emf.createEntityManager();

        Client customer = new Client();
        customer.setName("New");
        em.persist(customer);

        System.out.println("get type: " + Customer_.name.getType());

        assertTrue( true );
    }
}
