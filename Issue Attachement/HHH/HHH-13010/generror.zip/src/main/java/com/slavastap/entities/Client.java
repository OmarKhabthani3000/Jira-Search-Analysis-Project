package com.slavastap.entities;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * The entity that extends Customer without declaring any AccessType annotations.
 */
@Entity
@DiscriminatorValue("1")
//@Access(AccessType.FIELD) /* Uncomment to fix the bug */
public class Client extends Customer{

}
