package com.slavastap.entities;

import java.util.List;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * Parent entity with ACCESS TYPE FIELD + PROPERTY based getId
 */
@Entity
@Getter @Setter
@Table(name="CUSTOMER")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "ENTITY_ID", discriminatorType = DiscriminatorType.INTEGER)
@Access(AccessType.FIELD) //Access by fields
public class Customer {

	private Integer id;

	@Id
	@Column(name = "CUSTOMER_ID")
	@GeneratedValue()
	@Access(AccessType.PROPERTY) //Override for id field
	public Integer getId() {
		return id;
	}

	@Column(name = "CUSTOMER_NAME")
	private String name;

	@OneToMany(mappedBy = "id")
	private List<Order> order;

	@Column(name = "ENTITY_ID", updatable = false, insertable = false)
	private Integer entityId;
}
