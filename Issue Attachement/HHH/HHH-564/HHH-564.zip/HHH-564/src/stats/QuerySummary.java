/**
 * $Id: QuerySummary.java,v 1.7 2005/05/27 20:34:22 esword Exp $ 
 * Copyright (c) 2005 Object Sciences Corporation
 */

package stats;

import java.io.Serializable;

/**
 * Contains data and statistics for a single query by a user against a single DB table.
 * @version $Revision: 1.7 $
 * @author esword
 * 
 * @hibernate.class table="Query_Stats"
 */
public class QuerySummary implements Serializable
{
    private Long            id;
    private QuerySet        querySet;
    private QueryTable      table;
    
    public QuerySummary()
    {
    }

    /**
     * @param querySet
     */
    public QuerySummary(QuerySet querySet)
    {
        this();
        setQuerySet(querySet);
    }
    
    /**
     * Stores or updates QS into DB.
     *
    public void save()
    {        
        try
        {
            Session session = HibernateUtil.currentSession();
            Transaction tx = session.beginTransaction();
            session.saveOrUpdate(this);
            tx.commit();
            session.flush();
            HibernateUtil.closeSession();
        }
        catch (HibernateException e)
        {
            log.error("Exception caught. ", e); 
        }            
    }
    */
    
    /*
     * =================================================================================================
     * Getters and Setters
     * =================================================================================================
     */

    /**
     * @hibernate.id column="id" 
     * generator-class="native"
     * 
     * @return
     */
    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    /**
     * @return Returns the querySet.
     * @hibernate.many-to-one class="com.osc.QueryTreeNG.stats.QuerySet" column="querySetId"
     * @hibernate.column name="querySetId" index="querySetId_index"
     */
    public QuerySet getQuerySet()
    {
        return querySet;
    }

    /**
     * @return Returns the table that this query references.
     * @hibernate.many-to-one class="com.osc.QueryTreeNG.stats.QueryTable" column="tableId"
     * @hibernate.column name="tableId" index="tableId_index"
     */
    public QueryTable getTable()
    {
        return table;
    }

    /**
     * @param querySet The querySet to set.
     */
    public void setQuerySet(QuerySet querySet)
    {
        this.querySet = querySet;
    }
    
    /**
     * @param table The table to set.
     */
    public void setTable(QueryTable table)
    {
        this.table = table;
    }
}
