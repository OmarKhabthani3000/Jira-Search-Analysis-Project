/**
 * $Id$
 */

package stats;

import java.util.*;

import org.apache.log4j.Logger;
import org.hibernate.*;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * @version $Revision: 1.5 $
 * @author esword
 */
public class Tester
{
    protected static Logger log = Logger.getLogger(Tester.class);
    
    public Tester()
    {
    }

    /**
     * Testing method I use for performance of various query strings.
     */
    public void testQuery()
    {
        try
        {
            Session session = HibernateUtil.currentSession();
            List resultList = null;
            long time = 0;
            String queryString = null;
            Query query;
                
            queryString = 
                "select query.table.name, count(distinct query) " +
                "from QuerySet querySet " +
                "left join querySet.queries as query " +
                "group by query.table.name";
            
            query = session.createQuery(queryString);
            resultList = query.list();
            log.info("Got back " + resultList.size() + " results.");
        }
        catch (HibernateException e)
        {
            log.error("Exception caught. ", e); 
        }
        catch (Throwable t)
        {
            log.error("Throwable caught. ", t); 
        }
        finally
        {
            try
            {
                HibernateUtil.closeSession();
            }
            catch (HibernateException e1)
            {
                log.error("Exception caught. ", e1); 
            }            
        }
    }
    
    /*
     * =================================================================================================
     * Static Methods
     * =================================================================================================
     */

    public static void main(String[] args)
    {
        Tester gen = new Tester();
        
        try
        {
            gen.testQuery();
        }
        catch (Throwable e)
        {
            System.out.print("Exception caught: " + e.getMessage());
        }
    }
}
