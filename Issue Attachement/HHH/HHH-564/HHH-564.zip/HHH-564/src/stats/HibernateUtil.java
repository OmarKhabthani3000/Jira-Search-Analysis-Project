/**
 * $Id: HibernateUtil.java,v 1.6 2005/05/27 20:56:20 esword Exp $
 * Copyright (c) 2005 Object Sciences Corporation
 */
package stats;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import org.apache.log4j.Logger;

/**
 * Utility class taken from Hibernate reference guide.  Modified to allow outside source to set 
 * the factory.  Useful for if factory is inited from regular config or from something else
 * (like JNDI).
 * @author jerikson
 * @version $Revision: 1.6 $
 *  
 */
public class HibernateUtil 
{
    private static Logger log = Logger.getLogger(HibernateUtil.class);
    
    private static SessionFactory sessionFactory;

    private static final ThreadLocal session = new ThreadLocal();

    /**
     * Load factory using default config file name.
     * @return
     */
    private static SessionFactory getFactory()
    {
        SessionFactory factory = null;
        
        try 
        {
            Configuration cfg = new Configuration().configure();
            factory = cfg.buildSessionFactory();
        } catch (Throwable ex) {
            log.error("Initial SessionFactory creation failed.", ex);
            throw new ExceptionInInitializerError(ex);
        }
        
        return factory;
    }
    
    public static Session currentSession() throws HibernateException 
    {
        Session s = (Session) session.get();
        // Open a new Session, if this Thread has none yet
        if (s == null) {
            s = getSessionFactory().openSession();
            session.set(s);
        }
        return s;
    }

    public static void closeSession()
    {
        try
        {
            Session s = (Session) session.get();
            session.set(null);
            if (s != null)
                s.close();            
        }
        catch (Exception e)
        {
            log.error("Exception caught closing session. ", e);
        }
    }
    
    /**
     * @return Returns the sessionFactory.
     */
    public static SessionFactory getSessionFactory()
    {
        if (sessionFactory == null)
        {
            sessionFactory = getFactory();
        }
        return sessionFactory;
    }
    
    /**
     * @param sessionFactory The sessionFactory to set.
     */
    public static void setSessionFactory(SessionFactory sessionFactory)
    {
        HibernateUtil.sessionFactory = sessionFactory;
    }
}