/**
 * $Id: QueryTable.java,v 1.6 2005/05/27 20:34:22 esword Exp $
 * Copyright (c) 2005 Object Sciences Corporation
 */

package stats;

import java.io.Serializable;
import java.util.Set;

/**
 * Represents a data table reference for <code>QuerySummary</code>s.  This is primarily a lookup table,
 * but data can be added dynamically through code rather than depending on an admin person to remember to
 * add entries when new tables are added to the true data DB.
 * 
 * @version $Revision: 1.6 $
 * @author esword
 * 
 * @hibernate.class table="Query_Tables"
 */
public class QueryTable implements Serializable
{
    
    private Long            id;
    private String          name;
    private String          alias;
    private Set             queries;

    public QueryTable()
    {
    }
    
    /**
     * Only used from within call to <code>getTable</code>.  No outside object should be
     * creating an object of this type without checking the DB to see if a matching one exists.
     * @param text
     */
    protected QueryTable(String name)
    {
        setName(name);
    }
    
    
    public String toString()
    {
        return name;
    }
    
    /*
     * =================================================================================================
     * Getters and Setters
     * =================================================================================================
     */

    /**
     * @hibernate.id column="id" 
     *  generator-class="native"
     * 
     * @return
     */
    public Long getId()
    {
        return id;
    }

    /**
     * @return Returns the queries that used this criteria name
     * @hibernate.set lazy="true"
     * @hibernate.collection-one-to-many class="com.osc.QueryTreeNG.stats.QuerySummary"
     * @hibernate.collection-key column="tableId"
     */
    public Set getQueries()
    {
        return queries;
    }
    
    /**
     * @return Returns the name.
     * @hibernate.property column="name" unique="true"
     * @hibernate.column name="name" index="name_index"
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * @return Returns the alias.
     * @hibernate.property
     */
    public String getAlias()
    {
        return alias;
    }
    
    public void setId(Long id)
    {
        this.id = id;
    }

    /**
     * @param queries The queries to set.
     */
    public void setQueries(Set queries)
    {
        this.queries = queries;
    }
    
    /**
     * @param name The name to set.
     */
    public void setName(String text)
    {
        this.name = text;
    }
    
    /**
     * @param alias The alias to set.
     */
    public void setAlias(String alias)
    {
        this.alias = alias;
    }
}
