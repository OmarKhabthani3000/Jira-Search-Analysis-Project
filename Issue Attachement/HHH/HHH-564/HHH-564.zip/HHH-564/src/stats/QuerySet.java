/**
 * $Id: QuerySet.java,v 1.7 2005/05/27 20:34:22 esword Exp $ 
 * Copyright (c) 2005 Object Sciences Corporation
 */
package stats;

import java.io.Serializable;
import java.util.*;

/**
 * Represents a single user request for data from the DB.  A single request may generate several
 * queries.  There are three reasons for this. 1) A request could target multiple tables.  2) The
 * "name variants" functionality could be enabled.  3) Multiple terms may be entered in a single
 * "Mass Query" request.
 * 
 * @version $Revision: 1.7 $
 * @author esword
 * 
 * @hibernate.class table="Query_Sets"
 *  
 */
public class QuerySet implements Serializable
{
    public static int TYPE_SINGLE = 1;
    public static int TYPE_MASS = 2;
    
    private Long            id;
    private Integer         type;
    private Date            created;
    
    private Set queries;

    public QuerySet()
    {
        this(TYPE_SINGLE);
    }

    /**
     * Shortcut constructor.
     * @param type
     */
    public QuerySet(int type)
    {
        setType(new Integer(type));
        setCreated(Calendar.getInstance().getTime());
    }

    /*
     * =================================================================================================
     * Getters and Setters
     * =================================================================================================
     */

    /**
     * @hibernate.id column="id" 
     * generator-class="native"
     * 
     * @return
     */
    public Long getId()
    {
        return id;
    }
    public void setId(Long id)
    {
        this.id = id;
    }

    /**
     * @hibernate.set lazy="true"
     * @hibernate.collection-key column="querySetId"
     * @hibernate.collection-one-to-many class="com.osc.QueryTreeNG.stats.QuerySummary"
     */
    public Set getQueries() { return queries; }
    
    /**
     * @return Returns the type.
     * @hibernate.property
     */
    public Integer getType()
    {
        return type;
    }
    
    public void setQueries(Set val) { queries = val; }

    /**
     * @param type The type to set.
     */
    public void setType(Integer type)
    {
        this.type = type;
    }
    
    /**
     * @return Returns the created.
     * @hibernate.property column="created"
     * @hibernate.column name="created" index="created_index"
     */
    public Date getCreated()
    {
        if (created == null) created = Calendar.getInstance().getTime();
        return created;
    }
    
    /**
     * @param created The created to set.
     */
    public void setCreated(Date created)
    {
        this.created = created;
    }
}
