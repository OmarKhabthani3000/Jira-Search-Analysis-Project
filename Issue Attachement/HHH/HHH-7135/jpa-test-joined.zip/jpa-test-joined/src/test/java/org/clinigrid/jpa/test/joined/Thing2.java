package org.clinigrid.jpa.test.joined;

import javax.persistence.Basic;
import javax.persistence.Entity;

@Entity(name = "org.clinigrid.jpa.test.joined.Thing2")
public class Thing2 extends AThing {

	public Thing2() {
		super();
	}

	public Thing2(ThingHolder holder, Integer integer) {
		super(holder);
		this.integer = integer;
	}

	@Basic
	private Integer integer;

	public Integer getInteger() {
		return integer;
	}
}
