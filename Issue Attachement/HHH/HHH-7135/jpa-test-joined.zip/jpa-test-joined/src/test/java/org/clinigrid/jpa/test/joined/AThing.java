package org.clinigrid.jpa.test.joined;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;

@Entity(name = "org.clinigrid.jpa.test.joined.AThing")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class AThing {

	public AThing() {
	}

	public AThing(ThingHolder holder) {
		this.holder = holder;
	}

	@Id
//	@GeneratedValue(generator = "foreign")
//	@GenericGenerator(name = "foreign", strategy = "foreign", parameters = { @Parameter(name = "property", value = "holder") })
	private Integer id;

	@MapsId
	@OneToOne(mappedBy = "thing")
	private ThingHolder holder;

	public Integer getId() {
		return id;
	}

	public ThingHolder getHolder() {
		return holder;
	}
}
