package org.clinigrid.jpa.test.joined;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import junit.framework.TestCase;

public class JoinedSubclassAndForeignIdTest extends TestCase {

	public void test() {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("default");
		EntityManager em = emf.createEntityManager();
		EntityTransaction trans = em.getTransaction();

		ThingHolder holder = new ThingHolder();
		Thing1 thing1 = new Thing1(holder, "test");

		trans.begin();
		em.persist(holder);
		em.persist(thing1);
		trans.commit();

		em.close();
		emf.close();
	}
}
