package org.clinigrid.jpa.test.joined;

import javax.persistence.Basic;
import javax.persistence.Entity;

@Entity(name = "org.clinigrid.jpa.test.joined.Thing1")
public class Thing1 extends AThing {

	public Thing1() {
		super();
	}

	public Thing1(ThingHolder holder, String string) {
		super(holder);
		this.string = string;
	}

	@Basic
	private String string;

	public String getString() {
		return string;
	}
}
