package org.clinigrid.jpa.test.joined;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity(name = "org.clinigrid.jpa.test.joined.ThingHolder")
public class ThingHolder {

	public ThingHolder() {
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@OneToOne
	private AThing thing;

	public Integer getId() {
		return id;
	}

	public AThing getThing() {
		return thing;
	}

	public void setThing(AThing thing) {
		this.thing = thing;
	}
}
