package jpa.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Parameter;
import javax.persistence.Persistence;
import javax.persistence.Tuple;
import javax.persistence.TypedQuery;

import jpa.test.entities.Document;
import jpa.test.entities.DocumentVersion;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BugTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void setup() {
        emf = Persistence.createEntityManagerFactory("TestPU");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Document a = new Document("Aoc");
        Document b = new Document("Boc");
        
        em.persist(a);
        em.persist(b);

        DocumentVersion a1 = new DocumentVersion();
        a1.setDocument(a);
        em.persist(a1);
        
        tx.commit();
        em.close();
    }
    
    @After
    public void tearDown() {
        if (emf.isOpen()) {
            emf.close();
        }
    }
    
    @Test
    public void testBug() {
        EntityManager em = emf.createEntityManager();
        
        TypedQuery<Tuple> query = em.createQuery(
            "SELECT d.name, KEY(templateEntries) FROM Document d "
            + "LEFT JOIN d.documentVersions versions "
            + "LEFT JOIN versions.templateEntries templateEntries", Tuple.class);
        
        query.getResultList();
        
        List<Tuple> results = query.getResultList();
        
        /**
         * Hibernate 4.3.8.Final generates:
         * 
         * select document0_.name as col_0_0_, templateen2_.templateEntries_KEY as col_1_0_, templateen3_.id as id1_4_ 
         * from Document document0_ 
         * left outer join DocumentVersion documentve1_ on document0_.id=documentve1_.document_id 
         * left outer join DocumentVersion_TemplateEntry templateen2_ on documentve1_.id=templateen2_.DocumentVersion_id 
         * left outer join TemplateEntry templateen3_ on templateen2_.templateEntries_id=templateen3_.id;
         * 
         * Hibernate 5.1.0.Final generates:
         * select document0_.name as col_0_0_, templateen2_.templateEntries_KEY as col_1_0_, template4_.id as id1_3_ 
         * from Document document0_ 
         * left outer join DocumentVersion documentve1_ on document0_.id=documentve1_.document_id 
         * left outer join DocumentVersion_TemplateEntry templateen2_ on documentve1_.id=templateen2_.DocumentVersion_id 
         * left outer join TemplateEntry templateen3_ on templateen2_.templateEntries_id=templateen3_.id 
         * inner join Template template4_ on templateen2_.templateEntries_KEY=template4_.id;
         * 
         */
        // works with Hibernate 4.3.8.Final
        Assert.assertEquals(2, results.size());
    }
    
    private static boolean contains(Set<Parameter<?>> params, String name) {
        for (Parameter<?> p : params) {
            if (name.equals(p.getName())) {
                return true;
            }
        }
        
        return false;
    }

    private static void setParameters(TypedQuery<String> query, Map<String, Object> map) {
        for (Parameter<?> p : query.getParameters()) {
            query.setParameter(p.getName(), map.get(p.getName()));
        }
    }
}
