package jpa.test.entities;

import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyJoinColumn;
import javax.persistence.OneToMany;

@Entity
public class DocumentVersion {

	private Long id;
	private Document document;
	private Map<Template, TemplateEntry> templateEntries;
	
	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	public Document getDocument() {
		return document;
	}
	public void setDocument(Document document) {
		this.document = document;
	}
	
	@OneToMany
    @JoinTable(
    	joinColumns = {
    	        @JoinColumn(nullable = false)
    	},
    	inverseJoinColumns = {
    	        @JoinColumn(nullable = false, unique = true)
    	}
    )
    @MapKeyJoinColumn(updatable=false, insertable=false, nullable=false)
	public Map<Template, TemplateEntry> getTemplateEntries() {
		return templateEntries;
	}
	
	public void setTemplateEntries(Map<Template, TemplateEntry> templateEntries) {
		this.templateEntries = templateEntries;
	}
}
