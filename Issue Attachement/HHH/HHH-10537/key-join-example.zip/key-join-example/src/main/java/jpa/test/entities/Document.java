
package jpa.test.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Document {
    
    private Long id;
    private String name;
    private Set<DocumentVersion> documentVersions = new HashSet<>();

    public Document() {
    }

    public Document(String name) {
        this.name = name;
    }

    @Id
    @GeneratedValue
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @OneToMany(mappedBy = "document", fetch = FetchType.LAZY)
	public Set<DocumentVersion> getDocumentVersions() {
		return documentVersions;
	}

	public void setDocumentVersions(Set<DocumentVersion> documentVersions) {
		this.documentVersions = documentVersions;
	}
	
}
