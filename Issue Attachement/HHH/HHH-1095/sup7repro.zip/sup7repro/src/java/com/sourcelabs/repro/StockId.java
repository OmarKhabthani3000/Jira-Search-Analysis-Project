package com.sourcelabs.repro;

import java.io.Serializable;

/**
 * Stockid
 *
 * @author willpugh@sourcelabs.com
 */
public class StockId implements Serializable {
    private Warehouse warehouse;
    private Item item;

    public StockId() {
    }

    public StockId(Warehouse warehouse, Item item) {
        this.warehouse = warehouse;
        this.item = item;
    }

    public StockId(int warehouseId, Item item) {
        this(new Warehouse(warehouseId), item);
    }

    public StockId(int warehouseId, int itemId) {
        this(new Warehouse(warehouseId), new Item(itemId));
    }

    public Warehouse getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(Warehouse warehouse) {
        this.warehouse = warehouse;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public int hashCode() {
        return (item == null ? 0 : item.hashCode()) + (warehouse == null ? 0 : warehouse.hashCode());
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;

        if (o == null)
            return false;

        if (o instanceof StockId) {
            StockId id = (StockId) o;
            boolean retVal = (getItem() == null ? id.getItem() == null : getItem().equals(id.getItem()));
            retVal = retVal && (getWarehouse() == null ? id.getWarehouse() == null : getWarehouse().equals(id.getWarehouse()));

            return retVal;
        } else
            return false;
    }

}
