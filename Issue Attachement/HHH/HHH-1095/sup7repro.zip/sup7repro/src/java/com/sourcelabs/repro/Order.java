package com.sourcelabs.repro;

import org.apache.commons.lang.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;



public class Order implements Serializable {

    private OrderId     orderId;

    private Date o_entry_d;

    private Short o_carrier_id;

    private Short o_ol_cnt;

    private Short o_all_local;

    private Integer o_c_id;

    private NewOrder newOrder;

    private Set orderLines;

    protected transient Customer customer;


    public Order(int o_w_id, int o_d_id, int o_id, Date o_entry_d, Short o_carrier_id, Short o_ol_cnt, Short o_all_local, Customer customer, NewOrder newOrder, Set orderLines) {
        this(newOrder, orderLines);
        this.setO_entry_d(o_entry_d);
        this.setO_carrier_id(o_carrier_id);
        this.setO_ol_cnt(o_ol_cnt);
        this.setO_all_local(o_all_local);

        this.setOrderId(new OrderId(o_id, o_d_id, o_w_id));

    }

    public Order() {
    }

    public Order( NewOrder newOrder, Set orderLines) {
        this.setNewOrder(newOrder);
        this.setOrderLines(orderLines);
    }

    public Order(int o_w_id, int o_d_id, int o_id, NewOrder newOrder, Set orderLines) {
        this(newOrder, orderLines);
        this.setOrderId(new OrderId(o_id, o_d_id, o_w_id));
    }

    public Order(Customer customer, int o_id) {
        this(customer.getCustomerId().getDistrict().getDistrictId().getWarehouse().getW_id(),
             customer.getCustomerId().getDistrict().getDistrictId().getD_id(),
             o_id, null, null);
        setCustomer(customer);
    }


    public OrderId getOrderId() {
        return orderId;
    }

    public void setOrderId(OrderId orderId) {
        this.orderId = orderId;
    }


    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    public Date getO_entry_d() {
        return o_entry_d;
    }

    public void setO_entry_d(Date o_entry_d) {
        this.o_entry_d = o_entry_d;
    }

    public Short getO_carrier_id() {
        return o_carrier_id;
    }

    public void setO_carrier_id(Short o_carrier_id) {
        this.o_carrier_id = o_carrier_id;
    }

    public Short getO_ol_cnt() {
        return o_ol_cnt;
    }

    public void setO_ol_cnt(Short o_ol_cnt) {
        this.o_ol_cnt = o_ol_cnt;
    }

    public Short getO_all_local() {
        return o_all_local;
    }

    public void setO_all_local(Short o_all_local) {
        this.o_all_local = o_all_local;
    }

    public Integer getO_c_id() {
        return o_c_id;
    }

    public void setO_c_id(Integer o_c_id) {
        this.o_c_id = o_c_id;
    }

    public NewOrder getNewOrder() {
        return newOrder;
    }

    public void setNewOrder(NewOrder newOrder) {
        this.newOrder = newOrder;
    }

    public Set getOrderLines() {
        return orderLines;
    }

    public void setOrderLines(Set orderLines) {
        this.orderLines = orderLines;
    }



    public void setCustomer(com.sourcelabs.repro.Customer customer) {
        this.customer = customer;
        if (customer != null)
            setO_c_id(new Integer(customer.getCustomerId().getC_id()));
        else
            setO_c_id(null);
    }

}
