package com.sourcelabs.repro;

import java.io.Serializable;
import java.util.Set;


/**
 * This is the base class for the Warehouse table in the TPCC schema.
 * This base class exists to make it easier to create different implementations that
 * deal with the composite priimary keys in different ways.
 *
 * @author willpugh@sourcelabs.com
 */
abstract public class WarehouseBase implements Serializable {

    private int w_id;


    /**
     * nullable persistent field
     */
    private String w_name;

    /**
     * nullable persistent field
     */
    private String w_street_1;

    /**
     * nullable persistent field
     */
    private String w_street_2;

    /**
     * nullable persistent field
     */
    private String w_city;

    /**
     * nullable persistent field
     */
    private String w_state;

    /**
     * nullable persistent field
     */
    private String w_zip;

    /**
     * nullable persistent field
     */
    private float w_tax;

    /**
     * nullable persistent field
     */
    private double w_ytd;

    /**
     * persistent field
     */
    private Set districts;

  

    public WarehouseBase(String w_name, String w_street_1, String w_street_2, String w_city, String w_state, String w_zip, float w_tax, double w_ytd, Set districts) {
        this.w_name = w_name;
        this.w_street_1 = w_street_1;
        this.w_street_2 = w_street_2;
        this.w_city = w_city;
        this.w_state = w_state;
        this.w_zip = w_zip;
        this.w_tax = w_tax;
        this.w_ytd = w_ytd;
        this.districts = districts;
    }

    public WarehouseBase() {
    }

    public WarehouseBase(Set districts) {
        this.districts = districts;
    }

    public String getW_name() {
        return this.w_name;
    }

    public void setW_name(String w_name) {
        this.w_name = w_name;
    }

    public String getW_street_1() {
        return this.w_street_1;
    }

    public void setW_street_1(String w_street_1) {
        this.w_street_1 = w_street_1;
    }

    public String getW_street_2() {
        return this.w_street_2;
    }

    public void setW_street_2(String w_street_2) {
        this.w_street_2 = w_street_2;
    }

    public String getW_city() {
        return this.w_city;
    }

    public void setW_city(String w_city) {
        this.w_city = w_city;
    }

    public String getW_state() {
        return this.w_state;
    }

    public void setW_state(String w_state) {
        this.w_state = w_state;
    }

    public String getW_zip() {
        return this.w_zip;
    }

    public void setW_zip(String w_zip) {
        this.w_zip = w_zip;
    }

    public float getW_tax() {
        return this.w_tax;
    }

    public void setW_tax(float w_tax) {
        this.w_tax = w_tax;
    }

    public double getW_ytd() {
        return this.w_ytd;
    }

    public void setW_ytd(double w_ytd) {
        this.w_ytd = w_ytd;
    }

    public Set getDistricts() {
        return this.districts;
    }

    public void setDistricts(Set districts) {
        this.districts = districts;
    }

    public int getW_id() {
        return w_id;
    }

    public void setW_id(int w_id) {
        this.w_id = w_id;
    }
}
