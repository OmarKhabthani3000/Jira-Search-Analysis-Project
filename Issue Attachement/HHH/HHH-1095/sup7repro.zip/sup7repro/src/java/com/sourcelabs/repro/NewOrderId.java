package com.sourcelabs.repro;

import java.io.Serializable;

/**
 * NewOrderId
 *
 * @author willpugh@sourcelabs.com
 */
public class NewOrderId implements Serializable {
    private Order order;

    public NewOrderId() {
    }

    public NewOrderId(Order order) {
        this.order = order;
    }

    public int hashCode() {
        return order.getOrderId().hashCode();
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;

        if (o == null || !(o instanceof NewOrderId))
            return false;

        NewOrderId id = (NewOrderId) o;
        return id.getOrder().getOrderId().equals(order.getOrderId());
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }
}

