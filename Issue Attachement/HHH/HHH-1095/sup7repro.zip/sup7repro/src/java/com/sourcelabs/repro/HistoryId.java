package com.sourcelabs.repro;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.io.Serializable;
import java.sql.Date;

/**
 * HistoryId
 *
 * @author willpugh@sourcelabs.com
 */
public class HistoryId implements Serializable {
    protected Customer customer;
    protected District district;
    protected Date h_date;
    protected float h_amount;

    public HistoryId() {
    }

    public HistoryId(Customer customer, District district, Date h_date, float h_amount) {
        this.customer = customer;
        this.district = district;
        this.h_amount = h_amount;
        this.h_date = h_date;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public District getDistrict() {
        return district;
    }

    public void setDistrict(District district) {
        this.district = district;
    }

    public Date getH_date() {
        return h_date;
    }

    public void setH_date(Date h_date) {
        this.h_date = h_date;
    }

    public float getH_amount() {
        return h_amount;
    }

    public void setH_amount(float h_amount) {
        this.h_amount = h_amount;
    }

    public int hashCode() {
        HashCodeBuilder hashBuilder = new HashCodeBuilder();
        hashBuilder.append(getH_amount())
                .append(getH_date().getTime())
                .append(getCustomer().getCustomerId())
                .append(getDistrict().getDistrictId());
        return hashBuilder.toHashCode();
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;

        if (o == null)
            return false;

        if (o instanceof HistoryId) {
            HistoryId id = (HistoryId) o;
            EqualsBuilder eq = new EqualsBuilder();
            eq.append(this.getH_amount(), id.getH_amount())
                    .append(this.getH_date(), id.getH_date())
                    .append(this.getCustomer().getCustomerId(), id.getCustomer().getCustomerId())
                    .append(this.getDistrict().getDistrictId(), id.getDistrict().getDistrictId());
            return eq.isEquals();
        }
        return false;
    }

}

