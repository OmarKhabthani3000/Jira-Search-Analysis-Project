package com.sourcelabs.repro;

import org.apache.commons.lang.builder.ToStringBuilder;

import java.io.Serializable;

/**
 * Represents the primary key for a customer.  It is a composite of
 * a warehouse id, a district id and a customer id.  We represent it
 * here as simply a district and a customer id, since the district will
 * the have the warehouse id in it.
 * 
 * @author willpugh@sourcelabs.com
 */
public class CustomerId implements Serializable {
    private int c_id;

    private com.sourcelabs.repro.District district;

    public CustomerId() {
    }

    public CustomerId(int c_id, District district) {
        this.c_id = c_id;
        this.district = district;
    }

    public CustomerId(int c_id, int districtId, int warehouseId) {
        this(c_id, new District(districtId, warehouseId));
    }

    public int getC_id() {
        return c_id;
    }

    public void setC_id(int c_id) {
        this.c_id = c_id;
    }

    public District getDistrict() {
        return district;
    }

    public void setDistrict(District district) {
        this.district = district;
    }

    public int hashCode() {
        return district.getDistrictId().hashCode() * c_id;
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;

        if (o == null)
            return false;

        if (o instanceof CustomerId) {
            CustomerId id = (CustomerId) o;
            return (district.getDistrictId().equals(id.getDistrict().getDistrictId()) && (c_id == id.c_id));
        } else
            return false;
    }

    public String toString() {
        try {
            return ToStringBuilder.reflectionToString(this);
        } catch (ClassCastException cce) {
            cce.printStackTrace();
        }
        return "";
    }

}
