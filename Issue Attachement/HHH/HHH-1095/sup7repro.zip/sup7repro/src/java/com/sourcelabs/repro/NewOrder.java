package com.sourcelabs.repro;

import org.apache.commons.lang.builder.ToStringBuilder;

import java.io.Serializable;


/**
 * @author willpugh@sourcelabs.com
 */
public class NewOrder implements Serializable {

    private OrderId     orderId;

    private Order       order;


    public NewOrder(Order order) {
        this.setOrderId(order.getOrderId());
    }

    public NewOrder() {
    }

    public OrderId getOrderId() {
        return orderId;
    }

    public void setOrderId(OrderId orderId) {
        this.orderId = orderId;
    }

    public String toString() {
        return new ToStringBuilder(this)
                .append("order", getOrderId())
                .toString();
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }
}

