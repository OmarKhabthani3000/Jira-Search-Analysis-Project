package com.sourcelabs.repro;

import org.apache.commons.lang.builder.ToStringBuilder;

import java.io.Serializable;

/**
 * DistrictId
 *
 * @author willpugh@sourcelabs.com
 */
public class DistrictId implements Serializable {
    private int d_id;

    private Warehouse warehouse;

    public DistrictId() {
    }

    public DistrictId(int id, Warehouse wh) {
        warehouse = wh;
        d_id = id;
    }

    public DistrictId(int id, int wh_id) {
        warehouse = new Warehouse(wh_id);
        d_id = id;
    }

    public int getD_id() {
        return d_id;
    }

    public void setD_id(int d_id) {
        this.d_id = d_id;
    }

    public Warehouse getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(Warehouse warehouse) {
        this.warehouse = warehouse;
    }

    public int hashCode() {
        int i = new Long(getD_id() + getWarehouse().hashCode()).hashCode();
        return i;
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;

        if (o == null || !(o instanceof DistrictId))
            return false;

        DistrictId id = (DistrictId) o;
        return (id.getD_id() == getD_id()) && getWarehouse().equals(id.getWarehouse());
    }

    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}
