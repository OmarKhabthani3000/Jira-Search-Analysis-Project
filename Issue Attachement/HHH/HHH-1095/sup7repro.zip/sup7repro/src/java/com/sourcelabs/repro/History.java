package com.sourcelabs.repro;

import org.apache.commons.lang.builder.ToStringBuilder;

import java.io.Serializable;


/**
 * @author willpugh@sourcelabs.com
 */
public class History implements Serializable
{
    private HistoryId historyId;

    private String h_data;


    public History(HistoryId historyId) {
        this.setHistoryId(historyId);
    }

    public History() {
    }

    public HistoryId getHistoryId() {
        return historyId;
    }

    public void setHistoryId(HistoryId historyId) {
        this.historyId = historyId;
    }

    public String getH_data() {
        return this.h_data;
    }

    public void setH_data(String h_data) {
        this.h_data = h_data;
    }

    public String toString() {
        return new ToStringBuilder(this)
                .append("historyId", getHistoryId())
                .append("h_data", getH_data())
                .toString();
    }

}
