package com.sourcelabs.repro;

import org.apache.commons.lang.builder.ToStringBuilder;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * @author willpugh@sourcelabs.com
 */
public class OrderLine implements Serializable {

    private OrderLineId     orderLineId;
  
    private Item item;

    private Warehouse supplyWarehouse;

    private Date ol_delivery_d;

    private Short ol_quantity;

    private BigDecimal ol_amount;

    private String ol_dist_info;

    private Stock stock;

    public OrderLine(Short ol_number, Item item, Warehouse supplyWarehouse, Date ol_delivery_d, Short ol_quantity, BigDecimal ol_amount, String ol_dist_info, Order order, Stock stock) {
        this.setSupplyWarehouse(supplyWarehouse);
        this.setOl_delivery_d(ol_delivery_d);
        this.setOl_quantity(ol_quantity);
        this.setOl_amount(ol_amount);
        this.setOl_dist_info(ol_dist_info);
        this.setItem(item);
        this.setStock(stock);
        this.setOrderLineId(new OrderLineId(ol_number.shortValue(), order));
    }

    public OrderLine() {
    }

    public OrderLine(Short ol_number, Order order) {
        this.setOrderLineId(new OrderLineId(ol_number.shortValue(), order));
    }

    public OrderLine(short ol_number, Order order) {
        this(new Short(ol_number), order);
    }

    public OrderLineId getOrderLineId() {
        return orderLineId;
    }

    public void setOrderLineId(OrderLineId orderLineId) {
        this.orderLineId = orderLineId;
    }    

    public String toString() {
        return new ToStringBuilder(this)
                .append("orderLineId", getOrderLineId())
                .toString();
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public Warehouse getSupplyWarehouse() {
        return supplyWarehouse;
    }

    public void setSupplyWarehouse(Warehouse supplyWarehouse) {
        this.supplyWarehouse = supplyWarehouse;
    }

    public Date getOl_delivery_d() {
        return ol_delivery_d;
    }

    public void setOl_delivery_d(Date ol_delivery_d) {
        this.ol_delivery_d = ol_delivery_d;
    }

    public Short getOl_quantity() {
        return ol_quantity;
    }

    public void setOl_quantity(Short ol_quantity) {
        this.ol_quantity = ol_quantity;
    }

    public BigDecimal getOl_amount() {
        return ol_amount;
    }

    public void setOl_amount(BigDecimal ol_amount) {
        this.ol_amount = ol_amount;
    }

    public String getOl_dist_info() {
        return ol_dist_info;
    }

    public void setOl_dist_info(String ol_dist_info) {
        this.ol_dist_info = ol_dist_info;
    }

    public Stock getStock() {
        return stock;
    }

    public void setStock(Stock stock) {
        this.stock = stock;
    }
}
