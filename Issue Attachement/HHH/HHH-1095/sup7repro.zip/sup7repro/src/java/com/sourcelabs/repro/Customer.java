package com.sourcelabs.repro;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;



/**
 * This class represents a customer in the Customer table.  It uses a seperate class (CustomerId) to represent
 * the composite primary key.
 *
 * @author willpugh@sourcelabs.com
 */
public class Customer  implements Serializable {

    private CustomerId customerId;

    private String c_first;

    private Character c_middle;

    private String c_last;

    private String c_street_1;

    private String c_street_2;

    private String c_city;

    private String c_state;

    private String c_zip;

    private String c_phone;

    private Date c_since;

    private String c_credit;

    private Double c_credit_lim;

    private Float c_discount;

    private Double c_balance;

    private Double c_ytd_payment;

    private Short c_payment_cnt;

    private Short c_delivery_cnt;

    private String c_data;

    protected Set history;

    public Customer() {
    }

    public int getC_id() {
        return customerId.getC_id();
    }

    public Customer(int c_id, District district, Set history) {
        this.setCustomerId(new CustomerId(c_id, district));
        this.history = history;
    }

    public Customer(int c_id, int c_d_id, int c_w_id) {
        this(c_id, new District(new DistrictId(c_d_id, c_w_id)), null);
    }

    public CustomerId getCustomerId() {
        return customerId;
    }

    public void setCustomerId(CustomerId customerId) {
        this.customerId = customerId;
    }

    public String getC_first() {
        return this.c_first;
    }

    public void setC_first(String c_first) {
        this.c_first = c_first;
    }

    public Character getC_middle() {
        return this.c_middle;
    }

    public void setC_middle(Character c_middle) {
        this.c_middle = c_middle;
    }

    public String getC_last() {
        return this.c_last;
    }

    public void setC_last(String c_last) {
        this.c_last = c_last;
    }

    public String getC_street_1() {
        return this.c_street_1;
    }

    public void setC_street_1(String c_street_1) {
        this.c_street_1 = c_street_1;
    }

    public String getC_street_2() {
        return this.c_street_2;
    }

    public void setC_street_2(String c_street_2) {
        this.c_street_2 = c_street_2;
    }

    public String getC_city() {
        return this.c_city;
    }

    public void setC_city(String c_city) {
        this.c_city = c_city;
    }

    public String getC_state() {
        return this.c_state;
    }

    public void setC_state(String c_state) {
        this.c_state = c_state;
    }

    public String getC_zip() {
        return this.c_zip;
    }

    public void setC_zip(String c_zip) {
        this.c_zip = c_zip;
    }

    public String getC_phone() {
        return this.c_phone;
    }

    public void setC_phone(String c_phone) {
        this.c_phone = c_phone;
    }

    public Date getC_since() {
        return this.c_since;
    }

    public void setC_since(Date c_since) {
        this.c_since = c_since;
    }

    public String getC_credit() {
        return this.c_credit;
    }

    public void setC_credit(String c_credit) {
        this.c_credit = c_credit;
    }

    public Double getC_credit_lim() {
        return this.c_credit_lim;
    }

    public void setC_credit_lim(Double c_credit_lim) {
        this.c_credit_lim = c_credit_lim;
    }

    public Float getC_discount() {
        return this.c_discount;
    }

    public void setC_discount(Float c_discount) {
        this.c_discount = c_discount;
    }

    public Double getC_balance() {
        return this.c_balance;
    }

    public void setC_balance(Double c_balance) {
        this.c_balance = c_balance;
    }

    public Double getC_ytd_payment() {
        return this.c_ytd_payment;
    }

    public void setC_ytd_payment(Double c_ytd_payment) {
        this.c_ytd_payment = c_ytd_payment;
    }

    public Short getC_payment_cnt() {
        return this.c_payment_cnt;
    }

    public void setC_payment_cnt(Short c_payment_cnt) {
        this.c_payment_cnt = c_payment_cnt;
    }

    public Short getC_delivery_cnt() {
        return this.c_delivery_cnt;
    }

    public void setC_delivery_cnt(Short c_delivery_cnt) {
        this.c_delivery_cnt = c_delivery_cnt;
    }

    public String getC_data() {
        return this.c_data;
    }

    public void setC_data(String c_data) {
        this.c_data = c_data;
    }

    public Set getHistory() {
        return this.history;
    }

    public void setHistory(Set history) {
        this.history = history;
    }        

    public String toString() {
        return new ToStringBuilder(this)
                .append("customerId", getCustomerId())
                .toString();
    }

    public boolean equals(Object obj) {
            if (obj == null || !(obj instanceof Customer))
                return false;

            if (obj == this)
                return true;

            Customer        cust = (Customer) obj;
            EqualsBuilder   eb = new EqualsBuilder();
            eb.append(getCustomerId(), cust.getCustomerId());
            return eb.isEquals();
        }


    public int hashCode() {
        return getCustomerId().hashCode();
    }

}
