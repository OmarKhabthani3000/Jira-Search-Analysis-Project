package com.sourcelabs.repro;

import org.apache.commons.lang.builder.HashCodeBuilder;

import java.io.Serializable;

/**
 * OrderId
 *
 * @author willpugh@sourcelabs.com
 */
public class OrderId implements Serializable {
    private int o_id;
    private District district;

    public OrderId() {
    }

    public OrderId(int o_id, int d_id, int w_id) {
        this.o_id = o_id;
        district = new District(d_id, w_id);
    }

    public OrderId(int o_id, District district) {
        this.o_id = o_id;
        this.district = district;
    }

    public int getO_id() {
        return o_id;
    }

    public void setO_id(int o_id) {
        this.o_id = o_id;
    }

    public District getDistrict() {
        return district;
    }

    public void setDistrict(District dist) {
        this.district = dist;
    }

    public int hashCode() {
        HashCodeBuilder     hcb = new HashCodeBuilder();
        return hcb.append(o_id)
                    .append(getDistrict().getDistrictId())
                    .toHashCode();
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;

        if (o == null || !(o instanceof OrderId))
            return false;

        OrderId id = (OrderId) o;
        return (id.o_id == o_id) && (getDistrict().getDistrictId().equals(id.getDistrict().getDistrictId()));
    }


}
