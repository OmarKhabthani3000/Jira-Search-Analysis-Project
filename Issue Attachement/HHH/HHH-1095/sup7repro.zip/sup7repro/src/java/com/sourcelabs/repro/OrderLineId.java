package com.sourcelabs.repro;

import org.apache.commons.lang.builder.HashCodeBuilder;

import java.io.Serializable;

/**
 * OrderLineId
 *
 * @author willpugh@sourcelabs.com
 */
public class OrderLineId implements Serializable {
    private Order order;
    private short ol_number;

    public OrderLineId() {
    }

    public OrderLineId(short ol_number, Order order) {
        this.ol_number = ol_number;
        this.order = order;
    }

    public short getOl_number() {
        return ol_number;
    }

    public void setOl_number(short ol_number) {
        this.ol_number = ol_number;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public int hashCode() {
        HashCodeBuilder     hcb = new HashCodeBuilder();
        return hcb.append(getOrder().getOrderId())
            .append(getOl_number())
            .toHashCode();
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;

        if (o == null || !(o instanceof OrderLineId))
            return false;

        OrderLineId     id = (OrderLineId) o;
        return (getOrder().getOrderId().equals(id.getOrder().getOrderId()))
                && (getOl_number()==id.getOl_number());
    }


}
