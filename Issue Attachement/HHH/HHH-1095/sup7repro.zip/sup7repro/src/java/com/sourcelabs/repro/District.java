package com.sourcelabs.repro;

import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.Set;
import java.io.Serializable;


/**
 * @author willpugh@sourcelabs.com
 */
public class District implements Serializable {

    private DistrictId districtId;

    private String d_name;

    private String d_street_1;

    private String d_street_2;

    private String d_city;

    private String d_state;

    private String d_zip;

    private float d_tax;

    private double d_ytd;

    private int d_next_o_id;

    private Set customers;

    private Set history;



    public District() {
    }

    public District(DistrictId districtId) {
        this.setDistrictId(districtId);
    }

    public District(int districtId, Warehouse wh) {
        this(new DistrictId(districtId, wh));
    }

    public District(int districtId, int warehouseId) {
        this(new DistrictId(districtId, new Warehouse(warehouseId)));
    }


    public DistrictId getDistrictId() {
        return districtId;
    }

    public void setDistrictId(DistrictId districtId) {
        this.districtId = districtId;
    }    

    public String getD_name() {
        return this.d_name;
    }

    public void setD_name(String d_name) {
        this.d_name = d_name;
    }

    public String getD_street_1() {
        return this.d_street_1;
    }

    public void setD_street_1(String d_street_1) {
        this.d_street_1 = d_street_1;
    }

    public String getD_street_2() {
        return this.d_street_2;
    }

    public void setD_street_2(String d_street_2) {
        this.d_street_2 = d_street_2;
    }

    public String getD_city() {
        return this.d_city;
    }

    public void setD_city(String d_city) {
        this.d_city = d_city;
    }

    public String getD_state() {
        return this.d_state;
    }

    public void setD_state(String d_state) {
        this.d_state = d_state;
    }

    public String getD_zip() {
        return this.d_zip;
    }

    public void setD_zip(String d_zip) {
        this.d_zip = d_zip;
    }

    public float getD_tax() {
        return this.d_tax;
    }

    public void setD_tax(float d_tax) {
        this.d_tax = d_tax;
    }

    public double getD_ytd() {
        return this.d_ytd;
    }

    public void setD_ytd(double d_ytd) {
        this.d_ytd = d_ytd;
    }

    public int getD_next_o_id() {
        return this.d_next_o_id;
    }

    public void setD_next_o_id(int d_next_o_id) {
        this.d_next_o_id = d_next_o_id;
    }

    public Set getCustomers() {
        return this.customers;
    }

    public void setCustomers(Set customers) {
        this.customers = customers;
    }

    public Set getHistory() {
        return this.history;
    }

    public void setHistory(Set history) {
        this.history = history;
    }

    public String toString() {
        return new ToStringBuilder(this)
                .append("distring", getDistrictId().toString())
                .toString();
    }

    public int hashCode() {
        return districtId.hashCode();
    }

    public boolean equals(Object obj) {
        if (obj == this)
            return true;

        if (obj instanceof District)
            return districtId.equals(((District) obj).getDistrictId());
        return false;
    }
}
