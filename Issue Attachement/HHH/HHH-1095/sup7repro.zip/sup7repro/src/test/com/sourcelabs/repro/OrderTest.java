package com.sourcelabs.repro;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Set;

/**
 * @author willpugh  Oct 18, 2005 12:01:35 PM
 */
public class OrderTest extends AbstractTestCase {

  protected Order order1;
  protected Order order2;
  protected Order order3;

  protected NewOrder newOrder1;
  protected NewOrder newOrder2;
  protected NewOrder newOrder3;

  protected Stock stock1;
  protected Stock stock2;
  protected Stock stock3;

  protected OrderLine[] orderLine1 = new OrderLine[1];
  protected OrderLine[] orderLine2 = new OrderLine[3];
  protected OrderLine[] orderLine3 = new OrderLine[10];

  protected Item item1;
  protected Item item2;

  protected District dist1;
  protected District dist2;

  protected Warehouse wh;
  protected Customer cust1;
  protected Customer cust2;

  public void setUp() throws Exception{
    super.setUp();
    Session currSession = getPrimarySession();
    Transaction tran = currSession.beginTransaction();
    setData( tran );
    tran.commit();
    currSession.close();
  }


  protected Warehouse getTestWarehouse(){
    Warehouse wh = new Warehouse( 1 );
    wh.setW_city( "San Francisco" );
    wh.setW_name( "Bob" );
    wh.setW_state( "Ca" );
    wh.setW_street_1( "11 Foo bar" );
    wh.setW_tax( .08F );
    wh.setW_ytd( 0D );
    wh.setW_zip( "98088" );
    return wh;
  }

  private void setData( Transaction tran ){


    wh = getTestWarehouse();
    addObject( wh );

    dist1 = new District( 1, wh );
    addObject( dist1 );


    dist2 = new District( 2, new Warehouse( 1 ) );
    addObject( dist2 );



    cust1 = new Customer( 1, dist1, null );
    addObject( cust1 );


    cust2 = new Customer( 1, dist2, null );
    addObject( cust2 );


    order1 = new Order( cust1, 1 );
    addObject( order1 );


    order2 = new Order( cust1, 2 );
    addObject( order2 );


    order3 = new Order( cust2, 1 );
    addObject( order3 );


    newOrder1 = new NewOrder( order1 );
    addObject( newOrder1 );


    newOrder2 = new NewOrder( order2 );
    addObject( newOrder2 );



    item1 = new Item( 1 );
    addObject( item1 );


    item2 = new Item( 2 );
    addObject( item2 );


    stock1 = new Stock( wh, item1 );
    addObject( stock1 );


    stock2 = new Stock( wh, item2 );
    addObject( stock2 );


    for(int i = 0; i < 3; i++){
      Order currOrder = null;
      OrderLine[]     lines = null;
      switch( i ){
        case 0:
          currOrder = order1;
          lines = orderLine1;
          break;
        case 1:
          currOrder = order2;
          lines = orderLine2;
          break;
        case 2:
          currOrder = order3;
          lines = orderLine3;
          break;
        default:
          assertFalse( true );
      }

      for(int j = 0; j < lines.length; j++){
        lines[j] = new OrderLine( ( short ) j, currOrder );
        lines[j].setItem( item1 );
        lines[j].setSupplyWarehouse( wh );
        addObject( lines[j] );

      }
    }

  }


  public OrderTest( String testName ){
    super( testName );
  }

  public void testOrderLineAssociations(){
    assertTrue( verifyLinesForOrder( order1, orderLine1 ) );
    assertTrue( verifyLinesForOrder( order2, orderLine2 ) );
    assertTrue( verifyLinesForOrder( order3, orderLine3 ) );
    assertTrue( verifyLinesForOrder( order1, orderLine1 ) );
  }


  protected boolean verifyLinesForOrder( Order order, OrderLine[] lines ){

    Session newSession = null;
    Transaction tx = null;
    newSession = factory.openSession();
    tx = newSession.beginTransaction();



    try{
      Order foundOrder = ( Order ) newSession.load( Order.class, order.getOrderId() );
      assertNotNull( foundOrder );
      assertEquals( foundOrder.getOrderId(), order.getOrderId() );

      Set oLines = foundOrder.getOrderLines();
      Iterator iter = oLines.iterator();
      for(Iterator iterator = oLines.iterator(); iterator.hasNext();){
        Object o = iterator.next();

      }
      assertEquals( oLines.size(), lines.length );
      assertTrue( verifyOrderLines( oLines, lines ) );
      tx.commit();
    } finally{

      newSession.close();
    }
    return true;
  }

  protected boolean verifyOrderLines( Set oLines, OrderLine[] aLines ){

    //Make a copy since we will be modifying the array as it stands
    aLines = ( OrderLine[] ) Arrays.asList( aLines ).toArray( new OrderLine[aLines.length] );

    Iterator iter = oLines.iterator();
    while( iter.hasNext() ){
      OrderLine ol = ( OrderLine ) iter.next();

      int i;
      for(i = 0; i < aLines.length; i++){
        OrderLine aLine = aLines[i];
        if( aLine != null ){
          if( aLine.getOrderLineId().equals( aLine.getOrderLineId() ) ){
            //Let's make sure we don't have duplicates
            aLines[i] = null;
            break;
          }
        }
      }
      //If there is an entry we did not find, Fail.
      if( i == aLines.length ){
        assertFalse( "Retrived an OrderLineBase " + ol.toString(), false );
        return false;
      }
    }

    //If there are any entries we should have found but didn't, fail.
    for(int j = 0; j < aLines.length; j++){
      OrderLine aLine = aLines[j];
      if( aLine != null ){
        assertFalse( "We should have found " + aLine.toString() + " but didn't", true );
        return false;
      }
    }
    return true;
  }

}
