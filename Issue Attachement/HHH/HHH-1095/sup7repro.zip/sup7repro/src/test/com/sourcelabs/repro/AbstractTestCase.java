package com.sourcelabs.repro;

import com.sourcelabs.repro.*;
import junit.framework.TestCase;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.exception.ConstraintViolationException;

import java.io.File;
import java.util.ArrayList;

/**
 * Abstract base class for test cases.
 * <p/>
 * Properties:
 * IterationMultiplier  -- Since much of these tests are
 * random, it can be nice to take a nice long time to run test
 * cases over and over before believing they work.  This allows you
 * to change the loops to run for a nice long time.
 *
 * @author willpugh@sourcelabs.com
 */
public abstract class AbstractTestCase
    extends TestCase {
  /**
   * Basedir for all file I/O. Important when running tests from
   * the reactor.
   */
  public String basedir = System.getProperty( "basedir" );


  protected SessionFactory factory;
  //private Session primarySession;

  Session primarySession;

  private ArrayList objects = new ArrayList();

  private int iterationMultiplier = 1;


  /**
   * Constructor.
   */
  public AbstractTestCase( String testName ){
    super( testName );
  }


  protected void setUp() throws Exception{
    super.setUp();

    System.setProperty( "hibernate.dialect", "org.hibernate.dialect.HSQLDialect" );
    System.setProperty( "hibernate.connection.driver_class", "org.hsqldb.jdbcDriver" );
    System.setProperty( "hibernate.connection.url", "jdbc:hsqldb:." );

    Configuration cfg = new Configuration();
    cfg.addClass( Customer.class )
        .addClass( District.class )
        .addClass( History.class )
        .addClass( Item.class )
        .addClass( NewOrder.class )
        .addClass( Order.class )
        .addClass( Stock.class )
        .addClass( Warehouse.class )
        .addClass( OrderLine.class );

    cfg.setProperty( Environment.HBM2DDL_AUTO, "create" );

    factory = cfg.buildSessionFactory();

    //cfg.setProperty("hibernate.show_sql", "true");

    openPrimarySession();
  }


  protected Session openPrimarySession(){
    objects.clear();
    setPrimarySession( factory.openSession() );
    return getPrimarySession();
  }

  protected void addObject( Object obj ){
    objects.add( obj );
    getPrimarySession().save( obj );
  }

  protected void evictObject( Object obj ){
    getPrimarySession().evict( obj );
    objects.remove( obj );
  }

  protected void markForDeath( Object obj ){
    objects.add( obj );
  }

  protected void commitForSetup( Transaction tran ){
    //  There are many ways the DB can be left with objects
    //  still in it.  This method is to allow us to continue
    // with out tests in these cases (and allows us to cleanup
    // after the end of the tests)

    try{
//            tran.commit();
    } catch( ConstraintViolationException cve ){
      //Kill the constraint violation exceptions
      cve.printStackTrace();
    }
  }

  protected void deleteObject( Object obj ){
    getPrimarySession().delete( obj );
    objects.remove( obj );
  }

  protected void deleteAllObjects(){
    if( getPrimarySession() == null )
      return;

    Transaction tran = getPrimarySession().beginTransaction();
    try{
      while( objects.size() > 0 )
        deleteObject( objects.remove( objects.size() - 1 ) );
    } finally{
      tran.commit();
    }
  }

  protected void closePrimarySession(){
    if( getPrimarySession() != null ){
      objects.clear();
      getPrimarySession().close();
      setPrimarySession( null );
    }
  }

  /**
   * Get test input file.
   *
   * @param path Path to test input file.
   */
  public String getTestFile( String path ){
    return new File( basedir, path ).getAbsolutePath();
  }


  public Session getPrimarySession(){
    return primarySession;
  }

  public void setPrimarySession( Session primarySession ){
    this.primarySession = primarySession;
  }

  public void runBare() throws Throwable{
    try{
      //In the case of failures, we don't seem to get any cleanup
      //being called.  adding that here. . .
      super.runBare();
    } catch( Throwable t ){
      tearDown();
      t.printStackTrace();
      throw t;
    }
  }

  public int getIterationMultiplier(){
    return iterationMultiplier;
  }

  public void setIterationMultiplier( int iterationMultiplier ){
    this.iterationMultiplier = iterationMultiplier;
  }
}

