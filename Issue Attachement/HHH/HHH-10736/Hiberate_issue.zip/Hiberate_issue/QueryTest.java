package hibernate.test;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class QueryTest {
	public static void main(String[] args) {
		Session session = null;
		try {
			Configuration configuration = new Configuration();
			configuration.configure();
			ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
					.applySettings(configuration.getProperties())
					.buildServiceRegistry();
			SessionFactory sessionFactory = configuration
					.buildSessionFactory(serviceRegistry);
			session = sessionFactory.openSession();
			session.beginTransaction();

			
			Query q = session.getNamedQuery("Employee.sameFirstName");
			q.setString("firstName", "murray");
			q.setMaxResults(2);			
			
			List<Employee> udRec = (List<Employee>) q.list();
			
			
			for (int i = 0; i < udRec.size(); i++) {
				System.out.println("User ID = " + udRec.get(i).getId());
				System.out.println("User First Name = " + udRec.get(i).getFirstName());
				System.out.println("User Last  Name = " + udRec.get(i).getLastName());
				System.out.println("User SALARY = " + udRec.get(i).getSalary());
			}	
			 
			// uncomment the below block to execute the qry : Employee.select1
			/*   
			Query q = session.getNamedQuery("Employee.select1");
			q.setMaxResults(2);
			int size = q.list().size();
			System.out.println("size = " + size);*/
			
			session.getTransaction().commit();
			System.out.println("Done!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			session.flush();
			session.close();
		}
	}

}
