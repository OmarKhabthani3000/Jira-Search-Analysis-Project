import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.*;

public class TestNotNull {

    private EntityManager em;

    @Before
    public void setUp() {
        em = Persistence.createEntityManagerFactory("persistenceUnit").createEntityManager();
    }

    @After
    public void tearDown() {
        em.close();
    }

    @Test
    public void insert() {

        // insert record with only id - null association

        Entity entity = new Entity();
        entity.setId(1L);
        em.getTransaction().begin();
        em.persist(entity);
        em.getTransaction().commit();
    }

    @Test
    public void select() {;

        // select inserted record
        // throws: org.hibernate.AssertionFailure: null identifier

        System.out.println(em.find(Entity.class, 1L));

    }


}
