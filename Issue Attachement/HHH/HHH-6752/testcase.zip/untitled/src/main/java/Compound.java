import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

/**
 * This entity has a compound primary key containing a many-to-one
 */
@Entity
public class Compound {

    @EmbeddedId
    private Id id;

}
