import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 * Embeddable Id containing a many-to-one
 */
@Embeddable
public class Id implements Serializable {

    private String col1;

    @ManyToOne
    private Other other;

}
