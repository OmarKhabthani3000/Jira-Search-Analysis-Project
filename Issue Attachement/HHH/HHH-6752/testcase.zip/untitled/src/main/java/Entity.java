import com.sun.istack.internal.NotNull;

import javax.persistence.*;
import javax.persistence.Id;

/**
 * A root entity
 */
@javax.persistence.Entity
public class Entity {

    @Id
    private Long id;

    @OneToOne
    private Other other;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
