import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.List;

/**
 * Entity mapping a many-to-one contained by a compound primary key
 */
@Entity
public class Other {
    @Id
    private Long id;

    @OneToMany(mappedBy = "id.other", fetch = FetchType.EAGER)
    private List<Compound> compound;
}
