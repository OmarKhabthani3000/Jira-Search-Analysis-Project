
package hibernate.bug.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MapKeyColumn;

@Entity
public class Person implements Serializable {
    
    private Integer id;
    private String text;
    private Map<String, String> localized = new HashMap<String, String>();

    public Person() {
    }

    public Person(String text) {
        this.text = text;
    }

    @Id
    @GeneratedValue
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @ElementCollection
    @MapKeyColumn(length = 10)
    @Column(length = 10)
    public Map<String, String> getLocalized() {
        return localized;
    }

    public void setLocalized(Map<String, String> localized) {
        this.localized = localized;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + (this.text != null ? this.text.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Person other = (Person) obj;
        if ((this.text == null) ? (other.text != null) : !this.text.equals(other.text)) {
            return false;
        }
        return true;
    }
    
}
