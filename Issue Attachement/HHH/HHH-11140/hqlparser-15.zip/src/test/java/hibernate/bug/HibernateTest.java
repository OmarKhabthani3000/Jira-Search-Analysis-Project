package hibernate.bug;

import hibernate.bug.model.Document;
import hibernate.bug.model.Person;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p1 = new Person("t1");
        Person p2 = new Person("t2");
        Document d1 = new Document(p1);
        Document d2 = new Document(p2);
        
        p1.getLocalized().put("key1", "val1");
        p1.getLocalized().put("key2", "val2");
        p2.getLocalized().put("key1", "val1");
        p2.getLocalized().put("key2", "val2");
        
        em.persist(p1);
        em.persist(p2);
        
        em.persist(d1);
        em.persist(d2);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testIssue() throws Throwable {
        EntityManager em = emf.createEntityManager();
        List<Person> list = em.createQuery("SELECT DISTINCT p FROM Document d JOIN d.owner p LEFT JOIN FETCH p.localized", Person.class).getResultList();
        
        // Avoid possible lazy loading
        em.close();
        
        Assert.assertEquals(2, list.size());
        Assert.assertEquals(2, list.get(0).getLocalized().size());
        Assert.assertEquals(2, list.get(1).getLocalized().size());
    }
    
}
