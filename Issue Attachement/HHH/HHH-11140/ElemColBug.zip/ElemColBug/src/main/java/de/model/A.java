package de.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class A {
	
	@Id
	private Long id;
	

	@Column(length = 1024)
	private String name;

	@OneToMany(cascade = { CascadeType.PERSIST }, fetch = FetchType.LAZY, mappedBy = "a")
	private Set<B> bs;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<B> getBs() {
		if (bs == null) {
			bs = new HashSet<B>();
		}
		return bs;
	}

	public void setBs(Set<B> bs) {
		this.bs = bs;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
