package de.model;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class B {
	

	@Id
	private Long id;
	

	@Column(length = 1024)
	private String name;

	@ManyToOne(cascade = { CascadeType.PERSIST }, fetch = FetchType.LAZY)
	private A a;

	@ElementCollection
	private Collection<Long> someOtherLongs;

	public Collection<Long> getSomeOtherLongs() {
		return someOtherLongs;
	}

	public void setSomeOtherLongs(Collection<Long> someOtherLongs) {
		this.someOtherLongs = someOtherLongs;
	}

	public A getA() {
		return a;
	}

	public void setA(A a) {
		this.a = a;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
