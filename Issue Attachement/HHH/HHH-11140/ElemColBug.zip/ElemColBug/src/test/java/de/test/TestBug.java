package de.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.SetJoin;

import org.junit.Test;

import de.model.A;
import de.model.A_;
import de.model.B;
import de.model.B_;

public class TestBug {

	@Test
	public void failA() {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("abc_data");
		EntityManager em = emf.createEntityManager();

		CriteriaBuilder cb = em.getCriteriaBuilder();

		CriteriaQuery<B> query = cb.createQuery(B.class);
		Root<A> a = query.from(A.class);
		SetJoin<A, B> join = a.join(A_.bs);
		join.fetch(B_.someOtherLongs);

		query.select(join);

		em.createQuery(query).getResultList();
	}

	@Test
	public void failB() {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("abc_data");
		EntityManager em = emf.createEntityManager();

		TypedQuery<B> query = em
				.createQuery(
						"SELECT b FROM A a INNER JOIN a.bs b INNER JOIN FETCH b.someOtherLongs",
						B.class);

		query.getResultList();
	}

	@Test
	public void okA() {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("abc_data");
		EntityManager em = emf.createEntityManager();

		CriteriaBuilder cb = em.getCriteriaBuilder();

		CriteriaQuery<B> query = cb.createQuery(B.class);
		Root<A> a = query.from(A.class);
		SetJoin<A, B> join = a.join(A_.bs);

		query.select(join);

		em.createQuery(query).getResultList();
	}

	@Test
	public void okB() {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("abc_data");
		EntityManager em = emf.createEntityManager();

		TypedQuery<B> query = em.createQuery(
				"SELECT b FROM A a INNER JOIN a.bs b", B.class);

		query.getResultList();
	}

}
