package org.hibernate.bugs;

import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.TypeDef;

@MappedSuperclass
@TypeDef(defaultForType = EnumWithBody.class, typeClass = EnumWithBodyType.class)
public class EnumWithBodyType extends AbstractEnumType {
    @Override
    public Class returnedClass() {
        return EnumWithBody.class;
    }
}