package org.hibernate.bugs;

import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.SessionFactory;
import org.hibernate.type.TypeResolver;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

enum PlainEnum {
    A;
    
    @Override
    public String toString() {
        return "Hello, I'm a PlainEnum!";
    }
}
enum EnumWithBody {
    B {
        @Override
        public String toString() {
            return "Hello, I'm a EnumWithBody!";
        }
    }
}

public class JPAUnitTestCase {
    
    private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void testPlainEnum() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		entityManager.persist(new MyEntity());
		entityManager.flush();
		
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		
		assertEquals("org.hibernate.bugs.PlainEnum", PlainEnum.A.getClass().getName());
		
		// This works: the literal is serialized as VARCHAR
		CriteriaQuery<MyEntity> q1 = cb.createQuery(MyEntity.class);
        q1.where(cb.equal(q1.from(MyEntity.class).get(MyEntity_.plainEnum),
                          cb.literal(PlainEnum.A)));
        assertEquals(1, entityManager.createQuery(q1).getResultList().size());
		
        // This doesn't work: the literals are serialized as VARBINARY
		CriteriaQuery<MyEntity> q2 = cb.createQuery(MyEntity.class);
		q2.where(cb.equal(q2.from(MyEntity.class).get(MyEntity_.plainEnum),
		                  cb.coalesce(cb.literal(PlainEnum.A),cb.literal(PlainEnum.A))));
		assertEquals(0, entityManager.createQuery(q2).getResultList().size()); // Now rows returned!
		
		// This helps:
		TypeResolver typeResolver = entityManagerFactory.unwrap(SessionFactory.class).getSessionFactory().getTypeResolver();
        typeResolver.registerTypeOverride(new PlainEnumType(), new String[] {PlainEnum.class.getName()});
        
        // Now the same works:
        CriteriaQuery<MyEntity> q3 = cb.createQuery(MyEntity.class);
        q3.where(cb.equal(q3.from(MyEntity.class).get(MyEntity_.plainEnum),
                          cb.coalesce(cb.literal(PlainEnum.A),cb.literal(PlainEnum.A))));
        assertEquals(1, entityManager.createQuery(q3).getResultList().size());

		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	@Test
    public void testEnumWithBody() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        
        entityManager.persist(new MyEntity());
        entityManager.flush();
        
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        
        // class name for bodied enums is not exactly the enum class name!
        assertEquals("org.hibernate.bugs.EnumWithBody$1", EnumWithBody.B.getClass().getName());
        
        // This works: the literal is serialized as VARCHAR
        CriteriaQuery<MyEntity> q1 = cb.createQuery(MyEntity.class);
        q1.where(cb.equal(q1.from(MyEntity.class).get(MyEntity_.enumWithBody),
                          cb.literal(EnumWithBody.B)));
        assertEquals(1, entityManager.createQuery(q1).getResultList().size());

        // This doesn't work: the literals are serialized as VARBINARY
        CriteriaQuery<MyEntity> q2 = cb.createQuery(MyEntity.class);
        q2.where(cb.equal(q2.from(MyEntity.class).get(MyEntity_.enumWithBody),
                          cb.coalesce(cb.literal(EnumWithBody.B),cb.literal(EnumWithBody.B))));
        assertEquals(0, entityManager.createQuery(q2).getResultList().size()); // No rows returned!
        
        // This won't help this time:
        TypeResolver typeResolver = entityManagerFactory.unwrap(SessionFactory.class).getSessionFactory().getTypeResolver();
        typeResolver.registerTypeOverride(new EnumWithBodyType(), new String[] {EnumWithBody.class.getName()});
        
        // Still doesn't work:
        CriteriaQuery<MyEntity> q3 = cb.createQuery(MyEntity.class);
        q3.where(cb.equal(q3.from(MyEntity.class).get(MyEntity_.enumWithBody),
                          cb.coalesce(cb.literal(EnumWithBody.B),cb.literal(EnumWithBody.B))));
        assertEquals(0, entityManager.createQuery(q3).getResultList().size()); // No rows returned!
        
        // But this helps:
        typeResolver.registerTypeOverride(new EnumWithBodyType(), new String[] {EnumWithBody.class.getName(), EnumWithBody.B.getClass().getName()});
        
        // Now this works!
        CriteriaQuery<MyEntity> q4 = cb.createQuery(MyEntity.class);
        q4.where(cb.equal(q4.from(MyEntity.class).get(MyEntity_.enumWithBody),
                          cb.coalesce(cb.literal(EnumWithBody.B),cb.literal(EnumWithBody.B))));
        assertEquals(1, entityManager.createQuery(q4).getResultList().size());
        
        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
