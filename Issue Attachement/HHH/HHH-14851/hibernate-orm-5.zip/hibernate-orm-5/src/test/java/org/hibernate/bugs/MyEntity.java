package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class MyEntity {
    @Id
    @GeneratedValue
    private long id;
    
    private PlainEnum plainEnum = PlainEnum.A;
    private EnumWithBody enumWithBody = EnumWithBody.B;
}