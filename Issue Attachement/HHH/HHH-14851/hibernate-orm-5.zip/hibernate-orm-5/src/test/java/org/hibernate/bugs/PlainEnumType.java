package org.hibernate.bugs;

import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.TypeDef;

@MappedSuperclass
@TypeDef(defaultForType = PlainEnum.class, typeClass = PlainEnumType.class)
public class PlainEnumType extends AbstractEnumType {
    @Override
    public Class returnedClass() {
        return PlainEnum.class;
    }
}