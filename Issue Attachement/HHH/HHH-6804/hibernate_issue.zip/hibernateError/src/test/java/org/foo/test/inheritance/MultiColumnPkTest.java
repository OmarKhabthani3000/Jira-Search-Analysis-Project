package org.foo.test.inheritance;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import junit.framework.Assert;

import org.foo.test.inheritance.multiPk.Book;
import org.foo.test.inheritance.multiPk.BookPK;
import org.foo.test.inheritance.multiPk.ComicBook;
import org.foo.test.inheritance.multiPk.ComicBook_;
import org.foo.test.inheritance.multiPk.SciFiBook;
import org.foo.test.inheritance.multiPk.SciFiBook_;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class MultiColumnPkTest {
	
	private static EntityManagerFactory emf;
	private EntityManager em;
	
	@Test
	public void testCreateBook() {
	  System.out.println(ComicBook_.name);
		BookPK primaryKey = new BookPK("SciFiBook-001", 42);
		
		SciFiBook newBook = new SciFiBook();
    newBook.setName(primaryKey.getName());
    newBook.setRevision(primaryKey.getRevision());
    newBook.setFoo("123");
    
		em.getTransaction().begin();
		em.persist(newBook);
		
		SciFiBook fetchedBook = em.find(SciFiBook.class, primaryKey);
		
		Assert.assertEquals(newBook, fetchedBook);
		Assert.assertEquals(primaryKey.getName(), fetchedBook.getName());
		Assert.assertEquals(42, fetchedBook.getRevision());
		Assert.assertEquals("SF", fetchedBook.getType());
		Assert.assertEquals("123", fetchedBook.getFoo());
	}
	
  @Test
  public void testSelectBooks() {
    em.getTransaction().begin();
    Book newBook;
    
    newBook = new ComicBook();
    newBook.setName("Comic01");
    newBook.setRevision(2);
    em.persist(newBook);
    
    newBook = new ComicBook();
    newBook.setName("Comic02");
    newBook.setRevision(3);
    em.persist(newBook);
    
    newBook = new SciFiBook();
    newBook.setName("SF01");
    newBook.setRevision(2);
    em.persist(newBook);
    
    Query query = em.createQuery("SELECT o FROM SciFiBook o", SciFiBook.class);
    Assert.assertEquals(1, query.getResultList().size());
    
    query = em.createQuery("SELECT o FROM ComicBook o", ComicBook.class);
    Assert.assertEquals(2, query.getResultList().size());
  }
  
  @Test
  public void testCriteria()
  {
    BookPK primaryKey = new BookPK("SciFiBook-001", 42);
    
    SciFiBook newBook = new SciFiBook();
    newBook.setName(primaryKey.getName());
    newBook.setRevision(primaryKey.getRevision());
    newBook.setFoo("123");
    
    em.getTransaction().begin();
    em.persist(newBook);
    
    CriteriaBuilder cb = em.getCriteriaBuilder();
    CriteriaQuery<SciFiBook> bookQuery = cb.createQuery(SciFiBook.class);
    Root<SciFiBook> bookRoot = bookQuery.from(SciFiBook.class);
    
    Book fetchedBook = em.createQuery(
          bookQuery.where(cb.equal(bookRoot.get(SciFiBook_.name), primaryKey.getName())))
      .getSingleResult();
    
    Assert.assertEquals("SF", fetchedBook.getType());
  }
	
	
	@Before
	public void before() {
		em = emf.createEntityManager();
	}
	
	@After
	public void after() {
		if (em != null) {
		  em.getTransaction().rollback();
			em.close();
			em = null;
		}
	}
	
	@BeforeClass
	public static void beforeClass() {
		emf = Persistence.createEntityManagerFactory("jpa2Pu");
	}
	
	@AfterClass
	public static void afterClass() {
		if (emf != null) {
			emf.close();
			emf = null;
		}
	}
}
