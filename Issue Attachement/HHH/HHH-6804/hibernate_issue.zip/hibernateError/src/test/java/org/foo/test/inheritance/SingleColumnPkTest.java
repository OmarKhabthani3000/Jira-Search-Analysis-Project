package org.foo.test.inheritance;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import junit.framework.Assert;

import org.foo.test.inheritance.singlePk.ArtPoster;
import org.foo.test.inheritance.singlePk.ArtPoster_;
import org.foo.test.inheritance.singlePk.MoviePoster;
import org.foo.test.inheritance.singlePk.MoviePoster_;
import org.foo.test.inheritance.singlePk.Poster;
import org.foo.test.inheritance.singlePk.PosterPK;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class SingleColumnPkTest {
	
	private static EntityManagerFactory emf;
	private EntityManager em;
	
	@Test
	public void testCreatePoster() {
//	  System.out.println("##################");
//	  System.out.println(MoviePoster_.foo);
//	  System.out.println(CustomerId_.id);
//	  System.out.println(AbstractIdentity_.id);
//	  System.out.println("##################");
//	  
//	  Assert.assertNotNull(MoviePoster_.posterId);
	  
	  PosterPK primaryKey = new PosterPK(42);
	  
	  MoviePoster newPoster = new MoviePoster();
		newPoster.setPosterId(primaryKey.getPosterId());
		
		em.getTransaction().begin();
		em.persist(newPoster);
		
		MoviePoster fetchedPoster;
		
		//em.find 
//		fetchedPoster = em.find(Poster.class, primaryKey);
//		Assert.assertEquals(newPoster, fetchedPoster);
//		Assert.assertEquals("movie", fetchedPoster.getType());
//		System.out.println(fetchedPoster);
		
		//criteria
    CriteriaBuilder cb = em.getCriteriaBuilder();
    CriteriaQuery<MoviePoster> posterQuery = cb.createQuery(MoviePoster.class);
    Root<MoviePoster> posterRoot = posterQuery.from(MoviePoster.class);
		
    fetchedPoster = em.createQuery(
          posterQuery.where(cb.equal(posterRoot.get(MoviePoster_.posterId), primaryKey.getPosterId())))
      .getSingleResult();
    
    System.out.println(fetchedPoster);
    Assert.assertEquals("movie", fetchedPoster.getType());
	}
	
  @Test
  public void testSelectPoster() {
    em.getTransaction().begin();
    Poster newPoster;
    
    newPoster = new ArtPoster();
    newPoster.setPosterId(10);
    em.persist(newPoster);
    
    newPoster = new ArtPoster();
    newPoster.setPosterId(11);
    em.persist(newPoster);
    
    newPoster = new MoviePoster();
    newPoster.setPosterId(20);
    em.persist(newPoster);
    
    Query query = em.createQuery("SELECT o FROM MoviePoster o", MoviePoster.class);
    Assert.assertEquals(1, query.getResultList().size());
    
    query = em.createQuery("SELECT o FROM ArtPoster o", ArtPoster.class);
    Assert.assertEquals(2, query.getResultList().size());
  }
    
  @Test
  public void testCriteria()
  {
    PosterPK primaryKey = new PosterPK(123);
    
    ArtPoster newPoster = new ArtPoster();
    newPoster.setPosterId(primaryKey.getPosterId());
    
    em.getTransaction().begin();
    em.persist(newPoster);
    
    CriteriaBuilder cb = em.getCriteriaBuilder();
    CriteriaQuery<ArtPoster> posterQuery = cb.createQuery(ArtPoster.class);
    Root<ArtPoster> posterRoot = posterQuery.from(ArtPoster.class);
    
    Poster fetchedPoster = em.createQuery(
          posterQuery.where(cb.equal(posterRoot.get(ArtPoster_.posterId), primaryKey.getPosterId())))
      .getSingleResult();
    
    Assert.assertEquals("art", fetchedPoster.getType());
  }
	
	
	@Before
	public void before() {
		em = emf.createEntityManager();
	}
	
	@After
	public void after() {
		if (em != null) {
		  em.getTransaction().rollback();
			em.close();
			em = null;
		}
	}
	
	@BeforeClass
	public static void beforeClass() {
		emf = Persistence.createEntityManagerFactory("jpa2Pu");
	}
	
	@AfterClass
	public static void afterClass() {
		if (emf != null) {
			emf.close();
			emf = null;
		}
	}
}
