package org.foo.test.inheritance.singlePk;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("MOV")
public class MoviePoster extends Poster
{
  public MoviePoster()
  {
    setType("movie");
  }
  
  @Column(name = "foo")
  private String foo;
  
  public String getFoo()
  {
    return foo;
  }
  public void setFoo(String foo)
  {
    this.foo = foo;
  }
}
