package org.foo.test.inheritance.singlePk;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Id;

public class PosterPK implements Serializable
{  
  @Id
  @Column(name = "posterId")
  private int posterId;
  
  public PosterPK()
  {
    
  }
  public PosterPK(int posterId)
  {
    this.posterId = posterId;
  }
    
  public int getPosterId()
  {
    return posterId;
  }
  
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + posterId;
    return result;
  }
  
  @Override
  public boolean equals(Object obj)
  {
    if (obj instanceof PosterPK)
    {
      PosterPK otherBook = (PosterPK)obj;
      return posterId == otherBook.getPosterId();
    }
    else
    {
      return false;
    }
  }
}
