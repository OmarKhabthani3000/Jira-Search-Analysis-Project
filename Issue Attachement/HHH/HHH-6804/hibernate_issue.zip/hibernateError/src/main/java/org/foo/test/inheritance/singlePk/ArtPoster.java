package org.foo.test.inheritance.singlePk;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("ART")
public class ArtPoster extends Poster
{
  public ArtPoster()
  {
    setType("art");
  }
}
