package org.foo.test.inheritance.singlePk;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import org.foo.test.inheritance.common.BaseEntity;
import org.hibernate.annotations.DiscriminatorFormula;

@Entity
@Table(name = "Poster")
@IdClass(PosterPK.class)
@DiscriminatorFormula("case " +
    "when (type = 'movie') then 'MOV'" +
    "when (type = 'art') then 'ART'" +
    "end")
public abstract class Poster extends BaseEntity
{ 
  @Id
  @Column(name = "posterId")
  private int posterId;
  
  @Column(name = "type")
  private String type;
  
  public Poster()
  {
    
  }
  public Poster(int posterId)
  {
    this.posterId = posterId;
  }
    
  public int getPosterId()
  {
    return posterId;
  }
  
  public void setPosterId(int posterId)
  {
    this.posterId = posterId;
  }
  
  public String getType()
  {
    return type;
  }
  public void setType(String type)
  {
    this.type = type;
  }
}
