package org.foo.test.inheritance.multiPk;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("COM")
public class ComicBook extends Book
{
  public ComicBook()
  {
    setType("comic");
  }
}
