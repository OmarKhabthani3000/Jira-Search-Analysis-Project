package org.foo.test.inheritance.multiPk;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import org.foo.test.inheritance.common.BaseEntity;
import org.hibernate.annotations.DiscriminatorFormula;

@Entity
@Table(name = "Book")
@IdClass(BookPK.class)
@DiscriminatorFormula("case " +
    "when (type = 'SF') then 'SCI'" +
    "when (type = 'comic') then 'COM'" +
    "end")
public abstract class Book extends BaseEntity
{
  @Id
  @Column(name = "name")
  private String name;
  
  @Id
  @Column(name = "revision")
  private int revision;
  
  @Column(name = "type")
  private String type;
  
  public Book()
  {
    
  }
  public Book(String name, int revision)
  {
    this.name = name;
    this.revision = revision;
  }
  
  public String getName()
  {
    return name;
  }
  public void setName(String name)
  {
    this.name = name;
  }
  
  public int getRevision()
  {
    return revision;
  }
  public void setRevision(int revision)
  {
    this.revision = revision;
  }
  
  public String getType()
  {
    return type;
  }
  public void setType(String type)
  {
    this.type = type;
  }
}
