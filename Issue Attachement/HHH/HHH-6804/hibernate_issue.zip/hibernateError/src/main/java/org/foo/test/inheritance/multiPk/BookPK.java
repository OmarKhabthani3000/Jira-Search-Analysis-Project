package org.foo.test.inheritance.multiPk;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Id;

public class BookPK implements Serializable
{
  @Id
  @Column(name = "name")
  private String name;
  
  @Id
  @Column(name = "revision")
  private int revision;
  
  public BookPK()
  {
    
  }
  public BookPK(String name, int revision)
  {
    this.name = name;
    this.revision = revision;
  }
  
  public String getName()
  {
    return name;
  }
  
  public int getRevision()
  {
    return revision;
  }
  
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((name == null) ? 0 : name.hashCode());
    result = prime * result + revision;
    return result;
  }
  
  @Override
  public boolean equals(Object obj)
  {
    if (obj instanceof BookPK)
    {
      BookPK otherBook = (BookPK)obj;
      return name.equals(otherBook.getName()) && revision == otherBook.getRevision();
    }
    else
    {
      return false;
    }
  }
}
