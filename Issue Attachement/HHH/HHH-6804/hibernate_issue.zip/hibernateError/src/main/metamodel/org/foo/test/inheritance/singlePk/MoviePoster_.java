package org.foo.test.inheritance.singlePk;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

import org.foo.test.inheritance.multiPk.Book;

@StaticMetamodel(MoviePoster.class)
public abstract class MoviePoster_ extends Poster_ {
  public static volatile SingularAttribute<Book, String> foo;
}

