package org.foo.test.inheritance.singlePk;

import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(ArtPoster.class)
public abstract class ArtPoster_ extends Poster_ {

}

