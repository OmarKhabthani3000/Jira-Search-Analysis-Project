package org.foo.test.inheritance.multiPk;

import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(ComicBook.class)
public abstract class ComicBook_ extends Book_ {
  
}

