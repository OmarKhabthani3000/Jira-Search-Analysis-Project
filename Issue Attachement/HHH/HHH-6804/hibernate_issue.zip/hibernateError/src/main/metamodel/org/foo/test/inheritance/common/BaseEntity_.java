package org.foo.test.inheritance.common;

import javax.persistence.metamodel.StaticMetamodel;

import org.foo.test.inheritance.common.BaseEntity;

@StaticMetamodel(BaseEntity.class)
public abstract class BaseEntity_ {


}
