package org.foo.test.inheritance.multiPk;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(SciFiBook.class)
public abstract class SciFiBook_ extends Book_ {
  
  public static volatile SingularAttribute<Book, String> foo;
}

