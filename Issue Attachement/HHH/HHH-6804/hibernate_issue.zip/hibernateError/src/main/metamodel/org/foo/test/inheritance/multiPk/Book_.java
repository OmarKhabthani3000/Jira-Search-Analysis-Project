package org.foo.test.inheritance.multiPk;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

import org.foo.test.inheritance.common.BaseEntity_;
import org.foo.test.inheritance.multiPk.Book;

@StaticMetamodel(Book.class)
public abstract class Book_ extends BaseEntity_ {

  public static volatile SingularAttribute<Book, String> name;
	public static volatile SingularAttribute<Book, Integer> revision;
	public static volatile SingularAttribute<Book, String> type;
}

