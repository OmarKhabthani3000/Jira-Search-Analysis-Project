package org.foo.test.inheritance.singlePk;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

import org.foo.test.inheritance.common.BaseEntity_;

@StaticMetamodel(Poster.class)
public abstract class Poster_ extends BaseEntity_ {

	public static volatile SingularAttribute<Poster, Integer> posterId;
	public static volatile SingularAttribute<Poster, String> type;
}

