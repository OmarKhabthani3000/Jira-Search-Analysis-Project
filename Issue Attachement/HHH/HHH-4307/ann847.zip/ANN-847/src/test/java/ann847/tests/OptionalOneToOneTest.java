
package ann847.tests;

import junit.framework.Assert;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.dialect.HSQLDialect;
import org.hibernate.dialect.SQLServerDialect;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ann847.domain.Address;
import ann847.domain.Person;

public class OptionalOneToOneTest {
	
	private static Logger logger = LoggerFactory.getLogger(OptionalOneToOneTest.class);
	private static Configuration cfg = null;
	private static SessionFactory sf = null;
	
	@BeforeClass
	public static void buildSessionFactory() {
		cfg = new AnnotationConfiguration().configure();
		sf = cfg.buildSessionFactory();
		
		String[] schema = cfg.generateSchemaCreationScript(new HSQLDialect());
		
		for (String line : schema) {
			logger.debug(line);
		}
	}
	
	@Test
	public void createSinglePerson() {
		Transaction tx = null;
		
		try {
			tx = getSession().beginTransaction();
			
			getSession().save(new Person());
			
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			
			Assert.fail(e.getMessage());
		}
	}
	
	@Test
	public void createSingleAddress() {
		Transaction tx = null;
		
		try {
			tx = getSession().beginTransaction();
			
			getSession().save(new Address());
			
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			
			Assert.fail(e.getMessage());
		}
	}
	
	private static Session getSession() {
		return sf.getCurrentSession();
	}
}
