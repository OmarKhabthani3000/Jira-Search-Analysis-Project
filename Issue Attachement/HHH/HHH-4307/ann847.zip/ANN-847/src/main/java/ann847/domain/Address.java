
package ann847.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Address {
	
	@Id
	@GeneratedValue
	private long id;
	
	@OneToOne(mappedBy = "address")
	public Person person;

}
