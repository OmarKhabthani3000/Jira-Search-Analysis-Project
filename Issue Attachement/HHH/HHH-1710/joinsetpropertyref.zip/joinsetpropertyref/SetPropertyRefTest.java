package org.hibernate.test.joinsetpropertyref;

public class SetPropertyRefTest extends AbstractSetPropertyRefTestCase {

	public SetPropertyRefTest(String name) {
		super(name);
	}

	protected String[] getMappings() {
		return new String[]{"joinsetpropertyref/BookNoJoin.hbm.xml"};
	}
}
