package org.hibernate.test.joinsetpropertyref;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Book {
	
	public Book() {
	}

	public Book(String name, String author, String isbn) {
		this.name = name;
		this.author = author;
		this.isbn = isbn;
	}

	private long id;
	
	private String name;
	
	private String author;
	
	private String isbn;
	
	private Set chapters = new HashSet();
	
	public void add(Chapter aChapter) {
		chapters.add(aChapter);
	}

	public long getId() {
		return id;
	}

	public Set getChapters() {
		return chapters;
	}
}
