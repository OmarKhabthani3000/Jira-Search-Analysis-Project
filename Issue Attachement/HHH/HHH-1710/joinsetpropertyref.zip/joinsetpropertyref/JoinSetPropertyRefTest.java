package org.hibernate.test.joinsetpropertyref;

public class JoinSetPropertyRefTest extends AbstractSetPropertyRefTestCase {

	public JoinSetPropertyRefTest(String name) {
		super(name);
	}

	protected String[] getMappings() {
		return new String[]{"joinsetpropertyref/Book.hbm.xml"};
	}
}
