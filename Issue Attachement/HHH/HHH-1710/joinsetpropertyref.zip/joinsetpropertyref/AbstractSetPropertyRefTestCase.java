package org.hibernate.test.joinsetpropertyref;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.test.TestCase;

public abstract class AbstractSetPropertyRefTestCase extends TestCase {

	public AbstractSetPropertyRefTestCase(String name) {
		super(name);
	}

	public final void testSave() {
		Session s = openSession();
		Transaction t = s.beginTransaction();
		Book book = new Book("book1","author1","ISBN-001");
		book.add(new Chapter("chapter1"));
		book.add(new Chapter("chapter2"));
		s.save(book);
		t.commit();
		s.close();
	}

	public final void testFindByAuthor() {
		insertTestData();
		
		Session s = openSession();
		Transaction t = s.beginTransaction();
		List list = s.createQuery("from Book b left join fetch b.chapters where author=:author").setString("author","author1").setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		t.commit();
		s.close();
		
		assertEquals(2,list.size());
	}

	public final void testFindByAuthorByCriteria() {
		insertTestData();
		
		Session s = openSession();
		Transaction t = s.beginTransaction();
		List list = s.createCriteria(Book.class).add(Restrictions.eq("author","author1")).setFetchMode("chapters",FetchMode.JOIN).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		t.commit();
		s.close();
		
		assertEquals(2,list.size());
	}

	private void insertTestData() {
		Session s = openSession();
		Transaction t = s.beginTransaction();
		Book book = new Book("book1","author1","ISBN-001");
		book.add(new Chapter("chapter1"));
		book.add(new Chapter("chapter2"));
		s.save(book);
		book = new Book("book2","author1","ISBN-002");
		book.add(new Chapter("chapter3"));
		book.add(new Chapter("chapter4"));
		s.save(book);
		book = new Book("book3","author2","ISBN-003");
		book.add(new Chapter("chapter5"));
		book.add(new Chapter("chapter6"));
		s.save(book);
		t.commit();
		s.close();
	}

	public final void testLoad() {
		Session s = openSession();
		Transaction t = s.beginTransaction();
		Book book = new Book("book1","author1","ISBN-001");
		book.add(new Chapter("chapter1"));
		book.add(new Chapter("chapter2"));
		s.save(book);
		t.commit();
		s.close();
		
		s = openSession();
		t = s.beginTransaction();
		Book loaded = (Book) s.get(Book.class,new Long(book.getId()));
		t.commit();
		s.close();
		
		assertEquals(2,loaded.getChapters().size());
	}

	private void deleteAllBooks() {
		Session s = openSession();
		Transaction t = s.beginTransaction();
		s.createQuery("delete from Chapter").executeUpdate();
		s.createQuery("delete from Book").executeUpdate();
		t.commit();
		s.close();
	}

	protected void setUp() throws Exception {
		super.setUp();
		deleteAllBooks();
	}

}
