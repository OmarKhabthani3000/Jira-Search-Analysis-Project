package org.hibernate.test.joinsetpropertyref;

public class Chapter {
	
	public Chapter() {
	}
	
	public Chapter(String name) {
		this.name = name;
	}

	private long id;
	
	private String name;
}	
