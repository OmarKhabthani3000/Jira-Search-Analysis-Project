package com.example.bug;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Alessandro Polverini <alex@polverini.org>
 */
public interface ARepository extends JpaRepository<AEntity, Long> {

}
