package com.example.bug;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;

/**
 *
 * @author Alessandro Polverini <alex@polverini.org>
 */
@Entity
public class BEntity {

  @Id
  private Long id;

  @MapsId
  @OneToOne(optional = false)
  @JoinColumn(name = "id")
  private AEntity a;

  private String desc;

  public BEntity() {
  }

  public BEntity(AEntity a, String desc) {
    this.a = a;
    this.desc = desc;
  }

  public AEntity getA() {
    return a;
  }

  public void setA(AEntity a) {
    this.a = a;
  }

  public String getDesc() {
    return desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }

  @Override
  public String toString() {
    return "B[" + desc + " " + a + "]";
  }

}
