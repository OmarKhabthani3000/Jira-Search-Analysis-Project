package com.example.bug;

import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

/**
 *
 * @author Alessandro Polverini <alex@polverini.org>
 */
@DataJpaTest
public class HibTest {

  @Autowired
  private ARepository aRepo;

  @Autowired
  private BRepository bRepo;

  public void out(Object s) {
    System.out.println(s);
  }

  //@Test
  public void HHH13748() {
    out("--- Empty Collection Test");
    List<BEntity> res = bRepo.getFromList(List.of());
    assertNotNull(res);
    assertTrue(res.isEmpty());
  }

  @Test
  public void singleCollectionTest() {
    out("--- SingleCollectionTest");
    AEntity a1 = new AEntity("a1");
    aRepo.save(a1);
    BEntity b1 = new BEntity(a1, "b1");
    bRepo.save(b1);

    List<BEntity> res = bRepo.getFromList(List.of(a1));
    assertNotNull(res);
    assertEquals(1, res.size());

    res = bRepo.getFromList(List.of(a1));
    res.forEach(o -> out(o));
    assertNotNull(res);
    assertEquals(1, res.size());
  }

  @Test
  public void HHH13749() {
    out("--- Two elements collection test");
    AEntity a1 = new AEntity("a1");
    aRepo.save(a1);
    AEntity a2 = new AEntity("a2");
    aRepo.save(a2);

    BEntity b1 = new BEntity(a1, "b1");
    bRepo.save(b1);
    BEntity b2 = new BEntity(a2, "b2");
    bRepo.save(b2);

    List<BEntity> res = bRepo.getFromList(List.of(a1, a2));
    res.forEach(o -> out(o));
    assertNotNull(res);
    assertEquals(2, res.size());

    out("---");
  }
}
