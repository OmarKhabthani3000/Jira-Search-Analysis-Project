package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Entity
	static class Entity13651 {

		private Integer id;
		private List<String> strList;

		Entity13651() {}

		Entity13651(Integer id) {
			this.id = id;
		}

		@Id
		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		@ElementCollection
		@CollectionTable(name="e_2_string", joinColumns=@JoinColumn(name="e_id"))
		@Column(name="string_value", unique = false, nullable = true, insertable = true, updatable = true)
		public List<String> getStrList() {
			return strList;
		}

		public void setStrList(List<String> strList) {
			this.strList = strList;
		}

	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh12002Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		Entity13651 e = new Entity13651(1);
		ArrayList<String> strList = new ArrayList<>();
		strList.add(null);
		e.setStrList(strList);
		entityManager.persist(e);

		entityManager.flush();

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
