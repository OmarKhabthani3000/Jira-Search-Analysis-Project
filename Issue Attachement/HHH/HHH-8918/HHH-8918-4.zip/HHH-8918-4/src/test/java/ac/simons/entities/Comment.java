package ac.simons.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.annotations.DiscriminatorOptions;

@Entity
@Table(name = "comments")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(
        name = "commentable_type",
        discriminatorType = DiscriminatorType.STRING
)
@DiscriminatorOptions(force = true)
public abstract class Comment implements Serializable {

    @Entity
    @DiscriminatorValue("News")
    public static class BulletinComment extends Comment {

        private static final long serialVersionUID = 525829015554582275L;

        @JoinColumn(name = "commentable_id", referencedColumnName = "id")
        @ManyToOne(fetch = FetchType.EAGER, optional = false)
        private Bulletin commentable;

        public Bulletin getCommentable() {
            return commentable;
        }

        public void setCommentable(Bulletin commentable) {
            this.commentable = commentable;
        }
    }

    @Entity
    @DiscriminatorValue("Page")
    public static class PageComment extends Comment {

        private static final long serialVersionUID = 525829015554582275L;

        @JoinColumn(name = "commentable_id", referencedColumnName = "id")
        @ManyToOne(fetch = FetchType.EAGER, optional = false)
        private Page commentable;

        public Page getCommentable() {
            return commentable;
        }

        public void setCommentable(Page commentable) {
            this.commentable = commentable;
        }
    }

    private static final long serialVersionUID = 2425739099280354694L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "text")
    private String text;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

}
