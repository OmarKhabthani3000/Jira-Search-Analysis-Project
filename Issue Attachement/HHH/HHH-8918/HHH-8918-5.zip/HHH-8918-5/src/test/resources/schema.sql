drop table comments;
drop table pages;
drop table news;
drop table activities;

create table comments (id integer not null, commentable_id integer not null, commentable_type varchar(8) not null, name varchar(128) not null, text varchar(512) not null);
create table pages(id integer not null, name varchar(128) not null);
create table news(id integer not null, text varchar(512) not null);
create table activities(id integer not null, reference_object_id integer not null);

insert into news values(23, 'test news');
insert into pages values(42, 'test page');

insert into comments(id, commentable_id, commentable_type, name, text) values(1, 23, 'News', 'Michael', 'Test 1');
insert into comments(id, commentable_id, commentable_type, name, text) values(2, 42, 'Page', 'Michael', 'Test 2');

insert into activities values(1, 1);
insert into activities values(2, 2);

commit;