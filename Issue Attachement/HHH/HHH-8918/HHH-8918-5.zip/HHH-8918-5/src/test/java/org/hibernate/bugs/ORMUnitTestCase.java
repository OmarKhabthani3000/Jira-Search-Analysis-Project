/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import ac.simons.entities.Activity;
import ac.simons.entities.Comment;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Assert;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 *
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
                    ac.simons.entities.Activity.class,
                    ac.simons.entities.Bulletin.class,
                    ac.simons.entities.Comment.class,
                    ac.simons.entities.Comment.BulletinComment.class,
                    ac.simons.entities.Comment.PageComment.class,
                    ac.simons.entities.Page.class  
            	};
	}

	// If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
	@Override
	protected String[] getMappings() {
		return new String[] {
//				"Foo.hbm.xml",
//				"Bar.hbm.xml"
		};
	}
	// If those mappings reside somewhere other than resources/org/hibernate/test, change this.
	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/test/";
	}
        
	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );
                configuration.setProperty("hibernate.hbm2ddl.auto", "validate");
//		configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, "true" );
	}

	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		// BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		 // Make sure comments and commentables are setup correct
                // Compare this to schema.sql
                // Also: I've included the database inside this test as
                // the schema exporter adds foreign keys from comment to pages and news 
                // which is not correct. There is explicitly no foreign key. It would only
                // makes sense including the discriminator column.
                Comment.BulletinComment newsComment = (Comment.BulletinComment) s.load(Comment.BulletinComment.class, 1);
                Assert.assertNotNull(newsComment);
                Assert.assertEquals("Test 1", newsComment.getText());
                Assert.assertEquals("test news", newsComment.getCommentable().getText());
              
                Comment.PageComment pageComment = (Comment.PageComment) s.load(Comment.PageComment.class, 2);
                Assert.assertNotNull(pageComment);
                Assert.assertEquals("Test 2", pageComment.getText());
                Assert.assertEquals("test page", pageComment.getCommentable().getName());
              
             
                // There are 2 activities, each for one comment
                // In my application, those acitivites have a purpose, 
                // inside this test they are stripped of everything
                
                // As soon as there are 2 activities pointing to comments
                // of different type, this fails:
                Activity a1 = (Activity) s.load(Activity.class, 1);
                Assert.assertNotNull(a1);
                Assert.assertNotNull(a1.getObject());
                Assert.assertTrue(a1.getObject() instanceof Comment.BulletinComment);
                Assert.assertEquals("Test 1", a1.getObject().getText());
                
                Activity a2 = (Activity) s.load(Activity.class, 2);
                Assert.assertNotNull(a2);
                Assert.assertNotNull(a2.getObject());
                Assert.assertTrue(a2.getObject() instanceof Comment.PageComment);
                Assert.assertEquals("Test 2", a1.getObject().getText());
                
                // Hibernate 4.3.0
                // No row with the given identifier exists: [ac.simons.entities.Activity#1]
                /* Wrong query:
                
                 select
        activity0_.id as id1_0_0_,
        activity0_.reference_object_id as referenc2_0_0_,
        comment1_.id as id2_1_1_,
        comment1_.name as name3_1_1_,
        comment1_.text as text4_1_1_,
        comment1_.commentable_id as commenta5_1_1_,
        comment1_.commentable_type as commenta1_1_1_,
        page2_.id as id1_3_2_,
        page2_.name as name2_3_2_ 
    from
        activities activity0_ 
    inner join
        comments comment1_ 
            on activity0_.reference_object_id=comment1_.id 
    inner join
        pages page2_  -- This join is wrong!
            on comment1_.commentable_id=page2_.id 
    where
        activity0_.id=?
   
                */
                
                // Hibernate 4.3.11
                // Another wrong query
                /*
                select
        activity0_.id as id1_0_0_,
        activity0_.reference_object_id as referenc2_0_0_,
        comment1_.id as id2_1_1_,
        comment1_.name as name3_1_1_,
        comment1_.text as text4_1_1_,
        comment1_.commentable_id as commenta5_1_1_,
        comment1_.commentable_type as commenta1_1_1_,
        page2_.id as id1_3_2_,
        page2_.name as name2_3_2_ 
    from
        activities activity0_ 
    inner join
        comments comment1_ 
            on activity0_.reference_object_id=comment1_.id 
    left outer join
        pages page2_ 
            on comment1_.commentable_id=page2_.id 
    where
        activity0_.id=?
                */
		tx.commit();
		s.close();
	}
}
