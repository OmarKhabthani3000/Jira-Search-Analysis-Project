4 spring profiles are provided to run test :
- nocache : No cache used => Test pass
- ehcache-nojta : simple ehcache with JpaTransactionManager as TM => Test pass
- ehcache-jbossjta : ehcache with JTA JBoss Transaction Manager => Test fail
- infinispan-no-server : Infinispan with JTA JBoss Transaction Manager => Test fail

To run the test :
> mvn test -Dspring.profiles.active=$PROFILE

ex: 
> mvn test -Dspring.profiles.active=infinispan-no-server
