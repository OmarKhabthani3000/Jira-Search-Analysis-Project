package com.test.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.test.domain.model.User;
import com.test.domain.repository.UserRepository;
import com.test.service.UserService;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Resource
	UserRepository userRepository;

	@Override
	public void updateUserName(Long userId, String name) {
		User user = userRepository.findOne(userId);
		
		if(user == null) {
			throw new RuntimeException("No User found with id "+userId);
		}
		
		user.setName(name);
		userRepository.save(user);
	}

	@Override
	public User findById(Long userId) {
		return userRepository.findOne(userId);
	}

}
