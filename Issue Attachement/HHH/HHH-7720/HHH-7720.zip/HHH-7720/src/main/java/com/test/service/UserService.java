package com.test.service;

import com.test.domain.model.User;

public interface UserService {
	
	public User findById(Long userId);
	
	public void updateUserName(Long userId, String name);

}
