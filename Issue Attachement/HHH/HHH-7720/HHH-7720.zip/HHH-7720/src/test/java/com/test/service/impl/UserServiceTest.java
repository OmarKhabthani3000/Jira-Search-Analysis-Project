package com.test.service.impl;

import javax.annotation.Resource;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.test.domain.model.User;
import com.test.service.UserService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
public class UserServiceTest {

	@Resource
	UserService userService;

	@Test
	public void testUpdateUserName() {
		User userBeforeUpdate = userService.findById(1L);

		assertNotNull(userBeforeUpdate);
		assertEquals("John.Doe", userBeforeUpdate.getName());

		userService.updateUserName(1L, "Oscar.Peterson");
		
		User userAfterUpdate = userService.findById(1L);		
		assertEquals("Oscar.Peterson", userAfterUpdate.getName());
		
	}

}
