package org.hibernate.test.hhh5932;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Id;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.Table;

import org.hibernate.Session;
import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.ParamDef;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestHhh5932 {

	private static EntityManager entityManager;
	private static TestEntity5932 testEntity5932;
	private static Query query;

	@BeforeClass
	public static void beforeClass() {
		initializeEntityManager();
		createTestData();
		createQuery();
	}

	private static void initializeEntityManager() {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory(
				"Test5932", null);
		entityManager = factory.createEntityManager();
	}

	private static void createTestData() {
		testEntity5932 = new TestEntity5932();
		testEntity5932.setId(1l);
		// testEntity5932.setName("test"); // ok
		testEntity5932.setName(":test"); // error

		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		entityManager.persist(testEntity5932);
		transaction.commit();
	}

	private static void createQuery() {
		query = entityManager
				.createQuery("from TestHhh5932$TestEntity5932 o where name = '"
						+ testEntity5932.getName() + "'");
	}

	@Before
	public void beforeTest() {
		entityManager.clear();
		entityManager.unwrap(Session.class).disableFilter(
				TestEntity5932.FILTER_NAME);
	}

	@Test
	public void testHhh5932WithoutFilter() {
		Object result = null;
		try {
			result = query.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
		Assert.assertNotNull(result);
	}

	@Test
	public void testHhh5932WithFilter() {
		entityManager
				.unwrap(Session.class)
				.enableFilter(TestEntity5932.FILTER_NAME)
				.setParameter(TestEntity5932.FILTER_PARAM_NAME,
						testEntity5932.getId());

		Object result = null;
		try {
			result = query.getSingleResult();
		} catch (NoResultException e) {
			// with active filter we will NOT find the entity
			result = null;
		} catch (Exception e) {
			// FIXME Invalid filter-parameter name format is thrown!!!
			e.printStackTrace();
			Assert.fail();
		}
		Assert.assertNull(result);
	}

	@AfterClass
	public static void afterClass() {
		entityManager.close();
	}

	/**
	 * Test entity class for HHH-5932.
	 * 
	 * @author s.a.m.
	 */
	@Entity
	@Table(name = "Test5932")
	@FilterDef(name = TestEntity5932.FILTER_NAME, parameters = @ParamDef(name = TestEntity5932.FILTER_PARAM_NAME, type = "long"))
	@Filter(name = TestEntity5932.FILTER_NAME, condition = "TEST_ID > :"
			+ TestEntity5932.FILTER_PARAM_NAME)
	public static class TestEntity5932 {

		public static final String FILTER_NAME = "test5932";
		public static final String FILTER_PARAM_NAME = "test5932Param";

		private Long id;
		private String name;

		@Id
		@Column(name = "TEST_ID")
		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		@Column(name = "TEST_NAME")
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
	}
}
