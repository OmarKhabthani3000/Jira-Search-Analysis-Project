
package com.jpabugreport;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.MappedSuperclass;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@MappedSuperclass
@IdClass(Employee.PrimaryKey.class)
public abstract class Employee extends Person {

	protected int badgeNumber;

	/**
	 * Gets the value of the portId property.
	 * 
	 */
	@Id
	public int getBadgeNumber() {
		return badgeNumber;
	}

	public void setBadgeNumber(int badgeNumber) {
		this.badgeNumber = badgeNumber;
	}

	public static class PrimaryKey implements Serializable {

		private static final long serialVersionUID = 1L;

		private String ssn;
		private int badgeNumber;

		public PrimaryKey() {
		}

		public PrimaryKey(String ssn, int badgeNumber) {
			this.ssn = ssn;
			this.badgeNumber = badgeNumber;
		}

		public String getSsn() {
			return ssn;
		}

		public void setSsn(String ssn) {
			this.ssn = ssn;
		}

		public int getBadgeNumber() {
			return badgeNumber;
		}

		public void setBadgeNumber(int badgeNumber) {
			this.badgeNumber = badgeNumber;
		}

		@Override
		public boolean equals(Object obj) {
			if (obj == null)
				return false;
			return EqualsBuilder.reflectionEquals(this, obj);
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this);
		}
	}

}
