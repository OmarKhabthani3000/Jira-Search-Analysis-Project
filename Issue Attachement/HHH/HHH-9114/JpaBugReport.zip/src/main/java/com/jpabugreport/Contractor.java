package com.jpabugreport;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "Contractors")
public class Contractor extends Employee implements Serializable
{
	private static final long serialVersionUID = 1L;

	private long contractExpiration;

	@Column
	public long getContractExpiration() {
		return contractExpiration;
	}

	public void setContractExpiration(long contractExpiration) {
		this.contractExpiration = contractExpiration;
	}
}
