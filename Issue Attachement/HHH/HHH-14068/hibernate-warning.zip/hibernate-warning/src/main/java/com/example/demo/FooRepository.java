package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.*;

@Repository
public interface FooRepository extends JpaRepository<FooRepository.Foo, Integer> {

    @Entity
    @Inheritance(strategy = InheritanceType.JOINED)
    @DiscriminatorColumn(name = "type")
    class Foo {
        @Id
        @GeneratedValue
        Integer id;
   }
}
