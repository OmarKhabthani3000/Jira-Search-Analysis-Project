package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Repository
public interface BarRepository extends JpaRepository<BarRepository.Bar, Integer> {

    @Entity
    class Bar extends FooRepository.Foo {
        @Column
        String bar;
   }
}
