package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Repository
public interface BazRepository extends JpaRepository<BazRepository.Baz, Integer> {

    @Entity
    class Baz extends FooRepository.Foo {
        @Column
        String baz;
   }
}
