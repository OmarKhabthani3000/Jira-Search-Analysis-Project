package com.rreps.core.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.security.core.GrantedAuthority;

/**
 * This class is used to represent available roles in the database.
 */
@Entity
@Table(name = "roles")
public class Role extends BaseObject implements Serializable, GrantedAuthority {

    private static final long serialVersionUID = 3690197650654049848L;
    
    private String name;
    private String displayName;
    private String description;

    public Role() {}

    public Role(final String name) {
        this.name = name;
    }

    @Override
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    @NotNull
	@Size(min = 5, max = 50)
    @Column(length = 50, nullable = false, unique = true)
    public String getName() {
        return this.name;
    }

    @NotNull
	@Size(min = 5, max = 50)
    @Column(length = 50, nullable = false, unique = true)
    public String getDisplayName() {
        return this.displayName;
    }

    @Size(min = 1, max = 256)
    @Column(length = 256)
    public String getDescription() {
        return this.description;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Transient
    public String getAuthority() {
        return getName();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Role)) {
            return false;
        }

        final Role role = (Role) o;

        return !(name != null ? !name.equals(role.name) : role.name != null);

    }

    @Override
    public int hashCode() {
        return (name != null ? name.hashCode() : 0);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SIMPLE_STYLE).append(this.name).toString();
    }

	public int compareTo(GrantedAuthority o) {
		if (this == o){
			return 0;
		}
		return getAuthority().compareTo(o.getAuthority());
    }

}
