package com.rreps.core.dao;

import java.util.List;

public interface ReportDao{
    
    List<Object[]> userReport();
    
    List<Object[]> userReportHack();
}
