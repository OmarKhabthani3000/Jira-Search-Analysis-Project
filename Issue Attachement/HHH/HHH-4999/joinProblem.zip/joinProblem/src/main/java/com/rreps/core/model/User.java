package com.rreps.core.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * This class represents the basic "user" object that allows for authentication
 * and user management. It implements springsecurity's UserDetails interface.
 */
@Entity
@Table(name = "users")
public class User extends BaseObject implements Serializable, UserDetails {

	private static final long serialVersionUID = 3832626162173359411L;

	private String username;
	private String password;
	private String confirmPassword;
	private String email;
	private Integer version;
	private Role role;
	private boolean enabled;
	private String firstname;
	private String lastname;
	private Center center;

	public User() {}

	public User(final String username) {
		this.username = username;
	}

	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	@NotNull
	@Size(min = 3, max = 20)
	@Column(nullable = false, length = 20, unique = true)
	public String getUsername() {
		return username;
	}

	@NotNull
	@Size(min = 8, max = 15)
	@Column(nullable = false, length = 15)
	public String getPassword() {
		return password;
	}

	@NotNull
	@Size(min = 1, max = 50)
	@Column(name = "first_name", nullable = false, length = 50)
	public String getFirstname() {
		return firstname;
	}

	@NotNull
	@Size(min = 1, max = 50)
	@Column(name = "last_name", nullable = false, length = 50)
	public String getLastname() {
		return lastname;
	}

	@Version
	public Integer getVersion() {
		return version;
	}

	@Column(name = "enabled", columnDefinition = "BOOLEAN default 0")
	public boolean isEnabled() {
		return enabled;
	}

	@NotNull
	@Size(min = 6, max = 50)
	@Pattern(regexp = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[_A-Za-z0-9-]+)")
	@Column(nullable = false, unique = false)
	public String getEmail() {
		return email;
	}

	@NotNull
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "role_id", nullable = false)
	public Role getRole() {
		return role;
	}

	@Transient
	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public void setCenter(Center center) {
	    this.center = center;
    }

	@NotNull
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "center_id", nullable = false)
	public Center getCenter() {
	    return center;
    }

	@Transient
	public String getFullName() {
		return firstname + ' ' + lastname;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (!(o instanceof User)) {
			return false;
		}
		final User user = (User) o;
		return !(username != null ? !username.equals(user.getUsername()) : user.getUsername() != null);

	}

	@Override
	public int hashCode() {
		return (username != null ? username.hashCode() : 0);
	}

	@Override
	public String toString() {
		ToStringBuilder sb = new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE).append("username", this.username)
		        .append("enabled", this.enabled);

		Collection<GrantedAuthority> auths = this.getAuthorities();
		if (auths != null) {
			sb.append("Granted Authorities: ");

			for (GrantedAuthority grantedAuthority : auths) {
				sb.append(grantedAuthority.toString() + " ");
            }
		}
		else {
			sb.append("No Granted Authorities");
		}
		return sb.toString();
	}

	/**
	 * @see org.acegisecurity.userdetails.UserDetails#getAuthorities()
	 * @return GrantedAuthority[] an array of roles.
	 */
	@Transient
	public Collection<GrantedAuthority> getAuthorities() {
		ArrayList<GrantedAuthority> l = new ArrayList<GrantedAuthority>();
		if (this.role != null) {
			l.add(this.role);
		}
		return l;
	}

	@Transient
	public boolean isAccountNonExpired() {
		return true;
	}

	@Transient
	public boolean isAccountNonLocked() {
		return true;
	}

	@Transient
	public boolean isCredentialsNonExpired() {
		return true;
	}
}
