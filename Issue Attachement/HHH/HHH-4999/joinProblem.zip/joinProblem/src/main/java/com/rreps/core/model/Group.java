package com.rreps.core.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

@Entity
@Table(name = "groupe")
public class Group extends BaseObject implements Serializable {

	private static final long serialVersionUID = -5630993148201477562L;

	private String name;
	private List<Center> centers = new ArrayList<Center>();
	private boolean siteCoordinateur = false;
	private boolean centreReference = true;

	public Group() {
	}

	public Group(final String name, boolean siteCoordinateur, boolean centreReference) {
		this.name = name;
		this.siteCoordinateur = siteCoordinateur;
		this.centreReference = centreReference;
	}

	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	@NotNull
	@Size(min = 5, max = 50)
	@Column(nullable = false, length = 50, unique = true)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@OneToMany(mappedBy = "group", cascade = CascadeType.ALL)
	@OrderBy(value = "name")
	public List<Center> getCenters() {
		return centers;
	}

	public void addCenter(Center c){
		centers.add(c);
		c.setGroup(this);
	}
	
	public void setCenters(List<Center> centers) {
		this.centers = centers;
	}

	public void setCentreReference(boolean centreReference) {
	    this.centreReference = centreReference;
    }

	@Column(name = "centrereference", nullable = false, columnDefinition = "BOOLEAN")
	public boolean isCentreReference() {
	    return centreReference;
    }

	public void setSiteCoordinateur(boolean siteCoordinateur) {
	    this.siteCoordinateur = siteCoordinateur;
    }

	@Column(name = "sitecoordinateur", nullable = false, columnDefinition = "BOOLEAN")
	public boolean isSiteCoordinateur() {
	    return siteCoordinateur;
    }

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (!(o instanceof Group)) {
			return false;
		}
		final Group s = (Group) o;
		return !(name != null ? !name.equals(s.getName()) : s.getName() != null);
	}

	@Override
	public int hashCode() {
		return (name != null ? name.hashCode() : 0);
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE).append("name", this.name).toString();
	}
}
