package com.rreps.core.dao.hibernate;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.rreps.core.dao.ReportDao;

@Repository
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class ReportDaoHibernate extends HibernateDaoSupport implements ReportDao, Serializable {

	private static final long serialVersionUID = -6047386290014248846L;

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	public void setTheSessionFactory(@Qualifier("sessionFactory") SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@SuppressWarnings("unchecked")
	public List<Object[]> userReportHack() {
		//notice use of "CONCAT('', center.name)"
		String query = "SELECT groupe.name, CONCAT('', center.name), roles.displayname, users.username, CASE WHEN center.id = 2 THEN 1 ELSE 0 END AS showlast "
		        + "FROM groupe, center, users, roles WHERE users.role_id = roles.id AND users.center_id = center.id "
		        + "AND center.group_id = groupe.id ORDER BY showlast, groupe.sitecoordinateur DESC, groupe.name, center.headcenter DESC, center.name, roles.id";

		return getSession().createSQLQuery(query).list();
	}
	
	@SuppressWarnings("unchecked")
	public List<Object[]> userReport() {
		String query = "SELECT groupe.name, center.name, roles.displayname, users.username, CASE WHEN center.id = 2 THEN 1 ELSE 0 END AS showlast "
		        + "FROM groupe, center, users, roles WHERE users.role_id = roles.id AND users.center_id = center.id "
		        + "AND center.group_id = groupe.id ORDER BY showlast, groupe.sitecoordinateur DESC, groupe.name, center.headcenter DESC, center.name, roles.id";

		return getSession().createSQLQuery(query).list();
	}

}
