package com.rreps.core.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

@Entity
@Table(name = "center")
public class Center extends BaseObject implements Serializable {

	private static final long serialVersionUID = -5630993148201477562L;
	
	private String name;
	private Group group;
	private boolean headCenter = false;
	
	public Center() {
	}

	public Center(final String name) {
		this.name = name;
	}
	
	public Center(final String name, boolean head) {
		this.name = name;
		this.headCenter = head;
	}
	
	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	public void setName(String name) {
		this.name = name;
	}

	@NotNull
	@Size(min = 2, max = 50)
	@Column(nullable = false, length = 50, unique = true)
	public String getName() {
		return name;
	}

	public void setGroup(Group group) {
	    this.group = group;
    }

	@NotNull
	@ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH })
	@JoinColumn(nullable=false, updatable= false, name = "group_id")
	public Group getGroup() {
	    return group;
    }
	
	public void setHeadCenter(boolean b) {
	    this.headCenter = b;
    }

	@Column(name = "headcenter", nullable = false, columnDefinition = "BOOLEAN")
	public boolean isHeadCenter() {
	    return headCenter;
    }
	
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (!(o instanceof Center)) {
			return false;
		}
		final Center s = (Center) o;
		return !(name != null ? !name.equals(s.getName()) : s.getName() != null);
	}

	@Override
	public int hashCode() {
		return (name != null ? name.hashCode() : 0);
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE).append("name", this.name).toString();
	}
}
