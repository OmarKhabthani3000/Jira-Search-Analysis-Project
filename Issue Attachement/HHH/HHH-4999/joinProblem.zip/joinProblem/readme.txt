Hi!

to reproduce it : 
1) you must have a database named 'joinProblem' already existing.
2) mvn install -Pdb-create,db-insert-test-data

--Thomas