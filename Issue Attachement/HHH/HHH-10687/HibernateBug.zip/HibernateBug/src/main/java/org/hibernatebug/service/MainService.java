package org.hibernatebug.service;

import org.hibernatebug.dao.ServiceDao;
import org.springframework.transaction.annotation.Transactional;

public class MainService
{
	public MainService(ServiceDao serviceDao)
	{
		this.serviceDao = serviceDao;
	}

	private ServiceDao serviceDao;

	@Transactional
	public void serviceMethodBroken()
	{
		serviceDao.createParentAndChild();

		serviceDao.flush();
	}

	@Transactional
	public void serviceMethodWorking()
	{
		serviceDao.createParentAndChild();
	}

	@Transactional(readOnly = true)
	public int parentCount()
	{
		return serviceDao.parentCount();
	}

	@Transactional(readOnly = true)
	public int childCount()
	{
		return serviceDao.childCount();
	}
}
