package org.hibernatebug.dao;

import org.hibernatebug.entity.Child;
import org.hibernatebug.entity.Parent;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

public class ServiceDao extends HibernateDaoSupport
{
	public void createParentAndChild()
	{
		Parent p = new Parent();

		p.addChild(new Child());
		p.addChild(new Child());

		getHibernateTemplate().merge(p);
	}

	public void flush()
	{
		getHibernateTemplate().flush();
	}

	public int parentCount()
	{
		return getHibernateTemplate().loadAll(Parent.class).size();
	}

	public int childCount()
	{
		return getHibernateTemplate().loadAll(Child.class).size();
	}
}
