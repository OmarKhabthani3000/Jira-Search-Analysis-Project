package org.hibernatebug.bean;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;

import org.hibernatebug.service.MainService;

@ManagedBean(name = "hibernateBug")
@RequestScoped
public class HibernateBug
{
	@ManagedProperty("#{mainService}")
	private MainService service;

	public String getMessage()
	{
		return "Fixed HibernateBug Message";
	}

	public void actionBroken()
	{
		service.serviceMethodBroken();
	}

	public void actionWorking()
	{
		service.serviceMethodWorking();
	}

	public void setService(MainService service)
	{
		this.service = service;
	}

	public int getParentCount()
	{
		return service.parentCount();
	}

	public int getChildCount()
	{
		return service.childCount();
	}
}
