package test;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Vehicle
{
	@Id
	@GeneratedValue
	private Long id;

	@Column(length = 17)
	private String vin;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "VEHICLE_TAG", 
		joinColumns = {@JoinColumn(name = "VEHICLE_ID", referencedColumnName = "ID")}, 
		inverseJoinColumns = {@JoinColumn(name = "TAG_ID", referencedColumnName = "ID")})
	private Set<Tag> vehicleTags;

	Vehicle()
	{
		super();
	}

	public Vehicle(String vin)
	{
		this.vin = vin;
	}

	public Long getId()
	{
		return id;
	}

	public String getVin()
	{
		return vin;
	}

	public Set<Tag> getVehicleTags()
	{
		return vehicleTags;
	}

	public void addVehicleTag(Tag tag)
	{
		if (vehicleTags == null)
			vehicleTags = new HashSet<Tag>();

		vehicleTags.add(tag);
	}

	@Override
	public String toString()
	{
		return "Vehicle [vin=" + vin + ", vehicleTags=" + vehicleTags + "]";
	}
}
