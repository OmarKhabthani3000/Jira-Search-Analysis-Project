package test;

import java.util.List;

import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Main
{
	private static final Logger LOG = LoggerFactory.getLogger(Main.class);

	private static SessionFactory sessionFactory;

	public static void main(String[] args)
	{
		AnnotationConfiguration cfg = new AnnotationConfiguration().addAnnotatedClass(Vehicle.class)
			.addAnnotatedClass(Tag.class).setProperty("hibernate.dialect", "org.hibernate.dialect.H2Dialect")
			.setProperty("hibernate.connection.driver_class", "org.h2.Driver")
			.setProperty("hibernate.connection.url", "jdbc:h2:mem:test")
			.setProperty("hibernate.connection.username", "sa").setProperty("hibernate.connection.password", "sa")
			.setProperty("hibernate.hbm2ddl.auto", "create");

		sessionFactory = cfg.buildSessionFactory();

		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();

		Tag tag1 = new Tag("TAG1");
		session.save(tag1);
		Tag tag2 = new Tag("TAG2");
		session.save(tag2);

		LOG.info("Inserting vehicles:");
		for (int i = 0; i < 10; i++)
		{
			Vehicle vehicle = new Vehicle("WVWZZZ1KZ1234567" + i);
			vehicle.addVehicleTag(tag1);
			vehicle.addVehicleTag(tag2);
			session.save(vehicle);
			LOG.info(vehicle.toString());
		}

		for (int i = 0; i < 10; i++)
		{
			Vehicle vehicle = new Vehicle("WVWZZZ1KZXXXXXXX" + i);
			session.save(vehicle);
			LOG.info(vehicle.toString());
		}

		tx.commit();
		session.close();

		LOG.info("Loading vehicles (cursor):");
		session = sessionFactory.openSession();
		ScrollableResults results = session.createQuery(
			"SELECT DISTINCT v FROM Vehicle v LEFT JOIN FETCH v.vehicleTags ORDER BY v.id").scroll(
			ScrollMode.FORWARD_ONLY);
		while (results.next())
		{
			Vehicle vehicle = (Vehicle) results.get(0);
			LOG.info(vehicle.toString());
		}
		session.close();

		LOG.info("Loading vehicles (list):");
		session = sessionFactory.openSession();
		List<Vehicle> vehicleList = session.createQuery(
			"SELECT DISTINCT v FROM Vehicle v LEFT JOIN FETCH v.vehicleTags ORDER BY v.id").list();
		for (Vehicle vehicle : vehicleList)
		{
			LOG.info(vehicle.toString());
		}
		session.close();

		sessionFactory.close();
	}

}
