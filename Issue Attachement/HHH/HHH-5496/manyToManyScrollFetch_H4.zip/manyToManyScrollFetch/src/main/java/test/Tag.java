package test;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Tag {
    @Id
    @GeneratedValue
    private Long id;

    private String tagText;

    Tag() {
    }

    public Tag(String tagText) {
	super();
	this.tagText = tagText;
    }

    public String getTagText() {
	return tagText;
    }

    public void setTagText(String tagText) {
	this.tagText = tagText;
    }

    public Long getId() {
	return id;
    }

    @Override
    public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((tagText == null) ? 0 : tagText.hashCode());
	return result;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (obj == null)
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	Tag other = (Tag) obj;
	if (tagText == null) {
	    if (other.tagText != null)
		return false;
	} else if (!tagText.equals(other.tagText))
	    return false;
	return true;
    }

    @Override
    public String toString() {
	return tagText;
    }
}
