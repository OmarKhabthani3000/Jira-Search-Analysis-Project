package test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.util.List;
import java.util.logging.Logger;

import test.Tag;
import test.Vehicle;

import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ManyToManyScrollFetchTest {
    private static final Logger LOG = Logger
	    .getLogger("ManyToManyScrollFetchTest");

    private SessionFactory sessionFactory;

    @Before
    public void prepareSessionFactory() {
	Configuration cfg = new Configuration()
		.addAnnotatedClass(Vehicle.class).addAnnotatedClass(Tag.class);
	sessionFactory = cfg.buildSessionFactory();
    }

    @Test
    public void testScrollVsList() {
	Session session = sessionFactory.openSession();
	Transaction tx = session.beginTransaction();

	Tag tag1 = new Tag("TAG1");
	session.save(tag1);
	Tag tag2 = new Tag("TAG2");
	session.save(tag2);

	LOG.fine("Inserting vehicles:");
	for (int i = 0; i < 10; i++) {
	    Vehicle vehicle = new Vehicle("WVWZZZ1KZ1234567" + i);
	    vehicle.addVehicleTag(tag1);
	    vehicle.addVehicleTag(tag2);
	    session.save(vehicle);
	    LOG.fine(vehicle.toString());
	}

	for (int i = 0; i < 10; i++) {
	    Vehicle vehicle = new Vehicle("WVWZZZ1KZXXXXXXX" + i);
	    session.save(vehicle);
	    LOG.fine(vehicle.toString());
	}

	tx.commit();
	session.close();

	LOG.fine("Loading vehicles (cursor):");
	session = sessionFactory.openSession();
	ScrollableResults results = session
		.createQuery(
			"SELECT DISTINCT v FROM Vehicle v LEFT JOIN FETCH v.vehicleTags ORDER BY v.id")
		.scroll(ScrollMode.FORWARD_ONLY);
	while (results.next()) {
	    Vehicle vehicle = (Vehicle) results.get(0);
	    LOG.fine(vehicle.toString());
	    if (vehicle.getVin().startsWith("WVWZZZ1KZ1234567")) {
		assertThat(vehicle.getVehicleTags().size(), is(2));
	    } else {
		assertThat(vehicle.getVehicleTags().size(), is(0));
	    }
	}
	session.close();

	LOG.fine("Loading vehicles (list):");
	session = sessionFactory.openSession();
	List<Vehicle> vehicleList = session
		.createQuery(
			"SELECT DISTINCT v FROM Vehicle v LEFT JOIN FETCH v.vehicleTags ORDER BY v.id")
		.list();
	for (Vehicle vehicle : vehicleList) {
	    LOG.fine(vehicle.toString());
	    if (vehicle.getVin().startsWith("WVWZZZ1KZ1234567")) {
		assertThat(vehicle.getVehicleTags().size(), is(2));
	    } else {
		assertThat(vehicle.getVehicleTags().size(), is(0));
	    }
	}
	session.close();
    }

    @After
    public void closeSessionFactory() {
	sessionFactory.close();
    }
}
