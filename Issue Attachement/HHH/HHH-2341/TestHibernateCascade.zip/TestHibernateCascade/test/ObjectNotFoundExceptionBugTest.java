package test;

import junit.framework.TestCase;
import model.Child;
import model.Parent;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class ObjectNotFoundExceptionBugTest extends TestCase {

    public void testBug() {
       AnnotationConfiguration configuration = new AnnotationConfiguration();
       configuration.configure(this.getClass().getResource("/hibernate-annotation.cfg.xml"));
       SessionFactory sessionFactory = configuration.buildSessionFactory();

       Session session = sessionFactory.openSession();
       Transaction transaction = session.beginTransaction();
       
       Parent parent = new Parent();
       parent.setName("p1");
       session.persist(parent);
       assertNotNull(parent.getId());
       Integer parentId = parent.getId();

       Child child = new Child();
       child.setName("c1");
       child.setParent(parent);
       parent.getChildren().add(child);
       session.persist(parent);
       assertNotNull(child.getId());
       Integer childId = child.getId();

       transaction.commit();
       session.close();
       ///////////////////////////////////////////
       session = sessionFactory.openSession();
       transaction = session.beginTransaction();
       
       parent = (Parent) session.load(Parent.class, parentId);
       child = (Child) session.load(Child.class, childId);
//       child = (Child) session.get(Child.class, childId);
       session.delete(parent);
//       session.flush();   // !! required if session&transaction is re-opened and child is obtained with load(), otherwise exception on next line - BUG ? 
       child = (Child) session.get(Child.class, childId);
       assertNull(child);

       transaction.commit();

       sessionFactory.close();
       
    }
    

}
