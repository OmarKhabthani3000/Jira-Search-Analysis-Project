package com.example.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;

@Getter
@Setter
@Embeddable
@NoArgsConstructor
public class Address {
    private String city;
    private String street;
    @Embedded
    private ZipCode zipCode;
}
