/*******************************************************************************
 * Copyright 2010 PATRONAS Financial Systems GmbH. All rights reserved.
 ******************************************************************************/
package com.anybug;

public class Bar1 extends AbstractBar {
  private static final long serialVersionUID = 8452416954783321977L;

  private String bar1Value;

  protected Bar1() {
    super();
  }

  public Bar1(final String bar1Value) {
    super();
    this.bar1Value = bar1Value;
  }

  public String getBar1Value() {
    return bar1Value;
  }

  public void setBar1Value(final String bar1Value) {
    this.bar1Value = bar1Value;
  }

}
