/*******************************************************************************
 * Copyright 2010 PATRONAS Financial Systems GmbH. All rights reserved.
 ******************************************************************************/
package com.anybug;

public class Bar2 extends AbstractBar {
  private static final long serialVersionUID = -3889387995442606991L;
  private Long bar2Value;

  protected Bar2() {
    super();
  }

  public Bar2(final Long bar2Value) {
    super();
    this.bar2Value = bar2Value;
  }

  public Long getBar2Value() {
    return bar2Value;
  }

  public void setBar2Value(final Long bar2Value) {
    this.bar2Value = bar2Value;
  }

}
