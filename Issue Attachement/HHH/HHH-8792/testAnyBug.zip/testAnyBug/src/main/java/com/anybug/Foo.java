package com.anybug;

import java.io.Serializable;

public class Foo implements Serializable {

  private static final long serialVersionUID = 5411156736328007244L;
  private Long id;
  private AbstractBar testProperty;

  public void setId(final Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public AbstractBar getTestProperty() {
    return testProperty;
  }

  public void setTestProperty(final AbstractBar testProperty) {
    this.testProperty = testProperty;
  }

}
