/*******************************************************************************
 * Copyright 2010 PATRONAS Financial Systems GmbH. All rights reserved.
 ******************************************************************************/
package com.anybug;

import java.io.Serializable;

public abstract class AbstractBar implements Serializable {

  private static final long serialVersionUID = 401961366197528565L;
  private Long id;

  public Long getId() {
    return id;
  }

  public void setId(final Long id) {
    this.id = id;
  }
}
