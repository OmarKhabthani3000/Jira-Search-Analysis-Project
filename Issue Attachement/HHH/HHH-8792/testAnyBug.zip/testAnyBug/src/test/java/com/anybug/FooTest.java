package com.anybug;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class FooTest {

  private static EntityManagerFactory emf;
  private EntityManager em;

  public FooTest() {
  }

  @BeforeClass
  public static void setUpClass() throws Exception {
    emf = Persistence.createEntityManagerFactory("testunit");
  }

  @AfterClass
  public static void tearDownClass() throws Exception {
    emf.close();
  }

  @Before
  public void setUp() {
    em = emf.createEntityManager();
    em.getTransaction().begin();
  }

  @After
  public void tearDown() {
    if (em.getTransaction().isActive())
      em.getTransaction().rollback();

    if (em.isOpen())
      em.close();

  }

  /**
   * Test of persisting correctly mapped property (all is fine)
   */
  @Test
  public void testFooBar1() {
    final Foo foo = new Foo();
    final Bar1 bar1 = new Bar1("some value");
    foo.setTestProperty(bar1);
    em.persist(foo);
    em.persist(bar1);
    em.getTransaction().commit();

    // prevent caching etc
    em = emf.createEntityManager();
    final String getFoo = "select a from Foo a where a.id=" + foo.getId();
    final TypedQuery<Foo> query = em.createQuery(getFoo, Foo.class);
    final Foo fooResult = query.getSingleResult();
    assertNotNull("expected that bar property is set", fooResult.getTestProperty());
    assertEquals("expected that bar property has value \"some value\"", "some value", ((Bar1) fooResult
        .getTestProperty()).getBar1Value());
  }

  /**
   * Test of persisting incorrectly mapped property (no exception is thrown,
   * property is null when retriving Foo)
   */
  // maybe this behaviour could be prevented by throwing an exception when
  // inserting a not-known entity type into any mapping?
  @Test
  // (expected=HibernateException.class)
  public void testFooBar2() {
    final Foo foo = new Foo();
    final Bar2 bar2 = new Bar2(123L);
    foo.setTestProperty(bar2);
    em.persist(foo);
    em.persist(bar2);
    em.getTransaction().commit();
    final String getFoo = "select a from Foo a where a.id=" + foo.getId();

    // prevent caching etc
    em = emf.createEntityManager();
    final TypedQuery<Foo> query = em.createQuery(getFoo, Foo.class);
    final Foo fooResult = query.getSingleResult();
    assertNotNull("expected that bar property is set", fooResult.getTestProperty());
    assertEquals("expected that bar property has value 123", new Long(123), ((Bar2) fooResult
        .getTestProperty()).getBar2Value());
  }
}
