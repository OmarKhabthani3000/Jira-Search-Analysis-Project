package test;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Header {
	@Id
	private Long id;

	protected Long getId() {
		return id;
	}
	protected void setId(Long id) {
		this.id = id;
	}
}
