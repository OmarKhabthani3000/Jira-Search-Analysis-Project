package test;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Element {
	@ManyToOne
	@JoinColumn (name = "HEADER_ID")
	private Header header;
	@Id
	private Long id;

	protected Header getHeader() {
		return header;
	}
	protected Long getId() {
		return id;
	}
	protected void setHeader(Header header) {
		this.header = header;
	}
	protected void setId(Long id) {
		this.id = id;
	}
}
