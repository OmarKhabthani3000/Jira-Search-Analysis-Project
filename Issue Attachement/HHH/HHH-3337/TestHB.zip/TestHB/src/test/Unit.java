package test;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;

@Entity
public class Unit {
	@ManyToOne
	@JoinColumn (name = "HEAD_ID")
	private Unit head;
	@Id
	private Long id;
	@ManyToOne (fetch = FetchType.LAZY)
	@JoinTable (name = "LINK", joinColumns = @JoinColumn (name = "UNIT_ID"), inverseJoinColumns = @JoinColumn (name = "TOP_HEAD_ID"))
	private Unit topHead;

	protected Unit getHead() {
		return head;
	}
	protected Long getId() {
		return id;
	}
	protected Unit getTopHead() {
		return topHead;
	}
	protected void setHead(Unit head) {
		this.head = head;
	}
	protected void setId(Long id) {
		this.id = id;
	}
	protected void setTopHead(Unit head) {
		this.topHead = head;
	}
}
