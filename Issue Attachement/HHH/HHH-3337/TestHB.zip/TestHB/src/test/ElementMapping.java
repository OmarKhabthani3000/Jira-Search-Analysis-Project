package test;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery (name = "DeleteMappings", query = "DELETE FROM ElementMapping em WHERE NOT EXISTS"
		+ " (FROM HeaderMapping hm WHERE em.unit.topHead = hm.unit AND em.element.header = hm.header)")
public class ElementMapping {
	@ManyToOne
	@JoinColumn (name = "ELEMENT_ID")
	private Element element;
	@Id
	private Long id;
	@ManyToOne
	@JoinColumn (name = "UNIT_ID")
	private Unit unit;

	protected Element getElement() {
		return element;
	}
	protected Long getId() {
		return id;
	}
	protected Unit getUnit() {
		return unit;
	}
	protected void setElement(Element element) {
		this.element = element;
	}
	protected void setId(Long id) {
		this.id = id;
	}
	protected void setUnit(Unit unit) {
		this.unit = unit;
	}
}
