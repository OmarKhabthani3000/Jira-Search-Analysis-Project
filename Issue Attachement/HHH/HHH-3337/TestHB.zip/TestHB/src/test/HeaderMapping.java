package test;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class HeaderMapping {
	@ManyToOne
	@JoinColumn (name = "HEADER_ID")
	private Header header;
	@Id
	private Long id;
	@ManyToOne
	@JoinColumn (name = "UNIT_ID")
	private Unit unit;

	protected Header getHeader() {
		return header;
	}
	protected Long getId() {
		return id;
	}
	protected Unit getUnit() {
		return unit;
	}
	protected void setHeader(Header header) {
		this.header = header;
	}
	protected void setId(Long id) {
		this.id = id;
	}
	protected void setUnit(Unit unit) {
		this.unit = unit;
	}
}
