insert into Header values (1);
insert into Element (id, header_id) values (1, 1);
insert into Unit (id, head_id) values (1, null);
insert into Unit (id, head_id) values (2, 1);
insert into Unit (id, head_id) values (3, 2);
insert into Unit (id, head_id) values (4, null);
insert into Link (unit_id, top_head_id) values (1, 1);
insert into Link (unit_id, top_head_id) values (2, 1);
insert into Link (unit_id, top_head_id) values (3, 1);
insert into Link (unit_id, top_head_id) values (4, 4);
insert into HeaderMapping (id, header_id, unit_id) values (1, 1, 4);
insert into ElementMapping(id, element_id, unit_id) values (1, 1, 1);
insert into ElementMapping(id, element_id, unit_id) values (2, 1, 2);
insert into ElementMapping(id, element_id, unit_id) values (3, 1, 3);
insert into ElementMapping(id, element_id, unit_id) values (4, 1, 4);

commit;
