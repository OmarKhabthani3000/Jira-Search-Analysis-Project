package de.mtf;

import javax.persistence.Basic;
import javax.persistence.Entity;

//@Entity
public class DBValueWithBoolean extends DBValue {

	private Boolean value;

	@Basic
	public Boolean getValue() {
		return value;
	}

	public void setValue(Boolean value) {
		this.value = value;
	}
}
