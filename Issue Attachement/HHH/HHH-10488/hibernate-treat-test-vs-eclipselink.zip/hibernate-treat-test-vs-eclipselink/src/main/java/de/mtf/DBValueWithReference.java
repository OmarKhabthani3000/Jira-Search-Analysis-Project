package de.mtf;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

@Entity
public class DBValueWithReference extends DBValue {

	private DBObject value;

	@OneToOne(cascade = CascadeType.ALL)
	public DBObject getValue() {
		return value;
	}

	public void setValue(DBObject value) {
		this.value = value;
	}
}
