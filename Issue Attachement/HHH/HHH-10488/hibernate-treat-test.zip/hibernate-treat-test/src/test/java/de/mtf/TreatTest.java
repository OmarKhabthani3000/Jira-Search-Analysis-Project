package de.mtf;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.MapJoin;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.io.File;
import java.util.Arrays;

public class TreatTest extends TestCase {

	private EntityManager em;

	public TreatTest(String testName) {
		super(testName);
	}

	public static Test suite() {
		return new TestSuite(TreatTest.class);
	}

	public void setUp() throws Exception {
		super.setUp();

		this.em = Persistence.createEntityManagerFactory("pu").createEntityManager();
		this.em.getTransaction().begin();
	}

	public void testTreat() {

		final DBObject object = new DBObject();
		final DBObject reference = new DBObject();

		final DBKey key1 = new DBKey();
		final DBKey key2 = new DBKey();

		final DBValueWithString value1 = new DBValueWithString();
		final DBValueWithReference value2 = new DBValueWithReference();

		value1.setKey(key1);
		value1.setObject(object);
		value1.setValue("test");
		object.getProperties().put(key1, value1);

		value2.setKey(key2);
		value2.setObject(object);
		value2.setValue(reference);
		object.getProperties().put(key2, value2);

		em.persist(object);
		em.flush();

//		final File tmpFile = new File(System.getProperty("user.home"), "hsqldb.sql");
//		if (tmpFile.exists()) {
//			tmpFile.delete();
//		}
//		System.err.println(tmpFile.canWrite());
//		em.createNativeQuery("SCRIPT '" + tmpFile.getAbsolutePath() + "';").executeUpdate();

		System.out.println("--------------");

		final CriteriaBuilder builder = em.getCriteriaBuilder();
		final CriteriaQuery<DBObject> query = builder.createQuery(DBObject.class);

		final Root<DBObject> from = query.from(DBObject.class);
		final MapJoin<DBObject, DBKey, DBValue> valueJoin = from.join(DBObject_.properties);

		final Predicate predicate0 = builder.equal(valueJoin.get(DBValue_.id), 1);

		final MapJoin<DBObject, DBKey, DBValueWithString> stringJoin = builder.treat(valueJoin, DBValueWithString.class);
		final Predicate predicate1 = builder.and(builder.equal(stringJoin.get(DBValueWithString_.key), key1),
												 builder.equal(stringJoin.get(DBValueWithString_.value),
															   "test"));

		final MapJoin<DBObject, DBKey, DBValueWithReference> referenceJoin = builder.treat(valueJoin, DBValueWithReference.class);
		final Predicate predicate2 = builder.and(builder.equal(referenceJoin.get(DBValueWithReference_.key), key2),
												 builder.equal(referenceJoin.get(DBValueWithReference_.value),
															   reference));

		// works
//		query.select(from).where(predicate0);
		// works
//		query.select(from).where(predicate1);
		// does not work
		query.select(from).where(predicate2);

		assertNotNull(em.createQuery(query).getSingleResult());
	}
}
