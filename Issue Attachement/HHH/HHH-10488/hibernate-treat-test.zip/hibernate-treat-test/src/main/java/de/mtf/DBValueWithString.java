package de.mtf;

import javax.persistence.Basic;
import javax.persistence.Entity;

@Entity
public class DBValueWithString extends DBValue {

	private String value;

	@Basic
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
