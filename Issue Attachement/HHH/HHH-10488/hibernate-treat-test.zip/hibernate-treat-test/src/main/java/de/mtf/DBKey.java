package de.mtf;

import javax.persistence.Entity;

@Entity
public class DBKey extends DBIdentified {
}
