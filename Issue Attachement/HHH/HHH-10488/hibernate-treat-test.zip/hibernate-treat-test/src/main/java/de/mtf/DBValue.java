package de.mtf;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class DBValue extends DBIdentified {

	private DBKey key;

	private DBObject object;

	@ManyToOne(optional = false, cascade = CascadeType.ALL)
	public DBKey getKey() {
		return key;
	}

	public void setKey(DBKey key) {
		this.key = key;
	}

	@ManyToOne(optional = false, cascade = CascadeType.ALL)
	public DBObject getObject() {
		return object;
	}

	public void setObject(DBObject object) {
		this.object = object;
	}
}
