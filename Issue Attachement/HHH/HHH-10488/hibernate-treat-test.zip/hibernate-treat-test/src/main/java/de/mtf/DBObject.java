package de.mtf;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.MapKeyJoinColumn;
import javax.persistence.OneToMany;
import java.util.HashMap;
import java.util.Map;

@Entity
public class DBObject extends DBIdentified {

	private Map<DBKey, DBValue> properties;

	public DBObject() {
		this.setProperties(new HashMap<>());
	}

	@OneToMany(mappedBy= "object", cascade = CascadeType.ALL)
	@MapKeyJoinColumn(name = "key_id")
	public Map<DBKey, DBValue> getProperties() {
		return properties;
	}

	public void setProperties(Map<DBKey, DBValue> properties) {
		this.properties = properties;
	}
}
