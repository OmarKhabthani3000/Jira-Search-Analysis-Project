import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test
{

    /**
     * @param args
     */
    public static void main(String[] args)
    {
        SessionFactory factory = new Configuration().configure().buildSessionFactory();
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        Slave slave = new Slave();
        slave.setOid(1);
        session.save(slave);
        Master master = new Master();
        master.setSlave(slave);
        session.save(master);
        Query query = session.createQuery("from Master master where master.slave.oid=:oid");
        query.setParameter("oid", 1);
        System.out.println("Requete sur l'oid");
        for (Object object : query.list())
        {
            System.out.println(object);
        }
        query = session.createQuery("from Master master where master.slave=:slave");
        query.setParameter("slave", slave);
        System.out.println("Requete sur l'objet");
        for (Object object : query.list())
        {
            System.out.println(object);
        }
        tx.commit();
        session.close();
    }

}
