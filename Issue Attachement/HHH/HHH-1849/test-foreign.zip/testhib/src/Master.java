public class Master
{
    private Integer oid;
    private String libelle;
    private Slave slave;

    public String getLibelle()
    {
        return libelle;
    }

    public void setLibelle(String aLibelle)
    {
        libelle = aLibelle;
    }

    public Integer getOid()
    {
        return oid;
    }

    public void setOid(Integer aOid)
    {
        oid = aOid;
    }

    public Slave getSlave()
    {
        return slave;
    }

    public void setSlave(Slave aSlave)
    {
        slave = aSlave;
    }
}
