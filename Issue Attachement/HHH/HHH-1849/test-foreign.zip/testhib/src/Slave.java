public class Slave
{
    private Integer oid;
    private String libelle;

    public String getLibelle()
    {
        return libelle;
    }

    public void setLibelle(String aLibelle)
    {
        libelle = aLibelle;
    }

    public Integer getOid()
    {
        return oid;
    }

    public void setOid(Integer aOid)
    {
        oid = aOid;
    }
}
