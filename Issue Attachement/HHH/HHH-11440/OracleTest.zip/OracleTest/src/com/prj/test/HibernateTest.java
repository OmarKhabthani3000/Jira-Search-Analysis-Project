package com.prj.test;

import java.util.Arrays;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class HibernateTest {

	protected SessionFactory _sessionFactory;
    private ServiceRegistry _serviceRegistry;
    
	public static void main(String[] args) {
		HibernateTest test = new HibernateTest();
		test.configure();
		
	}

	private void configure() {
		Configuration hbConfig = new Configuration();
        HibernateEntityConfigurator.getInstance().configure(hbConfig,
                    Arrays.<Class> asList(new Class[] {
                            TracingConfig.class,TracingConfigId.class }));    
        hbConfig.setProperty("hibernate.connection.driver_class", "oracle.jdbc.driver.OracleDriver");
        hbConfig.setProperty("hibernate.connection.url", "jdbc:oracle:thin:@16.53.146.187:1521:siudb");
        hbConfig.setProperty("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
        
        hbConfig.setProperty("hibernate.connection.username", "siu20");
        hbConfig.setProperty("hibernate.connection.password", "siu20");        
            
            /*hbConfig.setProperty("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
            hbConfig.setProperty("hibernate.connection.url", "jdbc:mysql://localhost:3306/siu20");
            hbConfig.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");*/
        //String hbm2ddlAuto = config_info.getAttribute("DbTableCreateUpdate", "validate");
        //if (hbm2ddlAuto != null) {
            hbConfig.setProperty("hibernate.hbm2ddl.auto", "validate");
        //}
      
       
       ClassLoader contextClassLoader = Thread.currentThread()
                .getContextClassLoader();
        Thread.currentThread().setContextClassLoader(
                getClass().getClassLoader());
        try {
            _serviceRegistry = new StandardServiceRegistryBuilder().applySettings(
                    hbConfig.getProperties()). build();
            _sessionFactory = hbConfig.buildSessionFactory(_serviceRegistry);
        }catch (Exception e){
            e.printStackTrace();
        }
        finally {
            Thread.currentThread().setContextClassLoader(contextClassLoader);
        }        

		
	}

}
