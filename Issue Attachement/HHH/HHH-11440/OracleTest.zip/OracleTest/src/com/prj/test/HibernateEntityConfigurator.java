package com.prj.test;

import java.net.URL;
import java.util.Collection;

import org.hibernate.cfg.Configuration;

public class HibernateEntityConfigurator {
  public static final String HBM_XML_EXTENSION = ".hbm.xml";
  public static final HibernateEntityConfigurator instance = new HibernateEntityConfigurator();
  
  public static HibernateEntityConfigurator getInstance() {
    return instance;
  }
  
  private HibernateEntityConfigurator() {}

  public void configure(Configuration hibernateConfig, Collection<Class> entityClasses) {
    String connectionUrl = hibernateConfig.getProperty("hibernate.connection.url");
    String dbType = null;
    if (connectionUrl != null) {
      String[] connectionUrlParts = connectionUrl.split(":"); // ~ jdbc:mysql:... -> [jdbc,mysql, ...]
      if (connectionUrlParts.length > 1) {
        dbType = connectionUrlParts[1];
      }
    }
    configure(hibernateConfig, dbType, entityClasses);
  }
    
  public void configure(Configuration config, String dbType, Collection<Class> entityClasses) {
    for (Class<?> ec : entityClasses) {
      URL entityMappingResource = null;
      if (dbType != null) {
        entityMappingResource = ec.getClassLoader().getResource(getEntityMappingResourceName(dbType, ec));
      }
      if (entityMappingResource == null) {
        entityMappingResource = ec.getClassLoader().getResource(getEntityMappingResourceName(ec));
      }
      if (entityMappingResource != null) {
        config.addURL(entityMappingResource);
      }
    }
  }

  private String getEntityMappingResourceName(String dbType, Class ec) {
    return new StringBuilder()
        .append(ec.getPackage().getName().replace(".","/"))
        .append("/").append(dbType)
        .append("/").append(ec.getSimpleName())
        .append(HBM_XML_EXTENSION)
        .toString();
  }

  private String getEntityMappingResourceName(Class ec) {
    return new StringBuilder().append(ec.getName().replace(".","/")).append(HBM_XML_EXTENSION).toString();
  }  
}
