package test.dao.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import test.dao.DaoHelper;
import test.dao.DataAccess;
import test.logic.Inclusion;
import test.logic.Role;



class DaoHelperImpl implements DaoHelper {
	
	DataAccess dao;
	DaoHelperImpl(DataAccess dao){
		this.dao=dao;
	}


	public List<Inclusion> getRoleInclusions(){	
		Criteria cri=getClassCriteria(Inclusion.class);
		//cri=cri.setFetchMode("subClass", FetchMode.JOIN).cri.setFetchMode("superClass", FetchMode.JOIN);
		cri=cri.createAlias("subClass","sub").add(Restrictions.eq("sub.class",Role.class));//.getSimpleName()));
		cri=cri.createAlias("superClass","sup").add(Restrictions.eq("sup.class",Role.class));//.getSimpleName()));
		return cri.list();
	}
	

	private static Criteria getClassCriteria(Class<?> clazz) {
		return SessionFactoryAdapter.getInstance().getSession().createCriteria(clazz);
	}



}
