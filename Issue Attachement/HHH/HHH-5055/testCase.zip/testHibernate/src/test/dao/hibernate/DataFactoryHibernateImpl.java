package test.dao.hibernate;

import test.dao.DaoHelper;
import test.dao.DataAccess;
import test.dao.DataFactory;

public class DataFactoryHibernateImpl implements DataFactory{

	private static DataFactoryHibernateImpl kbDataFactoryHibernateImpl=null;
	private DataFactoryHibernateImpl(){};
	
	
	public static DataFactory getInstance(){
		if(kbDataFactoryHibernateImpl==null)kbDataFactoryHibernateImpl=new DataFactoryHibernateImpl();
			return kbDataFactoryHibernateImpl;

	}



	public DataAccess createKBDataAccess() {
		return new HibernateDataAccess();
	}



	public DaoHelper createReasonerDaoHelper(DataAccess kbDataAccess) {
		return new DaoHelperImpl(kbDataAccess);
	}
	
	
}
