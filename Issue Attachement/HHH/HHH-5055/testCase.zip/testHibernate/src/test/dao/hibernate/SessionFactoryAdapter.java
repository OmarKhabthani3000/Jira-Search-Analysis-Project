package test.dao.hibernate;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


class SessionFactoryAdapter {

	
	 // The Hibernate SessionFactory
	 private SessionFactory sessionFactory;
	

	 //the singleton instance of SessionFactortyAdapter
	private static  SessionFactoryAdapter instance;
	
	/**
	 * The constructor method, called only at the first getInstance()
	 *
	 */
	private SessionFactoryAdapter(){

		sessionFactory=new Configuration().configure().

		buildSessionFactory();		

		
	}
	public  void  detach(){
		this.sessionFactory.evictQueries();
		
	}
	public static SessionFactoryAdapter getInstance(){
		if(instance==null)
			instance= new SessionFactoryAdapter();
		return instance;
	}
	
	/**
	 * Creates and return a new Hibernate Session
	 * @return: a brand new Hibernate Session
	 */
	public Session openSession(){

		return this.sessionFactory.openSession();		
	}
	
	/**
	 * Return the instance of Session associated to the calling thread
	 * @return
	 */
	public Session getSession(){
		return this.sessionFactory.getCurrentSession();		
	}
	

	public void resetSchema(){
		this.sessionFactory.close();
		
		Configuration conf= new Configuration().configure();
		conf.setProperty("hibernate.hbm2ddl.auto", "create");
		
		SessionFactory s=conf.buildSessionFactory();
		Session ses=s.openSession();
		ses.beginTransaction(); ses.clear();
		s.close();
	
		this.sessionFactory=new Configuration().configure().buildSessionFactory();
		

	}

	}
