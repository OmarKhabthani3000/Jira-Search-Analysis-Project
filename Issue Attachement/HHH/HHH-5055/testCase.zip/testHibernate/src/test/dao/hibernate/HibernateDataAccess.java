package test.dao.hibernate;


import test.dao.DataAccess;


class HibernateDataAccess implements DataAccess {
        
    
    
    HibernateDataAccess () {}


	public void clear(){
		   SessionFactoryAdapter.getInstance().getSession().flush();
		   SessionFactoryAdapter.getInstance().getSession().clear();
	   }
	   
	public void delete(Object o){	   
	   SessionFactoryAdapter.getInstance().getSession().delete(o);
	  }
	 
	public void beginTransaction(){
		   SessionFactoryAdapter.getInstance().getSession().beginTransaction();
	  }
	
	public void endTransaction() throws Exception{
		try {
			SessionFactoryAdapter.getInstance().getSession().getTransaction().commit();	  
		} catch (Exception e) {
			  SessionFactoryAdapter.getInstance().getSession().getTransaction().rollback();
		
			 throw e;
		}
	}

	@Override
	public <T> T deproxy(Object maybeProxy, Class<T> baseClass)
			throws ClassCastException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void flush() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void reset() {
		// TODO Auto-generated method stub
		
	}


}