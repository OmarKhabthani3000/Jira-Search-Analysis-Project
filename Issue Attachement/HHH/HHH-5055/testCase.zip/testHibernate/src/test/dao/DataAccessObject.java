package test.dao;

/**
 * Data Access Object (DAO) utility
 * 
 * @author gvetere
 *
 */
public interface DataAccessObject {
    

    
    public void clear();
    
    public void flush();
    
    public void delete(Object o);

   	public void beginTransaction();
   
   	public void endTransaction() throws Exception;
    
   	public void reset();
        
	public <T> T deproxy(Object maybeProxy, Class<T> baseClass)
	throws ClassCastException;


}
