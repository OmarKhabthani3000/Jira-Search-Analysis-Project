package test.dao;





public interface DataAccess extends DataAccessObject {}
