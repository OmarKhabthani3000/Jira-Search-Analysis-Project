package test.dao;

import test.dao.hibernate.DataFactoryHibernateImpl;

public interface DataFactory {

	public DataFactory getInstance=DataFactoryHibernateImpl.getInstance();
	
	public DataAccess createKBDataAccess();
	
	public DaoHelper createReasonerDaoHelper(DataAccess kbDataAccess);
	
}
