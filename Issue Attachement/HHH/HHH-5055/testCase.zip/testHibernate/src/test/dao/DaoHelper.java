package test.dao;

import java.util.List;
import test.logic.Inclusion;



public interface DaoHelper {

	public List<Inclusion> getRoleInclusions();

}