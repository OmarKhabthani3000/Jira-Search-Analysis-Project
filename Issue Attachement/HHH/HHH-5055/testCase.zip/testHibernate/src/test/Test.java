package test;

import test.dao.DaoHelper;
import test.dao.DataAccess;
import test.dao.DataFactory;

public class Test {

	public static void main(String args[]){
		try{
			DataFactory dataFactory=DataFactory.getInstance;
			DataAccess dao=dataFactory.createKBDataAccess();
			dao.beginTransaction();
			DaoHelper helper=dataFactory.createReasonerDaoHelper(dao);
			helper.getRoleInclusions();
			dao.endTransaction();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
