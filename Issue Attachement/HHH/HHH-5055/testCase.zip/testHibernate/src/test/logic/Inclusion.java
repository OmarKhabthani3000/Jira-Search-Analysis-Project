package test.logic;




/** 
 * @author Alessandro
 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */

public class Inclusion {
	
	private Long id;
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	/** 
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	
	private Classifier subClass;

	/**
	 * @return the subClass
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Classifier getSubClass() {
		// begin-user-code
		return subClass;
		// end-user-code
	}

	/**
	 * @param theSubClass the subClass to set
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setSubClass(Classifier theSubClass) {
		// begin-user-code
		subClass = theSubClass;
		// end-user-code
	}

	/** 
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */

	private Classifier superClass;

	/**
	 * @return the superClass
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Classifier getSuperClass() {
		// begin-user-code
		return superClass;
		// end-user-code
	}

	/**
	 * @param theSuperClass the superClass to set
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setSuperClass(Classifier theSuperClass) {
		// begin-user-code
		superClass = theSuperClass;
		// end-user-code
	}
}