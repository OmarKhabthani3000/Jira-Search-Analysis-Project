package test.logic;


/**
 * 
 */

/** 
 * @author Alessandro
 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public abstract class Classifier extends Term {
	/** 
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	
	private Integer order;

	/**
	 * @return the order
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Integer getOrder() {
		// begin-user-code
		return order;
		// end-user-code
	}

	/**
	 * @param theOrder the order to set
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setOrder(Integer theOrder) {
		// begin-user-code
		order = theOrder;
		// end-user-code
	}

	/** 
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */

	private boolean declared;

	/**
	 * @return the declared
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public boolean getDeclared() {
		// begin-user-code
		return declared;
		// end-user-code
	}

	/**
	 * @param theDeclared the declared to set
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setDeclared(boolean theDeclared) {
		// begin-user-code
		declared = theDeclared;
		// end-user-code
	}
	
	public int hashCode(){
		return getIdentifier().hashCode();
	}
	
	public boolean equals(Object other){
		if(this==other)return true;
		
		if(other.getClass().equals(this.getClass())){
			Classifier otherClassifier=(Classifier)other;
			if( this.getIdentifier().equals(otherClassifier.getIdentifier())) return true;
			else return false;
		}
		return false;
	}
	

}