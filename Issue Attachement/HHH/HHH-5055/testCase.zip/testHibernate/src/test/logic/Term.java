/**
 * 
 */
package test.logic;



/** 
 * @author Alessandro
 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */

public abstract class Term {



	private Long id;
	
	public void setId(Long id) {
		this.id = id;
	}

	public Long getId() {
		return id;
	};


	private String identifier;

	/**
	 * @return the identifier
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String getIdentifier() {
		// begin-user-code
		return identifier;
		// end-user-code
	}

	/**
	 * @param theIdentifier the identifier to set
	 * @generated "UML to Java V5.0 (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setIdentifier(String theIdentifier) {
		// begin-user-code
		identifier = theIdentifier;
		// end-user-code
	}
	
	public String toString(){
		return this.getClass().getSimpleName()+": "+this.identifier;
	}
}