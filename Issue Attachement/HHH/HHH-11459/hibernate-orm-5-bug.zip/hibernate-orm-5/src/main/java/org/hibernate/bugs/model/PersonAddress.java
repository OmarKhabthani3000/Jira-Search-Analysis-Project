package org.hibernate.bugs.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class PersonAddress {
    
    @Id
    private Long id;
    
    @ManyToOne(optional=false, fetch=FetchType.LAZY)
    private Person parent;
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
