package org.hibernate.bugs.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Person {
	
	@Id
	private Long id;

	@Column(name="name", length=10, nullable=false)
	private String name;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "parent", orphanRemoval = true, cascade = CascadeType.ALL)
    private List<PersonAddress> details = new ArrayList<>();

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<PersonAddress> getDetails() {
        return details;
    }

    
    protected Person() {
        //JPA
    }

    public Person(Long id, String name) {
        this.id = id;
        this.name = name;
    }
}
