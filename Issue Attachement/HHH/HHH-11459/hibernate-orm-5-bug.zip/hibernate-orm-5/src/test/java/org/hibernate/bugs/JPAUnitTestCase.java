package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.hibernate.bugs.model.Person;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

    @Test
    public void testRefreshEnhancedEntity() throws Exception {
        EntityManager em;
        Person entity;
        
        // step 1: insert entity1
        em = begin();
        entity = new Person(1l, "Sam");
        em.persist(entity);
        commitAndClear(em);

        // step 2: read entity
        em = begin();
        entity = em.find(Person.class, 1L);
        entity.setName("Jhon");
        try {
            // step 3: refresh enhanced entity
            em.refresh(entity);
            commitAndClear(em);
        } catch (RuntimeException e) {
            e.printStackTrace();
            Assert.fail("Enhanced entity can't be refreshed");
        }
    }

    @Test
    public void testMergeEnhancedEntity() throws Exception {
        EntityManager em;
        Person entity;
        
        // step 1: insert entity1
        em = begin();
        entity = new Person(1l, "Sam");
        em.persist(entity);
        commitAndClear(em);

        // step 2: read entity
        em = begin();
        entity = em.find(Person.class, 1L);
        entity.setName("Jhon");
        try {
            // step 3: merge managed enhanced entity
            em.merge(entity);
            commitAndClear(em);
        } catch (RuntimeException e) {
            e.printStackTrace();
            Assert.fail("Enhanced entity can't be merged");
        }
    }

	private EntityManager begin() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		return entityManager;
	}
	
	private void commitAndClear(EntityManager em) {
		em.getTransaction().commit();
		em.clear();
	}
}
