package com.avispa;

import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;

/**
 * @author Rafał Hiszpański
 */
@Entity
public class Context extends Config {
    @ManyToOne
    private Type type;

    public Type getUnrelated() {
        return type;
    }

    public void setUnrelated(Type type) {
        this.type = type;
    }
}
