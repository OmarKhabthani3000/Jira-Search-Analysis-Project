package com.avispa;

import jakarta.persistence.Entity;

/**
 * @author Rafał Hiszpański
 */
@Entity
public class Config extends MasterEntity {
}
