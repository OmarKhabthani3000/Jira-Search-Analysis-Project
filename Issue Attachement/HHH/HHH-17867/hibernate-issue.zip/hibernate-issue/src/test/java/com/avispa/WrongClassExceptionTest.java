/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.avispa;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.hibernate.Session;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.util.List;
import java.util.stream.Collectors;

public class WrongClassExceptionTest extends BaseCoreFunctionalTestCase {

    // Add your entities here.
    @Override
    protected Class[] getAnnotatedClasses() {
        return new Class[] {
                Document.class,
                MasterEntity.class,
                Config.class,
                Type.class,
                Context.class,
        };
    }

    // Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
    @Override
    protected void configure(Configuration configuration) {
        super.configure( configuration );

        configuration.setProperty( AvailableSettings.SHOW_SQL, Boolean.TRUE.toString() );
        configuration.setProperty( AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString() );
        //configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, "true" );
    }

    // Add your tests, using standard JUnit.
    @Test
    public void throwsWrongClassExceptionTest() {
        Session session = openSession();

        // inserting data to db
        session.beginTransaction();

        // type
        Type type = new Type();
        type.setId("ABC");
        session.persist(type);

        // context
        Context context = new Context();
        context.setId("XYZ");
        context.setUnrelated(type);
        session.persist(context);

        session.flush();

        // querying for Documents with id = XYZ
        CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
        CriteriaQuery<Config> criteriaQuery = criteriaBuilder.createQuery(Config.class);
        Root<Config> queryRoot = criteriaQuery.from(Config.class);

        Predicate predicate = criteriaBuilder.equal(queryRoot.get("id"), "XYZ");
        criteriaQuery
                .select(queryRoot)
                .where(predicate);

        var query = session.createQuery(criteriaQuery);
        query.getResultList();
        //assertThrows(WrongClassException.class, () -> query.getResultList());

        session.close();
    }
}