package com.example.treatbug;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreatBugApplicationTests {

	@Test
	void contextLoads() {
	}

}
