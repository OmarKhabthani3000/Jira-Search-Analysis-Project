CREATE TABLE entity
(
    id     BIGINT NOT NULL,
    joined BIGINT,
    CONSTRAINT pk_entity PRIMARY KEY (id)
);

CREATE TABLE joined_entity
(
    id BIGINT NOT NULL,
    CONSTRAINT pk_joined_entity PRIMARY KEY (id)
);
