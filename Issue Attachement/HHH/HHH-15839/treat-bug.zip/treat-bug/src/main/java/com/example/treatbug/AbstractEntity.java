package com.example.treatbug;

import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.OneToOne;

@MappedSuperclass
public abstract class AbstractEntity<T> {

    @OneToOne
    private T joined;

    public T getJoined() {
        return joined;
    }

    public void setJoined(T joined) {
        this.joined = joined;
    }
}
