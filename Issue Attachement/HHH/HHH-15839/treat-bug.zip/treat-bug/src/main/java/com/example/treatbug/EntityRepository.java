package com.example.treatbug;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EntityRepository extends JpaRepository<ConcreteEntity, Long> {

    @Query("select e from ConcreteEntity e where treat(e.joined as JoinedEntity).id = ?1")
    Optional<ConcreteEntity> finbByJoindedId(long id);

}
