package com.example.treatbug;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TreatBugApplication {

	public static void main(String[] args) {
		SpringApplication.run(TreatBugApplication.class, args);
	}

}
