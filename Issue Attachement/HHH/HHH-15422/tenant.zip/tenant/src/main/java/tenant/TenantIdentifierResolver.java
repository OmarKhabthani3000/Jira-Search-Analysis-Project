package tenant;

import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
import org.springframework.stereotype.Component;

@Component
public class TenantIdentifierResolver implements CurrentTenantIdentifierResolver<String> {

	private static final ThreadLocal<String> holder = new ThreadLocal<>();

	public void setCurrentTenantIdentifier(String tenantId) {
		holder.set(tenantId);
	}

	@Override
	public String resolveCurrentTenantIdentifier() {
		return holder.get();
	}

	@Override
	public boolean validateExistingCurrentSessions() {
		return false;
	}

	@Override
	public boolean isRoot(String tenantId) {
		return "public".equals(tenantId);
	}
}
