package tenant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties(MultiTenantConnectionProviderProperties.class)
public class DemoApplication implements ApplicationRunner {

	@Autowired
	TestEntityRepository repository;

	@Autowired
	TenantIdentifierResolver tenantIdentifierResolver;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		tenantIdentifierResolver.setCurrentTenantIdentifier("test");

		TestEntity entity = new TestEntity();
		repository.save(entity);
	}

}
