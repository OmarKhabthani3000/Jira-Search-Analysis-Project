package tenant;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "tenent")
public class MultiTenantConnectionProviderProperties {

	private boolean useCatalog;

	private String defaultSchema;

	public boolean isUseCatalog() {
		return useCatalog;
	}

	public void setUseCatalog(boolean useCatalog) {
		this.useCatalog = useCatalog;
	}

	public String getDefaultSchema() {
		return defaultSchema;
	}

	public void setDefaultSchema(String defaultSchema) {
		this.defaultSchema = defaultSchema;
	}

}
