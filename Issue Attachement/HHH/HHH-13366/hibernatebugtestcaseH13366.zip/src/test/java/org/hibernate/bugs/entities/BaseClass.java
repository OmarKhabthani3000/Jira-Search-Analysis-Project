package org.hibernate.bugs.entities;


import javax.persistence.*;

/**
 *
 * An
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class BaseClass {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long sid;

    @Embedded
    protected EmbeddableAudit audit = new EmbeddableAudit();


    public Long getSid() {
        return sid;
    }

    public EmbeddableAudit getAudit() {
        return audit;
    }
}
