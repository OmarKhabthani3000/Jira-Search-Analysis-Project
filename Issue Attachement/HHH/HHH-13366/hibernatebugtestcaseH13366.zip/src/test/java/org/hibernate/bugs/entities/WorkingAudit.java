package org.hibernate.bugs.entities;

import javax.persistence.*;

/**
 *
 * An entity with a preUpdated audit. This works fine (in contrast with preUpdate audit of {@link BaseClass} which is not triggered).
 */
@Entity
public class WorkingAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long sid;

    @Embedded
    private EmbeddableAudit audit = new EmbeddableAudit();

    public Long getSid() {
        return sid;
    }

    public EmbeddableAudit getAudit() {
        return audit;
    }
}
