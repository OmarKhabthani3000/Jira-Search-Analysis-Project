package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Hibernate;
import org.hibernate.bugs.entities.NoWorkingAudit;
import org.hibernate.bugs.entities.WorkingAudit;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void hhh13366Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		NoWorkingAudit noWorkingAudit = new NoWorkingAudit();
		WorkingAudit workingAudit = new WorkingAudit();

		entityManager.persist(noWorkingAudit);
		entityManager.persist(workingAudit);

		entityManager.flush();
		entityManager.clear();

		Assert.assertNotNull(workingAudit.getAudit());
		Assert.assertNotNull(workingAudit.getAudit().getCreatedOn());

		Assert.assertNotNull(noWorkingAudit.getAudit());
		Assert.assertNotNull(noWorkingAudit.getAudit().getCreatedOn());

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
