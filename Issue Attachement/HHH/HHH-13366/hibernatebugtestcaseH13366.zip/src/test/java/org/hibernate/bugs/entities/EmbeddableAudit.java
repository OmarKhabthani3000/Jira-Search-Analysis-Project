package org.hibernate.bugs.entities;

import javax.persistence.Embeddable;
import javax.persistence.PrePersist;
import java.time.LocalDateTime;


@Embeddable
public class EmbeddableAudit {

    private LocalDateTime createdOn;

    @PrePersist
    public void onCreate(){
        createdOn = LocalDateTime.now();
    }

    public LocalDateTime getCreatedOn() {
        return createdOn;
    }
}
