package org.hibernate.bugs.entities;

import javax.persistence.Entity;

@Entity
public class NoWorkingAudit extends BaseClass {
}
