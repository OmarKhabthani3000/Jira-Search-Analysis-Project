package com.test.oneup.events.srv.domain.base;

import java.io.Serializable;


/**
 * This is an object that contains data related to the EV_SCHEDULE table.
 * Do not modify this class because it will be overwritten if the configuration file
 * related to this class is modified.
 *
 * @hibernate.class
 *  table="EV_SCHEDULE"
 */

public abstract class BaseScheduleImpl  implements Serializable {

	public static String REF = "ScheduleImpl";
	public static String PROP_LAB_ID = "labId";
	public static String PROP_ID = "id";


	// constructors
	public BaseScheduleImpl () {
		initialize();
	}

	/**
	 * Constructor for primary key
	 */
	public BaseScheduleImpl (java.lang.Long id) {
		this.setId(id);
		initialize();
	}

	/**
	 * Constructor for required fields
	 */
	public BaseScheduleImpl (
		java.lang.Long id,
		java.lang.Long labId) {

		this.setId(id);
		this.setLabId(labId);
		initialize();
	}

	protected void initialize () {}



	private int hashCode = Integer.MIN_VALUE;

	// primary key
	private java.lang.Long id;

	// fields
	private java.lang.Long labId;

	// collections
	private java.util.Set<com.test.oneup.events.srv.domain.ScheduleDetailImpl> scheduleDetails;



	/**
	 * Return the unique identifier of this class
     * @hibernate.id
     *  generator-class="sequence"
     *  column="SCH_ID"
     */
	public java.lang.Long getId () {
		return id;
	}

	/**
	 * Set the unique identifier of this class
	 * @param id the new ID
	 */
	public void setId (java.lang.Long id) {
		this.id = id;
		this.hashCode = Integer.MIN_VALUE;
	}




	/**
	 * labId is the java mapping to the LAB_ID DB column.
	 */
	public java.lang.Long getLabId () {
		return labId;
	}

	/**
	 * Set the value related to the column: LAB_ID
	 * @param labId the LAB_ID value
	 */
	public void setLabId (java.lang.Long labId) {
		this.labId = labId;
	}



	/**
	 * Return the value associated with the column: scheduleDetails
	 */
	public java.util.Set<com.test.oneup.events.srv.domain.ScheduleDetailImpl> getScheduleDetails () {
		return scheduleDetails;
	}

	/**
	 * Set the value related to the column: scheduleDetails
	 * @param scheduleDetails the scheduleDetails value
	 */
	public void setScheduleDetails (java.util.Set<com.test.oneup.events.srv.domain.ScheduleDetailImpl> scheduleDetails) {
		this.scheduleDetails = scheduleDetails;
	}




	public boolean equals (Object obj) {
		if (null == obj) return false;
		if (!(obj instanceof com.test.oneup.events.srv.domain.ScheduleImpl)) return false;
		else {
			com.test.oneup.events.srv.domain.ScheduleImpl scheduleImpl = (com.test.oneup.events.srv.domain.ScheduleImpl) obj;
			if (null == this.getId() || null == scheduleImpl.getId()) return false;
			else return (this.getId().equals(scheduleImpl.getId()));
		}
	}

	public int hashCode () {
		if (Integer.MIN_VALUE == this.hashCode) {
			if (null == this.getId()) return super.hashCode();
			else {
				String hashStr = this.getClass().getName() + ":" + this.getId().hashCode();
				this.hashCode = hashStr.hashCode();
			}
		}
		return this.hashCode;
	}


	public String toString () {
		return super.toString();
	}


}