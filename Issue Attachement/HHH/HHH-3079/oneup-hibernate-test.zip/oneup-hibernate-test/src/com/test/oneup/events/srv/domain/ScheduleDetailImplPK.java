package com.test.oneup.events.srv.domain;

import com.test.oneup.events.srv.domain.base.BaseScheduleDetailImplPK;

public class ScheduleDetailImplPK extends BaseScheduleDetailImplPK {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public ScheduleDetailImplPK () {}
	
	public ScheduleDetailImplPK (
		com.test.oneup.events.srv.domain.ScheduleImpl schedule,
		java.lang.Long lineRnk) {

		super (
			schedule,
			lineRnk);
	}
/*[CONSTRUCTOR MARKER END]*/


}