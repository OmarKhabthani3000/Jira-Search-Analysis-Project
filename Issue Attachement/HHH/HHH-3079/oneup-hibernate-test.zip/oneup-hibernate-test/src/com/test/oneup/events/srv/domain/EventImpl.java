package com.test.oneup.events.srv.domain;

import com.test.oneup.events.srv.domain.base.BaseEventImpl;



public class EventImpl extends BaseEventImpl {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public EventImpl () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public EventImpl (java.lang.Long id) {
		super(id);
	}

	/**
	 * Constructor for required fields
	 */
	public EventImpl (
		java.lang.Long id,
		java.lang.String eventEid) {

		super (
			id,
			eventEid);
	}

/*[CONSTRUCTOR MARKER END]*/


}