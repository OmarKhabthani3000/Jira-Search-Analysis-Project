package com.test.oneup.events.srv.domain;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.hibernate.dialect.Dialect;

import com.test.oneup.events.srv.domain.EventImpl;
import com.test.oneup.events.srv.domain.ScheduleDetailImpl;
import com.test.oneup.events.srv.domain.ScheduleDetailImplPK;
import com.test.oneup.events.srv.domain.ScheduleImpl;

public class Test {

	private SessionFactory sessionFactory;

	private Session session;

	private Configuration configuration;

	protected Configuration getConfiguration() {
		configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		return configuration;
	}

	public void init() {
		sessionFactory = getConfiguration().buildSessionFactory();
		session = sessionFactory.openSession();
		initDatabase();
	}

	public void testMergeScheduleDetails() {

		session.beginTransaction();

		// create an event
		EventImpl event = new EventImpl();
		event.setEventEid("MyEvent");
		Serializable id = session.save(event);
		session.getTransaction().commit();

		// merge a new schedule on the event
		session.beginTransaction();

		event.setEventEid("NewMyEvent");

		ScheduleImpl schedule = new ScheduleImpl();
		schedule.setLabId(10l);

		ScheduleDetailImpl scheduleDetails = new ScheduleDetailImpl(
				new ScheduleDetailImplPK(schedule, 1l), "aTitle", 1l);
		Set<ScheduleDetailImpl> details = new HashSet<ScheduleDetailImpl>();
		details.add(scheduleDetails);
		schedule.setScheduleDetails(details);

		event.setSchImpl(schedule);

		// this call fails ...
		session.merge(event);

		session.getTransaction().commit();

		// checking
		session.beginTransaction();
		EventImpl event2 = (EventImpl) session.get(EventImpl.class, id);
		ScheduleImpl sch2 = event2.getSchImpl();
		Set<ScheduleDetailImpl> details2 = (Set<ScheduleDetailImpl>) sch2
				.getScheduleDetails();
		session.getTransaction().commit();

	}

	public void run() {

		testMergeScheduleDetails();

	}

	public void initDatabase() {

		Dialect dialect = Dialect.getDialect(configuration.getProperties());

		executeSQL(session, new String[] { "DROP SEQUENCE SEQ_EV_ID",
				"DROP TABLE EV_SCHEDULE_DETAIL", "DROP TABLE EV_EVENT",
				"DROP TABLE EV_SCHEDULE" });
		executeSQL(session, configuration.generateSchemaCreationScript(dialect));

	}

	private void executeSQL(Session session, String[] sql) {
		try {
			session.beginTransaction();
			Connection con = session.connection();
			Statement st = con.createStatement();
			for (String query : sql) {
				try {
					System.out.println("Execute '" + query + "'");
					st.executeUpdate(query);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			st.close();
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Test test = new Test();
		test.init();
		test.run();
	}

}
