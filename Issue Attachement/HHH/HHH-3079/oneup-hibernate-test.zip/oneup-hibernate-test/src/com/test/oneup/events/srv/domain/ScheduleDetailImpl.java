package com.test.oneup.events.srv.domain;

import com.test.oneup.events.srv.domain.base.BaseScheduleDetailImpl;



public class ScheduleDetailImpl extends BaseScheduleDetailImpl {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public ScheduleDetailImpl () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public ScheduleDetailImpl (com.test.oneup.events.srv.domain.ScheduleDetailImplPK id) {
		super(id);
	}

	/**
	 * Constructor for required fields
	 */
	public ScheduleDetailImpl (
		com.test.oneup.events.srv.domain.ScheduleDetailImplPK id,
		java.lang.String title,
		java.lang.Long sortRank) {

		super (
			id,
			title,
			sortRank);
	}

/*[CONSTRUCTOR MARKER END]*/


}