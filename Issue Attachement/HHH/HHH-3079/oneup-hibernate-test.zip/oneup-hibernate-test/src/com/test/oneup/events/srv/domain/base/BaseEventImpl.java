package com.test.oneup.events.srv.domain.base;

import java.io.Serializable;


/**
 * This is an object that contains data related to the EV_EVENT table.
 * Do not modify this class because it will be overwritten if the configuration file
 * related to this class is modified.
 *
 * @hibernate.class
 *  table="EV_EVENT"
 */

public abstract class BaseEventImpl  implements Serializable {

	public static String REF = "EventImpl";
	public static String PROP_SCH_IMPL = "schImpl";
	public static String PROP_EVENT_EID = "eventEid";
	public static String PROP_ID = "id";


	// constructors
	public BaseEventImpl () {
		initialize();
	}

	/**
	 * Constructor for primary key
	 */
	public BaseEventImpl (java.lang.Long id) {
		this.setId(id);
		initialize();
	}

	/**
	 * Constructor for required fields
	 */
	public BaseEventImpl (
		java.lang.Long id,
		java.lang.String eventEid) {

		this.setId(id);
		this.setEventEid(eventEid);
		initialize();
	}

	protected void initialize () {}



	private int hashCode = Integer.MIN_VALUE;

	// primary key
	private java.lang.Long id;

	// fields
	private java.lang.String eventEid;

	// many to one
	private com.test.oneup.events.srv.domain.ScheduleImpl schImpl;



	/**
	 * Return the unique identifier of this class
     * @hibernate.id
     *  generator-class="sequence"
     *  column="EVT_ID"
     */
	public java.lang.Long getId () {
		return id;
	}

	/**
	 * Set the unique identifier of this class
	 * @param id the new ID
	 */
	public void setId (java.lang.Long id) {
		this.id = id;
		this.hashCode = Integer.MIN_VALUE;
	}




	/**
	 * eventEid is the java mapping to the EVENT_EID DB column.
	 */
	public java.lang.String getEventEid () {
		return eventEid;
	}

	/**
	 * Set the value related to the column: EVENT_EID
	 * @param eventEid the EVENT_EID value
	 */
	public void setEventEid (java.lang.String eventEid) {
		this.eventEid = eventEid;
	}



	/**
	 * Return the value associated with the column: SCH_ID
	 */
	public com.test.oneup.events.srv.domain.ScheduleImpl getSchImpl () {
		return schImpl;
	}

	/**
	 * Set the value related to the column: SCH_ID
	 * @param schImpl the SCH_ID value
	 */
	public void setSchImpl (com.test.oneup.events.srv.domain.ScheduleImpl schImpl) {
		this.schImpl = schImpl;
	}




	public boolean equals (Object obj) {
		if (null == obj) return false;
		if (!(obj instanceof com.test.oneup.events.srv.domain.EventImpl)) return false;
		else {
			com.test.oneup.events.srv.domain.EventImpl eventImpl = (com.test.oneup.events.srv.domain.EventImpl) obj;
			if (null == this.getId() || null == eventImpl.getId()) return false;
			else return (this.getId().equals(eventImpl.getId()));
		}
	}

	public int hashCode () {
		if (Integer.MIN_VALUE == this.hashCode) {
			if (null == this.getId()) return super.hashCode();
			else {
				String hashStr = this.getClass().getName() + ":" + this.getId().hashCode();
				this.hashCode = hashStr.hashCode();
			}
		}
		return this.hashCode;
	}


	public String toString () {
		return super.toString();
	}


}