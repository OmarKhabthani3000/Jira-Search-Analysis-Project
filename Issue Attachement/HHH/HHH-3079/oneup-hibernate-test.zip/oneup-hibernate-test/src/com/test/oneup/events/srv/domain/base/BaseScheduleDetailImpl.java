package com.test.oneup.events.srv.domain.base;

import java.io.Serializable;


/**
 * This is an object that contains data related to the EV_SCHEDULE_DETAIL table.
 * Do not modify this class because it will be overwritten if the configuration file
 * related to this class is modified.
 *
 * @hibernate.class
 *  table="EV_SCHEDULE_DETAIL"
 */

public abstract class BaseScheduleDetailImpl  implements Serializable {

	public static String REF = "ScheduleDetailImpl";
	public static String PROP_SORT_RANK = "sortRank";
	public static String PROP_TITLE = "title";
	public static String PROP_ID = "id";


	// constructors
	public BaseScheduleDetailImpl () {
		initialize();
	}

	/**
	 * Constructor for primary key
	 */
	public BaseScheduleDetailImpl (com.test.oneup.events.srv.domain.ScheduleDetailImplPK id) {
		this.setId(id);
		initialize();
	}

	/**
	 * Constructor for required fields
	 */
	public BaseScheduleDetailImpl (
		com.test.oneup.events.srv.domain.ScheduleDetailImplPK id,
		java.lang.String title,
		java.lang.Long sortRank) {

		this.setId(id);
		this.setTitle(title);
		this.setSortRank(sortRank);
		initialize();
	}

	protected void initialize () {}



	private int hashCode = Integer.MIN_VALUE;

	// primary key
	private com.test.oneup.events.srv.domain.ScheduleDetailImplPK id;

	// fields
	private java.lang.String title;
	private java.lang.Long sortRank;



	/**
	 * Return the unique identifier of this class
     * @hibernate.id
     */
	public com.test.oneup.events.srv.domain.ScheduleDetailImplPK getId () {
		return id;
	}

	/**
	 * Set the unique identifier of this class
	 * @param id the new ID
	 */
	public void setId (com.test.oneup.events.srv.domain.ScheduleDetailImplPK id) {
		this.id = id;
		this.hashCode = Integer.MIN_VALUE;
	}




	/**
	 * title is the java mapping to the TITLE DB column.
	 */
	public java.lang.String getTitle () {
		return title;
	}

	/**
	 * Set the value related to the column: TITLE
	 * @param title the TITLE value
	 */
	public void setTitle (java.lang.String title) {
		this.title = title;
	}



	/**
	 * sortRank is the java mapping to the SORT_RANK DB column.
	 */
	public java.lang.Long getSortRank () {
		return sortRank;
	}

	/**
	 * Set the value related to the column: sortRank
	 * @param sortRank the sortRank value
	 */
	public void setSortRank (java.lang.Long sortRank) {
		this.sortRank = sortRank;
	}




	public boolean equals (Object obj) {
		if (null == obj) return false;
		if (!(obj instanceof com.test.oneup.events.srv.domain.ScheduleDetailImpl)) return false;
		else {
			com.test.oneup.events.srv.domain.ScheduleDetailImpl scheduleDetailImpl = (com.test.oneup.events.srv.domain.ScheduleDetailImpl) obj;
			if (null == this.getId() || null == scheduleDetailImpl.getId()) return false;
			else return (this.getId().equals(scheduleDetailImpl.getId()));
		}
	}

	public int hashCode () {
		if (Integer.MIN_VALUE == this.hashCode) {
			if (null == this.getId()) return super.hashCode();
			else {
				String hashStr = this.getClass().getName() + ":" + this.getId().hashCode();
				this.hashCode = hashStr.hashCode();
			}
		}
		return this.hashCode;
	}


	public String toString () {
		return super.toString();
	}


}