package com.test.oneup.events.srv.domain.base;

import java.io.Serializable;


public abstract class BaseScheduleDetailImplPK implements Serializable {

	protected int hashCode = Integer.MIN_VALUE;

	private com.test.oneup.events.srv.domain.ScheduleImpl schedule;
	private java.lang.Long lineRnk;


	public BaseScheduleDetailImplPK () {}
	
	public BaseScheduleDetailImplPK (
		com.test.oneup.events.srv.domain.ScheduleImpl schedule,
		java.lang.Long lineRnk) {

		this.setSchedule(schedule);
		this.setLineRnk(lineRnk);
	}


	/**
	 * Return the value associated with the column: SCH_ID
	 */
	public com.test.oneup.events.srv.domain.ScheduleImpl getSchedule () {
		return schedule;
	}

	/**
	 * Set the value related to the column: SCH_ID
	 * @param schedule the SCH_ID value
	 */
	public void setSchedule (com.test.oneup.events.srv.domain.ScheduleImpl schedule) {
		this.schedule = schedule;
	}



	/**
	 * Return the value associated with the column: LINE_RNK
	 */
	public java.lang.Long getLineRnk () {
		return lineRnk;
	}

	/**
	 * Set the value related to the column: LINE_RNK
	 * @param lineRnk the LINE_RNK value
	 */
	public void setLineRnk (java.lang.Long lineRnk) {
		this.lineRnk = lineRnk;
	}




	public boolean equals (Object obj) {
		if (null == obj) return false;
		if (!(obj instanceof com.test.oneup.events.srv.domain.ScheduleDetailImplPK)) return false;
		else {
			com.test.oneup.events.srv.domain.ScheduleDetailImplPK mObj = (com.test.oneup.events.srv.domain.ScheduleDetailImplPK) obj;
			if (null != this.getSchedule() && null != mObj.getSchedule()) {
				if (!this.getSchedule().equals(mObj.getSchedule())) {
					return false;
				}
			}
			else {
				return false;
			}
			if (null != this.getLineRnk() && null != mObj.getLineRnk()) {
				if (!this.getLineRnk().equals(mObj.getLineRnk())) {
					return false;
				}
			}
			else {
				return false;
			}
			return true;
		}
	}

	public int hashCode () {
		if (Integer.MIN_VALUE == this.hashCode) {
			StringBuilder sb = new StringBuilder();
			if (null != this.getSchedule()) {
				sb.append(this.getSchedule().hashCode());
				sb.append(":");
			}
			else {
				return super.hashCode();
			}
			if (null != this.getLineRnk()) {
				sb.append(this.getLineRnk().hashCode());
				sb.append(":");
			}
			else {
				return super.hashCode();
			}
			this.hashCode = sb.toString().hashCode();
		}
		return this.hashCode;
	}


}