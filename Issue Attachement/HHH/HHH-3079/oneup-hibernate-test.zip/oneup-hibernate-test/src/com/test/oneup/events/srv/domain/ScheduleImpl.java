package com.test.oneup.events.srv.domain;

import com.test.oneup.events.srv.domain.base.BaseScheduleImpl;



public class ScheduleImpl extends BaseScheduleImpl {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public ScheduleImpl () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public ScheduleImpl (java.lang.Long id) {
		super(id);
	}

	/**
	 * Constructor for required fields
	 */
	public ScheduleImpl (
		java.lang.Long id,
		java.lang.Long labId) {

		super (
			id,
			labId);
	}

/*[CONSTRUCTOR MARKER END]*/


}