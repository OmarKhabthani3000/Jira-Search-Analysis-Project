package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.engine.spi.SessionImplementor;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static java.util.Collections.emptyList;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void inefficientQuery() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		ParentEntity entity = new ParentEntity();

		entityManager.persist(entity);

		entityManager.getTransaction().commit();

		entityManager.clear();
		entityManager.close();

		EntityManager secondEntityManager = entityManagerFactory.createEntityManager();
		secondEntityManager.getTransaction().begin();

		List<ParentEntity> resultList =
				secondEntityManager.createQuery("SELECT p from ParentEntity p where id IN (:idList)", ParentEntity.class)
						.setParameter("idList", emptyList())
						.getResultList();

		System.err.println(resultList);

		secondEntityManager.close();
	}
}
