package demo;

import javax.persistence.Persistence;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;

public class Runner {
    public static void main(String[] args) {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("DemoPeristenceUnit");


        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.createQuery("select ca from CarAttribute ca where ca.carAttributePK.car.name = 'A'").getResultList();
        entityManager.createQuery("delete CarAttribute ca where ca.carAttributePK.car.name = 'A'").executeUpdate();

        entityManager.close();

        entityManagerFactory.close();
    }
}
