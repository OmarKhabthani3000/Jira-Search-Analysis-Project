package demo.beans;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;

@Embeddable
public class CarAttributePK implements Serializable {
    private Car car;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CAR_ID", referencedColumnName = "ID", nullable = false)
    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    private String name;

    @Column(name = "NAME", nullable = false, length = 4000)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CarAttributePK that = (CarAttributePK) o;

        if (car != null ? !car.equals(that.car) : that.car != null) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (car != null ? car.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }
}
