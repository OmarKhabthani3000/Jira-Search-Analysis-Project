package demo.beans;

import javax.persistence.*;
import java.math.BigInteger;
import java.util.Collection;

@Entity
@Table(schema = "MAIN", name = "CAR")
public class Car {
    private BigInteger id;

    @Id
    @Column(name = "ID", nullable = false, length = 22)
    public BigInteger getId() {
        return id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    private String name;

    @Basic
    @Column(name = "NAME", nullable = false, length = 4000)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private Collection<CarAttribute> carAttributesById;

    @OneToMany(mappedBy = "carAttributePK.car")
    public Collection<CarAttribute> getCarAttributesById() {
        return carAttributesById;
    }

    public void setCarAttributesById(Collection<CarAttribute> carAttributesById) {
        this.carAttributesById = carAttributesById;
    }
}
