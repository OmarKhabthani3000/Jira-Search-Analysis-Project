package demo.beans;

import javax.persistence.*;
import java.math.BigInteger;

@Entity
@Table(schema = "MAIN", name = "CAR_ATTRIBUTE")
public class CarAttribute {

    private CarAttributePK carAttributePK;

    @EmbeddedId
    public CarAttributePK getCarAttributePK() {
        return carAttributePK;
    }

    public void setCarAttributePK(CarAttributePK carAttributePK) {
        this.carAttributePK = carAttributePK;
    }

    private String value;

    @Basic
    @Column(name = "VALUE", length = 4000)
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
