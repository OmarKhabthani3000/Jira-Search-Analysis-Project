package com.imgt.ligmdb.exceptions;

/**
 * Title:		PrepareTestException
 * Description: <br>
 * 
 * IMGT®, the international ImMunoGeneTics information system®
 *
 * @author Nelly JOUFFRE<br>
 * @version $Id: PrepareTestException.java,v 1.1 2011/08/25 10:24:31 nelly Exp $<br>
 */
public class PrepareTestException extends RuntimeException {

    private static final long serialVersionUID = -4125037539590294127L;

    public PrepareTestException(String message) {
	super(message);
    }

    public PrepareTestException(String message, Throwable cause) {
	super(message, cause);
    }
}
