package com.imgt.ligmdb;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.xml.FlatDtdDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.dbunit.ext.mysql.MySqlDataTypeFactory;
import org.dbunit.ext.mysql.MySqlMetadataHandler;
import org.dbunit.operation.DatabaseOperation;
import org.junit.After;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import com.imgt.ligmdb.exceptions.PrepareTestException;

/**
 * Title:		AbstractIntegrationTestCase
 * Description: <br>
 * 
 * IMGT®, the international ImMunoGeneTics information system®
 *
 * @author Nelly JOUFFRE<br>
 * @version $Id: AbstractIntegrationTestCase.java,v 1.1 2011/09/01 15:54:36 nelly Exp $<br>
 */
public abstract class AbstractIntegrationTestCase extends AbstractTransactionalJUnit4SpringContextTests {

    @Autowired
    private DataSource dataSource;
    private Map<String, String> dataSetMap;
    
    private static String dtdDirectory = "src/test/resources/dtd/";
    private static String testBaseDirectory = "src/test/resources/";
    protected static String LIGMDB_SCHEMA = "ligmdb";
    protected static String TAXONOMY_SCHEMA = "taxonomy";
    
    @Before
    public abstract void setUp();
    
    @After
    public void tearDown() {
	try {
	    prepareDatabase(DatabaseOperation.DELETE_ALL);
	} catch (Exception e) {
	    e.printStackTrace();
	    throw new PrepareTestException(e.getMessage());
	}
    }
    
    /**
     * 
     */
    protected void noDataSet() {
	this.dataSetMap = new HashMap<String, String>();
    }
    
    protected void addDataSet(String schema, String dataSetFileName) {
	if (this.dataSetMap == null) {
	    this.dataSetMap = new HashMap<String, String>();
	}
	if (this.dataSetMap.get(schema) == null || !this.dataSetMap.get(schema).equals(dataSetFileName)) {
	    this.dataSetMap.put(schema, dataSetFileName);
	}
	try {
	    prepareDatabase(DatabaseOperation.CLEAN_INSERT);
	} catch (Exception e) {
	    throw new PrepareTestException(e.getMessage());
	}
    }
    
    protected void generateDtd(String schema, String dtdFileName) {
	try {
	    IDatabaseConnection connection = getConnection(schema);
	    FlatDtdDataSet.write(connection.createDataSet(), new FileOutputStream(new File(dtdDirectory + dtdFileName)));
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }
    
    private void prepareDatabase(DatabaseOperation databaseOperation) throws Exception {
	IDatabaseConnection connection = null;
	for (String schema : dataSetMap.keySet()) {
	    try {
		connection = getConnection(schema);
		String dataSetFileName = dataSetMap.get(schema);
		// build dataSet full path
		// the dataSet xml file and the test class must be in the same package
		// the first one in the src/test/resources directory and the second one in the src/test/java directory
		String packageName = this.getClass().getPackage().getName();
		String packageDirectory = packageName.replaceAll("\\.", "/") + "/";
		String fullPathDataSet = testBaseDirectory + packageDirectory + dataSetFileName;

		databaseOperation.execute(connection, new FlatXmlDataSetBuilder().build(new FileInputStream(new File(fullPathDataSet))));
		connection.getConnection().commit();
	    }
	    finally {
		connection.close();
	    }
	}
    }
    
    private IDatabaseConnection getConnection(String schema) throws Exception {
	// Get connection from application context (dataSource is injected by IoC)
	Connection connection = dataSource.getConnection();
	// Instantiate DbUnit connection
	IDatabaseConnection iDatabaseConnection =  new DatabaseConnection(connection, schema);
	// Enable multiple schemas support
	iDatabaseConnection.getConfig().setProperty(DatabaseConfig.FEATURE_QUALIFIED_TABLE_NAMES, true);
	// Configure the handler used to control database metadata related methods
	// mandatory for MySQL database
	iDatabaseConnection.getConfig().setProperty(DatabaseConfig.PROPERTY_METADATA_HANDLER, new MySqlMetadataHandler());
	iDatabaseConnection.getConfig().setProperty(DatabaseConfig.PROPERTY_DATATYPE_FACTORY, new MySqlDataTypeFactory());
	return iDatabaseConnection;
    }
}
