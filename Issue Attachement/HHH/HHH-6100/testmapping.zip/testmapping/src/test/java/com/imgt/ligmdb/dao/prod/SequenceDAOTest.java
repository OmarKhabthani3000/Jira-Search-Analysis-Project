package com.imgt.ligmdb.dao.prod;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.imgt.ligmdb.dao.AbstractDAOTestCase;
import com.imgt.ligmdb.model.database.prod.Sequence;
import com.imgt.ligmdb.model.database.prod.SequenceAnnot;

/**
 * Title:		SequenceDAOTest
 * Description: <br>
 * 
 * IMGT®, the international ImMunoGeneTics information system®
 *
 * @author Nelly JOUFFRE<br>
 * @version $Id: SequenceDAOTest.java,v 1.7 2011/09/06 10:51:22 nelly Exp $<br>
 */
public class SequenceDAOTest extends AbstractDAOTestCase {

    @Autowired
    private SequenceDAO sequenceDAO;
    
    @Override
    public void setUp() {
	addDataSet(LIGMDB_SCHEMA, "SequenceDAOTest.xml");
    }
    
    @Test
    public void getAllSequencesAnnotJpql() {
	
	List<SequenceAnnot> results = sequenceDAO.getAllSequencesAnnotJpql();
	
	Assert.assertNotNull(results);
	Assert.assertEquals(3, results.size());
    } 
    
    @Test
    public void getAllSequencesAnnotCq() {
	
	List<SequenceAnnot> results = sequenceDAO.getAllSequencesAnnotCq();
	
	Assert.assertNotNull(results);
	Assert.assertEquals(3, results.size());
    } 
    
    @Test
    public void getAllSequencesXmlJpql() {
	
	List<Sequence> results = sequenceDAO.getAllSequencesXmlJpql();
	
	Assert.assertNotNull(results);
	Assert.assertEquals(3, results.size());
    } 
    
    @Test
    public void getAllSequencesXmlCq() {
	
	List<Sequence> results = sequenceDAO.getAllSequencesXmlCq();
	
	Assert.assertNotNull(results);
	Assert.assertEquals(3, results.size());
    } 
    
}
