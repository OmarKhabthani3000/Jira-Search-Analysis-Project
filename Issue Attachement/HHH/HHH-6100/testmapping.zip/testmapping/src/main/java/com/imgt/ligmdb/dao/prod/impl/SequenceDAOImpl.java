package com.imgt.ligmdb.dao.prod.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.apache.log4j.Logger;
import org.springframework.dao.DataRetrievalFailureException;

import com.imgt.ligmdb.dao.prod.SequenceDAO;
import com.imgt.ligmdb.model.database.prod.Sequence;
import com.imgt.ligmdb.model.database.prod.SequenceAnnot;

/**
 * Title:		SequenceDAOImpl
 * Description: <br>
 * 
 * IMGT®, the international ImMunoGeneTics information system®
 *
 * @author Nelly JOUFFRE<br>
 * @version $Id: SequenceDAOImpl.java,v 1.6 2011/09/06 10:51:22 nelly Exp $<br>
 */
public class SequenceDAOImpl implements SequenceDAO {

    protected Logger logger = Logger.getLogger(SequenceDAOImpl.class);
    
    @PersistenceContext
    protected EntityManager entityManager;
    
    /*
     * (non-Javadoc)
     * @see com.imgt.ligmdb.dao.prod.SequenceDAO#getAllSequencesAnnotJpql()
     */
    @SuppressWarnings("unchecked")
    public List<SequenceAnnot> getAllSequencesAnnotJpql() {
	
	String query = "select distinct s from SequenceAnnot as s";
	
	List<SequenceAnnot> results = entityManager.createQuery(query).getResultList();

	if (results == null || results.isEmpty()) {
	    throw new DataRetrievalFailureException("No sequences retrieved from database");
	}
	
	return results;
    }
    
    /*
     * (non-Javadoc)
     * @see com.imgt.ligmdb.dao.prod.SequenceDAO#getAllSequencesAnnotCq()
     */
    public List<SequenceAnnot> getAllSequencesAnnotCq() {
	
	CriteriaBuilder cb = entityManager.getCriteriaBuilder();
	CriteriaQuery<SequenceAnnot> cq = cb.createQuery(SequenceAnnot.class);
	cq.from(SequenceAnnot.class);
	List<SequenceAnnot> results = entityManager.createQuery(cq).getResultList();

	if (results == null || results.isEmpty()) {
	    throw new DataRetrievalFailureException("No sequences retrieved from database");
	}
	
	return results;
    }
    
    /*
     * (non-Javadoc)
     * @see com.imgt.ligmdb.dao.prod.SequenceDAO#getAllSequencesXmlJpql()
     */
    @SuppressWarnings("unchecked")
    public List<Sequence> getAllSequencesXmlJpql() {
	
	String query = "select distinct s from Sequence as s";
	
	List<Sequence> results = entityManager.createQuery(query).getResultList();

	if (results == null || results.isEmpty()) {
	    throw new DataRetrievalFailureException("No sequences retrieved from database");
	}
	
	return results;
    }
    
    /*
     * (non-Javadoc)
     * @see com.imgt.ligmdb.dao.prod.SequenceDAO#getAllSequencesXmlCq()
     */
    public List<Sequence> getAllSequencesXmlCq() {
	
	CriteriaBuilder cb = entityManager.getCriteriaBuilder();
	CriteriaQuery<Sequence> cq = cb.createQuery(Sequence.class);
	cq.from(Sequence.class);
	List<Sequence> results = entityManager.createQuery(cq).getResultList();

	if (results == null || results.isEmpty()) {
	    throw new DataRetrievalFailureException("No sequences retrieved from database");
	}
	
	return results;
    }
    
   
    
}
