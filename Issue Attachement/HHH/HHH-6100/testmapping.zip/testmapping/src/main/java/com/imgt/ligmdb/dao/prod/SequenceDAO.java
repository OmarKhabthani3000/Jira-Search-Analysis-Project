package com.imgt.ligmdb.dao.prod;

import java.util.List;

import com.imgt.ligmdb.model.database.prod.Sequence;
import com.imgt.ligmdb.model.database.prod.SequenceAnnot;

/**
 * Title:		SequenceDAO
 * Description: <br>
 * 
 * IMGT®, the international ImMunoGeneTics information system®
 *
 * @author Nelly JOUFFRE<br>
 * @version $Id: SequenceDAO.java,v 1.4 2011/09/01 15:49:00 nelly Exp $<br>
 */
public interface SequenceDAO {

    /**
     * Retrieve all the sequences from the database - Annotation mapping - JPQL implementation
     * @return the distinct list of Sequence objects 
     */
    public List<SequenceAnnot> getAllSequencesAnnotJpql();
    
    /**
     * Retrieve all the sequences from the database - Annotation mapping - CriteriaQuery implementation
     * @return the distinct list of Sequence objects 
     */
    public List<SequenceAnnot> getAllSequencesAnnotCq();
    
    /**
     * Retrieve all the sequences from the database - XML mapping - JPQL implementation
     * @return the distinct list of Sequence objects 
     */
    public List<Sequence> getAllSequencesXmlJpql();
    
    /**
     * Retrieve all the sequences from the database - XML mapping - CriteriaQuery implementation
     * @return the distinct list of Sequence objects 
     */
    public List<Sequence> getAllSequencesXmlCq();
    
}