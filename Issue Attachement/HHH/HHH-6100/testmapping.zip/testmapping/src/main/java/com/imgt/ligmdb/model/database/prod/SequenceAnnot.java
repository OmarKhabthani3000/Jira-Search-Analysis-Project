package com.imgt.ligmdb.model.database.prod;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.imgt.ligmdb.util.POJOUtil;


/**
 * Title:		SequenceAnnotGen
 * Description: <br>
 *
 * IMGT®, the international ImMunoGeneTics information system®
 *
 * @author Nelly JOUFFRE<br>
 * @version $Id: SequenceGen.java,v 1.9 2011/09/01 15:53:30 nelly Exp $<br>
 */
@Entity
@Table(name="SEQUENCE")
public class SequenceAnnot implements Serializable {

    private static final long serialVersionUID = -5890349012654277442L;
    
    @Id
    @Column(name="NUMACC")
    @GeneratedValue(strategy=GenerationType.AUTO)
    private String numacc;
    
    @Column(name="DEFINITION" )
    private String definition;
    
    /* Constructors */
    
    public SequenceAnnot() {}
    
    public SequenceAnnot(String numacc) {
	this.numacc = numacc;
    }

    /* Accessors */
    
    /**
     * @return the numacc
     */
    public String getNumacc() {
        return numacc;
    }

    /**
     * @param numacc the numacc to set
     */
    public void setNumacc(String numacc) {
        this.numacc = numacc;
    }

    /**
     * @return the definition
     */
    public String getDefinition() {
        return definition;
    }

    /**
     * @param definition the definition to set
     */
    public void setDefinition(String definition) {
        this.definition = definition;
    }
    
    /* Object methods */

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
	
	if (this == obj) return true;
	if (obj == null) return false;
	
	if (!POJOUtil.checkPOJOClassEquality(this, obj)) return false;
	
	final SequenceAnnot objImpl = (SequenceAnnot)POJOUtil.getPOJOImplementation(obj);
	
	if (!this.getNumacc().equals(objImpl.getNumacc())) return false;
	
	return true;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
	int result = 17;
	result = 37 * result + this.getNumacc().hashCode();
	return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
	return POJOUtil.toStringPOJO(this);
    }
}
