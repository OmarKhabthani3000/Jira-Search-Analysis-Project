package com.imgt.ligmdb.util;

import java.beans.PropertyDescriptor;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.proxy.HibernateProxy;
import org.hibernate.proxy.HibernateProxyHelper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

/**
 * Title: POJOUtil Description: <br>
 * 
 * IMGT®, the international ImMunoGeneTics information system®
 * 
 * @author Nelly JOUFFRE<br>
 * @version $Id: POJOUtil.java,v 1.3 2011/08/25 10:21:13 nelly Exp $<br>
 */
public class POJOUtil {
    
    private static Set<String> allowedToBePrinted;

    static {
	allowedToBePrinted = new HashSet<String>();
	allowedToBePrinted.add("java.lang.Boolean");
	allowedToBePrinted.add("java.util.Date");
	allowedToBePrinted.add("java.lang.Float");
	allowedToBePrinted.add("java.lang.Integer");
	allowedToBePrinted.add("java.lang.Long");
	allowedToBePrinted.add("java.lang.String");
    }

    /**
     * Utility method that build POJO.toString() content using Spring bean descriptors
     * @param pojo
     * @return
     */
    public static String toStringPOJO(Object pojo) {

	StringBuffer sb = null;
	BeanWrapper bw = null;
	PropertyDescriptor[] propertyDescs = null;
	String propertyName = null;
	Object propertyValue = null;
	String propertyClassName = null;

	sb = new StringBuffer();
	bw = new BeanWrapperImpl(pojo);
	propertyDescs = BeanUtils.getPropertyDescriptors(pojo.getClass());

	// does not display class name for inner classes
	if (!pojo.getClass().getName().contains("$")) {
	    sb.append("\n\n***** " + pojo.getClass().getName() + " *****");
	}
	 
	// go through all the pojo's properties
	for (PropertyDescriptor propertyDesc : propertyDescs) {
	   
	    // retrieve pojo's property name and class
	    propertyName = propertyDesc.getName();
	    propertyClassName = propertyDesc.getPropertyType().getName();
	    
	    
	    if (allowedToBePrinted.contains(propertyClassName) || propertyClassName.contains("$")) {
		
		propertyValue = bw.getPropertyValue(propertyName);
		
		// for properties not of inner class type, display propertyName : propertyValue
		// otherwise display detailed inner properties
		if (!propertyClassName.contains("$")) {
		    // do not display 'id' and 'class' properties
		    if (!propertyName.equals("id") && !propertyName.equals("class")) {
			sb.append("\n" + propertyName + " : ");
			if (propertyValue != null) {
			    propertyValue = "'" + propertyValue + "'";
			}
			sb.append(propertyValue);
		    }
		    
		    
		} 
	    }
	}
	
	return sb.toString();
    }
    
    /**
     * Utility method that return POJO implementation, deproxy object if necessary
     * @param obj the POJO to get implementation, can be a proxy
     * @return a POJO object
     */
    public static Object getPOJOImplementation(Object obj) {
	if (obj instanceof HibernateProxy) {
		return ((HibernateProxy) obj).getHibernateLazyInitializer().getImplementation();
	} else {
		return obj;
	}
    }
    
    /**
     * Utility method that check compared object's classes are equals
     * @param thisObject the object to compare to
     * @param thatObject the object to check
     * @return true if compared objects are of the same class
     */
    public static boolean checkPOJOClassEquality(Object thisObject, Object thatObject) {
	if (!HibernateProxyHelper.getClassWithoutInitializingProxy(thatObject).getName().equals(thisObject.getClass().getName())) {
	    return false;
	}
	return true;
    }

}
