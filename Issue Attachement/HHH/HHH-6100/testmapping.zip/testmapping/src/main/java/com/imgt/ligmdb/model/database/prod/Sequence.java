package com.imgt.ligmdb.model.database.prod;

import com.imgt.ligmdb.model.database.prod.gen.SequenceGen;
import com.imgt.ligmdb.util.POJOUtil;

/**
 * Title:		Sequence
 * Description: <br>
 *
 * IMGT®, the international ImMunoGeneTics information system®
 *
 * @author Nelly JOUFFRE<br>
 * @version $Id: Sequence.java,v 1.6 2011/09/01 15:53:30 nelly Exp $<br>
 */
public class Sequence extends SequenceGen {

    private static final long serialVersionUID = -5890349012654277442L;
    
    /* Constructors */

    public Sequence() {
	super();
    }
    
    public Sequence(String numacc) {
	super(numacc);
    }
    
    /* Object methods */

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
	
	if (this == obj) return true;
	if (obj == null) return false;
	
	if (!POJOUtil.checkPOJOClassEquality(this, obj)) return false;
	
	final Sequence objImpl = (Sequence)POJOUtil.getPOJOImplementation(obj);
	
	if (!this.getNumacc().equals(objImpl.getNumacc())) return false;
	
	return true;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
	int result = 17;
	result = 37 * result + this.getNumacc().hashCode();
	return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
	return POJOUtil.toStringPOJO(this);
    }
}
