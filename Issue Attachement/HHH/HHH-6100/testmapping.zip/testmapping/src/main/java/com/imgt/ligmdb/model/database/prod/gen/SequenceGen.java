package com.imgt.ligmdb.model.database.prod.gen;

import java.io.Serializable;


/**
 * Title:		SequenceGen
 * Description: <br>
 *
 * IMGT®, the international ImMunoGeneTics information system®
 *
 * @author Nelly JOUFFRE<br>
 * @version $Id: SequenceGen.java,v 1.9 2011/09/01 15:53:30 nelly Exp $<br>
 */
public abstract class SequenceGen implements Serializable {

    private static final long serialVersionUID = -5890349012654277442L;
    
    private String numacc;
    private String definition;
    
    /* Constructors */
    
    public SequenceGen() {}
    
    public SequenceGen(String numacc) {
	this.numacc = numacc;
    }

    /* Accessors */
    
    /**
     * @return the numacc
     */
    public String getNumacc() {
        return numacc;
    }

    /**
     * @param numacc the numacc to set
     */
    public void setNumacc(String numacc) {
        this.numacc = numacc;
    }

    /**
     * @return the definition
     */
    public String getDefinition() {
        return definition;
    }

    /**
     * @param definition the definition to set
     */
    public void setDefinition(String definition) {
        this.definition = definition;
    }
}
