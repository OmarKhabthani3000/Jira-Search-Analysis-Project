package com.test.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Version;

/**
 * JoinedEntityA that will be the parent of JoinedEntityB and JoinedEntityC
 * @author Roche
 *
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class JoinedEntityA implements Serializable {
	// Constants
	/** Constant of serialization */
	private static final long serialVersionUID = 4730091246658465893L;

	// Properties
	/** Uniq identifiant */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	/** Version */
	@Version
	private long version;
	
	/** Name */
	@Column(length=512)
	String name;
	
	/**
	 * Default constructor
	 */
	protected JoinedEntityA() {
		super();
		name = "A default name";
	}

	/**
	 * Constructor
	 * @param name Name to set
	 */
	public JoinedEntityA(String name) {
		this();
		this.name = name;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the version
	 */
	public long getVersion() {
		return version;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(long version) {
		this.version = version;
	}	
}
