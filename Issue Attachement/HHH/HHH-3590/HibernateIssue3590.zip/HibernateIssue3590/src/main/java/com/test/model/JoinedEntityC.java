package com.test.model;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 * JoinedEntityC
 * @author Roche
 *
 */
@Entity
public class JoinedEntityC extends JoinedEntityA {
	// Constants
	/** Constant of serialization */
	private static final long serialVersionUID = 4730091246658465894L;

	// Properties
	/** A number */
	@Column(nullable=false)
	private Integer number;
	
	
	/**
	 * Default constructor
	 */
	protected JoinedEntityC() {
		super();
		number = 0;
	}

	/**
	 * Constructor
	 * @param name Name to set
	 * @param number Number to set
	 */
	public JoinedEntityC(String name, Integer number) {
		super(name);
		this.number = number;
	}

	/**
	 * @return the number
	 */
	public Integer getNumber() {
		return number;
	}

	/**
	 * @param number the number to set
	 */
	public void setNumber(Integer number) {
		this.number = number;
	}
}
