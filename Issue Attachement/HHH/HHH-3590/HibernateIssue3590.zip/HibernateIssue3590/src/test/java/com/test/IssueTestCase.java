package com.test;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.test.model.JoinedEntityB;
import com.test.model.JoinedEntityC;

/**
 * Unit test to see the following problem:
 * In a bulk insert with HQL, in the case of a joined table, if the ended table
 * hasn't got he version colum, the query will fail
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@TransactionConfiguration
public class IssueTestCase extends AbstractTransactionalJUnit4SpringContextTests  {
	// Resources
	@Resource
	private SessionFactory sessionFactory;
	
	/**
	 * Unit Test initialization
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		// Insert some data
		Session session = sessionFactory.getCurrentSession();
		
		session.save(new JoinedEntityB("Joined B 1"));
		session.save(new JoinedEntityB("Joined B 2", "With a message"));
		session.save(new JoinedEntityC("Joined C 1", 1));
		session.save(new JoinedEntityC("Joined C 2", 2));
		session.save(new JoinedEntityC("Joined C 3", 3));
		
		session.flush();
		session.clear();
	}
	
	/**
	 * Tests some classic approach to see if the model works
	 */
	@Test
	public void testClassic() {
		Session session = sessionFactory.getCurrentSession();
		
		Assert.assertEquals(2, session.createQuery("from JoinedEntityB").list().size());
		Assert.assertEquals(3, session.createQuery("from JoinedEntityC").list().size());
		Assert.assertEquals(5, session.createQuery("from JoinedEntityA").list().size());
	}
	
	/**
	 * We will running a test to see the issue
	 * We will have : 
	 * org.hibernate.exception.SQLGrammarException: could not execute update query
	 *  	at org.hibernate.exception.SQLStateConverter.convert(SQLStateConverter.java:67)
	 *		at ...
	 *		...
	 * Caused by: java.sql.SQLException: Column not found: VERSION in statement [insert into JoinedEntityC ( version, number ) select ?, 5 as col_0_0_ from JoinedEntityB joinedenti0_ inner join JoinedEntityA joinedenti0_1_ on joinedenti0_.id=joinedenti0_1_.id]
	 *		at org.hsqldb.jdbc.Util.throwError(Unknown Source)
	 *		at ...
	 *		...
	 */
	@Test
	public void testIssueInsert() {
		// We will try to replace JoinedEntityB with JoinedEntityC
		// The following code is not a complete HQL code !
		Session session = sessionFactory.getCurrentSession();
		session.createQuery("insert into JoinedEntityC(number) select 5 from JoinedEntityB").executeUpdate();
		// ...
		
		Assert.assertTrue(true);
	}
}
