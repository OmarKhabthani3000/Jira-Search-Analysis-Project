package com.test;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.hql.ast.HqlSqlWalker;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.test.model.JoinedEntityB;
import com.test.model.JoinedEntityC;

/**
 * Unit test to see the following problem:
 * In a bulk insert with HQL, in the case of a joined table, if the ended table
 * hasn't got he version colum, the query will fail
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@TransactionConfiguration
public class IssueTestCase extends AbstractTransactionalJUnit4SpringContextTests  {
	// Resources
	@Resource
	private SessionFactory sessionFactory;
	
	/**
	 * Unit Test initialization
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		// Insert some data
		Session session = sessionFactory.getCurrentSession();
		
		session.save(new JoinedEntityB("Joined B 1"));
		session.save(new JoinedEntityB("Joined B 2", "With a message"));
		session.save(new JoinedEntityC("Joined C 1", 1));
		session.save(new JoinedEntityC("Joined C 2", 2));
		session.save(new JoinedEntityC("Joined C 3", 3));
		
		session.flush();
		session.clear();
	}
	
	/**
	 * Tests some classic approach to see if the model works
	 */
	@Test
	public void testClassic() {
		Session session = sessionFactory.getCurrentSession();
		
		Assert.assertEquals(2, session.createQuery("from JoinedEntityB").list().size());
		Assert.assertEquals(3, session.createQuery("from JoinedEntityC").list().size());
		Assert.assertEquals(5, session.createQuery("from JoinedEntityA").list().size());
	}
	
	/**
	 * We will running a test to see the issue
	 * Now that will works, because in {@link HqlSqlWalker}, in the method 'postProcessInsert',
	 * we put the following code:
	 * 
	 * <code>
	 * 	final boolean includeVersionProperty = persister.isVersioned() &&
	 *			!insertStatement.getIntoClause().isExplicitVersionInsertion() &&
	 *			persister.isVersionPropertyInsertable();
	 *	
	 *	// Start Fix
	 *	Boolean versionColumnOnTable = true;
	 *	if(persister instanceof JoinedSubclassEntityPersister){
	 *		// the version column is on this table or on parents ?
	 *		// maybe we must override isVersionPropertyInsertable into
	 *		// JoinedSubclassEntityPersister to return false ?
	 *		versionColumnOnTable = ((JoinedSubclassEntityPersister) persister).getPropertyTableName(
	 *				persister.getPropertyNames()[persister.getVersionProperty()]).equalsIgnoreCase(persister.getTableName());
	 *	}
	 *	// End Fix
	 *	
	 *	if ( includeVersionProperty && versionColumnOnTable) {
	 *  ...
	 * </code>
	 */
	@Test
	public void testIssueInsert() {
		// We will try to replace JoinedEntityB with JoinedEntityC
		Session session = sessionFactory.getCurrentSession();
		session.createQuery("insert into JoinedEntityC(number, id) select 5, id from JoinedEntityB").executeUpdate();
		session.createSQLQuery("delete from JoinedEntityB");
		session.flush();
		session.clear();
		
		Assert.assertEquals(2, session.createQuery("from JoinedEntityC where number = 5").list().size());
		Assert.assertEquals(5, session.createQuery("from JoinedEntityC").list().size());
		Assert.assertEquals(5, session.createQuery("from JoinedEntityA").list().size());
	}
}
