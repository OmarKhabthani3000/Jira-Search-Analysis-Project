package com.test.model;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 * JoinedEntityB
 * @author Roche
 *
 */
@Entity
public class JoinedEntityB extends JoinedEntityA {
	// Constants
	/** Constant of serialization */
	private static final long serialVersionUID = 4730091246658465894L;

	// Properties
	/** A message */
	@Column(length=512)
	private String message;
	
	
	/**
	 * Default constructor
	 */
	protected JoinedEntityB() {
		super();
	}

	/**
	 * Constructor
	 * @param name Name to set
	 */
	public JoinedEntityB(String name) {
		super(name);
	}
	
	/**
	 * Constructor
	 * @param name Name to set
	 * @param message Message to set
	 */
	public JoinedEntityB(String name, String message) {
		super(name);
		this.message = message;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
}
