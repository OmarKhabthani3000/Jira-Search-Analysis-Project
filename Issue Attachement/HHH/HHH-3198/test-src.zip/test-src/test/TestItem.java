package test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.testng.annotations.Test;

import com.api.annotations.NoSurvivors;
import com.api.util.Dbg;

public class TestItem {


	public Session getSession() {
    	AnnotationConfiguration cfg = new AnnotationConfiguration ( );
        SessionFactory annotationsSessionFactory = cfg.configure().buildSessionFactory ();
        return annotationsSessionFactory.getCurrentSession();
	}

	public void TestItem() {}



	@NoSurvivors
	@Test public void testItem() {
		Session s = getSession();
		s.beginTransaction();
		Specification spec1 = new Specification();
		spec1.setName("item1 spec");
		spec1.getProperties().put("item size", "large");
		Specification spec2 = new Specification();
		spec2.setName("item2 spec");
		spec2.getProperties().put("item size", "small");
		spec2.getProperties().put("item type", "solid");
		s.save(spec1);
		s.save(spec2);

		Container c = new Container();
		c.setName("container" );
		c.setDescription("the container");
		s.save(c);

		Item item1 = new Item();
		item1.setName("item1");
		item1.setSpecification(spec1);
		Item item2 = new Item();
		item2.setName("item2");
		item2.setContainer(c);  // only item2 in container
		item2.setSpecification(spec2);
		Item item3 = new Item();
		item3.setName("item3");

		s.save(item1);
		s.save(item2);
		s.save(item3);

		Query q = s.getNamedQuery("Item.findContainerlessBySpecificationHavingProperty");
		List<Item> items = q.setParameter("key", "item size").list();
		assert items.size() == 1 && items.contains(item1);

		Dbg.out("Item.findContainerlessBySpecificationHavingProperty " + items);

		s.getTransaction().commit();

	}
}
