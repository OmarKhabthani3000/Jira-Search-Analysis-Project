package test;

import java.io.Serializable;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;


@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING, columnDefinition = "varchar(255) CHARACTER SET utf8 COLLATE utf8_bin")
@DiscriminatorValue("a")
public abstract class NamedThing implements Serializable{
	@EmbeddedId
	protected UuidPk id = new UuidPk ();
	protected String name;
	public UuidPk getId() {
		return id;
	}
	public void setId(UuidPk id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String toString() {
		return name;
	}

}
