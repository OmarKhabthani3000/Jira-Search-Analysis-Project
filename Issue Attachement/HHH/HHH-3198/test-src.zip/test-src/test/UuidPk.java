package test;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Embeddable;


@Embeddable
public class UuidPk implements Serializable {
	private static final long serialVersionUID = 1L;
	private long idMsb;
	private long idLsb;

	public UuidPk(){
		UUID uuid = UUID.randomUUID();
		idMsb = uuid.getMostSignificantBits();
		idLsb = uuid.getLeastSignificantBits();
	}
	public UuidPk(long msb, long lsb){
		idMsb=msb;
		idLsb=lsb;
	}


    @Override
	public boolean equals(Object obj) {
		if (obj == null || ! (obj instanceof UuidPk ) ) {
			return false;
		}
		UuidPk opk = (UuidPk) obj;
		return idMsb == opk.idMsb && idLsb == opk.idLsb;
	}
	@Override
	public int hashCode() {
		return (int)((31 * idMsb + idLsb) % Integer.MAX_VALUE);
	}

	public String toString() {
		return new UUID(idMsb,idLsb).toString();
	}
	public String toLongPairString() {
		return "{idMsb=" + idMsb + ", idLsb=" + idLsb + "}";
	}
	public long getIdMsb() {
		return idMsb;
	}
	public void setIdMsb(long idMsb) {
		this.idMsb = idMsb;
	}
	public long getIdLsb() {
		return idLsb;
	}
	public void setIdLsb(long idLsb) {
		this.idLsb = idLsb;
	}
}
