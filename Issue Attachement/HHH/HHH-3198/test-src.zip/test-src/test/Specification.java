package test;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import org.hibernate.annotations.CollectionOfElements;

@Entity
@DiscriminatorValue("c")
public class Specification extends NamedThing {
	private static final long serialVersionUID = 1L;

    @CollectionOfElements
    private Map<String,String> properties = new HashMap<String,String>();

    public Specification() {}

	public Map<String, String> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, String> properties) {
		this.properties = properties;
	}

}
