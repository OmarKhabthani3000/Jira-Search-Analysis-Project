package test;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
@NamedQueries( {
@NamedQuery(name = "Item.findBySpecification",
		query="select distinct object(i) from Item i where i.specification = :specification"),
@NamedQuery(name = "Item.findBySpecificationProperty",
		query="select distinct object(i) from Item i, Specification s where i.specification = s and s.properties[:key] = :value"),
@NamedQuery(name = "Item.findBySpecificationHavingProperty",
		query="select distinct object(i) from Item i, Specification s where i.specification = s and :key in (s.properties)"),
@NamedQuery(name = "Item.findBySpecificationNotHavingProperty",
		query="select distinct object(i) from Item i, Specification s where i.specification = s and :key not in indices(s.properties)"),
@NamedQuery(name = "Item.findContainerlessBySpecificationHavingProperty",
		query="select distinct object(i) from Item i, Specification s where i.container is null and i.specification = s and s.properties[:key] is null")
/*
 * these all cause parse errors (the offending character is the '.' after specification
, @NamedQuery(name = "Item.findBySpecificationProperty2",
		query="select distinct object(i) from Item i where i.specification.properties[:key] = :value"),

@NamedQuery(name = "Item.findBySpecificationHavingProperty2",
		query=
"select distinct object(i) from Item i where :key in indices(i.specification.properties)"),
@NamedQuery(name = "Item.findBySpecificationNotHavingProperty2",
		query="select distinct object(i) from Item i where :key not in indices(i.specification.properties)")
*/
})
@DiscriminatorValue("b")
public class Item extends NamedThing {
	private static final long serialVersionUID = 1L;

    @ManyToOne
    private Specification specification;

    @ManyToOne
    private Container container;

    public Item() {}

	public Specification getSpecification() {
		return specification;
	}

	public void setSpecification(Specification specification) {
		this.specification = specification;
	}

	public Container getContainer() {
		return container;
	}

	public void setContainer(Container container) {
		this.container = container;
	}

}
