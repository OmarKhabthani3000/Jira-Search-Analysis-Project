package test;

import javax.persistence.Persistence;
import org.junit.Test;

public class FailingTest {

	@Test
	public void test() {
		Persistence.createEntityManagerFactory("PU");
	}

}
