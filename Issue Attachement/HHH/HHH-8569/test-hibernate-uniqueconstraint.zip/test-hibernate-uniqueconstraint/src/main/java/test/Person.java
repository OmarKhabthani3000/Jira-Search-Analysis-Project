package test;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "category", "age" }))
public class Person {

	@Id
	private int id;

	@ManyToOne(optional = false)
	private Category category;

	private int age;

}
