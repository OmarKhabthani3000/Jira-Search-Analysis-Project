package test;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
class Category {

	@Id
	private int id;

}
