package org.example.groupbytestcase.entities;

import javax.persistence.*;

@Entity
public class DBObject {

	private long id;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public long getId() {
		return this.id;
	}

	public void setId(final long id) {
		this.id = id;
	}


}
