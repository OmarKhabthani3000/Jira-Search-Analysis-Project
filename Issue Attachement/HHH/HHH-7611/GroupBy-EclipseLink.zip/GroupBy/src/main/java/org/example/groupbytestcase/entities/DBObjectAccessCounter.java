package org.example.groupbytestcase.entities;

import javax.persistence.*;

@Entity
public class DBObjectAccessCounter {

	private long id;
	private DBObject dbObject;
	private int count;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@ManyToOne
	public DBObject getObject() {
		return dbObject;
	}

	public void setObject(DBObject dbObject) {
		this.dbObject = dbObject;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
}
