package org.example.groupbytestcase.tests;

import junit.framework.TestCase;
import org.example.groupbytestcase.entities.DBObject;
import org.example.groupbytestcase.entities.DBObjectAccessCounter;
import org.example.groupbytestcase.entities.DBObjectAccessCounter_;
import org.example.groupbytestcase.entities.DBObject_;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.*;

public class GroupByTestCase extends TestCase {

	public GroupByTestCase(String string) {
		super(string);
	}

	public void testGroupByWithSum() {
		EntityManager entityManager = buildEntityManager();
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DBObject> query = builder.createQuery(DBObject.class);

		Root<DBObjectAccessCounter> from = query.from(DBObjectAccessCounter.class);
		Path<DBObject> object = from.get(DBObjectAccessCounter_.object);
		Expression<Long> sum = builder.sumAsLong(from.get(DBObjectAccessCounter_.count));
		query.multiselect(object, sum).groupBy(object);

		entityManager.createQuery(query).getResultList();
	}

	public void testSimplyfiedGroupByObject() {
		EntityManager entityManager = buildEntityManager();

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DBObject> query = builder.createQuery(DBObject.class);
		Root<DBObjectAccessCounter> from = query.from(DBObjectAccessCounter.class);
		Path<DBObject> object = from.get(DBObjectAccessCounter_.object);
		query.groupBy(object).select(object);

		entityManager.createQuery(query).getResultList();
	}

	public void testGroupById() {
		EntityManager entityManager = buildEntityManager();

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DBObject> query = builder.createQuery(DBObject.class);
		Root<DBObjectAccessCounter> from = query.from(DBObjectAccessCounter.class);
		Path<DBObject> object = from.get(DBObjectAccessCounter_.object);
		Path<Long> objectId = from.get(DBObjectAccessCounter_.object).get(DBObject_.id);
		query.select(object).groupBy(objectId);

		entityManager.createQuery(query).getResultList();
	}

	private EntityManager buildEntityManager() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		return emf.createEntityManager();
	}


}
