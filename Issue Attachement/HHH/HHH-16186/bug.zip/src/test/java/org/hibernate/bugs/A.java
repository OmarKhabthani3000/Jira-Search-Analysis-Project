package org.hibernate.bugs;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class A {

    @Id
    private Integer i;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private B b;

    public Integer getI() {
        return i;
    }

    public void setI(Integer i) {
        this.i = i;
    }

    public B getB() {
        return b;
    }

    public void setB(B b) {
        this.b = b;
    }
}
