package org.hibernate.bugs;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.ArrayList;
import java.util.List;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void testWithAdditionalSelectForEagerLoading() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        init(entityManager);

        entityManager.getTransaction().begin();

        List<A> aList = entityManager.createQuery("""
                select a from A a join fetch a.b
                """, A.class).getResultList();

        for (A a : aList) {
            Assert.assertTrue(Hibernate.isInitialized(a.getB()));
            Assert.assertFalse(Hibernate.isInitialized(a.getB().getcList()));
        }

        List<A> resultNotNeeded = entityManager.createQuery("""
                select distinct a from A a
                join fetch a.b b
                left join fetch b.cList
                where a in (:aList)
                """, A.class)
                .setParameter("aList", aList)
                .setHint(org.hibernate.jpa.QueryHints.HINT_PASS_DISTINCT_THROUGH, "false")
                .getResultList();

        for (A a : aList) {
            Assert.assertTrue(Hibernate.isInitialized(a.getB()));
            Assert.assertTrue(Hibernate.isInitialized(a.getB().getcList()));
            Assert.assertEquals("Each instance of B has exactly 2 entries of C", 2, a.getB().getcList().size());
        }


        entityManager.getTransaction().commit();
        entityManager.close();
    }

    private void init(EntityManager entityManager) {
        /* Structure is
        | A | B | C |
        | 1 | 1 | 1 |
        | 2 | 1 | 2 |
        | 3 | 1 | 1 |
        | 4 | 1 | 2 |

        Multiple A entities point to the same B entity which has several entries of C.
         */
        entityManager.getTransaction().begin();
        entityManager.createNativeQuery("insert into b values (1)").executeUpdate();

        entityManager.createNativeQuery("insert into c values (1, 1)").executeUpdate();
        entityManager.createNativeQuery("insert into c values (2, 1)").executeUpdate();

        entityManager.createNativeQuery("insert into a values (1, 1)").executeUpdate();
        entityManager.createNativeQuery("insert into a values (2, 1)").executeUpdate();
        entityManager.createNativeQuery("insert into a values (3, 1)").executeUpdate();
        entityManager.createNativeQuery("insert into a values (4, 1)").executeUpdate();
        entityManager.getTransaction().commit();
    }
}
