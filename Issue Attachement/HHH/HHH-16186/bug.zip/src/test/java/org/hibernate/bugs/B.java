package org.hibernate.bugs;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class B {

    @Id
    private Integer id;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "b")
    private List<C> cList = new ArrayList<>();;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<C> getcList() {
        return cList;
    }

    public void setcList(List<C> cList) {
        this.cList = cList;
    }
}
