package test;

import java.util.ArrayList;
import java.util.List;

abstract class Entity {
	static class WithNode extends Entity {
		public WithNode(int id, List data) {
			super(id, data);
		}
	}

	static class WithoutNode extends Entity {
		public WithoutNode(int id, List data) {
			super(id, data);
		}
	}

	private List data = new ArrayList();

	private int id;

	Entity(int id, List data) {
		super();
		this.id = id;
		this.data = data;
	}

	List getData() {
		return this.data;
	}

	int getId() {
		return id;
	}

	void setData(List data) {
		this.data = data;
	}

	void setId(int id) {
		this.id = id;
	}
}
