package test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import org.dom4j.io.XMLWriter;
import org.hibernate.EntityMode;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.HSQLDialect;
import org.hsqldb.jdbcDriver;

public class HibernatListIndexNodeTest extends TestCase {

	private List data;

	protected void setUp() throws Exception {
		data = new ArrayList();
		data.add("one");
		data.add("two");
	}

	public void testEntityWithoutNode() throws Exception {
		String xml = createXml(new Entity.WithoutNode(1, data));
		System.out.println(xml);
		assertEquals(
				"<entity><id>1</id><data><d>one</d><d>two</d></data></entity>",
				xml);
	}

	public void testEntityWithNode() throws Exception {
		String xml = createXml(new Entity.WithNode(2, data));
		System.out.println(xml);
		assertEquals(
				"<entity><id>2</id><data><d idx=\"0\">one</d><d idx=\"1\">two</d></data></entity>",
				xml);
	}

	private String createXml(final Entity entity) throws IOException {
		Class entityClass = entity.getClass();
		Configuration cfg = new Configuration();
		cfg.setProperty(Environment.DIALECT, HSQLDialect.class.getName());
		cfg.setProperty(Environment.DRIVER, jdbcDriver.class.getName());
		cfg.setProperty(Environment.URL, "jdbc:hsqldb:mem:test");
		cfg.setProperty(Environment.USER, "sa");
		cfg.setProperty(Environment.HBM2DDL_AUTO, "create-drop");
		cfg.setProperty(Environment.SHOW_SQL, "true");
		cfg.addClass(entityClass);

		Session sqlSession = cfg.buildSessionFactory().openSession();
		Serializable entityId = sqlSession.save(entity);
		sqlSession.flush();

		Session xmlSession = sqlSession.getSession(EntityMode.DOM4J);
		ByteArrayOutputStream xml = new ByteArrayOutputStream();
		new XMLWriter(xml).write(xmlSession.get(entityClass, entityId));
		return new String(xml.toByteArray());
	}
}
