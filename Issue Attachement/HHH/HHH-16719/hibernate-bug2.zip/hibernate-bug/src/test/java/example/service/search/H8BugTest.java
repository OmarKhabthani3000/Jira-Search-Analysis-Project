package example.service.search;

import example.model.Address;
import example.model.StreetAddress;
import example.model.StreetAddress_;
import example.model.parts.Street;
import example.model.parts.Street_;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.jupiter.api.*;


class H8BugTest {

    private static SessionFactory sessionFactory;
    private Session session = null;

    @BeforeAll
    static void setup(){
        try {
            StandardServiceRegistry standardRegistry
                    = new StandardServiceRegistryBuilder()
                    .configure("hibernate-test.cfg.xml")
                    .build();

            Metadata metadata = new MetadataSources(standardRegistry)
                    .addAnnotatedClass(Street.class)
                    .addAnnotatedClass(StreetAddress.class)
                    .addAnnotatedClass(Address.class)
                    .getMetadataBuilder()
                    .build();

            sessionFactory = metadata
                    .getSessionFactoryBuilder().build();

        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    @BeforeEach
    void setupThis(){
        session = sessionFactory.openSession();
        session.beginTransaction();
    }

    @AfterEach
    void tearThis(){
        session.getTransaction().commit();
    }

    @AfterAll
    static void tear(){
        sessionFactory.close();
    }
    
    @Test
    void findStreet() {
        var street = new Street();
        street.setName("BALLE");
        session.persist(street);
        var streetAddress = new StreetAddress();
        streetAddress.setStreet(street);
        streetAddress.setHouseNumber(1);
        streetAddress.setHouseLetter("A");        
        session.persist(streetAddress);

        var cb = session.getCriteriaBuilder();
        CriteriaQuery<Street> streetCriteriaQuery = cb.createQuery(Street.class);
        Root<Street> streetRoot = streetCriteriaQuery.from(Street.class);
        streetCriteriaQuery.select(streetRoot).where(cb.equal(streetRoot.get(Street_.name), "BALLE"));

        TypedQuery<Street> streetQuery = session.createQuery(streetCriteriaQuery);
        System.out.printf("Street result: " + streetQuery.getResultList());
    }

    @Test
    void findAddress() {
        var street = new Street();
        street.setName("BALLE");
        session.persist(street);
        var streetAddress = new StreetAddress();
        streetAddress.setStreet(street);
        streetAddress.setHouseNumber(1);
        streetAddress.setHouseLetter("A");
        session.persist(streetAddress);

        var cb = session.getCriteriaBuilder();
        CriteriaQuery<Address> addressCriteriaQuery = cb.createQuery(Address.class);
        Root<Address> addressRoot = addressCriteriaQuery.from(Address.class);
        addressCriteriaQuery.select(addressRoot).where(
                cb.equal(cb.treat(addressRoot, StreetAddress.class).get(StreetAddress_.street).get(Street_.name), "BALLE")
        );

        TypedQuery<Address> addressQuery = session.createQuery(addressCriteriaQuery);
        System.out.printf("Address result: " + addressQuery.getResultList());
    }

}