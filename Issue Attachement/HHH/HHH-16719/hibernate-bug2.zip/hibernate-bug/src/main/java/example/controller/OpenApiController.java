package example.controller;

import example.dto.AddressSearchRequest;
import example.dto.StreetSearchRequest;
import example.model.Address;
import example.model.parts.Street;
import example.service.search.AddressSearchService;
import example.service.search.H8AddressSearchService;
import example.service.search.H8StreetSearchService;
import example.service.search.StreetSearchService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/open")
public class OpenApiController {
    
    private final AddressSearchService addressSearchService;
    private final StreetSearchService streetSearchService;
    private final H8StreetSearchService h8StreetSearchService;
    private final H8AddressSearchService h8AddressSearchService;

    @PostMapping(value = "/address/search", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Address> search(@RequestBody AddressSearchRequest request, Pageable pageable) {
        return addressSearchService.findBySearchRequest(request);
    }

    @PostMapping(value = "/address/search2", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Address> search2(@RequestBody AddressSearchRequest request, Pageable pageable) {
        return h8AddressSearchService.findBySearchRequest(request);
    }

    @PostMapping(value = "/street/search", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Street> search(@RequestBody StreetSearchRequest request) {
        return streetSearchService.findBySearchRequest(request);
    }

    @PostMapping(value = "/street/search2", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Street> search2(@RequestBody StreetSearchRequest request) {
        return h8StreetSearchService.findBySearchRequest(request);
    }

}
