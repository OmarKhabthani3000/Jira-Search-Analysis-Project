package example.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import static jakarta.persistence.DiscriminatorType.STRING;

@Getter
@Setter
@Entity
@Inheritance
@DiscriminatorColumn(name = "type", discriminatorType=STRING)
public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "address_id_seq")
    @JsonIgnore
    Long id;
    Integer internalId;
}
