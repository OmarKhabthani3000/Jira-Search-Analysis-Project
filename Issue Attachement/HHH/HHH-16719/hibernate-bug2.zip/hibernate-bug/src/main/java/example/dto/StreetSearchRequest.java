package example.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class StreetSearchRequest {
    private Integer streetCode;
    private String streetName;
}
