package example.repository.search;

import example.dto.StreetSearchRequest;
import example.model.parts.Street;

import java.util.List;

public interface StreetSearchRepositoryCustom {
    List<Street> findBySearchRequest(StreetSearchRequest searchRequest);
}
