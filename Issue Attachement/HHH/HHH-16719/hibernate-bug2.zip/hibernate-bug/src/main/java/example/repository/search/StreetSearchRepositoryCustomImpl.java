package example.repository.search;

import example.dto.StreetSearchRequest;
import example.model.parts.Street;
import example.model.parts.Street_;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

import java.util.List;

public class StreetSearchRepositoryCustomImpl implements StreetSearchRepositoryCustom {
    @PersistenceContext
    private EntityManager entityManager;
    @Override
    public List<Street> findBySearchRequest(StreetSearchRequest searchRequest) {        
        var cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Street> cr = cb.createQuery(Street.class);
        Root<Street> root = cr.from(Street.class);
        cr.select(root).where(cb.equal(root.get(Street_.name), searchRequest.getStreetName()));

        TypedQuery<Street> query = entityManager.createQuery(cr);
        return query.getResultList();
    }
}
