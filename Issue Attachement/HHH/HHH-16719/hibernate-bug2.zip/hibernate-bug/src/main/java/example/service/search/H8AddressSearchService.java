package example.service.search;

import example.dto.AddressSearchRequest;
import example.model.Address;
import example.repository.search.AddressSearchRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Service
public class H8AddressSearchService {

    private final AddressSearchRepository addressSearchRepository;

    public List<Address> findBySearchRequest(AddressSearchRequest searchRequest) {
        return addressSearchRepository.findBySearchRequest(searchRequest);
    }

}
