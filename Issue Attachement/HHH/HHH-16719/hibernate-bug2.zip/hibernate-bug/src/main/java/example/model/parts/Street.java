package example.model.parts;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(indexes = {
        @Index(name = "idxStreetOfficialId", columnList = "officialId", unique = true),
        @Index(name = "idxStreetCode", columnList = "code")})
public class Street {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "street_id_seq")
    @JsonIgnore
    Long id;
    Long officialId;
    Integer code;
    @Column(length = 50)
    String name;
}
