package example.service.search;

import example.dto.StreetSearchRequest;
import example.model.parts.Street;
import example.repository.search.StreetSearchRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Service
public class H8StreetSearchService {

    private final StreetSearchRepository streetSearchRepository;

    public List<Street> findBySearchRequest(StreetSearchRequest searchRequest) {
        return streetSearchRepository.findBySearchRequest(searchRequest);
    }
   
    
}