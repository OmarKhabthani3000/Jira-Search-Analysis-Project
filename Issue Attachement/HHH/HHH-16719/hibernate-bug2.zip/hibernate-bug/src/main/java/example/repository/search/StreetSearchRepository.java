package example.repository.search;

import example.model.parts.Street;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface StreetSearchRepository extends JpaRepository<Street, Long>, StreetSearchRepositoryCustom, JpaSpecificationExecutor<Street> {

}
