package example.model;

import example.model.parts.Street;
import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToOne;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@DiscriminatorValue("O")
public class StreetAddress extends Address {
    Integer houseNumber;
    @Column(length = 2)
    String houseLetter;
    @OneToOne
    Street street;
}
