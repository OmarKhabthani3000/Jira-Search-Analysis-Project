package example.repository.search;

import example.dto.AddressSearchRequest;
import example.dto.StreetSearchRequest;
import example.model.Address;
import example.model.StreetAddress;
import example.model.StreetAddress_;
import example.model.parts.Street;
import example.model.parts.Street_;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

import java.util.List;

public class AddressSearchRepositoryCustomImpl implements AddressSearchRepositoryCustom {
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Address> findBySearchRequest(AddressSearchRequest searchRequest) {
        var cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Address> cr = cb.createQuery(Address.class);
        Root<Address> root = cr.from(Address.class);
        cr.select(root).where(
                cb.equal(cb.treat(root, StreetAddress.class).get(StreetAddress_.street).get(Street_.name), searchRequest.getStreetName())
        );

        TypedQuery<Address> query = entityManager.createQuery(cr);
        return query.getResultList();
    }
}
