package example.service.search;

import example.dto.StreetSearchRequest;
import example.model.parts.Street;
import example.repository.search.StreetSearchRepository;
import example.repository.specs.StreetSpecs;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Service
public class StreetSearchService {

    private final StreetSearchRepository streetSearchRepository;

    public List<Street> findBySearchRequest(StreetSearchRequest searchRequest) {
        Specification<Street> specification = Specification
                .where(getStreetCodeSpec(searchRequest))
                .and(getStreetNameSpec(searchRequest));
        return streetSearchRepository.findAll(specification);
    }
    
    private Specification<Street> getStreetCodeSpec(StreetSearchRequest searchRequest) {
        return searchRequest.getStreetCode() == null || searchRequest.getStreetCode() == 0 ? null : StreetSpecs.streetCodeEqual(searchRequest.getStreetCode());
    }
    
    private Specification<Street> getStreetNameSpec(StreetSearchRequest request) {
        if (request.getStreetName() == null) {
            return null;
        }
        final String searchValue = request.getStreetName().toUpperCase().trim();
        return StreetSpecs.streetNameEqual(searchValue);
    }
    
}