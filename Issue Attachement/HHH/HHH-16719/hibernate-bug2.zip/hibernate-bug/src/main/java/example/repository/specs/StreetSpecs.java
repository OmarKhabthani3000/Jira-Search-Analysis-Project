package example.repository.specs;

import example.model.parts.Street;
import example.model.parts.Street_;
import org.springframework.data.jpa.domain.Specification;

public class StreetSpecs {
    public static Specification<Street> streetCodeEqual(Integer streetCode) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.equal(root.get(Street_.code), streetCode);
    }

    public static Specification<Street> streetNameEqual(String streetName) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.equal(root.get(Street_.name), streetName);
    }

}
