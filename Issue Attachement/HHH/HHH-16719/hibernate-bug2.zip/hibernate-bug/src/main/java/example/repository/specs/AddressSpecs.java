package example.repository.specs;

import example.model.Address;
import example.model.Address_;
import example.model.StreetAddress;
import example.model.StreetAddress_;
import example.model.parts.Street_;
import org.springframework.data.jpa.domain.Specification;

public class AddressSpecs {
    public static Specification<Address> internalIdEqual(Integer internalId) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.equal(root.get(Address_.internalId), internalId);
    }

    public static Specification<Address> streetNameEqual(String streetName) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.equal(criteriaBuilder.treat(root, StreetAddress.class).get(StreetAddress_.street).get(Street_.name), streetName);
    }

}
