package example.service.search;

import example.dto.AddressSearchRequest;
import example.model.Address;
import example.repository.search.AddressSearchRepository;
import example.repository.specs.AddressSpecs;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Service
public class AddressSearchService {

    private final AddressSearchRepository addressSearchRepository;

    public List<Address> findBySearchRequest(AddressSearchRequest searchRequest) {
        Specification<Address> specification = Specification
                .where(getStreetNameSpec(searchRequest))
                .and(getInternalIdSpec(searchRequest));
        return addressSearchRepository.findAll(specification);
    }

    private Specification<Address> getInternalIdSpec(AddressSearchRequest searchRequest) {
        return searchRequest.getInternalId() == null || searchRequest.getInternalId() == 0 ? null : AddressSpecs.internalIdEqual(searchRequest.getInternalId());
    }

    private Specification<Address> getStreetNameSpec(AddressSearchRequest request) {
        if (request.getStreetName() == null) {
            return null;
        }
        final String searchValue = request.getStreetName().toUpperCase().trim();
        return AddressSpecs.streetNameEqual(searchValue);
    }

}
