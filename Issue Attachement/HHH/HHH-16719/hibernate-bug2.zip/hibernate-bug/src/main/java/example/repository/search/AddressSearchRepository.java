package example.repository.search;

import example.model.Address;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface AddressSearchRepository extends JpaRepository<Address, Long>, AddressSearchRepositoryCustom, JpaSpecificationExecutor<Address> {

}
