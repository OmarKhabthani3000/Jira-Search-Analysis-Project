package example.repository.search;

import example.dto.AddressSearchRequest;
import example.model.Address;

import java.util.List;

public interface AddressSearchRepositoryCustom {
    public List<Address> findBySearchRequest(AddressSearchRequest searchRequest);
}
