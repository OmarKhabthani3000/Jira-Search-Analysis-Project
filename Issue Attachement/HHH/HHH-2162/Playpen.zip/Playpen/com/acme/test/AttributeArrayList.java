package com.acme.test;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Version;

@Entity @Table(name="TEST_ATTRIB_AL") //NORES
public class AttributeArrayList implements Serializable {
    private Long ID = new Long(0);
    private String name;
    private Long version = new Long(0);
    private String value;
    private PojoArrayList pojo;

    public AttributeArrayList() {
    	super();
    }
    
    public AttributeArrayList(String name, String value, PojoArrayList pojo)
    {
        this();
        this.name = name;
        this.value = value;
        this.pojo = pojo;
    }

    @TableGenerator(
            name="ELEMENT_ID_GEN", 
            table="ELEMENT_ID_GEN", 
            pkColumnName="GEN_PK_ID", 
            valueColumnName="GEN_PK_VALUE", 
            pkColumnValue="NEXT_VALUE", 
            allocationSize=1)
    @Id @GeneratedValue(strategy=GenerationType.TABLE, generator="ELEMENT_ID_GEN") 
    @Column(name="AttrID")
    public Long getID() { return ID; }
    private void setID(Long ID) { this.ID = ID; } 
    
    @Version @Column(name="AttrVersion", nullable=false, updatable=true, unique=false) 
	public Long getVersion() { return version; }
	private void setVersion(Long version) { this.version = version; } 
    
    @Basic @Column(name="AttrName", nullable=true, updatable=false, unique=true) 
    public String getName() { return name; }
    private void setName(String name) { this.name = name; }

	@Basic @Column(name="AttrValue", nullable=true, updatable=true, unique=false)
	public String getValue() { return value; }
	public void setValue(String value) { this.value = value; }

	@ManyToOne(optional=false) 
    @JoinColumn(name="PojoID", nullable=false)
    public PojoArrayList getPojo() { return pojo; }
    private void setPojo(PojoArrayList pojo) { this.pojo = pojo; }

    public String toString() { return getName(); }
}
