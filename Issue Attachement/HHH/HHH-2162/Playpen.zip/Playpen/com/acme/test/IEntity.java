package com.acme.test;

public interface IEntity {
    public Long getID();
    public Long getVersion();
    public String getName();
}
