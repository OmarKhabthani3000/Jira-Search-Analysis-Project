package com.acme.test;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

public class PojoTest {
    private static EntityManagerFactory entityManagerFactory;
    private enum Type {ARRAYLIST, HASHSET, HASHMAP};
    
	public static void main(String[] args) throws Exception {
		System.out.println("CLASSPATH=" + System.getProperty("java.class.path"));
        createEMF();
		initDB();
        
        testOneType(Type.HASHSET);
        testOneType(Type.HASHMAP);
        testOneType(Type.ARRAYLIST);
        
    }
    
    private static void testOneType(Type type) {
		EntityManager em = entityManagerFactory.createEntityManager();
		EntityTransaction tx = em.getTransaction(); tx.begin();
		IEntity pojo = (type == Type.ARRAYLIST) ? findArrayListByUniqueName(em, "PojoArrayList4") :
                      (type == Type.HASHSET) ? findHashSetByUniqueName(em, "PojoHashSet4") :
                      findHashMapByUniqueName(em, "PojoHashMap4");
		tx.commit(); em.close();
		System.out.println("findByUniqueName: " + pojo + " version=" + pojo.getVersion());

		em = entityManagerFactory.createEntityManager();
		tx = em.getTransaction(); tx.begin();
		pojo = em.merge(pojo);
		System.out.println("merge: " + pojo + " version=" + pojo.getVersion());
		tx.commit(); em.close();

		em = entityManagerFactory.createEntityManager();
		tx = em.getTransaction(); tx.begin();
		pojo = em.merge(pojo);
		System.out.println("merge: " + pojo + " version=" + pojo.getVersion());
		tx.commit(); em.close();

		em = entityManagerFactory.createEntityManager();
		tx = em.getTransaction(); tx.begin();
        pojo = (type == Type.ARRAYLIST) ? findArrayListByUniqueName(em, "PojoArrayList4") :
            (type == Type.HASHSET) ? findHashSetByUniqueName(em, "PojoHashSet4") :
            findHashMapByUniqueName(em, "PojoHashMap4");
		tx.commit(); em.close();
		System.out.println("findByUniqueName: " + pojo + " version=" + pojo.getVersion());
	}
	
    private static PojoArrayList findArrayListByUniqueName(EntityManager em, String name) {
        String query = "select PojoArrayList from PojoArrayList as PojoArrayList where name = :nameValue";
        Query uniqueNameQuery = em.createQuery(query);
        uniqueNameQuery.setParameter("nameValue", name);
        return (PojoArrayList)uniqueNameQuery.getSingleResult();
    }

    private static PojoHashSet findHashSetByUniqueName(EntityManager em, String name) {
        String query = "select PojoHashSet from PojoHashSet as PojoHashSet where name = :nameValue";
        Query uniqueNameQuery = em.createQuery(query);
        uniqueNameQuery.setParameter("nameValue", name);
        return (PojoHashSet)uniqueNameQuery.getSingleResult();
    }

    private static PojoHashMap findHashMapByUniqueName(EntityManager em, String name) {
        String query = "select PojoHashMap from PojoHashMap as PojoHashMap where name = :nameValue";
        Query uniqueNameQuery = em.createQuery(query);
        uniqueNameQuery.setParameter("nameValue", name);
        return (PojoHashMap)uniqueNameQuery.getSingleResult();
    }

    private static void createEMF() throws Exception
    {
    	Properties propOverrides = new Properties();
    	String persistenceProvidersConfig = System.getProperty("persistence.props");
    	if (persistenceProvidersConfig != null) {
    		File configFile = new File(persistenceProvidersConfig.trim());
    		BufferedInputStream bis = new BufferedInputStream(new FileInputStream(configFile));
    		propOverrides.load(bis);
    	}
    	entityManagerFactory = javax.persistence.Persistence.createEntityManagerFactory("playpen", propOverrides);
    }

    // populate DB with 10 Pojo entites, each having
	// zero AttributeArrayList entites in the 1..N, Eager, Cascade.ALL collection.
	private static void initDB() {
		EntityManager em = entityManagerFactory.createEntityManager();
		EntityTransaction tx = em.getTransaction(); tx.begin();
		for (int i = 0; i < 10; i++) {
            PojoArrayList al = new PojoArrayList("PojoArrayList" + i);
            em.persist(al);
            PojoHashSet hs = new PojoHashSet("PojoHashSet" + i);
            em.persist(hs);
            PojoHashMap hm = new PojoHashMap("PojoHashMap" + i);
            em.persist(hm);
		}
		tx.commit(); em.close();
	}
}
