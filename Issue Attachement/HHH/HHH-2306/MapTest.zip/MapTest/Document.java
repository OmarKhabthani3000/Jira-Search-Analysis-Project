package at.cdes.test;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity @Table(name="Document")
public class Document implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
   private String uuid;
   private String title;
   private String content;
   private Map<Integer, DocumentHistory> histories = new HashMap<Integer, DocumentHistory>();

   @Id @GeneratedValue(generator = "system-uuid")
      @GenericGenerator(name = "system-uuid", strategy = "uuid")
   public String getUuid() {
      return uuid;
   }
   public void setUuid(String uuid) {
      this.uuid = uuid;
   }

   @Column(name = "title", length = 50)
   public String getTitle() {
      return title;
   }
   public void setTitle(String title) {
      this.title = title;
   }

   @Basic(fetch = FetchType.LAZY)
   @Column(name = "content", nullable = false)
   @Lob
   public String getContent() {
      return content;
   }
   public void setContent(String content) {
      this.content = content;
   }

   @OneToMany(mappedBy = "document", fetch = FetchType.LAZY,
         cascade = {CascadeType.ALL})
   @MapKey(name = "version")
   public Map<Integer, DocumentHistory> getHistories() {
      return this.histories;
   }
   public void setHistories(Map<Integer, DocumentHistory> histories) {
      this.histories = histories;
   }
}