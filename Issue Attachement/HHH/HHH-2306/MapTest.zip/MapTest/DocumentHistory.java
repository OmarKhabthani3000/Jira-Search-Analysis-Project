package at.cdes.test;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity @Table(name="DocumentHistory")
public class DocumentHistory implements Serializable {
   private static final long serialVersionUID = 1L;

   private String uuid;
   private int version;
   private String title;
   private String content;
   private Document document;

   @Id @GeneratedValue(generator = "system-uuid")
      @GenericGenerator(name = "system-uuid", strategy = "uuid")
   public String getUuid() {
      return uuid;
   }
   public void setUuid(String uuid) {
      this.uuid = uuid;
   }

   @Column(name = "version", nullable = false, updatable = false)
   public int getVersion() {
      return version;
   }
   public void setVersion(int version) {
      this.version = version;
   }

   @Column(name = "title", length = 50)
   public String getTitle() {
      return title;
   }
   public void setTitle(String title) {
      this.title = title;
   }

   @Basic(fetch = FetchType.LAZY)
   @Column(name = "content", nullable = false)
   @Lob
   public String getContent() {
      return content;
   }
   public void setContent(String content) {
      this.content = content;
   }

   @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "document_uuid", nullable = false, updatable = false)
   public Document getDocument() {
      return document;
   }
   public void setDocument(Document document) {
      this.document = document;
   }
}