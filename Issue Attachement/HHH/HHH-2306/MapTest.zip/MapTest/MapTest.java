package at.cdes.test;

import java.util.Map;

import junit.framework.TestCase;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class MapTest extends TestCase
{
	private Session session;

	private String documentId;

	@Override
	protected void setUp() throws Exception
	{
		AnnotationConfiguration cfg = new AnnotationConfiguration();
		cfg.addAnnotatedClass(Document.class);
		cfg.addAnnotatedClass(DocumentHistory.class);
		cfg.setProperty("hibernate.dialect",
				"org.hibernate.dialect.MySQLInnoDBDialect");
		cfg.setProperty("hibernate.connection.url",
				"jdbc:mysql://localhost/yourdb");
		cfg.setProperty("hibernate.connection.driver_class",
				"com.mysql.jdbc.Driver");
		cfg.setProperty("hibernate.connection.username", "***");
		cfg.setProperty("hibernate.connection.password", "***");
		cfg.setProperty("hibernate.show_sql", "true");

		SessionFactory sf = cfg.buildSessionFactory();

		session = sf.openSession();
		// Create a document
		Transaction tx = session.beginTransaction();
		Document document = new Document();
		document.setTitle("Title");
		document.setContent("Content");

		documentId = (String) session.save(document);
		tx.commit();
		// Kicks it out of the session cache
		session.evict(document);
	}

	@Override
	protected void tearDown() throws Exception
	{
		if (session != null && session.isOpen())
		{
			Transaction tx = session.getTransaction();
			try
			{
				// DB Clean-up
				Document document = (Document) session.get(Document.class,
						documentId);
				if (document != null)
				{
					tx.begin();
					session.delete(document);
					tx.commit();
				}
			} catch (HibernateException ex)
			{
				if (tx.isActive())
					tx.rollback();
			} finally
			{
				try
				{
					session.close();
					session = null;
				} catch (Throwable e)
				{
				}
			}
		}
	}

	public void testHistory1() throws Exception
	{
		Transaction tx = session.getTransaction();
		try
		{
			// Load it...
			Document document = (Document) session.load(Document.class,
					documentId);
			assertNotNull(document);

			DocumentHistory history = new DocumentHistory();
			history.setVersion(1);
			history.setTitle(document.getTitle());
			history.setContent(document.getContent());
			history.setDocument(document);

			// Put the new history into the map.
			// !!! The history is not persisted along with the document !!!
			Map<Integer, DocumentHistory> histories = document.getHistories();
			histories.put(history.getVersion(), history);
			
			assertEquals(1, histories.size());

			document.setTitle("New Title");
			document.setContent("New Content");

			tx.begin();
			session.flush();
			tx.commit();
			session.evict(document);

			// And load it agian...
			document = (Document) session.load(Document.class, documentId);
			assertNotNull(document);
			// Check if the DocumentHistory object persisted correctly...
			assertEquals(1, document.getHistories().size());
		} catch (HibernateException ex)
		{
			fail(ex.toString());
			tx.rollback();
		}
	}
}
