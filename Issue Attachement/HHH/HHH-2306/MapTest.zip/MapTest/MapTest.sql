CREATE TABLE `Document` (
  `uuid` char(32) NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY  (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `DocumentHistory` (
  `uuid` char(32) NOT NULL,
  `document_uuid` char(32) NOT NULL,
  `version` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY  (`uuid`),
  KEY `document_uuid` (`document_uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 