package temporal;

import java.util.Calendar;
import java.io.Serializable;

public class Employee implements Serializable {

    private Long id;
    private String name;
    private Calendar validFrom;
    private Calendar validTo;
    private Long employerId;

    public Employee() {}

    public Employee(Long id, String name, Calendar validFrom, Calendar validTo, Long employerId) {
        this.id = id;
        this.name = name;
        this.validFrom = validFrom;
        this.validTo = validTo;
        this.employerId = employerId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Calendar getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(Calendar validFrom) {
        this.validFrom = validFrom;
    }

    public Calendar getValidTo() {
        return validTo;
    }

    public void setValidTo(Calendar validTo) {
        this.validTo = validTo;
    }

    public Long getEmployerId() {
        return employerId;
    }

    public void setEmployerId(Long employerId) {
        this.employerId = employerId;
    }


    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final Employee employee = (Employee) o;

        if (!id.equals(employee.id)) return false;
        if (!validFrom.equals(employee.validFrom)) return false;
        if (!validTo.equals(employee.validTo)) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = id.hashCode();
        result = 29 * result + validFrom.hashCode();
        result = 29 * result + validTo.hashCode();
        return result;
    }

    public String toString() {
        return "EMPLOYEE: " + getId() + " FROM : " + getValidFrom().getTime() + " TO: " + getValidTo().getTime();
    }

}
