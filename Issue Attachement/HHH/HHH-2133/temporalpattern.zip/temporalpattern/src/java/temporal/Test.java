package temporal;

import org.hibernate.*;
import persistence.*;
import java.util.*;

public class Test {

    public static void main(String[] args) {

        Calendar today = new GregorianCalendar();
        Calendar tomorrow = new GregorianCalendar();
        tomorrow.roll(Calendar.DAY_OF_YEAR, 1);
        Calendar nextWeek = new GregorianCalendar();
        nextWeek.roll(Calendar.DAY_OF_YEAR, 7);
        Calendar nextMonth = new GregorianCalendar();
        nextMonth.roll(Calendar.MONTH, 1);

        System.out.println("### TODAY: " + today.getTime());
        System.out.println("### TOMORROW: " + tomorrow.getTime());
        System.out.println("### NEXTWEEK: " + nextWeek.getTime());
        System.out.println("### NEXTMONTH: " + nextMonth.getTime());

        // ############################################################################

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        Employer employerOne = new Employer(1l, "E1", today, tomorrow);
        Employer employerTwo = new Employer(1l, "E2", tomorrow, nextWeek);

        session.save(employerOne);
        session.save(employerTwo);

        Employee employeeOne = new Employee(1l, "EMP1", today, tomorrow, 1l);
        Employee employeeTwo = new Employee(1l, "EMP2", tomorrow, nextWeek, 1l);

        session.save(employeeOne);
        session.save(employeeTwo);

        tx.commit();
        session.close();

        // ############################################################################

        session = HibernateUtil.getSessionFactory().openSession();
        tx = session.beginTransaction();

        session.enableFilter("temporal").setParameter("restrictionDate", today);

        Employer emp = (Employer) session.get(Employer.class, employerOne);

        System.out.println("### GET: " + emp);

        for (Employee employee : emp.getEmployees()) {
            System.out.println("### FILTERED: " + employee);
        }

        tx.commit();
        session.close();


        // Shutting down the application
        HibernateUtil.shutdown();
    }
}
