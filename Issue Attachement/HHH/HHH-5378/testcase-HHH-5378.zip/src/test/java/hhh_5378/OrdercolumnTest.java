package hhh_5378;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class OrdercolumnTest {
	private static EntityManagerFactory emf;
	private EntityManager em;
	
	@BeforeClass
	public static void setupEMF() {
		Map<String, String> props = new HashMap<String, String>();
		emf = Persistence.createEntityManagerFactory("HHH_5378", props);
	}
	
	@AfterClass
	public static void closeEMF() {
		if (emf != null)
			emf.close();
	}
	
	@Before
	public void setupEM() {
		if (emf == null)
			throw new RuntimeException("!!! EntityManagerFactory == null !!!");
		em = emf.createEntityManager();
		if (em == null)
			throw new RuntimeException("!!! EntityManager == null !!!");
		}
	
	@After
	public void closeEM() {
		if (em != null)
			em.close();
	}
	
	@Test
	public void createOrder() {
		EntityTransaction tx = em.getTransaction();
		String customerName = "CustomerName";
		
		// Create a customer
		tx.begin();
			Customer customer = new Customer(customerName);
			em.persist(customer);
		tx.commit();
		
		// Create an order for the customer above
		tx.begin();
			customer = em.find(Customer.class, customerName);
			Assert.assertEquals(customer.getName(), customerName);
			
			List<Order> orders = customer.getOrders();
			if (orders == null) {
				orders = new ArrayList<Order>();
				customer.setOrders(orders);
			}
			int oldSize = orders.size();
			
			Order newOrder = new Order(new Date(), customer);
			orders.add(newOrder);
			
			em.persist(newOrder);
		tx.commit();
		
		// Check the persisted order
		tx.begin();
			customer = em.find(Customer.class, customerName);
			orders = customer.getOrders();
			int newSize = orders == null ? 0 : orders.size();
			Assert.assertEquals(newSize, oldSize+1);
			Assert.assertTrue(customer.getOrders().get(0).getTimestamp().getTime() < new Date().getTime());
		tx.commit();
	}
}
