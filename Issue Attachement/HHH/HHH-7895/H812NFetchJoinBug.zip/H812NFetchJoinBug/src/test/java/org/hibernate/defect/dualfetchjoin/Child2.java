package org.hibernate.defect.dualfetchjoin;

import javax.persistence.*;

@Entity(name="test_child2")
public class Child2 {
    @Id
    @Column(name = "childId", unique = true, nullable = false)
    public int id;

    @ManyToOne
    @JoinColumn(name = "parentId", nullable = false)
    public Parent parent;

    @Column(name = "myval", nullable = false)
    public int myval;
}
