package org.hibernate.defect.dualfetchjoin;

import org.junit.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class FetchJoinTest {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void before() {
        entityManagerFactory = Persistence.createEntityManagerFactory("org.hibernate.defect.dualfetchjoin");
    }

    @After
    public void after() {
        deleteAll();
        entityManagerFactory.close();
    }

    @Test
    public void test() {
        createParentWithChildren();
        printChildRecordCnt();
    }

    private void createParentWithChildren() {
        final EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        final Parent parent = new Parent();
        parent.id = 0;

        final Child1 child11 = new Child1();
        child11.id = 0;
        child11.parent = parent;
        child11.myval = 0;

        final Child1 child12 = new Child1();
        child12.id = 1;
        child12.parent = parent;
        child12.myval = 1;

        parent.children1.put(0, child11);
        parent.children1.put(1, child12);

        final Child2 child21 = new Child2();
        child21.id = 0;
        child21.parent = parent;
        child21.myval = 0;

        final Child2 child22 = new Child2();
        child22.id = 1;
        child22.parent = parent;
        child22.myval = 1;

        parent.children2.add(child21);
        parent.children2.add(child22);

        em.persist(parent);

        em.getTransaction().commit();
        em.close();
    }

    private void printChildRecordCnt() {
        final EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        final TypedQuery<Parent> query = em.createQuery("SELECT p FROM test_parent p JOIN FETCH p.children1 JOIN FETCH p.children2", Parent.class);
        final Parent parent = query.getSingleResult();
        final int child1Cnt = parent.children1.size();
        final int child2Cnt = parent.children2.size();

        em.getTransaction().commit();
        em.close();

        System.out.println(child1Cnt);
        System.out.println(child2Cnt);
    }

    private void deleteAll() {
        final EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        final Parent parent = em.find(Parent.class, 0);
        em.remove(parent);
        em.getTransaction().commit();
        em.close();
    }
}
