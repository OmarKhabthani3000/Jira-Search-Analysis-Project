package org.hibernate.defect.dualfetchjoin;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Entity(name="test_parent")
public class Parent {
    @Id
    @Column(name = "parentId", unique = true, nullable = false)
    public int id;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "parent")
    @MapKey(name = "myval")
    public Map<Integer, Child1> children1 = new HashMap<>();

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "parent")
    public List<Child2> children2 = new ArrayList<>();
}
