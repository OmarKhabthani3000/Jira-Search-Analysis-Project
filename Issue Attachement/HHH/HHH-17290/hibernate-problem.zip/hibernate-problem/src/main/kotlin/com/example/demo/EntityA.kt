package com.example.demo

import jakarta.persistence.*
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Entity
data class EntityA(
  @Id
  val entityId: String,

  @AttributeOverrides(
    AttributeOverride(name = "amount", column = Column(name = "materialCost_amount")),
    AttributeOverride(name = "currency", column = Column(name = "materialCost_currency")),
  )
  @Embedded
  val materialCost: Cost? = null,
)

@Embeddable
@Access(AccessType.FIELD)
data class Cost(
  val amount: Int,
  val currency: String,
)

@Repository
interface EntityARepository : JpaRepository<EntityA, String>
