package com.example.demo

import jakarta.persistence.*
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Entity
data class EntityB(
  @Id
  val entityId: String,

  @AttributeOverrides(
    AttributeOverride(name = "amount", column = Column(name = "materialCost_amount")),
    AttributeOverride(name = "currency", column = Column(name = "materialCost_currency")),
  )
  @Embedded
  val materialCost: CostNullable? = null,
)

@Embeddable
@Access(AccessType.FIELD)
data class CostNullable(
  val amount: Int?, // use nullable, so that a Java 'Integer' wrapper is used instead of 'int'
  val currency: String,
)

@Repository
interface EntityBRepository : JpaRepository<EntityB, String>
