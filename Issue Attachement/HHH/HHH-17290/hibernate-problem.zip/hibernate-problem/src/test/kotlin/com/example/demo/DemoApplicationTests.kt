package com.example.demo

import org.assertj.core.api.Assertions
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class DemoApplicationTests {

  @Autowired
  private lateinit var repositoryA: EntityARepository

  @Autowired
  private lateinit var repositoryB: EntityBRepository


  @Test
  fun `saving and updating of EntityA should work`() {
    val fixture = EntityA(
      entityId = "id1",
      materialCost = Cost(20, "USD")
    )

    // initial save
    val saved = repositoryA.save(fixture)
    // retrieve
    var retrieved = repositoryA.findById(fixture.entityId).get()
    // check
    Assertions.assertThat(retrieved).isEqualTo(saved)


    val fixtureNoCosts = EntityA(
      entityId = "id1",
      materialCost = null
    )
    // update (works with Hibernate 6.2.7, fails with Hibernate 6.2.8)
    val updated = repositoryA.save(fixtureNoCosts)
    Assertions.assertThat(updated).isEqualTo(fixtureNoCosts)

    // retrieve
    retrieved = repositoryA.findById(fixture.entityId).get()
    // check
    Assertions.assertThat(retrieved).isEqualTo(updated)
  }

  @Test
  fun `saving and updating of EntityB should work`() {
    val fixture = EntityB(
      entityId = "id1",
      materialCost = CostNullable(20, "USD")
    )

    // initial save
    val saved = repositoryB.save(fixture)
    // retrieve
    var retrieved = repositoryB.findById(fixture.entityId).get()
    // checks
    Assertions.assertThat(saved).isEqualTo(fixture)
    Assertions.assertThat(retrieved).isEqualTo(fixture)


    val fixtureNoCosts = EntityB(
      entityId = "id1",
      materialCost = null
    )
    // update
    val updated = repositoryB.save(fixtureNoCosts)
    // check  (works with Hibernate 6.2.7, fails with Hibernate 6.2.8)
    // v6.2.8 returns: EntityB(entityId=id1, materialCost=CostNullable(amount=null, currency=null))
    // instead of EntityB(entityId=id1, materialCost=null)
    Assertions.assertThat(updated).isEqualTo(fixtureNoCosts)

    // retrieve
    retrieved = repositoryB.findById(fixture.entityId).get()
    Assertions.assertThat(retrieved).isEqualTo(fixtureNoCosts)
  }

}
