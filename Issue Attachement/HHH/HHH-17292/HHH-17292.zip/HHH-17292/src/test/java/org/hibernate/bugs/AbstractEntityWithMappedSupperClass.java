package org.hibernate.bugs;

import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class AbstractEntityWithMappedSupperClass extends AbstractEntityRootLevel {

}