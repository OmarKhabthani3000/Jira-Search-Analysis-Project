/*
 * $Header: /repository/apps/aaa/JavaSource/net/paybox/aaa/authentication/ivr/IvrAuthenticationHandler.java,v 1.12 2006/02/22 14:01:18 skirsch Exp $
 * $Revision: 1.12 $
 * $Date: 2006/02/22 14:01:18 $
 *
 * ====================================================================
 *
 * Copyright (c) 2000-2006 paybox solutions AG. All rights reserved.
 *
 */
package net.paybox.hibernate.jira;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * <p>
 * The <code>ConcreteSelf</code> is an entity that refers to instances of its
 * own type.
 * </p>
 * 
 * @author <a href='mailto:Sebastian.Kirsch@paybox.net'>Sebastian Kirsch</a>
 * @version $Revision: 1.13 $ $Name: $
 */
@Entity
@DiscriminatorValue("1")
public class ConcreteSelf extends AbstractGeneric<ConcreteSelf> {

}