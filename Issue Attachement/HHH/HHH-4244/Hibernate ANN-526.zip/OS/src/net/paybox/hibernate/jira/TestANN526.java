/*
 * $Header: /repository/apps/aaa/JavaSource/net/paybox/aaa/authentication/ivr/IvrAuthenticationHandler.java,v 1.12 2006/02/22 14:01:18 skirsch Exp $
 * $Revision: 1.12 $
 * $Date: 2006/02/22 14:01:18 $
 *
 * ====================================================================
 *
 * Copyright (c) 2000-2006 paybox solutions AG. All rights reserved.
 *
 */
package net.paybox.hibernate.jira;

import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.dialect.HSQLDialect;
import org.junit.Assert;
import org.junit.Test;

/**
 * <p>
 * The <code>TestANN526</code> tests the EJB model.
 * </p>
 * 
 * <p>
 * &copy 2000-2007 by paybox solutions AG
 * </p>
 * 
 * @author <a href='mailto:Sebastian.Kirsch@paybox.net'>Sebastian Kirsch</a>
 * @version $Revision: 1.13 $ $Name: $
 */
public class TestANN526 {

    /**
         * Builds a session factory for {@link ConcreteOther} and
         * {@link ConcreteSelf}.
         */
    @Test
    public final void workingClasses() {
	AnnotationConfiguration config = new AnnotationConfiguration();
	// dialect doesn't matter
	config.setProperty("hibernate.dialect", HSQLDialect.class.getName());
	config.addAnnotatedClass(ConcreteOther.class);
	config.addAnnotatedClass(ConcreteSelf.class);
	config.buildSessionFactory().close();
    }

    /**
         * Builds a session factory for {@link AbstractGeneric},
         * {@link ConcreteOther} and {@link ConcreteSelf}.
         */
    @Test
    public final void breakingClasses() {
	AnnotationConfiguration config = new AnnotationConfiguration();
	// dialect doesn't matter
	config.setProperty("hibernate.dialect", HSQLDialect.class.getName());
	config.addAnnotatedClass(AbstractGeneric.class);
	config.addAnnotatedClass(ConcreteOther.class);
	config.addAnnotatedClass(ConcreteSelf.class);
	config.buildSessionFactory().close();
    }

    /**
         * Builds a session factory for {@link OtherEntity} and associated
         * entities classes.
         */
    @Test
    public final void otherClass() {
	AnnotationConfiguration config = new AnnotationConfiguration();
	// dialect doesn't matter
	config.setProperty("hibernate.dialect", HSQLDialect.class.getName());
	config.addAnnotatedClass(OtherEntity.class);
	try {
	    config.buildSessionFactory().close();
	    Assert.fail("It seems that the bug's fixed!");
	} catch (Exception e) {
	    // right, Hibernate doesn't know AbstractGeneric
	    System.err.println(e);
	}
	config.addAnnotatedClass(AbstractGeneric.class);
	config.buildSessionFactory().close();
    }

}