/*
 * $Header: /repository/apps/aaa/JavaSource/net/paybox/aaa/authentication/ivr/IvrAuthenticationHandler.java,v 1.12 2006/02/22 14:01:18 skirsch Exp $
 * $Revision: 1.12 $
 * $Date: 2006/02/22 14:01:18 $
 *
 * ====================================================================
 *
 * Copyright (c) 2000-2006 paybox solutions AG. All rights reserved.
 *
 */
package net.paybox.hibernate.jira;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;

/**
 * <p>
 * The <code>AbstractGeneric</code> is a base class with a generic type for
 * the reference entity.
 * </p>
 * 
 * @author <a href='mailto:Sebastian.Kirsch@paybox.net'>Sebastian Kirsch</a>
 * @version $Revision: 1.13 $ $Name: $
 * @param <T>
 *                the reference's type
 */
@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "Type")
public abstract class AbstractGeneric<T extends AbstractGeneric> {

    /** The PK. */
    @Id
    public long id;

    /** The reference. */
    @ManyToOne
    public T reference;

}