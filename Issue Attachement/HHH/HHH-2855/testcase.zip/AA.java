/*
 * AA.java
 *
 * Created on 20. September 2007, 13:29
 */
/**
 *
 * @author Peter Fassev
 */
public class AA extends A {

    private int a;
    
    /** Creates a new instance of AA */
    public AA() {
    }

    /** Creates a new instance of AA */
    public AA(int id, String name, int a) {
        super(id, name);
        this.a = a;
    }

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }
}
