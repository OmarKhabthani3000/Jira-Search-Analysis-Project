/*
 * AB.java
 *
 * Created on 20. September 2007, 13:29
 */
/**
 *
 * @author Peter Fassev
 */
public class AB extends A {
    
    private int b;
    
    /** Creates a new instance of AB */
    public AB() {
    }

    /** Creates a new instance of AA */
    public AB(int id, String name, int b) {
        super(id, name);
        this.b = b;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    
}
