/*
 * A.java
 *
 * Created on 20. September 2007, 13:29
 */
/**
 *
 * @author Peter Fassev
 */
public class A {
    
    private int id;
    
    private String name;
    
    private B bObject;

    /** Creates a new instance of A */
    public A() {
    }

    /** Creates a new instance of B */
    public A(int id, String name) {
        this.setId(id);
        this.setName(name);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String toString() {
        return name;
    }
    
    public B getBObject() {
        return bObject;
    }

    public void setBObject(B bObject) {
        this.bObject = bObject;
    }
    
}
