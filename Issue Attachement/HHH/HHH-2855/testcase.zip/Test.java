/*
 * Test.java
 *
 * Created on 20. September 2007, 13:37
 */

import java.util.*;

import org.hibernate.*;
import org.hibernate.dialect.*;
import org.hibernate.cfg.Environment;

/**
 *
 * @author Peter Fassev
 */
public class Test extends TestCase {
    
	public Test(String name) {
		super(name);
	}
    
	protected String getBaseForMappings() {
		return "";
	}
    
	protected String[] getMappings() {
		return new String[]{"hibernate.hbm.xml"};
	}

    private void insertTestData() {
        // create 3 dependent objects
		Session s = openSession();
		Transaction t = s.beginTransaction();
        AB ab = new AB(1, "ab1", 1);
        s.save(ab);
        AA aa = new AA(2, "aa1", 2);
        s.save(aa);
        // attach "aa" and "ab" to "b"
        B b = new B(1, "b1");
        b.addAa(aa);
        b.addAb(ab);
        s.save(b);
		t.commit();
		s.close();
	}

    public void test() throws Exception {
        try {
            deleteAll();
			insertTestData();
            Session s = openSession();
            Transaction t = s.beginTransaction();
            // load the object "b"
            List l = s.createQuery("select o from B as o").list();
            // try to access the "aaList", here you will get an exception, because the query select no only the "aa" object, but also "ab"
            // the query needs a subclass selector (discriminator)!
            System.out.println(((B)l.get(0)).getAaList().get(0));
            t.commit();
            s.close();
        } finally {
            deleteAll();
        }
    }
    
    private void deleteAll() {
		Session s = openSession();
		Transaction t = s.beginTransaction();
        s.createQuery("delete from AA").executeUpdate();
        s.createQuery("delete from AB").executeUpdate();
        s.createQuery("delete from B").executeUpdate();
		t.commit();
		s.close();
	}

    public static void main(String[] args) throws Exception
    {
        /*        ResourceManagerTest test = new ResourceManagerTest();
        test.runTests();*/
        startUnitTests(Test.class.getName());
    }

    public static void startUnitTests(String testClass)
    {
        junit.swingui.TestRunner runner = new junit.swingui.TestRunner();
        runner.setLoading(false);
        runner.start(new String[] { testClass });
    }
}
