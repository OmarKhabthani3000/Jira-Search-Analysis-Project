/*
 * B.java
 *
 * Created on 20. September 2007, 13:29
 */

import java.util.*;
/**
 *
 * @author Peter Fassev
 */
public class B {
    
    private int id;
    
    private String name;
    
    private List aaList;
    
    private List abList;
    
    /** Creates a new instance of B */
    public B() {
    }
    
    /** Creates a new instance of B */
    public B(int id, String name) {
        this.setId(id);
        this.setName(name);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addAa(AA aa) {
        if (aaList == null) {
            aaList = new ArrayList();
        }
        if (!aaList.contains(aa)) {
            aaList.add(aa);
            aa.setBObject(this);
        }
    }

    public List getAaList() {
        return aaList;
    }

    public void setAaList(List aaList) {
        this.aaList = aaList;
    }

    public void addAb(AB ab) {
        if (abList == null) {
            abList = new ArrayList();
        }
        if (!abList.contains(ab)) {
            abList.add(ab);
            ab.setBObject(this);
        }
    }

    public List getAbList() {
        return abList;
    }

    public void setAbList(List abList) {
        this.abList = abList;
    }

    public String toString() {
        return name;
    }

}
