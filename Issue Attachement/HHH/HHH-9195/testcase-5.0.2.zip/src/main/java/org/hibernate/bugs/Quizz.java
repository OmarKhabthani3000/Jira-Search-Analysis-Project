package org.hibernate.bugs;

import org.hibernate.Hibernate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Quizz {
    @Id
    @GeneratedValue
    private Long id;

    @OneToMany(mappedBy = "quizz", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderColumn(name = "position")
    private List<Question> questions = new ArrayList<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Question> getQuestions() {
        return questions;
    }

    public void addQuestion(Question question) {
        question.setQuizz(this);
        questions.add(question);
    }

    public void addQuestion(int index, Question question) {
        question.setQuizz(this);
        questions.add(index, question);
    }

    public void addQuestionAndInitializeLazyList(int index, Question question) {
        question.setQuizz(this);
        questions.add(index, question);
        Hibernate.initialize(questions);
    }
}
