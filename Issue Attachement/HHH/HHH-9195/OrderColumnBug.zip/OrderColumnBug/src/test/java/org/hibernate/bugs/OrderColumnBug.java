package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class OrderColumnBug {
	private Configuration config;

	private SessionFactory sessionFactory;

    private Long quizzId;

	@SuppressWarnings("deprecation")
	@Before
	public void setup() {
		config = new Configuration();

		config.addAnnotatedClass(Quizz.class);
        config.addAnnotatedClass(Question.class);

		config.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
		config.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:myunittests");
		config.setProperty("hibernate.connection.username", "sa");
		config.setProperty("hibernate.connection.password", "");
		config.setProperty("hibernate.connection.pool_size", "1");
		config.setProperty("hibernate.current_session_context_class", "thread");
		config.setProperty("hibernate.hbm2ddl.auto", "update");
		config.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
		config.setProperty("hibernate.show_sql", "true");

		sessionFactory = config.buildSessionFactory();

        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        Quizz quizz = new Quizz();
        session.persist(quizz);
        quizz.addQuestion(new Question("question 1"));
        quizz.addQuestion(new Question("question 2"));
        quizz.addQuestion(new Question("question 3"));

        transaction.commit();
        session.close();

        this.quizzId = quizz.getId();
    }

    /**
     * This test fails, but shouldn't
     */
	@Test
    public void addQuestionWithIndexShouldAddQuestionAtSpecifiedIndex() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        Quizz quizz = (Quizz) session.get(Quizz.class, quizzId);
        quizz.addQuestion(1, new Question("question that should be at index 1"));

        transaction.commit();
        session.close();

        session = sessionFactory.openSession();
        transaction = session.beginTransaction();

        quizz = (Quizz) session.get(Quizz.class, quizzId);

        assertEquals(4, quizz.getQuestions().size());
        assertEquals("question that should be at index 1", quizz.getQuestions().get(1).getText());

        transaction.commit();
        session.close();
    }

    /**
     * This test succeeds thanks to a dirty workaround consisting in initializing the ordered question list after the
     * question, has been inserted
     */
    @Test
    public void addQuestionWithIndexAndInitializeTheListShouldAddQuestionAtSpecifiedIndex() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        Quizz quizz = (Quizz) session.get(Quizz.class, quizzId);
        quizz.addQuestionAndInitializeLazyList(1, new Question("question that should be at index 1"));

        transaction.commit();
        session.close();

        session = sessionFactory.openSession();
        transaction = session.beginTransaction();

        quizz = (Quizz) session.get(Quizz.class, quizzId);

        assertEquals(4, quizz.getQuestions().size());
        assertEquals("question that should be at index 1", quizz.getQuestions().get(1).getText());

        transaction.commit();
        session.close();
    }
}
