DROP ALL OBJECTS;


CREATE TABLE AUTHOR (
    id                          int not null IDENTITY,
    primary key (id)
);

CREATE TABLE BOOK (
    id                          int not null IDENTITY,
    author_id                   int,
    title                       varchar(100) not null,
    constraint book_fk_1 foreign key (author_id) references AUTHOR,
    primary key (id)
);
