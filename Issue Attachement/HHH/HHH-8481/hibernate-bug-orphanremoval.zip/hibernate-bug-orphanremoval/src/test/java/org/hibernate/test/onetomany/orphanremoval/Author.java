package org.hibernate.test.onetomany.orphanremoval;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Author {
    private Integer id;
    private List<Book> books = new ArrayList<Book>();
    
    @Id
    @GeneratedValue
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @OneToMany(mappedBy = "author", orphanRemoval = false, cascade = CascadeType.ALL)
    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }

    public void addBook(Book book) {
        getBooks().add(book);
        book.setAuthor(this);
    }

    public void removeBook(Book book) {
        getBooks().remove(book);
        book.setAuthor(null);
    }
}