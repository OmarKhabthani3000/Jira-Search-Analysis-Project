package org.hibernate.test.onetomany.orphanremoval;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:applicationContext.xml" })
@Transactional
public class DeleteOneToManyOrphanTest {

    @PersistenceContext
    EntityManager em;
    
    // the unit test pass if you set to 'false'
    private boolean removeBookWhileAuthorIsDetached = true;

    @Test
    @Rollback
    public void testOrphanedWhileManaged() {

        // Let's create an author with a book
        Author author = new Author();
        Book book = new Book();
        book.setTitle("bug encyclopedia");
        author.addBook(book);
        em.persist(author);
        em.flush();
        em.clear();

        // let's check they were created
        List<Author> results = (List<Author>) em.createQuery("from Author").getResultList();
        assertEquals(1, results.size());
        author = results.get(0);
        assertEquals(1, author.getBooks().size());
        book = author.getBooks().get(0);

        // let's remove the book
        if (removeBookWhileAuthorIsDetached) {
            em.detach(author);
            assertEquals("detach is normally propagated to book", false, em.contains(book));
        }
        author.removeBook(book);
        assertEquals(0, author.getBooks().size());

        if (removeBookWhileAuthorIsDetached) {
            // let's merge our removal... cascade should do it
            author = em.merge(author);
        }

        em.flush();
        em.clear();

        // make sure book was unlinked
        author = em.find(Author.class, author.getId());
        assertEquals("Book should have been unlinked", 0, author.getBooks().size());
        em.clear();

        // make sure orphan book is still present in db
        List<Book> books = (List<Book>) em.createQuery("from Book").getResultList();
        assertEquals("Book should still be there!", 1, books.size());
    }
}