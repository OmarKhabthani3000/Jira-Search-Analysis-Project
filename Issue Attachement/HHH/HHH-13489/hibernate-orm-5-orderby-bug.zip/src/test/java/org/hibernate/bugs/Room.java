package org.hibernate.bugs;

import org.hibernate.bugs.Chair;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by sviataslau apanasionak(sviato_slav@tut.by)  on 09.07.2019.
 */

@Entity
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "room")
    private List<Chair> chairs = new ArrayList<>();

    private String name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Chair> getChairs() {
        return chairs;
    }

    public void setChairs(List<Chair> chairs) {
        this.chairs = chairs;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
