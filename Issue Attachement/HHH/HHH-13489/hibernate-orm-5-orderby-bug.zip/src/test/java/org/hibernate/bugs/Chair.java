package org.hibernate.bugs;

import javax.persistence.*;

/**
 * Created by sviataslau apanasionak(sviato_slav@tut.by)  on 09.07.2019.
 */

@Entity
public class Chair {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne( fetch = FetchType.LAZY, mappedBy = "chair")
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn
    private Room room;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }
}
