package org.hibernate.bugs;

import org.hibernate.bugs.Chair;

import javax.persistence.*;

/**
 * Created by sviataslau apanasionak(sviato_slav@tut.by)  on 09.07.2019.
 */

@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn
    private Chair chair;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Chair getChair() {
        return chair;
    }

    public void setChair(Chair chair) {
        this.chair = chair;
    }
}
