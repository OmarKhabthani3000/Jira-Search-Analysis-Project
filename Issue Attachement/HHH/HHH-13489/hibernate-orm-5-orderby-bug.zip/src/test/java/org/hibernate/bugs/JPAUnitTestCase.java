package org.hibernate.bugs;

import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.*;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		Room room = new Room();
		entityManager.persist(room);

		Chair chair = new Chair();
		chair.setRoom(room);
		entityManager.persist(chair);

		User user1 = new User();
		user1.setChair(chair);
		entityManager.persist(user1);

		User user2 = new User();
		entityManager.persist(user2);

		CriteriaBuilder cb = entityManager.getCriteriaBuilder();

		CriteriaQuery<User> query = cb.createQuery(User.class);

		Root<User> root = query.from(User.class);
		query.select(root);

		Join roomJoin = root.join("chair", JoinType.LEFT).join("room", JoinType.LEFT);

		//work normal
		Order order1 = cb.asc(roomJoin.get("name"));

		EntityGraph entityGraph = entityManager.createEntityGraph(User.class);
		entityGraph.addSubgraph("chair").addSubgraph("room");


		query.orderBy(order1);

		List<User> users = entityManager.createQuery(query).
				setHint("javax.persistence.fetchgraph", entityGraph).getResultList();

		Assert.assertEquals(2, users.size());

		//work wrong, cross joins
		Order order2 =  cb.asc(root.get("chair").get("room").get("name"));
		query.orderBy(order2);

		users = entityManager.createQuery(query).
				setHint("javax.persistence.fetchgraph", entityGraph).getResultList();

		Assert.assertEquals(2, users.size());

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
