package de.laliluna.test;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "tree_seq", sequenceName = "tree_id_seq")
public class Tree implements Serializable {

	private Integer id;

	private Set<Leaf> leafs = new HashSet<Leaf>();

	private Forest forest;

	public Tree() {
		super();
	}

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "tree_seq")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@OneToMany(mappedBy = "tree")
	@Column(name="tree_id")
	public Set<Leaf> getLeafs() {
		return leafs;
	}

	public void setLeafs(Set<Leaf> leafs) {
		this.leafs = leafs;
	}

	@ManyToOne
	public Forest getForest() {
		return forest;
	}

	public void setForest(Forest forest) {
		this.forest = forest;
	}

}
