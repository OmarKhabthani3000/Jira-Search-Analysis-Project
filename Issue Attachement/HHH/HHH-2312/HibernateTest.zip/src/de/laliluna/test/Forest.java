package de.laliluna.test;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "forest_seq", sequenceName = "forest_id_seq")
public class Forest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2040256167739484204L;

	private Integer id;

	private Set<Tree> trees = new HashSet<Tree>();

	public Forest() {
		super();
	}

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "forest_seq")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@OneToMany(mappedBy = "forest")
	@Column(name="forest_id")
	public Set<Tree> getTrees() {
		return trees;
	}

	public void setTrees(Set<Tree> trees) {
		this.trees = trees;
	}

}
