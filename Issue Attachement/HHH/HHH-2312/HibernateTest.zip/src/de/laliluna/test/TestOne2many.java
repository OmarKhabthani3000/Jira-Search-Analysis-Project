package de.laliluna.test;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import de.laliluna.hibernate.InitSessionFactory;

public class TestOne2many {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Session session = InitSessionFactory.getInstance().getCurrentSession();
		session.beginTransaction();
		session.createCriteria(Tree.class).createCriteria("leafs").add(Restrictions.eq("name", "test")).list();
		session.getTransaction().commit();

	}

}
