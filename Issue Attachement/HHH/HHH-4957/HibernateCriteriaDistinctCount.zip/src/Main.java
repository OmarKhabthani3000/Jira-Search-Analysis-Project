
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;

public class Main {
	
	public static void main(String[] args) {
		HibernateUtil.setup("create table Supplier ( id int, name VARCHAR);");
		
		prepareData();
		Session session = HibernateUtil.currentSession();		
		
        HibernateUtil.checkData("select * from Supplier");

		Criteria countCrit = session.createCriteria(Supplier.class);
        countCrit.setProjection(Projections.countDistinct("name"));
        long count = (Long) countCrit.uniqueResult();
        System.out.println("Nr suppliers to display: " + count);

	}

	private static void prepareData(){
        Session session = HibernateUtil.currentSession();

        Supplier supplier1 = new Supplier();
        supplier1.setName("Supplier Name 1");
        session.save(supplier1);
        
        Supplier supplier2 = new Supplier();
        supplier2.setName("Supplier Name 2");
        session.save(supplier2);   
        
        Supplier supplier3 = new Supplier();
        supplier3.setName("Supplier Name 2");
        session.save(supplier3);    
        
        session.flush();
        HibernateUtil.closeSession();
	}
}