package testbed.app;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import testbed.model.Users;

public class HibernateApp {

    public static void main(String args[]) {

        
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();

        Criteria c = s.createCriteria(Users.class);
        c.setProjection(Projections.projectionList().add(Projections.property("addr")));
        c.list();
        
        s.close();
        sf.close();

    }

}
