package testbed.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Address")
public class Addresses  implements java.io.Serializable {

    @Id
    private int id;

    @Column(name="CITY", length=30)
    private String city;

    @OneToOne
    @MapsId
    @JoinColumn(name="user_id")
    private Users users;

    public Addresses() {
    }
	
    public Addresses(String street, String city) {
       this.city = city;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public String getCity() {
        return this.city;
    }
    
    public void setCity(String city) {
        this.city = city;
    }

}


