package testbed.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity()
@Table(name="USERS")
public class Users  implements java.io.Serializable {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;

    @Column(name="USERNAME", length=20)
    private String username;

    @OneToOne(cascade=CascadeType.ALL, mappedBy="users")
    private Addresses addr;

    public Addresses getAddr() {
        return addr;
    }

    public void setAddr(Addresses addr) {
        this.addr = addr;
    }

    public Users() {
    }

    public Users(int id) {
        this.id = id;
    }
    
    public Users(int id, String username) {
       this.id = id;
       this.username = username;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

}
