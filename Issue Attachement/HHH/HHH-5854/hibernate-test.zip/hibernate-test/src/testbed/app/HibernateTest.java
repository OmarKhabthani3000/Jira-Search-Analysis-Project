package testbed.app;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.junit.Test;

import testbed.model.Addresses;
import testbed.model.Users;

public class HibernateTest
{
	public static void main(String args[])
	{
		new HibernateTest().testProjection();
	}

	@Test
	public void testProjection()
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session s = sf.openSession();

		fillDb(s);

		Criteria c = s.createCriteria(Users.class);
		c.setProjection(Projections.projectionList().add(Projections.property("addr")));
		c.list();

		s.close();
		sf.close();

	}

	public void fillDb(Session s)
	{
		Users users = new Users();
		users.setUsername("testuser");
		s.save(users);

		Addresses addresses = new Addresses("street", "city");
		users.setAddr(addresses);
		addresses.setUsers(users);
		s.save(addresses);

	}

}
