package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "`object_a_details`")
public class ObjectADetails
{
	@Id
	@Column(name="object_id")
	private Integer objectId;
	
	@MapsId
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "details", optional = false)
    @JoinColumn(name = "object_id")
	private ObjectA object;
	
	public ObjectADetails() {}
	
	public ObjectADetails(ObjectA object)
	{
		this.object = object;
	}
	
	public ObjectA getObject()
	{
		return object;
	}
	
	public void setObject(ObjectA object)
	{
		this.object = object;
	}
	
	public String toString()
	{
		return "{ObjectADetails}";
	}
}
