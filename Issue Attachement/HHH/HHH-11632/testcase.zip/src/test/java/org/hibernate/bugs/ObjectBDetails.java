package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "`object_b_details`")
public class ObjectBDetails
{
	@Id
	@Column(name="object_id")
	private Integer objectId;
	
	@MapsId
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "details", optional = false)
    @JoinColumn(name = "object_id")
	private ObjectB object;
	
	public ObjectBDetails() {}
	
	public ObjectBDetails(ObjectB object)
	{
		this.object = object;
	}
	
	public ObjectB getObject()
	{
		return object;
	}
	
	public void setObject(ObjectB object)
	{
		this.object = object;
	}
	
	public String toString()
	{
		return "{ObjectBDetails}";
	}
}
