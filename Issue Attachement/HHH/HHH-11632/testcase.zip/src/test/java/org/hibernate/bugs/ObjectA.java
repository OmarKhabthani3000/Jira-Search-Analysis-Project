package org.hibernate.bugs;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@DiscriminatorValue("A")
public class ObjectA extends ObjectBase
{
	@PrimaryKeyJoinColumn
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private ObjectADetails details;
	
	public ObjectA() {}
	
	public ObjectA(int id)
	{
		super(id);
		setDetails(new ObjectADetails(this));
	}
	
	public ObjectADetails getDetails()
	{
		return details;
	}
	
	public void setDetails(ObjectADetails details)
	{
		this.details = details;
	}
	
	public String toString()
	{
		return "{ObjectA id=" + getId() + ", details=" + getDetails() + "}";
	}
}
