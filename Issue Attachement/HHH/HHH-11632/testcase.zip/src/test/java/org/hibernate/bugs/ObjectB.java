package org.hibernate.bugs;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@DiscriminatorValue("B")
public class ObjectB extends ObjectBase
{
	@PrimaryKeyJoinColumn
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private ObjectBDetails details;
	
	public ObjectB() {}
	
	public ObjectB(int id)
	{
		super(id);
		setDetails(new ObjectBDetails(this));
	}
	
	public ObjectBDetails getDetails()
	{
		return details;
	}
	
	public void setDetails(ObjectBDetails details)
	{
		this.details = details;
	}
	
	public String toString()
	{
		return "{ObjectB id=" + getId() + ", details=" + getDetails() + "}";
	}
}
