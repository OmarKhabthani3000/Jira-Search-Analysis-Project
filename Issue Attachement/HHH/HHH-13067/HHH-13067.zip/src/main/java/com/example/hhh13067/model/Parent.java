package com.example.hhh13067.model;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table
public class Parent implements Serializable {

  private static final long serialVersionUID = 1L;
  private Long id;
  private Set<Child> children;

  @Id
  @Column
  public Long getId() {
    return this.id;
  }

  public void setId(final Long id) {
    this.id = id;
  }

  @ManyToMany(fetch = FetchType.EAGER)
  //@Fetch(FetchMode.SUBSELECT)
  public Set<Child> getChildren() {
    return children;
  }

  public void setChildren(final Set<Child> children) {
    this.children = children;
  }
}
