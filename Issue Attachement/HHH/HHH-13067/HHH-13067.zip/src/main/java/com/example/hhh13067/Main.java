package com.example.hhh13067;

import com.example.hhh13067.model.Child;
import com.example.hhh13067.model.Parent;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataBuilder;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.SessionFactoryBuilder;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Main {

  public static void main(final String[] arguments) {
    // Bootstrap
    final StandardServiceRegistryBuilder registryBuilder = new StandardServiceRegistryBuilder();
    registryBuilder.configure();
    final StandardServiceRegistry registry = registryBuilder.build();
    final MetadataSources metadataSources = new MetadataSources(registry);
    final MetadataBuilder metadataBuilder = metadataSources.getMetadataBuilder();
    final Metadata metadata = metadataBuilder.build();
    final SessionFactoryBuilder sessionFactoryBuilder = metadata.getSessionFactoryBuilder();
    try (final SessionFactory sessionFactory = sessionFactoryBuilder.build()) {
      // Setup
      try (final Session session = sessionFactory.openSession()) {
        final Transaction transaction = session.beginTransaction();
        final Child child1 = new Child();
        child1.setId(1L);
        session.save(child1);
        final Child child2 = new Child();
        child2.setId(2L);
        session.save(child2);
        final Parent parent = new Parent();
        parent.setId(3L);
        final Set<Child> children = new HashSet<>();
        children.add(child1);
        children.add(child2);
        parent.setChildren(children);
        session.save(parent);
        transaction.commit();
      }
      // Test 1 using CriteriaQuery API
      try (final Session session = sessionFactory.openSession()) {
        final CriteriaBuilder builder = session.getCriteriaBuilder();
        final CriteriaQuery<Parent> query = builder.createQuery(Parent.class);
        final Root<Parent> root = query.from(Parent.class);
        query.select(root);
        final TypedQuery<Parent> typedQuery = session.createQuery(query);
        final List<Parent> list = typedQuery.getResultList();
        if (list.size() != 1) {
          throw new RuntimeException("List size should be 1");
        }
      }
      // Test 2 using legacy Hibernate Criteria API
      try (final Session session = sessionFactory.openSession()) {
        @SuppressWarnings("deprecation")
        final Criteria criteria = session.createCriteria(Parent.class);
        //criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        final List list = criteria.list();
        if (list.size() != 1) {
          throw new RuntimeException("List size should be 1");
        }
      }
    }
  }
}
