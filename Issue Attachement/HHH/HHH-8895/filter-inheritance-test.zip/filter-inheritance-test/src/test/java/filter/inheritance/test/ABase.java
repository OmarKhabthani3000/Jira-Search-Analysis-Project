package filter.inheritance.test;


import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.Filters;
import org.hibernate.annotations.ParamDef;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;


@MappedSuperclass
@FilterDef(name="fooFilter", parameters=@ParamDef( name="foo", type="long" ) )
@Filters({
        @Filter(name="fooFilter", condition = ":foo = foo")
})
public abstract class ABase {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long foo;


    public Long getId() {
        return id;
    }


    public Long getFoo() {
        return foo;
    }

    public void setFoo(Long foo) {
        this.foo = foo;
    }
}
