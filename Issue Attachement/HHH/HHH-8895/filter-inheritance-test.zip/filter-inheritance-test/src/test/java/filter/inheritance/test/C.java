package filter.inheritance.test;

import javax.persistence.Entity;

@Entity
public class C extends B {

}
