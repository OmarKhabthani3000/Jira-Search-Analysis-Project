package filter.inheritance.test;

import org.hibernate.Session;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import java.util.Locale;

public class FilterInheritanceTest {


    static {
        Locale.setDefault(Locale.UK);
    }

    EntityManager em;

    @Before
    public void before() {
        em = Persistence.createEntityManagerFactory("default").createEntityManager();
        ((Session) em.getDelegate()).enableFilter("fooFilter").setParameter("foo", 9999L);

    }

    @Test
    public void test_select_from_A() {
        em.createQuery("SELECT a FROM A a").getResultList();
    }

    /**
     * Will fail with:<br/>
     * <code>javax.persistence.PersistenceException: org.hibernate.exception.SQLGrammarException: Column "B0_.FOO" not found; SQL statement:<br/>
     * select b0_.id as id6_, b0_1_.foo as foo6_, case when b0_2_.id is not null then 2 when b0_.id is not null then 1 end as clazz_ from B b0_ inner join A b0_1_ on b0_.id=b0_1_.id left outer join C b0_2_ on b0_.id=b0_2_.id where ? = b0_.foo and ? = b0_1_.foo [42122-170]</code>
     **/
    @Test
    public void test_select_from_B() {
        em.createQuery("SELECT b FROM B b").getResultList();
    }


    /**
     * Will fail with:<br/>
     * <code>javax.persistence.PersistenceException: org.hibernate.exception.SQLGrammarException: Column "B0_.FOO" not found; SQL statement:<br/>
     * select c0_.id as id12_, c0_2_.foo as foo12_ from C c0_ inner join B c0_1_ on c0_.id=c0_1_.id inner join A c0_2_ on c0_.id=c0_2_.id where ? = c0_.foo and ? = c0_1_.foo and ? = c0_2_.foo [42122-170]
     **/
    @Test
    public void test_select_from_C() {
        em.createQuery("SELECT c FROM C c").getResultList();
    }

}
