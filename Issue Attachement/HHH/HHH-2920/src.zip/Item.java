package auction;

import java.util.HashSet;
import java.util.Set;


public class Item {
	private long id;
	
	private String name;
	
	private Set<Bid> bids = new HashSet<Bid>();

	public Item() {
	}
	
	public Item(String name) {
		this.name = name;
	}

	public long getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
	
	@Override
	public String toString(){
		StringBuilder builder = new StringBuilder();
		builder.append("Name: ")
		.append(getName());
		System.out.println("Number of bids: "+ bids.size());
		for (Bid bid : bids) {
			builder.append("\n\tBid:\n")
				.append("amount: ")
				.append(bid.getAmount());
			
			if(bid instanceof CashBid){
				CashBid cashBid = (CashBid) bid;
				builder.append(" currency: " + cashBid.getCurrency());
			} 
		}
		return builder.toString();
	}

	public void addBid(Bid bid) {
		bids.add(bid);
		bid.setItem(this);
	}

	public void clear() {
		bids.clear();
	}
	
	public Set<Bid> getBids() {
		return bids;
	}

}
