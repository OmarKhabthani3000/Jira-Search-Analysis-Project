package auction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		
		// First Session
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		Bid bid = new CashBid(new BigDecimal(100.0d), "euro");
		Item item = new Item("pc");
		
		Serializable bidId = session.save(bid);
		item.addBid(bid);
		session.save(item);
		
		transaction.commit();
		session.close();
		
		// Second Session
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		
		session.load(CashBid.class, bidId);
		
		Query query = session.createQuery("from Item");
		List<Item> list = query.list();
		for (Item item_ : list) {
			System.out.println(item_);
		}
		
		transaction.commit();
		session.close();
		
		//Shutdown
		sessionFactory.close();
		
	}

}
