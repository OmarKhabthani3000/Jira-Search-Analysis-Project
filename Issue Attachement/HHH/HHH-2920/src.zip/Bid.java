package auction;

import java.math.BigDecimal;

public class Bid  {
	private BigDecimal amount;
	private Item item;
	private long id;
	
	public Bid() {}
	
	public Bid(BigDecimal amount) {
		this.amount = amount;
	}
	
	public BigDecimal getAmount() {
		return amount;
	}
	
	public long getId() {
		return id;
	}
	
	public void setItem(Item item) {
		this.item = item;
	}
	
	public Item getItem() {
		return item;
	}
	

	
}
