package auction;

import java.math.BigDecimal;

public class CashBid extends Bid {
	private String currency;

	public CashBid() {
		super();
	}
	
	public CashBid(BigDecimal offer, String currency) {
		super(offer);
		this.currency = currency;
	}
	
	public String getCurrency() {
		return currency;
	}
}
