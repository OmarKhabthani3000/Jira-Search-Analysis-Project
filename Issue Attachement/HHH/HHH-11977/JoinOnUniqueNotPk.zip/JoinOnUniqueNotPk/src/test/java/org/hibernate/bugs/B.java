package org.hibernate.bugs;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity @Table(name="B")
public class B implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="uniqueKey_a", referencedColumnName="uniqueKey") // A has it's PK, but I want to to join on the UK
	private A a;

	public A getA() {
		return a;
	}

	public void setA(A a) {
		this.a = a;
	}
}