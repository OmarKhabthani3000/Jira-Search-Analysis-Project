package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		entityManager.getTransaction().begin();
		A a = new A();
		a.setPrimaryKey(1); // primary and
		a.setUniqueKey(9); // unique are different
		entityManager.persist(a);

		B b = new B();
		b.setA( a );
		entityManager.persist(b);
		entityManager.getTransaction().commit();
		entityManager.clear(); // clear because I want to force a query

		a = entityManager.createQuery("select a from A a where a.primaryKey = :pk", A.class)
				.setParameter("pk", 1)
				.getSingleResult(); // goes ok
		b = entityManager.createQuery("select b from B b join b.a a where a = :a", B.class)
				.setParameter("a", a)
				// fails, doesn't find a "b" whose "a" has primaryKey = 9
				// It should look for a "b" whose "a" has primaryKey = 1, instead
				.getSingleResult();

		entityManager.close();
	}
}
