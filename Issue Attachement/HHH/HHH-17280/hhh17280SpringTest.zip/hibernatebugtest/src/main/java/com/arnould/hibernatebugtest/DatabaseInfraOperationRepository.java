package com.arnould.hibernatebugtest;

import java.util.List;

import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Repository;

import com.arnould.hibernatebugtest.db.EnvironmentTestCaseEntity;
import com.arnould.hibernatebugtest.db.InfraOperationJpaRepository;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;

@Repository
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class DatabaseInfraOperationRepository {
	InfraOperationJpaRepository repository;


	public List<EnvironmentTestCaseEntity> findEnvironments() {
		return repository.findEnvironmentWithOperations(PageRequest.of(0, 10));
	}


}
