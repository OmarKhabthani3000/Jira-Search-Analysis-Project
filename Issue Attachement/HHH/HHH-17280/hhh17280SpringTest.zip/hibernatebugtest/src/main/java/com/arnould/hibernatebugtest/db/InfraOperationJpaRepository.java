package com.arnould.hibernatebugtest.db;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface InfraOperationJpaRepository extends JpaRepository<InfraOperationTestCaseEntity, String> {

	@Query("""
					SELECT DISTINCT
					infraOperation.environment
				FROM
					InfraOperationTestCase infraOperation
				WHERE
					infraOperation.status In ('PENDING') AND
					infraOperation.environment.key not in (
					  SELECT
					    existingInfraOperation.environment.key
					  FROM
					    InfraOperationTestCase existingInfraOperation
					  WHERE
					  	existingInfraOperation.status IN ('IN_PROGRESS', 'ERROR')
					)
			""")
	List<EnvironmentTestCaseEntity> findEnvironmentWithOperations(Pageable pageable);

}
