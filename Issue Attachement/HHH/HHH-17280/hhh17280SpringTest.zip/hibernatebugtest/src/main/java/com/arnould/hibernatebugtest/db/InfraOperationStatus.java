package com.arnould.hibernatebugtest.db;

public enum InfraOperationStatus {
	ERROR,
	IN_PROGRESS,
	PENDING,
	SKIP,
	SUCCESS
}
