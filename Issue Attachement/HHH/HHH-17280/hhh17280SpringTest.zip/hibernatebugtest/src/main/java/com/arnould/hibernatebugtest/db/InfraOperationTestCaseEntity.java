package com.arnould.hibernatebugtest.db;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity(name = "InfraOperationTestCase")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class InfraOperationTestCaseEntity {
	@Id
	String id;

	@Enumerated(EnumType.STRING)
	InfraOperationStatus status;

	LocalDateTime createdTimestamp;

	@ManyToOne
	EnvironmentTestCaseEntity environment;
}
