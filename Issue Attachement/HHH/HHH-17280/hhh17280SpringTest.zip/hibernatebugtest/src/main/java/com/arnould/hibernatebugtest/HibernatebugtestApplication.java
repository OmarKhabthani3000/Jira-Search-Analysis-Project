package com.arnould.hibernatebugtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernatebugtestApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibernatebugtestApplication.class, args);
	}

}
