package com.arnould.hibernatebugtest.db;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EnvironmentJpaRepository extends JpaRepository<EnvironmentTestCaseEntity, String> {

}
