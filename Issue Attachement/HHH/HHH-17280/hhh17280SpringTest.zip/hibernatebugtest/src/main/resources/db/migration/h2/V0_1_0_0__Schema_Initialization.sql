create table environment_test_case (name varchar(63) not null, primary key (name));
create table infra_operation_test_case (id varchar(255) not null, created_timestamp timestamp, status varchar(255), environment_name varchar(63), primary key (id));
alter table infra_operation_test_case add constraint FKnwni2dfbeok9h59q7ebmgj01i foreign key (environment_name) references environment_test_case;
