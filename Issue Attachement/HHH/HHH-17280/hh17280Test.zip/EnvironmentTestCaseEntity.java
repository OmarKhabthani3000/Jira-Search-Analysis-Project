package org.hibernate.bugs;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "EnvironmentTestCase")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EnvironmentTestCaseEntity {
	@EmbeddedId
	String key;

}
