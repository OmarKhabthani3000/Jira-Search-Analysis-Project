package org.hibernate.bugs;

public enum InfraOperationStatus {
	ERROR,
	IN_PROGRESS,
	PENDING,
	SKIP,
	SUCCESS
}
