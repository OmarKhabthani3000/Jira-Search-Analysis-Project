CREATE TABLE public.users
(
    id                  serial4     NOT NULL,
    unit                int4        NULL     DEFAULT 1,
    email               text        NOT NULL,
    first_name          text        NOT NULL,
    last_name           text        NOT NULL,
    created             timestamptz NOT NULL DEFAULT now(),
    updated             timestamptz NOT NULL DEFAULT now(),
    active              bool        NOT NULL DEFAULT true,
    archived            bool        NOT NULL DEFAULT false,
    last_login          timestamptz NOT NULL DEFAULT now(),
    subject_common_name text        NULL,
    never_purge         bool        NULL     DEFAULT false,
    hidden              bool        NULL     DEFAULT false,
    us_citizen          bool        NOT NULL DEFAULT false,
    pii_review_date     timestamptz NULL     DEFAULT now(),
    clpm_id             int8        NULL,
    CONSTRAINT email_or_subject_common_name_not_null CHECK (((email IS NOT NULL) OR (subject_common_name IS NOT NULL))),
    CONSTRAINT users_email_key UNIQUE (email),
    CONSTRAINT users_pkey PRIMARY KEY (id),
    CONSTRAINT users_subject_common_name_key UNIQUE (subject_common_name),
    CONSTRAINT fk_clpm_id FOREIGN KEY (clpm_id) REFERENCES public.users (id)
);

CREATE TYPE public.user_role AS ENUM (
    'TRAINER',
    'LEARNER',
    'ANALYST',
    'OPERATIONS',
    'STAFF'
);

CREATE TABLE public.users_roles
(
    user_id   int4             NOT NULL,
    role_name public.user_role NOT NULL,
    CONSTRAINT users_roles_pk PRIMARY KEY (user_id, role_name),
    CONSTRAINT users_roles_user_id_fk FOREIGN KEY (user_id) REFERENCES public.users (id) ON DELETE CASCADE
);

CREATE TABLE public.units
(
    id            serial4     NOT NULL,
    "name"        text        NOT NULL,
    parent_id     int8        NULL,
    created       timestamptz NOT NULL DEFAULT now(),
    updated       timestamptz NOT NULL DEFAULT now(),
    created_by_id int4        NULL     DEFAULT '-1'::integer,
    updated_by_id int4        NULL     DEFAULT '-1'::integer,
    CONSTRAINT units_name_key UNIQUE (name),
    CONSTRAINT units_pkey PRIMARY KEY (id),
    CONSTRAINT fk_units_created_by FOREIGN KEY (created_by_id) REFERENCES public.users (id),
    CONSTRAINT fk_units_updated_by FOREIGN KEY (updated_by_id) REFERENCES public.users (id),
    CONSTRAINT units_parent_fkey FOREIGN KEY (parent_id) REFERENCES public.units (id) ON DELETE SET NULL
);

CREATE TABLE public.courses
(
    id          serial4     NOT NULL,
    "name"      text        NOT NULL,
    description text        NOT NULL,
    "number"    text        NOT NULL,
    author      int4        NOT NULL,
    published   bool        NOT NULL DEFAULT false,
    archived    bool        NOT NULL DEFAULT false,
    created     timestamptz NOT NULL DEFAULT now(),
    updated     timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT courses_pkey PRIMARY KEY (id),
    CONSTRAINT courses_author_fkey FOREIGN KEY (author) REFERENCES public.users (id)
);

CREATE TABLE public.course_enrollment
(
    id      serial4 NOT NULL,
    course  int8    NOT NULL,
    trainee int8    NOT NULL,
    CONSTRAINT course_enrollment_pkey PRIMARY KEY (id),
    CONSTRAINT course_enrollment_course_fkey FOREIGN KEY (course) REFERENCES public.courses (id) ON DELETE CASCADE,
    CONSTRAINT course_enrollment_trainee_fkey FOREIGN KEY (trainee) REFERENCES public.users (id) ON DELETE CASCADE
);

ALTER TABLE public.users
    ADD
        CONSTRAINT users_unit_fkey FOREIGN KEY (unit) REFERENCES public.units (id) ON DELETE SET DEFAULT;

INSERT INTO units (id, created, updated, name, created_by_id, updated_by_id)
VALUES (-4, now(), now(), 'SAIC Huntsville', NULL, NULL);

INSERT INTO users (id, unit, email, first_name, last_name)
VALUES (-1, -4, '', 'System', 'User');

-- ADD SOME USERS
-- Operations @ Unit -1
INSERT INTO users (id, created, email, first_name, last_name, updated, unit, subject_common_name)
VALUES (-8, now(), 'operations@migym.mil', 'Operations', 'User', now(), -4, 'OPERATIONS.MIGYM.1234567890');
INSERT INTO users_roles (user_id, role_name) VALUES(-8, 'OPERATIONS');

-- Trainer @ Unit -1
INSERT INTO users (id, created, email, first_name, last_name, updated, unit, subject_common_name)
VALUES (-2, now(), 'trainer@migym.mil', 'Trainer', 'User', now(), -4, 'TRAINER.MIGYM.1234567890');
INSERT INTO users_roles (user_id, role_name) VALUES(-2, 'TRAINER');

-- Analyst @ Unit -1
INSERT INTO users (id, created, email, first_name, last_name, updated, unit, subject_common_name)
VALUES (-7, now(), 'analyst@migym.mil', 'Analyst', 'User', now(), -4, 'ANALYST.MIGYM.1234567890');
INSERT INTO users_roles (user_id, role_name) VALUES(-7, 'ANALYST');

-- Staff @ Unit -1
INSERT INTO users (id, created, email, first_name, last_name, updated, unit, subject_common_name)
VALUES (-3, now(), 'staff@migym.mil', 'Staff', 'User', now(), -4, 'STAFF.MIGYM.1234567890');
INSERT INTO users_roles (user_id, role_name) VALUES(-3, 'STAFF');

-- Learner @ Unit -1
INSERT INTO users (id, created, email, first_name, last_name, updated, unit, subject_common_name)
VALUES (-4, now(), 'learner@migym.mil', 'Learner-4', 'User', now(), -4, 'LEARNER.MIGYM.1234567890');
INSERT INTO users_roles (user_id, role_name) VALUES(-4, 'LEARNER');

-- Learner @ Unit -2
INSERT INTO users (id, created, email, first_name, last_name, updated, unit, subject_common_name)
VALUES (-5, now(), 'learner-5@migym.mil', 'Learner-5', 'User', now(), -4, 'LEARNER5.MIGYM.1234567890');
INSERT INTO users_roles (user_id, role_name) VALUES(-5, 'LEARNER');

-- Learner @ Unit -3
INSERT INTO users (id, created, email, first_name, last_name, updated, unit, subject_common_name)
VALUES (-6, now(), 'learner-6@migym.mil', 'Learner-6', 'User', now(), -4, 'LEARNER6.MIGYM.1234567890');
INSERT INTO users_roles (user_id, role_name) VALUES(-6, 'LEARNER');

-- Create a Course
insert into courses (id, name, description, number, author, published, archived, created, updated)
values (-1000, 'Astronaut Lvl 1', 'Description', 'APLO101', -1, TRUE, FALSE, now(), now());

-- Add user from Unit -1
insert into course_enrollment (course, trainee)
values (-1000, -2);

-- Add user from Unit -2
insert into course_enrollment (course, trainee)
values (-1000, -5);

-- Add user from Unit -3 (a subunit of -1)
insert into course_enrollment (course, trainee)
values (-1000, -6);