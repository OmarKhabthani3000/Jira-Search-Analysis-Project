package org.hibernate.entities;

public enum RoleName {
    TRAINER,
    LEARNER,
    ANALYST,
    OPERATIONS,
    STAFF
}
