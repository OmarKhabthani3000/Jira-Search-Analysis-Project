package org.hibernate.entities;

import jakarta.persistence.*;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.NotFound;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Set;

import static org.hibernate.annotations.NotFoundAction.EXCEPTION;

@Entity
@DynamicUpdate
@Table(name = "users")
public class User implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "email")
    private String email;

    @Column(name = "subject_common_name")
    private String subjectCommonName;

    @Column(name = "never_purge")
    private boolean neverPurge;

    @Column(name = "hidden")
    private boolean hidden;

    @ManyToOne
    @NotFound(action = EXCEPTION)
    @JoinColumn(name = "unit")
    private Unit unit;

    @Column(columnDefinition = "TIMESTAMP WITH TIME ZONE", insertable = false, updatable = false)
    private OffsetDateTime created;

    @Column(columnDefinition = "TIMESTAMP WITH TIME ZONE", insertable = false, updatable = false)
    private OffsetDateTime updated;

    private boolean active = false;
    private boolean archived = false;

    @Column(name = "last_login", columnDefinition = "TIMESTAMP WITH TIME ZONE", insertable = false)
    private OffsetDateTime lastLogin;

    @Column(name = "us_citizen")
    private boolean usCitizen;

    @Column(name = "pii_review_date", columnDefinition = "TIMESTAMP WITH TIME ZONE")
    private OffsetDateTime piiReviewDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "clpm_id")
    private User clpm;

    @JoinColumn(name = "user_id", referencedColumnName = "id")
    @OneToMany(fetch = FetchType.EAGER, orphanRemoval = true, cascade = CascadeType.ALL)
    private Set<UserRole> roles;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSubjectCommonName() {
        return subjectCommonName;
    }

    public void setSubjectCommonName(String subjectCommonName) {
        this.subjectCommonName = subjectCommonName;
    }

    public boolean isNeverPurge() {
        return neverPurge;
    }

    public void setNeverPurge(boolean neverPurge) {
        this.neverPurge = neverPurge;
    }

    public boolean isHidden() {
        return hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    public Unit getUnit() {
        return unit;
    }

    public void setUnit(Unit unit) {
        this.unit = unit;
    }

    public OffsetDateTime getCreated() {
        return created;
    }

    public void setCreated(OffsetDateTime created) {
        this.created = created;
    }

    public OffsetDateTime getUpdated() {
        return updated;
    }

    public void setUpdated(OffsetDateTime updated) {
        this.updated = updated;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isArchived() {
        return archived;
    }

    public void setArchived(boolean archived) {
        this.archived = archived;
    }

    public OffsetDateTime getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(OffsetDateTime lastLogin) {
        this.lastLogin = lastLogin;
    }

    public boolean isUsCitizen() {
        return usCitizen;
    }

    public void setUsCitizen(boolean usCitizen) {
        this.usCitizen = usCitizen;
    }

    public OffsetDateTime getPiiReviewDate() {
        return piiReviewDate;
    }

    public void setPiiReviewDate(OffsetDateTime piiReviewDate) {
        this.piiReviewDate = piiReviewDate;
    }

    public User getClpm() {
        return clpm;
    }

    public void setClpm(User clpm) {
        this.clpm = clpm;
    }

    public Set<UserRole> getRoles() {
        return roles;
    }

    public void setRoles(Set<UserRole> roles) {
        this.roles = roles;
    }
}
