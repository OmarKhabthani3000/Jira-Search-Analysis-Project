package org.hibernate.entities;

import java.io.Serializable;

public class UserRoleId implements Serializable {

    private User user;
    private RoleName roleName;

    public UserRoleId() {}

    public UserRoleId(User user, RoleName roleName) {
        this.user = user;
        this.roleName = roleName;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public RoleName getRoleName() {
        return roleName;
    }

    public void setRoleName(RoleName roleName) {
        this.roleName = roleName;
    }
}
