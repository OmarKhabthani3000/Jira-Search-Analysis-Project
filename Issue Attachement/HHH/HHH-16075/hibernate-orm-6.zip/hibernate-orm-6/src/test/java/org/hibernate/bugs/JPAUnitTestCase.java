package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import org.hibernate.entities.CourseEnrollment;
import org.hibernate.entities.RoleName;
import org.hibernate.entities.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
//@Testcontainers
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

    @BeforeEach
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@AfterEach
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhTest() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

//        final List<CourseEnrollment> enrollments = entityManager.createQuery("SELECT c FROM CourseEnrollment c").getResultList();
        final List<CourseEnrollment> enrollments = entityManager.createQuery("SELECT c FROM CourseEnrollment c WHERE c.courseId = ?1 AND c.trainee.id IN (?2)", CourseEnrollment.class)
                        .setParameter(1, -1000L)
                        .setParameter(2, List.of(-2L, -5L, -6L))
                        .getResultList();

        assertEquals(3, enrollments.size());

        final User trainer = enrollments.stream().filter(e -> e.getTrainee().getId().equals(-2L)).findFirst().map(CourseEnrollment::getTrainee).orElse(null);

        assertEquals(RoleName.TRAINER, trainer.getRoles().stream().findFirst().orElse(null));

		entityManager.getTransaction().rollback();
		entityManager.close();
	}
}
