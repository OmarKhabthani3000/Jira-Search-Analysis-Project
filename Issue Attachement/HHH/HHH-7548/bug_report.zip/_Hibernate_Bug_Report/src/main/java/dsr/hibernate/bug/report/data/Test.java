package dsr.hibernate.bug.report.data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 */
@Entity
@Table(name="TSP010")
public class Test
{
    private int id;
    private String name = "";
    private char value = ' ';

    /**
     */
    public Test()
    {}
    
    /**
     * @param name
     */
    public Test(String name)
    {
        this(name, ' ');
    }
    
    /**
     * @param name
     * @param value
     */
    public Test(String name, char value)
    {
        this.name = name;
        this.value = value;
    }

    /**
     * @return id
     */
    @Id
    @GeneratedValue
    @Column(name="TSTSID")
    public int getId()
    {
        return id;
    }
    
    /**
     * @param id Festzulegender id
     */
    public void setId(int id)
    {
        this.id = id;
    }

    /**
     * @return name
     */
    @Column(name="TSNAME", nullable=false, length=32)
    public String getName()
    {
        return name;
    }

    /**
     * @param name Festzulegender name
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return value
     */
    @Column(name="TSTVAL", nullable=false)
    public char getValue()
    {
        return value;
    }

    /**
     * @param value Festzulegender value
     */
    public void setValue(char value)
    {
        this.value = value;
    }
}
