package dsr.hibernate.bug.report;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.type.descriptor.WrapperOptions;

import dsr.hibernate.bug.report.data.Test;

import static org.junit.Assert.*;

/**
 */
public class HibernateReportBug
{
    static final String PERSISTENCE_UNIT = "dsr-hibernate-bug";
    
    /**
     */
    @org.junit.Test
    public void test()
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT);

        //...insert
        Object id;
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Test t = new Test("Test");
        em.persist(t);
        id = t.getId();
        em.getTransaction().commit();
        em.close();
        
        
        //...select fails with StringIndexOutOfBoundsException 
        //because of the char property 
        em = emf.createEntityManager();
        em.getTransaction().begin();
        t = em.find(Test.class, id);
        em.getTransaction().commit();
        em.close();
        
        emf.close();
        
        assertEquals("Test", t.getName());
        assertTrue(' ' == t.getValue());
    }
    
    
    @SuppressWarnings("all")
    public <X> Character wrap(X value, WrapperOptions options) {
        if ( value == null ) {
            return null;
        }
        if ( Character.class.isInstance( value ) ) {
            return (Character) value;
        }
        // value is an empty string (""), so that charAt throws
        // a StringIndexOutOfBoundsException
        if ( String.class.isInstance( value ) ) {
            final String str = (String) value;
            return Character.valueOf( str.charAt(0) );
        }
        if ( Number.class.isInstance( value ) ) {
            final Number nbr = (Number) value;
            return Character.valueOf( (char)nbr.shortValue() );
        }
        return null;
        //throw unknownWrap( value.getClass() );
    }
}
