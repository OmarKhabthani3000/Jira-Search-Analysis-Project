package com.forio.hhh;

import javax.sql.DataSource;
import jakarta.persistence.CacheRetrieveMode;
import jakarta.persistence.CacheStoreMode;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.SharedCacheMode;
import jakarta.persistence.ValidationMode;
import jakarta.persistence.spi.PersistenceProvider;
import jakarta.persistence.spi.PersistenceUnitTransactionType;
import org.springframework.beans.BeanUtils;
import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
import org.springframework.orm.jpa.persistenceunit.MutablePersistenceUnitInfo;
import org.springframework.orm.jpa.persistenceunit.PersistenceUnitPostProcessor;
import org.springframework.util.ClassUtils;

public class SpecifiedClassEntityManagerFactoryBean extends AbstractEntityManagerFactoryBean {

  private Class[] persistentClasses;
  private DataSource dataSource;
  private DataSource jtaDataSource;
  private SharedCacheMode sharedCacheMode;
  private CacheStoreMode cacheStoreMode;
  private CacheRetrieveMode cacheRetrieveMode;
  private ValidationMode validationMode;
  private PersistenceUnitPostProcessor[] persistenceUnitPostProcessors;
  private MutablePersistenceUnitInfo persistenceUnitInfo;
  private boolean excludeUnlistedClasses = false;

  public void setPersistentClasses (Class[] persistentClasses) {

    this.persistentClasses = persistentClasses;
  }

  public void setDataSource (DataSource dataSource) {

    this.dataSource = dataSource;
  }

  public void setJtaDataSource (DataSource jtaDataSource) {

    this.jtaDataSource = jtaDataSource;
  }

  public void setSharedCacheMode (SharedCacheMode sharedCacheMode) {

    this.sharedCacheMode = sharedCacheMode;
  }

  public void setCacheStoreMode (CacheStoreMode cacheStoreMode) {

    this.cacheStoreMode = cacheStoreMode;
  }

  public void setCacheRetrieveMode (CacheRetrieveMode cacheRetrieveMode) {

    this.cacheRetrieveMode = cacheRetrieveMode;
  }

  public void setValidationMode (ValidationMode validationMode) {

    this.validationMode = validationMode;
  }

  public void setPersistenceUnitInfo (MutablePersistenceUnitInfo persistenceUnitInfo) {

    this.persistenceUnitInfo = persistenceUnitInfo;
  }

  public void setExcludeUnlistedClasses (boolean excludeUnlistedClasses) {

    this.excludeUnlistedClasses = excludeUnlistedClasses;
  }

  public void setPersistenceUnitPostProcessors (PersistenceUnitPostProcessor... persistenceUnitPostProcessors) {

    this.persistenceUnitPostProcessors = persistenceUnitPostProcessors;
  }

  @Override
  protected EntityManagerFactory createNativeEntityManagerFactory () {

    PersistenceProvider provider;

    if (persistenceUnitInfo == null) {
      persistenceUnitInfo = new MutablePersistenceUnitInfo();
    }

    persistenceUnitInfo.setExcludeUnlistedClasses(excludeUnlistedClasses);
    for (Class<?> clazz : persistentClasses) {
      persistenceUnitInfo.addManagedClassName(clazz.getName());
    }

    if (dataSource != null) {
      persistenceUnitInfo.setNonJtaDataSource(dataSource);
      persistenceUnitInfo.setTransactionType(PersistenceUnitTransactionType.RESOURCE_LOCAL);
    }
    if (jtaDataSource != null) {
      persistenceUnitInfo.setJtaDataSource(dataSource);
      persistenceUnitInfo.setTransactionType(PersistenceUnitTransactionType.JTA);
    }
    if (sharedCacheMode != null) {
      persistenceUnitInfo.setSharedCacheMode(sharedCacheMode);
    }
    if (cacheStoreMode != null) {
      persistenceUnitInfo.getProperties().setProperty("jakarta.persistence.cache.storeMode", cacheStoreMode.name());
    }
    if (cacheRetrieveMode != null) {
      persistenceUnitInfo.getProperties().setProperty("jakarta.persistence.cache.retrieveMode", cacheRetrieveMode.name());
    }
    if (validationMode != null) {
      persistenceUnitInfo.setValidationMode(validationMode);
    }

    if (getJpaVendorAdapter() != null) {
      persistenceUnitInfo.setPersistenceProviderPackageName(getJpaVendorAdapter().getPersistenceProviderRootPackage());
    }

    if (persistenceUnitPostProcessors != null) {
      for (PersistenceUnitPostProcessor persistenceUnitPostProcessor : persistenceUnitPostProcessors) {
        persistenceUnitPostProcessor.postProcessPersistenceUnitInfo(persistenceUnitInfo);
      }
    }

    if ((provider = getPersistenceProvider()) == null) {

      String providerClassName;

      if ((providerClassName = persistenceUnitInfo.getPersistenceProviderClassName()) == null) {
        throw new IllegalArgumentException("No PersistenceProvider specified in EntityManagerFactory configuration, and chosen PersistenceUnitInfo does not specify a provider class name either");
      } else {
        provider = (PersistenceProvider)BeanUtils.instantiateClass(ClassUtils.resolveClassName(providerClassName, getBeanClassLoader()));
      }
    }

    if (persistenceUnitInfo.getPersistenceUnitName() != null) {
      setPersistenceUnitName(persistenceUnitInfo.getPersistenceUnitName());
    }

    if (logger.isInfoEnabled()) {
      logger.info("Building JPA container EntityManagerFactory for persistence unit '" + persistenceUnitInfo.getPersistenceUnitName() + "'");
    }

    return provider.createContainerEntityManagerFactory(persistenceUnitInfo, getJpaPropertyMap());
  }
}
