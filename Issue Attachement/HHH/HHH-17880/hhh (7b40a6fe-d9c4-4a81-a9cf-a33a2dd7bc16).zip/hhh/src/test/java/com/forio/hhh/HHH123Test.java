package com.forio.hhh;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class HHH123Test {

  private ClassPathXmlApplicationContext context;
  private EntityManagerFactory entityManagerFactory;

  @BeforeClass
  public void beforeClass ()
    throws Exception {

    context = new ClassPathXmlApplicationContext("com/forio/hhh/test.xml");
    entityManagerFactory = context.getBean("entityManagerFactory", EntityManagerFactory.class);
  }

  @Test
  public void hhhTest123 () {

    EntityManager entityManager = entityManagerFactory.createEntityManager();
    EntityTransaction transaction = entityManager.getTransaction();

    transaction.begin();

    entityManager.merge(new ParentEntity("purple", new TargetEmbedded("1-2-3")));

    entityManager.flush();
    transaction.commit();
    entityManager.close();
  }
}
