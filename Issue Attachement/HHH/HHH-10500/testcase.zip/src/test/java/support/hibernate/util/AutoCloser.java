package support.hibernate.util;

public final class AutoCloser extends java.util.Stack<Object> {
	private static final long serialVersionUID = 1L;

	public void close() {
		while (!isEmpty()) {
			try {
				close(pop());
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}
	}

	private void close(Object o) throws Exception {
		o.getClass().getMethod("close").invoke(o);
	}
}
