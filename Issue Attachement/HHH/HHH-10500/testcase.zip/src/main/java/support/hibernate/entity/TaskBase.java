package support.hibernate.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "task_base")
public class TaskBase {
        @Id
        @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ID_GENERATOR")
        @SequenceGenerator(name = "ID_GENERATOR", sequenceName = "TASK_SEQ", initialValue= 1, allocationSize = 1)
        private long id;

	private String employee_id;

	public long getId() {
		return id;
	}

	protected void setId(long id) {
		this.id = id;
	}
}
