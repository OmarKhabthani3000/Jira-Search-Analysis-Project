package support.hibernate.entity;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Version;

@Entity
public class Employee {
	@Id
	private String name;

	@OneToMany
        @JoinColumn(name = "employee_id", table = "task_base")
	private Set<Task> tasks;

	public Employee(String name) {
		this();
		setName(name);
	}

	public String getName() {
		return name;
	}

	protected Employee() {
		// this form used by Hibernate
	}

	protected void setName(String name) {
		this.name = name;
	}
}
