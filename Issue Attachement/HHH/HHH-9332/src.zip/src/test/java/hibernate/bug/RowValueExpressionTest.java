package hibernate.bug;

import hibernate.bug.model.Address;
import hibernate.bug.model.Person;
import java.util.Arrays;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class RowValueExpressionTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p1 = new Person();
        Person p2 = new Person();
        
        Address a = new Address("a", "a", "a");
        Address b = new Address("b", "b", "b");
        Address c = new Address("c", "c", "c");
        
        p1.setAddress(a);
        p1.getAlternativeAddresses().add(b);
        p1.getAlternativeAddresses().add(c);
        p2.setAddress(b);
        p2.getAlternativeAddresses().add(c);
        
        em.persist(p1);
        em.persist(p2);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testRveInList() {
        EntityManager em = emf.createEntityManager();
        
        List l = em.createQuery("SELECT p.id FROM Person p WHERE (p.address.street, p.address.city, p.address.postalCode) IN :addresses")
            .setParameter("addresses", Arrays.asList(new Object[]{"b", "b", "b"}, new Object[]{"c", "c", "c"}))
            .getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
    
    @Test
    public void testRveInSubqueryRve() {
        EntityManager em = emf.createEntityManager();
        
        List l = em.createQuery("SELECT p.id FROM Person p WHERE (p.address.street, p.address.city, p.address.postalCode) IN (SELECT address.street, address.city, address.postalCode FROM Person p2 LEFT JOIN p2.alternativeAddresses address WHERE p2.id <> p.id)").getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
    
    @Test
    public void testEmbeddableInList() {
        EntityManager em = emf.createEntityManager();
        
        List l = em.createQuery("SELECT p.id FROM Person p WHERE p.address IN :addresses")
            .setParameter("addresses", Arrays.asList(new Address("b", "b", "b"), new Address("c", "c", "c")))
            .getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
    
    @Test
    public void testEmbeddableInSubquery() {
        EntityManager em = emf.createEntityManager();
        
        List l = em.createQuery("SELECT p.id FROM Person p WHERE p.address IN (SELECT address FROM Person p2 LEFT JOIN p2.alternativeAddresses address WHERE p2.id <> p.id)").getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
}
