package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test(expected = IllegalArgumentException.class)
	public void hhh11397Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		try {
			// create a record
			Event event = new Event();
			event.setMessage("Hello");
			entityManager.persist(event);
			
			Query query = entityManager.createQuery("SELECT e FROM Event e WHERE e.id = :id");
			// as param is an Integer, hibernate 4.x throws IllegalArgumentException (as per spec)
			query.setParameter("id", 1);
		} finally {
			entityManager.getTransaction().commit();
			entityManager.close();
		}
	}
}
