package brj.tests;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.junit.Test;

import brj.entities.EmbeddableBook;
import brj.entities.Person;

public class JunitTests {

    @Test
    public void test1() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("TEST");
        EntityManager em = emf.createEntityManager();
    
        Person person = new Person();
        person.setName("Person 1");
        
        EmbeddableBook book1 = new EmbeddableBook();
        book1.setName("Book 1");
        book1.setAuthor("Author Book 1");

        EmbeddableBook book2 = new EmbeddableBook();
        book2.setName("Book 2");
        book2.setAuthor("Author Book 2");
        
        person.setBook(book1);
        person.getEmbeddableBooks().add(book1);
        person.getEmbeddableBooks().add(book2);
        
        person.getNicknames().add("Nick 1");
        person.getNicknames().add("Nick 2");
        
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        em.persist(person);
        tx.commit();
        em.close();
    
        em = emf.createEntityManager();
        TypedQuery<Person> q = em.createQuery("select p from Person p where p.book = :book", Person.class);
        q.setParameter("book", book1);
        q.getResultList();

        q = em.createQuery("select p from Person p where :nick member of p.nicknames", Person.class);
        q.setParameter("nick", "Nick 1");
        q.getResultList();

        em.close();
    }

    @Test
    public void test2() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("TEST");
        EntityManager em = emf.createEntityManager();
    
        Person person = new Person();
        person.setName("Person 1");
        
        EmbeddableBook book1 = new EmbeddableBook();
        book1.setName("Book 1");
        book1.setAuthor("Author Book 1");

        EmbeddableBook book2 = new EmbeddableBook();
        book2.setName("Book 2");
        book2.setAuthor("Author Book 2");
        
        person.setBook(book1);
        person.getEmbeddableBooks().add(book1);
        person.getEmbeddableBooks().add(book2);
  
        person.getNicknames().add("Nick 1");
        person.getNicknames().add("Nick 2");
        
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        em.persist(person);
        tx.commit();
        em.close();
    
        em = emf.createEntityManager();
        TypedQuery<Person> q = em.createQuery("select p from Person p where :book member of p.embeddableBooks", Person.class);
        q.setParameter("book", book1);
        q.getResultList();
        
        em.close();
    }

}
