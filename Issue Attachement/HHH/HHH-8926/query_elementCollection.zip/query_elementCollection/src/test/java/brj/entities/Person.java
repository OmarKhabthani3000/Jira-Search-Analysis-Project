package brj.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "Q_PERSON")
public class Person {

	@Id
	@GeneratedValue
	private long id;
	
	@Version
	private long version;

	private String name;

	@ElementCollection
	@CollectionTable(name = "Q_PERSON_NICKNAMES")
	private List<String> nicknames = new ArrayList<String>();

	@ElementCollection
	@CollectionTable(name = "Q_PERSON_BOOKS")
	private List<EmbeddableBook> embeddableBooks = new ArrayList<EmbeddableBook>();

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "name", column = @Column(name = "BOOK_NAME")),
			@AttributeOverride(name = "author", column = @Column(name = "BOOK_AUTHOR")) })
	private EmbeddableBook book;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getVersion() {
		return version;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<EmbeddableBook> getEmbeddableBooks() {
		return embeddableBooks;
	}

	public void setEmbeddableBooks(List<EmbeddableBook> embeddableBooks) {
		this.embeddableBooks = embeddableBooks;
	}

	public EmbeddableBook getBook() {
		return book;
	}
	
	public void setBook(EmbeddableBook book) {
		this.book = book;
	}

	public List<String> getNicknames() {
		return nicknames;
	}
	
	public void setNicknames(List<String> nicknames) {
		this.nicknames = nicknames;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		if (id != other.id)
			return false;
		return true;
	}


}
