package test.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import test.model.TestObject;

public class TestObjektDao {

	private SessionFactory sessionFactory;

	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	// Logic

	@SuppressWarnings("unchecked")
	public List<TestObject> getAll() {
		Criteria c = getCurrentSession().createCriteria(TestObject.class);

		return c.list();
	}

	public void save(TestObject obj) {
		getCurrentSession().saveOrUpdate(obj);
	}

	public void delete(TestObject obj) {
		getCurrentSession().delete(obj);
	}

}
