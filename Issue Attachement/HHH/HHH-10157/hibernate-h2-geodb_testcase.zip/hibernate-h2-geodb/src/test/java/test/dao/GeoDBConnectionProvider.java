package test.dao;

import geodb.GeoDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import org.h2.Driver;
import org.h2.jdbcx.JdbcConnectionPool;
import org.hibernate.cfg.Environment;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
import org.hibernate.service.spi.Configurable;
import org.hibernate.service.spi.Stoppable;

/**
 * GeoDBConnectionProvider initialisiert eine GeoDB H2 Datenbank vor ihrem Gebrauch. Wenn dieser Provider genutzt werden
 * soll muss in der Hibernate Konfiguration die Eigenschaft 'hibernate.connection.provider_class' mit dem Namen dieser
 * Klasse belegt werden.
 * 
 * @author Lamann (2013.03.12)
 */
public class GeoDBConnectionProvider implements ConnectionProvider, Configurable, Stoppable {

	private static final long serialVersionUID = -5877516464792509106L;

	/**
	 * Der einfache ConnectionPool der H2 Datenbank
	 */
	private static JdbcConnectionPool connectionPool;

	/**
	 * Diese Connection bleibt die ganze Lebensdauer �ber offen damit die in Memmory Datenbank erhalten bleibt.
	 */
	private static Connection liveConnection;

	public GeoDBConnectionProvider() {
	}

	@Override
	public boolean isUnwrappableAs(@SuppressWarnings("rawtypes") Class unwrapType) {
		return false;
	}

	@Override
	public <T> T unwrap(Class<T> unwrapType) {
		return null;
	}

	@Override
	public Connection getConnection() throws SQLException {
		System.out.println(getClass().getSimpleName() + ".getConnection()");

		return connectionPool.getConnection();
	}

	@Override
	public void closeConnection(Connection conn) throws SQLException {

		System.out.println(getClass().getSimpleName() + ".closeConnection(...)");

		conn.close();
	}

	@Override
	public boolean supportsAggressiveRelease() {
		return false;
	}

	@Override
	public void stop() {

		System.out.println(getClass().getSimpleName() + ".stop()");

		// alle Resourcen wieder frei geben
		connectionPool.dispose();

		try {
			// Die letzte Connection schliessen
			liveConnection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		connectionPool = null;
		liveConnection = null;
	}

	@Override
	public void configure(@SuppressWarnings("rawtypes") Map configurationValues) {

		if (connectionPool != null) {
			System.out.println("Fehlerhafter Aufruf, connectionPool ist schon vorhanden!");
			new Exception().printStackTrace();
		}

		String url = (String) configurationValues.get(Environment.URL);
		String user = (String) configurationValues.get(Environment.USER);
		String pw = (String) configurationValues.get(Environment.PASS);

		System.out.println(getClass().getSimpleName() + " user=" + user + ", url=" + url);

		try {
			Class.forName(Driver.class.getName());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			liveConnection = DriverManager.getConnection(url, user, pw);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			// GeoDB initialisieren
			GeoDB.InitGeoDB(liveConnection);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// Schema user_mde anlegen
		try (Statement stmt = liveConnection.createStatement();) {
			stmt.execute("CREATE SCHEMA USER_MDE");
		} catch (SQLException e) {
			e.printStackTrace();
		}

		System.out.println("DB: " + url + ", user=" + user);
		// H2 ConnectionPool initialisieren
		connectionPool = JdbcConnectionPool.create(url, user, pw);
	}
}