package test.dao;

import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.BootstrapServiceRegistry;
import org.hibernate.boot.registry.BootstrapServiceRegistryBuilder;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.boot.spi.MetadataImplementor;
import org.hibernate.cfg.Environment;

public class DBConfiguration {

	static {
		// Hier wird h2.bindAddress auf localhost gesetzt damit beim Aufruf der
		// Methode openDatabaseInspector() der Klasse HibernateTest im Browser
		// die richtige URL aufgerufen wird. Dieses funktioniert nur weil diese
		// Klasse vor den Klassen der H2 Datenbank geladen wird. Siehe Klasse
		// org.h2.constant.SysProperties.
		System.setProperty("h2.bindAddress", "localhost");
	}

	public final static String URL = "jdbc:h2:mem:geoDB";
	public final static String USER = "sa";
	public final static String PASSWORD = "sa";

	private String conf;
	public static final String CONF_HSQL = "GEOH2SQL";

	// Save to be able to close later
	private StandardServiceRegistry serviceRegistry;

	public DBConfiguration(String conf) {
		super();
		this.conf = conf;
	}

	public MetadataImplementor getConfiguration() {

		final java.net.URL configUrl = getClass().getClassLoader().getResource("hibernate.cfg.xml");
		final BootstrapServiceRegistry bsr = new BootstrapServiceRegistryBuilder().build();
		final StandardServiceRegistryBuilder ssrBuilder = new StandardServiceRegistryBuilder(bsr);

		ssrBuilder.configure(configUrl);
		if (conf.equalsIgnoreCase(CONF_HSQL)) {
			ssrBuilder.applySetting(Environment.DIALECT,
					org.hibernate.spatial.dialect.h2geodb.GeoDBDialect.class.getName());
			ssrBuilder.applySetting(Environment.URL, URL);
			ssrBuilder.applySetting(Environment.USER, USER);
			ssrBuilder.applySetting(Environment.PASS, PASSWORD);
			ssrBuilder.applySetting(Environment.CONNECTION_PROVIDER, GeoDBConnectionProvider.class.getName());
			ssrBuilder.applySetting(Environment.SHOW_SQL, "false");
			ssrBuilder.applySetting(Environment.FORMAT_SQL, "false");
			ssrBuilder.applySetting(Environment.HBM2DDL_AUTO, "create");
			ssrBuilder.applySetting(Environment.CURRENT_SESSION_CONTEXT_CLASS, "thread");
		}

		serviceRegistry = ssrBuilder.build();

		final MetadataSources metadataSources = new MetadataSources(serviceRegistry);
		metadataSources.addURL(configUrl);
		final MetadataImplementor mi = (MetadataImplementor) metadataSources.buildMetadata();

		System.out.println("DB: " + conf);

		return mi;
	}

	public void shutdown() {
		StandardServiceRegistryBuilder.destroy(serviceRegistry);
	}

}
