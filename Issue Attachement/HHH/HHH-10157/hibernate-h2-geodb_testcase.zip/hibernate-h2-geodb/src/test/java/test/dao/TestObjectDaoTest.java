package test.dao;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import test.model.TestObject;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.GeometryFactory;

public class TestObjectDaoTest extends HibernateTest {

	private TestObjektDao dao;

	@Before
	public void init() {
		dao = new TestObjektDao();
		dao.setSessionFactory(getSessionFactory());
	}

	@Test
	public void test_save() {
		TestObject to = new TestObject();
		to.setName("t1");
		to.setArea(createGeom());

		beginTransaction();
		dao.save(to);
		commit();
	}

	@Test
	public void test_load() {
		TestObject to = new TestObject();
		to.setName("t1");
		to.setArea(createGeom());

		beginTransaction();
		dao.save(to);
		commit();

		// openDatabaseInspector();

		beginTransaction();
		List<TestObject> objs = dao.getAll();
		commit();

		assertNotNull(objs);
	}

	private Geometry createGeom() {

		GeometryFactory gf = new GeometryFactory(null, 3426);

		return gf.createPoint((Coordinate) null);

	}

}
