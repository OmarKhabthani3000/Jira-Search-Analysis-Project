package test.dao;

import java.sql.SQLException;

import org.h2.tools.Console;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.spi.MetadataImplementor;
import org.junit.After;
import org.junit.Before;

public abstract class HibernateTest {

	protected SessionFactory sessionFactory;

	protected Transaction tx;
	protected String dBConf = DBConfiguration.CONF_HSQL;

	private DBConfiguration config;

	public HibernateTest() {
		super();
	}

	public SessionFactory createSessionFactory() {
		config = new DBConfiguration(dBConf);
		MetadataImplementor metadata = config.getConfiguration();
		return metadata.buildSessionFactory();
	}

	@Before
	public void startup() {
		sessionFactory = createSessionFactory();
		System.out.println("init finished --------------------------------------------------");
	}

	@After
	public void tearDown() {
		try {
			sessionFactory.getCurrentSession().close();
		} catch (NullPointerException e) {
		}
		try {
			sessionFactory.close();
		} catch (NullPointerException e) {
		}
		tx = null;
		sessionFactory = null;
		after();

		config.shutdown();
		System.out.println("tearDown ####################################################");
	}

	public void after() {
		// do nothing
	}

	// =========================================================================
	//
	// =========================================================================

	protected void beginTransaction() {
		tx = sessionFactory.getCurrentSession().beginTransaction();
	}

	protected void commit() throws HibernateException {
		tx.commit();
	}

	protected void rollback() {
		tx.rollback();
	}

	protected void openDatabaseInspector() {
		// org.hsqldb.util.DatabaseManagerSwing.main(new String[] { "--url",
		// "jdbc:hsqldb:mem:TempDB", "--noexit" });

		System.out.println("openDatabaseInspector");

		try {
			Console.main(new String[] { "-url", DBConfiguration.URL, "-user", DBConfiguration.USER, "-password",
					DBConfiguration.PASSWORD });
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public Session getCurrentSession() {
		return getSessionFactory().getCurrentSession();
	}

}