create table TEST_ENTITY (
  id integer,
  attribute1 char(16) for bit data
);