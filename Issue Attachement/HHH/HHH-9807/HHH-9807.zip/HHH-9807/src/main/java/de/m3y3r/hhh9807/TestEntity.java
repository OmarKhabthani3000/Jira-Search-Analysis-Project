package de.m3y3r.hhh9807;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Formula;


@Entity
@Table(name="TEST_ENTITY")
public class TestEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Formula(value="CHAR")
	private String id;

	private byte[] attribute1;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public byte[] getAttribute1() {
		return attribute1;
	}

	public void setAttribute1(byte[] attribute1) {
		this.attribute1 = attribute1;
	}

}
