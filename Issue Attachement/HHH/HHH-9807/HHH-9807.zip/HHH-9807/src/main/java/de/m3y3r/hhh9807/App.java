package de.m3y3r.hhh9807;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class App implements Runnable
{
	public static void main(String[] args )
	{
		new App().run();
	}

	@Override
	public void run() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("unit");
		try {
			EntityManager em = emf.createEntityManager();
			try {
				TestEntity entity = em.find(TestEntity.class, "1");
				System.out.println(entity.getAttribute1());
			} finally {
				em.close();
			}
		} finally {
			emf.close();
		}
	}
}
