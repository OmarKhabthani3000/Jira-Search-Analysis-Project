package test.orderproblem2;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import test.orderproblem2.MarketBid;
import test.orderproblem2.MarketBidChange;
import test.orderproblem2.MarketBidGroup;
import test.orderproblem2.MarketResult;

public class OrderProblemTest {
	private SessionFactory sessionFactory;

	@Before
	public void setup() {
		final Configuration configure = new Configuration().configure();
		sessionFactory = configure
				.buildSessionFactory(new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build());
	}

	@After
	public void teardown() {
		sessionFactory.close();
	}

	@Test
	public void testOrder() {
		try (Session session = sessionFactory.openSession()) {
			session.setHibernateFlushMode(FlushMode.COMMIT);
			session.getTransaction().begin();

			// create new Group
			final MarketBidGroup group = new MarketBidGroup();
			
			// add new Bid to Group
			final MarketBid bid = new MarketBid();
			bid.setGroup(group);

			// add new Result to Bid
			final MarketResult result = new MarketResult(); 
			result.setMarketBid(bid);
			
			// add new Change to Bid
			final MarketBidChange change = new MarketBidChange();
			change.setMarketBid(bid);
			bid.addChange(change);
			
			session.save(bid);
			session.save(result);
			
			session.getTransaction().commit();
		}
	}
}
