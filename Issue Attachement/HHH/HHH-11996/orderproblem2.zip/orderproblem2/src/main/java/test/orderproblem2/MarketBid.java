package test.orderproblem2;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.TableGenerator;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cascade;

@Entity
@Access(AccessType.FIELD)
public class MarketBid {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "MarketBid")
	@TableGenerator(name = "MarketBid", pkColumnValue = "MarketBid", allocationSize = 10000)
	private Long id;

	@OneToMany(mappedBy = "marketBid", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<MarketBidChange> changes = new ArrayList<>();

	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE })
	@ManyToOne(optional = false)
	private MarketBidGroup group;

	public Long getId() {
		return id;
	}

	public void setGroup(MarketBidGroup group) {
		this.group = group;
	}
	
	public void addChange(MarketBidChange change) {
		 changes.add(change);
	}
}
