package test.orderproblem2;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.TableGenerator;

@Entity
@Access(AccessType.FIELD)
public class MarketBidChange {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "MarketBidChange")
	@TableGenerator(name = "MarketBidChange", pkColumnValue = "MarketBidChange", allocationSize = 10000)
	private Long id;

	@ManyToOne
	private MarketBid marketBid;

	public Long getId() {
		return id;
	}

	public void setMarketBid(MarketBid marketBid) {
		this.marketBid = marketBid;
	}
}
