/*
 * This class handles all retrieval and update methods on the EnterpriseObject and
 * the EnterpriseRelationship objects. It is a stateless EJB with no state of its 
 * own. 
 */
package eds.component;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * 
 * @author LeeKiatHaw
 */
@Stateless
public class GenericObjectService {

    /**
     * Inject an instance of EntityManager based on config in persistence.xml.
     * The persistence.xml must be in the project and includes this EDS package
     * as a JAR file.
     */
    @PersistenceContext(name = "HIBERNATE")
    private EntityManager em;
    
}
