/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redirect;

import java.io.IOException;
import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpSession;

/**
 *
 * @author LeeKiatHaw
 */
@RequestScoped
@Named("RedirectForm")
/*@URLBeanName("RedirectForm")
@URLMappings(mappings={
    @URLMapping(id="home", pattern="/*.xhtml",viewId="/index.xhtml"),
    @URLMapping(id="redirect", pattern="/redirect/",viewId="/redirect_no_sessionscoped.xhtml")
})*/
public class RedirectForm {
    
    @Inject private RedirectSessionScopedBean sbean;
    
    @PostConstruct
    public void init(){
        System.out.println("SessionId from init is "+sbean.getSessionId());
        System.out.println("SessionId from init is "+sbean.getSessionId());
    }
    
    public void redirect() throws IOException{
        FacesContext fc = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) fc.getExternalContext().getSession(true);
        
        //Before invalidating, check SessionId
        this.sbean.setSessionId(session.getId());
        System.out.println("SessionId before invalidate is "+sbean.getSessionId());
        
        //Invalidate session
        //session.invalidate();
        session = (HttpSession) fc.getExternalContext().getSession(true);
        this.sbean.setSessionId(session.getId());
        System.out.println("SessionId after invalidate is "+sbean.getSessionId());
        
        fc.getExternalContext().redirect("/SegMailReplica/redirect_no_sessionscoped.xhtml");
    }
    
    /*@URLActions(actions={
        @URLAction(mappingId="home", onPostback=true),
        @URLAction(mappingId="redirect", onPostback=true)
    })*/
    public void bootup(){
        System.out.println("SessionId from bootup is "+sbean.getSessionId());
    }

    public RedirectSessionScopedBean getSbean() {
        return sbean;
    }

    public void setSbean(RedirectSessionScopedBean sbean) {
        this.sbean = sbean;
    }

    
    
}
