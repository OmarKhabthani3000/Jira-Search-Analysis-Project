
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Expression;

public final class Main {

    private Main() {
    }

    public static void main(String[] args) throws Exception {

        // Configure log4j
        Level logLevel = Level.INFO;
        ConsoleAppender consoleAppender = new ConsoleAppender(
          new PatternLayout(PatternLayout.TTCC_CONVERSION_PATTERN),
          ConsoleAppender.SYSTEM_ERR);
        consoleAppender.setThreshold(logLevel);
        BasicConfigurator.configure(consoleAppender);
        final Logger log = Logger.getLogger(Main.class);

        // Configure Hibernate
        SessionFactory sessionFactory = new Configuration()
          .configure("hibernate.cfg.xml").buildSessionFactory();

        // Execute query
        Session session = sessionFactory.openSession();
        final String patientMRN = "12345678";
        Criteria criteria = session.createCriteria(Patient.class);
        criteria.add(Expression.eq("medicalRecordNumber", patientMRN));
        Patient p = (Patient)criteria.uniqueResult();
        log.info("patient=" + p + " patient.assignedRoom=" + p.getAssignedRoom());
        log.info("patient.id=" + p.getId());
        if (p.getAssignedRoom() != null) {
            log.info("patient.assignedRoom.id=" + p.getAssignedRoom().getId());
            if (p.getAssignedRoom().getId() == 0)
                log.error("WTF? ID OF ROOM IS ZERO!");
            log.info("patient.assignedRoom.id=" + session.getIdentifier(p.getAssignedRoom()));
        }
    }
}

