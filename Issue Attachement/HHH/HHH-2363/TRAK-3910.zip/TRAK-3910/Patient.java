
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Represents a patient.
 *
 * @hibernate.class
 */
public class Patient extends AbstractNamed {

    private String medicalRecordNumber;
    private Room assignedRoom;

    public Patient() {
    }

    public Patient(String name) {
        super(name);
    }

    /**
     * @hibernate.property
     *  length="64"
     *  not-null="true"
     */
    public String getMedicalRecordNumber() {
        return medicalRecordNumber;
    }
    public void setMedicalRecordNumber(String medicalRecordNumber) {
        this.medicalRecordNumber = medicalRecordNumber;
    }

    /**
     * @hibernate.many-to-one
     *  cascade="none"
     *  unique="true"
     */
    public Room getAssignedRoom() {
        return assignedRoom;
    }
    public void setAssignedRoom(Room assignedRoom) {
        this.assignedRoom = assignedRoom;
    }
    public void deassignRoom() {
        setAssignedRoom(null);
    }
}

