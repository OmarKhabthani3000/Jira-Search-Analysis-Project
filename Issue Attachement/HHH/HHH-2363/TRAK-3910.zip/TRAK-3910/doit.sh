#!/bin/sh

# DEFINE hibernate-3.2.0 DIRECTORY HERE
HIBERNATE_DIR="/home/archie/svn/eng/projects/open-source/hibernate/3.2.0/hibernate-3.2"

# DEFINE mysql-connector-java LOCATION HERE
MYSQL_CONNECTOR_JAVA="/usr/share/java/mysql-connector-java.jar"

# DEFINE LOCAL DATABASE USERNAME AND PASSWORD HERE
DATABASE_USERNAME="root"
DATABASE_PASSWORD=""

# END OF REQUIRED DEFINITIONS .. NOW JUST RUN THIS SCRIPT

# Bail on error
set -e

# Generate classpath
echo Generating list of Hibernate JARs...
CLASSPATH=`find "${HIBERNATE_DIR}" -name '*.jar' | xargs printf '%s:'`

# Set up database
echo Setting up MySQL database...
if [ "${DATABASE_PASSWORD}" != "" ]; then
    EXTRA="--password=${DATABASE_PASSWORD}"
fi
cat bugdb.sql | mysql -u "${DATABASE_USERNAME}" ${EXTRA} bugdb

# Compile java
echo Compiling Java code...
javac -classpath "${CLASSPATH}" *.java

# Create hibernate config
echo Creating hibernate config...
sed -e 's/@DATABASE_USERNAME@/'"${DATABASE_USERNAME}"'/g' \
    -e 's/@DATABASE_PASSWORD@/'"${DATABASE_PASSWORD}"'/g' \
    < hibernate.cfg.xml.in > hibernate.cfg.xml

# Run test
echo Executing Java code...
java -classpath .:"${CLASSPATH}":"${MYSQL_CONNECTOR_JAVA}" Main

