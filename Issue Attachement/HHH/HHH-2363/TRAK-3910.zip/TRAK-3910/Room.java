
/**
 * Represents a room (or portion of a room) that may be assigned to a patient.
 *
 * @hibernate.class
 */
public class Room extends AbstractNamed {

    public Room() {
    }

    public Room(String name) {
        setName(name);
    }
}

