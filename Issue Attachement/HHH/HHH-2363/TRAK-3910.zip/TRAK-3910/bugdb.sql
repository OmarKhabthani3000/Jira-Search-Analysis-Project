
DROP DATABASE IF EXISTS `bugdb`;
DROP DATABASE IF EXISTS `bugdb`;
CREATE DATABASE `bugdb`;
USE bugdb;

CREATE TABLE `Patient` (
  `id` bigint(20) NOT NULL auto_increment,
  `assignedRoom` bigint(20) default NULL,
  `medicalRecordNumber` varchar(64) default NULL,
  `name` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `assignedRoom` (`assignedRoom`),
  UNIQUE KEY `medicalRecordNumber` (`medicalRecordNumber`),
  KEY `FK340C82E592A36BC9` (`assignedRoom`)
);

CREATE TABLE `Room` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
);

ALTER TABLE `Patient`
  ADD CONSTRAINT `FK340C82E592A36BC9` FOREIGN KEY (`assignedRoom`) REFERENCES `Room` (`id`);

INSERT INTO `Room` ( `id`, `name` ) VALUES ( 1, 'Room 101' );
INSERT INTO `Patient` ( `name`, `medicalRecordNumber`, `assignedRoom` ) VALUES ( 'Fred Example', '12345678', 1 );

