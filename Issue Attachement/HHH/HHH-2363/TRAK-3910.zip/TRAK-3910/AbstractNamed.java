
import java.io.Serializable;

public abstract class AbstractNamed implements Serializable {

    private long id;
    private String name;

    protected AbstractNamed() {
    }

    protected AbstractNamed(String name) {
        this.name = name;
    }

    /**
     * @see com.awarix.trak.server.model.Identifiable#getId()
     *
     * @hibernate.id
     *  unsaved-value="0"
     *  generator-class="native"
     */
    public final long getId() {
        return id;
    }
    public final void setId(long id) {
        this.id = id;
    }

    /**
     * @hibernate.property
     *  length="64"
     *  not-null="true"
     */
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String toString() {
        String cname = getClass().getName();
        cname = cname.substring(cname.lastIndexOf('.') + 1);
        return cname + "[" + getName() + "]";
    }
}

