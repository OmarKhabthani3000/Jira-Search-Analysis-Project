package dao;

import junit.framework.TestCase;
import model.Order;
import model.Product;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public abstract class OrderDaoTest extends TestCase
{
	private Product product;

	public OrderDaoTest()
	{
		super();
	}
	
	public abstract SessionFactory getSessionFactory();

	@Override
	protected void setUp() throws Exception
	{
		Session session = getSessionFactory().openSession();
		
		product = new Product();
		product.setName("Product 1");
		
		session.beginTransaction();
		session.save(product);
		session.getTransaction().commit();
		
		session.close();
	}

	public void testCreateProject()
	{
		Order order = new Order();
		order.setName("Order 1");
		order.addLineItem(product, 2);

		Session session = getSessionFactory().openSession();
		session.beginTransaction();
		session.save(order);
		session.getTransaction().commit();
		session.close();
		
		Long orderId = order.getId();
		
		session = getSessionFactory().openSession();
		order = (Order) session.get(Order.class, orderId);
		assertEquals(1, order.getLineItems().size());
		session.close();
	}

}