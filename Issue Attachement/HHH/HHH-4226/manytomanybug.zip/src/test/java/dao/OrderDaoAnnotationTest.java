package dao;

import model.Order;
import model.OrderLine;
import model.Product;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class OrderDaoAnnotationTest extends OrderDaoTest
{
	private static final SessionFactory sessionFactory;

	static
	{
		try
		{
			// Create the SessionFactory from hibernate.cfg.xml
			sessionFactory = new AnnotationConfiguration()
				.addAnnotatedClass(Order.class)
				.addAnnotatedClass(Product.class)
				.addAnnotatedClass(OrderLine.class)
				.configure()
				.buildSessionFactory();
		} catch (Throwable ex)
		{
			// Make sure you log the exception, as it might be swallowed
			System.err.println("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	@Override
	public SessionFactory getSessionFactory()
	{
		return sessionFactory;
	}
}
