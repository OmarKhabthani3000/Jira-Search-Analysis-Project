package dao;

import java.io.File;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class OrderDaoHbmTest extends OrderDaoTest
{
	private static final SessionFactory sessionFactory;

	static
	{
		try
		{
			// Create the SessionFactory from hibernate.cfg.xml
			sessionFactory = new Configuration()
				.configure()
				.addFile(new File(OrderDaoHbmTest.class.getResource("/model/model.hbm.xml").toURI()))
				.buildSessionFactory();
		} catch (Throwable ex)
		{
			// Make sure you log the exception, as it might be swallowed
			System.err.println("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	@Override
	public SessionFactory getSessionFactory()
	{
		return sessionFactory;
	}

}
