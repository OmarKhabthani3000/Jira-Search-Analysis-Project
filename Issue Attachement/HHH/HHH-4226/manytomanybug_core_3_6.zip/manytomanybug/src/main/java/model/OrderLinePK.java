package model;


public class OrderLinePK
{
	public Order order;
	public Product product;
}
