create table lazy (
    id INTEGER UNSIGNED NOT NULL,
    string VARCHAR(128),
    PRIMARY KEY (id)
);

create table lazyChild (
  parent_id INTEGER UNSIGNED NOT NULL,
  createdAt DATETIME NOT NULL,
  PRIMARY KEY (parent_id, createdAt)
);

INSERT INTO lazy VALUES (1, '123');
INSERT INTO lazyChild VALUES (1, '2022-11-01 00:01');
INSERT INTO lazyChild VALUES (1, '2022-11-01 00:02');
