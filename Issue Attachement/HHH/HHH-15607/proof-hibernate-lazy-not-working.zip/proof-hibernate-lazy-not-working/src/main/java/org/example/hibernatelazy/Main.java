package org.example.hibernatelazy;

import org.example.hibernatelazy.entities.LazyChild;
import org.example.hibernatelazy.entities.LazyEntity;
import org.hibernate.Hibernate;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.jpa.SpecHints;

public class Main {

    public static void main(String[] args) {
        var standardRegistry = new StandardServiceRegistryBuilder().build();
        var sources = new MetadataSources(standardRegistry);
        sources.addAnnotatedClass(LazyEntity.class);
        sources.addAnnotatedClass(LazyChild.class);

        var configuration = new Configuration(sources);
        configuration.setProperty("hibernate.connection.url", "jdbc:mariadb://localhost/test");
        configuration.setProperty("hibernate.connection.username", "root");
        configuration.setProperty("hibernate.connection.password", "password");

        try(var sessionFactory = configuration.buildSessionFactory()) {
            try (var session = sessionFactory.openSession()) {
                var result = session.createQuery("SELECT e FROM LazyEntity e WHERE e.id = :id", LazyEntity.class)
                        .setParameter("id", 1L)
                        .setHint(SpecHints.HINT_SPEC_FETCH_GRAPH, sessionFactory.createEntityManager().getEntityGraph("LazyEntity.stringAndChildren"))
                        .getSingleResult();

                var string = Hibernate.isPropertyInitialized(result, "string");
                var children = Hibernate.isInitialized(result.getChildren());
                System.out.println("LazyEntity.stringAndChildren");
                System.out.println("\t string: " + string);
                System.out.println("\t children: " + children);
            }

            try (var session = sessionFactory.openSession()) {
                var result = session.createQuery("SELECT e FROM LazyEntity e WHERE e.id = :id", LazyEntity.class)
                        .setParameter("id", 1L)
                        .setHint(SpecHints.HINT_SPEC_FETCH_GRAPH, sessionFactory.createEntityManager().getEntityGraph("LazyEntity.stringOnly"))
                        .getSingleResult();

                var string = Hibernate.isPropertyInitialized(result, "string");
                var children = Hibernate.isInitialized(result.getChildren());
                System.out.println("LazyEntity.stringOnly");
                System.out.println("\t string: " + string);
                System.out.println("\t children: " + children);
            }

            try (var session = sessionFactory.openSession()) {
                var result = session.createQuery("SELECT e FROM LazyEntity e WHERE e.id = :id", LazyEntity.class)
                        .setParameter("id", 1L)
                        .setHint(SpecHints.HINT_SPEC_FETCH_GRAPH, sessionFactory.createEntityManager().getEntityGraph("LazyEntity.childrenOnly"))
                        .getSingleResult();

                var string = Hibernate.isPropertyInitialized(result, "string");
                var children = Hibernate.isInitialized(result.getChildren());
                System.out.println("LazyEntity.childrenOnly");
                System.out.println("\t string: " + string);
                System.out.println("\t children: " + children);
            }
        }
    }
}
