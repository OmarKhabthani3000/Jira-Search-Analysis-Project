package org.example.hibernatelazy.entities;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Table(name = "lazyChild")
@IdClass(LazyChild.PK.class)
public class LazyChild {

    @Id
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "parent_id")
    private LazyEntity parent;

    @Id @Column(name = "createdAt")
    private LocalDateTime createdAt;

    public LazyEntity getParent() {
        return parent;
    }

    public void setParent(LazyEntity parent) {
        this.parent = parent;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public static class PK implements Serializable {
        private Long parent;
        private LocalDateTime createdAt;

        public Long getParent() {
            return parent;
        }

        public void setParent(Long parent) {
            this.parent = parent;
        }

        public LocalDateTime getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(LocalDateTime createdAt) {
            this.createdAt = createdAt;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            PK pk = (PK) o;
            return Objects.equals(parent, pk.parent) && Objects.equals(createdAt, pk.createdAt);
        }

        @Override
        public int hashCode() {
            return Objects.hash(parent, createdAt);
        }
    }
}
