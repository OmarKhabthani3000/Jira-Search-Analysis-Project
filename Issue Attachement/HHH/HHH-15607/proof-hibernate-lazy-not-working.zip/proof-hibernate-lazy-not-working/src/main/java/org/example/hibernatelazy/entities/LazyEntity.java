package org.example.hibernatelazy.entities;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "lazy")
@NamedEntityGraph(
    name = "LazyEntity.stringOnly",
    attributeNodes = {
        @NamedAttributeNode("string"),
    }
)
@NamedEntityGraph(
    name = "LazyEntity.childrenOnly",
    attributeNodes = {
        @NamedAttributeNode("children"),
    }
)
@NamedEntityGraph(
    name = "LazyEntity.stringAndChildren",
    attributeNodes = {
        @NamedAttributeNode("string"),
        @NamedAttributeNode("children"),
    }
)
public class LazyEntity {

    @Id
    private Long id;

    @Basic(fetch = FetchType.LAZY)
    private String string;

    @OrderBy("createdAt DESC")
    @OneToMany(mappedBy = "parent")
    private List<LazyChild> children;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getString() {
        return string;
    }

    public void setString(String string) {
        this.string = string;
    }

    public List<LazyChild> getChildren() {
        return children;
    }

    public void setChildren(List<LazyChild> children) {
        this.children = children;
    }
}
