package hibernate.bug;

import hibernate.bug.model.Document;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.*;
import javax.persistence.criteria.*;
import java.util.Arrays;
import java.util.List;

public class InPaddingTest {

    private EntityManagerFactory emf;

    @Before
    public void init() {
        emf = Persistence.createEntityManagerFactory("Test");

        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        Document d = new Document();
        d.setName("A");
        em.persist(d);

        em.flush();
        tx.commit();
        em.close();

        StaticAppender.clear();
    }

    @Test
    public void testInPaddingInline() {
        EntityManager em = emf.createEntityManager();
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Long> query = cb.createQuery(Long.class);
        Root<Document> document = query.from(Document.class);

        query
                .select(document.<Long>get("id"))
                .where(
                        document.get("id").in(Arrays.asList(1,2,3,4,5))
                );


        TypedQuery<Long> typedQuery = em.createQuery(query);
        List l = typedQuery.getResultList();
        Assert.assertEquals(1, l.size());

        String executedQuery = StaticAppender.logs.get(StaticAppender.logs.size() - 1);
        System.out.println("Executed Query: "+executedQuery);
        Assert.assertTrue(executedQuery.endsWith("in (1 , 2 , 3 , 4 , 5 , 5 , 5 , 5);"));
    }

    @Test
    public void testInPaddingBind() {
        EntityManager em = emf.createEntityManager();
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Long> query = cb.createQuery(Long.class);
        Root<Document> document = query.from(Document.class);

        query
                .select(document.<Long>get("id"))
                .where(
                        document.get("name").in(Arrays.asList("A","B","C"))
                );


        TypedQuery<Long> typedQuery = em.createQuery(query);
        List l = typedQuery.getResultList();
        Assert.assertEquals(1, l.size());

        String executedQuery = StaticAppender.logs.get(StaticAppender.logs.size() - 1);
        System.out.println("Executed Query: "+executedQuery);
        Assert.assertTrue(executedQuery.endsWith("in ('A' , 'B' , 'C' , 'C');"));
    }


}
