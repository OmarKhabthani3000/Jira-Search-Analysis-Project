package hibernate.bug;

import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.core.Appender;
import ch.qos.logback.core.ConsoleAppender;

import java.util.ArrayList;
import java.util.List;

public class StaticAppender<E> extends ConsoleAppender<E> {

    public static List<String> logs = new ArrayList<String>();

    @Override
    public void doAppend(E eventObject) {
        LoggingEvent event = (LoggingEvent) eventObject;
        logs.add(event.getMessage());
        super.doAppend(eventObject);
    }

    public static void clear() {
        logs.clear();
    }
}
