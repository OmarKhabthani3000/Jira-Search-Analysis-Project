package org.hibernate.bugs;

import org.hibernate.bugs.entity.LineItem;
import org.hibernate.bugs.entity.ShoppingCart;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import static org.junit.Assert.assertEquals;

public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void hhh11328Test() throws Exception {
	    //GIVEN
        ShoppingCart transientCart = new ShoppingCart("cart1");
        transientCart.addLineItem(new LineItem(0, "description2", transientCart));


        //WHEN
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        entityManager.merge(transientCart);

        entityManager.getTransaction().commit();
        entityManager.close();


        //THEN
        EntityManager entityManager2 = entityManagerFactory.createEntityManager();
        entityManager2.getTransaction().begin();
        ShoppingCart updatedCart = entityManager2.find(ShoppingCart.class, "cart1");
        assertEquals(1, updatedCart.getLineItems().size());
        assertEquals("description2", updatedCart.getLineItems().get(0).getDescription());
    }
}
