package org.hibernate.bugs.entity;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
@IdClass(LineItem.Pk.class)
public class LineItem {

    @Id
    @Column(name = "item_seq_number", nullable = false)
    private Integer sequenceNumber;

    @Column(name = "description")
    private String description;

    @Id
    @ManyToOne
    @JoinColumn(name = "cart_id")
    private ShoppingCart cart;

    protected LineItem() {
    }

    public LineItem(Integer sequenceNumber, String description, ShoppingCart cart) {
        this.sequenceNumber = sequenceNumber;
        this.description = description;
        this.cart = cart;
    }

    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    public ShoppingCart getCart() {
        return cart;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LineItem)) return false;
        LineItem lineItem = (LineItem) o;
        return Objects.equals(getSequenceNumber(), lineItem.getSequenceNumber()) &&
                Objects.equals(getCart(), lineItem.getCart());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getSequenceNumber(), getCart());
    }

    public String getDescription() {
        return description;
    }

    public static class Pk implements Serializable {
        public Integer sequenceNumber;
        public String cart;

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Pk)) return false;
            Pk pk = (Pk) o;
            return Objects.equals(sequenceNumber, pk.sequenceNumber) &&
                    Objects.equals(cart, pk.cart);
        }

        @Override
        public int hashCode() {
            return Objects.hash(sequenceNumber, cart);
        }
    }
}
