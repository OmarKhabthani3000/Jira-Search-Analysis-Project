package test;

import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.ImprovedNamingStrategy;
import org.hibernate.validator.AssertTrue;

public class CascadeTestRunner {

	private static String CONFIG_FILE_LOCATION = "test/hibernate.cfg.xml";

	private Logger logger = Logger.getLogger(CascadeTestRunner.class);
	
    private static SessionFactory sessionFactory = null;
    private static final AnnotationConfiguration cfg = new AnnotationConfiguration();

    private static Session session;

    static {
        cfg.setNamingStrategy(ImprovedNamingStrategy.INSTANCE);
        cfg.configure(CONFIG_FILE_LOCATION);
        sessionFactory = cfg.buildSessionFactory();
    }
    
    private static Long companyId = null;
    
    public void doSaveCompany() {
    	
    	session = sessionFactory.openSession();
        session.getTransaction().begin();
        
		HashSet<Department> departments = new HashSet<Department>();
		Department department = new Department();
		department.setName("Accounting");
		departments.add(department);
		
		HashSet<Employee> employees = new HashSet<Employee>();
		Employee employee = new Employee();
		employee.setFirstName("emp one");
		employee.setLastName("testing");
		
		Employee employeeTwo = new Employee();
		employeeTwo.setFirstName("emp two");
		employeeTwo.setLastName("testing");
		
		employees.add(employee);
		employees.add(employeeTwo);
		
		Company company = new Company();
		company.setName("the company");
		company.setDepartment(departments);
		company.setEmployees(employees);
		
		session.save(company);
        session.getTransaction().commit();
        session.flush();
        
        companyId = company.getId();
        
        session.close();
    }
    
    public void doRefreshTest() {
    	
        session = sessionFactory.openSession();
        session.getTransaction().begin();
        
        Company loadedCompany = (Company)session.get(Company.class, companyId);
        logger.debug(loadedCompany);
        
        session.refresh(loadedCompany); // POINT A
        
        session.close();
        
        Set<Department> loadedDepartments = loadedCompany.getDepartments();
        logger.debug("TEST for LAZY DEPARTMENTS [START]");
        
        for (Department tmpDepartment : loadedDepartments) {
        	logger.debug(tmpDepartment); // POINT B
        }
        logger.debug("TEST for LAZY DEPARTMENTS [END]");
        
        Set<Employee> loadedEmployees = loadedCompany.getEmployees();
        logger.debug("TEST for LAZY EMPLOYEES [START]");
        for (Employee tmpEmployee : loadedEmployees) {
        	logger.debug(tmpEmployee); // POINT C
        }
        logger.debug("TEST for LAZY EMPLOYEES [END]");
    }

    public static void main(String[] args) {
    	
    	CascadeTestRunner testRunner = new CascadeTestRunner();
    	testRunner.doSaveCompany();
    	testRunner.doRefreshTest();
    	
    }
    
}