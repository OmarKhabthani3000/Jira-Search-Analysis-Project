package test;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@SuppressWarnings("serial") //$NON-NLS-1$
@Entity
@Table (name="employee") //$NON-NLS-1$
public class Employee implements java.io.Serializable {

    @Id @GeneratedValue
    @Column (name="employee_id") //$NON-NLS-1$
	private Long id;
    
    @ManyToOne
	@JoinColumn (name="department_employee") //$NON-NLS-1$
	private Company company;
	
    @Column (name="employee_first_name") //$NON-NLS-1$
    private String firstName;
    
    @Column (name="employee_last_name") //$NON-NLS-1$
    private String lastName;
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String toString() {
		return "employee id=" + id + ", firstName=" + firstName + ", lastName=" + lastName;
	}
	
}
