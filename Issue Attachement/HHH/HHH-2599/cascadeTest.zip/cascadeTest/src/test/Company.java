package test;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table (name="company")
public class Company implements java.io.Serializable {
	
    @Id @GeneratedValue
    @Column (name="company_id")
	private Long id;

    @Column (name="company_name")
    private String name;
    
    @OneToMany (mappedBy="company", cascade={ CascadeType.ALL })	// POINT 2
    private Set<Employee> employees;								// POINT 2
    
    @OneToMany (mappedBy="company", cascade={ CascadeType.ALL })	// POINT 1
    private Set<Department> departments;							// POINT 1

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public Set<Department> getDepartments() {
		return departments;
	}
	public void setDepartment(Set<Department> departments) {
		this.departments = departments;
		for (Department department : departments) {
			if (!this.equals(department.getCompany()))
				department.setCompany(this);
		}
	}
	
	public Set<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(Set<Employee> employees) {
		this.employees = employees;
		for (Employee employee : employees) {
			if (!this.equals(employee.getCompany()))
				employee.setCompany(this);
		}
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String toString() {
		return "company id=" + id + ", name=" + name;
	}

}
