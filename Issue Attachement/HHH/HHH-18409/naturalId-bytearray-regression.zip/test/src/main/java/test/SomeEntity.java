package test;

import java.util.Arrays;
import java.util.Objects;

import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.NaturalId;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.persistence.UniqueConstraint;

@Entity(name = "my_table")
@Immutable
@Table(uniqueConstraints = { @UniqueConstraint(name = "my_table_nkey", columnNames = { "someStringNid", "someMoreBytesNid" }) })
public class SomeEntity extends AbstractEntity {

    private static final long serialVersionUID = 1L;

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    @NaturalId
    @Column(nullable = false)
    private String someStringNid;

    @Transient
    private Object someObject;

    @Column(nullable = false, length = 16_000)
    private byte[] someBytes;

    @NaturalId
    @Column(nullable = false, length = 32)
    private byte[] someMoreBytesNid;

    public SomeEntity() {
        // empty
    }

    public SomeEntity(final String someString, final Object someObject, final byte[] someBytes, final byte[] someMoreBytes) {
        super();
        this.someStringNid = someString;
        this.someObject = someObject;
        this.someBytes = someBytes;
        this.someMoreBytesNid = someMoreBytes;
    }

    public byte[] getSomeBytes() {
        return someBytes;
    }

    public byte[] getSomeMoreBytesNid() {
        return someMoreBytesNid;
    }

    public Object getSomeObject() {
        return someObject;
    }

    public String getSomeStringNid() {
        return someStringNid;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + Arrays.hashCode(someMoreBytesNid);
        result = prime * result + Objects.hash(someStringNid);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SomeEntity)) {
            return false;
        }
        SomeEntity other = (SomeEntity) obj;
        return Arrays.equals(someMoreBytesNid, other.getSomeMoreBytesNid()) && Objects.equals(someStringNid, other.getSomeStringNid());
    }

}
