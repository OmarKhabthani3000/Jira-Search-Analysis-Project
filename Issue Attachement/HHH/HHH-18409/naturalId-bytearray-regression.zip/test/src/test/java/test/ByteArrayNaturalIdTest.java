package test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.hibernate.NaturalIdLoadAccess;
import org.hibernate.Session;
import org.hibernate.cfg.SchemaToolingSettings;
import org.hibernate.proxy.HibernateProxy;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * In Hibernate 6.5.2.Final, byte[] instance variables annotated with @NaturalId CANNOT be found with a natural ID query. This is a regression from Hibernate
 * 5.6.15.Final.
 *
 * <ol>
 * <li>In an EntityManager</li>
 * <li>Being a transaction</li>
 * <li>Persist entity A (in this test an instance of SomeEntity)</li>
 * <li>Create a second entity object B (another SomeEntity) for with SAME data</li>
 * <li>Perform a Natural ID query for object B and Hibernate 5 finds entity A</li>
 * <li>Perform a Natural ID query for object B and Hibernate 6 does NOT find entity A and returns null</li>
 * </ol>
 * <p>
 * This is because Arrays.equals() is used in org.hibernate.metamodel.mapping.internal.CompoundNaturalIdMapping.areEqual(Object, Object,
 * SharedSessionContractImplementor). This probably should use Objects.deepEquals() like Hiberate 5. In Hibernate 6 for this example, Arrays.equals() is given
 * an Object array with two elements, a String and a byte[], and Arrays.equals() does not compare the contents of the byte[] but it does compare the contents of
 * the String.
 * </p>
 * <p>
 * Eventually, this causes our app to try to persist the same object twice in the list which causes: PSQLException: ERROR: duplicate key value violates unique
 * constraint "dr_certificate_nkey" This hack causes the bytes in the NID to be different but breaks the digest for the byte[] to allow the tests to pass. This
 * part is not demonstrated in this test since this DB error is a side-effect of the actual bug.
 * </p>
 * <p>
 * This test uses an H2 database by default in ~/test. This test also provides a PostgreSQL PU since this is our actual use case.
 * </p>
 */
public class ByteArrayNaturalIdTest {

    static final Map<String, String> EMF_PROPERTIES = null;

    static final String PU_NAME_H2 = "test.h2";

    static final String PU_NAME_POSTGRES = "test.postgres";

    static final String PU_NAME = System.getProperty("pu", PU_NAME_H2);

    static void dropSchema(final boolean haltOnError) {
        generateSchema(PU_NAME, EMF_PROPERTIES, org.hibernate.tool.schema.Action.DROP, haltOnError);
    }

    static void generateSchema(final String persistenceUnitName, final Map<String, String> entityManagerFactoryProperties,
            final org.hibernate.tool.schema.Action action, final boolean haltOnError) {
        if (action == null || action == org.hibernate.tool.schema.Action.NONE) {
            return;
        }
        // Take exiting EMF properties, override the schema generation setting on a copy
        final Map<String, Object> generateSchemaProperties = new HashMap<>();
        if (entityManagerFactoryProperties != null) {
            generateSchemaProperties.putAll(entityManagerFactoryProperties);
        }
        generateSchemaProperties.put(SchemaToolingSettings.HBM2DDL_DATABASE_ACTION, action);
        generateSchemaProperties.put(SchemaToolingSettings.HBM2DDL_HALT_ON_ERROR, haltOnError);
        Persistence.generateSchema(persistenceUnitName, generateSchemaProperties);
    }

    static <T> Class<T> getPersistentClass(final T object) {
        if (object instanceof final HibernateProxy proxy) {
            return (Class<T>) proxy.getHibernateLazyInitializer().getPersistentClass();
        }
        return object != null ? (Class<T>) object.getClass() : null;
    }

    private EntityManagerFactory entityManagerFactory;

    private EntityManager entityManager;

    @AfterEach
    public void afterEach() {
        if (entityManager != null) {
            entityManager.close();
        }
        if (entityManagerFactory != null) {
            entityManagerFactory.close();
        }
    }

    @BeforeEach
    public void beforeEach() {
        dropSchema(false);
        generateSchema(PU_NAME, EMF_PROPERTIES, org.hibernate.tool.schema.Action.CREATE_ONLY, true);
        entityManagerFactory = Persistence.createEntityManagerFactory(PU_NAME);
        entityManager = entityManagerFactory.createEntityManager();
    }

    @SuppressWarnings("resource") // unwrapSession() does not allocate
    <T> NaturalIdLoadAccess<T> byNaturalId(final Class<T> entityClass) {
        return unwrapSession().byNaturalId(entityClass);
    }

    <T> T find(final Class<T> entityClass, final Function<NaturalIdLoadAccess<T>, NaturalIdLoadAccess<T>> naturalIdLoadAccess) {
        return naturalIdLoadAccess.apply(byNaturalId(entityClass)).load();
    }

    <T> T find(final Class<T> entityClass, final Object primaryKey) {
        if (primaryKey == null) {
            return null;
        }
        return entityManager.find(entityClass, primaryKey);
    }

    SomeEntity find(final SomeEntity entity) {
        // @formatter:off
        return find(entity, nila -> nila
                .using("someStringNid", entity.getSomeStringNid())
                .using("someMoreBytesNid", entity.getSomeMoreBytesNid()));
        // @formatter:on
    }

    <T extends AbstractEntity> T find(final T entity, final Function<NaturalIdLoadAccess<T>, NaturalIdLoadAccess<T>> naturalIdLoadAccess) {
        return entity == null ? null : find(entity, entity.getId(), naturalIdLoadAccess);
    }

    <T> T find(final T entity, final Object primaryKey, final Function<NaturalIdLoadAccess<T>, NaturalIdLoadAccess<T>> naturalIdLoadAccess) {
        if (entity == null || entityManager.contains(entity)) {
            return entity;
        }
        final Class<T> entityClass = getPersistentClass(entity);
        // Step 1: PK lookup
        final T found = primaryKey != null ? find(entityClass, primaryKey) : null;
        // Step 2: Natural ID lookup
        return found != null ? found : find(entityClass, naturalIdLoadAccess);
    }

    @Test
    public void test() {
        entityManager.getTransaction().begin();
        final SomeEntity e1 = new SomeEntity("someString", "someObject", new byte[] { 1 }, new byte[] { 1, 1 });
        final SomeEntity e2 = new SomeEntity("someString", "someObject", new byte[] { 1 }, new byte[] { 1, 1 });
        assertEquals(e1, e2);
        entityManager.persist(e1);
        // In Hibernate 6 find(e2) return null, in Hibernate 5 it returns the persisted entity.
        assertEquals(e1, find(e2));
        entityManager.getTransaction().commit();
    }

    <T> T unwrap(final Class<T> cls) {
        return entityManager.unwrap(cls);
    }

    Session unwrapSession() {
        return unwrap(Session.class);
    }

}
