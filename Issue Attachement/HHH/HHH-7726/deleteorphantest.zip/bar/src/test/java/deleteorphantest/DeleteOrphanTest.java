package deleteorphantest;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.HashSet;

import lombok.Cleanup;

import org.hibernate.Transaction;
import org.hibernate.Session;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DeleteOrphanTest {
	private DAO dao;
	private Parent parent;
	private Child child;
	private Session session;
	private Transaction transaction;
	
	@Before
	public void setUp() {
		// just a wrapper for SessionFactory instantiation
		// backed by a hsqldb in-memory database
		dao = new DAO();

		parent = new Parent();
		parent.setChildren(new HashSet<Child>());
		child = new Child();
		parent.getChildren().add(child);

		@Cleanup Session session = dao.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(parent);
		transaction.commit();
		
		this.session = dao.openSession();
		this.transaction = this.session.beginTransaction();
	}
	
	@Test
	public void testClearMerge() {
		// this works correctly
		parent.getChildren().clear();
		session.merge(parent);
		
		commitAndVerify();
	}

	@Test
	public void testEmptyMerge() {
		// this is the only case that works correctly
		// despite removing Hibernate's
		// PersistentCollection wrapper
		parent.setChildren(new HashSet<Child>());
		session.merge(parent);
		
		commitAndVerify();
	}

	@Test
	public void testNullMerge() {
		// this fails with an exception
		parent.setChildren(null);
		session.merge(parent);

		commitAndVerify();
	}
	
	@Test
	public void testClearUpdate() {
		// this works correctly
		parent.getChildren().clear();
		session.update(parent);
		
		commitAndVerify();
	}

	@Test
	public void testEmptyUpdate() {
		// this fails to delete the child instance
		parent.setChildren(new HashSet<Child>());
		session.update(parent);

		commitAndVerify();
	}

	@Test
	public void testNullUpdate() {
		// this fails to delete the child instance
		parent.setChildren(null);
		session.update(parent);

		commitAndVerify();
	}

	@After
	public void tearDown() throws SQLException {
		dao.shutDown();
	}

	private void commitAndVerify() {
		try{
			this.transaction.commit();
		} finally {
			this.session.close();
		}
		
		@Cleanup Session session = dao.openSession();
		Parent reloaded = (Parent) session.get(Parent.class, parent.getId());
		int parentChildCount = reloaded.getChildren().size();
		assertEquals("parent still references child", 0, parentChildCount);
		long databaseChildCount = (Long) session.createQuery("SELECT COUNT(*) AS n FROM Child").uniqueResult();
		assertEquals("child was not deleted from database", 0, databaseChildCount);
	}
}
