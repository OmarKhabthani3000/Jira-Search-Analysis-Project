package deleteorphantest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import lombok.Cleanup;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistryBuilder;
import org.hibernate.Session;

public class DAO {
	private static int nextDatabaseId = 0;

	private static final String USER = "sa";
	private static final String PASSWORD = "";

	private String url;

	private SessionFactory sessionFactory;
	
	public DAO() {
		// just setup for using a hsqldb in-memory database
		Configuration configuration = new Configuration();
		configuration.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
		configuration.setProperty("hibernate.connection.username", USER);
		configuration.setProperty("hibernate.connection.password", PASSWORD);
		configuration.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
		configuration.setProperty("hibernate.hbm2ddl.auto", "update");
		configuration.setProperty("hibernate.jdbc.batch_size", "0");
		url = "jdbc:hsqldb:mem:testdb"+nextDatabaseId++;
		configuration.setProperty("hibernate.connection.url", url);
		configuration.addResource("deleteorphantest/mapping.hbm.xml");
		ServiceRegistryBuilder serviceRegistryBuilder = new ServiceRegistryBuilder().applySettings(configuration.getProperties());
		sessionFactory = configuration.buildSessionFactory(serviceRegistryBuilder.buildServiceRegistry());
	}
	
	public Session openSession() {
		return sessionFactory.openSession();
	}
	
	public void shutDown() throws SQLException {
		// close session and shutdown hsqldb in-memory database
		sessionFactory.close();
		@Cleanup Connection connection = DriverManager.getConnection(url, USER, PASSWORD);
		@Cleanup Statement statement = connection.createStatement();
		statement.execute("SHUTDOWN");
	}
}
