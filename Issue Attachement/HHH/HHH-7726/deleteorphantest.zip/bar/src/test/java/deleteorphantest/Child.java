package deleteorphantest;

import lombok.Data;

@Data
public class Child {
	private long id;
}