package deleteorphantest;

import java.util.Set;

import lombok.Data;

@Data
public class Parent {
	private long id;
	private Set<Child> children;
}