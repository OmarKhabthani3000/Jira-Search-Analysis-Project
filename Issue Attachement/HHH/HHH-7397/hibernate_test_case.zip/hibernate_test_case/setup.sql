-- Setup entity tables
DROP DATABASE test2;
CREATE DATABASE test2;

USE test2;

CREATE TABLE GroupMember (
    groupMember_id bigint(20) NOT NULL,
    groupMember_type varchar(100) NOT NULL,
    name varchar(255) COLLATE utf8_bin NOT NULL,

    CONSTRAINT GroupMember_PK PRIMARY KEY (groupMember_id)
);

CREATE TABLE ColorGroup (
    id bigint(20) NOT NULL,
    name varchar(255) NOT NULL,

    CONSTRAINT Group_PK PRIMARY KEY (id)
);

CREATE TABLE GroupMembership (
    group_id bigint(20) NOT NULL,
    member_id bigint(20) NOT NULL,
    member_type varchar(100) NOT NULL,

    CONSTRAINT GroupMembership_PK PRIMARY KEY (group_id, member_id, member_type),
    CONSTRAINT GroupMembership_member_id_FK FOREIGN KEY (member_id) REFERENCES GroupMember (groupMember_id),
    CONSTRAINT GroupMembership_group_id_FK FOREIGN KEY (group_id) REFERENCES ColorGroup (id)
);
CREATE INDEX GroupMembership_group_IX ON GroupMembership (group_id);

CREATE TABLE SilverMember (
    id bigint(20) NOT NULL,
    name varchar(255) NOT NULL,
    CONSTRAINT SilverMember_id_FK FOREIGN KEY (id) REFERENCES GroupMember (groupMember_id)
);

CREATE TABLE BrassMember (
    id bigint(20) NOT NULL,
    name varchar(255) NOT NULL,
    CONSTRAINT BrassMember_id_FK FOREIGN KEY (id) REFERENCES GroupMember (groupMember_id)
);
