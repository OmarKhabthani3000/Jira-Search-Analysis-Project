Instructions:

It is recommended that an Eclipse project is created with access to the hibernate 3.6.0 core jar.  Add all of the files from the zip to the project.

A MySQL 5.5 database will need to be created.  Run the setup.sql script to create the requisite tables (this script will need to be re-run if the test case is run multiple times).

hibernate.cfg.xml will need to be modified to point to the test database.  This entails setting the values for connection.url, connection.username, and connection.password accordingly.

MappingTest.java will need to be modified such that the private variable, HIBERNATE_CFG_XML_LOCATION, is set to the location of hibernate.cfg.xml.

Compile the code and run MappingTest.java.  The following stack trace should be produced:

2012-06-18 16:39:30,685 DEBUG [main] [org.hibernate.SQL] delete from GroupMembership where group_id=? and member_id=?
Hibernate: delete from GroupMembership where group_id=? and member_id=?
2012-06-18 16:39:30,695 WARN  [main] [o.h.u.JDBCExceptionReporter] SQL Error: 0, SQLState: S1009
2012-06-18 16:39:30,695 ERROR [main] [o.h.u.JDBCExceptionReporter] Parameter index out of range (3 > number of parameters, which is 2).
2012-06-18 16:39:30,706 ERROR [main] [o.h.e.d.AbstractFlushingEventListener] Could not synchronize database state with session
org.hibernate.exception.GenericJDBCException: could not delete collection rows: [scratch.hibernate.ColorGroup.members#1]
	at org.hibernate.exception.SQLStateConverter.handledNonSpecificException(SQLStateConverter.java:140) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.exception.SQLStateConverter.convert(SQLStateConverter.java:128) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.exception.JDBCExceptionHelper.convert(JDBCExceptionHelper.java:66) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.persister.collection.AbstractCollectionPersister.deleteRows(AbstractCollectionPersister.java:1352) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.action.CollectionUpdateAction.execute(CollectionUpdateAction.java:84) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.engine.ActionQueue.execute(ActionQueue.java:273) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.engine.ActionQueue.executeActions(ActionQueue.java:265) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.engine.ActionQueue.executeActions(ActionQueue.java:187) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.event.def.AbstractFlushingEventListener.performExecutions(AbstractFlushingEventListener.java:321) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.event.def.DefaultFlushEventListener.onFlush(DefaultFlushEventListener.java:51) [hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.impl.SessionImpl.flush(SessionImpl.java:1216) [hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.impl.SessionImpl.managedFlush(SessionImpl.java:383) [hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.transaction.JDBCTransaction.commit(JDBCTransaction.java:133) [hibernate-core-3.6.0.jar:3.6.0.Final]
	at scratch.hibernate.MappingTest.testBasicUsage(MappingTest.java:77) [bin/:na]
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method) ~[na:1.6.0_17]
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:39) ~[na:1.6.0_17]
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25) ~[na:1.6.0_17]
	at java.lang.reflect.Method.invoke(Method.java:597) ~[na:1.6.0_17]
	at junit.framework.TestCase.runTest(TestCase.java:168) [junit-4.6.jar:na]
	at junit.framework.TestCase.runBare(TestCase.java:134) [junit-4.6.jar:na]
	at junit.framework.TestResult$1.protect(TestResult.java:110) [junit-4.6.jar:na]
	at junit.framework.TestResult.runProtected(TestResult.java:128) [junit-4.6.jar:na]
	at junit.framework.TestResult.run(TestResult.java:113) [junit-4.6.jar:na]
	at junit.framework.TestCase.run(TestCase.java:124) [junit-4.6.jar:na]
	at junit.framework.TestSuite.runTest(TestSuite.java:232) [junit-4.6.jar:na]
	at junit.framework.TestSuite.run(TestSuite.java:227) [junit-4.6.jar:na]
	at org.junit.internal.runners.JUnit38ClassRunner.run(JUnit38ClassRunner.java:91) [junit-4.6.jar:na]
	at org.eclipse.jdt.internal.junit4.runner.JUnit4TestReference.run(JUnit4TestReference.java:49) [.cp/:na]
	at org.eclipse.jdt.internal.junit.runner.TestExecution.run(TestExecution.java:38) [.cp/:na]
	at org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:467) [.cp/:na]
	at org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:683) [.cp/:na]
	at org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.run(RemoteTestRunner.java:390) [.cp/:na]
	at org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.main(RemoteTestRunner.java:197) [.cp/:na]
Caused by: java.sql.SQLException: Parameter index out of range (3 > number of parameters, which is 2).
	at com.mysql.jdbc.SQLError.createSQLException(SQLError.java:1073) ~[mysql-connector-java-5.1.20.jar:na]
	at com.mysql.jdbc.SQLError.createSQLException(SQLError.java:987) ~[mysql-connector-java-5.1.20.jar:na]
	at com.mysql.jdbc.SQLError.createSQLException(SQLError.java:982) ~[mysql-connector-java-5.1.20.jar:na]
	at com.mysql.jdbc.SQLError.createSQLException(SQLError.java:927) ~[mysql-connector-java-5.1.20.jar:na]
	at com.mysql.jdbc.PreparedStatement.checkBounds(PreparedStatement.java:3754) ~[mysql-connector-java-5.1.20.jar:na]
	at com.mysql.jdbc.PreparedStatement.setInternal(PreparedStatement.java:3738) ~[mysql-connector-java-5.1.20.jar:na]
	at com.mysql.jdbc.PreparedStatement.setInternal(PreparedStatement.java:3780) ~[mysql-connector-java-5.1.20.jar:na]
	at com.mysql.jdbc.PreparedStatement.setLong(PreparedStatement.java:3796) ~[mysql-connector-java-5.1.20.jar:na]
	at org.hibernate.type.descriptor.sql.BigIntTypeDescriptor$1.doBind(BigIntTypeDescriptor.java:52) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.type.descriptor.sql.BasicBinder.bind(BasicBinder.java:89) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.type.AbstractStandardBasicType.nullSafeSet(AbstractStandardBasicType.java:282) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.type.AbstractStandardBasicType.nullSafeSet(AbstractStandardBasicType.java:277) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.type.AbstractSingleColumnStandardBasicType.nullSafeSet(AbstractSingleColumnStandardBasicType.java:85) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.type.AnyType.nullSafeSet(AnyType.java:162) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.persister.collection.AbstractCollectionPersister.writeElementToWhere(AbstractCollectionPersister.java:844) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	at org.hibernate.persister.collection.AbstractCollectionPersister.deleteRows(AbstractCollectionPersister.java:1316) ~[hibernate-core-3.6.0.jar:3.6.0.Final]
	... 29 common frames omitted
