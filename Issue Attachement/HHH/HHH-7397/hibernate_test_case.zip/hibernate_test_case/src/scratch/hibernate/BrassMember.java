package scratch.hibernate;

import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name = "BrassMember")
public class BrassMember extends GroupMember {

}
