package scratch.hibernate;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "GroupMember")
public class GroupMemberRecord {

    @Id
    @GeneratedValue(generator="increment")
    @GenericGenerator(name="increment", strategy = "increment")
    @Column(name = "groupMember_id")
    private Long id;
 
    @Basic
    @Column(name = "groupMember_type")
    private String memberType;
 
    @Basic
    @Column(name = "name")
    private String name;
    
    GroupMemberRecord() {
        // for Hibernate
    }

    GroupMemberRecord(GroupMember groupMember) {
        if (groupMember instanceof SilverMember) {
            this.memberType = "SilverMember";
        } else if (groupMember instanceof BrassMember) {
            this.memberType = "BrassMember";
        } else {
            this.memberType = "unknown";
        }
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setObjectType(String objectType) {
        this.memberType = objectType;
    }

    public String getObjectType() {
        return memberType;
    }

    public Long getId() {
        return id;
    }
    
}
