package scratch.hibernate;

import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name = "SilverMember")
public class SilverMember extends GroupMember {

}
