package scratch.hibernate;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;

import org.hibernate.annotations.AnyMetaDef;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.ManyToAny;
import org.hibernate.annotations.MetaValue;

@Entity
@Table(name = "ColorGroup")
public class ColorGroup {
    
    /**
     * Instance ID value
     */
    @Id
    @GeneratedValue(generator="increment")
    @GenericGenerator(name="increment", strategy = "increment")
    private Long id;
    
    @AnyMetaDef(
        name = "GroupMember",
        idType = "long",
        metaType = "string",
        metaValues = {
            @MetaValue(value = "BrassMember", targetEntity = BrassMember.class),
            @MetaValue(value = "SilverMember", targetEntity = SilverMember.class)})
    @ManyToAny(metaDef = "GroupMember", metaColumn = @Column(name = "member_type"), fetch = FetchType.LAZY)
    @JoinTable(name = "GroupMembership",
        joinColumns = @JoinColumn(name = "group_id", nullable = false),
        inverseJoinColumns = @JoinColumn(name = "member_id", nullable = false)
    )
    private Set<GroupMember> members;
    
    @Basic
    private String name;
    
    public boolean addMember(GroupMember newMember) {
        if (newMember == null) {
            throw new IllegalArgumentException();
        }
        return this.getMembersMutable().add(newMember);
    }

    public boolean removeMember(GroupMember member) {
        return this.getMembersMutable().remove(member);
    }

    protected Set<GroupMember> getMembersMutable() {
        if (this.members == null) {
            this.members = new HashSet<GroupMember>();
        }
        return this.members;
    }
    
    protected Set<GroupMember> getMembers() {
        return Collections.unmodifiableSet(this.getMembersMutable());
    }
    
    public Long getId() {
        return this.id;
    }

    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
}
