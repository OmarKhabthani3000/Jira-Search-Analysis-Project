package scratch.hibernate;

import java.io.File;
import java.util.Set;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class MappingTest extends TestCase {
    
	//TODO Replace this value with the location of hibernate.cfg.xml
    private static final String HIBERNATE_CFG_XML_LOCATION = "/path/to/hibernate.cfg.xml";
    
    private SessionFactory sessionFactory;

    @Override
    protected void setUp() throws Exception {
        sessionFactory = new Configuration()
            .configure(new File(HIBERNATE_CFG_XML_LOCATION))
            .buildSessionFactory();
    }

    @Override
    protected void tearDown() throws Exception {
        if ( sessionFactory != null ) {
            sessionFactory.close();
        }
    }

    public void testBasicUsage() {
        
        /*
         * First, create a group that contains two members of differing types:
         * 
         * group1
         * -silver1
         * -brass1
         */
        Session session = sessionFactory.openSession();
        {
            session.beginTransaction();
            
            ColorGroup group = new ColorGroup();
            group.setName("group1");
            session.save(group);
            
            SilverMember silver1 = new SilverMember();
            silver1.setName("silver1");
            
            BrassMember brass1 = new BrassMember();
            brass1.setName("brass1");
            
            session.save(silver1);
            session.save(brass1);
            
            group.addMember(silver1);
            group.addMember(brass1);
            
            session.getTransaction().commit();
            session.close();
        }

        /*
         * Now try to remove silver1 from the group.
         */
        {
            session = sessionFactory.openSession();
            session.beginTransaction();
            
            ColorGroup retrievedGroup = (ColorGroup) session.createCriteria(ColorGroup.class).uniqueResult();
            SilverMember silver1 = (SilverMember) session.createCriteria(SilverMember.class).uniqueResult();
            retrievedGroup.removeMember(silver1);
            
            session.getTransaction().commit();
            session.close();
        }
    }
}
