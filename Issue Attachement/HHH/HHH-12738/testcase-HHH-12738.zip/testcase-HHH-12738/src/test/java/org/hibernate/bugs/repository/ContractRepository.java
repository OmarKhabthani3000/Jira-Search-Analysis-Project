package org.hibernate.bugs.repository;

import org.hibernate.bugs.entity.Contract;

public interface ContractRepository
{
    Long saveContract(Contract contract);
}
