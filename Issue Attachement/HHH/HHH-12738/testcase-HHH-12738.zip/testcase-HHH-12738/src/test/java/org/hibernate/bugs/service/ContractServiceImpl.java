package org.hibernate.bugs.service;

import javax.transaction.Transactional;

import org.hibernate.bugs.entity.Contract;
import org.hibernate.bugs.repository.ContractRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ContractServiceImpl implements ContractService
{
    @Autowired
    private ContractRepository customerRepository;

    @Override
    @Transactional
    public Long saveContract(Contract contract)
    {
        return customerRepository.saveContract(contract);
    }
}
