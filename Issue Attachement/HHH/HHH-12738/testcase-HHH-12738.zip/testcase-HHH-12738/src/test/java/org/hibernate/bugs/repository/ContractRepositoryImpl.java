package org.hibernate.bugs.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.bugs.entity.Contract;
import org.springframework.stereotype.Repository;

@Repository
public class ContractRepositoryImpl implements ContractRepository
{
    @PersistenceContext
    private EntityManager em;

    @Override
    @Transactional
    public Long saveContract(Contract contract)
    {
        em.persist(contract);
        return contract.getId();
    }
}
