package org.hibernate.bugs.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CustomerContractId implements Serializable
{
    private static final long serialVersionUID = 1115591676841551563L;

    @Column(name = "CUSTOMERID", nullable = false)
    private Long customerId;

    @Column(name = "CONTRACTID", nullable = false)
    private Long contractId;

    public Long getCustomerId()
    {
        return customerId;
    }

    public void setCustomerId(Long customerId)
    {
        this.customerId = customerId;
    }

    public Long getContractId()
    {
        return contractId;
    }

    public void setContractId(Long contractId)
    {
        this.contractId = contractId;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((contractId == null) ? 0 : contractId.hashCode());
        result = prime * result + ((customerId == null) ? 0 : customerId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CustomerContractId other = (CustomerContractId) obj;
        if (contractId == null)
        {
            if (other.contractId != null)
                return false;
        }
        else if (!contractId.equals(other.contractId))
            return false;
        if (customerId == null)
        {
            if (other.customerId != null)
                return false;
        }
        else if (!customerId.equals(other.customerId))
            return false;
        return true;
    }
}
