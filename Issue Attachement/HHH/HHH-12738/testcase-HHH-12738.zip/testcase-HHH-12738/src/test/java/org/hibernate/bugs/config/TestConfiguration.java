package org.hibernate.bugs.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.dialect.H2Dialect;
import org.hibernate.engine.transaction.jta.platform.internal.BitronixJtaPlatform;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.jta.JtaTransactionManager;

import bitronix.tm.BitronixTransactionManager;
import bitronix.tm.TransactionManagerServices;
import bitronix.tm.resource.jdbc.PoolingDataSource;

@Configuration
@EnableTransactionManagement
@ComponentScans(value = {
    @ComponentScan("org.hibernate.bugs.repository"),
    @ComponentScan("org.hibernate.bugs.service")})
public class TestConfiguration
{
    @Bean
    @DependsOn("btmConfiguration")
    public LocalContainerEntityManagerFactoryBean getEntityManagerFactoryBean()
    {
        LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
        factoryBean.setPersistenceUnitName("templatePU");
        factoryBean.setDataSource(getBTMDataSource());

        JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        factoryBean.setJpaVendorAdapter(vendorAdapter);
        factoryBean.setJpaProperties(additionalProperties());
        return factoryBean;
    }

    @Bean
    public PlatformTransactionManager platformTransactionManager(BitronixTransactionManager btmTransactionManager)
    {
        JtaTransactionManager transactionManager = new JtaTransactionManager();
        transactionManager.setTransactionManager(btmTransactionManager);
        transactionManager.setUserTransaction(btmTransactionManager);
        return transactionManager;
    }

    @Bean(name = "btmConfiguration")
    public bitronix.tm.Configuration getBTMConfiguration()
    {
        bitronix.tm.Configuration cfg = TransactionManagerServices.getConfiguration();
        cfg.setServerId("test-server");
        cfg.setLogPart1Filename("part1.btm");
        cfg.setLogPart2Filename("part2.btm");
        return cfg;
    }

    @Bean(destroyMethod = "shutdown")
    @DependsOn("btmConfiguration")
    public BitronixTransactionManager getBTMTransactionManager(bitronix.tm.Configuration cfg)
    {
        return TransactionManagerServices.getTransactionManager();
    }

    @Bean(destroyMethod = "close")
    @DependsOn("btmConfiguration")
    public DataSource getBTMDataSource()
    {
        PoolingDataSource poolingDataSource = new PoolingDataSource();
        poolingDataSource.setClassName("org.h2.jdbcx.JdbcDataSource");
        poolingDataSource.setUniqueName(getClass().getName());
        poolingDataSource.setMinPoolSize(0);
        poolingDataSource.setMaxPoolSize(5);
        poolingDataSource.setAllowLocalTransactions(true);
        poolingDataSource.setDriverProperties(new Properties());
        poolingDataSource.getDriverProperties().put("user", "sa");
        poolingDataSource.getDriverProperties().put("password", "");
        poolingDataSource.getDriverProperties().put("url", "jdbc:h2:mem:db1;DB_CLOSE_DELAY=-1");
        return poolingDataSource;
    }

    protected Properties additionalProperties()
    {
        Properties properties = new Properties();
        properties.setProperty("hibernate.transaction.jta.platform", BitronixJtaPlatform.class.getName());
        properties.setProperty("hibernate.dialect", H2Dialect.class.getName());
        properties.setProperty("hibernate.hbm2ddl.auto", "create-drop");
        return properties;
    }
}
