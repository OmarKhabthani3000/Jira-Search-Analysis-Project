package org.hibernate.bugs.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CUSTOMER_CONTRACT_RELATION")
public class CustomerContractRelation
{
    @EmbeddedId
    private final CustomerContractId id = new CustomerContractId();

    @Temporal(TemporalType.TIMESTAMP)
    @Column(nullable = true, name = "SIGNEDONDATE")
    private Date signedOn;

    @MapsId(value = "customerId")
    @JoinColumn(name = "CUSTOMERID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    public CustomerContractId getId()
    {
        return id;
    }

    public Customer getCustomer()
    {
        return customer;
    }

    public void setCustomer(Customer customer)
    {
        this.customer = customer;
    }

    public Date getSignedOn()
    {
        return signedOn;
    }

    public void setSignedOn(Date signedOn)
    {
        this.signedOn = signedOn;
    }

    public Long getCustomerId()
    {
        return id.getCustomerId();
    }

    public void setCustomerId(Long customerId)
    {
        id.setCustomerId(customerId);
    }

    public Long getContractId()
    {
        return id.getContractId();
    }

    public void setContractId(Long contractId)
    {
        id.setContractId(contractId);
    }
}
