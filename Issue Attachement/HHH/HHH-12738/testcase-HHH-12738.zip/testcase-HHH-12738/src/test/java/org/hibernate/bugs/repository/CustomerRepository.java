package org.hibernate.bugs.repository;

import org.hibernate.bugs.entity.Customer;

public interface CustomerRepository
{
    Long saveCustomer(Customer customer);

    Customer loadCustomer(long customerId);

    void flush();
}
