package org.hibernate.bugs.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.hibernate.bugs.entity.Customer;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerRepositoryImpl implements CustomerRepository
{
    @PersistenceContext
    private EntityManager em;

    @Override
    @Transactional
    public Long saveCustomer(Customer customer)
    {
        em.persist(customer);
        return customer.getId();
    }

    @Override
    public Customer loadCustomer(long customerId)
    {
        TypedQuery<Customer> query = em.createQuery("SELECT customer FROM org.hibernate.bugs.entity.Customer customer"
            + " LEFT JOIN FETCH customer.contractRelations "
            + " WHERE customer.id = :customerId", Customer.class);
        query.setParameter("customerId", customerId);
        return query.getSingleResult();
    }

    @Override
    public void flush()
    {
        em.flush();
    }
}
