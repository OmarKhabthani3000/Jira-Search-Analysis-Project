package org.hibernate.bugs.service;

import org.hibernate.bugs.entity.Contract;

public interface ContractService
{
    Long saveContract(Contract contract);
}
