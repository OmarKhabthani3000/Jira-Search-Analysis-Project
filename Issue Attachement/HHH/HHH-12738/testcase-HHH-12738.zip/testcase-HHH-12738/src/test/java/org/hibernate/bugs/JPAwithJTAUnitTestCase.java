package org.hibernate.bugs;

import org.hibernate.bugs.config.TestConfiguration;
import org.hibernate.bugs.entity.Contract;
import org.hibernate.bugs.entity.Customer;
import org.hibernate.bugs.entity.CustomerContractRelation;
import org.hibernate.bugs.service.ContractService;
import org.hibernate.bugs.service.CustomerService;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
@ContextConfiguration(classes = {TestConfiguration.class})
public class JPAwithJTAUnitTestCase extends AbstractJUnit4SpringContextTests
{
    @Autowired
    private CustomerService customerService;

    @Autowired
    private ContractService contractService;

    @Test
    public void createWithRelationTest() throws Exception
    {
        /* GIVEN */
        Contract contract = new Contract();
        Long contractId = contractService.saveContract(contract);

        /* WHEN */
        Customer customer = new Customer();
        CustomerContractRelation contractRelation = new CustomerContractRelation();
        contractRelation.setContractId(contractId);
        customer.addContractRelation(contractRelation);

        Long customerId = customerService.saveCustomer(customer);

        /* THEN*/
        Assert.assertNotNull(customerId);
    }

    /**
     * This test case is not working because spring logically closes the hibernate session (SessionImpl:418)
     * Flushing the session's dirty state seems to be executed afterwards causing the problem within the
     * ForeignGenerator.generate method accessing session.contains(...) which checks the session being open.
     */
    @Test
    public void addRelationImplicitFlush() throws Exception
    {
        /* GIVEN */
        Contract contract = new Contract();
        Long contractId = contractService.saveContract(contract);

        Customer customer = new Customer();
        Long customerId = customerService.saveCustomer(customer);

        /* WHEN */
        customerService.addContract(customerId, contractId);
    }

    @Test
    public void addRelationExplicitFlush() throws Exception
    {
        /* GIVEN */
        Contract contract = new Contract();
        Long contractId = contractService.saveContract(contract);

        Customer customer = new Customer();
        Long customerId = customerService.saveCustomer(customer);

        /* WHEN */
        customerService.addContractWithFlush(customerId, contractId);
    }
}
