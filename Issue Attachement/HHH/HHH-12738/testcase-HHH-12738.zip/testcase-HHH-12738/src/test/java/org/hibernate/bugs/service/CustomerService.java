package org.hibernate.bugs.service;

import org.hibernate.bugs.entity.Customer;

public interface CustomerService
{
    Long saveCustomer(Customer customer);

    void addContract(long customerId, long contractId);

    void addContractWithFlush(long customerId, long contractId);
}
