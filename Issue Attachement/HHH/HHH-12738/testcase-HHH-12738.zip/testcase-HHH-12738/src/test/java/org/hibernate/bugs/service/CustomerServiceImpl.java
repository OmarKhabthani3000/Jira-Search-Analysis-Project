package org.hibernate.bugs.service;

import javax.transaction.Transactional;

import org.hibernate.bugs.entity.Customer;
import org.hibernate.bugs.entity.CustomerContractRelation;
import org.hibernate.bugs.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService
{
    @Autowired
    private CustomerRepository customerRepository;

    @Override
    @Transactional
    public Long saveCustomer(Customer customer)
    {
        return customerRepository.saveCustomer(customer);
    }

    @Override
    @Transactional
    public void addContract(long customerId, long contractId)
    {
        Customer customer = customerRepository.loadCustomer(customerId);
        CustomerContractRelation relation = new CustomerContractRelation();
        relation.setContractId(contractId);
        customer.addContractRelation(relation);
    }

    @Override
    @Transactional
    public void addContractWithFlush(long customerId, long contractId)
    {
        Customer customer = customerRepository.loadCustomer(customerId);
        CustomerContractRelation relation = new CustomerContractRelation();
        relation.setContractId(contractId);
        customer.addContractRelation(relation);

        customerRepository.flush();
    }
}
