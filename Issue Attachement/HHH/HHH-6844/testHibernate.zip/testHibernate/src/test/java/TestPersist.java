import java.util.Date;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.myproject.domain.Account;
import com.myproject.domain.Credentials;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/META-INF/spring/applicationContext*.xml")
@Configurable
public class TestPersist {

	@Test
	public void testPersistAccount() {
		Account t = getNewTransientUser(0);
		t.setEmailAddress("myemail@wherever.com"); // same email address so will cause a constraint violation 

		Account t2 = getNewTransientUser(1);
		t2.setEmailAddress(t.getEmailAddress());
		try {
			t2.persist(); // this will throw a constraint violation. User2 won't be persisted but credentials will leaving an orphan }
		} catch(Exception err) {
			System.out.println("constraint error");
		}
		
		Credentials c = Credentials.findCredentials(t2.getCredentials().getId());
		Assert.assertNull(c);
	}
	
	public Account getNewTransientUser(int index) {
		Account obj = new Account();
        Credentials credentials = new Credentials();
		credentials.setUsername("username"); 
		credentials.setPassword("password");  
		obj.setCredentials(credentials);
		obj.setEmailAddress("email");
        obj.setFirstName("first");
        obj.setLastName("last");
        obj.setLocked(new Boolean(true));
        obj.setStatus(Account.STATUS.ACTIVE);

		return obj;
		
	}

}
