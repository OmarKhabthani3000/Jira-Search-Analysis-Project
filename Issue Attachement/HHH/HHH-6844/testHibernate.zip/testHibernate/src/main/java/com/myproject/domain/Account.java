package com.myproject.domain;

import org.springframework.transaction.annotation.Transactional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.persistence.Column;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToOne;
import javax.persistence.PersistenceContext;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;
import javax.persistence.Version;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.format.annotation.DateTimeFormat;

@Configurable
@Entity
@Inheritance(strategy=InheritanceType.JOINED)
public class Account {

	public enum GENDER { FEMALE, MALE }
	
	public enum STATUS { PENDING, ACTIVE, INACTIVE }
	
	@NotNull
	@Enumerated(EnumType.STRING)
    private STATUS status;
	
    @NotNull
    @Size(min = 1)
    private String firstName;

    @NotNull
    @Size(min = 1)
    private String lastName;

    @NotNull
    @Column(unique = true)
    @Size(min = 1)
    private String emailAddress;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "M-")
    private Date activationDate;
    
    @Column(unique = true)
    private String activationKey;

    private Boolean locked;

	@OneToOne(targetEntity=Credentials.class, cascade=CascadeType.ALL, fetch=FetchType.LAZY, orphanRemoval=true)
    private Credentials credentials;


	public STATUS getStatus() {
		return status;
	}

	public void setStatus(STATUS status) {
		this.status = status;
	}

	public String getFirstName() {
        return this.firstName;
    }

	public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

	public String getLastName() {
        return this.lastName;
    }

	public void setLastName(String lastName) {
        this.lastName = lastName;
    }

	public String getEmailAddress() {
        return this.emailAddress;
    }

	public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

	public Date getActivationDate() {
        return this.activationDate;
    }

	public void setActivationDate(Date activationDate) {
        this.activationDate = activationDate;
    }

	public String getActivationKey() {
        return this.activationKey;
    }

	public void setActivationKey(String activationKey) {
        this.activationKey = activationKey;
    }

	public Boolean getLocked() {
        return this.locked;
    }

	public void setLocked(Boolean locked) {
        this.locked = locked;
    }

	
	public Credentials getCredentials() {
		return credentials;
	}

	public void setCredentials(Credentials credentials) {
		this.credentials = credentials;
	}

	@Override
	public String toString() {
		return "User [firstName=" + firstName + ", lastName=" + lastName
				+ ", emailAddress=" + emailAddress + ", activationDate="
				+ activationDate + ", activationKey=" + activationKey
				+ ", locked=" + locked
				+ ", credentials=" + credentials + ", id=" + id + ", version="
				+ version + "]";
	}

	public static TypedQuery<Account> findUsersByActivationKeyAndEmailAddress(String activationKey, String emailAddress) {
        if (activationKey == null || activationKey.length() == 0) throw new IllegalArgumentException("The activationKey argument is required");
        if (emailAddress == null || emailAddress.length() == 0) throw new IllegalArgumentException("The emailAddress argument is required");
        EntityManager em = Account.entityManager();
        TypedQuery<Account> q = em.createQuery("SELECT o FROM Account AS o WHERE o.activationKey = :activationKey AND o.emailAddress = :emailAddress", Account.class);
        q.setParameter("activationKey", activationKey);
        q.setParameter("emailAddress", emailAddress);
        return q;
    }

	public static Account findUserByEmailAddress(String emailAddress) {
        if (emailAddress == null || emailAddress.length() == 0) throw new IllegalArgumentException("The emailAddress argument is required");
        EntityManager em = Account.entityManager();
        TypedQuery<Account> q = em.createQuery("SELECT o FROM Account AS o WHERE o.emailAddress = :emailAddress", Account.class);
        q.setParameter("emailAddress", emailAddress);
        Account user = q.getSingleResult();
        return user;
    }
	

	public static List<Account> findUsersByEmailAddress(String emailAddress) {
        if (emailAddress == null || emailAddress.length() == 0) throw new IllegalArgumentException("The emailAddress argument is required");
        EntityManager em = Account.entityManager();
        TypedQuery<Account> q = em.createQuery("SELECT o FROM Account AS o WHERE o.emailAddress = :emailAddress", Account.class);
        q.setParameter("emailAddress", emailAddress);
        
        return q.getResultList();
    }
	
	public static List<Account> findUsersByUsername(String username) {
        if (username == null || username.length() == 0) throw new IllegalArgumentException("The username argument is required");
        EntityManager em = Account.entityManager();
        TypedQuery<Account> q = em.createQuery("SELECT o FROM Account AS o WHERE o.credentials.username = :username", Account.class);
        q.setParameter("username", username);
        
        return q.getResultList();
    }
	
	
	public static Account findUserByUsername(String username) {
        if (username == null || username.length() == 0) throw new IllegalArgumentException("The username argument is required");
        EntityManager em = Account.entityManager();
        TypedQuery<Account> q = em.createQuery("SELECT o FROM Account AS o WHERE o.credentials.username = :username", Account.class);
        q.setParameter("username", username);
        Account user = q.getSingleResult();

        return user;
    }

	@PersistenceContext
    transient EntityManager entityManager;

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Long id;

	@Version
    @Column(name = "version")
    private Integer version;

	public Long getId() {
        return this.id;
    }

	public void setId(Long id) {
        this.id = id;
    }

	public Integer getVersion() {
        return this.version;
    }

	public void setVersion(Integer version) {
        this.version = version;
    }

	@Transactional
    public void persist() {
        if (this.entityManager == null) this.entityManager = entityManager();
        this.entityManager.persist(this);
    }

	@Transactional
    public void remove() {
        if (this.entityManager == null) this.entityManager = entityManager();
        if (this.entityManager.contains(this)) {
            this.entityManager.remove(this);
        } else {
            Account attached = Account.findUser(this.id);
            this.entityManager.remove(attached);
        }
    }

	@Transactional
    public void flush() {
        if (this.entityManager == null) this.entityManager = entityManager();
        this.entityManager.flush();
    }

	@Transactional
    public void clear() {
        if (this.entityManager == null) this.entityManager = entityManager();
        this.entityManager.clear();
    }

	@Transactional
    public Account merge() {
        if (this.entityManager == null) this.entityManager = entityManager();
        Account merged = this.entityManager.merge(this);
        this.entityManager.flush();
        return merged;
    }

	public static final EntityManager entityManager() {
        EntityManager em = new Account().entityManager;
        if (em == null) throw new IllegalStateException("Entity manager has not been injected (is the Spring Aspects JAR configured as an AJC/AJDT aspects library?)");
        return em;
    }

	public static long countUsers() {
        return entityManager().createQuery("SELECT COUNT(o) FROM Account o", Long.class).getSingleResult();
    }

	public static List<Account> findAllUsers() {
        return entityManager().createQuery("SELECT o FROM Account o", Account.class).getResultList();
    }

	public static Account findUser(Long id) {
        if (id == null) return null;
        return entityManager().find(Account.class, id);
    }

	public static List<Account> findUserEntries(int firstResult, int maxResults) {
        return entityManager().createQuery("SELECT o FROM Account o", Account.class).setFirstResult(firstResult).setMaxResults(maxResults).getResultList();
    }
	
	public static List<Account> findPendingEntries(int firstResult, int maxResults) {
        return entityManager().createQuery("SELECT o FROM Account o where o.status='PENDING'", Account.class).setFirstResult(firstResult).setMaxResults(maxResults).getResultList();
    }
	
	public static List<Account> findActiveEntries(int firstResult, int maxResults) {
        return entityManager().createQuery("SELECT o FROM Account o where o.status='ACTIVE'", Account.class).setFirstResult(firstResult).setMaxResults(maxResults).getResultList();
    }
	
	public static List<Account> findInActiveEntries(int firstResult, int maxResults) {
        return entityManager().createQuery("SELECT o FROM Account o where o.status='INACTIVE'", Account.class).setFirstResult(firstResult).setMaxResults(maxResults).getResultList();
    }
}
