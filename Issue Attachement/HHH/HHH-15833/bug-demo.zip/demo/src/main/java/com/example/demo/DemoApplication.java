package com.example.demo;

import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@PersistenceContext
	private EntityManager entityManager;

	@PostConstruct
	public void sybaseNamedParameterBug() {
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("SP_NAME_EXAMPLE");
		query.registerStoredProcedureParameter("@example_param", String.class, ParameterMode.IN);
		query.setParameter("@example_param", "example_value");
		query.getResultList();
	}

}
