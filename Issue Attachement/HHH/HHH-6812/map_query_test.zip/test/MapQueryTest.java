package test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

public class MapQueryTest extends TestCase {
  
  public void testMapQuery() {
    Session s = MapQueryTestSetup.openSession();
    Transaction t = s.beginTransaction();
    Set<MapQueryEntity> people = setup(s);
    {
      Query q1 = s.createQuery("from MapQueryEntity p where p.name = :name");
      q1.setString("name", "B");
      List<?> list1 = q1.list();
      assertEquals(1, list1.size());
      assertEquals("B", ((MapQueryEntity) list1.iterator().next()).getName());
    }
    {
      Query q2 = s.createQuery("from MapQueryEntity p where p.map['key'] = :val");
      q2.setString("val", "value");
      List<?> list2 = q2.list();
      assertEquals(1, list2.size());
      assertEquals("A", ((MapQueryEntity) list2.iterator().next()).getName());
    }
    {
      Query q3 = s.createQuery("from MapQueryEntity p where p.name = :name or p.map['key'] = :val");
      System.out.println(q3.getQueryString()); // TODO nej remove;
      q3.setString("name", "B");
      q3.setString("val", "value");
      List<?> list3 = q3.list();
      Set<String> expected = new HashSet<String>(Arrays.asList("A", "B"));
      for (Object object : list3) {
        if (object instanceof MapQueryEntity) {
          MapQueryEntity mqe = (MapQueryEntity) object;
          String name = mqe.getName();
          assertTrue("element '" + name + "' is not in the expected set (or twice in the result)", expected.remove(name));
        }
      }
      assertTrue("not found all expected entities. missing in result: " + expected, expected.isEmpty());
    }
    cleanup(s, people);
    t.commit();
    s.close();
  }
  
  private void cleanup(Session s, Set<MapQueryEntity> entities) {
    for (MapQueryEntity e : entities) {
      s.delete(e);
    }
    assertTrue(s.createQuery("from MapQueryEntity").list().isEmpty());
  }
  
  private Set<MapQueryEntity> setup(Session s) {
    MapQueryEntity a = new MapQueryEntity();
    a.setName("A");
    Map<String, String> m = new HashMap<String, String>();
    m.put("key", "value");
    a.setMap(m);
    
    MapQueryEntity b = new MapQueryEntity();
    b.setName("B");
    
    s.save(a);
    s.save(b);
    
    Set<MapQueryEntity> people = new HashSet<MapQueryEntity>();
    people.add(a);
    people.add(b);
    
    return people;
  }
  
  public static Test suite() {
    return new MapQueryTestSetup(new TestSuite(MapQueryTest.class));
  }

}
