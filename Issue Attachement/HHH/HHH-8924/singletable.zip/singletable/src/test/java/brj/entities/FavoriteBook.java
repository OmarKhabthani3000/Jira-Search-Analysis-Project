package brj.entities;

import javax.persistence.Entity;

@Entity
public class FavoriteBook extends AbstractBook {

}
