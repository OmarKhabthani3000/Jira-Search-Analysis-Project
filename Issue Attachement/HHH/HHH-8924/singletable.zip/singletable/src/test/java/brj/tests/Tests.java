package brj.tests;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import junit.framework.Assert;

import org.junit.Test;

import brj.entities.Book;
import brj.entities.FavoriteBook;
import brj.entities.Person;

public class Tests {

	@Test
	public void test() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("TEST");
		EntityManager em = emf.createEntityManager();

		Person person = new Person();
		person.setName("Person 1");

		Book book1 = new Book();
		book1.setName("Book 1");
		book1.setAuthor("Author Book 1");
		person.getBooks().add(book1);

		Book book2 = new Book();
		book2.setName("Book 2");
		book2.setAuthor("Author Book 2");
		person.getBooks().add(book2);

		FavoriteBook favBook = new FavoriteBook();
		favBook.setName("Favorite Book 1");
		favBook.setAuthor("Author Favorite Book 1");
		person.getFavoriteBooks().add(favBook);
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(person);
		tx.commit();
		em.close();

		em = emf.createEntityManager();
		TypedQuery<Person> qp = em.createQuery("select p from Person p", Person.class);
		List<Person> persons = qp.getResultList();
		
		Assert.assertEquals(1, persons.size());
		
		Person loaded = persons.get(0);
		List<Book> loadedBooks = loaded.getBooks();
		System.out.println(loadedBooks);
//		Assert.assertEquals(2, loadedBooks.size());
		
		List<FavoriteBook> loadedFavBooks = loaded.getFavoriteBooks();
		System.out.println(loadedFavBooks);
//		Assert.assertEquals(1, loadedFavBooks.size());
	}

}
