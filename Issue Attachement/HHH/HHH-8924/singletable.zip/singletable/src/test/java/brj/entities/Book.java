package brj.entities;

import javax.persistence.Entity;

@Entity
public class Book extends AbstractBook {

}
