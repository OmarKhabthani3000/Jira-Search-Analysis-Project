package patchTest.generatedDefault;

public class Key {
    private String id;
    
    public Key() {
        super();
    }
    
    public Key( String id ) {
        super();
        this.id = id;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId( String id ) {
        this.id = id;
    }
    
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ( ( getId() == null ) ? 0 : getId().hashCode() );
        return result;
    }
    
    public boolean equals( Object obj ) {
        if ( this == obj )
            return true;
        if ( ! ( obj instanceof Key ) )
            return false;
        final Key other = (Key) obj;
        if ( getId() == null ) {
            if ( other.getId() != null )
                return false;
        }
        else if ( !getId().equals( other.getId() ) )
            return false;
        return true;
    }
    
    public String toString() {
        return super.toString() + ":" + id;
    }
}
