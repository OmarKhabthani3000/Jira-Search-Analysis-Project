package patchTest.generatedDefault;


public class GeneratedDefault {
    private Long   id;
    
    private String property;
    
    private Key    many;
    
    public GeneratedDefault() {
        super();
    }
    
    public GeneratedDefault( String property, Key many ) {
        super();
        this.property = property;
        this.many = many;
    }
    
    public Long getId() {
        return id;
    }
    
    public void setId( Long id ) {
        this.id = id;
    }
    
    public Key getMany() {
        return many;
    }
    
    public void setMany( Key many ) {
        this.many = many;
    }
    
    public String getProperty() {
        return property;
    }
    
    public void setProperty( String property ) {
        this.property = property;
    }
}
