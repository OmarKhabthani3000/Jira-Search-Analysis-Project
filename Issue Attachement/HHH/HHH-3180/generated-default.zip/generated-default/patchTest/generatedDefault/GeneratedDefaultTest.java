package patchTest.generatedDefault;


import java.sql.Connection;
import java.sql.PreparedStatement;

import junit.framework.Test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;


/**
 * Implementation of test for patch not-found-keep.
 * 
 * @author Heinz Huber
 */
public class GeneratedDefaultTest extends FunctionalTestCase {
    
    public GeneratedDefaultTest( String name ) {
        super( name );
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see FunctionalTestCase#getBaseForMappings()
     */
    public String getBaseForMappings() {
        return "patchTest/";
    }
    
    public String[] getMappings() {
        return new String[] { "generatedDefault/mapping.hbm.xml" };
    }
    
    public static Test suite() {
        return new FunctionalTestClassTestSuite( GeneratedDefaultTest.class );
    }
    
    public void testGeneratedDefault() throws Throwable {
        Session session = openSession();
        Transaction txn = session.beginTransaction();
        
        setDefaults( session.connection() );
        
        Key manyKey = new Key( "many" );
        session.persist( manyKey );
        Key otherKey = new Key( "other" );
        session.persist( otherKey );
        session.flush();
        
        GeneratedDefault filled = new GeneratedDefault( "filled", otherKey );
        session.persist( filled );
        GeneratedDefault property = new GeneratedDefault( null, otherKey );
        session.persist( property );
        GeneratedDefault many = new GeneratedDefault( "many", null );
        session.persist( many );
        session.flush();
        
        checkAll( filled, property, many, manyKey, otherKey );
        
        session.clear();
        filled = get( session, filled );
        property = get( session, property );
        many = get( session, many );
        checkAll( filled, property, many, manyKey, otherKey );
        
        txn.rollback();
        session.close();
    }
    
    /**
     * @param session
     * @param filled
     * @return
     */
    private GeneratedDefault get( Session session, GeneratedDefault filled ) {
        return (GeneratedDefault) session.get( GeneratedDefault.class, filled.getId() );
    }
    
    private void checkAll( GeneratedDefault filled, GeneratedDefault property, GeneratedDefault many, Key manyKey,
                           Key otherKey ) {
        check( filled, "filled", otherKey );
        check( property, "property", otherKey );
        check( many, "many", manyKey );
    }
    
    private void check( GeneratedDefault def, String prop, Key many ) {
        assertEquals( prop + " property", prop, def.getProperty() );
        assertEquals( prop + " many", many, def.getMany() );
    }
    
    private void setDefaults( Connection conn ) throws Throwable {
        PreparedStatement stmnt = null;
        try {
            stmnt = conn.prepareStatement( "alter table GeneratedDefault alter column property set default 'property'" );
            stmnt.executeUpdate();
            stmnt.close();
            stmnt = conn.prepareStatement( "alter table GeneratedDefault alter column property set not null" );
            stmnt.executeUpdate();
            stmnt.close();
            stmnt = conn.prepareStatement( "alter table GeneratedDefault alter column many set default 'many'" );
            stmnt.executeUpdate();
            stmnt.close();
            stmnt = conn.prepareStatement( "alter table GeneratedDefault alter column many set not null" );
            stmnt.executeUpdate();
        }
        finally {
            if ( stmnt != null ) {
                try {
                    stmnt.close();
                }
                catch ( Throwable ignore ) {
                }
            }
        }
    }
}
