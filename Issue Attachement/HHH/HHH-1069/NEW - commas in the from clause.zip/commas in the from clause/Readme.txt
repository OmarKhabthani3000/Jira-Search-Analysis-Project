{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fcharset0 Courier New;}}
\viewkind4\uc1\pard\b\f0\fs20 Hibernate version:\b0  H3.1 rc2 (same problem with H3.1 rc1)\par
\b Database:\b0  Sybase 12.0.0.1\par
\par
\par
\b Problem description:\par
\b0 Commas are inserted in the FROM clause, between each join. This is rejected as a syntax error by JDBC.\par
If I send the Hibernate generated SQL, without the commas, I get my resultset (using a DB tool).\par
\par
Also, if I change my LEFT JOIN for JOIN, no commas are added but the Hibernate generated SQL is a THETA join not an ANSI join,\par
and the Hibernate generated SQL returns a resultset (see folder called "With JOIN instead of LEFT JOIN").\par
\par
How does Hibernate figure out which style of join to generate (THETA or ANSI). I must be missing something in my mapping files ???\par
I have a very similar query (except that the joined tables are one-to-many) on other tables and the Hibernate generated\par
SQL FROM clause contains the right LEFT JOIN statement without any commas.\par
\par
\par
Thanks for you help. I can't move forward if this is not resolved. If I could at least find a work around.\par
\par
\par
Cheers.\par
}
 