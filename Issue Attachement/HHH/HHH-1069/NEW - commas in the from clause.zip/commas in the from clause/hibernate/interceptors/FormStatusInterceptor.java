package hibernate.interceptors;

import java.io.*;

import org.apache.log4j.*;
import org.hibernate.*;

public class FormStatusInterceptor extends EmptyInterceptor {
    private Logger logger = Logger.getLogger(FormStatusInterceptor.class.getName());

    public int[] findDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState,
                           String[] propertyNames, org.hibernate.type.Type[] types) {

        boolean forceUpdate = false;
        String className = entity.getClass().toString();

        int[] results = null;
        int count = 0;
        if (className.equalsIgnoreCase("class hibernate.Form")) {

            for (int i = 0; i < types.length; i++) {
                if (propertyNames[i].equalsIgnoreCase("formstatus")) {
                    String currentStatus = (String) currentState[i];
                    String previousStatus = (String) previousState[i];
                    if (currentStatus.equalsIgnoreCase("N")) {
                        if (previousStatus.equalsIgnoreCase("N")) {
                            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                                logger.info("FormStatusInterceptor.findDirty - Forcing update to FORM table");
                            }
                            forceUpdate = true;
                        }
                    }
                }

                if (results == null) {
                    results = new int[types.length];
                }
                results[count++] = i;
            }
        }

        if (count == 0) {
            return null;
        } else {
            int[] trimmed = new int[count];
            System.arraycopy(results, 0, trimmed, 0, count);
            if (forceUpdate) {
                return trimmed;
            } else {
                return null;
            }
        }
    }
}
