package hibernate;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class PersonAcademicBackground implements Serializable {

    /** identifier field */
    private Integer degreeId;

    /** persistent field */
    private Integer cid;

    /** nullable persistent field */
    private hibernate.Cod degreeType;

    /** nullable persistent field */
    private String degreeName;

    /** nullable persistent field */
    private Date startDate;

    /** nullable persistent field */
    private Date completedDate;

    /** nullable persistent field */
    private Date expectedDate;

    /** nullable persistent field */
    private hibernate.Discipline discipline;

    /** nullable persistent field */
    private String otherDisciplineName;

    /** nullable persistent field */
    private hibernate.Organization organization;

    /** nullable persistent field */
    private String otherOrgName;

    /** nullable persistent field */
    private hibernate.Country otherCountry;

    /** nullable persistent field */
    private String resultOfSshrcInd;

    /** nullable persistent field */
    private String highestDegreeInd;

    /** persistent field */
    private String createUserId;

    /** persistent field */
    private Date createDate;

    /** persistent field */
    private String changeUserId;

    /** persistent field */
    private Date changeDate;

    /** nullable persistent field */
    private String startYear;

    /** nullable persistent field */
    private String startMonth;

    /** nullable persistent field */
    private String completedYear;

    /** nullable persistent field */
    private String completedMonth;

    /** nullable persistent field */
    private String expectedYear;

    /** nullable persistent field */
    private String expectedMonth;

    /** full constructor */
    public PersonAcademicBackground(Integer degreeId, Integer cid, hibernate.Cod degreeType, String degreeName, Date startDate, Date completedDate, Date expectedDate, hibernate.Discipline discipline, String otherDisciplineName, hibernate.Organization organization, String otherOrgName, hibernate.Country otherCountry, String resultOfSshrcInd, String highestDegreeInd, String createUserId, Date createDate, String changeUserId, Date changeDate, String startYear, String startMonth, String completedYear, String completedMonth, String expectedYear, String expectedMonth) {
        this.degreeId = degreeId;
        this.cid = cid;
        this.degreeType = degreeType;
        this.degreeName = degreeName;
        this.startDate = startDate;
        this.completedDate = completedDate;
        this.expectedDate = expectedDate;
        this.discipline = discipline;
        this.otherDisciplineName = otherDisciplineName;
        this.organization = organization;
        this.otherOrgName = otherOrgName;
        this.otherCountry = otherCountry;
        this.resultOfSshrcInd = resultOfSshrcInd;
        this.highestDegreeInd = highestDegreeInd;
        this.createUserId = createUserId;
        this.createDate = createDate;
        this.changeUserId = changeUserId;
        this.changeDate = changeDate;
        this.startYear = startYear;
        this.startMonth = startMonth;
        this.completedYear = completedYear;
        this.completedMonth = completedMonth;
        this.expectedYear = expectedYear;
        this.expectedMonth = expectedMonth;
    }

    /** default constructor */
    public PersonAcademicBackground() {
    }

    /** minimal constructor */
    public PersonAcademicBackground(Integer degreeId, Integer cid, String createUserId, Date createDate, String changeUserId, Date changeDate) {
        this.degreeId = degreeId;
        this.cid = cid;
        this.createUserId = createUserId;
        this.createDate = createDate;
        this.changeUserId = changeUserId;
        this.changeDate = changeDate;
    }

    public Integer getDegreeId() {
        return this.degreeId;
    }

    public void setDegreeId(Integer degreeId) {
        this.degreeId = degreeId;
    }

    public Integer getCid() {
        return this.cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public hibernate.Cod getDegreeType() {
        return this.degreeType;
    }

    public void setDegreeType(hibernate.Cod degreeType) {
        this.degreeType = degreeType;
    }

    public String getDegreeName() {
        return this.degreeName;
    }

    public void setDegreeName(String degreeName) {
        this.degreeName = degreeName;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getCompletedDate() {
        return this.completedDate;
    }

    public void setCompletedDate(Date completedDate) {
        this.completedDate = completedDate;
    }

    public Date getExpectedDate() {
        return this.expectedDate;
    }

    public void setExpectedDate(Date expectedDate) {
        this.expectedDate = expectedDate;
    }

    public hibernate.Discipline getDiscipline() {
        return this.discipline;
    }

    public void setDiscipline(hibernate.Discipline discipline) {
        this.discipline = discipline;
    }

    public String getOtherDisciplineName() {
        return this.otherDisciplineName;
    }

    public void setOtherDisciplineName(String otherDisciplineName) {
        this.otherDisciplineName = otherDisciplineName;
    }

    public hibernate.Organization getOrganization() {
        return this.organization;
    }

    public void setOrganization(hibernate.Organization organization) {
        this.organization = organization;
    }

    public String getOtherOrgName() {
        return this.otherOrgName;
    }

    public void setOtherOrgName(String otherOrgName) {
        this.otherOrgName = otherOrgName;
    }

    public hibernate.Country getOtherCountry() {
        return this.otherCountry;
    }

    public void setOtherCountry(hibernate.Country otherCountry) {
        this.otherCountry = otherCountry;
    }

    public String getResultOfSshrcInd() {
        return this.resultOfSshrcInd;
    }

    public void setResultOfSshrcInd(String resultOfSshrcInd) {
        this.resultOfSshrcInd = resultOfSshrcInd;
    }

    public String getHighestDegreeInd() {
        return this.highestDegreeInd;
    }

    public void setHighestDegreeInd(String highestDegreeInd) {
        this.highestDegreeInd = highestDegreeInd;
    }

    public String getCreateUserId() {
        return this.createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getChangeUserId() {
        return this.changeUserId;
    }

    public void setChangeUserId(String changeUserId) {
        this.changeUserId = changeUserId;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getStartYear() {
        return this.startYear;
    }

    public void setStartYear(String startYear) {
        this.startYear = startYear;
    }

    public String getStartMonth() {
        return this.startMonth;
    }

    public void setStartMonth(String startMonth) {
        this.startMonth = startMonth;
    }

    public String getCompletedYear() {
        return this.completedYear;
    }

    public void setCompletedYear(String completedYear) {
        this.completedYear = completedYear;
    }

    public String getCompletedMonth() {
        return this.completedMonth;
    }

    public void setCompletedMonth(String completedMonth) {
        this.completedMonth = completedMonth;
    }

    public String getExpectedYear() {
        return this.expectedYear;
    }

    public void setExpectedYear(String expectedYear) {
        this.expectedYear = expectedYear;
    }

    public String getExpectedMonth() {
        return this.expectedMonth;
    }

    public void setExpectedMonth(String expectedMonth) {
        this.expectedMonth = expectedMonth;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("degreeId", getDegreeId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof PersonAcademicBackground) ) return false;
        PersonAcademicBackground castOther = (PersonAcademicBackground) other;
        return new EqualsBuilder()
            .append(this.getDegreeId(), castOther.getDegreeId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getDegreeId())
            .toHashCode();
    }

}
