package ca.sshrc.web.common.util;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author Pierre Mass�
 * @version 1.0
 */
public class GenericDataTable {
    private String value;  // Can be used as a row or column value
    private String styleClass;  // Can be used as a row or column styleClass
    private boolean rendered; // To decide if OutputText or CommandLink (participantBody.jsp)

    public GenericDataTable() {
    }

    public GenericDataTable(String value, String styleClass, boolean rendered) {
        this.value = value;
        this.styleClass = styleClass;
        this.rendered = rendered;
    }

    public GenericDataTable(int value, String styleClass, boolean rendered) {
        this.value = new Integer(value).toString();
        this.styleClass = styleClass;
        this.rendered = rendered;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setStyleClass(String styleClass) {
        this.styleClass = styleClass;
    }

    public void setRendered(boolean rendered) {
        this.rendered = rendered;
    }

    public String getValue() {
        return value;
    }

    public String getStyleClass() {
        return styleClass;
    }

    public boolean isRendered() {
        return rendered;
    }
}
