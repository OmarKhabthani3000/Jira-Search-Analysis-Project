package ca.sshrc.web.forms.portFolio;

import java.util.*;

import org.apache.log4j.*;

public class PortFolioService {
    private Logger logger = Logger.getLogger(PortFolioService.class.getName());

    public List getPortFolio(Integer webId, Integer subSystemId) {
        PortFolioDBA portFolioDBA = new PortFolioDBA();
        List portFolioList = portFolioDBA.queryPortFolio(webId, subSystemId);

        return portFolioList;
    }

    public List getPortFolioCV(ca.sshrc.web.logon.LogonBean logonBean, Integer subSystemId) {
        PortFolioCVDBA portFolioCVDBA = new PortFolioCVDBA();
        List portFolioList = portFolioCVDBA.queryPortFolio(logonBean, subSystemId);

        return portFolioList;
    }

    public List getPortFolioList(Integer webId, Integer subSystemId) {
        PortFolioDBA portFolioDBA = new PortFolioDBA();
        List portFolioList = portFolioDBA.queryPortFolio(webId, subSystemId);

        return portFolioList;
    }

    public List getPortFolioCVList(ca.sshrc.web.logon.LogonBean logonBean, Integer subSystemId) {
        PortFolioCVDBA portFolioCVDBA = new PortFolioCVDBA();
        List portFolioList = portFolioCVDBA.queryPortFolio(logonBean, subSystemId);
        return portFolioList;
    }
    public Integer getPortFolioSubSystemId(Integer requestedSubsystemId) {
        PortFolioDBA portFolioDBA = new PortFolioDBA();
        return portFolioDBA.queryPortFolioSubSystemId(requestedSubsystemId);
    }
}
