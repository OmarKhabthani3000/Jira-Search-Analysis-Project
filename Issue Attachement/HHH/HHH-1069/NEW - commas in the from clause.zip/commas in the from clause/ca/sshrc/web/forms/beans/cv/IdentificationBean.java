package ca.sshrc.web.forms.beans.cv;

import java.lang.reflect.*;
import java.util.*;
import java.util.regex.*;

import javax.faces.application.*;
import javax.faces.component.*;
import javax.faces.context.*;
import javax.faces.model.*;
import javax.faces.validator.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.util.*;
import org.hibernate.*;
import org.apache.commons.beanutils.*;
import org.apache.log4j.*;
import hibernate.Country;

/**
 * <p>Title: CV Identification bean</p>
 *
 * <p>Description: Used on the CV Identification web page</p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class IdentificationBean extends ca.sshrc.web.common.services.baseObject.BeanBase {

    private Logger logger = Logger.getLogger(IdentificationBean.class.getName());

    /** From Person table */
    /** identifier field */
    private Integer cid;

    /** nullable persistent field */
    private Integer amisCid;

    /** nullable persistent field */
    private String familyName;

    /** nullable persistent field */
    private String givenName;

    /** nullable persistent field */
    private String initials;

    /** nullable persistent field */
    private Integer salutation;

    /** nullable persistent field */
    private Short yearOfBirth;
    private boolean yearOfBirthValidationError = false;

    /** nullable persistent field */
    private Integer citizenshipType;

    /** CitizenShipType - Radio button values and labels */
    private SelectItem[] citizenshipTypeStatusFrench = new SelectItem[] {new SelectItem(new Integer(12),
            "Canadien"), new SelectItem(new Integer(14), "Resident permanant"),
            new SelectItem(new Integer(13), "Autre")};
    private SelectItem[] citizenshipTypeStatusEnglish = new SelectItem[] {new SelectItem(new Integer(12),
            "Canadian"), new SelectItem(new Integer(14), "Permanent resident"),
            new SelectItem(new Integer(13), "Other")};

    /** nullable persistent field */
    private Country otherCountryCode;

    /** nullable persistent field */
    private Date landedOnDate;

    /** nullable persistent field */
    private String permResStatusInd;

    /** nullable persistent field */
    private Integer gender;

    /** persistent field */
    private String correspondenceLanguageCode;

    /** persistent field */
    private String readEnglish;
    private boolean readEnglishBoolean;

    /** nullable persistent field */
    private String writeEnglish;
    private boolean writeEnglishBoolean;

    /** nullable persistent field */
    private String speakEnglish;
    private boolean speakEnglishBoolean;

    /** nullable persistent field */
    private String auralEnglish;
    private boolean auralEnglishBoolean;

    /** nullable persistent field */
    private String readFrench;
    private boolean readFrenchBoolean;

    /** nullable persistent field */
    private String writeFrench;
    private boolean writeFrenchBoolean;

    /** nullable persistent field */
    private String speakFrench;
    private boolean speakFrenchBoolean;

    /** nullable persistent field */
    private String auralFrench;
    private boolean auralFrenchBoolean;

    /** nullable persistent field */
    private String otherLanguages;

    /** nullable persistent field */
    private String emailAddress;

    /** persistent field */
    private Date changeDate;

    /** nullable persistent field */
    private String alias;

    /** nullable persistent field */
    private String postalCode;
    private boolean postalCodeValidationError;

    /** nullable persistent field */
    private String landedYear;

    /** nullable persistent field */
    private String landedMonth;

    /** nullable persistent field */
    private String landedDay;

    /** nullable persistent field */
    private String newPersonInd;

    /** nullable persistent field */
    private String assessorWillingToServeInd;

    /** From Country table */
    /** persistent field */
    private String countryNameEnglish;

    /** persistent field */
    private String countryNameFrench;

    /** From Form table */
    /** persistent field */
    private String formLanguage;

    /** persistent field */
    private String formStatus;

    /** persistent field */
    private Long formId;

    /** default constructor */
    public IdentificationBean() {
        /**
         * This cannot be implemented in this particular bean because of the form language
         * field. If the language field changes, all the drop down list and List button value must
         * be re-retrieved.
         *
         * if (this.getFacesContext().getRenderResponse()) {
         * this.retrieve(0);
         * }
         * */

        try {
            // Get a session
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // Call this object's retrieve method
            this.retrieve(0, session);

        } catch (Exception ex) {
            HibernateUtil.closeSession();
            ex.printStackTrace();
        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    /** full constructor */
    public IdentificationBean(Integer cid, Integer amisCid, String familyName, String givenName,
                              String initials, Integer salutation, Short yearOfBirth, Integer citizenshipType,
                              hibernate.Country otherCountryCode, Date landedOnDate, String permResStatusInd,
                              Integer gender, String correspondenceLanguageCode, String readEnglish,
                              String writeEnglish, String speakEnglish, String auralEnglish,
                              String readFrench, String writeFrench, String speakFrench, String auralFrench,
                              String otherLanguages, String emailAddress, Date changeDate, String alias,
                              String postalCode, String landedYear, String landedMonth, String landedDay,
                              String newPersonInd, String assessorWillingToServeInd,
                              String countryNameEnglish, String countryNameFrench, String formLanguage,
                              String formStatus, Long formId) {
        this.cid = cid;
        this.amisCid = amisCid;
        this.familyName = familyName;
        this.givenName = givenName;
        this.initials = trim(initials);
        this.salutation = salutation;
        this.yearOfBirth = yearOfBirth;
        this.citizenshipType = citizenshipType;
        this.otherCountryCode = otherCountryCode;
        this.landedOnDate = landedOnDate;
        this.permResStatusInd = trim(permResStatusInd);
        this.gender = gender;
        this.correspondenceLanguageCode = trim(correspondenceLanguageCode);

        this.readEnglish = trim(readEnglish);
        this.readEnglishBoolean = booleanConverter(readEnglish);

        this.writeEnglish = trim(writeEnglish);
        this.writeEnglishBoolean = booleanConverter(writeEnglish);

        this.speakEnglish = trim(speakEnglish);
        this.speakEnglishBoolean = booleanConverter(speakEnglish);

        this.auralEnglish = trim(auralEnglish);
        this.auralEnglishBoolean = booleanConverter(auralEnglish);

        this.readFrench = trim(readFrench);
        this.readFrenchBoolean = booleanConverter(readFrench);

        this.writeFrench = trim(writeFrench);
        this.writeFrenchBoolean = booleanConverter(writeFrench);

        this.speakFrench = trim(speakFrench);
        this.speakFrenchBoolean = booleanConverter(speakFrench);

        this.auralFrench = trim(auralFrench);
        this.auralFrenchBoolean = booleanConverter(auralFrench);

        this.otherLanguages = otherLanguages;
        this.emailAddress = trim(emailAddress);
        this.changeDate = changeDate;
        this.alias = alias;
        this.postalCode = trim(postalCode);
        this.landedYear = trim(landedYear);
        this.landedMonth = trim(landedMonth);
        this.landedDay = trim(landedDay);
        this.newPersonInd = trim(newPersonInd);
        this.assessorWillingToServeInd = trim(assessorWillingToServeInd);
        this.countryNameEnglish = countryNameEnglish;
        this.countryNameFrench = countryNameFrench;
        this.formLanguage = formLanguage;
        this.formStatus = trim(formStatus);
        this.formId = formId;
    }

    /** booelean to String (Y or N) */
    private String booleanConverter(boolean value) {
        String returnString = "N";

        if (value) {
            returnString = "Y";
        }

        return returnString;
    }

    /** String (Y or N) to boolean */
    private boolean booleanConverter(String value) {
        boolean returnBoolean = false;

        if (value == null) {
            return returnBoolean;
        }
        if (value.equalsIgnoreCase("y") || value.equalsIgnoreCase("yes")) {
            returnBoolean = true;
        }

        return returnBoolean;
    }

    public Integer getCid() {
        return this.cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public Integer getAmisCid() {
        return this.amisCid;
    }

    public void setAmisCid(Integer amisCid) {
        this.amisCid = amisCid;
    }

    public String getFamilyName() {
        return this.familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getGivenName() {
        return this.givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getInitials() {
        return this.initials;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public Integer getSalutation() {
        return this.salutation;
    }

    public void setSalutation(Integer salutation) {
        this.salutation = salutation;
    }

    public Short getYearOfBirth() {
        if (null == this.yearOfBirth || this.yearOfBirth.intValue() == 0) {
            return null;
        }
        return this.yearOfBirth;
    }

    public void setYearOfBirth(Short yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    public boolean getYearOfBirthValidationError() {

        return this.yearOfBirthValidationError;
    }

    public Integer getCitizenshipType() {
        return this.citizenshipType;
    }

    public void setCitizenshipType(Integer citizenshipType) {
        this.citizenshipType = citizenshipType;
    }

    public SelectItem[] getCitizenShipStatusItems() {

        if (this.getFormLanguage() != null) {
            if (this.getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
                return this.citizenshipTypeStatusFrench;
            } else {
                return this.citizenshipTypeStatusEnglish;
            }
        } else {
            return this.citizenshipTypeStatusEnglish;
        }
    }

    public Country getOtherCountryCode() {
        if (null == this.otherCountryCode) {
            return new Country();
        } else {
            return this.otherCountryCode;
        }
    }

    public void setOtherCountryCode(Country otherCountryCode) {
        this.otherCountryCode = otherCountryCode;
    }

    public Date getLandedOnDate() {
        return this.landedOnDate;
    }

    public void setLandedOnDate(Date landedOnDate) {
        this.landedOnDate = landedOnDate;
    }

    public String getPermResStatusInd() {
        return this.permResStatusInd;
    }

    public void setPermResStatusInd(String permResStatusInd) {
        this.permResStatusInd = permResStatusInd;
    }

    public Integer getGender() {
        return this.gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public String getCorrespondenceLanguageCode() {
        return this.correspondenceLanguageCode;
    }

    public void setCorrespondenceLanguageCode(String correspondenceLanguageCode) {
        /** If user's changing the site language, implement the change in the navigationBean
         * so that the next time a "site" page is displayed, it will be in the selected language
         */
        if (!(this.correspondenceLanguageCode == null) &&
            !this.correspondenceLanguageCode.equalsIgnoreCase(correspondenceLanguageCode)) {
            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info(
                        "In IdentificationBean.setCorrespondenceLanguageCode - calling nav bean setLanguageSite");
            }
            if (correspondenceLanguageCode.equalsIgnoreCase("f")) {
                this.getNavigationBean().setLanguageSite(Constants.FRENCH_CANADIAN_LOCALE);
            } else {
                this.getNavigationBean().setLanguageSite(Constants.ENGLISH_CANADIAN_LOCALE);
            }
        }
        this.correspondenceLanguageCode = correspondenceLanguageCode;
    }

    /** Read English */
    public String getReadEnglish() {
        return this.readEnglish;
    }

    public boolean getReadEnglishBoolean() {
        return this.readEnglishBoolean;
    }

    public void setReadEnglish(String readEnglish) {
        this.readEnglish = readEnglish;
        this.readEnglishBoolean = booleanConverter(readEnglish);
    }

    public void setReadEnglishBoolean(boolean readEnglish) {
        this.readEnglishBoolean = readEnglish;
        this.readEnglish = booleanConverter(readEnglish);
    }

    /** Write English */
    public String getWriteEnglish() {
        return this.writeEnglish;
    }

    public boolean getWriteEnglishBoolean() {
        return this.writeEnglishBoolean;
    }

    public void setWriteEnglish(String writeEnglish) {
        this.writeEnglish = writeEnglish;
        this.writeEnglishBoolean = booleanConverter(writeEnglish);
    }

    public void setWriteEnglishBoolean(boolean writeEnglish) {
        this.writeEnglishBoolean = writeEnglish;
        this.writeEnglish = booleanConverter(writeEnglish);
    }


    /** Speak English */
    public String getSpeakEnglish() {
        return this.speakEnglish;
    }

    public boolean getSpeakEnglishBoolean() {
        return this.speakEnglishBoolean;
    }

    public void setSpeakEnglish(String speakEnglish) {
        this.speakEnglish = speakEnglish;
        this.speakEnglishBoolean = booleanConverter(speakEnglish);
    }

    public void setSpeakEnglishBoolean(boolean speakEnglish) {
        this.speakEnglishBoolean = speakEnglish;
        this.speakEnglish = booleanConverter(speakEnglish);
    }

    /** Aural English */
    public String getAuralEnglish() {
        return this.auralEnglish;
    }

    public boolean getAuralEnglishBoolean() {
        return this.auralEnglishBoolean;
    }

    public void setAuralEnglish(String auralEnglish) {
        this.auralEnglish = auralEnglish;
        this.auralEnglishBoolean = booleanConverter(auralEnglish);
    }

    public void setAuralEnglishBoolean(boolean auralEnglish) {
        this.auralEnglishBoolean = auralEnglish;
        this.auralEnglish = booleanConverter(auralEnglish);
    }

    /** Read French */
    public String getReadFrench() {
        return this.readFrench;
    }

    public boolean getReadFrenchBoolean() {
        return this.readFrenchBoolean;
    }

    public void setReadFrench(String readFrench) {
        this.readFrench = readFrench;
        this.readFrenchBoolean = booleanConverter(readFrench);
    }

    public void setReadFrenchBoolean(boolean readFrench) {
        this.readFrenchBoolean = readFrench;
        this.readFrench = booleanConverter(readFrench);
    }

    /** Write French */
    public String getWriteFrench() {
        return this.writeFrench;
    }

    public boolean getWriteFrenchBoolean() {
        return this.writeFrenchBoolean;
    }

    public void setWriteFrench(String writeFrench) {
        this.writeFrench = writeFrench;
        this.writeFrenchBoolean = booleanConverter(writeFrench);
    }

    public void setWriteFrenchBoolean(boolean writeFrench) {
        this.writeFrenchBoolean = writeFrench;
        this.writeFrench = booleanConverter(writeFrench);
    }

    /** Speak French */
    public String getSpeakFrench() {
        return this.speakFrench;
    }

    public boolean getSpeakFrenchBoolean() {
        return this.speakFrenchBoolean;
    }

    public void setSpeakFrench(String speakFrench) {
        this.speakFrench = speakFrench;
        this.speakFrenchBoolean = booleanConverter(speakFrench);
    }

    public void setSpeakFrenchBoolean(boolean speakFrench) {
        this.speakFrenchBoolean = speakFrench;
        this.speakFrench = booleanConverter(speakFrench);
    }

    /** Aural French */
    public String getAuralFrench() {
        return this.auralFrench;
    }

    public boolean getAuralFrenchBoolean() {
        return this.auralFrenchBoolean;
    }

    public void setAuralFrench(String auralFrench) {
        this.auralFrench = auralFrench;
        this.auralFrenchBoolean = booleanConverter(auralFrench);
    }

    public void setAuralFrenchBoolean(boolean auralFrench) {
        this.auralFrenchBoolean = auralFrench;
        this.auralFrench = booleanConverter(auralFrench);
    }

    public String getOtherLanguages() {
        return this.otherLanguages;
    }

    public void setOtherLanguages(String otherLanguages) {
        this.otherLanguages = otherLanguages;
    }

    public String getEmailAddress() {
        return this.emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getAlias() {
        return this.alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getPostalCode() {
        return this.postalCode;
    }

    public boolean getPostalCodeValidationError() {

        return this.postalCodeValidationError;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getLandedYear() {
        return this.landedYear;
    }

    public void setLandedYear(String landedYear) {
        this.landedYear = landedYear;
    }

    public String getLandedMonth() {
        return this.landedMonth;
    }

    public void setLandedMonth(String landedMonth) {
        this.landedMonth = landedMonth;
    }

    public String getLandedDay() {
        return this.landedDay;
    }

    public void setLandedDay(String landedDay) {
        this.landedDay = landedDay;
    }

    public String getNewPersonInd() {
        return this.newPersonInd;
    }

    public void setNewPersonInd(String newPersonInd) {
        this.newPersonInd = newPersonInd;
    }

    public String getAssessorWillingToServeInd() {
        return this.assessorWillingToServeInd;
    }

    public void setAssessorWillingToServeInd(String assessorWillingToServeInd) {
        this.assessorWillingToServeInd = assessorWillingToServeInd;
    }

    /**
     * Return country name based on form language
     * The returned value if often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getCountryName() {
        String countryName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.countryNameFrench != null) {
                countryName = this.countryNameFrench;
            }
        } else if (this.countryNameEnglish != null) {
            countryName = this.countryNameEnglish;
        }

        return countryName;
    }

    public void setCountryName(String countryName) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setCountryNameFrench(countryName);
        } else {
            this.setCountryNameEnglish(countryName);
        }
    }

    public String getCountryNameEnglish() {
        return this.countryNameEnglish;
    }

    public void setCountryNameEnglish(String countryNameEnglish) {
        this.countryNameEnglish = countryNameEnglish;
    }

    public String getCountryNameFrench() {
        return this.countryNameFrench;
    }

    public void setCountryNameFrench(String countryNameFrench) {
        this.countryNameFrench = countryNameFrench;
    }

    public String getFormLanguage() {
        return this.formLanguage;
    }

    public void setFormLanguage(String formLanguage) {
        /** If user's changing the form language, implement the change in the navigationBean
         * so that the next time a form page is displayed, it will be in the newly selected language
         */
        if (formLanguage.equalsIgnoreCase("f")) {
            this.getNavigationBean().setFormLanguage(Constants.FRENCH_CANADIAN_LOCALE);
        } else {
            this.getNavigationBean().setFormLanguage(Constants.ENGLISH_CANADIAN_LOCALE);
        }

        this.formLanguage = formLanguage;
    }

    public String getFormStatus() {
        return this.formStatus;
    }

    public Long getFormId() {
        return formId;
    }

    public void setFormStatus(String formStatus) {
        this.formStatus = formStatus;
    }

    public void setFormId(Long formId) {
        this.formId = formId;
    }

    // Overwrite ancestor method
    public void retrieve(Session session) {
        retrieve(0, session);
    }

    public void retrieve(long formId, Session session) {

        Logger logger = Logger.getLogger(IdentificationBean.class.getName());
        List queryList;

        if (null == session) {
            if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                logger.error("Cannot load IdentificationBean - Session is null");
                return;
            }
        }

        // If the passed form id is 0, get the form id from the NavigationBean
        if (formId == 0) {
            formId = getNavigationBean().getForm_id();
            if (formId == 0) {
                if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                    logger.error("Cannot load IdentificationBean - no FormId : " + formId);
                    return;
                }
            } else {
                logger.info("IdentificationBean.retrieve using navigationBean FormId : " + formId);
            }

        } else {
            logger.info("IdentificationBean.retrieve using passed parm FormId : " + formId);
        }

        // Retrieve data
        try {
            logger.info("In IdentificationBean.retrieve()");

            queryList = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.cv.IdentificationBean(person.cid,  " +
                    "person.amisCid, " +
                    "person.familyName, " +
                    "person.givenName, " +
                    "person.initials, " +
                    "person.salutation, " +
                    "person.yearOfBirth, " +
                    "person.citizenshipType, " +
                    "country, " +
                    "person.landedOnDate, " +
                    "person.permResStatusInd, " +
                    "person.gender, " +
                    "person.correspondenceLanguageCode, " +
                    "person.readEnglish, " +
                    "person.writeEnglish, " +
                    "person.speakEnglish, " +
                    "person.auralEnglish, " +
                    "person.readFrench, " +
                    "person.writeFrench, " +
                    "person.speakFrench, " +
                    "person.auralFrench, " +
                    "person.otherLanguages, " +
                    "person.emailAddress, " +
                    "person.changeDate, " +
                    "person.alias, " +
                    "person.postalCode, " +
                    "person.landedYear, " +
                    "person.landedMonth, " +
                    "person.landedDay, " +
                    "person.newPersonInd, " +
                    "person.assessorWillingToServeInd, " +
                    "country.nameEnglish, " +
                    "country.nameFrench, " +
                    "form.formLanguage, " +
                    "form.formStatus, " +
                    "form.formId) " +
                    "from Form form join form.person as person left outer join fetch person.otherCountryCode as country " +
                    "where ( form.formId = :formId )")
                        .setParameter("formId", new Long(formId))
                        .list();

            if (queryList.size() > 0) {
                this.loadData((IdentificationBean) queryList.get(0));
            }

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded IdentificationBean : " + queryList.size());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    private void loadData(IdentificationBean bean) {

        // Set values
        try {
            // PropertyUtils.copyProperties(destination, source)
            PropertyUtils.copyProperties(this, bean);

        } catch (NoSuchMethodException ex) {
            ex.printStackTrace();
        } catch (InvocationTargetException ex) {
            ex.printStackTrace();
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
        }

    }

    public String save(Session session) throws HibernateException, Exception {
        Logger logger = Logger.getLogger(IdentificationBean.class.getName());
        List queryList;
        String saveOutcome = Constants.UPDATE_ERROR_OUTCOME; // Defaults to update error

        /**
         * Save Person data
         * */
        logger.info("saving Person data");
        queryList = session.createQuery("from Person " +
                                        "where cid = :cid")
                    .setParameter("cid", this.getCid())
                    .list();

        logger.info("Retrieved hibernate.Person object for cid: " +
                    this.getCid());

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Loaded hibernate.Person objects : " + queryList.size());
        }

        if (queryList.size() > 0) {
            // Set values
            hibernate.Person myPerson = (hibernate.Person) queryList.get(0);

            // Check for stale data (BaseBean method - first param is DB date, second param is Web date)
            if (!isStaleData(myPerson.getChangeDate(), this.getChangeDate())) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("Person - Not Stale data");
                }
                // Save to DB

                // BeanUtils.copyProperties(destination, source)
                BeanUtils.copyProperties(myPerson, this);
                session.saveOrUpdate(myPerson);
                session.flush();
                session.refresh(myPerson);

                // Refresh Change_date on This.Bean
                this.setChangeDate(myPerson.getChangeDate());
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("Person - refreshing Web date : " + this.getChangeDate());
                    logger.info("Person - refreshing DB date : " + myPerson.getChangeDate());
                }

                saveOutcome = Constants.SUCCESS_OUTCOME;
            } else {
                logger.error("Stale data in Person -  NOT Saving");
            }
        }

        /**
         * Save Form data (if save Person saved successfully)
         * */
        if (saveOutcome.equalsIgnoreCase(Constants.SUCCESS_OUTCOME)) {
            logger.info("Saving Form data");
            logger.info("Retrieving hibernate.Form object for formId: " +
                        this.getFormId());
            queryList = session.createQuery("from Form form where form.formId = :formIdparm")
                        .setParameter("formIdparm", this.getFormId())
                        .list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded hibernate.Form objects : " + queryList.size());
            }

            if (queryList.size() > 0) {
                // Set values
                hibernate.Form myForm = (hibernate.Form) queryList.get(0);
                myForm.setFormLanguage(this.getFormLanguage());
                session.saveOrUpdate(myForm);
                saveOutcome = Constants.SUCCESS_OUTCOME;
            }
        }

        return saveOutcome;
    }

    public void validateYearOfBirth(FacesContext context, UIComponent toValidate, java.lang.Object value) throws
            ValidatorException {

        try {
            Short sYearOfBirth = (Short) value;

            // Only validate if user entered something
            if (sYearOfBirth != null) {

                String errorMessage, moduleBundleName[];

                // Get current year
                Calendar cal = Calendar.getInstance(TimeZone.getDefault());
                String DATE_FORMAT = "yyyy";
                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(DATE_FORMAT);
                Integer systemYear = new Integer(sdf.format(cal.getTime()));

                if (sYearOfBirth.intValue() < 1900 || sYearOfBirth.intValue() > systemYear.intValue()) {
                    // Set validation indicator, used for label style
                    this.yearOfBirthValidationError = true;

                    // Resource bundle stuff to get error message & label
                    ResourceBundle validationErrorBundle = null;
                    ResourceBundle moduleBundle = null;
                    Locale locale = null;

                    // Create Locale
                    if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.
                            FRENCH_CANADIAN_LOCALE)) {
                        locale = Locale.CANADA_FRENCH;
                    } else {
                        locale = Locale.CANADA;
                    }

                    // Get resource bundles
                    validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                            Constants.VALIDATION_ERROR_RESOURCES, locale);

                    // Get THIS module's resource bundle name
                    // moduleBundleName is a String array because it's possible to have more then one resource per module,
                    // like it's possible to have more then one bean per module. (so, it's basically one resource bundle per bean)
                    // I'll only plan for one per bean for now. I'll only take the first array position.
                    moduleBundleName = this.getNavigationBean().getRequestedModuleResourceBundle();
                    if (moduleBundleName.length > 0) {
                        moduleBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                                moduleBundleName[0], locale);
                    }

                    // Get
                    errorMessage = validationErrorBundle.getString("errorYearRange");
                    Object params[] = {moduleBundle.getString("birthYear"), new String("2005")};

                    // Need ValidationMessage object to do the param. substitution.
                    ValidationMessage validationMessage = new ValidationMessage();
                    ((UIInput) toValidate).setValid(false);
                    context.addMessage(toValidate.getClientId(context),
                                       new FacesMessage(validationMessage.
                            substituteParams(locale, errorMessage, params),
                            validationMessage.substituteParams(locale, errorMessage, params)));
                } else {
                    ((UIInput) toValidate).setValid(true);
                }
            }
        } catch (ClassCastException e) {
            throw new ValidatorException(
                    new FacesMessage(
                            "Validation Error: Value " +
                            "cannot be converted to String.",
                            null));
        }
    }


    public String validate(ValidationMessage validationMessage) throws HibernateException, Exception {
        Logger logger = Logger.getLogger(IdentificationBean.class.getName());
        String validationOutcome = Constants.SUCCESS_OUTCOME;
        ResourceBundle moduleBundle = null;
        ResourceBundle applicationBundle = null;
        ResourceBundle validationErrorBundle = null;
        Locale locale = null;
        Integer subSystemId = null;
        Integer moduleId = null;
        String moduleDisplayName = null;
        String errorMessage = null;

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("IdentificationBean.validate - Start");
        }

        // If no row, return success
        if (this.formId == null) {
            return validationOutcome;
        }

        // If messageContainer is null, throw exception
        if (validationMessage == null) {
            throw new Exception("Invalid parameter. ValidationMessage object was null.");
        }

        subSystemId = this.getNavigationBean().getRequestedSubsystemId();
        moduleId = validationMessage.getModuleNavigationBarBean().getSequenceNumber();

        // Create Locale
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            locale = Locale.CANADA_FRENCH;
            moduleDisplayName = validationMessage.getModuleNavigationBarBean().getNameFrench();
        } else {
            locale = Locale.CANADA;
            moduleDisplayName = validationMessage.getModuleNavigationBarBean().getNameEnglish();
        }

        // Get resource bundles
        applicationBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                Constants.APPLICATION_RESOURCES, locale);
        validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                Constants.VALIDATION_ERROR_RESOURCES, locale);
        moduleBundle = ResourceBundle.getBundle(validationMessage.getResourceBundleName(), locale);

        /**
         *
         * Validate Person data
         *
         * */

        // Family Name
        if (null == this.familyName || (this.familyName.trim()).equals("")) {
            // Add validation error message
            errorMessage = validationErrorBundle.getString("errorFieldToComplete");
            Object params[] = {applicationBundle.getString("familyName")};
            validationMessage.addMessage(subSystemId,
                                         moduleId,
                                         moduleDisplayName,
                                         validationMessage.substituteParams(locale, errorMessage, params));
        }
        // Given name
        if (null == this.givenName || (this.givenName.trim()).equals("")) {
            // Add validation error message
            errorMessage = validationErrorBundle.getString("errorFieldToComplete");
            Object params[] = {applicationBundle.getString("givenName")};
            validationMessage.addMessage(subSystemId,
                                         moduleId,
                                         moduleDisplayName,
                                         validationMessage.substituteParams(locale, errorMessage, params));
        }

        // Salutation
        if (null == this.salutation || this.salutation.equals(new Integer(0))) {
            // Add validation error message
            errorMessage = validationErrorBundle.getString("errorFieldToComplete");
            Object params[] = {applicationBundle.getString("title")};
            validationMessage.addMessage(subSystemId,
                                         moduleId,
                                         moduleDisplayName,
                                         validationMessage.substituteParams(locale, errorMessage, params));
        }

        /** Citizenship type
         *
         */
        switch (this.citizenshipType.intValue()) {

        case 12: // Citizenship = Canada

            // the other country, applied question & date should all be null.
            // check the country
            if (null != this.otherCountryCode.getCountryCode() &&
                this.otherCountryCode.getCountryCode().intValue() > 0) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorFieldCitizenType");
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             errorMessage);
            }

            if (subSystemId.intValue() != 22) { // Not for CISS-RDC
                if (null != this.permResStatusInd && !(this.permResStatusInd.trim()).equals("")) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorPermResStatusInd");
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 errorMessage);
                }

                // check that the date is null
                if ((null != this.landedYear && !(this.landedYear.trim()).equals("")) ||
                    (null != this.landedMonth && !(this.landedMonth.trim()).equals("")) ||
                    (null != this.landedDay && !(this.landedDay.trim()).equals(""))) {

                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorPermResDate");
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 errorMessage);
                }
            }

            break;

        case 14: // permanent resident
            if (subSystemId.intValue() != 22) { // Not for CISS-RDC
                // the other country, applied question & date should all be null.
                // check the country
                if (null != this.otherCountryCode.getCountryCode()) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorFieldCitizenType");
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 errorMessage);
                }

                if (null != this.permResStatusInd && !(this.permResStatusInd.trim()).equals("")) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorPermResStatusInd");
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 errorMessage);
                }

                // check that the date is null
                if ((null != this.landedYear && !(this.landedYear.trim()).equals("")) ||
                    (null != this.landedMonth && !(this.landedMonth.trim()).equals("")) ||
                    (null != this.landedDay && !(this.landedDay.trim()).equals(""))) {

                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorPermResDate");
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 errorMessage);
                }
            }
            break;

        case 13: // Citizenship = other

            // the other country, applied question & date should all be null.
            // check the country
            if (null == this.otherCountryCode.getCountryCode()) {
                // Add validation error message
                errorMessage = moduleBundle.getString("errorFieldToComplete");
                Object params[] = {moduleBundle.getString("citizenOf")};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage,
                        params));
            } else if (this.otherCountryCode.getCountryCode().intValue() == 1100) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorOtherCountryCanada");
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             errorMessage);
            }

            // check that the date is null
            if ((null != this.landedYear && !(this.landedYear.trim()).equals("")) ||
                (null != this.landedMonth && !(this.landedMonth.trim()).equals("")) ||
                (null != this.landedDay && !(this.landedDay.trim()).equals(""))) {

                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorPermResDate");
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             errorMessage);
            }
            if (subSystemId.intValue() != 22) { // Not for CISS-RDC
                if (null == this.permResStatusInd || (this.permResStatusInd.trim()).equals("")) {
                    // Add validation error message
                    errorMessage = moduleBundle.getString("errorFieldToComplete");
                    Object params[] = {moduleBundle.getString("appliedPermanent")};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage,
                            params));
                }
            }

            break;

        default: // if the status was not filled in, but other fields in citizenship were...

            // check that the date is null
            if ((null != this.landedYear && !(this.landedYear.trim()).equals("")) ||
                (null != this.landedMonth && !(this.landedMonth.trim()).equals("")) ||
                (null != this.landedDay && !(this.landedDay.trim()).equals("")) ||
                (null != this.otherCountryCode.getCountryCode())) {

                // Add validation error message
                errorMessage = moduleBundle.getString("errorFieldToComplete");
                Object params[] = {applicationBundle.getString("status")};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage,
                        params));
            }
        }

        // Birth date - Was in the back end validation but has been moved to the page

        // Postal code - Was in the back end validation but has been moved to the page





        return validationOutcome;
    }

    public void validatePostalCode(FacesContext context, UIComponent toValidate, java.lang.Object inputValue) throws
            ValidatorException {

        Pattern pattern;
        String expression = "\\D{1}\\d{1}\\D{1}\\d{1}\\D{1}\\d{1}"; // x9x9x9
        String value = null;

        try {
            value = inputValue.toString();
            pattern = Pattern.compile(expression);

            this.postalCodeValidationError = !pattern.matcher(value).matches();

        } catch (ClassCastException e) {
            throw new ValidatorException(
                    new FacesMessage(
                            "Validation Error: Value " +
                            "cannot be converted to String.",
                            null));
        }

        if (this.postalCodeValidationError) {
            // Get error message from resource bundle
            // Resource bundle stuff to get error message & label
            String errorMessage;
            ResourceBundle validationErrorBundle = null;
            Locale locale = null;

            // Create Locale
            if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
                locale = Locale.CANADA_FRENCH;
            } else {
                locale = Locale.CANADA;
            }

            // Get validation error resource bundles
            validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                    Constants.VALIDATION_ERROR_RESOURCES, locale);

            // Get error message
            errorMessage = validationErrorBundle.getString("errorPostalCodeFormat");

            if (null != errorMessage) {
                throw new ValidatorException(
                        new FacesMessage(errorMessage,
                                         null));
            } else {
                throw new ValidatorException(
                        new FacesMessage("Invalid postal code.",
                                         null));
            }
        }

    }
}
