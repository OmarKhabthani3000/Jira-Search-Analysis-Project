package ca.sshrc.web.common.services;

import javax.faces.event.ActionEvent;
import javax.faces.context.FacesContext;
import java.util.Map;
import java.util.Locale;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class form {
    public void changeLocale(ActionEvent e) {
        FacesContext context = FacesContext.getCurrentInstance();
        Map requestParams = context.getExternalContext().getRequestParameterMap();
        String locale = (String) requestParams.get("locale");
        if ("english".equals(locale)) {
            context.getViewRoot().setLocale(Locale.UK);
        } else if ("german".equals(locale)) {
            context.getViewRoot().setLocale(Locale.GERMANY);
        }
        if ("english".equals(locale)) {
            context.getViewRoot().setLocale(Locale.UK);
        }
    }
}
