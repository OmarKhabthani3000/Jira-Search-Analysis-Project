package ca.sshrc.web.common.converters;


import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.NumberUtils;
import java.math.BigDecimal;
import ca.sshrc.web.common.util.Constants;


/**
 * <p>{@link Converter} implementation for <code>java.lang.Integer</code>
 * (and int primitive) values. Will remove invalid characters before trying the
 * conversion. The characters removed are {.,$ and space}</p>
 */

public class BigDecimalToIntegerConverter implements Converter {


    // ------------------------------------------------------ Manifest Constants


    /**
     * <p>The standard converter id for this converter.</p>
     */
    public static final String CONVERTER_ID = "BigDecimalToIntegerConverter";


    // ------------------------------------------------------- Converter Methods


    /**
     * @exception ConverterException {@inheritDoc}
     * @exception NullPointerException {@inheritDoc}
     */
    public Object getAsObject(FacesContext context, UIComponent component,
                              String value) {

        BigDecimal valueBigDecimal;

        if (context == null || component == null) {
            throw new NullPointerException();
        }

        // If the specified value is null or zero-length, return null
        if (value == null) {
            return (null);
        }
        value = value.trim();
        if (value.length() < 1) {
            return (null);
        }

        if (!NumberUtils.isDigits(value)) {
            // Try cleaning it up first
            for (int i = 0; i < Constants.INVALID_CHARACTERS_IN_NUMERIC_FIELD.length; i++) {
                value = StringUtils.replace(value, Constants.INVALID_CHARACTERS_IN_NUMERIC_FIELD[i], "");
            }
        }

        try {
            valueBigDecimal = (new BigDecimal(value));
            return valueBigDecimal;
        } catch (Exception e) {
            throw new ConverterException(e);
        }

    }

    /**
     * @exception ConverterException {@inheritDoc}
     * @exception NullPointerException {@inheritDoc}
     */
    public String getAsString(FacesContext context, UIComponent component,
                              Object value) {

        String tempString;
        int indexOfDecimalPoint;

        if (context == null || component == null) {
            throw new NullPointerException();
        }

        // If the specified value is null, return a zero-length String
        if (value == null) {
            return "";
        }

        // If the incoming value is still a string, play nice
        // and return the value unmodified
        if (value instanceof String) {
            return (String) value;
        }

        try {
            // Truncate everything passed the decimal point (including the decimal point)
            // i.e.: 123.0000 => 123
            // The decimal point is removed in this object getAsObject() so, there should never be
            // a decimal value to be displayed.
            tempString = (((BigDecimal) value).toString());
            indexOfDecimalPoint = tempString.lastIndexOf(".");
            if(indexOfDecimalPoint > 0) {
                tempString = tempString.substring(0,indexOfDecimalPoint);
            }

            return tempString;
        } catch (Exception e) {
            throw new ConverterException(e);
        }

    }


}
