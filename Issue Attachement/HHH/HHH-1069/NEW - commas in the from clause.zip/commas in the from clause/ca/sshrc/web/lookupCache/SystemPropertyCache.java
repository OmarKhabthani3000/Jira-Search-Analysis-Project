package ca.sshrc.web.lookupCache;

import java.io.*;
import java.util.*;

import ca.sshrc.web.common.services.*;
import hibernate.*;
import org.apache.log4j.*;
import org.hibernate.*;

public class SystemPropertyCache implements Serializable {

    private Logger logger = Logger.getLogger(WebSubSystemCache.class.getName());
    private List queryList;

    public SystemPropertyCache() {
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In SystemProperty");

            // Ordered descending because when we look for a subsystem id, will most likely
            // look for high value sub. Subsystem id are added overtime as we add forms to our system.
            queryList = session.createQuery(
                    "from SystemProperty sp where sp.systemPropertyScope = :systemPropertyScope order by sp.systemPropertyName Asc").
                        setParameter("systemPropertyScope", "tomcat").
                        list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("SystemProperty loaded: " + queryList.size());
            }

            for(int i=0;i < queryList.size();i++) {
                logger.info("In SystemProperty: " + ((SystemProperty)queryList.get(i)).getSystemPropertyName());
            }

            HibernateUtil.commitTransaction();

        } catch (HibernateException ex) {
            HibernateUtil.rollbackTransaction();
            ex.printStackTrace();
        } finally {
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public String getValue(String propertyName) {
        String propertyValue = "";

        for(int i=0;i < queryList.size();i++) {
            if (((SystemProperty)queryList.get(i)).getSystemPropertyName().trim().equalsIgnoreCase(propertyName)) {
                propertyValue=((SystemProperty)queryList.get(i)).getSystemPropertyValue();
                break;
            }
        }

        return propertyValue;
    }
}
