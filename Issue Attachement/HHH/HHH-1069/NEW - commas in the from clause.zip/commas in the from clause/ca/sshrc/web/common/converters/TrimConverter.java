package ca.sshrc.web.common.converters;

import javax.faces.component.*;
import javax.faces.context.*;
import javax.faces.convert.*;

public class TrimConverter implements Converter {
    public Object getAsObject(FacesContext context, UIComponent component, String string) {
        return string == null ? null : string.trim();
    }

    public String getAsString(FacesContext context, UIComponent component, Object object) {
        return object == null ? null : object.toString();
    }
}
