package ca.sshrc.web.lookupCache;


import java.io.Serializable;

public class OrganizationBean implements Serializable {
    private Integer orgId;
    private int orgCategoryCode;
    private Integer countryCode;
    private String provinceStateCode;
    private String nameEnglish;
    private String nameFrench;
    private String countryNameEnglish;
    private String countryNameFrench;

    public OrganizationBean(Integer orgId, int orgCategoryCode, Integer countryCode, String provinceStateCode,
                            String nameEnglish, String nameFrench, String countryNameEnglish,
                            String countryNameFrench) {
        this.orgId = orgId;
        this.orgCategoryCode = orgCategoryCode;
        this.countryCode = countryCode;
        this.provinceStateCode = provinceStateCode;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.countryNameEnglish = countryNameEnglish;
        this.countryNameFrench = countryNameFrench;
    }

    /* Setters */
    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public void setOrgCategoryCode(int orgCategoryCode) {
        this.orgCategoryCode = orgCategoryCode;
    }

    public void setCountryCode(Integer countryCode) {
        this.countryCode = countryCode;
    }

    public void setProvinceStateCode(String provinceStateCode) {
        this.provinceStateCode = provinceStateCode;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    public void setCountryNameEnglish(String countryNameEnglish) {
        this.countryNameEnglish = countryNameEnglish;
    }

    public void setCountryNameFrench(String countryNameFrench) {
        this.countryNameFrench = countryNameFrench;
    }

    /* Getters */
    public Integer getOrgId() {
        return this.orgId;
    }

    public int getOrgCategoryCode() {
        return this.orgCategoryCode;
    }

    public Integer getCountryCode() {
        return this.countryCode;
    }

    public String getProvinceStateCode() {
        return this.provinceStateCode;
    }

    public String getNameEnglish() {
        return this.nameEnglish;
    }

    public String getNameFrench() {
        return this.nameFrench;
    }

    public String getCountryNameEnglish() {
        return this.countryNameEnglish;
    }

    public String getCountryNameFrench() {
        return this.countryNameFrench;
    }
}
