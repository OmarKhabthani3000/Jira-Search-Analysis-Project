package ca.sshrc.web.forms.portFolio;

import java.util.*;

import org.hibernate.*;
import org.apache.log4j.*;
import ca.sshrc.web.common.services.*;

public class PortFolioCVDBA {
    private Logger logger = Logger.getLogger(PortFolioCVDBA.class.getName());
    private List list;

    public List queryPortFolio(ca.sshrc.web.logon.LogonBean logonBean, Integer subSystemId) {
        Integer CVSubSystemId = new Integer(1);

        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // RDC CV Sub is 22
            if (subSystemId.intValue() == 23) {
                CVSubSystemId = new Integer(22);
            }

            list = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.portFolio.PortFolioBean( Form.person.cid, " +
                    "Form.webSubsystem.subsystemId, " +
                    "Form.formStatus, " +
                    "Form.formLanguage, " +
                    "Form.changeDate, " +
                    "Form.formId, " +
                    "Form.application.applId) " +
                    "from Form Form " +
                    "WHERE ( Form.person.cid = :webid ) and " +
                    "( Form.webSubsystem.subsystemId = :subsystemid )" +
                    "order by 1 ASC, 2 ASC ")
                   .setParameter("webid", logonBean.getWeb_id())
                   .setParameter("subsystemid", CVSubSystemId)
                   .list();


            HibernateUtil.commitTransaction();
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        return list;
    }
}
