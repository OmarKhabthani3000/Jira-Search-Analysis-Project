package ca.sshrc.web.logon;

import java.util.*;

import javax.faces.context.*;
import javax.servlet.http.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.util.*;
import ca.sshrc.web.lookupCache.*;
import hibernate.*;
import org.hibernate.*;
import org.apache.log4j.*;

public class LogonDBA {
    private Logger logger = Logger.getLogger(LogonDBA.class.getName());

    public LogonDBA() {
    }

    /**
     * This method is used to validate a user id and password. The validation DOES NOT
     * verify is the account is in good standing (i.e.: Lock or password expired).
     * This is used by the Password Change page.
     *
     * @param web_id Integer
     * @param password String
     * @return String
     */
    public String validateAccessRight(Integer web_id, String password) {
        String outcome = Constants.FAILURE_OUTCOME;
        int secProfileCount = 0;
        SecurityProfile secProfile = null;

        if (web_id != null && password != null) {
            if (web_id.intValue() > 0 && password.trim() != "") {
                logger.info("LogonDBA.validateAccessRight(" + web_id + ")");
                Session session = HibernateUtil.getSession();
                HibernateUtil.beginTransaction();

                // Get security profile
                Query query = null;
                try {
                    query = session.createQuery(
                            "select SecProf from SecurityProfile as SecProf where SecProf.cid = :cid");
                    query.setLong("cid", web_id.longValue());

                    // Iterate the result set
                    for (Iterator it = query.iterate(); it.hasNext(); ) {
                        secProfileCount++;
                        secProfile = (SecurityProfile) it.next();
                        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                            logger.info("Found SecurityProfile for cid : " + secProfile.getCid());
                        }
                    }

                    // If only one profile for webId, keep going...
                    if (secProfileCount == 1) {
                        // User's legitimate ... Validate password
                        if (secProfile.getCurrentPassword().trim().equalsIgnoreCase(password)) {
                            outcome = Constants.SUCCESS_OUTCOME;
                        }
                    }

                    HibernateUtil.commitTransaction();

                } catch (HibernateException e) {
                    HibernateUtil.rollbackTransaction();
                    outcome = Constants.DB_ERROR_OUTCOME;
                    e.printStackTrace();

                } catch (Exception e) {
                    outcome = Constants.SYSTEM_ERROR_OUTCOME;
                    e.printStackTrace();

                } finally {
                    try {
                        HibernateUtil.closeSession();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }

            }
        }
        return outcome;
    }


    /**
     * This method is used when a user is trying to log in the system.
     *
     * @param logon LogonBean
     * @return String
     */
    public String validateAccessRight(LogonBean logon) {

        String outcome = Constants.FAILURE_OUTCOME;

        int secProfileCount = 0;
        Integer maxLogonAttempt = Constants.MAX_LOGON_ATTEMPT;
        Integer daysBetweenPasswordChange = Constants.DAYS_BETWEEN_PASSWORD_CHANGE;

        Calendar nextPasswordChange = Calendar.getInstance(TimeZone.getDefault());

        SecurityProfile secProfile = null;
        CacheService cacheManager = null;

        try {

            // Get max_login_attempt and days_between_password_change from System Property Cache
            cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
            try {
                maxLogonAttempt = new Integer(((SystemPropertyCache) cacheManager.get("SystemPropertyCache")).
                                              getValue("max_login_attempt"));
                daysBetweenPasswordChange = new Integer(((SystemPropertyCache) cacheManager.get(
                        "SystemPropertyCache")).getValue("days_between_password_change"));

            } catch (NumberFormatException e) {
                // If conversion problem occurs, revert to default values
                maxLogonAttempt = Constants.MAX_LOGON_ATTEMPT;
                daysBetweenPasswordChange = Constants.DAYS_BETWEEN_PASSWORD_CHANGE;
                logger.error(
                        "LogonDBA.validateAccessRight - Datatype conversion error - maxLogonAttempt - String to Integer");
                logger.error(
                        "LogonDBA.validateAccessRight - Datatype conversion error - daysBetweenPasswordChange - String to Integer");
            }

            logger.info("LogonDBA.validateAccessRight(" + logon.getWeb_id() + ")");
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // Get security profile
            Query query = session.createQuery(
                    "select SecProf from SecurityProfile as SecProf where SecProf.cid = :cid");
            query.setLong("cid", logon.getWeb_id().longValue());

            // Iterate the result set
            for (Iterator it = query.iterate(); it.hasNext(); ) {
                secProfileCount++;
                secProfile = (SecurityProfile) it.next();
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("Found SecurityProfile for cid : " + secProfile.getCid());
                }
            }

            // If only one profile for webId, keep going...
            if (secProfileCount == 1) {
                // User's legitimate ... Validate password
                if (secProfile.getCurrentPassword().trim().equalsIgnoreCase(logon.getPassword())) {
                    // Password valide... Check if account is locked
                    if (secProfile.getProfileLockIndicator().equalsIgnoreCase("N")) {
                        // Account's not locked...Update successful logon info

                        // Access count
                        secProfile.setAccessCount(new Integer(secProfile.getAccessCount().intValue() + 1));

                        // Last access date
                        Calendar calTemp = Calendar.getInstance(TimeZone.getDefault());
                        secProfile.setLastAccessDatetime(calTemp.getTime());

                        // Reset invalid password attempt counter
                        secProfile.setInvalidPasswordAttempts(new Short("0"));

                        // Browser version
                        HttpServletRequest httpRequest = (HttpServletRequest) FacesContext.
                                getCurrentInstance().
                                getExternalContext().getRequest();

                        secProfile.setBrowserVersion(httpRequest.getHeader("User-Agent"));

                        // Get the date the next password change is required - daysBetweenPasswordChange number of days after the last password change
                        nextPasswordChange.setTime(secProfile.getLastPasswordChangeDatetime());
                        nextPasswordChange.add(Calendar.DATE, daysBetweenPasswordChange.intValue()); // add number of days between password change

                        // Reset calTemp to system date
                        calTemp = Calendar.getInstance(TimeZone.getDefault());

                        if (calTemp.getTimeInMillis() > nextPasswordChange.getTimeInMillis()) {
                            outcome = Constants.ACCOUNT_PASSWORD_EXPIRED_OUTCOME;
                        } else {
                            outcome = Constants.SUCCESS_OUTCOME;
                        }

                        // Get user's form language setting
                        query = session.createQuery("from Person where cid = :cid");
                        query.setLong("cid", logon.getWeb_id().longValue());

                        if (query.list().size() == 1) {
                            // Convert previous system's language value into valid Locale value
                            // before setting the logonBean site language attribute
                            if (((Person) query.iterate().next()).getCorrespondenceLanguageCode().
                                equalsIgnoreCase("f")) {
                                logon.setSiteLanguageAtLogon(Constants.FRENCH_CANADIAN_LOCALE);
                            } else {
                                logon.setSiteLanguageAtLogon(Constants.ENGLISH_CANADIAN_LOCALE);
                            }
                        } else {
                            logon.setSiteLanguageAtLogon(Constants.ENGLISH_CANADIAN_LOCALE);
                        } // Default to English
                    } else {
                        outcome = Constants.ACCOUNT_LOCKED_OUTCOME;
                    }
                } else {
                    // Increment invalid password attempt and or Lock indicator if necessary
                    secProfile.increaseInvalidPasswordAttempts();

                    // Last access date
                    Calendar cal = Calendar.getInstance(TimeZone.getDefault());
                    secProfile.setLastAccessDatetime(cal.getTime());

                    if (secProfile.getInvalidPasswordAttempts().intValue() > maxLogonAttempt.intValue()) {
                        secProfile.setProfileLockIndicator("Y");
                        outcome = Constants.ACCOUNT_LOCKED_OUTCOME;
                    }

                }

                // Send changes to DB
                session.saveOrUpdate(secProfile);
                session.flush();

            } else { // If more then one profile for webId, refuse access and generate error log

                outcome = Constants.FAILURE_OUTCOME;

                if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                    logger.error("Duplicate SecurityProfile for cid : " + secProfile.getCid());
                    throw new Exception("Duplicate SecurityProfile for cid : " + secProfile.getCid());
                }
            }

            HibernateUtil.commitTransaction();

        } catch (HibernateException e) {
            HibernateUtil.rollbackTransaction();
            outcome = Constants.DB_ERROR_OUTCOME;
            e.printStackTrace();

        } catch (Exception e) {
            outcome = Constants.SYSTEM_ERROR_OUTCOME;
            e.printStackTrace();

        } finally {
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return outcome;
    }

}
