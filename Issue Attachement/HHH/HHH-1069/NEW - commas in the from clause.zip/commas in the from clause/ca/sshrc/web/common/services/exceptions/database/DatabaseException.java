package ca.sshrc.web.common.services.exceptions.database;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Social Sciences and Humanities Research Council of Canada</p>
 * @author Pierre Mass�
 * @version 1.0
 */

public class DatabaseException extends Exception {
    public DatabaseException() {
        super();
        }

    public DatabaseException(String message) {
        super(message);
    }
}

