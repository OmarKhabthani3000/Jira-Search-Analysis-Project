package ca.sshrc.web.forms.beans.programs;

import java.lang.reflect.*;
import java.util.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.*;
import hibernate.*;
import org.apache.commons.beanutils.*;
import org.apache.log4j.*;
import org.hibernate.*;

public class ThemeBean extends BeanBase {
    private Logger logger = Logger.getLogger(ThemeBean.class.getName());

    private Integer themeId;
    private Short rank;
    private Date changeDate;
    private Integer subThemeCode = new Integer(0);
    private Integer themeCode = new Integer(0);
    private Integer applId;
    private Cod codBySubThemeCode = new Cod();
    private Cod codByThemeCode = new Cod();


    public ThemeBean() {
        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("ThemeBean.constructor");
        }
        /**
         * Only retrieve the data if the current phase is Render Response phase.
         * (There's no need to retrieve during the Restore View phase).
         * */
        if (this.getFacesContext().getRenderResponse()) {
            try {
                // Get a session
                Session session = HibernateUtil.getSession();
                HibernateUtil.beginTransaction();

                // Call this object's retrieve method
                this.retrieve(new Long(0), session);

            } catch (Exception ex) {
                HibernateUtil.closeSession();
                ex.printStackTrace();
            } finally {
                // Close the Hibernate connection
                try {
                    HibernateUtil.commitTransaction();
                    HibernateUtil.closeSession();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }

    }

    public ThemeBean(Integer themeId, Integer applId, Cod codByThemeCode, Short rank, Cod codBySubThemeCode, Date changeDate) {
        this.themeId = themeId;
        this.applId = applId;
        this.codByThemeCode = codByThemeCode;
        this.rank = rank;
        this.codBySubThemeCode = codBySubThemeCode;
        this.changeDate = changeDate;
    }

    public void setThemeId(Integer themeId) {
        this.themeId = themeId;
    }

    public void setRank(Short rank) {
        this.rank = rank;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public void setSubThemeCode(Integer subThemeCode) {
        this.codBySubThemeCode.setCode(subThemeCode);
    }

    public void setThemeCode(Integer themeCode) {
        this.codByThemeCode.setCode(themeCode);
    }

    public void setApplId(Integer applId) {
        this.applId = applId;
    }

    public void setCodBySubThemeCode(Cod codBySubThemeCode) {
        this.codBySubThemeCode = codBySubThemeCode;
    }

    public void setCodByThemeCode(Cod codByThemeCode) {
        this.codByThemeCode = codByThemeCode;
    }

    public Integer getThemeId() {
        return themeId;
    }

    public Short getRank() {
        return rank;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public Integer getSubThemeCode() {
        if (null == codBySubThemeCode) {
            return new Integer(0);
        } else {
            return codBySubThemeCode.getCode();
        }
    }

    public Integer getThemeCode() {
        if (null == codByThemeCode) {
            return new Integer(0);
        } else {
            return codByThemeCode.getCode();
        }
    }

    public Integer getApplId() {
        return applId;
    }

    public Cod getCodBySubThemeCode() {
        return codBySubThemeCode;
    }

    public Cod getCodByThemeCode() {
        return codByThemeCode;
    }

    // Overwrite ancestor method
    public void retrieve(Session session) {
        retrieve(new Long(0), session);
    }


    public void retrieve(Long formId, Session session) {
        Logger logger = Logger.getLogger(ThemeBean.class.getName());
        List queryList;

        if (null == session) {
            if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                logger.error("Cannot load ThemeBean - Session is null");
                return;
            }
        }

        // If the passed form id is 0, get the form id from the NavigationBean
        if (formId.longValue() == 0) {
            formId = new Long(getNavigationBean().getForm_id());
            if (formId.longValue() == 0) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.error("Cannot load ThemeBean - no FormId : " + formId);
                    return;
                }
            } else {
                logger.info("ThemeBean.retrieve using navigationBean FormId : " + formId);
            }

        } else {
            logger.info("ThemeBean.retrieve using passed parm FormId : " + formId);
        }

        // Retrieve data
        try {
            logger.info("In ThemeBean.retrieve()");
            /** Original retrieval SQL from PB
             *
             * SELECT  APPL_THEMES.Theme_ID ,
                        APPL_THEMES.Appl_ID ,
                        APPL_THEMES.Theme_Code ,
                        APPL_THEMES.Rank ,
                        APPL_THEMES.Sub_Theme_Code
                     FROM APPL_THEMES
                     WHERE ( APPL_THEMES.Appl_ID = :an_appl_id )

             */
            queryList = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.programs.ThemeBean(ApplIneThem.themeId, Application.applId, " +
                    "ApplIneThem.codByThemeCode, " +
                    "ApplIneThem.rank, " +
                    "ApplIneThem.codBySubThemeCode, " +
                    "ApplIneThem.changeDate) " +
                    "from Form Form, Application Application, ApplIneThem ApplIneThem " +
                    "where (Form.formId = :formId) and (Form.application.applId = Application.applId) and " +
                    "(Application.applId = ApplIneThem.applId)")
                        .setParameter("formId", formId)
                        .list();

            if (queryList.size() > 0) {
                this.loadData((ThemeBean) queryList.get(0));
            }

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded ThemeBean : " + queryList.size());
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void loadData(ThemeBean bean) {

        // Set values
        try {
            // PropertyUtils.copyProperties(destination, source)
            PropertyUtils.copyProperties(this, bean);

        } catch (NoSuchMethodException ex) {
            ex.printStackTrace();
        } catch (InvocationTargetException ex) {
            ex.printStackTrace();
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
        }

    }
    public String save(Session session) throws HibernateException, Exception {
        Logger logger = Logger.getLogger(ThemeBean.class.getName());
        List queryList;
        String saveOutcome = Constants.UPDATE_ERROR_OUTCOME; // Defaults to update error

        /**
         * Save data
         * */
        logger.info("saving ThemeBean data");
        queryList = session.createQuery("from ApplIneThem ApplIneThem " +
                                        "where ApplIneThem.applId = :applId")
                    .setParameter("applId", this.applId)
                    .list();

        logger.info("Retrieved hibernate.ApplIneThem object for Appl.Id: " +
                    this.applId);

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Loaded hibernate.ApplIneThem objects : " + queryList.size());
        }

        if (queryList.size() > 0) {
            // Set values
            ApplIneThem myApplIneThem = (ApplIneThem) queryList.get(0);

            // Check for stale data (BaseBean method - first param is DB date, second param is Web date)
            if (!isStaleData(myApplIneThem.getChangeDate(), this.getChangeDate())) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("ApplIneThem - Not Stale data");
                }
                // Save to DB
                PropertyUtils.copyProperties(myApplIneThem, this);
                session.saveOrUpdate(myApplIneThem);
                session.flush();
                session.refresh(myApplIneThem);

                // Refresh This.Bean
                PropertyUtils.copyProperties(this, myApplIneThem);

                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("ApplIneThem - refreshing Web date : " + this.getChangeDate());
                    logger.info("ApplIneThem - refreshing DB date : " + myApplIneThem.getChangeDate());
                }

                saveOutcome = saveOutcome;
            } else {
                logger.error("Stale data in ApplIneThem -  NOT Saving");
            }
        } else if (this.getNavigationBean().getFormModified().equalsIgnoreCase("Y")) {

            ApplIneThem myApplIneThem = new ApplIneThem();

            // Save to DB
            PropertyUtils.copyProperties(myApplIneThem, this);
            session.saveOrUpdate(myApplIneThem);
            session.flush();
            session.refresh(myApplIneThem);

            // Refresh Change_date on This.Bean
            this.setChangeDate(myApplIneThem.getChangeDate());
            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("ApplExpertise - refreshing Web date : " + this.getChangeDate());
                logger.info("ApplExpertise - refreshing DB date : " + myApplIneThem.getChangeDate());
            }

            saveOutcome = Constants.SUCCESS_OUTCOME;

        } else {
            saveOutcome = null; // return to same page
        }

        return Constants.SUCCESS_OUTCOME;
    }

}
