package ca.sshrc.web.common.services;

import java.text.*;
import java.util.*;

import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.lookupCache.*;
import javax.faces.application.FacesMessage;

public class ValidationMessage extends RootBase {
    private ArrayList messageList = new ArrayList();
    private boolean isfaces = false;
    private String resourceBundleName = null;
    private NavigationBarBean navigationBarBean = null;
    private String previuousModuleName = "";


    /**
     * Default constructor
     */
    public ValidationMessage() {
    }

    public ValidationMessage(boolean faces) {
        // If faces is true, this object will generate messages for the FacesMessage object
        // else it will generate messages for ValidationMessage object (this)
        this.isfaces = faces;
    }

    public void addMessage(String clientId, String message) {
        if (this.isfaces) {
            this.getFacesContext().addMessage(clientId, new FacesMessage(message));
        }
    }

    public void addMessage(Integer subsystemId, Integer moduleId, String moduleName, String message) {
        if (!isfaces) {

            // We don't want to see a module name appear more then once on the validationRoorList Jsp
            if (!previuousModuleName.equals("")) {
                if (previuousModuleName.equals(moduleName)) {
                    moduleName = "";
                } else {
                    previuousModuleName = moduleName;
                }
            } else {
                previuousModuleName = moduleName;
            }
            this.messageList.add(new ValidationMessageBean(subsystemId, moduleId, moduleName, message));
        }
    }

    public String getMessage(String moduleName) {
        String message = null;

        if (isfaces) {
            return message;
        }

        for (int x = 0; x < messageList.size(); x++) {
            if (((ValidationMessageBean) messageList.get(x)).getModuleName().equalsIgnoreCase(moduleName)) {
                message = ((ValidationMessageBean) messageList.get(x)).getMessage();
                break;
            }

        }
        return message;
    }

    public int getMessagesCount() {

        if (!isfaces) {
            if (this.messageList == null) {
                return 0;
            }
            return this.messageList.size();
        }

        // Return of facesMessages to be coded here

        return 0;
    }

    public ArrayList getMessageList() {
        return messageList;
    }

    public void setResourceBundleName(String resourceBundleName) {
        this.resourceBundleName = resourceBundleName;
    }

    public String getResourceBundleName() {
        return this.resourceBundleName;
    }

    public void setModuleNavigationBarBean(NavigationBarBean navigationBarBean) {
        this.navigationBarBean = navigationBarBean;
    }

    public NavigationBarBean getModuleNavigationBarBean() {
        return this.navigationBarBean;
    }

    public static String substituteParams(Locale locale, String msgtext, Object params[]) {
        String localizedStr = null;

        if (params == null || msgtext == null) {
            return msgtext;
        }
        StringBuffer b = new StringBuffer(100);
        MessageFormat mf = new MessageFormat(msgtext);
        if (locale != null) {
            mf.setLocale(locale);
            b.append(mf.format(params));
            localizedStr = b.toString();
        }
        return localizedStr;
    }

}
