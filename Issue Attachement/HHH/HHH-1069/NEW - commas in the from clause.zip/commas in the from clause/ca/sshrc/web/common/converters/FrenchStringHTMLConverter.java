package ca.sshrc.web.common.converters;

import javax.faces.component.*;
import javax.faces.context.*;
import javax.faces.convert.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class FrenchStringHTMLConverter implements Converter {

    public static final String CONVERTER_ID = "FrenchStringHTMLConverter";

    // Default constructor
    public FrenchStringHTMLConverter() {
    }

    /**
     * getAsObject is the method called by JSF when restoring the view
     *  */
    public Object getAsObject(FacesContext facesContext, UIComponent uIComponent, String string) {
        String returnedString = "";

        if (string == null)
        {return null;}

        returnedString = string.replaceAll("&apos;", "'");

        return returnedString;
    }

    /**
     * getAsString is the method called by JSF when rendering the view
     * */

    public String getAsString(FacesContext facesContext, UIComponent uIComponent, Object value) throws
            ConverterException {
        String returnedString = "";

        if (value == null) {
            return null;
        }

        if (value instanceof String) {
            returnedString = value.toString().replaceAll("'","&apos;");

            return returnedString;
        } else {
            throw new ConverterException(
                    "Incorrect type (" + value.getClass() +
                    "; value = " + value +
                    "); value must be a String instance");
        }
    }
}
