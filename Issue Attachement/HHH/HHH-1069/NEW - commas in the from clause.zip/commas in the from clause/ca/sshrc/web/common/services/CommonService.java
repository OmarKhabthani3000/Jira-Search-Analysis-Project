package ca.sshrc.web.common.services;


import java.util.*;

import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.*;
import ca.sshrc.web.lookupCache.*;
import org.hibernate.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class CommonService extends RootBase {
    public CommonService() {
    }

//    public static String getModuleRessourceFileName(Integer subSystemId)
    public static ArrayList getModuleBeanClass(Integer subSystemId, String moduleName) {
        CommonDBA commonDBA = new CommonDBA();

        return commonDBA.queryModuleBeanClass(subSystemId, moduleName);
    }

    public static ArrayList getModuleBeanClass(Integer subSystemId) {
        CommonDBA commonDBA = new CommonDBA();

        return commonDBA.queryModuleBeanClass(subSystemId);
    }

    public static String setFormStatus(Long formId, String status, String moduleName,
                                       Session hibernateSession) {
        CommonDBA commonDBA = new CommonDBA();

        return commonDBA.setFormStatus(formId, status, moduleName, hibernateSession);
    }

    /**
     * Validation method for Provinces
     *
     * @param provinceCode String
     * @return boolean
     */
    public static boolean isValidProvince(String provinceCode) {
        boolean isProvinceValid = false;

        if (provinceCode != null) {
            if (!provinceCode.trim().equals("")) {
                // Get province cache
                CacheService cacheManager = null;

                try {
                    cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
                    isProvinceValid = ((ProvinceCache) cacheManager.get("ProvinceCache")).isValidProvince(
                            provinceCode);

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }

        return isProvinceValid;
    }

    /**
     * Validation method for States
     *
     * @param stateCode String
     * @return boolean
     */
    public static boolean isValidState(String stateCode) {
        boolean isStateValid = false;

        if (stateCode != null) {
            if (!stateCode.trim().equals("")) {
                // Get state cache
                CacheService cacheManager = null;

                try {
                    cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
                    isStateValid = ((StateCache) cacheManager.get("StateCache")).isValidState(
                            stateCode);

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }

        return isStateValid;
    }

    /**
     * Validation method for email addresses
     *
     * @param emailAddress String
     * @param verifyUniqueness boolean
     * @return boolean
     */
    public static boolean isValidEmailAddress(String emailAddress, boolean verifyUniqueness) {

        boolean isEmailAddressValid = false;

        int posCharFound1;
        int posCharFound2;

        String trimmedAddress = emailAddress.trim();

        if (trimmedAddress != null) {
            if (!trimmedAddress.equals("")) {
                // Look for "@"
                posCharFound1 = trimmedAddress.indexOf("@");
                if (posCharFound1 < 0) { // "@" not found
                    return isEmailAddressValid;
                } else if (trimmedAddress.indexOf("@", posCharFound1 + 1) > 0) { // "@" found more then once
                    return isEmailAddressValid;
                }

                // Is there something in front of '@'
                if (posCharFound1 == 0) {
                    return isEmailAddressValid;
                }

                // Check for a '.' after the '@'
                posCharFound2 = trimmedAddress.indexOf(".", posCharFound1);
                if (posCharFound2 < 0) {
                    return isEmailAddressValid;
                }

                // Check for a space within the address
                posCharFound1 = trimmedAddress.indexOf(" ");
                if (posCharFound1 > -1) {
                    return isEmailAddressValid;
                }

                if (verifyUniqueness) {
                    // Query Person table using the email address
                    CommonDBA commonDBA = new CommonDBA();
                    if (commonDBA.isEmailAddressExist(trimmedAddress)) {
                        return isEmailAddressValid;
                    }
                }
            }
        } else {
            return isEmailAddressValid;
        }

        return true;
    }

    // Helper method to calculate the number of days between to dates
    public static Long daysBetweenDates(Calendar date1, Calendar date2) {
        final long msPerDay = 1000 * 60 * 60 * 24;

        final long date1Milliseconds = date1.getTime().getTime();
        final long date2Milliseconds = date2.getTime().getTime();
        final Long result = new Long((date1Milliseconds - date2Milliseconds) / msPerDay);

        return result;
    }

    /**
     * This method return's a subsystem's program id as recorded in the websubsystem table
     *
     * @param subSystemId Integer
     * @return int
     */
    public static int getProgramId(Integer subSystemId) {
        int programId = 0;

        if (subSystemId != null) {
            if (subSystemId.intValue() > 0) {
                // Get state cache
                CacheService cacheManager = null;

                try {
                    cacheManager = CacheService.getInstance(Constants.SYSTEM_CACHE_MANAGER);
                    programId = ((WebSubSystemCache) cacheManager.get("WebSubSystemCache")).getProgramId(
                           subSystemId);

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }

        return programId;
    }
}
