package ca.sshrc.web.lookupCache;

import java.io.*;
import java.text.*;
import java.util.*;

import ca.sshrc.web.common.services.*;
import hibernate.*;
import org.hibernate.*;
import org.apache.log4j.*;

public class StateCache implements Serializable {
    private Logger logger = Logger.getLogger(StateCache.class.getName());
    private List queryList;

    public StateCache() {
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In StateCache");

            queryList = session.createQuery(
                    "select new hibernate.ProvinceState(ProvinceState.provinceStateCode, " +
                    "ProvinceState.nameEnglish, " +
                    "ProvinceState.nameFrench, " +
                    "ProvinceState.sequenceNumber, " +
                    "ProvinceState.activeInd) " +
                    "from ProvinceState ProvinceState " +
                    "where ProvinceState.sequenceNumber = 0").list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("American States loaded: " + queryList.size());
            }

            HibernateUtil.commitTransaction();

        } catch (HibernateException ex) {
            HibernateUtil.rollbackTransaction();
            ex.printStackTrace();
        } finally {
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public static final Comparator nameEnglishOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            ProvinceState objComp1 = (ProvinceState) o1;
            ProvinceState objComp2 = (ProvinceState) o2;
            return myCollator.compare(objComp1.getNameEnglish(),
                                      objComp2.getNameEnglish());
        }
    };

    public static final Comparator nameFrenchOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            ProvinceState objComp1 = (ProvinceState) o1;
            ProvinceState objComp2 = (ProvinceState) o2;
            return objComp1.getNameFrench().compareTo(objComp2.getNameFrench());
        }
    };
    public List getList(String language) {
        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Sorting States");
        }

        // Keep the original array. Use a copy for sorting
        List listTemp;
        listTemp = queryList;

        if (language.equalsIgnoreCase("f")) {
            Collections.sort(listTemp, nameFrenchOrder);
        } else {
            Collections.sort(listTemp, nameEnglishOrder);
        }
        return listTemp;
    }
    // Scan state list to find a code
    public boolean isValidState(String stateCode) {
        boolean isValidState = false;
        for (int i = 0; i < queryList.size(); i++) {
            if (((hibernate.ProvinceState) queryList.get(i)).getProvinceStateCode().equals(stateCode)) {
                isValidState = true;
                break;
            }
        }

        return isValidState;
    }
}
