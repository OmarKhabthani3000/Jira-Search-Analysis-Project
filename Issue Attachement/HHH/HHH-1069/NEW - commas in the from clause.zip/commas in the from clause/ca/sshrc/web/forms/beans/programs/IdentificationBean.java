package ca.sshrc.web.forms.beans.programs;

import java.lang.reflect.*;
import java.util.*;
import java.util.regex.*;

import javax.faces.application.*;
import javax.faces.component.*;
import javax.faces.context.*;
import javax.faces.model.*;
import javax.faces.validator.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.*;
import org.hibernate.*;
import org.apache.commons.beanutils.*;
import org.apache.log4j.*;

public class IdentificationBean extends BeanBase {
    private Integer programId;
    private hibernate.Cod grantType;

    private Integer scholarType;

    /** ScholarshipType - Radio button code values and labels */
    private SelectItem[] scholarTypeStatusFrench = new SelectItem[] {new SelectItem(new Integer(167),
            "Ordinaire"), new SelectItem(new Integer(166), "Nouveau")};

    private SelectItem[] scholarTypeStatusEnglish = new SelectItem[] {new SelectItem(new Integer(167),
            "Regular"), new SelectItem(new Integer(166), "New")};


    private Integer scholarCategory;
    private hibernate.Committee committee;
    private String applTitle;
    private String letterOfIntentInd;

    private String fileNumber;
    private boolean fileNumberValidationError = false;

    private String finalReportInd;
    private hibernate.Cod activityType;
    private String keywords;
    private String awardStartYear;
    private String awardStartMonth;
    private String awardEndYear;
    private String awardEndMonth;
    private String activityLocation;
    private Integer activityScope;
    private String otherFundedInd;
    private String otherFundingOrgs;
    private String sshrcFundedProgram;
    private String sshrcFundedInd;
    private String otherActivity;

    private String completionDateYear;
    private boolean completionDateYearValidationError = false;
    private String completionDateMonth;
    private boolean completionDateMonthValidationError = false;

    private String completionDateDay;
    private Integer sequenceNumber;
    private Integer sshrcFundedProgramId;
    private Date changeDate;
    private Short competitionYear;
    private String departmentName;
    private String orgName;
    private hibernate.OrgDeptLocation orgDeptLocation;
    private hibernate.Organization organization;
    private Date applParticipationChangeDate;
    private String departmentNameEnglish;
    private String departmentNameFrench;
    private String organizationNameEnglish;
    private String organizationNameFrench;
    private String familyName;
    private String givenName;
    private String initials;
    private String committeeShortNameEnglish;
    private String committeeSshortNameFrench;
    private String programNameEnglish;
    private String programNameFrench;
    private String applicationActivityShortNameEnglish;
    private String applicationActivityShortNameFrench;
    private String grantTypeNameEnglish;
    private String grantTypeNameFrench;
    private Long formId;
    private String formLanguage;
    private hibernate.Cod supplement;
    private String supplementShortNameEnglish;
    private String supplementShortNameFrench;
    private Integer applId;


    // Default Constructor
    public IdentificationBean() {

        if (this.getFacesContext().getRenderResponse()) {
            try {
                // Get a session
                Session session = HibernateUtil.getSession();
                HibernateUtil.beginTransaction();

                // Call this object's retrieve method
                this.retrieve(0, session);

            } catch (Exception ex) {
                HibernateUtil.closeSession();
                ex.printStackTrace();
            } finally {
                // Close the Hibernate connection
                try {
                    HibernateUtil.commitTransaction();
                    HibernateUtil.closeSession();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

// Full constructor
    public IdentificationBean(Integer applId,
                              Integer programId,
                              hibernate.Cod grantType,
                              Integer scholarType,
                              Integer scholarCategory,
                              hibernate.Committee committee,
                              String applTitle,
                              String letterOfIntentInd,
                              String fileNumber,
                              String finalReportInd,
                              hibernate.Cod activityType,
                              String keywords,
                              String awardStartYear,
                              String awardStartMonth,
                              String awardEndYear,
                              String awardEndMonth,
                              String activityLocation,
                              Integer activityScope,
                              String otherFundedInd,
                              String otherFundingOrgs,
                              String sshrcFundedProgram,
                              String sshrcFundedInd,
                              String otherActivity,
                              String completionDateYear,
                              String completionDateMonth,
                              String completionDateDay,
                              Integer sequenceNumber,
                              Integer sshrcFundedProgramId,
                              Date changeDate,
                              Short competitionYear,
                              hibernate.Cod supplement,
                              String departmentName,
                              String orgName,
                              hibernate.OrgDeptLocation orgDeptLocation,
                              hibernate.Organization organization,
                              Date applParticipationChangeDate,
                              String departmentNameEnglish,
                              String departmentNameFrench,
                              String organizationNameEnglish,
                              String organizationNameFrench,
                              String familyName,
                              String givenName,
                              String initials,
                              String committeeShortNameEnglish,
                              String committeeSshortNameFrench,
                              String programNameEnglish,
                              String programNameFrench,
                              String applicationActivityShortNameEnglish,
                              String applicationActivityShortNameFrench,
                              String supplementShortNameEnglish,
                              String supplementShortNameFrench,
                              String grantTypeNameEnglish,
                              String grantTypeNameFrench,
                              Long formId,
                              String formLanguage) {

        this.applId = applId;
        this.programId = programId;
        this.grantType = grantType;
        this.scholarType = scholarType;
        this.scholarCategory = scholarCategory;
        this.committee = committee;
        this.applTitle = trim(applTitle);
        this.letterOfIntentInd = trim(letterOfIntentInd);
        this.fileNumber = trim(fileNumber);
        this.finalReportInd = trim(finalReportInd);
        this.activityType = activityType;
        this.keywords = trim(keywords);
        this.awardStartYear = trim(awardStartYear);
        this.awardStartMonth = trim(awardStartMonth);
        this.awardEndYear = trim(awardEndYear);
        this.awardEndMonth = trim(awardEndMonth);
        this.activityLocation = trim(activityLocation);
        this.activityScope = activityScope;
        this.otherFundedInd = trim(otherFundedInd);
        this.otherFundingOrgs = trim(otherFundingOrgs);
        this.sshrcFundedProgram = trim(sshrcFundedProgram);
        this.sshrcFundedInd = trim(sshrcFundedInd);
        this.otherActivity = trim(otherActivity);
        this.completionDateYear = trim(completionDateYear);
        this.completionDateMonth = trim(completionDateMonth);
        this.completionDateDay = trim(completionDateDay);
        this.sequenceNumber = sequenceNumber;
        this.sshrcFundedProgramId = sshrcFundedProgramId;
        this.changeDate = changeDate;
        this.competitionYear = competitionYear;
        this.departmentName = trim(departmentName);
        this.orgName = trim(orgName);
        this.orgDeptLocation = orgDeptLocation;
        this.organization = organization;
        this.applParticipationChangeDate = applParticipationChangeDate;
        this.departmentNameEnglish = trim(departmentNameEnglish);
        this.departmentNameFrench = trim(departmentNameFrench);
        this.organizationNameEnglish = trim(organizationNameEnglish);
        this.organizationNameFrench = trim(organizationNameFrench);
        this.familyName = trim(familyName);
        this.givenName = trim(givenName);
        this.initials = trim(initials);
        this.committeeShortNameEnglish = trim(committeeShortNameEnglish);
        this.committeeSshortNameFrench = trim(committeeSshortNameFrench);
        this.programNameEnglish = trim(programNameEnglish);
        this.programNameFrench = trim(programNameFrench);
        this.applicationActivityShortNameEnglish = trim(applicationActivityShortNameEnglish);
        this.applicationActivityShortNameFrench = trim(applicationActivityShortNameFrench);
        this.grantTypeNameEnglish = trim(grantTypeNameEnglish);
        this.grantTypeNameFrench = trim(grantTypeNameFrench);
        this.formId = formId;
        this.formLanguage = trim(formLanguage);
        this.supplement = supplement;
        this.supplementShortNameEnglish = supplementShortNameEnglish;
        this.supplementShortNameFrench = supplementShortNameFrench;
    }


    // Overwrite ancestor method
    public void retrieve(Session session) {
        retrieve(0, session);
    }

    public void retrieve(long formId, Session session) {
        Logger logger = Logger.getLogger(IdentificationBean.class.getName());
        List queryList;

        if (null == session) {
            if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                logger.error("Cannot load IdentificationBean - Session is null");
                return;
            }
        }

        // If the passed form id is 0, get the form id from the NavigationBean
        if (formId == 0) {
            formId = getNavigationBean().getForm_id();
            if (formId == 0) {
                if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                    logger.error("Cannot load IdentificationBean - no FormId : " + formId);
                    return;
                }
            } else {
                logger.info("IdentificationBean.retrieve using navigationBean FormId : " + formId);
            }

        } else {
            logger.info("IdentificationBean.retrieve using passed parm FormId : " + formId);
        }

        // Retrieve data
        try {
            logger.info("In IdentificationBean.retrieve()");

            /** Original SQL form PB d_appl_identification
             *
             * Scope of SQL was reduced to cover most programs.
             * Specific beans/SQL will have to be created for the other
             * cases like, for example, the Organization based applications.
             *
             * SELECT  APPLICATION.Program_ID ,
                       APPLICATION.Grant_Type ,
                       APPLICATION.Scholar_Type ,
                       APPLICATION.Scholar_Category ,
                       APPLICATION.Committee_ID ,
                       APPLICATION.Appl_Title ,
                       APPLICATION.Letter_Of_Intent_Ind ,
                       APPLICATION.File_number ,
                       APPLICATION.Final_Report_Ind ,
                       APPLICATION.Activity_Type ,
                       APPLICATION.Keywords ,
                       APPLICATION.Award_Start_Year ,
                       APPLICATION.Award_Start_Month ,
                       APPLICATION.Award_End_Year ,
                       APPLICATION.Award_End_Month ,
                       APPLICATION.Activity_Location ,
                       APPLICATION.Activity_Scope ,
                       APPLICATION.Other_Funded_Ind ,
                       APPLICATION.SSHRC_Funded_Program ,
                       APPLICATION.SSHRC_Funded_Ind ,
                       APPLICATION.Other_Funding_Orgs ,
                       APPLICATION.Other_Activity ,
                       APPLICATION.Completion_Date_Year ,
                       APPLICATION.Completion_Date_Month ,
                       APPLICATION.Completion_Date_Day ,
                       APPLICATION.Competition_Year ,
                       APPLICATION.Sequence_Number ,
                       APPLICATION.SSHRC_Funded_Program_ID ,
                       APPLICATION.Change_Date ,

                       APPL_PARTICIPATION.Department_Name ,
                       APPL_PARTICIPATION.Org_Name ,
                       APPL_PARTICIPATION.Org_Dept_Loc_ID ,
                       APPL_PARTICIPATION.Org_ID ,
                       APPL_PARTICIPATION.Change_Date ,

                       APPL_PARTICIPATION.Part_ID ,
                       APPL_PARTICIPATION.Address_Format_Type ,
                       APPL_PARTICIPATION.Address_1 ,
                       APPL_PARTICIPATION.Address_2 ,
                       APPL_PARTICIPATION.Address_3 ,
                       APPL_PARTICIPATION.Municipality ,
                       APPL_PARTICIPATION.Province_State_Code ,
                       APPL_PARTICIPATION.Country_Code ,
                       APPL_PARTICIPATION.Postal_Zip_Code ,
                       APPL_PARTICIPATION.Phone_Country_Code ,
                       APPL_PARTICIPATION.Phone_Area_Code ,
                       APPL_PARTICIPATION.Phone_Number ,
                       APPL_PARTICIPATION.Phone_Extension ,
                       APPL_PARTICIPATION.FAX_Country_Code ,
                       APPL_PARTICIPATION.FAX_Area_Code ,
                       APPL_PARTICIPATION.FAX_Number ,
                       APPL_PARTICIPATION.FAX_Phone_Extension ,
                       APPL_PARTICIPATION.EMail_Address ,
                       APPL_PARTICIPATION.Family_Name ,
                       APPL_PARTICIPATION.Given_Name ,
                       APPL_PARTICIPATION.Initials ,
                       APPL_PARTICIPATION.Address_4 ,
                       ORG_DEPT_LOCATION_a.Department_Name_English ,
                       ORG_DEPT_LOCATION_a.Department_Name_French ,
                       ORGANIZATION_a.Name_English ,
                       ORGANIZATION_a.Name_French ,
                       PERSON.Family_Name ,
                       PERSON.Given_Name ,
                       PERSON.Initials ,
                       COMMITTEE.Short_Name_English ,
                       COMMITTEE.Short_Name_French ,
                       PROGRAM.Name_English ,
                       PROGRAM.Name_French ,
                       CODES_a.Short_Name_English ,
                       CODES_a.Short_Name_French ,
                       CODES_b.Short_Name_English ,
                       CODES_b.Short_Name_French ,
                       COUNTRY.Name_English ,
                       COUNTRY.Name_French ,
                       CODES_a.Name_English ,
                       CODES_a.Name_French ,
                       case PERSON_POSITION.Org_Dept_Loc_ID when 2 then PERSON_POSITION.Other_Department_Name else ORG_DEPT_LOCATION_b.Department_Name_English end as person_dept_e,
                       case PERSON_POSITION.Org_Dept_Loc_ID when 2 then PERSON_POSITION.Other_Department_Name else ORG_DEPT_LOCATION_b.Department_Name_French end as person_dept_f,
                       case PERSON_POSITION.Org_ID when 1 then PERSON_POSITION.Other_Org_Name else ORGANIZATION_b.Name_English end as person_org_e,
                       case PERSON_POSITION.Org_ID when 1 then PERSON_POSITION.Other_Org_Name else ORGANIZATION_b.Name_French end as person_org_f,
                       (select appl_participation.data_centre_id
                           from appl_participation
                         where appl_participation.appl_id = :al_appl_id
                            and appl_participation.role_code = 147) as data_center_id,
                       FORMS.Form_Language ,
                       FORMS.Subsystem_ID
             FROM APPL_PARTICIPATION ,
                       APPLICATION ,
                       PERSON ,
                       ORG_DEPT_LOCATION ORG_DEPT_LOCATION_a ,
                       ORGANIZATION ORGANIZATION_a ,
                       COMMITTEE ,
                       PROGRAM ,
                       CODES CODES_a ,
                       CODES CODES_b ,
                       COUNTRY ,
                       PERSON_POSITION ,
                       ORG_DEPT_LOCATION ORG_DEPT_LOCATION_b ,
                       ORGANIZATION ORGANIZATION_b ,
                       FORMS
                     WHERE ( APPL_PARTICIPATION.Appl_ID =* APPLICATION.Appl_ID)
             and          ( ORG_DEPT_LOCATION_a.Org_Dept_Loc_ID =* APPL_PARTICIPATION.Org_Dept_Loc_ID)
                     and          ( COMMITTEE.Committee_ID =* APPLICATION.Committee_ID)
                     and          ( APPLICATION.Grant_Type *= CODES_a.Code)
                     and          ( APPLICATION.Program_ID *= PROGRAM.Program_ID)
                     and          ( ORGANIZATION_a.Org_ID =* APPL_PARTICIPATION.Org_ID)
                     and          ( APPLICATION.Activity_Type *= CODES_b.Code)
                     and          ( APPL_PARTICIPATION.Country_Code *= COUNTRY.Country_Code)
                     and          ( APPLICATION.Web_ID *= PERSON_POSITION.CID)
                     and          ( PERSON_POSITION.Org_Dept_Loc_ID *= ORG_DEPT_LOCATION_b.Org_Dept_Loc_ID)
                     and          ( PERSON_POSITION.Org_ID *= ORGANIZATION_b.Org_ID)
                     and          ( PERSON.CID = APPLICATION.Web_ID )
                     and          ( FORMS.CID = PERSON.CID )
                     and          ( FORMS.Appl_ID = APPLICATION.Appl_ID )
                     and          ( ( APPLICATION.Appl_ID = :al_appl_id )
                     And          ( APPL_PARTICIPATION.Role_Code = 155 )
                     and          ( PERSON_POSITION.Primary_Org_Ind = 'Y' )) **/

            queryList = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.programs.IdentificationBean(application.applId,  " +
                    "application.programId,  " +
                    "application.grantType, " +
                    "application.scholarType, " +
                    "application.scholarCategory, " +
                    "application.committee, " +
                    "application.applTitle, " +
                    "application.letterOfIntentInd, " +
                    "application.fileNumber, " +
                    "application.finalReportInd, " +
                    "application.activityType, " +
                    "application.keywords, " +
                    "application.awardStartYear, " +
                    "application.awardStartMonth, " +
                    "application.awardEndYear, " +
                    "application.awardEndMonth, " +
                    "application.activityLocation, " +
                    "application.activityScope, " +
                    "application.otherFundedInd, " +
                    "application.otherFundingOrgs, " +
                    "application.sshrcFundedProgram, " +
                    "application.sshrcFundedInd, " +
                    "application.otherActivity, " +
                    "application.completionDateYear, " +
                    "application.completionDateMonth, " +
                    "application.completionDateDay, " +
                    "application.sequenceNumber, " +
                    "application.sshrcFundedProgramId, " +
                    "application.changeDate, " +
                    "application.competitionYear, " +
                    "application.supplement, " +
                    "applparticipation.departmentName, " +
                    "applparticipation.orgName, " +
                    "applparticipation.orgDeptLocation, " +
                    "applparticipation.organization, " +
                    "applparticipation.changeDate, " +
                    "orgdeptlocation.departmentNameEnglish, " +
                    "orgdeptlocation.departmentNameFrench, " +
                    "organization.nameEnglish, " +
                    "organization.nameFrench, " +
                    "person.familyName, " +
                    "person.givenName, " +
                    "person.initials, " +
                    "committee.shortNameEnglish, " +
                    "committee.shortNameFrench, " +
                    "program.nameEnglish, " +
                    "program.nameFrench, " +
                    "codesApplicationActivity.shortNameEnglish, " +
                    "codesApplicationActivity.shortNameFrench, " +
                    "codesSupplement.shortNameEnglish, " +
                    "codesSupplement.shortNameFrench, " +
                    "codes.nameEnglish, " +
                    "codes.nameFrench, " +
                    "form.formId, " +
                    "form.formLanguage) " +
                    "from Form as form join form.application as application " +
                    "join fetch form.person as person " +
                    "left join fetch application.applParticipation as applparticipation " +
                    "left join fetch application.committee as committee " +
                    "left join fetch application.grantType as codes " +
                    "left join fetch application.supplement as codesSupplement " +
                    "left join fetch application.activityType as codesApplicationActivity " +
                    "left join fetch application.program as program " +
                    "left join fetch applparticipation.organization as organization " +
                    "left join fetch applparticipation.orgdeptlocation as orgdeptlocation " +
                    "where (form.formId = :formId) and " +
                    "(applparticipation.roleCode = 155)").setParameter("formId", new Long(formId)).list();

            /*
                                                    "from Application application, " +
                                                    "ApplParticipation applparticipation, " +
                                                    "OrgDeptLocation orgdeptlocation, " +
                                                    "Organization organization, " +
                                                    "Person person, " +
                                                    "Committee committee, " +
                                                    "Program program, " +
                                                    "Cod codesApplicationActivity, " +
                                                    "Cod codesSupplement, " +
                                                    "Cod codes, " +
                                                    "Form form " +
                                                    "where (form.formId = :formId) and " +
                                                    "(form.application.applId = application.applId) and " +
                                                    "(applparticipation.applId =* application.applId) and " +
                                                    "(applparticipation.roleCode = 155) and " +
             "(orgdeptlocation.orgDeptLocId =* applparticipation.orgDeptLocId) and " +
             "(committee.committeeId =* application.committeeId) and " +
                                                    "(application.grantType *= codes.code) and " +
                                                    "(application.programId *= program.programId) and " +
                                                    "(organization.orgId =* applparticipation.orgId) and " +
             "(application.activityType *= codesApplicationActivity.code) and " +
             "(application.supplementCode *= codesSupplement.code) and " +
             "(person.cid = application.webId)").setParameter("formId", new Long(formId)).list();

             */
            if (queryList.size() > 0) {
                // Set values
                try {
                    // PropertyUtils.copyProperties(destination, source)
                    PropertyUtils.copyProperties(this, (IdentificationBean) queryList.get(0));

                    // The following Catch need to be coded...
                } catch (NoSuchMethodException ex) {
                    ex.printStackTrace();
                } catch (InvocationTargetException ex) {
                    ex.printStackTrace();
                } catch (IllegalAccessException ex) {
                    ex.printStackTrace();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded IdentificationBean : " + queryList.size());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Save
     *
     * @param session Session
     * @return String
     * @throws HibernateException
     * @throws Exception
     */
    public String save(Session session) throws HibernateException, Exception {
        Logger logger = Logger.getLogger(IdentificationBean.class.getName());
        List queryList = null;
        String saveOutcome = Constants.UPDATE_ERROR_OUTCOME; // Defaults to update error
        int subSystemId = this.getNavigationBean().getRequestedSubsystemId().intValue();

        /**
         * Retrieve Application data
         * */
        logger.info("Saving Application - Retrieving data");
        if (null != this.getApplId()) {
            queryList = session.createQuery("from Application application " +
                                            "where application.applId = :applId")
                        .setParameter("applId", this.getApplId())
                        .list();

            logger.info("Retrieved hibernate.Application object for applId: " +
                        this.getApplId());

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded hibernate.Application objects : " + queryList.size());
            }
        }

        if (null != queryList && queryList.size() > 0) {
            // Set values
            hibernate.Application myApplication = (hibernate.Application) queryList.get(0);

            // Check for stale data (BaseBean method - first param is DB date, second param is Web date)
            if (!isStaleData(myApplication.getChangeDate(), this.getChangeDate())) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("Application - Not Stale data");
                }
                // Save to DB

                // BeanUtils.copyProperties(destination, source)
                BeanUtils.copyProperties(myApplication, this);
                session.saveOrUpdate(myApplication);
                session.flush();
                session.refresh(myApplication);

                // Refresh Change_date on This.Bean
                this.setChangeDate(myApplication.getChangeDate());
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("Application - refreshing Web date : " + this.getChangeDate());
                    logger.info("Application - refreshing DB date : " + myApplication.getChangeDate());
                }

                saveOutcome = Constants.SUCCESS_OUTCOME;
            } else {
                logger.error("Stale data in Application -  NOT Saving");
            }
        } else if (this.getNavigationBean().getFormModified().equalsIgnoreCase("Y")) {

            hibernate.Application myApplication = new hibernate.Application();
            // Save to DB

            // BeanUtils.copyProperties(destination, source)
            BeanUtils.copyProperties(myApplication, this);
            session.saveOrUpdate(myApplication);
            session.flush();
            session.refresh(myApplication);

            // Refresh Change_date on This.Bean
            this.setChangeDate(myApplication.getChangeDate());
            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Application - refreshing Web date : " + this.getChangeDate());
                logger.info("Application - refreshing DB date : " + myApplication.getChangeDate());
            }

            saveOutcome = Constants.SUCCESS_OUTCOME;

        } else {
            saveOutcome = null; // return to same page - To be changed if we want to route to error update page
        }

        /**
         *  Save participant data if Application saved successfully
         */
        if (saveOutcome.equalsIgnoreCase(Constants.SUCCESS_OUTCOME)) {
            // No organization to save if Final Research Report, Indirect Cost Request or Indirect Cost Outcomes Report
            if (subSystemId != 34 && subSystemId != 70 && subSystemId != 73) {

                logger.info("saving ApplParticipation data");
                if (null != this.getApplId()) {
                    queryList = session.createQuery("from ApplParticipation applParticipation " +
                            "where applParticipation.applId = :applId and applParticipation.roleCode in (147,155) order by applParticipation.roleCode")
                                .setParameter("applId", this.getApplId())
                                .list();

                    logger.info("Retrieved hibernate.ApplParticipation object for applId: " +
                                this.getApplId());

                    if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                        logger.info("Loaded hibernate.ApplParticipation objects : " + queryList.size());
                    }

                }

                if (null != queryList && queryList.size() > 0) {
                    // Set values
                    for (int i = 0; i < queryList.size(); i++) {
                        hibernate.ApplParticipation myApplParticipation = (hibernate.ApplParticipation)
                                queryList.
                                get(i);

                        // Check for stale data (BaseBean method - first param is DB date, second param is Web date)
                        // Only for the first row (i == 0) since the changeDate is updated by the trigger, and the trigger updates the
                        // changeDate for all applParticipation rows of an application (appl_id). After the first row is updated, every other
                        // rows changeDate, for the same application, are also updated.
                        if ((i == 0) &&
                            (isStaleData(myApplParticipation.getChangeDate(),
                                         this.getApplParticipationChangeDate()))) {
                            logger.error("Stale data in ApplParticipation -  NOT Saving");
                        } else {
                            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                                logger.info("ApplParticipation - Not Stale data");
                            }
                            // Save to DB

                            // BeanUtils.copyProperties(destination, source)
                            BeanUtils.copyProperties(myApplParticipation, this);
                            session.saveOrUpdate(myApplParticipation);
                            session.flush();
                            session.refresh(myApplParticipation);

                            // Refresh Change_date on This.Bean
                            if (i == 0) {
                                this.setApplParticipationChangeDate(myApplParticipation.getChangeDate());
                                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                                    logger.info("ApplParticipation - refreshing Web date : " +
                                                this.getApplParticipationChangeDate());
                                    logger.info("ApplParticipation - refreshing DB date : " +
                                                myApplParticipation.getChangeDate());
                                }
                            }
                            saveOutcome = Constants.SUCCESS_OUTCOME;
                        }
                    }
                }
            }
        }
        /**
         * Save Form data (if save Application saved successfully)
         * */
        if (saveOutcome.equalsIgnoreCase(Constants.SUCCESS_OUTCOME)) {
            logger.info("Saving Form data");
            logger.info("Retrieving hibernate.Form object for formId: " +
                        this.getFormId());
            queryList = session.createQuery("from Form form where form.formId = :formIdparm")
                        .setParameter("formIdparm", this.getFormId())
                        .list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded hibernate.Form objects : " + queryList.size());
            }

            if (queryList.size() > 0) {
                // Set values
                hibernate.Form myForm = (hibernate.Form) queryList.get(0);
                myForm.setFormLanguage(this.getFormLanguage());
                session.saveOrUpdate(myForm);
                saveOutcome = Constants.SUCCESS_OUTCOME;
            }
        }

        return saveOutcome;
    }

    public void setProgramId(Integer programId) {
        this.programId = programId;
    }

    public void setGrantType(hibernate.Cod grantType) {
        this.grantType = grantType;
    }

    public void setScholarType(Integer scholarType) {
        // default to 167 (Regular)
        if (null == scholarType) {
            this.scholarType = new Integer(167);
        }
        this.scholarType = scholarType;
    }

    public void setScholarCategory(Integer scholarCategory) {
        this.scholarCategory = scholarCategory;
    }

    public void setCommittee(hibernate.Committee committee) {
        this.committee = committee;
    }

    public void setApplTitle(String applTitle) {
        this.applTitle = applTitle;
    }

    public void setLetterOfIntentInd(String letterOfIntentInd) {
        this.letterOfIntentInd = letterOfIntentInd;
    }

    public void setFileNumber(String fileNumber) {
        this.fileNumber = fileNumber;
    }

    public void setFileNumberValidationError(boolean fileNumberValidationError) {
        this.fileNumberValidationError = fileNumberValidationError;
    }

    public void setFinalReportInd(String finalReportInd) {
        this.finalReportInd = finalReportInd;
    }

    public void setActivityType(hibernate.Cod activityType) {
        this.activityType = activityType;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public void setAwardStartYear(String awardStartYear) {
        this.awardStartYear = awardStartYear;
    }

    public void setAwardStartMonth(String awardStartMonth) {
        this.awardStartMonth = awardStartMonth;
    }

    public void setAwardEndYear(String awardEndYear) {
        this.awardEndYear = awardEndYear;
    }

    public void setAwardEndMonth(String awardEndMonth) {
        this.awardEndMonth = awardEndMonth;
    }

    public void setActivityLocation(String activityLocation) {
        this.activityLocation = activityLocation;
    }

    public void setActivityScope(Integer activityScope) {
        this.activityScope = activityScope;
    }

    public void setOtherFundedInd(String otherFundedInd) {
        this.otherFundedInd = otherFundedInd;
    }

    public void setOtherFundingOrgs(String otherFundingOrgs) {
        this.otherFundingOrgs = otherFundingOrgs;
    }

    public void setSshrcFundedProgram(String sshrcFundedProgram) {
        this.sshrcFundedProgram = sshrcFundedProgram;
    }

    public void setSshrcFundedInd(String sshrcFundedInd) {
        this.sshrcFundedInd = sshrcFundedInd;
    }

    public void setOtherActivity(String otherActivity) {
        this.otherActivity = otherActivity;
    }

    public void setCompletionDateYear(String completionDateYear) {
        this.completionDateYear = completionDateYear;
    }

    public void setCompletionDateMonth(String completionDateMonth) {
        this.completionDateMonth = completionDateMonth;
    }

    public void setCompletionDateDay(String completionDateDay) {
        this.completionDateDay = completionDateDay;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public void setSshrcFundedProgramId(Integer sshrcFundedProgramId) {
        this.sshrcFundedProgramId = sshrcFundedProgramId;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public void setCompetitionYear(Short competitionYear) {
        this.competitionYear = competitionYear;
    }

    public void setdepartmentName(String departmentName) {

        this.departmentName = departmentName;
    }

    public void setOrgName(String orgName) {

        this.orgName = orgName;
    }

    public void setOrgDeptLocation(hibernate.OrgDeptLocation orgDeptLocation) {
        this.orgDeptLocation = orgDeptLocation;
    }

    public void setOrganization(hibernate.Organization organization) {
        this.organization = organization;
    }

    public void setApplParticipationChangeDate(Date applParticipationChangeDate) {
        this.applParticipationChangeDate = applParticipationChangeDate;
    }

    public void setDepartmentNameLookupValue(String departmentName) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setDepartmentNameFrench(departmentName);
        } else {
            this.setDepartmentNameEnglish(departmentName);
        }
    }

    public void setDepartmentNameEnglish(String departmentNameEnglish) {
        this.departmentNameEnglish = departmentNameEnglish;
    }

    public void setDepartmentNameFrench(String departmentNameFrench) {
        this.departmentNameFrench = departmentNameFrench;
    }

    public void setOrganizationName(String organizationName) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setOrganizationNameFrench(organizationName);
        } else {
            this.setOrganizationNameEnglish(organizationName);
        }

    }

    public void setOrganizationNameEnglish(String organizationNameEnglish) {
        this.organizationNameEnglish = organizationNameEnglish;
    }

    public void setOrganizationNameFrench(String organizationNameFrench) {
        this.organizationNameFrench = organizationNameFrench;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public void setCommitteeShortName(String organizationName) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setCommitteeShortNameFrench(organizationName);
        } else {
            this.setCommitteeShortNameEnglish(organizationName);
        }
    }

    public void setCommitteeShortNameEnglish(String committeeShortNameEnglish) {
        this.committeeShortNameEnglish = committeeShortNameEnglish;
    }

    public void setCommitteeShortNameFrench(String committeeSshortNameFrench) {
        this.committeeSshortNameFrench = committeeSshortNameFrench;
    }

    public void setProgramNameEnglish(String programNameEnglish) {
        this.programNameEnglish = programNameEnglish;
    }

    public void setProgramNameFrench(String programNameFrench) {
        this.programNameFrench = programNameFrench;
    }

    public void setApplicationActivityName(String activityName) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setApplicationActivityShortNameFrench(activityName);
        } else {
            this.setApplicationActivityShortNameEnglish(activityName);
        }
    }

    public void setApplicationActivityShortNameEnglish(String applicationActivityShortNameEnglish) {
        this.applicationActivityShortNameEnglish = applicationActivityShortNameEnglish;
    }

    public void setApplicationActivityShortNameFrench(String applicationActivityShortNameFrench) {
        this.applicationActivityShortNameFrench = applicationActivityShortNameFrench;
    }

    public void setGrantTypeNameEnglish(String grantTypeNameEnglish) {
        this.grantTypeNameEnglish = grantTypeNameEnglish;
    }

    public void setGrantTypeNameFrench(String grantTypeNameFrench) {
        this.grantTypeNameFrench = grantTypeNameFrench;
    }

    public void setFormId(Long formId) {
        this.formId = formId;
    }

    public void setFormLanguage(String formLanguage) {
        /** If user's changing the form language, implement the change in the navigationBean
         * so that the next time a form page is displayed, it will be in the newly selected language
         */
        if (formLanguage.equalsIgnoreCase("f")) {
            this.getNavigationBean().setFormLanguage(Constants.FRENCH_CANADIAN_LOCALE);
        } else {
            this.getNavigationBean().setFormLanguage(Constants.ENGLISH_CANADIAN_LOCALE);
        }

        this.formLanguage = formLanguage;
    }

    public void setSupplement(hibernate.Cod supplement) {
        this.supplement = supplement;
    }

    public void setSupplementShortName(String organizationName) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setSupplementShortNameFrench(organizationName);
        } else {
            this.setSupplementShortNameEnglish(organizationName);
        }
    }

    public void setSupplementShortNameEnglish(String supplementShortNameEnglish) {
        this.supplementShortNameEnglish = supplementShortNameEnglish;
    }

    public void setSupplementShortNameFrench(String supplementShortNameFrench) {
        this.supplementShortNameFrench = supplementShortNameFrench;
    }

    public void setApplId(Integer applId) {
        this.applId = applId;
    }

    public Integer getProgramId() {
        return programId;
    }

    public hibernate.Cod getGrantType() {
        return grantType;
    }

    public Integer getScholarType() {
        return scholarType;
    }

    public SelectItem[] getScholarShipStatusItems() {

        if (this.getFormLanguage() != null) {
            if (this.getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
                return this.scholarTypeStatusFrench;
            } else {
                return this.scholarTypeStatusEnglish;
            }
        } else {
            return this.scholarTypeStatusEnglish;
        }
    }

    public Integer getScholarCategory() {
        return scholarCategory;
    }

    public hibernate.Committee getCommittee() {
        return committee;
    }

    public String getApplTitle() {
        return applTitle;
    }

    public String getLetterOfIntentInd() {
        return letterOfIntentInd;
    }

    public String getComputedFileNumber() {
        String fileNumber = "";

        // File Number
        if (null != this.getProgramId() && this.getProgramId().intValue() > 0) {
            fileNumber = this.getProgramId().toString();
        }

        if (null != this.getCompetitionYear() && this.getCompetitionYear().intValue() > 0) {
            fileNumber += "-" + this.getCompetitionYear();
        } else {
            fileNumber += " ";
        }

        if (null != this.getSequenceNumber() && this.getSequenceNumber().intValue() > 0) {
            fileNumber += "-" + this.getSequenceNumber();
        } else {
            fileNumber += "";
        }

        return fileNumber;
    }

    public String getFileNumber() {
        return fileNumber;
    }

    public boolean getFileNumberValidationError() {
        return fileNumberValidationError;
    }

    public String getFinalReportInd() {
        return finalReportInd;
    }

    public hibernate.Cod getActivityType() {
        if (null == activityType) {
            activityType = new hibernate.Cod();
        }
        return activityType;
    }

    public String getKeywords() {
        return keywords;
    }

    public String getAwardStartYear() {
        return awardStartYear;
    }

    public String getAwardStartMonth() {
        return awardStartMonth;
    }

    public String getAwardEndYear() {
        return awardEndYear;
    }

    public String getAwardEndMonth() {
        return awardEndMonth;
    }

    public String getActivityLocation() {
        return activityLocation;
    }

    public Integer getActivityScope() {
        return activityScope;
    }

    public String getOtherFundedInd() {
        return otherFundedInd;
    }

    public String getOtherFundingOrgs() {
        return otherFundingOrgs;
    }

    public String getSshrcFundedProgram() {
        return sshrcFundedProgram;
    }

    public String getSshrcFundedInd() {
        return sshrcFundedInd;
    }

    public String getOtherActivity() {
        return otherActivity;
    }

    public String getCompletionDateYear() {
        return completionDateYear;
    }

    public boolean getCompletionDateYearValidationError() {
        return completionDateYearValidationError;
    }


    public String getCompletionDateMonth() {
        return completionDateMonth;
    }

    public boolean getCompletionDateMonthValidationError() {
        return completionDateMonthValidationError;
    }

    public String getCompletionDateDay() {
        return completionDateDay;
    }

    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    public Integer getSshrcFundedProgramId() {
        return sshrcFundedProgramId;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public Short getCompetitionYear() {
        return competitionYear;
    }

    public String getDepartmentName() {

        return departmentName;
    }

    public String getOrgName() {

        return orgName;
    }

    public hibernate.OrgDeptLocation getOrgDeptLocation() {
        if (null == orgDeptLocation) {
            orgDeptLocation = new hibernate.OrgDeptLocation();
        }
        return orgDeptLocation;
    }

    public hibernate.Organization getOrganization() {
        if (null == organization) {
            organization = new hibernate.Organization();
        }
        return organization;
    }

    public Date getApplParticipationChangeDate() {
        return applParticipationChangeDate;
    }

    public String getDepartmentNameLookupValue() {
        String name = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.departmentNameFrench != null) {
                name = this.departmentNameFrench;
            }
        } else if (this.departmentNameEnglish != null) {
            name = this.departmentNameEnglish;
        }
        return name;
    }

    public String getDepartmentNameEnglish() {
        return departmentNameEnglish;
    }

    public String getDepartmentNameFrench() {
        return departmentNameFrench;
    }

    public String getOrganizationName() {
        String name = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.organizationNameFrench != null) {
                name = this.organizationNameFrench;
            }
        } else if (this.organizationNameEnglish != null) {
            name = this.organizationNameEnglish;
        }
        return name;
    }

    public String getOrganizationNameEnglish() {
        return organizationNameEnglish;
    }

    public String getOrganizationNameFrench() {
        return organizationNameFrench;
    }

    public String getFamilyName() {
        return familyName;
    }

    public String getGivenName() {
        return givenName;
    }

    public String getInitials() {
        return initials;
    }

    public String getCommitteeShortName() {
        String name = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.committeeSshortNameFrench != null) {
                name = this.committeeSshortNameFrench;
            }
        } else if (this.committeeShortNameEnglish != null) {
            name = this.committeeShortNameEnglish;
        }
        return name;
    }

    public String getCommitteeShortNameEnglish() {
        return committeeShortNameEnglish;
    }

    public String getCommitteeSshortNameFrench() {
        return committeeSshortNameFrench;
    }

    public String getProgramNameEnglish() {
        return programNameEnglish;
    }

    public String getProgramNameFrench() {
        return programNameFrench;
    }

    public String getApplicationActivityName() {
        String name = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.applicationActivityShortNameFrench != null) {
                name = this.applicationActivityShortNameFrench;
            }
        } else if (this.applicationActivityShortNameEnglish != null) {
            name = this.applicationActivityShortNameEnglish;
        }
        return name;
    }

    public String getApplicationActivityShortNameEnglish() {
        return applicationActivityShortNameEnglish;
    }

    public String getApplicationActivityShortNameFrench() {
        return applicationActivityShortNameFrench;
    }

    public String getGrantTypeNameEnglish() {
        return grantTypeNameEnglish;
    }

    public String getGrantTypeNameFrench() {
        return grantTypeNameFrench;
    }

    public Long getFormId() {
        return formId;
    }

    public String getFormLanguage() {
        return formLanguage;
    }

    public hibernate.Cod getSupplement() {
        if (null == supplement) {
            supplement = new hibernate.Cod();
        }
        return supplement;
    }

    public String getSupplementShortName() {
        String name = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.supplementShortNameFrench != null) {
                name = this.supplementShortNameFrench;
            }
        } else if (this.supplementShortNameEnglish != null) {
            name = this.supplementShortNameEnglish;
        }
        return name;
    }

    public String getSupplementShortNameEnglish() {
        return supplementShortNameEnglish;
    }

    public String getSupplementShortNameFrench() {
        return supplementShortNameFrench;
    }

    public Integer getApplId() {
        return applId;
    }

    public String validate(ValidationMessage validationMessage) throws HibernateException, Exception {
        Logger logger = Logger.getLogger(IdentificationBean.class.getName());
        String validationOutcome = Constants.SUCCESS_OUTCOME;
        ResourceBundle moduleBundle = null;
        ResourceBundle applicationBundle = null;
        ResourceBundle validationErrorBundle = null;
        Locale locale = null;
        Integer subSystemId = null;
        Integer moduleId = null;
        String moduleDisplayName = null;
        String errorMessage = null;
        int year, month;

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("programs.IdentificationBean.validate - Start");
        }

        // Call this object's retrieve method
        try {
            // Get a session
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // Call this object's retrieve method
            this.retrieve(0, session);

        } catch (Exception ex) {
            HibernateUtil.closeSession();
            ex.printStackTrace();
        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        /**
         * If no row, return success. This should never happend for this object since
         * the row's created when the user account is.
         */
        if (this.formId == null) {
            return validationOutcome;
        }

        // If messageContainer is null, throw exception
        if (validationMessage == null) {
            throw new Exception(
                    "Invalid parameter. ValidationMessage object was null. Validation stopped before completion.");
        }

        // Get the current subsystem & module id we're validating for
        subSystemId = this.getNavigationBean().getRequestedSubsystemId();
        moduleId = validationMessage.getModuleNavigationBarBean().getSequenceNumber();

        /**
         * Create Locale
         * Get the module's display name used to identify from which module the validation error message's generated
         *
         */
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            locale = Locale.CANADA_FRENCH;
            moduleDisplayName = validationMessage.getModuleNavigationBarBean().getNameFrench();
        } else {
            locale = Locale.CANADA;
            moduleDisplayName = validationMessage.getModuleNavigationBarBean().getNameEnglish();
        }

        // Get resource bundles
        applicationBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                Constants.APPLICATION_RESOURCES, locale);
        validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                Constants.VALIDATION_ERROR_RESOURCES, locale);
        moduleBundle = ResourceBundle.getBundle(validationMessage.getResourceBundleName(), locale);

        /**
         *
         * Validate Identification data
         *
         * */

        /** Application Title
         *
         * Validation required for all EXCEPT subsystem id: 34 (Final research report)
         *
         */
        if (subSystemId.intValue() != 34) {
            if (null == this.applTitle || (this.applTitle.trim()).equals("")) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                Object params[] = {applicationBundle.getString("applicationTitle")};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage, params));
            }

            /** Organization - Was Org. Id selected */
            if (null == this.organization.getOrgId() || (this.organization.getOrgId().intValue() == 0)) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                Object params[] = {applicationBundle.getString("administrativeOrganization")};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage, params));
                // Organization - Was Org. Id 1 selected - Other
            } else if (this.organization.getOrgId().intValue() == 1) { // Other
                // Organization - Org. Id 1 selected - Was org. name entered
                if (null == this.orgName || this.orgName.trim().equals("")) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                    Object params[] = {applicationBundle.getString("OtherOrganization")};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage,
                            params));
                }
            }

            // Organization - Org. Id 1 not selected - org. name was entered
            if (null != this.orgName && !this.orgName.trim().equals("") && this.organization.getOrgId().intValue() != 1) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorIfOther");
                Object params[] = {applicationBundle.getString("administrativeOrganization"), ""};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage, params));

            }

            // Department - Was dept. Id selected
            if (null == this.orgDeptLocation.getOrgDeptLocId() || (this.orgDeptLocation.getOrgDeptLocId().intValue() == 0)) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                Object params[] = {applicationBundle.getString("Department")};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage, params));
                // Department - Was dept. Id 2 selected - Other
            } else if (this.orgDeptLocation.getOrgDeptLocId().intValue() == 2) { // Other
                // Department - Dept. Id 2 selected - Was Dept. name entered
                if (null == this.departmentName || this.departmentName.trim().equals("")) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                    Object params[] = {applicationBundle.getString("OtherDepartment")};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage,
                            params));
                }
            }

            // Organization - Org. Id 1 not selected - org. name was entered
            if (null != this.departmentName && !this.departmentName.trim().equals("") &&
                this.orgDeptLocation.getOrgDeptLocId().intValue() != 2) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorIfOther");
                Object params[] = {applicationBundle.getString("Department"), ""};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage, params));

            }
        }

        if (subSystemId.intValue() == 37) {
            /** Activity type - sub 37 INE outreach
             * activityType
             * otherActivity
             */
            if (null == this.activityType.getCode() || this.activityType.getCode().intValue() == 0) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                Object params[] = {moduleBundle.getString("activityType")};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage, params));
            } else if (this.activityType.getCode().intValue() == 994 &&
                       (null == this.otherActivity || this.otherActivity.trim().equals(""))) { // Other
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                Object params[] = {moduleBundle.getString("otherActivity")};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage, params));
            }

            /** Completion date year & month - sub 37 INE outreach
             *  completionDateYear
             *  completionDateMonth
             *
             *  Max & min value - Moved to front end - see method validateCompletionDateYear & validateCompletionDateMonth in this object
             */

            // String to int conversion
            try {
                year = Integer.parseInt(this.completionDateYear);
            } catch (NumberFormatException nfe) {
                year = 0;
            }

            try {
                month = Integer.parseInt(this.completionDateMonth);
            } catch (NumberFormatException nfe) {
                month = 0;
            }

            if (year == 0 || month == 0) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                Object params[] = {moduleBundle.getString("completionDate")};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage, params));
            }
        }

        /** Preferred adjudication committee - only sub 2 Standard research grant
         *  committeeId
         */
        if (subSystemId.intValue() == 2) {
            if (null == this.committee.getCommitteeId() || this.committee.getCommitteeId().intValue() == 0) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                Object params[] = {moduleBundle.getString("preferredAdjudication")};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage, params));
            }
        }

        // Scholar type & category
        if (null != this.scholarType && (this.scholarType.intValue() == 166)) {
            if (null == this.scholarCategory || this.scholarCategory.intValue() == 0) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                Object params[] = {moduleBundle.getString("scholarshipCategory")};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage, params));
            }
        } else if ((null == this.scholarType || this.scholarType.intValue() == 167) &&
                   (null != this.scholarCategory) && this.scholarCategory.intValue() != 0) {
            // Add validation error message
            errorMessage = validationErrorBundle.getString("errorCategoryRadioButton");
            // Field name varies depending on the subsystemid...
            Object params[] = {moduleBundle.getString("scholarship")};
            if (subSystemId.intValue() == 37) {
                params[0] = moduleBundle.getString("researcher");
            }
            validationMessage.addMessage(subSystemId,
                                         moduleId,
                                         moduleDisplayName,
                                         validationMessage.substituteParams(locale, errorMessage, params));
        }

        /** Program name - only sub 37 INE outreach
         *  sshrcFundedProgramId
         */
        if (subSystemId.intValue() == 37) {
            if (null == this.sshrcFundedProgramId || this.sshrcFundedProgramId.intValue() == 0) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                Object params[] = {moduleBundle.getString("programName")};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage, params));
            }

            /** File number
             *  fileNumber
             */
            if (null == this.fileNumber || this.fileNumber.trim().equals("")) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                Object params[] = {moduleBundle.getString("fileNumber")};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage, params));
            }
        }

        return validationOutcome;
    }

    public void validateCompletionDateYear(FacesContext context, UIComponent toValidate,
                                           java.lang.Object value) throws
            ValidatorException {

        try {
            Integer year = new Integer((String) value);

            // Only validate if user entered something
            if (year != null) {

                String errorMessage, moduleBundleName[];

                if (year.intValue() < 1901) {
                    // Set validation indicator, used for label style
                    this.completionDateYearValidationError = true;

                    // Resource bundle stuff to get error message & label
                    ResourceBundle validationErrorBundle = null;
                    ResourceBundle moduleBundle = null;
                    Locale locale = null;

                    // Create Locale
                    if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.
                            FRENCH_CANADIAN_LOCALE)) {
                        locale = Locale.CANADA_FRENCH;
                    } else {
                        locale = Locale.CANADA;
                    }

                    // Get resource bundles
                    validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                            Constants.VALIDATION_ERROR_RESOURCES, locale);

                    // Get THIS module's resource bundle name
                    // moduleBundleName is a String array because it's possible to have more then one resource per module,
                    // like it's possible to have more then one bean per module. (so, it's basically one resource bundle per bean)
                    // I'll only plan for one per bean for now. I'll only take the first array position.
                    moduleBundleName = this.getNavigationBean().getRequestedModuleResourceBundle();
                    if (moduleBundleName.length > 0) {
                        moduleBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                                moduleBundleName[0], locale);
                    }

                    // Get
                    errorMessage = validationErrorBundle.getString("errorYearMinimum");
                    Object params[] = {moduleBundle.getString("completionDate")};

                    // Need ValidationMessage object to do the param. substitution.
                    ValidationMessage validationMessage = new ValidationMessage();
                    ((UIInput) toValidate).setValid(false);
                    context.addMessage(toValidate.getClientId(context),
                                       new FacesMessage(validationMessage.
                            substituteParams(locale, errorMessage, params),
                            validationMessage.substituteParams(locale, errorMessage, params)));
                } else {
                    ((UIInput) toValidate).setValid(true);
                }
            }
        } catch (ClassCastException e) {
            throw new ValidatorException(
                    new FacesMessage(
                            "Validation Error: Value " +
                            "cannot be converted to String.",
                            null));
        } catch (NumberFormatException e) {
            throw new ValidatorException(
                    new FacesMessage(
                            "Validation Error: Value " +
                            "cannot be converted to String.",
                            null));
        }
    }

    public void validateCompletionDateMonth(FacesContext context, UIComponent toValidate,
                                            java.lang.Object value) throws
            ValidatorException {

        try {
            Integer month = new Integer((String) value);

            // Only validate if user entered something
            if (month != null) {

                String errorMessage, moduleBundleName[];

                if (month.intValue() < 1 || month.intValue() > 12) {
                    // Set validation indicator, used for label style
                    this.completionDateMonthValidationError = true;

                    // Resource bundle stuff to get error message & label
                    ResourceBundle validationErrorBundle = null;
                    ResourceBundle moduleBundle = null;
                    Locale locale = null;

                    // Create Locale
                    if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.
                            FRENCH_CANADIAN_LOCALE)) {
                        locale = Locale.CANADA_FRENCH;
                    } else {
                        locale = Locale.CANADA;
                    }

                    // Get resource bundles
                    validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                            Constants.VALIDATION_ERROR_RESOURCES, locale);

                    // Get THIS module's resource bundle name
                    // moduleBundleName is a String array because it's possible to have more then one resource per module,
                    // like it's possible to have more then one bean per module. (so, it's basically one resource bundle per bean)
                    // I'll only plan for one per bean for now. I'll only take the first array position.
                    moduleBundleName = this.getNavigationBean().getRequestedModuleResourceBundle();
                    if (moduleBundleName.length > 0) {
                        moduleBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                                moduleBundleName[0], locale);
                    }

                    // Get label
                    errorMessage = validationErrorBundle.getString("errorMonthRange");
                    Object params[] = {moduleBundle.getString("completionDate")};

                    // Need ValidationMessage object to do the param. substitution.
                    ValidationMessage validationMessage = new ValidationMessage();
                    ((UIInput) toValidate).setValid(false);
                    context.addMessage(toValidate.getClientId(context),
                                       new FacesMessage(validationMessage.
                            substituteParams(locale, errorMessage, params),
                            validationMessage.substituteParams(locale, errorMessage, params)));
                } else {
                    ((UIInput) toValidate).setValid(true);
                }
            }
        } catch (ClassCastException e) {
            throw new ValidatorException(
                    new FacesMessage(
                            "Validation Error: Value " +
                            "cannot be converted to String.",
                            null));
        } catch (NumberFormatException e) {
            throw new ValidatorException(
                    new FacesMessage(
                            "Validation Error: Value " +
                            "cannot be converted to String.",
                            null));
        }
    }

    public void validateFileNumber(FacesContext context, UIComponent toValidate, java.lang.Object inputValue) throws
            ValidatorException {

        Pattern pattern;
        String expression = "\\d{3}\\p{Pd}\\d{4}\\p{Pd}\\d{4}"; // 999-9999-9999 (ex.: 501-2002-0101)
        String value = null;

        try {
            value = inputValue.toString();
            pattern = Pattern.compile(expression);

            this.fileNumberValidationError = !pattern.matcher(value).matches();

        } catch (ClassCastException e) {
            throw new ValidatorException(
                    new FacesMessage(
                            "Validation Error: Value " +
                            "cannot be converted to String.",
                            null));
        }

        if (this.fileNumberValidationError) {
            // Get error message from resource bundle
            // Resource bundle stuff to get error message & label
            String errorMessage;
            ResourceBundle validationErrorBundle = null;
            Locale locale = null;

            // Create Locale
            if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
                locale = Locale.CANADA_FRENCH;
            } else {
                locale = Locale.CANADA;
            }

            // Get validation error resource bundles
            validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                    Constants.VALIDATION_ERROR_RESOURCES, locale);

            // Get error message
            errorMessage = validationErrorBundle.getString("errorInvalidNumberFormat");

            if (null != errorMessage) {
                throw new ValidatorException(
                        new FacesMessage(errorMessage,
                                         null));
            } else {
                throw new ValidatorException(
                        new FacesMessage("Invalid file number.",
                                         null));
            }
        }

    }

}
