package ca.sshrc.web.logon;

import java.util.*;

import javax.faces.application.*;
import javax.faces.component.*;
import javax.faces.context.*;
import javax.faces.validator.*;
import javax.servlet.http.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.*;
import ca.sshrc.web.lookupCache.*;
import hibernate.*;
import org.hibernate.*;
import org.apache.log4j.*;

public class PasswordChangeBean extends BeanBase {
    private String daysSinceLastPasswordChange;
    private String daysBetweenPasswordChange = Constants.DAYS_BETWEEN_PASSWORD_CHANGE.toString();
    private String currentPassword;
    private String newPassword;
    private String newPasswordConfirmation;

    private Logger logger = Logger.getLogger(PasswordChangeBean.class.getName());

    public PasswordChangeBean() {

        int secProfileCount = 0;

        Calendar calendarForSystemDate = Calendar.getInstance(TimeZone.getDefault());
        Calendar calendarForDaysSinceLastPasswordChange = Calendar.getInstance(TimeZone.getDefault());

        SecurityProfile secProfile = null;
        CacheService cacheManager = null;
        LogonBean logon = this.getLogonBean();

        // Get days_between_password_change from System Property Cache
        cacheManager = CacheService.getInstance(Constants.LOOKUP_CACHE_MANAGER);
        this.daysBetweenPasswordChange = ((SystemPropertyCache) cacheManager.get(
                "SystemPropertyCache")).getValue("days_between_password_change");

        if (this.daysBetweenPasswordChange.trim().equals("")) {
            this.daysSinceLastPasswordChange = Constants.DAYS_BETWEEN_PASSWORD_CHANGE.toString();
        }

        Session session = HibernateUtil.getSession();
        HibernateUtil.beginTransaction();

        // Get security profile
        Query query = null;
        try {
            query = session.createQuery(
                    "select SecProf from SecurityProfile as SecProf where SecProf.cid = :cid");
            query.setLong("cid", logon.getWeb_id().longValue());

            // Iterate the result set
            for (Iterator it = query.iterate(); it.hasNext(); ) {
                secProfileCount++;
                secProfile = (SecurityProfile) it.next();
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("Found SecurityProfile for cid : " + secProfile.getCid());
                }
            }

            // If more than one row, throw exception
            if (secProfileCount > 1) {
                throw new Exception("Duplicate SecurityProfile for cid : " + secProfile.getCid());
            }

            // Calculate days since last password change
            calendarForDaysSinceLastPasswordChange.setTime(secProfile.getLastPasswordChangeDatetime());
            this.daysSinceLastPasswordChange = (CommonService.daysBetweenDates(calendarForSystemDate,
                    calendarForDaysSinceLastPasswordChange)).toString();

            HibernateUtil.commitTransaction();

        } catch (HibernateException ex) {
            HibernateUtil.rollbackTransaction();
            ex.printStackTrace();

        } catch (Exception ex) {
            HibernateUtil.rollbackTransaction();
            ex.printStackTrace();
        } finally {
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

    }

    public void setDaysSinceLastPasswordChange(String daysSinceLastPasswordChange) {
        this.daysSinceLastPasswordChange = daysSinceLastPasswordChange;
    }

    public void setDaysBetweenPasswordChange(String daysBetweenPasswordChange) {
        this.daysBetweenPasswordChange = daysBetweenPasswordChange;
    }

    public void setCurrentPassword(String currentPassword) {
        this.currentPassword = currentPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public void setNewPasswordConfirmation(String newPasswordConfirmation) {
        this.newPasswordConfirmation = newPasswordConfirmation;
    }

    public String getDaysSinceLastPasswordChange() {
        return daysSinceLastPasswordChange;
    }

    public String getDaysBetweenPasswordChange() {
        return daysBetweenPasswordChange;
    }

    public String getCurrentPassword() {
        return currentPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public String getNewPasswordConfirmation() {
        return newPasswordConfirmation;
    }

    /**
     * validatePassword
     * - Length
     * - The 2 passwords (new and confirmation password) must be exactly the same
     * - Current password must be valid - Exist in DB for current user
     *
     * @param context FacesContext
     * @param toValidate UIComponent
     * @param value Object
     * @throws ValidatorException
     */
    public void validatePassword(FacesContext context, UIComponent toValidate, java.lang.Object value) throws
            ValidatorException {

        String errorMessage;
        String clientId = toValidate.getClientId(context);
        String theOtherPassword;

        // Resource bundle stuff to get error message & label
        ResourceBundle validationErrorBundle = null;
        Locale locale = null;

        try {
            String password = (String) value;

            password = password.trim();

            // Password must be between 6 and 10 chars.
            if (password.length() < 6 || password.length() > 10) {

                // Create Locale
                if (this.getLogonBean().getSiteLanguageAtLogon().equalsIgnoreCase(Constants.
                        FRENCH_CANADIAN_LOCALE)) {
                    locale = Locale.CANADA_FRENCH;
                } else {
                    locale = Locale.CANADA;
                }

                // Get resource bundles
                validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                        Constants.VALIDATION_ERROR_RESOURCES, locale);

                // Get error message
                errorMessage = validationErrorBundle.getString("errorPasswordLength");

                if (null != errorMessage) {
                    throw new ValidatorException(
                            new FacesMessage(errorMessage,
                                             null));
                } else {
                    throw new ValidatorException(
                            new FacesMessage("%%%errorPasswordLength%%%",
                                             null));
                }
            }

            // Get the other password. If this one is the newPassword field, get the newPasswordConfirmation field (or vice versa).
            if (!clientId.endsWith("currentPassword")) {

                if (clientId.endsWith("newPasswordConfirmation")) {
                    theOtherPassword = ((HttpServletRequest) context.getExternalContext().getRequest()).
                                       getParameter("mainForm:bodyContent:newPassword");
                } else {
                    theOtherPassword = ((HttpServletRequest) context.getExternalContext().getRequest()).
                                       getParameter("mainForm:bodyContent:newPasswordConfirmation");
                }

                if (null == theOtherPassword || !password.equals(theOtherPassword)) {

                    // Create Locale
                    if (this.getLogonBean().getSiteLanguageAtLogon().equalsIgnoreCase(Constants.
                            FRENCH_CANADIAN_LOCALE)) {
                        locale = Locale.CANADA_FRENCH;
                    } else {
                        locale = Locale.CANADA;
                    }

                    // Get resource bundles
                    validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                            Constants.VALIDATION_ERROR_RESOURCES, locale);

                    // Get error message
                    errorMessage = validationErrorBundle.getString("errorPasswordConfirmation");

                    if (null != errorMessage) {
                        throw new ValidatorException(
                                new FacesMessage(errorMessage,
                                                 null));
                    } else {
                        throw new ValidatorException(
                                new FacesMessage("%%%errorPasswordConfirmation%%%",
                                                 null));
                    }
                }
            } else { // Validate currentPassword

                // If not valid...
                if (!LogonService.validateAccessRight(this.getLogonBean().getWeb_id(),
                        password).equals(Constants.SUCCESS_OUTCOME)) {

                    // Create Locale
                    if (this.getLogonBean().getSiteLanguageAtLogon().equalsIgnoreCase(Constants.
                            FRENCH_CANADIAN_LOCALE)) {
                        locale = Locale.CANADA_FRENCH;
                    } else {
                        locale = Locale.CANADA;
                    }

                    // Get resource bundles
                    validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                            Constants.VALIDATION_ERROR_RESOURCES, locale);

                    // Get error message
                    errorMessage = validationErrorBundle.getString("errorCurrentPasswordInvalide");

                    if (null != errorMessage) {
                        throw new ValidatorException(
                                new FacesMessage(errorMessage,
                                                 null));
                    } else {
                        throw new ValidatorException(
                                new FacesMessage("%%%errorCurrentPasswordInvalide%%%",
                                                 null));
                    }
                }
            }

        } catch (ClassCastException e) {
            throw new ValidatorException(
                    new FacesMessage(
                            "Validation Error: Value " +
                            "cannot be converted to String.",
                            null));
        }
    }

    /**
     * save
     *
     * Save new password
     *
     * @return String
     */
    public String save() {
        String outcome = Constants.SYSTEM_ERROR_OUTCOME;

        Session session = HibernateUtil.getSession();
        HibernateUtil.beginTransaction();
        SecurityProfile secProfile = null;
        Calendar calTemp = Calendar.getInstance(TimeZone.getDefault());
        ValidationMessage validationMessage = new ValidationMessage(true);

        try {
            // Get security profile
            Query query = session.createQuery(
                    "select SecProf from SecurityProfile as SecProf where SecProf.cid = :cid");
            query.setLong("cid", this.getLogonBean().getWeb_id().longValue());

            // Iterate the result set
            for (Iterator it = query.iterate(); it.hasNext(); ) {
                secProfile = (SecurityProfile) it.next();
            }

            // Validate that the selected password was not used in the past 2 password changes

            if (!secProfile.getPreviousPassword1().trim().equals(this.getNewPassword()) &&
                !secProfile.getPreviousPassword2().trim().equals(this.getNewPassword())) {

                // Previous password 1 moves to Previous password 2
                secProfile.setPreviousPassword2(secProfile.getPreviousPassword1());

                // Previous current password moves to Previous password 2
                secProfile.setPreviousPassword1(secProfile.getCurrentPassword());

                // Set new password
                secProfile.setCurrentPassword(this.getNewPassword());

                // Set last password changed date
                secProfile.setLastPasswordChangeDatetime(calTemp.getTime());

                session.saveOrUpdate(secProfile);
                session.flush();

                HibernateUtil.commitTransaction();

                outcome = Constants.SUCCESS_OUTCOME;
            } else {
                Locale locale = null;
                ResourceBundle validationErrorBundle = null;
                String errorMessage;

                outcome = ""; // Empty outcome var. so JSF navigation will return to the change password page (this page)

                // Create Locale
                if (this.getLogonBean().getSiteLanguageAtLogon().equalsIgnoreCase(Constants.
                        FRENCH_CANADIAN_LOCALE)) {
                    locale = Locale.CANADA_FRENCH;
                } else {
                    locale = Locale.CANADA;
                }

                // Get resource bundles
                validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                        Constants.VALIDATION_ERROR_RESOURCES, locale);

                // Get error message
                errorMessage = validationErrorBundle.getString("errorNewPasswordInvalide");
                validationMessage.addMessage(null, errorMessage);
            }

        } catch (HibernateException e) {
            HibernateUtil.rollbackTransaction();
            outcome = Constants.DB_ERROR_OUTCOME;
            e.printStackTrace();

        } catch (Exception e) {
            outcome = Constants.SYSTEM_ERROR_OUTCOME;
            HibernateUtil.rollbackTransaction();
            e.printStackTrace();

        } finally {
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        return outcome;

    }
}
