package ca.sshrc.web.forms.beans.cv;

import java.util.*;

import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.*;
import hibernate.*;
import org.apache.log4j.*;

public class AcademicDataBean extends BeanBase {

    private Integer degreeId;
    private Integer cid;
    private hibernate.Cod degreeType;
    private String degreeName;
    private Date startDate;
    private Date completedDate;
    private Date expectedDate;
    private hibernate.Discipline discipline;
    private String otherDisciplineName;
    private hibernate.Organization organization;
    private String otherOrgName;
    private hibernate.Country otherCountry;
    private String resultOfSshrcInd;
    private String highestDegreeInd;
    private Date changeDate;
    private String startYear;
    private String startMonth;
    private String completedYear;
    private String completedMonth;
    private String expectedYear;
    private String expectedMonth;
    private String degreeTypeEnglish;
    private String degreeTypeFrench;
    private String disciplineNameEnglish;
    private String disciplineNameFrench;
    private String orgNameEnglish;
    private String orgNameFrench;
    private String countryNameEnglish;
    private String countryNameFrench;
    private boolean highestDegreeBoolean;





    /**
     * AcademicDataBean Full Constructor
     *
     * @param degreeId Integer
     * @param cid Integer
     * @param degreeType Integer
     * @param degreeName String
     * @param startDate Date
     * @param completedDate Date
     * @param expectedDate Date
     * @param disciplineCode Integer
     * @param otherDisciplineName String
     * @param orgId Integer
     * @param otherOrgName String
     * @param otherCountryCode Integer
     * @param resultOfSshrcInd String
     * @param highestDegreeInd String
     * @param changeDate Date
     * @param startYear String
     * @param startMonth String
     * @param completedYear String
     * @param completedMonth String
     * @param expectedYear String
     * @param expectedMonth String
     * @param degreeTypeEnglish String
     * @param degreeTypeFrench String
     * @param disciplineNameEnglish String
     * @param disciplineNameFrench String
     * @param orgNameEnglish String
     * @param orgNameFrench String
     * @param countryNameEnglish String
     * @param countryNameFrench String
     */

    public AcademicDataBean(Integer degreeId, Integer cid, hibernate.Cod degreeType, String degreeName,
                            Date startDate, Date completedDate, Date expectedDate, hibernate.Discipline discipline,
                            String otherDisciplineName, hibernate.Organization organization, String otherOrgName,
                            hibernate.Country otherCountry, String resultOfSshrcInd, String highestDegreeInd,
                            Date changeDate, String startYear, String startMonth, String completedYear,
                            String completedMonth, String expectedYear, String expectedMonth,
                            String degreeTypeEnglish, String degreeTypeFrench, String disciplineNameEnglish,
                            String disciplineNameFrench, String orgNameEnglish, String orgNameFrench,
                            String countryNameEnglish, String countryNameFrench) {
        this.degreeId = degreeId;
        this.cid = cid;
        this.degreeType = degreeType;
        this.degreeName = degreeName;
        this.startDate = startDate;
        this.completedDate = completedDate;
        this.expectedDate = expectedDate;
        this.discipline = discipline;
        this.otherDisciplineName = otherDisciplineName;
        this.organization = organization;
        this.otherOrgName = otherOrgName;
        this.otherCountry = otherCountry;
        this.resultOfSshrcInd = resultOfSshrcInd;
        this.highestDegreeInd = highestDegreeInd;
        this.highestDegreeBoolean = booleanConverter(highestDegreeInd);
        this.changeDate = changeDate;
        this.startYear = startYear;
        this.startMonth = startMonth;
        this.completedYear = completedYear;
        this.completedMonth = completedMonth;
        this.expectedYear = expectedYear;
        this.expectedMonth = expectedMonth;
        this.degreeTypeEnglish = degreeTypeEnglish;
        this.degreeTypeFrench = degreeTypeFrench;
        this.disciplineNameEnglish = disciplineNameEnglish;
        this.disciplineNameFrench = disciplineNameFrench;
        this.orgNameEnglish = orgNameEnglish;
        this.orgNameFrench = orgNameFrench;
        this.countryNameEnglish = countryNameEnglish;
        this.countryNameFrench = countryNameFrench;

    }


// For testing with testDBAHibernate
    public AcademicDataBean(Integer degreeId, Integer cid, hibernate.Cod degreeType,
                            String degreeTypeEnglish, String degreeTypeFrench) {
        this.degreeId = degreeId;
        this.cid = cid;
        this.degreeType = degreeType;
        this.degreeName = degreeName;
        this.startDate = startDate;
        this.completedDate = completedDate;
        this.expectedDate = expectedDate;
        this.discipline = discipline;
        this.otherDisciplineName = otherDisciplineName;
        this.organization = organization;
        this.otherOrgName = otherOrgName;
        this.otherCountry = otherCountry;
        this.resultOfSshrcInd = resultOfSshrcInd;
        this.highestDegreeInd = highestDegreeInd;
        this.highestDegreeBoolean = booleanConverter(highestDegreeInd);
        this.changeDate = changeDate;
        this.startYear = startYear;
        this.startMonth = startMonth;
        this.completedYear = completedYear;
        this.completedMonth = completedMonth;
        this.expectedYear = expectedYear;
        this.expectedMonth = expectedMonth;
        this.degreeTypeEnglish = degreeTypeEnglish;
        this.degreeTypeFrench = degreeTypeFrench;
        this.disciplineNameEnglish = disciplineNameEnglish;
        this.disciplineNameFrench = disciplineNameFrench;
        this.orgNameEnglish = orgNameEnglish;
        this.orgNameFrench = orgNameFrench;
        this.countryNameEnglish = countryNameEnglish;
        this.countryNameFrench = countryNameFrench;

    }


    /**
     * Minimal (empty) constructor
     */
    public AcademicDataBean() {
    }

    public void setDegreeId(Integer degreeId) {
        this.degreeId = degreeId;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public void setDegreeType(hibernate.Cod degreeType) {
        this.degreeType = degreeType;
    }

    public void setDegreeName(String degreeName) {
        this.degreeName = degreeName;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public void setCompletedDate(Date completedDate) {
        this.completedDate = completedDate;
    }

    public void setExpectedDate(Date expectedDate) {
        this.expectedDate = expectedDate;
    }

    public void setDiscipline(hibernate.Discipline discipline) {
        this.discipline = discipline;
    }

    public void setOtherDisciplineName(String otherDisciplineName) {
        this.otherDisciplineName = otherDisciplineName;
    }

    public void setOrganization(hibernate.Organization organization) {
        this.organization = organization;
    }

    public void setOtherOrgName(String otherOrgName) {
        this.otherOrgName = otherOrgName;
    }

    public void setOtherCountry(hibernate.Country otherCountry) {
        this.otherCountry = otherCountry;
    }

    public void setResultOfSshrcInd(String resultOfSshrcInd) {
        this.resultOfSshrcInd = resultOfSshrcInd;
    }

    public void setHighestDegreeInd(String highestDegreeInd) {
        this.highestDegreeInd = highestDegreeInd;
        this.highestDegreeBoolean = this.booleanConverter(highestDegreeInd);
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public void setStartYear(String startYear) {
        this.startYear = startYear;
    }

    public void setStartMonth(String startMonth) {
        this.startMonth = startMonth;
    }

    public void setCompletedYear(String completedYear) {
        this.completedYear = completedYear;
    }

    public void setCompletedMonth(String completedMonth) {
        this.completedMonth = completedMonth;
    }

    public void setExpectedYear(String expectedYear) {
        this.expectedYear = expectedYear;
    }

    public void setExpectedMonth(String expectedMonth) {
        this.expectedMonth = expectedMonth;
    }

    public void setDegreeTypeEnglish(String degreeTypeEnglish) {
        this.degreeTypeEnglish = degreeTypeEnglish;
    }

    public void setDegreeTypeFrench(String degreeTypeFrench) {
        this.degreeTypeFrench = degreeTypeFrench;
    }

    public void setDisciplineNameEnglish(String disciplineNameEnglish) {
        this.disciplineNameEnglish = disciplineNameEnglish;
    }

    public void setDisciplineNameFrench(String disciplineNameFrench) {
        this.disciplineNameFrench = disciplineNameFrench;
    }

    public void setOrgNameEnglish(String orgNameEnglish) {
        this.orgNameEnglish = orgNameEnglish;
    }

    public void setOrgNameFrench(String orgNameFrench) {
        this.orgNameFrench = orgNameFrench;
    }

    public void setCountryNameEnglish(String countryNameEnglish) {
        this.countryNameEnglish = countryNameEnglish;
    }

    public void setCountryNameFrench(String countryNameFrench) {
        this.countryNameFrench = countryNameFrench;
    }

    public void setHighestDegreeBoolean(boolean highestDegreeBoolean) {
        this.highestDegreeBoolean = highestDegreeBoolean;
        this.highestDegreeInd = booleanConverter(highestDegreeBoolean);
    }

    /**
     * setDisciplineName
     *
     * @param adisciplineName String
     */
    public void setDisciplineName(String adisciplineName) {
        if (this.getNavigationBean().getFormLanguage().equals(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.disciplineNameFrench = adisciplineName;
        } else {
            this.disciplineNameEnglish = adisciplineName;
        }
    }

    /**
     * setCountryName
     *
     * @param aCountryName String
     */
    public void setCountryName(String aCountryName) {
        if (this.getNavigationBean().getFormLanguage().equals(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.countryNameFrench = aCountryName;
        } else {
            this.countryNameEnglish = aCountryName;
        }
    }

    /**
     * setOrgName
     *
     * @param aOrgName String
     */
    public void setOrgName(String aOrgName) {
        if (this.getNavigationBean().getFormLanguage().equals(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.countryNameFrench = aOrgName;
        } else {
            this.countryNameEnglish = aOrgName;
        }

    }

    /**
     * getDisciplineName
     *
     * @return String
     */
    public String getDisciplineName() {
        if (this.getNavigationBean().getFormLanguage().equals(Constants.FRENCH_CANADIAN_LOCALE)) {
            return this.disciplineNameFrench;
        } else {
            return this.disciplineNameEnglish;
        }
    }

    /**
     * getCountryName
     *
     * @return String
     */
    public String getCountryName() {
        if (this.getNavigationBean().getFormLanguage().equals(Constants.FRENCH_CANADIAN_LOCALE)) {
            return this.countryNameFrench;
        } else {
            return this.countryNameEnglish;
        }
    }

    /**
     * getOrgName
     *
     * @return String
     */
    public String getOrgName() {
        if (this.getNavigationBean().getFormLanguage().equals(Constants.FRENCH_CANADIAN_LOCALE)) {
            return this.orgNameFrench;
        } else {
            return this.orgNameEnglish;
        }

    }

    public Integer getDegreeId() {
        return degreeId;
    }

    public Integer getCid() {
        return cid;
    }

    public hibernate.Cod getDegreeType() {
        if(null == degreeType) {
            degreeType = new Cod();
        }
        return degreeType;
    }

    public String getDegreeName() {
        return degreeName;
    }

    public Date getStartDate() {
        return startDate;
    }

    public Date getCompletedDate() {
        return completedDate;
    }

    public Date getExpectedDate() {
        return expectedDate;
    }

    public hibernate.Discipline getDiscipline() {
        if(null == discipline) {
            discipline = new Discipline();
        }
        return discipline;
    }

    public String getOtherDisciplineName() {
        return otherDisciplineName;
    }

    public hibernate.Organization getOrganization() {
        if(null == organization) {
            organization = new Organization();
        }
        return organization;
    }

    public String getOtherOrgName() {
        return otherOrgName;
    }

    public hibernate.Country getOtherCountry() {
        if(null == otherCountry) {
            otherCountry = new Country();
        }
        return otherCountry;
    }

    public String getResultOfSshrcInd() {
        if (this.resultOfSshrcInd == null) {
            return "";
        } else {
            return resultOfSshrcInd;
        }
    }

    public String getHighestDegreeInd() {
        return highestDegreeInd;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public String getStartYear() {
        return startYear;
    }

    public String getStartMonth() {
        return startMonth;
    }

    public String getCompletedYear() {
        return completedYear;
    }

    public String getCompletedMonth() {
        return completedMonth;
    }

    public String getExpectedYear() {
        return expectedYear;
    }

    public String getExpectedMonth() {
        return expectedMonth;
    }

    public String getDegreeTypeEnglish() {
        return degreeTypeEnglish;
    }

    public String getDegreeTypeFrench() {
        return degreeTypeFrench;
    }

    public String getDisciplineNameEnglish() {
        return disciplineNameEnglish;
    }

    public String getDisciplineNameFrench() {
        return disciplineNameFrench;
    }

    public String getOrgNameEnglish() {
        return orgNameEnglish;
    }

    public String getOrgNameFrench() {
        return orgNameFrench;
    }

    public String getCountryNameEnglish() {
        return countryNameEnglish;
    }

    public String getCountryNameFrench() {
        return countryNameFrench;
    }

    public boolean getHighestDegreeBoolean() {
        return highestDegreeBoolean;
    }

    /**
     * AcademicDataBean
     *
     * @param aCid Integer
     */
    public AcademicDataBean(Integer aCid) {
        this.cid = aCid;
    }

    /** boolean to String (Y or N) */
    private String booleanConverter(boolean value) {
        String returnString = "N";

        if (value) {
            returnString = "Y";
        }

        return returnString;
    }

    /** String (Y or N) to boolean */
    private boolean booleanConverter(String value) {
        boolean returnBoolean = false;

        if (value == null) {
            return returnBoolean;
        }
        if (value.compareToIgnoreCase("y") == 0 || value.compareToIgnoreCase("yes") == 0) {
            returnBoolean = true;
        }

        return returnBoolean;
    }

    /**
     * hasData
     *
     * @return boolean
     */
    public boolean hasData() {
        Logger logger = Logger.getLogger(AcademicDataBean.class.getName());
        logger.info("entered the realm of hasdata ");
        if ((degreeType.getCode() == null ||degreeType.getCode().equals("0")  || degreeType.getCode().intValue() == 0 ) &&
            (degreeName == null || degreeName.trim().equals("")) &&
            (discipline.getDisciplineCode() == null || discipline.getDisciplineCode().intValue() == 0) &&
            (otherDisciplineName == null || otherDisciplineName.trim().equals("")) &&
            (organization.getOrgId() == null || organization.getOrgId().intValue() == 0) &&
            (otherOrgName == null || otherOrgName.equals("")) &&
            (otherCountry.getCountryCode() == null || otherCountry.getCountryCode().intValue() == 0) &&
            (resultOfSshrcInd.trim().equals("N") || resultOfSshrcInd.trim().equals("") ) &&
            (highestDegreeInd.trim().equals("N") || highestDegreeInd.trim().equals("")) &&
            (startYear == null || startYear.trim().equals("")) &&
            (startMonth == null || startMonth.trim().equals("")) &&
            (completedYear == null || completedYear.trim().equals("")) &&
            (completedMonth == null || completedMonth.trim().equals("")) &&
            (expectedYear == null || expectedYear.trim().equals("")) &&
            (expectedMonth == null || expectedMonth.trim().equals(""))) {


            return false;
        } else {
            logger.info("degreeType: '" + degreeType.getCode()+"'");
            logger.info("degreeName: '" + degreeName+"'");
            logger.info("disciplineCode: '" + discipline.getDisciplineCode()+"'");
            logger.info("otherDisciplineName: '" + otherDisciplineName+"'");
            logger.info("orgId: '" + organization.getOrgId()+"'");
            logger.info("otherOrgName: '" + otherOrgName+"'");
            logger.info("otherCountryCode: '" + otherCountry.getCountryCode()+"'");
            logger.info("resultOfSshrcInd: '" + resultOfSshrcInd+"'");
            logger.info("highestDegreeInd: '" + highestDegreeInd+"'");
            logger.info("startYear: '" + startYear+"'");
            logger.info("startMonth: '" + startMonth+"'");
            logger.info("completedYear: '" + completedYear+"'");
            logger.info("completedMonth: '" + completedMonth+"'");
            logger.info("expectedYear: '" + expectedYear+"'");
            logger.info("expectedMonth: '" + expectedMonth+"'");

            return true;
        }

    }

}
