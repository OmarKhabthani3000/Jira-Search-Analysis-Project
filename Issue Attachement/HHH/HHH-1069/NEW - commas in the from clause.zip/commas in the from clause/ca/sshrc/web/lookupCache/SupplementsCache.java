package ca.sshrc.web.lookupCache;

import java.util.List;
import java.io.Serializable;
import org.hibernate.Session;
import ca.sshrc.web.common.services.HibernateUtil;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import java.util.Comparator;
import java.util.Locale;
import java.text.Collator;
import java.util.Collections;
import ca.sshrc.web.common.util.Constants;
import java.util.ArrayList;
import javax.faces.model.SelectItem;
import ca.sshrc.web.common.services.NavigationBean;
import javax.servlet.http.HttpServletRequest;
import javax.faces.context.FacesContext;

public class SupplementsCache implements Serializable {
    private Logger logger = Logger.getLogger(SupplementsCache.class.getName());
    List queryList = null;

    public SupplementsCache() {


        /**
         * Integer subGroup:         Sub group number to be used for the retrieval.
         * String descType:          Specifies which code's description will be returned by the getList method.
         *                           Should be (s)hort description) or (l)ong description.
         * String sortOrder:         Specifies if the list returned by getList method will be sorted (A)scending or (D)escending.
         * String sortBy:            Specifies if the list returned by getList method will be sorted on the (s)equence number or the (d)escription.
         * boolean insertBlankEntry: Specifies weather to add a blank entry in list first position or not
         */


        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In SupplementsCache");

            queryList = session.createQuery("select new ca.sshrc.web.lookupCache.CodesDescBean(Codes.code, " +
                                            "Codes.codeType, " +
                                            "Codes.nameEnglish, " +
                                            "Codes.nameFrench, " +
                                            "Codes.shortNameEnglish, " +
                                            "Codes.shortNameFrench, " +
                                            "Codes.sequenceNumber, " +
                                            "CodesCategory.sequenceNumber, " +
                                            "CodesCategory.comp_id.subGroup) " +
                                            "from Cod Codes, " +
                                            "CodesCategory CodesCategory " +
                                            "where (Codes.code = CodesCategory.comp_id.codByCode) and " +
                                            "((CodesCategory.comp_id.subGroup in (43,44,106)) and " +
                                            "(Codes.activeInd = 'Y')) " +
                                            "order by 9 Asc, 1 Asc")
                        .list();

            /* Original PB SQL - dddw_fellowships_supplements
             SELECT  CODES.Code ,
                        CODES.Name_English ,
                        CODES.Name_French ,
                        CODES.Sequence_Number ,
                        CODES.Short_Name_English ,
                        CODES.Short_Name_French ,
                        CODES_CATEGORY.Sub_Group
                     FROM CODES ,
                        CODES_CATEGORY
             WHERE ( CODES.Code = CODES_CATEGORY.Code ) and          ( ( CODES_CATEGORY.Sub_Group in ( 43,
             44,
             106 ) ) )  */

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("SupplementsCache loaded: " + queryList.size());
            }

        } catch (HibernateException ex) {
            ex.printStackTrace();
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
        } finally {
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    // Collator - Sort English desc. Ascending
    private static final Comparator shortNameEnglishOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp1.getShortNameEnglish(), objComp2.getShortNameEnglish());
        }
    };

    // Collator - Sort French desc. Ascending
    private static final Comparator shortNameFrenchOrderAsc = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA_FRENCH);
            CodesDescBean objComp1 = (CodesDescBean) o1;
            CodesDescBean objComp2 = (CodesDescBean) o2;
            return myCollator.compare(objComp1.getShortNameFrench(), objComp2.getShortNameFrench());
        }
    };

    public ArrayList getList(String language, Integer webSubsystemId) {
        ArrayList listTemp = new ArrayList();
        int found = 0;
        int subGroup = 0;

        // Based on passed subsystem id, set the subgroup rows to be returned
        switch (webSubsystemId.intValue()) {
        case 13: // Doctoral
            subGroup = 43;
            break;
        case 14: // Postdoctoral
            subGroup = 44;
            break;
        case 2: // Standard Research Grants
            subGroup = 106;
            break;
        default:
            subGroup = 106;
        }

        for (int i = 0; i < queryList.size(); ++i) {
            CodesDescBean codesDescBean = (CodesDescBean) queryList.get(i);
            // Look for passed program id)
            if (subGroup == codesDescBean.getSubGroup().intValue()) {
                found++;
                listTemp.add(codesDescBean);
            } else if (found > 1) {

                // queryList is sorted by subGroup
                // therefore, we stop the loop as soon as we find a non matching
                // pair (after we found at least one pair)
                break;
            }
        }

        // Trim arrayList
        listTemp.trimToSize();

        // Sort only if more then 1 item
        if (found > 1) {
            return this.sort(listTemp, language);
        } else {
            return listTemp;
        }
    }

    private ArrayList sort(ArrayList list, String language) {
        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Sorting Supplements - " + language);
        }

        // Keep the original List. Use a copy for sorting
        ArrayList listTemp;
        listTemp = list;

        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            Collections.sort(listTemp, shortNameFrenchOrderAsc);
        } else {
            Collections.sort(listTemp, shortNameEnglishOrderAsc);
        }
        return listTemp;
    }

    public SelectItem[] getSelectItem(String language) {
        ArrayList listTemp = new ArrayList();

        // Need NavigationBean to get the current subsystem
        NavigationBean navigationBean = (NavigationBean) ((HttpServletRequest) (HttpServletRequest)
                FacesContext.getCurrentInstance().getExternalContext().getRequest()).getSession(false).
                                        getAttribute("navigationBean");

        // Get the current subsystem
        listTemp = this.getList(language, navigationBean.getCurrentSubsystemId());

        // Instantiate a SelectItem object in which we'll load the list
        SelectItem selectItemTemp[] = new SelectItem[listTemp.size() + 1];

        // Add a blank entry in first position
        selectItemTemp[0] = new SelectItem(new Integer(0), "");

        // Loop thru the list and add items to SeletItem object
        for (int i = 0; i < listTemp.size(); i++) {
            if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
                selectItemTemp[i + 1] = new SelectItem(((CodesDescBean) listTemp.get(i)).
                        getCode(),
                        ((CodesDescBean) listTemp.get(i)).
                        getShortNameFrench());
            } else {
                selectItemTemp[i + 1] = new SelectItem(((CodesDescBean) listTemp.get(i)).
                        getCode(),
                        ((CodesDescBean) listTemp.get(i)).
                        getShortNameEnglish());
            }
        }

        return selectItemTemp;
    }

}
