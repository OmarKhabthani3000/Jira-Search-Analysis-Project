package ca.sshrc.web.common.services;

import java.io.*;

import net.sf.ehcache.*;
import org.apache.jcs.*;
import org.apache.jcs.access.exception.CacheException;
import org.apache.log4j.Logger;

/**
 * <p>Title: Generic caching implementation.</p>
 *
 * <p>Description:
 * Generic caching implementation to abstract the real cache mechanism used</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * @author Pierre Masse
 * @version 1.0
 */

public class CacheService {
    private JCS jcsCacheManager;
    private Cache ehCache;

    public CacheService() {
    }

    // Set caching mechanism here by return a known cache implementation
    // Either ehcache or jcs
    private static String getcacheImplementation() {

        return "ehcache";
        //return "jcs";
    }

    public static CacheService getInstance(String cacheName) {
        Logger logger = Logger.getLogger(CacheService.class.getName());

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("getInstance() - " + getcacheImplementation() + " implementation");
        }

        CacheService cacheObjectToReturn = new CacheService();

        // JCS Implementation
        if (getcacheImplementation().equalsIgnoreCase("jcs")) {
            JCS jcsCache = null;
            try {
                jcsCache = JCS.getInstance(cacheName);
            } catch (CacheException ex) {
                ex.printStackTrace();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            cacheObjectToReturn.setCacheObject(jcsCache);
        }

        if (getcacheImplementation().equalsIgnoreCase("ehcache")) {
            CacheManager ehCacheManager = null;
            Cache cache = null;
            try {
                ehCacheManager = CacheManager.create();
                cache = ehCacheManager.getCache(cacheName);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            cacheObjectToReturn.setCacheObject(cache);
        }

        return cacheObjectToReturn;
    }

// Putting an object into cache
    public void put(String objectName, Serializable object) {
        Logger logger = Logger.getLogger(CacheService.class.getName());

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info(getcacheImplementation() + " put() - " + objectName);
        }

        // JCS Implementation
        if (getcacheImplementation().equalsIgnoreCase("jcs")) {
            try {
                this.jcsCacheManager.put(objectName, object);
            } catch (CacheException ex) {
                ex.printStackTrace();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        }

        if (getcacheImplementation().equalsIgnoreCase("ehcache")) {
            ehCache.put(new Element(objectName, object));
        }

    }

    // Getting an object from cache
    public Object get(String objectName) {
        Logger logger = Logger.getLogger(CacheService.class.getName());

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("get() - " + getcacheImplementation() + " implementation");
        }

        Object object = null;
        if (getcacheImplementation().equalsIgnoreCase("jcs")) {
            object = jcsCacheManager.get(objectName);
        }
        if (getcacheImplementation().equalsIgnoreCase("ehcache")) {
            try {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("get() - objectName: " + objectName);
                }

                Element element = (Element) ehCache.get(objectName);
                object = (Object) element.getValue();
            } catch (net.sf.ehcache.CacheException ex) {
                ex.printStackTrace();
            } catch (IllegalStateException ex) {
                ex.printStackTrace();
            }
        }

        return object;
    }


    // Setting this class' caching object/manager
    private void setCacheObject(Object cacheObject) {
        Logger logger = Logger.getLogger(CacheService.class.getName());

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("setCacheObject() - " + getcacheImplementation() + " implementation");
        }

        // JCS Implementation
        if (getcacheImplementation().equalsIgnoreCase("jcs")) {
            this.jcsCacheManager = (JCS) cacheObject;
        }
        if (getcacheImplementation().equalsIgnoreCase("ehcache")) {
            this.ehCache = (Cache) cacheObject;
        }
    }
}
