package ca.sshrc.web.forms.beans.cv;

import java.lang.reflect.*;
import java.util.*;

import javax.faces.component.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.services.baseObject.*;
import hibernate.*;
import org.hibernate.*;
import org.apache.commons.beanutils.*;
import org.apache.log4j.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class ExperienceBean extends BeanBase {
    private ArrayList workExperiences = new ArrayList();
    private Logger logger = Logger.getLogger(ExperienceBean.class.getName());
    private UIData experienceTable;
    private int rowsPerPage = 6;
    private String firstDisplayRow;

    public ExperienceBean() {
        logger.info("ExperienceBean - default constructor ");

        try {
            // Get a session
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // Call this object's retrieve method
            this.retrieve(new Long(0), session);

        } catch (Exception ex) {
            HibernateUtil.closeSession();
            ex.printStackTrace();
        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public UIData getExperienceTable() {
        return this.experienceTable;
    }

    public void setExperienceTable(UIData experienceTable) {
        this.experienceTable = experienceTable;

    }

    public void setRowsPerPage(int rowsPerPage) {
        this.rowsPerPage = rowsPerPage;
    }

    public void setFirstDisplayRow(String firstRow) {
        this.firstDisplayRow = firstRow;
    }

    /**
     * getWorkExperience
     *
     * @return ArrayList
     */
    public ArrayList getWorkExperiences() {
        ExperienceDetailBean tempBean = new ExperienceDetailBean();

        tempBean.setCid(this.getLogonBean().getWeb_id());
        this.workExperiences.add(tempBean);

        return this.workExperiences;
    }

    // Overwrite ancestor method
    public void retrieve(Session session) {
        retrieve(new Long(0), session);
    }

    public int getRowsPerPage() {
        return rowsPerPage;
    }

    public String getFirstDisplayRow() {
        return firstDisplayRow;
    }

    /**
     * retrieve
     *
     * @param formId Long
     */
    public void retrieve(Long formId, Session session) {

        List queryList;
        logger.info("PositionBean.retrieve passed parameter is FormId : " + formId);

        if (null == session) {
            if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                logger.error("Cannot load PositionBean - Session is null");
                return;
            }
        }

        // If the passed form_id is 0, get the form_id from the NavigationBean
        if (formId.longValue() == 0) {
            formId = new Long(getNavigationBean().getForm_id());
            if (formId.longValue() == 0) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.error("Cannot load PositionBean - no FormId : " + formId);
                    return;
                }
            } else {
                logger.info("PositionBean.retrieve using navigationBean FormId : " + formId);
            }

        } else {
            logger.info("PositionBean.retrieve using passed parm FormId : " + formId);
        }

        //Let's retrieve the data from the DB
        try {
            logger.info("In ExperienceBean.retrieve()");

            /*            queryList = session.createQuery(
             "select new ca.sshrc.web.forms.beans.cv.ExperienceDetailBean(position.positionId, " +
                                "position.cid, " +
                                "position.orgDeptLocId, " +
                                "position.positionNumber, " +
                                "position.positionStartYear, " +
                                "position.positionEndYear, " +
                                "position.otherOrgName, " +
                                "position.otherDepartmentName, " +
                                "position.otherPositionName, " +
                                "position.orgId, "+
                                "cod.shortNameEnglish, " +
                                "cod.shortNameFrench, " +
                                "organization.nameEnglish, " +
                                "organization.nameFrench, " +
                                "department.departmentNameEnglish, " +
                                "department.departmentNameFrench) " +
                                "from Form form, " +
                                "PersonPosition position, " +
                                "Organization organization, " +
                                "Cod cod, " +
                                "OrgDeptLocation department " +
             "where (form.cid = position.cid) and (position.positionNumber *= cod.code) and  " +
                                "(position.orgDeptLocId *= department.orgDeptLocId) and  " +
                                "(position.orgId *= organization.orgId) and (form.formId = :formID) and  " +
                                "(position.primaryOrgInd = 'N')" +
                                "order by position.positionEndYear DESC, " +
                                "position.positionStartYear DESC")
                                    .setParameter("formID", formId)
                                    .list();
             */
            queryList = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.cv.ExperienceDetailBean(position.positionId, " +
                    "position.cid, " +
                    "position.orgDeptLocation, " +
                    "position.positionNumber, " +
                    "position.positionStartYear, " +
                    "position.positionEndYear, " +
                    "position.otherOrgName, " +
                    "position.otherDepartmentName, " +
                    "position.otherPositionName, " +
                    "position.organization, " +
                    "cod.shortNameEnglish, " +
                    "cod.shortNameFrench, " +
                    "organization.nameEnglish, " +
                    "organization.nameFrench, " +
                    "department.departmentNameEnglish, " +
                    "department.departmentNameFrench) " +
                    "from Form form join form.person person " +
                    "left outer join fetch person.personPosition position " +
                    "left outer join fetch position.organization organization " +
                    "left outer join fetch position.positionNumber cod " +
                    "left outer join fetch position.orgDeptLocation department " +
                    "where (form.formId = :formID) and  " +
                    "(position.primaryOrgInd = 'N')" +
                    "order by position.positionEndYear DESC, " +
                    "position.positionStartYear DESC")
                        .setParameter("formID", formId)
                        .list();
            logger.info("number of rows retireved : " + queryList.size());
            if (queryList.size() > 0) {

                this.workExperiences.addAll(queryList);

            }

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded workExperiences : " + workExperiences.size());

            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * save
     *
     * @param session Session
     * @return String
     */
    public String save(Session session) throws HibernateException, InvocationTargetException,
            IllegalAccessException {
        List queryList;
        ExperienceDetailBean tempBean = null;
        hibernate.PersonPosition myPosition = null;
        String saveOutcome = "failure"; // Defaults to failure

        logger.info("In ExperienceBean.save()");
        logger.info("We have " + this.workExperiences.size() + " beans in workexperiences");
        if (this.workExperiences.size() > 0) {
            //           for (int i = 0; i < this.workExperiences.size(); i++){
            tempBean = (ExperienceDetailBean)this.workExperiences.get(0);
            logger.info("the cid = " + tempBean.getCid());
            //               logger.info("other position text = "+tempBean.getOtherPositionName());
//            }
        }

        HibernateUtil.beginTransaction();

        queryList = session.createQuery("from PersonPosition " +
                                        "where cid = :cid and Primary_Org_Ind = 'N'")
                    .setParameter("cid", tempBean.getCid())
                    .list();
        logger.info("In ExperienceBean.save() - Retrieved hibernate.PersonPosition object for cid: " +
                    tempBean.getCid());

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Loaded hibernate.PersonPosition objects : " + queryList.size());
        }

        if (this.workExperiences.size() > 0) {
            // Set values
            for (int i = 0; i < this.workExperiences.size(); i++) {
                tempBean = (ExperienceDetailBean)this.workExperiences.get(i);

                // Check that this is an existing record
                if (tempBean.getPositionId() == null) {
                    logger.info("this is a new record");
                    // there is no record, copy the bean and save
                    hibernate.PersonPosition newPosition = new PersonPosition();
                    BeanUtils.copyProperties(newPosition, tempBean);
                    session.saveOrUpdate(newPosition);
                    session.flush();
                    session.refresh(newPosition);
                    saveOutcome = "success";

                } else {

                    // this is an existing record. Locate the matching one in the database
                    Iterator it = queryList.iterator();
                    while (it.hasNext()) {
                        myPosition = (PersonPosition) it.next();
                        if (myPosition.getPositionId().equals(tempBean.getPositionId())) {
                            // this is the correct record, update and save
                            BeanUtils.copyProperties(myPosition, tempBean);
                            session.saveOrUpdate(myPosition);
                            session.flush();
                            saveOutcome = "success";
                            break;
                        }
                    }

                }

            }
        }

        return saveOutcome;
    }


}
