package ca.sshrc.web.lookupCache;

import java.io.*;
import java.text.*;
import java.util.*;

import ca.sshrc.web.common.services.*;
import hibernate.*;
import org.hibernate.*;
import org.apache.log4j.*;
import ca.sshrc.web.common.util.Constants;

public class FundingOrganizationCache implements Serializable {
    private Logger logger = Logger.getLogger(FundingOrganizationCache.class.getName());
    private List queryList;

    public FundingOrganizationCache() {
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In FundingOrganizationCache");

            /* Original SQL from PB - dddw_cv_funding_orgs

                         SELECT  organization.org_id ,
                                    organization.name_english ,
                                    organization.name_french
                                 FROM funding_orgs ,
                                    organization
                                 WHERE ( funding_orgs.org_id = organization.org_id ) and
                 (  organization.org_id > 1)
             */

            queryList = session.createQuery(
                    "select new hibernate.Organization(Organization.orgId, " +
                    "Organization.nameEnglish, " +
                    "Organization.nameFrench) " +
                    "from FundingOrg FundingOrg, " +
                    "Organization Organization " +
                    "where FundingOrg.orgId = Organization.orgId and " +
                        "Organization.orgId > 1").list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Organization loaded: " + queryList.size());
            }

        } catch (HibernateException ex) {
            ex.printStackTrace();
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
        } finally {
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public static final Comparator nameEnglishOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            Organization objComp1 = (Organization) o1;
            Organization objComp2 = (Organization) o2;
            return myCollator.compare(objComp1.getNameEnglish(),
                                      objComp2.getNameEnglish());
        }
    };

    public static final Comparator nameFrenchOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA_FRENCH);
            Organization objComp1 = (Organization) o1;
            Organization objComp2 = (Organization) o2;
            return myCollator.compare(objComp1.getNameFrench(),
                                      objComp2.getNameFrench());
        }
    };
    public List getList(String language) {
        // Keep the original array. Use a copy for sorting
        ArrayList listTemp = new ArrayList(queryList);

        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            Collections.sort(listTemp, nameFrenchOrder);
        } else {
            Collections.sort(listTemp, nameEnglishOrder);
        }

        // Add row for orgId 1, "Other"
        // This is required because AMIS's orgId 1's description is "Other/Unknown" and our must be "Other"
        Organization organization = new Organization(new Integer(1),"Other", "Autre");
        listTemp.add(0,organization);

        return listTemp;
    }
}
