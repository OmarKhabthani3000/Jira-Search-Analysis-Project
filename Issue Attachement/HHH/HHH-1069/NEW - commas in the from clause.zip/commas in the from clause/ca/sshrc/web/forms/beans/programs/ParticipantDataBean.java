package ca.sshrc.web.forms.beans.programs;



import java.util.*;

import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.*;
import org.apache.commons.lang.builder.*;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author Pierre Mass�
 * @version 1.0
 */
public class ParticipantDataBean extends BeanBase {

    private Integer partId;
    private Integer participationType;
    private Integer applId;
    private Integer roleCode;
    private Integer orgDeptLocId;
    private Integer cid;
    private String familyName;
    private String givenName;
    private String initials;
    private String departmentName;
    private Date changeDate;
    private Integer orgId;
    private Integer dataCentreId;
    private String departmentNameEnglish;
    private String departmentNameFrench;
    private String formLanguage;
    private boolean delete = false;
    private Long formId;
    private String orgName;
    private String orgNameEnglish;
    private String orgNameFrench;
//    private String computedSortValue;

    /**
     * Full constructor
     *
     * @param formId Long
     * @param partId Integer
     * @param participationType Integer
     * @param applId Integer
     * @param roleCode Integer
     * @param orgDeptLocId Integer
     * @param cid Integer
     * @param familyName String
     * @param givenName String
     * @param initials String
     * @param orgName String
     * @param departmentName String
     * @param changeDate Date
     * @param orgId Integer
     * @param dataCentreId Integer
     * @param departmentNameEnglish String
     * @param departmentNameFrench String
     * @param formLanguage String
     */
    public ParticipantDataBean(Long formId, Integer partId, Integer participationType, Integer applId,
                               Integer roleCode,
                               Integer orgDeptLocId, Integer cid, String familyName, String givenName,
                               String initials,
                               String otherOrgName, String otherDepartmentName, Date changeDate, Integer orgId,
                               Integer dataCentreId,
                               String departmentNameEnglish, String departmentNameFrench, String orgNameEnglish, String orgNameFrench, String formLanguage) {
//        String departmentNameEnglish, String departmentNameFrench, String orgNameEnglish, String orgNameFrench, String computedSortValue, String formLanguage) {

        this.formId = formId;
        this.partId = partId;
        this.participationType = participationType;
        this.applId = applId;
        this.roleCode = roleCode;
        this.orgDeptLocId = orgDeptLocId;
        this.cid = cid;
        this.familyName = trim(familyName);
        this.givenName = trim(givenName);
        this.initials = trim(initials);
        this.orgName = trim(otherOrgName);
        this.departmentName = trim(otherDepartmentName);
        this.changeDate = changeDate;
        this.orgId = orgId;
        this.dataCentreId = dataCentreId;
        this.departmentNameEnglish = departmentNameEnglish;
        this.departmentNameFrench = departmentNameFrench;
        this.orgNameEnglish = orgNameEnglish;
        this.orgNameFrench = orgNameFrench;
        this.formLanguage = formLanguage;
//        this.computedSortValue = computedSortValue;
    }

    /**
     * Default Constructor
     */
    public ParticipantDataBean() {
    }


    /**
     * Getters & Setters
     */

    public void setDelete(boolean delete) {
        this.delete = delete;
    }

    public boolean isDelete() {
        return this.delete;
    }

    public void setFormId(Long formId) {
        this.formId = formId;
    }

    public Long getFormId() {
        return this.formId;
    }

    public Integer getPartId() {
        return this.partId;
    }

    public Integer getParticipationType() {
        return this.participationType;
    }

    public Integer getApplId() {
        return this.applId;
    }

    public Integer getRoleCode() {
        return this.roleCode;
    }

    public Integer getOrgDeptLocId() {
        return this.orgDeptLocId;
    }

    public Integer getCid() {
        return this.cid;
    }

    public String getFamilyName() {
        return this.familyName;
    }

    public String getGivenName() {
        return this.givenName;
    }

    public String getInitials() {
        return this.initials;
    }

    public String getOrgNameForDisplay() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.orgNameFrench != null) {
                returnedName = this.orgNameFrench;
            }
        } else if (this.orgNameEnglish != null) {
            returnedName = this.orgNameEnglish;
        }
        return returnedName;
    }

    public String getDepartmentName() {
        return this.departmentName;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public Integer getOrgId() {
        return this.orgId;
    }

    public Integer getDataCentreId() {
        return this.dataCentreId;
    }

    public String getDepartmentNameEnglish() {
        return this.departmentNameEnglish;
    }

    public String getDepartmentNameFrench() {
        return this.departmentNameFrench;
    }

    public String getFormLanguage() {
        return this.formLanguage;
    }

    public String getOrgName() {
        return this.orgName;
    }


    public String getOrgNameEnglish() {
        return this.orgNameEnglish;
    }

    public String getOrgNameFrench() {
        return this.orgNameFrench;
    }

    public String getDeptName() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.departmentNameFrench != null) {
                returnedName = this.departmentNameFrench;
            }
        } else if (this.departmentNameEnglish != null) {
            returnedName = this.departmentNameEnglish;
        }
        return returnedName;

    }

    public void setPartId(Integer partId) {
        this.partId = partId;
    }

    public void setParticipationType(Integer participationType) {
        this.participationType = participationType;
    }

    public void setApplId(Integer applId) {
        this.applId = applId;
    }

    public void setRoleCode(Integer roleCode) {
        this.roleCode = roleCode;
    }

    public void setOrgDeptLocId(Integer orgDeptLocId) {
        this.orgDeptLocId = orgDeptLocId;
    }

    public void setCid(Integer cid) {
            this.cid = cid;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public void setDepartmentName(String otherDepartmentName) {
        this.departmentName = otherDepartmentName;
    }

    public void setDeptName(String deptName) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setDepartmentNameFrench(deptName);
        } else {
            this.setDepartmentNameEnglish(deptName);
        }
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public void setDataCentreId(Integer dataCentreId) {
        this.dataCentreId = dataCentreId;
    }

    public void setDepartmentNameEnglish(String departmentNameEnglish) {
        this.departmentNameEnglish = departmentNameEnglish;
    }

    public void setDepartmentNameFrench(String departmentNameFrench) {
        this.departmentNameFrench = departmentNameFrench;
    }

    public void setFormLanguage(String formLanguage) {
        this.formLanguage = formLanguage;
    }

    public void setOrgName(String otherOrgName) {
        this.orgName = otherOrgName;
    }

    public void setOrgNameForDisplay(String orgName) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setOrgNameFrench(orgName);
        } else {
            this.setOrgNameEnglish(orgName);
        }
    }

    public void setOrgNameEnglish(String orgNameEnglish) {
        this.orgNameEnglish = orgNameEnglish;
    }

    public void setOrgNameFrench(String orgNameFrench) {
        this.orgNameFrench = orgNameFrench;
    }

    /**
     * Over writing isEmpty().
     *
     * @return boolean
     */
    public boolean isEmpty() {
        // Load String array with property names to be check when figuring out if a bean is empty or not
        String[] propertyNamesForEmptiness = {"orgDeptLocId", "cid", "familyName",
                                             "givenName", "initials", "orgId",
                                             "orgName", "departmentName", "dataCentreId"};

        return this.isEmpty(propertyNamesForEmptiness);
    }

    /**
     * toString()
     *
     * @return String
     */
    public String toString() {
        return new ToStringBuilder(this)
                .append("partId", getPartId())
                .toString();
    }

    /**
     * equals()
     *
     * @param other Object
     * @return boolean
     */
    public boolean equals(Object other) {
        if (!(other instanceof ParticipantDataBean)) {
            return false;
        }
        ParticipantDataBean castOther = (ParticipantDataBean) other;
        return new EqualsBuilder()
                .append(this.getPartId(), castOther.getPartId())
                .isEquals();
    }

    /**
     * hashCode()
     *
     * @return int
     */
    public int hashCode() {
        return new HashCodeBuilder()
                .append(getPartId())
                .toHashCode();
    }
}
