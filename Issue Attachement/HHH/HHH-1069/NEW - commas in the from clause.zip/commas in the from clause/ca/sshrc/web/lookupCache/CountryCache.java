package ca.sshrc.web.lookupCache;

import java.io.*;
import java.text.*;
import java.util.*;

import ca.sshrc.web.common.services.*;
import hibernate.*;
import org.hibernate.*;
import org.apache.log4j.*;
import ca.sshrc.web.common.util.Constants;

public class CountryCache implements Serializable {
    private Logger logger = Logger.getLogger(CountryCache.class.getName());
    private List queryList;

    public CountryCache() {
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In CountryCache");

            queryList = session.createQuery(
                    "select new hibernate.Country(Country.countryCode, " +
                    "Country.nameEnglish, " +
                    "Country.nameFrench, " +
                    "Country.activeInd) " +
                    "from Country Country " +
                    "where Country.countryCode not in(9000,9999) and Country.activeInd = 'Y'").list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Country loaded: " + queryList.size());
            }

        } catch (HibernateException ex) {
            ex.printStackTrace();
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
        } finally {
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }


        // test beanutils stuff
/*        System.out.println("Testing beanutils stuff");
        IdentificationBean test = new IdentificationBean();
        Map map = null;
        try {
            map = PropertyUtils.describe(test);
        } catch (NoSuchMethodException ex1) {
        } catch (InvocationTargetException ex1) {
        } catch (IllegalAccessException ex1) {
        }
        if(!map.isEmpty()) {

            Collection coll = map.values();
            Iterator it = coll.iterator();
            while (it.hasNext()){
                System.out.println("Map: " + it.toString());
            }
        }        */
    }

    public static final Comparator nameEnglishOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            Country objComp1 = (Country) o1;
            Country objComp2 = (Country) o2;
            return myCollator.compare(objComp1.getNameEnglish(),
                                      objComp2.getNameEnglish());
        }
    };

    public static final Comparator nameFrenchOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA_FRENCH);
            Country objComp1 = (Country) o1;
            Country objComp2 = (Country) o2;
            return myCollator.compare(objComp1.getNameFrench(),
                                      objComp2.getNameFrench());
        }
    };
    public List getList(String language) {
        // Keep the original array. Use a copy for sorting
        List listTemp;
        listTemp = queryList;

        if (language.equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            Collections.sort(listTemp, nameFrenchOrder);
        } else {
            Collections.sort(listTemp, nameEnglishOrder);
        }
        return listTemp;
    }
}
