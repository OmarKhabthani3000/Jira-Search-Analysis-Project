package ca.sshrc.web.forms.beans.cv;


import java.math.*;
import java.util.*;
import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.Constants;


/**
 * <p>Title: CredentialDataBean</p>
 *
 * <p>Description: This bean contains the data to be displayed on the cv Credentials page</p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */

public class CredentialDataBean extends BeanBase {

    private Integer distId;
    private Integer cid;
    private Integer distinctionType;
    private Date receivedDate;
    private String distinctionName;
    private BigDecimal distinctionAmount;
    private Integer countryCode;
    private Date changeDate;
    private String countryNameEnglish;
    private String countryNameFrench;


    /**
     * CredentialDataBean
     * Empty constructor
     */

    public CredentialDataBean() {
        this.cid = this.getLogonBean().getWeb_id();
    }


    /**
     * CredentialDataBean Minimal Constructor
     *
     * @param aCid Intege
     */

    public CredentialDataBean(Integer aCid) {

        this.cid = aCid;
    }


    /**
     * CredentialDataBean Full constructor
     *
     * @param aDistinctId Integer
     * @param aCid Integer
     * @param aDistinctType Integer
     * @param aReceivedDate Date
     * @param aDistinctName String
     * @param aDistinctAmount BigDecimal
     * @param aCountryCode Integer
     * @param aChangeDate Date
     * @param aCountryNameEnglish String
     * @param aCountryNameFrench String
     */

    public CredentialDataBean(Integer aDistinctId, Integer aCid, Integer aDistinctType,
                              Date aReceivedDate, String aDistinctName, BigDecimal aDistinctAmount,
                              Integer aCountryCode, Date aChangeDate, String aCountryNameEnglish,
                              String aCountryNameFrench) {

        this.distId = aDistinctId;
        this.cid = aCid;
        this.distinctionType = aDistinctType;
        this.receivedDate = aReceivedDate;
        this.distinctionName = aDistinctName;
        this.distinctionAmount = aDistinctAmount;
        this.countryCode = aCountryCode;
        this.changeDate = aChangeDate;
        this.countryNameEnglish = aCountryNameEnglish;
        this.countryNameFrench = aCountryNameFrench;
    }


    public void setDistId(Integer distId) {
        this.distId = distId;
    }


    public void setCid(Integer cid) {
        this.cid = cid;
    }


    public void setDistinctionType(Integer distinctionType) {
        this.distinctionType = distinctionType;
    }

    public void setReceivedDate(Date receivedDate) {

            this.receivedDate = receivedDate;

        }


    public void setReceivedYear(Integer receivedDate) {
        if (receivedDate == null || receivedDate.equals("0")) {
            this.receivedDate = null;
        } else {
            Calendar tempDate = Calendar.getInstance();
            tempDate.set(tempDate.YEAR, receivedDate.intValue());
            this.receivedDate = tempDate.getTime();

        }

    }

    public void setDistinctionName(String distinctionName) {
        this.distinctionName = distinctionName;
    }

    public void setDistinctionAmount(BigDecimal distinctionAmount) {
        this.distinctionAmount = distinctionAmount;
    }

    public void setCountryCode(Integer countryCode) {
        this.countryCode = countryCode;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public void setCountryNameEnglish(String countryNameEnglish) {
        this.countryNameEnglish = countryNameEnglish;
    }

    public void setCountryNameFrench(String countryNameFrench) {
        this.countryNameFrench = countryNameFrench;
    }

    public void setCountryName(String countryName) {
        if (this.getNavigationBean().getFormLanguage().equals(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.countryNameFrench = countryName;
        } else {
            this.countryNameEnglish = countryName;
        }
    }

    public Integer getDistId() {
        return distId;
    }

    public Integer getCid() {
        return cid;
    }

    public Integer getDistinctionType() {
        return distinctionType;
    }

    public Integer getReceivedYear() {

        if (this.receivedDate == null) {
            return null;
        }
        Calendar tempDate = Calendar.getInstance();
        tempDate.setTime(this.receivedDate);

        return new Integer(tempDate.get(tempDate.YEAR));
    }

    public Date getReceivedDate() {

       return this.receivedDate;
    }
    public String getDistinctionName() {
        return distinctionName;
    }

    public BigDecimal getDistinctionAmount() {
        return distinctionAmount;
    }

    public Integer getCountryCode() {
        return countryCode;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public String getCountryNameEnglish() {
        return countryNameEnglish;
    }

    public String getCountryNameFrench() {
        return countryNameFrench;
    }

    public String getCountryName() {
        if (this.getNavigationBean().getFormLanguage().equals(Constants.FRENCH_CANADIAN_LOCALE)) {
            return this.countryNameFrench;
        } else {
            return this.countryNameEnglish;
        }
    }

    /**
     * hasData
     *
     * @return boolean
     */
    public boolean hasData() {
        if ((this.countryCode == null || this.countryCode.intValue() == 0) &&
            (this.distinctionName == null || this.distinctionName.equals("")) &&
            (this.distinctionType == null || this.distinctionType.intValue() == 0) &&
            (this.receivedDate == null)) {

            return false;
        } else {
            return true;
        }
    }

}
