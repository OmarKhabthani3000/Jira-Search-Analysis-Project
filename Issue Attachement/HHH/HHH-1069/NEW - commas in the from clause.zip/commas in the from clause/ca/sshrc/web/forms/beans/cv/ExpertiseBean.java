package ca.sshrc.web.forms.beans.cv;

import java.lang.reflect.*;
import java.util.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.util.*;
import hibernate.*;
import org.apache.commons.beanutils.*;
import org.apache.commons.lang.builder.*;
import org.apache.log4j.*;
import org.hibernate.*;

/**
 * <p>Title: CV Expertise bean</p>
 *
 * <p>Description: Used on the CV BeanUtils.copyProperties web page</p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class ExpertiseBean extends ca.sshrc.web.common.services.baseObject.BeanBase {

    private Logger logger = Logger.getLogger(ExpertiseBean.class.getName());

    /** persistent field */
    private Long formId;

    /** identifier field */
    private Integer cid;

    /** nullable persistent field */
    private String keywords;

    /** nullable persistent field */
    private hibernate.Discipline disciplineCode1;
    private String disciplineNameFrench1;
    private String disciplineNameEnglish1;

    /** nullable persistent field */
    private String otherDisciplineName1;

    /** nullable persistent field */
    private hibernate.Discipline disciplineCode2;
    private String disciplineNameFrench2;
    private String disciplineNameEnglish2;

    /** nullable persistent field */
    private String otherDisciplineName2;

    /** nullable persistent field */
    private hibernate.Discipline disciplineCode3;
    private String disciplineNameFrench3;
    private String disciplineNameEnglish3;

    /** nullable persistent field */
    private String otherDisciplineName3;

    /** nullable persistent field */
    private hibernate.Discipline disciplineCode4;
    private String disciplineNameFrench4;
    private String disciplineNameEnglish4;

    /** nullable persistent field */
    private String otherDisciplineName4;

    /** nullable persistent field */
    private hibernate.Discipline disciplineCode5;
    private String disciplineNameFrench5;
    private String disciplineNameEnglish5;

    /** nullable persistent field */
    private String otherDisciplineName5;

    /** nullable persistent field */
    private hibernate.Cod areaOfResearchCode1;
    private String areaOfResearchNameFrench1;
    private String areaOfResearchNameEnglish1;

    /** nullable persistent field */
    private hibernate.Cod areaOfResearchCode2;
    private String areaOfResearchNameFrench2;
    private String areaOfResearchNameEnglish2;

    /** nullable persistent field */
    private hibernate.Cod areaOfResearchCode3;
    private String areaOfResearchNameFrench3;
    private String areaOfResearchNameEnglish3;

    /** nullable persistent field */
    private hibernate.Cod geoPoliticalCode1;
    private String geoPoliticalNameFrench1;
    private String geoPoliticalNameEnglish1;

    /** nullable persistent field */
    private hibernate.Cod geoPoliticalCode2;
    private String geoPoliticalNameFrench2;
    private String geoPoliticalNameEnglish2;

    /** nullable persistent field */
    private hibernate.Cod geoPoliticalCode3;
    private String geoPoliticalNameFrench3;
    private String geoPoliticalNameEnglish3;

    /** nullable persistent field */
    private hibernate.Country countryCode1;
    private String countryNameFrench1;
    private String countryNameEnglish1;

    /** nullable persistent field */
    private hibernate.ProvinceState provinceStateCode1;
    private String provinceStateNameFrench1;
    private String provinceStateNameEnglish1;

    /** nullable persistent field */
    private hibernate.Country countryCode2;
    private String countryNameFrench2;
    private String countryNameEnglish2;

    /** nullable persistent field */
    private hibernate.ProvinceState provinceStateCode2;
    private String provinceStateNameFrench2;
    private String provinceStateNameEnglish2;

    /** nullable persistent field */
    private hibernate.Country countryCode3;
    private String countryNameFrench3;
    private String countryNameEnglish3;

    /** nullable persistent field */
    private hibernate.ProvinceState provinceStateCode3;
    private String provinceStateNameFrench3;
    private String provinceStateNameEnglish3;

    /** nullable persistent field */
    private hibernate.Country countryCode4;
    private String countryNameFrench4;
    private String countryNameEnglish4;

    /** nullable persistent field */
    private hibernate.ProvinceState provinceStateCode4;
    private String provinceStateNameFrench4;
    private String provinceStateNameEnglish4;

    /** nullable persistent field */
    private hibernate.Country countryCode5;
    private String countryNameFrench5;
    private String countryNameEnglish5;

    /** nullable persistent field */
    private hibernate.ProvinceState provinceStateCode5;
    private String provinceStateNameFrench5;
    private String provinceStateNameEnglish5;

    /** nullable persistent field */
    private Integer temporalStartYear1;

    /** nullable persistent field */
    private String temporalStartBcAd1;

    /** nullable persistent field */
    private Integer temporalEndYear1;

    /** nullable persistent field */
    private String temporalEndBcAd1;

    /** nullable persistent field */
    private Integer temporalStartYear2;

    /** nullable persistent field */
    private String temporalStartBcAd2;

    /** nullable persistent field */
    private Integer temporalEndYear2;

    /** nullable persistent field */
    private String temporalEndBcAd2;

    /** nullable persistent field */
    private Date changeDate;

    /** full constructor */
    public ExpertiseBean(Long formId,
                         Integer cid,
                         String keywords,
                         hibernate.Discipline disciplineCode1,
                         String disciplineNameFrench1,
                         String disciplineNameEnglish1,
                         String otherDisciplineName1,
                         hibernate.Discipline disciplineCode2,
                         String disciplineNameFrench2,
                         String disciplineNameEnglish2,
                         String otherDisciplineName2,
                         hibernate.Discipline disciplineCode3,
                         String disciplineNameFrench3,
                         String disciplineNameEnglish3,
                         String otherDisciplineName3,
                         hibernate.Discipline disciplineCode4,
                         String disciplineNameFrench4,
                         String disciplineNameEnglish4,
                         String otherDisciplineName4,
                         hibernate.Discipline disciplineCode5,
                         String disciplineNameFrench5,
                         String disciplineNameEnglish5,
                         String otherDisciplineName5,
                         hibernate.Cod areaOfResearchCode1,
                         String areaOfResearchNameFrench1,
                         String areaOfResearchNameEnglish1,
                         hibernate.Cod areaOfResearchCode2,
                         String areaOfResearchNameFrench2,
                         String areaOfResearchNameEnglish2,
                         hibernate.Cod areaOfResearchCode3,
                         String areaOfResearchNameFrench3,
                         String areaOfResearchNameEnglish3,
                         hibernate.Cod geoPoliticalCode1,
                         String geoPoliticalNameFrench1,
                         String geoPoliticalNameEnglish1,
                         hibernate.Cod geoPoliticalCode2,
                         String geoPoliticalNameFrench2,
                         String geoPoliticalNameEnglish2,
                         hibernate.Cod geoPoliticalCode3,
                         String geoPoliticalNameFrench3,
                         String geoPoliticalNameEnglish3,
                         hibernate.Country countryCode1,
                         String countryNameFrench1,
                         String countryNameEnglish1,
                         hibernate.ProvinceState provinceStateCode1,
                         String provinceStateFrench1,
                         String provinceStateEnglish1,
                         hibernate.Country countryCode2,
                         String countryNameFrench2,
                         String countryNameEnglish2,
                         hibernate.ProvinceState provinceStateCode2,
                         String provinceStateFrench2,
                         String provinceStateEnglish2,
                         hibernate.Country countryCode3,
                         String countryNameFrench3,
                         String countryNameEnglish3,
                         hibernate.ProvinceState provinceStateCode3,
                         String provinceStateFrench3,
                         String provinceStateEnglish3,
                         hibernate.Country countryCode4,
                         String countryNameFrench4,
                         String countryNameEnglish4,
                         hibernate.ProvinceState provinceStateCode4,
                         String provinceStateFrench4,
                         String provinceStateEnglish4,
                         hibernate.Country countryCode5,
                         String countryNameFrench5,
                         String countryNameEnglish5,
                         hibernate.ProvinceState provinceStateCode5,
                         String provinceStateFrench5,
                         String provinceStateEnglish5,
                         Integer temporalStartYear1,
                         String temporalStartBcAd1,
                         Integer temporalEndYear1,
                         String temporalEndBcAd1,
                         Integer temporalStartYear2,
                         String temporalStartBcAd2,
                         Integer temporalEndYear2,
                         String temporalEndBcAd2,
                         Date changeDate) {
        this.formId = formId;
        this.cid = cid;
        this.keywords = keywords;

        this.disciplineCode1 = disciplineCode1;
        this.disciplineNameFrench1 = disciplineNameFrench1;
        this.disciplineNameEnglish1 = disciplineNameEnglish1;
        this.otherDisciplineName1 = otherDisciplineName1;

        this.disciplineCode2 = disciplineCode2;
        this.disciplineNameFrench2 = disciplineNameFrench2;
        this.disciplineNameEnglish2 = disciplineNameEnglish2;
        this.otherDisciplineName2 = otherDisciplineName2;

        this.disciplineCode3 = disciplineCode3;
        this.disciplineNameFrench3 = disciplineNameFrench3;
        this.disciplineNameEnglish3 = disciplineNameEnglish3;
        this.otherDisciplineName3 = otherDisciplineName3;

        this.disciplineCode4 = disciplineCode4;
        this.disciplineNameFrench4 = disciplineNameFrench4;
        this.disciplineNameEnglish4 = disciplineNameEnglish4;
        this.otherDisciplineName4 = otherDisciplineName4;

        this.disciplineCode5 = disciplineCode5;
        this.disciplineNameFrench5 = disciplineNameFrench5;
        this.disciplineNameEnglish5 = disciplineNameEnglish5;
        this.otherDisciplineName5 = otherDisciplineName5;

        this.areaOfResearchCode1 = areaOfResearchCode1;
        this.areaOfResearchNameFrench1 = areaOfResearchNameFrench1;
        this.areaOfResearchNameEnglish1 = areaOfResearchNameEnglish1;

        this.areaOfResearchCode2 = areaOfResearchCode2;
        this.areaOfResearchNameFrench2 = areaOfResearchNameFrench2;
        this.areaOfResearchNameEnglish2 = areaOfResearchNameEnglish2;

        this.areaOfResearchCode3 = areaOfResearchCode3;
        this.areaOfResearchNameFrench3 = areaOfResearchNameFrench3;
        this.areaOfResearchNameEnglish3 = areaOfResearchNameEnglish3;

        this.geoPoliticalCode1 = geoPoliticalCode1;
        this.geoPoliticalNameFrench1 = geoPoliticalNameFrench1;
        this.geoPoliticalNameEnglish1 = geoPoliticalNameEnglish1;

        this.geoPoliticalCode2 = geoPoliticalCode2;
        this.geoPoliticalNameFrench2 = geoPoliticalNameFrench2;
        this.geoPoliticalNameEnglish2 = geoPoliticalNameEnglish2;

        this.geoPoliticalCode3 = geoPoliticalCode3;
        this.geoPoliticalNameFrench3 = geoPoliticalNameFrench3;
        this.geoPoliticalNameEnglish3 = geoPoliticalNameEnglish3;

        this.countryCode1 = countryCode1;
        this.countryNameFrench1 = countryNameFrench1;
        this.countryNameEnglish1 = countryNameEnglish1;

        this.provinceStateCode1 = provinceStateCode1;
        this.provinceStateNameFrench1 = provinceStateFrench1;
        this.provinceStateNameEnglish1 = provinceStateEnglish1;

        this.countryCode2 = countryCode2;
        this.countryNameFrench2 = countryNameFrench2;
        this.countryNameEnglish2 = countryNameEnglish2;

        this.provinceStateCode2 = provinceStateCode2;
        this.provinceStateNameFrench2 = provinceStateFrench2;
        this.provinceStateNameEnglish2 = provinceStateEnglish2;

        this.countryCode3 = countryCode3;
        this.countryNameFrench3 = countryNameFrench3;
        this.countryNameEnglish3 = countryNameEnglish3;

        this.provinceStateCode3 = provinceStateCode3;
        this.provinceStateNameFrench3 = provinceStateFrench3;
        this.provinceStateNameEnglish3 = provinceStateEnglish3;

        this.countryCode4 = countryCode4;
        this.countryNameFrench4 = countryNameFrench4;
        this.countryNameEnglish4 = countryNameEnglish4;

        this.provinceStateCode4 = provinceStateCode4;
        this.provinceStateNameFrench4 = provinceStateFrench4;
        this.provinceStateNameEnglish4 = provinceStateEnglish4;

        this.countryCode5 = countryCode5;
        this.countryNameFrench5 = countryNameFrench5;
        this.countryNameEnglish5 = countryNameEnglish5;

        this.provinceStateCode5 = provinceStateCode5;
        this.provinceStateNameFrench5 = provinceStateFrench5;
        this.provinceStateNameEnglish5 = provinceStateEnglish5;

        this.temporalStartYear1 = temporalStartYear1;
        this.temporalStartBcAd1 = temporalStartBcAd1;
        this.temporalEndYear1 = temporalEndYear1;
        this.temporalEndBcAd1 = temporalEndBcAd1;
        this.temporalStartYear2 = temporalStartYear2;
        this.temporalStartBcAd2 = temporalStartBcAd2;
        this.temporalEndYear2 = temporalEndYear2;
        this.temporalEndBcAd2 = temporalEndBcAd2;
        this.changeDate = changeDate;
    }

    /** default constructor */
    public ExpertiseBean() {

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("ExpertiseBean.constructor");
        }
        /**
         * Only retrieve the data if the current phase is Render Response phase.
         * (There's no need to retrieve during the Restore View phase).
         * */
        if (this.getFacesContext().getRenderResponse()) {
            try {
                // Get a session
                Session session = HibernateUtil.getSession();
                HibernateUtil.beginTransaction();

                // Call this object's retrieve method
                this.retrieve(new Long(0), session);

            } catch (Exception ex) {
                HibernateUtil.closeSession();
                ex.printStackTrace();
            } finally {
                // Close the Hibernate connection
                try {
                    HibernateUtil.commitTransaction();
                    HibernateUtil.closeSession();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }

    }

    public Integer getCid() {
        return this.cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public String getKeywords() {
        return this.keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public hibernate.Discipline getDisciplineCode1() {
        return this.disciplineCode1;
    }

    public void setDisciplineCode1(hibernate.Discipline disciplineCode1) {
        this.disciplineCode1 = disciplineCode1;
    }

    public String getOtherDisciplineName1() {
        return this.otherDisciplineName1;
    }

    public void setOtherDisciplineName1(String otherDisciplineName1) {
        this.otherDisciplineName1 = otherDisciplineName1;
    }

    public hibernate.Discipline getDisciplineCode2() {
        return this.disciplineCode2;
    }

    public void setDisciplineCode2(hibernate.Discipline disciplineCode2) {
        this.disciplineCode2 = disciplineCode2;
    }

    public String getOtherDisciplineName2() {
        return this.otherDisciplineName2;
    }

    public void setOtherDisciplineName2(String otherDisciplineName2) {
        this.otherDisciplineName2 = otherDisciplineName2;
    }

    public hibernate.Discipline getDisciplineCode3() {
        return this.disciplineCode3;
    }

    public void setDisciplineCode3(hibernate.Discipline disciplineCode3) {
        this.disciplineCode3 = disciplineCode3;
    }

    public String getOtherDisciplineName3() {
        return this.otherDisciplineName3;
    }

    public void setOtherDisciplineName3(String otherDisciplineName3) {
        this.otherDisciplineName3 = otherDisciplineName3;
    }

    public hibernate.Discipline getDisciplineCode4() {
        return this.disciplineCode4;
    }

    public void setDisciplineCode4(hibernate.Discipline disciplineCode4) {
        this.disciplineCode4 = disciplineCode4;
    }

    public String getOtherDisciplineName4() {
        return this.otherDisciplineName4;
    }

    public void setOtherDisciplineName4(String otherDisciplineName4) {
        this.otherDisciplineName4 = otherDisciplineName4;
    }

    public hibernate.Discipline getDisciplineCode5() {
        return this.disciplineCode5;
    }

    public void setDisciplineCode5(hibernate.Discipline disciplineCode5) {
        this.disciplineCode5 = disciplineCode5;
    }

    public String getOtherDisciplineName5() {
        return this.otherDisciplineName5;
    }

    public void setOtherDisciplineName5(String otherDisciplineName5) {
        this.otherDisciplineName5 = otherDisciplineName5;
    }

    public hibernate.Cod getAreaOfResearchCode1() {
        return this.areaOfResearchCode1;
    }

    public void setAreaOfResearchCode1(hibernate.Cod areaOfResearchCode1) {
        this.areaOfResearchCode1 = areaOfResearchCode1;
    }

    public hibernate.Cod getAreaOfResearchCode2() {
        return this.areaOfResearchCode2;
    }

    public void setAreaOfResearchCode2(hibernate.Cod areaOfResearchCode2) {
        this.areaOfResearchCode2 = areaOfResearchCode2;
    }

    public hibernate.Cod getAreaOfResearchCode3() {
        return this.areaOfResearchCode3;
    }

    public void setAreaOfResearchCode3(hibernate.Cod areaOfResearchCode3) {
        this.areaOfResearchCode3 = areaOfResearchCode3;
    }

    public hibernate.Cod getGeoPoliticalCode1() {
        return this.geoPoliticalCode1;
    }

    public void setGeoPoliticalCode1(hibernate.Cod geoPoliticalCode1) {
        this.geoPoliticalCode1 = geoPoliticalCode1;
    }

    public hibernate.Cod getGeoPoliticalCode2() {
        return this.geoPoliticalCode2;
    }

    public void setGeoPoliticalCode2(hibernate.Cod geoPoliticalCode2) {
        this.geoPoliticalCode2 = geoPoliticalCode2;
    }

    public hibernate.Cod getGeoPoliticalCode3() {
        return this.geoPoliticalCode3;
    }

    public void setGeoPoliticalCode3(hibernate.Cod geoPoliticalCode3) {
        this.geoPoliticalCode3 = geoPoliticalCode3;
    }

    public hibernate.Country getCountryCode1() {
        return this.countryCode1;
    }

    public void setCountryCode1(hibernate.Country countryCode1) {
        this.countryCode1 = countryCode1;
    }

    public hibernate.ProvinceState getProvinceStateCode1() {
        return this.provinceStateCode1;
    }

    public void setProvinceStateCode1(hibernate.ProvinceState provinceStateCode1) {
        this.provinceStateCode1 = provinceStateCode1;
    }

    public hibernate.Country getCountryCode2() {
        return this.countryCode2;
    }

    public void setCountryCode2(hibernate.Country countryCode2) {
        this.countryCode2 = countryCode2;
    }

    public hibernate.ProvinceState getProvinceStateCode2() {
        return this.provinceStateCode2;
    }

    public void setProvinceStateCode2(hibernate.ProvinceState provinceStateCode2) {
        this.provinceStateCode2 = provinceStateCode2;
    }

    public hibernate.Country getCountryCode3() {
        return this.countryCode3;
    }

    public void setCountryCode3(hibernate.Country countryCode3) {
        this.countryCode3 = countryCode3;
    }

    public hibernate.ProvinceState getProvinceStateCode3() {
        return this.provinceStateCode3;
    }

    public void setProvinceStateCode3(hibernate.ProvinceState provinceStateCode3) {
        this.provinceStateCode3 = provinceStateCode3;
    }

    public hibernate.Country getCountryCode4() {
        return this.countryCode4;
    }

    public void setCountryCode4(hibernate.Country countryCode4) {
        this.countryCode4 = countryCode4;
    }

    public hibernate.ProvinceState getProvinceStateCode4() {
        return this.provinceStateCode4;
    }

    public void setProvinceStateCode4(hibernate.ProvinceState provinceStateCode4) {
        this.provinceStateCode4 = provinceStateCode4;
    }

    public hibernate.Country getCountryCode5() {
        return this.countryCode5;
    }

    public void setCountryCode5(hibernate.Country countryCode5) {
        this.countryCode5 = countryCode5;
    }

    public hibernate.ProvinceState getProvinceStateCode5() {
        return this.provinceStateCode5;
    }

    public void setProvinceStateCode5(hibernate.ProvinceState provinceStateCode5) {
        this.provinceStateCode5 = provinceStateCode5;
    }

    public Integer getTemporalStartYear1() {
        return this.temporalStartYear1;
    }

    public void setTemporalStartYear1(Integer temporalStartYear1) {
        this.temporalStartYear1 = temporalStartYear1;
    }

    public String getTemporalStartBcAd1() {
        return this.temporalStartBcAd1;
    }

    public void setTemporalStartBcAd1(String temporalStartBcAd1) {
        this.temporalStartBcAd1 = temporalStartBcAd1;
    }

    public Integer getTemporalEndYear1() {
        return this.temporalEndYear1;
    }

    public void setTemporalEndYear1(Integer temporalEndYear1) {
        this.temporalEndYear1 = temporalEndYear1;
    }

    public String getTemporalEndBcAd1() {
        return this.temporalEndBcAd1;
    }

    public void setTemporalEndBcAd1(String temporalEndBcAd1) {
        this.temporalEndBcAd1 = temporalEndBcAd1;
    }

    public Integer getTemporalStartYear2() {
        return this.temporalStartYear2;
    }

    public void setTemporalStartYear2(Integer temporalStartYear2) {
        this.temporalStartYear2 = temporalStartYear2;
    }

    public String getTemporalStartBcAd2() {
        return this.temporalStartBcAd2;
    }

    public void setTemporalStartBcAd2(String temporalStartBcAd2) {
        this.temporalStartBcAd2 = temporalStartBcAd2;
    }

    public Integer getTemporalEndYear2() {
        return this.temporalEndYear2;
    }

    public void setTemporalEndYear2(Integer temporalEndYear2) {
        this.temporalEndYear2 = temporalEndYear2;
    }

    public String getTemporalEndBcAd2() {
        return this.temporalEndBcAd2;
    }

    public void setTemporalEndBcAd2(String temporalEndBcAd2) {
        this.temporalEndBcAd2 = temporalEndBcAd2;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    /**
     * Return Area Of Research name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getAreaOfResearchName1() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.areaOfResearchNameFrench1 != null) {
                returnedName = this.areaOfResearchNameFrench1;
            }
        } else if (this.areaOfResearchNameEnglish1 != null) {
            returnedName = this.areaOfResearchNameEnglish1;
        }

        return returnedName;
    }

    public void setAreaOfResearchName1(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setAreaOfResearchNameFrench1(name);
        } else {
            this.setAreaOfResearchNameEnglish1(name);
        }
    }

    public String getAreaOfResearchNameEnglish1() {
        return areaOfResearchNameEnglish1;
    }

    public String getAreaOfResearchNameFrench1() {
        return areaOfResearchNameFrench1;
    }

    /**
     * Return Area Of Research name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getAreaOfResearchName2() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.areaOfResearchNameFrench2 != null) {
                returnedName = this.areaOfResearchNameFrench2;
            }
        } else if (this.areaOfResearchNameEnglish2 != null) {
            returnedName = this.areaOfResearchNameEnglish2;
        }

        return returnedName;
    }

    public void setAreaOfResearchName2(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setAreaOfResearchNameFrench2(name);
        } else {
            this.setAreaOfResearchNameEnglish2(name);
        }
    }

    public String getAreaOfResearchNameEnglish2() {
        return areaOfResearchNameEnglish2;
    }

    public String getAreaOfResearcNameFrench2() {
        return areaOfResearchNameFrench2;
    }

    /**
     * Return Area Of Research name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getAreaOfResearchName3() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.areaOfResearchNameFrench3 != null) {
                returnedName = this.areaOfResearchNameFrench3;
            }
        } else if (this.areaOfResearchNameEnglish3 != null) {
            returnedName = this.areaOfResearchNameEnglish3;
        }

        return returnedName;
    }

    public void setAreaOfResearchName3(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setAreaOfResearchNameFrench3(name);
        } else {
            this.setAreaOfResearchNameEnglish3(name);
        }
    }

    public String getAreaOfResearchNameEnglish3() {
        return areaOfResearchNameEnglish3;
    }

    public String getAreaOfResearchNameFrench3() {
        return areaOfResearchNameFrench3;
    }

    /**
     * Return Country name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getCountryName1() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.countryNameFrench1 != null) {
                returnedName = this.countryNameFrench1;
            }
        } else if (this.countryNameEnglish1 != null) {
            returnedName = this.countryNameEnglish1;
        }

        return returnedName;
    }

    public void setCountryName1(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setCountryNameFrench1(name);
        } else {
            this.setCountryNameEnglish1(name);
        }
    }

    public String getCountryNameEnglish1() {
        return countryNameEnglish1;
    }

    /**
     * Return Country name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getCountryName2() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.countryNameFrench2 != null) {
                returnedName = this.countryNameFrench2;
            }
        } else if (this.countryNameEnglish2 != null) {
            returnedName = this.countryNameEnglish2;
        }

        return returnedName;
    }

    public void setCountryName2(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setCountryNameFrench2(name);
        } else {
            this.setCountryNameEnglish2(name);
        }
    }

    public String getCountryNameEnglish2() {
        return countryNameEnglish2;
    }

    /**
     * Return Country name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getCountryName3() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.countryNameFrench3 != null) {
                returnedName = this.countryNameFrench3;
            }
        } else if (this.countryNameEnglish3 != null) {
            returnedName = this.countryNameEnglish3;
        }

        return returnedName;
    }

    public void setCountryName3(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setCountryNameFrench3(name);
        } else {
            this.setCountryNameEnglish3(name);
        }
    }

    public String getCountryNameEnglish3() {
        return countryNameEnglish3;
    }

    /**
     * Return Country name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getCountryName4() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.countryNameFrench4 != null) {
                returnedName = this.countryNameFrench4;
            }
        } else if (this.countryNameEnglish4 != null) {
            returnedName = this.countryNameEnglish4;
        }

        return returnedName;
    }

    public void setCountryName4(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setCountryNameFrench4(name);
        } else {
            this.setCountryNameEnglish4(name);
        }
    }

    public String getCountryNameEnglish4() {
        return countryNameEnglish4;
    }

    /**
     * Return Country name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getCountryName5() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.countryNameFrench5 != null) {
                returnedName = this.countryNameFrench5;
            }
        } else if (this.countryNameEnglish5 != null) {
            returnedName = this.countryNameEnglish5;
        }

        return returnedName;
    }

    public void setCountryName5(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setCountryNameFrench5(name);
        } else {
            this.setCountryNameEnglish5(name);
        }
    }

    public String getCountryNameEnglish5() {
        return countryNameEnglish5;
    }

    public String getCountryNameFrench1() {
        return countryNameFrench1;
    }

    public String getCountryNameFrench2() {
        return countryNameFrench2;
    }

    public String getCountryNameFrench3() {
        return countryNameFrench3;
    }

    public String getCountryNameFrench4() {
        return countryNameFrench4;
    }

    public String getCountryNameFrench5() {
        return countryNameFrench5;
    }

    /**
     * Return discipline name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getDisciplineName1() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.disciplineNameFrench1 != null) {
                returnedName = this.disciplineNameFrench1;
            }
        } else if (this.disciplineNameEnglish1 != null) {
            returnedName = this.disciplineNameEnglish1;
        }

        return returnedName;
    }

    public void setDisciplineName1(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setDisciplineNameFrench1(name);
        } else {
            this.setDisciplineNameEnglish1(name);
        }
    }

    public String getDisciplineNameEnglish1() {
        return disciplineNameEnglish1;
    }

    /**
     * Return discipline name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getDisciplineName2() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.disciplineNameFrench2 != null) {
                returnedName = this.disciplineNameFrench2;
            }
        } else if (this.disciplineNameEnglish2 != null) {
            returnedName = this.disciplineNameEnglish2;
        }

        return returnedName;
    }

    public void setDisciplineName2(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setDisciplineNameFrench2(name);
        } else {
            this.setDisciplineNameEnglish2(name);
        }
    }

    public String getDisciplineNameEnglish2() {
        return disciplineNameEnglish2;
    }

    /**
     * Return discipline name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getDisciplineName3() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.disciplineNameFrench3 != null) {
                returnedName = this.disciplineNameFrench3;
            }
        } else if (this.disciplineNameEnglish3 != null) {
            returnedName = this.disciplineNameEnglish3;
        }

        return returnedName;
    }

    public void setDisciplineName3(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setDisciplineNameFrench3(name);
        } else {
            this.setDisciplineNameEnglish3(name);
        }
    }

    public String getDisciplineNameEnglish3() {
        return disciplineNameEnglish3;
    }

    /**
     * Return discipline name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getDisciplineName4() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.disciplineNameFrench4 != null) {
                returnedName = this.disciplineNameFrench4;
            }
        } else if (this.disciplineNameEnglish4 != null) {
            returnedName = this.disciplineNameEnglish4;
        }

        return returnedName;
    }

    public void setDisciplineName4(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setDisciplineNameFrench4(name);
        } else {
            this.setDisciplineNameEnglish4(name);
        }
    }

    public String getDisciplineNameEnglish4() {
        return disciplineNameEnglish4;
    }

    /**
     * Return discipline name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getDisciplineName5() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.disciplineNameFrench5 != null) {
                returnedName = this.disciplineNameFrench5;
            }
        } else if (this.disciplineNameEnglish5 != null) {
            returnedName = this.disciplineNameEnglish5;
        }

        return returnedName;
    }

    public void setDisciplineName5(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setDisciplineNameFrench5(name);
        } else {
            this.setDisciplineNameEnglish5(name);
        }
    }

    public String getDisciplineNameEnglish5() {
        return disciplineNameEnglish5;
    }

    public String getDisciplineNameFrench1() {
        return disciplineNameFrench1;
    }

    public String getDisciplineNameFrench2() {
        return disciplineNameFrench2;
    }

    public String getDisciplineNameFrench4() {
        return disciplineNameFrench4;
    }

    public String getDisciplineNameFrench5() {
        return disciplineNameFrench5;
    }

    /**
     * Return geoPolitical name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getGeoPoliticalName1() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.geoPoliticalNameFrench1 != null) {
                returnedName = this.geoPoliticalNameFrench1;
            }
        } else if (this.geoPoliticalNameEnglish1 != null) {
            returnedName = this.geoPoliticalNameEnglish1;
        }

        return returnedName;
    }

    public void setGeoPoliticalName1(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setGeoPoliticalNameFrench1(name);
        } else {
            this.setGeoPoliticalNameEnglish1(name);
        }
    }

    public String getGeoPoliticalNameEnglish1() {
        return geoPoliticalNameEnglish1;
    }


    /**
     * Return geoPolitical name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getGeoPoliticalName2() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.geoPoliticalNameFrench2 != null) {
                returnedName = this.geoPoliticalNameFrench2;
            }
        } else if (this.geoPoliticalNameEnglish2 != null) {
            returnedName = this.geoPoliticalNameEnglish2;
        }

        return returnedName;
    }

    public void setGeoPoliticalName2(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setGeoPoliticalNameFrench2(name);
        } else {
            this.setGeoPoliticalNameEnglish2(name);
        }
    }

    public String getGeoPoliticalNameEnglish2() {
        return geoPoliticalNameEnglish2;
    }

    /**
     * Return geoPolitical name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getGeoPoliticalName3() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.geoPoliticalNameFrench3 != null) {
                returnedName = this.geoPoliticalNameFrench3;
            }
        } else if (this.geoPoliticalNameEnglish3 != null) {
            returnedName = this.geoPoliticalNameEnglish3;
        }

        return returnedName;
    }

    public void setGeoPoliticalName3(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setGeoPoliticalNameFrench3(name);
        } else {
            this.setGeoPoliticalNameEnglish3(name);
        }
    }

    public String getGeoPoliticalNameEnglish3() {
        return geoPoliticalNameEnglish3;
    }

    public String getGeoPoliticalNameFrench3() {
        return geoPoliticalNameFrench3;
    }

    public String getGeoPoliticalNameFrench2() {
        return geoPoliticalNameFrench2;
    }

    public String getGeoPoliticalNameFrench1() {
        return geoPoliticalNameFrench1;
    }

    /**
     * Return ProvinceState name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getProvinceStateName1() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.provinceStateNameFrench1 != null) {
                returnedName = this.provinceStateNameFrench1;
            }
        } else if (this.provinceStateNameEnglish1 != null) {
            returnedName = this.provinceStateNameEnglish1;
        }

        return returnedName;
    }

    public void setProvinceStateName1(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setProvinceStateNameFrench1(name);
        } else {
            this.setProvinceStateNameEnglish1(name);
        }
    }

    public String getProvinceStateEnglish1() {
        return provinceStateNameEnglish1;
    }

    /**
     * Return ProvinceState name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getProvinceStateName2() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.provinceStateNameFrench2 != null) {
                returnedName = this.provinceStateNameFrench2;
            }
        } else if (this.provinceStateNameEnglish2 != null) {
            returnedName = this.provinceStateNameEnglish2;
        }

        return returnedName;
    }

    public void setProvinceStateName2(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setProvinceStateNameFrench2(name);
        } else {
            this.setProvinceStateNameEnglish2(name);
        }
    }

    public String getProvinceStateEnglish2() {
        return provinceStateNameEnglish2;
    }

    /**
     * Return ProvinceState name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getProvinceStateName3() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.provinceStateNameFrench3 != null) {
                returnedName = this.provinceStateNameFrench3;
            }
        } else if (this.provinceStateNameEnglish3 != null) {
            returnedName = this.provinceStateNameEnglish3;
        }

        return returnedName;
    }

    public void setProvinceStateName3(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setProvinceStateNameFrench3(name);
        } else {
            this.setProvinceStateNameEnglish3(name);
        }
    }

    public String getProvinceStateEnglish3() {
        return provinceStateNameEnglish3;
    }

    /**
     * Return ProvinceState name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getProvinceStateName4() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.provinceStateNameFrench4 != null) {
                returnedName = this.provinceStateNameFrench4;
            }
        } else if (this.provinceStateNameEnglish4 != null) {
            returnedName = this.provinceStateNameEnglish4;
        }

        return returnedName;
    }

    public void setProvinceStateName4(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setProvinceStateNameFrench4(name);
        } else {
            this.setProvinceStateNameEnglish4(name);
        }
    }

    public String getProvinceStateEnglish4() {
        return provinceStateNameEnglish4;
    }

    /**
     * Return ProvinceState name based on form language
     * The returned value is often used in a JSF f:selectItem tag and
     * therefore should not return a Null value.
     *  */
    public String getProvinceStateName5() {
        String returnedName = "";

        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            if (this.provinceStateNameFrench5 != null) {
                returnedName = this.provinceStateNameFrench5;
            }
        } else if (this.provinceStateNameEnglish5 != null) {
            returnedName = this.provinceStateNameEnglish5;
        }

        return returnedName;
    }

    public void setProvinceStateName5(String name) {
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            this.setProvinceStateNameFrench5(name);
        } else {
            this.setProvinceStateNameEnglish5(name);
        }
    }

    public String getProvinceStateEnglish5() {
        return provinceStateNameEnglish5;
    }

    public String getProvinceStateFrench1() {
        return provinceStateNameFrench1;
    }

    public String getProvinceStateFrench2() {
        return provinceStateNameFrench2;
    }

    public String getProvinceStateFrench3() {
        return provinceStateNameFrench3;
    }

    public String getProvinceStateFrench4() {
        return provinceStateNameFrench4;
    }

    public String getProvinceStateFrench5() {
        return provinceStateNameFrench5;
    }

    public String getDisciplineNameFrench3() {
        return disciplineNameFrench3;
    }

    public String getAreaOfResearchNameFrench2() {
        return areaOfResearchNameFrench2;
    }

    public Long getFormId() {
        return formId;
    }

    public void setAreaOfResearchNameFrench1(String areaOfResearchNameFrench1) {
        this.areaOfResearchNameFrench1 = areaOfResearchNameFrench1;
    }

    public void setAreaOfResearchNameFrench2(String areaOfResearchNameFrench2) {
        this.areaOfResearchNameFrench2 = areaOfResearchNameFrench2;
    }

    public void setAreaOfResearchNameFrench3(String areaOfResearchNameFrench3) {
        this.areaOfResearchNameFrench3 = areaOfResearchNameFrench3;
    }

    public void setAreaOfResearchNameEnglish1(String areaOfResearchNameEnglish1) {
        this.areaOfResearchNameEnglish1 = areaOfResearchNameEnglish1;
    }

    public void setAreaOfResearchNameEnglish2(String areaOfResearchNameEnglish2) {
        this.areaOfResearchNameEnglish2 = areaOfResearchNameEnglish2;
    }

    public void setAreaOfResearchNameEnglish3(String areaOfResearchNameEnglish3) {
        this.areaOfResearchNameEnglish3 = areaOfResearchNameEnglish3;
    }

    public void setCountryNameFrench5(String countryNameFrench5) {
        this.countryNameFrench5 = countryNameFrench5;
    }

    public void setCountryNameFrench4(String countryNameFrench4) {
        this.countryNameFrench4 = countryNameFrench4;
    }

    public void setCountryNameFrench3(String countryNameFrench3) {
        this.countryNameFrench3 = countryNameFrench3;
    }

    public void setCountryNameFrench2(String countryNameFrench2) {
        this.countryNameFrench2 = countryNameFrench2;
    }

    public void setCountryNameFrench1(String countryNameFrench1) {
        this.countryNameFrench1 = countryNameFrench1;
    }

    public void setCountryNameEnglish5(String countryNameEnglish5) {
        this.countryNameEnglish5 = countryNameEnglish5;
    }

    public void setCountryNameEnglish4(String countryNameEnglish4) {
        this.countryNameEnglish4 = countryNameEnglish4;
    }

    public void setCountryNameEnglish3(String countryNameEnglish3) {
        this.countryNameEnglish3 = countryNameEnglish3;
    }

    public void setCountryNameEnglish2(String countryNameEnglish2) {
        this.countryNameEnglish2 = countryNameEnglish2;
    }

    public void setCountryNameEnglish1(String countryNameEnglish1) {
        this.countryNameEnglish1 = countryNameEnglish1;
    }

    public void setGeoPoliticalNameEnglish1(String geoPoliticalNameEnglish1) {
        this.geoPoliticalNameEnglish1 = geoPoliticalNameEnglish1;
    }

    public void setGeoPoliticalNameEnglish2(String geoPoliticalNameEnglish2) {
        this.geoPoliticalNameEnglish2 = geoPoliticalNameEnglish2;
    }

    public void setGeoPoliticalNameEnglish3(String geoPoliticalNameEnglish3) {
        this.geoPoliticalNameEnglish3 = geoPoliticalNameEnglish3;
    }

    public void setGeoPoliticalNameFrench1(String geoPoliticalNameFrench1) {
        this.geoPoliticalNameFrench1 = geoPoliticalNameFrench1;
    }

    public void setGeoPoliticalNameFrench2(String geoPoliticalNameFrench2) {
        this.geoPoliticalNameFrench2 = geoPoliticalNameFrench2;
    }

    public void setGeoPoliticalNameFrench3(String geoPoliticalNameFrench3) {
        this.geoPoliticalNameFrench3 = geoPoliticalNameFrench3;
    }

    public void setProvinceStateNameEnglish1(String provinceStateEnglish1) {
        this.provinceStateNameEnglish1 = provinceStateEnglish1;
    }

    public void setProvinceStateNameEnglish2(String provinceStateEnglish2) {
        this.provinceStateNameEnglish2 = provinceStateEnglish2;
    }

    public void setProvinceStateNameEnglish3(String provinceStateEnglish3) {
        this.provinceStateNameEnglish3 = provinceStateEnglish3;
    }

    public void setProvinceStateNameEnglish4(String provinceStateEnglish4) {
        this.provinceStateNameEnglish4 = provinceStateEnglish4;
    }

    public void setProvinceStateNameEnglish5(String provinceStateEnglish5) {
        this.provinceStateNameEnglish5 = provinceStateEnglish5;
    }

    public void setProvinceStateNameFrench1(String provinceStateFrench1) {
        this.provinceStateNameFrench1 = provinceStateFrench1;
    }

    public void setProvinceStateNameFrench2(String provinceStateFrench2) {
        this.provinceStateNameFrench2 = provinceStateFrench2;
    }

    public void setProvinceStateNameFrench3(String provinceStateFrench3) {
        this.provinceStateNameFrench3 = provinceStateFrench3;
    }

    public void setProvinceStateNameFrench4(String provinceStateFrench4) {
        this.provinceStateNameFrench4 = provinceStateFrench4;
    }

    public void setProvinceStateNameFrench5(String provinceStateFrench5) {
        this.provinceStateNameFrench5 = provinceStateFrench5;
    }

    public void setDisciplineNameEnglish1(String disciplineNameEnglish1) {
        this.disciplineNameEnglish1 = disciplineNameEnglish1;
    }

    public void setDisciplineNameEnglish2(String disciplineNameEnglish2) {
        this.disciplineNameEnglish2 = disciplineNameEnglish2;
    }

    public void setDisciplineNameEnglish3(String disciplineNameEnglish3) {
        this.disciplineNameEnglish3 = disciplineNameEnglish3;
    }

    public void setDisciplineNameEnglish4(String disciplineNameEnglish4) {
        this.disciplineNameEnglish4 = disciplineNameEnglish4;
    }

    public void setDisciplineNameEnglish5(String disciplineNameEnglish5) {
        this.disciplineNameEnglish5 = disciplineNameEnglish5;
    }

    public void setDisciplineNameFrench1(String disciplineNameFrench1) {
        this.disciplineNameFrench1 = disciplineNameFrench1;
    }

    public void setDisciplineNameFrench2(String disciplineNameFrench2) {
        this.disciplineNameFrench2 = disciplineNameFrench2;
    }

    public void setDisciplineNameFrench3(String disciplineNameFrench3) {
        this.disciplineNameFrench3 = disciplineNameFrench3;
    }

    public void setDisciplineNameFrench4(String disciplineNameFrench4) {
        this.disciplineNameFrench4 = disciplineNameFrench4;
    }

    public void setDisciplineNameFrench5(String disciplineNameFrench5) {
        this.disciplineNameFrench5 = disciplineNameFrench5;
    }

    public void setFormId(Long formId) {
        this.formId = formId;
    }

    public void setAreaOfResearcNameFrench2(String areaOfResearcNameFrench2) {
        this.areaOfResearchNameFrench2 = areaOfResearcNameFrench2;
    }

    public String toString() {
        return new ToStringBuilder(this)
                .append("cid", getCid())
                .toString();
    }

    public boolean equals(Object other) {
        if (!(other instanceof PersonExpertise)) {
            return false;
        }
        PersonExpertise castOther = (PersonExpertise) other;
        return new EqualsBuilder()
                .append(this.getCid(), castOther.getCid())
                .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
                .append(getCid())
                .toHashCode();
    }


    // Overwrite ancestor method
    public void retrieve(Session session) {
        retrieve(new Long(0), session);
    }

    public void retrieve(Long formId, Session session) {
        Logger logger = Logger.getLogger(ExpertiseBean.class.getName());
        List queryList;

        if (null == session) {
            if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                logger.error("Cannot load ExpertiseBean - Session is null");
                return;
            }
        }

        // If the passed form id is 0, get the form id from the NavigationBean
        if (formId.longValue() == 0) {
            formId = new Long(getNavigationBean().getForm_id());
            if (formId.longValue() == 0) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.error("Cannot load ExpertiseBean - no FormId : " + formId);
                    return;
                }
            } else {
                logger.info("ExpertiseBean.retrieve using navigationBean FormId : " + formId);
            }

        } else {
            logger.info("ExpertiseBean.retrieve using passed parm FormId : " + formId);
        }

        // Retrieve data
        try {
            logger.info("In ExpertiseBean.retrieve()");
            /* Send a Set Forceplan ON to force ASE to join the
             tables in the order specified in the FROM clause */
            session.connection().prepareStatement("Set forceplan on").execute();
            queryList = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.cv.ExpertiseBean(form.formId, " +
                    "PersonExpertise.cid, " +
                    "PersonExpertise.keywords, " +
                    "PersonExpertise.disciplineCode1, " +
                    "Discipline_a.nameFrench, " +
                    "Discipline_a.nameEnglish, " +
                    "PersonExpertise.otherDisciplineName1, " +
                    "PersonExpertise.disciplineCode2, " +
                    "Discipline_b.nameFrench, " +
                    "Discipline_b.nameEnglish, " +
                    "PersonExpertise.otherDisciplineName2, " +
                    "PersonExpertise.disciplineCode3, " +
                    "Discipline_c.nameFrench, " +
                    "Discipline_c.nameEnglish, " +
                    "PersonExpertise.otherDisciplineName3, " +
                    "PersonExpertise.disciplineCode4, " +
                    "Discipline_d.nameFrench, " +
                    "Discipline_d.nameEnglish, " +
                    "PersonExpertise.otherDisciplineName4, " +
                    "PersonExpertise.disciplineCode5, " +
                    "Discipline_e.nameFrench, " +
                    "Discipline_e.nameEnglish, " +
                    "PersonExpertise.otherDisciplineName5, " +
                    "PersonExpertise.areaOfResearchCode1, " +
                    "Codes_a.nameFrench, " +
                    "Codes_a.nameEnglish, " +
                    "PersonExpertise.areaOfResearchCode2, " +
                    "Codes_b.nameFrench, " +
                    "Codes_b.nameEnglish, " +
                    "PersonExpertise.areaOfResearchCode3, " +
                    "Codes_c.nameFrench, " +
                    "Codes_c.nameEnglish, " +
                    "PersonExpertise.geoPoliticalCode1, " +
                    "Codes_d.shortNameFrench, " +
                    "Codes_d.shortNameEnglish, " +
                    "PersonExpertise.geoPoliticalCode2, " +
                    "Codes_e.shortNameFrench, " +
                    "Codes_e.shortNameEnglish, " +
                    "PersonExpertise.geoPoliticalCode3, " +
                    "Codes_f.shortNameFrench, " +
                    "Codes_f.shortNameEnglish, " +
                    "PersonExpertise.countryCode1, " +
                    "Country_a.nameFrench, " +
                    "Country_a.nameEnglish, " +
                    "PersonExpertise.provinceStateCode1, " +
                    "ProvinceState_a.nameFrench, " +
                    "ProvinceState_a.nameEnglish, " +
                    "PersonExpertise.countryCode2, " +
                    "Country_b.nameFrench, " +
                    "Country_b.nameEnglish, " +
                    "PersonExpertise.provinceStateCode2, " +
                    "ProvinceState_b.nameFrench, " +
                    "ProvinceState_b.nameEnglish, " +
                    "PersonExpertise.countryCode3, " +
                    "Country_c.nameFrench, " +
                    "Country_c.nameEnglish, " +
                    "PersonExpertise.provinceStateCode3, " +
                    "ProvinceState_c.nameFrench, " +
                    "ProvinceState_c.nameEnglish, " +
                    "PersonExpertise.countryCode4, " +
                    "Country_d.nameFrench, " +
                    "Country_d.nameEnglish, " +
                    "PersonExpertise.provinceStateCode4, " +
                    "ProvinceState_d.nameFrench, " +
                    "ProvinceState_d.nameEnglish, " +
                    "PersonExpertise.countryCode5, " +
                    "Country_e.nameFrench, " +
                    "Country_e.nameEnglish, " +
                    "PersonExpertise.provinceStateCode5, " +
                    "ProvinceState_e.nameFrench, " +
                    "ProvinceState_e.nameEnglish, " +
                    "PersonExpertise.temporalStartYear1, " +
                    "PersonExpertise.temporalStartBcAd1, " +
                    "PersonExpertise.temporalEndYear1, " +
                    "PersonExpertise.temporalEndBcAd1, " +
                    "PersonExpertise.temporalStartYear2, " +
                    "PersonExpertise.temporalStartBcAd2, " +
                    "PersonExpertise.temporalEndYear2, " +
                    "PersonExpertise.temporalEndBcAd2, " +
                    "PersonExpertise.changeDate) " +
                    "from Form form join form.person as Person " +
                    "join fetch Person.personExpertise as PersonExpertise " +
                    "left join fetch PersonExpertise.disciplineCode1 as Discipline_a " +
                    "left join fetch PersonExpertise.disciplineCode2 as Discipline_b " +
                    "left join fetch PersonExpertise.disciplineCode3 as Discipline_c " +
                    "left join fetch PersonExpertise.disciplineCode4 as Discipline_d " +
                    "left join fetch PersonExpertise.disciplineCode5 as Discipline_e " +
                    "left join fetch PersonExpertise.areaOfResearchCode1 as Codes_a " +
                    "left join fetch PersonExpertise.areaOfResearchCode2 as Codes_b " +
                    "left join fetch PersonExpertise.areaOfResearchCode3 as Codes_c " +
                    "left join fetch PersonExpertise.geoPoliticalCode1 as Codes_d " +
                    "left join fetch PersonExpertise.geoPoliticalCode2 as Codes_e " +
                    "left join fetch PersonExpertise.geoPoliticalCode3 as Codes_f " +
                    "left join fetch PersonExpertise.provinceStateCode1 as ProvinceState_a " +
                    "left join fetch PersonExpertise.provinceStateCode2 as ProvinceState_b " +
                    "left join fetch PersonExpertise.provinceStateCode3 as ProvinceState_c " +
                    "left join fetch PersonExpertise.provinceStateCode4 as ProvinceState_d " +
                    "left join fetch PersonExpertise.provinceStateCode5 as ProvinceState_e " +
                    "left join fetch PersonExpertise.countryCode1 as Country_a " +
                    "left join fetch PersonExpertise.countryCode2 as Country_b " +
                    "left join fetch PersonExpertise.countryCode3 as Country_c " +
                    "left join fetch PersonExpertise.countryCode4 as Country_d " +
                    "left join fetch PersonExpertise.countryCode5 as Country_e " +
                    "where (form.formId = :formId)")
                        .setParameter("formId", formId)
                        .list();

/*
                        queryList = session.createQuery(
                                "select new ca.sshrc.web.forms.beans.cv.ExpertiseBean(Form.formId, PersonExpertise.cid, " +
                                "PersonExpertise.keywords, " +
                                "PersonExpertise.disciplineCode1, " +
                                "Discipline_a.nameFrench, " +
                                "Discipline_a.nameEnglish, " +
                                "PersonExpertise.otherDisciplineName1, " +
                                "PersonExpertise.disciplineCode2, " +
                                "Discipline_b.nameFrench, " +
                                "Discipline_b.nameEnglish, " +
                                "PersonExpertise.otherDisciplineName2, " +
                                "PersonExpertise.disciplineCode3, " +
                                "Discipline_c.nameFrench, " +
                                "Discipline_c.nameEnglish, " +
                                "PersonExpertise.otherDisciplineName3, " +
                                "PersonExpertise.disciplineCode4, " +
                                "Discipline_d.nameFrench, " +
                                "Discipline_d.nameEnglish, " +
                                "PersonExpertise.otherDisciplineName4, " +
                                "PersonExpertise.disciplineCode5, " +
                                "Discipline_e.nameFrench, " +
                                "Discipline_e.nameEnglish, " +
                                "PersonExpertise.otherDisciplineName5, " +
                                "PersonExpertise.areaOfResearchCode1, " +
                                "Codes_a.nameFrench, " +
                                "Codes_a.nameEnglish, " +
                                "PersonExpertise.areaOfResearchCode2, " +
                                "Codes_b.nameFrench, " +
                                "Codes_b.nameEnglish, " +
                                "PersonExpertise.areaOfResearchCode3, " +
                                "Codes_c.nameFrench, " +
                                "Codes_c.nameEnglish, " +
                                "PersonExpertise.geoPoliticalCode1, " +
                                "Codes_d.shortNameFrench, " +
                                "Codes_d.shortNameEnglish, " +
                                "PersonExpertise.geoPoliticalCode2, " +
                                "Codes_e.shortNameFrench, " +
                                "Codes_e.shortNameEnglish, " +
                                "PersonExpertise.geoPoliticalCode3, " +
                                "Codes_f.shortNameFrench, " +
                                "Codes_f.shortNameEnglish, " +
                                "PersonExpertise.countryCode1, " +
                                "Country_a.nameFrench, " +
                                "Country_a.nameEnglish, " +
                                "PersonExpertise.provinceStateCode1, " +
                                "ProvinceState_a.nameFrench, " +
                                "ProvinceState_a.nameEnglish, " +
                                "PersonExpertise.countryCode2, " +
                                "Country_b.nameFrench, " +
                                "Country_b.nameEnglish, " +
                                "PersonExpertise.provinceStateCode2, " +
                                "ProvinceState_b.nameFrench, " +
                                "ProvinceState_b.nameEnglish, " +
                                "PersonExpertise.countryCode3, " +
                                "Country_c.nameFrench, " +
                                "Country_c.nameEnglish, " +
                                "PersonExpertise.provinceStateCode3, " +
                                "ProvinceState_c.nameFrench, " +
                                "ProvinceState_c.nameEnglish, " +
                                "PersonExpertise.countryCode4, " +
                                "Country_d.nameFrench, " +
                                "Country_d.nameEnglish, " +
                                "PersonExpertise.provinceStateCode4, " +
                                "ProvinceState_d.nameFrench, " +
                                "ProvinceState_d.nameEnglish, " +
                                "PersonExpertise.countryCode5, " +
                                "Country_e.nameFrench, " +
                                "Country_e.nameEnglish, " +
                                "PersonExpertise.provinceStateCode5, " +
                                "ProvinceState_e.nameFrench, " +
                                "ProvinceState_e.nameEnglish, " +
                                "PersonExpertise.temporalStartYear1, " +
                                "PersonExpertise.temporalStartBcAd1, " +
                                "PersonExpertise.temporalEndYear1, " +
                                "PersonExpertise.temporalEndBcAd1, " +
                                "PersonExpertise.temporalStartYear2, " +
                                "PersonExpertise.temporalStartBcAd2, " +
                                "PersonExpertise.temporalEndYear2, " +
                                "PersonExpertise.temporalEndBcAd2, " +
                                "PersonExpertise.createDate, " +
                                "PersonExpertise.createUserId, " +
                                "PersonExpertise.changeDate, " +
                                "PersonExpertise.changeUserId) " +
                                "from PersonExpertise PersonExpertise, " +
                                "Form Form, " +
                                "ProvinceState ProvinceState_a, " +
                                "ProvinceState ProvinceState_b, " +
                                "ProvinceState ProvinceState_c, " +
                                "ProvinceState ProvinceState_d, " +
                                "ProvinceState ProvinceState_e, " +
                                "Country Country_a, " +
                                "Country Country_b, " +
                                "Country Country_c, " +
                                "Country Country_d, " +
                                "Country Country_e, " +
                                "Discipline Discipline_a, " +
                                "Discipline Discipline_b, " +
                                "Discipline Discipline_c, " +
                                "Discipline Discipline_d, " +
                                "Discipline Discipline_e, " +
                                "Cod Codes_a, " +
                                "Cod Codes_b, " +
                                "Cod Codes_c, " +
                                "Cod Codes_d, " +
                                "Cod Codes_e, " +
                                "Cod Codes_f " +
                                "where (Form.formId = :formId) and " +
                                "(PersonExpertise.cid = Form.cid) and " +
                                "(PersonExpertise.disciplineCode1 *= Discipline_a.disciplineCode) and " +
                                "(PersonExpertise.disciplineCode2 *= Discipline_b.disciplineCode) and " +
                                "(PersonExpertise.disciplineCode3 *= Discipline_c.disciplineCode) and " +
                                "(PersonExpertise.disciplineCode4 *= Discipline_d.disciplineCode) and " +
                                "(PersonExpertise.disciplineCode5 *= Discipline_e.disciplineCode) and " +
                                "(PersonExpertise.areaOfResearchCode1 *= Codes_a.code) and " +
                                "(PersonExpertise.areaOfResearchCode2 *= Codes_b.code) and " +
                                "(PersonExpertise.areaOfResearchCode3 *= Codes_c.code) and " +
                                "(PersonExpertise.geoPoliticalCode1 *= Codes_d.code) and " +
                                "(PersonExpertise.geoPoliticalCode2 *= Codes_e.code) and " +
                                "(PersonExpertise.geoPoliticalCode3 *= Codes_f.code) and " +
                                "(PersonExpertise.countryCode1 *= Country_a.countryCode) and " +
                                "(PersonExpertise.provinceStateCode1 *= ProvinceState_a.provinceStateCode) and " +
                                "(PersonExpertise.countryCode2 *= Country_b.countryCode) and " +
                                "(PersonExpertise.provinceStateCode2 *= ProvinceState_b.provinceStateCode) and " +
                                "(PersonExpertise.countryCode3 *= Country_c.countryCode) and " +
                                "(PersonExpertise.provinceStateCode3 *= ProvinceState_c.provinceStateCode) and " +
                                "(PersonExpertise.countryCode4 *= Country_d.countryCode) and " +
                                "(PersonExpertise.provinceStateCode4 *= ProvinceState_d.provinceStateCode) and " +
                                "(PersonExpertise.countryCode5 *= Country_e.countryCode) and " +
                                "(PersonExpertise.provinceStateCode5 *= ProvinceState_e.provinceStateCode)")
                                    .setParameter("formId", formId)
                                    .list();
             */

            if (queryList.size() > 0) {
                this.loadData((ExpertiseBean) queryList.get(0));
            }

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded ExpertiseBean : " + queryList.size());
            }

            /* Send a Set Forceplan OFF */
            session.connection().prepareStatement("Set forceplan off").execute();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void loadData(ExpertiseBean bean) {

        // Set values
        try {
            // PropertyUtils.copyProperties(destination, source)
            PropertyUtils.copyProperties(this, bean);

        } catch (NoSuchMethodException ex) {
            ex.printStackTrace();
        } catch (InvocationTargetException ex) {
            ex.printStackTrace();
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
        }

    }

    public String save(Session session) throws HibernateException, Exception {
        Logger logger = Logger.getLogger(ExpertiseBean.class.getName());
        List queryList;
        String saveOutcome = Constants.UPDATE_ERROR_OUTCOME; // Defaults to update error

        /**
         * Save Person data
         * */
        logger.info("saving ExpertiseBean data");
        queryList = session.createQuery("from PersonExpertise " +
                                        "where cid = :cid")
                    .setParameter("cid", this.getCid())
                    .list();

        logger.info("Retrieved hibernate.PersonExpertise object for cid: " +
                    this.getCid());

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Loaded hibernate.PersonExpertise objects : " + queryList.size());
        }

        if (queryList.size() > 0) {
            // Set values
            hibernate.PersonExpertise myPersonExpertise = (hibernate.PersonExpertise) queryList.get(0);

            // Check for stale data (BaseBean method - first param is DB date, second param is Web date)
            if (!isStaleData(myPersonExpertise.getChangeDate(), this.getChangeDate())) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("PersonExpertise - Not Stale data");
                }
                // Save to DB

                // BeanUtils.copyProperties(destination, source)
                // PropertyUtils.copyProperties(destination, source) - without data conversion.
                PropertyUtils.copyProperties(myPersonExpertise, this);
                session.saveOrUpdate(myPersonExpertise);
                session.flush();
                session.refresh(myPersonExpertise);

                // Refresh This.Bean
                PropertyUtils.copyProperties(this, myPersonExpertise);

                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("PersonExpertise - refreshing Web date : " + this.getChangeDate());
                    logger.info("PersonExpertise - refreshing DB date : " + myPersonExpertise.getChangeDate());
                }

                saveOutcome = Constants.SUCCESS_OUTCOME;
            } else {
                logger.error("Stale data in PersonExpertise -  NOT Saving");
            }
        } else if (this.getNavigationBean().getFormModified().equalsIgnoreCase("Y")) {

            hibernate.Person myPersonExpertise = new hibernate.Person();
            // Save to DB

            // BeanUtils.copyProperties(destination, source)
            BeanUtils.copyProperties(myPersonExpertise, this);
            session.saveOrUpdate(myPersonExpertise);
            session.flush();
            session.refresh(myPersonExpertise);

            // Refresh Change_date on This.Bean
            this.setChangeDate(myPersonExpertise.getChangeDate());
            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("PersonExpertise - refreshing Web date : " + this.getChangeDate());
                logger.info("PersonExpertise - refreshing DB date : " + myPersonExpertise.getChangeDate());
            }

            saveOutcome = Constants.SUCCESS_OUTCOME;

        } else {
            saveOutcome = null; // return to same page
        }

        return saveOutcome;
    }

    public String validate(ValidationMessage validationMessage) throws HibernateException, Exception {
        Logger logger = Logger.getLogger(ExpertiseBean.class.getName());

        ResourceBundle moduleBundle = null;
        ResourceBundle applicationBundle = null;
        ResourceBundle validationErrorBundle = null;

        Locale locale = null;

        String validationOutcome = Constants.SUCCESS_OUTCOME;
        String moduleDisplayName = null;
        String errorMessage = null;
        String valueString1;
        String valueString2;
        String valueStringArray[] = new String[2];

        Integer subSystemId = null;
        Integer moduleId = null;
        Integer valueInteger1;
        Integer valueInteger2;

        boolean keepLooping = true;
        boolean errorFound = false;

        Object tempForNullObject;

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("ExpertiseBean.validate - Start");
        }

        // If messageContainer is null, throw exception
        if (validationMessage == null) {
            throw new Exception("Invalid parameter. ValidationMessage object was null.");
        }

        subSystemId = this.getNavigationBean().getRequestedSubsystemId();
        moduleId = validationMessage.getModuleNavigationBarBean().getSequenceNumber();

        // Create Locale
        if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            locale = Locale.CANADA_FRENCH;
            moduleDisplayName = validationMessage.getModuleNavigationBarBean().getNameFrench();
        } else {
            locale = Locale.CANADA;
            moduleDisplayName = validationMessage.getModuleNavigationBarBean().getNameEnglish();
        }

        // Get resource bundles
        applicationBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                Constants.APPLICATION_RESOURCES, locale);
        validationErrorBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                Constants.VALIDATION_ERROR_RESOURCES, locale);
        moduleBundle = ResourceBundle.getBundle(validationMessage.getResourceBundleName(), locale);

        /**
         *
         * Validate Expertise data
         *
         * */

        try {
            // Get a session
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // Call this object's retrieve method
            this.retrieve(new Long(0), session);

        } catch (Exception ex) {
            HibernateUtil.closeSession();
            ex.printStackTrace();
        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        // If no row
        if (this.cid == null) {

            // Add validation error message
            errorMessage = validationErrorBundle.getString("errorFieldToComplete");
            Object params[] = {moduleBundle.getString("sectionName2")};
            validationMessage.addMessage(subSystemId,
                                         moduleId,
                                         moduleDisplayName,
                                         validationMessage.substituteParams(locale, errorMessage, params));
        } else {

            // Keywords
            if (null == this.keywords || (this.keywords.trim()).equals("")) {
                // Add validation error message
                errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                Object params[] = {applicationBundle.getString("sectionName1")};
                validationMessage.addMessage(subSystemId,
                                             moduleId,
                                             moduleDisplayName,
                                             validationMessage.substituteParams(locale, errorMessage, params));
            }

            /**
             * Discipline codes and Other fields
             *
             */

            // check if they picked "other" in code field
            for (int i = 1; i < 6; i++) {
                // Avoid NullPointerException
                tempForNullObject = PropertyUtils.getProperty(this, "disciplineCode" + i);
                if (tempForNullObject != null) {
                    valueInteger1 = (Integer) tempForNullObject;
                } else {
                    valueInteger1 = null;
                }

                valueString1 = (String) PropertyUtils.getProperty(this, "otherDisciplineName" + i);

                // If it's the first code, it's mandatory
                if (i == 1 && valueInteger1 == null) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                    Object params[] = {moduleBundle.getString("sectionName2") + validationErrorBundle.getString("errorEntryFieldNumberLowerCase") + i};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage,
                            params));
                }

                // All code finishing by 99 must have a value entered in there corresponding otherDisciplineName field.
                if (valueInteger1 != null) {
                    if (valueInteger1.toString().endsWith("99")) {
                        if (valueString1 == null || (valueString1.trim()).equals("")) {

                            // Add validation error message
                            errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                            Object params[] = {validationErrorBundle.getString("errorOther") +
                                              moduleBundle.getString("sectionName2") + validationErrorBundle.getString("errorEntryFieldNumberLowerCase") + i};
                            validationMessage.addMessage(subSystemId,
                                    moduleId,
                                    moduleDisplayName,
                                    validationMessage.substituteParams(locale, errorMessage, params));
                        }
                    }
                }

                // All otherDisciplineName must have a value entered and there corresponding disciplineCode that ends by 99.
                if (valueString1 != null) {
                    if (!(valueString1.trim()).equals("")) {
                        if (valueInteger1 == null || (valueString1.trim()).equals("") ||
                            !valueInteger1.toString().endsWith("99")) {

                            // Add validation error message
                            errorMessage = validationErrorBundle.getString("errorIfOther");
                            Object params[] = {moduleBundle.getString("sectionName2"), validationErrorBundle.getString("errorEntryNumberUpperCase") + i + "."};
                            validationMessage.addMessage(subSystemId,
                                    moduleId,
                                    moduleDisplayName,
                                    validationMessage.substituteParams(locale, errorMessage, params));
                        }
                    }
                }
            }

            // Check for duplicate discipline code
            keepLooping = true;
            for (int i = 1; i < 5; i++) {
                // Avoid NullPointerException
                tempForNullObject = PropertyUtils.getProperty(this, "disciplineCode" + i);
                if (tempForNullObject != null) {
                    valueInteger1 = (Integer) tempForNullObject;
                } else {
                    valueInteger1 = null;
                }
                for (int j = i + 1; j < 6; j++) {
                    // Avoid NullPointerException
                    tempForNullObject = PropertyUtils.getProperty(this, "disciplineCode" + j);
                    if (tempForNullObject != null) {
                        valueInteger2 = (Integer) tempForNullObject;
                    } else {
                        valueInteger2 = null;
                    }
                    if (valueInteger1 != null && valueInteger2 != null) {
                        if (valueInteger1.equals(valueInteger2)) {
                            // Add validation error message
                            errorMessage = validationErrorBundle.getString("errorDuplicate");
                            Object params[] = {moduleBundle.getString("sectionName2")};
                            validationMessage.addMessage(subSystemId,
                                    moduleId,
                                    moduleDisplayName,
                                    validationMessage.substituteParams(locale, errorMessage, params));

                            // set indicator that will stop the main loop
                            keepLooping = false;
                            break;
                        }
                    }
                }
                // Stop looping?
                if (!keepLooping) {
                    break;
                }
            }

            /**
             * Validate areas of research
             *
             */

            // Check for duplicate areaOfResearchCode
            keepLooping = true;
            for (int i = 1; i < 3; i++) {
                // Avoid NullPointerException
                tempForNullObject = PropertyUtils.getProperty(this, "areaOfResearchCode" + i);
                if (tempForNullObject != null) {
                    valueInteger1 = (Integer) tempForNullObject;
                } else {
                    valueInteger1 = null;
                }
                for (int j = i + 1; j < 4; j++) {
                    // Avoid NullPointerException
                    tempForNullObject = PropertyUtils.getProperty(this, "areaOfResearchCode" + j);
                    if (tempForNullObject != null) {
                        valueInteger2 = (Integer) tempForNullObject;
                    } else {
                        valueInteger2 = null;
                    }
                    if (valueInteger1 != null && valueInteger2 != null) {
                        if (valueInteger1.equals(valueInteger2)) {
                            // Add validation error message
                            errorMessage = validationErrorBundle.getString("errorDuplicate");
                            Object params[] = {moduleBundle.getString("sectionName3")};
                            validationMessage.addMessage(subSystemId,
                                    moduleId,
                                    moduleDisplayName,
                                    validationMessage.substituteParams(locale, errorMessage, params));
                            // set indicator that will stop the main loop
                            keepLooping = false;
                            break;
                        }
                    }
                }
                // Stop looping?
                if (!keepLooping) {
                    break;
                }
            }

            /**
             * Validate geographical region
             *
             */

            // Check for duplicate geoPoliticalCode
            keepLooping = true;
            for (int i = 1; i < 3; i++) {
                // Avoid NullPointerException
                tempForNullObject = PropertyUtils.getProperty(this, "geoPoliticalCode" + i);
                if (tempForNullObject != null) {
                    valueInteger1 = (Integer) tempForNullObject;
                } else {
                    valueInteger1 = null;
                }
                for (int j = i + 1; j < 4; j++) {
                    // Avoid NullPointerException
                    tempForNullObject = PropertyUtils.getProperty(this, "geoPoliticalCode" + j);
                    if (tempForNullObject != null) {
                        valueInteger2 = (Integer) tempForNullObject;
                    } else {
                        valueInteger2 = null;
                    }
                    if (valueInteger1 != null && valueInteger2 != null) {
                        if (valueInteger1.equals(valueInteger2)) {
                            // Add validation error message
                            errorMessage = validationErrorBundle.getString("errorDuplicate");
                            Object params[] = {moduleBundle.getString("sectionGeographical")};
                            validationMessage.addMessage(subSystemId,
                                    moduleId,
                                    moduleDisplayName,
                                    validationMessage.substituteParams(locale, errorMessage, params));
                            // set indicator that will stop the main loop
                            keepLooping = false;
                            break;
                        }
                    }
                }
                // Stop looping?
                if (!keepLooping) {
                    break;
                }
            }

            /**
             * Countries and Province/state
             *
             */

            // check if the province is valid for the country
            for (int i = 1; i < 6; i++) {
                // Avoid NullPointerException
                tempForNullObject = PropertyUtils.getProperty(this, "countryCode" + i);
                if (tempForNullObject != null) {
                    valueInteger1 = (Integer) tempForNullObject;
                } else {
                    valueInteger1 = null;
                }
                valueString1 = (String) PropertyUtils.getProperty(this, "provinceStateCode" + i);
                if (valueString1 != null) {
                    if (!(valueString1.trim()).equals("")) {
                        if (valueInteger1 == null) {
                            // Add validation error message
                            errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                            Object params[] = {moduleBundle.getString("sectionCountries") + validationErrorBundle.getString("errorEntryFieldNumberLowerCase") + i};
                            validationMessage.addMessage(subSystemId,
                                    moduleId,
                                    moduleDisplayName,
                                    validationMessage.substituteParams(locale, errorMessage, params));
                        } else if (valueInteger1.intValue() != 1100 && valueInteger1.intValue() != 1200) {
                            // Add validation error message
                            errorMessage = validationErrorBundle.getString("errorInvalidProvinceStateCountry") + " " + validationErrorBundle.getString("errorEntryFieldNumberUpperCase") + i;
                            validationMessage.addMessage(subSystemId,
                                    moduleId,
                                    moduleDisplayName,
                                    errorMessage);
                            errorFound = true;
                        } else if (valueInteger1.intValue() == 1100) { // Canada - check province
                            if (!CommonService.isValidProvince(valueString1)) {
                                // Add validation error message
                                errorMessage = validationErrorBundle.getString("errorInvalidEntry");
                                Object params[] = {applicationBundle.getString("province") + validationErrorBundle.getString("errorEntryFieldNumberLowerCase") + i};
                                validationMessage.addMessage(subSystemId,
                                        moduleId,
                                        moduleDisplayName,
                                        validationMessage.substituteParams(locale, errorMessage, params));
                            }
                        } else { // It's the U.S.
                            if (!CommonService.isValidProvince(valueString1)) {
                                // Add validation error message
                                errorMessage = validationErrorBundle.getString("errorInvalidEntry");
                                Object params[] = {applicationBundle.getString("province") + validationErrorBundle.getString("errorEntryFieldNumberLowerCase") + i};
                                validationMessage.addMessage(subSystemId,
                                        moduleId,
                                        moduleDisplayName,
                                        validationMessage.substituteParams(locale, errorMessage, params));
                            }
                        }

                    }
                }
            }

            /**
             * Temporal period
             *
             */

            // Check the temporal period values
            errorFound = false;
            for (int i = 1; i < 3; i++) {
                // Avoid NullPointerException
                tempForNullObject = PropertyUtils.getProperty(this, "temporalStartYear" + i);
                if (tempForNullObject != null) {
                    valueInteger1 = (Integer) tempForNullObject;
                } else {
                    valueInteger1 = new Integer(0);
                }
                valueString1 = (String) PropertyUtils.getProperty(this, "temporalStartBcAd" + i);

                // Avoid NullPointerException
                tempForNullObject = (Integer) PropertyUtils.getProperty(this, "temporalEndYear" + i);
                if (tempForNullObject != null) {
                    valueInteger2 = (Integer) tempForNullObject;
                } else {
                    valueInteger2 = new Integer(0);
                }
                valueString2 = (String) PropertyUtils.getProperty(this, "temporalEndBcAd" + i);

                // Keep a copy of all field for duplicate validation (see bottom of this method)
                valueStringArray[i -
                        1] = valueInteger1.toString().trim() + valueString1 + valueInteger1.toString().trim() +
                             valueString2;

                // Is there values to be validated ?
                if (valueInteger1 != null || valueInteger2 != null || valueString1 != null || valueString2 != null) {

                    // Is temporal period (from ot to) missing ?
                    if ((valueString1 == null || valueString1.trim().equals("")) ||
                        (valueString2 == null || valueString2.trim().equals(""))) {
                        // Add validation error message
                        errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                        Object params[] = {moduleBundle.getString("sectionTemporal") + " - " +
                                          applicationBundle.getString("timePeriod")  + " " + validationErrorBundle.getString("errorEntryFieldNumberLowerCase") + i};
                        validationMessage.addMessage(subSystemId,
                                moduleId,
                                moduleDisplayName,
                                validationMessage.substituteParams(locale, errorMessage, params));
                        errorFound = true;
                    }

                    // Temporal start year
                    if (valueInteger1 == null) {
                        // Add validation error message
                        errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                        Object params[] = {moduleBundle.getString("sectionTemporal") + " - " +
                                          applicationBundle.getString("fromYear") + " " + validationErrorBundle.getString("errorEntryFieldNumberLowerCase") + i};
                        validationMessage.addMessage(subSystemId,
                                moduleId,
                                moduleDisplayName,
                                validationMessage.substituteParams(locale, errorMessage, params));
                        errorFound = true;
                    }

                    // Temporal end year
                    if (valueInteger2 == null) {
                        // Add validation error message
                        errorMessage = validationErrorBundle.getString("errorFieldToComplete");
                        Object params[] = {moduleBundle.getString("sectionTemporal") + " - " +
                                          applicationBundle.getString("toYear") + validationErrorBundle.getString("errorEntryFieldNumberLowerCase") + i};
                        validationMessage.addMessage(subSystemId,
                                moduleId,
                                moduleDisplayName,
                                validationMessage.substituteParams(locale, errorMessage, params));
                        errorFound = true;
                    }

                    // validate the start, end year, bc/ad combinations
                    if (valueString1.equalsIgnoreCase("AD")) {
                        if (valueString2.equalsIgnoreCase("BC")) {
                            // Add validation error message
                            errorMessage = validationErrorBundle.getString("errorTemporalBcAd") + " " + validationErrorBundle.getString("errorEntryFieldNumberUpperCase") + i + ".";
                            validationMessage.addMessage(subSystemId,
                                    moduleId,
                                    moduleDisplayName,
                                    errorMessage);
                            errorFound = true;
                        }

                        // End year < start year
                        if (valueInteger2.intValue() < valueInteger1.intValue()) {
                            // Add validation error message
                            errorMessage = validationErrorBundle.getString("errorTemporalAd") + " " + validationErrorBundle.getString("errorEntryFieldNumberUpperCase") + i + ".";
                            validationMessage.addMessage(subSystemId,
                                    moduleId,
                                    moduleDisplayName,
                                    errorMessage);
                            errorFound = true;
                        }

                    } else if (valueString2.equalsIgnoreCase("BC")) {

                        // End year > start year
                        if (valueInteger2.intValue() > valueInteger1.intValue()) {
                            // Add validation error message
                            errorMessage = validationErrorBundle.getString("errorTemporalBc") + " " + validationErrorBundle.getString("errorEntryFieldNumberUpperCase") + i + ".";
                            validationMessage.addMessage(subSystemId,
                                    moduleId,
                                    moduleDisplayName,
                                    errorMessage);
                            errorFound = true;
                        }
                    }
                }
            }

            // If no error found check for duplicate entries
            if (!errorFound) {
                if (valueStringArray[0] == valueStringArray[1]) {
                    // Add validation error message
                    errorMessage = validationErrorBundle.getString("errorDuplicate");
                    Object params[] = {moduleBundle.getString("sectionTemporal")};
                    validationMessage.addMessage(subSystemId,
                                                 moduleId,
                                                 moduleDisplayName,
                                                 validationMessage.substituteParams(locale, errorMessage,
                            params));
                }
            }
        }

        return validationOutcome;
    }
}
