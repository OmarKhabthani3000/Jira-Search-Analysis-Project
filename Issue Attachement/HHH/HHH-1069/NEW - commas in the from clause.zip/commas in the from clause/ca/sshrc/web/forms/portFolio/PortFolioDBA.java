package ca.sshrc.web.forms.portFolio;

import java.util.*;

import ca.sshrc.web.common.services.*;
import hibernate.*;
import org.hibernate.*;
import org.apache.log4j.*;
import ca.sshrc.web.common.util.Constants;

public class PortFolioDBA {
    private Logger logger = Logger.getLogger(PortFolioDBA.class.getName());
    private List list;

    public List queryPortFolio(Integer webId, Integer subSystemId) {
        Integer daysPortofolioHistory = Constants.DAYS_PORTFOLIO_HISTORY;

        // If Final research report portfolio, switch number of days
        if (subSystemId.intValue() == 36) {
            daysPortofolioHistory = Constants.DAYS_PORTFOLIO_HISTORY_FINAL_REPORT;
        }

        try {
            try {
                Session session = HibernateUtil.getSession();
                HibernateUtil.beginTransaction();
                logger.info("PortFolioDBA.queryPortFolio - About to execute query ...");
                logger.info("PortFolioDBA.queryPortFolio - retrieving for subsystem id: " + subSystemId);

                /* Changed to handle all portfolio retrieval - Aug. 19 2005


                                 list = session.createQuery(
                 "select new ca.sshrc.web.forms.beans.portFolio.PortFolioBean( Form.application.applId, " +
                                        "Application.programId, " +
                                        "Application.applTitle, " +
                                        "Form.cid, " +
                                        "Form.webSubsystem.subsystemId, " +
                                        "Application.letterOfIntentInd, " +
                                        "Cod.shortNameFrench, " +
                                        "Cod.shortNameEnglish, " +
                                        "WebSubsystem.displayNameFrench, " +
                                        "WebSubsystem.displayNameEnglish, " +
                                        "Form.formStatus, " +
                                        "Form.formLanguage, " +
                                        "Form.changeDate, " +
                                        "Form.formId) " +
                                        "from Application Application, " +
                                        "WebSubsystem WebSubsystem, " +
                                        "WebSubsystemCrossref WebSubsystemCrossref, " +
                                        "Cod Cod, " +
                                        "Person Person, " +
                                        "Form Form " +
                                        "WHERE ( Application.grantType *= Cod.code) and " +
                                        "( Application.programId = WebSubsystem.program.programId ) and " +
                 "(WebSubsystem.subsystemId = WebSubsystemCrossref.comp_id.bySubsystemId) AND " +
                                        "( Application.webId = Person.cid ) and " +
                                        "( Form.webSubsystem.subsystemId = WebSubsystem.subsystemId ) and " +
                                        "( Form.application.applId = Application.applId ) and " +
                                        "( Application.webId = Form.cid ) and " +
                                        "( ( Application.webId = :webid ) AND " +
                                        "( (WebSubsystem.grantType = Application.grantType OR " +
                                        "Application.grantType is null) AND " +
                                        "(Application.letterOfIntentInd is null OR " +
                 "Application.letterOfIntentInd = WebSubsystem.letterOfIntentInd)) AND " +
                 "WebSubsystemCrossref.comp_id.byPortfolioSubsystemId = :subsysid AND " +
                                        "Application.finalReportInd = 'N' ) AND " +
                                        "(DATEDIFF(day,Form.changeDate, getdate()) < :numberOfDays OR " +
                 "DATEDIFF(day,Form.transferredToAmisDate, getdate()) < :numberOfDays) " +
                                        "order by 2 ASC, 3 ASC, 1 ASC ")
                                       .setParameter("webid", webId)
                                       .setParameter("subsysid", subSystemId)
                                       .setParameter("numberOfDays", Constants.DAYS_PORTFOLIO_HISTORY)
                                       .list();*/

                /* Prior to ANSI join upgrade
                 list = session.createQuery(
                        "select new ca.sshrc.web.forms.beans.portFolio.PortFolioBean( Form.application.applId, " +
                        "Application.programId, " +
                        "Application.applTitle, " +
                        "Form.cid, " +
                        "Form.webSubsystem.subsystemId, " +
                        "Application.letterOfIntentInd, " +
                        "Cod.shortNameFrench, " +
                        "Cod.shortNameEnglish, " +
                        "WebSubsystem.displayNameFrench, " +
                        "WebSubsystem.displayNameEnglish, " +
                        "Form.formStatus, " +
                        "Form.formLanguage, " +
                        "Form.changeDate, " +
                        "Form.formId) " +
                        "from Application Application, " +
                        "WebSubsystem WebSubsystem, " +
                        "WebSubsystemCrossref WebSubsystemCrossref, " +
                        "Cod Cod, " +
                        "Person Person, " +
                        "Form Form " +
                        "WHERE ( WebSubsystemCrossref.comp_id.byPortfolioSubsystemId = :subsysid ) AND " +
                        "( WebSubsystem.subsystemId = WebSubsystemCrossref.comp_id.bySubsystemId ) AND " +
                        "( Form.webSubsystem.subsystemId = WebSubsystem.subsystemId ) and " +
                        "( Form.cid = :webid ) and " +
                        "( Form.cid = Person.cid ) and " +
                        "( Form.application.applId = Application.applId ) and " +
                        "( Application.grantType *= Cod.code ) and " +
                        "( DATEDIFF(day,Form.changeDate, getdate()) < :numberOfDays OR " +
                        "DATEDIFF(day,Form.transferredToAmisDate, getdate()) < :numberOfDays) " +
                        "order by 2 ASC, 3 ASC, 1 ASC ")
                       .setParameter("webid", webId)
                       .setParameter("subsysid", subSystemId)
                       .setParameter("numberOfDays", daysPortofolioHistory)
                       .list();*/

                list = session.createQuery(
                        "select new ca.sshrc.web.forms.beans.portFolio.PortFolioBean( Form.application.applId, " +
                        "Application.program.programId, " +
                        "Application.applTitle, " +
                        "Form.person.cid, " +
                        "Form.webSubsystem.subsystemId, " +
                        "Application.letterOfIntentInd, " +
                        "Cod.shortNameFrench, " +
                        "Cod.shortNameEnglish, " +
                        "WebSubsystem.displayNameFrench, " +
                        "WebSubsystem.displayNameEnglish, " +
                        "Form.formStatus, " +
                        "Form.formLanguage, " +
                        "Form.changeDate, " +
                        "Form.formId) " +
                        "from WebSubsystem WebSubsystem join WebSubsystem.bySubsystemId as WebSubsystemCrossref " +
                        "join fetch WebSubsystem.form as Form " +
                        "join fetch Form.application as Application " +
                        "join fetch Form.webSubsystem as WebSubsystem " +
                        "join Form.person Person " +
                        "left outer join fetch Application.grantType as Cod " +
                        "left outer join Application.program as program " +
                        "WHERE ( WebSubsystemCrossref.comp_id.byPortfolioSubsystemId = :subsysid ) AND " +
                        "( Form.person.cid = :webid ) and " +
                        "( DATEDIFF(day,Form.changeDate, getdate()) < :numberOfDays OR " +
                        "DATEDIFF(day,Form.transferredToAmisDate, getdate()) < :numberOfDays) " +
                        "order by 2 ASC, 3 ASC, 1 ASC ")
                       .setParameter("webid", webId)
                       .setParameter("subsysid", subSystemId)
                       .setParameter("numberOfDays", daysPortofolioHistory)
                       .list();


                logger.info("PortFolioDBA.queryPortFolio - retrieved: " + list.size());

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    HibernateUtil.commitTransaction();
                    HibernateUtil.closeSession();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception ex1) {
            ex1.printStackTrace();
        }

        return list;
    }

    public Integer queryPortFolioSubSystemId(Integer subSystemId) {
        WebSubsystemCrossref webSubsystemCrossref = new WebSubsystemCrossref();
        Integer portFolioSubSystemId = null;

        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("PortFolioDBA.queryPortFolioSubSystemId - SubSystem id parameter: " + subSystemId);

            Query query = session.createQuery(
                    "select webSubsystemCrossref from WebSubsystemCrossref as webSubsystemCrossref where webSubsystemCrossref.comp_id.bySubsystemId.subsystemId = :subsysid")
                          .setParameter("subsysid", subSystemId);

            for (Iterator it = query.iterate(); it.hasNext(); ) {
                webSubsystemCrossref = (WebSubsystemCrossref) it.next();
                portFolioSubSystemId = webSubsystemCrossref.getComp_id().getByPortfolioSubsystemId().
                                       getSubsystemId();
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("PortFolioDBA.queryPortFolioSubSystemId - SubsystemId found: " +
                                portFolioSubSystemId);
                }
            }

//            HibernateUtil.commitTransaction();
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        return portFolioSubSystemId;
    }
}
